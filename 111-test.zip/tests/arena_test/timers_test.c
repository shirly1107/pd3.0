/*
 * Copyright 2017 NXP
 */

#include "fsl_types.h"
#include "common/fsl_stdio.h"
#include "common/fsl_string.h"
#include "fsl_smp.h"
#include "fsl_dbg.h"
#include "fsl_sl_dbg.h"

#include "fsl_timer.h"
#include "mpic_timers.h"

#define SYSTEM_TIMER  1
#define USER_TIMER    0

int sys_timer_test();

#define TMR_FLG_1     0
#define TMR_FLG_2     1
#define TMR_FLG_3     2
#define TMR_FLG_4     3
#define NUM_OF_TIMERS 4

uint32_t timer_flag[INTG_MAX_NUM_OF_CORES][NUM_OF_TIMERS] = {0};

static void f_timer_cb(void* data)
{
	uint32_t core_id = core_get_id();
	timer_flag[core_id][(uint32_t)data] = 1;

	pr_info("f_timer_expired, timer #%d\n", (uint32_t)data);
}

int sys_timer_test()
{
	void *h_tmr1, *h_tmr2, *h_tmr3, *h_tmr4;
	uint64_t curr_time_1, curr_time_2;
	uint32_t core_id = core_get_id();
	int i;

	pr_info("Timer test started\n");

	curr_time_1 = timer_current_time();
	timer_sleep(2); /* wait more than 1 mS */
	curr_time_2 = timer_current_time();

	/* Make sure timer global value is counting */
	if(curr_time_1 >= curr_time_2)
		return EACCES;

	pr_info("timer_current_time test done\n");

	pr_info("Testing sleep");
	for(i=0; i<5; i++) {
		timer_sleep(100);
		fsl_print(".");
	}
	fsl_print("\n");
	pr_info("timer_sleep test done\n");

	pr_info("Testing udelay");
	for(i=0; i<5; i++) {
		timer_udelay(100);
		fsl_print(".");
	}
	fsl_print("\n");
	pr_info("timer_udelay test done\n");

	if(IS_SIM)
	{
		/* Create timers for the test */
		h_tmr1 = timer_create();

		/* Initiate timer parameters */
		timer_init(h_tmr1, 1000, f_timer_cb, (void*)TMR_FLG_1, E_TIMER_MODE_SINGLE, SYSTEM_TIMER);

		/* Start the timer */
		timer_start(h_tmr1);

		while(timer_flag[core_id][TMR_FLG_1] == 0){}

		/* Free all timers used in the test */
		timer_free(h_tmr1);
	}
	else
	{
		/* Create timers for the test */
		h_tmr1 = timer_create();
		h_tmr2 = timer_create();
		h_tmr3 = timer_create();
		h_tmr4 = timer_create();

		/* Initiate timer parameters */
		timer_init(h_tmr1, 1000, f_timer_cb, (void*)TMR_FLG_1, E_TIMER_MODE_SINGLE, SYSTEM_TIMER);
		timer_init(h_tmr2, 2000, f_timer_cb, (void*)TMR_FLG_2, E_TIMER_MODE_SINGLE, USER_TIMER);
		timer_init(h_tmr3, 3000, f_timer_cb, (void*)TMR_FLG_3, E_TIMER_MODE_SINGLE, SYSTEM_TIMER);
		timer_init(h_tmr4, 4000, f_timer_cb, (void*)TMR_FLG_4, E_TIMER_MODE_SINGLE, USER_TIMER);

		/* Start the timers */
		timer_start(h_tmr1);
		timer_start(h_tmr2);
		timer_start(h_tmr3);
		timer_start(h_tmr4);

		/*
		 * Validate time expiration sequence
		 * Wait for timer #2 to expire
		 */
		while(timer_flag[core_id][TMR_FLG_2] == 0){}

		/* Timer #1 should expire before timer #2 */
		if(timer_flag[core_id][TMR_FLG_1] == 0)
			return -EACCES;

		timer_stop(h_tmr3);

		/* Wait for timer #4 to expire */
		while(timer_flag[core_id][TMR_FLG_4] == 0){}

		/* Timer #3 should be skipped */
		if(timer_flag[core_id][TMR_FLG_3] != 0)
			return -EACCES;

		/* Free all timers used in the test */
		timer_free(h_tmr1);
		timer_free(h_tmr2);
		timer_free(h_tmr3);
		timer_free(h_tmr4);
	}

	pr_info("Timer test: Done\n");

	return 0;
}
