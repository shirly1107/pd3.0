/*
 * Copyright 2017 NXP
 */

#include "common/fsl_string.h"
#include "include/fsl_sys.h"
#include "fsl_dpaiop_mc.h"

extern int test_edma();
extern int malloc_test();
extern int get_mem_test();
extern int sys_timer_test();
extern int tasklets_test();
extern int inject_packet(void);
extern int mpic_test();

int arena_app_init(void);
extern void cmdif_polling(void);

#define APPS                            	\
{                                       	\
	{arena_app_init},		\
	{NULL} /* never remove! */    	\
}

#define SEARCH_FOR_MC_COMMANDS 	\
	do {for (mc_i = 0; mc_i < 1000; mc_i++) cmdif_polling();} while(0)
 
void build_apps_array(struct sys_module_desc *apps);

void build_apps_array(struct sys_module_desc *apps)
{
	struct sys_module_desc apps_tmp[] = APPS;
	memcpy(apps, apps_tmp, sizeof(apps_tmp));
}

int arena_app_init(void)
{
	fsl_print("Running MC arena_app_init ...\n");
	struct dpaiop *dpaiop = NULL;
	uint32_t state = 0;
	int err = 0;
	uint64_t base_time = 0x1451425E900LL;
	int mc_i = 0;

	dpaiop = sys_get_handle(FSL_MOD_DPAIOP, 1, 0);

	if (dpaiop)
	{
		do {
			cmdif_polling();
			dpaiop_get_state(dpaiop, &state);
		} while (state == DPAIOP_STATE_BOOT_ONGOING);

		if (state == DPAIOP_STATE_RUNNING)
		{
			pr_info("=================================================================\n");
			pr_info("AIOP Boot Completed!\n");
			pr_info("=================================================================\n");
		}
		else
		{
			pr_info("=================================================================\n");
			pr_info("AIOP Run Failed!\n");
			pr_info("=================================================================\n");
			return -1;
		}

		err = dpaiop_set_time_of_day(dpaiop, base_time);
		if(err != 0) {
			pr_err("dpaiop_set_time_of_day failed (err: %d)\n", err);
			return err;
		}
	}
	else{
		pr_info("No DPAIOP in DPL, Running MC arena test only\n");
	}


	SEARCH_FOR_MC_COMMANDS;

	int rc = 0;
	rc = test_edma();
	SEARCH_FOR_MC_COMMANDS;

	rc |= malloc_test();
	SEARCH_FOR_MC_COMMANDS;

	rc |= get_mem_test();
	SEARCH_FOR_MC_COMMANDS;

	rc |= sys_timer_test();
	SEARCH_FOR_MC_COMMANDS;

	rc |= mpic_test();
	SEARCH_FOR_MC_COMMANDS;

	rc |= tasklets_test();
	SEARCH_FOR_MC_COMMANDS;

	/* Inject packets only if AIOP exists */
	if(dpaiop){
#ifndef GPP_TEST
		/* Inject packets from MC only if not running on simulator and no GPP */
		if(!IS_SIM)
		{
			err = inject_packet();
			if(err){
				pr_err("Injecting packets test failed: %d\n",err);
				rc |= err;
			}
			else{
				fsl_print("Injected packets SUCCESSFULLY\n");
			}
		}
#endif
	}


	if(rc){
		fsl_print("MC ARENA Test Finished with ERRORS\n");
	}
	else{
		if(!dpaiop){
			/* No need to notify that the test finished successfully if AIOP exists*/
			fsl_print("MC Arena Test Finished SUCCESSFULLY\n");
		}
	}
	/*The test will pass if AIOP app process packet finish successfully*/

	fsl_print("Running MC app, waiting for events ...\n");

	do {
		cmdif_polling();
	}while (1) ;

	return 0;
}
