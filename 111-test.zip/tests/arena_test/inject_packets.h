/*
 * Copyright 2017 NXP
 */

/******************************************************************************
 @File          inject_packet.h

 @Description   declaration of test functions.
 *//***************************************************************************/

#ifndef __INJECT_PACKET_H
#define __INJECT_PACKET_H



int inject_packet(void);

#endif /* __INJECT_PACKET_H */
