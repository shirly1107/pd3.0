/*
 * Copyright 2017 NXP
 */

#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "fsl_io.h"
#include "fsl_platform.h"
#include "fsl_malloc.h"
#include "fsl_smp.h"
#include "mpic.h"
#include "drivers/fsl_mcpic.h"
#include "drivers/fsl_mc.h"

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_soc.h"

#include "fsl_tasklet.h"

#define INSANE_AMOUNT_OF_TASKLETS 100000

#define DELAYED_DATA_VAL   42
#define IMMEDIATE_DATA_VAL 43

#define BLOCKING_MSG 1
#define NON_BLOCKING_MSG 0
#define ISR_ARG      44
#define MSG_DATA     45

uint32_t num_of_scheduled_tasklets[INTG_MAX_NUM_OF_CORES] = {0};
uint32_t tasklet_test_val[INTG_MAX_NUM_OF_CORES] = {0};

int tasklets_test();
void mc_msg_isr(uint32_t arg);
void tasklet_im(uint64_t data);
void tasklet_de(uint64_t data);
void tsklt_mc_msg_isr(uint32_t arg);

void tasklet_im(uint64_t data)
{
	uint32_t core_id = core_get_id();
	//pr_info("Immediate tasklet\n");

	ASSERT_COND(data == IMMEDIATE_DATA_VAL);

	tasklet_test_val[core_id]++;
}

void tasklet_de(uint64_t data)
{
	uint32_t core_id = core_get_id();
	//pr_info("Delayed tasklet\n");

	ASSERT_COND(data == DELAYED_DATA_VAL);

	tasklet_test_val[core_id]++;
}

static void tsklt_mc_read_msg()
{
	uint32_t msg_data;
	uint32_t core_id = core_get_id();

	mpic_read_msg(MC_MPIC_INTR_MSG_0 + core_id, &msg_data);
	
	ASSERT_COND(msg_data == MSG_DATA);
}

void tsklt_mc_msg_isr(uint32_t arg)
{
	int err, i;	
	uint32_t core_id = core_get_id();
	tsklt_mc_read_msg();
	
	ASSERT_COND(arg == ISR_ARG);
	
	for(i=0; i<INSANE_AMOUNT_OF_TASKLETS; i++)
	{
		err = fsl_schedule_tasklet(tasklet_de, DELAYED_DATA_VAL, tsk_priority_delayed);
		if(err != 0) {
			break;
		}
		num_of_scheduled_tasklets[core_id]++;

		err = fsl_schedule_tasklet(tasklet_im, IMMEDIATE_DATA_VAL, tsk_priority_immediate);
		if(err != 0) {
			break;
		}
		num_of_scheduled_tasklets[core_id]++;
	}
	
	pr_info("Scheduled %d tasklets\n", num_of_scheduled_tasklets[core_id]);
}

int tasklets_test()
{
	uint32_t core_id = core_get_id();
	mpic_intr_params_t intr_params;
	int err;
	
	pr_info("Starting tasklets test\n");
	
	intr_params.polarity = OS_MPIC_INTR_POLARITY_HIGH;
    intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;
	intr_params.sense = OS_MPIC_INTR_SENSE_EDGE;
    intr_params.priority = 0xa;

    /* Interrupt registration */
	err = mpic_set_config_intr(MC_MPIC_INTR_MSG_0 + core_id, core_id, tsklt_mc_msg_isr, ISR_ARG, &intr_params);
	if(err != 0) {
		return err;
	}
	err = mpic_enable_intr(MC_MPIC_INTR_MSG_0 + core_id);
	if(err != 0) {
		return err;
	}
    
    /* Write the message */
    err = mpic_write_msg(MC_MPIC_INTR_MSG_0 + core_id, MSG_DATA, NON_BLOCKING_MSG);
	if(err != 0) {
		return err;
	}
	
	err = mpic_disable_intr(MC_MPIC_INTR_MSG_0 + core_id);
	if (err != 0)
		return err;

	err = mpic_free_intr(MC_MPIC_INTR_MSG_0 + core_id);
	if (err != 0)
		return err;

    /* Validate teset results */
    if(tasklet_test_val[core_id] != num_of_scheduled_tasklets[core_id]) {
    	pr_err("Not all scheduled tasklets were executed (scheduled: %d, exec: %d)\n",
    			num_of_scheduled_tasklets[core_id], tasklet_test_val[core_id]);
    	return -ETIMEDOUT;
    }
    
    pr_info("Tasklets test - Done (executed %d tasklets)\n", tasklet_test_val[core_id]);
    
    return 0;
}
