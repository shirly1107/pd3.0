/*
 * Copyright 2017 NXP
 */

/******************************************************************************
 @File          inject_packets.c

 @Description   test implementation.
 *//***************************************************************************/

/************/
/* INCLUDES */
/************/

#include "common.h"

#include "fsl_types.h"
#include "fsl_dprc_mc.h"
#include "fsl_dpmac_mc.h"
#include "kernel/device.h"
#include "fsl_errors.h"
#include "common/fsl_string.h"			/* memset */
#include "include/fsl_sys.h"
#include "fsl_malloc.h"
#include "fsl_dpmng_mc.h"			/* dpmng_amq */
#include "fsl_dpmac_mc.h"			/* dpmac */
#include "fsl_dpni_mc.h"			/* dpni */
#include "fsl_dpio_mc.h"			/* dpio */
#include "fsl_dpbp_mc.h"			/* dpbp */
#include "fsl_dpsw_mc.h"			/* L2 Switch */
#include "drivers/fsl_qbman_portal.h"		/* BMan */
#include "drivers/fsl_qbman_ctrl.h"		/* BMan */
#include "fsl_linkman.h"			/* Link Manager */
#include "drivers/fsl_edma.h"

/*Declaration for test function*/
int inject_packet(void);
/************/
/*  DEFINES */
/************/
#if defined (IPR_DEMO) | defined (IPF_DEMO)
	#define TEST_BUFFER_SIZE	5120
#else
	#define TEST_BUFFER_SIZE	512
#endif
#define TEST_BUFFER_NUM		20
#define MAC_ID			1
/* enabled/disable use cases (comment out to disable) */
#define UC_ENABLED_DPNI2DPNI_SEND

#ifdef IPR_DEMO
	#define PACKET_MODIFIED_IN_AIOP
#endif
#ifdef IPSEC_DEMO
	#define PACKET_MODIFIED_IN_AIOP
#endif

/************/
/*  GLOBALS */
/************/
static int err_counters;
/* define here the dpmng context type of the test objects */
const enum dpmng_ctx_type global_objects_context = DPMNG_CTX_TYPE_GPP;

/* -------------------------------------------------------------- */

/********************************/
/* Static functions declaration */
/********************************/
/* initialization functions */

static int init_dpni(struct dpni **dpni_p, int reset);

static int init_objects(struct dpni **dpni_mc,
	struct dpbp **dpbp,
	struct dpio **dpio,
	struct qbman_swp **swp);
static int destroy_objects(struct dpni *dpni_mc,
	struct dpio *dpio,
	struct dpbp *dpbp);
/* configuration functions */
static int configure_dpni_mac_addr(struct dpni *dpni, const uint8_t *mac_addr);
static int configure_connect(struct dpni *dpni1, uint16_t aiop_niid);
static int send_event(enum linkman_event event,
	uint16_t dpmac_id,
	uint16_t dpni_id);

/* use case functions */
static int check_dpni2dpni_frame_sending(struct dpni *dpni_tx,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	const uint8_t *tx_frame,
	uint32_t tx_length,
	int frame_number);

/*****************/
/* Test Function */
/*****************/
int inject_packet(void)
{
	/******************************/
	/*          Variables         */
	/******************************/
	/* objects handles */
	struct dpni *dpni_mc;
	uint16_t aiop_niid = 1;
	struct dpmac *dpmac = NULL;
	struct dpbp *dpbp = NULL;
	struct dpio *dpio = NULL;
	struct qbman_swp *swp = NULL;
	const int dpni_num = 1;
		/* frame */
#ifdef IPR_DEMO
 	const uint8_t *tx_frame = reass_frame_hm;
 	uint32_t tx_length = sizeof(reass_frame_hm);
#elif defined (IPF_DEMO)
 	const uint8_t *tx_frame = frame_for_frag;
 	uint32_t tx_length = sizeof(frame_for_frag);
 #elif defined (IPSEC_DEMO)
	const uint8_t *tx_frame = ipsec_plain_packet;
	uint32_t tx_length = sizeof(ipsec_plain_packet);
 #else
	const uint8_t *tx_frame = frame_00_00_01_00_00_01_8023_64;
	uint32_t tx_length = sizeof(frame_00_00_01_00_00_01_8023_64);
#endif

	/* misc */
	int err, err_dpni2dpni, err_destroy;

	/***************************/
	/*     Initializations     */
	/***************************/
	err_counters = 0;
	/* init objects */
	err = init_objects(&dpni_mc, &dpbp, &dpio, &swp);
	LOOP_ON_ERR(err, "objects initialization");

	/***************************/
	/*      Configuration      */
	/***************************/

	err = configure_dpni_mac_addr(dpni_mc, tx_frame);
	LOOP_ON_ERR(err, "configure_dpni_mac_addr");

	err = configure_connect(dpni_mc, aiop_niid);
	LOOP_ON_ERR(err, "configure_connect");

	/***************************/
	/*  send frame dpni->dpni  */
	/***************************/

	err = check_dpni2dpni_frame_sending(dpni_mc, dpbp,
						swp, tx_frame, tx_length, 1);
	err_dpni2dpni = err;
	fsl_print("-------------------------------------------------\n");
	fsl_print("send frame dpni_mc->dpni_aiop: %s!\n",
			((err != 0) ? "FAIL" : "PASS"));
	fsl_print("-------------------------------------------------\n");

#if 0
	err = dpni_reset(dpni_mc);
	LOOP_ON_ERR(err, "dpni_reset");

	init_dpni(&dpni_mc, 1);

	err = ni_set_pool(dpni_mc, dpbp, TEST_BUFFER_SIZE);
	LOOP_ON_ERR(err, "ni_set_pool");

	/* enable */
	err = dpni_enable(dpni_mc);
	LOOP_ON_ERR(err, "dpni_enable");
#endif


	err = check_dpni2dpni_frame_sending(dpni_mc, dpbp,
						swp, tx_frame, tx_length, 2);
	err_dpni2dpni = err;
	fsl_print("-------------------------------------------------\n");
	fsl_print("send frame dpni_mc->dpni_aiop: %s!\n",
			((err != 0) ? "FAIL" : "PASS"));
	fsl_print("-------------------------------------------------\n");


	/***************************/
	/*         Destroy         */
	/***************************/
	err = destroy_objects(dpni_mc, dpio, dpbp);
	err_destroy = err;
	fsl_print("destroy_objects: %s!\n", ((err != 0) ? "FAIL" : "PASS"));

	/****************************/
	/* Print Successes/Failures */
	/****************************/
	/* print use cases results */
	fsl_print("-------------------------------------------------\n");
	fsl_print("Bring Up Test #4 Finished:\n");

#ifdef UC_ENABLED_DPNI2DPNI_SEND
	fsl_print("\t Receive frame:   \t %s!\n",
			((err_dpni2dpni != 0) ? "FAIL" : "PASS"));
	fsl_print("\t Counters check:  \t %s!\n",
			((err_counters != 0) ? "FAIL" : "PASS"));
#endif

	fsl_print("\t Objects Destroy: \t %s!\n",
			((err_destroy != 0) ? "FAIL" : "PASS"));

	if ((err_dpni2dpni == 0) && (err_counters == 0) && (err_destroy == 0))
		fsl_print("Finished SUCCESSFULLY\n");
	else 
		fsl_print("Finished with ERRORS\n");

	while (1) {
	};

	return 0;
}

/*******************************/
/*        Static functions     */
/*******************************/
/*-------------------------initialization functions---------------------------*/

static int init_objects(struct dpni **dpni_mc,
	struct dpbp **dpbp,
	struct dpio **dpio,
	struct qbman_swp **swp)
{
	int err;

	/* dpio */
	err = init_dpio(dpio);
	CHECK_ERR(err, "init_dpio");

	/* swp */
	err = init_swp(swp, *dpio);
	CHECK_ERR(err, "init_swp");

	/* dpbp */
	err = init_dpbp(dpbp);
	CHECK_ERR(err, "init_dpbp");

	err = init_dpbp_buffers(*dpbp, *swp, TEST_BUFFER_NUM,
				TEST_BUFFER_SIZE);
	CHECK_ERR(err, "init_dpbp_buffers");

	/* dpni-s */
	/* Init */
	err = init_dpni(dpni_mc, 0);
	CHECK_ERR(err, "init_dpni");

	/* attach buffer pool */
	err = ni_set_pool(*dpni_mc, *dpbp, TEST_BUFFER_SIZE);
	CHECK_ERR(err, "ni_set_pool");

	/* enable */
	err = dpni_enable(*dpni_mc);
	CHECK_ERR(err, "dpni_enable");

	return 0;
}

static int init_dpni(struct dpni **dpni_p, int reset)
{
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpni_cfg cfg = { 0 };
	struct dpni *dpni;
	void *dev = NULL;
	int err;

	if (!reset) {
		/* allocation */
		*dpni_p = dpni_allocate();
		err = (*dpni_p == NULL);
		CHECK_ERR(err, "dpni allocation");
		err = create_resman_device("dpni", &dev);
		CHECK_ERR(err, "create_resman_device (dpni)");
	}
	/* init */
	dpni = *dpni_p;
	cfg.mac_addr[5] = 0x01;
	cfg.adv.options |= DPNI_OPT_TX_CONF_DISABLED;
	dev_cfg.device = dev;
	dev_cfg.id = device_get_id(dev);
	dev_cfg.ctx.type = global_objects_context;

	if (!reset) {
		err = dpni_init(dpni, &cfg, &dev_cfg);
		CHECK_ERR(err, "dpni_init");
	}
	err = dpni_set_dev_ctx(dpni, &dev_cfg.ctx);
	CHECK_ERR(err, "dpni_set_dev_ctx");

	err = dpni_set_unicast_promisc(dpni, 1);
	CHECK_ERR(err, "dpni_set_unicast_promisc");
	err = dpni_set_multicast_promisc(dpni, 1);
	CHECK_ERR(err, "dpni_set_unicast_promisc");

#if defined (IPR_DEMO) | defined (IPF_DEMO)
	err = dpni_set_max_frame_length(dpni, 0x2000);
	CHECK_ERR(err, "max_frame_length");
#endif


#if 0
	{
		struct dpni_error_cfg cfg = {0};
		cfg.error_action = DPNI_ERROR_ACTION_SEND_TO_ERROR_QUEUE;
		cfg.errors = 0xffffffff;
		cfg.set_frame_annotation = 1;
		err = dpni_set_errors_behavior(dpni, &cfg);
		CHECK_ERR(err, "dpndpni_set_errors_behavior");
	}
#endif
	/* Register NI in RM*/
	if (!reset) {
		device_set_priv(dev, dpni);
		err = sys_add_handle(dpni, FSL_MOD_DPNI, 1, dev_cfg.id);
		CHECK_ERR(err, "sys_add_handle (dpni)");
	}
	return 0;
}

static int destroy_objects(struct dpni *dpni_mc,
	struct dpio *dpio,
	struct dpbp *dpbp)
{
	struct dpni *dpni;
	struct dpni_attr dpni_attr;
	struct dpbp_attr dpbp_attr;
	struct dpio_attr dpio_attr;
	int err;

	/* dpni */

	dpni = dpni_mc;
	err = dpni_get_attributes(dpni, &dpni_attr);
	CHECK_ERR(err, "dpni_get_attributes");
	dpni_destroy(dpni);
	sys_remove_handle(FSL_MOD_DPNI, 1, dpni_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpni)");
	dpni_deallocate(dpni);
	CHECK_ERR(err, "dpni_deallocate");

	/* dpbp */
	err = dpbp_get_attributes(dpbp, &dpbp_attr);
	CHECK_ERR(err, "dpbp_get_attributes");
	dpbp_destroy(dpbp);
	sys_remove_handle(FSL_MOD_DPBP, 1, dpbp_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpbp)");
	dpbp_deallocate(dpbp);
	CHECK_ERR(err, "dpbp_deallocate");

	/* dpio */
	err = dpio_get_attributes(dpio, &dpio_attr);
	CHECK_ERR(err, "dpio_get_attributes");
	dpio_destroy(dpio);
	sys_remove_handle(FSL_MOD_DPIO, 1, dpio_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpio)");
	dpio_deallocate(dpio);
	CHECK_ERR(err, "dpio_deallocate");

	return 0;
}

/*------------------------- Configuration Functions --------------------------*/

static int configure_dpni_mac_addr(struct dpni *dpni, const uint8_t *mac_addr)
{
	int err;

	err = dpni_set_primary_mac_addr(dpni, mac_addr);
	CHECK_ERR(err, "dpni_set_primary_mac_addr");
	return 0;
}

static int configure_mac_loopback(struct dpmac *dpmac, int enabled)
{
	int err;

	err = dpmac_set_loopback(dpmac, enabled);
	CHECK_ERR(err, "dpmac_set_loopback");

	return 0;
}

static int configure_connect(struct dpni *dpni1, uint16_t aiop_niid)
{
	struct dpni_attr dpni_attr;
	uint16_t dpni_id1;
	int err;

	/* get dpni id-s */
	err = dpni_get_attributes(dpni1, &dpni_attr);
	CHECK_ERR(err, "dpni_get_attr");
	dpni_id1 = (uint16_t)dpni_attr.id;

	fsl_print("mc dpni %d\n", dpni_id1);
	fsl_print("aiop dpni %d\n", aiop_niid);

	/*! Connect */
	err = send_event(LINKMAN_EVENT_CONNECT, /*! Event */
				dpni_id1, /*! mac ID */
				aiop_niid); /* peer connector id */
	CHECK_ERR(err, "send_event (connect)");

	/*! Link up */
	err = send_event(LINKMAN_EVENT_LINKUP, /*! Event */
				dpni_id1, /*! mac ID */
				aiop_niid); /*! peer connector id */

	CHECK_ERR(err, "send_event (link up)");

	return 0;
}

static int send_event(enum linkman_event event,
	uint16_t dpmac_id,
	uint16_t dpni_id)
{
	int err;
	struct linkman_endpoint self; /* dpni1 */
	struct linkman_endpoint peer; /* dpni2 */
	struct linkman_control control; /* dpni2 */
	struct linkman *linkman = NULL;

	memset(&self, 0x0, sizeof(struct linkman_endpoint));
	memset(&peer, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));

	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	err = (linkman == NULL);
	CHECK_ERR(err, "sys_get_unique_handle");

	/* dpmac */
	self.id = (uint16_t)dpmac_id; /* Switch ID */
	self.type = FSL_MOD_DPNI; /* Type */

	/* Peer connector */
	peer.type = FSL_MOD_DPNI; /* peer type*/
	peer.id = dpni_id; /* peer id */

	control.event = event;
	/* Start link up state machine */
	err = linkman_set_connection(linkman, /*! context */
					&control, /*! control */
					&self, /*! endpoint 1 */
					&peer); /*! endpoint 2 */

	return err;
}

/*--------------------------- Use Cases Functions ----------------------------*/

static int check_dpni2dpni_frame_sending(struct dpni *dpni_tx,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	const uint8_t *tx_frame,
	uint32_t tx_length,
	int frame_number)
{
#ifdef IPR_DEMO
	uint8_t rx_frame[sizeof(reass_frame_hm)];
#elif defined (IPF_DEMO)
	uint8_t rx_frame[sizeof(frag1_hm)];
#elif defined (IPSEC_DEMO)
	uint8_t rx_frame[sizeof(ipsec_plain_packet)];
#else
	uint8_t rx_frame[sizeof(frame_00_00_01_00_00_01_8023_64)];
#endif
	uint32_t rx_length;
	int err, i, err_counters = 0;
	/* frames */

	struct dpni_link_state state;

	err = dpni_get_link_state(dpni_tx, &state);
	CHECK_ERR(err, "dpni_get_link_state");
	if (!state.up)
		CHECK_ERR(1, "link down on dpni-tx");

	//err = dpni_get_link_state(dpni_rx, &state);
	CHECK_ERR(err, "dpni_get_link_state");
	if (!state.up)
		CHECK_ERR(1, "link down on dpni-rx");

	dump_dpni_counters(dpni_tx, "dpni tx before sending");
	//dump_dpni_counters(dpni_rx, "dpni rx before receiving");

#ifdef IPR_DEMO
	err = test_send_frame(dpni_tx, dpbp, swp, frag1, sizeof(frag1),
			0 /* no special options */,
			0 /* no tx flow id */);
	CHECK_ERR(err, "frag1 send");
	err = test_send_frame(dpni_tx, dpbp, swp, frag2, sizeof(frag2),
			0 /* no special options */,
			0 /* no tx flow id */);
	CHECK_ERR(err, "frag2 send");
	err = test_send_frame(dpni_tx, dpbp, swp, frag3, sizeof(frag3),
			0 /* no special options */,
			0 /* no tx flow id */);
	CHECK_ERR(err, "frag3 send");
	err = test_send_frame(dpni_tx, dpbp, swp, frag4, sizeof(frag4),
			0 /* no special options */,
			0 /* no tx flow id */);
	CHECK_ERR(err, "frag4 send");

	dump_dpni_counters(dpni_tx, "dpni tx after sending");

	/* check counters */
	{
		err_counters |= check_dpni_counter(dpni_tx, DPNI_CNT_EGR_FRAME,
										   4 * frame_number);
		err_counters |= check_dpni_counter(dpni_tx, DPNI_CNT_EGR_BYTE,
				frame_number *	(sizeof(frag1)+ sizeof(frag2)+ sizeof(frag3)+ sizeof(frag4)));
	}
#else
		err = test_send_frame(dpni_tx, dpbp, swp, tx_frame, tx_length,
				0 /* no special options */,
				0 /* no tx flow id */);
		CHECK_ERR(err, "frame send");

		dump_dpni_counters(dpni_tx, "dpni tx after sending");

		/* check counters */
		{
			err_counters |= check_dpni_counter(dpni_tx, DPNI_CNT_EGR_FRAME,
												frame_number);
			err_counters |= check_dpni_counter(dpni_tx, DPNI_CNT_EGR_BYTE,
										frame_number * tx_length);
		}
#endif

	/* receive frame */

	print_port_counters(EIOP_ETHERNET_PORT, 17);
	print_port_counters(EIOP_ETHERNET_PORT, 18);

	fsl_print("tx_length: %d\n", tx_length);

#ifdef IPF_DEMO
for (i=1;i<5;i++)
{
	/* receive frame */
	err = test_receive_frame(
		dpni_tx, swp, rx_frame, &rx_length,
		1 /* keep polling if queue is empty */);
	CHECK_ERR(err, "frame receive");

	/* compare frames */
	if (i == 1){
		err = (sizeof(frag1_hm) != rx_length);
		CHECK_ERR(
			err, "check length of 1st fragment");
		err = (memcmp(frag1_hm, rx_frame, rx_length));
		CHECK_ERR(
			err, "check data equality of 1st received fragment");
	}
	else if (i == 2){
		err = (sizeof(frag2_hm) != rx_length);
		CHECK_ERR(
			err, "check length of 2nd fragment");
		err = (memcmp(frag2_hm, rx_frame, rx_length));
		CHECK_ERR(
			err, "check data equality of 2nd received fragment");
		}
	else if (i == 3){
		err = (sizeof(frag3_hm) != rx_length);
		CHECK_ERR(
			err, "check length of 3rd fragment");
		err = (memcmp(frag3_hm, rx_frame, rx_length));
		CHECK_ERR(
			err, "check data equality of 3rd received fragment");
		}
	else {
		err = (sizeof(frag4_hm) != rx_length);
		CHECK_ERR(
				err, "check length of last fragment");
		err = (memcmp(frag4_hm, rx_frame, rx_length));
		CHECK_ERR(
			err, "check data equality of last received fragment");
		}
}

dump_dpni_counters(dpni_tx, "dpni rx after receiving (same dpni)");

/* check counters */
{
	err_counters |= check_dpni_counter(dpni_tx, DPNI_CNT_ING_FRAME,
	                                   4 * frame_number);
	err_counters |= check_dpni_counter(dpni_tx, DPNI_CNT_ING_BYTE,
			frame_number * (sizeof(frag1_hm)+sizeof(frag2_hm)+sizeof(frag3_hm)+sizeof(frag4_hm)));
}

print_port_counters(EIOP_ETHERNET_PORT, 17);
print_port_counters(EIOP_ETHERNET_PORT, 18);


#else
	/* receive frame */
	err = test_receive_frame(
		dpni_tx, swp, rx_frame, &rx_length,
		1 /* keep polling if queue is empty */);
	CHECK_ERR(err, "frame receive");

	dump_dpni_counters(dpni_tx, "dpni rx after receiving (same dpni)");

	/* check counters */
	{
		err_counters |= check_dpni_counter(dpni_tx, DPNI_CNT_ING_FRAME,
										frame_number);
		err_counters |= check_dpni_counter(dpni_tx, DPNI_CNT_ING_BYTE,
								frame_number * rx_length);
	}

	print_port_counters(EIOP_ETHERNET_PORT, 17);
	print_port_counters(EIOP_ETHERNET_PORT, 18);

	/* debug prints */
	fsl_print("rx_length: %d\n", rx_length);
	fsl_print("tx_length: %d\n", tx_length);
#ifndef IPR_DEMO
	fsl_print("dump tx frame:\n");
	for (i = 0; i < tx_length; i++) {
		fsl_print("0x%02x ", tx_frame[i]);
		if(i > 0 && (i + 1) % 16 == 0)
			fsl_print("\n");
	}
	fsl_print("\n");
	fsl_print("dump rx frame:\n");
	for (i = 0; i < rx_length; i++) {
		fsl_print("0x%02x ", rx_frame[i]);
		if(i > 0 && (i + 1) % 16 == 0)
			fsl_print("\n");
	}
	fsl_print("\n");

#endif

	/* compare frames */
	err = (tx_length != rx_length);
	CHECK_ERR(
		err,
		"check length equality of transmitted and received frames");
#ifdef PACKET_MODIFIED_IN_AIOP
	err = (memcmp(tx_frame, rx_frame, rx_length));
	fsl_print("dump rx frame:\n");
	for (i = 0; i < rx_length; i++) {
		fsl_print("0x%02x ", rx_frame[i]);
		if(i > 0 && (i + 1) % 16 == 0)
			fsl_print("\n");
	}

	CHECK_ERR(
		err, "check data equality of transmitted and received frames");
#endif
#endif
return 0;
}

static int check_loopback_disabled(struct dpni *dpni,
	struct dpmac *dpmac,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	const uint8_t *tx_frame,
	uint32_t tx_length)
{
	int err, receive_err;
	/* frames */
	uint8_t rx_frame[sizeof(frame_00_00_01_00_00_01_8023_64)];
	uint32_t rx_length;

	/* enable loop back */
	err = configure_mac_loopback(dpmac, 0);
	CHECK_ERR(err, "configure_mac_loopback (disabled)");

	/* send frame */
	err = test_send_frame(dpni, dpbp, swp, tx_frame, tx_length,
				0 /* no special options */,
				0 /* no tx flow id */);
	CHECK_ERR(err, "frame send");

	/* receive frame */
	receive_err = test_receive_frame(
		dpni, swp, rx_frame, &rx_length,
		0 /* don't keep polling if queue is empty */);
	err = (receive_err != -ENAVAIL);
	CHECK_ERR(err, "frame not received (-ENAVAIL is returned)");

	return 0;
}

