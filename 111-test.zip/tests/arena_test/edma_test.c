/*
 * Copyright 2017 NXP
 */


#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_io.h"
#include "fsl_platform.h"
#include "dma/edma.h"
#include "drivers/fsl_edma.h"
#include "dma/edma_init.h"
#include "hw_sem.h"
#include "fsl_smp.h"
#include "fsl_dbg.h"
#include "fsl_malloc.h"
#include <cstring>


#define __ERR_MODULE__  MODULE_EDMA

static void config_peb_window();
static void config_dp_ddr_window();
static void config_system_ddr_window();

static int test_dp_ddr2dmem_transac();
static int test_peb2dmem_transac();
static int test_system_ddr2dmem_transac();
static int test_dmem2dmem_transac();
static int test_system_ddr2local_transac();




/*
 This file is an example how to use edma_init_api API for initialization
 purposes and use edma_transcation() in run-time.
 */
#define MC_C1SAWBALR 0x21010000
#define MC_C1SAWBAHR 0x21010004
#define MC_C2SAWBALR 0x21011000
#define MC_C2SAWBAHR 0x21011004



#define VALUE_TO_COPY 0xdeadbeef
#define NUM_BYTES_TO_COPY 0x10

/* Take the maximum of num. of entries in SQ and CQ to test wrap around condition*/
#define max(a,b) ((a) > (b) ? (a):(b))
#define NUM_TRANSAC (max(NUM_ENTRIES_IN_SQ,NUM_ENTRIES_IN_CQ)+1)
//#define NUM_TRANSAC 1
#define RUN_NUMBER 97

int test_edma();

int test_edma()
{

	int rc = 0, error = 0;
	pr_info("Running test_dmem2dmem_transac-%d...\n",RUN_NUMBER);
	rc =  test_dmem2dmem_transac();
	if(0 != rc)
	        error  = 1;
	if(fsl_mem_exists(MEM_PART_DP_DDR))
	{
		pr_info("Running test_dp_ddr2dmem_transac-%d...\n",RUN_NUMBER);
		rc = test_dp_ddr2dmem_transac();
		if(0 != rc)
			error  = 1;
	}
	if(fsl_mem_exists(MEM_PART_PEB))
	{
		pr_info("Running test_peb2dmem_transac-%d...\n",RUN_NUMBER);
		rc = test_peb2dmem_transac();
		if(0 != rc)
			error = 1;
	}
	if(fsl_mem_exists(MEM_PART_SYSTEM_DDR1))
	{
		pr_info("Running test_system_ddr2dmem_transac-%d...\n",RUN_NUMBER);
		rc = test_system_ddr2dmem_transac();
		if(0 != rc)
			error = 1;
	}
	if(fsl_mem_exists(MEM_PART_SYSTEM_DDR1))
	{
		pr_info("Running test_system_ddr2local_transac-%d...\n",RUN_NUMBER);
		rc = test_system_ddr2local_transac();
		if(0 != rc)
			error = 1;
	}
	return error;
}

int test_dp_ddr2dmem_transac()
{
	struct edma_queue *p_queue;
	struct edma_transfer params;
	void *p_virt_dst = fsl_xmalloc(NUM_BYTES_TO_COPY*NUM_TRANSAC,MEM_PART_DMEM1,1);
	uint32_t dst_vaddr = (uint32_t)p_virt_dst;
	uint32_t value = 0,block_id = 0,queue_id = 0;
	int rc = 0;
	enum transac_status status;
	dma_addr_t source_paddr = 0;
	uint32_t source_vaddr = 0; /* address in SoC window  for core's access */
	struct dpmng_amq amq = {0};
	dpmng_get_amq(&amq);
	if(NULL == p_virt_dst)
	{
            pr_err("fsl_xmalloc() returned no DMEM1 memory available\n");
	    return -EIO;
	}
	if(fsl_get_mem(NUM_BYTES_TO_COPY*NUM_TRANSAC,
                       MEM_PART_DP_DDR,1,
		       &source_paddr) != 0)
	{
	    fsl_xfree(p_virt_dst);
	    pr_err("fsl_get_mem() returned no dp-ddr memory available\n");
	    return -EIO;
	}

	/* configure SoC Window  to enable core to write into dp-ddr*/
	source_vaddr = (uint32_t)dpmng_mc_set_soc_window(source_paddr,&amq);
	if(!sys_is_master_core())
	    block_id = 1;
	memset(&params,0, sizeof(params));
	params.byte_count = NUM_BYTES_TO_COPY;
	params.src_icid = 0x0; // an arbitrary value only for demonstration
	params.dst_icid = 0x0; // an arbitrary value only for demonstration
	params.flags |= EDMA_DEST_ADDR_IA | EDMA_DEST_ADDR_PL | EDMA_DEST_ADDR_BMT;
	/* Source address is a physical adress */
	params.flags |= EDMA_SRC_ADDR_PL | EDMA_SRC_ADDR_BMT;
	/* Retrieve queue_0 from block 0 */
	p_queue = sys_get_handle(FSL_MOD_EDMA_BLOCK_QUEUE,3/* number of arguments to follow*/,0,block_id,queue_id);
	// Going over a loop of 127 eDMA transactions and execute it with step of 0x100.
	for(int i = 0 ; i < NUM_TRANSAC; i++)
	{
		params.src = source_paddr;
		params.dst =  dst_vaddr;
		// zero memory
		iowrite32(0,UINT_TO_PTR(dst_vaddr));
		iowrite32(VALUE_TO_COPY,UINT_TO_PTR(source_vaddr));
		rc = edma_queue_transfer(p_queue,&params,&status);
		value = ioread32(UINT_TO_PTR(dst_vaddr));
		if(status != EDMA_NORMAL || value != VALUE_TO_COPY){
			fsl_xfree(p_virt_dst);
			fsl_put_mem(source_paddr);
			pr_err("test_dp_ddr2dmem_transac failed\n");
			return EIO;
		}
		dst_vaddr += NUM_BYTES_TO_COPY;
		source_vaddr += NUM_BYTES_TO_COPY;
		source_paddr += NUM_BYTES_TO_COPY;
	}
	fsl_xfree(p_virt_dst);
	fsl_put_mem(source_paddr);
	pr_info("test_dp_ddr2dmem_transac  succeeded, src.addr=0x%x%08x, dst.addr=0x%x\n",
	        (uint32_t)(source_paddr>>32),(uint32_t)source_paddr,dst_vaddr);
	return 0;
}

int test_peb2dmem_transac()
{
	struct edma_queue *p_queue;
	struct edma_transfer params;
	uint32_t source_vaddr = 0;/* address in SoC window  for core's access */
	dma_addr_t source_paddr =  0;
	void *p_virt_dst = fsl_xmalloc(NUM_BYTES_TO_COPY*NUM_TRANSAC,MEM_PART_DMEM1,1);
	uint32_t dst_vaddr = (uint32_t)p_virt_dst;
	uint32_t value = 0,block_id = 0,queue_id = 0;
	int rc = 0;
	enum transac_status status;
	struct dpmng_amq amq = {0};
	dpmng_get_amq(&amq);
	if(NULL == p_virt_dst)
	{
	    pr_err("fsl_xmalloc() returned no DMEM1 memory available\n");
	    return -EIO;
	}
	if(fsl_get_mem(NUM_BYTES_TO_COPY*NUM_TRANSAC,
	               MEM_PART_PEB,1,
		       &source_paddr) != 0)
	{
	    fsl_xfree(p_virt_dst);
	    pr_err("fsl_get_mem() returned no peb memory available\n");
	    return -EIO;
	}
	/* configure SoC Window  to enable core to write into peb*/
	source_vaddr = (uint32_t)dpmng_mc_set_soc_window(source_paddr,&amq);
	if(!sys_is_master_core())
			block_id = 1;
	memset(&params,0, sizeof(params));
	params.byte_count = NUM_BYTES_TO_COPY;
	params.src_icid = 0x0; // an arbitrary value only for demonstration
	params.dst_icid = 0x0; // an arbitrary value only for demonstration
	/* Destination address is an internal address */
	params.flags |= EDMA_DEST_ADDR_IA | EDMA_DEST_ADDR_PL | EDMA_DEST_ADDR_BMT;
	params.flags |= EDMA_SRC_ADDR_PL | EDMA_SRC_ADDR_BMT;

	/* Retrieve queue_0 from block 0 */
	p_queue = sys_get_handle(FSL_MOD_EDMA_BLOCK_QUEUE,3/* number of arguments to follow*/,0,block_id,queue_id);
	if(NULL == p_queue)
	{
	    pr_info("Cannot retrieve FSL_MOD_EDMA_BLOCK_QUEUE by sys_get_handle,"
		    "test_peb2dmem_transac failed\n");
	    fsl_xfree(p_virt_dst);
	    fsl_put_mem(source_paddr);
	    return -EIO;
	}
	// Going over a loop of 120 eDMA transactions and execute it with step of 0x100.
	for(int i = 0 ; i < NUM_TRANSAC; i++)
	{
		params.src = source_paddr;
		params.dst =  dst_vaddr;
		iowrite32(0,UINT_TO_PTR(dst_vaddr)); // zero memory
		iowrite32(VALUE_TO_COPY,UINT_TO_PTR(source_vaddr));
		rc = edma_queue_transfer(p_queue,&params,&status);
		// read back the value and compare expected results
		value = ioread32(UINT_TO_PTR(dst_vaddr));
		if(status != EDMA_NORMAL || value != VALUE_TO_COPY){
			pr_err("test_peb2dmem_transac failed\n");
			fsl_xfree(p_virt_dst);
			fsl_put_mem(source_paddr);
			return EIO;
		}
		dst_vaddr += NUM_BYTES_TO_COPY;
		source_vaddr += NUM_BYTES_TO_COPY;
		source_paddr += NUM_BYTES_TO_COPY;
	}
	fsl_xfree(p_virt_dst);
	fsl_put_mem(source_paddr);
	pr_info("test_peb2dmem_transac  succeeded,src.addr=0x%x%08x, dst.addr=0x%x\n",
	        (uint32_t)(source_paddr>>32),(uint32_t)source_paddr,dst_vaddr);
	return 0;
}

int test_system_ddr2dmem_transac()
{
	struct edma_queue *p_queue;
	struct edma_transfer params;
	uint32_t source_vaddr = 0;
	dma_addr_t source_paddr =  0;/* address in SoC window  for core's access */
	void * p_virt_dst = fsl_xmalloc(NUM_BYTES_TO_COPY*NUM_TRANSAC,MEM_PART_DMEM1,1);
	uint32_t dst_vaddr = (uint32_t)p_virt_dst;
	uint32_t value = 0,block_id = 0,queue_id = 0;
	int rc = 0;
	enum transac_status status;
	struct dpmng_amq amq = {0};
	dpmng_get_amq(&amq);
	if(NULL == p_virt_dst)
	{
	    pr_err("fsl_xmalloc with MEM_PART_DMEM1 returned NULL\n");
	    return -EIO;
	}
	if(fsl_get_mem(NUM_BYTES_TO_COPY*NUM_TRANSAC,
	               MEM_PART_SYSTEM_DDR1,1,
		       &source_paddr) != 0)
	{
	    fsl_xfree(p_virt_dst);
	    pr_err("fsl_get_mem() returned no system-ddr memory available\n");
	    return -EIO;
	}
	/* configure SoC Window  to enable core to write into system-ddr*/
	source_vaddr = (uint32_t)dpmng_mc_set_soc_window(source_paddr,&amq);
	if(!sys_is_master_core())
	    block_id = 1;
	memset(&params,0, sizeof(params));
	params.byte_count = NUM_BYTES_TO_COPY;
	params.src_icid = 0x0; // an arbitrary value only for demonstration
	params.dst_icid = 0x0; // an arbitrary value only for demonstration
	/* Destination address is an internal address */
	params.flags |= EDMA_DEST_ADDR_IA | EDMA_DEST_ADDR_PL | EDMA_DEST_ADDR_BMT;
	params.flags |= EDMA_SRC_ADDR_IA | EDMA_SRC_ADDR_PL | EDMA_SRC_ADDR_BMT;

	/* Retrieve queue_0 from block 0 */
	p_queue = sys_get_handle(FSL_MOD_EDMA_BLOCK_QUEUE,3/* number of arguments to follow*/,0,block_id,queue_id);
	if(NULL == p_queue)
	{
	    pr_info("Cannot retrieve FSL_MOD_EDMA_BLOCK_QUEUE by sys_get_handle,"
		    "test_system_ddr2dmem_transac failed\n");
	    fsl_xfree(p_virt_dst);
	    fsl_put_mem(source_paddr);
	    return -EIO;
	}
	// Going over a loop of 120 eDMA transactions and execute it with step of 0x100.
	for(int i = 0 ; i < NUM_TRANSAC; i++)
	{
		params.src = source_vaddr;
		params.dst =  dst_vaddr;
		iowrite32(0,UINT_TO_PTR(dst_vaddr)); // zero memory
		iowrite32(VALUE_TO_COPY,UINT_TO_PTR(source_vaddr));
		rc = edma_queue_transfer(p_queue,&params,&status);
		// read back the value and compare expected results
		value = ioread32(UINT_TO_PTR(dst_vaddr));
		if(status != EDMA_NORMAL || value != VALUE_TO_COPY){
			pr_err("test_system_ddr2dmem_transac failed\n");
			fsl_xfree(p_virt_dst);
			fsl_put_mem(source_paddr);
			return EIO;
		}
		dst_vaddr += NUM_BYTES_TO_COPY;
		source_vaddr += NUM_BYTES_TO_COPY;
	}
	fsl_xfree(p_virt_dst);
	fsl_put_mem(source_paddr);
	pr_info("test_system_ddr2dmem_transac succeeded,src.addr=0x%x%08x, dst.addr=0x%x\n",
	        (uint32_t)(source_paddr>>32),(uint32_t)source_paddr,dst_vaddr);
	return 0;
}

static int test_dmem2dmem_transac()
{
	struct edma_queue *p_queue;
	struct edma_transfer params;
	void* p_v_source = fsl_xmalloc(NUM_BYTES_TO_COPY*NUM_TRANSAC,MEM_PART_DMEM1,1);
	void* p_virt_dst = NULL;
	int virt_dst_mem_part = MEM_PART_DMEM1;
	if(fsl_mem_exists(MEM_PART_DMEM2))
	    virt_dst_mem_part =  MEM_PART_DMEM2;
	p_virt_dst = fsl_xmalloc(NUM_BYTES_TO_COPY*NUM_TRANSAC,virt_dst_mem_part,1);
	uint32_t source_vaddr = (uint32_t)p_v_source;
	uint32_t dst_vaddr = (uint32_t)p_virt_dst;
	uint32_t value = 0,block_id = 0,queue_id = 0;
	uint32_t temp = 0;
	int rc = 0;

	enum transac_status status;
	if(!sys_is_master_core())
	    block_id = 1;
	memset(&params,0, sizeof(params));
	params.byte_count = NUM_BYTES_TO_COPY;
	params.src_icid = 0x0; // an arbitrary value only for demonstration
	params.dst_icid = 0x0; // an arbitrary value only for demonstration
	/* Destination address is an internal address */
	params.flags |= EDMA_DEST_ADDR_IA | EDMA_DEST_ADDR_PL | EDMA_DEST_ADDR_BMT;
	params.flags |= EDMA_SRC_ADDR_IA | EDMA_SRC_ADDR_PL | EDMA_SRC_ADDR_BMT;
	if(NULL == p_v_source || NULL == p_virt_dst)
	{
	    if(NULL != p_v_source)
                fsl_xfree(p_v_source);
	    if(NULL != p_virt_dst)
		 fsl_xfree(p_virt_dst);
            if(NULL == p_virt_dst)
                pr_err("fsl_xmalloc from %d returned NULL\n",virt_dst_mem_part);
            if(NULL == p_v_source)
        	pr_err("fsl_xmalloc from MEM_PART_DMEM1 returned NULL\n");
	    return -EIO;
	}
	/* Retrieve queue_0 from block 0 */
	p_queue = sys_get_handle(FSL_MOD_EDMA_BLOCK_QUEUE,3/* number of arguments to follow*/,0,block_id,queue_id);
	if(NULL == p_queue)
	{
	    pr_info("Cannot retrieve FSL_MOD_EDMA_BLOCK_QUEUE by sys_get_handle,"
		    "test_dmem2dmem_transac failed\n");
	    fsl_xfree(p_v_source);
	    fsl_xfree(p_virt_dst);
	    return -EIO;
	}

	// Going over a loop of 120 eDMA transactions and execute it with step of 0x100.
	for(int i = 0 ; i < NUM_TRANSAC; i++)
	{
		params.src = source_vaddr;
		params.dst =  dst_vaddr;
		iowrite32(0,UINT_TO_PTR(dst_vaddr)); // zero memory
		temp = ioread32(UINT_TO_PTR(dst_vaddr));
		if(temp != 0)
		{
		    fsl_xfree(p_v_source);
                    fsl_xfree(p_virt_dst);
		    return -EIO;
		}
		iowrite32(VALUE_TO_COPY,UINT_TO_PTR(source_vaddr));
		temp = ioread32(UINT_TO_PTR(source_vaddr));
		if(temp != VALUE_TO_COPY)
			return -EIO;
		rc = edma_queue_transfer(p_queue,&params,&status);
		//pr_info("edma:After edma_queue_transfer finished\n");
		// read back the value and compare expected results
		value = ioread32(UINT_TO_PTR(dst_vaddr));
		if(status != EDMA_NORMAL || value != VALUE_TO_COPY){
			//restore_access_window();
			fsl_xfree(p_v_source);
			fsl_xfree(p_virt_dst);
			pr_err("edma: read value 0x%x from address 0x%x\n",value,dst_vaddr);
			return -EIO;
		}
		dst_vaddr += NUM_BYTES_TO_COPY;
		source_vaddr += NUM_BYTES_TO_COPY;
	}
	fsl_xfree(p_v_source);
	fsl_xfree(p_virt_dst);
	pr_info("test_dmem2dmem_transac succeeded,src.addr = 0x%x, dst.addr = 0x%x\n",
	        source_vaddr,dst_vaddr);
	return 0;
}

static int test_system_ddr2local_transac()
{
	struct edma_queue *p_queue;
	struct edma_transfer params;
	uint8_t  dst_buffer[NUM_BYTES_TO_COPY];
	uint32_t temp = 0;
	//local buffer address
	uint32_t dst_vaddr = PTR_TO_UINT(&dst_buffer[0]);
	uint32_t value = 0,block_id = 0,queue_id = 0;
	int rc = 0;
	enum transac_status status;
	uint32_t source_vaddr = 0;/* address in SoC window  for core's access */
	dma_addr_t source_paddr =  0;
	struct dpmng_amq amq = {0};
	dpmng_get_amq(&amq);
	if(fsl_get_mem(NUM_BYTES_TO_COPY*NUM_TRANSAC,
		               MEM_PART_SYSTEM_DDR1,1,
			       &source_paddr) != 0)
	{
	    pr_err("fsl_get_mem() returned no system-ddr memory available\n");
	    return -EIO;
	}
	/* configure SoC Window  to enable core to write into system-ddr*/
	source_vaddr = (uint32_t)dpmng_mc_set_soc_window(source_paddr,&amq);
	if(!sys_is_master_core())
	    block_id = 1;
	memset(&params,0, sizeof(params));
	params.byte_count = NUM_BYTES_TO_COPY;
	params.src_icid = 0x0; // an arbitrary value only for demonstration
	params.dst_icid = 0x0; // an arbitrary value only for demonstration
	/* Destination address is an internal address */
	params.flags |= EDMA_DEST_ADDR_IA | EDMA_DEST_ADDR_PL | EDMA_DEST_ADDR_BMT;
	/* Source address is an internal address */
	params.flags |= EDMA_SRC_ADDR_IA | EDMA_SRC_ADDR_PL | EDMA_SRC_ADDR_BMT;
	/* Retrieve queue_0 from block 0 */
	p_queue = sys_get_handle(FSL_MOD_EDMA_BLOCK_QUEUE,3/* number of arguments to follow*/,0,block_id,queue_id);
	if(NULL == p_queue)
	{
	    pr_info("Cannot retrieve FSL_MOD_EDMA_BLOCK_QUEUE by sys_get_handle,"
		    "test_system_ddr2local_transac failed\n");
	    fsl_put_mem(source_paddr);
	    return -EIO;
	}
	// Going over a loop of 129 eDMA transactions and execute it with step of 0x100.
	for(int i = 0 ; i < NUM_TRANSAC; i++)
	{
		params.src = source_vaddr;
		params.dst =  dst_vaddr;
		iowrite32(0,UINT_TO_PTR(dst_vaddr)); // zero memory
		temp = ioread32(UINT_TO_PTR(dst_vaddr));
		if(temp != 0){
			fsl_put_mem(source_paddr);
			pr_err("test_system_ddr2local_transac failed,i = %d,read value 0x%x instead of 0\n",i,temp);
			return EIO;
		}
		iowrite32(VALUE_TO_COPY,UINT_TO_PTR(source_vaddr));
		temp = ioread32(UINT_TO_PTR(source_vaddr));
		if(temp != VALUE_TO_COPY){
			fsl_put_mem(source_paddr);
			pr_err("test_system_ddr2local_transac failed,i = %d,read value 0x%x instead of 0x%x\n",i,temp,VALUE_TO_COPY);
			return EIO;
		}
		rc = edma_queue_transfer(p_queue,&params,&status);
		// read back the value and compare expected results
		// invalidate dcache and read back the value and compare expected results
		l1dcache_block_invalidate(dst_vaddr);
		value = ioread32(UINT_TO_PTR(dst_vaddr));
		if(status != EDMA_NORMAL || value != VALUE_TO_COPY){
			fsl_put_mem(source_paddr);
			pr_err("test_system_ddr2local_transac failed,i = %d, read value 0x%x from address 0x%x\n",i, value,dst_vaddr);
			return EIO;
		}
		// always write into the same buffer.
		// dst_vaddr += NUM_BYTES_TO_COPY;
		source_vaddr += NUM_BYTES_TO_COPY;
	}
	fsl_put_mem(source_paddr);
	pr_info("test_system_ddr2local_transac succeeded,src.addr=0x%x%08x, dst.addr=0x%x\n",
	        (uint32_t)(source_paddr>>32),(uint32_t)source_paddr,dst_vaddr);
	return 0;
}

void config_peb_window()
{
	if(sys_is_master_core())
	{
        iowrite32(0x00000000, UINT_TO_PTR(MC_C1SAWBALR));
        iowrite32(0x0000004c,UINT_TO_PTR(MC_C1SAWBAHR)); // PEB
	}
	else
	{
		iowrite32(0x00000000, UINT_TO_PTR(MC_C2SAWBALR));
        iowrite32(0x0000004c,UINT_TO_PTR(MC_C2SAWBAHR)); // PEB
	}
}
void config_dp_ddr_window()
{
    if(sys_is_master_core())
    {
        iowrite32(0x00000000, UINT_TO_PTR(MC_C1SAWBALR));
        iowrite32(0x00000060,UINT_TO_PTR(MC_C1SAWBAHR)); // DP-DDR
    }
    else
    {
        iowrite32(0x00000000, UINT_TO_PTR(MC_C2SAWBALR));
        iowrite32(0x00000060,UINT_TO_PTR(MC_C2SAWBAHR)); // DP-DDR
    }
}
void config_system_ddr_window()
{
	if(sys_is_master_core())
	{
       iowrite32(0x80000000, UINT_TO_PTR(MC_C1SAWBALR));
       iowrite32(0x00000000,UINT_TO_PTR(MC_C1SAWBAHR)); //SYSTEM-DDR
	}
	else
	{
	    iowrite32(0x80000000, UINT_TO_PTR(MC_C2SAWBALR));
		iowrite32(0x00000000,UINT_TO_PTR(MC_C2SAWBAHR)); //SYSTEM-DDR
	}
}
