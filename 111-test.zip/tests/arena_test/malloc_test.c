/*
 * Copyright 2017 NXP
 */

#include "fsl_malloc.h"
#include "fsl_errors.h"
#include "fsl_io.h"
#include "fsl_platform.h"
#include "fsl_malloc.h"
#include "fsl_mem_mng.h"
#include "fsl_stdio.h"
#include "fsl_dbg.h"


int malloc_test();
int get_mem_test();
int slob_test();

static uint32_t s_system_ddr_non_cacheable_exists = 0;
static uint32_t s_system_ddr_cacheable_exists = 0;
static uint32_t s_system_ddr_exists = 0;
static uint32_t s_peb_exists = 0;
static uint32_t s_dpddr_exists = 0;
static uint32_t s_dmem_exists = 0;
static uint32_t s_dmem1_exists = 0;
static uint32_t s_dmem2_exists = 0;
static t_mem_mng_phys_addr_alloc_info sys_ddr_info = {0};
static t_mem_mng_phys_addr_alloc_info peb_info = {0};
static t_mem_mng_phys_addr_alloc_info dp_ddr_info = {0};


static t_mem_mng_partition_info dmem1_info = {0};
static t_mem_mng_partition_info dmem2_info = {0};
static t_mem_mng_partition_info sys_ddr_cacheable_info = {0};
static t_mem_mng_partition_info sys_ddr_non_cacheable_info = {0};








static int check_non_valid_xmalloc_partitions();
static int allocate_check_mem(const int memory_partition,
                              const t_mem_mng_partition_info* part_info,
		              const uint32_t num_iterations, const uint32_t size,
		              void** allocated_pointers );
/* Number of malloc allocations for each partition */
#define NUM_TEST_ITER 10


int malloc_test()
{
	uint32_t num_iter = NUM_TEST_ITER, size = 0x100;
	void* allocated_pointers[NUM_TEST_ITER];
	int err = 0, local_error = 0;
	uint32_t core_id = core_get_id();
	void** dmem_allocated_pointers = NULL;
	t_mem_mng_partition_info dmem_info = {0};
	s_system_ddr_non_cacheable_exists = (uint32_t)fsl_mem_exists(MEM_PART_SYSTEM_DDR1_NON_CACHEABLE) ;
	s_system_ddr_cacheable_exists = (uint32_t)fsl_mem_exists(MEM_PART_SYSTEM_DDR1_CACHEABLE);
	s_system_ddr_exists = (uint32_t)fsl_mem_exists(MEM_PART_SYSTEM_DDR1) == 1;
	s_peb_exists = (uint32_t)fsl_mem_exists(MEM_PART_PEB);
	s_dpddr_exists = (uint32_t)fsl_mem_exists(MEM_PART_DP_DDR);
	s_dmem_exists = (uint32_t)fsl_mem_exists(MEM_PART_DMEM);
	s_dmem1_exists = (uint32_t)fsl_mem_exists(MEM_PART_DMEM1);
	s_dmem2_exists = (uint32_t)fsl_mem_exists(MEM_PART_DMEM2);
	if(s_dmem_exists){
	    if(0 != sys_get_mem_partition_info(MEM_PART_DMEM1 + (int)core_get_id(),&dmem_info))
	    {
	        pr_err(" Cannot retrieve partition info for DMEM \n");
		err = 1;
	    }
	}
        if(s_dmem1_exists){
	    if(0 != sys_get_mem_partition_info(MEM_PART_DMEM1,&dmem1_info))
	    {
	        pr_err(" Cannot retrieve partition info for DMEM1 \n");
	        err = 1;
	    }
        }
        if(s_dmem2_exists){
	    if(0 != sys_get_mem_partition_info(MEM_PART_DMEM2,&dmem2_info))
	    {
		pr_err(" Cannot retrieve partition info for DMEM2 \n");
		err = 1;
	    }
	}
        if(s_system_ddr_cacheable_exists){
	    if(0 != sys_get_mem_partition_info(MEM_PART_SYSTEM_DDR1_CACHEABLE,
	                                       &sys_ddr_cacheable_info))
	    {
	        pr_err(" Cannot retrieve partition info for SYSTEM_DDR1_CACHEABLE \n");
	        err = 1;
	    }
        }
        if(s_system_ddr_non_cacheable_exists){
            if(0 != sys_get_mem_partition_info(MEM_PART_SYSTEM_DDR1_NON_CACHEABLE,
                                               &sys_ddr_non_cacheable_info))
       	    {
                pr_err(" Cannot retrieve partition info for SYSTEM_DDR1_CACHEABLE \n");
       	        err = 1;
       	    }
         }
        if(0 != check_non_valid_xmalloc_partitions())
        {
            pr_err("fsl_xmalloc(): check_non_valid_xmalloc_partitions failed for "
                      "core  %d\n",core_id);
        }
        else
            fsl_print("get_mem(): check_non_valid_xmalloc_partitions succeeded for "
                      "core  %d\n",core_id);
	// allocate from the heap
	local_error = allocate_check_mem(-1,0,num_iter,size,allocated_pointers);
	if(!local_error)
		fsl_print("malloc_test from the heap succeeded for core  %d\n",core_id);
	else{
		pr_err("malloc_test from the heap failed  for core  %d\n",core_id);
		err = 1;
	}
	local_error = allocate_check_mem(0 /*default heap*/,0,num_iter,size,
				         allocated_pointers);
	if(!local_error)
		fsl_print("malloc_test from   default heap succeeded for core  %d\n",
		          core_id);
	else
	{
		pr_err("malloc_test from   default heap failed  for core  %d\n",
		          core_id);
		err = 1;
	}


	local_error = allocate_check_mem(MEM_PART_SYSTEM_DDR1_NON_CACHEABLE,
	                                 &sys_ddr_non_cacheable_info,
	                                 num_iter,size,
					 allocated_pointers);
	if((!local_error && s_system_ddr_non_cacheable_exists)  ||
	   (local_error && !s_system_ddr_non_cacheable_exists))
	{
	    fsl_print("malloc_test from  non-cacheable MC-DDR succeeded for core  %d\n",
	              core_id);
	}
	if((!local_error && !s_system_ddr_non_cacheable_exists) ||
	   (local_error && s_system_ddr_non_cacheable_exists))
	{
	    pr_err("malloc_test from  non-cacheable MC-DDR failed for core  %d\n",
	              core_id);
	    err = 1;
	}

	local_error = allocate_check_mem(MEM_PART_SYSTEM_DDR1_CACHEABLE,
	                                 &sys_ddr_cacheable_info,
	                                 num_iter,size,allocated_pointers);
	if((!local_error && s_system_ddr_cacheable_exists)  ||
	   (local_error && !s_system_ddr_cacheable_exists))
	{
	    fsl_print("malloc_test from  cacheable MC-DDR succeeded for core  %d\n",
	              core_id);
	}
	if((!local_error && !s_system_ddr_cacheable_exists) ||
	    (local_error && s_system_ddr_cacheable_exists))
	{
	    pr_err("malloc_test from  cacheable MC-DDR failed for core  %d\n",
	              core_id);
	    err = 1;
	}
	local_error = allocate_check_mem(MEM_PART_DMEM,&dmem_info,
	                                 num_iter,size,allocated_pointers);
	if((!local_error && s_dmem_exists)  ||
	   (local_error && !s_dmem_exists))
	{
	    fsl_print("malloc_test from DMEM succeeded for core  %d\n", core_id);
	}
	if((!local_error && !s_dmem_exists) ||
	   (local_error && s_dmem_exists))
	{
	    pr_err("malloc_test from  DMEM  failed for core  %d\n",core_id);
	    err = 1;
	}
	local_error = allocate_check_mem(MEM_PART_DMEM1,&dmem1_info,
			                 num_iter,size,allocated_pointers);
	if((!local_error && s_dmem1_exists)  ||
	   (local_error && !s_dmem1_exists))
	{
	    fsl_print("malloc_test from DMEM1 succeeded for core  %d\n", core_id);
	}
	if((!local_error && !s_dmem1_exists) ||
	   (local_error && s_dmem1_exists))
	{
	    pr_err("malloc_test from  DMEM1  failed for core  %d\n",core_id);
	    err = 1;
	}
	local_error = allocate_check_mem(MEM_PART_DMEM2,&dmem2_info,
		                                 num_iter,size,allocated_pointers);
	if((!local_error && s_dmem2_exists)  ||
	   (local_error && !s_dmem2_exists))
	{
	    fsl_print("malloc_test from DMEM2 succeeded for core  %d\n", core_id);
	}
	if((!local_error && !s_dmem2_exists) ||
	   (local_error && s_dmem2_exists))
	{
	    pr_err("malloc_test from  DMEM2  failed for core  %d\n",core_id);
	    err = 1;
	}
	return err;
}

static int check_non_valid_xmalloc_partitions()
{
    int rc = 0, local_error = 0;
    uint32_t size = 0x10, alignment = 4;
    // The following test should fail.
    if(fsl_xmalloc(size,MEM_PART_SYSTEM_DDR1,alignment) != NULL
                      && s_system_ddr_exists)
	    local_error = 1;
    if(fsl_xmalloc(size,MEM_PART_PEB,alignment) != NULL
                      && s_peb_exists)
	    local_error = 1;
    if(fsl_xmalloc(size,MEM_PART_DP_DDR,alignment) != NULL
                      && s_dpddr_exists)
	    local_error = 1;
    if(local_error)
	    return -EINVAL;
    return 0;
}
static  int check_returned_malloc_address(const uint32_t vaddr,
                                           const uint32_t size,
                                           const uint32_t alignment,
                                           const t_mem_mng_partition_info* part_info)
{
    int error = 0;
    // check if returned address is in boundaries;
    error = (vaddr < part_info->base_address) ||
	    (vaddr > part_info->base_address + part_info->size - size);
    // check alignment;
    error |=  (int)(vaddr & (alignment-1));
    return error;
}

static int allocate_check_mem(const int  memory_partition,
                              const struct t_mem_mng_partition_info* part_info,
		              const uint32_t num_iter, const uint32_t size,
		              void **allocated_pointers)
{

	int i = 0;
	uint32_t value = 0xdeadbeef,expected_value = 0xdeadbeef;
	uint32_t alignment = 4;
	if(memory_partition == -1)
	{
		// allocate from the heap
		for(i = 0 ; i < num_iter; i++)
		{
			allocated_pointers[i] = fsl_malloc(size);
			if(NULL == allocated_pointers[i])
			{
				fsl_print("malloc from the heap failed, NULL returned \n");
				return -ENOMEM;
			}
			iowrite32(value,allocated_pointers[i]);
			value = ioread32(allocated_pointers[i]);
			if(value != expected_value) {
				fsl_print("malloc from the heap has failed, address %x\n",
						PTR_TO_UINT(allocated_pointers[i]));
				return -ENOMEM;
			}
		}
		for(i = 0 ; i < num_iter; i++)
		{
			fsl_free(allocated_pointers[i]);
			iowrite32(0,allocated_pointers[i]);
			allocated_pointers[i] = NULL;
		}

	}
	else // xmalloc case
	{
	    for(i = 0 ; i < num_iter; i++)
	    {
	        allocated_pointers[i] = fsl_xmalloc(size,memory_partition,alignment);
	        if(NULL != part_info &&
	           0 != check_returned_malloc_address((uint32_t)allocated_pointers[i],
					  size,alignment,part_info))
	        {
		    fsl_print("malloc from part %d failed, returned address"
			      "is not in mem. parition range or not-aligned 0x%x \n",
			      memory_partition,(uint32_t)allocated_pointers[i]);
		    return -ENOMEM;
	        }
	       if(NULL == allocated_pointers[i])
	       {
	           fsl_print("malloc from part %d failed, NULL returned \n",memory_partition);
		   return -ENOMEM;
	       }
	       iowrite32(value,allocated_pointers[i]);
	       value = ioread32(allocated_pointers[i]);
	       if(value != expected_value) {
	           fsl_print("malloc from mem part %d has failed, address %x\n",
			     memory_partition,PTR_TO_UINT(allocated_pointers[i]));
		   return -ENOMEM;
	       }
	       alignment<<=1;
            }
            for(i = 0 ; i < num_iter; i++)
	    {
		fsl_xfree(allocated_pointers[i]);
		iowrite32(0,allocated_pointers[i]);
		if(memory_partition != MEM_PART_DMEM)
			allocated_pointers[i] = NULL;
	    }
	}
	return 0;
}

static int check_non_valid_get_mem_partitions()
{
    int rc = 0, local_error = 0;
    uint64_t size = 0x10, alignment = 4, paddr;
    // The following test should fail.
    if(fsl_get_mem(size,MEM_PART_SYSTEM_DDR1_CACHEABLE,alignment,&paddr) != -EINVAL
    		&& s_system_ddr_cacheable_exists)
	    local_error = 1;
    if(fsl_get_mem(size,MEM_PART_SYSTEM_DDR1_NON_CACHEABLE,alignment,&paddr) != -EINVAL
    	 && s_system_ddr_non_cacheable_exists)
	    local_error = 1;
    if(fsl_get_mem(size,MEM_PART_DMEM,alignment,&paddr) != -EINVAL
    	&& s_dmem_exists)
            local_error = 1;
    if(fsl_get_mem(size,MEM_PART_DMEM1,alignment,&paddr) != -EINVAL
       && s_dmem1_exists)
            local_error = 1;
    if(fsl_get_mem(size,MEM_PART_DMEM2,alignment,&paddr) != -EINVAL
       && s_dmem2_exists)
            local_error = 1;
    if(local_error)
	    return -EINVAL;
    return 0;
}

static  int check_returned_get_mem_address(uint64_t paddr,
                                           uint64_t size,
                                           uint64_t alignment,
                                   t_mem_mng_phys_addr_alloc_info* part_info)
{
    int error = 0;
    // check if returned address is in boundaries;
    error = (paddr < part_info->base_paddress) ||
	    (paddr > part_info->base_paddress + part_info->size - size);
    // check alignment;
    error |=  (int)(paddr & (uint64_t)(alignment-1));
    return error;
}

static int check_get_mem_size_alignment()
{
    int rc = 0, local_error = 0;
    uint64_t alignment = 0,prev_alignment = 0;
    uint64_t size = 0, prev_size = 0, paddr = 0,prev_paddr = 0;
    if(s_system_ddr_exists && sys_get_phys_addr_alloc_partition_info(MEM_PART_SYSTEM_DDR1,
                                                    &sys_ddr_info) != 0)
        return rc;
    if(s_peb_exists && sys_get_phys_addr_alloc_partition_info(MEM_PART_PEB,
                                                    &peb_info) != 0)
        return rc;
    if(s_dpddr_exists && sys_get_phys_addr_alloc_partition_info(MEM_PART_DP_DDR,
                                                    &dp_ddr_info) != 0)
        return rc;
    /* Test MEM_PART_SYSTEM_DDR1 */
    if(s_system_ddr_exists)
    {
		size = sys_ddr_info.size >> 1; // half of total partition size
		alignment = (size > MEGABYTE)? MEGABYTE : size;
		while(fsl_get_mem(size,MEM_PART_SYSTEM_DDR1,alignment,&paddr) == 0)
		{
			//  get_mem() from MEM_PART_SYSTEM_DDR1 returns successfully
			local_error |= check_returned_get_mem_address(paddr,size, alignment,
								      &sys_ddr_info);
			prev_paddr = paddr;
			prev_size = size;
			prev_alignment = alignment;
			size = (size > 0x10) ? (size>>1):0x10;
			alignment = (size > MEGABYTE)? MEGABYTE : size;
		}
		if(prev_paddr != 0)
			fsl_put_mem(prev_paddr);
		// after releasing memory, we  are supposed to get the same address
		if(prev_size != 0 && fsl_get_mem(prev_size,MEM_PART_SYSTEM_DDR1,
				               prev_alignment,&paddr) != 0)
			local_error = 1;
    }
    else{ //no system_ddr exists
    	alignment = size = 0;
    	if(fsl_get_mem(size,MEM_PART_SYSTEM_DDR1,alignment,&paddr) == 0)
    		local_error = 1; //allocation from non-existing sys_ddr should have failed
    }
    /* Test MEM_PART_PEB*/
    if(s_peb_exists)
    {
		size = peb_info.size >> 4;
		alignment = (size > MEGABYTE)? MEGABYTE : size;
		while(fsl_get_mem(size,MEM_PART_PEB,alignment,&paddr) == 0)
		{
			 //  get_mem() from MEM_PART_PEB returns successfully
			 local_error |= check_returned_get_mem_address(paddr,size, alignment,
			                                               &peb_info);
			 prev_paddr = paddr;
			 prev_size = size;
			 prev_alignment = alignment;
			 size = (size > 0x800) ? (size>>1):0x800;
			 alignment = (size > MEGABYTE)? MEGABYTE : size;
		}
		if(prev_paddr != 0 )
			fsl_put_mem(prev_paddr);
		if(prev_size != 0 && fsl_get_mem(prev_size,MEM_PART_PEB,
						    prev_alignment,&paddr) != 0)
					local_error = 1;
    }
    else{// no  peb exists
    	alignment = size = 4;
    	if(fsl_get_mem(size,MEM_PART_PEB,alignment,&paddr) == 0)
    		local_error = 1; //allocation from non-existing peb should have failed
    }
    /* MEM_PART_DP_DDR */
    if(s_dpddr_exists)
    {
		size = dp_ddr_info.size >> 1;
		alignment = (size > MEGABYTE)? MEGABYTE : size;
		if(fsl_get_mem(size,MEM_PART_DP_DDR,alignment,&prev_paddr) == 0 )
		{
			local_error |= check_returned_get_mem_address(prev_paddr,size, alignment,
								   &dp_ddr_info);
			fsl_put_mem(prev_paddr);
		}
    }
    else{// no dp_ddr exists
    	alignment = size = 4;
		if(fsl_get_mem(size,MEM_PART_DP_DDR,alignment,&paddr) == 0)
			local_error = 1; //allocation from non-existing dp_ddr should have failed
    }

    if(local_error)
        return local_error;
    return 0;

}

int get_mem_test()
{
    int rc = 0, local_error = 0;
    uint32_t core_id = core_get_id();
    /* Check for validity of mem_partition
    For non-valid partitions get_mem() should fail.*/
    if((rc = check_non_valid_get_mem_partitions()) != 0)
    {
        pr_err("get_mem(): check_non_valid_get_mem_partitions failed for "
                   "core  %d\n",core_id) ;
    }
    else
        fsl_print("get_mem(): check_non_valid_get_mem_partitions succeeded for "
                  "core %d\n",core_id) ;
    if((rc = check_get_mem_size_alignment()) != 0)
    {
        pr_err("get_mem(): check_get_mem_size_alignment failed for core  %d"
                  " \n",core_id) ;
    	local_error = 1;
    }
    else
        fsl_print("get_mem(): check_get_mem_size_alignment succeeded for core  %d"
                  " \n",core_id) ;
    if(local_error)
       return rc;
    return 0;
}
