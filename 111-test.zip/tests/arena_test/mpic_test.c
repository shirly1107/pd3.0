/*
 * Copyright 2017 NXP
 */

#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "fsl_io.h"
#include "fsl_platform.h"
#include "fsl_malloc.h"
#include "fsl_smp.h"
#include "mpic.h"
#include "drivers/fsl_mcpic.h"
#include "drivers/fsl_mc.h"

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_soc.h"


#define MPIC_TEST_VAL (0x1234)

uint32_t mpic_ok_flag = 0;

int mpic_test();
void mc_msg_isr(uint32_t arg);
uint32_t mpic_standalone_init();

uint32_t mpic_standalone_init()
{
	struct pic_desc pic_desc;
	int   err, iter = 0;
	
	memset(&pic_desc, 0, sizeof(pic_desc));
	sys_get_desc(SOC_MODULE_PIC, SOC_DB_NO_MATCH_FIELDS, &pic_desc, &iter);
	err = mcpic_init(pic_desc.vaddr);
	if (err != 0) {
		ASSERT_COND( 0 );
		//TODO do something bad !!
	}
	
	return 0;
}

void mc_msg_isr(uint32_t arg)
{
	uint32_t msg_data;
	mpic_read_msg(MC_MPIC_INTR_MSG_0, &msg_data);
	ASSERT_COND(msg_data == MPIC_TEST_VAL);
	mpic_ok_flag = msg_data;
}

int mpic_test()
{
	mpic_intr_params_t intr_params;
	int err, is_master_core;

	is_master_core = sys_is_master_core();
	
    intr_params.polarity = OS_MPIC_INTR_POLARITY_HIGH;
    intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;
	intr_params.sense = OS_MPIC_INTR_SENSE_EDGE;
    intr_params.priority = 0xa;

	/* Interrupt registration */
	err = mpic_set_config_intr(MC_MPIC_INTR_MSG_0, 0, mc_msg_isr, 0, &intr_params);
	if(err != 0) {
		return err;
	}
	err = mpic_enable_intr(MC_MPIC_INTR_MSG_0);
	if(err != 0) {
		return err;
	}

	/* Write the message */
	mpic_write_msg(MC_MPIC_INTR_MSG_0, MPIC_TEST_VAL, 0);
	
	/* Wait for message to arrive */
	while(mpic_ok_flag != MPIC_TEST_VAL) {}
	
	err = mpic_disable_intr(MC_MPIC_INTR_MSG_0);
	if (err != 0)
		return err;

	err = mpic_free_intr(MC_MPIC_INTR_MSG_0);
	if (err != 0)
		return err;

	return 0;
}
