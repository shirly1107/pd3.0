/*
 * Copyright 2017 NXP
 */

/******************************************************************************
 @File          bringup1_test.c

 @Description   test implementation
 *//***************************************************************************/

/************/
/* INCLUDES */
/************/

#include "bringup1_test.h"
#include "common.h"

#include "fsl_types.h"
#include "fsl_dprc_mc.h"
#include "fsl_dpmac_mc.h"
#include "kernel/device.h"
#include "fsl_errors.h"
#include "common/fsl_string.h"			/* memset */
#include "include/fsl_sys.h"
#include "fsl_malloc.h"
#include "fsl_dpmng_mc.h"			/* dpmng_amq */
#include "fsl_dpni_mc.h"			/* dpni */
#include "fsl_dpio_mc.h"			/* dpio */
#include "fsl_dpbp_mc.h"			/* dpbp */
#include "fsl_dpsw_mc.h"			/* L2 Switch */
#include "drivers/fsl_qbman_portal.h"		/* BMan */
#include "drivers/fsl_qbman_ctrl.h"		/* BMan */
#include "fsl_linkman.h"			/* Link Manager */

/************/
/*  DEFINES */
/************/
/* use case defines */
#define UC_INT2INT			0
#define UC_INT2EXT			1
#define UC_EXT2EXT			2
#define UC_EXT2INT			3

/* TODO: define your use case here from the above values */
/* TODO: fine-tune the test properties by changing properties in set_cfg_info() */
#define USE_CASE_INDEX		UC_INT2INT

#define FRAMES_NUM		1 /* number of frames to send through the dpsw */
/* buffers */
#define TEST_BUFFER_SIZE	512
#define TEST_BUFFER_NUM		MAX(DPNI_MIN_BUFFERS_NUM, (FRAMES_NUM+2))

/************/
/*  GLOBALS */
/************/
static struct dpsw_uc_info dpsw_uc_info = { 0 };
static int err_counters;
extern const enum dpmng_ctx_type global_objects_context;
static int usecase_index;
static int is_int2ext2int_test;
static uint16_t egr_port, ing_port;

/********************************/
/* Static functions declaration */
/********************************/
/* initialization functions */
static int init_dpsw(struct dpsw **dpsw_p);
static int init_dpni(struct dpni **dpni_p);
static int init_objects(struct dpsw **dpsw,
	struct dpni **dpni_arr,
	struct dpmac **dpmac_arr,
	struct dpbp **dpbp,
	struct dpio **dpio,
	struct qbman_swp **swp);

static int destroy_objects(struct dpsw *dpsw,
	struct dpni **dpni_arr,
	struct dpio *dpio,
	struct dpbp *dpbp);

/* configuration functions */
static int configure_dpni_mac_addr(struct dpni *dpni, const uint8_t *mac_addr);
static int configure_connect(struct dpsw *dpsw,
	struct dpni **dpni_arr,
	struct dpmac **dpmac);
static int configure_fdb(struct dpsw *dpsw,
	const uint8_t *mac_addr,
	uint16_t port);
static int send_event(enum linkman_event event,
	int is_mac,
	uint16_t dpsw_id /*! switch ID */,
	uint16_t if_id /*! switch interface id */,
	uint16_t dpni_id /*! peer connector id */);
static int set_cfg_info();

/* traffic functions */
static int test_traffic(struct dpsw *dpsw,
	struct dpni **dpni_arr,
	struct dpmac **dpmac_arr,
	struct qbman_swp *swp,
	struct dpbp *dpbp);
static int check_receive_frame_dpni(struct dpsw *dpsw,
	struct dpni *dpni,
	struct qbman_swp *swp,
	struct dpbp *dpbp,
	uint16_t port,
	int frame_iteration);
static int check_receive_frame_dpmac(struct dpsw *dpsw,
	struct dpmac *dpmac,
	uint16_t port,
	int frame_iteration);

/* debug */
static void dump_counters(struct dpsw *dpsw,
	struct dpni **dpni_arr,
	struct dpmac **dpmac_arr);

/*****************/
/* Test Function */
/*****************/
int bringup1_app_init(void)
{
	/******************************/
	/*          Variables         */
	/******************************/
	/* objects handles */
	struct dpsw *dpsw = NULL;
	struct dpni *dpni_arr[10] = { 0 };
	struct dpmac *dpmac_arr[10] = { 0 };
	struct dpbp *dpbp = NULL;
	struct dpio *dpio = NULL;
	struct qbman_swp *swp = NULL;

	/* tx frame */
	const uint8_t *tx_frame = frame_00_00_01_00_00_01_8023_64;
	uint32_t tx_length = sizeof(frame_00_00_01_00_00_01_8023_64);

	/* misc */
	int i;
	int err, err_dpsw_traffic, err_destroy;

	/***************************/
	/*    Initializations      */
	/***************************/
	err_counters = 0;

	/* set configuration */
	err = set_cfg_info();
	LOOP_ON_ERR(err, "set_cfg_info");

	/* init objects */
	err = init_objects(&dpsw, dpni_arr, dpmac_arr, &dpbp, &dpio, &swp);
	LOOP_ON_ERR(err, "objects initialization");

	/***************************/
	/*      Configuration      */
	/***************************/
	for (i = 0; i < dpsw_uc_info.num_ifs; i++) {
		if (dpsw_uc_info.ports_peer_mac_id[i] != 0) /* dpmac */
			continue;

		err = configure_dpni_mac_addr(dpni_arr[i],
						dpsw_uc_info.tx_frame);
		LOOP_ON_ERR(err, "configure_dpni_mac_addr");
	}

	err = configure_connect(dpsw, dpni_arr, dpmac_arr);
	LOOP_ON_ERR(err, "configure_connect");

	/**********************************************************************/
	/*                         Check dpsw Forwarding                      */
	/**********************************************************************/
#ifdef UC_ENABLED_DPSW_TRAFFIC
	err = test_traffic(dpsw, dpni_arr, dpmac_arr, swp, dpbp);
	err_dpsw_traffic = err;
	fsl_print("----------------------------------\n");
	fsl_print("dpsw traffic use case: %s!\n",
			((err != 0) ? "FAIL" : "PASS"));
	fsl_print("----------------------------------\n");
#endif

	/***************************/
	/*         Destroy         */
	/***************************/
	err = destroy_objects(dpsw, dpni_arr, dpio, dpbp);
	err_destroy = err;
	fsl_print("destroy_objects: %s!\n", ((err != 0) ? "FAIL" : "PASS"));

	/****************************/
	/* Print Successes/Failures */
	/****************************/
	/* print use cases results */
	fsl_print("----------------------------------\n");
	fsl_print("Bring Up Test #1 Finished:\n");
#ifdef UC_ENABLED_DPSW_TRAFFIC
	print_test_result("dpsw traffic", err_dpsw_traffic);
	print_test_result("dpsw counters", err_counters);
#endif
	print_test_result("destroys", err_destroy);

	while (1) {
	};

	return 0;
}

/*******************************/
/*        Static functions     */
/*******************************/

/*-------------------------initialization functions---------------------------*/

static int init_objects(struct dpsw **dpsw,
	struct dpni **dpni_arr,
	struct dpmac **dpmac_arr,
	struct dpbp **dpbp,
	struct dpio **dpio,
	struct qbman_swp **swp)
{
	struct dpsw_tci_cfg dpsw_tci_cfg = { 0 };
	uint16_t i;
	int err;

	/* dpio */
	err = init_dpio(dpio);
	CHECK_ERR(err, "init_dpio");

	/* swp */
	err = init_swp(swp, *dpio);
	CHECK_ERR(err, "init_swp");

	/* dpsw */
	err = init_dpsw(dpsw);
	CHECK_ERR(err, "dpsw initialization");

	/* dpbp */
	err = init_dpbp(dpbp);
	CHECK_ERR(err, "init_dpbp");
	err = init_dpbp_buffers(*dpbp, *swp, TEST_BUFFER_NUM,
				TEST_BUFFER_SIZE);
	CHECK_ERR(err, "init_dpbp_buffers");

	/* dpni-s */
	for (i = 0; i < dpsw_uc_info.num_ifs; i++) {
		if (dpsw_uc_info.ports_peer_mac_id[i] == 0) {
			/* Init */
			err = init_dpni(&dpni_arr[i]);
			CHECK_ERR(err, "init_dpni");

			/* attach buffer pool */
			err = ni_set_pool(dpni_arr[i], *dpbp,
						TEST_BUFFER_SIZE);
			CHECK_ERR(err, "ni_set_pool");

			/* enable */
			err = dpni_enable(dpni_arr[i]);
			CHECK_ERR(err, "dpni_enable");
		}
	}

	/* dpmac */
	for (i = 0; i < dpsw_uc_info.num_ifs; i++) {
		if (dpsw_uc_info.ports_peer_mac_id[i] != 0) {
			/* init dpmac */
			err = init_dpmac(
				&dpmac_arr[i],
				dpsw_uc_info.ports_peer_mac_id[i]);
			CHECK_ERR(err, "init_dpmac");

			/* set loopback*/
			err = dpmac_set_loopback(
				dpmac_arr[i], dpsw_uc_info.is_macs_loopback);
			CHECK_ERR(err, "dpmac_set_loopback");

			/* avoid frame ping-pong between dpsw and dpmac due to 
			 * the dpmac loopback; set up tci for the dpsw egress port
			 * so that when frame gets in, it would be tagged with
			 * non-existing VLAN and therefore be dropped */
			if (dpsw_uc_info.is_macs_loopback) {
				dpsw_tci_cfg.vlan_id = 42; /* an arbitrary vlan not
				 existing in the dpsw database */

				err = dpsw_if_disable(*dpsw, i);
				CHECK_ERR(err, "dpsw_if_disable");

				err = dpsw_if_set_tci(*dpsw, i, &dpsw_tci_cfg);
				CHECK_ERR(err, "dpsw_if_set_tci");

				err = dpsw_if_enable(*dpsw, i);
				CHECK_ERR(err, "dpsw_if_enable");
			}
		}
	}

	return 0;
}

static int init_dpsw(struct dpsw **dpsw_p)
{
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpsw_cfg cfg = { 0 };
	void *dev = NULL;
	struct dpsw *dpsw;
	int err;

	/* allocate */
	*dpsw_p = dpsw_allocate();
	err = (*dpsw_p == NULL);
	CHECK_ERR(err, "dpsw allocation");

	dpsw = *dpsw_p;

	cfg.adv.options = 0;
	cfg.adv.max_fdb_entries = 1024;
	cfg.adv.fdb_aging_time = 256;
	cfg.adv.max_fdb_mc_groups = 2;
	cfg.adv.max_vlans = 4;
	cfg.adv.max_fdbs = 4;
	cfg.num_ifs = dpsw_uc_info.num_ifs;

	err = create_resman_device("dpsw", &dev);
	CHECK_ERR(err, "create_resman_device (dpsw)");
	dev_cfg.device = dev;
	dev_cfg.ctx.type = DPMNG_CTX_TYPE_GPP;
	dev_cfg.id = device_get_id(dev);

	/* init */
	err = dpsw_init(dpsw, &cfg, &dev_cfg);
	CHECK_ERR(err, "dpsw_init");

	err = dpsw_set_dev_ctx(dpsw, &dev_cfg.ctx);
	CHECK_ERR(err, "dpsw_set_dev_ctx");

	/* register */
	device_set_priv(dev, dpsw);
	err = sys_add_handle(dpsw, /* Module Context */
				FSL_MOD_DPSW, /* Module type */
				1, /* Number of ID's */
				dev_cfg.id); /* ID */
	CHECK_ERR(err, "sys_add_handle (dpsw)");

	return 0;
}

static int init_dpni(struct dpni **dpni_p)
{
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpni_cfg cfg = { 0 };
	struct dpni *dpni;
	void *dev = NULL;
	int err;

	/* allocation */
	*dpni_p = dpni_allocate();
	err = (*dpni_p == NULL);
	CHECK_ERR(err, "dpni allocation");

	/* init */
	dpni = *dpni_p;
	cfg.mac_addr[5] = 0x01;
	err = create_resman_device("dpni", &dev);
	CHECK_ERR(err, "create_resman_device (dpni)");
	dev_cfg.device = dev;
	dev_cfg.ctx.type = global_objects_context;
	dev_cfg.id = device_get_id(dev);

	err = dpni_init(dpni, &cfg, &dev_cfg);
	CHECK_ERR(err, "dpni_init");

	err = dpni_set_dev_ctx(dpni, &dev_cfg.ctx);
	CHECK_ERR(err, "dpni_set_dev_ctx");

	/* Register NI in RM*/
	device_set_priv(dev, dpni);
	err = sys_add_handle(dpni, FSL_MOD_DPNI, 1, dev_cfg.id);
	CHECK_ERR(err, "sys_add_handle (dpni)");

	return 0;
}

static int destroy_objects(struct dpsw *dpsw,
	struct dpni **dpni_arr,
	struct dpio *dpio,
	struct dpbp *dpbp)
{
	struct dpni *dpni;
	struct dpni_attr dpni_attr;
	struct dpsw_attr dpsw_attr;
	struct dpbp_attr dpbp_attr;
	struct dpio_attr dpio_attr;
	int err, i;

	/* dpni */
	for (i = 0; i < dpsw_uc_info.num_ifs; i++) {
		if (dpsw_uc_info.ports_peer_mac_id[i] != 0) { /* dpmac */
			continue;
		}
		dpni = dpni_arr[i];
		err = dpni_get_attributes(dpni, &dpni_attr);
		CHECK_ERR(err, "dpni_get_attributes");
		dpni_destroy(dpni);
		sys_remove_handle(FSL_MOD_DPNI, 1, dpni_attr.id);
		CHECK_ERR(err, "sys_remove_handle (dpni)");
		dpni_deallocate(dpni);
		CHECK_ERR(err, "dpni_deallocate");
	}

	/* dpbp */
	err = dpbp_get_attributes(dpbp, &dpbp_attr);
	CHECK_ERR(err, "dpbp_get_attributes");
	dpbp_destroy(dpbp);
	sys_remove_handle(FSL_MOD_DPBP, 1, dpbp_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpbp)");
	dpbp_deallocate(dpbp);
	CHECK_ERR(err, "dpbp_deallocate");

	/* dpsw */
	err = dpsw_get_attributes(dpsw, &dpsw_attr);
	CHECK_ERR(err, "dpsw_get_attributes");
	dpsw_destroy(dpsw);
	sys_remove_handle(FSL_MOD_DPSW, 1, dpsw_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpsw)");
	dpsw_deallocate(dpsw);
	CHECK_ERR(err, "dpsw_deallocate");

	/* dpio */
	err = dpio_get_attributes(dpio, &dpio_attr);
	CHECK_ERR(err, "dpio_get_attributes");
	dpio_destroy(dpio);
	sys_remove_handle(FSL_MOD_DPIO, 1, dpio_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpio)");
	dpio_deallocate(dpio);
	CHECK_ERR(err, "dpio_deallocate");

	return 0;
}

/*------------------------- Configuration Functions --------------------------*/

static int configure_dpni_mac_addr(struct dpni *dpni, const uint8_t *mac_addr)
{
	int err;

	err = dpni_set_primary_mac_addr(dpni, mac_addr);
	CHECK_ERR(err, "dpni_set_primary_mac_addr");
	return 0;
}

static int configure_connect(struct dpsw *dpsw,
	struct dpni **dpni_arr,
	struct dpmac **dpmac)
{
	struct dpsw_attr dpsw_attr;
	struct dpni_attr dpni_attr;
	uint16_t dpsw_id;
	int mac_id;
	uint16_t peer_id;
	uint16_t i;
	int err;

	/* get dpsw id */
	err = dpsw_get_attributes(dpsw, &dpsw_attr);
	CHECK_ERR(err, "dpsw_get_attributes");
	dpsw_id = (uint16_t)dpsw_attr.id;

	ing_port = 0;

	for (i = 0; i < dpsw_uc_info.num_ifs; i++) {

		/* get peer id */
		{
			mac_id = dpsw_uc_info.ports_peer_mac_id[i];
			if (mac_id == 0 /* =>dpni*/) {
				err = dpni_get_attributes(dpni_arr[i],
								&dpni_attr);
				CHECK_ERR(err, "dpni_get_attr");
				peer_id = (uint16_t)dpni_attr.id;
			} else if (mac_id != 0) {
				peer_id = mac_id;
			}
		}

		/* connect */
		{
			/*! Connect */
			err = send_event(LINKMAN_EVENT_CONNECT, /*! Event */
						(mac_id != 0), /* is mac or dpni */
						dpsw_id, /*! switch ID */
						i, /*! switch interface id */
						peer_id); /* peer connector id */
			CHECK_ERR(err, "send_event (connect)");

			/*! Link up */
			err = send_event(LINKMAN_EVENT_LINKUP, /*! Event */
						(mac_id != 0), /* is mac or dpni */
						dpsw_id, /*! switch ID */
						i, /*! switch interface id */
						peer_id); /*! peer connector id */
			CHECK_ERR(err, "send_event (link up)");
			continue;
		}

	}

	return 0;
}

static int configure_fdb(struct dpsw *dpsw,
	const uint8_t *mac_addr,
	uint16_t port)
{
	struct dpsw_fdb_unicast_cfg fdb_unicast;
	int err;

	memset(&fdb_unicast, 0, sizeof(struct dpsw_fdb_unicast_cfg));
	fdb_unicast.type = DPSW_FDB_ENTRY_STATIC;
	memcpy(fdb_unicast.mac_addr, mac_addr, 6);
	fdb_unicast.if_egress = port;

	err = dpsw_fdb_add_unicast(dpsw, 0, &fdb_unicast);
	CHECK_ERR(err, "dpsw_fdb_add_unicast");

	return 0;
}

static int send_event(enum linkman_event event,
	int is_mac,
	uint16_t dpsw_id /*! switch ID */,
	uint16_t if_id /*! switch interface id */,
	uint16_t peer_id /*! peer connector id */)
{
	int err;
	struct linkman_endpoint self; /* L2 switch */
	struct linkman_endpoint peer; /* dpni */
	struct linkman *linkman = NULL;
	struct linkman_control control;

	memset(&self, 0x0, sizeof(struct linkman_endpoint));
	memset(&peer, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));

	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	err = (linkman == NULL);
	CHECK_ERR(err, "sys_get_unique_handle");

	/* L2 switch */
	self.id = (uint16_t)dpsw_id; /* Switch ID */
	self.type = FSL_MOD_DPSW; /* Type */
	self.if_id = if_id; /* IF ID */

	/* Peer connector */
	peer.type = is_mac ? FSL_MOD_DPMAC : FSL_MOD_DPNI; /* peer type*/
	peer.id = peer_id; /* peer id */

	/* Start link up state machine */
	control.event = event;
	err = linkman_set_connection(linkman, &control, &self, &peer);
	return err;
}

/*--------------------------- Use Cases Functions ----------------------------*/

static int test_traffic(struct dpsw *dpsw,
	struct dpni **dpni_arr,
	struct dpmac **dpmac_arr,
	struct qbman_swp *swp,
	struct dpbp *dpbp)
{
	uint16_t i;
	int j, err;
	int err_sending;

	/* frame */
	uint8_t rx_frame[sizeof(frame_00_00_01_00_00_01_8023_64)];
	uint32_t rx_length = 0;

	/* add FDB entries */
	{
		for (i = 0; i < dpsw_uc_info.num_ifs; i++) {
			if (dpsw_uc_info.egr_ports[i] != -1) {
				err = configure_fdb(dpsw,
							dpsw_uc_info.tx_frame,
							i);
				CHECK_ERR(err, "configure_fdb");
			}
		}
	}

	/* validate up state for both sending and receiving dpni-s*/
	{
		struct dpni_link_state state;

		/* sending dpni */
		{
			struct dpni *dpni_ing = dpni_arr[dpsw_uc_info.ing_port];
			int is_ing_dpni =
				(dpsw_uc_info.ports_peer_mac_id[dpsw_uc_info.ing_port]
					== 0);

			if (is_ing_dpni) {
				err = dpni_get_link_state(dpni_ing, &state);
				CHECK_ERR(err, "dpni_get_link_state");
				err = !(state.up == 1);
				CHECK_ERR(
					err,
					"validate sending dpni link state is up");
			}
		}

		/* validate link state up */
		{
			int i;
			int is_dpni_port;
			struct dpni *dpni;

			for (i = 0; i < dpsw_uc_info.num_ifs; i++) {
				is_dpni_port =
					(dpsw_uc_info.ports_peer_mac_id[i] == 0);
				if (!is_dpni_port) {
					continue;
				}
				dpni = dpni_arr[i];
				err = dpni_get_link_state(dpni, &state);
				CHECK_ERR(err, "dpni_get_link_state");
				err = !(state.up == 1);
				CHECK_ERR(
					err,
					"validate receiving dpni link state is up");
			}

		}
	}

	for (j = 1; j <= FRAMES_NUM; j++) {
		fsl_print(
			"\x1b[34m=== forwarding: #%d frame (out of %d) ===\x1b[0m\n",
			j, FRAMES_NUM);
		/* send */
		{
			int sending_mac_id =
				dpsw_uc_info.ports_peer_mac_id[dpsw_uc_info.ing_port];
			fsl_print("Sending frame...\n");
			if (sending_mac_id == 0 /* send by dpni */) {
				struct dpni *dpni_send =
					dpni_arr[dpsw_uc_info.ing_port];
				/* enqueue */
				{
					err = test_send_frame(
						dpni_send, dpbp, swp,
						dpsw_uc_info.tx_frame,
						dpsw_uc_info.tx_frame_len,
						0 /* no special options */,
						0 /* no tx flow id */);
					err_sending = err;

				}

				/* counters check */
				{
					err_counters |=
						check_dpni_counter(
							dpni_arr[dpsw_uc_info.ing_port],
							DPNI_CNT_EGR_FRAME, j);

					err_counters |=
						check_dpni_counter(
							dpni_arr[dpsw_uc_info.ing_port],
							DPNI_CNT_EGR_BYTE,
							(j
								* dpsw_uc_info.tx_frame_len));

				}

			} else if (sending_mac_id /* send from mac*/) {
				test_inject_frame(
					"[dpsw_uc_info.tx_frame value].pcap",
					sending_mac_id);
				err_sending = 0;

				/* counters check */
				{
					err_counters |=
						check_dpmac_counter(
							dpmac_arr[dpsw_uc_info.ing_port],
							DPMAC_CNT_ING_GOOD_FRAME,
							j);
				}
			}

			/* dpsw counters check */
			{
				err_counters |= check_dpsw_if_counter(
					dpsw, ing_port, DPSW_CNT_ING_FRAME, j);
			}
		}

		dump_counters(dpsw, dpni_arr, dpmac_arr);
		CHECK_ERR(err_sending, "frame send");

		/* receive */
		{
			int receiving_mac_id;
			int receive_by_dpni;
			for (i = 0; i < ARRAY_SIZE(dpsw_uc_info.egr_ports);
				i++) {
				if (dpsw_uc_info.egr_ports[i]
					== (uint16_t) - 1)
					continue;
				fsl_print("Receiving frame(s) #%i...\n", i);

				receiving_mac_id =
					dpsw_uc_info.ports_peer_mac_id[dpsw_uc_info.egr_ports[i]];
				receive_by_dpni = (receiving_mac_id == 0);
				if (!receiving_mac_id /* receiving from dpni */) {
					struct dpni *dpni_receive =
						dpni_arr[dpsw_uc_info.egr_ports[i]];
					err = check_receive_frame_dpni(
						dpsw, dpni_receive, swp, dpbp,
						dpsw_uc_info.egr_ports[i], j);
					CHECK_ERR(
						err,
						"check_receive_frame_dpni");
				} else if (receiving_mac_id /* receive on mac */) {
					struct dpmac *dpmac_receive =
						dpmac_arr[dpsw_uc_info.egr_ports[i]];
					err = check_receive_frame_dpmac(
						dpsw, dpmac_receive,
						dpsw_uc_info.egr_ports[i], j);
					CHECK_ERR(
						err,
						"check_receive_frame_dpmac");
				}
			}
		}
	}

	return 0;
}

static int check_receive_frame_dpni(struct dpsw *dpsw,
	struct dpni *dpni,
	struct qbman_swp *swp,
	struct dpbp *dpbp,
	uint16_t port,
	int frame_iteration)
{
	uint32_t rx_length;
	uint32_t actual_tx_length = dpsw_uc_info.tx_frame_len;
	uint8_t rx_frame[1512];
	int is_ing_port_mac;
	int i, err;

	/* dequeue */
	{
		err = test_receive_frame(
			dpni, swp, rx_frame, &rx_length,
			0 /* don't keep polling if queue is empty */);
		CHECK_ERR(err, "test_receive_frame");
	}

	is_ing_port_mac =
		(dpsw_uc_info.ports_peer_mac_id[dpsw_uc_info.ing_port] != 0);
	if (is_ing_port_mac) { /* ingress port is mac*/
		actual_tx_length -= 4; /* CRC length */
	}

	/* debug prints */
	{
		fsl_print("(actual) tx_length: %d\n", actual_tx_length);
		fsl_print("rx_length: %d\n", rx_length);
		fsl_print("dump rx frame:\n");

		for (i = 0; i < rx_length; i++) {
			fsl_print("0x%02x ", rx_frame[i]);
		}
		fsl_print("\n");
	}

	/* check received frame integrity */
	{
		err = (actual_tx_length != rx_length);
		CHECK_ERR(
			err,
			"check length equality of ingress and egress frames");

		err = (memcmp(dpsw_uc_info.tx_frame, rx_frame, rx_length));
		CHECK_ERR(
			err,
			"check data equality of ingress and egress frames");
	}

	/* counters check */
	{
		err_counters |= check_dpsw_if_counter(
			dpsw, port, DPSW_CNT_EGR_FRAME,
			(uint64_t)frame_iteration);
		err_counters |= check_dpni_counter(
			dpni, DPSW_CNT_ING_FRAME, (uint64_t)frame_iteration);
	}

	return 0;
}

static int check_receive_frame_dpmac(struct dpsw *dpsw,
	struct dpmac *dpmac,
	uint16_t port,
	int frame_iteration)
{
	/* counters check */
	{
		err_counters |= check_dpsw_if_counter(
			dpsw, port, DPSW_CNT_EGR_FRAME,
			(uint64_t)frame_iteration);
		err_counters |= check_dpmac_counter(
			dpmac,
			DPMAC_CNT_EGR_BYTE,
			(uint64_t)(
				frame_iteration * dpsw_uc_info.tx_frame_len));
	}

	/* counters because of loopback */
	{
		if (dpsw_uc_info.is_macs_loopback) {
			err_counters |= check_dpsw_if_counter(
				dpsw, port, DPSW_CNT_ING_FRAME,
				(uint64_t)frame_iteration);
			err_counters |= check_dpmac_counter(
				dpmac, DPMAC_CNT_ING_GOOD_FRAME,
				(uint64_t)frame_iteration);
		}
	}

	return 0;
}

/*--------------------------- Debug ----------------------------*/

static void dump_counters(struct dpsw *dpsw,
	struct dpni **dpni_arr,
	struct dpmac **dpmac_arr)
{
	uint64_t counter = 0;
	struct dpsw_counters_cfg dpsw_counters_cfg = { 0 };
	int i;

	fsl_print(
		COLOR_BLUE"--------------dumping counters--------------\n"COLOR_RESET);

	/* ingress */
	{
		int ing_is_dpni =
			(dpsw_uc_info.ports_peer_mac_id[dpsw_uc_info.ing_port]
				== 0);

		/* dpsw */
		{
			dump_dpsw_if_counters(
				dpsw, (uint16_t)dpsw_uc_info.ing_port,
				"ingress port");
		}
		/* peer */
		{
			if (ing_is_dpni) {
				dump_dpni_counters(
					dpni_arr[dpsw_uc_info.ing_port],
					"dpni in");
			} else {
				dump_mac_counters(
					dpmac_arr[dpsw_uc_info.ing_port],
					dpsw_uc_info.ports_peer_mac_id[dpsw_uc_info.ing_port],
					"dpmac in");
			}
		}

	}

	/* egress  */
	{
		int is_dpni;

		for (i = 0; i < ARRAY_SIZE(dpsw_uc_info.egr_ports); i++) {
			if (dpsw_uc_info.egr_ports[i] == (uint16_t) - 1)
				continue;

			/* dpsw */
			{
				dump_dpsw_if_counters(
					dpsw,
					(uint16_t)dpsw_uc_info.egr_ports[i],
					"egress port");
			}

			/* peer */
			{
				is_dpni =
					(dpsw_uc_info.ports_peer_mac_id[dpsw_uc_info.egr_ports[i]]
						== 0);
				if (is_dpni) {
					dump_dpni_counters(
						dpni_arr[dpsw_uc_info.egr_ports[i]],
						"dpni out");
				} else {
					dump_mac_counters(
						dpmac_arr[dpsw_uc_info.egr_ports[i]],
						dpsw_uc_info.ports_peer_mac_id[i],
						"dpmac out");
				}
			}
		}
	}

	/* recycle port counters */
	{
		print_port_counters(EIOP_RECYCLE_PORT, 0);
		print_port_counters(EIOP_RECYCLE_PORT, 1);
	}
}

static int set_cfg_info()
{
	const int cfg_index = USE_CASE_INDEX;
	int i;

	/* init */
	memset(&dpsw_uc_info, 0, sizeof(struct dpsw_uc_info));
	dpsw_uc_info.ing_port = (uint16_t)(-1);
	for (i = 0; i < ARRAY_SIZE(dpsw_uc_info.egr_ports); i++) {
		dpsw_uc_info.egr_ports[i] = (uint16_t)(-1);
	}

	/* set info by USE_CASE_INDEX */
	switch (cfg_index) {
	case UC_INT2INT:
		dpsw_uc_info.tx_frame = frame_00_00_01_00_00_01_8023_64;
		dpsw_uc_info.tx_frame_len =
			sizeof(frame_00_00_01_00_00_01_8023_64);
		dpsw_uc_info.num_ifs = 2;
		dpsw_uc_info.ing_port = 0;
		dpsw_uc_info.egr_ports[0] = 1;
		break;
	case UC_INT2EXT:
		dpsw_uc_info.tx_frame = frame_00_00_01_00_00_01_8023_64;
		dpsw_uc_info.tx_frame_len =
			sizeof(frame_00_00_01_00_00_01_8023_64);
		dpsw_uc_info.num_ifs = 2;
		dpsw_uc_info.ing_port = 0;
		dpsw_uc_info.egr_ports[0] = 1;
		dpsw_uc_info.ports_peer_mac_id[1] = 1;
		dpsw_uc_info.is_macs_loopback = 1;
		break;
	case UC_EXT2EXT:
		dpsw_uc_info.tx_frame = frame_00_00_01_00_00_01_8023_64;
		dpsw_uc_info.tx_frame_len =
			sizeof(frame_00_00_01_00_00_01_8023_64);
		dpsw_uc_info.num_ifs = 2;
		dpsw_uc_info.ing_port = 0;
		dpsw_uc_info.egr_ports[0] = 1;
		dpsw_uc_info.ports_peer_mac_id[0] = 1;
		dpsw_uc_info.ports_peer_mac_id[1] = 2;
		dpsw_uc_info.is_macs_loopback = 0;
		break;
	case UC_EXT2INT:
		dpsw_uc_info.tx_frame = frame_00_00_01_00_00_01_8023_64;
		dpsw_uc_info.tx_frame_len =
			sizeof(frame_00_00_01_00_00_01_8023_64);
		dpsw_uc_info.num_ifs = 2;
		dpsw_uc_info.ing_port = 0;
		dpsw_uc_info.egr_ports[0] = 1;
		dpsw_uc_info.ports_peer_mac_id[0] = 1;
		break;
	default:
		CHECK_ERR(1, "invalid use case index\n");
	}

	return 0;
}
