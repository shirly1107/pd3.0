/*
 * Copyright 2017 NXP
 */

/******************************************************************************
 @File          bringup1_test.h

 @Description   declaration of test functions for bring up test #2.
 *//***************************************************************************/

#ifndef __BRINGUP2_TEST_H
#define __BRINGUP2_TEST_H

/* enabled/disable use cases (comment out to disable) */
#define UC_ENABLED_CONFIRMATION
#define UC_ENABLED_DMA
#define UC_ENABLED_LOOPBACK
#define UC_ENABLED_NOLOOPBACK
//#define UC_MAC_INJECTION

#include "common.h"

int bringup2_app_init(void);

#endif /* __BRINGUP2_TEST_H */
