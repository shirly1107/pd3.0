/*
 * Copyright 2017 NXP
 */

/******************************************************************************
 @File          dpdmux_test.h

 @Description   declaration of test functions for bringup test #3.
 *//***************************************************************************/

#ifndef __BRINGUP3_TEST_H
#define __BRINGUP3_TEST_H

#include "fsl_dpdmux_mc.h"
#include "common.h"

int bringup3_app_init(void);

struct dpdmux_uc_info {
	enum dpdmux_method method;
	const uint8_t *tx_frame;
	uint32_t tx_frame_len;
	uint16_t ing_port;
	uint16_t egr_ports[10];
	uint16_t num_ifs;
	int is_bridge_enabled;
};

#endif /* __BRINGUP3_TEST_H */
