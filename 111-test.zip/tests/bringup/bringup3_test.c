/*
 * Copyright 2017 NXP
 */

/******************************************************************************
 @File          bringup3_test.c

 @Description   test implementation
 *//***************************************************************************/

/************/
/* INCLUDES */
/************/

#include "bringup3_test.h"
#include "common.h"

#include "fsl_types.h"
#include "fsl_dprc_mc.h"
#include "fsl_dpmac_mc.h"
#include "kernel/device.h"
#include "fsl_errors.h"
#include "common/fsl_string.h"			/* memset */
#include "include/fsl_sys.h"
#include "fsl_malloc.h"
#include "fsl_dpmng_mc.h"			/* dpmng_amq */
#include "fsl_dpni_mc.h"			/* dpni */
#include "fsl_dpio_mc.h"			/* dpio */
#include "fsl_dpbp_mc.h"			/* dpbp */
#include "fsl_dpdmux_mc.h"			/* dpdmux */
#include "drivers/fsl_qbman_portal.h"		/* BMan */
#include "drivers/fsl_qbman_ctrl.h"		/* BMan */
#include "fsl_linkman.h"			/* Link Manager */

/************/
/*  DEFINES */
/************/
/* use case defines */
#define UC_VEB_UNICAST			0
#define UC_VEPA_UL2VIRT_UNICAST		1
#define UC_VEPA_VIRT2UL_UNICAST		2
#define UC_VEPA_VIRT2UL_MULTICAST	3
#define UC_VEB_MULTICAST		4

/* TODO: define your use case here from the above values */
#define USE_CASE_INDEX		UC_VEPA_UL2VIRT_UNICAST
/* TODO: enable/disable options */
//#define DPDMUX_OPT_PRUNING_DISABLE /* effective only for UC_VEPA_VIRT2UL_MULTICAST*/
/* others */
#define UPLINK_MAC		1
#define TEST_BUFFER_SIZE	512
#define TEST_BUFFER_NUM		DPNI_MIN_BUFFERS_NUM
#define MAX_RX_FRAME_LEN	128	/* the max among all the use cases */

#define MAC_LOOPBACK_SUPPORTED_BY_SIMULATOR
/************/
/*  GLOBAL  */
/************/
static struct dpdmux_uc_info dpdmux_uc_info = { 0 };
static uint8_t mac_id = UPLINK_MAC;
extern const enum dpmng_ctx_type global_objects_context;

/********************************/
/* Static functions declaration */
/********************************/
/* initialization functions */

static int init_dpdmux(struct dpdmux **dpdmux_p);
static int init_dpni(struct dpni **dpni_p);

static int init_objects(struct dpdmux **dpdmux,
	struct dpmac **dpmac,
	struct dpni **dpni_arr,
	int dpni_arr_size,
	struct dpbp **dpbp,
	struct dpio **dpio,
	struct qbman_swp **swp);
static int destroy_objects(struct dpdmux *dpdmux,
	struct dpmac *dpmac,
	struct dpni **dpni_arr,
	int dpni_arr_size,
	struct dpio *dpio,
	struct dpbp *dpbp);
/* configuration functions */
static int configure_dpni_mac_addr(struct dpni *dpni, const uint8_t *mac_addr);
static int configure_connect(struct dpdmux *dpdmux,
	struct dpni **dpni_arr,
	int dpni_arr_size);
static int send_event(enum linkman_event event,
	uint16_t dpdmux_id /*! dpdmux ID */,
	uint16_t if_id /*! dpdmux interface id */,
	uint16_t dpni_id /*! peer connector id */);
static void set_cfg_info();

/* utilities*/
static int is_in_array(uint16_t arr[], uint16_t arr_size, uint16_t value);

/*****************/
/* Test Function */
/*****************/

int bringup3_app_init(void)
{
	/******************************/
	/*          Variables         */
	/******************************/
	/* objects handles */
	struct dpdmux *dpdmux = NULL;
	struct dpmac *dpmac = NULL;
	struct dpni *dpni_arr[10];
	struct dpbp *dpbp = NULL;
	struct dpio *dpio = NULL;
	struct dpni *dpni_temp = NULL;
	struct qbman_swp *swp = NULL;
	int dpni_num;

	/* flags */
	int is_frame_injected_through_mac;
	int is_egress_uplink;

	/* frame */
	const uint8_t *tx_frame;
	uint32_t tx_length;
	uint8_t rx_frame[MAX_RX_FRAME_LEN];
	uint32_t rx_length;

	/* objects attributes */
	struct dpni_link_state state;

	/* misc */
	uint16_t i;
	int err, j;
	int err_counters = 0, err_destroy = 0, err_receieve = 0, err_receive =
		0;

	/***************************/
	/*     Initializations     */
	/***************************/
	/* set use case info */
	{
		set_cfg_info();

		tx_frame = dpdmux_uc_info.tx_frame;
		tx_length = dpdmux_uc_info.tx_frame_len;
		dpni_num = dpdmux_uc_info.num_ifs;
	}

	err = init_objects(&dpdmux, &dpmac, dpni_arr, dpni_num, &dpbp, &dpio,
				&swp);
	LOOP_ON_ERR(err, "objects initialization");

	/***************************/
	/*      Configuration      */
	/***************************/
	for (i = 0; i < dpni_num; i++) {
		/* set mac address only for egress ports */
		if (is_in_array(dpdmux_uc_info.egr_ports,
				ARRAY_SIZE(dpdmux_uc_info.egr_ports),
				(i + 1))) {
			err = configure_dpni_mac_addr(dpni_arr[i], tx_frame);
			LOOP_ON_ERR(err, "configure_dpni_mac_addr");
		} else if (dpdmux_uc_info.ing_port == (i + 1)) {
			if (NH_ETH_IS_MULTICAST_ADDR(tx_frame)) { /* additions for checking pruning */
				/* add tx frame destination MAC */
				err = configure_dpni_mac_addr(dpni_arr[i],
								tx_frame);
				LOOP_ON_ERR(err, "configure_dpni_mac_addr");
				/* add tx frame source MAC (indication for pruning not to receive on the sending port) */
				err = configure_dpni_mac_addr(
					dpni_arr[i], (tx_frame + 6));
				LOOP_ON_ERR(err, "configure_dpni_mac_addr");
			}
		}
	}

	/* set loopback for the uplink MAC
	 * Required for particular MAC IDs. Doesn't affect on the test */
	err = dpmac_set_loopback(dpmac, 1 /* enable */);
	LOOP_ON_ERR(err, "dpmac_set_loopback");

	/* connect dpdmux to dpmac/dpni-s */
	err = configure_connect(dpdmux, dpni_arr, dpni_num);
	LOOP_ON_ERR(err, "configure_connect");

	/***************************/
	/*           Send          */
	/***************************/
	fsl_print(
		"\x1b[34m================= Sending =================\x1b[0m\n");
	is_frame_injected_through_mac = (dpdmux_uc_info.ing_port == 0);

	if (!is_frame_injected_through_mac) { /* ingress port is not uplink */

		/* validate link state is up for sending dpni */
		{
			err = dpni_get_link_state(
				dpni_arr[(dpdmux_uc_info.ing_port - 1)],
				&state);
			LOOP_ON_ERR(err, "dpni_get_link_state");
			err = !(state.up == 1);
			LOOP_ON_ERR(
				err, "validate sending dpni link state is up");
		}

		/* send */
		{
			err = test_send_frame(
				dpni_arr[(dpdmux_uc_info.ing_port - 1)], dpbp,
				swp, tx_frame, tx_length,
				0 /* no special options */,
				0 /* no tx flow id */);
			LOOP_ON_ERR(err, "frame send");
		}

		/* egress dpni counters */
		{
			dpni_temp = dpni_arr[(dpdmux_uc_info.ing_port - 1)];
			dump_dpni_counters(dpni_temp, "ingress dpni");

			err_counters |= check_dpni_counter(
				dpni_temp, DPNI_CNT_EGR_FRAME, 1);

			err_counters |= check_dpni_counter(
				dpni_temp, DPNI_CNT_EGR_BYTE, tx_length);
		}

		/* dpdmux ingress port counters */
		{
			dump_dpdmux_if_counters(dpdmux,
						dpdmux_uc_info.ing_port,
						"ingress port");
			fsl_print("check ingress counters...\n");
			err_counters |= check_dpdmux_counter(
				dpdmux, dpdmux_uc_info.ing_port,
				DPDMUX_CNT_ING_FRAME, 1);

			err_counters |= check_dpdmux_counter(
				dpdmux, dpdmux_uc_info.ing_port,
				DPDMUX_CNT_ING_BYTE, tx_length);
		}
	} else if (is_frame_injected_through_mac) {
		/* send */
		{
			test_inject_frame("00_00_01_00_00_01.8023.64.pcap",
						UPLINK_MAC);
			tx_length -= 4; /* MAC removes CRC field */
		}

		/* mac counters */
		{
			fsl_print("dump uplink mac counters...\n");
			dump_mac_counters(dpmac, mac_id, "uplink MAC");

			fsl_print("check mac counters...\n");

			err_counters |= check_dpmac_counter(
				dpmac, DPMAC_CNT_ING_BYTE, tx_length);
		}

		/* dpdmux uplink counters */
		{
			dump_dpdmux_if_counters(dpdmux, 0, "uplink");
			fsl_print("check uplink counters...\n");
			err_counters |= check_dpdmux_counter(
				dpdmux, 0/*uplink port*/, DPDMUX_CNT_ING_FRAME,
				1);

			err_counters |= check_dpdmux_counter(
				dpdmux, 0/*uplink port*/, DPDMUX_CNT_ING_BYTE,
				tx_length);
		}
	}

	/* port counters */
	{
		print_port_counters(EIOP_RECYCLE_PORT, 0);
		print_port_counters(EIOP_RECYCLE_PORT, 1);
	}

	/***************************/
	/*         Receive         */
	/***************************/
	fsl_print(
		"\x1b[34m=============== Not Receiving Checks ===============\x1b[0m\n");
	/* check frames not received on virtual ports not aimed to */
	{
		int frame_shouldnt_be_received_on_this_port;
		uint16_t virt_port;

		for (virt_port = 1; virt_port <= dpdmux_uc_info.num_ifs;
			virt_port++) {
			frame_shouldnt_be_received_on_this_port = !is_in_array(
				dpdmux_uc_info.egr_ports,
				ARRAY_SIZE(dpdmux_uc_info.egr_ports),
				virt_port);

#ifdef DPDMUX_OPT_PRUNING_DISABLE
			if (virt_port == dpdmux_uc_info.ing_port) {
				frame_shouldnt_be_received_on_this_port = 0;
			}
#endif

			if (frame_shouldnt_be_received_on_this_port) {
				fsl_print(
					"\x1b[34mchecking frame was NOT received on port %d...\x1b[0m\n",
					virt_port);
				err = test_receive_frame(
					dpni_arr[(virt_port - 1)], swp,
					rx_frame, &rx_length,
					0 /* don't poll while empty */);
				err = (err != -ENAVAIL);

				dump_dpdmux_if_counters(
					dpdmux, dpdmux_uc_info.ing_port,
					"egress port");

				dpni_temp = dpni_arr[(virt_port - 1)];
				dump_dpni_counters(dpni_temp, "egress dpni");

				LOOP_ON_ERR(err, "frame not received");
			}
		}
	}

	fsl_print(
		"\x1b[34m================= Receiving Checks =================\x1b[0m\n");
	/* check receive */
	for (i = 0; i < ARRAY_SIZE(dpdmux_uc_info.egr_ports); i++) {
		if (dpdmux_uc_info.egr_ports[i] != (uint16_t)(-1)) {
			fsl_print(
				"\x1b[34m=== checking frame was received on port %d...\x1b[0m\n",
				dpdmux_uc_info.egr_ports[i]);
			is_egress_uplink = (dpdmux_uc_info.egr_ports[i] == 0);
			/* counters influenced by the receiving */
			{
				/* dpdmux egress port counters */
				{
					dump_dpdmux_if_counters(
						dpdmux,
						dpdmux_uc_info.egr_ports[i],
						"egress port");
					fsl_print(
						"check egress port counters...\n");
					err_counters |= check_dpdmux_counter(
						dpdmux,
						dpdmux_uc_info.egr_ports[i],
						DPDMUX_CNT_EGR_FRAME, 1);

					err_counters |= check_dpdmux_counter(
						dpdmux,
						dpdmux_uc_info.egr_ports[i],
						DPDMUX_CNT_EGR_BYTE,
						(uint64_t)tx_length
						+ (is_egress_uplink ? 4 : 0)); /* the egress port of the uplink are taken from the MAC that adds CRC */
				}

				if (!is_egress_uplink) {
					/* dpni ingress counters */
					dpni_temp =
						dpni_arr[(dpdmux_uc_info.egr_ports[i]
								- 1)];
					dump_dpni_counters(dpni_temp,
								"egress dpni");

					err_counters |= check_dpni_counter(
						dpni_temp, DPNI_CNT_ING_FRAME,
						1);

					err_counters |= check_dpni_counter(
						dpni_temp, DPNI_CNT_ING_BYTE,
						(uint64_t)tx_length);
				} else if (is_egress_uplink) {
					/* dpmac egress counters */
					fsl_print(
						"dump uplink mac counters...\n");
					dump_mac_counters(dpmac, mac_id,
								"uplink MAC");

					fsl_print(
						"check mac counters...\n");

					err_counters |=
						check_dpmac_counter(
							dpmac,
							DPMAC_CNT_EGR_BYTE,
							(tx_length + 4)/* 4 is for the CRC added by MAC*/);

#ifdef MAC_LOOPBACK_SUPPORTED_BY_SIMULATOR
					err_counters |=
						check_dpmac_counter(
							dpmac,
							DPMAC_CNT_ING_BYTE,
							tx_length
							+ 4 /* +4 is for the CRC added by MAC on egress*/);
#endif
				}
			}

			if (!is_egress_uplink) {
				/* validate link state is up for receiving dpni */
				{
					err =
						dpni_get_link_state(
							dpni_arr[(dpdmux_uc_info.egr_ports[i]
									- 1)],
							&state);
					LOOP_ON_ERR(err,
							"dpni_get_link_state");
					err = !(state.up == 1);
					LOOP_ON_ERR(
						err,
						"validate receiving dpni link state is up");
				}

				/* dequeue from dpni (connected to dpdmux virtual port) */
				err =
					test_receive_frame(
						/* dequeue from dpni connected to egress virtual port */
						dpni_arr[(dpdmux_uc_info.egr_ports[i]
								- 1)],
						swp,
						rx_frame,
						&rx_length,
						is_frame_injected_through_mac /* poll_while_empty */);
				LOOP_ON_ERR(err, "frame receive");

				if (!err) {
					/***************************/
					/*         Compare         */
					/***************************/
					/* debug prints */

					/* check */
					err = (tx_length != rx_length);
					if (err) {
						fsl_print("rx_length: %d\n",
								rx_length);
						fsl_print("tx_length: %d\n",
								tx_length);
					}

					LOOP_ON_ERR(
						err,
						"check length equality of ingress and egress frames");
					err = (memcmp(tx_frame, rx_frame,
							rx_length));
					if (err) {
						fsl_print(
							"dump rx frame:\n");
						for (j = 0; j < rx_length;
							j++) {
							fsl_print(
								"0x%x ",
								rx_frame[j]);
						}
						fsl_print("\n");
					}
					LOOP_ON_ERR(
						err,
						"check content equality of ingress and egress frames");
				}
			} else if (is_egress_uplink) {
				uint64_t counter = 0;

				err = dpmac_get_counter(dpmac,
							DPMAC_CNT_EGR_BYTE,
							&counter);
				if (err) {
					fsl_print(
						"FAIL- dpmac_get_counter DPMAC_CNT_EGR_BYTE\n");
				} else {
					err = (counter == 0);
					LOOP_ON_ERR( err, "receive on uplink");
				}
			}
		}
	}

	/***************************/
	/*         Destroy         */
	/***************************/
	err_destroy = destroy_objects(dpdmux, dpmac, dpni_arr, dpni_num, dpio,
					dpbp);

	/**************************/
	/*       Finish Test      */
	/**************************/
	fsl_print("Bring Up Test #3 Finished:\n");
	print_test_result("Receive frame", err_receive);
	print_test_result("Counters", err_counters);
	print_test_result("Objects Destroy", err_destroy);
	while (1) {
	};

	return 0;
}

/*******************************/
/*        Static functions     */
/*******************************/

/*-------------------------initialization functions---------------------------*/

static int init_objects(struct dpdmux **dpdmux,
	struct dpmac **dpmac,
	struct dpni **dpni_arr,
	int dpni_arr_size,
	struct dpbp **dpbp,
	struct dpio **dpio,
	struct qbman_swp **swp)
{
	int err, i;

	/* dpio */
	err = init_dpio(dpio);
	CHECK_ERR(err, "init_dpio");

	/* swp */
	err = init_swp(swp, *dpio);
	CHECK_ERR(err, "init_swp");

	/* dpdmux */
	err = init_dpdmux(dpdmux);
	CHECK_ERR(err, "dpdmux initialization");

	/* uplink (dpmac)*/
	err = init_dpmac(dpmac, mac_id);
	CHECK_ERR(err, "init_dpmac");

	/* dpbp */
	err = init_dpbp(dpbp);
	CHECK_ERR(err, "init_dpbp");
	err = init_dpbp_buffers(*dpbp, *swp, TEST_BUFFER_NUM,
				TEST_BUFFER_SIZE);
	CHECK_ERR(err, "init_dpbp_buffers");

	/* dpni-s */
	for (i = 0; i < dpni_arr_size; i++) {
		/* Init */
		err = init_dpni(&dpni_arr[i]);
		CHECK_ERR(err, "init_dpni");

		/* attach buffer pool */
		err = ni_set_pool(dpni_arr[i], *dpbp, TEST_BUFFER_SIZE);
		CHECK_ERR(err, "ni_set_pool");

		/* enable */
		err = dpni_enable(dpni_arr[i]);
		CHECK_ERR(err, "dpni_enable");
	}

	return 0;
}

static int init_dpdmux(struct dpdmux **dpdmux_p)
{
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpdmux_cfg dpdmux_cfg = { 0 };
	void *dev = NULL;
	struct dpdmux *dpdmux;
	int err;

	/* allocate */
	*dpdmux_p = dpdmux_allocate();
	err = (*dpdmux_p == NULL);
	CHECK_ERR(err, "dpdmux allocation");

	dpdmux = *dpdmux_p;

	/* fields set by usecase */
	dpdmux_cfg.method = dpdmux_uc_info.method;
	dpdmux_cfg.num_ifs = dpdmux_uc_info.num_ifs;
	if (dpdmux_uc_info.is_bridge_enabled) {
		dpdmux_cfg.adv.options |= DPDMUX_OPT_BRIDGE_EN;
	}
	/* hard coded fields */
	dpdmux_cfg.manip = DPDMUX_MANIP_NONE;
	dpdmux_cfg.control_if = 0;
	dpdmux_cfg.adv.max_dmat_entries = 8;
	dpdmux_cfg.adv.max_mc_groups = 8;

	err = create_resman_device("dpdmux", &dev);
	CHECK_ERR(err, "create_resman_device (dpdmux)");
	dev_cfg.ctx.type = global_objects_context;
	dev_cfg.device = dev;
	dev_cfg.id = device_get_id(dev);

	/* init */
	err = dpdmux_init(dpdmux, &dpdmux_cfg, &dev_cfg);
	CHECK_ERR(err, "dpdmux_init");

	/* register */
	device_set_priv(dev, dpdmux);
	err = sys_add_handle(dpdmux, /* Module Context */
				FSL_MOD_DPDMUX, /* Module type */
				1, /* Number of ID's */
				dev_cfg.id); /* ID */
	CHECK_ERR(err, "sys_add_handle (dpdmux)");

	return 0;
}

static int init_dpni(struct dpni **dpni_p)
{
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpni_cfg cfg = { 0 };
	struct dpni *dpni;
	void *dev = NULL;
	static unsigned char running_num_for_dpni_dummy_mac_addr = 1;
	int err;

	/* allocation */
	*dpni_p = dpni_allocate();
	err = (*dpni_p == NULL);
	CHECK_ERR(err, "dpni allocation");

	/* init */
	dpni = *dpni_p;
	cfg.mac_addr[3] = 0x42; /* dummy */
	cfg.mac_addr[4] = running_num_for_dpni_dummy_mac_addr++;
	cfg.adv.options = DPNI_OPT_MULTICAST_FILTER;
	err = create_resman_device("dpni", &dev);
	CHECK_ERR(err, "create_resman_device (dpni)");
	dev_cfg.device = dev;
	dev_cfg.ctx.type = global_objects_context;
	dev_cfg.id = device_get_id(dev);

	err = dpni_init(dpni, &cfg, &dev_cfg);
	CHECK_ERR(err, "dpni_init");
	err = dpni_set_dev_ctx(dpni, &dev_cfg.ctx);
	CHECK_ERR(err, "dpni_set_dev_ctx");

	/* Register NI in RM*/
	device_set_priv(dev, dpni);
	err = sys_add_handle(dpni, FSL_MOD_DPNI, 1, dev_cfg.id);
	CHECK_ERR(err, "sys_add_handle (dpni)");

	return 0;
}

static int destroy_objects(struct dpdmux *dpdmux,
	struct dpmac *dpmac,
	struct dpni **dpni_arr,
	int dpni_arr_size,
	struct dpio *dpio,
	struct dpbp *dpbp)
{
	struct dpni *dpni;
	struct dpni_attr dpni_attr;
	struct dpdmux_attr dpdmux_attr;
	struct dpbp_attr dpbp_attr;
	struct dpio_attr dpio_attr;
	int err, i;

	/* dpni */
	for (i = 0; i < dpni_arr_size; i++) {
		dpni = dpni_arr[i];
		err = dpni_get_attributes(dpni, &dpni_attr);
		CHECK_ERR(err, "dpni_get_attributes");
		dpni_destroy(dpni);
		sys_remove_handle(FSL_MOD_DPNI, 1, dpni_attr.id);
		CHECK_ERR(err, "sys_remove_handle (dpni)");
		dpni_deallocate(dpni);
		CHECK_ERR(err, "dpni_deallocate");
	}

	/* dpbp */
	err = dpbp_get_attributes(dpbp, &dpbp_attr);
	CHECK_ERR(err, "dpbp_get_attributes");
	dpbp_destroy(dpbp);
	sys_remove_handle(FSL_MOD_DPBP, 1, dpbp_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpbp)");
	dpbp_deallocate(dpbp);
	CHECK_ERR(err, "dpbp_deallocate");

	/* dpdmux */
	err = dpdmux_get_attributes(dpdmux, &dpdmux_attr);
	CHECK_ERR(err, "dpdmux_get_attributes");
	dpdmux_destroy(dpdmux);
	sys_remove_handle(FSL_MOD_DPDMUX, 1, dpdmux_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpdmux)");
	dpdmux_deallocate(dpdmux);
	CHECK_ERR(err, "dpdmux_deallocate");

	/* dpmac */
	dpmac_destroy(dpmac);
	sys_remove_handle(FSL_MOD_DPMAC, 1, UPLINK_MAC);
	CHECK_ERR(err, "sys_remove_handle (dpmac)");
	dpmac_deallocate(dpmac);
	CHECK_ERR(err, "dpmac_deallocate");

	/* dpio */
	err = dpio_get_attributes(dpio, &dpio_attr);
	CHECK_ERR(err, "dpio_get_attributes");
	dpio_destroy(dpio);
	sys_remove_handle(FSL_MOD_DPIO, 1, dpio_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpio)");
	dpio_deallocate(dpio);
	CHECK_ERR(err, "dpio_deallocate");

	return 0;
}

/*------------------------- Utility Functions --------------------------*/
static int is_in_array(uint16_t arr[], uint16_t arr_size, uint16_t value)
{
	int i;
	for (i = 0; i < arr_size; i++) {
		if (arr[i] == value)
			return 1; /* found */
	}
	return 0; /* not found */
}

/*------------------------- Configuration Functions --------------------------*/

static int configure_dpni_mac_addr(struct dpni *dpni, const uint8_t *mac_addr)
{
	int err;

	if (!NH_ETH_IS_MULTICAST_ADDR(mac_addr)) { /* unicast address */
		err = dpni_set_primary_mac_addr(dpni, mac_addr);
		CHECK_ERR(err, "dpni_set_primary_mac_addr");
	} else { /* multicast/broarcast address */
		err = dpni_add_mac_addr(dpni, mac_addr);
		CHECK_ERR(err, "dpni_add_mac_addr");
	}
	return 0;
}

static int configure_connect(struct dpdmux *dpdmux,
	struct dpni **dpni_arr,
	int dpni_arr_size)
{
	struct dpdmux_attr dpdmux_attr;
	struct dpni_attr dpni_attr;
	uint16_t dpdmux_id;
	uint16_t dpni_id;
	uint16_t i;
	int err;

	/* get dpdmux id + validation */
	{
		err = dpdmux_get_attributes(dpdmux, &dpdmux_attr);
		CHECK_ERR(err, "dpdmux_get_attributes");
		dpdmux_id = (uint16_t)dpdmux_attr.id;

		err = (dpni_arr_size > dpdmux_attr.num_ifs);
		CHECK_ERR(err, "validate dpdmux number of interfaces");
	}

	/*! Connect Uplink */
	{
		err = send_event(LINKMAN_EVENT_CONNECT, /*! Event */
					dpdmux_id, /*! dpdmux ID */
					0, /*! dpdmux uplink interface id */
					(uint16_t)(-1)); /* -1 signals to send_event to connect uplink */
		CHECK_ERR(err, "send_event (connect dpmac-dpdmux)");

		err = send_event(LINKMAN_EVENT_LINKUP, /*! Event */
					dpdmux_id, /*! dpdmux ID */
					0, /*! dpdmux uplink interface id */
					(uint16_t)(-1)); /* -1 signals to send_event to connect uplink */
	}

	/*! Connect Virtuals */
	{
		for (i = 0; i < dpni_arr_size; i++) {
			/* get dpni id */
			err = dpni_get_attributes(dpni_arr[i], &dpni_attr);
			CHECK_ERR(err, "dpni_get_attr");
			dpni_id = (uint16_t)dpni_attr.id;

			/*! Connect */
			err = send_event(LINKMAN_EVENT_CONNECT, /*! Event */
						dpdmux_id, /*! dpdmux ID */
						(i + 1), /*! dpdmux interface id */
						dpni_id); /* peer connector id */
			CHECK_ERR(err, "send_event (connect)");

			/*! Link up */
			err = send_event(LINKMAN_EVENT_LINKUP, /*! Event */
						dpdmux_id, /*! dpdmux ID */
						(i + 1), /*! dpdmux interface id */
						dpni_id); /*! peer connector id */

			CHECK_ERR(err, "send_event (link up)");
		}
	}
	return 0;
}

static int send_event(enum linkman_event event,
	uint16_t dpdmux_id /*! dpdmux ID */,
	uint16_t if_id /*! dpdmux interface id */,
	uint16_t dpni_id /*! peer connector id- if -1 then dpmac it connected to switch */)
{
	int err;
	struct linkman_endpoint self; /* dpdmux */
	struct linkman_endpoint peer; /* dpni */
	struct linkman *linkman = NULL;
	struct linkman_control control;

	memset(&self, 0x0, sizeof(struct linkman_endpoint));
	memset(&peer, 0x0, sizeof(struct linkman_endpoint));

	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	err = (linkman == NULL);
	CHECK_ERR(err, "sys_get_unique_handle (linkman)");

	/* dpdmux */
	self.id = (uint16_t)dpdmux_id; /* dppmux ID */
	self.type = FSL_MOD_DPDMUX; /* Type */
	self.if_id = if_id; /* IF ID */

	/* Peer connector */
	if (dpni_id != (uint16_t)(-1)) {
		peer.type = FSL_MOD_DPNI; /* peer type*/
		peer.id = dpni_id; /* peer id */
	} else {
		peer.type = FSL_MOD_DPMAC; /* peer type*/
		peer.id = UPLINK_MAC; /* peer id */
	}

	control.event = event;
	control.committed_rate = 0; //2000;
	control.max_rate = 0;
	/* Start link up state machine */
	err = linkman_set_connection(linkman, /*! context */
					&control, /*! event */
					&self, /*! endpoint 1 */
					&peer); /*! endpoint 2 */

	return err;
}

static void set_cfg_info()
{
	const int cfg_index = USE_CASE_INDEX;
	int i;

	/* init */
	dpdmux_uc_info.ing_port = (uint16_t)(-1);
	for (i = 0; i < ARRAY_SIZE(dpdmux_uc_info.egr_ports); i++) {
		dpdmux_uc_info.egr_ports[i] = (uint16_t)(-1);
	}

	/* set info by USE_CASE_INDEX */
	switch (cfg_index) {
	case UC_VEB_UNICAST:
		dpdmux_uc_info.method = DPDMUX_METHOD_MAC;
		dpdmux_uc_info.tx_frame = frame_00_00_01_00_00_01_8023_64;
		dpdmux_uc_info.tx_frame_len =
			sizeof(frame_00_00_01_00_00_01_8023_64);
		dpdmux_uc_info.num_ifs = 2;
		dpdmux_uc_info.ing_port = 1;
		dpdmux_uc_info.egr_ports[0] = 2;
		dpdmux_uc_info.is_bridge_enabled = 1;
		break;
	case UC_VEPA_UL2VIRT_UNICAST:
		dpdmux_uc_info.method = DPDMUX_METHOD_MAC;
		dpdmux_uc_info.tx_frame = frame_00_00_01_00_00_01_8023_64;
		dpdmux_uc_info.tx_frame_len =
			sizeof(frame_00_00_01_00_00_01_8023_64);
		dpdmux_uc_info.num_ifs = 1;
		dpdmux_uc_info.ing_port = 0;
		dpdmux_uc_info.egr_ports[0] = 1;
		dpdmux_uc_info.is_bridge_enabled = 0;
		break;
	case UC_VEPA_VIRT2UL_UNICAST:
		dpdmux_uc_info.method = DPDMUX_METHOD_MAC;
		dpdmux_uc_info.tx_frame = frame_00_00_01_00_00_01_8023_64;
		dpdmux_uc_info.tx_frame_len =
			sizeof(frame_00_00_01_00_00_01_8023_64);
		dpdmux_uc_info.num_ifs = 1;
		dpdmux_uc_info.ing_port = 1;
		dpdmux_uc_info.egr_ports[0] = 0;
		dpdmux_uc_info.is_bridge_enabled = 0;
		break;
	case UC_VEPA_VIRT2UL_MULTICAST:
		dpdmux_uc_info.method = DPDMUX_METHOD_MAC;
		dpdmux_uc_info.tx_frame = frame_01_02_03_04_05_06_8023_128;
		dpdmux_uc_info.tx_frame_len =
			sizeof(frame_01_02_03_04_05_06_8023_128);
		dpdmux_uc_info.num_ifs = 3;
		dpdmux_uc_info.ing_port = 1;
		dpdmux_uc_info.egr_ports[0] = 0;
#ifdef MAC_LOOPBACK_SUPPORTED_BY_SIMULATOR /* must have working mac loopback */
		dpdmux_uc_info.egr_ports[1] = 2;
		dpdmux_uc_info.egr_ports[2] = 3;
#ifdef DPDMUX_OPT_PRUNING_DISABLE
		dpdmux_uc_info.egr_ports[3] = dpdmux_uc_info.ing_port;
#endif		/* DPDMUX_OPT_PRUNING_DISABLE */
#endif /* MAC_LOOPBACK_SUPPORTED_BY_SIMULATOR */
		dpdmux_uc_info.is_bridge_enabled = 0;
		break;
	case UC_VEB_MULTICAST:
		dpdmux_uc_info.method = DPDMUX_METHOD_MAC;
		dpdmux_uc_info.tx_frame = frame_01_02_03_04_05_06_8023_128;
		dpdmux_uc_info.tx_frame_len =
			sizeof(frame_01_02_03_04_05_06_8023_128);
		dpdmux_uc_info.num_ifs = 2;
		dpdmux_uc_info.ing_port = 1;
		dpdmux_uc_info.egr_ports[0] = 2;
		dpdmux_uc_info.is_bridge_enabled = 1;
		break;

	default:
		break;
	}
}
