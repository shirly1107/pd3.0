/*
 * Copyright 2017 NXP
 */

/******************************************************************************
 @File          bringup1_test.h

 @Description   declaration of test functions for bringup test #1.
 *//***************************************************************************/

#ifndef __BRINGUP1_TEST_H
#define __BRINGUP1_TEST_H

/* enabled/disable use cases (comment out to disable) */
#define UC_ENABLED_DPSW_TRAFFIC

#include "common.h"

int bringup1_app_init(void);

struct dpsw_uc_info {
	const uint8_t *tx_frame;
	uint32_t tx_frame_len;
	uint16_t num_ifs;
	uint16_t ports_peer_mac_id[10]; /* 0 for non-mac peer */
	uint16_t ing_port;
	uint16_t egr_ports[10];
	int is_macs_loopback;
};

#endif /* __BRINGUP1_TEST_H */
