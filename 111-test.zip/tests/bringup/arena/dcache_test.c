/*
 * Copyright 2017 NXP
 */


#include "fsl_types.h"
#include "fsl_errors.h"
#include "dcache_test.h"
#include "fsl_core_booke_regs.h"
#include "fsl_core_booke.h"
#include "fsl_core_arch.h"
#include "fsl_io.h"
#include "fsl_sys.h"
#include "drivers/fsl_edma.h"
#include "edma_init.h"
#include "fsl_string.h"
#include "fsl_smp.h"
#include "edma.h"

int dcache_init();
int dcache_test();
static uint8_t buffer_A[32];
static uint8_t buffer_B[32];

 /*External functions and objects */
extern struct edma_queue g_queue_0_core0;
extern struct edma_queue g_queue_0_core1;

/*****************************************************************************/
int dcache_init()
{
	booke_dcache_enable();
	fsl_print("The test will work after initialization of edma and console\n");
	return 0;
}


/*****************************************************************************/
int dcache_test()
{
	void *ptr;
	uint32_t temp;
	void *dma_src_virt;
	struct edma_queue *p_queue;
	struct edma_transfer params = {0};
	enum transac_status status;

	uint32_t block_id = 0,queue_id = 0;
	int rc = 0;

	dma_src_virt = &buffer_A[0];
	ptr = &buffer_B[0]; /*virt to phys*/
	memset32(dma_src_virt,'5',32);/*0x35, update the src address used for dma with different value*/
	//fsl_print("%x\n",(uint32_t)*(uint32_t *)dma_src_virt);
	if(!sys_is_master_core())
		 block_id = 1;
	params.byte_count = 32;
	params.src_icid = 0x0; // an arbitrary value only for demonstration
	params.dst_icid = 0x0; // an arbitrary value only for demonstration
	params.flags |= EDMA_DEST_ADDR_IA | EDMA_DEST_ADDR_PL | EDMA_DEST_ADDR_BMT;
	params.flags |= EDMA_SRC_ADDR_IA | EDMA_SRC_ADDR_PL | EDMA_SRC_ADDR_BMT;
	/* Retrieve queue_0 from block 0 */
	if(block_id == 0)
			p_queue = &g_queue_0_core0;
		else
			p_queue = &g_queue_0_core1;

	//p_source_addr = fsl_virt_to_phys(dma_src_virt);
	//p_dest_addr = fsl_virt_to_phys(ptr);
	params.src = (uint64_t) dma_src_virt;
	params.dst = (uint64_t) ptr;


	/*The test start here*/
	memset32(ptr,'2',32);/*0x32*/
	temp = (uint32_t)*(uint32_t *)ptr;
	fsl_print("you may see any value:\n");
	fsl_print("before fetch: 0x%x\n\n",temp); /*you may see the original value or not - depends on the value in cache*/
	fetch(ptr,32);
	/*write different value with fdma*/
	temp = (uint32_t)*(uint32_t *)ptr;
	fsl_print("you must see 0x32323232\n");
	fsl_print("after fetch: 0x%x\n\n",temp); /*You have to see the value 0x32323232 */
	rc = edma_queue_transfer(p_queue,&params,&status);
	if(status != EDMA_NORMAL){
		fsl_print("test failed during edma copy\n");
		return -1;
	}
	fsl_print("you must see value 0x32323232:(from cache)\n");
	fsl_print("after edma: 0x%x\n\n",temp);/*you should receive the value 0x32323232 */

	fetch(ptr,32);
		/*write different value with fdma*/
	temp = (uint32_t)*(uint32_t *)ptr;
	fsl_print("you must see value different from 0x32323232:(must be 0x35353535)\n");
	fsl_print("after fetch: 0x%x\n\n",temp);/*you should not receive the value 0x32323232 */
	memset32(ptr,'4',32);/*0x34*/
	flush(ptr,32);
	temp = (uint32_t)*(uint32_t *)ptr;
	fsl_print("now you should see bellow exactly 2 same values(not 0x32323232):\n");
	fsl_print("after flush:  0x%x\n",temp);
	/*dma read - you should see the same value like in the cache*/
	params.src =  (uint64_t) ptr;
	params.dst =  (uint64_t) dma_src_virt;

	rc = edma_queue_transfer(p_queue,&params,&status);
	if(status != EDMA_NORMAL){
		fsl_print("test failed during edma copy\n");
		return -1;
	}

	fetch(dma_src_virt,32);
	temp = (uint32_t)*(uint32_t *)dma_src_virt;
	fsl_print("after flush:  0x%x\n\n\n\n",temp);
	fsl_print("End of test.\n");

	while(1){}
	return 0;
}


static void fetch(void *ptr, uint32_t size)
{
	uint32_t cache_size = 0;
	uint32_t addr = (uint32_t)ptr;

	ASSERT_COND_LIGHT(size != 0);
	while(cache_size <= size)
	{
		l1dcache_block_invalidate(addr);
		addr += L1_CACHE_LINE_SIZE;
		cache_size += L1_CACHE_LINE_SIZE;
	}

}

/*****************************************************************************/
static void flush(void *ptr, uint32_t size)
{
	uint32_t cache_size = 0;
	uint32_t addr = (uint32_t)ptr;
	volatile uint64_t chase_read;
	int i;

	ASSERT_COND_LIGHT(size != 0);
	while(cache_size <= size)
	{
		/*The cache is right through so the call to flush is
		 * just for future support */
		/*l1dcache_block_flush(addr);//This call is not supported on simulator*/
		l1dcache_block_invalidate(addr);
		/*read in chunks of 8 bytes*/
		for(i = 0; i < L1_CACHE_LINE_SIZE && cache_size <= size;
			i += sizeof(uint64_t),
			addr += sizeof(uint64_t),
			cache_size += sizeof(uint64_t))
		{
			chase_read = (*(uint64_t *)addr);
			core_memory_barrier();
			core_instruction_sync();
			UNUSED(chase_read);
		}
	}
	core_instruction_sync();
}


