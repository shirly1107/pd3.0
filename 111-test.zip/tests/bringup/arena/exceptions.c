/*
 * Copyright 2017 NXP
 */

#include "fsl_errors.h"
#include "fsl_io.h"
#include "fsl_platform.h"
#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_soc.h"
#include "fsl_dbg.h"
#include "fsl_core_booke.h"
#include "fsl_core_booke_regs.h"
#include "fsl_core_regs_arch.h"
#include "booke.h"
#include "fsl_dbg.h"
#include "bringup_tests.h"

#if (TEST_EXCEPTIONS == ON)

static int check_exceptions()
{
	uint32_t esr, mcsr;

	esr = booke_get_spr_ESR();
	mcsr = booke_get_spr_MCSR();

	if (!esr && !mcsr)
		return 1; /* No exceptions */
	else
		return 0; /* Exception happened */
}

/*---------------------------------------------------------*/
/*  Install A PPC Interrupt vector routine                 */
/*---------------------------------------------------------*/
int booke_set_intr(int ppc_intr_src,
		   void (* isr)(void * handle),
		   void * handle);
int booke_set_intr(int ppc_intr_src,
		   void (* isr)(void * handle),
		   void * handle)
{
	do {} while(1); /* FAILED: Exceptions test */

	return -1;
}


/*---------------------------------------------------------*/
/*  Clear A PPC Interrupt vector routine                   */
/*---------------------------------------------------------*/
int booke_clear_intr(int ppc_intr_src);
int booke_clear_intr(int ppc_intr_src)
{
	do {} while(1); /* FAILED: Exceptions test */
	return -1;
}
/*****************************************************************/
/* routine:       booke_generic_irq_init                         */
/*                                                               */
/* description:                                                  */
/*        Initiate the Ivpr register to point to right address.  */
/* arguments:                                                    */
/*    None.                                                      */
/*                                                               */
/*****************************************************************/
void booke_generic_irq_init(void);
void booke_init_interrupt_vector(void);
void booke_generic_irq_init(void)
{
	booke_init_interrupt_vector();
}

/*****************************************************************/
/* routine:       booke_critical_isr                             */
/*                                                               */
/* description:                                                  */
/*    Internal routine, called by the critical interrupt handler */
/*    to indicate the occurrence of a critical INT.              */
/*                                                               */
/* arguments:                                                    */
/*    intr_entry (In) - The interrupt handler original offset.   */
/*                                                               */
/*****************************************************************/
void booke_critical_isr(uint32_t intr_entry);
void booke_critical_isr(uint32_t intr_entry)
{
	do {} while(1); /* FAILED: Exceptions test */
}


/*****************************************************************/
/* routine:       booke_generic_isr                              */
/*                                                               */
/* description:                                                  */
/*    Internal routine, called by the main interrupt handler     */
/*    to indicate the occurrence of an INT.                      */
/*                                                               */
/* arguments:                                                    */
/*    intrEntry (In) - The interrupt handler original address.   */
/*                                                               */
/*****************************************************************/

/* Redefine original function booke_generic_isr */
void booke_generic_isr(uint32_t intr_entry);
void booke_generic_isr(uint32_t intr_entry)
{
	static int print_limit = 3;

	switch(intr_entry)
	{
	case(CRITICAL_INTR):
		do {} while(1);
	break;
	case(MACHINE_CHECK_INTR):
		do {} while(1);
	break;
	case(DATA_STORAGE_INTR):
		do {} while(1);
	break;
	case(INSTRUCTION_STORAGE_INTR):
		do {} while(1);
	break;
	case(EXTERNAL_INTR):
		do {} while(1);
	break;
	case(ALIGNMENT_INTR):
		do {} while(1);
	break;
	case(PROGRAM_INTR):
		if (check_exceptions() == 0)
			do {} while(1); /* PASSED: Exceptions test */
		else
			do {} while(1); /* FAILED: Exceptions test */
	break;
	case(SYSTEM_CALL_INTR):
		do {} while(1);
	break;
	case(DEBUG_INTR):
		do {} while(1);
	break;
	case(EFPU_DATA_INTR):
		do {} while(1);
	break;
	case(EFPU_ROUND_INTR):
		do {} while(1);
	break;
	case(EFPU_NA_INTR):
		do {} while(1);
	break;
	case(PERF_MONITOR_INTR):
		do {} while(1);
	break;
	default:
		do {} while(1);
		break;
	}
}


static int func_in_iram()
{
	int err = 0;

	err = -1;

	return err;
}


/* Call it only if you want an interrupt */
void exceptions_init();
void exceptions_init()
{
	booke_generic_irq_init();
}

int exceptions_test();
int exceptions_test()
{
	int err = 0;
	uint8_t *iram_ptr = (uint8_t *)((void *)func_in_iram);

	err = check_exceptions();
	if (err == 0) return 2;

	/* Write to IRAM */
	iram_ptr[0] = 0xff;
	iram_ptr[1] = 0xff;
	if ((iram_ptr[1] != 0xff) || (iram_ptr[1] != 0xff))
		return -EINVAL;

	/* Trigger exception */
	err = func_in_iram();

	/* Should not get here */
	err = check_exceptions();
	if (err != 0) return 4;

	return -EINVAL;
}
#endif /* TEST_EXCEPTIONS == ON */
