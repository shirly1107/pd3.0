/*
 * Copyright 2017 NXP
 */

/**
@File          dcache_test.h

@Description   Internal header file for dcache test routines
*//***************************************************************************/
#ifndef __DCACHE_TEST_H
#define __DCACHE_TEST_H

#include "fsl_types.h"
#include "fsl_errors.h"

void fetch(void *ptr, uint32_t size);
void flush(void *ptr, uint32_t size);

#endif /* __DCACHE_TEST_H */

