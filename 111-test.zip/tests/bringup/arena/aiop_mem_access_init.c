/*
 * Copyright 2017 NXP
 */

#include "fsl_errors.h"
#include "fsl_io.h"
#include "platform.h"
#include "ls2085_mc/fsl_platform.h"
#include "fsl_smp.h"
#include "drivers/fsl_mc.h"
#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_soc.h"

/*****************************************************************************/
int mem_standalone_init()
{
	//TODO ATU Configuration
	return 0;
}

