/*
 * Copyright 2017 NXP
 */


#ifndef __BRINGUP_TESTS_H
#define __BRINGUP_TESTS_H

#define ON  1
#define OFF 0

// the bring-up tests should be executed in this order.
#define TEST_MEM_ACCESS              ON
#define TEST_CONSOLE_PRINT           OFF
#define TEST_HW_SEM                  OFF
#define TEST_MPIC                    OFF
#define TEST_EXCEPTIONS              OFF
#define TEST_MPU                     OFF
#define TEST_EDMA                    OFF
#define TEST_DCACHE                  OFF


// the TEST_SPINLOCK works if the SYS_SMP_SUPPORT is defined in build_flags.h
#define TEST_SPINLOCK                OFF

// tests below are not updated yet
#define TEST_AIOP                    OFF
#define AIOP_TEST_MEM_ACCESS         OFF
#define TEST_SHARED_MEMORY_ACCESS    OFF
#define TEST_LED                     OFF

#if (TEST_MEM_ACCESS == ON)
/* memory access test */
int mem_standalone_init();
int mem_test();
#endif /* TEST_MEM_ACCESS */

#if (TEST_HW_SEM == ON)
int hw_sem_standalone_init();
int hw_sem_test();
#endif /* TEST_HW_SEM */

#if (TEST_SPINLOCK == ON)
int spinlock_standalone_init();
int spinlock_test();
#endif /* TEST_SPINLOCK */

#if (TEST_CONSOLE_PRINT == ON)
int console_print_init();
int console_print_test();
#endif /* TEST_CONSOLE_PRINT */

#if (TEST_MPIC == ON)
int mpic_standalone_init();
int mpic_test();
#endif /* TEST_MPIC */

#if (TEST_MPU == ON)
int mpu_standalone_init();
int mpu_test();
#endif /* TEST_MPU */

#if (TEST_AIOP == ON)
#if (AIOP_TEST_MEM_ACCESS == ON)
int mem_standalone_init();
#endif /* AIOP_TEST_MEM_ACCESS */

//TODO all AIOP initiations should be here

#endif /* TEST_AIOP */

#if (TEST_DCACHE == ON)
int edma_test_init();
int dcache_init();
int dcache_test();
#endif /* TEST_DCACHE */

#if (TEST_SHARED_MEMORY_ACCESS == ON)
int shared_memory_access_init();
int shared_memory_access_test();
#endif /* TEST_SHARED_MEMORY_ACCESS */

#if (TEST_EDMA == ON)
int edma_test_init();
int edma_test();
#endif /* TEST_EDMA */

#if (TEST_EXCEPTIONS == ON)
void exceptions_init();
int exceptions_test();
#endif

#endif /* __BRINGUP_TESTS_H */
