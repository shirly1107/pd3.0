/*
 * Copyright 2017 NXP
 */

#ifndef _EDMA_TEST_H
#define _EDMA_TEST_H

int edma_test_init();
int edma_test();
void restore_access_window();
void config_dp_ddr_window();
void config_system_ddr_window();

extern struct edma_queue g_queue_0_core0;
extern struct edma_queue g_queue_0_core1;

#endif

