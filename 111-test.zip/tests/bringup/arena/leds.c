/*
 * Copyright 2017 NXP
 */

/**
@File          leds.c

@Description   file to turn on leds from MC.

@Cautions      Lock should be use for safety in MC full boot when changing the window.

*//***************************************************************************/

#include "fsl_types.h"
#include "leds.h"
#include "fsl_dpmng_mc.h"
#include "fsl_sys.h"



/**
 * @Function turn_led_configuration;
 */
void turn_led_configuration(void)
{
	uint32_t vaddr;
	struct dpmng_amq amq;
#ifdef BRINGUP_TEST
	amq.icid = 0;
	amq.pl = 1;
	amq.va = 0;
	amq.bmt = 1;
	amq.bdi = 1;
#else
	dpmng_get_amq(&amq);
#endif


	vaddr = (uint32_t )dpmng_mc_set_soc_window(
		FPGA_PHYS_ADDR, &amq);

	TURN_ON_LEDS_CTRL(vaddr);

}

/**
 * @Function turn_led_on;
 * @param[in] led_num bitmask to choose which leds to turn on (8 bits = 8 leds)
 */
void turn_led_on(uint8_t led_num)
{

	uint32_t vaddr = 0;
	struct dpmng_amq amq;
#ifdef BRINGUP_TEST
	amq.icid = 0;
	amq.pl = 1;
	amq.va = 0;
	amq.bmt = 1;
	amq.bdi = 1;
#else
	dpmng_get_amq(&amq);
#endif


	vaddr = (uint32_t)dpmng_mc_set_soc_window(
		FPGA_PHYS_ADDR, &amq);

	if(led_num | 0x01)
		SWITCH_LED_1(vaddr);
	if(led_num | 0x02)
		SWITCH_LED_2(vaddr);
	if(led_num | 0x04)
		SWITCH_LED_3(vaddr);
	if(led_num | 0x08)
		SWITCH_LED_4(vaddr);
	if(led_num | 0x10)
		SWITCH_LED_5(vaddr);
	if(led_num | 0x20)
		SWITCH_LED_6(vaddr);
	if(led_num | 0x40)
		SWITCH_LED_7(vaddr);
	if(led_num | 0x80)
		SWITCH_LED_8(vaddr);


}



