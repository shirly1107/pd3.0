/*
 * Copyright 2017 NXP
 */

#include "bringup_tests.h"
#include "fsl_errors.h"
#include "fsl_smp.h"
#include "fsl_errors.h"
#include "hw_sem.h"
#include "fsl_dbg.h"

/*****************************************************************************/
int hw_sem_standalone_init();
int hw_sem_test();

/*****************************************************************************/
int hw_sem_standalone_init()
{
	if(sys_is_master_core()) {
		hw_sem_init((void*)0x21018000);
	}
	return 0;
}

/*****************************************************************************/
int hw_sem_test()
{
	int i;

 	for (i=0; i < NUMBER_OF_HW_SEMAPHORES; i++) {
		uint8_t sem_val = (uint8_t) (i + 1);
 		uint8_t sem_val_2 = sem_val + 1;

 		hw_sem_release(i);
 		ASSERT_COND_LIGHT(hw_sem_get_val(i) == 0);

 		hw_sem_try_take(i, sem_val);
 		ASSERT_COND_LIGHT(hw_sem_get_val(i) == sem_val);

 		hw_sem_try_take(i, sem_val_2);
 		ASSERT_COND_LIGHT(hw_sem_get_val(i) == sem_val);

 		hw_sem_release(i);
 		ASSERT_COND_LIGHT(hw_sem_get_val(i) == 0);

 		hw_sem_try_take(i, sem_val);
 		ASSERT_COND_LIGHT(hw_sem_get_val(i) == sem_val);
 	}
	return 0;
}
