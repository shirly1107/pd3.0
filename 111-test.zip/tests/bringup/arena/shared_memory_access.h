/*
 * Copyright 2017 NXP
 */

/**
@File          shared_memory_access_test.h

@Description   Internal header file for shared memory access test routines
*//***************************************************************************/
#ifndef __SHARED_MEMORY_ACCESS_TEST_H
#define __SHARED_MEMORY_ACCESS_TEST_H

#include "fsl_types.h"
#include "fsl_errors.h"

void fetch(void *ptr, uint32_t size);
void flush(void *ptr, uint32_t size);

#endif /* __SHARED_MEMORY_ACCESS_TEST_H */

