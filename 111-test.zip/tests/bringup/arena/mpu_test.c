/*
 * Copyright 2017 NXP
 */

#include "bringup_tests.h"
#include "mpu.h"

#include "fsl_errors.h"

/*****************************************************************************/
int mpu_standalone_init();
int mpu_test();
/*****************************************************************************/
int mpu_standalone_init()
{
	//TODO
	
	return 0;
}

/*****************************************************************************/
int mpu_test() 
{
	//TODO
	
    return 0;
}
