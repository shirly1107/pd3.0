/*
 * Copyright 2017 NXP
 */


#include "fsl_types.h"
#include "fsl_errors.h"
#include "shared_memory_access.h"
#include "fsl_core_booke_regs.h"
#include "fsl_core_booke.h"
#include "fsl_io.h"
#include "fsl_sys.h"
#include "drivers/fsl_edma.h"
#include "edma_init.h"
#include "fsl_string.h"
#include "fsl_spinlock.h"
#include "fsl_smp.h"
#include "edma.h"



static uint8_t buffer_A[L1_CACHE_LINE_SIZE];
int shared_memory_access_init();
int shared_memory_access_test();


/*****************************************************************************/
int shared_memory_access_init()
{
	booke_dcache_enable();
	if(sys_is_master_core())
	{
		fsl_print("Initializing buffer\n");
		fsl_print("The test mast work in multi-core environment\n");
		memset(&buffer_A[0], 0x15, L1_CACHE_LINE_SIZE);
		fsl_print("Buffer A: 0x%x \n",(uint32_t)buffer_A[0]);
	}
	sys_barrier();
	return 0;
}


/*****************************************************************************/
int shared_memory_access_test()
{
	uint32_t *ptr = (void *) &buffer_A[0];
	if(!sys_is_master_core())/*core 1 reads the shared memory*/
	{
		fsl_print("should see ptr: 0x15151515\n");
		fsl_print("ptr: 0x%x\n", (uint32_t)*ptr);
	}
	sys_barrier();
	if(sys_is_master_core())/*core 0 write to the ptr;*/
	{
		*ptr = 0x77777777;
		flush((void *)ptr,32);
	}
	sys_barrier();
	if(!sys_is_master_core())/*core 1 reads the shared memory again before fetch(after core 0 updated it)*/
	{
		fsl_print("should see ptr: 0x15151515\n");
		fsl_print("ptr: 0x%x\n", (uint32_t)*ptr);
		fetch((void *)ptr, L1_CACHE_LINE_SIZE);
	}
	sys_barrier();
	if(!sys_is_master_core())
	{
		fsl_print("should see ptr: 0x77777777\n");
		fsl_print("ptr: 0x%x\n", (uint32_t)*ptr);
	}

	return 0;
}


static void fetch(void *ptr, uint32_t size)
{
	uint32_t cache_size = 0;
	uint32_t addr = (uint32_t)ptr;

	ASSERT_COND_LIGHT(size != 0);
	while(cache_size <= size)
	{
		l1dcache_block_invalidate(addr);
		addr += L1_CACHE_LINE_SIZE;
		cache_size += L1_CACHE_LINE_SIZE;
	}

}

/*****************************************************************************/
static void flush(void *ptr, uint32_t size)
{
	uint32_t cache_size = 0;
	uint32_t addr = (uint32_t)ptr;
	volatile uint64_t chase_read;
	int i;

	ASSERT_COND_LIGHT(size != 0);
	while(cache_size <= size)
	{
		/*The cache is right through so the call to flush is
		 * just for future support */
		/*l1dcache_block_flush(addr);//This call is not supported on simulator*/
		l1dcache_block_invalidate(addr);
		/*read in chunks of 8 bytes*/
		for(i = 0; i < L1_CACHE_LINE_SIZE && cache_size <= size;
			i += sizeof(uint64_t),
			addr += sizeof(uint64_t),
			cache_size += sizeof(uint64_t))
		{
			chase_read = (*(uint64_t *)addr);
			core_memory_barrier();
			core_instruction_sync();
			UNUSED(chase_read);
		}
	}
	core_instruction_sync();
}


