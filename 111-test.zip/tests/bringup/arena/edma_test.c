/*
 * Copyright 2017 NXP
 */

#include "fsl_types.h"
#include "drivers/fsl_edma.h"
#include "edma.h"
#include "fsl_malloc.h"
#include "fsl_errors.h"
#include "fsl_endian.h"
#include "common/fsl_string.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "drivers/fsl_edma.h"
#include "fsl_sl_dbg.h"
#include "fsl_platform.h"
#include "edma_test.h"


#define TIMEOUT_ATTEMPTS 1000000

#ifndef  ON
#define  ON 1
#endif
#ifndef OFF
#define OFF 0
#endif

/* For bring-up tests snooping is disabled to exclude cache update
 * In real code the snooping is enabled by default */
#define EDMA_SNOOP ON

/* The same ICID for both cores to access internal EDMA structures*/
#define CORE_ICID  0xA

#define  MULTI_CORE 0


/*External functions and objects */
struct edma_queue g_queue_0_core0;
struct edma_queue g_queue_0_core1;


static uint32_t get_command_queue_addr(uint32_t block_num, uint32_t queue);

static uint32_t get_status_queue_addr(uint32_t block_num, uint32_t queue);

static int edma_reg_init(struct  edma_priviledged_reg * priviledged_reg,
		struct edma_manage_reg *manage_reg);

static int block_reg_init(struct status_queue_reg* sq_regs,
		           struct global_queue_reg *cq_global_regs,
		           struct edma_block *p_block,
		           uint32_t block_id);


static int queue_reg_init(struct command_queue_reg *cq_regs,
		            const struct edma_queue *p_queue);

static  void cd_set_addr_low(struct edma_command_descriptor* cd,
		                     uint32_t address);

static uint32_t cd_get_addr_low(struct edma_command_descriptor* cd);

static void cd_set_ser_bit(struct edma_command_descriptor* cd,
        					uint32_t ser);

static void cd_set_format(struct edma_command_descriptor* cd,
        					uint32_t format);

static void cd_set_icid(struct edma_command_descriptor* cd,
		                uint16_t icid);

static void cd_set_IA_bit(struct edma_command_descriptor* cd,
						uint32_t IA);

static uint8_t cd_get_status(struct edma_command_descriptor* cd);

static void csgc_set_final_bit(struct edma_compound_sg_command* csgc,
		                           uint32_t value);


static void csgc_set_extension_bit(struct edma_compound_sg_command* csgc,
		                           uint32_t value);

static void csgc_set_length(struct edma_compound_sg_command* csgc,
		                     uint32_t address);

static void csgc_set_low_address(struct edma_compound_sg_command* csgc,
		                         uint32_t address);
static void csgc_set_high_address(struct edma_compound_sg_command* csgc,
		                         uint32_t address);

static void sdb_set_internal_address(
		                  struct edma_source_descr_buffer *sdf,
		                  uint32_t value);

static void ddb_set_internal_address(
		                  struct edma_destination_descr_buffer *ddf,
		                  uint32_t value);

static void set_transfer_param(struct edma_command_descriptor *cd,
		                       const  struct edma_transfer *params,
		                       uint32_t queue_id);

static void set_enable_queue(struct edma_queue* queue,uint32_t enable);

static void set_enable_sq(struct edma_block* block,uint32_t enable);

static  void set_DMR_DQD(struct  edma_priviledged_reg *priviled_reg,
		                       uint32_t value);
static  uint32_t get_DMR_DQD(struct  edma_priviledged_reg *priviled_reg);
static  uint32_t incr_command_desc(struct edma_command_descriptor** cd,
                       const struct edma_queue *queue);

static void process_transac_status(uint8_t cd_status,
		    enum transac_status *return_status);





static struct edma_block* edma_obj_block_init (uint8_t core_id);
static struct edma_queue* edma_queue_obj_init(struct edma_block* block_handle,
                                   uint32_t block_id);
static int test_edma_dp_ddr2dmem_transac();
static int test_system_ddr2dmem_transac();




static struct edma s_edma;
static struct edma_block s_edma_block0; // for core 0
static struct edma_block s_edma_block1; // for core 1

#define EDMA_DESC_INIT {\
	0/*edma_id*/,2/*num_blocks*/,6/*irq_transaction_err*/,7/*irq_queue_err*/,\
	0x21028000/*paddr*/,UINT_TO_PTR(0x21028000)/*vaddr*/\
}	

static struct edma* edma_obj_init()
{
	struct edma_desc  desc = EDMA_DESC_INIT;

	struct edma *p_edma = &s_edma;
	p_edma->num_blocks = desc.num_blocks;
	p_edma->priviledged_reg = (struct  edma_priviledged_reg*)desc.vaddr;
	p_edma->manage_reg = PTR_MOVE(p_edma->priviledged_reg,
			              sizeof(struct  edma_priviledged_reg));
	if(0 != edma_reg_init(p_edma->priviledged_reg,p_edma->manage_reg))
		return NULL;
	return p_edma;
}

int edma_reg_init(struct  edma_priviledged_reg *priviledged_reg,
		          struct edma_manage_reg *manage_reg)
{
	uint32_t reg_value = ioread32(&priviledged_reg->DMR);
	reg_value |= (1 << 30); /* DMR[DQD] = 1 */
	reg_value |= (1 << 28); /* DMR[SO] = 1 */
	if(EDMA_SNOOP == OFF){
		reg_value |= (1 << 21); /* DMR[SD] = 1, disable snooping for memory data */
		reg_value |= (1 << 20); /* DMR[DSD] = 1, disable snooping for memory descriptor access*/		
	}
	iowrite32(reg_value,&priviledged_reg->DMR);
	/* According to spec., should wait for wait until DSR[DB] = 0 (DMA idle)*/
	do{
		reg_value = ioread32(&priviledged_reg->DSR);
	}
	while(reg_value & (1 << 31)); //  wait until DSR[DB] = 0
	iowrite32(0xCF000000,&manage_reg->DEDR); /* Clear DEDR error */
	iowrite32(0,&manage_reg->DEIER); /* Disable interrupts on error*/
	/* Enable dequeue from the beginning (DMR[DQD] = 0) */
	reg_value = ioread32(&priviledged_reg->DMR);
	reg_value &= ~(0x1 << 30);
	iowrite32(reg_value,&priviledged_reg->DMR);
	return 0;
}

// For core 0
#define BLOCK0_DESC_INIT\
{\
0/*edma_block_id*/,8/*irq*/,8/*num_queues*/,0x2102A000/*paddr*/,\
UINT_TO_PTR(0x2102A000)/*vaddr*/\
}

// For core 1
#define BLOCK1_DESC_INIT\
{\
1/*edma_block_id*/,9/*irq*/,8/*num_queues*/,0x2102B000/*paddr*/,\
UINT_TO_PTR(0x2102B000)/*vaddr*/\
}

#define BLOCK_CFG_INIT\
{\
    &s_edma/* edma handle*/,NUM_ENTRIES_IN_SQ,0/*coalesc_intr_status_threshold*/,SQ_WATER_MARK,\
	MEM_PART_SYSTEM_DDR1_CACHEABLE/*mem_partition_id, not relevant*/,{CORE_ICID/*block_icid*/, 1 /*pl*/, 0 /*va*/, 1 /*bmt*/, 1/*bdi*/} \
}

#define STATUS_QUEUE_SIZE (NUM_ENTRIES_IN_SQ*sizeof(struct edma_command_descriptor))
#define STATUS_QUEUE_ALIGNMENT STATUS_QUEUE_SIZE

static char s_status_queue_memory0[STATUS_QUEUE_ALIGNMENT*2]; 
static char s_status_queue_memory1[STATUS_QUEUE_ALIGNMENT*2];

    
struct edma_block* edma_obj_block_init(uint8_t core_id)
{
	uint32_t tmp_ptr = 0;
	struct edma_block_desc block_desc0 = BLOCK0_DESC_INIT; 
	struct edma_block_desc block_desc1 = BLOCK1_DESC_INIT;
	struct edma_block_cfg  block_cfg = BLOCK_CFG_INIT;	
	struct edma_block* p_edma_block = (core_id == 0 ) ? &s_edma_block0:&s_edma_block1 ;
	struct edma_block_desc *p_block_desc = (core_id == 0 ) ? &block_desc0:&block_desc1;
	p_edma_block->sq_enabled = 0;
	p_edma_block->block_amq = block_cfg.block_amq;
	p_edma_block->num_queues = p_block_desc->num_queues;
	p_edma_block->edma = block_cfg.edma;
	p_edma_block->num_entries_in_status_queue = block_cfg.num_entries_in_status_queue;
	p_edma_block->coalesc_intr_status_threshold =
		block_cfg.coalesc_intr_status_threshold;
	p_edma_block->water_mark_threshold = block_cfg.water_mark_threshold;
	p_edma_block->comman_queue_reg = p_block_desc->vaddr;
	p_edma_block->status_queue_reg =
			      PTR_MOVE(p_block_desc->vaddr,STATUS_QUEUE_OFF);
	p_edma_block->global_queue_reg =
			PTR_MOVE(p_block_desc->vaddr,QUEUE_GLOBAL_REGS);
	// allocate internal status queue structure
	/*
	uint32_t alignment = p_edma_block->num_entries_in_status_queue*
		       sizeof(struct edma_command_descriptor);
		       */
	if(core_id == 0)
		tmp_ptr = ALIGN_UP(s_status_queue_memory0,STATUS_QUEUE_ALIGNMENT);
	else
		tmp_ptr = ALIGN_UP(s_status_queue_memory1,STATUS_QUEUE_ALIGNMENT);
	p_edma_block->sq_command_descr = UINT_TO_PTR(tmp_ptr);
	/*
	p_edma_block->sq_command_descr = (fsl_xmalloc
			      (p_edma_block->num_entries_in_status_queue*
			       sizeof(struct edma_command_descriptor),
			       block_cfg.mem_partition_id,alignment));
			       */
	if(NULL == p_edma_block->sq_command_descr)
		return NULL;
	memset(p_edma_block->sq_command_descr,
			0,
			p_edma_block->num_entries_in_status_queue*
			sizeof(struct edma_command_descriptor));
	if(0 != block_reg_init(p_edma_block->status_queue_reg,
			       p_edma_block->global_queue_reg,
			       p_edma_block,
			       p_block_desc->edma_block_id))
    	return NULL;

	/* Enable status queue that belongs to this block */
	set_enable_sq(p_edma_block,1/*enable*/);
	return p_edma_block;
}

static int block_reg_init(struct status_queue_reg* sq_regs,
		           struct global_queue_reg *cq_global_regs,
		           struct edma_block *p_block,
		           uint32_t block_id)
{
	uint32_t num_entries_in_sq_log_2 = 0, coalescing_intr_log_2 = 0;
	uint32_t reg_value = ioread32(&sq_regs->BmSQMR);
	uint64_t sq_address = 0;
	uint32_t sq_low_address = 0, sq_high_address = 0;
	reg_value &= ~(0x1 << 31); /* BmSQMR[EN] = 0 */
	LOG2((p_block->num_entries_in_status_queue>>6),num_entries_in_sq_log_2);
	reg_value &= ~(0xF<<16); /*  clear BmSQMR[SQ_SIZE] */
	reg_value |= num_entries_in_sq_log_2 << 16;
	reg_value &= ~(0x1 << 30);  /* BmSQMR[DI] = 0 */
	iowrite32(reg_value,&sq_regs->BmSQMR); /* set BmSQMR[SQ_SIZE] */
	/* Attention !!
	 * When descriptors put in external memory (64b address),
	 * the following line should be changed as there is truncation to 32 bit.
	 */
	sq_address = PTR_TO_UINT(&p_block->sq_command_descr[0]);

	sq_high_address = ((uint32_t)(sq_address >> 32)) & 0x1FFFF;
	// sq_low_address should be aligned to 16 bits
	sq_low_address = ((uint32_t)(sq_address))& 0xFFFFFFF0;
	iowrite32(sq_low_address,&sq_regs->BmSQEPAR);
	iowrite32(sq_low_address,&sq_regs->BmSQDPAR);

	iowrite32(sq_high_address,&sq_regs->BmSQEEPAR);
	iowrite32(sq_high_address,&sq_regs->BmSQEDPAR);
	reg_value = ioread32(&sq_regs->BmSQICR);
	if(p_block->coalesc_intr_status_threshold > 0)
		reg_value |= (0x1 << 31);/*BmSQICR[CEN] = 1 */
	else
		reg_value &= ~(0x1 << 31);/*BmSQICR[CEN] = 0 */
	reg_value &= ~(0xF << 16); /* clear BmSQICR[ICST] */
	if(0==p_block->coalesc_intr_status_threshold)
		coalescing_intr_log_2 = 0;
	else
	{
		LOG2(p_block->coalesc_intr_status_threshold,coalescing_intr_log_2);
		coalescing_intr_log_2++;
	}
	reg_value |= coalescing_intr_log_2 << 16;
	iowrite32(reg_value,&sq_regs->BmSQICR); /* Set BmSQICR[ICST] */
	if(block_id == 0)
	{/* privileged core configures CQBnAMQR for both cores */
	    reg_value = ioread32(&cq_global_regs->CQB0AMQR);
	    reg_value |= 0x08000000;/* set CQBnAMQR[IA] = 1 */
	    reg_value &= ~(0x1<<28);
	    reg_value |= (p_block->block_amq.pl&0x1) << 28; /*CQBnAMQR[PL] = 1*/
	    reg_value &= ~(0x1<<29);
	    reg_value |= (p_block->block_amq.bmt &0x1) << 29; /* CQBnAMQR[BMT] = 1 */
	    /* Setting CQBnAMQR[ICID] field */
	    reg_value &= ~(0x7FFF);
	    reg_value |= (p_block->block_amq.icid);
	    iowrite32(reg_value,&cq_global_regs->CQB0AMQR);
	    reg_value = ioread32(&cq_global_regs->CQB1AMQR);
	    reg_value |= 0x08000000;/* set CQBnAMQR[IA] = 1 */
	    reg_value &= ~(0x1<<28);
	    reg_value |= (p_block->block_amq.pl&0x1) << 28;/*CQBnAMQR[PL] = 1*/
	    reg_value &= ~(0x1<<29);
	    reg_value |= (p_block->block_amq.bmt &0x1) << 29;/* CQBnAMQR[BMT] = 1*/
	    /* Setting CQBnAMQR[ICID] field */
	    reg_value &= ~(0x7FFF) ;
	    reg_value |= (p_block->block_amq.icid);
	    iowrite32(reg_value,&cq_global_regs->CQB1AMQR);
	}
	return 0;
}




#define EDMA_HIGH_PRIORITY_QUEUE_CFG_INIT\
{\
0/*priority_queue, 0 - highest*/,NUM_ENTRIES_IN_CQ,MEM_PART_SYSTEM_DDR1_CACHEABLE/*Not relevant*/\
}

#define EDMA_LOW_PRIORITY_QUEUE_CFG_INIT\
{\
7/*priority_queue, 0 - highest, 7 -LOWEST*/,NUM_ENTRIES_IN_CQ,MEM_PART_SYSTEM_DDR1_CACHEABLE/*Nor relevant*/\
}

#define COMMAND_DESC_SIZE NUM_ENTRIES_IN_CQ*sizeof(struct edma_command_descriptor)
#define COMMAND_DESC_ALIGNMENT COMMAND_DESC_SIZE

static char s_command_desc_memory_core0[COMMAND_DESC_ALIGNMENT*2];
static char s_command_desc_memory_core1[COMMAND_DESC_ALIGNMENT*2];

#define COMPOUND_COMMAND_SIZE NUM_ENTRIES_IN_CQ*sizeof(struct edma_compound_command)
/* compound commands structure must be alighned to a power of 2, choosing  8192 */
#define COMPOUND_COMMAND_ALIGNMENT  (2 << 13)

static char s_compound_command_memory_core0[2*COMPOUND_COMMAND_ALIGNMENT];
static char s_compound_command_memory_core1[2*COMPOUND_COMMAND_ALIGNMENT];

#define DESC_BUFFERS_SIZE NUM_ENTRIES_IN_CQ*sizeof(struct edma_descriptor_buffers)
#define DESC_BUFFERS_ALIGNMENT DESC_BUFFERS_SIZE

static char s_desc_buffers_memory_core0[2*DESC_BUFFERS_ALIGNMENT];
static char s_desc_buffers_memory_core1[2*DESC_BUFFERS_ALIGNMENT];

struct edma_queue* edma_queue_obj_init(struct edma_block* block_handle,
                                   uint32_t block_id)
{
	struct edma_queue_cfg queue_cfg = EDMA_HIGH_PRIORITY_QUEUE_CFG_INIT;
	uint32_t queue_id = 0;
	struct edma_queue_cfg *cfg = &queue_cfg;
	struct edma_queue* p_edma_queue = NULL;
	uint32_t temp_ptr = 0;
	
	if(block_id == 0)
		p_edma_queue = &g_queue_0_core0;
	else
		p_edma_queue = &g_queue_0_core1;
	uint32_t i = 0;
	uint16_t block_icid = 0;
	
	p_edma_queue->block = block_handle;
	p_edma_queue->block_id = block_id;
	p_edma_queue->queue_id = queue_id;
	p_edma_queue->queue_size = cfg->size_queue;
	p_edma_queue->command_queue_regs = &block_handle->comman_queue_reg[queue_id];
	/* allocate memory for command descriptor */	
	if(block_id == 0)		
		temp_ptr = ALIGN_UP(&s_command_desc_memory_core0,COMMAND_DESC_ALIGNMENT);
	else
		temp_ptr = ALIGN_UP(&s_command_desc_memory_core1,COMMAND_DESC_ALIGNMENT);
	p_edma_queue->command_descriptors = UINT_TO_PTR(temp_ptr);
	memset(p_edma_queue->command_descriptors,
		  0,
		  p_edma_queue->queue_size*sizeof(struct edma_command_descriptor));
	/* allocate and reset memory for compound commands */
	if(block_id == 0)		
		temp_ptr = ALIGN_UP(&s_compound_command_memory_core0,COMPOUND_COMMAND_ALIGNMENT);
	else
		temp_ptr = ALIGN_UP(&s_compound_command_memory_core1,COMPOUND_COMMAND_ALIGNMENT);
	//alignment = p_edma_queue->queue_size*sizeof(struct edma_compound_command);
	//NEXT_POWER_OF_2(alignment, _next_pow);
	p_edma_queue->compound_commands = UINT_TO_PTR(temp_ptr);
	memset(p_edma_queue->compound_commands,
			  0,
			  p_edma_queue->queue_size*sizeof(struct edma_compound_command));
	/* allocate memory for descriptor buffer */
	
	//alignment = p_edma_queue->queue_size*sizeof(struct edma_descriptor_buffers);
	if(block_id == 0)		
		temp_ptr = ALIGN_UP(s_desc_buffers_memory_core0,DESC_BUFFERS_ALIGNMENT);
	else
		temp_ptr = ALIGN_UP(s_desc_buffers_memory_core1,DESC_BUFFERS_ALIGNMENT);
	p_edma_queue->descriptor_buffers = UINT_TO_PTR(temp_ptr);
	memset(p_edma_queue->descriptor_buffers,
			  0,
			  p_edma_queue->queue_size*sizeof(struct edma_descriptor_buffers));
	if(block_id == 0){
		block_icid = (uint16_t)
			     (ioread32(&block_handle->global_queue_reg->CQB0AMQR) & 0x7FFF);
	}
	else{
		/* For block 1, take icid from block[0]->global_queue_reg->CQB1AMQR */
		struct edma_block *block0 = &block_handle->edma->edma_blocks_arr[0];
		block_icid = (uint16_t)
				 (ioread32(&block0->global_queue_reg->CQB1AMQR) & 0x7FFF);
	}
	for(i = 0; i < p_edma_queue->queue_size; i++)
	{
		/*set CD[ADDR] field to point to the corresponding compound command */
		cd_set_addr_low(&p_edma_queue->command_descriptors[i],
				PTR_TO_UINT(&p_edma_queue->compound_commands[i]));
		/* set Descriptor Addr to point to Descriptor Buffers*/
		csgc_set_low_address(
						     &(p_edma_queue->compound_commands[i].descr_command),
						     PTR_TO_UINT(&p_edma_queue->descriptor_buffers[i]));
		/*set CD[SER] = 1 */
		cd_set_ser_bit(&p_edma_queue->command_descriptors[i],
				       1);
		/* Set CD[FORMAT] = 0x1 */
		cd_set_format(&p_edma_queue->command_descriptors[i],1);

		/* Set CD[IA] = 0x1 Internal Address*/
		cd_set_IA_bit(&p_edma_queue->command_descriptors[i],1);
		/* Populate value of CQBnAMQR[ICID] to CD entries */
		cd_set_icid(&p_edma_queue->command_descriptors[i],block_icid);

		csgc_set_extension_bit
		    (&(p_edma_queue->compound_commands[i].descr_command),
		    0);
		csgc_set_final_bit(
				    &(p_edma_queue->compound_commands[i].descr_command),
				    0);
		csgc_set_length(
				&(p_edma_queue->compound_commands[i].descr_command),
				32);
		csgc_set_extension_bit
				    (&(p_edma_queue->compound_commands[i].src_command),
				    0);
		csgc_set_final_bit(
				    &(p_edma_queue->compound_commands[i].src_command),
				     0);
		csgc_set_extension_bit
				    (&(p_edma_queue->compound_commands[i].dst_command),
					0);
		csgc_set_final_bit(
					&(p_edma_queue->compound_commands[i].dst_command),
					1);
	}
	block_handle->queues[queue_id] = p_edma_queue;
	p_edma_queue->next_available = NULL;
	p_edma_queue->first_pending = 0;
	p_edma_queue->enabled = 0;
	if(0 != queue_reg_init(p_edma_queue->command_queue_regs,p_edma_queue))
		return NULL;
	/* Enable queue from the beginning */
	set_enable_queue(p_edma_queue,1/*enable*/);
	return p_edma_queue;
}

static int queue_reg_init(struct command_queue_reg *cq_regs,
		            const struct edma_queue *p_queue)
{
	uint32_t num_entries_in_cq_log_2 = 0;
	uint32_t reg_value = 0;
	uint64_t addr = 0;
	uint32_t low_addr = 0, high_addr = 0;
	LOG2((p_queue->queue_size>>6),num_entries_in_cq_log_2);
	reg_value = ioread32(&cq_regs->BmCQnMR);
	reg_value &= ~(0x1 << 31); /*BmCQnMR[EN] = 0*/
	reg_value &= ~(0xF<<16); /*reset BmCQnMR[CQ_SIZE] */
	reg_value |= (num_entries_in_cq_log_2 << 16);
	reg_value &= ~(0x1 << 30); /*BmCQnMR[EI] = 0*/
	iowrite32(reg_value,&cq_regs->BmCQnMR);
	/* Attention !!
	 * When descriptors put in external memory (64b address),
	 * the following line should be changed as there is truncation to 32 bit.
	 */
	addr = PTR_TO_UINT(&p_queue->command_descriptors[0]);

	// low_addr is aligned to 16 bits
	low_addr = (uint32_t)addr & 0xFFFFFFF0;
	high_addr = ((uint32_t)(addr >> 32)) & 0x1FFFF;
	iowrite32(low_addr,&cq_regs->BmCQnDPAR); /* set BmCQnDPAR */
	iowrite32(low_addr,&cq_regs->BmCQnEPAR); /* set BmCQnEPAR */

	iowrite32(high_addr,&cq_regs->BmCQnEDPAR); /* set BmCQnEDPAR */
	iowrite32(high_addr,&cq_regs->BmCQnEEPAR); /* set BmCQnEEPAR */
	return 0;
}

static int check_and_clear_transaction_error(struct edma_block *block)
{
    uint32_t reg_value = ioread32(&block->global_queue_reg->CQEDR);
    if(reg_value & 0x80000001){
	pr_debug("edma: CQEDR = 0x%x\n",reg_value);
	reg_value = ioread32(&block->global_queue_reg->CQECEAR);
        pr_debug("edma: CQECEAR = 0x%x\n",reg_value);
	reg_value = ioread32(&block->global_queue_reg->CQECAR);
	pr_debug("edma: CQECAR = 0x%x\n",reg_value);
        // clear transaction error
	reg_value |= 0x80000001;
	iowrite32(reg_value,&block->global_queue_reg->CQEDR);
	return -EIO;
    }
    return 0;
}

static void print_CQ_SQ_registers(const struct edma_queue* queue)
{
    uint32_t reg_value = 0;
    reg_value = ioread32(&queue->block->status_queue_reg->BmSQEPAR);
    pr_debug("edma: BmSQEPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->block->status_queue_reg->BmSQEEPAR);
    pr_debug("edma: BmSQEEPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->block->status_queue_reg->BmSQDPAR);
    pr_debug("edma: BmSQDPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->block->status_queue_reg->BmSQEDPAR);
    pr_debug("edma: BmSQEDPAR = 0x%x\n",reg_value);

    reg_value = ioread32(&queue->command_queue_regs->BmCQnEDPAR);
    pr_debug("edma: BmCQnEDPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->command_queue_regs->BmCQnDPAR);
    pr_debug("edma: BmCQnDPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->command_queue_regs->BmCQnEEPAR);
    pr_debug("edma: BmCQnEEPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->command_queue_regs->BmCQnEPAR);
    pr_debug("edma: BmCQnEPAR = 0x%x\n",reg_value);
}

static int  check_and_clear_errors_DEDR(struct edma_queue* queue)
{
    uint32_t DEDR_value = ioread32(&queue->block->edma->manage_reg->DEDR);
    uint32_t DECBR_value = ioread32(&queue->block->edma->manage_reg->DECBR);
    if(DEDR_value & 0xBF000000){
        pr_debug("edma: DEDR = 0x%x\n",DEDR_value);
        pr_debug("edma: DECBR = 0x%x\n",DECBR_value);
        iowrite32(0xBF000000,&queue->block->edma->manage_reg->DEDR);
        return -EIO;
    }
    return 0;
}

static uint32_t get_command_queue_addr(uint32_t block_num, uint32_t queue)
{
	return COMMAND_QUEUE0_OFF + (block_num*BLOCK_REGS_SIZE) +
		  (queue*QUEUE_REGS_SIZE);
}

static uint32_t get_status_queue_addr(uint32_t block_num, uint32_t queue)
{
	return STATUS_QUEUE_OFF + (block_num*BLOCK_REGS_SIZE) +
		  (queue*QUEUE_REGS_SIZE);
}

static void cd_set_addr_low(struct edma_command_descriptor* cd,
                             uint32_t value)
{
	iowrite32be(value,&cd->desc2);
}

static uint32_t cd_get_addr_low(struct edma_command_descriptor* cd)
{
	return ioread32be(&cd->desc2);
}


static void cd_set_ser_bit(struct edma_command_descriptor* cd,
        					uint32_t ser)
{
	uint32_t desc4 = ioread32be(&cd->desc4);
	if(ser)
		desc4 |= (1 << 30);
	else
		/* reset ser bit */
		desc4  &= ~(1 << 30);
	iowrite32be(desc4,&cd->desc4);
}

static void cd_set_icid(struct edma_command_descriptor* cd,
		                uint16_t icid)
{
	uint32_t desc4 = ioread32be(&cd->desc4);
	desc4 &= ~(0x7FFF << 8);
	desc4 |= ((icid & 0x7FFF) << 8);
	iowrite32be(desc4,&cd->desc4);
}

static void cd_set_format(struct edma_command_descriptor* cd,
        					uint32_t format)
{
	uint32_t desc3 = ioread32be(&cd->desc3);
	desc3 &= ~(0x7 << 29);
	desc3 |= (format &0x7) << 29;
	iowrite32be(desc3,&cd->desc3);
}

void cd_set_IA_bit(struct edma_command_descriptor* cd,
						uint32_t IA)
{
	uint32_t desc4 = ioread32be(&cd->desc4);
	if(IA)
		desc4 |= (1 << 24);
	else
		desc4 &= ~(1 << 24); /* reset CD[IA] */
	iowrite32be(desc4,&cd->desc4);
}

static void cd_set_queue(struct edma_command_descriptor* cd,
        					uint32_t queue_id)
{
	uint32_t desc1 = ioread32be(&cd->desc1);
	desc1 &=  ~(0x7 << 24);
	desc1 |= ((queue_id&0x7) << 24);
	iowrite32be(desc1,&cd->desc1);
}

static uint8_t cd_get_status(struct edma_command_descriptor* cd)
{
	uint32_t desc4 = ioread32be(&cd->desc4);
	return (uint8_t)(desc4 & 0xFF);
}

static void csgc_set_extension_bit(struct edma_compound_sg_command* csgc,
		                           uint32_t value)
{
	uint32_t desc3 = ioread32be(&csgc->desc3);
	if(value){
		desc3 |= 1 << 31;
	}
	else
		desc3  &= ~(1 << 31);
	iowrite32be(desc3,&csgc->desc3);
}

static void csgc_set_final_bit(struct edma_compound_sg_command* csgc,
		                           uint32_t value)
{
	uint32_t desc3 = ioread32be(&csgc->desc3);
	if(value){
		desc3 |= (1 << 30);
	}
	else
		desc3 &= ~( 1 << 30);
	iowrite32be(desc3,&csgc->desc3);
}

static void csgc_set_length(struct edma_compound_sg_command* csgc,
		                     uint32_t address)
{
	uint32_t desc3 = ioread32be(&csgc->desc3);
	// reset length field
	desc3 &= (0xC0000000);
	// set address
	desc3 |=  ((address) & 0x3FFFFFFF);
	iowrite32be(desc3,&csgc->desc3);
}

static void csgc_set_low_address(struct edma_compound_sg_command* csgc,
		                         uint32_t address)
{
	iowrite32be(address,&csgc->desc2);
}

static uint32_t csgc_get_low_address(struct edma_compound_sg_command* csgc)
{
	return ioread32be(&csgc->desc2);
}

static void csgc_set_high_address(struct edma_compound_sg_command* csgc,
		                         uint32_t address)
{
	uint32_t desc1 = ioread32be(&csgc->desc1);
	desc1 &= ~(0x1FFFF);
	desc1 |= (address &(0x1FFFF));
	iowrite32be(desc1,&csgc->desc1);
}

/*
 * Source Descriptor Buffer
 */
static void sdb_set_internal_address(
		                  struct edma_source_descr_buffer *sdf,
		                  uint32_t value)
{
	uint32_t desc4 = ioread32be(&sdf->desc4);
	if(value){
		desc4 |= (0x1) << 28;
	}
	else
		desc4 &= ~(1 << 28);
	iowrite32be(desc4,&sdf->desc4);
}

static void sdb_set_icid(struct edma_source_descr_buffer *sdf,
		                 uint16_t icid)
{
	uint32_t desc4 = ioread32be(&sdf->desc4);
	desc4 &= ~(0x7FFF );
	desc4 |=  icid & 0x7FFF;
	iowrite32be(desc4,&sdf->desc4);
}

static void sdb_set_PL(struct edma_source_descr_buffer *sdf,
		                 uint32_t PL)
{
	uint32_t desc4 = ioread32be(&sdf->desc4);
	if(PL){
		desc4 |= (0x1) << 29;
	}
	else
		desc4 &= ~(1 << 29);
	iowrite32be(desc4,&sdf->desc4);
}

static void sdb_set_BMT(struct edma_source_descr_buffer *sdf,
		                 uint32_t BMT)
{
	uint32_t desc4 = ioread32be(&sdf->desc4);
	if(BMT){
		desc4 |= (0x1) << 30;
	}
	else
		desc4 &= ~(1 << 30);
	iowrite32be(desc4,&sdf->desc4);
}

static void sdb_set_VA(struct edma_source_descr_buffer *sdf,
		                 uint32_t VA)
{
	uint32_t desc4 = ioread32be(&sdf->desc4);
	if(VA){
		desc4 |= (0x1) << 31;
	}
	else
		desc4 &= ~(1 << 31);
	iowrite32be(desc4,&sdf->desc4);
}

static void sdb_set_sde(struct edma_source_descr_buffer *sdf,
		                 uint16_t sde)
{
	uint32_t desc1 = ioread32be(&sdf->desc1);
	if(sde){
		desc1 |= (0x1) << 30;
	}
	else
		desc1 &= ~(1 << 30);
	iowrite32be(desc1,&sdf->desc1);
}

/*
 * Destination Descriptor Buffer
 */
static void ddb_set_internal_address(
		                  struct edma_destination_descr_buffer *ddf,
		                  uint32_t value)
{
	uint32_t desc4 = ioread32be(&ddf->desc4);
	if(value){
		desc4 |= (0x1) << 28;
	}
	else
		desc4 &= ~(1 << 28);
	iowrite32be(desc4,&ddf->desc4);
}

static void ddb_set_PL(struct edma_destination_descr_buffer *ddf,
		                  uint32_t PL)
{
	uint32_t desc4 = ioread32be(&ddf->desc4);
	if(PL){
		desc4 |= (0x1) << 29;
	}
	else
		desc4 &= ~(1 << 29);
	iowrite32be(desc4,&ddf->desc4);
}


static void ddb_set_BMT(struct edma_destination_descr_buffer *ddf,
		                  uint32_t BMT)
{

	uint32_t desc4 = ioread32be(&ddf->desc4);
	if(BMT){
		desc4 |= (0x1) << 30;
	}
	else
		desc4 &= ~(1 << 30);
	iowrite32be(desc4,&ddf->desc4);
}

static void ddb_set_VA(struct edma_destination_descr_buffer *ddf,
		                  uint32_t VA)
{
	uint32_t desc4 = ioread32be(&ddf->desc4);
	if(VA){
		desc4 |= (0x1) << 31;
	}
	else
		desc4 &= ~(1 << 31);
	iowrite32be(desc4,&ddf->desc4);
}

static void ddb_set_dde(struct edma_destination_descr_buffer *ddf,
		                  uint32_t dde)
{
	uint32_t desc1 = ioread32be(&ddf->desc1);
	if(dde){
		desc1 |= (0x1) << 30;
	}
	else
		desc1 &= ~(1 << 30);
	iowrite32be(desc1,&ddf->desc1);
}

static void ddb_set_icid(struct edma_destination_descr_buffer *ddf,
		                 uint16_t icid)
{
	uint32_t desc4 = ioread32be(&ddf->desc4);
	desc4 &= ~(0x7FFF );
	desc4 |= icid & 0x7FFF;
	iowrite32be(desc4,&ddf->desc4);
}


static void set_transfer_param(struct edma_command_descriptor *cd,
		                  const  struct edma_transfer *params,
		                   uint32_t queue_id)
{
	struct edma_compound_command* cc = UINT_TO_PTR(cd_get_addr_low(cd));
	struct edma_descriptor_buffers* desc_buffs = NULL;
	struct edma_source_descr_buffer *src_desc_buffer = NULL;
	struct edma_destination_descr_buffer *dst_desc_buffer = NULL;
	desc_buffs = UINT_TO_PTR(csgc_get_low_address(&cc->descr_command));
	src_desc_buffer = &desc_buffs->src_descr_buff;
	dst_desc_buffer  = &desc_buffs->dest_descr_buffer;
	uint32_t src_low_address = (uint32_t)(params->src & 0xFFFFFFFFLL);
	uint32_t src_high_address = (uint32_t)((params->src >> 32) & 0x1FFFFLL);
	uint32_t dst_low_address = (uint32_t)(params->dst & 0xFFFFFFFFLL);
	uint32_t dst_high_address = (uint32_t)((params->dst >> 32) & 0x1FFFFLL);

	cd_set_queue(cd,queue_id);
	csgc_set_length(&cc->src_command,params->byte_count);
	csgc_set_length(&cc->dst_command,params->byte_count);
	csgc_set_low_address(&cc->src_command,src_low_address);
	csgc_set_high_address(&cc->src_command,src_high_address);
	csgc_set_low_address(&cc->dst_command,dst_low_address);
	csgc_set_high_address(&cc->dst_command,dst_high_address);
	/* set IA,PL,BMT bits for source descriptor buffer */
	sdb_set_internal_address(src_desc_buffer,
			                params->flags & EDMA_SRC_ADDR_IA);
	sdb_set_icid(src_desc_buffer,
			    params->src_icid);

	sdb_set_PL(src_desc_buffer,params->flags & EDMA_SRC_ADDR_PL);
	sdb_set_BMT(src_desc_buffer,params->flags & EDMA_SRC_ADDR_BMT);
	sdb_set_VA(src_desc_buffer,params->flags & EDMA_SRC_ADDR_VA);

	sdb_set_sde(src_desc_buffer,1);
	/* set IA,BMT,PL bits for destination descriptor buffer */
	ddb_set_internal_address(dst_desc_buffer,
			               params->flags & EDMA_DEST_ADDR_IA);
	ddb_set_icid(dst_desc_buffer,
			params->dst_icid);
	ddb_set_PL(dst_desc_buffer,params->flags & EDMA_DEST_ADDR_PL );
	ddb_set_BMT(dst_desc_buffer, params->flags & EDMA_DEST_ADDR_BMT);
	ddb_set_VA(dst_desc_buffer, params->flags & EDMA_DEST_ADDR_VA);
	ddb_set_dde(dst_desc_buffer,1);

}

static void set_enable_queue(struct edma_queue* queue,uint32_t enable)
{
	struct command_queue_reg *cq_regs = queue->command_queue_regs;
	uint32_t reg_value = 0;
	reg_value = ioread32(&cq_regs->BmCQnMR);
	if(enable)
		reg_value |= (0x1 << 31);
	else
		reg_value &= ~(0x1 << 31);
	iowrite32(reg_value,&cq_regs->BmCQnMR);
	queue->enabled = enable;
}

static void set_enable_sq(struct edma_block* block,uint32_t enable)
{
	 struct status_queue_reg *sq_reg = block->status_queue_reg;
	 uint32_t reg_value = 0;
	 reg_value = ioread32(&sq_reg->BmSQMR);
		if(enable)
			reg_value |= (0x1 << 31);
		else
			reg_value &= ~(0x1 << 31);
		iowrite32(reg_value,&sq_reg->BmSQMR);
	block->sq_enabled = enable;
}

static  void set_DMR_DQD(struct  edma_priviledged_reg *priviled_reg,
		                       uint32_t value)
{
	uint32_t reg_value = ioread32(&priviled_reg->DMR);
	reg_value &= ~(0x1 << 30);
	reg_value |= (value&0x1) << 30;
	iowrite32(reg_value,&priviled_reg->DMR);
}

static  uint32_t get_DMR_DQD(struct  edma_priviledged_reg *priviled_reg)
{
	uint32_t reg_value = ioread32(&priviled_reg->DMR);
	reg_value &= (0x1 << 30);
	return reg_value >>= 30;
}

static  uint32_t incr_command_desc(struct edma_command_descriptor** cd,
		                                  const struct edma_queue *queue)
{
	if(++(*cd) >= &queue->command_descriptors[queue->queue_size])
	{
		*cd = &queue->command_descriptors[0];
		return 1;
	}
	return 0;
}

static void process_transac_status(uint8_t cd_status,
		    enum transac_status *return_status)
{
    *return_status = cd_status;
}



#define DMEM1_ADDRESS 0x20807fff
#define DP_DDR_PHYS_ADDRESS 0x6000000000
#define MC_DDR_OFFSET 0x80000000
#define VALUE_TO_COPY 0xdeadbeef
#define NUM_BYTES_TO_COPY 0x100

#define MC_C1SAWBALR 0x21010000
#define MC_C1SAWBAHR 0x21010004
#define MC_C2SAWBALR 0x21011000
#define MC_C2SAWBAHR 0x21011004

static uint32_t s_MC_C1SAWBALR;
static uint32_t s_MC_C1SAWBAHR;
static uint32_t s_MC_C2SAWBALR;
static uint32_t s_MC_C2SAWBAHR;

void restore_access_window()
{
    if(sys_is_master_core())
    {
	iowrite32(s_MC_C1SAWBALR, UINT_TO_PTR(MC_C1SAWBALR));
	iowrite32(s_MC_C1SAWBAHR, UINT_TO_PTR(MC_C1SAWBAHR));
    }
    else
    {
	iowrite32(s_MC_C2SAWBALR, UINT_TO_PTR(MC_C2SAWBALR));
	iowrite32(s_MC_C2SAWBAHR, UINT_TO_PTR(MC_C2SAWBAHR));
    }	
}

void config_dp_ddr_window()
{
    if(sys_is_master_core())
    {	
	s_MC_C1SAWBALR = ioread32(UINT_TO_PTR(MC_C1SAWBALR));    
        iowrite32(0x00000000, UINT_TO_PTR(MC_C1SAWBALR));
        s_MC_C1SAWBAHR = ioread32(UINT_TO_PTR(MC_C1SAWBAHR));
        iowrite32(0x00000060,UINT_TO_PTR(MC_C1SAWBAHR)); // DP-DDR
    }
    else
    {
	s_MC_C2SAWBALR = ioread32(UINT_TO_PTR(MC_C2SAWBALR));    
        iowrite32(0x00000000, UINT_TO_PTR(MC_C2SAWBALR));
        s_MC_C2SAWBAHR = ioread32(UINT_TO_PTR(MC_C2SAWBAHR));
        iowrite32(0x00000060,UINT_TO_PTR(MC_C2SAWBAHR)); // DP-DDR
    }
}

void config_system_ddr_window()
{
	if(sys_is_master_core())
	{	
		s_MC_C1SAWBALR = ioread32(UINT_TO_PTR(MC_C1SAWBALR));    
		iowrite32(0x80000000, UINT_TO_PTR(MC_C1SAWBALR));
		s_MC_C1SAWBAHR = ioread32(UINT_TO_PTR(MC_C1SAWBAHR));
		iowrite32(0x00000000,UINT_TO_PTR(MC_C1SAWBAHR)); //SYSTEM-DDR
	}
	else
	{
		s_MC_C2SAWBALR = ioread32(UINT_TO_PTR(MC_C2SAWBALR));    
		iowrite32(0x80000000, UINT_TO_PTR(MC_C2SAWBALR));
		s_MC_C2SAWBAHR = ioread32(UINT_TO_PTR(MC_C2SAWBAHR));
		iowrite32(0x00000000,UINT_TO_PTR(MC_C2SAWBAHR)); //SYSTEM-DDR
	}
}

int test_edma_dp_ddr2dmem_transac()
{
	struct edma_queue *p_queue;
	struct edma_transfer params;
	uint32_t v_source_addr = 0x80000000; 
	uint32_t v_dst_addr = DMEM1_ADDRESS; // memory address in DMEM.
	uint32_t value = 0,block_id = 0,queue_id = 0;
	int rc = 0;
	enum transac_status status; 
	if(!sys_is_master_core())
		block_id = 1;	
	memset(&params,0, sizeof(params));	
	dma_addr_t p_source_addr =  DP_DDR_PHYS_ADDRESS; // DP-DDR external address	
	params.byte_count = NUM_BYTES_TO_COPY;
	params.src_icid = 0x0; // an arbitrary value only for demonstration 
	params.dst_icid = 0x0; // an arbitrary value only for demonstration
	params.flags |= EDMA_DEST_ADDR_IA | EDMA_DEST_ADDR_PL | EDMA_DEST_ADDR_BMT;
	/* Source address 0x6000000000 is physical ( external address), it is such by default */
	/* Retrieve queue_0 from block 0 */ 
	if(block_id == 0)
		p_queue = &g_queue_0_core0;
	else
		p_queue = &g_queue_0_core1;
	// Memory configuration is needed for MC to write into an address in DP-DDR    	
	config_dp_ddr_window(); 
	params.src = p_source_addr; 
	params.dst =  v_dst_addr;
	iowrite32(0,UINT_TO_PTR(v_dst_addr)); // zero memory
	iowrite32(VALUE_TO_COPY,UINT_TO_PTR(v_source_addr));	
	rc = edma_queue_transfer(p_queue,&params,&status);	
	// read back the value and compare expected results
	value = ioread32(UINT_TO_PTR(v_dst_addr));
	if(status != EDMA_NORMAL || value != VALUE_TO_COPY){
	    restore_access_window();
	    return -EIO;
	}
	restore_access_window();
	return 0;
}

int test_system_ddr2dmem_transac()
{
	struct edma_queue *p_queue;
	struct edma_transfer params;
	uint32_t v_source_addr = MC_DDR_OFFSET; 
	uint32_t v_dst_addr = DMEM1_ADDRESS; // memory address in DMEM.
	uint32_t value = 0,block_id = 0,queue_id = 0;
	int rc = 0;
	enum transac_status status;    
	//DEBUG_HALT
	if(!sys_is_master_core())
	    block_id = 1;
	memset(&params,0, sizeof(params));
	params.byte_count = NUM_BYTES_TO_COPY;
	params.src_icid = 0x0; // an arbitrary value only for demonstration 
	params.dst_icid = 0x0; // an arbitrary value only for demonstration
	/* Destination address is an internal address */
	params.flags |= EDMA_DEST_ADDR_IA | EDMA_DEST_ADDR_PL | EDMA_DEST_ADDR_BMT;
	/* Source address 0x80000000 is virtual (internal) */
	params.flags |= EDMA_SRC_ADDR_IA | EDMA_SRC_ADDR_PL | EDMA_SRC_ADDR_BMT;
	/* Retrieve queue_0 from block 0 */ 
	if(block_id == 0)
		p_queue = &g_queue_0_core0;
	else
		p_queue = &g_queue_0_core1;
	// Memory configuration is needed for MC to write into an address in DP-DDR    	
	config_system_ddr_window(); 
	// Going over a loop of 120 eDMA transactions and execute it with step of 0x100.	
	params.src = v_source_addr;
	params.dst =  v_dst_addr;
	iowrite32(0,UINT_TO_PTR(v_dst_addr)); // zero memory
	iowrite32(VALUE_TO_COPY,UINT_TO_PTR(v_source_addr));	
	rc = edma_queue_transfer(p_queue,&params,&status);	
	// read back the value and compare expected results
	value = ioread32(UINT_TO_PTR(v_dst_addr));
	if(status != EDMA_NORMAL || value != VALUE_TO_COPY){
		restore_access_window();
		return -EIO;
	}
	restore_access_window();			
	return 0;
}

int edma_test_init()
{
	edma_obj_init();
	edma_obj_block_init(0/*core_id*/);
	if(MULTI_CORE)
		edma_obj_block_init(1/*core_id*/);
	edma_queue_obj_init(&s_edma_block0,0/*core_id*/);
	if(MULTI_CORE)
		edma_queue_obj_init(&s_edma_block1,1/*core_id*/);
	return 0;
}

int edma_test()
{
	int err = 0;
	if((err = test_edma_dp_ddr2dmem_transac()) != 0)
		return err;
	if((err = test_system_ddr2dmem_transac()) != 0)
		return err;
	return 0;
}
