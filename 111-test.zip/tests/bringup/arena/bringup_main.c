/*
 * Copyright 2017 NXP
 */

#include "fsl_types.h"
#include "common/fsl_stdio.h"
#include "common/fsl_string.h"
#include "fsl_smp.h"
#include "fsl_malloc.h"
#include "dpc.h"
#include "dpl.h"
#include "fsl_dpmng_mc.h"
#include "fsl_dpaiop_mc.h"
#include "drivers/fsl_aiop.h"
#include "mpu.h"
#include "leds.h"
#include "fsl_sys.h"
#include "fsl_system.h"
#include "soc_db.h"
#include "bringup_tests.h"

#define GCR1_P1_RST_MASK  0x00800000
#define GCR1_P1_STOP_MASK 0x80000000
#define GCR1_P2_RST_MASK  0x00400000
#define GCR1_P2_STOP_MASK 0x40000000
#define GCR1_P1_RST_OFF   23
#define GCR1_P2_RST_OFF   22
#define GCR1_P1_STOP_OFF  31
#define GCR1_P2_STOP_OFF  30

extern int sys_init(void);
extern void sys_free(void);
extern int global_init(void);
extern int global_free(void);
extern int global_post_init(void);
extern int run_apps(void);
extern int sys_init_multi_processing(void);
extern int sys_lo_process(void);
extern int aiop_drv_init(void);
extern void cmdif_polling(void);

#if (TEST_AIOP == ON)

static void start_aiop(void)
{
	struct dpaiop *dpaiop;
	struct dpaiop_run_cfg run_cfg = {0};
	struct dpaiop_load_cfg load_cfg = {0};
	int err;

	dpaiop = sys_get_handle(FSL_MOD_DPAIOP, 1, 0);

	if (dpaiop)
	{
		load_cfg.img_iova = DPAIOP_ELF_LOAD_ADDRESS_LPVOID;
		load_cfg.options = 0x8000000000000000 | DPAIOP_LOAD_OPT_DEBUG;
		err = dpaiop_load(dpaiop, &load_cfg);
		if (err)
			pr_info("AIOP load failed (%d), elf image expected at 0x%x\n", err, DPAIOP_ELF_LOAD_ADDRESS);
		else {
			run_cfg.cores_mask = 0xffff;
			run_cfg.options = DPAIOP_RUN_OPT_DEBUG;

			err = dpaiop_run(dpaiop, &run_cfg);
			if (err)
				pr_info("AIOP run failed (%d)\n", err);
#if 0
			else
			{
				uint32_t status;
				do {
					dpaiop_get_state(dpaiop, &status);
				} while (status == DPAIOP_STATE_BOOT_ONGOING);
					
				if (status == DPAIOP_STATE_RUNNING)
					pr_info("AIOP boot completed\n");
				else
					pr_info("AIOP boot failed\n");
			}
#endif
		}
	}
	else
		pr_info("No DPAIOP in DPL - skipping AIOP load\n");
}
#endif /* TEST_AIOP */

int soc_db_init()
{
	/* soc_db init */
/*	dcfg_get_revision(&s_pltfrm.soc_info.rev.major,
			&s_pltfrm.soc_info.rev.minor,
			&s_pltfrm.soc_info.rev.system_version);

	return soc_db_select(&s_pltfrm.soc_info.rev, s_pltfrm.soc_info.name);*/
	return 0;
}

/*****************************************************************************/
int main(int argc, char *argv[])

{
	int err = 0;
	volatile uint32_t wait = 1; /* Don't change */
//	int is_master_core;
//	struct mc_version mc_version;
//	uint32_t uboot_init_word;

	/* so sys_is_master_core() will work */
	extern char _spin_table[];  /* base address of spin table (from linker file) */
	extern t_system sys; /* Global System Object */
	extern struct soc_db soc_db;
	uint32_t        core_id = core_get_id();
	uint32_t *reg_base = soc_db.mc_db[0].desc.vaddr;
	uint32_t GCR1 = ioread32(reg_base);
	sys.is_master_core[core_id]       = (int)(0x1 & (1ULL << core_id));
	if(sys.is_master_core[core_id]) {
		sys.active_cores_mask = ((GCR1 & GCR1_P1_RST_MASK) >> GCR1_P1_RST_OFF)
									 | ((GCR1 & GCR1_P2_RST_MASK) >> (GCR1_P2_RST_OFF-1));
		sys.barrier_mask = sys.active_cores_mask;
		*((uint32_t*)_spin_table) = 1; /* start spinning core */
	}

	UNUSED(argc); UNUSED(argv);
	INIT_LIST(&(sys.forced_objects_list)); // for sys_get_handle

#if (TEST_MEM_ACCESS == ON)
	err |= mem_standalone_init();

//	sys_barrier();

	err |=  mem_test();
#endif

#if (TEST_CONSOLE_PRINT == ON)
	err |= console_print_init();
	err |=  console_print_test();
#endif

#if (TEST_LED == ON)
	err = sys_init_multi_processing();
	if (err) return err;

	err = soc_db_init();

	turn_led_configuration();
	turn_led_on(3);
#endif

#if (TEST_HW_SEM == ON)
	err |= hw_sem_standalone_init();

//	sys_barrier();

	err |= hw_sem_test();
#endif

#if (TEST_SPINLOCK == ON)
	err |= spinlock_standalone_init();

//	sys_barrier();

	err |= spinlock_test();
#endif

#if (TEST_MPIC == ON)
	err |= mpic_standalone_init();

//	sys_barrier();

	err |= mpic_test();
#endif

#if (TEST_MPU == ON)
	err |= mpu_standalone_init();

//	sys_barrier();

	err |= mpu_test();
#endif

#if (TEST_DCACHE == ON)
	err |= edma_test_init();
	err |= dcache_init();
	//sys_barrier();
	err |= dcache_test();
#endif

#if (TEST_SHARED_MEMORY_ACCESS == ON)
	sys_init_multi_processing();
	err |= shared_memory_access_init();

//	sys_barrier();

	err |= shared_memory_access_test();
#endif

#if (TEST_EDMA == ON)

	err |= edma_test_init();
	err |= edma_test();

#endif

#if (TEST_EXCEPTIONS == ON)
	exceptions_init();
	err |= exceptions_test();
#endif


#if (TEST_AIOP == ON)

#if (AIOP_TEST_MEM_ACCESS == ON)
	err |= mem_standalone_init();
#endif /* AIOP_TEST_MEM_ACCESS */

	{
		struct mc_version mc_version;
		uint32_t mc_boot_code;
		int is_master_core;
		struct dpmng_amq amq = {0};
		// ######################################################################
		// ######################## Load and start AIOP #########################
		// ######################################################################
		/* Do early operations prior to system initialization */
		if (core_get_id() == 0) {
			/* Find out how much system memory is allocated for MC */
			dpmng_set_dpaa_sys_ddr_region();

			/* Process DPC */
			dpc_process();

			/* LOG initialization */
			log_init();
		}

		/* Read MC boot code */
		mc_boot_code = dpmng_get_mc_status();

		/* Initialize system */
		err = sys_init();
		if (err) {
			dpmng_set_mc_status(MC_SYS_INIT_ERR);
			return err;
		}

		is_master_core = sys_is_master_core();

		if (is_master_core)
		{
			mc_get_version(&mc_version);
			pr_info("\nMC firmware version: %d.%d.%d\n",
				mc_version.major, mc_version.minor, mc_version.revision);

			pr_info("\nMC DDR base: 0x%08x%08x\nMC DDR Size = 0x%08x%08x\n",
							UINT32_HI(dpaa_sys_ddr_base),
							UINT32_LO(dpaa_sys_ddr_base),
							UINT32_HI(dpaa_sys_ddr_size),
							UINT32_LO(dpaa_sys_ddr_size));
			dpmng_get_amq(&amq);
			pr_info ("\nMC Attributes (AMQ): ICID-%d; BMT-%d; PL-%d; BDI-%d; VA-%d\n",
				amq.icid, amq.bmt, amq.pl, amq.bdi, amq.va);

#ifdef DEBUG
			mpu_print_tables();
#endif
			err = global_init();
			if (err) {
				pr_err("MC error status: 0x%08x\n", dpmng_get_mc_status());
				return err;
			}
		}
		sys_barrier();

		if (is_master_core ) {
			if (mc_boot_code == BOOT_CODE_DELAYED_DPL_DEPLOYMENT) {
				pr_info("Waiting for indication to process DPL...\n");
				dpmng_set_mc_status(MC_INIT_DONE);
				while (dpmng_get_mc_status() != 0)cmdif_polling();
			}

			pr_info("Processing DPL...\n");
			err = dpl_process();
			if (err)
			{
				pr_err("DPL processing failed; continuing...\n");
				dpmng_set_mc_status(MC_LO_PROCESS_ERR);
			}
		}
		sys_barrier();

		if (is_master_core)
			/* Start AIOP if image is found */
			start_aiop();

		sys_barrier();

		if (is_master_core) {
			pr_info("MC boot done; Running...\n");
			dpmng_set_mc_status(MC_INIT_DONE);
		}
		sys_barrier();

		//run_apps();
		sys_barrier();
	}
	while(1){}

#endif /* TEST_AIOP */

#if 0
#ifdef BRINGUP_TEST
	struct dpmng_amq {
		uint16_t icid;	/*! Isolation Context ID */
		int pl;		/*! Privilege level */
		int va;		/*! Virtual Address */
		int bmt;	/*! Bypass Memory Translation */
		int bdi;	/*! Bypass DPAA Isolation */
	};
#else
	dpmng_get_amq(sys_get_unique_handle(FSL_MOD_DPMNG), &amq);
#endif

	       psram_vaddr = dpmng_mc_set_soc_window(
	              0x520000000, &amq);

#endif
	if (err) {
#if (TEST_CONSOLE_PRINT == ON)
		fsl_print("TEST FAILED\n");
#endif
		do {} while(wait); /* TEST failed */
	} else {
#if (TEST_CONSOLE_PRINT == ON)
		fsl_print("TEST PASSED\n");
#endif
		do {} while(wait); /* TEST passed */
	}


//	sys_barrier();
//
//	if (is_master_core && ((err = global_post_init()) != 0)) {
//		return err;
//	}
//	sys_barrier();
//
//	if (is_master_core)
//		pr_info("Running applications\n");
//
//	run_apps();
//	sys_barrier();
//
//	if (is_master_core)
//	{
//		pr_info("complete. Freeing resources and going out ...\n");
//		global_free();
//	}
//
//	sys_barrier();
//	/* TODO - complete - free everything here!!! */
//
//	if (is_master_core)
//		pr_info("MC status = 0x%08x.\n", dpmng_get_mc_status());
//
//	/* Free system */
//	sys_free();


	return err;
}

