/*
 * Copyright 2017 NXP
 */

#include "bringup_tests.h"
#include "mpic.h"
#include "fsl_mpic.h"
#include "fsl_mcpic.h"


#include "fsl_types.h"
#include "fsl_sys.h"
#include "fsl_platform.h"
#include "fsl_system.h"
#include "fsl_errors.h"
#include "fsl_mc.h"
#include "fsl_soc.h"
#include "fsl_smp.h"
#include "fsl_string.h"
#include "fsl_dpmng_mc.h"
#include "cmdif/cmdif_srv.h"
#include "fsl_list.h"

#define MPIC_TEST_VAL (0x1234)
#define NUM_OF_CMDIF 2

volatile uint32_t mpic_ok_flag = 0;
extern t_system sys; /* Global System Object */
extern int sys_init_multi_processing(void);
extern int sys_init_memory_management();
/*****************************************************************************/
void mc_msg_isr(uint32_t arg);
void test_portal_isr(uint32_t arg);
int mpic_standalone_init();
int mpic_standalone_init();
int mpic_test();
/*****************************************************************************/
void mc_msg_isr(uint32_t arg)
{
	uint32_t msg_data;
	mpic_ok_flag = MPIC_TEST_VAL/*arg*/;
	mpic_read_msg(MC_MPIC_INTR_MSG_0, &msg_data);
}

/*****************************************************************************/
void test_portal_isr(uint32_t arg)
{
	int i = 0;
	struct cpm_desc cpm_desc;
	uint32_t pending;
	uint8_t portal_indx;

	mpic_ok_flag = MPIC_TEST_VAL/*arg*/;

	memset(&cpm_desc, 0, sizeof(cpm_desc));
	sys_get_desc(SOC_MODULE_CPM, SOC_DB_NO_MATCH_FIELDS, &cpm_desc, NULL);

	for (i = 0; i < NUM_OF_CMDIF; i++) {
		struct mc_cpm_regs *cpm_regs;
		cpm_regs = (struct mc_cpm_regs *)PTR_MOVE(cpm_desc.vaddr, (0x1000 * i));

		pending = ioread32(&(cpm_regs->hpspr));
		if((pending & CMD_PORTAL_PENDING_BIT) == 0)
			pending = ioread32(&(cpm_regs->lpspr));

		if (pending & CMD_PORTAL_PENDING_BIT) {
			portal_indx = (uint8_t)(pending & 0xFF);
			iowrite32((0x1 << (portal_indx % 32)), &(cpm_regs->cprr[portal_indx / 32]));
			iowrite32((0x1 << (portal_indx % 32)), &(cpm_regs->cppr[portal_indx / 32]));
		}

	}
}


static int config_cpm()
{
	int err = 0, i = 0, j = 0;
	struct cpm_desc cpm_desc;

	memset(&cpm_desc, 0, sizeof(cpm_desc));
	err = sys_get_desc(SOC_MODULE_CPM, SOC_DB_NO_MATCH_FIELDS, &cpm_desc, NULL);
	if(err) return err;

	for (i = 0; i < NUM_OF_CMDIF; i++)
	{
		struct mc_cpm_regs *cpm_regs;
		cpm_regs = (struct mc_cpm_regs *)PTR_MOVE(cpm_desc.vaddr, (0x1000 * i));

		/* set the initialization values to the cpm registers*/
		for (j = 0; j < NUMBER_OF_PORTALS_REGS; j++) {
			/* cleaning received commands register*/
			iowrite32(0xffffffff, &(cpm_regs->cprr[j]));
			/* cleaning error commands register*/
			iowrite32(0xffffffff, &(cpm_regs->cper[j]));
			/* cleaning priority commands register*/
			iowrite32(0xffffffff, &(cpm_regs->cppr[j]));
			/* mask interrupts for all portals */
			iowrite32(0xffffffff, &(cpm_regs->cpmr[j]));
		}
	}

	return 0;
}

/*****************************************************************************/
int mpic_standalone_init()
{
	int err = 0;

	booke_generic_irq_init();

	msr_enable_ee();
	msr_enable_me();
	msr_enable_ce();

	if (sys_is_master_core())
	{
		/* init multi-proc */
		err = sys_init_multi_processing();
		if (err) return err;

		INIT_LIST(&(sys.forced_objects_list)); // for sys_get_handle

		/* Initialize memory management */
		err = sys_init_memory_management();
		if (err) return err;

		/* init soc_db */
		err = soc_db_init();
		if (err) return err;

		err = mcpic_init((void*)0x21040000);
		if (err) return err;
	}

	return err;
}

/*****************************************************************************/
static int config_portal_interrupts()
{
    mpic_intr_params_t intr_params;
    int err;

    intr_params.polarity = OS_MPIC_INTR_POLARITY_HIGH;
    intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;
    intr_params.sense = OS_MPIC_INTR_SENSE_EDGE;
    intr_params.priority = 0xa;

    /* For core #0 */
	err = mpic_set_config_intr(MC_MPIC_INTR_CPM_1_HP, 0, test_portal_isr, 0, &intr_params);
	if(err) return err;

	err = mpic_enable_intr(MC_MPIC_INTR_CPM_1_HP);
	if(err) return err;

	/* For core #1
	err = mpic_set_config_intr(MC_MPIC_INTR_CPM_2_HP, 1, test_portal_isr, 0, &intr_params);
	if(err) return err;

	err = mpic_enable_intr(MC_MPIC_INTR_CPM_2_HP);
	if(err) return err;
	*/
	intr_params.priority = 0x5;

	err = mpic_set_config_intr(MC_MPIC_INTR_CPM_1_LP, 0, test_portal_isr, 0, &intr_params);
	if(err) return err;

	err = mpic_enable_intr(MC_MPIC_INTR_CPM_1_LP);
	if(err) return err;

	/* For core #1
	err = mpic_set_config_intr(MC_MPIC_INTR_CPM_2_LP, 1, test_portal_isr, 0, &intr_params);
	if(err) return err;

	err = mpic_enable_intr(MC_MPIC_INTR_CPM_2_LP);
	if(err) return err;
	*/
	return 0;
}


/*****************************************************************************/
static int config_msg_interrupts()
{
	mpic_intr_params_t intr_params;
	int err;

	intr_params.polarity = OS_MPIC_INTR_POLARITY_HIGH;
	intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;
	intr_params.sense = OS_MPIC_INTR_SENSE_EDGE;
	intr_params.priority = 0xa;

	/* Interrupt registration */
	err = mpic_set_config_intr(MC_MPIC_INTR_MSG_0, 0, mc_msg_isr, 0, &intr_params);
	if(err) return err;

	err = mpic_enable_intr(MC_MPIC_INTR_MSG_0);
	if(err) return err;

	return 0;
}

/*****************************************************************************/
static int test_portals_intr()
{
	int err, is_master_core;
	uint32_t *vaddr;

	is_master_core = sys_is_master_core();

	if (is_master_core) {
		struct dpmng_amq amq;

		err = config_portal_interrupts();
		if(err) return err;

		err = config_cpm();
		if(err) return err;

		/* mimic write to portal */
		amq.icid 	= 0;
		amq.pl 		= 1;
		amq.va 		= 0;
		amq.bmt 	= 1;
		amq.bdi 	= 0;
		vaddr = (uint32_t*)dpmng_mc_set_soc_window(0x00080C000000, &amq);
		iowrite32(0xffffffff,vaddr); /* write to portal 0 */

//		iowrite32(0xffffffff, (uint32_t *)0x208000C0); //TODO remove
//		iowrite32(0xffffffff, (uint32_t *)0x200000C0); //TODO remove
	}

	/* Wait for interrupt to arrive */
	while(mpic_ok_flag != MPIC_TEST_VAL) {}

	return 0;
}

static int test_msg_intr()
{

	int err, is_master_core;
	is_master_core = sys_is_master_core();

	if (is_master_core) {
		err = config_msg_interrupts();
		if(err) return err;

		/* Write the message */
		err = mpic_write_msg(MC_MPIC_INTR_MSG_0, MPIC_TEST_VAL, 0);
		if(err) return err;
	}

	/* Wait for message to arrive */
	while(mpic_ok_flag != MPIC_TEST_VAL) {}

	err = mpic_disable_intr(MC_MPIC_INTR_MSG_0);
	if (err != 0)
		return err;

	err = mpic_free_intr(MC_MPIC_INTR_MSG_0);
	if (err != 0)
		return err;

	return 0;
}

/*****************************************************************************/
int mpic_test()
{
	int err;

	err = test_msg_intr();
	if(err) return err;

	mpic_ok_flag = 0;

	err = test_portals_intr();
	if(err) return err;

    return 0;
}
