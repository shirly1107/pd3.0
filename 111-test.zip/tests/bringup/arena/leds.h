/*
 * Copyright 2017 NXP
 */

/**
@File          leds.h

@Description   header file to turn on leds from MC.

*//***************************************************************************/
#ifndef __LED_H
#define __LED_H

#include "fsl_types.h"

#define FPGA_PHYS_ADDR        0x500000000 /*physical address for FPGA*/
#define FPGA_OFFSET           0x020000000 /*FPGA offset*/
#define LED_CTL_OFFSET        0x04 /*led ctl is in offset 05*/
#define LED_SWITCH_OFFSET     0x0C /*led switch is in offset 0x0E*/


#define TURN_ON_LEDS_CTRL(vaddr)                                          \
	{                                                                 \
		uint32_t *ptr = (uint32_t *)(vaddr + FPGA_OFFSET + LED_CTL_OFFSET);     \
		*ptr ^= 0x00020000;                                       \
	}

#define SWITCH_LED_1(vaddr)                                               \
	{                                                                 \
		uint32_t *ptr = (uint32_t *)(vaddr + FPGA_OFFSET + LED_SWITCH_OFFSET);  \
		*ptr ^= 0x00000100;                                       \
	}
#define SWITCH_LED_2(vaddr)                                               \
	{                                                                 \
		uint32_t *ptr = (uint32_t *)(vaddr + FPGA_OFFSET +  LED_SWITCH_OFFSET);  \
		*ptr ^= 0x00000200;                                       \
	}
#define SWITCH_LED_3(vaddr)                                               \
	{                                                                 \
		uint32_t *ptr = (uint32_t *)(vaddr + FPGA_OFFSET + LED_SWITCH_OFFSET);  \
		*ptr ^= 0x00000400;                                       \
	}
#define SWITCH_LED_4(vaddr)                                               \
	{                                                                 \
		uint32_t *ptr = (uint32_t *)(vaddr + FPGA_OFFSET + LED_SWITCH_OFFSET);  \
		*ptr ^= 0x00000800;                                       \
	}
#define SWITCH_LED_5(vaddr)                                               \
	{                                                                 \
		uint32_t *ptr = (uint32_t *)(vaddr + FPGA_OFFSET + LED_SWITCH_OFFSET);  \
		*ptr ^= 0x00001000;                                       \
	}
#define SWITCH_LED_6(vaddr)                                               \
	{                                                                 \
		uint32_t *ptr = (uint32_t *)(vaddr + FPGA_OFFSET + LED_SWITCH_OFFSET);  \
		*ptr ^= 0x00002000;                                       \
	}
#define SWITCH_LED_7(vaddr)                                               \
	{                                                                 \
		uint32_t *ptr = (uint32_t *)(vaddr + FPGA_OFFSET + LED_SWITCH_OFFSET);  \
		*ptr ^= 0x00004000;                                       \
	}
#define SWITCH_LED_8(vaddr)                                               \
	{                                                                 \
		uint32_t *ptr = (uint32_t *)(vaddr + FPGA_OFFSET + LED_SWITCH_OFFSET);  \
		*ptr ^= 0x00008000;                                       \
	}

/**
 * @Function turn_led_configuration;
 */
void turn_led_configuration(void);
/**
 * @Function turn_led_on;
 * @param[in] led_num bitmask to choose which leds to turn on (8 bits = 8 leds)
 */
void turn_led_on(uint8_t led_num);

#endif /* __LED_H */

