/*
 * Copyright 2017 NXP
 */

/******************************************************************************
 @File          bringup2_test.c

 @Description   test implementation.
 *//***************************************************************************/

/************/
/* INCLUDES */
/************/

#include "bringup2_test.h"
#include "common.h"

#include "fsl_types.h"
#include "fsl_dprc_mc.h"
#include "fsl_dpmac_mc.h"
#include "kernel/device.h"
#include "fsl_errors.h"
#include "common/fsl_string.h"			/* memset */
#include "include/fsl_sys.h"
#include "fsl_malloc.h"
#include "fsl_dpmng_mc.h"			/* dpmng_amq */
#include "fsl_dpmac_mc.h"			/* dpmac */
#include "fsl_dpni_mc.h"			/* dpni */
#include "fsl_dpio_mc.h"			/* dpio */
#include "fsl_dpbp_mc.h"			/* dpbp */
#include "fsl_dpsw_mc.h"			/* L2 Switch */
#include "fsl_linkman.h"			/* Link Manager */
#include "coherent_access.h"		/* fetch */
#include "drivers/fsl_qbman_portal.h"		/* BMan */
#include "drivers/fsl_qbman_ctrl.h"		/* BMan */
#include "drivers/fsl_edma.h"

/************/
/*  DEFINES */
/************/
#define MAC_ID			1
#define FRAMES_NUM		10 /* number of frames to send through the dpni */

#define TEST_BUFFER_SIZE	512
#define TEST_BUFFER_NUM		MAX(DPNI_MIN_BUFFERS_NUM, (FRAMES_NUM*2+2))

/************/
/*  GLOBALS */
/************/
static int err_counters;
extern const enum dpmng_ctx_type global_objects_context;

/********************************/
/* Static functions declaration */
/********************************/
/* initialization functions */
static int init_dpni(struct dpni **dpni_p, int reset);
static int init_objects(struct dpni **dpni,
	struct dpmac **dpmac,
	struct dpbp **dpbp,
	struct dpio **dpio,
	struct qbman_swp **swp);
static int destroy_objects(struct dpni *dpni_arr,
	struct dpio *dpio,
	struct dpbp *dpbp);

/* configuration functions */
static int configure_dpni_mac_addr(struct dpni *dpni, const uint8_t *mac_addr);
static int configure_mac_loopback(struct dpmac *dpmac, int enabled);
static int configure_connect(struct dpni *dpni, struct dpmac *dpmac);
static int send_event(enum linkman_event event,
	uint16_t dpmac_id,
	uint16_t dpni_id);

/* use case functions */
static int check_loopback_enabled(struct dpni *dpni,
	struct dpmac *dpmac,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	const uint8_t *tx_frame,
	uint32_t tx_length);
static int check_loopback_disabled(struct dpni *dpni,
	struct dpmac *dpmac,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	const uint8_t *tx_frame,
	uint32_t tx_length);
static int check_dma(void);
static int check_confirmation(struct dpni *dpni,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	const uint8_t *tx_frame,
	uint32_t tx_length);
static int check_mac_injection(struct dpni *dpni,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	struct dpmac *dpmac);

/*****************/
/* Test Function */
/*****************/
int bringup2_app_init(void)
{
	/******************************/
	/*          Variables         */
	/******************************/
	/* objects handles */
	struct dpni *dpni = NULL;
	struct dpmac *dpmac = NULL;
	struct dpbp *dpbp = NULL;
	struct dpio *dpio = NULL;
	struct qbman_swp *swp = NULL;
#if 0
	int phy_loop = 1; /* 0-no loop ; 1-loop */
#endif
	/* frame */
	const uint8_t *tx_frame = frame_00_00_01_00_00_01_8023_64;
	uint32_t tx_length = sizeof(frame_00_00_01_00_00_01_8023_64);

	/* misc */
	int err, err_mac_injection, err_confirmation, err_dma, err_loopback,
		err_no_loopback, err_destroy;

	/***************************/
	/*     Initializations     */
	/***************************/
	err_counters = 0;
	/* init objects */
	err = init_objects(&dpni, &dpmac, &dpbp, &dpio, &swp);
	LOOP_ON_ERR(err, "objects initialization");

#if 0
	err = dpmac_config_sgmii(dpmac, phy_loop);
	if (err)
	fsl_print("dpmac_config_sgmii failed\n");
#endif
	/***************************/
	/*      Configuration      */
	/***************************/
	err = configure_dpni_mac_addr(dpni, tx_frame);
	LOOP_ON_ERR(err, "configure_dpni_mac_addr");

	err = configure_connect(dpni, dpmac);
	LOOP_ON_ERR(err, "configure_connect");

	/**********************************************************************/
	/*                Check receive when MAC loop back enabled            */
	/**********************************************************************/

#ifdef UC_ENABLED_LOOPBACK
	err = check_loopback_enabled(dpni, dpmac, dpbp, swp, tx_frame,
					tx_length);
	err_loopback = err;
	fsl_print(COLOR_BLUE"-------------------------------\n");
	fsl_print("loop back use case: %s!\n", ((err != 0) ? "FAIL" : "PASS"));
	fsl_print("-------------------------------\n"COLOR_RESET);

	{
		dpni_reset(dpni);
		err = 0;
		LOOP_ON_ERR(err, "dpni_reset");

		init_dpni(&dpni, 1);

		err = ni_set_pool(dpni, dpbp, TEST_BUFFER_SIZE);
		LOOP_ON_ERR(err, "ni_set_pool");

		/* enable */
		err = dpni_enable(dpni);
		LOOP_ON_ERR(err, "dpni_enable");
	}
	err = check_loopback_enabled(dpni, dpmac, dpbp, swp, tx_frame,
					tx_length);
	err_loopback = err;
	fsl_print("------------------------------------\n");
	fsl_print("loop back use case: %s!\n", ((err != 0) ? "FAIL" : "PASS"));
	fsl_print("------------------------------------\n");
#endif
	/**********************************************************************/
	/*             Check no receive when MAC loop back disabled           */
	/**********************************************************************/

#ifdef UC_ENABLED_NOLOOPBACK
	err = check_loopback_disabled(dpni, dpmac, dpbp, swp, tx_frame,
					tx_length);
	err_no_loopback = err;
	fsl_print("------------------------------------\n");
	fsl_print("NO loop back use case: %s!\n",
			((err != 0) ? "FAIL" : "PASS"));
	fsl_print("------------------------------------\n");
#endif
	/**********************************************************************/
	/*                              Check DMA                             */
	/**********************************************************************/
#ifdef UC_ENABLED_DMA
	err = check_dma();
	err_dma = err;
	fsl_print("------------------------------\n");
	fsl_print("DMA use case: %s!\n", ((err != 0) ? "FAIL" : "PASS"));
	fsl_print("------------------------------\n");
#endif
	/**********************************************************************/
	/*                         Check Confirmation                         */
	/**********************************************************************/
#ifdef UC_ENABLED_CONFIRMATION
	err = check_confirmation(dpni, dpbp, swp, tx_frame, tx_length);
	err_confirmation = err;
	fsl_print("------------------------------\n");
	fsl_print("Confirmation use case: %s!\n",
		((err != 0) ? "FAIL" : "PASS"));
	fsl_print("------------------------------\n");
#endif
	/**********************************************************************/
	/*                         Check MAC injection                        */
	/**********************************************************************/
#ifdef UC_MAC_INJECTION
	err = check_mac_injection(dpni, dpbp, swp, dpmac);
	err_mac_injection = err;
	fsl_print("------------------------------\n");
	fsl_print("MAC injection use case: %s!\n",
			((err != 0) ? "FAIL" : "PASS"));
	fsl_print("------------------------------\n");
#endif

	/***************************/
	/*         Destroy         */
	/***************************/
	err = destroy_objects(dpni, dpio, dpbp);
	err_destroy = err;
	fsl_print("destroy_objects: %s!\n", ((err != 0) ? "FAIL" : "PASS"));

	/****************************/
	/* Print Successes/Failures */
	/****************************/
	/* print use cases results */
	fsl_print("------------------------------\n");
	fsl_print("Bring Up Test #2 Finished:\n");

#ifdef UC_ENABLED_DMA
	print_test_result("Copy data by DMA", err_dma);
#endif

#ifdef UC_ENABLED_LOOPBACK
	print_test_result("receive when loop back enabled", err_loopback);
	print_test_result("dpni Counters", err_counters);
#endif

#ifdef UC_ENABLED_NOLOOPBACK
	print_test_result("not receive when loop back disabled",
				err_no_loopback);
#endif
#ifdef UC_ENABLED_CONFIRMATION
	print_test_result("confirmation use case", err_confirmation);
#endif
#ifdef UC_MAC_INJECTION
	print_test_result("MAC injection use case", err_mac_injection);
#endif

	print_test_result("Objects Destroy", err_destroy);

	while (1) {
	};

	return 0;
}

/*******************************/
/*        Static functions     */
/*******************************/

/*-------------------------initialization functions---------------------------*/

static int init_objects(struct dpni **dpni,
	struct dpmac **dpmac,
	struct dpbp **dpbp,
	struct dpio **dpio,
	struct qbman_swp **swp)
{
	int err;

	/* dpio */
	err = init_dpio(dpio);
	CHECK_ERR(err, "init_dpio");

	/* swp */
	err = init_swp(swp, *dpio);
	CHECK_ERR(err, "init_swp");

	/* dpbp */
	err = init_dpbp(dpbp);
	CHECK_ERR(err, "init_dpbp");
	err = init_dpbp_buffers(*dpbp, *swp, TEST_BUFFER_NUM,
				TEST_BUFFER_SIZE);
	CHECK_ERR(err, "init_dpbp_buffers");

	/* DPMAC */
	err = init_dpmac(dpmac, MAC_ID);
	CHECK_ERR(err, "init_dpmac");

	/* dpni */
	{
		err = init_dpni(dpni, 0);
		CHECK_ERR(err, "init_dpni");

		/* attach buffer pool */
		/* attach buffer pool */
		err = ni_set_pool(*dpni, *dpbp, TEST_BUFFER_SIZE);
		CHECK_ERR(err, "ni_set_pool");

		/* enable */
		err = dpni_enable(*dpni);
		CHECK_ERR(err, "dpni_enable");
	}

	return 0;
}

static int init_dpni(struct dpni **dpni_p, int reset)
{
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpni_cfg cfg = { 0 };
	struct dpni *dpni;
	void *dev = NULL;
	int err;

	if (!reset) {
		/* allocation */
		*dpni_p = dpni_allocate();
		err = (*dpni_p == NULL);
		CHECK_ERR(err, "dpni allocation");
		err = create_resman_device("dpni", &dev);
		CHECK_ERR(err, "create_resman_device (dpni)");
	}
	/* init */
	dpni = *dpni_p;
	cfg.mac_addr[5] = 0x01;
	cfg.adv.max_senders = 8;
	dev_cfg.device = dev;
	dev_cfg.id = device_get_id(dev);
	dev_cfg.ctx.type = global_objects_context;

	if (!reset) {
		err = dpni_init(dpni, &cfg, &dev_cfg);
		CHECK_ERR(err, "dpni_init");
	}
	err = dpni_set_dev_ctx(dpni, &dev_cfg.ctx);
	CHECK_ERR(err, "dpni_set_dev_ctx");

	err = dpni_set_unicast_promisc(dpni, 1);
	CHECK_ERR(err, "dpni_set_unicast_promisc");
	err = dpni_set_multicast_promisc(dpni, 1);
	CHECK_ERR(err, "dpni_set_unicast_promisc");
#if 0
	{
		struct dpni_error_cfg cfg = {0};
		cfg.error_action = DPNI_ERROR_ACTION_SEND_TO_ERROR_QUEUE;
		cfg.errors = 0xffffffff;
		cfg.set_frame_annotation = 1;
		err = dpni_set_errors_behavior(dpni, &cfg);
		CHECK_ERR(err, "dpndpni_set_errors_behavior");
	}
#endif
	/* Register NI in RM*/
	if (!reset) {
		device_set_priv(dev, dpni);
		err = sys_add_handle(dpni, FSL_MOD_DPNI, 1, dev_cfg.id);
		CHECK_ERR(err, "sys_add_handle (dpni)");
	}
	return 0;
}

static int destroy_objects(struct dpni *dpni,
	struct dpio *dpio,
	struct dpbp *dpbp)
{
	struct dpni_attr dpni_attr;
	struct dpbp_attr dpbp_attr;
	struct dpio_attr dpio_attr;
	int err;

	/* dpni */
	err = dpni_get_attributes(dpni, &dpni_attr);
	CHECK_ERR(err, "dpni_get_attributes");
	dpni_destroy(dpni);
	sys_remove_handle(FSL_MOD_DPNI, 1, dpni_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpni)");
	dpni_deallocate(dpni);
	CHECK_ERR(err, "dpni_deallocate");

	/* dpbp */
	err = dpbp_get_attributes(dpbp, &dpbp_attr);
	CHECK_ERR(err, "dpbp_get_attributes");
	dpbp_destroy(dpbp);
	sys_remove_handle(FSL_MOD_DPBP, 1, dpbp_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpbp)");
	dpbp_deallocate(dpbp);
	CHECK_ERR(err, "dpbp_deallocate");

	/* dpio */
	err = dpio_get_attributes(dpio, &dpio_attr);
	CHECK_ERR(err, "dpio_get_attributes");
	dpio_destroy(dpio);
	sys_remove_handle(FSL_MOD_DPIO, 1, dpio_attr.id);
	CHECK_ERR(err, "sys_remove_handle (dpio)");
	dpio_deallocate(dpio);
	CHECK_ERR(err, "dpio_deallocate");

	return 0;
}

/*------------------------- Configuration Functions --------------------------*/

static int configure_dpni_mac_addr(struct dpni *dpni, const uint8_t *mac_addr)
{
	int err;

	err = dpni_set_primary_mac_addr(dpni, mac_addr);
	CHECK_ERR(err, "dpni_set_primary_mac_addr");
	return 0;
}

static int configure_mac_loopback(struct dpmac *dpmac, int enabled)
{
	int err;

	err = dpmac_set_loopback(dpmac, enabled);
	CHECK_ERR(err, "dpmac_set_loopback");

	return 0;
}

static int configure_connect(struct dpni *dpni, struct dpmac *dpmac)
{
	struct dpni_attr dpni_attr;
	uint16_t dpni_id;
	uint16_t dpmac_id;
	int err;

	/* get dpni id */
	err = dpni_get_attributes(dpni, &dpni_attr);
	CHECK_ERR(err, "dpni_get_attr");
	dpni_id = (uint16_t)dpni_attr.id;

	/* get dpmac id */
	UNUSED(dpmac);
	dpmac_id = MAC_ID;

	/*! Connect */
	err = send_event(LINKMAN_EVENT_CONNECT, /*! Event */
				dpmac_id, /*! mac ID */
				dpni_id); /* peer connector id */
	CHECK_ERR(err, "send_event (connect)");

	/*! Link up */
	err = send_event(LINKMAN_EVENT_LINKUP, /*! Event */
				dpmac_id, /*! mac ID */
				dpni_id); /*! peer connector id */

	CHECK_ERR(err, "send_event (link up)");

	return 0;
}

static int send_event(enum linkman_event event,
	uint16_t dpmac_id,
	uint16_t dpni_id)
{
	int err;
	struct linkman_endpoint self; /* dpmac */
	struct linkman_endpoint peer; /* dpni */
	struct linkman *linkman = NULL;
	struct linkman_control control;

	memset(&self, 0x0, sizeof(struct linkman_endpoint));
	memset(&peer, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));

	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	err = (linkman == NULL);
	CHECK_ERR(err, "sys_get_unique_handle");

	/* dpmac */
	self.id = (uint16_t)dpmac_id; /* Switch ID */
	self.type = FSL_MOD_DPMAC; /* Type */

	/* Peer connector */
	peer.type = FSL_MOD_DPNI; /* peer type*/
	peer.id = dpni_id; /* peer id */

	/* Start link up state machine */
	control.event = event;
	err = linkman_set_connection(linkman, &control, &self, &peer);

	return err;
}

/*--------------------------- Use Cases Functions ----------------------------*/

static int check_loopback_enabled(struct dpni *dpni,
	struct dpmac *dpmac,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	const uint8_t *tx_frame,
	uint32_t tx_length)
{
	int err, i, j;
	/* frames */
	uint8_t rx_frame[sizeof(frame_00_00_01_00_00_01_8023_64)];
	uint32_t rx_length;
	struct dpni_link_state state;

	err = dpni_get_link_state(dpni, &state);
	CHECK_ERR(err, "dpni_get_link_state");
	if (!state.up)
		CHECK_ERR(1, "link down");

	/* enable loop back */
	err = configure_mac_loopback(dpmac, 1);
	CHECK_ERR(err, "configure_mac_loopback (enabled)");

	dump_dpni_counters(dpni, "before frame sending");

	/* send frame */
	for (j = 1; j <= FRAMES_NUM; j++) {
		fsl_print(
			"\x1b[34m=== check loopback: #%d frame (out of %d) ===\x1b[0m\n",
			j, FRAMES_NUM);
		err = test_send_frame(dpni, dpbp, swp, tx_frame, tx_length,
					0 /* no special options */,
					0 /* no tx flow id */);
		CHECK_ERR(err, "frame send");
		dump_dpni_counters(dpni, "after frame sending");
		print_port_counters(EIOP_ETHERNET_PORT, MAC_ID);
		dump_mac_counters(dpmac, MAC_ID, "loopback-ed MAC");

		/* receive frame */
		err = test_receive_frame(
			dpni, swp, rx_frame, &rx_length,
			0 /* don't keep polling if queue is empty */);
		CHECK_ERR(err, "frame receive");

		/* check counters */
		{
			err_counters |= check_dpni_counter(
				dpni, DPNI_CNT_ING_FRAME, j);
			err_counters |= check_dpni_counter(
				dpni, DPNI_CNT_ING_BYTE, (j * tx_length));
			err_counters |= check_dpni_counter(
				dpni, DPNI_CNT_EGR_FRAME, j);
			err_counters |= check_dpni_counter(
				dpni, DPNI_CNT_EGR_BYTE, (j * rx_length));
		}

		/* debug prints */
		pr_info("rx_length: %d\n", rx_length);
		pr_info("tx_length: %d\n", tx_length);
		pr_info("dump rx frame:\n");
		for (i = 0; i < rx_length; i++) {
			fsl_print("0x%02x ", rx_frame[i]);
		}
		fsl_print("\n");

		/* compare frames */
		err = (tx_length != rx_length);
		CHECK_ERR(
			err,
			"check length equality of transmitted and received frames");
		err = (memcmp(tx_frame, rx_frame, rx_length));
		CHECK_ERR(
			err,
			"check data equality of transmitted and received frames");
	}
	return 0;
}

static int check_loopback_disabled(struct dpni *dpni,
	struct dpmac *dpmac,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	const uint8_t *tx_frame,
	uint32_t tx_length)
{
	int err, receive_err;
	/* frames */
	uint8_t rx_frame[sizeof(frame_00_00_01_00_00_01_8023_64)];
	uint32_t rx_length;

	/* enable loop back */
	err = configure_mac_loopback(dpmac, 0);
	CHECK_ERR(err, "configure_mac_loopback (disabled)");

	/* send frame */
	err = test_send_frame(dpni, dpbp, swp, tx_frame, tx_length,
				0 /* no special options */,
				0 /* no tx flow id */);
	CHECK_ERR(err, "frame send");

	/* receive frame */
	receive_err = test_receive_frame(
		dpni, swp, rx_frame, &rx_length,
		0 /* don't keep polling if queue is empty */);
	err = (receive_err != -ENAVAIL);
	CHECK_ERR(err, "frame not received (-E_EMPTY is returned)");

	return 0;
}

static int check_confirmation(struct dpni *dpni,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	const uint8_t *tx_frame,
	uint32_t tx_length)
{
	uint8_t rx_frame[sizeof(frame_00_00_01_00_00_01_8023_64)];
	uint32_t rx_length;
	uint16_t flow_id;
	struct dpni_tx_flow_cfg dpni_tx_flow_cfg = { 0 };
	struct dpni_tx_conf_cfg dpni_tx_conf_cfg = { 0 };
	struct dpni_attr dpni_attr;
	uint32_t fqid, common_fqid;
	struct dpni_tx_conf_attr dpni_tx_conf_attr;
	int is_public, is_only_errors, is_tx_error;
	int err;

	err = dpni_get_attributes(dpni, &dpni_attr);
	CHECK_ERR(err, "dpni_get_attributes");

	/* get common queue */
	err = dpni_get_tx_conf(dpni, DPNI_COMMON_TX_CONF, &dpni_tx_conf_attr);
	CHECK_ERR(err, "dpni_get_tx_conf");
	common_fqid = dpni_tx_conf_attr.queue_attr.fqid;

	dpni_tx_flow_cfg.options = DPNI_TX_FLOW_OPT_TX_CONF_ERROR;

	for (is_public = 0; is_public <= 1; is_public++) {
		for (is_only_errors = 0; is_only_errors <= 1;
			is_only_errors++) {

			flow_id = DPNI_NEW_FLOW_ID;
			dpni_tx_flow_cfg.use_common_tx_conf_queue = is_public;
			err = dpni_set_tx_flow(dpni, &flow_id,
						&dpni_tx_flow_cfg);
			CHECK_ERR( err, "dpni_set_tx_flow");

			dpni_tx_conf_cfg.errors_only = is_only_errors;
			err = dpni_set_tx_conf(
				dpni,
				(is_public ? DPNI_COMMON_TX_CONF : flow_id),
				&dpni_tx_conf_cfg);

			CHECK_ERR(err, "dpni_set_tx_conf (public)");

			for (is_tx_error = 0; is_tx_error <= 1;
				is_tx_error++) {

				if (is_public) {
					fqid = common_fqid;

				} else {
					err = dpni_get_tx_conf(
						dpni, flow_id,
						&dpni_tx_conf_attr);
					CHECK_ERR(err, "dpni_get_tx_flow");
					fqid =
						dpni_tx_conf_attr.queue_attr.fqid;
				}

				/* send frame */
				err =
					test_send_frame(
						dpni,
						dpbp,
						swp,
						tx_frame,
						tx_length,
						((is_tx_error
							* SEND_FRAME_OPT_GENERTATE_TX_ERR)
							| SEND_FRAME_OPT_TX_FLOW_ID),
						flow_id);
				CHECK_ERR(err, "frame send");

				err = test_dequeue_from_fqid(
					fqid, swp, rx_frame, &rx_length,
					0 /* don't poll while empty */);
				if (is_only_errors && !is_tx_error) {
					CHECK_ERR(
						!err,
						"receive from err_conf queue (shouldn't be received)");
				} else {
					CHECK_ERR(
						err, "receive when no_errors");
				}
			}
		}
	}
	return 0;
}

static int check_mac_injection(struct dpni *dpni,
	struct dpbp *dpbp,
	struct qbman_swp *swp,
	struct dpmac *dpmac)
{
	int err, i;
	/* frames */
	uint8_t rx_frame[4096];
	uint32_t rx_length;
	struct dpni_link_state state;

	err = dpni_get_link_state(dpni, &state);
	CHECK_ERR(err, "dpni_get_link_state");
	if (!state.up)
		CHECK_ERR(1, "link down");

	/* disable loop back */
	err = configure_mac_loopback(dpmac, 0);
	CHECK_ERR(err, "configure_mac_loopback (disable)");

	/* enable unicast promisc mode (for any frame user would choose to inject) */
	err = dpni_set_unicast_promisc(dpni, 1);
	CHECK_ERR(err, "dpni_set_unicast_promisc (enable)");

	/* print message to user to manually inject frame */
	fsl_print(
		"\n TODO: Inject a frame to MAC#%d now!\n"
		"\t when reception is detected on the dpni, this test will continue automatically\n",
		MAC_ID);

	/* receive frame */
	err = test_receive_frame(
		dpni, swp, rx_frame, &rx_length,
		1 /* keep polling if queue is empty */);
	CHECK_ERR(err, "frame receive");

	/* debug prints */
	pr_info("rx_length: %d\n", rx_length);
	pr_info("dump rx frame:\n");
	for (i = 0; i < rx_length; i++) {
		fsl_print("0x%02x ", rx_frame[i]);
	}
	fsl_print("\n");

	err = test_send_frame(dpni, dpbp, swp, rx_frame, rx_length,
				0 /* no special options */,
				0 /* no tx flow id */);
	CHECK_ERR(err, "send frame back to dpmac");

	dump_mac_counters(dpmac, MAC_ID, "");
	err = check_dpmac_counter(dpmac, DPMAC_CNT_EGR_UCAST_FRAME, 1);
	if (err)
		pr_err("dpmac counters indicate no frame was received back\n");

	err_counters |= err;

	return 0;
}

static int check_dma(void)
{
	int err;
	struct dpmng_amq dpmng_amq;
	const uint8_t *data = frame_00_00_01_00_00_01_8023_64;
	uint8_t destination_addr[sizeof(frame_00_00_01_00_00_01_8023_64)];
	const uint32_t data_size = sizeof(frame_00_00_01_00_00_01_8023_64);
	void* source_addr;
	struct edma_queue *dma_queue;
	struct edma_transfer params;
	enum transac_status status;

	source_addr = fsl_xmalloc(data_size,
					MEM_PART_SYSTEM_DDR1_NON_CACHEABLE, 0);
	err = (source_addr == NULL);
	CHECK_ERR( err, "fsl_xmalloc from MEM_PART_SYSTEM_DDR1_NON_CACHEABLE");
	memcpy(source_addr, data, data_size);

	/* Retrieve queue_0 that belongs to block 0 from the system*/
	dma_queue = sys_get_handle(FSL_MOD_EDMA_BLOCK_QUEUE, 3, 0,
					core_get_id()/*block_id*/,
					0/*queue_id*/);
	err = (dma_queue == NULL);
	CHECK_ERR(err, "sys_get_handle (FSL_MOD_EDMA_BLOCK_QUEUE)");

	memset(&params, 0, sizeof(params));

	/* Get MC am */
	pr_info("before dpmng_get_amq\n");
	dpmng_get_amq(&dpmng_amq);
	pr_info("after dpmng_get_amq\n");

	/* Set transaction parameters */
	params.src = (dma_addr_t)source_addr;
	params.dst = (dma_addr_t)destination_addr;
	params.byte_count = data_size;
	params.src_icid = dpmng_amq.icid;
	params.dst_icid = dpmng_amq.icid;
	params.flags = EDMA_DEST_ADDR_IA | EDMA_DEST_ADDR_PL
			| EDMA_DEST_ADDR_BMT
			| EDMA_SRC_ADDR_IA
			| EDMA_SRC_ADDR_PL
			| EDMA_SRC_ADDR_BMT;

	/* Enqueue to eDMA */
	fsl_print("before edma_queue_transfer\n");
	err = edma_queue_transfer(dma_queue, &params, &status);
	CHECK_ERR(err, "edma_queue_transfer");

	err = (status != EDMA_NORMAL);
	CHECK_ERR(err, "validate DMA transfer status is OK (EDMA_NORMAL)");

	flush(UINT_TO_PTR(destination_addr), data_size);
	err = memcmp(data, destination_addr, data_size);
	CHECK_ERR(err, "compare data copied by DMA");

	return 0;
}

