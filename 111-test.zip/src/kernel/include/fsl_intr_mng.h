/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_SYS_INTR_MNG_H
#define __FSL_SYS_INTR_MNG_H

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_irq.h"


#define SYS_INTR_CTRL_ID_MASK   0xff000000
#define SYS_INTR_CTRL_ID_SHIFT  24


#define SYS_MAKE_INTR_ID(_intr_id_base, _intr_ctrl_src) \
    ((int)(((_intr_ctrl_src) == NO_IRQ) ? \
           NO_IRQ : ((_intr_id_base) | ((_intr_ctrl_src) & ~(SYS_INTR_CTRL_ID_MASK)))))


#define SYS_MAX_INTR_CONTROLLERS    	2

typedef struct t_sys_intr_ctrl_info {
    void *    h_intr_ctrl;
    int       (*f_set_intr)(void * h_intr_ctrl, int intr_src, isr_t *f_isr, void * handle);
    int       (*f_free_intr)(void * h_intr_ctrl, int intr_src);
    int       (*f_enable_intr)(void * h_intr_ctrl, int intr_src);
    int       (*f_disable_intr)(void * h_intr_ctrl, int intr_src);
} t_sys_intr_ctrl_info;

int sys_register_intr_controller(void * h_intr_ctrl,
                                   int  (*f_set_intr)(void * h_intr_ctrl, int intr_src, isr_t *f_isr, void * handle),
                                   int  (*f_free_intr)(void * h_intr_ctrl, int intr_src),
                                   int  (*f_enable_intr)(void * h_intr_ctrl, int intr_src),
                                   int  (*f_disable_intr)(void * h_intr_ctrl, int intr_src),
                                   int      *p_intr_id_base);

int sys_unregister_intr_controller(void * h_intr_ctrl);

/**************************************************************************//**
 @Function      sys_set_intr

 @Description   Set a specific interrupt to be handled by a given callback routine.

 @Param[in]     intrId  - Interrupt source ID.
 @Param[in]     f_Isr   - Interrupt service routine, which will be called when
                          the interrupt occurs.
 @Param[in]     handle  - Argument for the interrupt service routine.

 @Return        E_OK on success; error code otherwise.
*//***************************************************************************/
int sys_set_intr(int intr_id, isr_t *f_isr, void * handle);

/**************************************************************************//**
 @Function      sys_free_intr

 @Description   Free a specific interrupt source.

 @Param[in]     intrId - Interrupt source ID.

 @Return        E_OK on success; error code otherwise.
*//***************************************************************************/
int sys_free_intr(int intr_id);

/**************************************************************************//**
 @Function      sys_enable_intr

 @Description   Enable a specific interrupt source.

 @Param[in]     intrId - Interrupt source ID.

 @Return        E_OK on success; error code otherwise.
*//***************************************************************************/
int sys_enable_intr(int intr_id);

/**************************************************************************//**
 @Function      sys_disable_intr

 @Description   Disable a specific interrupt source.

 @Param[in]     intrId - Interrupt source ID.

 @Return        E_OK on success; error code otherwise.
*//***************************************************************************/
int sys_disable_intr(int intr_id);


#endif /* __FSL_SYS_INTR_MNG_H */
