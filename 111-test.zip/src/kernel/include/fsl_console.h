/*
 * Copyright 2013-2020 NXP
 */

#ifndef __SYS_CONSOLE_H
#define __SYS_CONSOLE_H

#include "fsl_types.h"


/**************************************************************************//**
 @Group         sys_grp     System Interfaces

 @Description   Bare-board system programming interfaces.

 @{
*//***************************************************************************/
/**************************************************************************//**
 @Group         sys_console_grp     System Console Service

 @Description   Bare-board system interface for console operations.

 @{
*//***************************************************************************/

#define PRE_CONSOLE_BUF_SIZE    (4 * 1024)

/**************************************************************************//**
 @Function      sys_register_console

 @Description   Register a new system console.

 @Param[in]     h_ConsoleDev    - Handle to console device (passed as the first
                                  parameter to \c f_ConsolePrint and \c f_ConsoleGet).
 @Param[in]     f_ConsolePrint  - Console routine for printing characters.
 @Param[in]     f_ConsoleGet    - Console routine for reading characters.

 @Return        0 on success; Error code otherwise.

 @Cautions      Only a single console is supported. The existing console must
                be unregistered before a new one is registered.
*//***************************************************************************/
int sys_register_console(void *    h_console_dev,
                         int (*f_console_print)(void * h_console_dev,
                        	 uint8_t *p_data, uint32_t size),
                         int (*f_console_get)(void * h_console_dev,
                        	 uint8_t *p_data, uint32_t size));

/**************************************************************************//**
 @Function      sys_flush_pre_console_buf

 @Description   Flush the pre-console buffer.

 @Param[in]     h_ConsoleDev    - Handle to console device.
 *//***************************************************************************/
void sys_flush_pre_console_buf(void * h_console_dev);

/**************************************************************************//**
 @Function      sys_unregister_console

 @Description   Unregister the existing system console.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int sys_unregister_console(void);

#define SYS_PRINT_TO_CONSOLE_DEVICE 1
#define SYS_PRINT_TO_LOG_BUFFER 2

/**************************************************************************//**
 @Function      sys_print

 @Description   Prints a characters string to the console device or the log buffer.

                If no console has been registered yet, the function prints the
                string into an internal buffer. The buffer will be printed to
                the first registered console.

 @Param[in]     str - The characters string to print.
 @Param[in]     print_type - The type of print; it is a bit set. The SYS_PRINT_TO_*
                     macros would be used to set the value of print_type.

 @Return        None.
*//***************************************************************************/
void sys_print(char *str, int print_type);
char sys_get_char(void);

/** @} */ /* end of sys_console_grp */
/** @} */ /* end of sys_grp */
#endif /* __SYS_CONSOLE_H */
