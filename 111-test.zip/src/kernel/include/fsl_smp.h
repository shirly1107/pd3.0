/*
 * Copyright 2013-2020 NXP
 */

/**
 @File          fsl_smp.h

 @Description   Definitions and functions for initializing and operating
                multi-processing services.

*//***************************************************************************/
#ifndef __FSL_SYS_MP_H
#define __FSL_SYS_MP_H

#include "fsl_types.h"
#include "fsl_gen.h"
#include "fsl_core.h"
#include "hw_sem.h"

/**************************************************************************//**
 @Group         sys_g     System Interfaces

 @Description   Bare-board system programming interfaces.

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Group         sys_mp_grp      System Multi-Processing Interfaces

 @Description   System interfaces for Multi-Processing.

                The system Multi-Processing interfaces include:
                - General functions
                - Spinlocks
                - Barrier

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Collection    General Multi-Processing Application Programming Interface

 @Description   Spinlock definitions and functions.

 @{
*//***************************************************************************/

#define SYS_ANY_CORE    ((uint32_t)(~0)) /**< Assignment to any valid core (for use
                                              in system layout object descriptors) */

/**************************************************************************//**
 @Function      sys_is_core_active

 @Description   Checks if a given core is active in current configuration
                (according to the active cores mask).

                This macro evaluates to 1 if the respective bit of current
                core is set.
*//***************************************************************************/
int sys_is_core_active(uint32_t core_id);

/**************************************************************************//**
 @Function      sys_is_master_core

 @Description   Checks if the current core is the master core.

                In SMP configuration, the master core is marked by the user in
                the masterCoresMask variable in the system initialization parameters.

 @Cautions      This macro may be interpreted to a function call. When using
                it more than once in a code section, consider saving it into a
                local variable.
*//***************************************************************************/
int sys_is_master_core(void);

/**************************************************************************//**
 @Function      sys_get_cores_mask

 @Description   Returns the system's active cores in a mask format.

                Core 0 is marked by the least significant bit, core 1 is marked
                by the next bit to the left, and so on.
*//***************************************************************************/
uint64_t sys_get_cores_mask(void);

/**************************************************************************//**
 @Function      sys_get_num_of_cores

 @Description   Returns the number of active cores in the system.
*//***************************************************************************/
uint32_t sys_get_num_of_cores(void);

/**************************************************************************//**
 @Function      sys_get_max_num_of_cores

 @Description   Returns the maximum number of cores in the system.
*//***************************************************************************/
uint32_t sys_get_max_num_of_cores(void);

/**************************************************************************//**
 @Function      sys_kick_guest_partition

 @Description

 @Param[in]     coresMask
 @Param[in]     physBaseAddr

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int sys_kick_guest_partition(uint64_t cores_mask, dma_addr_t phys_base_addr);

/* @} */ /* end of general collection */

/**************************************************************************//**
 @Collection    Spinlock Application Programming Interface

 @Description   Spinlock definitions and functions.

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Description   Spinlock structure.
*//***************************************************************************/
struct spinlock {
    volatile int    lock;   /**< Lock indicator */
};


/**************************************************************************//**
 @Function      sys_init_spinlock

 @Description   Initialize spinlock structure.

                The routine initializes the given spinlock structure as unlocked.

 @Param         p_Spinlock  -  (In) Pointer to spinlock structure to be initialize.
*//***************************************************************************/
static __inline__ void sys_init_spinlock(struct spinlock *slock)
{
#ifdef SYS_SMP_SUPPORT
	slock->lock = 0;
#else
    UNUSED(slock);
#endif
}

/**************************************************************************//**
 @Function      sys_try_lock_spinlock

 @Description   Try locking the spinlock.

 @Param[in]     p_Spinlock - Pointer to spinlock structure.

 @Return        spinlock value, 0 if failed
*//***************************************************************************/
static __inline__ int sys_try_lock_spinlock(struct spinlock *slock)
{
#ifdef SYS_SMP_SUPPORT
	volatile int lock_val;
	hw_sem_take(HW_SEM_SPINLOCK, HW_SEM_VAL);
	
	core_memory_barrier();
	l1dcache_block_invalidate((uint32_t) &(slock->lock));
	
	lock_val = slock->lock;
	if(lock_val == 0) {
		slock->lock++;
		
		core_instruction_sync();
		core_memory_barrier();
		
		/* chase read */
		l1dcache_block_invalidate((uint32_t) &(slock->lock));
		lock_val = slock->lock;
	} else {
		lock_val = 0;
	}
	
	core_instruction_sync();
	hw_sem_release(HW_SEM_SPINLOCK);
	return lock_val;
#else
	UNUSED(slock);
	return 0;
#endif
}

/**************************************************************************//**
 @Function      sys_lock_spinlock

 @Description   Lock the spinlock.

 @Param[in]     p_Spinlock - Pointer to spinlock structure.

 @Return        None.
*//***************************************************************************/
static __inline__ void sys_lock_spinlock(struct spinlock *slock)
{
#ifdef SYS_SMP_SUPPORT
	volatile int lock_val = 0;
    
    do {
    	lock_val = sys_try_lock_spinlock(slock);
    } while(lock_val == 0);
    
    core_instruction_sync();
#else  /* not SYS_SMP_SUPPORT */
    /* Single core version: do nothing */
    UNUSED(slock);
#endif /* not SYS_SMP_SUPPORT */
}

/**************************************************************************//**
 @Function      sys_unlock_spinlock

 @Description   Unlock the spinlock.

 @Param[in]     p_Spinlock - Pointer to spinlock structure.

 @Return        None.
*//***************************************************************************/
static __inline__ void sys_unlock_spinlock(struct spinlock *slock)
{
#ifdef SYS_SMP_SUPPORT
	volatile int chase_read;
    
	/* Memory barrier is required before spinlock is released */
	core_memory_barrier();
    slock->lock = 0;
	core_instruction_sync();
	
    l1dcache_block_invalidate((uint32_t) &(slock->lock));
    chase_read = slock->lock;
#else  /* not SYS_SMP_SUPPORT */
    UNUSED(slock);
#endif /* not SYS_SMP_SUPPORT */
}

/**************************************************************************//**
 @Function      sys_lock_intr_spinlock

 @Description   Lock the spinlock and disable interrupts on local processor.

 @Param[in]     p_Spinlock - Pointer to spinlock structure.

 @Return        A value that represents the interrupts state before the
                operation, and should be passed to the matching
                sys_unlock_intr_spinlock() call.
*//***************************************************************************/
static __inline__ uint32_t sys_lock_intr_spinlock(struct spinlock *slock)
{
#ifdef SYS_SMP_SUPPORT
    register uint32_t irq_flags;

    /* The implementation below avoids looping on atomic reservations while
       interrupts are disabled. First try to acquire the lock. If the lock is
       taken, loop with interrupts enabled until the lock seems to be free,
       and try again. */
    while (1)
    {
        irq_flags = core_local_irq_save();

        if (sys_try_lock_spinlock(slock))
            break; /* Exit with interrupts disabled */

        core_local_irq_restore(irq_flags);

        while (slock->lock != 0) {
        	l1dcache_block_invalidate((uint32_t) &(slock->lock));
        }
    }

    /* Wait for all previous instructions to complete */
    core_instruction_sync();
    return irq_flags;
#else  /* not SYS_SMP_SUPPORT */
    /* Single core version: simply disable interrupts */
    UNUSED(slock);

    return core_local_irq_save();
#endif /* not SYS_SMP_SUPPORT */
}

/**************************************************************************//**
 @Function      sys_unlock_intr_spinlock

 @Description   Unlock the spinlock and restore interrupts on local processor.

 @Param[in]     p_Spinlock  - Pointer to spinlock structure.
 @Param[in]     intrFlags   - A value that represents the interrupts state to
                              restore, as returned by the matching call for
                              SYS_LockIntrSpinlock().

 @Return        None.
*//***************************************************************************/
static __inline__ void sys_unlock_intr_spinlock(struct spinlock *slock, uint32_t irq_flags)
{
#ifdef SYS_SMP_SUPPORT
	volatile int chase_read;
	
    /* Memory barrier is required before spinlock is released */
    core_memory_barrier();
    slock->lock = 0;
    core_instruction_sync();
    
    l1dcache_block_invalidate((uint32_t) &(slock->lock));
    chase_read = slock->lock;
#else  /* not SYS_SMP_SUPPORT */
    UNUSED(slock);
#endif /* not SYS_SMP_SUPPORT */

    /* Restore interrupts */
    core_local_irq_restore(irq_flags);
}
/* @} */ /* end of spinlock collection */


/**************************************************************************//**
 @Collection    Barrier Application Programming Interface

 @Description   Definitions and functions for central program barrier.

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Function      core_memory_barrier

 @Description   Forces the program to perform busy-wait cycles until all cores
                reach this point in the flow.

 @Param         None.
*//***************************************************************************/
void sys_barrier(void);

/** @} */ /* end of sys_mp_grp */
/** @} */ /* end of sys_g */


#endif /* __FSL_SYS_MP_H */
