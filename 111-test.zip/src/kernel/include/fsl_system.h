/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_SYSTEM_H
#define __FSL_SYSTEM_H

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_list.h"
#include "fsl_irq.h"
#include "fsl_dbg.h"
#include "fsl_smp.h"
#include "fsl_platform.h"
#include "fsl_sys.h"
#include "fsl_mem_mng.h"
#include "fsl_intr_mng.h"

typedef struct t_system {
    /* Memory management variables */
    struct initial_mem_mng 		boot_mem_mng;
    void 						*mem_mng;

    /* Interrupt management variables */
    t_sys_intr_ctrl_info        intr_ctrl_info[SYS_MAX_INTR_CONTROLLERS];
    struct spinlock             intr_mng_lock;

    /* Console variables */
    void 						*console;
    int                         (*f_console_print)(void * console, uint8_t *p_data, uint32_t size);
    int                         (*f_console_get)(void * console, uint8_t *p_data, uint32_t size);
    char                        *p_pre_console_buf[INTG_MAX_NUM_OF_CORES];
    uint32_t                    pre_console_buf_pos[INTG_MAX_NUM_OF_CORES];
    struct spinlock             console_lock;

    /* Interactive mode / CLI variables */
    int                         is_interactive_mode;
    volatile int                interactive_mode_counter;
    void 						*cli;
    volatile int                is_running;
    struct spinlock             run_cmd_lock;

    /* Multi-Processing variables */
    int                         is_master_core[INTG_MAX_NUM_OF_CORES];
    uint64_t                    active_cores_mask;
    uint32_t                    num_of_active_cores;
    struct spinlock             barrier_lock;
    volatile uint64_t           barrier_mask;

    list_t                      forced_objects_list;

    /* boot synchronization variables */
    volatile uint32_t           boot_sync_flag;

    /* Platform operations */
    t_platform_ops              platform_ops;
} t_system;

/* Global System Object */
extern t_system sys;

#endif /* __FSL_SYSTEM_H */
