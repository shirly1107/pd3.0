/*
 * Copyright 2013-2020 NXP
 */

#ifndef __SYS_MEM_MNG_H
#define __SYS_MEM_MNG_H

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_malloc.h"
#include "fsl_string.h"
#include "fsl_platform.h"

/**************************************************************************//**
 @Group         sys_grp     System Interfaces

 @Description   Bare-board system programming interfaces.

 @{
*//***************************************************************************/
/**************************************************************************//**
 @Group         sys_mem_grp     System Memory Management Service

 @Description   Bare-board system interface for memory management.

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Anchor        mem_attr

 @Collection    Memory Attributes

                Various attributes of memory partitions. These values may be
                or'ed together to create a mask of all memory attributes.
 @{
*//***************************************************************************/

/**< No memory attribute */
#define MEMORY_ATTR_NONE          0x00000000

/**< Memory is cacheable */
#define MEMORY_ATTR_CACHEABLE           0x00000001

/**< Memory is non-cacheable */
#define MEMORY_ATTR_NON_CACHEABLE           0x00000002
/**< It is possible to make dynamic memory allocation */
#define MEMORY_ATTR_MALLOCABLE          0x00000004

/**< Memory partition for physical address allocation  through fsl_get_mem() */
#define MEMORY_ATTR_PHYS_ALLOCATION		0x00000008


#define SYS_DEFAULT_HEAP_PARTITION  0   /**< Partition ID for default heap */
#define MEM_MNG_MAX_PARTITION_NAME_LEN      32


/**************************************************************************//**
 @Description   Initial Memory management, used for allocations during boot.
 *//***************************************************************************/
struct initial_mem_mng
{
    uint64_t base_paddress;
    uint32_t base_vaddress;
    uint64_t size;
    uint64_t curr_ptr;
    void *   lock;
};

/**************************************************************************//**
 @Description   Memory partition information for physical address allocation
 *//***************************************************************************/
typedef struct t_mem_mng_phys_addr_alloc_info
{
    char        name[MEM_MNG_MAX_PARTITION_NAME_LEN];
    uint64_t    base_paddress;
    uint64_t    size;
    uint32_t    attributes;
    uint64_t    current_usage;
    uint64_t    maximum_usage;
    int32_t    total_allocations;
    int32_t    total_deallocations;
} t_mem_mng_phys_addr_alloc_info;

/**************************************************************************//**
 @Description   Memory partition information
 *//***************************************************************************/
typedef struct t_mem_mng_partition_info
{
    char        name[MEM_MNG_MAX_PARTITION_NAME_LEN];
    uint64_t    base_address;
    uint64_t    size;
    uint32_t    attributes;
    uint64_t    current_usage;
    uint64_t    maximum_usage;
    int32_t    total_allocations;
    int32_t    total_deallocations;
} t_mem_mng_partition_info;

/* @} */

int sys_register_virt_mem_mapping(uint64_t virt_addr, uint64_t phys_addr, uint64_t size);

int sys_unregister_virt_mem_mapping(uint64_t virt_addr);

/**************************************************************************//**
 @Function      fsl_phys_to_virt

 @Description   Translates a physical address to the matching virtual address.

 @Param[in]     addr - The physical address to translate.

 @Return        Virtual address.
 *//***************************************************************************/
void *fsl_phys_to_virt(phys_addr_t addr);

/**************************************************************************//**
 @Function      fsl_virt_to_phys

 @Description   Translates a virtual address to the matching physical address.

 @Param[in]     addr - The virtual address to translate.

 @Return        Physical address.
 *//***************************************************************************/
phys_addr_t fsl_virt_to_phys(void *addr);


/**************************************************************************//**
 @Function      SYS_VirtToPhys

 @Description   Translate virtual address to physical one.

 @Param[in]     addr    - Virtual address

*//***************************************************************************/
dma_addr_t sys_virt_to_phys(void *addr);

/**************************************************************************//**
 @Function      SYS_PhysToVirt

 @Description   Translate physical address to virtual one.

 @Param[in]     addr    - Physical address

*//***************************************************************************/
void * sys_phys_to_virt(dma_addr_t addr);

/**************************************************************************//**
 @Function      SYS_MemAlloc

 @Description   Allocate a memory block from a specific partition and with
                specific attributes.

 @Param[in]     partitionId - Requested memory partition ID
 @Param[in]     size        - Requested memory size
 @Param[in]     alignment   - Requested memory alignment
 @Param[in]     info        - Allocation information string (for debug)
 @Param[in]     filename    - Caller file name (for debug)
 @Param[in]     line        - Caller line number (for debug)

 @Return        Pointer to allocated memory; NULL on failure.
*//***************************************************************************/
void * sys_mem_alloc(int         partition_id,
                    uint32_t    size,
                    uint32_t    alignment,
                    const char  *info,
                    const char  *filename,
                    int         line);

/**************************************************************************//**
 @Function      sys_mem_free

 @Description   Free a memory block that was previously allocated using the
                SYS_MemAlloc() routine.

 @Param[in]     p_Memory - Pointer to the memory block

 @Return        None.
*//***************************************************************************/
void sys_mem_free(void *p_memory);

/**************************************************************************//**
 @Function      sys_mem_xfree

 @Description   Free a memory block that was previously allocated using the
                SYS_MemAlloc() routine.

 @Param[in]     p_Memory - Pointer to the memory block

 @Return        None.
*//***************************************************************************/
void sys_mem_xfree(void *p_memory);


/**************************************************************************//**
 @Function      sys_register_phys_addr_alloc_partition

 @Description   Register a new memory partition to the system's memory manager.

                Note that if \c f_UserMalloc and \c f_UserFree are not NULL,
                the system will not manage the partition, but only record
                allocations and de-allocations for debug purposes (providing
                that \c enableDebug is set to '1').

 @Param[in]     partitionId     - Memory partition ID
 @Param[in]     baseAddress     - Base address of memory partition
 @Param[in]     size            - Size (in bytes) of memory partition
 @Param[in]     attributes      - Memory attributes mask (a combination of MEMORY_ATTR_x flags)
 @Param[in]     name            - Memory partition name (up to 32 bytes).
 @Param[in]     f_UserMalloc    - User's memory allocation routine, for bypassing the
                                  default memory manager; Set to NULL for default operation.
 @Param[in]     f_UserFree      - User's memory freeing routine, for bypassing the
                                  default memory manager; Set to NULL for default operation.
 @Param[in]     enableDebug     - '1' to enable memory leaks debug; '0' to disable.

 @Return        Pointer to allocated memory; NULL on failure.
*//***************************************************************************/
int sys_register_phys_addr_alloc_partition(int        partition_id,
		                                   uint64_t  base_paddress,
                                           uint64_t   size,
                                            uint32_t   attributes,
                                            char       name[]);

/**************************************************************************//**
 @Function      sys_register_mem_partition

 @Description   Register a new memory partition to the system's memory manager.

                Note that if \c f_UserMalloc and \c f_UserFree are not NULL,
                the system will not manage the partition, but only record
                allocations and de-allocations for debug purposes (providing
                that \c enableDebug is set to '1').

 @Param[in]     partitionId     - Memory partition ID
 @Param[in]     baseAddress     - Base address of memory partition
 @Param[in]     size            - Size (in bytes) of memory partition
 @Param[in]     attributes      - Memory attributes mask (a combination of MEMORY_ATTR_x flags)
 @Param[in]     name            - Memory partition name (up to 32 bytes).
 @Param[in]     f_UserMalloc    - User's memory allocation routine, for bypassing the
                                  default memory manager; Set to NULL for default operation.
 @Param[in]     f_UserFree      - User's memory freeing routine, for bypassing the
                                  default memory manager; Set to NULL for default operation.

 @Return        Pointer to allocated memory; NULL on failure.
*//***************************************************************************/
int sys_register_mem_partition(int        partition_id,
                                 uintptr_t  base_address,
                                 uint64_t   size,
                                 uint32_t   attributes,
                                 char       name[]);
/**************************************************************************//**
 @Function      SYS_UnregisterMemPartition

 @Description   Unregister a specific memory partition.

                Note that if \c f_UserMalloc and \c f_UserMalloc are not NULL,
                the system will not manage the partition, but only record
                allocations and de-allocations for debug purposes (providing
                that \c enableDebug is set to '1').

 @Param[in]     partitionId     - Memory partition ID

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int sys_unregister_mem_partition(int partition_id);


/**************************************************************************//**
 @Function      sys_get_phys_addr_alloc_partition_info

 @Description   Retrieves memory partition details of a given memory partition.

 @Param[in]     partitionId - Memory partition ID

 @Param[out]    partition_info - Info about given partition.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int sys_get_phys_addr_alloc_partition_info(int partition_id,
                                           t_mem_mng_phys_addr_alloc_info* partition_info);

/**************************************************************************//**
 @Function      sys_get_mem_partition_info

 @Description   Retrieves memory partition details of a given memory partition.

 @Param[in]     partitionId - Memory partition ID

 @Param[out]    partition_info - Info about given partition.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/

int sys_get_mem_partition_info(int partition_id,
                               t_mem_mng_partition_info* partition_info);

/**************************************************************************//**
@Function      sys_get_phys_mem

@Description   Allocates contiguous block of memory with the specified
               alignment and from the specified  memory partition.
@Param[in]     mem_partition_id    Memory partition ID; The value zero must
                                    be mapped to the default heap partition.
@Param[in]     alignment           Required memory alignment (in bytes).
@Param[out]    paddr               A valid allocated physical address if success,
                                   NULL if failure.
@Return        0                   on success,
               -ENOMEM (not enough memory to allocate)or
               -EINVAL ( invalid memory partition ) on failure.
*//***************************************************************************/
int sys_get_phys_mem(uint64_t size, int mem_partition_id,  uint64_t alignment,
                uint64_t* paddr);

/**************************************************************************//**
@Function     sys_put_phys_mem

@Description   Frees the memory block pointed to by "paddr".
               paddr should be allocated by fsl_get_mem()

@Param[in]    paddr  An address to be freed.

*//***************************************************************************/
void  sys_put_phys_mem(uint64_t paddr);

int sys_mem_exists(int mem_partition_id);
uint64_t sys_mem_size(int mem_partition_id);

void  sys_mem_partitions_init_complete();
/** @} */ /* end of sys_mem_grp */
/** @} */ /* end of sys_grp */



/* These values are calculated in dpmng.c */
extern uint64_t dpaa_sys_ddr_base;
extern uint64_t dpaa_sys_ddr_size;
/* second ddr partition created when MC mem size >= 1GB or/and
 the dpc 'mc_sys_ddr_start_address' property exists. */
extern uint64_t mc_sysddr2_ph_base;
extern uint64_t mc_sys_ddr2_size;
extern uintptr_t mc_sys_ddr2_virt_add_base;

/**************************************************************************//**
 @Description  MEM_PART_SYSTEM_DDR1_CACHEABLE virtual address offset
*//***************************************************************************/
extern uint32_t g_system_ddr1_cacheable_offset;

/**************************************************************************//**
 @Description  MEM_PART_SYSTEM_DDR1_CACHEABLE  size
*//***************************************************************************/
extern uint32_t g_system_ddr1_cacheable_size;

/**************************************************************************//**
 @Description  MEM_PART_SYSTEM_DDR1_NON_CACHEABLE virtual address offset
*//***************************************************************************/
extern uint32_t g_system_ddr1_non_cacheable_offset;

/**************************************************************************//**
 @Description  MEM_PART_SYSTEM_DDR1_NON_CACHEABLE size
*//***************************************************************************/
extern uint32_t g_system_ddr1_non_cacheable_size;

#define MEM_MNG_LOGGER_PART_NAME "MC-Logger"
#define MEM_MNG_BOOT_MEM_MANAG_NAME "BOOT MEMORY MANAGER"
#define MEM_MNG_DDR_NON_CACHEABLE_NAME "MC DDR #1 non-cacheable"
#define MEM_MNG_DDR_CACHEABLE_NAME "MC DDR #1 cacheable"
#define MEM_MNG_SYS_DDR_NAME "DDR #1"
#define MEM_MNG_SYS_DDR2_NAME "DDR #2"
#define MEM_MNG_DMEM_NAME "DMEM"
#define MEM_MNG_DMEM1_NAME "DMEM1"
#define MEM_MNG_DMEM2_NAME "DMEM2"
#define MEM_MNG_PEB_NAME "PEB"
#define MEM_MNG_DPDDR_NAME  "DP-DDR"

extern const  uint32_t g_boot_mem_mng_size;
#define MEM_PART_SYSTEM_DDR1_BOOT_MEM_MNG (MEM_PART_LAST+1)

#define	LOG_DDR_ADDR			0x01000000
#define	LOG_DMEM_ADDR			0x20017000

#ifdef SYS_SMP_SUPPORT
#define  MEMORY_ATTR_BOOT_MEM_MNG	MEMORY_ATTR_NON_CACHEABLE
#else
#define  MEMORY_ATTR_BOOT_MEM_MNG	MEMORY_ATTR_CACHEABLE
#endif

#define MEMORY_PARTITIONS\
{   /* Memory partition ID                Phys. Addr. Virt. Addr.  Size  Attributes Name           */\
    {MEM_PART_LOGGER,                     0xFFFFFFFF, LOG_DDR_ADDR,16*MEGABYTE,\
        MEMORY_ATTR_NON_CACHEABLE,MEM_MNG_LOGGER_PART_NAME},\
    {MEM_PART_SYSTEM_DDR1_BOOT_MEM_MNG,   0xFFFFFFFF, g_boot_mem_mng_offset, g_boot_mem_mng_size,\
        MEMORY_ATTR_BOOT_MEM_MNG, MEM_MNG_BOOT_MEM_MANAG_NAME},\
    {MEM_PART_SYSTEM_DDR1_NON_CACHEABLE,  0xFFFFFFFF, g_system_ddr1_non_cacheable_offset , g_system_ddr1_non_cacheable_size,\
        MEMORY_ATTR_NON_CACHEABLE|MEMORY_ATTR_MALLOCABLE, MEM_MNG_DDR_NON_CACHEABLE_NAME},\
    {MEM_PART_SYSTEM_DDR1_CACHEABLE,      0xFFFFFFFF, g_system_ddr1_cacheable_offset,g_system_ddr1_cacheable_size,\
        MEMORY_ATTR_CACHEABLE|MEMORY_ATTR_MALLOCABLE,MEM_MNG_DDR_CACHEABLE_NAME},\
    {MEM_PART_SYSTEM_DDR1,                dpaa_sys_ddr_base, 0xFFFFFFFF, dpaa_sys_ddr_size,\
        MEMORY_ATTR_PHYS_ALLOCATION,MEM_MNG_SYS_DDR_NAME},\
    {MEM_PART_DMEM1,                       0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF,\
        MEMORY_ATTR_NON_CACHEABLE|MEMORY_ATTR_MALLOCABLE,MEM_MNG_DMEM1_NAME},\
    {MEM_PART_DMEM2,                       0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF,\
        MEMORY_ATTR_NON_CACHEABLE|MEMORY_ATTR_MALLOCABLE,MEM_MNG_DMEM2_NAME},\
    {MEM_PART_PEB,                        0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF,\
        MEMORY_ATTR_PHYS_ALLOCATION,                          MEM_MNG_PEB_NAME},\
    {MEM_PART_DP_DDR,                     0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF,\
        MEMORY_ATTR_PHYS_ALLOCATION,                          MEM_MNG_DPDDR_NAME},\
    {MEM_PART_SYSTEM_DDR2, 0xFFFFFFFF, 0xFFFFFFFF, 0,\
        MEMORY_ATTR_PHYS_ALLOCATION , MEM_MNG_SYS_DDR2_NAME},\
}

static int get_partition_name(int part_id,
                              char* part_name,
                              const uint32_t name_length)
{
    switch(part_id)
    {
        case MEM_PART_LOGGER:
            strncpy(part_name,MEM_MNG_LOGGER_PART_NAME,name_length);
            break;
        case MEM_PART_SYSTEM_DDR1_NON_CACHEABLE:
            strncpy(part_name,MEM_MNG_DDR_NON_CACHEABLE_NAME,name_length);
            break;
        case  MEM_PART_SYSTEM_DDR1_CACHEABLE:
            strncpy(part_name,MEM_MNG_DDR_CACHEABLE_NAME,name_length);
            break;
        case  MEM_PART_SYSTEM_DDR1:
            strncpy(part_name,MEM_MNG_SYS_DDR_NAME,name_length);
            break;
        case  MEM_PART_SYSTEM_DDR2:
            strncpy(part_name,MEM_MNG_SYS_DDR2_NAME,name_length);
            break;
        case MEM_PART_DMEM:
            strncpy(part_name,MEM_MNG_DMEM_NAME,name_length);
            break;
        case MEM_PART_DMEM1:
           strncpy(part_name,MEM_MNG_DMEM1_NAME,name_length);
           break;
        case MEM_PART_DMEM2:
	   strncpy(part_name,MEM_MNG_DMEM2_NAME,name_length);
	   break;
        case MEM_PART_PEB:
            strncpy(part_name,MEM_MNG_PEB_NAME,name_length);
            break;
        case MEM_PART_DP_DDR:
            strncpy(part_name,MEM_MNG_DPDDR_NAME,name_length);
            break;
        default:
            strncpy(part_name,"unknown",name_length);
    }
    return 0;
}

int boot_get_mem(struct initial_mem_mng* boot_mem_mng,
                 const uint64_t size,uint64_t* paddr);

int boot_get_mem_virt(struct initial_mem_mng* boot_mem_mng,
                      const uint64_t size,uint32_t* vaddr);

#ifdef MEM_MNG_COUNT_ALLOC

/* flag used to enable allocation/deallocation counter*/
#define MC_MISC_MM_ALLOC_CHECK_COUNTERS	(1<<0)
/* flag used to enable recording of allocations*/
#define MC_MISC_MM_ALLOC_ENABLE_REC_INFO	(1<<1)

	void sys_mem_mng_set_alloc_flags(uint32_t flags);
	void sys_mem_mng_check_alloc(int32_t *cnt);
#endif //MEM_MNG_COUNT_ALLOC
	
void sys_mem_mng_print_alloc_info();

#endif /* __SYS_MEM_MNG_H */
