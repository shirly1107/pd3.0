/*
 * Copyright 2013 Freescale Semiconductor, Inc.
 * Copyright 2014-2020 NXP
 */

/**************************************************************************//**
 @File          fsl_cmdif.h

 @Description
 *//***************************************************************************/

#ifndef __FSL_CMDIF_H
#define __FSL_CMDIF_H

/*!
 * @Group grp_cmdif	Command Interface API
 *
 * @brief	Contains API for Command Interface
 * @{
 */

/**
 * @brief	Command interface descriptor
 */
#if 0
struct cmdif_desc {
	void *regs;
	/*!<
	 * Pointer to command interface registers (virtual address);
	 * Must be set by the user
	 */
	void *dev;
	/*!<
	 * Opaque handle for the use of the command interface;
	 * user should not modify it.
	 */
	void *lock;
	/*!<
	 * Optional lock object to be used with the lock/unlock callbacks;
	 * user must zero it if not needed.
	 */
	void (*lock_cb)(void *lock);
	/*!<
	 * Callback for locking the command interface (multi-user scenario);
	 * user must zero it if not needed.
	 */
	void (*unlock_cb)(void *lock);
	/*!<
	 * Callback for unlocking the command interface (multi-user scenario);
	 * user must zero it if not needed.
	 */
};
#endif

enum cmdif_module {
	CMDIF_MOD_DPRC = 0,
	CMDIF_MOD_DPNI,
	CMDIF_MOD_DPMAC,
	CMDIF_MOD_DPIO,
	CMDIF_MOD_DPBP,
	CMDIF_MOD_DPSW,
	CMDIF_MOD_DPDMUX,
	CMDIF_MOD_DPCON,
	CMDIF_MOD_DPCI,
	CMDIF_MOD_DPSECI,
	CMDIF_MOD_DPDCEI,
	CMDIF_MOD_DPDMAI,
	CMDIF_MOD_DPAIOP,
	CMDIF_MOD_DPMCP,
	CMDIF_MOD_DPDBG,
	CMDIF_MOD_DPRTC,
	CMDIF_MOD_DPSPARSER,
	CMDIF_MOD_MODULES_NUM
};

#define CMDIF_PRI_LOW		0 /*!< Low Priority command indication */
#define CMDIF_PRI_HIGH		1 /*!< High Priority command indication */

/**************************************************************************//**
 @Group         cmdif_server_g  Command Interface - Server API

 @Description

 @{
 *//***************************************************************************/

/**************************************************************************//**
 @Description
 *//***************************************************************************/
/**************************************************************************//**
 @Description    Open callback.

 User provides this function. Driver invokes it when it gets establish instance command.

 @Param[in]     handle      - device handle.
 @Param[in]     cmdif_cmd   - pointer to the init command, should include all that needed for initialization of a module:
 icid, ports,etc..
 @Return        Handle to instance object, or NULL for Failure.
 *//***************************************************************************/
typedef int (open_cb)(void *dev, int portal_id);

/**************************************************************************//**
 @Description   De-init callback.

 User provides this function. Driver invokes it when it gets
 terminate instance command.

 @Param[in]     dev         A handle of the device.

 @Return        OK on success; error code, otherwise.
 *//***************************************************************************/
typedef int (close_cb)(void *dev, int portal_id, uint32_t token);

/**************************************************************************//**
 @Description   Control callback.

 User provides this function. Driver invokes it for all runtime commands

 @Param[in]     dev          A handle of the device.
 @Param[in]     cmd_ver     Command version
 @Param[in]     cmd_code
 @Param[in]     size
 @Param[in]     desc        A pointer of the command

 @Return        OK on success; error code, otherwise.
 *//***************************************************************************/
typedef int (ctrl_cb)(void *dev, uint8_t cmd_ver, uint16_t cmd_code, int portal_id, uint8_t *data);

/**************************************************************************//**
 @Description   is this command high priority callback.

 User provides this function. Driver invokes it for all runtime commands
 command can be high priority only if it doesn't use cpu_sleep

 @Param[in]     dev         A handle of the device.
 @Param[in]     cmd_code    

 @Return        1 if high priority command; 0 otherwise.
 *//***************************************************************************/
typedef int (cmd_priority_cb)(void *dev, uint16_t cmd);
/**************************************************************************//**
 @Description
 *//***************************************************************************/
struct cmdif_module_ops {
	open_cb *open_cb;
	close_cb *close_cb;
	ctrl_cb *ctrl_cb;
	cmd_priority_cb *cmd_priority_cb;
};

/**************************************************************************//**
 @Function      cmdif_register_module

 @Description   registration of a module to the command portal.

 Each module needs to register to the command interface by
 supplying the following:

 @Param[in]     module_id  	module ID
 @Param[in]     ops     	A structure with 3 callbacks decscribed below for open,
 close and control

 @Return        0 on success; error code, otherwise.
 *//***************************************************************************/
int cmdif_register_module(enum cmdif_module module,
                          struct cmdif_module_ops *ops);

#if 0
/**************************************************************************//**
 @Function      cmdif_unregister_module

 @Description   cancel the registration of a module to the command portal.

 Each module needs to unregister from the command interface

 @Param[in]     module_id  	module ID

 @Return        0 on success; error code, otherwise.
 *//***************************************************************************/
int cmdif_unregister_module(enum cmdif_module module);
#endif

/**************************************************************************//**
 @Function      cmdif_close_dev

 @Description   Used by resman to remove all portals for a specific device.


 @Param[in]     dev  	device ID

 @Return        0 on success; error code, otherwise.
 *//***************************************************************************/
int cmdif_close_dev(void *dev, int Portal_id);

/**************************************************************************//**
 @Function      cmdif_reset_portal_ctrl_cb

 @Description   Used by dpmng to remove all devices for a specific portal.


 @Param[in]     dev  	device ID
 @Param[in]     data    command params- param 0 will include the portal index

 @Return        0 on success; error code, otherwise.
 *//***************************************************************************/
int cmdif_reset_portal_ctrl_cb(void *dpmcp, int portal_id);


/** @} *//* end of cmdif_server_g group */

#if 0
/**************************************************************************//**
 @Group         cmdif_client_g  Command Interface - Client API

 @Description

 @{
 *//***************************************************************************/
int cmdif_create(struct cmdif_desc *cidesc,
                 enum cmdif_module module,
                 int size,
                 uint8_t *cmd_data);

int cmdif_open(struct cmdif_desc *cidesc,
               enum cmdif_module module,
	int size,
	uint8_t *cmd_data,
	uint32_t options);

int cmdif_close(struct cmdif_desc *cidesc);

int cmdif_send(struct cmdif_desc *cidesc,
               uint16_t cmd_id,
               int size,
               int priority,
               uint8_t *cmd_data);

#if 1
int cmdif_get_cmd_data(struct cmdif_desc *cidesc, uint8_t **cmd_data);
#endif

/** @} *//* end of grp_cmdif group */
#endif

/** @} *//* end of grp_cmdif */

#endif /* __FSL_CMDIF_H */
