/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "kernel/fsl_spinlock.h"
#include "fsl_intr_mng.h"
#include "fsl_system.h"

#define INTR_CTRL_SRC(_intr_src) \
    ((int)((_intr_src) & ~(SYS_INTR_CTRL_ID_MASK)))


int     sys_init_interrupt_management(void);
int     sys_free_interrupt_management(void);

int sys_init_interrupt_management(void)
{
    spin_lock_init(&(sys.intr_mng_lock));

    return 0;
}

int sys_free_interrupt_management(void)
{
    /* Nothing to do for now */
    return 0;
}

int sys_register_intr_controller(void * h_intr_ctrl,
                                   int  (*f_set_intr)(void * h_intr_ctrl, int intr_src, isr_t *f_isr, void * handle),
                                   int  (*f_free_intr)(void * h_intr_ctrl, int intr_src),
                                   int  (*f_enable_intr)(void * h_intr_ctrl, int intr_src),
                                   int  (*f_disable_intr)(void * h_intr_ctrl, int intr_src),
                                   int      *p_intr_id_base)
{
    int i;

    if(!p_intr_id_base) {
    	pr_crit("Null pointer");
    	return -ENODEV;
    }

    if (!h_intr_ctrl)
    {
        pr_err("no device: interrupt controller handle\n");
        return -ENODEV;
    }

    /* Find a free entry */
    for (i=0; i < SYS_MAX_INTR_CONTROLLERS; i++)
    {
        if (!sys.intr_ctrl_info[i].h_intr_ctrl)
        {
            sys.intr_ctrl_info[i].h_intr_ctrl = h_intr_ctrl;
            sys.intr_ctrl_info[i].f_set_intr = f_set_intr;
            sys.intr_ctrl_info[i].f_free_intr = f_free_intr;
            sys.intr_ctrl_info[i].f_enable_intr = f_enable_intr;
            sys.intr_ctrl_info[i].f_disable_intr = f_disable_intr;

            *p_intr_id_base = (i << SYS_INTR_CTRL_ID_SHIFT);

            return 0;
        }
    }

    pr_err("Resource not available: interrupt controllers registry\n");
    return -ENAVAIL;
    
}

int sys_unregister_intr_controller(void * h_intr_ctrl)
{
    int i;

    if (!h_intr_ctrl)
    {
        pr_err("no device: interrupt controller handle\n");
        return -ENODEV;
    }

    for (i=0; i < SYS_MAX_INTR_CONTROLLERS; i++)
    {
        if (sys.intr_ctrl_info[i].h_intr_ctrl == h_intr_ctrl)
        {
            /* Mark this entry as free */
            sys.intr_ctrl_info[i].h_intr_ctrl = NULL;

            return 0;
        }
    }

    pr_err("Resource not available: interrupt controller\n");
    return -ENAVAIL;
}

int sys_set_intr(int intr_id, isr_t *f_isr, void * handle)
{
    void *    h_intr_ctrl;
    int         intr_ctrl_id = (intr_id >> SYS_INTR_CTRL_ID_SHIFT);
    uint32_t    int_flags;
    int     err_code;

    h_intr_ctrl = sys.intr_ctrl_info[intr_ctrl_id].h_intr_ctrl;

    if (!h_intr_ctrl)
    {
        pr_err("No such device: interrupt source\n");
        return -ENODEV;
    }

    ASSERT_COND(sys.intr_ctrl_info[intr_ctrl_id].f_set_intr);

    int_flags = sys_lock_intr_spinlock(&(sys.intr_mng_lock));

    err_code = sys.intr_ctrl_info[intr_ctrl_id].f_set_intr(h_intr_ctrl,
                                                     INTR_CTRL_SRC(intr_id),
                                                     f_isr,
                                                     handle);

    sys_unlock_intr_spinlock(&(sys.intr_mng_lock), int_flags);
    return err_code;
}

int sys_free_intr(int intr_id)
{
    void *    h_intr_ctrl;
    int         intr_ctrl_id = (intr_id >> SYS_INTR_CTRL_ID_SHIFT);
    uint32_t    int_flags;
    int     err_code;

    h_intr_ctrl = sys.intr_ctrl_info[intr_ctrl_id].h_intr_ctrl;

    if (!h_intr_ctrl)
    {
        pr_err("No such device: interrupt source\n");
        return -ENODEV;
    }

    ASSERT_COND(sys.intr_ctrl_info[intr_ctrl_id].f_free_intr);

    int_flags = sys_lock_intr_spinlock(&(sys.intr_mng_lock));

    err_code = sys.intr_ctrl_info[intr_ctrl_id].f_free_intr(h_intr_ctrl, INTR_CTRL_SRC(intr_id));

    sys_unlock_intr_spinlock(&(sys.intr_mng_lock), int_flags);
    return err_code;
}

int sys_enable_intr(int intr_id)
{
    void *    h_intr_ctrl;
    int         intr_ctrl_id = (intr_id >> SYS_INTR_CTRL_ID_SHIFT);
    uint32_t    int_flags;
    int     err_code;

    h_intr_ctrl = sys.intr_ctrl_info[intr_ctrl_id].h_intr_ctrl;

    if (!h_intr_ctrl)
    {
        pr_err("No such device: interrupt source\n");
        return -ENODEV;
    }

    ASSERT_COND(sys.intr_ctrl_info[intr_ctrl_id].f_enable_intr);

    int_flags = sys_lock_intr_spinlock(&(sys.intr_mng_lock));

    err_code = sys.intr_ctrl_info[intr_ctrl_id].f_enable_intr(h_intr_ctrl, INTR_CTRL_SRC(intr_id));

    sys_unlock_intr_spinlock(&(sys.intr_mng_lock), int_flags);
    return err_code;
}

int sys_disable_intr(int intr_id)
{
    void *    h_intr_ctrl;
    int         intr_ctrl_id = (intr_id >> SYS_INTR_CTRL_ID_SHIFT);
    uint32_t    int_flags;
    int     err_code;

    h_intr_ctrl = sys.intr_ctrl_info[intr_ctrl_id].h_intr_ctrl;

    if (!h_intr_ctrl)
    {
        pr_err("No such device: interrupt source\n");
        return -ENODEV;
    }

    ASSERT_COND(sys.intr_ctrl_info[intr_ctrl_id].f_disable_intr);

    int_flags = sys_lock_intr_spinlock(&(sys.intr_mng_lock));

    err_code = sys.intr_ctrl_info[intr_ctrl_id].f_disable_intr(h_intr_ctrl, INTR_CTRL_SRC(intr_id));

    sys_unlock_intr_spinlock(&(sys.intr_mng_lock), int_flags);
    return err_code;
}
