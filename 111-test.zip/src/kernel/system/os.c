/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_malloc.h"
#include "common/fsl_stdarg.h"
#include "kernel/fsl_spinlock.h"
#include "fsl_timer.h"
#include "fsl_irq.h"
#include "fsl_io.h"
#include "fsl_smp.h"
#include "fsl_dbg.h"
#include "fsl_platform.h"

#include "fsl_console.h"
#include "fsl_mem_mng.h"
#include "fsl_intr_mng.h"
#include "fsl_timer.h"
#include "fsl_mem_mng.h"

#define __ERR_MODULE__ MODULE_UNKNOWN

#define MAX_UDELAY   50000000

#define BUF_SIZE    1024

void fsl_print(char *format, ...)
{
    va_list args;
    char    tmp_buf[BUF_SIZE];

    memset(&args, 0, sizeof(args));
    va_start(args, format);

    vsnprintf (tmp_buf, BUF_SIZE, format, args);
    va_end(args);

    sys_print(tmp_buf, SYS_PRINT_TO_CONSOLE_DEVICE|SYS_PRINT_TO_LOG_BUFFER);
}

/*****************************************************************************/
/*                        Spinlock Service Routines                          */
/*****************************************************************************/
spinlock_t spin_lock_create(void)
{
#ifdef SYS_SMP_SUPPORT
    struct spinlock *p_spinlock = (struct spinlock *)fsl_malloc(sizeof(struct spinlock));
    if (!p_spinlock)
    {
        pr_err("spinlock structure");
        return NULL;
    }
    sys_init_spinlock(p_spinlock);

    return p_spinlock;
#else
    return (spinlock_t)(-1);
#endif
}

void spin_lock_init(spinlock_t lock)
{
	ASSERT_COND(lock);
    sys_init_spinlock((struct spinlock *)lock);
}

void spin_lock_free(spinlock_t lock)
{
#ifdef SYS_SMP_SUPPORT
    if (lock)
        fsl_free(lock);
#else
    UNUSED(lock);
#endif
}

void spin_lock(spinlock_t lock)
{
	ASSERT_COND(lock);
    sys_lock_spinlock((struct spinlock *)lock);
}

void spin_unlock(spinlock_t lock)
{
	ASSERT_COND(lock);
    sys_unlock_spinlock((struct spinlock *)lock);
}

uint32_t spin_lock_irqsave(spinlock_t lock)
{
	ASSERT_COND(lock);
    return sys_lock_intr_spinlock((struct spinlock *)lock);
}

void spin_unlock_irqrestore(spinlock_t lock, uint32_t irq_flags)
{
	ASSERT_COND(lock);
    sys_unlock_intr_spinlock((struct spinlock *)lock, irq_flags);
}

/*****************************************************************************/
#ifdef MEM_MNG_REC_ALLOC_INFO
void * fsl_malloc_dbg(size_t size, const char *info,
		const char *filename, int line)
#else
void * fsl_malloc(size_t size)
#endif //MEM_MNG_REC_ALLOC_INFO
{
	/*
	* Due to change the default alignment value from one to value of cache line
	* many buffers are generated in the memory manager and the fsl_malloc is slow
	* after many calls.
	*
	* A temporary workaround to reduce the number of buffers is: to force
	* the value of size to be multiple of the value of core cache line.
	* */
    if (!IS_ALIGNED(size, CORE_CACHELINE_SIZE))
        size = ALIGN_UP(size, CORE_CACHELINE_SIZE);

    /* Set default alignment to a value of core cache line to prevent
    * different structures in cacheable memory partition to be located in the
    * same cache line.
    * */
#ifdef MEM_MNG_REC_ALLOC_INFO
    return sys_mem_alloc(SYS_DEFAULT_HEAP_PARTITION,
                size,
                CORE_CACHELINE_SIZE/*alignment*/,
                info /* info */,
                filename,
                line);
#else
    return sys_mem_alloc(SYS_DEFAULT_HEAP_PARTITION,
                size,
                CORE_CACHELINE_SIZE/*alignment*/,
                "" /* info */,
                "",
                -1);
#endif //MEM_MNG_REC_ALLOC_INFO
}

/*****************************************************************************/
#ifdef MEM_MNG_REC_ALLOC_INFO
void * fsl_xmalloc_dbg(size_t size, int partition_id, uint32_t alignment,
		const char *info, const char *filename, int line)
#else
void * fsl_xmalloc(size_t size, int partition_id, uint32_t alignment)
#endif //MEM_MNG_REC_ALLOC_INFO
{
#ifdef MEM_MNG_REC_ALLOC_INFO
    return sys_mem_alloc(partition_id, size, alignment, info, filename, line);
#else
    return sys_mem_alloc(partition_id, size, alignment, "", "", -1);
#endif //MEM_MNG_REC_ALLOC_INFO
}

int fsl_get_mem(uint64_t size, int mem_partition_id, uint64_t alignment,
                   uint64_t* paddr)
{
	return sys_get_phys_mem(size, mem_partition_id, alignment,paddr);
}

int fsl_get_mem_mp(uint64_t size,
				const struct memory_partition_list* mem_partitions,
				uint64_t alignment,
				uint64_t* paddr)
{
	int err = -EINVAL;
	int mem_partition_id = 0;
	int show_message = 0;
	*paddr = ILLEGAL_BASE;
	if (!mem_partitions)
		return -EINVAL;
	for (int idx = 0; idx < MEM_PART_LAST && err; idx++) {
		mem_partition_id = mem_partitions->mem_part_ids[idx];
		// check if we reach the end of the list
		if (!VALID_FSL_GET_MEM_PARTITION(mem_partition_id))
			break;
		// check if the partition exists in current SoC configuration
		if (sys_mem_exists(mem_partition_id)) {
			if( show_message && will_log(NO_ID, LOG_LEVEL_ERROR) ) {
				fsl_print("MEM: retry to allocate 0x%x%08x/0x%x (bytes/alignment) from memory partition id %d\n",
						(uint32_t)(size >> 32), (uint32_t)(size),
						(uint32_t)(alignment >> 32), (uint32_t)(alignment),
						mem_partition_id);
			}
			err = sys_get_phys_mem(size, mem_partition_id, alignment, paddr);
			if( err ) {
				pr_err("MEM: Failed to allocate 0x%x%08x/0x%x (bytes/alignment) from memory partition id %d. "
					   "The system will attempt to allocate using next partition from list.\n",
						(uint32_t)(size >> 32), (uint32_t)(size),
						(uint32_t)(alignment >> 32), (uint32_t)(alignment), mem_partition_id);
				show_message = 1;
			}
			else if ( show_message && will_log(NO_ID, LOG_LEVEL_ERROR) ) {
				fsl_print("MEM: successful allocated 0x%x%08x/0x%x (bytes/alignment) from memory partition id %d\n",
						(uint32_t)(size >> 32), (uint32_t)(size),
						(uint32_t)(alignment >> 32), (uint32_t)(alignment),
						mem_partition_id);
			}
		}
	}

	CHECK_COND_RETVAL(err==0, err, "No more partitions available. Failed to allocate memory.\n");
	return err;
}

void fsl_put_mem(uint64_t paddr)
{
    sys_put_phys_mem(paddr);
}

void fsl_free(void *p_memory)
{
    sys_mem_free(p_memory);
}

void fsl_xfree(void *p_memory)
{
    sys_mem_xfree(p_memory);
}

void * fsl_phys_to_virt(phys_addr_t addr)
{
    return sys_phys_to_virt(addr);
}

phys_addr_t fsl_virt_to_phys(void *addr)
{
    return sys_virt_to_phys(addr);
}

int fsl_mem_exists(int mem_partition_id)
{
    return sys_mem_exists(mem_partition_id);
}

/*****************************************************************************/
/*                          IRQ Service Routines                             */
/*****************************************************************************/

int fsl_set_irq(int irq, isr_t *f_isr, void * handle)
{
    return sys_set_intr(irq, f_isr, handle);
}

int fsl_free_irq(int irq)
{
    return sys_free_intr(irq);
}

int fsl_enable_irq(int irq)
{
    return sys_enable_intr(irq);
}

int fsl_disable_irq(int irq)
{
    return sys_disable_intr(irq);
}
