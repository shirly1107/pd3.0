/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "common/fsl_stdarg.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_smp.h"
#include "fsl_console.h"

#include "fsl_system.h"

#define __ERR_MODULE__  MODULE_UNKNOWN

#define SYS_BOOT_SYNC_FLAG_WAITING  	1
#define SYS_BOOT_SYNC_FLAG_DONE     	2

/* Global System Object */
t_system sys;
char pre_console_buf[INTG_MAX_NUM_OF_CORES][PRE_CONSOLE_BUF_SIZE];

extern void     __sys_start(register int argc, register char **argv, register char **envp);
extern void     __sys_start_secondary(void);
extern int     fill_system_parameters(t_sys_param *sys_param);
extern int     sys_init_memory_management(void);
extern int     sys_free_memory_management(void);
extern int     sys_init_interrupt_management(void);
extern int     sys_free_interrupt_management(void);
extern int     sys_init_multi_processing(void);
extern void    sys_free_multi_processing(void);

typedef struct t_sys_forced_object {
	enum fsl_module  module;
	int                  num_of_ids;
	int                  id[SYS_MAX_NUM_OF_MODULE_IDS];
	void *        h_module;
	list_t              node;
} t_sys_forced_object_desc;

static void sys_init_objects_registry(void)
{
	//memset(sys.modules_info, 0, sizeof(sys.modules_info));
	//memset(sys.sub_modules_info, 0, sizeof(sys.sub_modules_info));
	INIT_LIST(&(sys.forced_objects_list));

	//sys_init_spinlock(&sys.object_mng_lock);
}

static void sys_free_objects_management(void)
{
	t_sys_forced_object_desc   *p_forced_object;
	list_t                  *p_node, *p_temp;

	/* Freeing all network devices descriptors */
	LIST_FOR_EACH_SAFE(p_node, p_temp, &(sys.forced_objects_list)) {
		p_forced_object = LIST_OBJECT(p_node, t_sys_forced_object_desc,
		                              node);

		list_del(p_node);
		fsl_free(p_forced_object);
	}

#if 0
	/* Free the settings cloning information */
	if (sys.p_clone_scratch_pad)
		fsl_free(sys.p_clone_scratch_pad);
#endif
}

void * sys_get_handle(enum fsl_module module, int num_of_ids, ... )
{
	t_sys_forced_object_desc   *p_forced_object;
	va_list                    arguments; /*store the list of arguments*/
	list_t                  *p_node;
	int                        ids[SYS_MAX_NUM_OF_MODULE_IDS];
	int                        i;
	ASSERT_COND(num_of_ids <= SYS_MAX_NUM_OF_MODULE_IDS && num_of_ids > 0);
	ASSERT_COND(sys.forced_objects_list.next &&
	            sys.forced_objects_list.prev);

	va_start(arguments, num_of_ids); /*initializing va arguments*/
	for(i = 0; (i < num_of_ids) && (i < SYS_MAX_NUM_OF_MODULE_IDS); i++){
		ids[i] = va_arg(arguments, int);
	}
	va_end(arguments);

	/* If id equals SYS_NULL_OBJECT_ID, we must return NULL */
	/* Search in the forced objects list. This list usually serves for*/
	/*storing specific objects that were initialized by the platform. */
	LIST_FOR_EACH(p_node, &(sys.forced_objects_list)) {
		p_forced_object = LIST_OBJECT(p_node,
		                              t_sys_forced_object_desc, node);

		if ((p_forced_object->module == module) &&
			(p_forced_object->num_of_ids == num_of_ids)) {
			for(i = 0; i < p_forced_object->num_of_ids; i++)
				if (p_forced_object->id[i] != ids[i])
					break;

			if (i == p_forced_object->num_of_ids)
				return p_forced_object->h_module;
		}
	}

	return NULL;
}

int sys_add_handle(void * h_module, enum fsl_module module,
                   int num_of_ids, ... )
{
	t_sys_forced_object_desc   *p_forced_object;
	int                        id;
	int                        i;
	va_list                    arguments;   /*store the list of arguments*/

	ASSERT_COND(num_of_ids <= SYS_MAX_NUM_OF_MODULE_IDS && num_of_ids > 0);
	ASSERT_COND((sys.forced_objects_list.next &&
		sys.forced_objects_list.prev) ||
		(!sys.forced_objects_list.next &&
			!sys.forced_objects_list.prev));

	if (!sys.forced_objects_list.next)
		INIT_LIST(&sys.forced_objects_list);


	p_forced_object = (t_sys_forced_object_desc *)fsl_malloc(
		sizeof(t_sys_forced_object_desc));
	if (!p_forced_object) {
		pr_err("no memory creating forced object descriptor\n");
		return ENOMEM;
	}

	va_start(arguments, num_of_ids); /*initializing va arguments*/
	p_forced_object->num_of_ids = num_of_ids;
	for(i = 0; i < num_of_ids; i++) {
		id = va_arg(arguments, int);
		p_forced_object->id[i] = id;
	}
	va_end(arguments);
	p_forced_object->module = module;
	p_forced_object->h_module = h_module;
	INIT_LIST(&(p_forced_object->node));
	list_add_to_tail(&(p_forced_object->node), &(sys.forced_objects_list));

	return 0;
}

int sys_remove_handle(enum fsl_module module, int num_of_ids, ... )
{
	t_sys_forced_object_desc   *p_forced_object;
	int                        ids[SYS_MAX_NUM_OF_MODULE_IDS];
	int                        i;
	va_list                    arguments;/*store the list of arguments*/
	list_t                     *p_node;

	ASSERT_COND(num_of_ids <= SYS_MAX_NUM_OF_MODULE_IDS && num_of_ids > 0);
	ASSERT_COND(sys.forced_objects_list.next &&
	            sys.forced_objects_list.prev);/*no handle available at all*/

	/*build handle node to be removed from forced object list */
	va_start(arguments, num_of_ids); /*initializing va arguments*/
	for(i = 0; i < num_of_ids; i++) {
		ids[i] = va_arg(arguments, int);
	}
	va_end(arguments);

	LIST_FOR_EACH(p_node, &(sys.forced_objects_list)) {
		p_forced_object = LIST_OBJECT(p_node,
		                              t_sys_forced_object_desc, node);

		if ((p_forced_object->module == module)  &&
			(p_forced_object->num_of_ids == num_of_ids)){
			for(i = 0; i < p_forced_object->num_of_ids; i++)
				if (p_forced_object->id[i] != ids[i])
					break;

			if (i == p_forced_object->num_of_ids){
				list_del(&(p_forced_object->node));
				fsl_free(p_forced_object);
				return 0;
			}
		}
	}
	return EAGAIN;
}

static int sys_init_platform(struct platform_param *platform_param)
{
	int i, err = 0;
	int is_master_core = sys_is_master_core();

	if (is_master_core) {
		err = platform_init(platform_param, &(sys.platform_ops));
		if (err != 0) return err;

		ASSERT_COND(sys.platform_ops.h_platform);

		err = sys_add_handle(sys.platform_ops.h_platform,
		                     FSL_MOD_SOC, 1, 0);
		if (err != 0) return err;
	}

	sys_barrier();

	if (sys.platform_ops.f_disable_local_irq)
		sys.platform_ops.f_disable_local_irq(sys.platform_ops.h_platform);

	for (i = 0; i < PLTFORM_NUM_OF_INIT_MODULES ; i++)
	{
		if (sys.platform_ops.modules[i].init)
		{
			if(sys.platform_ops.modules[i].is_single_core)
			{
				if(is_master_core)
				{
					err = sys.platform_ops.modules[i].init(
							sys.platform_ops.h_platform);
					if(err) return err;
				}
			}
			else
			{
				err = sys.platform_ops.modules[i].init(
						sys.platform_ops.h_platform);
				if(err) return err;
			}
			
			sys_barrier();
		}
	}

	if (sys.platform_ops.f_enable_local_irq)
		sys.platform_ops.f_enable_local_irq(sys.platform_ops.h_platform);

	return 0;
}

static int sys_free_platform(void)
{
	int i, err = 0;
	int is_master_core = sys_is_master_core();

	for (i = PLTFORM_NUM_OF_INIT_MODULES-1; i >= 0 ; i--)
	{
		if (sys.platform_ops.modules[i].free)
		{
			if(sys.platform_ops.modules[i].is_single_core)
			{
				if(is_master_core)
				{
					err = sys.platform_ops.modules[i].free(
							sys.platform_ops.h_platform);
					if(err) return err;
				}
			}
			else
			{
				err = sys.platform_ops.modules[i].free(
						sys.platform_ops.h_platform);
				if(err) return err;
			}
			
			sys_barrier();
		}
	}
	
	if (is_master_core) {
		err = platform_free(sys.platform_ops.h_platform);
		sys.platform_ops.h_platform = NULL;
	}

	sys_barrier();

	return err;
}

static uint32_t count_cores(uint64_t cores_mask)
{
    uint32_t count;
    for(count = 0; cores_mask > 0; cores_mask >>= 1) {
	if(cores_mask & 1 == 1)
	    count ++;
    }

    return count;
}

int sys_early_init()
{
	return platform_early_init();

}

int sys_init(void)
{
	t_sys_param             sys_param;
	struct platform_param   platform_param;
	int       err;
	uint32_t        core_id = core_get_id();
	int is_master_core;

	CHECK_COND_RETVAL(core_id < INTG_MAX_NUM_OF_CORES, -EINVAL);
	memset( &pre_console_buf[core_id][0], 0, PRE_CONSOLE_BUF_SIZE - 1);
	pre_console_buf[core_id][PRE_CONSOLE_BUF_SIZE] = '\0';
	sys.p_pre_console_buf[core_id] = &pre_console_buf[core_id][0];
	sys.pre_console_buf_pos[core_id] = 0;

	memset(&sys_param, 0, sizeof(sys_param));
	memset(&platform_param, 0, sizeof(platform_param));
	sys_param.platform_param = &platform_param;
	fill_system_parameters(&sys_param);

	sys.is_master_core[core_id]       = (int)(sys_param.master_cores_mask & (1ULL << core_id));

	is_master_core = sys_is_master_core();

	if (is_master_core) {
		sys.active_cores_mask    = sys_param.active_cores_mask;
		sys.num_of_active_cores  = count_cores(sys.active_cores_mask);
	}

	/* reset boot_sync_flag */
	sys.boot_sync_flag = SYS_BOOT_SYNC_FLAG_DONE;

	/* Initialize Multi-Processing services as needed */
	err = sys_init_multi_processing();
	ASSERT_COND(err == 0);

	if (is_master_core) {

		/* Initialize memory management */
		err = sys_init_memory_management();
		ASSERT_COND(err == 0);

#ifdef SYS_SMP_SUPPORT
		/* Kick secondary cores */
#ifdef SYS_SECONDARY_START
		sys_kick_spinning_cores(sys.active_cores_mask,
		                        (dma_addr_t)PTR_TO_UINT(__sys_start_secondary),
		                        0);
#else  /*!SYS_SECONDARY_START*/
		sys_kick_spinning_cores(sys.active_cores_mask, (dma_addr_t)PTR_TO_UINT(__sys_start), 0);
#endif /* SYS_SECONDARY_START */
#endif /* SYS_SMP_SUPPORT */

		/* Initialize interrupt management */
		err = sys_init_interrupt_management();
		CHECK_COND_RETVAL(err==0, err, "sys_init_interrupt_management\n");

		/* Initialize the objects registry structures */
		sys_init_objects_registry();
	}

	sys_barrier();


#if 0
	if (sys.is_master_core[core_id] && sys_param.use_cli) {
		/* Initialize CLI */
		err = sys_init_cli();
		ASSERT_COND(err == 0);
	}
	sys_barrier();
#endif

	err = sys_init_platform(sys_param.platform_param);
	if (err != 0)
		return -1;

	return 0;
}

void sys_free(void)
{
	int is_master_core = sys_is_master_core();

	sys_free_platform();

#if 0
	if (sys.is_master_core[core_id])
		sys_free_cli();
#endif

	sys_barrier();

	sys_free_multi_processing();


	sys_barrier();

	if (is_master_core) {
		/* Free objects management structures */
		sys_free_objects_management();

		/* Free interrupt management module */
		sys_free_interrupt_management();

		/* Free memory management module */
		sys_free_memory_management();
	}
}
