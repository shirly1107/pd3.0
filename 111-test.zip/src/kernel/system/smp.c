/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_smp.h"
#include "hw_sem.h"
#include "fsl_system.h"
#include "soc_db.h"

typedef struct t_spin_table {
	uint64_t entry_addr;
	uint64_t r3;
	uint32_t rsvd1;
	uint32_t pir;
} t_spin_table;

#define GCR1_P2_RST_MASK  0x00400000
#define GCR1_M2_RST_MASK  0x00004000
#define GCR1_P2_STOP_MASK 0x40000000

int     sys_init_multi_processing(void);
void    sys_free_multi_processing(void);

int sys_init_multi_processing(void)
{
    int is_master_core = sys_is_master_core();
     
    /* Initialize HW semaphores */
    if (is_master_core) {
        hw_sem_init((void*)0x21018000);
    }

#ifdef SYS_SMP_SUPPORT
    if (is_master_core) {
        /* Initialize the central program barrier */
        sys_init_spinlock(&(sys.barrier_lock));

        sys.barrier_mask = sys.active_cores_mask;
    } else {
        /* Wait until system barrier is initialized */
        while (!sys.barrier_mask) ;
    }
#endif /* SYS_SMP_SUPPORT */

    return 0;
}

void sys_free_multi_processing(void)
{
	return;
}

void sys_kick_spinning_cores(uint64_t cores_mask,
                          dma_addr_t core_master_entry,
                          dma_addr_t core_guest_entry)
{
	extern struct soc_db soc_db;
	extern char _spin_table[];  /* base address of spin table (from linker file) */
    uint32_t *reg_base = soc_db.mc_db[0].desc.vaddr; /* 0x28340000 */
    uint32_t GCR1 = ioread32(UINT_TO_PTR(reg_base));
    
    UNUSED(core_master_entry);
    UNUSED(core_guest_entry);

	/* kick secondary core */
    GCR1 |= GCR1_P2_RST_MASK;   /* set P2_RST bit */
    GCR1 |= GCR1_M2_RST_MASK;  /* set M2_RST bit */
    GCR1 &= ~GCR1_P2_STOP_MASK; /* clear P2_STOP bit */
    iowrite32(GCR1, reg_base);

	*((uint32_t*)_spin_table) = 1;
}

void sys_barrier(void)
{
#ifdef SYS_SMP_SUPPORT
    uint64_t core_mask = (uint64_t)(1 << core_get_id());

    sys_lock_spinlock(&(sys.barrier_lock));
    
    /* Mark this core's presence */
    l1dcache_block_invalidate((uint32_t)&sys.barrier_mask);
    sys.barrier_mask &= ~(core_mask);

    if (sys.barrier_mask)
    {
        sys_unlock_spinlock(&(sys.barrier_lock));
        /* Wait until barrier is reset */
        while (!(sys.barrier_mask & core_mask)) {
        	l1dcache_block_invalidate((uint32_t)&sys.barrier_mask);
        }
    }
    else
    {
        /* Last core to arrive - reset the barrier */
        sys.barrier_mask = sys.active_cores_mask;
        l1dcache_block_flush((uint32_t)&sys.barrier_mask);
        sys_unlock_spinlock(&(sys.barrier_lock));
    }
#endif /* SYS_SMP_SUPPORT */
}

int sys_is_core_active(uint32_t core_id)
{
    return (int)(((sys.active_cores_mask & (1ULL << core_id)))?0:1);
}

int sys_is_master_core(void)
{
    return sys.is_master_core[core_get_id()];
}

uint64_t sys_get_cores_mask(void)
{
#ifdef SYS_SMP_SUPPORT
    return sys.active_cores_mask;
#else /* SYS_SMP_SUPPORT */
    return (uint64_t)(1ull << core_get_id());
#endif /* SYS_SMP_SUPPORT */
}

uint32_t sys_get_num_of_cores(void)
{
	return sys.num_of_active_cores;
}

uint32_t sys_get_max_num_of_cores(void)
{
	struct mc_desc mc_desc;
	int err;

	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, 0);
	ASSERT_COND(!err);
	return (uint32_t)mc_desc.num_cores;
}
