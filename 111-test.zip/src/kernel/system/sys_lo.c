/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "kernel/layout.h"
#include "sys.h"
#include "fsl_resman.h"
#include "fsl_soc.h"
#include "drivers/fsl_mc.h"
#include "dpl/dpl.h"
#include "common/fsl_string.h"
#include "fsl_malloc.h"

#define COMPATIBLE	"compatible"
#define BIND	 1
#define UNBIND	 0

struct dpl {
	struct sys_lo_mod_params *module;
	struct dpl *next;
};

static struct dpl *sys_get_dpl(void)
{
	return (struct dpl *)sys_get_unique_handle(FSL_MOD_LAYOUT);
}

static unsigned int *lo_read(void)
{
#define MC_GSR_READ_LO_MASK     0x3FFFFFFF
	uint32_t tmp;
	struct mc_desc mc_desc;
	uint32_t *mc_gsr_reg;
	int err;

	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, 0);
	ASSERT_COND(!err);

	mc_gsr_reg = (uint32_t *)PTR_MOVE(mc_desc.vaddr, 0x8);

	tmp = ioread32(mc_gsr_reg);
	tmp &= MC_GSR_READ_LO_MASK;
	tmp <<= 2;
	return UINT_TO_PTR(tmp);
}

static struct dpl *scan_dpl(struct dpl *dpl,
                            struct sys_lo_mod_params *lo_mod_params)
{
	while (dpl->module && dpl->module->compatibles
	       && strcmp(*(dpl->module->compatibles),
	                 *(lo_mod_params->compatibles))) {
		if (dpl->next)
			dpl = dpl->next;
		else
			break;
	}
	return dpl;
}

int sys_lo_register_module(struct sys_lo_mod_params *lo_mod_params)
{
	struct dpl *dpl = sys_get_dpl();
	char *src;
	char *dest;
	int i=0;
	if (!dpl) {
		pr_err("Could not get DPL\n");
		return -ENAVAIL;
	}
	/* check if already registered */
	dpl = scan_dpl(dpl, lo_mod_params);
	if (!dpl->module) /* register new module */
	{
		dpl->module =
		        (struct sys_lo_mod_params *)fsl_malloc(sizeof(struct sys_lo_mod_params));
		if (!dpl->module) {
			pr_err("No memory for new dpl module\n");
			return -ENOMEM;
		}
		memset(dpl->module, 0x0, sizeof(struct sys_lo_mod_params));
	} else if (!dpl->next) {
		dpl->next = (struct dpl *)fsl_malloc(sizeof(struct dpl));
		if (!dpl->next) {
			pr_err("No memory for new dpl module\n");
			return -ENOMEM;
		}
		memset(dpl->next, 0x0, sizeof(struct dpl));

		dpl = dpl->next;
		dpl->module =
		        (struct sys_lo_mod_params *)fsl_malloc(sizeof(struct sys_lo_mod_params));
		if (!dpl->module) {
			pr_err("No memory for new dpl module\n");
			return -ENOMEM;
		}
		memset(dpl->module, 0x0, sizeof(struct sys_lo_mod_params));

	} else if (dpl->module->compatibles
	           && !strcmp(*(dpl->module->compatibles),
	                      *(lo_mod_params->compatibles))) {
		pr_debug("module already registered\n");
		return 0;
	}
	/* register module */
	dpl->module->compatibles = (char **)fsl_malloc(sizeof(char *));
	if (!dpl->module->compatibles) {
		pr_err("No memory for new DPL module\n");
		return -ENOMEM;
	}
	do {
		dpl->module->compatibles[i] = (char *)fsl_malloc(16 * sizeof(char));
		if (!(*(dpl->module->compatibles))) {
			pr_err("No memory for new DPL module\n");
			return -ENOMEM;
		}
		dest = dpl->module->compatibles[i];//PTR_MOVE(*(dpl->module->compatibles), strlen(*(dpl->module->compatibles)));
		src = lo_mod_params->compatibles[i];//PTR_MOVE(*(lo_mod_params->compatibles), strlen(*(dpl->module->compatibles)));
		strcpy(dest, src);
		i++;
	} while ( i < lo_mod_params->num_compats );
	dpl->module->f_prob_module = lo_mod_params->f_prob_module;
	dpl->module->f_remove_module = lo_mod_params->f_remove_module;
	dpl->module->num_compats = lo_mod_params->num_compats;
	for (i = 0; i < lo_mod_params->num_compats ; i++)
		pr_info("DPL registered %s module\n", lo_mod_params->compatibles[i]);
	return 0;
}

int sys_lo_unregister_module(char *module_match)
{
	struct dpl *dpl = sys_get_dpl();
	struct dpl *tmp;
	if (!dpl) {
		pr_err("Could not get DPL\n");
		return -ENAVAIL;
	}
	/* search for registered device */
	if (!strcmp(*(dpl->module->compatibles), module_match)) {
		tmp = dpl;
		dpl = dpl->next;
		if (dpl){
			pr_warn("unregister from DPL changed order since register\n"
				"may cause un-freed objects\n");
			sys_remove_handle(FSL_MOD_LAYOUT, 1, 0);
			sys_add_handle(dpl, FSL_MOD_LAYOUT, 1, 0);
		}
		fsl_free(tmp->module);
		fsl_free(tmp);
		pr_info("Removed %s from DPL\n", module_match);
		return 0;
	}
	while (strcmp(*(dpl->next->module->compatibles), module_match)) {
		if (dpl->next->next)
			dpl = dpl->next;
		else
			break;
	}
	if (!strcmp(*(dpl->next->module->compatibles), module_match)) {
		tmp = dpl->next;
		dpl->next = dpl->next->next;
		fsl_free(tmp->module);
		fsl_free(tmp);
		pr_info("Removed %s from DPL\n", module_match);
		return 0;
	}

	pr_info("%s was not registered to DPL\n", module_match);
	return 0;
}

static uint32_t get_res_options(void *lo, int node_off)
{
	char *opt_str;
	int total_len;
	int len;
	int i = 0;
	uint64_t options = 0;
	struct {
		char *opt_str;
		uint32_t options;
	} map[] = {

	{ "DPRC_RES_REQ_OPT_EXPLICIT", DPRC_RES_REQ_OPT_EXPLICIT },
			{ "DPRC_RES_REQ_OPT_ALIGNED",
					DPRC_RES_REQ_OPT_ALIGNED }};
	
	//check if user entered number instead of define
	getprop_val(lo, node_off, "options", 0, 0, &options);
	if (options > 3){ //options entered as define
		options = 0;
		opt_str = (char *)fdt_getprop(lo, node_off, "options", &total_len);
		if (opt_str && (int)(*opt_str) != 0) {
			while (total_len > 0) {
				while (i < ARRAY_SIZE(map)
					&& strcmp(opt_str, map[i].opt_str))
					i++;
				if (i < ARRAY_SIZE(map)
					&& !strcmp(opt_str, map[i].opt_str))
					options |= map[i].options;
				len = (int)strlen(opt_str) + 1;
				total_len -= len;
				opt_str = PTR_MOVE(opt_str, len );
				i = 0;
			}
		}
	}
	return (uint32_t)options;
}

static int lo_bind_resources(void *lo,
	int node_off,
	struct device *mc_dev)
{
	int subnode_off;
	struct resman_res_req res_req;
	char tmp_str[16] = { 0 };
	char *str;
	int err = 0;
	int resman_err;
	int res_ids[16];
	uint64_t val;
	uint32_t num_explicit;
	int i;
	
	memset(&res_req, 0, sizeof(struct resman_res_req));

	subnode_off = fdt_first_subnode(lo, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND) {
		res_req.options = (uint32_t)get_res_options(lo, subnode_off);
		if (res_req.options && DPRC_RES_REQ_OPT_EXPLICIT)
		{
			str = (char *)fdt_getprop(lo, subnode_off, "type", NULL);
			if (str) {
				strncpy(res_req.type, str, sizeof(res_req.type) - 1);
			} else {
				pr_err("Resource type is not defined\n");
				return -EINVAL;
			}
			if(getprop_val(lo, subnode_off, "num", 0, 0, &val)){
				pr_err("'num' is a required field for layout resource\n");
				return -EINVAL;
			}
			res_req.num = (uint32_t)val;
			if(getprop_val(lo, subnode_off, "id_base_align", 0, 0, &val)){
				pr_err("'id_base_align' is a required field for layout resource\n");
				return -EINVAL;
			}
			res_req.id_base_align = (int)val;
			// explicit resources must be bind one at the time
			if (res_req.num > 1)
			{
				num_explicit = res_req.num;
				res_req.num = 1;
				for (i = 0; i < num_explicit; i++)
				{
					resman_err = resman_bind(mc_dev,
											 &res_req, res_ids);
					if (resman_err) {
						pr_err("failed to bind resource\n");
						return resman_err;
					}
					res_req.id_base_align++;
				}
			}
		}
		subnode_off = fdt_next_subnode(lo, subnode_off);
	}

	return err;
}

static int lo_bind(void *lo, int node_off)
{
	struct resman *resman;
	struct device *mc_dev;
	int cont_node_off, subnode_off;
	const char *subnode_name;
	uint64_t portal_id;
	struct resman_res_req res_req;
	int res_ids[16];
	int err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	ASSERT_COND(resman);
	mc_dev = (struct device *)resman_create_mc_device(resman);
	sys_add_handle(mc_dev, FSL_MOD_MC, 1, 0);

	cont_node_off = fdt_first_subnode(lo, node_off);
	while (cont_node_off != -FDT_ERR_NOTFOUND) { //goes over all containers
		subnode_off = fdt_first_subnode(lo, cont_node_off);
		getprop_val(lo, cont_node_off, "portal_id", "DPRC_GET_PORTAL_ID_FROM_POOL", DPRC_GET_PORTAL_ID_FROM_POOL, &portal_id);
		if (portal_id && ((int)portal_id != DPRC_GET_PORTAL_ID_FROM_POOL)){
			strcpy(res_req.type, "mcp");
			res_req.id_base_align = (int)portal_id;
			res_req.num = 1;
			res_req.options = DPRC_RES_REQ_OPT_EXPLICIT;
			err = resman_bind(mc_dev, &res_req, res_ids);
		}
		while (subnode_off != -FDT_ERR_NOTFOUND) { //goes over all resources in container
			subnode_name = fdt_get_name(lo, subnode_off, NULL);
			if (subnode_name && !strcmp(subnode_name, "resources")) {
				err = lo_bind_resources(lo, subnode_off, mc_dev);
				if (err)
					return err;
			}
			subnode_off = fdt_next_subnode(lo, subnode_off);
		}
		cont_node_off = fdt_next_subnode(lo, cont_node_off);
	}
	return 0;
}

static int call_linkman_driver(void *lo, int node_off, struct dpl *dpl)
{
	while (strcmp("fsl,linkman", *(dpl->module->compatibles)) && dpl->next) {
		dpl = dpl->next;
	}
	if (!strcmp("fsl,linkman", *(dpl->module->compatibles))) {
		return dpl->module->f_prob_module(lo, node_off); /* call driver */
	}

	pr_err("Can't process unregister module - linkman\n");
	return -ENAVAIL;
}

static struct dpl * search_in_registry(struct dpl *dpl, char *comp_name, int *i)
{	
	int j = 0;
	while (strcmp(comp_name,
	              dpl->module->compatibles[j])
	       && (dpl->next || dpl->module->num_compats > 1)) {
		if (dpl->module->num_compats > 1){
			j = 0;
			while (strcmp(comp_name, dpl->module->compatibles[j]) && j < dpl->module->num_compats)
				j++;
		}
		if (strcmp(comp_name, dpl->module->compatibles[j]) && dpl->next){
			j = 0;
			dpl = dpl->next;
		}
	}
	*i = j;
	return dpl;
}

static int subnode_process(void *lo, int node_off, struct dpl *dpl)
{
	int subnode_off;
	char *comp_name;
	const char *node_name;
	char *compatible;
	int len, len_p;
	int err = 0;
	int i = 0;

	subnode_off = fdt_first_subnode(lo, node_off);

	while (subnode_off != -FDT_ERR_NOTFOUND) {
		node_name = fdt_get_name(lo, node_off, NULL);
		if (node_name && ((!(strcmp(node_name, "links"))) || (!(strcmp(node_name, "connections"))))) {
			return call_linkman_driver(lo, node_off, dpl);
		}
		compatible = (char *)fdt_getprop(lo, subnode_off,
		                                 "compatible", &len_p);
		if (!compatible) {
			pr_err("Missing compatible in %s node - driver not started!\n", fdt_get_name(lo, subnode_off, NULL));
			break;
		}

		len = len_p;
		while (len > 0) {
			/* search for module in registry */
			comp_name = PTR_MOVE(compatible, len_p - len);
			if (!comp_name)
				break;
			dpl = search_in_registry(dpl, comp_name, &i);

			if (!strcmp(comp_name,
			            dpl->module->compatibles[i])) {
				err = dpl->module->f_prob_module(lo,
				                           subnode_off); /* call driver */
				if (err)
					return err;
				len -= (strlen(compatible) + 1);
				dpl = sys_get_dpl();
				if (!dpl) {
					pr_err("Did not find DPL\n");
					return -ENAVAIL;
				}
			} else if (!dpl->next) {
				pr_err("Can't process unregister module %s\n", fdt_get_name(lo, subnode_off, NULL));
				err |= -ENAVAIL;
				break;
			}
		}
		subnode_off = fdt_next_subnode(lo, subnode_off);
	}
	return err;
}

int sys_lo_process(void)
{
	int node_off;
	void *lo;
	struct resman *resman;
	struct device *mc_dev;
	int err = 0;

	struct dpl *dpl = sys_get_dpl();
	if (!dpl) {
		pr_err("Could not get DPL\n");
		return -ENODEV;
	}

	lo = lo_read();
	if (!lo) {
		pr_info("No DPL address found; Continue without DPL\n");
		return 0;
	}

	if (fdt_magic(lo) != 0xD00DFEED) {
		pr_info("Illegal DPL found at address %08x; Continue without DPL\n", PTR_TO_UINT(lo));
		return 0;
	}

	pr_info("Found DPL at address: %08x; Processing DPL...\n", PTR_TO_UINT(lo));
	node_off = fdt_first_subnode(lo, 0); //containers
	lo_bind(lo, node_off);
	while (node_off != -FDT_ERR_NOTFOUND) //containers , objects , links
	{
		err |= subnode_process(lo, node_off, dpl);
		if (err)
			break;
		node_off = fdt_next_subnode(lo, node_off);
	}
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	ASSERT_COND(resman);
	mc_dev = sys_get_unique_handle(FSL_MOD_MC);
	ASSERT_COND(mc_dev);
	resman_destroy_mc_device(resman, mc_dev);
	sys_remove_handle(FSL_MOD_MC, 1, 0);
	return err;
}

int lo_drv_init(void)
{
	struct dpl *dpl = (struct dpl *)fsl_malloc(sizeof(struct dpl));
	if (!dpl) {
		pr_err("No memory for DPL init");
		return -ENOMEM;
	}
	memset(dpl, 0x0, sizeof(struct dpl));

	sys_add_handle(dpl, FSL_MOD_LAYOUT, 1, 0);
	return 0;
}

void lo_drv_free(void)
{
	sys_remove_handle(FSL_MOD_LAYOUT, 1, 0);
	pr_debug("Removed DPL handle\n");

}
