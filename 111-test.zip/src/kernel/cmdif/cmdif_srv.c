/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_stdlib.h"
#include "fsl_gen.h"
#include "fsl_dbg.h"
#include "fsl_malloc.h"
#include "common/fsl_string.h"
#include "fsl_core.h"
#include "fsl_platform.h"
#include "fsl_resman.h"
#include "fsl_soc.h"
#include "drivers/fsl_mc.h"
#include "mpic.h"

#include "resman.h"
#include "kernel/device.h"
#include "cmdif_srv.h"
#include "fsl_dpmcp_mc.h"
#include "fsl_tasklet.h"
#include "log.h"
#include "dprc_cmd.h"
#ifdef MISC_CMD_SUPPORT
extern int misc_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data);
#endif //MISC_CMD_SUPPORT

char dp_res_type_array [CMDIF_MOD_MODULES_NUM][17] =
{"dprc","dpni","dpmac","dpio","dpbp","dpsw","dpdmux","dpcon","dpci","dpseci","dpdcei","dpdmai","dpaiop","dpmcp","dpdbg", "dprtc", "dpsparser"};
uint16_t  cmd_module_num_array [CMDIF_MOD_MODULES_NUM] =
{ 5     , 1    , 12    , 3    , 4    , 2    , 6     , 8     , 7    , 9      , 13     , 14     , 10     , 11    , 15    , 16,		17};
/* "dprc","dpni","dpmac","dpio","dpbp","dpsw","dpdmux","dpcon","dpci","dpseci","dpdcei","dpdmai","dpaiop","dpmcp","dpdbg", "dprtc", "dpsparser"};*/

/*
 * array used to convert from command code module id to command interface module id
 */
enum cmdif_module cmdif_module_id_array[CMDIF_MOD_MODULES_NUM + 1] = { CMDIF_MOD_MODULES_NUM,
                                                                       CMDIF_MOD_DPNI,
                                                                       CMDIF_MOD_DPSW,
                                                                       CMDIF_MOD_DPIO,
                                                                       CMDIF_MOD_DPBP,
                                                                       CMDIF_MOD_DPRC,
                                                                       CMDIF_MOD_DPDMUX,
                                                                       CMDIF_MOD_DPCI,
                                                                       CMDIF_MOD_DPCON,
                                                                       CMDIF_MOD_DPSECI,
                                                                       CMDIF_MOD_DPAIOP,
                                                                       CMDIF_MOD_DPMCP,
                                                                       CMDIF_MOD_DPMAC,
                                                                       CMDIF_MOD_DPDCEI,
                                                                       CMDIF_MOD_DPDMAI,
                                                                       CMDIF_MOD_DPDBG,
                                                                       CMDIF_MOD_DPRTC,
                                                                       CMDIF_MOD_DPSPARSER
                                                                  };

static void command_dump(uint8_t portal_indx, struct mc_portal *mc_portal) {
	char buf[1024];
	uint32_t chr, i;
	int count = 0;
	uint64_t val;
	
	if (!(((log_levels[LOG_MODULE] != LOG_LEVEL_GLOBAL)
		&& (log_levels[LOG_MODULE] <= LOG_LEVEL_DEBUG))
		|| ((log_levels[LOG_MODULE] == LOG_LEVEL_GLOBAL)
			&& (log_global_level <= LOG_LEVEL_DEBUG))))
		return;
	
	memset(buf, 0, sizeof(buf));
	
	count += sprintf((char *)&buf[count], "Command received on portal %d [0x%08X]\n", portal_indx, mc_portal);
	
	val = swap_uint64(mc_portal->header);

	count += sprintf((char *)&buf[count], "\t00: ");
	for (chr = 0; chr < 8; chr++) {
		count += sprintf((char *)&buf[count], "%02x ", (uint8_t)(val >> (8*(8 - (chr + 1)))));
		if (chr == 3) {
			count += sprintf((char *)&buf[count], " ");
		}
	}
	
	count += sprintf((char *)&buf[count], "\n");

	for (i = 0; i < MC_CMD_NUM_OF_PARAMS; i++) {
		val = swap_uint64(mc_portal->data.params[i]);
		
		count += sprintf((char *)&buf[count], "\t%02x: ",  (i+1) * 8);
		
		for (chr = 0; chr < 8; chr++) {
			count += sprintf((char *)&buf[count], "%02x ", (uint8_t)(val >> (8*(8 - (chr + 1)))));
			if (chr == 3) {
				count += sprintf((char *)&buf[count], " ");
			}
		}
		
		count += sprintf((char *)&buf[count], "\n");
	}
	
	pr_debug(buf);
}

static uint32_t get_module_id_for_type(char* type)
{
	for (uint32_t i = 0; i < CMDIF_MOD_MODULES_NUM; i++) {
		if (strcmp(type, dp_res_type_array[i]) == 0) {
			return i;
		}
	}
	return CMDIF_MOD_MODULES_NUM;
}

static inline uint8_t get_cmd_ver(struct mc_portal *cmd)
{
    if(cmd)
    {
        uint64_t cmd_version = swap_uint64(cmd->header) & CMDHDR_CMD_CODE_VERSION_MASK;
        cmd_version >>= CMDHDR_CMD_VERSION_SHIFT;
        return (uint8_t)cmd_version;
    }

    /* default to zero - select functionality before versioning system */
    return (uint8_t)MC_CMD_HDR_NO_VER;
}

static void remove_cmdif_instance(struct cmdif_srv *cmdif, uint32_t instance)
{
    cmdif->instance_handle[instance] = NULL;
    cmdif->module_id[instance] = 0;
    cmdif->portal_id[instance] = 0;
    cmdif->portal_dprc_id[instance] = RESMAN_NO_CONTAINER_ID;
    cmdif->instances_counter--;
}

static inline uint32_t get_auth_id(struct mc_portal *cmd)
{
    uint64_t instance = (uint64_t)-1;
    uint8_t cmd_ver = get_cmd_ver(cmd);
    uint64_t cmd_hdr = swap_uint64(cmd->header);

    switch(cmd_ver)
    {
        case MC_CMD_HDR_NO_VER:
          {
            instance = cmd_hdr & CMDHDR_AUTH_ID_MASK_V0;
            instance >>= CMDHDR_AUTH_ID_SHIFT_V0;
          }break;
        default:
        {
          /* apply new header format */
            instance = cmd_hdr & CMDHDR_AUTH_ID_MASK;
            instance >>= CMDHDR_AUTH_ID_SHIFT;
        }break;
    };
    return (uint32_t)instance;
}

static inline void set_auth_id(struct mc_portal *cmd, uint16_t instance)
{
    uint64_t hdr_instance = instance;
    uint64_t tmp = swap_uint64(cmd->header);
    uint8_t cmd_ver = get_cmd_ver(cmd);

    switch(cmd_ver)
    {
        case MC_CMD_HDR_NO_VER:
        {
            hdr_instance <<= CMDHDR_AUTH_ID_SHIFT_V0;
            tmp &= ~CMDHDR_AUTH_ID_MASK_V0;
        }break;
        default:
        {
          /* apply new header format */
            hdr_instance <<= CMDHDR_AUTH_ID_SHIFT;
            tmp &= ~CMDHDR_AUTH_ID_MASK;
        }break;
    };

    tmp |= hdr_instance;
    cmd->header = swap_uint64(tmp);
}

static inline uint16_t get_cmdcode(struct mc_portal *cmd)
{
	uint64_t cmd_code = swap_uint64(cmd->header) & CMDHDR_CMD_CODE_MASK;
	cmd_code >>= CMDHDR_CMD_CODE_SHIFT;
	return (uint16_t)cmd_code;
}

static inline void set_cmdcode(struct mc_portal *cmd, uint16_t code)
{
	uint64_t hdr_code = code;
	uint64_t tmp = swap_uint64(cmd->header);

	hdr_code <<= CMDHDR_CMD_CODE_SHIFT;
	tmp &= ~CMDHDR_CMD_CODE_MASK;
	tmp |= hdr_code;
	cmd->header = swap_uint64(tmp);
}

static inline uint16_t get_id(struct mc_portal *cmd)
{
	uint64_t id = swap_uint64(cmd->data.params[0]) & CMDPARAM1_ID_MASK;
	return (uint16_t)id;
}

static inline void set_id(struct mc_portal *cmd, uint16_t dev_id)
{
	uint64_t id = dev_id & CMDPARAM1_ID_MASK;
	cmd->data.params[0] = swap_uint64(id);
}

static inline int get_intr_dis(struct mc_portal *cmd)
{
	uint64_t cmd_intr_dis = swap_uint64(cmd->header) & CMDHDR_INTR_DIS_MASK;
	cmd_intr_dis >>= CMDHDR_INTR_DIS_SHIFT;
	return (int)cmd_intr_dis;
}

static inline void cmd_done(struct mc_portal *cmd,
	enum mc_cmd_status status,
	int portal_indx)
{
	struct dpmcp *dpmcp;
	int intr_dis;
	uint64_t hdr_status = status;
	uint64_t tmp = swap_uint64(cmd->header);

	hdr_status <<= CMDHDR_STATUS_SHIFT;
	tmp &= ~CMDHDR_STATUS_MASK;
	tmp |= hdr_status;

	intr_dis = get_intr_dis(cmd);

	cmd->header = swap_uint64(tmp);
	dpmcp = sys_get_handle(FSL_MOD_DPMCP, 1, portal_indx);
	if (dpmcp)
		if (!intr_dis)
			dpmcp_invoke_inter(dpmcp);

}

static inline void clear_portal_err(struct cmdif_srv *cmdif, 
		uint8_t portal_indx, 
		struct mc_portal *mc_portal)
{
	cmd_done(mc_portal, MC_CMD_STATUS_INVALID_STATE, portal_indx);
	iowrite32((0x1 << (portal_indx % 32)),
			&(cmdif->cpm_regs->cprr[portal_indx / 32]));
	iowrite32((0x1 << (portal_indx % 32)),
			&(cmdif->cpm_regs->cppr[portal_indx / 32]));
	iowrite32((0x1 << (portal_indx % 32)),
			&(cmdif->cpm_regs->cper[portal_indx / 32]));
}

static inline void clear_portal(struct cmdif_srv *cmdif, 
		uint8_t portal_indx)
{
	iowrite32((0x1 << (portal_indx % 32)),
			&(cmdif->cpm_regs->cprr[portal_indx / 32]));
	iowrite32((0x1 << (portal_indx % 32)),
			&(cmdif->cpm_regs->cppr[portal_indx / 32]));
}

static inline int check_portal_err(struct cmdif_srv *cmdif,
		uint8_t portal_indx,
		struct mc_portal *mc_portal)
{
	uint32_t cper = ioread32(&(cmdif->cpm_regs->cper[portal_indx / 32]));

	/* portal error */
	if ((0x1 << (portal_indx % 32)) & cper) {
		clear_portal_err(cmdif, portal_indx, mc_portal);
		return 1;
	}
	return 0;
}

int cmdif_reset_portal_ctrl_cb(void *dpmcp, int portal_id)
{
	struct cmdif_srv *cmdif;
        uint32_t instance;
        uint32_t module_id;
        void *device = NULL;
        int ret = 0;
        int 	cmd_portal_base;

        if(portal_id<256)
         	cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1,0);
         else
         	cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1,1);


        UNUSED(dpmcp);
        ASSERT_COND(cmdif);

        cmd_portal_base = cmdif->portal_base_id;

        for (instance = 1; instance < MAX_NUM_OF_INSTANCES; instance++) {
        	if (portal_id - cmd_portal_base == cmdif->portal_id[instance] &&
        		cmdif->instance_handle[instance]){
        		device = cmdif->instance_handle[instance];
        		if (device == dpmcp)
        			continue;
			module_id = cmdif->module_id[instance];

		    if(module_id >= CMDIF_MOD_MODULES_NUM)
				return MC_CMD_STATUS_NO_RESOURCE;


			ret = cmdif->close_cb[module_id](device, portal_id, instance);
                        if (ret)
                return MC_CMD_STATUS_NO_RESOURCE;

			ret = resman_close_dev(
				sys_get_unique_handle(FSL_MOD_RESMAN),
				device, dp_res_type_array[module_id],
				cmdif->portal_id[instance], 0);

			if (ret)
				return MC_CMD_STATUS_NO_RESOURCE;

			remove_cmdif_instance(cmdif, instance);
		}
	}

	return 0;
}

static enum mc_cmd_status cmdif_code(int ret)
{

	switch (ret) {
	case 0:
		return MC_CMD_STATUS_OK;
	case -EACCES:
		return MC_CMD_STATUS_AUTH_ERR; /* Authentication error */
	case -EPERM:
		return MC_CMD_STATUS_NO_PRIVILEGE; /* Permission denied */
	case -EIO:
		return MC_CMD_STATUS_DMA_ERR; /* Input/Output error */
	case -EINVAL:
		return MC_CMD_STATUS_CONFIG_ERR; /* Device not configured */
	case -ETIMEDOUT:
		return MC_CMD_STATUS_TIMEOUT; /* Operation timed out */
	case -ENAVAIL:
		return MC_CMD_STATUS_NO_RESOURCE; /* Resource temporarily unavailable */
	case -ENOMEM:
		return MC_CMD_STATUS_NO_MEMORY; /* Cannot allocate memory */
	case -EBUSY:
		return MC_CMD_STATUS_BUSY; /* Device busy */
	case -ENOTSUP:
		return MC_CMD_STATUS_UNSUPPORTED_OP; /* Operation not supported by device */
	case -ENODEV:
		return MC_CMD_STATUS_INVALID_STATE; /* Invalid device state */
	default:
		return MC_CMD_STATUS_CONFIG_ERR; /* Device not configured */
		break;
	}
}

/**************************************************************************//**
@Function       get_cmdif_module_from_cmd_module

@Description    Convert from module id received via command code, first byte from it,
                into module id as it is recorded by server in @see enum cmdif_module

@Param[in]      module_id   derived from command code 

@Return         command interface module id @see enum cmdif_module for details
 *//***************************************************************************/
static enum cmdif_module get_cmdif_module_from_cmd_module(uint16_t module_id)
{
    if ( module_id > CMDIF_MOD_MODULES_NUM )
      return CMDIF_MOD_MODULES_NUM;
    return cmdif_module_id_array[module_id];
}

/**************************************************************************//**
@Function       get_cmd_group

@Description    Get command class/group based on command code - command's group is used
                in authentication and command dispatch step 

@Param[in]      code   Command code @see dpxx_cmd.h

@Return         command group @see enum srv_cmd_group for details
 *//***************************************************************************/
static enum srv_cmd_group get_cmd_group(uint16_t cmd_code)
{
	/* the MSB bits from the command code represent the command group */
	uint16_t group = cmd_code & INIT_CMD_TYPE_MASK;
	enum srv_cmd_group ret = CMD_GROUP_INVALID;
	switch(group)
	{
	case INIT_CMD_MASK:
	case CREATE_CMD_MASK:
	case DESTROY_CMD_V2_MASK:
		ret = CMD_GROUP_CREATE_DESTROY;
		break;
	case COMMON_CMD_MASK:
		ret = CMD_GROUP_COMMON;
		break;
	case MC_MISC_CMD_MASK:
		ret = CMD_GROUP_MC_MISC;
		break;
	default:
		ret = CMD_GROUP_SPECIFIC;
		break;
	};
	return ret;
}

static enum mc_cmd_status setup_portal(struct cmdif_srv *cmdif,
	struct mc_portal *mc_portal,
	uint32_t portal_idx)
{
	uint16_t code = get_cmdcode(mc_portal);
	uint8_t cmd_ver = get_cmd_ver(mc_portal);
	uint16_t module_id = code & INIT_CMD_MODULE_MASK;
	enum cmdif_module cmdif_module;
	void *dev = NULL;
	struct resman *resman;
	uint16_t id;
	int ret;
	int r;
	int cmd_portal_base = cmdif->portal_base_id;
	uint8_t create_device = (code & INIT_CMD_TYPE_MASK) == CREATE_CMD_MASK;
	uint8_t new_api = CMD_GT_V0(cmd_ver);

	ASSERT_COND(cmdif);

	if (cmdif->instances_counter >= (MAX_NUM_OF_INSTANCES - 1)) {
		return MC_CMD_STATUS_NO_RESOURCE;
	}

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman)
		return MC_CMD_STATUS_NO_RESOURCE;

	/*convert module id to cmdif module id*/
	cmdif_module = get_cmdif_module_from_cmd_module(module_id);
	if (cmdif_module == CMDIF_MOD_MODULES_NUM) {
		if (module_id >= CMDIF_MOD_MC_RESERVED && cmdif->ctrl_cb[module_id]) {
			ret = cmdif->ctrl_cb[module_id](NULL, cmd_ver, code,
					(int)portal_idx+cmd_portal_base, (uint8_t*)&(mc_portal->data));

			if (ret)
				return MC_CMD_STATUS_CONFIG_ERR;
			else
				return MC_CMD_STATUS_OK;
		}
		return MC_CMD_STATUS_NO_RESOURCE;
	}

	/* check for valid open cb on old flow only*/
	if (cmdif->open_cb[cmdif_module] == NULL)
		return MC_CMD_STATUS_CONFIG_ERR;

	/* randomly pick instance/authentication id
	 on old flow and when we open a device. */
	if (!new_api ||
			(new_api && !create_device)) {
		r = rand() % MAX_NUM_OF_INSTANCES;
		int count = 0;
		while ((!r || cmdif->instance_handle[r])
				&& count < MAX_NUM_OF_INSTANCES) {
			r = rand() % MAX_NUM_OF_INSTANCES;
			count++;
		}
		/*! didn't find empty space yet */
		if (!r || cmdif->instance_handle[r]) {
			count = 0;
			while ((!r || cmdif->instance_handle[r])
					&& count < MAX_NUM_OF_INSTANCES) {
				r = (r+1) % MAX_NUM_OF_INSTANCES;
				count++;
			}
		}
		if (cmdif->instance_handle[r])
			return MC_CMD_STATUS_NO_RESOURCE;
	}

	/* get device id on old flow or when we open a device */
	if (!new_api || !create_device)
		id = get_id(mc_portal);

	/*Create command*/
	if (create_device) {
		if (strcmp(dp_res_type_array[cmdif_module], "dpmcp") == 0
			|| strcmp(dp_res_type_array[cmdif_module], "dpmac") == 0
			|| strcmp(dp_res_type_array[cmdif_module], "dpaiop") == 0)
			id = (uint16_t)u64_dec(
				swap_uint64(mc_portal->data.params[0]), 0, 32);
		else
			id = RESMAN_NO_DEVICE_ID;
		if (new_api) {
			/* for the new create command the device must be assigned to the
			 container pointed by token/handle.*/
			int dprc_assign_portal_id = (int)portal_idx;
			uint32_t handle_token = get_auth_id(mc_portal);
			struct dprc* dprc_obj =
					(struct dprc*)cmdif->instance_handle[handle_token];
			CHECK_COND_RETVAL((dprc_obj != 0) &&
				cmdif->module_id[handle_token] == CMDIF_MOD_DPRC,
				MC_CMD_STATUS_NO_RESOURCE,
				"Fail to create object: no opened container for token:0x%x",
				handle_token);
			dprc_assign_portal_id = dprc_obj->portal_id;
			if(!dprc_obj->locked){
				dev = resman_create_dev(resman, dp_res_type_array[cmdif_module], dprc_assign_portal_id + cmd_portal_base, NULL, &id);
			} else{
				pr_err("Create command on a locked container\n");
				return MC_CMD_STATUS_NO_PRIVILEGE;
			}

		} else {
			dev = resman_open_dev(resman, dp_res_type_array[cmdif_module], id, (int)portal_idx + cmd_portal_base, DPRC_OPEN_CREATE_DEV, NULL);
		}
	} else {
		/* open command*/
		dev = resman_open_dev(resman, dp_res_type_array[cmdif_module], id, (int)portal_idx + cmd_portal_base,
				DPRC_OPEN_DEV_ONLY, NULL);
	}
	if (!dev) /* No device */
		return MC_CMD_STATUS_NO_RESOURCE;

	/* open command */
	if (!new_api || !create_device) {
		ret = cmdif->open_cb[cmdif_module](dev, (int)portal_idx+cmd_portal_base);
		if (!ret) {
			cmdif->instance_handle[r] = (void*)dev;
			cmdif->module_id[r] = (uint8_t)cmdif_module;
			cmdif->portal_id[r] = (uint8_t)portal_idx;
			/* cache the id of the container holding the portal id
			on which we opened this device in order to use it later for
			command authentication on a different portal id. */
			if (resman_get_container_id((int)portal_idx,
					&(cmdif->portal_dprc_id[r])) != 0)
			{
				cmdif->portal_dprc_id[r] = RESMAN_NO_CONTAINER_ID;
			}
			cmdif->instances_counter++;
			set_auth_id(mc_portal, (uint16_t)r);
		} else {
			resman_close_dev(resman, dev, dp_res_type_array[cmdif_module], (int)portal_idx + cmd_portal_base, 0);
			return cmdif_code(ret);
		}
	}

	/*Create command*/
	if (create_device) {
		ret = cmdif->ctrl_cb[cmdif_module](
			dev, cmd_ver, code, (int)portal_idx + cmd_portal_base,
			(uint8_t*)&(mc_portal->data));
		if (ret) {
			if( !new_api )
				remove_cmdif_instance(cmdif, (uint32_t)r);
			resman_close_dev(resman, dev, dp_res_type_array[cmdif_module],
						(int)portal_idx + cmd_portal_base, 1);

			return cmdif_code(ret);
		}
		resman_object_created(dev);
		set_id(mc_portal, id); // set the id of the newly created device
	}
	return MC_CMD_STATUS_OK;
}

/* called internally from another MC module*/
enum mc_cmd_status create_portal(enum cmdif_module cmdif_module,
		struct mc_cmd_data *cmd_data,
		uint32_t portal_id)
{
	struct cmdif_srv *cmdif;
	struct mc_portal mc_portal;

    if(portal_id<256)
      	cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1,0);
      else
      	cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1,1);

    if(!cmdif)
    return MC_CMD_STATUS_INVALID_STATE;

    if(cmdif_module >= CMDIF_MOD_MODULES_NUM)
		return MC_CMD_STATUS_CONFIG_ERR;
    mc_portal.header = 0x0;
   	memcpy(&mc_portal.data, cmd_data, sizeof(struct mc_cmd_data));
   	set_cmdcode(&mc_portal, CREATE_CMD_MASK|cmd_module_num_array[cmdif_module]);

   	return	 setup_portal(cmdif,
   						  &mc_portal,
   						  portal_id);
}

static enum mc_cmd_status close_portal(struct cmdif_srv *cmdif,
	struct mc_portal *mc_portal)
{
	uint16_t code = get_cmdcode(mc_portal);
	uint8_t cmd_ver = get_cmd_ver(mc_portal);
	uint32_t instance;
	uint8_t cmdif_module_id;
	int portal_id = NO_PORTAL_ID;
	uint16_t obj_id = RESMAN_NO_DEVICE_ID;
	void *dev = NULL;
	char *type = NULL;
	int ret;
	struct resman *presman = (struct resman*) NULL;
	uint8_t destroy_device = (code & INIT_CMD_TYPE_MASK) == CMD_CODE_DESTROY ||
							 (code & INIT_CMD_TYPE_MASK) == DESTROY_CMD_V2_MASK;
	uint8_t new_api = CMD_GT_V0(cmd_ver);
	struct dprc *dev_creator_dprc = (struct dprc*) NULL;
	ASSERT_COND(cmdif);

	presman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!presman)
		return MC_CMD_STATUS_NO_RESOURCE;
	instance = get_auth_id(mc_portal);
	portal_id = (int)(cmdif->portal_id[instance]+cmdif->portal_base_id);
	dev = cmdif->instance_handle[instance];
	cmdif_module_id = cmdif->module_id[instance];

	if (!dev)
		return MC_CMD_STATUS_NO_RESOURCE;

	if(cmdif_module_id>= CMDIF_MOD_MODULES_NUM)
		return MC_CMD_STATUS_NO_RESOURCE;


	type = dp_res_type_array[cmdif_module_id];
	/* on new destroy API the dprc token and the object id
	 should be used to identify the device; they are provided as
	 parameters for each dpXX_destroy(); the bellow code handles
	 non-dprc devices as containers are destroyed using another command */
	if (new_api && destroy_device) {
		struct dprc *contain_dprc = (struct dprc*) NULL;
		// destroy should receive the token/instance of the dprc holding the device
		CHECK_COND_RETVAL(cmdif_module_id == CMDIF_MOD_DPRC,
				MC_CMD_STATUS_UNSUPPORTED_OP,
				"The received token for destroy command does not point to an opened DPRC.");
		// get object id embedded in command code
		obj_id = (uint16_t)(swap_uint64(mc_portal->data.params[0]) & CMDPARAM1_ID_MASK);
		// convert to actual cmdif module id from the module id embedded in the command code
		cmdif_module_id = get_cmdif_module_from_cmd_module(code & INIT_CMD_MODULE_MASK);
		CHECK_COND_RETVAL(cmdif_module_id < CMDIF_MOD_MODULES_NUM,
				MC_CMD_STATUS_NO_RESOURCE,
				"The destroy command is not supported for module id: %d.", (code & INIT_CMD_MODULE_MASK));
		type = dp_res_type_array[cmdif_module_id]; // get the new type
		// search for devices only - non-container devices
		dev_creator_dprc = (struct dprc*) dev; // save creator dprc
		struct resman_device* res_device = resman_find_device_at_descendant(
				presman, dev_creator_dprc, type, obj_id, &contain_dprc);
		CHECK_COND_RETVAL(res_device != NULL,
						MC_CMD_STATUS_NO_RESOURCE,
						"No object found for received id (%d) and dprc token (%d).", obj_id, instance);
		dev = &res_device->dev;
	}
	if (destroy_device) /*Destroy and create command are the same code*/
	{
		ret = resman_is_destroy_allowed(dev, type, dev_creator_dprc); // check if object can be destroyed.
		if (!ret)
			return MC_CMD_STATUS_NO_PRIVILEGE;

		ret = cmdif->ctrl_cb[cmdif_module_id](
			dev, cmd_ver, CMD_CODE_DESTROY,
			portal_id, (uint8_t*)&(mc_portal->data));
		if (ret)
			return MC_CMD_STATUS_NO_PRIVILEGE;

		ret = resman_close_dev(presman, dev, type, portal_id, 1);

		if (ret)
			return MC_CMD_STATUS_NO_PRIVILEGE;

		/* old command still needs to remove the instance */
		if (!new_api)
			remove_cmdif_instance(cmdif, instance);
	} else/* close command*/
	{
		ret = cmdif->close_cb[cmdif_module_id](dev, portal_id, instance);
		if (ret)
			return MC_CMD_STATUS_NO_RESOURCE;

		ret = resman_close_dev(presman, dev, type, portal_id, 0);

		if (ret)
			//what if resman failed closing but not the driver??
			return MC_CMD_STATUS_NO_RESOURCE;
		remove_cmdif_instance(cmdif, instance);
	}

	return MC_CMD_STATUS_OK;
}

static int portal_in_device_container(struct cmdif_srv *cmdif, uint32_t instance, int authentication_portal_id, uint8_t search_all)
{
	struct resman* resmgr = (struct resman*) 0;
	void* device = cmdif->instance_handle[instance];
	unsigned int isDprcDev = 0;
	int dprc_id = RESMAN_NO_CONTAINER_ID;
	int portal_dprc_id = cmdif->portal_dprc_id[instance];
	int search_level = 0;
	struct dprc* dprc_obj = (struct dprc*) NULL;

	if (portal_dprc_id < 0)
		return 0;

	resmgr = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resmgr)
		return 0;

	if (cmdif->module_id[instance] == CMDIF_MOD_DPRC)
	{
		dprc_obj = (struct dprc*) device;
		/* if the sent token/instance points to a dprc object check first
		 if the authentication_portal_id is the assigned portal of that container */
		if (dprc_obj->portal_id == authentication_portal_id)
			return 1;
		isDprcDev = 1;
		search_level = 1;
	}
	if (search_all)
		search_level = MAX_NUM_OF_CONTAINERS;
	/* check if both the current authentication portal and the portal id used to open
	 the device pertain to the same container */
	if (resman_is_portal_in_dev_rc_hierarchy(resmgr,
			device,	isDprcDev, authentication_portal_id, &dprc_id, search_level))
	{
		return (portal_dprc_id == dprc_id) ||
		/* in case the token points to a dprc device then maybe
		 the authentication_portal_id resides in assigned of
		 in use portal lists of this container*/
		(isDprcDev && dprc_obj && dprc_obj->container_id == dprc_id);
	}

	return 0;
}

static int authenticate(struct cmdif_srv *cmdif,
		struct mc_portal *mc_portal,
		uint32_t *instance,
		uint16_t *code,
		uint8_t portal_indx)
{
	/* get 'TOKEN' parameter from command */
	*instance = get_auth_id(mc_portal);
	/* internally, the token represents an index in the array that "holds" the
	devices that are currently opened; must check here for "index out of bounds"
	to avoid using a bad token */
	int invalid_token = *instance >= MAX_NUM_OF_INSTANCES;
	enum srv_cmd_group cmd_group = CMD_GROUP_INVALID;
	if ((*instance) == 0 || invalid_token)
	{
		/* get 'CMDID' parameter from command */
		*code = get_cmdcode(mc_portal);
		cmd_group = get_cmd_group(*code);
		if (cmd_group == CMD_GROUP_SPECIFIC)
		{
			return 1;
		}
		/* the only commands that don't require a valid token are the open and
		the "common" commands, all other commands require a valid token */
		if (invalid_token &&
			!(((*code & INIT_CMD_MODULE_MASK) != 0) &&
			((*code & INIT_CMD_TYPE_MASK) == INIT_CMD_MASK)))
			return 1;
	}
	else if (cmdif->instance_handle[*instance] == NULL)
	{
		return 1;

	}
	else if (cmdif->portal_id[*instance] != portal_indx)
	{
		/* for the new create command search for the command portal id up to the root container */
		uint16_t cmd_type = (get_cmdcode(mc_portal) & INIT_CMD_TYPE_MASK);
		uint8_t search_all_ancestors =
				((cmd_type == CREATE_CMD_MASK) || (cmd_type == DESTROY_CMD_V2_MASK)) &&
				CMD_GT_V0(get_cmd_ver(mc_portal));
		if (!portal_in_device_container(cmdif, *instance, portal_indx, search_all_ancestors))
		{
			return 1;
		}
	}
	return 0;
}

static enum mc_cmd_status execute_command(struct cmdif_srv *cmdif,
		struct mc_portal *mc_portal_tmp,
		uint32_t instance,
                uint8_t cmd_ver,
		uint16_t code,
		uint8_t portal_indx)
{
	struct dprc *tmp_dprc = (struct dprc *)cmdif->instance_handle[instance];
	uint16_t module_id = CMDIF_MOD_MODULES_NUM;
	/* get command group from command code */
	enum srv_cmd_group cmd_group = get_cmd_group(code);
	enum mc_cmd_status ret;
	if (cmd_group == CMD_GROUP_CREATE_DESTROY) {
		if (CMD_GT_V0(cmd_ver)) {
			int cmd_type = code & INIT_CMD_TYPE_MASK;
			if (((code & INIT_CMD_MODULE_MASK) != 0) &&
					((cmd_type == INIT_CMD_MASK || /* open */
							cmd_type == CREATE_CMD_MASK) /* create */)) {
				ret = setup_portal(cmdif, mc_portal_tmp, portal_indx);
			} else {/* close || destroy */
				ret = close_portal(cmdif, mc_portal_tmp);
			}
		} else {
			if (instance == 0)
				ret = setup_portal(
						cmdif,
						mc_portal_tmp,
						portal_indx);
			else
				ret = close_portal(
						cmdif,
						mc_portal_tmp);
		}
	} else {
		if (cmd_group == CMD_GROUP_COMMON)
		{
			module_id = get_cmdif_module_from_cmd_module(code & INIT_CMD_MODULE_MASK);
			if (module_id == CMDIF_MOD_MODULES_NUM)
				return MC_CMD_STATUS_NO_RESOURCE;
#ifdef MISC_CMD_SUPPORT
		} else if (cmd_group == CMD_GROUP_MC_MISC) {
			if (cmdif->misc_cb) {
				int ret_code = cmdif->misc_cb(
						NULL,
						cmd_ver,
						code,
						(int)(portal_indx + cmdif->portal_base_id),
						(uint8_t*)&(mc_portal_tmp->data));
				ret = cmdif_code(ret_code);
				return ret;
			}
#endif //MISC_CMD_SUPPORT
		}
		else
			module_id = cmdif->module_id[instance];

		if (module_id == CMDIF_MOD_DPRC)
			switch (code)
			{
				case DPRC_CMD_CODE_ASSIGN :
				case DPRC_CMD_CODE_UNASSIGN :
				case DPRC_CMD_CODE_SET_LOCKED :
					if (tmp_dprc->locked == RESMAN_DPRC_STATE_LOCKED){
						pr_err("Assign/Unassign/Set_locked command on a locked container\n");
						return MC_CMD_STATUS_NO_PRIVILEGE;
					}
				break;
				case DPRC_CMD_CODE_CREATE_CONT :
				case DPRC_CMD_CODE_DESTROY_CONT :
					if (tmp_dprc->locked == RESMAN_DPRC_STATE_LOCKED){
						pr_err("Create/Destroy container command on a locked container\n");
						return MC_CMD_STATUS_NO_PRIVILEGE;
					}
				break;
				default :
				break;
			}
		if (cmdif->ctrl_cb[module_id]) {
			int ret_code = cmdif->ctrl_cb[module_id](
					cmdif->instance_handle[instance],
					cmd_ver,
					code,
					(int)(portal_indx + cmdif->portal_base_id),
					(uint8_t*)&(mc_portal_tmp->data));
			ret = cmdif_code(ret_code);
		} else
			ret = MC_CMD_STATUS_NO_RESOURCE;
	}
		
	return ret;
}

static void excute_high_priority_command(uint64_t portal_indx)
{
	struct cmdif_srv *cmdif = 
			sys_get_handle(FSL_MOD_CMDIF_SRV, 1, core_get_id());
	struct mc_portal *mc_portal;
	struct eiop_rtc *eiop_rtc;
	uint32_t instance;
	uint8_t cmd_ver;
	uint16_t code;
	enum mc_cmd_status cmd_status;
	uint32_t int_flags;
	uint64_t timestamp = 0;
	uint64_t command_time = 0;
	uint64_t timer_overflow_value = (~0);
	uint8_t is_timestamping = 0;
	static uint8_t is_no_timer = 0;
	
	ASSERT_COND (cmdif);
	/*get timestamp before executing the command*/
	if((log_get_timestamp_mode() == LOG_TIMESTAMP_ON) && (log_get_mode() == LOG_MODE_ON))
		if(log_get_global_level() <= LOG_LEVEL_INFO) {
			eiop_rtc = sys_get_handle(FSL_MOD_EIOP_RTC, 1, 0);
			if (eiop_rtc) {
				eiop_rtc_get_current_timestamp(eiop_rtc, &timestamp);
				is_timestamping = 1;
				command_time = timestamp;
			} else if (!is_no_timer) {
				pr_warn("No timer available\n");
				is_no_timer = 1;
			}
		}
	
	mc_portal = (struct mc_portal*)(cmdif->cmdif_base + (portal_indx * sizeof(struct mc_portal)));	
	instance = get_auth_id(cmdif->mc_portal_tmp[portal_indx]);
	code = get_cmdcode(cmdif->mc_portal_tmp[portal_indx]);	 
	cmd_ver = get_cmd_ver(cmdif->mc_portal_tmp[portal_indx]);
	cmd_status = execute_command(cmdif, cmdif->mc_portal_tmp[portal_indx], instance, cmd_ver, code, (uint8_t)portal_indx);

	/*copy back to portal*/
	memcpy(mc_portal, cmdif->mc_portal_tmp[portal_indx], sizeof(struct mc_portal));
	#if 0
							pr_info("HPCmd Done on portal %d [0x%08X] with status 0x%x\n",
									portal_indx, mc_portal, cmd_status);
	#endif
	int_flags = core_local_irq_save();
	cmdif->active_portals[portal_indx/64] &= ~(0x1ULL << (portal_indx % 64));
	core_local_irq_restore(int_flags);
	
	/*calculate and print the command execution time*/
	if(is_timestamping)
		if (eiop_rtc) {
			eiop_rtc_get_current_timestamp(eiop_rtc, &timestamp);
			command_time = timestamp < command_time ? timer_overflow_value - command_time + timestamp : timestamp - command_time;
			pr_info("Command execution time: ~%d us\n", UINT32_LO((command_time/1000)));
		} else if (!is_no_timer) {
			pr_warn("No timer available\n");
			is_no_timer = 1;
		}

	cmd_done(mc_portal, cmd_status, (int)portal_indx);
}

/* high & low priority ISR */
void mc_portal_isr(uint32_t arg)
{
	struct cmdif_srv *cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1,
							core_get_id());
	struct mc_portal *mc_portal;
	uint32_t instance, pending;
	uint8_t portal_indx;
	uint16_t code;
	int ret;
	int portal_busy =0;
	int high = 1;

	UNUSED(arg);
	ASSERT_COND (cmdif);

	pending = ioread32(&(cmdif->cpm_regs->hpspr));
	if((pending & CMD_PORTAL_PENDING_BIT) == 0){
		pending = ioread32(&(cmdif->cpm_regs->lpspr));
		high = 0;
	}		

	while (pending & CMD_PORTAL_PENDING_BIT) {
		portal_indx = (uint8_t)(pending & CMD_PORTAL_INDEX_MASK);

		mc_portal =
			(struct mc_portal*)(cmdif->cmdif_base
						+ (portal_indx
							* sizeof(struct mc_portal)));
		
		command_dump(portal_indx, mc_portal);

		// not closing interrupts because we are in interrupt context
		if( cmdif->active_portals[portal_indx/64] & (0x1ULL << (portal_indx % 64) ) )
		{
			portal_busy = 1;
			pr_err("portal %d is serving previous command!\n", portal_indx);
		}
		
		/* Authentication */
		if(!portal_busy && authenticate(cmdif, mc_portal, &instance, &code, portal_indx) == 0)
		{
			/* copy to temp portal*/  //need to make one for portal?
			memcpy(cmdif->mc_portal_tmp[portal_indx], mc_portal,
					sizeof(struct mc_portal));

			/* check portal error */
			ret = check_portal_err(cmdif, portal_indx,	mc_portal);
			if (ret)
			{
				pr_err("Command error on portal %d, ignoring...\n", portal_indx);
				return;
			}
			cmdif->active_portals[portal_indx/64] |= (0x1ULL << (portal_indx%64));/* no need to close interrupts because we are in interrupt context*/

			clear_portal(cmdif, portal_indx);
if (IS_SIM)
			excute_high_priority_command(portal_indx);
else {
			if (high)
				fsl_schedule_tasklet(excute_high_priority_command, portal_indx, tsk_priority_immediate);
			else
				fsl_schedule_tasklet(excute_high_priority_command, portal_indx, tsk_priority_delayed);
#if 0
			if(instance && cmdif->cmd_priority_cb[cmdif->module_id[instance]] != NULL &&
			   cmdif->cmd_priority_cb[cmdif->module_id[instance]]( cmdif->instance_handle[instance], code))
			{
				fsl_schedule_tasklet(excute_high_priority_command, portal_indx, tsk_priority_delayed);
			}
			else
			{
				if(high)
					list_add_to_tail(&cmdif->cmdif_command[portal_indx].node,&(cmdif->high_priority_list));
				else
					list_add_to_tail(&cmdif->cmdif_command[portal_indx].node,&(cmdif->low_priority_list));
			}
#endif
}
		} else {
			/* authentication error  or busy portal*/
			if(!portal_busy)
				pr_err(
				"Authentication error: invalid token:0x%x set on portal %d\n",
				instance, portal_indx);
			portal_busy = 0;
			clear_portal(cmdif, portal_indx);
			cmd_done(mc_portal, MC_CMD_STATUS_AUTH_ERR,
					portal_indx);
		}
		
		pending = ioread32(&(cmdif->cpm_regs->hpspr));
		if((pending & CMD_PORTAL_PENDING_BIT) == 0)
		{	
			pending = ioread32(&(cmdif->cpm_regs->lpspr));
			high = 0;
		} else
			high = 1;	
	};
}

#if 0
void cmdif_polling(void) //excute_low_priority_command
{
	struct cmdif_srv *cmdif = 
			sys_get_handle(FSL_MOD_CMDIF_SRV, 1, core_get_id());
	struct mc_portal *mc_portal;
	uint8_t portal_indx;
	uint32_t instance;
	uint16_t code;
	uint8_t cmd_ver;
	enum mc_cmd_status cmd_status;
	list_t           *p_node;
	cmdif_command_t	*cmdif_command;
	uint32_t int_flags;
	uint8_t nesting_depth = 0;


	ASSERT_COND (cmdif);

	if(cmdif->nesting_depth >= CMDIF_NESTING_DEPTH)
	{
		pr_debug("reached nesting depth maximum\n");
		return;
	}
	
	while(nesting_depth == 0){
		
		int_flags = core_local_irq_save();
		if(!list_is_empty(&cmdif->high_priority_list)){
			p_node = LIST_FIRST(&cmdif->high_priority_list);
		}else if(!list_is_empty(&cmdif->low_priority_list)){
			p_node = LIST_FIRST(&cmdif->low_priority_list);
		}else{
			core_local_irq_restore(int_flags);
			return;
		}
		//found command
		cmdif_command = LIST_OBJECT(p_node, struct cmdif_command, node);
		list_del(p_node);
		core_local_irq_restore(int_flags);
		
		nesting_depth = cmdif->nesting_depth++;

		portal_indx = cmdif_command->portal_indx;
			
		mc_portal = (struct mc_portal*)(cmdif->cmdif_base + (portal_indx * sizeof(struct mc_portal)));
			                       
		instance = get_auth_id(cmdif->mc_portal_tmp[portal_indx]);
		code = get_cmdcode(cmdif->mc_portal_tmp[portal_indx]);
		cmd_ver = get_cmd_ver(cmdif->mc_portal_tmp[portal_indx]);
		cmd_status = execute_command(cmdif, cmdif->mc_portal_tmp[portal_indx], instance,
                                              cmd_ver, code, portal_indx);

		/*copy back to portal*/
		memcpy(mc_portal, cmdif->mc_portal_tmp[portal_indx], sizeof(struct mc_portal));
		#if 0
		pr_info("HPCmd Done on portal %d [0x%08X] with status 0x%x\n",
									portal_indx, mc_portal, cmd_status);
		#endif
		int_flags = core_local_irq_save();
		cmdif->active_portals[portal_indx/64] &= ~(0x1 << (portal_indx % 64));
		core_local_irq_restore(int_flags);
		cmd_done(mc_portal, cmd_status, portal_indx);
		cmdif->nesting_depth--;
		}
}
#endif

int cmdif_close_dev(void *dev, int portal_id)
{
        struct cmdif_srv *cmdif;
        uint32_t instance;
        uint32_t module_id;
        int ret = 0;
        int cmd_portal_base;

        if(portal_id<256)
        	cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1,0);
        else
        	cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1,1);

        ASSERT_COND(cmdif);

        if (!dev)
                return -ENODEV;

        cmd_portal_base = cmdif->portal_base_id;

        for (instance = 1; instance < MAX_NUM_OF_INSTANCES; instance++) {
                if ((dev == cmdif->instance_handle[instance])  &&
                        (portal_id - cmd_portal_base== cmdif->portal_id[instance])){
                        module_id = cmdif->module_id[instance];

                        ret = cmdif->close_cb[module_id](dev, portal_id, instance);
                        if (ret) {
                                return -EACCES;
                        }
                        remove_cmdif_instance(cmdif, instance);
                        ret = 1;
                }
        }

        if (ret != 1)
                return -ENODEV;

        return 0;
}

int cmdif_register_module(enum cmdif_module module,
	struct cmdif_module_ops *ops)
{
	struct cmdif_srv *cmdif;
	uint8_t module_id;
    int i = 0;
    struct cpm_desc cpm_desc = {0};


	module_id = (uint8_t)module;
    
    while (sys_get_desc(SOC_MODULE_CPM,
                SOC_DB_NO_MATCH_FIELDS,
                &cpm_desc, &i) == 0)
    {
    	cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1, i-1);
		
    	if (!cmdif)
    	{
			pr_err("cmdif_register_module failed no cmdif cpu %d!\n", i);
			return -ENODEV;
    	}

		if (module >= MAX_NUM_OF_MODULES)
			return -ENODEV;

		/* for dprc speical init without device, only with ctrl cb*/
		if (!ops->close_cb || !ops->ctrl_cb || !ops->open_cb)
			return EINVAL;

		/* module already registered before */
		if (cmdif->open_cb[module_id])
			return -EACCES;

		cmdif->open_cb[module_id] = ops->open_cb;
		cmdif->close_cb[module_id] = ops->close_cb;
		cmdif->ctrl_cb[module_id] = ops->ctrl_cb;
		cmdif->cmd_priority_cb[module_id] = ops->cmd_priority_cb;
	}
	return 0;
}

#if 0
int cmdif_unregister_module(enum cmdif_module module)
{
	struct cmdif_srv *cmdif;
	uint8_t module_id;
	int i = 0;
	int j;
	struct cpm_desc cpm_desc = {0};

	module_id = (uint8_t)module;
	   while (sys_get_desc(SOC_MODULE_CPM,
                SOC_DB_NO_MATCH_FIELDS,
                &cpm_desc, &i) == 0)
    {
    	cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1, i-1);
		
    	if (!cmdif)
    	{
			pr_err("cmdif_unregister_module failed no cmdif cpu %d!\n", i);
			return -ENODEV;
    	}
		if (module >= MAX_NUM_OF_MODULES)
			return -ENODEV;

		/* module is not registered */
		if (cmdif->open_cb[module_id])
			return 0;

		for (j = 1; j < MAX_NUM_OF_INSTANCES; j++) {
			if (cmdif->module_id[j] == module_id)
				return -EACCES;
		}

		cmdif->open_cb[module_id] = NULL;
		cmdif->close_cb[module_id] = NULL;
		cmdif->ctrl_cb[module_id] = NULL;
	}
	return 0;
}
#endif

static int config_interrupts(struct cpm_desc *desc)
{
	mpic_intr_params_t intr_params;
	int err;

	intr_params.polarity = OS_MPIC_INTR_POLARITY_HIGH;
	intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;
	intr_params.sense = OS_MPIC_INTR_SENSE_EDGE;
	intr_params.priority = 0xa;

	err = mpic_set_config_intr(desc->irq_hp, (uint32_t)desc->core_id,
			mc_portal_isr, 0, &intr_params); 
	if (err != 0) {
		return err;
	}
	err = mpic_enable_intr(desc->irq_hp);
	if (err != 0) {
		return err;
	}

	intr_params.priority = 0x5;

	err = mpic_set_config_intr(desc->irq_lp, (uint32_t)desc->core_id, mc_portal_isr,
					0, &intr_params);
	if (err != 0) {
		return err;
	}
	err = mpic_enable_intr(desc->irq_lp);
	if (err != 0) {
		return err;
	}
	return 0;
}

#if 0
static int free_interrupts()
{
	int err = 0;

	err = mpic_disable_intr(MC_MPIC_INTR_CPM_1_HP);
	if (err != 0) {
		return err;
	}
	err = mpic_free_intr(MC_MPIC_INTR_CPM_1_HP);
	if (err != 0) {
		return err;
	}

	err = mpic_disable_intr(MC_MPIC_INTR_CPM_1_LP);
	if (err != 0) {
		return err;
	}
	err = mpic_free_intr(MC_MPIC_INTR_CPM_1_LP);
	if (err != 0) {
		return err;
	}

	err = mpic_disable_intr(MC_MPIC_INTR_CPM_2_HP);
	if (err != 0) {
		return err;
	}
	err = mpic_free_intr(MC_MPIC_INTR_CPM_2_HP);
	if (err != 0) {
		return err;
	}

	err = mpic_disable_intr(MC_MPIC_INTR_CPM_2_LP);
	if (err != 0) {
		return err;
	}
	err = mpic_free_intr(MC_MPIC_INTR_CPM_2_LP);
	if (err != 0) {
		return err;
	}

	return err;
}
#endif

static int cmdif_malloc_structures(struct cmdif_srv *cmdif, e_memory_partition_id dmem_partition)
{			
	int   j;
	
	/* D-mem */
	cmdif->instance_handle = 
			fsl_xmalloc(MAX_NUM_OF_INSTANCES * sizeof(void*), dmem_partition, 32);
	if (!cmdif->instance_handle)
		return -ENOMEM;
	memset(cmdif->instance_handle, 0, MAX_NUM_OF_INSTANCES * sizeof(void*));
	cmdif->module_id = 	fsl_xmalloc(MAX_NUM_OF_INSTANCES, dmem_partition, 32);
	if (!cmdif->module_id)
		return -ENOMEM;
	memset(cmdif->module_id, 0, MAX_NUM_OF_INSTANCES);
	cmdif->portal_id = fsl_xmalloc(MAX_NUM_OF_INSTANCES, dmem_partition, 32); 
	if (!cmdif->portal_id)
		return -ENOMEM;
	memset(cmdif->portal_id, 0, MAX_NUM_OF_INSTANCES);
	cmdif->portal_dprc_id = fsl_xmalloc(MAX_NUM_OF_INSTANCES * (sizeof *cmdif->portal_dprc_id), dmem_partition, 32);
	if (!cmdif->portal_dprc_id)
		return -ENOMEM;
	memset(cmdif->portal_dprc_id, RESMAN_NO_CONTAINER_ID, MAX_NUM_OF_INSTANCES * (sizeof *cmdif->portal_dprc_id));
	cmdif->ctrl_cb = fsl_xmalloc(sizeof(void*) * MAX_NUM_OF_MODULES, dmem_partition, 32);
	if (!cmdif->ctrl_cb)
		return -ENOMEM;
	memset(cmdif->ctrl_cb, 0, sizeof(void*) * MAX_NUM_OF_MODULES);
	cmdif->cmd_priority_cb = fsl_xmalloc(sizeof(void*) * MAX_NUM_OF_MODULES, dmem_partition, 32);
	if (!cmdif->cmd_priority_cb)
		return -ENOMEM;
	memset(cmdif->cmd_priority_cb, 0, sizeof(void*) * MAX_NUM_OF_MODULES);
	cmdif->active_portals = fsl_xmalloc(PORTALS_NUM/8, dmem_partition, 32);
	if(!cmdif->active_portals)
		return -ENOMEM;
	memset(cmdif->active_portals, 0, PORTALS_NUM/8);
	for(j=0; j<PORTALS_NUM; j++)
	{	
		cmdif->cmdif_command[j].portal_indx = (uint8_t)j;
		cmdif->mc_portal_tmp[j] = fsl_xmalloc(sizeof(struct mc_portal), dmem_partition ,32);
		if (!cmdif->mc_portal_tmp[j])
			return -ENOMEM;

		memset(cmdif->mc_portal_tmp[j], 0, sizeof(struct mc_portal));
	}
	/*DDR */
	cmdif->open_cb = fsl_malloc(sizeof(void*) * MAX_NUM_OF_MODULES);
	if (!cmdif->open_cb)
		return -ENOMEM;
	memset(cmdif->open_cb, 0, sizeof(void*) * MAX_NUM_OF_MODULES);
	cmdif->close_cb =  fsl_malloc(sizeof(void*) * MAX_NUM_OF_MODULES);
	if (!cmdif->close_cb)
		return -ENOMEM;
	memset(cmdif->close_cb, 0, sizeof(void*) * MAX_NUM_OF_MODULES);
	return 0;
}


int cmdif_srv_init(void)
{
	struct cmdif_srv *cmdif;
	int   j;
	int err;
	struct mc_portal_desc mc_portal_desc;
	int i = 0;
	struct cpm_desc cpm_desc = {0};
	e_memory_partition_id dmem_partition;

	pr_info("Executing cmdif_srv_init...\n");
	
	if (sys_get_unique_handle(FSL_MOD_CMDIF_SRV))
		return -ENODEV;

    while (sys_get_desc(SOC_MODULE_CPM,
                SOC_DB_NO_MATCH_FIELDS,
                &cpm_desc, &i) == 0)

    {
		if(i == 1)
			dmem_partition = MEM_PART_DMEM1;
		else if(i == 2)
			dmem_partition = MEM_PART_DMEM2;
		else
			dmem_partition = MEM_PART_DMEM;
		cmdif = (struct cmdif_srv*)fsl_malloc(sizeof(struct cmdif_srv));
		if (!cmdif)
			return -ENOMEM;
	
		memset(cmdif, 0, sizeof(struct cmdif_srv));		
		cmdif->portal_base_id = (i-1)*256;
		cmdif->nesting_depth = 0;
		
		err = cmdif_malloc_structures(cmdif, dmem_partition);
		if(err)
			return err;
		
		/*init lists*/
		INIT_LIST(&cmdif->low_priority_list);
		INIT_LIST(&cmdif->high_priority_list);
		
		memset(&mc_portal_desc, 0, sizeof(mc_portal_desc));
		mc_portal_desc.portal_id = 0;
		err = sys_get_desc(SOC_MODULE_MC_PORTAL,
					SOC_DB_MC_PORTAL_DESC_ID,
					&mc_portal_desc, NULL);
		if (err)
			return -ENODEV;

		cmdif->cmdif_base = (phys_addr_t)mc_portal_desc.vaddr;
		cmdif->cpm_regs = cpm_desc.vaddr;

		/* set the initialization values to the cpm registers*/
		for (j = 0; j < NUMBER_OF_PORTALS_REGS; j++) {
			/* cleaning received commands register*/
			iowrite32(0xffffffff, &(cmdif->cpm_regs->cprr[j]));
			/* cleaning error commands register*/
			iowrite32(0xffffffff, &(cmdif->cpm_regs->cper[j]));
			/* cleaning priority commands register*/
			iowrite32(0xffffffff, &(cmdif->cpm_regs->cppr[j]));
			/* mask interrupts for all portals */
			iowrite32(0xffffffff, &(cmdif->cpm_regs->cpmr[j]));
		}

#ifdef MISC_CMD_SUPPORT
		/* initialize misc command dispatcher callback */
		cmdif->misc_cb = misc_ctrl_cb;
#endif //MISC_CMD_SUPPORT

		sys_add_handle(cmdif, FSL_MOD_CMDIF_SRV, 1, i-1);
		err = config_interrupts(&cpm_desc);
		if (err != 0) {
			return err;
		}
		pr_info("CPM %d CCSR = 0x%08x%08x)\n", i-1, UINT32_HI(cpm_desc.paddr), UINT32_LO(cpm_desc.paddr));
	}

	return 0;
}
