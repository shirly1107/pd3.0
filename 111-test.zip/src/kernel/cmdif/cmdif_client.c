/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_io.h"
#include "fsl_gen.h"
#include "fsl_dbg.h"
#include "fsl_cmdif_flib_c.h"
#include "fsl_malloc.h"
#include "fsl_core_booke_regs.h"
#include "fsl_aiop_common.h"
#include "fsl_soc.h"
#include "fsl_platform.h"
#include "kernel/device.h"
#include "kernel/layout.h"
#include "fsl_smp.h"

#include "fsl_dpmng_mc.h"
#include "fsl_dpci_mc.h"
#include "fsl_resman.h"
#include "fsl_gen.h"
#include "cmdif_client_flib.h"
#include "cmdif_client.h"
#include "coherent_access.h"

#include "drivers/fsl_qbman_ctrl.h"
#include "drivers/fsl_qbman_portal.h"
#include "drivers/fsl_qbman_portal_ex.h"


#define MC_CBL_CORE_OFF	    0x1000
#define MC_C1BL_START_ADDR  0x21010000
#define MC_C2BL_START_ADDR  MC_C1BL_START_ADDR + MC_CBL_CORE_OFF

static uint32_t cmdif_timeout = 0x10000000;

#define INVALIDATE_DONE \
	l1dcache_block_invalidate((uint32_t)(((struct cmdif_dev *)cidesc->dev)->sync_done))

int cmdif_client_init();

#ifdef DP_DDR_SUPPORT
static void config_memory(uint32_t reg[2], uint8_t core_id)
{
	uint32_t *cbl_addr = (uint32_t *)(MC_C1BL_START_ADDR +
					(core_id * MC_CBL_CORE_OFF));

	reg[0] = ioread32(cbl_addr);
	reg[1] = ioread32(cbl_addr + 1);

	iowrite32(0x00000000, cbl_addr);
	iowrite32(0x00000060, cbl_addr + 1); // DP-DDR
	//iowrite32(0x0000004c,UINT_TO_PTR(MC_C1BL_START_ADDR+4)); // PEB
	//iowrite32(0x00000000,UINT_TO_PTR(MC_C1BL_START_ADDR+4)); // DP-SYSTEM
}

static void reset_config_memory(uint32_t reg[2], uint8_t core_id)
{
	uint32_t *cbl_addr = (uint32_t *)(MC_C1BL_START_ADDR +
					(core_id * MC_CBL_CORE_OFF));

	iowrite32(reg[0], cbl_addr);
	iowrite32(reg[1], cbl_addr + 1);
}
#endif

int cmdif_client_init()
{

	int    err = 0;
	
	pr_info("Executing cmdif_client_init...\n");
	
	if (IS_SIM)
		cmdif_timeout = 0x100000;
	else
		cmdif_timeout = 0x1000000;

	return err;
}

static int send_fd(struct cmdif_fd *cfd, int pr, void *sdev)
{
	struct   cmdif_reg *dev = (struct cmdif_reg *)sdev;
	struct   qbman_eq_desc eqdesc;
	uint32_t fqid = 0;
	int      ret  = 0;
	struct   qbman_fd fd;
	struct   qbman_swp *swp = NULL;
	struct dpmng *dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);

	ASSERT_COND(dpmng);

	if ((pr < 0) || (pr > CMDIF_PRI_HIGH) || (dev == NULL))
		return -EINVAL;

	fqid = dev->tx_queue_attr[pr].fqid;
	pr_debug("Sending to fqid 0x%x\n", fqid);
	dpmng_get_swportal(dpmng, (void **)&swp);
	ASSERT_COND(swp);

	/*********************************/
	/* Prepare a enqueue descriptor */
	/*********************************/
	qbman_eq_desc_clear(&eqdesc);
	qbman_eq_desc_set_no_orp(&eqdesc, 0);
	qbman_eq_desc_set_response(&eqdesc, 0, 0);
	qbman_eq_desc_set_token(&eqdesc, 0x99);
	qbman_eq_desc_set_fq(&eqdesc, fqid);

	/******************/
	/* Copy FD        */
	/******************/
	memset(&fd, 0, sizeof(struct qbman_fd));
	fd.simple.frc     = cfd->u_frc.frc;
	fd.simple.len     = cfd->d_size;
	fd.simple.flc_hi  = cfd->u_flc.word[0];
	fd.simple.flc_lo  = cfd->u_flc.word[1];
	fd.simple.addr_hi = cfd->u_addr.word[0];
	fd.simple.addr_lo = cfd->u_addr.word[1];
	fd.simple.bpid_offset    = (0x1 << 15) | (0x1 << 14);  /* BMT & IVP */

	core_memory_barrier();

	/******************/
	/* Try an enqueue */
	/******************/
	ret = qbman_swp_enqueue(swp, &eqdesc, (const struct qbman_fd *)&fd);
	dpmng_put_swportal(dpmng, (void *)swp);

	return ret;
}

static int receive_fd(struct cmdif_fd *cfd, int pr, void *sdev)
{
	const struct qbman_result *dq_storage;
	struct cmdif_reg *dev = (struct cmdif_reg *)sdev;
	const struct qbman_fd *fd;
	struct qbman_pull_desc pulldesc;
	struct qbman_swp *swp = NULL;
	uint32_t fqid = 0;
	int err = 0;
	struct dpmng *dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);

	ASSERT_COND(dpmng);

	if ((pr < 0) || (pr > CMDIF_PRI_HIGH) || (dev == NULL))
		return -EINVAL;

	fqid = dev->rx_queue_attr[pr].fqid;
	dpmng_get_swportal(dpmng, (void **)&swp);
	ASSERT_COND(swp);

	qbman_pull_desc_clear(&pulldesc);
	qbman_pull_desc_set_storage(&pulldesc, NULL, 0, 0);
	qbman_pull_desc_set_numframes(&pulldesc, 1);
	qbman_pull_desc_set_token(&pulldesc, 0xab);
	qbman_pull_desc_set_fq(&pulldesc, fqid);
	err = qbman_swp_pull(swp, &pulldesc);
	if (err)
		return err;
	do {
		dq_storage = qbman_swp_dqrr_next(swp);
	} while (!dq_storage);

	/* Pull dequeues always produce at least one
	 * result, but if there is nothing to dequeue, the "VALIDFRAME"
	 * flag won't be set */
	if (!(qbman_result_DQ_flags(dq_storage) & QBMAN_DQ_STAT_VALIDFRAME)) {
		qbman_swp_dqrr_consume(swp, dq_storage);
		return -EACCES;
	}

	fd = qbman_result_DQ_fd(dq_storage);
	qbman_swp_dqrr_consume(swp, dq_storage);
	dpmng_put_swportal(dpmng, (void *)swp);

	/******************/
	/* Copy FD        */
	/******************/
	cfd->u_frc.frc      = fd->simple.frc;
	cfd->d_size         = fd->simple.len;
	cfd->u_flc.word[0]  = fd->simple.flc_hi;
	cfd->u_flc.word[1]  = fd->simple.flc_lo;
	cfd->u_addr.word[0] = fd->simple.addr_hi;
	cfd->u_addr.word[1] = fd->simple.addr_lo;

	pr_debug("Received FD from fqid 0x%x\n", fqid);
	return 0;
}

int cmdif_open(struct cmdif_desc *cidesc,
		const char *m_name,
		uint8_t inst_id,
		void *v_data,
		uint32_t size)
{
	struct   cmdif_fd fd;
	int      err = 0;
	int      t   = 0;
#ifdef DP_DDR_SUPPORT
	uint32_t win_reg[2];
	uint8_t  core_id = (uint8_t)core_get_id();
#endif
	struct dpci      *dpci_regs = (struct dpci *)cidesc->regs;
	struct cmdif_reg *regs = fsl_malloc(sizeof(struct cmdif_reg));
	uint64_t p_data = 0;
	int link_up = 0;
	uint8_t i;

	pr_debug("Open for %s\n", m_name);
	if (!regs)
		return -ENOMEM;

	if ((v_data == NULL) || (size == 0))
		return -EINVAL;

	p_data = fsl_virt_to_phys(v_data);
	ASSERT_COND(p_data);


	cidesc->regs = NULL;
	regs->dpci = dpci_regs;

	dpci_get_link_state(regs->dpci, &link_up);
	pr_debug("DPCI link up is %d\n", link_up);
	if (!link_up) {
		err = dpci_enable(regs->dpci);
		if (err) {
			pr_err("Failed dpci_enable err = %d\n");
			fsl_free(regs);
			return -ENAVAIL;
		}
		err = dpci_get_link_state(regs->dpci, &link_up);
		if (!link_up || err) {
			pr_err("Failed dpci link_up = %d err = %d\n",
			       link_up, err);
			fsl_free(regs);
			return -ENAVAIL;
		}
	}

	err |= dpci_get_attributes(regs->dpci, &regs->dpci_attr);
	for (i = 0; i < DPCI_PRIO_NUM; i++){
		err |= dpci_get_rx_queue(regs->dpci, i, &regs->rx_queue_attr[i]);
		err |= dpci_get_tx_queue(regs->dpci, i, &regs->tx_queue_attr[i]);
	}
	if (err) {
		pr_err("Failed to get DPCI queues \n");
		fsl_free(regs);
		return -ENAVAIL;
	}

	err = cmdif_open_cmd(cidesc, m_name, inst_id,
	                     v_data, p_data, size, &fd);
	if (err) {
		fsl_free(regs);
		return err;
	}

	err = send_fd(&fd, CMDIF_PRI_LOW, regs);
	if (err) {
		pr_err("Failed to send FD err %d\n", err);
		fsl_free(regs);
		return err;
	}

	/* Wait for response from Server */
	/* Save transport device for future sends */
	cidesc->regs = regs;
	do {
		INVALIDATE_DONE;
		err = cmdif_sync_ready(cidesc);
		t++;
	} while ((err == 0) && (t < cmdif_timeout));

	if (size > 0)
		fetch(v_data, size);
	err = cmdif_open_done(cidesc);

	if (t == cmdif_timeout)
		return -ETIMEDOUT;
	else
		return err;

	return err;
}

int aiop_evm_cmdif_open(struct cmdif_desc *cidesc, void *v_data, uint32_t size);
int aiop_evm_cmdif_open(struct cmdif_desc *cidesc, void *v_data, uint32_t size)
{
	struct   cmdif_fd fd;
	int      err = 0;
	struct dpci      *dpci_regs = (struct dpci *)cidesc->regs;
	struct cmdif_reg *regs = fsl_malloc(sizeof(struct cmdif_reg));
	struct cmdif_dev *dev;
	uint64_t p_data = 0;
	int link_up = 0;
	uint8_t i;
	const char *m_name = AIOP_SRV_EVM_NAME;

	pr_debug("Open for %s\n", m_name);
	if (!regs)
		return -ENOMEM;

	p_data = fsl_virt_to_phys(v_data);
	ASSERT_COND(p_data);


	cidesc->regs = NULL;
	regs->dpci = dpci_regs;

	dpci_get_link_state(regs->dpci, &link_up);
	pr_debug("DPCI link up is %d\n", link_up);
	if (!link_up) {
		err = dpci_enable(regs->dpci);
		if (err) {
			pr_err("Failed dpci_enable err = %d\n");
			fsl_free(regs);
			return -ENAVAIL;
		}
		err = dpci_get_link_state(regs->dpci, &link_up);
		if (!link_up || err) {
			pr_err("Failed dpci link_up = %d err = %d\n",
			       link_up, err);
			fsl_free(regs);
			return -ENAVAIL;
		}
	}

	err |= dpci_get_attributes(regs->dpci, &regs->dpci_attr);
	for (i = 0; i < DPCI_PRIO_NUM; i++) {
		err |= dpci_get_rx_queue(regs->dpci, i, &regs->rx_queue_attr[i]);
		err |= dpci_get_tx_queue(regs->dpci, i, &regs->tx_queue_attr[i]);
	}
	if (err) {
		pr_err("Failed to get DPCI queues \n");
		fsl_free(regs);
		return -ENAVAIL;
	}

	err = cmdif_open_cmd(cidesc, m_name, 0, v_data, p_data, size, &fd);
	if (err) {
		fsl_free(regs);
		return err;
	}

	/* Prepare MC device */
	cidesc->regs = regs;
	dev = (struct cmdif_dev *)cidesc->dev;
	dev->auth_id = AIOP_SRV_EVM_AUTH_ID;

	return 0;
}

int cmdif_close(struct cmdif_desc *cidesc)
{
	struct   cmdif_fd fd;
	int      err = 0;
	int      t   = 0;
#ifdef DP_DDR_SUPPORT
	uint32_t win_reg[2];
	uint8_t  core_id = (uint8_t)core_get_id();
#endif

	if (cidesc->regs == NULL)
		return -EINVAL;

	err = cmdif_close_cmd(cidesc, &fd);
	if (err) {
		return err;
	}

	err = send_fd(&fd, CMDIF_PRI_LOW, cidesc->regs);
	if (err) {
		pr_err("Failed to send FD err %d\n", err);
		return err;
	}

	/* Wait for response from Server */
	do {
		INVALIDATE_DONE;
		err = cmdif_sync_ready(cidesc);
		t++;
	} while ((err == 0) && (t < cmdif_timeout));

	err = cmdif_close_done(cidesc);
	if (err == 0)
		fsl_free(cidesc->regs);

	if (t == cmdif_timeout)
		return -ETIMEDOUT;
	else
		return err;

	return err;
}

int cmdif_send(struct cmdif_desc *cidesc,
		uint16_t cmd_id,
		uint32_t size,
		int priority,
		uint64_t data,
		cmdif_cb_t *async_cb,
		void *async_ctx)
{
	struct   cmdif_fd fd;
	int      err = 0;
	int      t   = 0;
	uint64_t phys_data = 0;
#ifdef DP_DDR_SUPPORT
	uint32_t win_reg[2];
	uint8_t  core_id = (uint8_t)core_get_id();
#endif

	if (data)
		phys_data = fsl_virt_to_phys((void *)data);

	/* Pass virtual address for async cb to be set correctly
	 * This is MC specific WA because MC DDR space is not SMMU mapped */
	err = cmdif_cmd(cidesc, cmd_id, size, data,
	                async_cb, async_ctx, &fd);
	if (err) {
		pr_err("Failed cmdif_cmd err = %d\n", err);
		return err;
	}

	/* Replace address back to physical
	 * This is MC specific WA because MC DDR space is not SMMU mapped */
	fd.u_addr.d_addr = phys_data;

	err = send_fd(&fd, priority, cidesc->regs);
	if (err) {
		pr_err("Failed to send FD err %d\n", err);
		return err;
	}

	if (cmdif_is_sync_cmd(cmd_id)) {

		/* acquire lock as needed */

		/* Wait for response from Server */
		do {
			INVALIDATE_DONE;
			err = cmdif_sync_ready(cidesc);
			t++;
		} while ((err == 0) && (t < cmdif_timeout));

		if (size > 0)
			fetch((void *)data, size);
		err = cmdif_sync_cmd_done(cidesc);

		/* release lock as needed */

		if (t == cmdif_timeout)
			return -ETIMEDOUT;
		else
			return err;
	}

	return 0;
}

int cmdif_resp_read(struct cmdif_desc *cidesc, int priority)
{
	struct   cmdif_fd fd;
	int      err = 0;
#ifdef DP_DDR_SUPPORT
	uint32_t win_reg[2];
	uint8_t  core_id = (uint8_t)core_get_id();
#endif

	if (cidesc == NULL)
		return -EINVAL;

	err = receive_fd(&fd, priority, cidesc->regs);
	if (err)
		return err;

	while(!err) {
		void *v_addr = NULL;

		if (fd.u_addr.d_addr) {
			v_addr = fsl_phys_to_virt(fd.u_addr.d_addr);
			/* This is MC specific WA because MC DDR space is not SMMU mapped */
			fd.u_addr.d_addr = (uint64_t)v_addr;
		} else {
			pr_err("Addr = NULL\n");
			return -EINVAL;
		}

		if (fd.d_size > 0)
			fetch(v_addr, fd.d_size);
		err = cmdif_async_cb(&fd);
		if (err) {
			pr_err("FAILED cmdif_async_cb() err = %d\n", err);
			return err;
		}

		err = receive_fd(&fd, priority, cidesc->regs);
	}

	return 0;
}

