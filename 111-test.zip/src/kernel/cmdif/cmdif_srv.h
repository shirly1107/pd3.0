/*
 * Copyright 2013-2020 NXP
 */

#ifndef __CMDIF_SRV_H
#define __CMDIF_SRV_H

#include "fsl_types.h"
#include "fsl_cmdif.h"
#include "fsl_cmdif_mc.h"
#include "fsl_list.h"


#define MAX_NUM_OF_INSTANCES    1024
#define MAX_NUM_OF_MODULES      64
#define PORTALS_NUM             256
#define CMDIF_NESTING_DEPTH     2

#define CMD_DESTROY_VER_BASE       CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)

#define CREATE_CMD_MASK         0x900
#define CMD_CODE_DESTROY	0x900
#define INIT_CMD_MASK           0x800
/* New destroy command code mask from MC v10.0.0
were the lower bits provide the module id */
#define DESTROY_CMD_V2_MASK		0x980
#define COMMON_CMD_MASK		0xA00

/* miscellaneous commands mask -
 *  place at the end of spectrum */
#define MC_MISC_CMD_MASK	0xF00

/* For create/destroy/open and device specific commands
the lower 6 bits (of the 12-bit command code) represent the module id */
#define CMD_ID_MODULE_ID_BITS  6
#define INIT_CMD_MODULE_MASK    ((1 << (CMD_ID_MODULE_ID_BITS)) - 1)
/* Mask used to differentiate between create/destroy/open commands;
 these commands share the module id.*/
#define INIT_CMD_TYPE_MASK	(~INIT_CMD_MODULE_MASK)
/* greater than first or '0' version */
#define CMD_GT_V0(cmd)	((cmd) > MC_CMD_HDR_NO_VER)

enum srv_cmd_group {
    CMD_GROUP_CREATE_DESTROY = 0x1,     /* group of commands used to create/open and destroy objects */
    CMD_GROUP_COMMON = 0x2,             /* group of commands with the same code over all modules
                                          not necessarily requires an objects instance to complete @see dpxx_get_version*/
    CMD_GROUP_SPECIFIC = 0x3,           /* group of commands specific for every module - objects instance is required*/
    CMD_GROUP_MC_MISC = 0x4,           /* group of miscellaneous commands - for internal use only - */
    CMD_GROUP_INVALID
};

#define NUMBER_OF_PORTALS_REGS  8

struct mc_cpm_regs {
	uint32_t cpmr[NUMBER_OF_PORTALS_REGS];	/**< command portal mask */
	uint32_t cprr[NUMBER_OF_PORTALS_REGS];	/**< command portal received */
	uint32_t cper[NUMBER_OF_PORTALS_REGS];	/**< command portal error */
	uint32_t cppr[NUMBER_OF_PORTALS_REGS];	/**< command Priority */
	uint32_t res1[16];
	uint32_t hpspr;		/**< high priority selected portal */
	uint32_t res2[7];
	uint32_t lpspr;		/**< low priority selected portal */
};

typedef struct cmdif_command {
	uint8_t 			portal_indx;
	struct list         node;
} cmdif_command_t;

struct cmdif_srv {

	/* D-mem structures*/
	struct mc_portal *mc_portal_tmp[PORTALS_NUM];
	uint64_t 		 *active_portals; /*bitmap*/
	cmdif_command_t	 cmdif_command[PORTALS_NUM];
	list_t  			low_priority_list;
	list_t  			high_priority_list;
	ctrl_cb **ctrl_cb; /**< execution callbacks one per module */
	cmd_priority_cb **cmd_priority_cb; /**< callbacks for checking if a command is high priority, one per module */
	void  **instance_handle;/**< array of instances handles(converted from the authentication ID) in the size of MAX_NUM_OF_INSTANCES */
	uint8_t *module_id;/**< converts ID to module for cb */
	uint8_t *portal_id;/**< converts ID to portal number used for authentication */
	int *portal_dprc_id; /**< the id of the dprc containing the portal on which the instance/device was opened. */
	phys_addr_t cmdif_base;
	struct mc_cpm_regs *cpm_regs;
	uint16_t instances_counter;
	/*DDR structures */
	open_cb **open_cb; /**<open(init) callbacks, one per module*/
	close_cb **close_cb; /**<close(de-init) callbacks, one per module*/
	int  	portal_base_id;
	/*nesting*/
	uint8_t  nesting_depth;
	
#ifdef MISC_CMD_SUPPORT	
	ctrl_cb	*misc_cb;	/**< misccellaneous callback */
#endif //MISC_CMD_SUPPORT	
};

void mc_portal_isr(uint32_t arg);
int cmdif_srv_init(void);
enum mc_cmd_status create_portal(enum cmdif_module cmdif_module,
		struct mc_cmd_data *cmd_data, 
		uint32_t portal_id);

#endif /* __CMDIF_SRV_H */
