/*
 * Copyright 2013-2020 NXP
 */

#include "buffer_pool.h"
#include "fsl_spinlock.h"
#include "buffer_pool.h"
#include "fsl_dbg.h"

#define __ERR_MODULE__  MODULE_UNKNOWN



int buffer_pool_create(struct buffer_pool    **bf_pool,
                       const uint32_t        bf_pool_id,
                       const uint32_t        num_buffs,
                       const uint32_t        buff_size,
                       void * h_boot_mem_mng)
{
	int rc = -ENOMEM;
	uint32_t curr_addr = 0;
	uint8_t *p_buffers_start = NULL;
	uint8_t *p_buffers_end = NULL;
	uint32_t *p_buffers_stack = NULL;
	
	struct initial_mem_mng* boot_mem_mng = NULL;
	ASSERT_COND_LIGHT(h_boot_mem_mng);
	
	if ((num_buffs == 0) || (buff_size == 0))
		return 0;
	
	boot_mem_mng = (struct initial_mem_mng*)h_boot_mem_mng;
	/* Allocate stack of pointers to buffers */
	rc =  boot_get_mem_virt(boot_mem_mng,sizeof(struct buffer_pool),&curr_addr);
	if(rc){
		pr_err("MAJOR memory allocation failed: buffer_pool create\n");
		return -ENOMEM;
	}
	*bf_pool = (struct buffer_pool *)curr_addr;
	rc =  boot_get_mem_virt(boot_mem_mng,num_buffs * sizeof(uint32_t),&curr_addr);
	if(rc){
		pr_err("MAJOR memory allocation failed: buffer_pool\n");
		return -ENOMEM;
	}
	(*bf_pool)->p_buffers_stack = (uint32_t*)curr_addr;
	 /* store info about this buffer pool */
	(*bf_pool)->num_buffs = num_buffs;
	(*bf_pool)->current = 0;
	(*bf_pool)->buff_size = (uint16_t)buff_size;
	(*bf_pool)->bf_pool_id = bf_pool_id;
	sys_init_spinlock(&(*bf_pool)->lock);
	/* Allocate buffers */
	rc =  boot_get_mem_virt(boot_mem_mng,num_buffs * buff_size,&curr_addr);
	if(rc){
		pr_err("MAJOR memory allocation failed: buffer_pool\n");
		return -ENOMEM;
	}
	(*bf_pool)->p_buffers = (uint8_t*)(curr_addr);
	p_buffers_start = (*bf_pool)->p_buffers;
	p_buffers_end = p_buffers_start + (num_buffs * buff_size);
	p_buffers_stack = (*bf_pool)->p_buffers_stack;
	/* initialize the buffers */
	do 
	{
		*(p_buffers_stack++) = PTR_TO_UINT(p_buffers_start);
		p_buffers_start += buff_size;
	}while (p_buffers_start != p_buffers_end);
	
	return 0;

}

int get_buff(struct buffer_pool *bf_pool, uint32_t *buffer_addr)
{
	uint32_t        int_flags = 0;
	ASSERT_COND(bf_pool);
	int_flags = spin_lock_irqsave(&bf_pool->lock);
	/* check if there is an available buffer */
	if (bf_pool->current == bf_pool->num_buffs)
	{
		pr_err("MAJOR buffer pool memory depletion for id = %d, num_buffs = %d\n",
		bf_pool->bf_pool_id, bf_pool->num_buffs);
		spin_unlock_irqrestore(&bf_pool->lock, int_flags);
		ASSERT_COND(0);
		return -ENOMEM;
	}
	/* get the buffer */
	*buffer_addr = (bf_pool->p_buffers_stack[bf_pool->current]);
#ifdef DEBUG
	bf_pool->p_buffers_stack[bf_pool->current] = 0;
#endif /* DEBUG */
	/* advance current index */
	bf_pool->current++;
	spin_unlock_irqrestore(&bf_pool->lock, int_flags);
	return 0;
}

int put_buff(struct buffer_pool  *bf_pool, const void *p_buffer)
{
	uint32_t   int_flags = 0;
	ASSERT_COND(bf_pool);
	int_flags = spin_lock_irqsave(&bf_pool->lock);
	/* check if buffers stack is full */
	if (bf_pool->current > 0)
	{
		/* decrease current index */
		bf_pool->current--;
		/* put the buffer */
		bf_pool->p_buffers_stack[bf_pool->current] = PTR_TO_UINT(p_buffer);
		spin_unlock_irqrestore(&bf_pool->lock, int_flags);
		return 0;
	}
	spin_unlock_irqrestore(&bf_pool->lock, int_flags);
	return -ENOSPC;
}

uint32_t caclculate_num_buffs(uint32_t mem_size,uint16_t  buff_size)
{
	uint32_t buffers_mem  = mem_size - sizeof(struct buffer_pool);
	return buffers_mem/(sizeof(uint32_t) + buff_size);
}
