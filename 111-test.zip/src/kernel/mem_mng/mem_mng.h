/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 @File          mem_mng.h

 @Description   Internal definitions for memory allocation management module.
*//***************************************************************************/
#ifndef __MEM_MNG_H
#define __MEM_MNG_H

#include "fsl_mem_mng.h"
#include "fsl_list.h"


#define __ERR_MODULE__  MODULE_UNKNOWN

#define PLATFORM_MAX_MAP_VIRT_PHYS_ENTRIES   1

/**************************************************************************//**
 @Description  MEM_PART_SYSTEM_DDR1_BOOT_MEM_MNG  virtual addr offset
*//***************************************************************************/
extern const uint32_t  g_boot_mem_mng_offset;

/**************************************************************************//**
 @Description  MEM_PART_SYSTEM_DDR1_BOOT_MEM_MNG size
*//***************************************************************************/
extern const uint32_t  g_buffer_pool_size;

#ifdef MEM_MNG_REC_ALLOC_INFO

	typedef struct t_mem_mng_debug_entry
	{
		void        *p_memory;
		uint32_t    size;
		const char  *info;
		const char  *filename;
		int         line;
		list_t      node;
	} t_mem_mng_debug_entry;
	
	#define MEM_MNG_DBG_OBJECT(p_list)  \
		LIST_OBJECT(p_list, t_mem_mng_debug_entry, node)

#endif //MEM_MNG_REC_ALLOC_INFO


#define MEM_MNG_PARTITION_OBJECT(p_list)  \
    LIST_OBJECT(p_list, t_mem_mng_partition, node)

#define MEM_MNG_PHYS_ADDR_ALLOC_PARTITION_OBJECT(p_list)  \
    LIST_OBJECT(p_list, t_mem_mng_phys_addr_alloc_partition, node)






typedef enum buffer_pool_type{
	E_BFT_SLOB_BLOCK = 0,
	E_BFT_DEBUG_BLOCK
} e_buffer_pool_type;

/**************************************************************************//**
 @Function      mem_mng_get_partition_info

 @Description   Get information and usage statistics of a selected partition.
*//***************************************************************************/
int mem_mng_get_partition_info(void *               h_mem_mng,
                                 int                    partition_id,
                                 t_mem_mng_partition_info  *p_partition_info);

/**************************************************************************//**
 @Function      mem_mng_get_phys_partition_info

 @Description   Get information and usage statistics of a selected partition.
*//***************************************************************************/
int mem_mng_get_phys_partition_info(void * h_mem_mng, uint32_t partition_id,
                                  t_mem_mng_phys_addr_alloc_info *p_partition_info);

/**************************************************************************//**
 @Description   Memory management module initialization parameters
 *//***************************************************************************/
typedef struct t_mem_mng_param
{
    void *    lock;
                /**< We might not have malloc at the beginning, so we
                     need the spinlock object to be allocated outside of the manager */
} t_mem_mng_param;

/**************************************************************************//**
@Description   Memory management partition control structure
 *//***************************************************************************/
typedef struct t_mem_mng_partition
{
    int                     id;             /**< Partition ID */
    void *                h_mem_manager;   /**< Memory manager handle */
    int                     was_initialized;
    list_t                  mem_debug_list;   /**< List of allocation entries (for debug) */
    list_t                  node;
    t_mem_mng_partition_info   info;           /**< Partition information */
    void *                lock;
} t_mem_mng_partition;

/**************************************************************************//**
 @Description   Memory management partition control structure
 *//***************************************************************************/
typedef struct t_mem_mng_phys_addr_alloc_partition
{
    int                              id;             /**< Partition ID */
    void *                     h_mem_manager;   /**< Memory manager handle */
    list_t                           node;
    t_mem_mng_phys_addr_alloc_info   info;           /**< Partition information */
    void *                           lock;
    uint64_t 	                     curr_paddress;
    int                              was_initialized;
    list_t                  mem_debug_list;   /**< List of allocation entries (for debug) */
} t_mem_mng_phys_addr_alloc_partition;

typedef struct t_sys_virt_mem_map
{
    uint64_t    virt_addr;
    uint64_t    phys_addr;
    uint64_t    size;
    uint32_t    was_initialized;
} t_sys_virt_mem_map;

/**************************************************************************//**
 @Description   Memory management module internal parameters
 *//***************************************************************************/
typedef struct t_mem_mng
{
    t_mem_mng_partition mem_partitions_array[PLATFORM_MAX_MEM_INFO_ENTRIES];
                /**< List of partition control structures */
    t_mem_mng_phys_addr_alloc_partition
           phys_allocation_mem_partitions_array[PLATFORM_MAX_MEM_INFO_ENTRIES];
                /**< List of partition for fsl_get_mem function() control structures */
    t_sys_virt_mem_map          virt_mem_array[PLATFORM_MAX_MAP_VIRT_PHYS_ENTRIES];
    uint32_t    mem_partitions_initialized;
    void * h_boot_mem_mng;
    void * h_slob_bf_pool;
    int		enable_debug;
    int		report_mem_leaks;
} t_mem_mng;

/**************************************************************************//**
 @Function      SYS_GetMemPartitionBase

 @Description   Retrieves the base address of a given memory partition.

 @Param[in]     partitionId - Memory partition ID

 @Return        Base address of the memory partition.
*//***************************************************************************/
uint64_t sys_get_mem_partition_base(int partition_id);

/**************************************************************************//**
 @Function      SYS_GetMemPartitionAttributes

 @Description   Retrieves the memory attributes mask of a given memory partition.

 @Param[in]     partitionId - Memory partition ID

 @Return        Memory attributes of the memory partition.
*//***************************************************************************/
uint32_t sys_get_mem_partition_attributes(int partition_id);

/**************************************************************************//**
 @Function      MEM_MNG_Init

 @Description   Initialize the memory allocation management module.

 @Param[in]     p_mem_mng_param - MEM_MNG initialization parameters.

 @Param[in]     h_boot_mem_mng - Handle to boot memory manage.

 @Return        Handle to initialized MEM_MNG object, or NULL on error.
*//***************************************************************************/
void *  mem_mng_init(void * h_boot_mem_mng,
                           t_mem_mng_param *p_mem_mng_param);
/**************************************************************************//**
 @Function      MEM_MNG_Free

 @Description   Free the memory allocation management module.

 @Param[in]     h_mem_mng - Handle to MEM_MNG object.

 @Param[in]     h_boot_mem_mng - Handle to boot memory manage.

 @Return        None.
*//***************************************************************************/
void mem_mng_free(void * h_mem_mng, void * h_boot_mem_mng);
/**************************************************************************//**/
void * mem_mng_alloc_mem(void *    h_mem_mng,
                        int         partition_id,
                        uint32_t    size,
                        uint32_t    alignment,
                        const char  *info,
                        const char  *filename,
                        int         line);
/**************************************************************************//**/
void mem_mng_free_mem(void * h_mem_mng, void *p_memory);
/**************************************************************************//**/
int mem_mng_get_phys_mem(void *    h_mem_mng,
                        int         partition_id,
                        uint64_t    size,
                        uint64_t    alignment,
                        uint64_t*  paddr);
/**************************************************************************//**/
void mem_mng_put_phys_mem(void * h_mem_mng, uint64_t p_memory);
/**************************************************************************//**/
void mem_mng_xfree_mem(void * h_mem_mng, void *p_memory);
/**************************************************************************//**
 @Function      mem_mng_get_phys_addr_alloc_info
 @Description   Get information and usage statistics of a selected partition.
//***************************************************************************/
int mem_mng_get_phys_addr_alloc_info(void *               h_mem_mng,
                                 int                    partition_id,
                                 t_mem_mng_phys_addr_alloc_info  *p_partition_info);
/**************************************************************************//**/
typedef void (t_mem_mng_leak_report_func)(void      *p_memory,
                                      uint32_t  size,
                                      const char *info,
                                      const char *filename,
                                      uint32_t       line);
/**************************************************************************//**/
int mem_mng_mem_partitions_init_completed(void * h_mem_mng);
/**************************************************************************//**/
int mem_mng_register_virt_mem_mapping(void *h_mem_mng,
                                      uint64_t virt_addr,
                                      uint64_t phys_addr,
                                      uint64_t size);
/**************************************************************************//**/
int mem_mng_unregister_virt_mem_mapping(void *h_mem_mng,uint64_t virt_addr);
/**************************************************************************//**/
uint64_t mem_mng_virt_to_phys(void *h_mem_mng,void *virt_addr);
/**************************************************************************//**/
void *mem_mng_phys_to_virt(void *h_mem_mng,dma_addr_t phys_addr);

/**************************************************************************//**/
int mem_mng_register_phys_addr_alloc_partition(void *  h_mem_mng,
                                  int       partition_id,
                                  uint64_t base_paddress,
                                  uint64_t  size,
                                  uint32_t  attributes,
                                  char      name[]);
/**************************************************************************//**/
int mem_mng_register_partition(void *  h_mem_mng,
                                  int       partition_id,
                                  uintptr_t base_address,
                                  uint64_t  size,
                                  uint32_t  attributes,
                                  char      name[]);
/**************************************************************************//**/
int mem_mng_unregister_partition(void * h_mem_mng, int partition_id);

/**************************************************************************//**/
int mem_mng_get_partition_id_by_addr(void *   h_mem_mng,
                                     uint64_t   addr,
                                     int        *p_partition_id);
/**************************************************************************//**
 @Function      boot_mem_mng_init

 @Description   Initialize the memory allocation management module.

 @Param[in]     boot_mem_mng - MEM_MNG initialization parameters.

 @Return        Handle to initialized MEM_MNG object, or NULL on error.
*//***************************************************************************/
int boot_mem_mng_init(struct initial_mem_mng* boot_mem_mng);

/**************************************************************************//**
 @Function      boot_mem_mng_free

 @Description   Free the memory allocation management module.

 @Param[in]     boot_mem_mng - initial_mem_mng

 @Return        None.
*//***************************************************************************/
int boot_mem_mng_free(struct initial_mem_mng* boot_mem_mng);

/*****************************************************************************/
uint32_t boot_get_free_mem(struct initial_mem_mng* boot_mem_mng);

/**************************************************************************//**
 @Function      mem_mng_print_partition_info

 @Description   Prints information and statistics of the given memory partition,
                and possibly reports known memory leaks.

 @Param[in]     p_partition - Memory partition
 @Param[in]     reportLeaks - '1' to report memory leaks; 0 otherwise.
 @Param[in]     h_report - handler to a report method

 @Return        None.
*//***************************************************************************/
void mem_mng_print_partition_info(t_mem_mng_partition *p_partition, int reportLeaks,
		t_mem_mng_leak_report_func *h_report);

/**************************************************************************//**
 @Function      mem_mng_print_phys_partition_info

 @Description   Prints information and statistics of the given memory partition,
                and possibly reports known memory leaks.

 @Param[in]     p_partition - Memory partition
 @Param[in]     reportLeaks - '1' to report memory leaks; 0 otherwise.
 @Param[in]     h_report - handler to a report method

 @Return        None.
*//***************************************************************************/
void mem_mng_print_phys_partition_info(t_mem_mng_phys_addr_alloc_partition *p_partition,
												int reportLeaks, t_mem_mng_leak_report_func *h_report);

#ifdef MEM_MNG_COUNT_ALLOC
/**************************************************************************//**
 @Function      mem_mng_set_alloc_flags

 @Description   set allocator flags for memory manager enable/disable debug,
				enable/disable memory leaks report

 @Param[in]     h_mem_mng - global memory manger handler
 @Param[in]     flags - allocator flags (count alloc, record alloc info).

 @Return        None.
*//***************************************************************************/
void mem_mng_set_alloc_flags(void *h_mem_mng, uint32_t flags);

/**************************************************************************//**
 @Function      mem_mng_check_alloc_leaks

 @Description   check if there are memory leaks in all if the
 	 	 	 	 regitered partitions

 @Param[in]     h_mem_mng - global memory manger handler

 @Return        None.
*//***************************************************************************/
int32_t mem_mng_check_alloc(void *h_mem_mng);
#endif //MEM_MNG_COUNT_ALLOC

/**************************************************************************//**
 @Function      mem_mng_print_alloc_records

 @Description   print recorded allocation status for all registered partitions,
				alloc/dealloc counters, memory leaks report

 @Param[in]     h_mem_mng - global memory manger handler
 @Param[in]     f_report_leak - handler to report method
 
 @Return        None.
*//***************************************************************************/
void mem_mng_print_alloc_info(void *h_mem_mng, t_mem_mng_leak_report_func *f_report_leak);

#endif /* __MEM_MNG_H */

