/*
 * Copyright 2013-2020 NXP
 */


#include "fsl_spinlock.h"
#include "fsl_dbg.h"


#include "fsl_mem_mng.h"
#include "mem_mng.h"
#include "fsl_system.h"
#include "fsl_malloc.h"
#include "fsl_mc.h"



int     sys_init_memory_management(void);
int     sys_free_memory_management(void);

static void     sys_print_mem_leak(void        *p_memory,
                                uint32_t    size,
                                const char        *info,
                                const char        *filename,
                                uint32_t         line);

void sys_mem_partitions_init_complete()
{
    mem_mng_mem_partitions_init_completed(sys.mem_mng);
}

int sys_register_virt_mem_mapping(uint64_t virt_addr, uint64_t phys_addr, uint64_t size)
{
    ASSERT_COND(sys.mem_mng);
    return mem_mng_register_virt_mem_mapping(sys.mem_mng,virt_addr, phys_addr, size);
}

int sys_unregister_virt_mem_mapping(uint64_t virt_addr)
{
    ASSERT_COND(sys.mem_mng);
    return mem_mng_unregister_virt_mem_mapping(sys.mem_mng,virt_addr);
}

dma_addr_t sys_virt_to_phys(void *virt_addr)
{
    if(NULL != sys.mem_mng)
        return mem_mng_virt_to_phys(sys.mem_mng,virt_addr);
    else
        return  (dma_addr_t)virt_addr;
}

void * sys_phys_to_virt(dma_addr_t phys_addr)
{
    if(sys.mem_mng)
	    return mem_mng_phys_to_virt(sys.mem_mng,phys_addr);
    return UINT_TO_PTR(phys_addr);
}

void * sys_mem_alloc(int         partition_id,
                    uint32_t    size,
                    uint32_t    alignment,
                    const char  *info,
                    const char  *filename,
                    int         line)
{
    void *p_memory;

    ASSERT_COND(sys.mem_mng);
    if(0 == size)
    {
        pr_err("sys_mem_alloc(): invalid value: allocation size must be positive\n");
        return NULL;
    }
    p_memory = mem_mng_alloc_mem(sys.mem_mng,
                                partition_id,
                                size,
                                alignment,
                                info,
                                filename,
                                line);

    return p_memory;
}

void sys_mem_free(void *p_memory)
{
    ASSERT_COND(sys.mem_mng);

    mem_mng_free_mem(sys.mem_mng, p_memory);
}

void sys_mem_xfree(void *p_memory)
{
    ASSERT_COND(sys.mem_mng);

    mem_mng_xfree_mem(sys.mem_mng, p_memory);
}

int sys_register_phys_addr_alloc_partition(int  partition_id,
        uint64_t  base_paddress,
        uint64_t   size,
         uint32_t   attributes,
         char       name[])
{
	int err_code;
	ASSERT_COND(sys.mem_mng);
	 if (partition_id == SYS_DEFAULT_HEAP_PARTITION)
	 {
            pr_err("MAJOR invalid value in sys_register_phys_addr_alloc_partition:"
                   " partition ID %d is reserved for default heap\n",
                   SYS_DEFAULT_HEAP_PARTITION);
	        return -EDOM;
	 }
	 err_code = mem_mng_register_phys_addr_alloc_partition(sys.mem_mng,
	                                         partition_id,
	                                         base_paddress,
	                                         size,
	                                         attributes,
	                                         name);
	  if (err_code != 0)
	  {
          if(-EEXIST == err_code)
              pr_err("MAJOR resource already exists\n");
          else if(-EAGAIN == err_code)
              pr_err("MAJOR resource is unavailable\n");
          return err_code;
	  }
	  return 0;
}

int sys_register_mem_partition(int        partition_id,
                                 uintptr_t  base_address,
                                 uint64_t   size,
                                 uint32_t   attributes,
                                 char       name[])
{
    int err_code;

    ASSERT_COND(sys.mem_mng);

    if (partition_id == SYS_DEFAULT_HEAP_PARTITION)
    {
        pr_err("MAJOR invalid value in sys_register_mem_partition: partition ID %d is reserved for default heap",
                SYS_DEFAULT_HEAP_PARTITION);
        return -EDOM;
    }

    err_code = mem_mng_register_partition(sys.mem_mng,
                                        partition_id,
                                        base_address,
                                        size,
                                        attributes,
                                        name);
    if (err_code != 0)
    {
        if(-EEXIST == err_code)
            pr_err("MAJOR resource already exists\n");
        else if(-EAGAIN == err_code)
            pr_err("MAJOR resource is unavailable \n");
        return err_code;
    }

    return 0;
}

int sys_unregister_mem_partition(int partition_id)
{
    int err_code;

    ASSERT_COND(sys.mem_mng);

    if (partition_id == SYS_DEFAULT_HEAP_PARTITION)
    {
	    pr_err("Invalid value in sys_unregister_mem_partition: partition ID %d"
	   "is reserved for default heap",SYS_DEFAULT_HEAP_PARTITION);
	    return -EDOM;
    }

    err_code = mem_mng_unregister_partition(sys.mem_mng, partition_id);

    if (err_code != 0)
    {
        return err_code;
    }

    return 0;
}

int sys_get_mem_partition_info(int partition_id,t_mem_mng_partition_info* partition_info)
{
    int                 err_code;

    ASSERT_COND(sys.mem_mng);

    if (partition_id == SYS_DEFAULT_HEAP_PARTITION)
    {
	   pr_err("Invalid value in sys_get_mem_partition_info: partition ID %d is "
	           "reserved for default heap",SYS_DEFAULT_HEAP_PARTITION);
	   return -EDOM;
    }


    err_code = mem_mng_get_partition_info(sys.mem_mng, partition_id, partition_info);

    if (err_code != 0)
    {
        return (uint32_t)ILLEGAL_BASE;
    }

    return 0;
}

int sys_get_phys_addr_alloc_partition_info(int partition_id,
                                           t_mem_mng_phys_addr_alloc_info* partition_info)
{
    int                 err_code;

    ASSERT_COND(sys.mem_mng);

    if (partition_id == SYS_DEFAULT_HEAP_PARTITION)
    {
	   pr_err("Invalid value in sys_get_phys_addr_alloc_partition_info: "
	          "partition ID %d is reserved for default heap",
	          SYS_DEFAULT_HEAP_PARTITION);
	  return -EDOM;
    }


    err_code = mem_mng_get_phys_addr_alloc_info(sys.mem_mng, partition_id, partition_info);

    if (err_code != 0)
    {
        return (uint32_t)ILLEGAL_BASE;
    }

    return 0;
}

uint64_t sys_get_mem_partition_base(int partition_id)
{
    t_mem_mng_partition_info   partition_info;
    int                 err_code;

    ASSERT_COND(sys.mem_mng);


    if (partition_id == SYS_DEFAULT_HEAP_PARTITION)
    {
        pr_err("Invalid value in sys_get_mem_partition_base: partition ID %d is"
	        "reserved for default heap",SYS_DEFAULT_HEAP_PARTITION);
	return -EDOM;
    }

    err_code = mem_mng_get_partition_info(sys.mem_mng, partition_id, &partition_info);

    if (err_code != 0)
    {
        return (uint32_t)ILLEGAL_BASE;
    }

    return partition_info.base_address;
}

uint32_t sys_get_mem_partition_attributes(int partition_id)
{
    t_mem_mng_partition_info   partition_info;
    int                 err_code;

    ASSERT_COND(sys.mem_mng);

    if (partition_id == SYS_DEFAULT_HEAP_PARTITION)
    {
        pr_err("Invalid value in sys_get_mem_partition_attributes: partition"
	       "ID %d is reserved for default heap",SYS_DEFAULT_HEAP_PARTITION);
        return 0;
    }

    err_code = mem_mng_get_partition_info(sys.mem_mng, partition_id, &partition_info);

    if (err_code != 0)
    {
        return (uint32_t)0;
    }

    return partition_info.attributes;
}

int sys_init_memory_management(void)
{
    t_mem_mng_param mem_mng_param;

    /* initialize boot memory manager to use MEM_PART_SYSTEM_DDR1_NON_CACHEABLE*/
    boot_mem_mng_init(&sys.boot_mem_mng);
    sys.mem_mng = mem_mng_init(&sys.boot_mem_mng,&mem_mng_param);
    if (!sys.mem_mng)
    {
        pr_err("MAJOR resource is unavailable: memory management object\n");
        return -EAGAIN;
    }
    return 0;
}

int sys_free_memory_management(void)
{
    if (sys.mem_mng)
    {
        mem_mng_free(sys.mem_mng,&sys.boot_mem_mng);
        sys.mem_mng = NULL;
    }

    return 0;
}

static void sys_print_mem_leak(void        *p_memory,
                            uint32_t    size,
                            const char        *info,
                            const char        *filename,
                            uint32_t         line)
{
    UNUSED(size);
    UNUSED(info);

    pr_info("memory leak: %dB at %09p, %s->%s:%d\r\n", size, p_memory, info, filename, line);
}

int  sys_get_phys_mem(uint64_t size, int mem_partition_id, uint64_t alignment,
                 uint64_t* paddr)
{

	ASSERT_COND(sys.mem_mng);
	if( 0 == size)
	{
	    pr_err("sys_mem_alloc(): invalid value: allocation size must be positive\n");
	    return -EINVAL;
	}
	return  mem_mng_get_phys_mem(sys.mem_mng,
                                mem_partition_id,
                                size,
	                        alignment,
	                        paddr);
}

void  sys_put_phys_mem(uint64_t paddr)
{

	ASSERT_COND(sys.mem_mng);
	mem_mng_put_phys_mem(sys.mem_mng,paddr);
}

int sys_mem_exists(int mem_partition_id)
{
    struct mem_desc peb_desc = {0};
    struct dmem_desc dmem_desc = {0};
    struct mem_desc dpddr_desc = {0};
    switch(mem_partition_id)
    {
        case MEM_PART_SYSTEM_DDR1_CACHEABLE:
            if(g_system_ddr1_cacheable_size > 0)
        	    return 1;
            return 0;
        case MEM_PART_SYSTEM_DDR1_NON_CACHEABLE:
            if(g_system_ddr1_non_cacheable_size > 0)
                return 1;
            return 0;
        case MEM_PART_DP_DDR:
            if(0 != sys_get_desc(SOC_MODULE_DPDDR, 0, &dpddr_desc, NULL))
                return 0;
            return (dpddr_desc.size > 0);
        case MEM_PART_SYSTEM_DDR1:
            if(dpaa_sys_ddr_size > 0)
                return 1;
            return 0;
        case MEM_PART_SYSTEM_DDR2:
            if(mc_sys_ddr2_size > 0)
                return 1;
            return 0;
        case MEM_PART_DMEM:
            dmem_desc.core_id = (int)core_get_id()+1;
            if (0 != sys_get_desc(SOC_MODULE_DMEM, SOC_DB_DMEM_DESC_CORE_ID, &dmem_desc, NULL))
                return 0;
            return (dmem_desc.block_size > 0);
        case MEM_PART_DMEM1:
            dmem_desc.core_id = 1;
            if (0 != sys_get_desc(SOC_MODULE_DMEM, SOC_DB_DMEM_DESC_CORE_ID, &dmem_desc, NULL))
                return 0;
            return (dmem_desc.block_size > 0);
        case MEM_PART_DMEM2:
            dmem_desc.core_id = 2;
	    if (0 != sys_get_desc(SOC_MODULE_DMEM, SOC_DB_DMEM_DESC_CORE_ID, &dmem_desc, NULL))
		return 0;
	    return (dmem_desc.block_size > 0);
        case MEM_PART_PEB:
            if (0 != sys_get_desc(SOC_MODULE_PEBM, 0, &peb_desc, NULL))
                return 0;
            return (peb_desc.size > 0);
        default:
            return 0;
    }
}

uint64_t sys_mem_size(int mem_partition_id)
{
	struct mem_desc peb_desc = {0};
	struct dmem_desc dmem_desc = {0};
	struct mem_desc dpddr_desc = {0};
	switch(mem_partition_id)
	{
		case MEM_PART_SYSTEM_DDR1_CACHEABLE:
			return g_system_ddr1_cacheable_size;
		case MEM_PART_SYSTEM_DDR1_NON_CACHEABLE:
			return g_system_ddr1_non_cacheable_size;
		case MEM_PART_DP_DDR:
			if(0 != sys_get_desc(SOC_MODULE_DPDDR, 0, &dpddr_desc, NULL))
				return 0;
			return dpddr_desc.size;
		case MEM_PART_SYSTEM_DDR1:
			return dpaa_sys_ddr_size;
		case MEM_PART_SYSTEM_DDR2:
			return mc_sys_ddr2_size;
		case MEM_PART_DMEM:
			dmem_desc.core_id = (int)core_get_id()+1;
			if (0 != sys_get_desc(SOC_MODULE_DMEM, SOC_DB_DMEM_DESC_CORE_ID, &dmem_desc, NULL))
				return 0;
			return dmem_desc.block_size;
		case MEM_PART_DMEM1:
			dmem_desc.core_id = 1;
			if (0 != sys_get_desc(SOC_MODULE_DMEM, SOC_DB_DMEM_DESC_CORE_ID, &dmem_desc, NULL))
				return 0;
			return dmem_desc.block_size;
		case MEM_PART_DMEM2:
			dmem_desc.core_id = 2;
			if (0 != sys_get_desc(SOC_MODULE_DMEM, SOC_DB_DMEM_DESC_CORE_ID, &dmem_desc, NULL))
				return 0;
			return dmem_desc.block_size;
		case MEM_PART_PEB:
			if (0 != sys_get_desc(SOC_MODULE_PEBM, 0, &peb_desc, NULL))
				return 0;
			return peb_desc.size;
		default:
			return 0;
    }
}

#ifdef MEM_MNG_COUNT_ALLOC
void sys_mem_mng_set_alloc_flags(uint32_t flags)
{
	int is_master_core = sys_is_master_core();
	if (is_master_core) {
		mem_mng_set_alloc_flags(sys.mem_mng, flags);

	}
}

void sys_mem_mng_check_alloc(int32_t *cnt)
{
	int is_master_core = sys_is_master_core();
	if (is_master_core) {
		*cnt = mem_mng_check_alloc(sys.mem_mng);
	}
}
#endif //MEM_MNG_COUNT_ALLOC

void sys_mem_mng_print_alloc_info()
{
	int is_master_core = sys_is_master_core();
	if (is_master_core) {
		mem_mng_print_alloc_info(sys.mem_mng, sys_print_mem_leak);
	}
}
