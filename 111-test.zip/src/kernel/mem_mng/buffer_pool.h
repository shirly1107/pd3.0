/*
 * Copyright 2013-2020 NXP
 */

#ifndef __BUFFER_POOL_H
#define __BUFFER_POOL_H

#include "fsl_types.h"
#include "fsl_smp.h"
/**************************************************************************//*
 @Description    Buffer pool structure
*//***************************************************************************/
struct buffer_pool {
	uint8_t  *p_buffers;          /* Pointer to the buffers */
	uint32_t  *p_buffers_stack;    /* Array of pointers to buffers */
	struct spinlock lock;
	uint16_t    buff_size;           /* Size of each data buffer */
	uint32_t    num_buffs;          /* Number of buffers in segment */
	uint32_t    current;            /* Current buffer */
	uint32_t  bf_pool_id;
} ;
/**************************************************************************//**
 *              Stack of 64 bit addresses to    	Buffers,
 *		buffers                    		each one of buff_size
		|--------------------------|  Address_1 |-------------------|
Current	----->	|  32b Address_1           |    	|    Buffer1        |
		|--------------------------|            |                   |
		|  32b Adress_2            |    	|                   |
		|--------------------------|  Address_2 |-------------------|
		|  32b Address_3           |            |    Buffer 2       |
		|--------------------------|            |		    |
		|			   |		|		    |
 * *//***************************************************************************/
int buffer_pool_create(struct buffer_pool    **bf_pool,
                      const uint32_t 	    bf_pool_id,
                      const uint32_t        num_buffs,
                      const uint32_t        buff_size,
                      void * h_boot_mem_mng);

/*
 * Returns number of buffers that may fit into mem_size.
 * @param buff_size Buffer size.
 */
uint32_t caclculate_num_buffs(const uint32_t mem_size,const uint16_t  buff_size);

/**************************************************************************//**
 @Function      get_buff

 @Description   Returns a 32b address of a free buffer from the pool.

 @Param[in]     bf_pool - Object of buffer pool, returned by buffer_pool_create
 @Param[out]    buff_addr Address of a buffer.

 @Return        0 - if success, a  non-zero value in case of error
*//***************************************************************************/
int get_buff(struct buffer_pool *bf_pool, uint32_t *buffer_addr);

/**************************************************************************//**
 @Function      put_buff

 @Description   Puts  back a previously returned buffer to the pool.

 @Param[in]     bf_pool - Object of buffer pool, returned by buffer_pool_create
 @Param[out]    p_buffer Address of a buffer to be returned to the pool.

 @Return        0 - if success, a  non-zero value in case of error
*//***************************************************************************/
int put_buff(struct buffer_pool  *bf_pool, const void *p_buffer);

#endif
