/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 @File          mem_mng.c

 @Description   Implementation of the memory allocation management module.
*//***************************************************************************/

#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "kernel/fsl_spinlock.h"
#include "fsl_slob.h"
#include "fsl_platform.h"

#include "mem_mng.h"
#include "fsl_dbg.h"
#include "fsl_malloc.h"
#include "buffer_pool.h"
#include "slob.h"
#include "fsl_dpmng_mc.h"
#include "fsl_mc.h"

static void mem_mng_add_entry(t_mem_mng             *p_mem_mng,
                           t_mem_mng_partition    *p_partition,
                           void                 *p_memory,
                           uint32_t             size,
                           const char           *info,
                           const char           *filename,
                           int                  line);

static int mem_mng_remove_entry(t_mem_mng          *p_mem_mng,
                              t_mem_mng_partition *p_partition,
                              void              *p_memory);

static int mem_mng_get_partition_id_by_addr_local(t_mem_mng             *p_mem_mng,
                                       uint64_t             addr,
                                       int                  *p_partition_id,
                                       t_mem_mng_partition    **p_partition);

static void mem_mng_free_partition(t_mem_mng *p_mem_mng,
                                   t_mem_mng_partition* p_partition);

static void mem_mng_free_phys_alloc_partition(t_mem_mng *p_mem_mng,
									t_mem_mng_phys_addr_alloc_partition *p_partittion);

#ifdef MEM_MNG_COUNT_ALLOC

	static int32_t mem_mng_check_mem_partition(t_mem_mng_partition *p_partition);
	static int32_t mem_mng_check_phys_alloc(t_mem_mng_phys_addr_alloc_partition *p_partition);
	
	static void mem_mng_report_mem_partition_leaks(t_mem_mng_partition *p_partition,
								t_mem_mng_leak_report_func *f_report_leak);

	static int32_t mem_mng_report_phys_alloc_leaks(t_mem_mng_phys_addr_alloc_partition *p_partition,
								t_mem_mng_leak_report_func *f_report_leak);
	
	/*****************************************************************************/
	static void mem_mng_print_mem_leak(void        *p_memory,
								uint32_t    size,
								const char  *info,
								const char  *filename,
								uint32_t         line)
	{
		pr_info("memory leak: %dB at %09p, %s->%s:%d\r\n", size, p_memory, info, filename, line);
	}

#endif //MEM_MNG_COUNT_ALLOC

int boot_mem_mng_init(struct initial_mem_mng* boot_mem_mng)
{
	uint32_t offset = 0;
	int rc = 0;
	struct mem_desc mc_ddr_desc = {0};
	if (0 != (rc = sys_get_desc(SOC_MODULE_MC_DDR, 0, &mc_ddr_desc, NULL)))
			return rc;
	dma_addr_t   mc_mem_phys_base = dpmng_get_mc_mem_base();
	offset = (uint32_t)g_boot_mem_mng_offset - (uint32_t)mc_ddr_desc.paddr;
	boot_mem_mng->base_paddress = mc_mem_phys_base + offset;
	boot_mem_mng->base_vaddress = (uint32_t)mc_ddr_desc.paddr + offset;
	boot_mem_mng->size = (uint32_t)g_boot_mem_mng_size;
	boot_mem_mng->curr_ptr = boot_mem_mng->base_paddress;

    spin_lock_init(&boot_mem_mng->lock);

	return 0;
}

int boot_mem_mng_free(struct initial_mem_mng* boot_mem_mng)
{
	boot_mem_mng->curr_ptr = boot_mem_mng->base_paddress;
	return 0;
}

int boot_get_mem(struct initial_mem_mng* boot_mem_mng,
                 uint64_t size,uint64_t* paddr)
{
    uint32_t int_flags;

	int_flags = spin_lock_irqsave(&boot_mem_mng->lock);

    if(boot_mem_mng->curr_ptr + size >=
		boot_mem_mng->base_paddress + boot_mem_mng->size) {
		return -ENOMEM;
    }

	*paddr = boot_mem_mng->curr_ptr;
	boot_mem_mng->curr_ptr += size;

	spin_unlock_irqrestore(&boot_mem_mng->lock, int_flags);

	return  0;
}

int boot_get_mem_virt(struct initial_mem_mng* boot_mem_mng,
                 uint64_t size,uint32_t* vaddr)
{
    uint32_t            int_flags;

    int_flags = spin_lock_irqsave(&boot_mem_mng->lock);

	if(boot_mem_mng->curr_ptr + size >=
		boot_mem_mng->base_paddress + boot_mem_mng->size) {
		return -ENOMEM;
	}

	*vaddr = (uint32_t)(boot_mem_mng->curr_ptr-boot_mem_mng->base_paddress) +
		boot_mem_mng->base_vaddress ;
	boot_mem_mng->curr_ptr += size;

	spin_unlock_irqrestore(&boot_mem_mng->lock, int_flags);

	return  0;
}

uint32_t boot_get_free_mem(struct initial_mem_mng* boot_mem_mng)
{
    uint32_t            int_flags;

    int_flags = spin_lock_irqsave(&boot_mem_mng->lock);

    uint32_t rc = 0;
    rc = (uint32_t)(boot_mem_mng->size -
                   (boot_mem_mng->curr_ptr-boot_mem_mng->base_paddress));

	spin_unlock_irqrestore(&boot_mem_mng->lock, int_flags);

	return rc;
}

void *  mem_mng_init(void * h_boot_mem_mng,
                           t_mem_mng_param *p_mem_mng_param)
{
    t_mem_mng    *p_mem_mng;
    uint32_t      mem_mng_addr = 0;
    int rc = 0, i, array_size = 0;


    ASSERT_COND_LIGHT(h_boot_mem_mng);
    if(NULL == h_boot_mem_mng)
        return NULL;
    struct initial_mem_mng* boot_mem_mng = (struct initial_mem_mng*)h_boot_mem_mng;

    rc =  boot_get_mem_virt(boot_mem_mng,sizeof(t_mem_mng),&mem_mng_addr);
    if (rc)
    {
        pr_err("MAJOR mem. manager memory allocation failed: memory manager "
               "structure\n");
        return NULL;
    }
    p_mem_mng = UINT_TO_PTR(mem_mng_addr);
    memset(p_mem_mng, 0, sizeof(t_mem_mng));


    p_mem_mng->h_boot_mem_mng = h_boot_mem_mng;

    struct buffer_pool *bf_pool = NULL;
    uint32_t slob_blocks_num = g_buffer_pool_size/sizeof(t_slob_block);
    rc = buffer_pool_create(&bf_pool,E_BFT_SLOB_BLOCK,
                            slob_blocks_num,(uint16_t)sizeof(t_slob_block),h_boot_mem_mng);
    if(rc)
    {
        pr_err("MAJOR mem.manager memory allocation failed slob free blocks\n");
        return NULL;
    }
    p_mem_mng->h_slob_bf_pool = bf_pool;
    p_mem_mng->mem_partitions_initialized = 0;
    /* Initialize internal partitions array */
    array_size = ARRAY_SIZE(p_mem_mng->mem_partitions_array);
    // Check that memory partition array size greater than MEM_PART_LAST
    ASSERT_COND_LIGHT(array_size>= MEM_PART_LAST);
    for(i = 0 ; i < array_size;i++ ){
        p_mem_mng->mem_partitions_array[i].was_initialized = 0;
    }

    /* Initialize phys internal partitions array */
    array_size = ARRAY_SIZE(p_mem_mng->phys_allocation_mem_partitions_array);
    // Check that memory partition array size greater than MEM_PART_LAST
    ASSERT_COND_LIGHT(array_size>= MEM_PART_LAST);
    for(i = 0 ; i < array_size;i++ ){
        p_mem_mng->phys_allocation_mem_partitions_array[i].was_initialized = 0;
    }
    /* Initialize  virt 2 phys map  array */
    array_size = ARRAY_SIZE(p_mem_mng->virt_mem_array);
    for(i = 0 ; i < array_size;i++ ){
	    p_mem_mng->virt_mem_array[i].was_initialized = 0;
    }


    p_mem_mng->mem_partitions_initialized = 0;

    /* set memory manager debug flags */
#ifdef FORCE_MEM_MNG_COUNT_ALLOC
    p_mem_mng->enable_debug = 1;
#else
    p_mem_mng->enable_debug = 0;
#endif //FORCE_MEM_MNG_COUNT_ALLOC

#ifdef FORCE_MEM_MNG_REC_ALLOC_INFO
    p_mem_mng->report_mem_leaks = 1;
#else
    p_mem_mng->report_mem_leaks = 0;
#endif //FORCE_MEM_MNG_REC_ALLOC_INFO

    return p_mem_mng;
}

/*
 * Caution: * There are no locks on p_mem_mng->mem_partitions_array therefore
 * this function should be called only by one core.
 */
void mem_mng_free(void * h_mem_mng, void * h_boot_mem_mng)
{
    t_mem_mng	*p_mem_mng = (t_mem_mng *)h_mem_mng;

    uint32_t i = 0,
    		array_size = ARRAY_SIZE(p_mem_mng->mem_partitions_array);
    struct initial_mem_mng *boot_mem_mng = h_boot_mem_mng;

    /* free mem boot partition */
    boot_mem_mng_free(boot_mem_mng);

    /* if there are any partitions left initialized
     *  then do a last change free */
    for ( i = 0; i < array_size ;i++)
    {
        if(p_mem_mng->mem_partitions_array[i].was_initialized){
	    mem_mng_free_partition(p_mem_mng, &p_mem_mng->mem_partitions_array[i]);
	    p_mem_mng->mem_partitions_array[i].was_initialized = 0;
        }
    }

    array_size = ARRAY_SIZE(p_mem_mng->phys_allocation_mem_partitions_array);
    for ( i = 0; i < array_size ;i++)
    {
        p_mem_mng->phys_allocation_mem_partitions_array[i].was_initialized = 0;
    }

    array_size = ARRAY_SIZE(p_mem_mng->virt_mem_array);
    for ( i = 0; i < array_size ;i++)
    {
        if(p_mem_mng->virt_mem_array[i].was_initialized){
            p_mem_mng->virt_mem_array[i].was_initialized = 0;
        }
    }
}

/*
 * Caution: * There are no locks on p_mem_mng->mem_partitions_array therefore
 * this function should be called only by one core.
 */
int mem_mng_register_partition(void *  h_mem_mng,
                                  int       partition_id,
                                  uintptr_t base_address,
                                  uint64_t  size,
                                  uint32_t  attributes,
                                  char      name[])
{
    t_mem_mng            *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_mem_mng_partition   *p_new_partition;
    uint32_t array_size = ARRAY_SIZE(p_mem_mng->mem_partitions_array);

    /* make sure that mem_partitions_array is big enough to contain element with
     * index=partition_id
     */
    ASSERT_COND_LIGHT(partition_id < array_size);
    if(p_mem_mng->mem_partitions_array[partition_id].was_initialized)
    {

            pr_err("MAJOR  mem_manager resource already exists: partition ID %d\n",
                   partition_id);
            return -EEXIST;
    }


    p_new_partition = &p_mem_mng->mem_partitions_array[partition_id];
    memset(p_new_partition, 0, sizeof(t_mem_mng_partition));

    p_new_partition->lock = spin_lock_create();

    if (!p_new_partition->lock)
    {
        p_new_partition->was_initialized = 0;
        pr_err("MAJOR mem_manager resource is unavailable: spinlock object for"
                "partition: %s\n", name);
        return -EAGAIN;
    }

	/* Prevent allocation of address 0x00000000 (reserved to NULL) */
	if (base_address == 0)
	{
		base_address += 4;
		size -= 4;
	}
	/* Initialize the memory manager handle for the new partition */
	if (0 != slob_init(&(p_new_partition->h_mem_manager),
			           base_address, size,p_mem_mng->h_boot_mem_mng,
			           p_mem_mng->h_slob_bf_pool))
	{
		/*p_mem_mng->f_free(p_new_partition);*/
		p_new_partition->was_initialized = 0;
		pr_err("MAJOR mem_manager resource is unavailable: slob  object for "
				"partition: %s\n", name);
		return -EAGAIN;
	}


    /* Copy partition name */
    strncpy(p_new_partition->info.name, name, MEM_MNG_MAX_PARTITION_NAME_LEN-1);

    /* Initialize debug entries list */
    INIT_LIST(&(p_new_partition->mem_debug_list));

    /* Store other parameters */
    p_new_partition->id = partition_id;
    p_new_partition->info.base_address = base_address;
    p_new_partition->info.size = size;
    p_new_partition->info.attributes = attributes;
    p_new_partition->was_initialized = 1;

    if (p_mem_mng->enable_debug)
    	mem_mng_print_partition_info(p_new_partition, 0, NULL);

    return 0;
}

/*
 * Caution: * There are no locks on p_mem_mng->mem_partitions_array therefore
 * this function should be called only by one core.
 */
int mem_mng_register_phys_addr_alloc_partition(void *  h_mem_mng,
                                  int       partition_id,
                                  uint64_t base_paddress,
                                  uint64_t  size,
                                  uint32_t  attributes,
                                  char      name[])
{
    t_mem_mng            *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_mem_mng_phys_addr_alloc_partition  *p_new_partition;
    uint32_t array_size = ARRAY_SIZE(p_mem_mng->phys_allocation_mem_partitions_array);
    /* make sure that phys_allocation_mem_partitions_array is big enough
     * to contain element with index=partition_id*/

    ASSERT_COND_LIGHT(partition_id < array_size);

    if(p_mem_mng->phys_allocation_mem_partitions_array[partition_id].was_initialized){
            pr_err("MAJOR mem. manager resource already exists: partition ID %d\n",
                   partition_id);
            return -EEXIST;
    }
   p_new_partition = &p_mem_mng->phys_allocation_mem_partitions_array[partition_id];
   memset(p_new_partition, 0, sizeof(t_mem_mng_phys_addr_alloc_partition));

    p_new_partition->lock = spin_lock_create();

    if (!p_new_partition->lock)
    {
        /*p_mem_mng->f_free(p_new_partition); */
        p_new_partition->was_initialized = 0;
        pr_err("MAJOR mem. manager resource is unavailable: spinlock object for "
               "partition: %s\n", name);
        return -EAGAIN;
    }

    /* Initialize the memory manager handle for the new partition */
   if (0 != slob_init(&(p_new_partition->h_mem_manager),
		              base_paddress, size,p_mem_mng->h_boot_mem_mng,
		              p_mem_mng->h_slob_bf_pool))
   {
       p_new_partition->was_initialized = 0;
       pr_err("MAJOR mem. manager resource is unavailable: slob object for "
               "partition: %s\n",name);
       return -EAGAIN;
   }
   /* Copy partition name */
   strncpy(p_new_partition->info.name, name, MEM_MNG_MAX_PARTITION_NAME_LEN-1);

   /* Initialize debug entries list */
   INIT_LIST(&(p_new_partition->mem_debug_list));
   
   /* Store other parameters */
   p_new_partition->id = partition_id;
   p_new_partition->info.base_paddress = base_paddress;
   p_new_partition->info.size = size;
   p_new_partition->info.attributes = attributes;
   p_new_partition->curr_paddress = base_paddress;
   p_new_partition->was_initialized = 1;

   if (p_mem_mng->enable_debug)
	   mem_mng_print_phys_partition_info(p_new_partition, 0, NULL);

   return 0;
}

/*
 * Caution: * There are no locks on p_mem_mng->mem_partitions_array therefore
 * this function should be called only by one core.
 */
int mem_mng_unregister_partition(void * h_mem_mng, int partition_id)
{
    t_mem_mng            *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_mem_mng_partition   *p_partition;
    t_mem_mng_phys_addr_alloc_partition *p_phys_partition;



    /* Find the requested partition and release it */
    p_partition = &p_mem_mng->mem_partitions_array[partition_id];

    if (p_partition->was_initialized)
    {
#ifdef MEM_MNG_COUNT_ALLOC
    		if (p_mem_mng->enable_debug)
    			mem_mng_print_partition_info(p_partition, 
    					p_mem_mng->report_mem_leaks, mem_mng_print_mem_leak);
#endif //MEM_MNG_COUNT_ALLOC

            mem_mng_free_partition(p_mem_mng, p_partition);
            p_partition->was_initialized = 0;
            return 0;
    }
    else
    {
    	p_phys_partition = &p_mem_mng->phys_allocation_mem_partitions_array[partition_id];
        if (p_phys_partition->was_initialized)
        {
#ifdef MEM_MNG_COUNT_ALLOC
        	if (p_mem_mng->enable_debug)
        		mem_mng_print_phys_partition_info(p_phys_partition,
        							p_mem_mng->report_mem_leaks, mem_mng_print_mem_leak);
#endif //MEM_MNG_COUNT_ALLOC

        	mem_mng_free_phys_alloc_partition(p_mem_mng, p_phys_partition);
             p_phys_partition->was_initialized = 0;
             return 0;
         }
    }
    pr_err("MAJOR mem. manager unsupported operation: partition ID %d\n", partition_id);
    return -ENOTSUP;
}

/*
 * Caution: * There are no locks on p_mem_mng->mem_partitions_array therefore
 * this function should be called only by one core.
 */
int mem_mng_get_partition_info(void *               h_mem_mng,
                                  int                   partition_id,
                                  t_mem_mng_partition_info *p_partition_info)
{
    t_mem_mng            *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_mem_mng_partition   *p_partition;



    p_partition = &p_mem_mng->mem_partitions_array[partition_id];

    if (p_partition->was_initialized)
    {
        *p_partition_info = p_partition->info;
        return 0;
    }

    pr_err("MAJOR mem. manager resource is unavailable: partition ID %d\n", partition_id);
    return -EAGAIN;
}

/*
 * Caution: * There are no locks on p_mem_mng->mem_partitions_array therefore
 * this function should be called only by one core.
 */
int mem_mng_get_phys_addr_alloc_info(void *               h_mem_mng,
                                  int                   partition_id,
                                  t_mem_mng_phys_addr_alloc_info *p_partition_info)
{
    t_mem_mng            *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_mem_mng_phys_addr_alloc_partition   *p_partition;

    p_partition =  &(p_mem_mng->phys_allocation_mem_partitions_array[partition_id]);
    if (p_partition->was_initialized)
    {
            *p_partition_info = p_partition->info;
            return 0;
     }

    pr_err("MAJOR mem. manager resource is unavailable: partition ID %d\n",
            partition_id);
    return -EAGAIN;
}

/*
 * Caution: * There are no locks on p_mem_mng->mem_partitions_array therefore
 * this function should be called only by one core.
 */
int mem_mng_get_partition_id_by_addr(void *   h_mem_mng,
                                     uint64_t   addr,
                                     int        *p_partition_id)
{
    t_mem_mng            *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_mem_mng_partition   *p_partition;
    int                found;

    found = mem_mng_get_partition_id_by_addr_local(p_mem_mng, addr, p_partition_id, &p_partition);

    if (!found)
    {
        pr_err("MAJOR mem.manager resource is unavailable: partition ID\n",
               p_partition_id);
        return -EAGAIN;
    }

    return 0;
}

void * mem_mng_alloc_mem(void *    h_mem_mng,
                        int         partition_id,
                        uint32_t    size,
                        uint32_t    alignment,
                        const char  *info,
                        const char  *filename,
                        int         line)
{
    t_mem_mng            *p_mem_mng = (t_mem_mng *)h_mem_mng;
    struct initial_mem_mng* boot_mem_mng = NULL;

    t_mem_mng_partition   *p_partition;
    uint32_t virt_address = 0;
    void                *p_memory;
    char  part_name[32];

#ifndef MEM_MNG_REC_ALLOC_INFO
    UNUSED(info);
    UNUSED(filename);
    UNUSED(line);
#endif //MEM_MNG_REC_ALLOC_INFO

    if (size == 0)
    {
        pr_err("MAJOR mem.manager invalid value: allocation size must be positive\n");
    }

    if(!p_mem_mng->mem_partitions_initialized)
    {
		ASSERT_COND_LIGHT(partition_id == SYS_DEFAULT_HEAP_PARTITION) ;
		boot_mem_mng = (struct initial_mem_mng*)p_mem_mng->h_boot_mem_mng;
		if(boot_get_mem_virt(boot_mem_mng,size,&virt_address) != 0)
			return NULL;
		return (UINT_TO_PTR(virt_address));
    }
    /*  Redirect a former CW allocation to MEM_PART_SYSTEM_DDR1_CACHEABLE*/
    if (partition_id == SYS_DEFAULT_HEAP_PARTITION)
    {
        partition_id =  MEM_PART_SYSTEM_DDR1_CACHEABLE;
    }
    /* redirect memory allocation from MEM_PART_DMEM to dmem1 or dmem2 according to core
     * number.
     */
    else if(partition_id == MEM_PART_DMEM)
    { /* It is supposed that MEM_PART_DMEM1,MEM_PART_DMEM2,... are sequential
       numbers */
        partition_id = MEM_PART_DMEM1 + (int)core_get_id();
    }

    /* Not early allocation - allocate from registered partitions */
    p_partition = &p_mem_mng->mem_partitions_array[partition_id];
    if (p_partition->was_initialized && p_partition->id == partition_id)
    {
#ifdef MEM_MNG_REC_ALLOC_INFO
    	if (p_mem_mng->report_mem_leaks) {
    	/* alloc at the end space for debug metadata */
        size += sizeof(t_mem_mng_debug_entry);
    	}
#endif //MEM_MNG_REC_ALLOC_INFO

    /* Internal MM malloc */
	p_memory = UINT_TO_PTR(
			slob_get(p_partition->h_mem_manager, size, alignment, ""));
	if ((uintptr_t)p_memory == ILLEGAL_BASE)
	/* Do not report error - let the allocating entity report it */
		return NULL;
	
	p_partition->info.current_usage += size;
	
	if (partition_id == MEM_PART_PEB) {
		pr_info("PEB memory: %ld bytes free of %ld bytes\n", (long)(p_partition->info.size - p_partition->info.current_usage), (long)p_partition->info.size);
	}
	

#ifdef MEM_MNG_COUNT_ALLOC
	if (p_mem_mng->enable_debug) {
		/* count allocations */
		p_partition->info.total_allocations++;
	}
#endif //MEM_MNG_COUNT_ALLOC

#ifdef MEM_MNG_REC_ALLOC_INFO
	if (p_mem_mng->report_mem_leaks) {
			/* remove metadata size */
			size -= sizeof(t_mem_mng_debug_entry);
	
			if (p_mem_mng->report_mem_leaks)
			{
				mem_mng_add_entry(p_mem_mng, p_partition, p_memory,
								  size, info, filename, line);
			}
		}
#endif //MEM_MNG_REC_ALLOC_INFO

        return p_memory;
    }
    get_partition_name(partition_id,part_name,sizeof(part_name));
    pr_err("Memory %s is not found when trying to call malloc with partition %d\n",part_name,partition_id);
    return NULL;
}

int mem_mng_get_phys_mem(void * h_mem_mng, int  partition_id,
                        uint64_t size, uint64_t alignment,
                        uint64_t *paddr)
{
    t_mem_mng            *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_mem_mng_phys_addr_alloc_partition   *p_partition;
    char part_name[32];

    if (size == 0)
    {
        pr_err("MAJOR mem. manager invalid value: allocation size must be positive\n");
    }
    
    /* Not early allocation - allocate from registered partitions */
    p_partition = &p_mem_mng->phys_allocation_mem_partitions_array[partition_id];
    if (p_partition->was_initialized)
    {
        if((*paddr = slob_get(p_partition->h_mem_manager,size,alignment,"")) == ILLEGAL_BASE)
        {
            pr_err("MAJOR mem. manager memory allocation failed\n");
            pr_err("Required size 0x%x%08x alignment 0x%x%08x exceeds "
                   "available memory for partition ID %d\n",
                   (uint32_t)(size >> 32),(uint32_t)size, (uint32_t)(alignment >> 32), (uint32_t)(alignment), partition_id);
            return -ENOMEM;
        }

        p_partition->info.current_usage += size;
        
        if (partition_id == MEM_PART_PEB) {			
			pr_info("PEB memory: %ld bytes free of %ld bytes\n", (long)(p_partition->info.size - p_partition->info.current_usage), (long)p_partition->info.size);
		}

#ifdef MEM_MNG_COUNT_ALLOC
        if (p_mem_mng->enable_debug) {
        	p_partition->info.total_allocations++;
        }
#endif //MEM_MNG_COUNT_ALLOC

         return 0; // Success
     }
    get_partition_name(partition_id,part_name,sizeof(part_name));
    pr_err("Memory %s not found when trying to call get_mem() with partition %d\n",part_name,partition_id);
    return -EINVAL;
}

void mem_mng_put_phys_mem(void * h_mem_mng, uint64_t paddress)
{
    uint64_t size;
	t_mem_mng            *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_mem_mng_phys_addr_alloc_partition   *p_partition;
    uint32_t             array_size = 0, i = 0;

    array_size = ARRAY_SIZE(p_mem_mng->phys_allocation_mem_partitions_array);
    /* Not early allocation - allocate from registered partitions */
    for(i = 0; i < array_size ; i++)
    {
    	p_partition  = &(p_mem_mng->phys_allocation_mem_partitions_array[i]);
    	if (p_partition->was_initialized && paddress >= p_partition->info.base_paddress && paddress < (p_partition->info.base_paddress + p_partition->info.size))
    	{
    		size = slob_put(p_partition->h_mem_manager, paddress);
            
            p_partition->info.current_usage -= size;
            
            if (i == MEM_PART_PEB){
            	pr_info("PEB memory: %ld bytes free of %ld bytes\n", (long)(p_partition->info.size - p_partition->info.current_usage), (long)p_partition->info.size);
            }

#ifdef MEM_MNG_COUNT_ALLOC
            	if (p_mem_mng->enable_debug) {
            		p_partition->info.total_deallocations++;
            	}
#endif //MEM_MNG_COUNT_ALLOC

            return;
    	}
    }
    return;
}

void mem_mng_free_mem(void * h_mem_mng, void *p_memory)
{
	/* Redirect mem_mng_free_mem to mem_mng_xfree_mem as former CW malloc
	 * is allocated from MEM_PART_SYSTEM_DDR1_CACHEABLE
	 */
	/*sys_aligned_free(p_memory);*/
	mem_mng_xfree_mem(h_mem_mng,p_memory);
}

void mem_mng_xfree_mem(void * h_mem_mng, void *p_memory)
{
	uint64_t size;
    t_mem_mng            *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_mem_mng_partition   *p_partition;
    uintptr_t           addr = (uintptr_t)p_memory;
    int                 partition_id;
    int                address_found = 1;

	if (mem_mng_get_partition_id_by_addr_local(p_mem_mng, addr, &partition_id, &p_partition))
	{
#ifdef MEM_MNG_REC_ALLOC_INFO
		if (p_mem_mng->report_mem_leaks &&
				!mem_mng_remove_entry(p_mem_mng, p_partition, p_memory))
		{
			address_found = 0;
		}
#endif //MEM_MNG_REC_ALLOC_INFO
		if (address_found)
		{
			size = slob_put(p_partition->h_mem_manager, PTR_TO_UINT(p_memory));
			
			p_mem_mng->mem_partitions_array[partition_id].info.current_usage -= size;
			
			if (partition_id == MEM_PART_PEB) {
				pr_info("PEB memory: %ld bytes free of %ld bytes\n", (long)(p_mem_mng->mem_partitions_array[partition_id].info.size - p_mem_mng->mem_partitions_array[partition_id].info.current_usage), (long)p_mem_mng->mem_partitions_array[partition_id].info.size);
			}

#ifdef MEM_MNG_COUNT_ALLOC
			if (p_mem_mng->enable_debug) {
				p_partition->info.total_deallocations++;
			}
#endif //MEM_MNG_COUNT_ALLOC
		}
	}
	else
	{
	    address_found = 0;
	}

    if (!address_found)
    {
        pr_err("MAJOR mem. manager resource not found: attempt to free "
                "unallocated address (0x%08x)\n",p_memory);
    }
}

/*
 * Caution: * There are no locks on p_mem_mng->mem_partitions_array therefore
 * this function should be called only by one core.
 */
static int mem_mng_get_partition_id_by_addr_local(t_mem_mng          *p_mem_mng,
                                       uint64_t          addr,
                                       int               *p_partition_id,
                                       t_mem_mng_partition **p_partition)
{
    t_mem_mng_partition   *p_tmp_partition;
    uint32_t i = 0, array_size = 0;

    array_size = ARRAY_SIZE(p_mem_mng->mem_partitions_array);
    for (i = 0; i < array_size; i++)
    {
	p_tmp_partition =  &p_mem_mng->mem_partitions_array[i];
        if (p_tmp_partition->was_initialized &&
            (addr >= p_tmp_partition->info.base_address) &&
            (addr < (p_tmp_partition->info.base_address + p_tmp_partition->info.size)))
        {
            *p_partition_id = p_tmp_partition->id;
            *p_partition = p_tmp_partition;
            return 1;
        }
    }

    return 0;
}

static void mem_mng_free_partition(t_mem_mng *p_mem_mng,
                                   t_mem_mng_partition* p_partition)
{
    UNUSED(p_mem_mng);

#ifdef MEM_MNG_REC_ALLOC_INFO
    t_mem_mng_debug_entry  *p_mem_mng_debug_entry;
    list_t              *p_debug_iterator, *p_tmp_iterator;
    uint32_t            int_flags;

    int_flags = spin_lock_irqsave(p_partition->lock);

    /* Release the debug entries list */
    LIST_FOR_EACH_SAFE(p_debug_iterator, p_tmp_iterator, &(p_partition->mem_debug_list))
    {
        p_mem_mng_debug_entry = MEM_MNG_DBG_OBJECT(p_debug_iterator);

        list_del(p_debug_iterator);
    }

    spin_unlock_irqrestore(p_partition->lock, int_flags);

#endif //MEM_MNG_REC_ALLOC_INFO

	/* Release the memory manager object */
	slob_free(p_partition->h_mem_manager);
	
	p_partition->info.current_usage = 0;
	
	if (p_partition->id == MEM_PART_PEB) {
		pr_info("PEB memory: %ld bytes free of %ld bytes\n", (long)(p_partition->info.size - p_partition->info.current_usage), (long)p_partition->info.size);
	}

    /* Remove from partitions list and free the allocated memory */

    if (p_partition->lock) {
        spin_lock_free(p_partition->lock);
    }
}

static void mem_mng_free_phys_alloc_partition(t_mem_mng *p_mem_mng,
		t_mem_mng_phys_addr_alloc_partition* p_partition)
{
    UNUSED(p_mem_mng);

#ifdef MEM_MNG_REC_ALLOC_INFO
    t_mem_mng_debug_entry  *p_mem_mng_debug_entry;
    list_t              *p_debug_iterator, *p_tmp_iterator;
    uint32_t            int_flags;

    int_flags = spin_lock_irqsave(p_partition->lock);

    /* Release the debug entries list */
    LIST_FOR_EACH_SAFE(p_debug_iterator, p_tmp_iterator, &(p_partition->mem_debug_list))
    {
        p_mem_mng_debug_entry = MEM_MNG_DBG_OBJECT(p_debug_iterator);

        list_del(p_debug_iterator);
    }

    spin_unlock_irqrestore(p_partition->lock, int_flags);

#endif //MEM_MNG_REC_ALLOC_INFO

	/* Release the memory manager object */
    slob_free(p_partition->h_mem_manager);

    p_partition->info.current_usage = 0;
    	
    if (p_partition->id == MEM_PART_PEB) {
    	pr_info("PEB memory: %ld bytes free of %ld bytes\n", (long)(p_partition->info.size - p_partition->info.current_usage), (long)p_partition->info.size);
    }
    
    if (p_partition->lock) {
        spin_lock_free(p_partition->lock);
    }
}

#ifdef MEM_MNG_REC_ALLOC_INFO
static void mem_mng_add_entry(t_mem_mng             *p_mem_mng,
                           t_mem_mng_partition    *p_partition,
                           void                 *p_memory,
                           uint32_t             size,
                           const char           *info,
                           const char           *filename,
                           int                  line)
{
    t_mem_mng_debug_entry  *p_mem_mng_debug_entry;
    uint32_t            int_flags;

    p_mem_mng_debug_entry = (t_mem_mng_debug_entry *) (p_memory + size); //sys_default_malloc(sizeof(t_mem_mng_debug_entry));

    if (p_mem_mng_debug_entry != NULL)
    {
        INIT_LIST(&p_mem_mng_debug_entry->node);
        p_mem_mng_debug_entry->p_memory = p_memory;
        p_mem_mng_debug_entry->filename = filename;
        p_mem_mng_debug_entry->info = info;
        p_mem_mng_debug_entry->line = line;
        p_mem_mng_debug_entry->size = size;

        int_flags = spin_lock_irqsave(p_partition->lock);

        list_add_to_tail(&p_mem_mng_debug_entry->node, &(p_partition->mem_debug_list));

        spin_unlock_irqrestore(p_partition->lock, int_flags);

        p_partition->info.current_usage += size;

        //@@@@ add check for size overflow
        p_partition->info.maximum_usage = 
        		MAX(p_partition->info.maximum_usage, p_partition->info.current_usage);
    }
    else
    {
        pr_err("MAJOR mem. manager memory allocation failed: memory manager "
                "debug entry \n");
    }
}

static int mem_mng_remove_entry(t_mem_mng          *p_mem_mng,
                              t_mem_mng_partition *p_partition,
                              void              *p_memory)
{
    t_mem_mng_debug_entry  *p_mem_mng_debug_entry;
    list_t              *p_debug_iterator, *p_tmp_iterator;
    uint32_t            int_flags;
    int_flags = spin_lock_irqsave(p_partition->lock);

    LIST_FOR_EACH_SAFE(p_debug_iterator, p_tmp_iterator, &(p_partition->mem_debug_list))
    {
        p_mem_mng_debug_entry = MEM_MNG_DBG_OBJECT(p_debug_iterator);

        if (p_mem_mng_debug_entry->p_memory == p_memory)
        {
            p_partition->info.current_usage -= p_mem_mng_debug_entry->size;


            list_del(p_debug_iterator);

    	    spin_unlock_irqrestore(p_partition->lock, int_flags);

            /*p_mem_mng->f_free(p_mem_mng_debug_entry); */
            //sys_default_free(p_mem_mng_debug_entry);
            return 1;
        }
    }

    spin_unlock_irqrestore(p_partition->lock, int_flags);

    return 0;
}
#endif //MEM_MNG_REC_ALLOC_INFO


#ifdef MEM_MNG_COUNT_ALLOC

/*
 * Caution: * There are no locks on p_mem_mng->mem_partitions_array therefore
 * this function should be called only by one core.
 */
static int32_t mem_mng_check_mem_partition(t_mem_mng_partition *p_partition)
{
	int32_t alloc_delta = (p_partition->info.total_allocations -
							p_partition->info.total_deallocations);
	return alloc_delta;
}

static int32_t mem_mng_check_phys_alloc(t_mem_mng_phys_addr_alloc_partition *p_partition)
{
	int32_t alloc_delta = (p_partition->info.total_allocations -
							p_partition->info.total_deallocations);
	return alloc_delta;
}

#ifdef MEM_MNG_REC_ALLOC_INFO
void mem_mng_report_mem_partition_leaks(t_mem_mng_partition *p_partition,
                            t_mem_mng_leak_report_func *h_report_leak)
{

    t_mem_mng_debug_entry  *p_mem_mng_debug_entry;
    list_t              *p_debug_iterator;
    t_mem_mng_leak_report_func *report_leak =  NULL;

    if (h_report_leak)
    	report_leak = h_report_leak;
    else
    	report_leak = mem_mng_print_mem_leak;

	spin_lock(p_partition->lock);

	if (report_leak)
	{
		LIST_FOR_EACH(p_debug_iterator, &(p_partition->mem_debug_list))
		{
			p_mem_mng_debug_entry = MEM_MNG_DBG_OBJECT(p_debug_iterator);

			report_leak(p_mem_mng_debug_entry->p_memory,
					  p_mem_mng_debug_entry->size,
					  p_mem_mng_debug_entry->info,
					  p_mem_mng_debug_entry->filename,
					  p_mem_mng_debug_entry->line);
		}
	}

	spin_unlock(p_partition->lock);
}

int32_t mem_mng_report_phys_alloc_leaks(t_mem_mng_phys_addr_alloc_partition *p_partition,
                            t_mem_mng_leak_report_func *h_report_leak)
{
    t_mem_mng_debug_entry  *p_mem_mng_debug_entry;
    list_t              *p_debug_iterator;
    t_mem_mng_leak_report_func *report_leak =  NULL;

    if (h_report_leak)
    	report_leak = h_report_leak;
    else
    	report_leak = mem_mng_print_mem_leak;

	spin_lock(p_partition->lock);

	if (report_leak)
	{
		LIST_FOR_EACH(p_debug_iterator, &(p_partition->mem_debug_list))
		{
			p_mem_mng_debug_entry = MEM_MNG_DBG_OBJECT(p_debug_iterator);

			report_leak(p_mem_mng_debug_entry->p_memory,
					  p_mem_mng_debug_entry->size,
					  p_mem_mng_debug_entry->info,
					  p_mem_mng_debug_entry->filename,
					  p_mem_mng_debug_entry->line);
		}
	}

	spin_unlock(p_partition->lock);

}
#endif //MEM_MNG_REC_ALLOC_INFO
#endif //MEM_MNG_COUNT_ALLOC

int mem_mng_mem_partitions_init_completed(void * h_mem_mng)
{
	t_mem_mng  *p_mem_mng = (t_mem_mng *)h_mem_mng;
	p_mem_mng->mem_partitions_initialized = 1;
	return 0;
}

int mem_mng_register_virt_mem_mapping(void *h_mem_mng,
                                      uint64_t virt_addr,
                                      uint64_t phys_addr,
                                      uint64_t size)
{
    t_mem_mng  *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_sys_virt_mem_map *p_virt_mem_map = NULL;
    uint32_t array_size = 0, i = 0;
    array_size = ARRAY_SIZE(p_mem_mng->virt_mem_array);
    for (i = 0; i < array_size ; i++)
    {
	if(p_mem_mng->virt_mem_array[i].was_initialized &&
	   p_mem_mng->virt_mem_array[i].virt_addr == virt_addr &&
	   p_mem_mng->virt_mem_array[i].phys_addr == phys_addr &&
	   p_mem_mng->virt_mem_array[i].size == size)
		return -EEXIST;
        if(!p_mem_mng->virt_mem_array[i].was_initialized)
            break;
    }
    
    CHECK_COND_RETVAL(i < array_size, -EINVAL);
    
    p_virt_mem_map = &p_mem_mng->virt_mem_array[i];
    p_virt_mem_map->virt_addr = virt_addr;
    p_virt_mem_map->phys_addr = phys_addr;
    p_virt_mem_map->size     = size;
    p_virt_mem_map->was_initialized = 1;

    return 0;
}

int mem_mng_unregister_virt_mem_mapping(void *h_mem_mng,uint64_t virt_addr)
{
    t_mem_mng  *p_mem_mng = (t_mem_mng *)h_mem_mng;
    int array_size = ARRAY_SIZE(p_mem_mng->virt_mem_array), i = 0;
    t_sys_virt_mem_map *p_virt_mem_map = NULL;
    for ( i = 0; i < array_size;i++)
    {
	p_virt_mem_map = &p_mem_mng->virt_mem_array[i];
	if(virt_addr >= p_virt_mem_map->virt_addr &&
	   virt_addr < p_virt_mem_map->virt_addr + p_virt_mem_map->size){
		p_virt_mem_map->was_initialized = 0;
		break;
	}
    }
    return 0;
}

uint64_t mem_mng_virt_to_phys(void *h_mem_mng,void *virt_addr)
{
    t_mem_mng  *p_mem_mng = (t_mem_mng *)h_mem_mng;
    t_sys_virt_mem_map *p_virt_mem_map = NULL;
    uint64_t        virt_addr64 = PTR_TO_UINT(virt_addr);
    int array_size = ARRAY_SIZE(p_mem_mng->virt_mem_array), i = 0;

    for ( i = 0; i < array_size;i++){
	p_virt_mem_map = &p_mem_mng->virt_mem_array[i];
	if(p_virt_mem_map->was_initialized &&
	   virt_addr64 >= p_virt_mem_map->virt_addr &&
	   virt_addr64 < p_virt_mem_map->virt_addr + p_virt_mem_map->size)
	   return (dma_addr_t)
		 (virt_addr64 - p_virt_mem_map->virt_addr + p_virt_mem_map->phys_addr);
    }
    /* Mapping not found */
    return (dma_addr_t)virt_addr64;
}

void *mem_mng_phys_to_virt(void *h_mem_mng,dma_addr_t phys_addr)
{
    t_mem_mng  *p_mem_mng = (t_mem_mng *)h_mem_mng;
    int array_size = ARRAY_SIZE(p_mem_mng->virt_mem_array), i = 0;
    t_sys_virt_mem_map *p_virt_mem_map = NULL;

    for ( i = 0; i < array_size;i++){
	p_virt_mem_map = &p_mem_mng->virt_mem_array[i];
	if(p_virt_mem_map->was_initialized &&
	   phys_addr >= p_virt_mem_map->phys_addr &&
	   phys_addr < p_virt_mem_map->phys_addr + p_virt_mem_map->size)
	   return UINT_TO_PTR(phys_addr - p_virt_mem_map->phys_addr + p_virt_mem_map->virt_addr);
    }
    /* Mapping not found */
    return UINT_TO_PTR(phys_addr);
}

void mem_mng_print_partition_info(t_mem_mng_partition *p_partition, int reportLeaks,
		t_mem_mng_leak_report_func *h_report)
{
    ASSERT_COND(p_partition);

    t_mem_mng_leak_report_func *report_leak =  NULL;
#ifdef MEM_MNG_COUNT_ALLOC
    int32_t leaks_cnt = mem_mng_check_mem_partition(p_partition);
#endif //MEM_MNG_COUNT_ALLOC
    pr_info("partition - %s: (alloc)\r\n",p_partition->info.name);
    pr_info("----------------------------------------\r\n");
    pr_info("base address:         0x%08X%08X\r\n",
    		UINT32_HI(p_partition->info.base_address), UINT32_LO(p_partition->info.base_address));
    pr_info("total size (KB):      %18lu\r\n", UINT32_LO((p_partition->info.size / 1024)));
#ifdef MEM_MNG_COUNT_ALLOC
#ifdef MEM_MNG_REC_ALLOC_INFO
	pr_info("current usage (B):   %19lu\r\n", p_partition->info.current_usage);
	pr_info("maximum usage (B):   %19lu\r\n", p_partition->info.maximum_usage);
#endif //MEM_MNG_REC_ALLOC_INFO
    pr_info("total allocations:    %18lu\r\n", p_partition->info.total_allocations);
    pr_info("total deallocations:  %18lu\r\n", p_partition->info.total_deallocations);

    if (leaks_cnt) {
        pr_info("leaks count:  %26d\r\n", leaks_cnt);
#ifdef MEM_MNG_REC_ALLOC_INFO
         if(reportLeaks) {
             pr_info("memory leaks report:\r\n");
             pr_info("------------------------------------------------------------\r\n");
        	 mem_mng_report_mem_partition_leaks(p_partition, report_leak);
         }
#endif //MEM_MNG_REC_ALLOC_INFO
    } else {
    	 pr_info("no memory leaks found\r\n");
    }
#endif //MEM_MNG_COUNT_ALLOC
    pr_info("#\r\n");
}

void mem_mng_print_phys_partition_info(t_mem_mng_phys_addr_alloc_partition *p_partition,
		int reportLeaks, t_mem_mng_leak_report_func *h_report)
{
    ASSERT_COND(p_partition);

    t_mem_mng_leak_report_func *report_leak =  NULL;
#ifdef MEM_MNG_COUNT_ALLOC
    int32_t leaks_cnt = mem_mng_check_phys_alloc(p_partition);
#endif //MEM_MNG_COUNT_ALLOC
    pr_info("partition - %s: (phys)\r\n",p_partition->info.name);
    pr_info("----------------------------------------\r\n");
    pr_info("base address:         0x%08X%08X\r\n",
    		UINT32_HI(p_partition->info.base_paddress), UINT32_LO(p_partition->info.base_paddress));
    pr_info("total size (KB):      %18lu\r\n", UINT32_LO((p_partition->info.size / 1024)));
#ifdef MEM_MNG_COUNT_ALLOC
#ifdef MEM_MNG_REC_ALLOC_INFO
	pr_info("current usage (B):   %19lu\r\n", p_partition->info.current_usage);
	pr_info("maximum usage (B):   %19lu\r\n", p_partition->info.maximum_usage);
#endif //MEM_MNG_REC_ALLOC_INFO
    pr_info("total allocations:    %18lu\r\n", p_partition->info.total_allocations);
    pr_info("total deallocations:  %18lu\r\n", p_partition->info.total_deallocations);

    if (leaks_cnt) {
        pr_info("leaks count:  %26d\r\n", leaks_cnt);
#ifdef MEM_MNG_REC_ALLOC_INFO
         if(reportLeaks) {
             pr_info("memory leaks report: \r\n");
             pr_info("------------------------------------------------------------\r\n");
        	 mem_mng_report_phys_alloc_leaks(p_partition, report_leak);
         }
#endif //MEM_MNG_REC_ALLOC_INFO
    } else {
    	 pr_info("no memory leaks found\r\n");
    }
#endif //MEM_MNG_COUNT_ALLOC
    pr_info("#\r\n");
}

#ifdef MEM_MNG_COUNT_ALLOC
void mem_mng_set_alloc_flags(void *h_mem_mng, uint32_t flags)
{
	UNUSED(flags);
    t_mem_mng  *p_mem_mng = (t_mem_mng *)h_mem_mng;

    if ((flags & MC_MISC_MM_ALLOC_CHECK_COUNTERS) ==
    		MC_MISC_MM_ALLOC_CHECK_COUNTERS) {
    	p_mem_mng->enable_debug = 1;
    }

    if ((flags & MC_MISC_MM_ALLOC_ENABLE_REC_INFO) ==
    		MC_MISC_MM_ALLOC_ENABLE_REC_INFO) {
    	p_mem_mng->report_mem_leaks = 1;
    }
}

int32_t mem_mng_check_alloc(void *h_mem_mng)
{
    t_mem_mng *p_mem_mng = (t_mem_mng *)h_mem_mng;
    int i = 0,
    		size = ARRAY_SIZE(p_mem_mng->mem_partitions_array);
    int32_t cnt = 0;

    t_mem_mng_partition *p_partition = NULL;
    t_mem_mng_phys_addr_alloc_partition *p_phys_partition = NULL;

    /* dump alloc partitions debug info */
    for (; i < size; ++i) {
    	p_partition = p_mem_mng->mem_partitions_array + i;
    	if (p_partition->was_initialized) {
    		cnt += mem_mng_check_mem_partition(p_partition);
    	}
    }

    /* dump alloc partitions debug info */
    size = ARRAY_SIZE(p_mem_mng->phys_allocation_mem_partitions_array);
    for (i = 0; i < size; ++i) {
    	p_phys_partition = p_mem_mng->phys_allocation_mem_partitions_array + i;
    	if (p_phys_partition->was_initialized) {
    		cnt += mem_mng_check_phys_alloc(p_phys_partition);
    	}
    }

    return cnt;
}
#endif //MEM_MNG_COUNT_ALLOC

void mem_mng_print_alloc_info(void *h_mem_mng, t_mem_mng_leak_report_func *f_report_leak)
{
    t_mem_mng *p_mem_mng = (t_mem_mng *)h_mem_mng;
    int i = 0,
    		size = ARRAY_SIZE(p_mem_mng->mem_partitions_array);
    t_mem_mng_partition *p_partition = NULL;
    t_mem_mng_phys_addr_alloc_partition *p_phys_partition = NULL;

    /* dump alloc partitions debug info */
    for (; i < size; ++i) {
    	p_partition = p_mem_mng->mem_partitions_array + i;
    	if (p_partition->was_initialized) {
    		mem_mng_print_partition_info(p_partition,
    				p_mem_mng->report_mem_leaks, f_report_leak);
    	}
    }

    /* dump alloc partitions debug info */
    size = ARRAY_SIZE(p_mem_mng->phys_allocation_mem_partitions_array);
    for (i = 0; i < size; ++i) {
    	p_phys_partition = p_mem_mng->phys_allocation_mem_partitions_array + i;
    	if (p_phys_partition->was_initialized) {
    		mem_mng_print_phys_partition_info(p_phys_partition,
    				p_mem_mng->report_mem_leaks, f_report_leak);
    	}
    }
}
