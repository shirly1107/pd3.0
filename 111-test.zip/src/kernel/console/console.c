/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_gen.h"
#include "kernel/fsl_spinlock.h"
#include "common/fsl_string.h"
#include "fsl_console.h"
#include "fsl_system.h"

int sys_register_console(void * h_console_dev,
                        int(*f_console_print)(void * h_console_dev,
                        	uint8_t *p_data,
                        	uint32_t size),
                        int(*f_console_get)(void * h_console_dev,
                        	uint8_t *p_data,
                        	uint32_t size))
{
	if (sys.console){
		pr_err("system console");
		return -EEXIST;
	}
	/* Must have Print routine (Get routine is not mandatory) */
	ASSERT_COND(f_console_print);
	sys.console = h_console_dev;
	sys.f_console_print = f_console_print;
	sys.f_console_get = f_console_get;
	spin_lock_init(&(sys.console_lock));
	return 0;
}

void sys_flush_pre_console_buf(void * h_console_dev)
{
	uint32_t core_id = core_get_id();
	/* Flush pre-console printouts as necessary */
	if (h_console_dev && sys.p_pre_console_buf[core_id]) {
		sys_print(sys.p_pre_console_buf[core_id], SYS_PRINT_TO_CONSOLE_DEVICE);
		sys.p_pre_console_buf[core_id] = NULL;
		sys.pre_console_buf_pos[core_id] = 0;
	}
}

int sys_unregister_console(void)
{
	if (!sys.console){
		pr_err("console");
		return -ENODEV;
	}
	sys.console = NULL;
	return 0;
}

void sys_print(char *str, int print_type)
{
	uint32_t count = (uint32_t)strlen(str);
	uint32_t core_id = core_get_id();
	uint32_t int_flags;

	if (print_type & SYS_PRINT_TO_LOG_BUFFER)
	{
		/* Print to log buffer */
		log_print(str, count);
	}

	if (print_type & SYS_PRINT_TO_CONSOLE_DEVICE)
	{
		/* Print to the registered console, if exists */
		if (sys.console)
		{
			int_flags = spin_lock_irqsave(&(sys.console_lock));
			sys.f_console_print(sys.console, (uint8_t *)str, count);
			spin_unlock_irqrestore(&(sys.console_lock), int_flags);
		}
		else
		{
			if (!sys.p_pre_console_buf[core_id])
			{
				/* Cannot print error message - print called before entering to sys_init */
				return;
			}
			else
			{
				if (count >= (PRE_CONSOLE_BUF_SIZE - sys.pre_console_buf_pos[core_id])) {
					/* Reached buffer end - overwrite from buffer start */
					sys.pre_console_buf_pos[core_id] = 0;
					sys.pre_console_buf_pos[core_id] += sprintf(
						sys.p_pre_console_buf[core_id], "[TRUNCATED]...\n");
				}

				memcpy(&(sys.p_pre_console_buf[core_id][sys.pre_console_buf_pos[core_id]]),
					   str, /* sys.print_buf */
					   count);
				sys.pre_console_buf_pos[core_id] += count;
			}
		}
	}
}

char sys_get_char(void)
{
	uint8_t temp_char;
	int read_chars;
	uint32_t int_flags;

	if (sys.console && sys.f_console_get) {
		int_flags = spin_lock_irqsave(&(sys.console_lock));

		read_chars = sys.f_console_get(sys.console, &temp_char, 1);

		spin_unlock_irqrestore(&(sys.console_lock), int_flags);

		if (read_chars == 1)
			return temp_char;
	}

	return ('\0');
}
