/*
 * Copyright 2013-2020 NXP
 */

#ifndef __TASKLET_H
#define __TASKLET_H

#define TASKLET_STARVATION_LIMIT  100

#define NUM_OF_TASKLET_PRIORITIES 2
#define MIN_NUM_OF_TASKLETS       1

#if MIN_NUM_OF_TASKLETS <= 0
#error "Minimum number of tasklets must be over 0"
#endif

#if TASKLET_STARVATION_LIMIT <= 1
#error "Tasklet starvation limit must be at least 1"
#endif

#if NUM_OF_TASKLET_PRIORITIES < 2
#error "Number of tasklet priorities must be at least 2 (immediate/delayed)"
#endif

#include "fsl_types.h"

enum tasklet_state_t {
	tasklet_state_ready,
	tasklet_state_running
};

struct tasklet_node_t {
	struct tasklet_node_t *next;
	enum tasklet_state_t state;
	void (*func)(uint64_t data);
	uint64_t data;
};

struct tasklet_list_t {
	struct tasklet_node_t *head;
	struct tasklet_node_t *tail;
};

/* 
 * Start running the tasklet scheduler.
 * Should be called from ISR epilog.
 */
void start_scheduler(void);

/*
 * This should be called from the ISR epilog
 * to enable tasklet scheduling
 */
void tasklets_isr_epilog(uint32_t orig_msr);

#endif /* __TASKLET_H */
