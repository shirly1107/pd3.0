/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "tasklet.h"
#include "fsl_tasklet.h"
#include "fsl_slab.h"
#include "fsl_soc_arch.h"
#include "fsl_core.h"
#include "fsl_dbg.h"
#include "fsl_errors.h"

#include "fsl_core_booke_regs.h"
#include "fsl_core_booke.h"

static uint8_t scheduler_is_running[INTG_MAX_NUM_OF_CORES];

/* Pointers to slab handles */
static struct slab *tasklets_slab[INTG_MAX_NUM_OF_CORES];

/* Linked lists */
static struct tasklet_list_t tasklet_list[INTG_MAX_NUM_OF_CORES][NUM_OF_TASKLET_PRIORITIES];

static uint32_t starvation_counter[INTG_MAX_NUM_OF_CORES];

static void push_to_tail(struct tasklet_node_t* node, struct tasklet_list_t* list)
{
	uint32_t int_flags;
	
	ASSERT_COND(list != NULL);
	ASSERT_COND(node != NULL);

	int_flags = core_local_irq_save();
	
	/* Check if list is empty */
	if(list->tail == NULL) 
	{
		/* If tail is null than head also must be null */
		ASSERT_COND(list->head == NULL); 
		
		list->head = list->tail = node;
	}
	else
	{
		list->tail->next = node;
		list->tail = list->tail->next;
	}
	
	core_local_irq_restore(int_flags);
}

static struct tasklet_node_t* pop_from_head(struct tasklet_list_t* list)
{
	struct tasklet_node_t* node;
	uint32_t int_flags;
	
	ASSERT_COND(list != NULL);
	
	int_flags = core_local_irq_save();

	node = list->head;
	
	if(list->head != NULL) 
	{
		list->head = list->head->next;
		if(list->head == NULL) list->tail = NULL;
	}
	
	core_local_irq_restore(int_flags);
	
	return node;
}

int tasklet_module_init(uint32_t max_num_of_tasklets, uint8_t mem_part_id)
{
	int err;
	uint32_t core_id = core_get_id();
	
	ASSERT_COND(max_num_of_tasklets >= MIN_NUM_OF_TASKLETS);
	
	err = slab_create("tasklet nodes", &tasklets_slab[core_id], 
			max_num_of_tasklets, sizeof(struct tasklet_node_t), 
			0, 0, 0, mem_part_id, 1);
	if(err) {
		return err;
	}
	
	/* Clear running flag */
	scheduler_is_running[core_id] = 0;
	
	/* clear the starvation count */
	starvation_counter[core_id] = 0;
	
	/* Initiate the delayed lists */
	tasklet_list[core_id][tsk_priority_delayed].head = NULL;
	tasklet_list[core_id][tsk_priority_delayed].tail = NULL;
	
	/* Initiate the immediate lists */
	tasklet_list[core_id][tsk_priority_immediate].head = NULL;
	tasklet_list[core_id][tsk_priority_immediate].tail = NULL;
	
	return 0;
}

int fsl_schedule_tasklet(void (*func)(uint64_t data), uint64_t data, enum tasklet_priority_t priority)
{
	int err;
	uint32_t core_id = core_get_id();
	uint64_t tmp_addr;
	struct tasklet_node_t* node;

	/* Allocate memory for a list node */
	err = slab_acquire(tasklets_slab[core_id], &tmp_addr);
	if(err) {
		return err;
	}
	
	/* make sure address is 32 bit */
	ASSERT_COND((tmp_addr & 0xffffffff00000000ULL) == 0x0ULL);
	
	node = (struct tasklet_node_t *)UINT_TO_PTR(tmp_addr);
	if(node == NULL) {
		return -ENOMEM;
	}
	
	/* Set data */
	node->next = NULL;
	node->func = func;
	node->data = data;
	node->state = tasklet_state_ready;
	
	push_to_tail(node, &tasklet_list[core_id][priority]);	
	
	return 0;
}

static void flush_tasklets_from_list(struct tasklet_list_t* list)
{
	uint32_t core_id = core_get_id();
	struct tasklet_node_t* node;
	
	do {
		node = pop_from_head(list);
		if(node != NULL) 
		{
			slab_release(tasklets_slab[core_id], (uint64_t)node);
		}
	}while(node != NULL);
}

void fsl_flush_scheduled_tasklets()
{
	uint32_t core_id = core_get_id();

	flush_tasklets_from_list(&tasklet_list[core_id][tsk_priority_immediate]);
	flush_tasklets_from_list(&tasklet_list[core_id][tsk_priority_delayed]);
}

void start_scheduler()
{
	uint32_t core_id = core_get_id();
	struct tasklet_node_t* node;
	
	do {
		if(starvation_counter[core_id] < TASKLET_STARVATION_LIMIT)
		{
			node = pop_from_head(&tasklet_list[core_id][tsk_priority_immediate]);
			if(node != NULL) {
				starvation_counter[core_id]++;
				
				node->state = tasklet_state_running;
				node->func(node->data);
				slab_release(tasklets_slab[core_id], (uint64_t)node);
				continue;
			}
		}
		
		starvation_counter[core_id] = 0;
		
		node = pop_from_head(&tasklet_list[core_id][tsk_priority_delayed]);
		if(node != NULL) 
		{
			node->state = tasklet_state_running;
			node->func(node->data);
			slab_release(tasklets_slab[core_id], (uint64_t)node);
		}
		
	}while(node != NULL);
}

void tasklets_isr_epilog(uint32_t orig_msr)
{
	uint32_t core_id = core_get_id();
	
	if(!scheduler_is_running[core_id]) 
	{
		uint32_t isr_msr = get_msr();
		scheduler_is_running[core_id] = 1;
		
		msr_restore(orig_msr);
		start_scheduler();
		msr_restore(isr_msr);
		
		scheduler_is_running[core_id] = 0;
	}
}
