/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_stdio.h"
#include "common/fsl_string.h"
#include "fsl_smp.h"
#include "fsl_malloc.h"
#include "dpc.h"
#include "dpl.h"
#include "fsl_dpmng_mc.h"
#include "fsl_dpaiop_mc.h"
#include "mpu.h"
#include "drivers/fsl_serdes.h"

extern int sys_init(void);
extern void sys_free(void);
extern int global_init(void);
extern int global_post_init(void);
extern int run_apps(void);

extern uint64_t dpaa_sys_ddr_base;
extern uint64_t dpaa_sys_ddr_size;

int in_dpl_processing = 0;

static void start_aiop(void)
{
	struct dpaiop *dpaiop;
	struct dpaiop_run_cfg run_cfg = {0};
	struct dpaiop_load_cfg load_cfg = {0};
	int err;

	dpaiop = sys_get_handle(FSL_MOD_DPAIOP, 1, 0);

	if (dpaiop)
	{
		load_cfg.img_iova = DPAIOP_ELF_LOAD_ADDRESS_LPVOID;
		load_cfg.options = 0x8000000000000000 | DPAIOP_LOAD_OPT_DEBUG;
		err = dpaiop_load(dpaiop, &load_cfg);
		if (err)
			pr_info("AIOP load failed (%d), elf image expected at 0x%x\n", err, DPAIOP_ELF_LOAD_ADDRESS);
		else {
			run_cfg.cores_mask = 0xffff;
			run_cfg.options = DPAIOP_RUN_OPT_DEBUG;

			err = dpaiop_run(dpaiop, &run_cfg);
			if (err)
				pr_info("AIOP run failed (%d)\n", err);
#if 0
			else
			{
				uint32_t status;
				do {
					dpaiop_get_state(dpaiop, &status);
				} while (status == DPAIOP_STATE_BOOT_ONGOING);
					
				if (status == DPAIOP_STATE_RUNNING)
					pr_info("AIOP boot completed\n");
				else
					pr_info("AIOP boot failed\n");
			}
#endif
		}
	}
	else
		pr_info("No DPAIOP in DPL - skipping AIOP load\n");
}


int main(int argc, char *argv[])
{
	int err;
	int is_master_core;
	struct mc_version mc_version;
	uint32_t mc_boot_code;
	struct dpmng_amq amq = {0};
	uint32_t status;

	UNUSED(argc);
	UNUSED(argv);

	status = MC_INIT_DONE;
	err = sys_early_init();
	if (err) {
		if (err == -EINVAL)	
			dpmng_set_mc_status(MC_INCOMPATIBLE_ERR);
		else
			dpmng_set_mc_status(MC_SYS_INIT_ERR);
		return err;
	}

	/* Do early operations prior to system initialization */
	if (core_get_id() == 0) {
		/* Find out how much system memory is allocated for MC */
		dpmng_set_dpaa_sys_ddr_region();

		/* Process DPC */
		dpc_process();

		/* LOG initialization */
		log_init();
	}

	/* Read MC boot code */
	mc_boot_code = dpmng_get_mc_status();

	/* Initialize system */
	err = sys_init();
	if (err) {
		dpmng_set_mc_status(MC_SYS_INIT_ERR);
		return err;
	}

#ifdef EMULATOR
#if defined(EMULATOR_LX2160)
	pr_info("Emulator: running MC for LX2160\n");
#elif defined(EMULATOR_LS2088)
	pr_info("Emulator: running MC for LS2088\n");
#elif defined(EMULATOR_LS1088)
	pr_info("Emulator: running MC for LS1088\n");
#elif defined(EMULATOR_UA)
	pr_info("Emulator: running MC for LA1575A\n");	
#endif
#endif /* EMULATOR */

	is_master_core = sys_is_master_core();

	if (is_master_core)
	{
		mc_get_version(&mc_version);
		pr_info("MC firmware version: %d.%d.%d\n",
			mc_version.major, mc_version.minor, mc_version.revision);
		pr_info("MC DDR base: 0x%08x%08x\n",
						UINT32_HI(dpaa_sys_ddr_base),
						UINT32_LO(dpaa_sys_ddr_base));
		pr_info("MC DDR Size = 0x%08x%08x\n",
						UINT32_HI(dpaa_sys_ddr_size),
						UINT32_LO(dpaa_sys_ddr_size));
		dpmng_get_amq(&amq);
		pr_info ("MC Attributes (AMQ): ICID-%d; BMT-%d; PL-%d; BDI-%d; VA-%d\n",
			amq.icid, amq.bmt, amq.pl, amq.bdi, amq.va);

#ifdef DEBUG
		mpu_print_tables();
#endif
		err = global_init();
		if (err) {
			pr_err("MC error status: 0x%08x\n", dpmng_get_mc_status());
			return err;
		}		
	}
	sys_barrier();

	/* Increase gain on the TX side for LX2 SerDes */
	serdes_wa_gain_tecr();

	/* Workaround for TKT320141
	 *
	 * The problem occurs when the SerDes module's clock/data
	 * recovery (CDR) lock status for the 10.3125 Gbps lane gets
	 * stuck in the unlocked state. A software interaction is required
	 * for the CDR to recover and the XFI link to complete
	 * initialization.
	 */

         /*
	  * This WR is deprecated. MC must not enable a lane before any MAC, that is available in the devdisr, comes
	  * into existence. In other words, it's a good practice not to have any signal on a lane unless a DPMAC object
	  * is created by the user. The MAC driver will periodically check for the CDR lock after the MAC
	  * has been initialized and this is enough. A use case for this is a situation in which, due to a problematic
	  * design (e.g. some SerDes signals out of spec would influence the clock - in general Rx clock, and traffic
	  * on the Rx side might be affected - frame physical errors) we must turn off the SerDes lanes on our side
	  * at early stages, before the MC has been started. This is not possible if the wr below is applied because
	  * the lane config from the early stages will be overwritten by the call below.
	  */
/*
#ifdef TKT320141
	serdes_wa_cdr_lock();
#endif
*/

	if (is_master_core ) {
		if (mc_boot_code == BOOT_CODE_DELAYED_DPL_DEPLOYMENT) {
			pr_info("Waiting for indication to process DPL...\n");
			dpmng_set_mc_status(MC_INIT_DONE);
			while (dpmng_get_mc_status() != 0) {}
		}

		pr_info("Processing DPL...\n");
		in_dpl_processing = 1;
		err = dpl_process();
		in_dpl_processing = 0;

		if (err)
		{
			pr_err("DPL processing failed; continuing...\n");
			status = MC_LO_PROCESS_ERR;
			dpmng_set_mc_status(status);
		}
	}
	sys_barrier();

	if (is_master_core)
		/* Start AIOP if image is found */
		start_aiop();

	sys_barrier();

	if (is_master_core) {
		pr_info("MC boot done; Running...\n");
		dpmng_set_mc_status(status);
	}
	sys_barrier();

	run_apps();
	sys_barrier();

	/* Free system */
	sys_free();

	return 0;
}

