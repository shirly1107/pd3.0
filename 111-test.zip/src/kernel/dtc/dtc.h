/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DTC_H
#define _DTC_H
#include "dtc/libfdt/libfdt.h"
#include "fsl_dbg.h"

#if 0
struct boot_info *dtc_from_blob(const unsigned int *dt_blob);

/**
 * @brief	Gets the value (number) of a given property from layout \
 * 		structure.
 *
 * @param[in]	node			The specific node from layout.
 * @param[in]	propname		String contains the property name
 * @param[in]	index			in case of an array value, this is the \
 * 					index of the required value. shuld be \
 * 					'0' otherwise
 *
 * @returns	'0' on Success; Error code otherwise.
 */
uint64_t get_val(struct node *node, const char *propname, int index);
/**
 * @brief	Gets the enum string of a given property from layout \
 * 		structure.
 *
 * @param[in]	node			The specific node from layout.
 * @param[in]	propname		String contains the property name
 *
 * @returns	pointer to the string representing the enum on Success; NULL otherwise.
 */

char * get_enum(struct node *node, const char *propname);
#endif
/**
 * @brief	Gets the ID of a given device node.
 *
 * @param[in]	dtc_addr			pointer to the layout blob.
 * @param[in]	node_off		structure block offset of a node.
 * @param[out]	id			requested ID.
 *
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int get_node_id(void *dtc_addr, int node_off, int *id);

/**
 * @brief	Gets the value (number) of a given property from layout \
 * 		structure.
 *
 * @param[in]	dtc_addr			pointer to the layout blob.
 * @param[in]	node_off		structure block offset of a node.
 * @param[in]	propname		String contains the property name
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int getprop_val(void *dtc_addr, int node_off, const char *propname, const char *default_str, int default_val ,uint64_t *val);

/**
 * @brief	Gets the value (number) of one cell from a given property's \
 * 		array from layout structure.
 *
 * @param[in]	dtc_addr			pointer to the layout blob.
 * @param[in]	node_off		structure block offset of a node.
 * @param[in]	propname		String contains the property name
 * @param[in]	index			cell index requested
 * @returns	'0' on Success; Error code otherwise.
 */
int getprop_array(void *dtc_addr, int node_off, const char *propname, int index, uint32_t *val);

/**
 * @brief	Gets the value (number) of one cell from a given property's \
 * 		array from layout structure.
 *
 * @param[in]	dtc_addr			pointer to the layout blob.
 * @param[in]	node_off		structure block offset of a node.
 * @param[in]	propname		String contains the property name
 * @param[in]	index			cell index requested
 * @returns	'0' on Success; Error code otherwise.
 */
int get_node_name(void *dtc_addr, int node_off, char *node_name);

struct dtc {
	struct sys_dtc_mod_params *module;
	struct dtc *next;
};

/* Provides node name and probe function */
struct dtc_node_parser {
	const char* node_name;
	int (*subnode_process)(void *dtc_addr, int node_off);
	int stop_proc_and_ret_on_error; // '1' (true): dtc_process() returns
									// immediately with the parse error
};
/* Additional parameters for dtc_process() */
struct dtc_parse_params {
	/* parse the below dtc nodes first and in the specified order */
	const struct dtc_node_parser* node_order;
	int node_order_size; // size of node_order array
	int parse_all_nodes; // true: parse all nodes as in the following order:
						 // (1) provided nodes in the specified order
						 // (2) rest of nodes in the ordedr found in dtb
						 // false: try parse only the provided nodes in the
						 // specified order
};

#define MAX_OBJ_TYPE_NAME 64

struct dtc *sys_get_dtc(void);

int dtc_process(void *dtc_addr, struct dtc*, const struct dtc_parse_params*);
const char* dtc_get_last_visited_node();

int dtc_drv_init(void);


#endif /* _DTC_H */
