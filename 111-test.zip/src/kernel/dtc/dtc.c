/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_system.h"
#include "dtc/dtc.h"
#include "kernel/layout.h"
#include "fsl_resman.h"

/*! Global variables */
static int global_dtc_err = 0;

/******************************************************************************/
/* functions for reading binary file                                          */
/******************************************************************************/

#define PROPERY_NOT_DEFINED -1

int getprop_val(void *dtc_addr,
	int node_off,
	const char *propname,
	const char *default_str,
	int default_val,
	uint64_t *val)
{
	uint64_t *tmp_val64;
	char *prop;
	int len;
	prop = (char *)fdt_getprop(dtc_addr, node_off, propname, &len);
	if (!prop) {
		*val = default_val;
		return -EINVAL;
	}
	if (default_str && !strcmp(prop, default_str)) {
		*val = default_val;
		return 0;
	}
	tmp_val64 = (uint64_t *)prop;
	*val = (uint64_t)((*tmp_val64) >> (8 * (8 - len)));

	return 0;
}

int getprop_array(void *dtc_addr,
	int node_off,
	const char *propname,
	int index,
	uint32_t *val)
{
	uint32_t *tmp_val;
	char *prop;
	int len;
	prop = (char *)fdt_getprop(dtc_addr, node_off, propname, &len);
	if (!prop) {
		*val = 0;
		return -EINVAL;
	}
	tmp_val = (uint32_t *)prop;
	/* move to next array index */
	tmp_val = PTR_MOVE(tmp_val, (index * 4) );
	if ((index * 4) < len)
		*val = *tmp_val;
	else
		*val = 0;
	return 0;
}

int get_node_id(void *dtc_addr, int node_off, int *id)
{
	char *tokens;
	char original[64];
	const char *name;
	int err = 0;

	name = fdt_get_name(dtc_addr, node_off, NULL);
	if (!name) {
		pr_err("node name is not defined!\n");
		return -EINVAL;
	}
	strncpy(original, name, sizeof(original) - 1);
	original[strlen(name)] = '\0';
	tokens = strtok(original, "@");
	if (!tokens)
		return -EINVAL;

	*id = atoi(PTR_MOVE(tokens,strlen(tokens)+1));

	return err;
}

int get_node_name(void *dtc_addr, int node_off, char *node_name)
{
	const char *name;
	int len;

	name = fdt_get_name(dtc_addr, node_off, &len);
	if (!name) {
		pr_err("node name is not found\n");
		return -EINVAL;
	}
	strncpy(node_name, name, (uint32_t)len);
	node_name[len] = '\0';
	node_name = strtok(node_name, "@");
	return 0;
}
/******************************************************************************/
/* functions for processing file into MC 			              */
/******************************************************************************/

struct dtc *sys_get_dtc(void)
{
	return (struct dtc *)sys_get_unique_handle(FSL_MOD_DTC);
}

static struct dtc * search_in_registry(struct dtc *dtc, const char *node_name)
{
	int j;

	while (dtc) {
		for (j = 0; j < dtc->module->num_compats; j++) {
			/*pr_info("debug: %d %s \n", j,
			 dtc->module->compatibles[j]);*/
			if (!strcmp(node_name, dtc->module->compatibles[j]))
				return dtc;
		}

		/* Continue to next node */
		dtc = dtc->next;
	}

	return NULL;
}

static int subnode_process(void *dtc_addr, int node_off, struct dtc *dtc)
{
	int subnode_off;
	char node_name[MAX_OBJ_TYPE_NAME];
	int err = 0;
	struct dtc *dtc_item;

	/* start processing subnodes */
	subnode_off = fdt_first_subnode(dtc_addr, node_off);

	while (subnode_off != -FDT_ERR_NOTFOUND) {
		get_node_name(dtc_addr, subnode_off, node_name);

		dtc_item = search_in_registry(dtc, node_name);
		if (dtc_item) {
			err = dtc_item->module->f_prob_module(dtc_addr,
								subnode_off); /* call driver */
			if (err) {
				// log the error
				pr_err("Probing module '%s' return error code %d. "
						"Continue dpl processing...\n",
						node_name, err);
				// Save the first encountered error in global err variable than clear the error and continue 
				// with next subnode
				if (!global_dtc_err) {
					global_dtc_err = err;
				}
				err = 0;
			}
		} else {
			pr_err("Cannot process unregistered module %s\n",
					node_name);
		}

		subnode_off = fdt_next_subnode(dtc_addr, subnode_off);
	}
	return err;
}

static char last_visited_node[MAX_OBJ_TYPE_NAME];
const char* dtc_get_last_visited_node() {
	return last_visited_node;
}
int dtc_process(void *dtc_addr, struct dtc *dtc,
		const struct dtc_parse_params* params)
{
	int node_off;
	int* visited_nodes_offs = NULL;
	int err = 0;
	int continue_parse = 1;

	CHECK_COND_RETVAL(dtc, -EINVAL);
	CHECK_COND_RETVAL(dtc_addr, -EINVAL);

	/* check DTC validation */
	if (fdt_magic(dtc_addr) != 0xD00DFEED) {
		pr_err(
		"Illegal DTC found at address %08x; Continue without processing\n",
		PTR_TO_UINT(dtc_addr));
		return 0;
	}
	memset(last_visited_node, 0, MAX_OBJ_TYPE_NAME);
	/* start processing */
	global_dtc_err = 0;
	// some nodes need to be parsed first
	if (params && params->node_order && params->node_order_size > 0) {
		int nodes_arr_size = params->node_order_size + 1; // tail is 'NULL'
		int stop_visit = 0;
		visited_nodes_offs =
				fsl_malloc(nodes_arr_size * sizeof *visited_nodes_offs);
		memset(visited_nodes_offs, 0,
				nodes_arr_size * sizeof *visited_nodes_offs);
		int* visited_off = visited_nodes_offs;
		for (int idx = 0;
			idx < params->node_order_size && !stop_visit; idx++) {
			const struct dtc_node_parser* parser = &params->node_order[idx];
			if (!parser || strlen(parser->node_name) == 0)
				continue;
			node_off = fdt_first_subnode(dtc_addr, 0);
			while (node_off != -FDT_ERR_NOTFOUND)
			{
				if (get_node_name(dtc_addr, node_off, last_visited_node))
					break; // no reason to continue without a name
				if (strcmp(parser->node_name, last_visited_node) == 0) {
					*visited_off++ = node_off;
					if (parser->subnode_process)
						err = parser->subnode_process(dtc_addr, node_off);
					else /* default subnode process */
						err = subnode_process(dtc_addr, node_off, dtc);
					/* return any error for this node */
					if (err && parser->stop_proc_and_ret_on_error) {
						global_dtc_err = err;
						stop_visit = 1; // don't parse other nodes, just exit
					}
					break; // for
				}
				node_off = fdt_next_subnode(dtc_addr, node_off);
			}
		}
		continue_parse = params->parse_all_nodes && !stop_visit;
	}
	// don't parse the other nodes if we got an error while parsing the
	// required nodes or we finish parsing the required nodes
	if (continue_parse) {
		int* node = 0;
		node_off = fdt_first_subnode(dtc_addr, 0);
		while (node_off != -FDT_ERR_NOTFOUND)
		{
			get_node_name(dtc_addr, node_off, last_visited_node);
			node = visited_nodes_offs;
			while (node && *node != 0 && *node != node_off) {
				node++;
			};
			if (!visited_nodes_offs || *node == 0) {
				// ignore errors; individual probe functions
				// will set 'global_dtc_err' instead
				subnode_process(dtc_addr, node_off, dtc);
			}
			node_off = fdt_next_subnode(dtc_addr, node_off);
		}
	}
	if (visited_nodes_offs)
		fsl_free(visited_nodes_offs);
	return global_dtc_err;
}

static struct dtc *scan_dtc(struct dtc *dtc,
	struct sys_dtc_mod_params *dtc_mod_params)
{
	while (dtc->module && dtc->module->compatibles
		&& strcmp(*(dtc->module->compatibles),
				*(dtc_mod_params->compatibles))) {
		if (dtc->next)
			dtc = dtc->next;
		else
			break;
	}
	return dtc;
}

int sys_dtc_register_module(struct sys_dtc_mod_params *dtc_mod_params)
{
	struct dtc *dtc = sys_get_dtc();
	char *src;
	char *dest;
	int i = 0;

	ASSERT_COND(dtc);
	/* check if already registered */
	dtc = scan_dtc(dtc, dtc_mod_params);
	if (!dtc->module) /* register new module */
	{
		dtc->module = (struct sys_dtc_mod_params *)fsl_malloc(
			sizeof(struct sys_dtc_mod_params));
		if (!dtc->module) {
			pr_err("No memory for new DTC module\n");
			return -ENOMEM;
		}
		memset(dtc->module, 0x0, sizeof(struct sys_dtc_mod_params));
	} else if (!dtc->next) {
		dtc->next = (struct dtc *)fsl_malloc(sizeof(struct dtc));
		if (!dtc->next) {
			pr_err("No memory for new DTC module\n");
			return -ENOMEM;
		}
		memset(dtc->next, 0x0, sizeof(struct dtc));

		dtc = dtc->next;
		dtc->module = (struct sys_dtc_mod_params *)fsl_malloc(
			sizeof(struct sys_dtc_mod_params));
		if (!dtc->module) {
			pr_err("No memory for new DTC module\n");
			return -ENOMEM;
		}
		memset(dtc->module, 0x0, sizeof(struct sys_dtc_mod_params));

	} else if (dtc->module->compatibles
			&& !strcmp(*(dtc->module->compatibles),
					*(dtc_mod_params->compatibles))) {
		pr_debug("module already registered\n");
		return 0;
	}
	/* register module */
	dtc->module->compatibles = (char **)fsl_malloc(
		dtc_mod_params->num_compats * sizeof(char *));
	if (!dtc->module->compatibles) {
		pr_err("No memory for new DTC module\n");
		return -ENOMEM;
	}
	do {
		dtc->module->compatibles[i] = (char *)fsl_malloc(
			16 * sizeof(char));
		if (!(*(dtc->module->compatibles))) {
			pr_err("No memory for new DTC module\n");
			return -ENOMEM;
		}
		dest = dtc->module->compatibles[i];
		src = dtc_mod_params->compatibles[i];
		strcpy(dest, src);
		i++;
	} while (i < dtc_mod_params->num_compats);
	dtc->module->f_prob_module = dtc_mod_params->f_prob_module;
	dtc->module->f_remove_module = dtc_mod_params->f_remove_module;
	dtc->module->num_compats = dtc_mod_params->num_compats;
	for (i = 0; i < dtc_mod_params->num_compats; i++)
		pr_debug(
			"DTC registered %s module\n", dtc_mod_params->compatibles[i]);
	return 0;
}

int sys_dtc_unregister_module(char *module_match)
{
	struct dtc *dtc = sys_get_dtc();
	struct dtc *tmp;

	ASSERT_COND(dtc);
	/* search for registered device */
	if (!strcmp(*(dtc->module->compatibles), module_match)) {
		tmp = dtc;
		dtc = dtc->next;
		if (dtc) {
			pr_debug("WARNING: unregister from DTC changed order "
			"since register\n"
			"may cause un-freed objects\n");
			sys_remove_handle(FSL_MOD_DTC, 1, 0);
			sys_add_handle(dtc, FSL_MOD_DTC, 1, 0);
		}
		fsl_free(tmp->module);
		fsl_free(tmp);
		pr_debug("Removed %s from DTC\n", module_match);
		return 0;
	}
	while (strcmp(*(dtc->next->module->compatibles), module_match)) {
		if (dtc->next->next)
			dtc = dtc->next;
		else
			break;
	}
	if (!strcmp(*(dtc->next->module->compatibles), module_match)) {
		tmp = dtc->next;
		dtc->next = dtc->next->next;
		fsl_free(tmp->module);
		fsl_free(tmp);
		pr_info("Removed %s from DTC\n", module_match);
		return 0;
	}

	pr_debug("%s was not registered to DTC\n", module_match);
	return 0;
}

int dtc_drv_init(void)
{
	struct dtc *dtc;
	
	pr_info("Executing dtc_drv_init...\n");

	dtc = (struct dtc *)fsl_malloc(sizeof(struct dtc));
	if (!dtc) {
		pr_err("No memory for DTC init");
		return -ENOMEM;
	}
	memset(dtc, 0x0, sizeof(struct dtc));

	sys_add_handle(dtc, FSL_MOD_DTC, 1, 0);

	return 0;
}
