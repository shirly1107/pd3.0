/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 @File          timer.h

 @Description   structures and definitions for initialize and operate Timer
                module.
*//***************************************************************************/
#ifndef __TIMER_H
#define __TIMER_H

#include "fsl_types.h"
#include "fsl_timer.h"

#define __ERR_MODULE__  MODULE_UNKNOWN

#define TIMER_INTERVAL       1000 /* [uSec] 1 mSec */
#define MAX_NUM_OF_TIMERS    128

#define CONVERT_TO_USEC(__VAL_) ((__VAL_) * TIMER_INTERVAL)

/*
 * Timers may be dynamically created and destroyed, and should be initialized
 * by a call to InitTimer() upon creation.
 *
 * The "data" field enables use of a common timeout function for several
 * timeouts. You can use this field to distinguish between the different
 * invocations.
 * If timer's mode is E_TIMER_MODE_PERIODIC then there should be only one
 * tasklet currently scheduled.
 */
typedef struct t_timer
{
    uint64_t         expires; /* global time to expire at, in mSec */
    uint64_t         period;  /* in mSec */
    e_timer_mode     mode;    /* Timer mode of operation (single/periodic) */
    int              active;  /* if a timer is pending or not (set by add(), clear by del() ) */
    int              valid;   /* indicates if timer exists (or just an empty slot) */
    int              is_sys;  /* indicates if timer is a system timer or user timer (will run in a tasklet)*/
    void*            data;
    void             (*f_timer_expired)(void*);
} t_timer;

typedef struct t_sys_timer_control {
    volatile uint64_t   global_time;
    t_timer             timers_array[MAX_NUM_OF_TIMERS];
    uint32_t            last_active_timer_id;
} t_sys_timer_control;

#endif /* __TIMER_H */

