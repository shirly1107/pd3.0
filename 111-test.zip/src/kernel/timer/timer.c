/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 @File          timer.c

 @Description   routines for initialize the timer module.
 *//***************************************************************************/
#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_timer.h"
#include "timer.h"
#include "fsl_errors.h"
#include "fsl_core.h"
#include "fsl_soc.h"
#include "fsl_dbg.h"
#include "fsl_core_booke_regs.h"
#include "mpic_timers.h"
#include "fsl_sl_dbg.h"
#include "fsl_tasklet.h"

t_sys_timer_control sys_timers[INTG_MAX_NUM_OF_CORES] = {{0}};

static void update_last_active_id()
{
	uint32_t int_flags, i;
	t_timer *p_timer;
	t_sys_timer_control *p_sys_timer_ctrl = &(sys_timers[core_get_id()]);
	uint32_t last_active_id = 0;

	int_flags = core_local_irq_save();
	for(i=0; i<MAX_NUM_OF_TIMERS; i++)
	{
		p_timer = &p_sys_timer_ctrl->timers_array[i];
		if((p_timer->valid) && (p_timer->active))
			last_active_id = i;
	}

	p_sys_timer_ctrl->last_active_timer_id = last_active_id;
	core_local_irq_restore(int_flags);
}

static void tsklt_isr(uint64_t data)
{
	t_timer *p_timer = (t_timer*)data;
	
	ASSERT_COND(p_timer != NULL);
	ASSERT_COND(p_timer->is_sys == 0);
	ASSERT_COND(p_timer->f_timer_expired);
	
	p_timer->f_timer_expired(p_timer->data);

	/* reactivate the periodic timers */
	if (p_timer->mode == E_TIMER_MODE_PERIODIC) {
		p_timer->active = 1;
		update_last_active_id();
	}
}

static void timer_expired(void* h_app, uint8_t id)
{
	t_sys_timer_control *p_sys_timer_ctrl = &(sys_timers[core_get_id()]);
	t_timer *p_timer;
	register uint32_t new_last_active_id = 0;
	register uint32_t i;

	UNUSED(h_app);

	ASSERT_COND(id == core_get_id());

	p_sys_timer_ctrl->global_time++;

	for(i=0; i <= p_sys_timer_ctrl->last_active_timer_id; i++)
	{
		p_timer = &p_sys_timer_ctrl->timers_array[i];
		if(p_timer->active)
		{
			ASSERT_COND(p_timer->valid);

			if(p_timer->expires <= p_sys_timer_ctrl->global_time)
			{
				if(p_timer->mode == E_TIMER_MODE_PERIODIC) {
					p_timer->expires = p_sys_timer_ctrl->global_time + p_timer->period;
					new_last_active_id = i;
				}else {
					p_timer->active = 0;
				}
				
				if(p_timer->is_sys) 
				{
					ASSERT_COND(p_timer->f_timer_expired);
					p_timer->f_timer_expired(p_timer->data);
				}else 
				{
					int err = fsl_schedule_tasklet(tsklt_isr, (uint64_t)p_timer, tsk_priority_delayed);
					if(err) {
						pr_err("Failed to schedule a tasklet for a user timer\n");
					} else if (p_timer->mode == E_TIMER_MODE_PERIODIC)
						/* don't schedule another tasklet for this timer */
						p_timer->active = 0;
				}
			}
			else
			{
				new_last_active_id = i;
			}
		}
	}

	p_sys_timer_ctrl->last_active_timer_id = new_last_active_id;
}

int timer_init_module()
{
	uint32_t core_id = core_get_id();
	t_sys_timer_control *p_sys_timer_ctrl = &(sys_timers[core_id]);
	int err;

	/* Clear timers array */
	memset((void*)p_sys_timer_ctrl->timers_array, 0, MAX_NUM_OF_TIMERS * sizeof(t_timer));

	p_sys_timer_ctrl->global_time = 0;
	p_sys_timer_ctrl->last_active_timer_id = 0;

	err = mpic_timer_start((uint8_t)core_id, timer_expired,
	                 NULL, TIMER_INTERVAL);
	if (err!= 0)
	{
		pr_err("timer start failed\n");
		return err;
	}

	return 0;
}

void timer_free_module(void)
{
	mpic_timer_stop((uint8_t)core_get_id());
}

void* timer_create(void)
{
	t_sys_timer_control *p_sys_timer_ctrl = &(sys_timers[core_get_id()]);
	t_timer *p_timer;
	int i;

	for(i=0; i<MAX_NUM_OF_TIMERS; i++)
	{
		p_timer = &p_sys_timer_ctrl->timers_array[i];
		if(!p_timer->valid)
		{
			memset(p_timer, 0, sizeof(t_timer));
			p_timer->valid = 1;
			return (void*)p_timer;
		}
	}

	pr_err("user timer structure\n");
	return NULL;
}

int timer_init(void* tmr, uint32_t msecs,
               void (*f_timer_expired)(void*),
               void* data, e_timer_mode mode,
               int sys_timer)
{
	t_timer             *p_timer = (t_timer *)tmr;

	p_timer->active = 0;
	p_timer->f_timer_expired = f_timer_expired;
	p_timer->data = data;
	p_timer->period = msecs;
	p_timer->mode = mode;
	p_timer->is_sys = sys_timer;
	return 0;
}

int timer_free(void* tmr)
{
	if(!tmr) {
		pr_crit("Null pointer");
		return -ENODEV;
	}

	timer_stop(tmr);
	((t_timer *)tmr)->valid = 0;

	return 0;
}

uint64_t timer_get_expiration_time(void* tmr)
{
	return ((t_timer *)tmr)->expires;
}

void timer_start(void* tmr)
{
	t_sys_timer_control *p_sys_timer_ctrl = &(sys_timers[core_get_id()]);
	t_timer *p_timer = (t_timer *)tmr;

	if(!p_timer) {
		pr_crit("Null handle passed to timer_add\n");
		return;
	}

	if(IS_SIM)
	{
		p_timer->f_timer_expired(p_timer->data); /* call the callback */
	}
	else
	{
		p_timer->expires = p_sys_timer_ctrl->global_time + p_timer->period;
		p_timer->active = 1;

		update_last_active_id();
	}
}

void timer_stop(void* tmr)
{
	((t_timer *)tmr)->active = 0;
	update_last_active_id();
}

int timer_mod(void* tmr, uint32_t msecs)
{
	t_timer *p_timer = (t_timer *)tmr;

	if(!p_timer) {
		pr_crit("Null pointer");
		return -ENODEV;
	}

	/* Update just the time value here before reading. Everything else remains the same */
	p_timer->period = msecs;

	timer_start(p_timer);

	return 0;
}

int timer_is_pending (const void* tmr)
{
	t_timer	*p_timer = (t_timer *)tmr;
	return 	(p_timer->active && p_timer->valid);
}

uint64_t timer_current_time(void)
{
	t_sys_timer_control *p_sys_timer_ctrl = &(sys_timers[core_get_id()]);

	if(IS_SIM)
	{
		p_sys_timer_ctrl->global_time++;
	}

	return p_sys_timer_ctrl->global_time;
}

uint32_t timer_sleep(uint32_t msecs)
{
	uint64_t end_global_time;
	uint32_t temp_msr;

	end_global_time = timer_current_time() + msecs;

	temp_msr = get_msr();
	while (timer_current_time() < end_global_time)
	{
		msr_restore(temp_msr | MSR_EE);
		msr_restore(temp_msr);
	}

	return 0;
}

void timer_udelay(uint32_t usecs)
{
	uint32_t rollovers = 0;
	uint64_t current_time_val;
	uint64_t old_time_val;
	uint64_t end_time_stamp;
	uint64_t tmp_val = 0;
	uint8_t  core_id = (uint8_t)core_get_id();

	/* Initial time stamp */
	mpic_timer_get_time(core_id, &tmp_val);
	old_time_val = current_time_val = tmp_val;

	/* calculate end_times_tamp */
	end_time_stamp = current_time_val + usecs;

	while (current_time_val < end_time_stamp)
	{
		if(IS_SIM)
		{
			current_time_val++;
			continue;
		}

		uint32_t int_flags = core_local_irq_save();

		mpic_timer_get_time(core_id, &tmp_val);
		current_time_val = CONVERT_TO_USEC(rollovers) + tmp_val;

		if(current_time_val < old_time_val)
		{
			rollovers++;
			current_time_val = CONVERT_TO_USEC(rollovers) + tmp_val;
		}

		core_local_irq_restore(int_flags);

		old_time_val = current_time_val;
	}
}
