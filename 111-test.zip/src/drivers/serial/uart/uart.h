/*
 * Copyright 2013-2020 NXP
 */

/**
@File          uart.h

@Description   Internal header file for UART unit routines
*//***************************************************************************/
#ifndef __UART_H
#define __UART_H

#include "fsl_duart.h"
#include "fsl_types.h"

#define NUM_CONTROL_CHARS   8

#define DEFAULT_POLL_MODE                0       /* Default poll mode NO */
#define DEFAULT_NUM_cc_entries            2
#define DEFAULT_CONTROL_CHAR          "\r\3\0\0\0\0\0\0"
#define DEFAULT_CONTROL_CHAR_REJECT   "\0\1\0\0\0\0\0\0"  /* 0=0 otherwise=1 */
#define DEFAULT_POLL_LF_2Crlf             0      /*Default value for lf2crlf
						is false*/
#define DEFAULT_RX_TIMEOUT               1000000 /* Default value for the
						rxTimeout variable */

#define UART_OE		(1 << 3)	/* overrun error */
#define UART_BE		(1 << 2)	/* break error */
#define UART_PE		(1 << 1)	/* parity error */
#define UART_FE		(1 << 0)	/* framing error */

#define UARTFR_TXFE		(1 << 7)	/* Transmit FIFO empty */
#define UARTFR_RXFF 	(1 << 6)	/* Receive FIFO full */
#define UARTFR_TXFF 	(1 << 5)	/* Transmit FIFO full */
#define UARTFR_RXFE		(1 << 4)	/* Receive FIFO empty */
#define UARTFR_BUSY 	(1 << 3)	/* UART busy */

#define UARTCR_CTSEN	(1 << 15)	/* CTS hardware flow control enable */
#define UARTCR_RTSEN	(1 << 14)	/* RTS hardware flow control enable */
#define UARTCR_Out2		(1 << 13)	/* the complement of the UART Out2 (nUARTOut2) modem status output */
#define UARTCR_Out1		(1 << 12)	/* the complement of the UART Out1 (nUARTOut1) modem status output */
#define UARTCR_RTS		(1 << 11)	/* Request to send */
#define UARTCR_DTR		(1 << 10)	/* Data transmit ready */
#define UARTCR_RXE		(1 << 9)	/* Receive enable */
#define UARTCR_TXE		(1 << 8)	/* Transmit enable */
#define UARTCR_LBE		(1 << 7)	/* Loop back enable */
#define UARTCR_SIRLP	(1 << 2)	/* IrDA SIR low power mode */
#define UARTCR_SIREN	(1 << 1)	/* SIR enable */
#define UARTCR_UARTEN	(1 << 0)	/* UART enable */

#define UARTLCR_H_SPS		(1 << 7)	/* Stick parity select */
/* The select bits indicate the number of data bits transmitted or received in a frame */
#define UARTLCR_H_WLEN_8	(3 << 5)	/* 11 = 8 bits */
#define UARTLCR_H_WLEN_7	(2 << 5)	/* 10 = 7 bits */
#define UARTLCR_H_WLEN_6	(1 << 5)	/* 01 = 6 bits */
#define UARTLCR_H_WLEN_5	(0 << 5)	/* 00 = 5 bits */
#define UARTLCR_H_FEN		(1 << 4)	/* Enable FIFOs */
#define UARTLCR_H_STP2		(1 << 3)	/* Two stop bits select */
#define UARTLCR_H_EPS		(1 << 2)	/* Even parity select */
#define UARTLCR_H_PEN		(1 << 1)	/* Parity enable */
#define UARTLCR_H_BRK		(1 << 0)	/* Send break */

typedef struct t_uart_mem_map {
	uint32_t uartdr; 			/* 0x000 - Data register, UARTDR */
	uint32_t uartrsr_uartecr;	/* 0x004 - Receive status register/error clear register, UARTRSR/UARTECR */
	uint32_t reserved0;			/* 0x008-0x00c - reserved */
	uint32_t reserved1;			/* 0x00c-0x010 - reserved */
	uint32_t reserved2;			/* 0x010-0x014 - reserved */
	uint32_t reserved3;			/* 0x014-0x018 - reserved */
	uint32_t uartfr;			/* 0x018 - Flag register, UARTFR */
	uint32_t reserved4;			/* 0x01C - reserved */
	uint32_t uartilpr;			/* 0x020 - IrDA low-power counter register, UARTILPR */
	uint32_t uartibrd;			/* 0x024 - Integer baud rate register, UARTIBRD */
	uint32_t uartfbrd;			/* 0x028 - Fractional baud rate register, UARTFBRD */
	uint32_t uartlcr_h;			/* 0x02c - Line control register, UARTLCR_H */
	uint32_t uartcr;			/* 0x030 - Control register, UARTCR */
} t_uart_mem_map;

typedef struct t_uart {
	uint32_t system_clock_mhz; 	/* UART clock */
	t_uart_mem_map *regs;		/* UART regs */
	uint32_t baud_rate;			/* the same for RX and TX */
	int poll_mode;				/* poll mode or intr mode */
	int lf2crlf;				/* In poll mode convert [LF] to [CR LF] */
	int32_t rx_timeout;			/* Number of times the driver
		checks if a specific char was received before returning from
		Rx. If '-1' the driver will	check for chars an infinite
		number of times until all bytes are received */
	uint8_t                 numcc_entries;  /**< Number of entries in
						control char table.*/
	char                    p_control_char[NUM_CONTROL_CHARS+1];
	/**< Control Character table entry. Table contains up to 8 entries.
	Size of table is configured with UCC_UART_ConfigNumControlCharEntries()
	MSBs padded with zeros for characters smaller than 8 bits.
	[DEFAULT_controlChar0], [DEFAULT_controlChar1],
	[DEFAULT_controlChar2], [DEFAULT_controlChar3],
	[DEFAULT_controlChar4], [DEFAULT_controlChar5],
	[DEFAULT_controlChar6], [DEFAULT_controlChar7] */
	int                    p_control_char_reject[NUM_CONTROL_CHARS];
	/**< Whether to reject received character that matches this Control
	Character table entry. Table contains up to 8 entries. Size of table is
	configured with UCC_UART_ConfigNumControlCharEntries().
	1 to reject. Matching char can be read via
	UCC_UART_GetMatchedControlChar. Maskable interrupt is genereted.
	UCC_UART_UCCE_CCR. 0 to accept normally. [DEFAULT_controlCharReject0],
	[DEFAULT_controlCharReject1], [DEFAULT_controlCharReject2],
	[DEFAULT_controlCharReject3], [DEFAULT_controlCharReject4],
	[DEFAULT_controlCharReject5], [DEFAULT_controlCharReject6],
	[DEFAULT_controlCharReject7] */
} t_uart;

#endif /* __UART_H */
