/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "drivers/fsl_edma.h"
#include "edma.h"
#include "fsl_malloc.h"
#include "fsl_errors.h"
#include "fsl_endian.h"
#include "common/fsl_string.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "drivers/fsl_edma.h"
#include "fsl_sl_dbg.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_EDMA

//#define REG_LITTLE_ENDIAN
//#define STRUCT_BIG_ENDIAN



#define TIMEOUT_ATTEMPTS 1000000

static uint32_t get_command_queue_addr(uint32_t block_num, uint32_t queue);

static uint32_t get_status_queue_addr(uint32_t block_num, uint32_t queue);

static int edma_reg_init(struct  edma_priviledged_reg * priviledged_reg,
		struct edma_manage_reg *manage_reg);

static int block_reg_init(struct status_queue_reg* sq_regs,
		           struct global_queue_reg *cq_global_regs,
		           struct edma_block *p_block,
		           uint32_t block_id);


static int queue_reg_init(struct command_queue_reg *cq_regs,
		            const struct edma_queue *p_queue);

static  void cd_set_addr_low(struct edma_command_descriptor* cd,
		                     uint32_t address);

static uint32_t cd_get_addr_low(struct edma_command_descriptor* cd);

static void cd_set_ser_bit(struct edma_command_descriptor* cd,
        					uint32_t ser);

static void cd_set_format(struct edma_command_descriptor* cd,
        					uint32_t format);

static void cd_set_icid(struct edma_command_descriptor* cd,
		                uint16_t icid);

static void cd_set_IA_bit(struct edma_command_descriptor* cd,
						uint32_t IA);

static uint8_t cd_get_status(struct edma_command_descriptor* cd);

static void csgc_set_final_bit(struct edma_compound_sg_command* csgc,
		                           uint32_t value);


static void csgc_set_extension_bit(struct edma_compound_sg_command* csgc,
		                           uint32_t value);

static void csgc_set_length(struct edma_compound_sg_command* csgc,
		                     uint32_t address);

static void csgc_set_low_address(struct edma_compound_sg_command* csgc,
		                         uint32_t address);
static void csgc_set_high_address(struct edma_compound_sg_command* csgc,
		                         uint32_t address);

static void sdb_set_internal_address(
		                  struct edma_source_descr_buffer *sdf,
		                  uint32_t value);

static void sdb_set_BMT(struct edma_source_descr_buffer *sdf,
		                 uint32_t BMT);

static void sdb_set_PL(struct edma_source_descr_buffer *sdf,
		                 uint32_t PL);
static void sdb_set_VA(struct edma_source_descr_buffer *sdf,
		                 uint32_t VA);
static void sdb_set_sde(struct edma_source_descr_buffer *sdf,
		                 uint16_t sde);

static void ddb_set_internal_address(
		                  struct edma_destination_descr_buffer *ddf,
		                  uint32_t value);

static void ddb_set_PL(struct edma_destination_descr_buffer *ddf,
		                  uint32_t PL);

static void ddb_set_BMT(struct edma_destination_descr_buffer *ddf,
		                  uint32_t BMT);
static void ddb_set_VA(struct edma_destination_descr_buffer *ddf,
		                  uint32_t VA);
static void ddb_set_dde(struct edma_destination_descr_buffer *ddf,
		                  uint32_t dde);

static void set_transfer_param(struct edma_command_descriptor *cd,
		                       const  struct edma_transfer *params,
		                       uint32_t queue_id);

static void set_enable_queue(struct edma_queue* queue,uint32_t enable);

static void set_enable_sq(struct edma_block* block,uint32_t enable);

static  void set_DMR_DQD(struct  edma_priviledged_reg *priviled_reg,
		                       uint32_t value);
static  uint32_t get_DMR_DQD(struct  edma_priviledged_reg *priviled_reg);
static  uint32_t incr_command_desc(struct edma_command_descriptor** cd,
                       const struct edma_queue *queue);

static void process_transac_status(uint32_t cd_status,
		    enum transac_status *return_status);

static void print_CQ_SQ_registers(const struct edma_queue* queue);
static int check_and_clear_transaction_error(struct edma_block *block);
static int  check_and_clear_errors_DEDR(struct edma_queue* queue);



struct edma* edma_init (const struct edma_desc *desc)
{
	struct edma *p_edma = (struct edma*)fsl_malloc(sizeof(struct edma));
	if(NULL == p_edma)
		return NULL;
	p_edma->num_blocks = desc->num_blocks;
	p_edma->priviledged_reg = (struct  edma_priviledged_reg*)desc->vaddr;
	p_edma->manage_reg = PTR_MOVE(p_edma->priviledged_reg,
			              sizeof(struct  edma_priviledged_reg));
	if(0 != edma_reg_init(p_edma->priviledged_reg,p_edma->manage_reg))
		return NULL;
	return p_edma;
}

int edma_reg_init(struct  edma_priviledged_reg *priviledged_reg,
		          struct edma_manage_reg *manage_reg)
{
	uint32_t reg_value = ioread32(&priviledged_reg->DMR);
	reg_value |= (1 << 30); /* DMR[DQD] = 1 */
	reg_value |= (1 << 28); /* DMR[SO] = 1 */
	iowrite32(reg_value,&priviledged_reg->DMR);
	/* According to spec., should wait for wait until DSR[DB] = 0 (DMA idle)*/
	do{
		reg_value = ioread32(&priviledged_reg->DSR);
	}
	while(reg_value & (1 << 31)); //  wait until DSR[DB] = 0
	iowrite32(0xCF000000,&manage_reg->DEDR); /* Clear DEDR error */
	iowrite32(0,&manage_reg->DEIER); /* Disable interrupts on error*/
	/* Enable dequeue from the beginning (DMR[DQD] = 0) */
	reg_value = ioread32(&priviledged_reg->DMR);
	reg_value &= ~(0x1 << 30);
	iowrite32(reg_value,&priviledged_reg->DMR);
	return 0;
}

struct edma_block* edma_block_init (const struct edma_block_desc *desc,
			                        const struct edma_block_cfg *cfg)
{
	struct edma_block* p_edma_block = NULL;
	p_edma_block = (struct edma_block*)fsl_malloc(sizeof(struct edma_block));
	if(NULL == p_edma_block)
		return NULL;
	p_edma_block->sq_enabled = 0;
	p_edma_block->block_amq.icid = cfg->block_amq.icid;
	p_edma_block->block_amq.bmt = cfg->block_amq.bmt;
	p_edma_block->block_amq.pl = cfg->block_amq.pl;
	p_edma_block->block_amq.va = cfg->block_amq.va;
	p_edma_block->num_queues = desc->num_queues;
	p_edma_block->edma = cfg->edma;
	p_edma_block->num_entries_in_status_queue = cfg->num_entries_in_status_queue;
	p_edma_block->coalesc_intr_status_threshold =
			      cfg->coalesc_intr_status_threshold;
	p_edma_block->water_mark_threshold = cfg->water_mark_threshold;
	p_edma_block->comman_queue_reg = desc->vaddr;
	p_edma_block->status_queue_reg =
			      PTR_MOVE(desc->vaddr,STATUS_QUEUE_OFF);
	p_edma_block->global_queue_reg =
			PTR_MOVE(desc->vaddr,QUEUE_GLOBAL_REGS);
	// allocate internal status queue structure
	uint32_t alignment = p_edma_block->num_entries_in_status_queue*
		       sizeof(struct edma_command_descriptor);
	p_edma_block->sq_command_descr = (fsl_xmalloc
			      (p_edma_block->num_entries_in_status_queue*
			       sizeof(struct edma_command_descriptor),
			       cfg->mem_partition_id,alignment));
	if(NULL == p_edma_block->sq_command_descr)
		return NULL;
	memset(p_edma_block->sq_command_descr,
			0,
			p_edma_block->num_entries_in_status_queue*
			sizeof(struct edma_command_descriptor));
    if(0 != block_reg_init(p_edma_block->status_queue_reg,
			       p_edma_block->global_queue_reg,
			       p_edma_block,
			       desc->edma_block_id)){
	    return NULL;
    }
    /* Enable status queue that belongs to this block */
    set_enable_sq(p_edma_block,1/*enable*/);
    return p_edma_block;
}

static int block_reg_init(struct status_queue_reg* sq_regs,
		           struct global_queue_reg *cq_global_regs,
		           struct edma_block *p_block,
		           uint32_t block_id)
{
	uint32_t num_entries_in_sq_log_2 = 0, coalescing_intr_log_2 = 0;
	uint32_t reg_value = ioread32(&sq_regs->BmSQMR);
	uint64_t sq_address = 0;
	uint32_t sq_low_address = 0, sq_high_address = 0;
	reg_value &= ~(0x1 << 31); /* BmSQMR[EN] = 0 */
	LOG2((p_block->num_entries_in_status_queue>>6),num_entries_in_sq_log_2);
	reg_value &= ~(0xF<<16); /*  clear BmSQMR[SQ_SIZE] */
	reg_value |= num_entries_in_sq_log_2 << 16;
	reg_value &= ~(0x1 << 30);  /* BmSQMR[DI] = 0 */
	iowrite32(reg_value,&sq_regs->BmSQMR); /* set BmSQMR[SQ_SIZE] */
	/* 
	 * When descriptors put in external memory (64b address),
	 * the following line should be changed as there is truncation to 32 bit.
	 */
	sq_address = PTR_TO_UINT(&p_block->sq_command_descr[0]);

	sq_high_address = ((uint32_t)(sq_address >> 32)) & 0x1FFFF;
	// sq_low_address should be aligned to 16 bits
	sq_low_address = ((uint32_t)(sq_address))& 0xFFFFFFF0;
	iowrite32(sq_low_address,&sq_regs->BmSQEPAR);
	iowrite32(sq_low_address,&sq_regs->BmSQDPAR);

	iowrite32(sq_high_address,&sq_regs->BmSQEEPAR);
	iowrite32(sq_high_address,&sq_regs->BmSQEDPAR);
	reg_value = ioread32(&sq_regs->BmSQICR);
	if(p_block->coalesc_intr_status_threshold > 0)
		reg_value |= (0x1 << 31);/*BmSQICR[CEN] = 1 */
	else
		reg_value &= ~(0x1 << 31);/*BmSQICR[CEN] = 0 */
	reg_value &= ~(0xF << 16); /* clear BmSQICR[ICST] */
	if(0==p_block->coalesc_intr_status_threshold)
		coalescing_intr_log_2 = 0;
	else
	{
		LOG2(p_block->coalesc_intr_status_threshold,coalescing_intr_log_2);
		coalescing_intr_log_2++;
	}
	reg_value |= coalescing_intr_log_2 << 16;
	iowrite32(reg_value,&sq_regs->BmSQICR); /* Set BmSQICR[ICST] */
	if(block_id == 0)
	{/* privileged core configures CQBnAMQR for both cores */
	    reg_value = ioread32(&cq_global_regs->CQB0AMQR);
	    reg_value |= 0x08000000;/* set CQBnAMQR[IA] = 1 */
	    reg_value &= ~(0x1<<28);
	    reg_value |= (p_block->block_amq.pl&0x1) << 28; /*CQBnAMQR[PL] = 1*/
	    reg_value &= ~(0x1<<29);
	    reg_value |= (p_block->block_amq.bmt &0x1) << 29; /* CQBnAMQR[BMT] = 1 */
	    /* Setting CQBnAMQR[ICID] field */
	    reg_value &= ~(0x7FFF) ;
	    reg_value |= (p_block->block_amq.icid);
	    iowrite32(reg_value,&cq_global_regs->CQB0AMQR);
	    reg_value = ioread32(&cq_global_regs->CQB1AMQR);
	    reg_value |= 0x08000000;/* set CQBnAMQR[IA] = 1 */
	    reg_value &= ~(0x1<<28);
	    reg_value |= (p_block->block_amq.pl&0x1) << 28;/*CQBnAMQR[PL] = 1*/
	    reg_value &= ~(0x1<<29);
	    reg_value |= (p_block->block_amq.bmt &0x1) << 29;/* CQBnAMQR[BMT] = 1*/
	    /* Setting CQBnAMQR[ICID] field */
	    reg_value &= ~(0x7FFF) ;
	    reg_value |= (p_block->block_amq.icid);
	    iowrite32(reg_value,&cq_global_regs->CQB1AMQR);
	}
	return 0;
}

struct edma_queue* edma_queue_init(struct edma_block* block_handle,
                                   uint32_t block_id,
                                   uint32_t queue_id,
                                   struct edma_queue_cfg *cfg)
{
	struct edma_queue* p_edma_queue =
		   (struct edma_queue*)fsl_malloc(sizeof(struct edma_queue));
	uint32_t i = 0;
	uint32_t alignment =  0, _next_pow;
	if(NULL == p_edma_queue)
		return NULL;
	p_edma_queue->block = block_handle;
	p_edma_queue->block_id = block_id;
	p_edma_queue->queue_id = queue_id;
	p_edma_queue->queue_size = cfg->size_queue;
	p_edma_queue->command_queue_regs = &block_handle->comman_queue_reg[queue_id];
	/* allocate memory for command descriptor */
	alignment = p_edma_queue->queue_size*
			          sizeof(struct edma_command_descriptor);
	p_edma_queue->command_descriptors = (struct edma_command_descriptor*)
			(fsl_xmalloc(
			p_edma_queue->queue_size*sizeof(struct edma_command_descriptor),
			cfg->mem_partition_id,
			alignment));
	if(NULL == p_edma_queue->command_descriptors)
		return NULL;
	memset(p_edma_queue->command_descriptors,
		  0,
		  p_edma_queue->queue_size*sizeof(struct edma_command_descriptor));
	/* allocate and reset memory for compound commands */
	alignment = p_edma_queue->queue_size*sizeof(struct edma_compound_command);
	NEXT_POWER_OF_2(alignment, _next_pow);
	p_edma_queue->compound_commands = ( struct edma_compound_command *)
			    (fsl_xmalloc(
				p_edma_queue->queue_size*sizeof(struct edma_compound_command),
				cfg->mem_partition_id,
				_next_pow));
	if(NULL == p_edma_queue->compound_commands)
		return NULL;
	memset(p_edma_queue->compound_commands,
			  0,
			  p_edma_queue->queue_size*sizeof(struct edma_compound_command));
	/* allocate memory for descriptor buffer */
	alignment = p_edma_queue->queue_size*sizeof(struct edma_descriptor_buffers);
	p_edma_queue->descriptor_buffers = (struct edma_descriptor_buffers*)
			       (fsl_xmalloc(
					p_edma_queue->queue_size*sizeof(struct edma_descriptor_buffers),
					cfg->mem_partition_id,
					alignment));
	if(NULL == p_edma_queue->descriptor_buffers)
		return NULL;
	memset(p_edma_queue->descriptor_buffers,
			  0,
			  p_edma_queue->queue_size*sizeof(struct edma_descriptor_buffers));
	for(i = 0; i < p_edma_queue->queue_size; i++)
	{
		/*set CD[ADDR] field to point to the corresponding compound command */
		cd_set_addr_low(&p_edma_queue->command_descriptors[i],
				PTR_TO_UINT(&p_edma_queue->compound_commands[i]));
		/* set Descriptor Addr to point to Descriptor Buffers*/
		csgc_set_low_address(&(p_edma_queue->compound_commands[i].descr_command),
				     PTR_TO_UINT(&p_edma_queue->descriptor_buffers[i]));
		/*set CD[SER] = 1 */
		cd_set_ser_bit(&p_edma_queue->command_descriptors[i],
				       1);
		/* Set CD[FORMAT] = 0x1 */
		cd_set_format(&p_edma_queue->command_descriptors[i],1);

		csgc_set_extension_bit
		    (&(p_edma_queue->compound_commands[i].descr_command),
		    0);
		csgc_set_final_bit(
				    &(p_edma_queue->compound_commands[i].descr_command),
				    0);
		csgc_set_length(
				&(p_edma_queue->compound_commands[i].descr_command),
				32);
		csgc_set_extension_bit
				    (&(p_edma_queue->compound_commands[i].src_command),
				    0);
		csgc_set_final_bit(
				    &(p_edma_queue->compound_commands[i].src_command),
				     0);
		csgc_set_extension_bit
				    (&(p_edma_queue->compound_commands[i].dst_command),
					0);
		csgc_set_final_bit(
					&(p_edma_queue->compound_commands[i].dst_command),
					1);
	}
	block_handle->queues[queue_id] = p_edma_queue;
	p_edma_queue->next_available = NULL;
	p_edma_queue->first_pending = 0;
	p_edma_queue->enabled = 0;
	if(0 != queue_reg_init(p_edma_queue->command_queue_regs,p_edma_queue))
		return NULL;
	/* Enable queue from the beginning */
	set_enable_queue(p_edma_queue,1/*enable*/);
	return p_edma_queue;
}

static int queue_reg_init(struct command_queue_reg *cq_regs,
		            const struct edma_queue *p_queue)
{
	uint32_t num_entries_in_cq_log_2 = 0;
	uint32_t reg_value = 0;
	uint64_t addr = 0;
	uint32_t low_addr = 0, high_addr = 0;
	LOG2((p_queue->queue_size>>6),num_entries_in_cq_log_2);
	reg_value = ioread32(&cq_regs->BmCQnMR);
	reg_value &= ~(0x1 << 31); /*BmCQnMR[EN] = 0*/
	reg_value &= ~(0xF<<16); /*reset BmCQnMR[CQ_SIZE] */
	reg_value |= (num_entries_in_cq_log_2 << 16);
	reg_value &= ~(0x1 << 30); /*BmCQnMR[EI] = 0*/
	iowrite32(reg_value,&cq_regs->BmCQnMR);
	/* 
	 * When descriptors put in external memory (64b address),
	 * the following line should be changed as there is truncation to 32 bit.
	 */
	addr = PTR_TO_UINT(&p_queue->command_descriptors[0]);

	// low_addr is aligned to 16 bits
	low_addr = (uint32_t)addr & 0xFFFFFFF0;
	high_addr = ((uint32_t)(addr >> 32)) & 0x1FFFF;
	iowrite32(low_addr,&cq_regs->BmCQnDPAR); /* set BmCQnDPAR */
	iowrite32(low_addr,&cq_regs->BmCQnEPAR); /* set BmCQnEPAR */

	iowrite32(high_addr,&cq_regs->BmCQnEDPAR); /* set BmCQnEDPAR */
	iowrite32(high_addr,&cq_regs->BmCQnEEPAR); /* set BmCQnEEPAR */
	return 0;
}


int edma_queue_transfer(struct edma_queue *queue,
                        struct edma_transfer *params,
			    enum transac_status *return_status)
{

	/*setting transaction parameters*/
	struct edma_command_descriptor *cd = NULL;

	uint32_t  low_addr = 0, high_addr = 0;
	uint64_t addr = 0;

	uint32_t sq_last_enq_reg_low =
				ioread32(&queue->block->status_queue_reg->BmSQEPAR);
	uint32_t sq_last_enq_reg_high =
				ioread32(&queue->block->status_queue_reg->BmSQEEPAR)&0x1FFFF;
	uint32_t sq_curr_enq_reg_low,sq_curr_enq_reg_high;
	uint64_t sq_curr_enq_reg_full = 0;
	uint32_t time_out_counter = TIMEOUT_ATTEMPTS;

	struct edma_command_descriptor*  finished_cd = NULL;
	uint8_t cd_status = 0;

	pr_debug("edma_queue_transfer:block=%d,queue=%d,src_add=0x%x%08x,dst_addr=0x%x%08x,byte_count=0x%x,\n",
		queue->block_id,queue->queue_id,(uint32_t)(params->src>>32),(uint32_t)params->src,
		(uint32_t)(params->dst>>32),(uint32_t)params->dst,params->byte_count);

	if(NULL == queue->next_available)
	    cd = &queue->command_descriptors[0];
	else
	    cd =  queue->next_available;
	set_transfer_param(cd,
                           params,
                           queue->queue_id);

	/* set BmCQnEEPAR and BmCQnEPAR */
	incr_command_desc(&cd,queue);
	addr = PTR_TO_UINT(cd);

	low_addr = ((uint32_t)addr)&0xFFFFFFF0;
	high_addr = ((uint32_t)(addr >> 32)) & 0x1FFFF;

	iowrite32(high_addr,&queue->command_queue_regs->BmCQnEEPAR);
	iowrite32(low_addr,&queue->command_queue_regs->BmCQnEPAR);


	/* waiting for BmSQEPAR to change that indicates hw completes transaction */
	do
	{

		sq_curr_enq_reg_low =
				ioread32(&queue->block->status_queue_reg->BmSQEPAR);

		sq_curr_enq_reg_high = ioread32(&queue->block->status_queue_reg->BmSQEEPAR)&0x1FFFF;
		time_out_counter--;

	}while(sq_curr_enq_reg_low == sq_last_enq_reg_low &&
		sq_curr_enq_reg_high == sq_last_enq_reg_high && time_out_counter);

	if(!time_out_counter){
		pr_err("edma: Exit on timeout from polling on BmSQEPAR/BmSQEEPAR registers\n");
		print_CQ_SQ_registers(queue);
		check_and_clear_transaction_error(queue->block);
		cd_status = EDMA_DESCRIPTORS_ACCESS_ERROR;
	}
	else{
		sq_curr_enq_reg_full = MAKE_UINT64(sq_last_enq_reg_high,sq_last_enq_reg_low);
		/* 
		 * When descriptors put in external memory (64b address),
		 * the following line should be changed as there is truncation to 32 bit.
		 */
		finished_cd = UINT_TO_PTR(sq_curr_enq_reg_full);
		cd_status = cd_get_status(finished_cd);
	}
	process_transac_status(cd_status,return_status);
	if(*return_status != 0)
	{// Error case
	    pr_err("eDMA transcation: queue_id = %d, block_id = %d\n",
		      queue->queue_id,queue->block_id);
	    pr_err("src_addr=0x%x%08x,dst_addr=0x%x%08x,byte_count=0x%x,src_ia=%d,dst_ia=%d,src_icid =0x%x,dst_icid=0x%x\n",
	             (uint32_t)(params->src>>32),(uint32_t)params->src,
		     (uint32_t)(params->dst>>32),(uint32_t)params->dst,
		      params->byte_count,
		      (params->flags & EDMA_SRC_ADDR_IA) ? 1:0,
		      (params->flags & EDMA_DEST_ADDR_IA) ? 1:0,
		       params->src_icid,
		       params->dst_icid);
	    pr_err("completed with error status 0x%x\n",*return_status);
	}
	// mark this entry in SQ as handled by writing into BmSQ(E)DPAR
	iowrite32(sq_curr_enq_reg_high,&queue->block->status_queue_reg->BmSQEDPAR);
	iowrite32(sq_curr_enq_reg_low,&queue->block->status_queue_reg->BmSQDPAR);

	check_and_clear_transaction_error(queue->block);
	check_and_clear_errors_DEDR(queue);
	queue->next_available = cd;
	if(0 != *return_status)
		return -EIO;
	return  0;
}



int edma_free(struct edma* edma_handle)
{
	if(edma_handle)
		fsl_free(edma_handle);
	return 0;
}

int edma_block_free(struct edma_block* edma_block_handle)
{
	if(edma_block_handle)
	{
		if(edma_block_handle->sq_command_descr)
			fsl_xfree(edma_block_handle->sq_command_descr);
		edma_block_handle->sq_command_descr = NULL;
		fsl_free(edma_block_handle);
	}
	return 0;
}

int edma_queue_free(struct edma_queue* queue_handle)
{
	if(queue_handle)
	{
		if(queue_handle->command_descriptors)
		{
			fsl_xfree(UINT_TO_PTR(queue_handle->command_descriptors));
			queue_handle->command_descriptors = NULL;
		}
		if(queue_handle->compound_commands)
		{
			fsl_xfree(UINT_TO_PTR(queue_handle->compound_commands));
			queue_handle->compound_commands = NULL;
		}
		if(queue_handle->descriptor_buffers)
		{
			fsl_xfree(UINT_TO_PTR(queue_handle->descriptor_buffers));
			queue_handle->descriptor_buffers = NULL;
		}
#if 0
		if(queue_handle->cb_functions)
		{
			fsl_xfree(UINT_TO_PTR(queue_handle->cb_functions));
			queue_handle->cb_functions = NULL;
		}
		if(queue_handle->cb_args)
		{
			fsl_xfree(UINT_TO_PTR(queue_handle->cb_args));
			queue_handle->cb_args = NULL;
		}
#endif
		fsl_free(queue_handle);
	}
	return 0;
}

static uint32_t get_command_queue_addr(uint32_t block_num, uint32_t queue)
{
	return COMMAND_QUEUE0_OFF + (block_num*BLOCK_REGS_SIZE) +
		  (queue*QUEUE_REGS_SIZE);
}

static uint32_t get_status_queue_addr(uint32_t block_num, uint32_t queue)
{
	return STATUS_QUEUE_OFF + (block_num*BLOCK_REGS_SIZE) +
		  (queue*QUEUE_REGS_SIZE);
}

static void cd_set_addr_low(struct edma_command_descriptor* cd,
                             uint32_t value)
{
	iowrite32be(value,&cd->desc2);

}

static uint32_t cd_get_addr_low(struct edma_command_descriptor* cd)
{
	return ioread32be(&cd->desc2);
}


static void cd_set_ser_bit(struct edma_command_descriptor* cd,
        					uint32_t ser)
{
	uint32_t desc4 = ioread32be(&cd->desc4);
	if(ser)
		desc4 |= (1 << 30);
	else
		/* reset ser bit */
		desc4  &= ~(1 << 30);
	iowrite32be(desc4,&cd->desc4);
}

static void cd_set_icid(struct edma_command_descriptor* cd,
		                uint16_t icid)
{
	uint32_t desc4 = ioread32be(&cd->desc4);
	desc4 &= ~(0x7FFF << 8);
	desc4 |= ((icid & 0x7FFF) << 8);
	iowrite32be(desc4,&cd->desc4);
}

static void cd_set_format(struct edma_command_descriptor* cd,
        					uint32_t format)
{
	uint32_t desc3 = ioread32be(&cd->desc3);
	desc3 &= ~(0x7 << 29);
	desc3 |= (format &0x7) << 29;
	iowrite32be(desc3,&cd->desc3);
}

void cd_set_IA_bit(struct edma_command_descriptor* cd,
						uint32_t IA)
{
	uint32_t desc4 = ioread32be(&cd->desc4);
	if(IA)
		desc4 |= (1 << 24);
	else
		desc4 &= ~(1 << 24); /* reset CD[IA] */
	iowrite32be(desc4,&cd->desc4);
}

static void cd_set_queue(struct edma_command_descriptor* cd,
        					uint32_t queue_id)
{
	uint32_t desc1 = ioread32be(&cd->desc1);
	desc1 &=  ~(0x7 << 24);
	desc1 |= ((queue_id&0x7) << 24);
	iowrite32be(desc1,&cd->desc1);
}

static uint8_t cd_get_status(struct edma_command_descriptor* cd)
{
	uint32_t desc4 = ioread32be(&cd->desc4);
	return (uint8_t)(desc4 & 0xFF);

}

static void csgc_set_extension_bit(struct edma_compound_sg_command* csgc,
		                           uint32_t value)
{
	uint32_t desc3 = ioread32be(&csgc->desc3);
	if(value){
		desc3 |= 1 << 31;
	}
	else
		desc3  &= ~(1 << 31);
	iowrite32be(desc3,&csgc->desc3);
}

static void csgc_set_final_bit(struct edma_compound_sg_command* csgc,
		                           uint32_t value)
{
	uint32_t desc3 = ioread32be(&csgc->desc3);
	if(value){
		desc3 |= (1 << 30);
	}
	else
		desc3 &= ~( 1 << 30);
	iowrite32be(desc3,&csgc->desc3);

}

static void csgc_set_length(struct edma_compound_sg_command* csgc,
		                     uint32_t address)
{
	uint32_t desc3 = ioread32be(&csgc->desc3);
	// reset length field
	desc3 &= (0xC0000000);
	// set address
	desc3 |=  ((address) & 0x3FFFFFFF);
	iowrite32be(desc3,&csgc->desc3);

}

static void csgc_set_low_address(struct edma_compound_sg_command* csgc,
		                         uint32_t address)
{
	iowrite32be(address,&csgc->desc2);
}

static uint32_t csgc_get_low_address(struct edma_compound_sg_command* csgc)
{
	return ioread32be(&csgc->desc2);
}

static void csgc_set_high_address(struct edma_compound_sg_command* csgc,
		                         uint32_t address)
{
	uint32_t desc1 = ioread32be(&csgc->desc1);
	desc1 &= ~(0x1FFFF);
	desc1 |= (address &(0x1FFFF));
	iowrite32be(desc1,&csgc->desc1);
}

/*
 * Source Descriptor Buffer
 */
static void sdb_set_internal_address(
		                  struct edma_source_descr_buffer *sdf,
		                  uint32_t value)
{
	uint32_t desc4 = ioread32be(&sdf->desc4);
	if(value){
		desc4 |= (0x1) << 28;
	}
	else
		desc4 &= ~(1 << 28);
	iowrite32be(desc4,&sdf->desc4);
}

static void sdb_set_icid(struct edma_source_descr_buffer *sdf,
		                 uint16_t icid)
{
	uint32_t desc4 = ioread32be(&sdf->desc4);
	desc4 &= ~(0x7FFF );
	desc4 |=  icid & 0x7FFF;
	iowrite32be(desc4,&sdf->desc4);
}

static void sdb_set_PL(struct edma_source_descr_buffer *sdf,
		                 uint32_t PL)
{
	uint32_t desc4 = ioread32be(&sdf->desc4);
	if(PL){
		desc4 |= (0x1) << 29;
	}
	else
		desc4 &= ~(1 << 29);
	iowrite32be(desc4,&sdf->desc4);
}

static void sdb_set_BMT(struct edma_source_descr_buffer *sdf,
		                 uint32_t BMT)
{
	uint32_t desc4 = ioread32be(&sdf->desc4);
	if(BMT){
		desc4 |= (0x1) << 30;
	}
	else
		desc4 &= ~(1 << 30);
	iowrite32be(desc4,&sdf->desc4);
}

static void sdb_set_VA(struct edma_source_descr_buffer *sdf,
		                 uint32_t VA)
{
	uint32_t desc4 = ioread32be(&sdf->desc4);
	if(VA){
		desc4 |= (0x1) << 31;
	}
	else
		desc4 &= ~(1 << 31);
	iowrite32be(desc4,&sdf->desc4);
}

static void sdb_set_sde(struct edma_source_descr_buffer *sdf,
		                 uint16_t sde)
{
	uint32_t desc1 = ioread32be(&sdf->desc1);
	if(sde){
		desc1 |= (0x1) << 30;
	}
	else
		desc1 &= ~(1 << 30);
	iowrite32be(desc1,&sdf->desc1);
}
/*
 * Destination Descriptor Buffer
 */
static void ddb_set_internal_address(
		                  struct edma_destination_descr_buffer *ddf,
		                  uint32_t value)
{
	uint32_t desc4 = ioread32be(&ddf->desc4);
	if(value){
		desc4 |= (0x1) << 28;
	}
	else
		desc4 &= ~(1 << 28);
	iowrite32be(desc4,&ddf->desc4);
}

static void ddb_set_PL(struct edma_destination_descr_buffer *ddf,
		                  uint32_t PL)
{
	uint32_t desc4 = ioread32be(&ddf->desc4);
	if(PL){
		desc4 |= (0x1) << 29;
	}
	else
		desc4 &= ~(1 << 29);
	iowrite32be(desc4,&ddf->desc4);
}


static void ddb_set_BMT(struct edma_destination_descr_buffer *ddf,
		                  uint32_t BMT)
{

	uint32_t desc4 = ioread32be(&ddf->desc4);
	if(BMT){
		desc4 |= (0x1) << 30;
	}
	else
		desc4 &= ~(1 << 30);
	iowrite32be(desc4,&ddf->desc4);
}

static void ddb_set_VA(struct edma_destination_descr_buffer *ddf,
		                  uint32_t VA)
{
	uint32_t desc4 = ioread32be(&ddf->desc4);
	if(VA){
		desc4 |= (0x1) << 31;
	}
	else
		desc4 &= ~(1 << 31);
	iowrite32be(desc4,&ddf->desc4);
}

static void ddb_set_dde(struct edma_destination_descr_buffer *ddf,
		                  uint32_t dde)
{
	uint32_t desc1 = ioread32be(&ddf->desc1);
	if(dde){
		desc1 |= (0x1) << 30;
	}
	else
		desc1 &= ~(1 << 30);
	iowrite32be(desc1,&ddf->desc1);
}

static void ddb_set_icid(struct edma_destination_descr_buffer *ddf,
		                 uint16_t icid)
{
	uint32_t desc4 = ioread32be(&ddf->desc4);
	desc4 &= ~(0x7FFF );
	desc4 |= icid & 0x7FFF;
	iowrite32be(desc4,&ddf->desc4);
}


static void set_transfer_param(struct edma_command_descriptor *cd,
		                  const  struct edma_transfer *params,
		                   uint32_t queue_id)
{
	struct edma_compound_command* cc = UINT_TO_PTR(cd_get_addr_low(cd));
	struct edma_descriptor_buffers* desc_buffs = NULL;
	struct edma_source_descr_buffer *src_desc_buffer = NULL;
	struct edma_destination_descr_buffer *dst_desc_buffer = NULL;
	desc_buffs = UINT_TO_PTR(csgc_get_low_address(&cc->descr_command));
	src_desc_buffer = &desc_buffs->src_descr_buff;
	dst_desc_buffer  = &desc_buffs->dest_descr_buffer;
	uint32_t src_low_address = (uint32_t)(params->src & 0xFFFFFFFFLL);
	uint32_t src_high_address = (uint32_t)((params->src >> 32) & 0x1FFFFLL);
	uint32_t dst_low_address = (uint32_t)(params->dst & 0xFFFFFFFFLL);
	uint32_t dst_high_address = (uint32_t)((params->dst >> 32) & 0x1FFFFLL);

	cd_set_queue(cd,queue_id);
	csgc_set_length(&cc->src_command,params->byte_count);
	csgc_set_length(&cc->dst_command,params->byte_count);
	csgc_set_low_address(&cc->src_command,src_low_address);
	csgc_set_high_address(&cc->src_command,src_high_address);
	csgc_set_low_address(&cc->dst_command,dst_low_address);
	csgc_set_high_address(&cc->dst_command,dst_high_address);
	/* set IA,PL,BMT bits for source descriptor buffer */
	sdb_set_internal_address(src_desc_buffer,
			                params->flags & EDMA_SRC_ADDR_IA);
	sdb_set_icid(src_desc_buffer,
			    params->src_icid);

	sdb_set_PL(src_desc_buffer,params->flags & EDMA_SRC_ADDR_PL);
	sdb_set_BMT(src_desc_buffer,params->flags & EDMA_SRC_ADDR_BMT);
	sdb_set_VA(src_desc_buffer,params->flags & EDMA_SRC_ADDR_VA);

	sdb_set_sde(src_desc_buffer,1);
	/* set IA,BMT,PL bits for destination descriptor buffer */
	ddb_set_internal_address(dst_desc_buffer,
			               params->flags & EDMA_DEST_ADDR_IA);
	ddb_set_icid(dst_desc_buffer,
			params->dst_icid);
	ddb_set_PL(dst_desc_buffer,params->flags & EDMA_DEST_ADDR_PL );
	ddb_set_BMT(dst_desc_buffer, params->flags & EDMA_DEST_ADDR_BMT);
	ddb_set_VA(dst_desc_buffer, params->flags & EDMA_DEST_ADDR_VA);
	ddb_set_dde(dst_desc_buffer,1);

}

static void set_enable_queue(struct edma_queue* queue,uint32_t enable)
{
	struct command_queue_reg *cq_regs = queue->command_queue_regs;
	uint32_t reg_value = 0;
	reg_value = ioread32(&cq_regs->BmCQnMR);
	if(enable)
		reg_value |= (0x1 << 31);
	else
		reg_value &= ~(0x1 << 31);
	iowrite32(reg_value,&cq_regs->BmCQnMR);
	queue->enabled = enable;
}

static void set_enable_sq(struct edma_block* block,uint32_t enable)
{
	struct status_queue_reg *sq_reg = block->status_queue_reg;
	uint32_t reg_value = 0;
	reg_value = ioread32(&sq_reg->BmSQMR);
	if(enable)
		reg_value |= (0x1 << 31);
	else
		reg_value &= ~(0x1 << 31);
	iowrite32(reg_value,&sq_reg->BmSQMR);
	block->sq_enabled = enable;
}

static  void set_DMR_DQD(struct  edma_priviledged_reg *priviled_reg,
		                       uint32_t value)
{
	uint32_t reg_value = ioread32(&priviled_reg->DMR);
	reg_value &= ~(0x1 << 30);
	reg_value |= (value&0x1) << 30;
	iowrite32(reg_value,&priviled_reg->DMR);

}

static  uint32_t get_DMR_DQD(struct  edma_priviledged_reg *priviled_reg)
{
	uint32_t reg_value = ioread32(&priviled_reg->DMR);
	reg_value &= (0x1 << 30);
	return reg_value >>= 30;
}

static  uint32_t incr_command_desc(struct edma_command_descriptor** cd,
		                                  const struct edma_queue *queue)
{
	if(++(*cd) >= &queue->command_descriptors[queue->queue_size])
	{
		*cd = &queue->command_descriptors[0];
		return 1;
	}
	return 0;
}

static void process_transac_status(uint32_t cd_status,
		    enum transac_status *return_status)
{
    *return_status = (enum transac_status)cd_status;
}

static int check_and_clear_transaction_error(struct edma_block *block)
{
    uint32_t reg_value = ioread32(&block->global_queue_reg->CQEDR);
    if(reg_value & 0x80000001){
	pr_debug("edma: CQEDR = 0x%x\n",reg_value);
	reg_value = ioread32(&block->global_queue_reg->CQECEAR);
        pr_debug("edma: CQECEAR = 0x%x\n",reg_value);
	reg_value = ioread32(&block->global_queue_reg->CQECAR);
	pr_debug("edma: CQECAR = 0x%x\n",reg_value);
        // clear transaction error
	reg_value |= 0x80000001;
	iowrite32(reg_value,&block->global_queue_reg->CQEDR);
	return -EIO;
    }
    return 0;
}

static void print_CQ_SQ_registers(const struct edma_queue* queue)
{
    uint32_t reg_value = 0;
    reg_value = ioread32(&queue->block->status_queue_reg->BmSQEPAR);
    pr_debug("edma: BmSQEPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->block->status_queue_reg->BmSQEEPAR);
    pr_debug("edma: BmSQEEPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->block->status_queue_reg->BmSQDPAR);
    pr_debug("edma: BmSQDPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->block->status_queue_reg->BmSQEDPAR);
    pr_debug("edma: BmSQEDPAR = 0x%x\n",reg_value);

    reg_value = ioread32(&queue->command_queue_regs->BmCQnEDPAR);
    pr_debug("edma: BmCQnEDPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->command_queue_regs->BmCQnDPAR);
    pr_debug("edma: BmCQnDPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->command_queue_regs->BmCQnEEPAR);
    pr_debug("edma: BmCQnEEPAR = 0x%x\n",reg_value);
    reg_value = ioread32(&queue->command_queue_regs->BmCQnEPAR);
    pr_debug("edma: BmCQnEPAR = 0x%x\n",reg_value);
}

static int  check_and_clear_errors_DEDR(struct edma_queue* queue)
{
    uint32_t DEDR_value = ioread32(&queue->block->edma->manage_reg->DEDR);
    uint32_t DECBR_value = ioread32(&queue->block->edma->manage_reg->DECBR);
    if(DEDR_value & 0xBF000000){
        pr_debug("edma: DEDR = 0x%x\n",DEDR_value);
        pr_debug("edma: DECBR = 0x%x\n",DECBR_value);
        iowrite32(0xBF000000,&queue->block->edma->manage_reg->DEDR);
        return -EIO;
    }
    return 0;
}

