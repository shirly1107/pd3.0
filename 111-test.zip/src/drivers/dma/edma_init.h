/*
 * Copyright 2013-2020 NXP
 */

#ifndef _EDMA_INIT_API
#define _EDMA_INIT_API

#include "drivers/fsl_edma.h" 


/*
 * Removes the queues that belong to block_id
 */
int remove_edma_queues(uint32_t block_id);

/*
 * Removes block_id
 */
int remove_edma_blocks(uint32_t block_id);

int remove_edma();

struct edma *add_edma(); 
struct edma_block *add_edma_block( uint32_t block_id,
		                      struct edma_block_cfg *block_cfg);

int add_edma_queue(uint32_t block_id,
		      uint32_t queue_id, 
		      struct edma_queue_cfg *queue_cfg);



#endif
