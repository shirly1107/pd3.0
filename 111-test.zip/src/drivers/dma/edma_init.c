/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_sys.h"
#include "edma_init.h"
#include "fsl_platform.h"
#include "soc_db.h"
#include <cstring> // for memset




int remove_edma_queues(uint32_t block_id)
{	
	struct edma_block_desc block_description;
	memset(&block_description,0,sizeof(struct edma_block_desc));
	struct edma_queue* queue_hdl = NULL;
	int rc = 0, block_index = (int)block_id;	
	block_description.edma_block_id = block_id;
	rc = sys_get_desc(SOC_MODULE_EDMA_BLOCK,SOC_DB_EDMA_BLOCK_DESC_ID, 
                      &block_description,NULL);
	if(0 != rc )
	{
		pr_warn("Cannot retrieve description for block %d\n", block_index);
		return 0; /* not a failure */
	}
	for(int i = 0 ; i < block_description.num_queues;i++)
	{
		queue_hdl = sys_get_handle(FSL_MOD_EDMA_BLOCK_QUEUE,3,0,block_index,i);
		if(NULL != queue_hdl){
			edma_queue_free(queue_hdl);
			rc  = sys_remove_handle(FSL_MOD_EDMA_BLOCK_QUEUE,3,0,block_index,i);
			if(rc){
				pr_warn("Cannot remove queue handle: block=%d,queue=%d\n"
					, block_index,i);
			}
		}
	}
	return 0;
}

int remove_edma_blocks(uint32_t block_id)
{		
	struct edma_block *block_hdl = sys_get_handle(FSL_MOD_EDMA_BLOCK,2,0,block_id);
	if(NULL != block_hdl)
	{
		edma_block_free(block_hdl);
		sys_remove_handle(FSL_MOD_EDMA_BLOCK,2,0,block_id);
	}	
	return 0;
}

int remove_edma()
{
	struct edma *edma_hnl = sys_get_unique_handle(FSL_MOD_EDMA);
	if(NULL != edma_hnl){
		edma_free(edma_hnl);
		sys_remove_handle(FSL_MOD_EDMA,1,0);	
	}
	return 0;
}

struct edma *add_edma()
{
	int edma_num = 0, rc ;
	struct edma_desc edma_description; 
	struct edma *edma_handle = NULL;
	
	// initialize edma ( in ls2100_a there is only one)
	memset(&edma_description,0,sizeof(edma_description));

	/* assuming there is only a single eDMA  */
	rc = sys_get_desc(SOC_MODULE_EDMA,SOC_DB_EDMA_DESC_ID, &edma_description, 
					  &edma_num);
	if(rc !=  0)
	{
		pr_warn("Couldn't retrieve edma description from SoC DB\n");
		return NULL;
	}
	/* initialize edma block */
	edma_handle = edma_init(&edma_description);
	if(!edma_handle)
	{// couldn't initialize edma
		pr_warn("Couldn't initialize edma\n");
		return NULL;
	}
	pr_debug("edma:edma_init successfully finished\n");
	// add edma handle to the system
	rc = sys_add_handle(edma_handle,FSL_MOD_EDMA,1,0);
	if(0 != rc)
	{
		pr_warn("Couldn't add  edma handle  to system\n");
		return NULL;
	}			
	return edma_handle;
}

struct edma_block *add_edma_block( uint32_t block_id,
		                      struct edma_block_cfg *block_cfg)
{
	int  rc;
	struct edma_block_desc edma_block_description;
	struct edma_block *edma_block_handle = NULL;	
	memset(&edma_block_description,0,sizeof(edma_block_description));
	edma_block_description.edma_block_id = block_id;
	rc = sys_get_desc(SOC_MODULE_EDMA_BLOCK,SOC_DB_EDMA_BLOCK_DESC_ID,
					 &edma_block_description, NULL);
	
	if(rc != 0)
	{
		pr_warn("Couldn't retrieve edma block description from SoC DB\n");
		return NULL;
	}
	
	edma_block_handle = edma_block_init(&edma_block_description,block_cfg);
	if(!edma_block_handle)
	{// couldn't initialize edma_block
		pr_warn("Couldn't initialize edma block %d\n",block_id);
		return NULL;		
	}
	pr_debug("edma:edma_block_init block_id=%d successfully finished\n",block_id);
	// add edma handle to the system
	rc = sys_add_handle(edma_block_handle,FSL_MOD_EDMA_BLOCK,2,0,block_id);
	if(rc != 0)
	{
		pr_warn("Couldn't add edma block to system\n");
		return NULL;
	}
	return edma_block_handle;
}

int add_edma_queue( uint32_t block_id,
		      uint32_t queue_id, 
		      struct edma_queue_cfg *queue_cfg)
{
	struct edma_block *edma_block_handle = NULL;
	struct edma_queue *queue_hndl = NULL;
	edma_block_handle = (struct edma_block *)sys_get_handle
					  (FSL_MOD_EDMA_BLOCK,2,0,block_id);
	if(NULL == edma_block_handle){
		pr_warn("Couldn't retreive edma block %d from the system\n",
				 block_id);
		return -ENAVAIL;	
	}		
	queue_hndl = edma_queue_init(edma_block_handle,block_id,queue_id,queue_cfg);
	if(queue_hndl == NULL)
	{
		pr_warn("Couldn't create edma queue num %d for edma block %d\n",
				0,block_id);
		return -ENAVAIL;	
	}
	pr_debug("edma:edma_queue_init block_id=%d , queue_id=%d successfully finished\n",block_id,queue_id);
	return sys_add_handle(queue_hndl,FSL_MOD_EDMA_BLOCK_QUEUE,3,0,block_id,queue_id);
}








