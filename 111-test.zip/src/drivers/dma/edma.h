/*
 * Copyright 2013-2020 NXP
 */

#ifndef _EDMA_H
#define _EDMA_H

#include "fsl_dpmng_mc.h"

/**************************************************************************//**
 @Description A structure that defines eDMA privileged registers programming 
 model.
*//***************************************************************************/
struct edma_priviledged_reg
{
	uint32_t DMR;
	uint32_t DSR;
	uint32_t reserved_1[22];
	uint32_t DEEPR;
	uint32_t reserved_2[999];
};

/**************************************************************************//**
 @Description A structure that defines eDMA manage registers programming model.
*//***************************************************************************/
struct edma_manage_reg
{
	uint32_t reserved_1[766];
	uint32_t IPBRR0;
	uint32_t IPBRR1;
	uint32_t reserved_2[128];
	uint32_t DEIER;
	uint32_t DEDR;
	uint32_t reserved_3[2];
	uint32_t DECCDW0R;
	uint32_t DECCDW1R;
	uint32_t DECCDW2R;
	uint32_t DECCDW3R;
	uint32_t reserved_4[4];
	uint32_t DECCQIDR;
	uint32_t DECBR;
	uint32_t reserved_5[114];
};


/**************************************************************************//**
 @Description eDMA handle structure
*//***************************************************************************/
struct edma
{
    struct  edma_priviledged_reg *priviledged_reg; /**< Points to privileged 
                                                    registers */
    struct edma_manage_reg *manage_reg; /**< Points to  manage registers */
    uint32_t num_blocks;/** < Number of eDMA blocks */
    struct edma_block *edma_blocks_arr; /** <Array of blocks information. */
 };

#define NUM_ENTRIES_IN_SQ 128 /* NUmber of entries in status queue */
#define NUM_ENTRIES_IN_CQ 128 /* NUmber of entries in command queue */
#define MAX_QUEUE_NUM 32 /* Maximal queue number per block */
#define SQ_WATER_MARK 32 /* Status queue water mark value(congesting condition*/


/**************************************************************************//**
 @Description A command queue group registers
*//***************************************************************************/
struct command_queue_reg
{
     uint32_t reserved_1[48];
     uint32_t BmCQnMR; /* Block m Command Queue n Mode Registers*/
     uint32_t BmCQnSR; /* Block m Command Queue n Status Registers*/
     uint32_t BmCQnEDPAR; /* Extended dequeue pointer address register */
     uint32_t BmCQnDPAR; /* Dequeue pointer address register */
     uint32_t BmCQnEEPAR; /* Extended enqueue pointer address register */
     uint32_t BmCQnEPAR; /* Enqueue pointer address register */
     uint32_t reserved_2[2];     
     uint32_t BmCQIER; /* Command queue interrupt enable registers */    
     uint32_t B0CQIDR; /* Command queue interrupt detect registers */
     uint32_t reserved_3[6]; 
};


/**************************************************************************//**
 @Description Status queue registers
*//***************************************************************************/
struct status_queue_reg
{
	 uint32_t BmSQMR; /* Block m Status Queue Mode Registers */
	 uint32_t BmSQSR; /* Block m status queue status register */
	 uint32_t BmSQEDPAR; /* Status queue extended dequeue pointer 
	                       address register */
	 uint32_t BmSQDPAR; /* Status queue enqueue pointer address register */
	 uint32_t BmSQEEPAR;
	 uint32_t BmSQEPAR;
	 uint32_t reserved[4];
	 uint32_t BmSQICR; /* Status queue interrupt coalescing register */
};


/**************************************************************************//**
 @Description Global queue registers
*//***************************************************************************/
struct global_queue_reg
{
	
	 uint32_t CQMR; /*Command queue mode register*/
	 uint32_t RESERVED_0; 
	 uint32_t CQDSCR1; /*Command queue dequeue scheduler configuration 
	                    register 1*/
	 uint32_t CQDSCR2; /* Command queue dequeue scheduler configuration 
	                    register 2 */
	 uint32_t CQIER; /*Command queue interrupt enable register */
	 uint32_t CQEDR; /*Command queue error detect register */
	 uint32_t CQECEAR; /*Command Queue Error Capture Extended Address Register */
	 uint32_t CQECAR; /*Command queue error capture address register */
	 uint32_t SQCCMR; /* Status queue critical congestion management register */
	 uint32_t RESERVED_2[23];
	 /*Command Queue Block n Access Management Qualifier Register */
	 uint32_t CQB0AMQR; 
	 /*Command Queue Block 0 Access Management Qualifier Register */
	 uint32_t CQB1AMQR; /*Command queue block 2 isolation context ID register */
	 /*Command Queue Block 1 Access Management Qualifier Register */
};

/**************************************************************************//**
 @Description eDMA  Command descriptor. Used in Command queue.
 *//***************************************************************************/ 
struct edma_command_descriptor
{
	uint32_t desc1;
	uint32_t desc2;
	uint32_t desc3;
	uint32_t desc4;
}; 

/**************************************************************************//**
 @Description eDMA  Compound scatter-gather command descriptor.                 
 *//***************************************************************************/
struct edma_compound_sg_command
{
	uint32_t desc1;
	uint32_t desc2;
	uint32_t desc3;
	uint32_t desc4;
};

#define EDMA_CSGC_SET_ADDR_LOW(csgc, value)	\
		((struct edma_compound_sg_command*)csgc)->desc3 = value;


/**************************************************************************//**
 @Description eDMA  Compound command descriptor. Consists of three 
              edma_compound_sg_command                 
 *//***************************************************************************/
struct edma_compound_command
{
	struct edma_compound_sg_command descr_command;
	struct edma_compound_sg_command src_command;
	struct edma_compound_sg_command dst_command;
};
struct edma_source_descr_buffer
{
	uint32_t desc1;
	uint32_t desc2;
	uint32_t desc3;
	uint32_t desc4;
};

struct edma_destination_descr_buffer
{
	uint32_t desc1;
	uint32_t desc2;
	uint32_t desc3;
	uint32_t desc4;
};

struct edma_descriptor_buffers
{
	struct edma_source_descr_buffer src_descr_buff;
	struct edma_destination_descr_buffer dest_descr_buffer;	
};


/**************************************************************************//**
 @Description queue handle structure
*//***************************************************************************/
struct edma_queue
{
    struct edma_block *block; /**< Pointer to  block handle */
    uint32_t block_id; /**< block_id that this queue belongs to, values 0,1*/
    uint32_t queue_id; /**< queue_id, values 0-7*/
    uint32_t queue_size; /** number of entries in this queue */
    struct command_queue_reg *command_queue_regs; /**< Points to command queue  
                                     registers for  this queue. */
    struct edma_command_descriptor* command_descriptors; /**< address that points 
                             to the beginning of command descriptors array.*/
    struct edma_compound_command *compound_commands; /**< address that points 
                            to the beginning of compound descriptors array. */
    struct edma_descriptor_buffers* descriptor_buffers; /**< address that points
                               to the beginning of descriptor buffer array. */
    uintptr_t cb_functions; /**< address that points to the beginning of 
                           callback functions array. */
    uintptr_t cb_args; /**< address that points to the beginning of arguments 
                       array for callback functions */
    struct edma_command_descriptor* next_available; /**<points to the next 
                                                 available command descriptor*/
    uintptr_t first_pending; /**< points to the first CD that is waiting 
                             to be completed*/
    uint32_t enabled;
};


/**************************************************************************//**
 @Description eDMA block handle
*//***************************************************************************/
struct edma_block
{
    struct edma* edma; /**<Pointer to edma handle (parent) */
    struct command_queue_reg *comman_queue_reg; /**< Points to command queue 0 
                                                  registers for this block. */
    uint32_t num_queues; /**< queues number per block, for ls2100 it is 8*/
    uint32_t coalesc_intr_status_threshold;/**< Coalescing interrupt status 
                                           threshold for this block. 
                                           0 means no interrupts*/
    uint32_t water_mark_threshold; /**< Water mark for Status queue
                                        Congestion Management */
    struct status_queue_reg *status_queue_reg; /**< Points to status queue 
                                               registers for this block. */
    struct global_queue_reg *global_queue_reg; /**< Points to global queue 
                                                 registers for this block. */
    uint32_t num_entries_in_status_queue; /**< Number of entries in status 
                                           queue.*/ 
    struct edma_command_descriptor* sq_command_descr; /**< Data structure that 
                                      sw maintains for status queue entries. */
    struct edma_queue* queues[MAX_QUEUE_NUM]; /**< Array of pointers to queues 
                                    that belong to this block. queues[i] = null 
                                      means, no queue defined for this index */
    uint32_t sq_enabled;
    struct dpmng_amq    block_amq; /** Access Management Qualifiers to access eDMA 
                                    descriptors */ 
};



/**************************************************************************//**
  @Description  Privileged registers memory offsets
*//***************************************************************************/ 

static const uint32_t COMMAND_QUEUE0_OFF = 0x000;
static const uint32_t STATUS_QUEUE_OFF = 0x800;
static const uint32_t QUEUE_GLOBAL_REGS = 0xA00;

/**************************************************************************//**
 @Description  eDMA Block registers group size in bytes.
*//***************************************************************************/ 
static const uint32_t BLOCK_REGS_SIZE = 0x10000; 

/**************************************************************************//**
 @Description eDMA Command Queue registers group size in bytes.
 *//***************************************************************************/ 
static const uint32_t QUEUE_REGS_SIZE = 0x100;










#endif

