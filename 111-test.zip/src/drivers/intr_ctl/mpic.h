/*
 * Copyright 2013-2020 NXP
 */


#ifndef __MPIC_H_
#define __MPIC_H_

#include "fsl_types.h"
#include "fsl_mpic.h"
#include "ls2085_mc_mpic.h"


		
/* Definitions for MPIC groups */
#define MPIC_NUM_OF_INTR_GROUPS         6

#define NUM_OF_TIMERS_PER_GROUP         4
#define NUM_OF_MSG_INTR_PER_GROUP       8
#define NUM_OF_LOW_MSG_INTR_PER_GROUP   (NUM_OF_MSG_INTR_PER_GROUP/2)
#define NUM_OF_MSI_INTR_PER_GROUP       16
#define NUM_OF_LOW_MSI_INTR_PER_GROUP   (NUM_OF_MSI_INTR_PER_GROUP/2)         

#define MPIC_INTR_COUNT_BY_GROUP \
{                                \
    MPIC_NUM_OF_INT_INTRS,       \
    MPIC_NUM_OF_EXT_INTRS,       \
    MPIC_NUM_OF_TIMERS,          \
    MPIC_NUM_OF_MSG_INTRS,       \
    MPIC_NUM_OF_SMSG_INTRS,      \
    MPIC_NUM_OF_IPI_EVENTS       \
}

/**************************************************************************//**
 @Description   The total number of MPIC interrupt sources
*//***************************************************************************/
#define MPIC_NUM_OF_INTR_SOURCES     (MPIC_NUM_OF_INT_INTRS    + \
                                     MPIC_NUM_OF_EXT_INTRS    + \
                                     MPIC_NUM_OF_TIMERS       + \
                                     MPIC_NUM_OF_MSG_INTRS    + \
                                     MPIC_NUM_OF_SMSG_INTRS   + \
                                     MPIC_NUM_OF_IPI_EVENTS)

/**************************************************************************//**
 @Description   MPIC ored error vector
*//***************************************************************************/
#define MPIC_ORED_ERROR_VECTOR   ((uint16_t)(g_mc_mpic_handle->intr_group_base_idx[MPIC_INTR_GROUP_INTERNAL] + MPIC_ORED_ERROR_INTR_IDX))    

/**************************************************************************//**
 @Description   MPIC Configuration Parameters
*//***************************************************************************/
typedef struct mpic_config_params
{
    /* System integration parameters */
    uint8_t         guest_id;        /**< Driver ID in guest mode;
                                         Use NCSW_MASTER_ID in master mode */
} mpic_config_params_t;

/**************************************************************************//**
 @Description   Interrupt vector mapping.
*//***************************************************************************/
typedef struct mpic_intr_vector_entry
{
    uint32_t            intr_id;     /**< MPIC interrupt ID */
    uint16_t            vector;     /**< Assigned vector - must be lower than
                                         #MPIC_NUM_OF_INTR_SOURCES */
} mpic_intr_vector_entry_t;

/*****************************************************************************/
typedef struct mpic_multi_src_entry
{
    uint16_t    index;              /**< Index in internal interrupts registers group */
    uint8_t     num_of_sources;       /**< Number of sources for this shared interrupt */
} mpic_multi_src_entry_t;

/*****************************************************************************/
typedef struct
{
    mpic_isr_entry_t        isr_table[MPIC_NUM_OF_INTR_SOURCES + MPIC_MULTI_SRC_INTERNAL_INTERRUPTS_COUNT +1];    
                                        /**< Interrupt handlers table */
    uint16_t                intr_group_base_idx[MPIC_NUM_OF_INTR_GROUPS];
                                        /**< Base indices of all interrupt groups */
    uint16_t                intr_count_by_group[MPIC_NUM_OF_INTR_GROUPS];
                                        /**< Interrupt count for all interrupt groups */
    uint8_t                 guest_id;   /**< Master/guest ID for multi-partition systems */
    uint8_t                 initialized;/**< Successful initialization flag */
}mpic_t;

/**************************************************************************//**
 @Function      mpic_config 

 @Description   General initialization of the MPIC interrupt controller.

                The MPIC driver assigns default configuration (priority,
                attributes, etc.) to all interrupt sources. the user may
                override this configuration using the osMpicConfigInterruptSources()
                and osMpicConfigInterruptVectors() advanced configuration routines.

                MPIC configuration and any (optional) advanced configuration
                routines must be followed by a call to osMpicInit() to take effect
                in the MPIC hardware block.

 @Param[in]     mpic_params - Pointer to configuration parameters structure.
 @Param[in]     mpic_handle - Pointer to Mpic configuration structure.

 @Return        status
*//***************************************************************************/
int mpic_config(mpic_config_params_t *mpic_params,mpic_t **mpic_handle );

#if OS_STRIPPED_CODE
/* untested function for future support */
/**************************************************************************//**
 @Function      osMpicConfigInterruptVectors 
 
 @Description   Non-default configuration of interrupt vector assignment.

                Interrupt vector is the number retrieved from the interrupt
                acknowledgment cycle (when processor reads the IACK register).
                This number serves as the index in the ISR table, therefore
                in a specific system re-arranging the interrupt vectors may
                improve caching.

 @Param[in]     num_of_intr_entries - Number of interrupt vector entries.
 @Param[in]     intr_vector_entries - Pointer to interrupt vector entries.

 @Return        OS_SUCCESS on success; Error code otherwise.
*//***************************************************************************/
os_status osMpicConfigInterruptVectors(uint16_t                     num_of_intr_entries,
                                       mpic_intr_vector_entry_t  *intr_vector_entries);

/**************************************************************************//**
 @Function      osMpicConfigInterruptSources 

 @Description   Non-default configuration of interrupt source attributes.

 @Param[in]     mpic_handle               - Handle to MPIC object.
 @Param[in]     num_of_intr_entries       - Number of interrupt parameter entries.
 @Param[in]     intr_params               - Pointer to interrupt parameter entries.

 @Return        OS_SUCCESS on success; Error code otherwise.
*//***************************************************************************/
os_status osMpicConfigInterruptSources(mpic_t               *mpic_handle,
                                       uint16_t                num_of_intr_entries,
                                       os_mpic_intr_params_t   *intr_params);
#endif //OS_STRIPPED_CODE
/**************************************************************************//**
 @Function      mpic_init 

 @Description   Unmasks a specific interrupt source to enable interrupts to
                this source.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int mpic_init();
/**************************************************************************//**
 @Function      mpic_clear_pending_core_interrupts 

 @Description   Clear pending interrupts for calling core
*//***************************************************************************/
void mpic_clear_pending_core_interrupts();
/****************************************************************************/
void     mpic_get_intr_config_regs(    uint16_t  grp,
                                     uint16_t  idx,
                                     uint32_t  **vpr,
                                     uint32_t  **dr,
                                     uint32_t  **lr);

#if 0
/**************************************************************************//**
 @Function      osMpicGetMsiIndexReg

 @Description   This function finds the register use to invoke an interrupt for
                a given message signal interrupt ID.

 @Param[in]     msi_id    - message signaled ID (valid values: 0-MPIC_NUM_OF_SMSG_INTRS).
 @Param[in]     p_msiir1  - pointer to the msiir1 register.
 @Param[in]     msir_num  - message signaled ID within the group.
 
 @Return        OS_SUCCESS on success; Error code otherwise.
*//***************************************************************************/
os_status osMpicGetMsiIndexReg(uint32_t mpic_intr_id, uint32_t **p_msiir1 ,uint8_t *msir_num);
/********************************************************************************/
os_status osMpicGetMsiCoalescingReg(uint32_t msi_id, uint32_t **p_msicr);
#endif // 0

/*****************************************************************************/
void mpic_set_interrupt_mask(uint16_t grp, uint16_t idx, uint8_t intr_enable);

/*****************************************************************************/
/* ISRs */
void mpic_unassigned_isr(mpic_arg arg);
void mpic_error_isr(mpic_arg arg);
void mpic_multi_source_isr(mpic_arg arg);


/**************************************************************************/
/* Definitions for building mpic_intr_id codes */
#define MPIC_INTR_GRP_MASK           0x00F00000
#define MPIC_MULTI_SRC_IDX_MASK      0x000FF000
#define MPIC_INTR_IDX_MASK           0x00000FFF
#define MPIC_INTR_GRP_SHIFT          20
#define MPIC_MULTI_SRC_IDX_SHIFT     12

#define MPIC_INTR_GRP(intr_id) \
    (uint16_t)(((intr_id) & MPIC_INTR_GRP_MASK) >> MPIC_INTR_GRP_SHIFT)

#define MPIC_MULTI_SRC_IDX(intr_id) \
    (uint16_t)(((intr_id) & MPIC_MULTI_SRC_IDX_MASK) >> MPIC_MULTI_SRC_IDX_SHIFT)

#define MPIC_INTR_IDX(intr_id) \
    (uint16_t)((intr_id) & MPIC_INTR_IDX_MASK)

#define MPIC_INTR_REG_MASK           (MPIC_INTR_GRP_MASK | MPIC_INTR_IDX_MASK)

#define IS_INTR_PAIR_SHARED(intr_id1, intr_id2) \
    (((intr_id1) & MPIC_INTR_REG_MASK) == ((intr_id2) & MPIC_INTR_REG_MASK))

#define OS_MPIC_GUEST_ID 1
#define OS_MPIC_MASTER_ID 8
/*****************************************************************************/
/* Definitions for multi-source interrupt handling */
#define MPIC_MAKE_MULTI_SRC_HANDLE(offset, count) \
    (mpic_arg)(((offset) << 16) | ((count) << 8))

#define MPIC_MULTI_SRC_OFFSET(handle)       (uint16_t)(((uint32_t)(handle) & 0xFFFF0000) >> 16)
#define MPIC_MULTI_SRC_COUNT(handle)        (uint8_t)(((uint32_t)(handle) & 0x0000FF00) >> 8)
#define MPIC_MULTI_SRC_EN_COUNT(handle)     (uint8_t)( (uint32_t)(handle) & 0x000000FF)

#define MPIC_MULTI_SRC_INCREMENT(handle) \
    (handle) = (mpic_arg)((uint32_t)(handle) + 1)
#define MPIC_MULTI_SRC_DECREMENT(handle) \
    (handle) = (mpic_arg)((uint32_t)(handle) - 1)

#define MPIC_ISR(isr)                       (mpic_isr)(((uint32_t)(isr) & ~(0x3)))
#define MPIC_ISR_EN                          0x1
#define MPIC_ISR_ENABLED(isr)               ((uint32_t)(isr) & MPIC_ISR_EN)

#define MPIC_ISR_ENABLE(isr)                                    \
    do {                                                        \
        (isr) = (mpic_isr)((uint32_t)(isr) | MPIC_ISR_EN);      \
    } while (0)

#define MPIC_ISR_DISABLE(isr)                                   \
    do {                                                        \
        (isr) = (mpic_isr)((uint32_t)(isr) & ~(MPIC_ISR_EN));   \
    } while (0)


/*****************************************************************************/
/* Other definitions */
#define MPIC_ORED_ERROR_INTR_IDX     0

#define MPIC_ALL_PROCESSORS_MASK     ((1 << sys_get_max_num_of_cores()) - 1)

#define MPIC_HIGHEST_INTR_PRIORITY   15

#define MPIC_UNASSIGNED_VECTOR       ((uint16_t)0xFFFF)

#define MPIC_VECTOR_MASK_SIZE \
    ((MPIC_NUM_OF_INTR_SOURCES + 31) / 32)

#define MPIC_IS_VECTOR_ASSIGNED(mask_array, vector) \
    (mask_array[(vector) / 32] & (0x80000000 >> ((vector) & 0x1F)))

#define MPIC_SET_VECTOR_MASK(mask_array, vector) \
    mask_array[(vector) / 32] |= (0x80000000 >> ((vector) & 0x1F))
/*****************************************************************************/
/* MPIC MSI definitions */
#define MPIC_SET_MSIIR_MASK(msir_num, signal) \
    GET_UINT32( ((msir_num & 0xF )<< 24) | ((signal & 0xF) << 28) |((signal & 0x10) << 12))


/******************************************************************************/
/* MPIC registers */

/* Interrupt Vector/Priority Registers */
#define VPR_MSK                 0x80000000
#define VPR_A                   0x40000000
#define VPR_P                   0x00800000
#define VPR_S                   0x00400000
#define VPR_PRIORITY_MASK       0x000F0000
#define VPR_VECTOR_MASK         0x0000FFFF
#define VPR_PRIORITY_SHIFT      16

/* Interrupt Destination Registers */
#define DR_EP                   0x80000000
#define DR_CI0                  0x40000000
#define DR_P0                   0x00000001
#define DR_P1                   0x00000002
#define DR_P2                   0x00000004
#define DR_P3                   0x00000008
#define DR_P4                   0x00000010
#define DR_P5                   0x00000020
#define DR_P6                   0x00000040
#define DR_P7                   0x00000080
#define DR_P8                   0x00000100
#define DR_P9                   0x00000200
#define DR_P10                  0x00000400
#define DR_P11                  0x00000800
#define DR_P12                  0x00001000
#define DR_P13                  0x00002000
#define DR_ALL_CORES_MASK       (uint32_t)((1ULL << sys_get_max_num_of_cores()) - 1)

/* Interrupt Level Registers */
#define LR_INTTGT_INT           0x00000000
#define LR_INTTGT_CINT          0x00000001
#define LR_INTTGT_MCP           0x00000002
#define LR_INTTGT_SIE0          0x000000F0
#define LR_INTTGT_SIE1          0x000000F1
#define LR_INTTGT_SIE2          0x000000F2
#define LR_INTTGT_IRQ_OUT       0x000000FF

/* Current Task Priority Register */
#define CTPR_DEF                0x00000000
#define CTPR_MASK               0x0000000F

/* Feature Reporting Register */
#define FRR_NIRQ_MASK           0x07FF0000
#define FRR_NCPU_MASK           0x00001F00
#define FRR_VID_MASK            0x000000FF
#define FRR_NIRQ_SHIFT          16
#define FRR_NCPU_SHIFT          8
#define FRR_EXPECTED_NIRQ       MPIC_MAX_NUM_OF_INTR_SRC

/* Global Configuration Register */
#define GCR_RST                 0x80000000
#define GCR_PROXY_MODE          0x60000000
#define GCR_MIXED_MODE          0x20000000

/* Processor Initialization Register */
#define PIR_RST                 0x00000001
    
/* Message Enable Register */
#define MER_INIT_MASK           0x000000FF

/* Error Interrupt Summary Register */
#define EISR_EVENT_MASK         0x80000000
#define EIMR_ALL_EVENTS_MASK    0xFFFFFFFF

/* EOI */
#define EOI_CODE                0x00000000

#endif // __MPIC_H_
