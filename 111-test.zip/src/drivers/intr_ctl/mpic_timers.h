/*
 * Copyright 2013-2020 NXP
 */

#ifndef __MPIC_TIMERS_H_
#define __MPIC_TIMERS_H_

#include "fsl_types.h"

#define MAX_TMR_VALUE 0x0fffffff
#define MIN_TMR_VALUE 0x00000010

#define TICKS_TO_USECS(ticks)   (uint64_t)(((ticks) * 1000000ULL)/(mpic_timer_clk))
#define USECS_TO_TICKS(usecs)   (uint64_t)(((mpic_timer_clk)*(usecs)) / 1000000ULL)

/* calculate the minimum period allowed for MPIC global timers */
#define MIN_PERIOD              MAX(TICKS_TO_USECS(MIN_TMR_VALUE), 1)

/* calculate the maximum period allowed for MPIC global timers */
#define MAX_PERIOD              TICKS_TO_USECS(MAX_TMR_VALUE)

/*****************************************************************************/
enum mpic_gt_clk_src {
	mpic = 0b0,
	rtc  = 0b1
};

/*****************************************************************************/
enum mpic_gt_clk_ratio {
	div_8  = 0b00,
	div_16 = 0b01,
	div_32 = 0b10,
	div_64 = 0b11
};

/*****************************************************************************/
enum mpic_gt_dest {
	dest_core_0    = 0b01,
	dest_core_1    = 0b10,
};

/*****************************************************************************/
struct mpic_gt_init_params {
	enum mpic_gt_clk_src   clk_src;
	enum mpic_gt_clk_ratio clk_ratio;
};

/*****************************************************************************/
struct mpic_gt_config_params {
	uint8_t  priority;
	enum mpic_gt_dest destination;
	uint64_t base_count_us;
	void (*user_exp_cb)(void * h_app, uint8_t id);
};

/**************************************************************************//**
 @Function      mpic_gt_init

 @Description   Initialize the mpic timers module.
*//***************************************************************************/
void* mpic_gt_init(const struct mpic_gt_init_params* const params);

/**************************************************************************//**
 @Function      mpic_gt_get_freq

 @Description   Returns the timer clock frequency in Hz.
*//***************************************************************************/
uint32_t mpic_gt_get_freq();

/**************************************************************************//**
 @Function      mpic_timer_start

 @Description   Configure and start the timer.
*//***************************************************************************/
int mpic_timer_start(uint8_t id,
            void (*f_expired_callback) (void* h_app, uint8_t id),
            void* h_app, uint64_t period_us);

/**************************************************************************//**
 @Function      mpic_timer_stop

 @Description   Stop the timer.
*//***************************************************************************/
int mpic_timer_stop(uint8_t id);

/**************************************************************************//**
 @Function      mpic_timer_set_time

 @Description   Set time period for the timer.
*//***************************************************************************/
int mpic_timer_set_time(uint8_t id, uint64_t period_us);

/**************************************************************************//**
 @Function      mpic_timer_get_time

 @Description   Returns the time in uSec timer is running since last expiration.
*//***************************************************************************/
int mpic_timer_get_time(uint8_t id, uint64_t *p_time_us);

#endif // __MPIC_TIMERS_H_


