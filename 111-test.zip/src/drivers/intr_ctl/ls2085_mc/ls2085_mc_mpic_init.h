/*
 * Copyright 2013-2020 NXP
 */


#ifndef ___LS2085_MC_MPIC_INIT_H
#define ___LS2085_MC_MPIC_INIT_H

#include "mpic.h" 
#include "fsl_core.h"

#define mpic_get_core_id() (core_get_id())
#define mpic_get_master_core()   (0) //TODO check

extern mpic_t *g_mc_mpic_handle;

int mpic_initialize(void * mpic_register_base);
void mpic_clear_pending_core_events();

#endif // ___LS2085_MC_MPIC_INIT_H

