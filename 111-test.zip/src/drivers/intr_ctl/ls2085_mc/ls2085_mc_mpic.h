/*
 * Copyright 2013-2020 NXP
 */


#ifndef ___LS2085_MC_MPIC_H
#define ___LS2085_MC_MPIC_H

/**************************************************************************//**
 @Group        os_mpic_id   MPIC Module API

 @Description   MPIC Module API.
 
 @{
*//***************************************************************************/

/**************************************************************************//**
 @Group         mpic_ls2085_id MPIC LS2085 Initialization API

 @Description   B486x Initialization API.
 
 @{
*//***************************************************************************/

/******************************************************************************
 MPIC INTEGRATION-SPECIFIC DEFINITIONS
******************************************************************************/

/**************************************************************************//**
 @Description   MPIC interrupt groups

                This enum is not directly used in the MPIC API, but represents
                the internal enumeration of interrupt groups and thus needed
                for the definition of MPIC interrupt IDs (see mpic_intr_id).
*//***************************************************************************/
typedef enum os_mpic_intr_groups
{
    MPIC_INTR_GROUP_INTERNAL = 0,      /**< Internal interrupts group */
    MPIC_INTR_GROUP_EXTERNAL,          /**< External interrupts group */
    MPIC_INTR_GROUP_TIMERS,            /**< Timers interrupts group */
    MPIC_INTR_GROUP_MSG,               /**< Massage interrupts group */
    MPIC_INTR_GROUP_SHARED_MSG,        /**< MSI interrupts group */
    MPIC_INTR_GROUP_IPI                /**< IPI interrupts group */
} mpic_intr_groups_t;

#define NUM_OF_MPIC_IPI_CORES 2
/**< The amount of mpic IPI supported cores */
												
#define MPIC_NUM_OF_EXT_INTRS        12		/**< The amount of External interrupts */
#define MPIC_NUM_OF_INT_INTRS        128    /**< The amount of internal interrupts */
#define MPIC_NUM_OF_TIMERS           8      /**< The amount of Timers interrupts */
#define MPIC_NUM_OF_MSG_INTRS        16     /**< The amount of Massage interrupts */
#define MPIC_NUM_OF_SMSG_INTRS       64     /**< The amount of MSI interrupts */
#define MPIC_NUM_OF_IPI_EVENTS       4      /**< The amount of IPI interrupts */
#define MPIC_NUM_OF_LOW_INT_INTRS    160	/**< The amount of low internal interrupts */

#define MPIC_MAX_NUM_OF_INTR_SRC \
    (MPIC_NUM_OF_EXT_INTRS +     \
     MPIC_NUM_OF_INT_INTRS +     \
     MPIC_NUM_OF_TIMERS +        \
     MPIC_NUM_OF_MSG_INTRS +     \
     MPIC_NUM_OF_SMSG_INTRS +    \
     (MPIC_NUM_OF_IPI_EVENTS * (NUM_OF_MPIC_IPI_CORES)))
/**< Maximum number of interrupt source, IPI events
   takes into account all chip's core, both PowerPC and StarCore */

#define MPIC_MULTI_SRC_INTERNAL_INTERRUPTS   \
    {                                        \
        /* index    , sources */             \
        {  0        , 0        }             \
    }
/**< number of interrupt source per interrupt index */

#define MPIC_MULTI_SRC_INTERNAL_INTERRUPTS_COUNT 0
/**< number of multi-source interrupts */

#define MPIC_INTR(type, idx, mult_src_idx) \
    (((uint32_t)MPIC_INTR_GROUP_##type << 20) | ((mult_src_idx) << 12) | (idx))
/**< interrupt id [group | multi-source index | interrupt index] */

#define MPIC_INTR_TO_IDX(__mpic_intr_id) (__mpic_intr_id & 0xfff)
/**< returns the interrupt id in the group from the interrupt general id */

/**************************************************************************//**
 @Description   Enumeration of MPIC interrupts
*//***************************************************************************/
typedef enum mc_mpic_intr_id
{
    /* Internal interrupts */
    /* OR-ed interrupt 0 errors are provided in opposed order due to
       mapping order in EISR0/EIMR0 registers.
       The mapping in these registers is:
           bit 0 for source 31,
           bit 0 for source 30 etc.
       Thus, here we configure source 0 as source 31, so it will go to
       the correct bit in EISR0/EIMR0. */
    MC_MPIC_INTR_CPM_1_HP         = MPIC_INTR(INTERNAL     , 0   , 0   ),      /**< Command Portal 1 - 256 High Priority (CPM 1 HPSPR valid) */
    MC_MPIC_INTR_CPM_2_HP         = MPIC_INTR(INTERNAL     , 1   , 0   ),      /**< Command Portal 257- 512 High Priority (CPM 2 HPSPR valid) */
    MC_MPIC_INTR_NUM_2            = MPIC_INTR(INTERNAL     , 2   , 0   ),      /**< Reserved */
    MC_MPIC_INTR_NUM_3            = MPIC_INTR(INTERNAL     , 3   , 0   ),      /**< Reserved */
    MC_MPIC_INTR_CPM_1_LP         = MPIC_INTR(INTERNAL     , 4   , 0   ),      /**< Command Portal 1 - 256 Low Priority (CPM 1 LPSPR valid) */
    MC_MPIC_INTR_CPM_2_LP         = MPIC_INTR(INTERNAL     , 5   , 0   ),      /**< Command Portal 257- 512 Low Priority (CPM 2 LPSPR valid) */
    MC_MPIC_INTR_NUM_6            = MPIC_INTR(INTERNAL     , 6   , 0   ),      /**< Reserved */
    MC_MPIC_INTR_NUM_7            = MPIC_INTR(INTERNAL     , 7   , 0   ),      /**< Reserved */
    MC_MPIC_INTR_EPU_1            = MPIC_INTR(INTERNAL     , 8   , 0   ),      /**< SoC Event Processing Unit (EPU) 0 (precaution for debug or may be used for SIEs) */
    MC_MPIC_INTR_EPU_2            = MPIC_INTR(INTERNAL     , 9   , 0   ),      /**< SoC Event Processing Unit (EPU) 1 (precaution for debug or may be used for SIEs) */
    MC_MPIC_INTR_EPU_3            = MPIC_INTR(INTERNAL     , 10  , 0   ),      /**< SoC Event Processing Unit (EPU) 2 (precaution for debug or may be used for SIEs) */
    MC_MPIC_INTR_EPU_4            = MPIC_INTR(INTERNAL     , 11  , 0   ),      /**< SoC Event Processing Unit (EPU) 3 (precaution for debug or may be used for SIEs) */
    MC_MPIC_INTR_MDIO_1_GLT       = MPIC_INTR(INTERNAL     , 12  , 0   ),      /**< MDIO 1GLT */
    MC_MPIC_INTR_MDIO_10_GLT      = MPIC_INTR(INTERNAL     , 13  , 0   ),      /**< MDIO MDIO 10GLT */
    MC_MPIC_INTR_MDIO_40_GLT      = MPIC_INTR(INTERNAL     , 14  , 0   ),      /**< MDIO MDIO 40GLT */
    MC_MPIC_INTR_MDIO_100_GLT     = MPIC_INTR(INTERNAL     , 15  , 0   ),      /**< MDIO MDIO 100GLT */
    OS_MPIC_INTR_DUART            = MPIC_INTR(INTERNAL     , 16  , 0   ),      /**< DUART (for debug) */
    OS_MPIC_INTR_NUM_17           = MPIC_INTR(INTERNAL     , 17  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_18           = MPIC_INTR(INTERNAL     , 18  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_19           = MPIC_INTR(INTERNAL     , 19  , 0   ),      /**< Reserved */
    MC_MPIC_INTR_PEBM_REC_ERR     = MPIC_INTR(INTERNAL     , 20  , 0   ),      /**< PEBM recoverable error */
    MC_MPIC_INTR_SDRAM_REC_ERR    = MPIC_INTR(INTERNAL     , 21  , 0   ),      /**< LDPAA DDR-SDRAM controller recoverable error */
    OS_MPIC_INTR_NUM_22           = MPIC_INTR(INTERNAL     , 22  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_23           = MPIC_INTR(INTERNAL     , 23  , 0   ),      /**< Reserved */
    MC_MPIC_INTR_NUM_24           = MPIC_INTR(INTERNAL     , 24  , 0   ),      /**< Reserved */
    MC_MPIC_INTR_NUM_25           = MPIC_INTR(INTERNAL     , 25  , 0   ),      /**< Reserved */
    MC_MPIC_INTR_NUM_26           = MPIC_INTR(INTERNAL     , 26  , 0   ),      /**< Reserved */
    MC_MPIC_INTR_SEC_CAT_ERR      = MPIC_INTR(INTERNAL     , 27  , 0   ),      /**< SEC catastrophic error */
    MC_MPIC_INTR_SEC_REC_ERR      = MPIC_INTR(INTERNAL     , 28  , 0   ),      /**< SEC recoverable error */
    MC_MPIC_INTR_SEC_GEN          = MPIC_INTR(INTERNAL     , 29  , 0   ),      /**< SEC general */
    MC_MPIC_INTR_SEC_JOB_1        = MPIC_INTR(INTERNAL     , 30  , 0   ),      /**< SEC job queue 1 */
    MC_MPIC_INTR_SEC_JOB_2        = MPIC_INTR(INTERNAL     , 31  , 0   ),      /**< SEC job queue 2 */
    MC_MPIC_INTR_SEC_JOB_3        = MPIC_INTR(INTERNAL     , 32  , 0   ),      /**< SEC job queue 3 */
    MC_MPIC_INTR_SEC_JOB_4        = MPIC_INTR(INTERNAL     , 33  , 0   ),      /**< SEC job queue 4 */
    
    /* DPIO */
    MC_MPIC_INTR_QBMAN_1          = MPIC_INTR(INTERNAL     , 34  , 0   ),      /**< QBMAN 1 - QBMAN portal interrupt vector bit[1] */
    MC_MPIC_INTR_QBMAN_2          = MPIC_INTR(INTERNAL     , 35  , 0   ),      /**< QBMAN 2 - QBMAN portal interrupt vector bit[2] */
    MC_MPIC_INTR_QBMAN_3          = MPIC_INTR(INTERNAL     , 36  , 0   ),      /**< QBMAN 3 - QBMAN portal interrupt vector bit[3] */
    MC_MPIC_INTR_QBMAN_4          = MPIC_INTR(INTERNAL     , 37  , 0   ),      /**< QBMAN 4 - QBMAN portal interrupt vector bit[4] */
    MC_MPIC_INTR_QBMAN_CAT_ERR    = MPIC_INTR(INTERNAL     , 38  , 0   ),      /**< QBMAN catastrophic error */
    MC_MPIC_INTR_QBMAN_REC_ERR    = MPIC_INTR(INTERNAL     , 39  , 0   ),      /**< QBMAN recoverable error */
    MC_MPIC_INTR_PME_CAT_ERR      = MPIC_INTR(INTERNAL     , 40  , 0   ),      /**< PME catastrophic error */
    MC_MPIC_INTR_PME_REC_ERR      = MPIC_INTR(INTERNAL     , 41  , 0   ),      /**< PME recoverable error */
    MC_MPIC_INTR_DCE_CAT_ERR      = MPIC_INTR(INTERNAL     , 42  , 0   ),      /**< DCE catastrophic error */
    MC_MPIC_INTR_DCE_REC_ERR      = MPIC_INTR(INTERNAL     , 43  , 0   ),      /**< DCE recoverable error */
    MC_MPIC_INTR_NUM_44           = MPIC_INTR(INTERNAL     , 44  , 0   ),      /**< Reserved */
    MC_MPIC_INTR_QDMA_REC_ERR     = MPIC_INTR(INTERNAL     , 45  , 0   ),      /**< QDMA recoverable  error */
    MC_MPIC_INTR_NUM_46           = MPIC_INTR(INTERNAL     , 46  , 0   ),      /**< Reserved */
    MC_MPIC_INTR_NUM_47           = MPIC_INTR(INTERNAL     , 47  , 0   ),      /**< Reserved */
    MC_MPIC_INTR_NUM_48           = MPIC_INTR(INTERNAL     , 48  , 0   ),      /**< Reserved */
    MC_MPIC_INTR_NUM_49           = MPIC_INTR(INTERNAL     , 49  , 0   ),      /**< Reserved */
    MC_MPIC_INTR_RMAN_CAT_ERR     = MPIC_INTR(INTERNAL     , 50  , 0   ),      /**< RMAN catastrophic error */
    MC_MPIC_INTR_RMAN_REC_ERR     = MPIC_INTR(INTERNAL     , 51  , 0   ),      /**< RMAN recoverable error */
    MC_MPIC_INTR_RMAN_RT          = MPIC_INTR(INTERNAL     , 52  , 0   ),      /**< RMAN run-time */
    MC_MPIC_INTR_XMAN_CAT_ERR     = MPIC_INTR(INTERNAL     , 53  , 0   ),      /**< XMAN catastrophic error */
    MC_MPIC_INTR_XMAN_RET_ERR     = MPIC_INTR(INTERNAL     , 54  , 0   ),      /**< XMAN recoverable error */
    MC_MPIC_INTR_XMAN_RT          = MPIC_INTR(INTERNAL     , 55  , 0   ),      /**< XMAN run-time */
    MC_MPIC_INTR_WRIOP_1_CAT_ERR  = MPIC_INTR(INTERNAL     , 56  , 0   ),      /**< WRIOP 1 catastrophic error */
    MC_MPIC_INTR_WRIOP_1_REC_ERR  = MPIC_INTR(INTERNAL     , 57  , 0   ),      /**< WRIOP 1 recoverable error */
    MC_MPIC_INTR_WRIOP_1_RT       = MPIC_INTR(INTERNAL     , 58  , 0   ),      /**< WRIOP 1 run-time */
    MC_MPIC_INTR_AIOP_1_CAT_ERR   = MPIC_INTR(INTERNAL     , 59  , 0   ),      /**< AIOP 1 catastrophic error */
    MC_MPIC_INTR_AIOP_1_REC_ERR   = MPIC_INTR(INTERNAL     , 60  , 0   ),      /**< AIOP 1 recoverable error */
    OS_MPIC_INTR_NUM_61           = MPIC_INTR(INTERNAL     , 61  , 0   ),      /**< Reserved - AIOP 1 run-time */
    MC_MPIC_INTR_WRIOP_2_CAT_ERR  = MPIC_INTR(INTERNAL     , 62  , 0   ),      /**< WRIOP 2 catastrophic error */
    MC_MPIC_INTR_WRIOP_2_REC_ERR  = MPIC_INTR(INTERNAL     , 63  , 0   ),      /**< WRIOP 2 recoverable error */
    MC_MPIC_INTR_WRIOP_2_RT       = MPIC_INTR(INTERNAL     , 64  , 0   ),      /**< WRIOP 2 run-time */
    MC_MPIC_INTR_AIOP_2_CAT_ERR   = MPIC_INTR(INTERNAL     , 65  , 0   ),      /**< AIOP 2 catastrophic error */
    MC_MPIC_INTR_AIOP_2_REC_ERR   = MPIC_INTR(INTERNAL     , 66  , 0   ),      /**< AIOP 2 recoverable error */
    OS_MPIC_INTR_NUM_67           = MPIC_INTR(INTERNAL     , 67  , 0   ),      /**< Reserved - AIOP 2 run-time */
    MC_MPIC_INTR_WRIOP_3_CAT_ERR  = MPIC_INTR(INTERNAL     , 68  , 0   ),      /**< WRIOP 3 catastrophic error */
    MC_MPIC_INTR_WRIOP_3_REC_ERR  = MPIC_INTR(INTERNAL     , 69  , 0   ),      /**< WRIOP 3 recoverable error */
    MC_MPIC_INTR_WRIOP_3_RT       = MPIC_INTR(INTERNAL     , 70  , 0   ),      /**< WRIOP 3 run-time */
    MC_MPIC_INTR_AIOP_3_CAT_ERR   = MPIC_INTR(INTERNAL     , 71  , 0   ),      /**< AIOP 3 catastrophic error */
    MC_MPIC_INTR_AIOP_3_REC_ERR   = MPIC_INTR(INTERNAL     , 72  , 0   ),      /**< AIOP 3 recoverable error */
    OS_MPIC_INTR_NUM_73           = MPIC_INTR(INTERNAL     , 73  , 0   ),      /**< Reserved - AIOP 3 run-time */
    MC_MPIC_INTR_WRIOP_4_CAT_ERR  = MPIC_INTR(INTERNAL     , 74  , 0   ),      /**< WRIOP 4 catastrophic error */
    MC_MPIC_INTR_WRIOP_4_REC_ERR  = MPIC_INTR(INTERNAL     , 75  , 0   ),      /**< WRIOP 4 recoverable error */
    MC_MPIC_INTR_WRIOP_4_RT       = MPIC_INTR(INTERNAL     , 76  , 0   ),      /**< WRIOP 4 run-time */
    MC_MPIC_INTR_AIOP_4_CAT_ERR   = MPIC_INTR(INTERNAL     , 77  , 0   ),      /**< AIOP 4 catastrophic error */
    MC_MPIC_INTR_AIOP_4_REC_ERR   = MPIC_INTR(INTERNAL     , 78  , 0   ),      /**< AIOP 4 recoverable error */
    OS_MPIC_INTR_NUM_79           = MPIC_INTR(INTERNAL     , 79  , 0   ),      /**< Reserved - AIOP 4 run-time */
    OS_MPIC_INTR_NUM_80           = MPIC_INTR(INTERNAL     , 80  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_81           = MPIC_INTR(INTERNAL     , 81  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_82           = MPIC_INTR(INTERNAL     , 82  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_83           = MPIC_INTR(INTERNAL     , 83  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_84           = MPIC_INTR(INTERNAL     , 84  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_85           = MPIC_INTR(INTERNAL     , 85  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_86           = MPIC_INTR(INTERNAL     , 86  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_87           = MPIC_INTR(INTERNAL     , 87  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_88           = MPIC_INTR(INTERNAL     , 88  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_89           = MPIC_INTR(INTERNAL     , 89  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_90           = MPIC_INTR(INTERNAL     , 90  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_91           = MPIC_INTR(INTERNAL     , 91  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_92           = MPIC_INTR(INTERNAL     , 92  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_93           = MPIC_INTR(INTERNAL     , 93  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_94           = MPIC_INTR(INTERNAL     , 94  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_95           = MPIC_INTR(INTERNAL     , 95  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_96           = MPIC_INTR(INTERNAL     , 96  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_97           = MPIC_INTR(INTERNAL     , 97  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_98           = MPIC_INTR(INTERNAL     , 98  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_99           = MPIC_INTR(INTERNAL     , 99  , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_100          = MPIC_INTR(INTERNAL     , 100 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_101          = MPIC_INTR(INTERNAL     , 101 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_102          = MPIC_INTR(INTERNAL     , 102 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_103          = MPIC_INTR(INTERNAL     , 103 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_104          = MPIC_INTR(INTERNAL     , 104 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_105          = MPIC_INTR(INTERNAL     , 105 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_106          = MPIC_INTR(INTERNAL     , 106 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_107          = MPIC_INTR(INTERNAL     , 107 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_108          = MPIC_INTR(INTERNAL     , 108 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_109          = MPIC_INTR(INTERNAL     , 109 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_110          = MPIC_INTR(INTERNAL     , 110 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_111          = MPIC_INTR(INTERNAL     , 111 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_112          = MPIC_INTR(INTERNAL     , 112 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_113          = MPIC_INTR(INTERNAL     , 113 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_114          = MPIC_INTR(INTERNAL     , 114 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_115          = MPIC_INTR(INTERNAL     , 115 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_116          = MPIC_INTR(INTERNAL     , 116 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_117          = MPIC_INTR(INTERNAL     , 117 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_118          = MPIC_INTR(INTERNAL     , 118 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_119          = MPIC_INTR(INTERNAL     , 119 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_120          = MPIC_INTR(INTERNAL     , 120 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_121          = MPIC_INTR(INTERNAL     , 121 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_122          = MPIC_INTR(INTERNAL     , 122 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_123          = MPIC_INTR(INTERNAL     , 123 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_124          = MPIC_INTR(INTERNAL     , 124 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_125          = MPIC_INTR(INTERNAL     , 125 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_126          = MPIC_INTR(INTERNAL     , 126 , 0   ),      /**< Reserved */
    OS_MPIC_INTR_NUM_127          = MPIC_INTR(INTERNAL     , 127 , 0   ),      /**< Reserved */

    /* External interrupts */
    MC_MPIC_INTR_GPPL_SW_NMI      = MPIC_INTR(EXTERNAL     , 0  , 0    ),      /**< GCR1[1] GPPL S/W triggerable NMI */ 
    MC_MPIC_INTR_EXT_NUM_1        = MPIC_INTR(EXTERNAL     , 1  , 0    ),      /**< reserved (MC Internal Error: interconnect decode and slave errors) */
    MC_MPIC_INTR_EXT_NUM_2        = MPIC_INTR(EXTERNAL     , 2  , 0    ),      /**< reserved */
    MC_MPIC_INTR_WDT_1            = MPIC_INTR(EXTERNAL     , 3  , 0    ),      /**< Watchdog Timer 1 Timeout */
    MC_MPIC_INTR_WDT_2            = MPIC_INTR(EXTERNAL     , 4  , 0    ),      /**< Watchdog Timer 2 Timeout */
    MC_MPIC_INTR_EXT_NUM_5        = MPIC_INTR(EXTERNAL     , 5  , 0    ),      /**< reserved (power management) */
    MC_MPIC_INTR_EDMA_ERR         = MPIC_INTR(EXTERNAL     , 6  , 0    ),      /**< MC EDMA Error (Note: DMA legacy mode interrupt is not supported) */
    MC_MPIC_INTR_EDMA_QML_ERR     = MPIC_INTR(EXTERNAL     , 7  , 0    ),      /**< MC EDMA QMLite Error */
    MC_MPIC_INTR_EDMA_QML_OUT_1   = MPIC_INTR(EXTERNAL     , 8  , 0    ),      /**< MC EDMA QMLite Outbound 1 (expected to be vectored to core 1) */
    MC_MPIC_INTR_EDMA_QML_OUT_2   = MPIC_INTR(EXTERNAL     , 9  , 0    ),      /**< MC EDMA QMLite Outbound 2 (expected to be vectored to core 2) */
    OS_MPIC_INTR_CPM_1_ERR        = MPIC_INTR(EXTERNAL     , 10 , 0    ),      /**< CPM 1 Portal Error */
    OS_MPIC_INTR_CPM_2_ERR        = MPIC_INTR(EXTERNAL     , 11 , 0    ),      /**< CPM 2 Portal Error */

    /* Timer interrupts */
    OS_MPIC_INTR_TIMER_0          = MPIC_INTR(TIMERS       , 0  , 0    ),      /**< Timer interrupt 0 */
    OS_MPIC_INTR_TIMER_1          = MPIC_INTR(TIMERS       , 1  , 0    ),      /**< Timer interrupt 1 */
    OS_MPIC_INTR_TIMER_2          = MPIC_INTR(TIMERS       , 2  , 0    ),      /**< Timer interrupt 2 */
    OS_MPIC_INTR_TIMER_3          = MPIC_INTR(TIMERS       , 3  , 0    ),      /**< Timer interrupt 3 */
    OS_MPIC_INTR_TIMER_4          = MPIC_INTR(TIMERS       , 4  , 0    ),      /**< Timer interrupt 4 */
    OS_MPIC_INTR_TIMER_5          = MPIC_INTR(TIMERS       , 5  , 0    ),      /**< Timer interrupt 5 */
    OS_MPIC_INTR_TIMER_6          = MPIC_INTR(TIMERS       , 6  , 0    ),      /**< Timer interrupt 6 */
    OS_MPIC_INTR_TIMER_7          = MPIC_INTR(TIMERS       , 7  , 0    ),      /**< Timer interrupt 7 */
    
    /* Message interrupts */
    MC_MPIC_INTR_MSG_0            = MPIC_INTR(MSG          , 0  , 0    ),      /**< Message interrupt 0 */
    MC_MPIC_INTR_MSG_1            = MPIC_INTR(MSG          , 1  , 0    ),      /**< Message interrupt 1 */
    MC_MPIC_INTR_MSG_2            = MPIC_INTR(MSG          , 2  , 0    ),      /**< Message interrupt 2 */
    MC_MPIC_INTR_MSG_3            = MPIC_INTR(MSG          , 3  , 0    ),      /**< Message interrupt 3 */
    MC_MPIC_INTR_MSG_4            = MPIC_INTR(MSG          , 4  , 0    ),      /**< Message interrupt 4 */
    MC_MPIC_INTR_MSG_5            = MPIC_INTR(MSG          , 5  , 0    ),      /**< Message interrupt 5 */
    MC_MPIC_INTR_MSG_6            = MPIC_INTR(MSG          , 6  , 0    ),      /**< Message interrupt 6 */
    MC_MPIC_INTR_MSG_7            = MPIC_INTR(MSG          , 7  , 0    ),      /**< Message interrupt 7 */
    MC_MPIC_INTR_MSG_8            = MPIC_INTR(MSG          , 8  , 0    ),      /**< Message interrupt 8 */
    MC_MPIC_INTR_MSG_9            = MPIC_INTR(MSG          , 9  , 0    ),      /**< Message interrupt 9 */
    MC_MPIC_INTR_MSG_10           = MPIC_INTR(MSG          , 10 , 0    ),      /**< Message interrupt 10 */
    MC_MPIC_INTR_MSG_11           = MPIC_INTR(MSG          , 11 , 0    ),      /**< Message interrupt 11 */
    MC_MPIC_INTR_MSG_12           = MPIC_INTR(MSG          , 12 , 0    ),      /**< Message interrupt 12 */
    MC_MPIC_INTR_MSG_13           = MPIC_INTR(MSG          , 13 , 0    ),      /**< Message interrupt 13 */
    MC_MPIC_INTR_MSG_14           = MPIC_INTR(MSG          , 14 , 0    ),      /**< Message interrupt 14 */
    MC_MPIC_INTR_MSG_15           = MPIC_INTR(MSG          , 15 , 0    )       /**< Message interrupt 15 */
    
#if 0
    /* Shared message interrupts */
    OS_MPIC_INTR_SHARED_MSG_0     = MPIC_INTR(SHARED_MSG   , 0  , 0    ),      /**< Shared message interrupt 0 */ //TODO
    OS_MPIC_INTR_SHARED_MSG_1     = MPIC_INTR(SHARED_MSG   , 1  , 0    ),      /**< Shared message interrupt 1 */
    OS_MPIC_INTR_SHARED_MSG_2     = MPIC_INTR(SHARED_MSG   , 2  , 0    ),      /**< Shared message interrupt 2 */
    OS_MPIC_INTR_SHARED_MSG_3     = MPIC_INTR(SHARED_MSG   , 3  , 0    ),      /**< Shared message interrupt 3 */
    OS_MPIC_INTR_SHARED_MSG_4     = MPIC_INTR(SHARED_MSG   , 4  , 0    ),      /**< Shared message interrupt 4 */
    OS_MPIC_INTR_SHARED_MSG_5     = MPIC_INTR(SHARED_MSG   , 5  , 0    ),      /**< Shared message interrupt 5 */
    OS_MPIC_INTR_SHARED_MSG_6     = MPIC_INTR(SHARED_MSG   , 6  , 0    ),      /**< Shared message interrupt 6 */
    OS_MPIC_INTR_SHARED_MSG_7     = MPIC_INTR(SHARED_MSG   , 7  , 0    ),      /**< Shared message interrupt 7 */
    OS_MPIC_INTR_SHARED_MSG_8     = MPIC_INTR(SHARED_MSG   , 8  , 0    ),      /**< Shared message interrupt 8 */
    OS_MPIC_INTR_SHARED_MSG_9     = MPIC_INTR(SHARED_MSG   , 9  , 0    ),      /**< Shared message interrupt 9 */
    OS_MPIC_INTR_SHARED_MSG_10    = MPIC_INTR(SHARED_MSG   , 10 , 0    ),      /**< Shared message interrupt 10 */
    OS_MPIC_INTR_SHARED_MSG_11    = MPIC_INTR(SHARED_MSG   , 11 , 0    ),      /**< Shared message interrupt 11 */
    OS_MPIC_INTR_SHARED_MSG_12    = MPIC_INTR(SHARED_MSG   , 12 , 0    ),      /**< Shared message interrupt 12 */
    OS_MPIC_INTR_SHARED_MSG_13    = MPIC_INTR(SHARED_MSG   , 13 , 0    ),      /**< Shared message interrupt 13 */
    OS_MPIC_INTR_SHARED_MSG_14    = MPIC_INTR(SHARED_MSG   , 14 , 0    ),      /**< Shared message interrupt 14 */
    OS_MPIC_INTR_SHARED_MSG_15    = MPIC_INTR(SHARED_MSG   , 15 , 0    ),      /**< Shared message interrupt 15 */
    OS_MPIC_INTR_SHARED_MSG_16    = MPIC_INTR(SHARED_MSG   , 16 , 0    ),      /**< Shared message interrupt 16 */
    OS_MPIC_INTR_SHARED_MSG_17    = MPIC_INTR(SHARED_MSG   , 17 , 0    ),      /**< Shared message interrupt 17 */
    OS_MPIC_INTR_SHARED_MSG_18    = MPIC_INTR(SHARED_MSG   , 18 , 0    ),      /**< Shared message interrupt 18 */
    OS_MPIC_INTR_SHARED_MSG_19    = MPIC_INTR(SHARED_MSG   , 19 , 0    ),      /**< Shared message interrupt 19 */
    OS_MPIC_INTR_SHARED_MSG_20    = MPIC_INTR(SHARED_MSG   , 20 , 0    ),      /**< Shared message interrupt 20 */
    OS_MPIC_INTR_SHARED_MSG_21    = MPIC_INTR(SHARED_MSG   , 21 , 0    ),      /**< Shared message interrupt 21 */
    OS_MPIC_INTR_SHARED_MSG_22    = MPIC_INTR(SHARED_MSG   , 22 , 0    ),      /**< Shared message interrupt 22 */
    OS_MPIC_INTR_SHARED_MSG_23    = MPIC_INTR(SHARED_MSG   , 23 , 0    ),      /**< Shared message interrupt 23 */	
    OS_MPIC_INTR_SHARED_MSG_24    = MPIC_INTR(SHARED_MSG   , 24 , 0    ),      /**< Shared message interrupt 24 */
    OS_MPIC_INTR_SHARED_MSG_25    = MPIC_INTR(SHARED_MSG   , 25 , 0    ),      /**< Shared message interrupt 25 */
    OS_MPIC_INTR_SHARED_MSG_26    = MPIC_INTR(SHARED_MSG   , 26 , 0    ),      /**< Shared message interrupt 26 */
    OS_MPIC_INTR_SHARED_MSG_27    = MPIC_INTR(SHARED_MSG   , 27 , 0    ),      /**< Shared message interrupt 27 */
    OS_MPIC_INTR_SHARED_MSG_28    = MPIC_INTR(SHARED_MSG   , 28 , 0    ),      /**< Shared message interrupt 28 */
    OS_MPIC_INTR_SHARED_MSG_29    = MPIC_INTR(SHARED_MSG   , 29 , 0    ),      /**< Shared message interrupt 29 */
    OS_MPIC_INTR_SHARED_MSG_30    = MPIC_INTR(SHARED_MSG   , 30 , 0    ),      /**< Shared message interrupt 30 */
    OS_MPIC_INTR_SHARED_MSG_31    = MPIC_INTR(SHARED_MSG   , 31 , 0    ),      /**< Shared message interrupt 31 */
    OS_MPIC_INTR_SHARED_MSG_32    = MPIC_INTR(SHARED_MSG   , 32 , 0    ),      /**< Shared message interrupt 32 */
    OS_MPIC_INTR_SHARED_MSG_33    = MPIC_INTR(SHARED_MSG   , 33 , 0    ),      /**< Shared message interrupt 33 */
    OS_MPIC_INTR_SHARED_MSG_34    = MPIC_INTR(SHARED_MSG   , 34 , 0    ),      /**< Shared message interrupt 34 */
    OS_MPIC_INTR_SHARED_MSG_35    = MPIC_INTR(SHARED_MSG   , 35 , 0    ),      /**< Shared message interrupt 35 */
    OS_MPIC_INTR_SHARED_MSG_36    = MPIC_INTR(SHARED_MSG   , 36 , 0    ),      /**< Shared message interrupt 36 */
    OS_MPIC_INTR_SHARED_MSG_37    = MPIC_INTR(SHARED_MSG   , 37 , 0    ),      /**< Shared message interrupt 37 */
    OS_MPIC_INTR_SHARED_MSG_38    = MPIC_INTR(SHARED_MSG   , 38 , 0    ),      /**< Shared message interrupt 38 */
    OS_MPIC_INTR_SHARED_MSG_39    = MPIC_INTR(SHARED_MSG   , 39 , 0    ),      /**< Shared message interrupt 39 */
    OS_MPIC_INTR_SHARED_MSG_40    = MPIC_INTR(SHARED_MSG   , 40 , 0    ),      /**< Shared message interrupt 40 */
    OS_MPIC_INTR_SHARED_MSG_41    = MPIC_INTR(SHARED_MSG   , 41 , 0    ),      /**< Shared message interrupt 41 */
    OS_MPIC_INTR_SHARED_MSG_42    = MPIC_INTR(SHARED_MSG   , 42 , 0    ),      /**< Shared message interrupt 42 */
    OS_MPIC_INTR_SHARED_MSG_43    = MPIC_INTR(SHARED_MSG   , 43 , 0    ),      /**< Shared message interrupt 43 */
    OS_MPIC_INTR_SHARED_MSG_44    = MPIC_INTR(SHARED_MSG   , 44 , 0    ),      /**< Shared message interrupt 44 */
    OS_MPIC_INTR_SHARED_MSG_45    = MPIC_INTR(SHARED_MSG   , 45 , 0    ),      /**< Shared message interrupt 45 */
    OS_MPIC_INTR_SHARED_MSG_46    = MPIC_INTR(SHARED_MSG   , 46 , 0    ),      /**< Shared message interrupt 46 */
    OS_MPIC_INTR_SHARED_MSG_47    = MPIC_INTR(SHARED_MSG   , 47 , 0    ),      /**< Shared message interrupt 47 */
    OS_MPIC_INTR_SHARED_MSG_48    = MPIC_INTR(SHARED_MSG   , 48 , 0    ),      /**< Shared message interrupt 48 */
    OS_MPIC_INTR_SHARED_MSG_49    = MPIC_INTR(SHARED_MSG   , 49 , 0    ),      /**< Shared message interrupt 49 */
	OS_MPIC_INTR_SHARED_MSG_50    = MPIC_INTR(SHARED_MSG   , 50 , 0    ),      /**< Shared message interrupt 50 */
    OS_MPIC_INTR_SHARED_MSG_51    = MPIC_INTR(SHARED_MSG   , 51 , 0    ),      /**< Shared message interrupt 51 */
    OS_MPIC_INTR_SHARED_MSG_52    = MPIC_INTR(SHARED_MSG   , 52 , 0    ),      /**< Shared message interrupt 52 */
    OS_MPIC_INTR_SHARED_MSG_53    = MPIC_INTR(SHARED_MSG   , 53 , 0    ),      /**< Shared message interrupt 53 */
    OS_MPIC_INTR_SHARED_MSG_54    = MPIC_INTR(SHARED_MSG   , 54 , 0    ),      /**< Shared message interrupt 54 */
    OS_MPIC_INTR_SHARED_MSG_55    = MPIC_INTR(SHARED_MSG   , 55 , 0    ),      /**< Shared message interrupt 55 */
    OS_MPIC_INTR_SHARED_MSG_56    = MPIC_INTR(SHARED_MSG   , 56 , 0    ),      /**< Shared message interrupt 56 */
    OS_MPIC_INTR_SHARED_MSG_57    = MPIC_INTR(SHARED_MSG   , 57 , 0    ),      /**< Shared message interrupt 57 */
    OS_MPIC_INTR_SHARED_MSG_58    = MPIC_INTR(SHARED_MSG   , 58 , 0    ),      /**< Shared message interrupt 58 */
    OS_MPIC_INTR_SHARED_MSG_59    = MPIC_INTR(SHARED_MSG   , 59 , 0    ),      /**< Shared message interrupt 59 */
    OS_MPIC_INTR_SHARED_MSG_60    = MPIC_INTR(SHARED_MSG   , 60 , 0    ),      /**< Shared message interrupt 60 */
    OS_MPIC_INTR_SHARED_MSG_61    = MPIC_INTR(SHARED_MSG   , 61 , 0    ),      /**< Shared message interrupt 61 */
    OS_MPIC_INTR_SHARED_MSG_62    = MPIC_INTR(SHARED_MSG   , 62 , 0    ),      /**< Shared message interrupt 62 */
    OS_MPIC_INTR_SHARED_MSG_63    = MPIC_INTR(SHARED_MSG   , 63 , 0    ),      /**< Shared message interrupt 63 */    
    
    /* Inter-processor interrupts */
    OS_MPIC_INTR_IPI_0            = MPIC_INTR(IPI          , 0  , 0    ),      /**< Inter-processor interrupt 0 */
    OS_MPIC_INTR_IPI_1            = MPIC_INTR(IPI          , 1  , 0    ),      /**< Inter-processor interrupt 1 */
    OS_MPIC_INTR_IPI_2            = MPIC_INTR(IPI          , 2  , 0    ),      /**< Inter-processor interrupt 2 */
    OS_MPIC_INTR_IPI_3            = MPIC_INTR(IPI          , 3  , 0    )       /**< Inter-processor interrupt 3 */
#endif
} mc_mpic_intr_id_t;

/** @} */ // mpic_ls2085_id
/** @} */ // os_mpic_id

#endif // ___LS2085_MC_MPIC_H

