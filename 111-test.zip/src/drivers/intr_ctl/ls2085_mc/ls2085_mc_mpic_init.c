/*
 * Copyright 2013-2020 NXP
 */

#include "mpic_memmap.h"
#include "ls2085_mc_mpic_init.h"
#include "mpic.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"

mpic_t *g_mc_mpic_handle;

extern mpic_memmap_t * g_mpic_memmap;

static void osMpicParamsInit(mpic_config_params_t *mpic_config_params)
{
	/* Store parameters */
	mpic_config_params->guest_id = (uint8_t)mpic_get_core_id();
}

void mpic_clear_pending_core_events()
{
	mpic_clear_pending_core_interrupts();
}

int mpic_initialize(void * mpic_register_base)
{
	int err;

	mpic_config_params_t mpic_params;

	ASSERT_COND(mpic_register_base != NULL);

	g_mpic_memmap = mpic_register_base;

	/* MPIC parameters initialize*/
	osMpicParamsInit(&mpic_params);

	/* initialize MPIC */
	err = mpic_config(&mpic_params, &g_mc_mpic_handle);
	if (err)
		return err;

	err = mpic_init();

	return err;
}
