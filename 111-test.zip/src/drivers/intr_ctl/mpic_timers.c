/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "mpic.h"
#include "fsl_io.h"
#include "fsl_mpic.h"
#include "fsl_dbg.h"
#include "fsl_errors.h"
#include "mpic_memmap.h"
#include "mpic_timers.h"
#include "fsl_platform.h"
#include "fsl_core_booke.h"

/*****************************************************************************/
#define MPIC_GT_NUM_OF_GROUPS            2
#define MPIC_GT_NUM_OF_TIMERS_IN_GROUP   4

#define MPIC_GT_NUM_OF_TIMERS (MPIC_GT_NUM_OF_GROUPS * MPIC_GT_NUM_OF_TIMERS_IN_GROUP)

#define MPIC_GT_GTBCR_CI_MASK            0x80000000
#define MPIC_GT_GTBCR_BASE_COUNT_MASK    0x7fffffff

#define MPIC_GT_GTCCR_TOG_MASK           0x80000000
#define MPIC_GT_GTCCR_COUNT_MASK         0x7fffffff

#define MPIC_GT_TCR_CLKR_MASK            0x00000300
#define MPIC_GT_TCR_RTM_MASK             0x00010000
#define MPIC_GT_TCR_CLKR_OFF             8
#define MPIC_GT_TCR_RTM_OFF              16

/*****************************************************************************/
extern mpic_memmap_t * g_mpic_memmap;

#define TIMERS_DB_DATA \
	{/*	tid	interrupt_id		f_user_cb	h_app	orig_period	p_timer */ \
		{0, 	OS_MPIC_INTR_TIMER_0, 	NULL, 		NULL,	0,		NULL }, \
		{1, 	OS_MPIC_INTR_TIMER_1, 	NULL, 		NULL,	0,		NULL }, \
		{2, 	OS_MPIC_INTR_TIMER_2, 	NULL, 		NULL,	0,		NULL }, \
		{3, 	OS_MPIC_INTR_TIMER_3, 	NULL, 		NULL,	0,		NULL }, \
		{4, 	OS_MPIC_INTR_TIMER_4, 	NULL, 		NULL,	0,		NULL }, \
		{5, 	OS_MPIC_INTR_TIMER_5, 	NULL, 		NULL,	0,		NULL }, \
		{6, 	OS_MPIC_INTR_TIMER_6, 	NULL, 		NULL,	0,		NULL }, \
		{7, 	OS_MPIC_INTR_TIMER_7, 	NULL, 		NULL,	0,		NULL }  \
	}

struct mpic_timers_entry {
	uint8_t tid;
	uint32_t interrupt_id;
	void (*f_user_cb) (void* h_app, uint8_t id);
	void* h_app;
	uint64_t orig_period; /* original requested period [ticks] */
	mpic_gtr_part_memmap_t *p_timer;
};
static struct mpic_timers_entry timers_db[MPIC_GT_NUM_OF_TIMERS] = TIMERS_DB_DATA;

uint32_t mpic_timer_clk = 0;

/*****************************************************************************/
static void mpic_timer_isr(int arg)
{
	struct mpic_timers_entry * entry = (struct mpic_timers_entry *)arg;

	if(entry != NULL) {
		if(entry->f_user_cb) {
			entry->f_user_cb(entry->h_app, entry->tid);
		}
	}
}

/*****************************************************************************/
static int register_interrupt(uint32_t timer_int_id, uint32_t core_id, uint8_t priority, mpic_isr timer_cb, mpic_arg arg)
{
	mpic_intr_params_t intr_params;
	int err;

	intr_params.polarity = OS_MPIC_INTR_POLARITY_LOW;
	intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;
	intr_params.sense = OS_MPIC_INTR_SENSE_EDGE;
	intr_params.priority = priority;

	err = mpic_set_config_intr(timer_int_id, core_id, timer_cb, arg, &intr_params);
	if(err != 0) return err;

	err = mpic_enable_intr(timer_int_id);
	if(err != 0) return err;

	return 0;
}

/*****************************************************************************/
static int unregister_interrupt(uint32_t timer_int_id)
{
	int err;

	err = mpic_disable_intr(timer_int_id);
	if (err != 0) return err;
	
	err = mpic_free_intr(timer_int_id);
	if (err != 0) return err;

	return 0;
}

static uint32_t calc_timer_clk(enum mpic_gt_clk_src clk, enum mpic_gt_clk_ratio ratio)
{
	uint32_t timer_clk;

	if(clk == mpic)
	{
		pr_debug("MPIC timer clock source: mpic\n");
		pr_debug("platform_clk: 0x%x[kHz]\n", sys_get_platform_clk());

		/* Get platform clock in Hz */
		timer_clk = sys_get_platform_clk() * 1000;
		timer_clk /= 2; /* MPIC clock is half platform clock */

		switch(ratio)
		{
		case div_8:
			timer_clk = timer_clk / 8;
			break;
		case div_16:
			timer_clk = timer_clk / 16;
			break;
		case div_32:
			timer_clk = timer_clk / 32;
			break;
		case div_64:
			timer_clk = timer_clk / 64;
			break;
		default:
			/* Unsupported divider */
			return 0;
		}
	}
	else
	{
		/* RTC source is not supported for now */
		return 0;
	}

	pr_debug("MPIC timer clk: 0x%x[Hz]\n", timer_clk);

	return timer_clk;
}

/*****************************************************************************/
void* mpic_gt_init(const struct mpic_gt_init_params* const params)
{
	uint32_t tcr_val = 0;

	/* Only master-core is allowed here */
	ASSERT_COND(sys_is_master_core());

	mpic_timer_clk = calc_timer_clk(params->clk_src, params->clk_ratio);
	if(mpic_timer_clk == 0) {
		pr_err("Failed to get mpic clock\n");
		return NULL;
	}

	/* tfrr for both groups */
	iowrite32be(mpic_timer_clk, &g_mpic_memmap->mpic_global_memmap.global_timer_a.tfrr);
	iowrite32be(mpic_timer_clk, &g_mpic_memmap->mpic_global_memmap.global_timer_b.tfrr);

	ASSERT_COND(g_mpic_memmap->mpic_global_memmap.global_timer_a.tfrr
			== g_mpic_memmap->mpic_global_memmap.global_timer_b.tfrr);

	/* initiate timers_db */
	timers_db[0].p_timer = &g_mpic_memmap->mpic_global_memmap.global_timer_a.gtr[0];
	timers_db[1].p_timer = &g_mpic_memmap->mpic_global_memmap.global_timer_a.gtr[1];
	timers_db[2].p_timer = &g_mpic_memmap->mpic_global_memmap.global_timer_a.gtr[2];
	timers_db[3].p_timer = &g_mpic_memmap->mpic_global_memmap.global_timer_a.gtr[3];
	timers_db[4].p_timer = &g_mpic_memmap->mpic_global_memmap.global_timer_b.gtr[0];
	timers_db[5].p_timer = &g_mpic_memmap->mpic_global_memmap.global_timer_b.gtr[1];
	timers_db[6].p_timer = &g_mpic_memmap->mpic_global_memmap.global_timer_b.gtr[2];
	timers_db[7].p_timer = &g_mpic_memmap->mpic_global_memmap.global_timer_b.gtr[3];

	/* initialize Timer Control Registers */
	tcr_val = (uint32_t)(params->clk_src << MPIC_GT_TCR_RTM_OFF);
	tcr_val |= params->clk_ratio << (MPIC_GT_TCR_CLKR_OFF);
	iowrite32be(tcr_val, &g_mpic_memmap->mpic_global_memmap.global_timer_a.tcr);
	iowrite32be(tcr_val, &g_mpic_memmap->mpic_global_memmap.global_timer_b.tcr);

	return (void*)&timers_db;
}

/*****************************************************************************/
uint32_t mpic_gt_get_freq()
{
	ASSERT_COND(g_mpic_memmap->mpic_global_memmap.global_timer_a.tfrr
			== g_mpic_memmap->mpic_global_memmap.global_timer_b.tfrr);

	return ioread32be(&g_mpic_memmap->mpic_global_memmap.global_timer_a.tfrr);
}

/*****************************************************************************/
static int mpic_gt_config_timer(uint8_t id, const struct mpic_gt_config_params* const params)
{
	int err;
	struct mpic_timers_entry * entry = &timers_db[id];

	entry->f_user_cb = params->user_exp_cb;

	err = mpic_timer_set_time(id, params->base_count_us);
	if(err != 0) return err;

	/* Register MPIC interrupts */
	if(params->destination == dest_core_0)
	{
		err = register_interrupt(entry->interrupt_id, 0, params->priority, (mpic_isr)mpic_timer_isr, (mpic_arg)entry);
		if(err != 0) return err;
	}
	else if(params->destination == dest_core_1)
	{
		err = register_interrupt(entry->interrupt_id, 1, params->priority, (mpic_isr)mpic_timer_isr, (mpic_arg)entry);
		if(err != 0) return err;
	}

	return 0;
}

/*****************************************************************************/
static int mpic_gt_start_timer(uint8_t id)
{
	uint32_t reg;
	mpic_gtr_part_memmap_t *gtr = timers_db[id].p_timer;

	reg = ioread32be(&gtr->gtbcr);
	reg &= ~MPIC_GT_GTBCR_CI_MASK;
	iowrite32be(reg, &gtr->gtbcr);

	return 0;
}

/*****************************************************************************/
int mpic_timer_stop(uint8_t id)
{
	uint32_t reg;
	int err;
	struct mpic_timers_entry * entry = &timers_db[id];
	mpic_gtr_part_memmap_t *gtr = entry->p_timer;
	
	ASSERT_COND(id < MPIC_GT_NUM_OF_TIMERS);

	reg = ioread32be(&gtr->gtbcr);
	reg |= MPIC_GT_GTBCR_CI_MASK;
	iowrite32be(reg, &gtr->gtbcr);
	
	err = unregister_interrupt(entry->interrupt_id);
	if(err != 0) return err;

	return 0;
}

/*****************************************************************************/
int mpic_timer_start(uint8_t id, void (*f_expired_callback) (void* h_app, uint8_t id),
            void* h_app, uint64_t period_us)
{
	int err;
	uint32_t reg;
	struct mpic_gt_config_params params;
	struct mpic_timers_entry * entry = &timers_db[id];

	ASSERT_COND(id < MPIC_GT_NUM_OF_TIMERS);
	
	/* stop timer (validate timer is not running) */
	reg = ioread32be(&entry->p_timer->gtbcr);
	ASSERT_COND(reg |= (MPIC_GT_GTBCR_CI_MASK));

	entry->h_app = h_app;

	params.base_count_us = period_us;
	params.destination = core_get_id() == 0 ? dest_core_0 : dest_core_1;
	params.priority = 0xa; /* Highest priority */
	params.user_exp_cb = f_expired_callback;

	err = mpic_gt_config_timer(id, &params);
	if(err != 0) return err;

	err = mpic_gt_start_timer(id);
	if(err != 0) return err;

	return 0;
}

/*****************************************************************************/
int mpic_timer_set_time(uint8_t id, uint64_t period_us)
{
	uint32_t reg;
	struct mpic_timers_entry * entry = &timers_db[id];
	mpic_gtr_part_memmap_t *gtr = entry->p_timer;
	uint64_t period = USECS_TO_TICKS(period_us);

	if(period_us > MAX_PERIOD) {
		pr_err("MPIC timer period is too large\n");
		return -EINVAL;
	}

	if(period_us < MIN_PERIOD) {
		pr_err("MPIC timer period is too small\n");
		return -EINVAL;
	}

	/* don't allow period greater than 32 bit (for now) */
	/* MSB bit is reserved for CI (Count Inhibited) */
	ASSERT_COND(period < 0x80000000ULL);

	/* Update base count */
	reg = ioread32be(&gtr->gtbcr);
	reg &= ~MPIC_GT_GTBCR_BASE_COUNT_MASK;
	reg |= (uint32_t)period;
	iowrite32be(reg, &gtr->gtbcr);

	entry->orig_period = period;

	return 0;
}

/*****************************************************************************/
int mpic_timer_get_time(uint8_t id, uint64_t *p_time_us)
{
	mpic_gtr_part_memmap_t *gtr = timers_db[id].p_timer;
	uint64_t temp;

	ASSERT_COND(id < MPIC_GT_NUM_OF_TIMERS);
	ASSERT_COND(p_time_us);

	if(!timers_db[id].f_user_cb)
		return -ENODEV;

	temp = (uint64_t)ioread32be(&gtr->gtccr);
	temp &= MPIC_GT_GTCCR_COUNT_MASK; /* Don't read the TOG bit */
	temp = timers_db[id].orig_period - temp; /* calculate passed time */

	*p_time_us = TICKS_TO_USECS(temp);

	return 0;
}


