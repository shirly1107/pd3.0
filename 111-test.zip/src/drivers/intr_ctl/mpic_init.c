/*
 * Copyright 2013-2020 NXP
 */


#include "fsl_gen.h"
#include "fsl_smp.h"
#include "fsl_io.h"

#include "mpic.h"
#include "fsl_mpic.h"
#include "mpic_memmap.h"
#include "ls2085_mc_mpic.h"
#include "ls2085_mc_mpic_init.h"
#include "fsl_dbg.h"

#define __ARRAY_SIZE(ARRAY)     (sizeof(ARRAY) / sizeof(ARRAY[0]))

#ifndef DISABLE_ALL_ERROR_CHECKING
#define MPIC_ERROR_CHECK
#endif//DISABLE_ALL_ERROR_CHECKING

/* Global for fast implementation of MPIC_Intr() */
static mpic_t   mpic_dev;
extern mpic_t *g_mc_mpic_handle;
extern mpic_memmap_t * g_mpic_memmap;

/******************************************************************************/
void mpic_unassigned_isr(mpic_arg arg)
{
	UNUSED(arg);
	DEBUG_HALT;
}

/*****************************************************************************/
void mpic_error_isr(mpic_arg arg)
{
	uint32_t    isr_index = MPIC_MULTI_SRC_OFFSET(arg);
	uint32_t    events;

	/* Read event register and clear any umasked bits */
	events = ioread32be(&(g_mpic_memmap->mpic_global_memmap.global_interrupt_summary.eisr));

	/* Error interrupt handling */
	while (events)
	{
		if (events & EISR_EVENT_MASK)
		{
			ASSERT_COND(g_mc_mpic_handle->isr_table[isr_index].isr != mpic_unassigned_isr);
			(MPIC_ISR(g_mc_mpic_handle->isr_table[isr_index].isr))(g_mc_mpic_handle->isr_table[isr_index].arg);
		}

		/* Move to check the next bit */
		events <<= 1;
		isr_index++;
	}
}

/*****************************************************************************/
void mpic_multi_source_isr(mpic_arg arg)
{
	uint16_t    isr_index = MPIC_MULTI_SRC_OFFSET(arg);
	uint16_t    isr_count = MPIC_MULTI_SRC_COUNT(arg);
	uint8_t     found_isr = 0;

	while (isr_count)
	{
		if ( (g_mc_mpic_handle->isr_table[isr_index].isr) != mpic_unassigned_isr)
		{
			(MPIC_ISR(g_mc_mpic_handle->isr_table[isr_index].isr))(g_mc_mpic_handle->isr_table[isr_index].arg);
			found_isr = 0x1;
		}
		isr_index++;
		isr_count--;
		ASSERT_COND(isr_index < (MPIC_NUM_OF_INTR_SOURCES + MPIC_MULTI_SRC_INTERNAL_INTERRUPTS_COUNT + 1));
	}
	if (!found_isr)
	{
		DEBUG_HALT;
	}
}

/*******************************************************************************/
#if 0
static os_status  osMpicCheckInitParameters()
{

	uint16_t    grp, idx, int_cfg_idx;

	/* Loop on all interrupt sources to check constraints */
	for (grp=0; grp < MPIC_NUM_OF_INTR_GROUPS; grp++)
	{
		int_cfg_idx = g_dsp_mpic_handle->intr_group_base_idx[grp];

		for (idx=0; idx < g_dsp_mpic_handle->intr_count_by_group[grp]; idx++, int_cfg_idx++)
		{
			if ((g_dsp_mpic_handle->intr_config[int_cfg_idx].vector != MPIC_UNASSIGNED_VECTOR) &&
				(g_dsp_mpic_handle->intr_config[int_cfg_idx].vector >= MPIC_NUM_OF_INTR_SOURCES))
			{
				RETURN_ERROR(TODO);
			}
			if (g_dsp_mpic_handle->intr_config[int_cfg_idx].priority > MPIC_HIGHEST_INTR_PRIORITY)
			{
				RETURN_ERROR(TODO);
			}

			if (grp != OS_MPIC_INTR_GROUP_EXTERNAL)
			{
				/* Non-external interrupts */
				if (g_dsp_mpic_handle->intr_config[int_cfg_idx].sense != OS_MPIC_INTR_SENSE_EDGE)
				{
					RETURN_ERROR_MESSAGE(TODO,
					                     ("Non-external interrupts must not use OS_MPIC_INTR_SENSE_LEVEL"));
				}

				if (grp == OS_MPIC_INTR_GROUP_INTERNAL)
				{
					/* Internal interrupts */
					if (g_dsp_mpic_handle->intr_config[int_cfg_idx].polarity != OS_MPIC_INTR_POLARITY_HIGH)
					{
						RETURN_ERROR_MESSAGE(TODO,
						                     ("Internal interrupts must use OS_MPIC_INTR_POLARITY_HIGH"));
					}
				}
				else
				{
					/* Neither internal nor external interrupts */
					if (g_dsp_mpic_handle->intr_config[int_cfg_idx].polarity != OS_MPIC_INTR_POLARITY_LOW)
					{
						RETURN_ERROR_MESSAGE(TODO,
						                     ("Interrupts other than internal/external must not use OS_MPIC_INTR_POLARITY_HIGH"));
					}
					if (g_dsp_mpic_handle->intr_config[int_cfg_idx].target != OS_MPIC_INTR_TARGET_DEFAULT)
					{
						RETURN_ERROR_MESSAGE(TODO,
						                     ("Interrupts other than internal/external must use OS_MPIC_INTR_TARGET_DEFAULT"));
					}
				}
			}
			else
			{
				/* External interrupts */
				if ((g_dsp_mpic_handle->intr_config[int_cfg_idx].target != OS_MPIC_INTR_TARGET_DEFAULT) &&
					(g_dsp_mpic_handle->intr_config[int_cfg_idx].sense  != OS_MPIC_INTR_SENSE_LEVEL))
				{
					RETURN_ERROR_MESSAGE(TODO,
					                     ("External interrupts with non-default target must use OS_MPIC_INTR_SENSE_LEVEL"));
				}
			}
		}
	}

	return OS_SUCCESS;

}
#endif // 0

#if 0
// Removed because there is correlation between vector and interrupt source thus there is no need for g_dsp_mpic_handle->vector
/*******************************************************************************/
static void     osMpicAssignInterruptVectors()
{

	uint16_t    int_cfg_idx, vector;
	uint32_t    assigned_vectors[MPIC_VECTOR_MASK_SIZE] = { 0 };


	/* First mark all interrupt vectors assigned by the user */
	for (int_cfg_idx = 0; int_cfg_idx < MPIC_NUM_OF_INTR_SOURCES; int_cfg_idx++)
	{
		vector = g_dsp_mpic_handle->vector[int_cfg_idx];

		if (vector != MPIC_UNASSIGNED_VECTOR)
			MPIC_SET_VECTOR_MASK(assigned_vectors, vector);
	}

	/* Now assign vectors to the remaining interrupt sources */
	vector = 0;

	for (int_cfg_idx = 0; int_cfg_idx < MPIC_NUM_OF_INTR_SOURCES; int_cfg_idx++)
	{
		if (g_dsp_mpic_handle->vector[int_cfg_idx] == MPIC_UNASSIGNED_VECTOR)
		{
			/* Skip already assigned vectors */
			while (MPIC_IS_VECTOR_ASSIGNED(assigned_vectors, vector))
				vector++;

			/* Assign the vector and mark it in the mask array */
			OS_ASSERT_COND(vector < MPIC_NUM_OF_INTR_SOURCES);
			g_dsp_mpic_handle->vector[int_cfg_idx] = vector;
			MPIC_SET_VECTOR_MASK(assigned_vectors, vector);

			vector++;
		}
	}
}
#endif

/*******************************************************************************/
static void get_intr_conf_regs_internal(uint32_t **vpr, uint32_t **dr, uint32_t **lr, uint16_t idx)
{
	mpic_memmap_t       *mpic_memmap = g_mpic_memmap;

	if (idx < MPIC_NUM_OF_LOW_INT_INTRS)
	{
		*vpr = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.internal_interrupt_configuration_low.iirl[idx].iivpr);
		*dr  = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.internal_interrupt_configuration_low.iirl[idx].iidr);
		*lr  = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.internal_interrupt_configuration_low.iirl[idx].iilr);
	}
	else
	{
		idx -= MPIC_NUM_OF_LOW_INT_INTRS;
		*vpr = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.internal_interrupt_configuration_high.iirh[idx].iivpr);
		*dr  = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.internal_interrupt_configuration_high.iirh[idx].iidr);
		*lr  = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.internal_interrupt_configuration_high.iirh[idx].iilr);
	}
}

/*******************************************************************************/
static void get_intr_conf_regs_external(uint32_t **vpr, uint32_t **dr, uint32_t **lr, uint16_t idx)
{
	mpic_memmap_t       *mpic_memmap = g_mpic_memmap;

	*vpr = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.external_interrupt_configuration.eir[idx].eivpr);
	*dr  = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.external_interrupt_configuration.eir[idx].eidr);
	*lr  = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.external_interrupt_configuration.eir[idx].eilr);
}

/*******************************************************************************/
static void get_intr_conf_regs_timers(uint32_t **vpr, uint32_t **dr, uint32_t **lr, uint16_t idx)
{
	mpic_memmap_t       *mpic_memmap = g_mpic_memmap;

	if (idx < NUM_OF_TIMERS_PER_GROUP)
	{
		*vpr = (uint32_t *)&(mpic_memmap->mpic_global_memmap.global_timer_a.gtr[idx].gtvpr);
		*dr  = (uint32_t *)&(mpic_memmap->mpic_global_memmap.global_timer_a.gtr[idx].gtdr);
	}
	else
	{
		idx -= NUM_OF_TIMERS_PER_GROUP;
		*vpr = (uint32_t *)&(mpic_memmap->mpic_global_memmap.global_timer_b.gtr[idx].gtvpr);
		*dr  = (uint32_t *)&(mpic_memmap->mpic_global_memmap.global_timer_b.gtr[idx].gtdr);
	}
	/* No level registers for Timers */
}

/*******************************************************************************/
static void get_intr_conf_regs_msg(uint32_t **vpr, uint32_t **dr, uint32_t **lr, uint16_t idx)
{
	mpic_memmap_t       *mpic_memmap = g_mpic_memmap;

	if (idx < NUM_OF_MSG_INTR_PER_GROUP)
	{
		if (idx < NUM_OF_LOW_MSG_INTR_PER_GROUP)
		{
			*vpr = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.msg_interrupt_configuration.mir_low_a[idx].mivpr);
			*dr  = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.msg_interrupt_configuration.mir_low_a[idx].midr);
			/* No level registers for MSG */
		}
		else
		{
			idx -= NUM_OF_LOW_MSG_INTR_PER_GROUP;
			*vpr = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.msg_interrupt_configuration.mir_high_a[idx].mivpr);
			*dr  = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.msg_interrupt_configuration.mir_high_a[idx].midr);
			/* No level registers for MSG */
		}
	}
	else //Group B
	{
		idx -= NUM_OF_MSG_INTR_PER_GROUP;
		if (idx < NUM_OF_LOW_MSG_INTR_PER_GROUP)
		{
			*vpr = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.msg_interrupt_configuration.mir_low_b[idx].mivpr);
			*dr  = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.msg_interrupt_configuration.mir_low_b[idx].midr);
			/* No level registers for MSG */
		}
		else
		{
			idx -= NUM_OF_LOW_MSG_INTR_PER_GROUP;
			*vpr = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.msg_interrupt_configuration.mir_high_b[idx].mivpr);
			*dr  = (uint32_t *)&(mpic_memmap->mpic_int_src_memmap.msg_interrupt_configuration.mir_high_b[idx].midr);
			/* No level registers for MSG */
		}
	}
}

/*******************************************************************************/
static void get_intr_conf_regs_shared_msg(uint32_t **vpr, uint32_t **dr, uint32_t **lr, uint16_t idx)
{
	mpic_memmap_t *mpic_memmap = g_mpic_memmap;
	uint32_t msi_grp_offset = 0;

	while(idx >= NUM_OF_MSI_INTR_PER_GROUP)
	{
		idx -= NUM_OF_MSI_INTR_PER_GROUP;
		msi_grp_offset += (sizeof ( mpic_msi_interrupt_registers_memmap_t ) * (NUM_OF_LOW_MSI_INTR_PER_GROUP/4) );
		/* offset to the next group of (msi low msi group size)/(32bit)*/
	}
	if(idx < NUM_OF_LOW_MSI_INTR_PER_GROUP) //low interrupt
	{
		*vpr = (uint32_t *)(&(mpic_memmap->mpic_int_src_memmap.msi_interrupt_configuration.mir_low_a[idx].mivpr)+ (msi_grp_offset));
		*dr  = (uint32_t *)(&(mpic_memmap->mpic_int_src_memmap.msi_interrupt_configuration.mir_low_a[idx].midr)+ (msi_grp_offset));
		/* No level registers for MSG */
	}
	else //high interrupt
	{
		idx -= NUM_OF_LOW_MSI_INTR_PER_GROUP;
		*vpr = (uint32_t *)(&(mpic_memmap->mpic_int_src_memmap.msi_interrupt_configuration.mir_high_a[idx].mivpr)+ (msi_grp_offset));
		*dr  = (uint32_t *)(&(mpic_memmap->mpic_int_src_memmap.msi_interrupt_configuration.mir_high_a[idx].midr)+ (msi_grp_offset));
		/* No level registers for MSG */
	}
}

/*******************************************************************************/
void mpic_get_intr_config_regs(uint16_t grp, uint16_t idx, uint32_t **vpr,
                               uint32_t **dr, uint32_t **lr)
{
	mpic_memmap_t *mpic_memmap = g_mpic_memmap;
	uint32_t      *tmp_vpr = NULL;
	uint32_t      *tmp_dr = NULL;
	uint32_t      *tmp_lr = NULL;

	if (grp == MPIC_INTR_GROUP_INTERNAL) {
		get_intr_conf_regs_internal(&tmp_vpr, &tmp_dr, &tmp_lr, idx);
	}
	else if (grp == MPIC_INTR_GROUP_EXTERNAL) {
		get_intr_conf_regs_external(&tmp_vpr, &tmp_dr, &tmp_lr, idx);
	}
	else if (grp == MPIC_INTR_GROUP_TIMERS) {
		get_intr_conf_regs_timers(&tmp_vpr, &tmp_dr, &tmp_lr, idx);
	}
	else if (grp == MPIC_INTR_GROUP_MSG) {
		get_intr_conf_regs_msg(&tmp_vpr, &tmp_dr, &tmp_lr, idx);
	}
	else if (grp == MPIC_INTR_GROUP_SHARED_MSG) {
		get_intr_conf_regs_shared_msg(&tmp_vpr, &tmp_dr, &tmp_lr, idx);
	}
	else if (grp == MPIC_INTR_GROUP_IPI) {
		tmp_vpr = (uint32_t *)&(mpic_memmap->mpic_global_memmap.gcr.ipivp[idx].ipivpr);
		/* No destination and level registers for IPI */
	}

	if (vpr)
		*vpr = tmp_vpr;
	if (dr)
		*dr  = tmp_dr;
	if (lr)
		*lr  = tmp_lr;
}

#if 0
/****************************************************************************/
int osMpicGetMsiIndexReg(uint32_t mpic_intr_id, uint32_t **p_msiir1 ,uint8_t *msir_num)
{
	uint32_t *msiir1;
	uint32_t msi_grp_offset = 0;
	uint32_t msi_id;

	msi_id = MPIC_INTR_TO_IDX(mpic_intr_id);

	/* find the msi group */
	while(msi_id >= NUM_OF_MSI_INTR_PER_GROUP)
	{
		msi_id -= NUM_OF_MSI_INTR_PER_GROUP;
		msi_grp_offset+=((sizeof(mpic_global_shared_msi_index_grp_memmap_t))/4);
	}

	msiir1 = (uint32_t *)(&(g_soc_ccsr_map->mpic_memmap.mpic_global_memmap.global_shared_msi_index_grp[0].msiir1) + (msi_grp_offset));

	*msir_num = (uint8_t)msi_id;
	*p_msiir1 = msiir1;

	return 0;
}

/****************************************************************************/
int osMpicGetMsiCoalescingReg(uint32_t msi_id, uint32_t **p_msicr)
{
	uint32_t *msicr;
	uint32_t msi_grp_offset = 0;

	/* find the msi group */
	while(msi_id >= NUM_OF_MSI_INTR_PER_GROUP)
	{
		msi_id -= NUM_OF_MSI_INTR_PER_GROUP;
		msi_grp_offset+=((sizeof(mpic_global_shared_msi_index_grp_memmap_t))/4);
	}

	msicr = (uint32_t *)(&(g_soc_ccsr_map->mpic_memmap.mpic_global_memmap.global_shared_msi_index_grp[0].msicr[msi_id]) + (msi_grp_offset));

	*p_msicr = msicr;

	return 0;
}
#endif

#if 0
/*******************************************************************************/
static void     osMpicConfigureInterrupt(uint16_t grp, uint16_t idx)
{
	uint32_t            *p_vpr;
	uint32_t            vpr;
	uint16_t            intr_cfg_idx, intr_vector;


	intr_cfg_idx = ((uint16_t)(g_dsp_mpic_handle->intr_group_base_idx[grp]) + idx);
	intr_vector = g_dsp_mpic_handle->vector[intr_cfg_idx];
	OS_ASSERT_COND((intr_vector & VPR_VECTOR_MASK) == intr_vector);

	/* vpr modification - *interrupt is masked */
	vpr = (uint32_t)(VPR_MSK | intr_vector);

	/* Write interrupt configuration registers */
	mpic_get_intr_config_regs(grp, idx, &p_vpr, NULL, NULL);

	OS_ASSERT_COND(p_vpr);
	WRITE_UINT32(*p_vpr, (volatile uint32_t)vpr);
}
#endif
/*******************************************************************************/
void mpic_set_interrupt_mask(uint16_t grp, uint16_t idx, uint8_t intr_enable)
{
	uint32_t   *p_vpr;
	uint32_t   vpr;

	mpic_get_intr_config_regs(grp, idx, &p_vpr, NULL, NULL);

	ASSERT_COND(p_vpr);
	vpr = ioread32be(p_vpr);

	if (intr_enable)
		iowrite32be((volatile uint32_t)(vpr & ~(VPR_MSK)), p_vpr);
	else
		iowrite32be((volatile uint32_t)(vpr | VPR_MSK), p_vpr);

}

/*****************************************************************************/
static void osMpicSpuriousIsr(mpic_arg arg)
{
	UNUSED(arg);
	DEBUG_HALT;
}

/****************************************************************************/
int mpic_config(mpic_config_params_t *mpic_params,mpic_t **mpic_handle )
{
	mpic_t   *p_mpic;
	uint16_t    intr_count_by_group[] = MPIC_INTR_COUNT_BY_GROUP;
	uint32_t    i;

	/*Sanity check*/
	ASSERT_COND(mpic_params != NULL);

	/* MPIC handle initialize */
	p_mpic = (void *)&mpic_dev; // This only allows 1 MPIC in the system (mpic_config can only be called once)
	*mpic_handle = p_mpic;

	/* Store parameters */
	p_mpic->guest_id  = mpic_params->guest_id;

	/* Set interrupt count and base indices for all interrupt groups
       (Do not move to osMpicInit() - needed also in osMpicConfigInterruptSources) */
	p_mpic->intr_count_by_group[0] = intr_count_by_group[0];
	p_mpic->intr_group_base_idx[0] = 0;

	for (i=1; i < MPIC_NUM_OF_INTR_GROUPS; i++)
	{
		p_mpic->intr_count_by_group[i] = intr_count_by_group[i];
		p_mpic->intr_group_base_idx[i] = (uint16_t)(p_mpic->intr_group_base_idx[i-1] + intr_count_by_group[i-1]);
	}

	return 0;
}

/****************************************************************************/
#if 0
/* untested function for future support */
os_status osMpicConfigInterruptSources(mpic_t               *mpic_handle,
                                       uint16_t                num_of_intr_entries,
                                       os_mpic_intr_params_t   *intr_params)
{
	uint32_t    intr_cfg_idx, i, j;
	uint16_t    grp, idx;

	/*Sanity checks*/
	OS_ASSERT_COND(mpic_handle != NULL);
	OS_ASSERT_COND(intr_params != NULL);

#ifdef MPIC_ERROR_CHECK

	/* First pass - verify that interrupt sources are valid; This is only needed
       for safe access to the table - interrupt configuration will be checked during init. */
	for (i=0; i < num_of_intr_entries; i++)
	{
		grp = MPIC_INTR_GRP(intr_params[i].intr_id);
		idx = MPIC_INTR_IDX(intr_params[i].intr_id);

		OS_ASSERT_COND(grp < MPIC_NUM_OF_INTR_GROUPS);
		OS_ASSERT_COND(idx < mpic_handle->intr_count_by_group[grp]);

		intr_cfg_idx = (uint32_t)(mpic_handle->intr_group_base_idx[grp] + idx);
		OS_ASSERT_COND(intr_cfg_idx < MPIC_NUM_OF_INTR_SOURCES);

		/* Check if further entries conflict with current entry */
		for (j = i+1; j < num_of_intr_entries; j++)
		{
			if (IS_INTR_PAIR_SHARED(intr_params[i].intr_id, intr_params[j].intr_id))
			{
				if ((intr_params[i].priority != intr_params[j].priority) ||
					(intr_params[i].target   != intr_params[j].target  ) ||
					(intr_params[i].sense    != intr_params[j].sense   ) ||
					(intr_params[i].polarity != intr_params[j].polarity))
				{
					RETURN_ERROR(TODO);
				}
			}
		}
	}
#endif //MPIC_ERROR_CHECK

	/* store interrupt configuration */
	for (i=0; i < num_of_intr_entries; i++)
	{
		grp = MPIC_INTR_GRP(intr_params[i].intr_id);
		idx = MPIC_INTR_IDX(intr_params[i].intr_id);

		OS_ASSERT_COND(grp < MPIC_NUM_OF_INTR_GROUPS);
		intr_cfg_idx = (uint32_t)(mpic_handle->intr_group_base_idx[grp] + idx);

		mpic_handle->intr_config[intr_cfg_idx].priority = intr_params[i].priority;
		mpic_handle->intr_config[intr_cfg_idx].target   = intr_params[i].target;
		mpic_handle->intr_config[intr_cfg_idx].sense    = intr_params[i].sense;
		mpic_handle->intr_config[intr_cfg_idx].polarity = intr_params[i].polarity;
	}

	return OS_SUCCESS;
}
/****************************************************************************/
os_status osMpicConfigInterruptVectors(mpic_t                    *mpic_handle,
                                       uint16_t                     num_of_intr_entries,
                                       mpic_intr_vector_entry_t  *intr_vector_entries)
{
	uint32_t    intr_cfg_idx, i, j;
	uint16_t    grp, idx;

	/*Sanity checks*/
	OS_ASSERT_COND(mpic_handle != NULL);
	OS_ASSERT_COND(intr_vector_entries != NULL);

#ifdef  MPIC_ERROR_CHECK
	/* First pass - verify that interrupt indices are valid; This is only needed
       for safe access to the table - interrupt configuration will be checked during init. */
	for (i=0; i < num_of_intr_entries; i++)
	{
		grp = MPIC_INTR_GRP(intr_vector_entries[i].intr_id);
		idx = MPIC_INTR_IDX(intr_vector_entries[i].intr_id);

		OS_ASSERT_COND(grp < MPIC_NUM_OF_INTR_GROUPS);
		OS_ASSERT_COND(idx < mpic_handle->intr_count_by_group[grp]);

		intr_cfg_idx = (uint32_t)(mpic_handle->intr_group_base_idx[grp] + idx);
		OS_ASSERT_COND(intr_cfg_idx < MPIC_NUM_OF_INTR_SOURCES);

		/* Check if further entries conflict with current entry */
		for (j = i+1; j < num_of_intr_entries; j++)
		{
			if (!IS_INTR_PAIR_SHARED(intr_vector_entries[i].intr_id, intr_vector_entries[j].intr_id))
			{
				if (intr_vector_entries[j].vector == intr_vector_entries[i].vector)
				{
					RETURN_ERROR(TODO);
				}
			}
			else if (intr_vector_entries[j].vector != intr_vector_entries[i].vector)
			{
				RETURN_ERROR(TODO);
			}
		}
	}
#endif //MPIC_ERROR_CHECK

	/* store interrupt vector */
	for (i=0; i < num_of_intr_entries; i++)
	{
		grp = MPIC_INTR_GRP(intr_vector_entries[i].intr_id);
		idx = MPIC_INTR_IDX(intr_vector_entries[i].intr_id);

		OS_ASSERT_COND(grp < MPIC_NUM_OF_INTR_GROUPS);
		intr_cfg_idx = (uint32_t)(mpic_handle->intr_group_base_idx[grp] + idx);

		mpic_handle->intr_config[intr_cfg_idx].vector = intr_vector_entries[i].vector;
	}
	return OS_SUCCESS;
}
#endif //0

/****************************************************************************/
void mpic_clear_pending_core_interrupts()
{
	uint32_t i, iack;
	for (i=0; i < MPIC_NUM_OF_INTR_SOURCES; i++)
	{
		/**
		 * Reading IACK returns the interrupt vector corresponding to the highest priority pending interrupt
		 * and it also has the following side effects:
		 * The associated field in the corresponding interrupt pending register (IPR) is cleared for edge-sensitive interrupts.
		 * The corresponding in-service register (ISR) is updated.
		 * The corresponding int output signal from the MPIC is negated.
		 */
		iack = (volatile uint32_t)ioread32be(&(g_mpic_memmap->mpic_global_memmap.private_per_cpu_par.iack));
		iowrite32be(EOI_CODE, &(g_mpic_memmap->mpic_global_memmap.private_per_cpu_par.eoi));
	}

	UNUSED(iack);
	core_memory_barrier();

	iowrite32be(0, &(g_mpic_memmap->mpic_core_memmap.core_per_cpu_par[core_get_id()].per_cpu_par.ctpr));
	core_memory_barrier();
	core_instruction_sync();
}

/****************************************************************************/
int mpic_init()
{
	mpic_memmap_t       *mpic_memmap;
	uint32_t            total_isr_count = MPIC_NUM_OF_INTR_SOURCES + 1;
	volatile uint32_t   iack;
	uint16_t            i, j, multi_src_idx, multi_src_offset, multi_src_vector;
	mpic_multi_src_entry_t  multi_src_entries[] = MPIC_MULTI_SRC_INTERNAL_INTERRUPTS;
#if 0 /* the FRR sanity check can be enabled only with different targets for each derivative */
	uint32_t            frr, frr_num_of_irqs, frr_expected_irqs;
#endif // 0

	/*Sanity checks*/
	ASSERT_COND(g_mc_mpic_handle != NULL);

	mpic_memmap = g_mpic_memmap;

#if 0 /* the FRR sanity check can be enabled only with different targets for each derivative */
#ifdef MPIC_ERROR_CHECK
	/* Verify correct definition of interrupt sources number */
	frr = GET_UINT32(mpic_memmap->mpic_global_memmap.gcr.frr);
	frr_num_of_irqs = (uint32_t)(((frr & FRR_NIRQ_MASK) >> FRR_NIRQ_SHIFT) + 1);
	frr_expected_irqs = FRR_EXPECTED_NIRQ;

	OS_ASSERT_COND(frr_num_of_irqs == frr_expected_irqs);
#else
	VAR_UNUSED(frr_expected_irqs);
	VAR_UNUSED(frr);
	VAR_UNUSED(frr_num_of_irqs);
#endif //MPIC_ERROR_CHECK
#endif // 0

	/* totalIsrCount is initialized to MPIC_NUM_OF_INTR_SOURCES + 1 (spurious).
       We also need to add entries for multi-source interrupt handlers */
	for (i=0; i < __ARRAY_SIZE(multi_src_entries); i++)
		total_isr_count += multi_src_entries[i].num_of_sources;

	/* Initialize interrupt service table */
	for (i=0; i < total_isr_count; i++)
	{
		/* Single device per interrupt source */
		g_mc_mpic_handle->isr_table[i].isr = mpic_unassigned_isr;
		g_mc_mpic_handle->isr_table[i].arg = (mpic_arg)i;  /* For error reporting */
	}

	/* Initialize multi-source interrupt handlers */
	multi_src_offset = (uint16_t)(MPIC_NUM_OF_INTR_SOURCES + 1/* spurious */);

	for (i=0; i < __ARRAY_SIZE(multi_src_entries); i++)
	{
		multi_src_idx    = (uint16_t)(g_mc_mpic_handle->intr_group_base_idx[MPIC_INTR_GROUP_INTERNAL] + multi_src_entries[i].index);
		multi_src_vector = multi_src_idx;

		if(multi_src_entries[i].num_of_sources != 0) {
			g_mc_mpic_handle->isr_table[multi_src_vector].isr  = mpic_multi_source_isr;
			g_mc_mpic_handle->isr_table[multi_src_vector].arg =
				MPIC_MAKE_MULTI_SRC_HANDLE(multi_src_offset, multi_src_entries[i].num_of_sources);
		}

		multi_src_offset += multi_src_entries[i].num_of_sources;
	}

	UNUSED(multi_src_offset);

	/* Set the dedicated ISR to the ORed error interrupt */
	//    g_mc_mpic_handle->isr_table[MPIC_ORED_ERROR_VECTOR].isr = osMpicErrorIsr;
	/* Set the spurious interrupt handler in the last entry */
	g_mc_mpic_handle->isr_table[MPIC_NUM_OF_INTR_SOURCES].isr = osMpicSpuriousIsr;
	g_mc_mpic_handle->isr_table[MPIC_NUM_OF_INTR_SOURCES].arg = 0;

	/* Initialize g_mc_mpic_handle registers in master mode only */
	if (g_mc_mpic_handle->guest_id == mpic_get_master_core())
	{
		/**
		 * Set spurious interrupt vector.
		 * Under certain circumstances, the MPIC has no valid vector to return to a processor core during an interrupt acknowledge cycle.
		 * In these cases, the spurious vector from the spurious vector register is returned.
		 */
		iowrite32be((uint32_t)MPIC_NUM_OF_INTR_SOURCES, &(mpic_memmap->mpic_global_memmap.gcr.svr));

		/* Set Mixed mode */
		iowrite32be(ioread32be(&(mpic_memmap->mpic_global_memmap.gcr.gcr)) | GCR_MIXED_MODE, &(mpic_memmap->mpic_global_memmap.gcr.gcr));

		/* Enable message interrupts */
		iowrite32be(MER_INIT_MASK, &(mpic_memmap->mpic_global_memmap.global_msg_a.mer));
		iowrite32be(MER_INIT_MASK, &(mpic_memmap->mpic_global_memmap.global_msg_b.mer));

		/* Read IACK repeatedly to clear all pending and in-service registers  for all DSP cores*/
		for (i=0; i <sys_get_max_num_of_cores(); i++)
		{
			for (j=0; j < MPIC_NUM_OF_INTR_SOURCES; j++)
			{
				/**
				 * Reading IACK returns the interrupt vector corresponding to the highest priority pending interrupt
				 * and it also has the following side effects:
				 * The associated field in the corresponding interrupt pending register (IPR) is cleared for edge-sensitive interrupts.
				 * The corresponding in-service register (ISR) is updated.
				 * The corresponding int output signal from the MPIC is negated.
				 */
				iack = (volatile uint32_t)ioread32be(&(mpic_memmap->mpic_core_memmap.core_per_cpu_par[i].per_cpu_par.iack));
				iowrite32be(EOI_CODE, &(mpic_memmap->mpic_core_memmap.core_per_cpu_par[i].per_cpu_par.eoi));
			}
		}
	}

	/* Set Task Priority threshold to 0 to enable all interrupts */
	for (i = 0; i< sys_get_max_num_of_cores(); i++)
		iowrite32be(0, &(mpic_memmap->mpic_core_memmap.core_per_cpu_par[i].per_cpu_par.ctpr));

	g_mc_mpic_handle->initialized = 0x1;

	return 0;
}



