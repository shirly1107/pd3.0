/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_core.h"
#include "fsl_io.h"
#include "fsl_dbg.h"

#include "drivers/fsl_mcpic.h"

#include "mpic_memmap.h"
#include "ls2085_mc_mpic_init.h"

void pic_isr(void *handle);

int mcpic_init(void *regs)
{
	return  mpic_initialize(regs);
}

void mcpic_free(void *regs)
{

}

void pic_isr(void * handle)
{
	extern mpic_memmap_t * g_mpic_memmap;
	uint32_t iack;

	iack = ioread32be(&(g_mpic_memmap->mpic_global_memmap.private_per_cpu_par.iack));
	ASSERT_COND(g_mc_mpic_handle->isr_table[iack].isr != NULL);
	g_mc_mpic_handle->isr_table[iack].isr(g_mc_mpic_handle->isr_table[iack].arg);
	iowrite32(1, &(g_mpic_memmap->mpic_global_memmap.private_per_cpu_par.eoi));
}
