/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_MPIC_H
#define __FSL_MPIC_H

#include "fsl_types.h"
/**************************************************************************//**
 @Group        mpic_id   MPIC Module API

 @Description   MPIC Module API.
 
 @{
*//***************************************************************************/

typedef uint32_t mpic_arg; // debug only
typedef void (*mpic_isr)(mpic_arg); // debug only

/**************************************************************************//**
 @Group         mpic_runtime_id  MPIC runtime API

 @Description   MPIC runtime API.
 
 @{
*//***************************************************************************/
/**************************************************************************//**
 @Description   MPIC interrupt target selection
 
 Internal Interrupt Level Registers (IILR0�IILR255)
*//***************************************************************************/
typedef enum mpic_intr_target 
{
    OS_MPIC_INTR_TARGET_DEFAULT,          /**< Default interrupt line (core int) */
    OS_MPIC_INTR_TARGET_CRITICAL,         /**< Critical interrupt line (core cint) */
    OS_MPIC_INTR_TARGET_IRQ_OUT,           /**< IRQ_OUT signal for external processing */
    OS_MPIC_INTR_TARGET_MACHINE_CHECK,    /**< Machine check interrupt line (core mcp) */
    OS_MPIC_INTR_TARGET_SOC_INTR_0,       /**< SoC-specific interrupt routing (option 0) */
    OS_MPIC_INTR_TARGET_SOC_INTR_1,       /**< SoC-specific interrupt routing (option 1) */
    OS_MPIC_INTR_TARGET_SOC_INTR_2        /**< SoC-specific interrupt routing (option 2) */
} mpic_intr_target_t;

/**************************************************************************//**
 @Description   MPIC interrupt sense modes (external interrupts only)
*//***************************************************************************/
typedef enum mpic_intr_sense
{
    OS_MPIC_INTR_SENSE_EDGE,              /**< Interrupt is edge-sensitive */
    OS_MPIC_INTR_SENSE_LEVEL              /**< Interrupt is level-sensitive */
} mpic_intr_sense_t;

/**************************************************************************//**
 @Description   MPIC interrupt polarity modes (internal/external interrupts only)
*//***************************************************************************/
typedef enum mpic_intr_polarity
{
    OS_MPIC_INTR_POLARITY_LOW,            /**< For edge-sensitive interrupts: high-to-low triggered;
                                             For level-sensitive interrupts: active-low */
    OS_MPIC_INTR_POLARITY_HIGH            /**< For edge-sensitive interrupts: low-to-high triggered;
                                             For level-sensitive interrupts: active-high */
} mpic_intr_polarity_t;

/**************************************************************************//**
 @Description   MPIC default interrupt parameters (internal/external interrupts only)
*//***************************************************************************/
#define MPIC_VPR_PRIORITY_SET(priority) priority << VPR_PRIORITY_SHIFT /**< use to set priority in vpr register */
#define MPIC_DEFAULT_PRIORITY    1                              /**< Default interrupt priority - lowest priority 1*/
#define MPIC_DEFAULT_POLARITY    OS_MPIC_INTR_POLARITY_LOW      /**< Default interrupt polarity -  active-low */
#define MPIC_DEFAULT_SENSE       OS_MPIC_INTR_SENSE_EDGE        /**< Default interrupt sense edge-sensitive */
#define MPIC_DEFAULT_TARGET      OS_MPIC_INTR_TARGET_DEFAULT   /**< Default interrupt line (core int) */

/**************************************************************************//**
 @Description   MPIC Interrupt Configuration Parameters
*//***************************************************************************/
typedef struct mpic_intr_params
{
    uint8_t             priority;   /**< Interrupt priority:
                                         0 disabled, 1 lowest, ... 15 highest */
    mpic_intr_target_t     target;     /**< Interrupt target selection */
    mpic_intr_sense_t      sense;      /**< Interrupt sense (external interrupts only) */
    mpic_intr_polarity_t   polarity;   /**< Interrupt polarity (internal/external interrupts only) */

} mpic_intr_params_t;
/**************************************************************************//**
 @Description   Interrupt table definition.
*//***************************************************************************/
typedef struct mpic_isr_entry
{
        mpic_isr       isr;     /**< Interrupt service routine (ISR) */
        mpic_arg       arg;     /**< Argument for the ISR */
} mpic_isr_entry_t;

/**************************************************************************//**
 @Function      mpic_set_config_intr

 @Description   Registration of an interrupt source.

 @Param[in]     mpic_intr_id  - Interrupt ID as defined by os_mpic_intr_id.
 @Param[in]     dest_core_id  - Destination core
 @Param[in]     isr           - Callback routine to be called when interrupt occurs;
 @Param[in]     arg           - This argument will be passed in the isr callback.
 @Param[in]     intr_params   - This argument contain the requested interrupt parameters.

 @Return        OS_SUCCESS on success; Error code otherwise.
*//****************************************************************************/
int mpic_set_config_intr(uint32_t mpic_intr_id, uint32_t dest_core_id, mpic_isr isr, mpic_arg arg, mpic_intr_params_t *intr_params);

#define mpic_set_intr(mpic_intr_id,dest_core,isr,arg)    mpic_set_config_intr(mpic_intr_id,dest_core,isr,arg,NULL)
    /**< Function osMpicSetIntr - sets interrupt with default parameters*/

#if 0
/* untested function for future support */
/**************************************************************************//**
 @Function      osMpicInterruptCores

 @Description   Issue inter-processor interrupt (IPI) to one or more cores on
                the device.

                User can select one of four IPI events, and to specify one or
                more cores to interrupt (including itself).

 @Param[in]     ipi_event   - IPI event to signal (valid values: 0-MPIC_NUM_OF_IPI_EVENTS).
 @Param[in]     cores_mask  - Cores mask - user should set one or more bits per
                              interrupted core, where the least significant bit
                              represents core 0, and so on; other bits must
                              be cleared.

 @Return        OS_SUCCESS on success; Error code otherwise.
*//***************************************************************************/
os_status osMpicInterruptCores(uint8_t ipi_event, uint32_t cores_mask);
#endif // 0

/**************************************************************************//**
 @Function      mpic_write_msg

 @Description   Write one of the message registers to issue a message interrupt
                to the assigned core.

                The message interrupts can be used as a doorbell mechanism
                between cores. The user writes a 32-bit data to one of the
                message registers. When this value is written, the core assigned
                to that interrupt is interrupted and may read the message data
                using the osMpicReadMessage() routine.

                Cores are assigned to message interrupts as with any other
                interrupt, using the osMpicSetIntr() routine.

 @Param[in]     mpic_intr_id - Interrupt ID as defined by os_mpic_intr_id.
 @Param[in]     msg_data     - The message data to write (up to 32-bits).
 @Param[in]     blocking     - FALSE to return after the message is written;
                               TRUE to block until the message is read;
                               Note that blocking mode has no timeout, and it is
                               not recommended to use blocking mode when running
                               in interrupt context.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int mpic_write_msg(uint32_t mpic_intr_id, uint32_t msg_data, uint8_t blocking);

/**************************************************************************//**
 @Function      mpic_read_msg

 @Description   Read one of the message registers to retrieve its 32-bit data.

                The message interrupts can be used as a doorbell mechanism
                between cores. The user writes a 32-bit data to one of the
                message registers via osMpicWriteMessage() routine. When this
                value is written, the core assigned to that interrupt is
                interrupted and may read the message data using this routine.

                Cores are assigned to message interrupts as with any other
                interrupt, using the osMpicSetIntr() routine.

                This routine may be called by the message interrupt handler,
                or even in polling mode (without registering for the interrupt).
                In polling mode, the return value indicates whether a message was
                pending (in which case the returned message data is valid).

 @Param[in]     mpic_intr_id    - Interrupt ID as defined by os_mpic_intr_id.
 @Param[out]    msg_data        - Returns the message data (up to 32-bits) only if
                                  a message was pending.

 @Return        TRUE if a message was pending on the given message ID; FALSE otherwise.
*//***************************************************************************/
uint8_t mpic_read_msg(uint32_t mpic_intr_id, uint32_t *msg_data);

/**************************************************************************//**
 @Function      mpic_reset

 @Description   Reset MPIC.

 @Cautions      Needs to be used only by the MPIC owner.

 @Return        None.
*//***************************************************************************/
void mpic_reset();
/**************************************************************************//**
 @Function      mpic_enable_intr

 @Description   Unmask (enable) a specific interrupt source.

 @Param[in]     mpic_intr_id   - Interrupt ID as defined by os_mpic_intr_id.

 @Return       OS_SUCCESS on success; Error code otherwise.
*//***************************************************************************/
int mpic_enable_intr(uint32_t mpic_intr_id);

/**************************************************************************//**
 @Function      mpic_disable_intr

 @Description   Mask (disable) a specific interrupt source.

 @Param[in]     mpic_intr_id   - Interrupt ID as defined by os_mpic_intr_id.

 @Return        OS_SUCCESS on success; Error code otherwise.
*//***************************************************************************/
int mpic_disable_intr(uint32_t mpic_intr_id);

#if 0
/**************************************************************************//**
 @Function      osMpicWriteMsi

 @Description   Invoke an interrupt to the assigned signal.

 @Param[in]     mpic_intr_id - Interrupt ID as defined by os_mpic_intr_id.    
 @Param[out]    signal       - The assigned signal (valid values: 0-31).

 @Return        OS_SUCCESS on success; Error code otherwise.
*//***************************************************************************/
os_status osMpicWriteMsi(uint32_t mpic_intr_id, uint8_t signal);

/**************************************************************************//**
 @Function      osMpicMsiCoalescingConfig

 @Description   Configure the coalescing settings for one of the MSI.

 @Param[in]     mpic_intr_id    - Interrupt ID as defined by os_mpic_intr_id.
 @Param[out]    coalescing_mask - The signals included in coalescing.  (up to 32-bits).

 @Return        OS_SUCCESS on success; Error code otherwise.
*//***************************************************************************/
os_status osMpicMsiCoalescingConfig(uint32_t mpic_intr_id, uint32_t coalescing_mask);

/**************************************************************************//**
 @Function      osMpicReadMsiSignalRegister

 @Description   Reads the signals from the MSI message registe.

 @Param[in]     mpic_intr_id - Interrupt ID as defined by os_mpic_intr_id.
 @Param[out]    msir         - Pointer to the signals register.

 @Return        OS_SUCCESS on success; Error code otherwise.
*//***************************************************************************/
os_status osMpicReadMsiSignalRegister(uint32_t mpic_intr_id, uint32_t *msir);
#endif // 0

/**************************************************************************//**
 @Function      mpic_free_intr

 @Description   Deregistration of an interrupt source.

 @Param[in]     mpic_intr_id   - Interrupt ID as defined by os_mpic_intr_id.

 @Return        OS_SUCCESS on success; Error code otherwise.
*//***************************************************************************/
int mpic_free_intr(uint32_t mpic_intr_id); 

#if 0
/* untested function for future support */
/**************************************************************************//**
 @Function      osMpicFindMsgIntr

 @Description   Returns the interrupt id of an unused message interrupt.

 @Param[in]    mpic_intr_id - Interrupt ID as defined by os_mpic_intr_id.

 @Return        OS_SUCCESS on success; Error code otherwise.
 
 @Cautions      This function is not multi-core safe!
*//***************************************************************************/
os_status osMpicFindMsgIntr(uint32_t *mpic_intr_id);

/**************************************************************************//**
 @Function      osMpicFindMsiIntr

 @Description   Returns the interrupt id of an unused MSI interrupt.

 @Param[in]     mpic_intr_id    - Pointer to hold the free interrupt ID as defined by os_mpic_intr_id.

 @Return        OS_SUCCESS on success; Error code otherwise.
 
 @Cautions      This function is not multi-core safe!
*//***************************************************************************/
os_status osMpicFindMsiIntr(uint32_t *mpic_intr_id);
#endif // 0

/*****************************************************************************/
/** @} */ // mpic_runtime_id
/** @} */ // mpic_id

#endif // __FSL_MPIC_H
