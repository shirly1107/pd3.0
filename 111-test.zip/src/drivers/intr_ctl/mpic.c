/*
 * Copyright 2013-2020 NXP
 */


#include "fsl_types.h"
#include "fsl_io.h"
#include "mpic.h"
#include "fsl_mpic.h"
#include "mpic_memmap.h"
#include "fsl_dbg.h"

extern mpic_t *g_mc_mpic_handle;

mpic_memmap_t * g_mpic_memmap;

/*****************************************************************************/
static inline uint8_t osMpicIsMultiSrcVector(uint16_t intr_vector)
{
	return (uint8_t)((g_mc_mpic_handle->isr_table[intr_vector].isr == (mpic_isr)mpic_multi_source_isr)||
		(g_mc_mpic_handle->isr_table[intr_vector].isr == (mpic_isr)mpic_error_isr));
}

/*****************************************************************************/
static int osMpicParseIntrId(uint32_t   mpic_intr_id,
                             uint16_t  *p_grp,
                             uint16_t  *p_idx,
                             uint16_t  *p_intr_vector,
                             uint16_t  *p_isr_index,
                             uint16_t  *p_multi_src_idx)
{
	uint16_t    grp = MPIC_INTR_GRP(mpic_intr_id);
	uint16_t    idx = MPIC_INTR_IDX(mpic_intr_id);
	uint16_t    multi_src_idx = MPIC_MULTI_SRC_IDX(mpic_intr_id);
	uint16_t    intr_cfg_idx, intr_vector, isr_index, isr_count;
	/* sanity checks */
	ASSERT_COND(grp < MPIC_NUM_OF_INTR_GROUPS);
	ASSERT_COND(idx < g_mc_mpic_handle->intr_count_by_group[grp]);

	intr_cfg_idx = (uint16_t)(g_mc_mpic_handle->intr_group_base_idx[grp] + idx);
	ASSERT_COND(intr_cfg_idx < MPIC_NUM_OF_INTR_SOURCES);

	intr_vector = isr_index = intr_cfg_idx;

	if (osMpicIsMultiSrcVector(intr_vector))
	{
		/* Interrupt source with multiple handlers */
		isr_index = MPIC_MULTI_SRC_OFFSET(g_mc_mpic_handle->isr_table[intr_vector].arg);
		isr_count = MPIC_MULTI_SRC_COUNT(g_mc_mpic_handle->isr_table[intr_vector].arg);

		ASSERT_COND(multi_src_idx < isr_count);
		isr_index += multi_src_idx;
	}

	/* Return requested information */
	*p_grp            = grp;
	*p_idx            = idx;
	*p_intr_vector    = intr_vector;
	*p_isr_index      = isr_index;
	*p_multi_src_idx  = multi_src_idx;

	return 0;
}

#if 0
/*****************************************************************************/
int osMpicFindMsiIntr(uint32_t *mpic_intr_id)
{
	os_status   status = OS_SUCCESS;
	uint32_t i,idx;

	/* sanity check */
	OS_ASSERT_COND(g_mc_mpic_handle != NULL);
	OS_ASSERT_COND(g_mc_mpic_handle->initialized == TRUE);


	idx = g_mc_mpic_handle->intr_group_base_idx[OS_MPIC_INTR_GROUP_SHARED_MSG];
	for (i = 0; i < g_mc_mpic_handle->intr_count_by_group[OS_MPIC_INTR_GROUP_SHARED_MSG]; i++, idx++ )
	{
		if (g_mc_mpic_handle->isr_table[idx].isr == mpic_unassigned_isr)
			break;
	}

	if (i == g_mc_mpic_handle->intr_count_by_group[OS_MPIC_INTR_GROUP_SHARED_MSG])
		status = OS_FAIL;

	*mpic_intr_id = OS_MPIC_INTR_SHARED_MSG_0 +i;

	return status;
}
#endif // 0

static void mpic_config_intr_lr(uint32_t *lr, mpic_intr_target_t target)
{
	/* configure which signal is asserted */
	switch(target)
	{
	case OS_MPIC_INTR_TARGET_CRITICAL:
		*lr = LR_INTTGT_CINT; break;
	case OS_MPIC_INTR_TARGET_MACHINE_CHECK:
		*lr = LR_INTTGT_MCP; break;
	case OS_MPIC_INTR_TARGET_SOC_INTR_0:
		*lr = LR_INTTGT_SIE0; break;
	case OS_MPIC_INTR_TARGET_SOC_INTR_1:
		*lr = LR_INTTGT_SIE1; break;
	case OS_MPIC_INTR_TARGET_SOC_INTR_2:
		*lr = LR_INTTGT_SIE2; break;
	case OS_MPIC_INTR_TARGET_IRQ_OUT:
		*lr = LR_INTTGT_IRQ_OUT; break;
	default: break;//OS_MPIC_INTR_TARGET_DEFAULT
	}
}

/*****************************************************************************/
int mpic_set_config_intr(uint32_t mpic_intr_id, uint32_t dest_core_id, mpic_isr isr, mpic_arg arg, mpic_intr_params_t *intr_params)
{
	uint32_t            *p_dr, *p_vpr, *p_lr;
	uint32_t            vpr,lr = MPIC_DEFAULT_TARGET;
	uint32_t            core_id = dest_core_id; /*core_get_id();*/
	uint16_t            grp, idx, isr_index, intr_vector, multi_src_idx;
	int                 status;
	mpic_intr_params_t __intr_params;

	ASSERT_COND(core_id < sys_get_max_num_of_cores());

	/* sanity check */
	ASSERT_COND(g_mc_mpic_handle != NULL);
	ASSERT_COND(g_mc_mpic_handle->initialized != 0);

	/* Driver requirement is that ISR is aligned to 4 bytes at least */
	//    ASSERT_COND(((uint32_t )isr & 0x3) == 0);
	status = osMpicParseIntrId(mpic_intr_id, &grp, &idx, &intr_vector, &isr_index, &multi_src_idx);
	ASSERT_COND(status == 0);

	if (intr_params != NULL)
	{
		__intr_params = *intr_params;
	}
	else
	{
		// set default
		__intr_params.polarity = MPIC_DEFAULT_POLARITY;
		__intr_params.priority = MPIC_DEFAULT_PRIORITY;
		__intr_params.sense    = MPIC_DEFAULT_SENSE;
		__intr_params.target   = MPIC_DEFAULT_TARGET;
	}

	/* vpr modification - *interrupt is masked */
	vpr = VPR_MSK;
	vpr |= MPIC_VPR_PRIORITY_SET(__intr_params.priority);

	if (__intr_params.polarity)
		vpr |= VPR_P;

	if (__intr_params.sense)
		vpr |= VPR_S;

	/* configure which signal is asserted */
	mpic_config_intr_lr(&lr, __intr_params.target);

	ASSERT_COND(g_mc_mpic_handle->isr_table[isr_index].isr == mpic_unassigned_isr);

	/* Set the ISR and its handle argument in the interrupt service table */
	g_mc_mpic_handle->isr_table[isr_index].isr = isr;
	g_mc_mpic_handle->isr_table[isr_index].arg = arg;

	mpic_get_intr_config_regs(grp, idx, &p_vpr, &p_dr, &p_lr);

	/* Update the vector (assignment is per core) and the core ID */
	ASSERT_COND(p_vpr); // reset value is VPR[MSK] = 1
	vpr |= intr_vector;

	iowrite32be((volatile uint32_t)vpr, p_vpr);

	if (p_lr)
		iowrite32be((volatile uint32_t)lr, p_lr);

	if(p_dr)
		iowrite32be((volatile uint32_t)(DR_P0 << core_id), p_dr);

	return 0;
}

/*****************************************************************************/
int mpic_free_intr(uint32_t mpic_intr_id)
{
	int status;
	uint16_t    grp, idx, isr_index, intr_vector, multi_src_idx;

	/*  Sanity check    */
	ASSERT_COND(g_mc_mpic_handle != NULL);
	ASSERT_COND(g_mc_mpic_handle->initialized != 0);

	status = osMpicParseIntrId(mpic_intr_id, &grp, &idx, &intr_vector, &isr_index, &multi_src_idx);
	ASSERT_COND(status == 0);

	ASSERT_COND(g_mc_mpic_handle->isr_table[isr_index].isr != mpic_unassigned_isr);

	g_mc_mpic_handle->isr_table[isr_index].isr  = mpic_unassigned_isr;
	g_mc_mpic_handle->isr_table[isr_index].arg = (mpic_arg)isr_index; /* For error reporting */

	return 0;
}

/*****************************************************************************/
int mpic_enable_intr(uint32_t mpic_intr_id)
{
	int         status;
	uint8_t     do_enable = 0x1;
	uint16_t    grp, idx, en_count, isr_index, intr_vector, multi_src_idx;

	/*  Sanity check    */
	ASSERT_COND(g_mc_mpic_handle != NULL);
	ASSERT_COND(g_mc_mpic_handle->initialized != 0);

	status = osMpicParseIntrId(mpic_intr_id, &grp, &idx, &intr_vector, &isr_index, &multi_src_idx);
	ASSERT_COND(status == 0);

	ASSERT_COND(g_mc_mpic_handle->isr_table[isr_index].isr != mpic_unassigned_isr);

	if (osMpicIsMultiSrcVector(intr_vector))
	{
		if (!MPIC_ISR_ENABLED(g_mc_mpic_handle->isr_table[isr_index].isr))
		{
			en_count = MPIC_MULTI_SRC_EN_COUNT(g_mc_mpic_handle->isr_table[intr_vector].arg);
			MPIC_MULTI_SRC_INCREMENT(g_mc_mpic_handle->isr_table[intr_vector].arg);
			do_enable = (uint8_t)(en_count == 0);

			/* Mark the interrupt as enabled */
			MPIC_ISR_ENABLE(g_mc_mpic_handle->isr_table[isr_index].isr);
		}
		else
			do_enable = 0;

		if (g_mc_mpic_handle->isr_table[intr_vector].isr == mpic_error_isr)
		{
			/* Check unmask of relevant bit of ORed error interrupt */
			ASSERT_COND(((g_mpic_memmap->mpic_global_memmap.global_interrupt_summary.eimr0) & (EISR_EVENT_MASK >> multi_src_idx)) == 0);
		}
	}

	if (do_enable)
	{
		/* Unmask the interrupt */
		mpic_set_interrupt_mask(grp, idx, 0x1);
	}

	return 0;
}

/*****************************************************************************/
int mpic_disable_intr(uint32_t mpic_intr_id)
{
	int         status;
	uint8_t     do_disable = 0x1;
	uint16_t    grp, idx, en_count, isr_index, intr_vector, multi_src_idx;

	/*  Sanity check    */
	ASSERT_COND(g_mc_mpic_handle != NULL);
	ASSERT_COND(g_mc_mpic_handle->initialized != 0);

	status = osMpicParseIntrId(mpic_intr_id, &grp, &idx, &intr_vector, &isr_index, &multi_src_idx);
	ASSERT_COND(status == 0);

	ASSERT_COND(g_mc_mpic_handle->isr_table[isr_index].isr != mpic_unassigned_isr);

	if (osMpicIsMultiSrcVector(intr_vector))
	{
		if (MPIC_ISR_ENABLED(g_mc_mpic_handle->isr_table[isr_index].isr))
		{
			en_count = MPIC_MULTI_SRC_EN_COUNT(g_mc_mpic_handle->isr_table[intr_vector].arg);
			MPIC_MULTI_SRC_DECREMENT(g_mc_mpic_handle->isr_table[intr_vector].arg);
			do_disable = (uint8_t)(en_count == 1);

			/* Mark the interrupt as disabled */
			MPIC_ISR_DISABLE(g_mc_mpic_handle->isr_table[isr_index].isr);
		}
		else
			do_disable = 0;
	}

	if (do_disable)
	{
		/* Mask the interrupt */
		mpic_set_interrupt_mask(grp, idx, 0);
	}

	return 0;
}
#if 0
/* untested function for future support */
/*****************************************************************************/
os_status osMpicInterruptCores(uint8_t ipi_event, uint32_t cores_mask)
{
	/*  Sanity check    */
	OS_ASSERT_COND(g_mc_mpic_handle != NULL);
	OS_ASSERT_COND(g_mc_mpic_handle->initialized == TRUE);
	OS_ASSERT_COND(ipi_event<MPIC_NUM_OF_IPI_EVENTS);
	OS_ASSERT_COND(cores_mask!=0);
	OS_ASSERT_COND(!(cores_mask & ~(MPIC_ALL_PROCESSORS_MASK)));

	WRITE_UINT32(g_soc_ccsr_map->mpic_memmap.mpic_global_memmap.private_per_cpu_par.ipid[ipi_event].ipidr, cores_mask);

	return OS_SUCCESS;
}
#endif

/*****************************************************************************/
int mpic_write_msg(uint32_t mpic_intr_id, uint32_t msg_data, uint8_t blocking)
{
	volatile uint32_t   *p_msgr, *p_msr;
	uint32_t msg_id;

	ASSERT_COND(g_mc_mpic_handle != NULL);
	ASSERT_COND(g_mc_mpic_handle->initialized != 0);

	msg_id = MPIC_INTR_TO_IDX(mpic_intr_id);
	ASSERT_COND(msg_id<MPIC_NUM_OF_MSG_INTRS);

	if (msg_id < NUM_OF_MSG_INTR_PER_GROUP)
	{
		p_msgr = (uint32_t *)(&(g_mpic_memmap->mpic_global_memmap.global_msg_a.msgr[msg_id].msg));
		p_msr  = (uint32_t *)&(g_mpic_memmap->mpic_global_memmap.global_msg_a.msr);
	}
	else
	{
		msg_id -= NUM_OF_MSG_INTR_PER_GROUP;
		ASSERT_COND(msg_id < NUM_OF_MSG_INTR_PER_GROUP);

		p_msgr = (uint32_t *)&(g_mpic_memmap->mpic_global_memmap.global_msg_b.msgr[msg_id].msg);
		p_msr  = (uint32_t *)&(g_mpic_memmap->mpic_global_memmap.global_msg_b.msr);
	}

	iowrite32be(msg_data, p_msgr);
	core_memory_barrier();

	/* In blocking mode, wait until the message is read */
	if (blocking)
		while ((*p_msr) & (1 << msg_id)) ;

	return 0;
}

/*****************************************************************************/
uint8_t mpic_read_msg(uint32_t mpic_intr_id, uint32_t *msg_data)
{
	uint32_t   *p_msgr;
	uint32_t   msr,msg_id;

	/* sanity checks */
	ASSERT_COND(g_mc_mpic_handle != NULL);
	ASSERT_COND(g_mc_mpic_handle->initialized != 0);

	msg_id = MPIC_INTR_TO_IDX(mpic_intr_id);

	ASSERT_COND(msg_data != NULL);
	ASSERT_COND(msg_id<MPIC_NUM_OF_MSG_INTRS);

	if (msg_id < NUM_OF_MSG_INTR_PER_GROUP)
	{
		p_msgr = (uint32_t *)&(g_mpic_memmap->mpic_global_memmap.global_msg_a.msgr[msg_id].msg);
		msr  = ioread32be(&(g_mpic_memmap->mpic_global_memmap.global_msg_a.msr));
	}
	else
	{
		msg_id -= NUM_OF_MSG_INTR_PER_GROUP;
		ASSERT_COND(msg_id < NUM_OF_MSG_INTR_PER_GROUP);

		p_msgr = (uint32_t *)&(g_mpic_memmap->mpic_global_memmap.global_msg_b.msgr[msg_id].msg);
		msr  = ioread32be( &(g_mpic_memmap->mpic_global_memmap.global_msg_b.msr));
	}

	/* This check allows the function to be called in polling mode */
	if (msr & (uint32_t)(1 << msg_id))
	{
		*msg_data = (volatile uint32_t)ioread32be(p_msgr);
		return 1;
	}

	return 0; /* No message is pending */
}

#if 0
/***************************************************************************/
os_status osMpicWriteMsi(uint32_t mpic_intr_id, uint8_t signal)
{
	os_status status = OS_SUCCESS;
	uint32_t *p_msiir1;
	uint32_t msiir1,msi_id;
	uint8_t msir_num;

	/* sanity checks */
	OS_ASSERT_COND(g_mc_mpic_handle != NULL);
	OS_ASSERT_COND(g_mc_mpic_handle->initialized == TRUE);

	msi_id = MPIC_INTR_TO_IDX(mpic_intr_id);
	OS_ASSERT_COND(msi_id < MPIC_NUM_OF_SMSG_INTRS);
	OS_ASSERT_COND(signal < 32);

	/* invoking interrupt */
	status = osMpicGetMsiIndexReg(msi_id,&p_msiir1,&msir_num);
	msiir1 = MPIC_SET_MSIIR_MASK(msir_num,signal);


	WRITE_UINT32_DBAR_SCFG(*p_msiir1, (volatile)msiir1);

	return status;
}

/***************************************************************************/
os_status osMpicReadMsiSignalRegister(uint32_t mpic_intr_id,  uint32_t *msir)
{
	uint32_t *p_msir;
	uint32_t msi_id,msi_grp_offset = 0;

	msi_id = MPIC_INTR_TO_IDX(mpic_intr_id);
	/* find the msi group */
	while(msi_id >= NUM_OF_MSI_INTR_PER_GROUP)
	{
		msi_id -= NUM_OF_MSI_INTR_PER_GROUP;
		msi_grp_offset += ((sizeof(mpic_global_shared_massage_memmap_t))/4);
	}

	p_msir = (uint32_t *)(&(g_soc_ccsr_map->mpic_memmap.mpic_global_memmap.global_shared_msg_a.msir[msi_id].msg) + (msi_grp_offset));

	*msir = *p_msir;

	return OS_SUCCESS;
}


/***************************************************************************/
os_status osMpicMsiCoalescingConfig(uint32_t mpic_intr_id, uint32_t coalescing_mask)
{
	os_status status = OS_SUCCESS;
	uint32_t *p_msicr;
	uint32_t msi_id;

	/* sanity check */
	OS_ASSERT_COND(g_mc_mpic_handle != NULL);
	OS_ASSERT_COND(g_mc_mpic_handle->initialized == TRUE);

	msi_id = MPIC_INTR_TO_IDX(mpic_intr_id);
	OS_ASSERT_COND(msi_id < MPIC_NUM_OF_SMSG_INTRS);
	OS_ASSERT_COND(coalescing_mask != 0);

	status = osMpicGetMsiCoalescingReg(msi_id,&p_msicr);

	WRITE_UINT32_DBAR_SCFG(*p_msicr, (volatile)coalescing_mask);

	return status;
}
#endif // 0

/*****************************************************************************/
void mpic_reset()
{
	iowrite32be(GCR_RST, &(g_mpic_memmap->mpic_global_memmap.gcr.gcr));
	core_memory_barrier();

	/* Wait until RST bit is cleared - to indicate reset completion; must be volatile to prevent compiler optimization */
	while (g_mpic_memmap->mpic_global_memmap.gcr.gcr & GCR_RST) ;
}
