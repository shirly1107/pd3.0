/*
 * Copyright 2013-2020 NXP
 */


#ifndef __MPIC_MEMMAP_H
#define __MPIC_MEMMAP_H

#include "fsl_types.h"
#include "fsl_gen.h"

typedef struct
{
     volatile uint32_t  ipidr;
     OS_MEM_RESERVED(0x00004, 0x00010);
}mpic_ipidr_part_memmap_t;

typedef struct
{
     volatile uint32_t  ipivpr;
     OS_MEM_RESERVED(0x00004, 0x00010);
}mpic_ipivpr_part_memmap_t;

typedef struct
{
     volatile uint32_t  gtccr;    /* Global Timer Current Count Registers */
     OS_MEM_RESERVED(0x00004, 0x00010);
     volatile uint32_t  gtbcr;    /* Global Timer Base Count Registers */
     OS_MEM_RESERVED(0x00014, 0x00020);
     volatile uint32_t  gtvpr;    /* Global Timer Vector/Priority Registers */
     OS_MEM_RESERVED(0x00024, 0x00030);
     volatile uint32_t  gtdr;     /* Global Timer Destination Registers */
     OS_MEM_RESERVED(0x00034, 0x00040);
}mpic_gtr_part_memmap_t;

typedef struct
{
     volatile uint32_t  msg;
     OS_MEM_RESERVED(0x00004, 0x00010);
}mpic_msg_part_memmap_t;

typedef struct
{
     volatile uint32_t  msi;
     OS_MEM_RESERVED(0x00004, 0x00010);
}mpic_msi_part_memmap_t;

typedef struct
{
     volatile uint32_t  mr;
     OS_MEM_RESERVED(0x00004, 0x00010);
}mpic_performance_mask_register_memmap_t;

typedef struct
{
     mpic_performance_mask_register_memmap_t  pmr[12];
     OS_MEM_RESERVED(0x000C0, 0x00100);
}mpic_performance_monitor_register_memmap_t;

typedef struct
{
    volatile uint32_t brr1;
    OS_MEM_RESERVED(0x00004, 0x00010);
    volatile uint32_t brr2;
    OS_MEM_RESERVED(0x00014, 0x00020);
}mpic_global_revision_memmap_t;

typedef struct
{
        volatile uint32_t cisr;
     OS_MEM_RESERVED(0x00004, 0x00010);
}mpic_critical_interrtupt_summary_memmap_t;

typedef struct
{
     volatile uint32_t mcsr;
     OS_MEM_RESERVED(0x00004, 0x00010);
}mpic_machine_check_summary_memmap_t;

typedef struct
{
     volatile uint32_t irqsiesr;
     OS_MEM_RESERVED(0x00004, 0x00010);
}mpic_irq_soc_interrupt_event_summary_memmap_t;

typedef struct
{
    OS_MEM_RESERVED(0x00000, 0x0020);
    mpic_ipidr_part_memmap_t ipid[4];
    volatile uint32_t ctpr;
    OS_MEM_RESERVED(0x00064, 0x00070);
    volatile uint32_t whoami;
    OS_MEM_RESERVED(0x00074, 0x00080);
    volatile uint32_t iack;
    OS_MEM_RESERVED(0x00084, 0x00090);
    volatile uint32_t eoi;
    OS_MEM_RESERVED(0x00094, 0x00FD0);
}mpic_per_cpu_par_memmap_t;

typedef struct
{
    volatile uint32_t frr;
    OS_MEM_RESERVED(0x00004, 0x00020);
    volatile uint32_t gcr;
    volatile uint32_t gcr1;
    OS_MEM_RESERVED(0x00028, 0x00080);
    volatile uint32_t vir;
    OS_MEM_RESERVED(0x00084, 0x00090);
    volatile uint32_t pir;
    OS_MEM_RESERVED(0x00094, 0x00098);
    volatile uint32_t pnmir;
    OS_MEM_RESERVED(0x0009c, 0x000A0);
    mpic_ipivpr_part_memmap_t ipivp[4];
    volatile uint32_t svr;   
}mpic_gcr_memmap_t;

typedef struct
{
    volatile uint32_t tfrr;         /* Timer Frequency Reporting Register */
    OS_MEM_RESERVED(0x00004, 0x00010);
    mpic_gtr_part_memmap_t gtr[4];  /* Global Timer Registers */
    OS_MEM_RESERVED(0x000F4, 0x00200);
    volatile uint32_t tcr;          /* Timer Control Registers */
    OS_MEM_RESERVED(0x00210, 0x002F0);
}mpic_global_timer_memmap_t;

typedef struct
{
    mpic_msg_part_memmap_t msgr[8];
    OS_MEM_RESERVED(0x00080, 0x00100);
    volatile uint32_t mer;
    OS_MEM_RESERVED(0x00104, 0x00110);
    volatile uint32_t msr;
    OS_MEM_RESERVED(0x00114, 0x001f0);
}mpic_global_massage_memmap_t;

typedef struct
{
     mpic_msg_part_memmap_t msir[16];
     OS_MEM_RESERVED(0x0100, 0x00120);
     volatile uint32_t msisr;
     OS_MEM_RESERVED(0x00124, 0x00140);
     volatile uint32_t msiir;
     OS_MEM_RESERVED(0x00144, 0x00200);
}mpic_global_shared_massage_memmap_t;

typedef struct
{
     mpic_performance_monitor_register_memmap_t pmmr[4];
     OS_MEM_RESERVED(0x00400, 0x007F0);
}mpic_global_performance_monitor_memmap_t;

typedef struct
{
        volatile uint32_t erqsr;
        OS_MEM_RESERVED(0x00004, 0x00100);
        volatile uint32_t eisr;
        OS_MEM_RESERVED(0x00104, 0x00110);
        volatile uint32_t eimr0;
        OS_MEM_RESERVED(0x00114, 0x00200);
        volatile uint32_t wsrsr;
        OS_MEM_RESERVED(0x00204, 0x00300);
        mpic_critical_interrtupt_summary_memmap_t  cisr0;
        OS_MEM_RESERVED(0x00310, 0x00340);
        mpic_critical_interrtupt_summary_memmap_t cis[8];
        OS_MEM_RESERVED(0x003C0, 0x00400);
        mpic_machine_check_summary_memmap_t   mcsr0;
        OS_MEM_RESERVED(0x00410, 0x00440);
        mpic_machine_check_summary_memmap_t mcs[8];  
        OS_MEM_RESERVED(0x004C0, 0x00500);
        mpic_irq_soc_interrupt_event_summary_memmap_t irqsiesr0;
        OS_MEM_RESERVED(0x00510, 0x00540);
        mpic_irq_soc_interrupt_event_summary_memmap_t irqsies[8];
        OS_MEM_RESERVED(0x005C0, 0x007F0);
}mpic_global_interrupt_memmap_t;

typedef struct
{
        OS_MEM_RESERVED(0x00000, 0x00140);
        volatile uint32_t msiir;
        OS_MEM_RESERVED(0x00144, 0x00148);
        volatile uint32_t msiir1;
        OS_MEM_RESERVED(0x0014C, 0x00180);
        volatile uint32_t msicr[16];
        OS_MEM_RESERVED(0x001C0, 0x01000);
}mpic_global_shared_msi_index_grp_memmap_t;

typedef struct
{
        mpic_global_revision_memmap_t global_revision;
        mpic_per_cpu_par_memmap_t private_per_cpu_par;
        OS_MEM_RESERVED(0x00FF0, 0x01000);
        mpic_gcr_memmap_t   gcr;
        OS_MEM_RESERVED(0x010E4, 0x010F0);
        mpic_global_timer_memmap_t global_timer_a;
        OS_MEM_RESERVED(0x013F0, 0x01400);
        mpic_global_massage_memmap_t global_msg_a;
        OS_MEM_RESERVED(0x015F0, 0x01600);
        mpic_global_shared_massage_memmap_t global_shared_msg_a;       
        mpic_global_shared_massage_memmap_t global_shared_msg_b;
        mpic_global_shared_massage_memmap_t global_shared_msg_c;
        mpic_global_shared_massage_memmap_t global_shared_msg_d;
        OS_MEM_RESERVED(0x01E00, 0x020F0);
        mpic_global_timer_memmap_t global_timer_b;
        OS_MEM_RESERVED(0x023F0, 0x02400);
        mpic_global_massage_memmap_t global_msg_b;
        OS_MEM_RESERVED(0x025F0, 0x03000);
        mpic_global_performance_monitor_memmap_t global_performance;
        OS_MEM_RESERVED(0x037F0, 0x03800);
        mpic_global_interrupt_memmap_t  global_interrupt_summary;
        OS_MEM_RESERVED(0x03FF0, 0x04000);
        mpic_global_shared_msi_index_grp_memmap_t global_shared_msi_index_grp[4];
        OS_MEM_RESERVED(0x08000, 0x10000);
}mpic_global_memmap_t;

typedef struct
{
        volatile uint32_t eivpr;
        OS_MEM_RESERVED(0x00004, 0x00010);
        volatile uint32_t eidr;
        OS_MEM_RESERVED(0x00014, 0x00018);
        volatile uint32_t eilr;
        OS_MEM_RESERVED(0x0001C, 0x00020);
}mpic_external_interrupt_registers_memmap_t;

typedef struct
{
        mpic_external_interrupt_registers_memmap_t eir[12];
        OS_MEM_RESERVED(0x00180, 0x001F0);
}mpic_external_interrupt_configuration_memmap_t;

typedef struct
{
        volatile uint32_t iivpr;
        OS_MEM_RESERVED(0x00004, 0x00010);
        volatile uint32_t iidr;
        OS_MEM_RESERVED(0x00014, 0x00018);
        volatile uint32_t iilr;
        OS_MEM_RESERVED(0x0001C, 0x00020);
}mpic_internal_interrupt_registers_memmap_t;

typedef struct
{
        mpic_internal_interrupt_registers_memmap_t iirl[160];
}mpic_internal_interrupt_configuration_low_memmap_t;

typedef struct
{
        mpic_internal_interrupt_registers_memmap_t iirh[96];
        OS_MEM_RESERVED(0x00C00, 0x0CFF0);
}mpic_internal_interrupt_configuration_high_memmap_t;

typedef struct
{
        volatile uint32_t mivpr;
        OS_MEM_RESERVED(0x00004, 0x00010);
        volatile uint32_t midr;
        OS_MEM_RESERVED(0x00014, 0x00020);
}mpic_msg_interrupt_registers_memmap_t;

typedef struct
{
        mpic_msg_interrupt_registers_memmap_t mir_low_a[4];
        mpic_msg_interrupt_registers_memmap_t mir_low_b[4];
        mpic_msg_interrupt_registers_memmap_t mir_high_a[4];
        mpic_msg_interrupt_registers_memmap_t mir_high_b[4];
        OS_MEM_RESERVED(0x0200, 0x005F0);
}mpic_msg_interrupt_configuration_memmap_t;

typedef struct
{
        volatile uint32_t mivpr;
        OS_MEM_RESERVED(0x00004, 0x00010);
        volatile uint32_t midr;
        OS_MEM_RESERVED(0x00014, 0x00020);
}mpic_msi_interrupt_registers_memmap_t;

typedef struct
{
        mpic_msi_interrupt_registers_memmap_t mir_low_a[8];
        mpic_msi_interrupt_registers_memmap_t mir_low_b[8];
        mpic_msi_interrupt_registers_memmap_t mir_low_c[8];
        mpic_msi_interrupt_registers_memmap_t mir_low_d[8];
        mpic_msi_interrupt_registers_memmap_t mir_high_a[8];
        mpic_msi_interrupt_registers_memmap_t mir_high_b[8];
        mpic_msi_interrupt_registers_memmap_t mir_high_c[8];
        mpic_msi_interrupt_registers_memmap_t mir_high_d[8];
        OS_MEM_RESERVED(0x00800, 0x013F0);
}mpic_msi_interrupt_configuration_memmap_t;

typedef struct
{
        mpic_external_interrupt_configuration_memmap_t external_interrupt_configuration;
        OS_MEM_RESERVED(0x001F0, 0x00200);
        mpic_internal_interrupt_configuration_low_memmap_t  internal_interrupt_configuration_low;
        mpic_msg_interrupt_configuration_memmap_t   msg_interrupt_configuration;
        OS_MEM_RESERVED(0x01bF0, 0x01c00);
        mpic_msi_interrupt_configuration_memmap_t   msi_interrupt_configuration;
        OS_MEM_RESERVED(0x02FF0, 0x03000);
        mpic_internal_interrupt_configuration_high_memmap_t internal_interrupt_configuration_high;
        OS_MEM_RESERVED(0x0FFF0, 0x10000);
}mpic_int_src_memmap_t;


typedef struct
{
        OS_MEM_RESERVED(0x00000, 0x00020);
        mpic_per_cpu_par_memmap_t per_cpu_par;
        OS_MEM_RESERVED(0x00FF0, 0x001000);
}mpic_core_per_cpu_par_memmap_t;


typedef struct
{
        mpic_core_per_cpu_par_memmap_t core_per_cpu_par[14];
        OS_MEM_RESERVED(0x00E000, 0x0010000);
}mpic_core_memmap_t;

typedef struct
{
    mpic_global_memmap_t    mpic_global_memmap;
    mpic_int_src_memmap_t   mpic_int_src_memmap;
    mpic_core_memmap_t      mpic_core_memmap;
}mpic_memmap_t;

#endif  // __MPIC_MEMMAP_H

