/*
 * Copyright 2013-2020 NXP
 */

/**
 @File          serdes.c

 @Description   SerDes specific routines.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "fsl_errors.h"
#include "drivers/fsl_mc.h"
#include "drivers/fsl_serdes.h"
#include "fsl_timer.h"
#include "serdes.h"

#include "dpc.h"

static int is_two_and_half_sgmii(struct serdes_desc *desc, int lane)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	int is_pll1_used;
	uint32_t reg, frate_sel;

#ifdef EMULATOR
	return 0;
#endif

	/* Determine which PLL used */
	reg = ioread32(&regs->lane_control[lane].lnxgcr0);
	is_pll1_used = (int)(reg >> GCR0_RPLL_LES_SHIFT);

	/* Read PLL configuration */
	if (is_pll1_used)
		reg = ioread32(&regs->pll_cfg[0].pllxcr0);
	else
		reg = ioread32(&regs->pll_cfg[1].pllxcr0);

	/* Determine if it's SGMII or SGMII2.5.
	 * Use SGMII as default, it'll be useful when SerDes
	 * block is not implemented (Simulator/Emulator)
	 */
	frate_sel = (reg & PLLXCR0_FRATE_SEL_MASK) >> PLLXCR0_FRATE_SEL_SHIFT;

	if (frate_sel == PLLXCR0_FRATE_SEL_SGMII_2_5)
		return 1;
	else
		return 0;
}

#if defined(EMULATOR_LX2160)
static uint32_t serdes_pssr0[] = {
		/* SerDes block 0 - 2 * XFI, 2 * 25G.E, 1 * 40G.E (4 lanes) */
		0x28020000, 0x28030000, 0x68040000, 0x68050000,
		0x2B010000, 0x2B010001, 0x2B010002, 0x2B010003,
};
#elif defined(EMULATOR_LS2088)
static uint32_t serdes_pssr0[][8] = {
	{
		/* SerDes block 0 - 8 * XFI */
		0x28070000, 0x28060000, 0x28050000, 0x28040000,
		0x28030000, 0x28020000, 0x28010000, 0x28000000,
	}, {
		/* SerDes block 1 - 8 * SGMII */
		0x04080000, 0x04090000, 0x040a0000, 0x040b0000,
		0x040c0000, 0x040d0000, 0x040e0000, 0x040f0000,
	}
};
#elif defined(EMULATOR_LS1088) || defined(TMP_1088_SERDES_SIM)
static uint32_t serdes_pssr0[] = {
		/* Lane A: QSGMIIb (MAC 3-6)
		 * Lane B: QSGMIIb (MAC 7-10)
		 * Lane C: XFI1
		 * Lane D: XFI2
		 */
		0x05020000, 0x05060000, 0x28000000, 0x28010000,
};
#elif defined(EMULATOR_UA) || defined(TMP_UA_SERDES_SIM)
/* UA has only 1 XFI port on Lane A - Serdes1 */
static uint32_t serdes_pssr0[] = {
		/* Lane A: XFI1
		 */
		0x28000000, 0x10000, 0x20000, 0x30000,
};
#endif

/* Read Lane Protocol Select Status 0 register */
static inline uint32_t serdes_get_pssr0(struct serdes_desc *desc, int lane)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;

#if defined(EMULATOR_LS2088)
	return serdes_pssr0[desc->id][lane];
#elif defined(EMULATOR_LS1088) || defined(EMULATOR_LX2160) || defined(EMULATOR_UA)
	return serdes_pssr0[lane];
#elif defined(TMP_1088_SERDES_SIM) || defined(TMP_UA_SERDES_SIM)
	if (IS_SIM)
		return serdes_pssr0[lane];
#endif

	return ioread32(&regs->lane_info[lane].lnxpssr0);
}

static uint8_t get_no_lanes(struct serdes_desc *desc,
							int mac_id,
							int lane)
{
	uint32_t reg;
	int i;
	uint8_t no_lanes = 0;
	uint32_t protocol;

	if (lane > desc->num_lanes - 1)
		return 0;

	for (i = lane; i < desc->num_lanes; i++) {
		reg = serdes_get_pssr0(desc, i);
		if (!reg)
			break;
		if (mac_id == (((reg & desc->mac_mask) >> PSSR0_MAC_ID_SHIFT) + 1)) {
			protocol = (reg & PSSR0_PROTS_MASK) >> PSSR0_PROTS_SHIFT;
			switch( protocol ) {
				/* verify against MAC protocols */
				case PSSR0_PROTS_SGMII:
				case PSSR0_PROTS_XAUI:
				case PSSR0_PROTS_XFI:
				case PSSR0_PROTS_CAUI:
					no_lanes++;
					break;
			}
		}
	}

	return no_lanes;
}

/* This API is not yet supported on LS2 platforms */
int serdes_convert_enet_if(struct serdes_desc *desc,
						   struct serdes_mac_info *mac_info,
						   uint8_t sd_proto,
						   uint32_t pssr0_enet_if)
{
	mac_info->converted = SERDES_IF_CONVERT_NOT_SUPPORTED;
	return 0;
}

unsigned char *serdes_get_enet_if_str(uint32_t enet_if)
{
	unsigned char *p = NULL;
	switch(enet_if) {
		case FSL_ENET_IF_SGMII:
			p = "SGMII";
			break;
		case FSL_ENET_IF_SGMII_BASEX:
			p = "BASE";
			break;
		case FSL_ENET_IF_XGMII:
			p = "XGMII";
			break;
		case FSL_ENET_IF_XFI:
			p = "XFI";
			break;
		case FSL_ENET_IF_USXGMII:
			p = "USXGMII";
			break;
		case FSL_ENET_IF_CAUI:
			p = "CAUI";
			break;
		default:
			p = "NONE";
			break;
	}
	return p;
}

/* translate the actual enet_if into PSSR0 format */
uint32_t serdes_enet_to_pssr0(enum enet_interface enet_if)
{
	uint32_t protocol = 0;

	switch (enet_if)
	{
	case FSL_ENET_IF_SGMII:
	case FSL_ENET_IF_SGMII_BASEX:
		protocol = PSSR0_PROTS_SGMII;
		break;
	case FSL_ENET_IF_XFI:
	case FSL_ENET_IF_USXGMII:
		protocol = PSSR0_PROTS_XFI;
		break;
	case FSL_ENET_IF_XGMII:
		protocol = PSSR0_PROTS_XAUI;
		break;
	case FSL_ENET_IF_QSGMII:
		protocol = PSSR0_PROTS_QSGMII;
		break;
	case FSL_ENET_IF_CAUI:
		protocol = PSSR0_PROTS_CAUI;
		break;
	default:
		return 0;
	}
	
	return protocol;
} 

void serdes_get_mac_info(struct serdes_desc *desc,
                         struct serdes_mac_info *mac_info,
                         int *lane,
                         uint8_t sd_proto)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t reg, protocol, isQsgmii;

	reg = serdes_get_pssr0(desc, *lane);

	/* SerDes dosen't give information about eiop, for now we use 0 */
	mac_info->eiop_id = 0;

	/* PSSR0 holds MAC IDs 0-15, we support MAC IDs 1 - 16 */
	mac_info->mac_id =
	        (int)((reg & desc->mac_mask) >> PSSR0_MAC_ID_SHIFT) + 1;
	isQsgmii = (reg & PSSR0_IS_QSGMII_MASK) >> PSSR0_IS_QSGMII_SHIFT;
	protocol = (reg & PSSR0_PROTS_MASK) >> PSSR0_PROTS_SHIFT;

	mac_info->lanes = get_no_lanes(desc, mac_info->mac_id, *lane);

	/* exit early, good luck with the next lane */
	if (mac_info->lanes == 0) {
		return;
	}

	/* Set valid as default */
	mac_info->valid = 1;

	switch (protocol) {
	case (PSSR0_PROTS_SGMII):
		if (isQsgmii) {
			mac_info->enet_if = FSL_ENET_IF_QSGMII;
			mac_info->rate = 1000;
		} else {
			if (is_two_and_half_sgmii(desc, *lane))
				mac_info->rate = 2500;
			else
				mac_info->rate = 1000;

			mac_info->enet_if = FSL_ENET_IF_SGMII;
		}
		break;
	case (PSSR0_PROTS_XAUI):
		mac_info->enet_if = FSL_ENET_IF_XGMII;
		mac_info->rate = 10000;
		break;
	case (PSSR0_PROTS_XFI):
		mac_info->enet_if = FSL_ENET_IF_XFI;
		mac_info->rate = 10000;
		/* SerDes for LX2  uses the Qsgmii bits to describe the rates */
		if (isQsgmii & PSSR0_RATE_40G)
			mac_info->rate = 40000;
		break;
	case (PSSR0_PROTS_CAUI):
		mac_info->enet_if = FSL_ENET_IF_CAUI;
		mac_info->rate = 25000;
		/* SerDes for LX2 uses the Qsgmii bits to describe the rates */
		if (isQsgmii)
			mac_info->rate = (isQsgmii & PSSR0_RATE_5_10_50G) ?
					50000 : 100000;
		break;
	default:
		/* not a MAC process next lane */
		mac_info->valid = 0;
		return;
	}

	/* Move the lane parameter to the next valid distinct MAC */
	*lane += mac_info->lanes - 1;
}

int serdes_get_mac_string(struct dcfg_desc *dcfg_desc,
						struct serdes_desc *desc,
						int *lane,
						char *buf,
						uint8_t sd_proto)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t reg, protocol, isQsgmii;
	int mac_id, no_lanes;
	int i;
	int count = 0;

	reg = serdes_get_pssr0(desc, *lane);

	/* PSSR0 holds MAC IDs 0-15, we support MAC IDs 1 - 16 */
	mac_id = (int)((reg & desc->mac_mask) >> PSSR0_MAC_ID_SHIFT) + 1;
	isQsgmii = (reg & PSSR0_IS_QSGMII_MASK) >> PSSR0_IS_QSGMII_SHIFT;
	protocol = (reg & PSSR0_PROTS_MASK) >> PSSR0_PROTS_SHIFT;
	no_lanes = get_no_lanes(desc, mac_id, *lane);

	/* jump if MAC is set as RGMII
	 * Do not double print it as SGMII or QSGMII is set through SerDes
	 */
	for (i = 0; i < MAX_EC_CFG; i++){
		if (dcfg_desc->ec[i].valid)
			if((dcfg_desc->ec[i].port_id == mac_id) && dcfg_has_rgmii(dcfg_desc, i))
				return 0;
	}

	/* jump to the next lane; nothing here */
	if (no_lanes == 0) {
		return 0;
	}

	switch (protocol) {
	case (PSSR0_PROTS_SGMII):
		if (isQsgmii) {
			for (i = 0; i < 4; i++)
				count += sprintf(&buf[count], "QSGMII[%d] on SerDes %d, lane %d\n",
						mac_id + i, desc->id + 1, *lane);
		} else {
			if (is_two_and_half_sgmii(desc, *lane))
				count += sprintf(&buf[count],"SGMII2.5[%d] on SerDes %d, lane %d\n",
						mac_id, desc->id + 1, *lane);
			else
				count += sprintf(&buf[count],"SGMII[%d] on SerDes %d, lane %d\n",
						mac_id, desc->id + 1, *lane);
			}
		break;
	case (PSSR0_PROTS_XAUI):
		count += sprintf(&buf[count],"XAUI[%d] on SerDes %d, lane %d\n",
				mac_id, desc->id + 1, *lane);
		break;
	case (PSSR0_PROTS_XFI):
		count += sprintf(&buf[count],"XFI[%d] on SerDes %d, lane %d spread on %d lane(s)\n",
				mac_id, desc->id + 1, *lane, no_lanes);
		break;
	case (PSSR0_PROTS_CAUI):
		count += sprintf(&buf[count],"CAUI%d[%d] on SerDes %d, lane %d spread on %d lane(s)\n",
				no_lanes, mac_id, desc->id + 1, *lane, no_lanes);
		break;
	default:
		/* not a MAC, no prints and return to process next lane */
		return 0;
	}

	/* move the next lane with a distinct MAC */
	*lane += no_lanes - 1;

	return count;
}

void serdes_set_loopback(struct serdes_desc *desc)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t reg, i;

	pr_info("SerDes[%d]: Setting SerDes loopback\n", desc->id);
	for (i = 0; i < desc->num_lanes; i++) {
		/* Read Test Control/Status 3 register */
		reg = ioread32(&regs->lane_control[i].lnxtcsr3);
		/* Clean LPBK_EN bits and set Digital Loop-back Mode */
		reg = (reg & ~0x30000000) | 0x10000000;
		iowrite32(reg, &regs->lane_control[i].lnxtcsr3);
	}
}

int serdes_mac_to_lane(struct serdes_desc *desc, int mac_id, uint8_t sd_proto, uint8_t *lane)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t reg;
	uint32_t tmp_mac_id;
	uint32_t tmp_mac_proto;
	int i;

	for (i = 0; i < desc->num_lanes; i++) {
		reg = serdes_get_pssr0(desc, i);

		tmp_mac_id = ((reg & desc->mac_mask) >> PSSR0_MAC_ID_SHIFT) + 1;
		if (mac_id == (int) tmp_mac_id ) {
			tmp_mac_proto = (reg & PSSR0_PROTS_MASK) >> PSSR0_PROTS_SHIFT;
			switch( tmp_mac_proto ) {
				/* verify against MAC protocols */
				case PSSR0_PROTS_SGMII:
				case PSSR0_PROTS_XAUI:
				case PSSR0_PROTS_XFI:
				case PSSR0_PROTS_CAUI:
					*lane = (uint8_t)i;
					return 0;
			}
		}
	}

	pr_err("No lane that matches to mac_id[%d] was found\n", mac_id);
	return -EINVAL;
}

void serdes_reset_lane(struct serdes_desc *desc, int lane)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *gcr0, *recr0;

	gcr0 = &(regs->lane_control[lane].lnxgcr0);
	recr0 = &(regs->lane_control[lane].lnxrecr0);

	/* reset the lane */
	iowrite32(ioread32(gcr0) & ~GCR0_TX_RX_RST_MASK, gcr0);
	timer_udelay(1);

	iowrite32(ioread32(recr0) & ~(RECRO_RXEQ_BST_MASK), recr0);
	timer_udelay(1);

	/* unreset the lane */
	iowrite32(ioread32(gcr0) | GCR0_TX_RX_RST_MASK, gcr0);
	timer_udelay(1);

}

void serdes_enable_1000base_kx_an(struct serdes_desc *desc,
                                  int lane,
                                  int dpmac_id)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;;
	uint32_t *gcr0, *pllcr0, *pccr8;
	uint32_t tpll_les = 0, sgmii_kx_mask;

	gcr0 = &(regs->lane_control[lane].lnxgcr0);
	tpll_les = ioread32(gcr0) & GCR0_TPLL_LES_MASK;

	if (tpll_les) /* tpll_les=1: use PLL1 */
		pllcr0 = &(regs->pll_cfg[0].pllxcr0);
	else /* tpll_les=0: use PLL2 */
		pllcr0 = &(regs->pll_cfg[1].pllxcr0);

	iowrite32(ioread32(pllcr0) | PLLXCR0_DLYDIV_SEL, pllcr0);

	pccr8 = &(regs->pccr8);

	/* The bit that should be 'on' per mac:
	 * mac=1 (serdes_id=0) or mac=9 (serdes_id=1) -> bit=31
	 * mac=2 (serdes_id=0) or mac=10 (serdes_id=1) -> bit=27
	 * mac=3 (serdes_id=0) or mac=11 (serdes_id=1) -> bit=23
	 * mac=4 (serdes_id=0) or mac=12 (serdes_id=1) -> bit=19
	 * mac=5 (serdes_id=0) or mac=13 (serdes_id=1) -> bit=15
	 * mac=6 (serdes_id=0) or mac=14 (serdes_id=1) -> bit=11
	 * mac=7 (serdes_id=0) or mac=15 (serdes_id=1) -> bit=7
	 * mac=8 (serdes_id=0) or mac=16 (serdes_id=1) -> bit=3
	 */
	if (dpmac_id % 8)
		sgmii_kx_mask = 0x1 << (31 - 4 * ((dpmac_id % 8) - 1));
	else 
		sgmii_kx_mask = 0x8;


	iowrite32(ioread32(pccr8) | sgmii_kx_mask, pccr8);
}

void serdes_init_1000base_kx(struct serdes_desc *desc,
                             int lane,
                             int dpmac_id)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;;
	uint32_t *gcr1, *tecr0;

	gcr1 = &(regs->lane_control[lane].lnxgcr1);
	tecr0 = &(regs->lane_control[lane].lnxtecr0);

	iowrite32(ioread32(gcr1) & GCR1_KX_MASK, gcr1);
	timer_udelay(1);

	iowrite32(ioread32(tecr0) & TECR0_AMP_RED_MASK, tecr0);
	timer_udelay(1);

	serdes_enable_1000base_kx_an(desc, lane, dpmac_id);
}

void serdes_set_tx_equalization_values(struct serdes_desc *desc,
                                       struct serdes_kr_cfg kr_cfg)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *gcr0, *tecr0, val;

	gcr0 = &(regs->lane_control[kr_cfg.lane].lnxgcr0);
	tecr0 = &(regs->lane_control[kr_cfg.lane].lnxtecr0);

	val = TECR0_INIT_VAL |
		kr_cfg.adpt_eq << TECR0_ADPT_EQ |
		kr_cfg.ratio_preq << TECR0_RATIO_PREQ_SHIFT |
		kr_cfg.ratio_pst1q << TECR0_RATIO_RATIO_PST1Q;

	/* reset the lane */
	iowrite32(ioread32(gcr0) & ~GCR0_TX_RX_RST_MASK, gcr0);
	timer_udelay(1);

	iowrite32(val, tecr0);
	timer_udelay(1);

	/* release reset */
	iowrite32(ioread32(gcr0) | GCR0_TX_RX_RST_MASK, gcr0);
	timer_udelay(1);

}

int serdes_check_bin_status(struct serdes_desc *desc,
                            enum serdes_10gbase_kr_bins bin_sel, int lane)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	int i, timeout, negative_count = 0, early = 0;
	uint32_t bin_snap_shot[NUM_OF_SNAPSHOTS];
	uint32_t *recr1, *tcsr1, *gcr1;
	uint32_t reg;

	recr1 = &(regs->lane_control[lane].lnxrecr1);
	tcsr1 = &(regs->lane_control[lane].lnxtcsr1);
	gcr1 = &(regs->lane_control[lane].lnxgcr1);

	for (i = 0; i < NUM_OF_SNAPSHOTS; i++) {
		/* wait RECR1_EQ_BSNP_DN has cleared */
		timeout = 100;
		while ((ioread32(recr1) & RECR1_EQ_BSNP_DN)) {
				timer_udelay(1);
				timeout--;
				if (timeout == 0)
					break;
		}

		/* set TCSR1[CDR_SEL] to BinM1/BinLong */
		reg = ioread32(tcsr1);
		reg &= ~TCSR1_CDR_SEL_MASK;
		if (bin_sel == SERDES_10GBASE_KR_BIN_M1)
			reg |= TCSR1_CDR_SEL_BIN_M1;
		else
			reg |= TCSR1_CDR_SEL_BIN_LONG;

		iowrite32(reg, tcsr1);

		/* start snap shot */
		iowrite32(ioread32(gcr1) | GCR1_REQ_BIN_SNP_MASK, gcr1);

		/* wait for SNP done */
		timeout = 100;

		do {
			timer_udelay(1);
		} while (!(ioread32(recr1) & RECR1_EQ_BSNP_DN) && timeout--);

		/* read and save the snap shot */
		bin_snap_shot[i] = (ioread32(tcsr1) &
			TCSR1_EQ_SNPBIN_DATA_MASK) >> TCSR1_EQ_SNPBIN_DATA_SHIFT;
		if (bin_snap_shot[i] & TCSR1_EQ_SNPBIN_DATA_SIGN_MASK)
			negative_count++;

		/* terminate the snap shot by setting GCR1[REQ_CTL_SNP] */
		iowrite32(ioread32(gcr1) & ~GCR1_REQ_BIN_SNP_MASK, gcr1);
	}

	if (((bin_sel == SERDES_10GBASE_KR_BIN_M1) &&
		negative_count > BIN_M1_THRESHOLD) ||
	    ((bin_sel == SERDES_10GBASE_KR_BIN_LONG &&
		    negative_count > BIN_LONG_THRESHOLD))) {
		early = 1;
	}

	return early;
}

/* only serdes_28g is SFI capable; we are serdes_10g */
int is_serdes_sfi_capable(struct serdes_eq_settings *sfi_settings)
{
	return 0;
}

int serdes_eq_setup(struct serdes_desc *desc, int dpmac_id, struct serdes_eq_settings *serdes_cfg)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	struct serdes_mac_info *dpmac = NULL;
	uint32_t *tecr0_reg, tecr0_val;
	uint8_t master_lane, no_lanes, lane;
	uint8_t sd_proto = 0;

	/* get master lane number from dpmac_id and serdes_desc */
	if (serdes_mac_to_lane(desc, dpmac_id, sd_proto, &master_lane))
		return -EINVAL;

	/* find if mac has multiple lanes */
	no_lanes = get_no_lanes(desc, dpmac_id, master_lane);

	pr_info("serdes_cfg: amp=%#x, post1q=%#x, preq=%#x, eq_type=%#x\n",
			serdes_cfg->eq_amp_red, serdes_cfg->eq_post1q, serdes_cfg->eq_preq, serdes_cfg->eq_type);

	/* update fields that require change */
	/* iterate through all mac lanes and apply new settings */
	for (lane = master_lane; lane < (master_lane + no_lanes); lane++) {
		tecr0_reg = &(regs->lane_control[lane].lnxtecr0);
		tecr0_val = ioread32(tecr0_reg);

		/* update bits if necessary */
		SERDES_SET_CFG(SERDES_10G_TECR0, serdes_cfg->eq_type,    tecr0_val, EQ_TYPE);
		SERDES_SET_CFG(SERDES_10G_TECR0, serdes_cfg->sgn_preq,   tecr0_val, SGN_PREQ);
		SERDES_SET_CFG(SERDES_10G_TECR0, serdes_cfg->eq_preq,    tecr0_val, EQ_PREQ);
		SERDES_SET_CFG(SERDES_10G_TECR0, serdes_cfg->sgn_post1q, tecr0_val, SGN_POST1Q);
		SERDES_SET_CFG(SERDES_10G_TECR0, serdes_cfg->eq_post1q,  tecr0_val, EQ_POST1Q);
		SERDES_SET_CFG(SERDES_10G_TECR0, serdes_cfg->eq_amp_red, tecr0_val, EQ_AMP_RED);
		//pr_info("dpmac %d lane %d, after: %#x --> %#x\n", dpmac_id, lane, tecr0_reg, tecr0_val);

		/* write the updated tecr0 value */
		if (ioread32(tecr0_reg) != tecr0_val)
			iowrite32(tecr0_val, tecr0_reg);
	}

	return 0;
}

int get_serdes_eq_setup(struct serdes_desc *desc, int dpmac_id, struct serdes_eq_settings *attr)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *tecr0_reg, tecr0_val;
	uint8_t master_lane = 0;
	uint8_t sd_proto = 0;

	/* get master lane number from dpmac_id and serdes_desc */
	if (serdes_mac_to_lane(desc, dpmac_id, sd_proto, &master_lane))
		return -EINVAL;

	tecr0_reg = &(regs->lane_control[master_lane].lnxtecr0);
	tecr0_val = ioread32(tecr0_reg);

	SERDES_GET_CFG(SERDES_10G_TECR0, tecr0_val, attr->eq_type, EQ_TYPE);
	SERDES_GET_CFG(SERDES_10G_TECR0, tecr0_val, attr->sgn_preq, SGN_PREQ);
	SERDES_GET_CFG(SERDES_10G_TECR0, tecr0_val, attr->eq_preq, EQ_PREQ);
	SERDES_GET_CFG(SERDES_10G_TECR0, tecr0_val, attr->sgn_post1q, SGN_POST1Q);
	SERDES_GET_CFG(SERDES_10G_TECR0, tecr0_val, attr->eq_post1q, EQ_POST1Q);
	SERDES_GET_CFG(SERDES_10G_TECR0, tecr0_val, attr->eq_amp_red, EQ_AMP_RED);

	return 0;
}


void convert_xfi2usxgmiia(struct serdes_desc *desc, int dpmac_id)
{
	/* no such thing on LS* boards */
	return;
}

#ifdef TKT320141
int serdes_reset_receiver_lane(struct serdes_desc *desc,
								int mac_id,
								uint8_t master_lane,
								uint8_t no_lanes,
								enum enet_interface enet_if)
{
	uint32_t tcsr3, *gcr0;
	uint8_t tries;
	struct serdes_mem_map *regs;
	int reset = 0;

	regs = (struct serdes_mem_map *)desc->vaddr;

	/* attempt to reset the lane 3 times */
	tries = 3;
	while (tries-- > 0) {
		tcsr3 = ioread32(&regs->lane_control[master_lane].lnxtcsr3);
		if (!(tcsr3 & TCSR3_CDR_LOCK_MASK)) {
//			pr_info("CDR LOCK - serdes: %d, lane: %d, MAC: %d, tcsr3: %#x\n",
//					serdes_id, master_lane, mac_id, tcsr3);
			/* reset the lane */
			gcr0 = &(regs->lane_control[master_lane].lnxgcr0);
			iowrite32(ioread32(gcr0) & ~GCR0_RRST_B_MASK, gcr0);
			timer_udelay(1);

			/* unreset the lane */
			iowrite32(ioread32(gcr0) | GCR0_RRST_B_MASK, gcr0);
			timer_udelay(100);

			reset = 1;
//			pr_info("CDR LOCK - serdes: %d, lane: %d, MAC: %d, tcsr3: %#x\n",
//					serdes_id, lane_id, mac_id, tcsr3);
		}
		else
			break;
	}
	
	return reset;
}

void serdes_wa_cdr_lock()
{
	struct serdes_desc serdes_desc = { 0 };
	struct serdes_mem_map *regs;
	struct serdes_mac_info mac_info = { 0 };
	int iter = 0, i, disable, phy_id;
	uint32_t link_type;

	/* skip for simulator */
	if (IS_SIM)
		return;

	while (soc_db_get_desc(SOC_MODULE_SERDES,
						   SOC_DB_NO_MATCH_FIELDS,
						   &serdes_desc, &iter) == 0) {
		regs = (struct serdes_mem_map *)serdes_desc.vaddr;

		for (i = 0; i < serdes_desc.num_lanes; i++) {
			memset(&mac_info, 0, sizeof (struct serdes_mac_info));

			/* obtain MAC id based on lane */
			serdes_get_mac_info(&serdes_desc, &mac_info, &i, 0);
			dpc_get_mac_info(mac_info.mac_id, &disable, &link_type,
								&phy_id, 0, 0, 0, 0);

			/* apply workaround only if:
			 * - mac is valid
			 * - interface is XFI
			 * - mac type is not TYPE_NONE in dpc
			 */
			if (!mac_info.valid ||
				(mac_info.enet_if != FSL_ENET_IF_XFI) ||
				(link_type == DPMAC_LINK_TYPE_NONE) || (link_type == DPMAC_LINK_TYPE_RECYCLE))
				continue;

			/* reset the receiver of the current lane */
			serdes_reset_receiver_lane(&serdes_desc,
										mac_info.mac_id,
										(uint8_t)i,
										0,
										mac_info.enet_if);
		}
	}
}
#endif

void serdes_enable_rs_fec()
{
	return;
}

void serdes_wa_gain_tecr()
{
	return;
}

void serdes_setup_fec_dispatch(struct serdes_desc *desc, int dpmac_id, enum dpmac_fec_mode fec_mode)
{
	return;
}

void serdes_set_fault(struct serdes_desc *desc, int dpmac_id,
						enum serdes_fault_type fault_type, uint8_t en)
{
	return;
}

static void serdes_rstctl_ops(struct serdes_desc *desc,
		       int mac_id,
		       uint8_t master_lane,
		       uint32_t flags)
{
	return;
}

void serdes_disable_lane(enum enet_interface enet_if,
			 struct serdes_desc *desc,
			 int mac_id,
			 uint8_t master_lane)
{
	return;
}

void serdes_enable_lane(struct serdes_desc *desc,
		int mac_id,
		uint8_t master_lane,
		uint8_t no_lanes,
		enum enet_interface enet_if)
{
	return;
}
