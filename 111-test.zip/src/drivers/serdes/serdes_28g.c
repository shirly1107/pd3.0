/*
 * Copyright 2013-2020 NXP
 */

/**
 @File          serdes.c

 @Description   SerDes specific routines.
 *//***************************************************************************/

#include "fsl_types.h"

#include "fsl_io.h"
#include "fsl_dbg.h"
#include "fsl_errors.h"
#include "drivers/fsl_mc.h"
#include "drivers/fsl_serdes.h"
#include "fsl_timer.h"
#include "serdes_28g.h"
#include "fsl_dcfg.h"

#ifdef TKT320141
#include "dpc.h"
#endif

static int is_two_and_half_sgmii(struct serdes_desc *desc, int lane)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	int is_plls_used;
	uint32_t reg, frate_sel;

#ifdef EMULATOR
	return 0;
#endif

	/* Determine which PLL used  */
	reg = ioread32(&regs->lane_info[lane].lnatgcr[0]);
	is_plls_used = (int)((reg & TGCR0_USE_SLOW_PLL_MASK) >> TGCR0_USE_SLOW_PLL_SHIFT);

	/* Read PLL configuration PLLF (0) or PLLS (1) */
	if (is_plls_used)
		reg = ioread32(&regs->pll_cfg[1].pllxcr[1]);
	else
		reg = ioread32(&regs->pll_cfg[0].pllxcr[1]);

	frate_sel = (reg & PLLXCR1_FRATE_SEL_MASK) >> PLLXCR1_FRATE_SEL_SHIFT;

	/* Determine if it's SGMII or SGMII2.5.
	 * Use SGMII as default, it'll be useful when SerDes
	 * block is not implemented (Simulator/Emulator)
	 *
	 * PLLS and PLLF, if they are used for 2.5 SGMII,
	 * have different values
	 */
	if (is_plls_used) /* PLLF (0) or PLLS (1) */
		if (frate_sel == PLLSCR1_FRATE_SEL_SGMII_2_5)
			return 1;
		else
			return 0;
	else
		if (frate_sel == PLLFCR1_FRATE_SEL_SGMII_2_5)
			return 1;
		else
			return 0;
}

#if defined(LX2160)
/* SRDS_PRTCL_S1 has 5 bits encoding */
static uint32_t serdes_pssr0[2][32][8] = {
	{ /* SerDes block1 */
		{
			/* [0] */
		},
		{
			/* [1] */
		},
		{
			/* [2] - 4 * SGMII */
			0x04020000,	0x04030001,	0x04040002, 0x04050003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [3] - 4 * USXGMII/XFI */
			0x28020000, 0x28030001, 0x28040002, 0x28050003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [4] - 8 * SGMII */
			0x04020000,	0x04030001,	0x04040002, 0x04050003,
			0x04060004,	0x04070005,	0x04080006, 0x04090007
		},
		{
			/* [5] - 4 * USXGMII/XFI */
			0x0,		0x0,		0x0,		0x0,
			0x28060004, 0x28070005, 0x28080006, 0x28090007
		},
		{
			/* [6] - 2 * USXGMII/XFI, 6 * SGMII */
			0x28020000, 0x28030001, 0x04040002, 0x04050003,
			0x04060004, 0x04070005, 0x04080006, 0x04090007
		},
		{
			/* [7] - 4 * USXGMII/XFI, 4 * SGMII */
			0x28020000, 0x28030001, 0x28040002, 0x28050003,
			0x04060004, 0x04070005, 0x04080006, 0x04090007
		},
		{
			/* [8] - 8 * USXGMII/XFI */
			0x28020000, 0x28030001, 0x28040002, 0x28050003,
			0x28060004, 0x28070005, 0x28080006, 0x28090007
		},
		{
			/* [9] - 6 * SGMII */
			0x0,		0x04030001, 0x04040002, 0x04050003,
			0x0,		0x04070005, 0x04080006, 0x04090007,
		},
		{
			/* [10] - 6 * USXGMII/XFI */
			0x0,		0x28030001, 0x28040002, 0x28050003,
			0x0,		0x28070005, 0x28080006, 0x28090007
		},
		{
			/* [11] - 4 * SGMII */
			0x0,		0x0,		0x04040002, 0x04050003,
			0x0,		0x0,		0x04080006, 0x04090007
		},
		{
			/* [12] - 2 * SGMII */
			0x0,		0x0,		0x0,		0x0,
			0x0,		0x0,		0x04080006, 0x04090007
		},
		{
			/* [13] - 2 * 100GE (4 lanes) */
			0x6A000000, 0x6A000001, 0x6A000002, 0x6A000003,
			0x6A010004, 0x6A010005, 0x6A010006, 0x6A010007,
		},
		{
			/* [14] - 1 * 100GE (4 lanes) */
			0x6A000000, 0x6A000001, 0x6A000002, 0x6A000003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [15] - 2 * 50GE (2 lanes) */
			0x69000000, 0x69000001, 0x69010002, 0x69010003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [16] - 1 * 50GE (2 lanes), 2 * 25GE */
			0x69000000, 0x69000001, 0x68040002, 0x68050003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [17] - 4 * 25GE */
			0x68020000, 0x68030001, 0x68040002, 0x68050003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [18] - 6 * USXGMII/XFI, 2 * 25GE */
			0x28020000, 0x28030001, 0x68040002, 0x68050003,
			0x28060004, 0x28070005, 0x28080006, 0x28090007
		},
		{
			/* [19] - 2 * USXGMII/XFI, 2 * 25GE, 1 * 40GE (4 lanes) */
			0x28020000, 0x28030001, 0x68040002, 0x68050003,
			0x2B010004, 0x2B010005, 0x2B010006, 0x2B010007,
		},
		{
			/* [20] - 2 * 40GE (4 lanes) */
			0x2B000000, 0x2B000001, 0x2B000002, 0x2B000003,
			0x2B010004, 0x2B010005, 0x2B010006, 0x2B010007,
		},
		{
			/* [21] - 6 * 25GE */
			0x68020000, 0x68030001, 0x68040002, 0x68050003,
			0x0,		0x0,		0x68080000, 0x68090000
		},
		{
			/* [22] - 6 * USXGMII/XFI */
			0x28020000, 0x28030001, 0x28040002, 0x28050003,
			0x0,		0x0,		0x28080006, 0x28090007,
		},
		{
			/* [23] */
		},
		{
			/* [24] */
		},
		{
			/* [25] */
		},
		{
			/* [26] */
		},
		{
			/* [27] */
		},
		{
			/* [28] */
		},
		{
			/* [29] */
		},
		{
			/* [30] */
		},
		{
			/* [31] */
			0x0,		0x0, 		0x28040002, 0x28050003,
			0x0,		0x0, 		0x28080006, 0x28090007,
		},
	},
	{ /* SerDes block2 */
		{
			/* [0] */
		},
		{
			/* [1] */
		},
		{
			/* [2] */
		},
		{
			/* [3] */
		},
		{
			/* [4] */
		},
		{
			/* [5] */
		},
		{
			/* [6] - 2 * SGMII, 2 * USXGMII/XFI */
			0x0,		0x0,		0x0,		0x0,
			0x040E0004,	0x040F0005,	0x280C0006, 0x280D0007,
		},
		{
			/* [7] - 4 * SGMII, 2 * USXGMII/XFI */
			0x0,		0x040B0001,	0x04100002, 0x04110003,
			0x0,		0x040F0005,	0x280C0006, 0x280D0007,
		},
		{
			/* [8] - 2 * USXGMII/XFI */
			0x0,		0x0,		0x0,		0x0,
			0x0,		0x0,		0x280C0006, 0x280D0007,
		},
		{
			/* [9] - 8 * SGMII */
			0x040A0000,	0x040B0001,	0x04100002, 0x04110003,
			0x040E0004,	0x040F0005,	0x040C0006, 0x040D0007,
		},
		{
			/* [10] - 4 * SGMII */
			0x040A0000,	0x040B0001,	0x04100002, 0x04110003,
			0x0,		0x0,		0x0,		0x0,
		},
		{
			/* [11] - 6 * SGMII */
			0x0,		0x040B0001,	0x04100002, 0x04110003,
			0x0,		0x040F0005,	0x040C0006, 0x040D0007,
		},
		{
			/* [12] - 4 * SGMII */
			0x040A0000,	0x040B0001,	0x04100002, 0x04110003,
			0x0,		0x0,		0x0,		0x0,
		},
		{
			/* [13] - 2 * SGMII */
			0x0,		0x0,		0x0,		0x0,
			0x0,		0x0,		0x040C0006, 0x040D0007,
		},
		{
			/* [14] - 4 * SGMII */
			0x0,		0x0,		0x04100002, 0x04110003,
			0x0,		0x0,		0x040C0006, 0x040D0007,
		}
	}
};

static uint32_t serdes_pssr0_lx2162[2][32][8] = {
	{ /* SerDes block1 */
	  /* due to SerDes1 lines reduction, the lanes 4-7 are not pinned out */

		{
			/* [0] */
		},
		{
			/* [1] */
		},
		{
			/* [2] - 4 * SGMII */
			0x04020000,	0x04030001,	0x04040002, 0x04050003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [3] - 4 * USXGMII/XFI */
			0x28020000, 0x28030001, 0x28040002, 0x28050003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [4] - 4 * SGMII */
			/* Redundant with protocol 2 */
		},
		{
			/* [5]  */
			/* Redundant with protocol 1 */
		},
		{
			/* [6] - 2 * USXGMII/XFI, 2 * SGMII */
			/* Not supported because 2nd REF_CLK not pinned out */
		},
		{
			/* [7] - 4 * USXGMII/XFI */
			/* Redundant with protocol 3 */
		},
		{
			/* [8] - 4 * USXGMII/XFI */
			/* Redundant with protocol 3 */
		},
		{
			/* [9] - 3 * SGMII */
			0x0,		0x04030001, 0x04040002, 0x04050003,
			0x0,		0x0, 		0x0, 		0x0,
		},
		{
			/* [10] - 3 * USXGMII/XFI */
			/* Not supported because 2nd REF_CLK not pinned out */
		},
		{
			/* [11] - 2 * SGMII */
			0x0,		0x0,		0x04040002, 0x04050003,
			0x0,		0x0, 		0x0, 		0x0,
		},
		{
			/* [12] */
		},
		{
			/* [13] - 1 * 100GE (4 lanes) */
			/* Not supported because 650MHz platform too slow */
		},
		{
			/* [14] - 1 * 100GE (4 lanes) */
			/* Not supported because 650MHz platform too slow */
		},
		{
			/* [15] - 2 * 50GE (2 lanes) */
			0x69000000, 0x69000001, 0x69010002, 0x69010003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [16] - 1 * 50GE (2 lanes), 2 * 25GE */
			0x69000000, 0x69000001, 0x68040002, 0x68050003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [17] - 4 * 25GE */
			0x68020000, 0x68030001, 0x68040002, 0x68050003,
			0x0,		0x0,		0x0,		0x0
		},
		{
			/* [18] - 2 * USXGMII/XFI, 2 * 25GE */
			0x28020000, 0x28030001, 0x68040002, 0x68050003,
			0x0,		0x0, 		0x0, 		0x0
		},
		{
			/* [19] - 2 * USXGMII/XFI, 2 * 25GE */
			/* Redundant with protocol 18 */
		},
		{
			/* [20] - 2 * 40GE (4 lanes) */
			0x2B000000, 0x2B000001, 0x2B000002, 0x2B000003,
			0x0,		0x0, 		0x0, 		0x0
		},
		{
			/* [21] - 6 * 25GE */
			/* Redundant with protocol 17 */
		},
		{
			/* [22] - 6 * USXGMII/XFI */
			/* Redundant with protocol 3 */
		},
	},
	{ /* SerDes block2 */
		{
			/* [0] */
		},
		{
			/* [1] */
		},
		{
			/* [2] */
		},
		{
			/* [3] */
		},
		{
			/* [4] */
		},
		{
			/* [5] */
		},
		{
			/* [6] - 2 * SGMII, 2 * USXGMII/XFI */
			/* Not supported because 2nd REF_CLK not pinned out */
		},
		{
			/* [7] - 4 * SGMII, 2 * USXGMII/XFI */
			/* Not supported because 2nd REF_CLK not pinned out */
		},
		{
			/* [8] - 2 * USXGMII/XFI */
			/* Not supported because 2nd REF_CLK not pinned out */
		},
		{
			/* [9] - 8 * SGMII */
			0x040A0000,	0x040B0001,	0x04100002, 0x04110003,
			0x040E0004,	0x040F0005,	0x040C0006, 0x040D0007,
		},
		{
			/* [10] - 4 * SGMII */
			0x040A0000,	0x040B0001,	0x04100002, 0x04110003,
			0x0,		0x0,		0x0,		0x0,
		},
		{
			/* [11] - 6 * SGMII */
			0x0,		0x040B0001,	0x04100002, 0x04110003,
			0x0,		0x040F0005,	0x040C0006, 0x040D0007,
		},
		{
			/* [12] - 4 * SGMII */
			0x040A0000,	0x040B0001,	0x04100002, 0x04110003,
			0x0,		0x0,		0x0,		0x0,
		},
		{
			/* [13] - 2 * SGMII */
			0x0,		0x0,		0x0,		0x0,
			0x0,		0x0,		0x040C0006, 0x040D0007,
		},
		{
			/* [14] - 4 * SGMII */
			0x0,		0x0,		0x04100002, 0x04110003,
			0x0,		0x0,		0x040C0006, 0x040D0007,
		}
	}
};
#elif defined(EMULATOR_LS2088)
static uint32_t serdes_pssr0[][8] = {
	{
		/* SerDes block 0 - 8 * XFI */
		0x28070000, 0x28060000, 0x28050000, 0x28040000,
		0x28030000, 0x28020000, 0x28010000, 0x28000000,
	}, {
		/* SerDes block 1 - 8 * SGMII */
		0x04080000, 0x04090000, 0x040a0000, 0x040b0000,
		0x040c0000, 0x040d0000, 0x040e0000, 0x040f0000,
	}
};
#elif defined(EMULATOR_LS1088) || defined(TMP_1088_SERDES_SIM)
static uint32_t serdes_pssr0[] = {
		/* Lane A: QSGMIIb (MAC 3-6)
		 * Lane B: QSGMIIb (MAC 7-10)
		 * Lane C: XFI1
		 * Lane D: XFI2
		 */
		0x05020000, 0x05060000, 0x28000000, 0x28010000,
};
#elif defined(EMULATOR_UA) || defined(TMP_UA_SERDES_SIM)
/* UA has only 1 XFI port on Lane A - Serdes1 */
static uint32_t serdes_pssr0[] = {
		/* Lane A: XFI1
		 */
		0x28000000, 0x10000, 0x20000, 0x30000,
};
#endif

/* Read Lane Protocol Select Status 0 register */
static inline uint32_t serdes_get_pssr0(struct serdes_desc *desc,
										int lane,
										uint8_t sd_proto)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;

#if defined(EMULATOR_LS2088)
	return serdes_pssr0[desc->id][lane];
#elif defined(EMULATOR_LS1088) || defined(EMULATOR_UA)
	return serdes_pssr0[lane];
#elif defined(TMP_1088_SERDES_SIM) || defined(TMP_UA_SERDES_SIM)
	if (IS_SIM)
		return serdes_pssr0[lane];
#elif defined(LX2160)
	if (soc_db_is_lx2162_package())
		return serdes_pssr0_lx2162[desc->id][sd_proto][lane];
	else
		return serdes_pssr0[desc->id][sd_proto][lane];
#endif

	return ioread32(&regs->lnapss_lnhpss[lane]);
}

/* translate the actual enet_if into PSSR0 format */
uint32_t serdes_enet_to_pssr0(enum enet_interface enet_if)
{
	uint32_t protocol = 0;

	switch (enet_if)
	{
	case FSL_ENET_IF_SGMII:
	case FSL_ENET_IF_SGMII_BASEX:
		protocol = PSSR0_PROTS_SGMII;
		break;
	case FSL_ENET_IF_XFI:
	case FSL_ENET_IF_XGMII:
	case FSL_ENET_IF_USXGMII:
		protocol = PSSR0_PROTS_XFI;
		break;
	case FSL_ENET_IF_QSGMII:
		protocol = PSSR0_PROTS_QSGMII;
		break;
	case FSL_ENET_IF_CAUI:
		protocol = PSSR0_PROTS_CAUI;
		break;
	default:
		return 0;
	}

	return protocol;
}

/* Update PSSR0 protocol: for LX2xxx packages */
static int serdes_update_pssr0(struct serdes_desc *desc,
					 int mac_id,
					 int lane,
					 uint8_t sd_proto,
					 uint32_t enet_if)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *reg = NULL, tmp_reg, protocol;

	/* figure out what pssr0 must be used by getting the package id */
#if defined(LX2160)
	if (soc_db_is_lx2162_package())
		reg = &serdes_pssr0_lx2162[desc->id][sd_proto][lane];
	else
		reg = &serdes_pssr0[desc->id][sd_proto][lane];
#endif

	tmp_reg = *reg;
	/* check if mac_id parameter matches the pssr0 content */
	if (mac_id != (int)((tmp_reg & desc->mac_mask) >> PSSR0_MAC_ID_SHIFT) + 1)
		return -1;

	/* translate the actual enet_if into PSSR0 format */
	protocol = serdes_enet_to_pssr0((enum enet_interface)enet_if);
	if (!protocol)
		return -1;

	tmp_reg &= ~PSSR0_PROTS_MASK;
	tmp_reg |= protocol << PSSR0_PROTS_SHIFT;
	*reg = tmp_reg;

	return 0;
}

static uint8_t get_no_lanes(struct serdes_desc *desc,
							int mac_id,
							int lane,
							uint8_t sd_proto)
{
	uint32_t reg;
	int i;
	uint8_t no_lanes = 0;
	uint32_t protocol;

	if (lane > desc->num_lanes - 1)
		return 0;

	for (i = lane; i < desc->num_lanes; i++) {
		reg = serdes_get_pssr0(desc, i, sd_proto);
		if (!reg)
			break;
		if (mac_id == (((reg & desc->mac_mask) >> PSSR0_MAC_ID_SHIFT) + 1)){
			protocol = (reg & PSSR0_PROTS_MASK) >> PSSR0_PROTS_SHIFT;
			switch( protocol ) {
				/* verify against MAC protocols */
				case PSSR0_PROTS_SGMII:
				case PSSR0_PROTS_XAUI:
				case PSSR0_PROTS_XFI:
				case PSSR0_PROTS_CAUI:
					no_lanes++;
					break;
			}
		}
	}

	return no_lanes;
}

static int serdes_enet_if_refclk_valid(uint32_t enet_if, uint32_t refclk_sel)
{
	int valid = 0;
	/*
		Recommended setting per protocol:
		SATA: 00000 or 00001
		PCIe: 00000 or 00001
		1G SGMII: 00000 or 00001 or 00010
		1000Base-KX: 00000 or 00001 or 00010
		10GBase-KR: 00010 or 00100
		USXGMII @5G, 10G: 00010 or 00100
		40G Ethernet: 00010 or 00100
		25/50/100G Ethernet: 00100 or 10100
	*/
	switch(enet_if) {
	case FSL_ENET_IF_SGMII:
	case FSL_ENET_IF_SGMII_BASEX:
		if (refclk_sel == PLLXCR0_REFCLK_SEL_100MHZ ||
			refclk_sel == PLLXCR0_REFCLK_SEL_125MHZ ||
			refclk_sel == PLLXCR0_REFCLK_SEL_156MHZ)
			valid = 1;
		break;
	case FSL_ENET_IF_XGMII:
	case FSL_ENET_IF_XFI:
	case FSL_ENET_IF_USXGMII:
		if (refclk_sel == PLLXCR0_REFCLK_SEL_156MHZ ||
			refclk_sel == PLLXCR0_REFCLK_SEL_161MHZ)
			valid = 1;
		break;
	case FSL_ENET_IF_CAUI:
		if (refclk_sel == PLLXCR0_REFCLK_SEL_161MHZ)
			valid = 1;
		break;
	default:
		valid = 0;
	}

	return valid;
}

/* API to onfigure a lane into a different SerDes protocol
 * Will return 1 on success (boolean like)
 */
int serdes_convert_enet_if(struct serdes_desc *desc,
						   struct serdes_mac_info *mac_info,
						   uint8_t sd_proto,
						   uint32_t pssr0_enet_if)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t is_pllf_used;
	uint32_t reg, refclk_sel;
	uint8_t lane, lane_for_regs;

	/* get the lane for further usage */
	if (serdes_mac_to_lane(desc, mac_info->mac_id, sd_proto, &lane)) {
		mac_info->converted = SERDES_IF_CONVERT_FAILURE;
		return 0;
	}

	/* update lane for regs */
	lane_for_regs = desc->num_lanes - lane - 1;

	/* determine which PLL is used by lane */
	reg = ioread32(&regs->lane_info[lane_for_regs].lnatgcr[0]);
	is_pllf_used = (uint32_t)((reg & TGCR0_USE_SLOW_PLL_MASK) >> TGCR0_USE_SLOW_PLL_SHIFT);

	/* get pll refclk:
	 * 00000b - 100 MHz
	 * 00001b - 125 MHz
	 * 00010b - 156.25 MHz
	 * 00100b - 161.1328125 MHz
	 */

	/* pll_cfg[0] is PLLF, pll_cfg[1] is PLLS */
	reg = ioread32(&regs->pll_cfg[!is_pllf_used].pllxcr[0]);
	refclk_sel = (uint32_t)((reg & PLLXCR0_REFCLK_SEL_MASK) >> PLLXCR0_REFCLK_SEL_SHIFT);

	if (!serdes_enet_if_refclk_valid(mac_info->enet_if, refclk_sel)) {
		mac_info->converted = SERDES_IF_CONVERT_FAILURE;
		return 0;
	}

	if (serdes_update_pssr0(desc, mac_info->mac_id, lane, sd_proto, mac_info->enet_if)) {
		mac_info->converted = SERDES_IF_CONVERT_FAILURE;
		return 0;
	}

	/* if we've gone so far, update mac rate and keep track of what was changed */
	mac_info->converted = SERDES_IF_CONVERT_SUCCESS;
	mac_info->enet_prev = (enum enet_interface)pssr0_enet_if;

	switch(mac_info->enet_if) {
		case FSL_ENET_IF_SGMII:
		case FSL_ENET_IF_SGMII_BASEX:
			mac_info->rate = 1000;
			break;
		case FSL_ENET_IF_XGMII:
		case FSL_ENET_IF_XFI:
		case FSL_ENET_IF_USXGMII:
			mac_info->rate = 10000;
			break;
		case FSL_ENET_IF_CAUI:
			mac_info->rate = 25000;
			break;
		default:
	}

	return 1;
}

unsigned char *serdes_get_enet_if_str(uint32_t enet_if)
{
	unsigned char *p = NULL;
	switch(enet_if) {
		case FSL_ENET_IF_SGMII:
			p = "SGMII";
			break;
		case FSL_ENET_IF_SGMII_BASEX:
			p = "BASE";
			break;
		case FSL_ENET_IF_XGMII:
			p = "XGMII";
			break;
		case FSL_ENET_IF_XFI:
			p = "XFI";
			break;
		case FSL_ENET_IF_USXGMII:
			p = "USXGMII";
			break;
		case FSL_ENET_IF_CAUI:
			p = "CAUI";
			break;
		default:
			p = "NONE";
			break;
	}
	return p;
}

void serdes_get_mac_info(struct serdes_desc *desc,
                         struct serdes_mac_info *mac_info,
                         int *lane,
                         uint8_t sd_proto)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t reg, protocol, isQsgmii;
	struct eiop_memac_desc memac_desc = {0};

	reg = serdes_get_pssr0(desc, *lane, sd_proto);

	memset(mac_info, 0, sizeof(struct serdes_mac_info));

	/* SerDes dosen't give information about eiop, for now we use 0 */
	mac_info->eiop_id = 0;

	/* PSSR0 holds MAC IDs 0-15, we support MAC IDs 1 - 16 */
	mac_info->mac_id =
	        (int)((reg & desc->mac_mask) >> PSSR0_MAC_ID_SHIFT) + 1;
	isQsgmii = (reg & PSSR0_IS_QSGMII_MASK) >> PSSR0_IS_QSGMII_SHIFT;
	protocol = (reg & PSSR0_PROTS_MASK) >> PSSR0_PROTS_SHIFT;

	/* return if ENET_IF is RGMII accordingly with ECx_PMUX */
	memac_desc.mac_id = mac_info->mac_id;
	soc_db_get_desc(SOC_MODULE_EIOP_MEMAC,
						SOC_DB_MAC_DESC_ID,
						&memac_desc,
						NULL);

	if(memac_desc.enet_if == FSL_ENET_IF_RGMII){
		return;
	}

	mac_info->lanes = get_no_lanes(desc, mac_info->mac_id, *lane, sd_proto);

	/* exit early, good luck with the next lane */
	if (mac_info->lanes == 0) {
		return;
	}
	/* Set valid as default */
	mac_info->valid = 1;

	switch (protocol) {
	case (PSSR0_PROTS_SGMII):
		if (isQsgmii) {
			mac_info->enet_if = FSL_ENET_IF_QSGMII;
			mac_info->rate = 1000;
		} else {
			if (is_two_and_half_sgmii(desc, *lane))
				mac_info->rate = 2500;
			else
				mac_info->rate = 1000;

			mac_info->enet_if = FSL_ENET_IF_SGMII;
		}
		break;
	case (PSSR0_PROTS_XAUI):
		mac_info->enet_if = FSL_ENET_IF_XGMII;
		mac_info->rate = 10000;
		break;
	case (PSSR0_PROTS_XFI):
		mac_info->enet_if = FSL_ENET_IF_XFI;
		mac_info->rate = 10000;
		/* SerDes for LX2  uses the Qsgmii bits to describe the rates */
		if (isQsgmii & PSSR0_RATE_40G)
			mac_info->rate = 40000;
		break;
	case (PSSR0_PROTS_CAUI):
		mac_info->enet_if = FSL_ENET_IF_CAUI;
		mac_info->rate = 25000;
		/* SerDes for LX2 uses the Qsgmii bits to describe the rates */
		if (isQsgmii)
			mac_info->rate = (isQsgmii & PSSR0_RATE_5_10_50G) ?
					50000 : 100000;
		break;
	default:
		/* not a MAC process next lane */
		mac_info->valid = 0;
		return;
	}

	/* Move the lane parameter to the next valid distinct MAC */
	*lane += mac_info->lanes - 1;
}

int serdes_get_mac_string(struct dcfg_desc *dcfg_desc,
						struct serdes_desc *desc,
						int *lane,
						char *buf,
						uint8_t sd_proto)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t reg, protocol, isQsgmii;
	int mac_id, no_lanes;
	int i;
	int count = 0;

	reg = serdes_get_pssr0(desc, *lane, sd_proto);

	/* PSSR0 holds MAC IDs 0-15, we support MAC IDs 1 - 16 */
	mac_id = (int)((reg & desc->mac_mask) >> PSSR0_MAC_ID_SHIFT) + 1;
	isQsgmii = (reg & PSSR0_IS_QSGMII_MASK) >> PSSR0_IS_QSGMII_SHIFT;
	protocol = (reg & PSSR0_PROTS_MASK) >> PSSR0_PROTS_SHIFT;
	no_lanes = get_no_lanes(desc, mac_id, *lane, sd_proto);

	/* jump if MAC is set as RGMII 
	 * Do not double print it as SGMII or QSGMII is set through SerDes
	 */
	for (i = 0; i < MAX_EC_CFG; i++){
		if (dcfg_desc->ec[i].valid)
			if((dcfg_desc->ec[i].port_id == mac_id) && dcfg_has_rgmii(dcfg_desc, i))
				return 0;
	}

	/* jump to the next lane; nothing here */
	if (no_lanes == 0) {
		return 0;
	}

	switch (protocol) {
	case (PSSR0_PROTS_SGMII):
		if (isQsgmii) {
			for (i = 0; i < 4; i++)
				count += sprintf(&buf[count], "QSGMII[%d] on SerDes %d, lane %d\n",
						mac_id + i, desc->id + 1, *lane);
		} else {
			if (is_two_and_half_sgmii(desc, *lane))
				count += sprintf(&buf[count],"SGMII2.5[%d] on SerDes %d, lane %d\n",
						mac_id, desc->id + 1, *lane);
			else
				count += sprintf(&buf[count],"SGMII[%d] on SerDes %d, lane %d\n",
						mac_id, desc->id + 1, *lane);
			}
		break;
	case (PSSR0_PROTS_XAUI):
		count += sprintf(&buf[count],"XAUI[%d] on SerDes %d, lane %d\n",
				mac_id, desc->id + 1, *lane);
		break;
	case (PSSR0_PROTS_XFI):
		count += sprintf(&buf[count],"XFI[%d] on SerDes %d, lane %d spread on %d lane(s)\n",
				mac_id, desc->id + 1, *lane, no_lanes);
		break;
	case (PSSR0_PROTS_CAUI):
		count += sprintf(&buf[count],"CAUI%d[%d] on SerDes %d, lane %d spread on %d lane(s)\n",
				no_lanes, mac_id, desc->id + 1, *lane, no_lanes);
		break;
	default:
		/* not a MAC, no prints and return to process next lane */
		return 0;
	}

	/* move the next lane with a distinct MAC */
	*lane += no_lanes - 1;

	return count;
}

void serdes_set_loopback(struct serdes_desc *desc)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t reg, i;

	pr_info("SerDes[%d]: Setting SerDes loopback\n", desc->id);
	for (i = 0; i < desc->num_lanes; i++) {
		/* Read Test Control/Status 3 register */
		reg = ioread32(&regs->lane_info[i].lnatcsr[0]);
		/* Clean LPBK_EN bits and set Digital Loop-back Mode */
		reg = (reg & ~TCSR0_SD_LPBK_SEL_MASK) | TCSR0_SD_LPBK_DIG_LB;
		iowrite32(reg, &regs->lane_info[i].lnatcsr[0]);
	}
}

int serdes_mac_to_lane(struct serdes_desc *desc, int mac_id, uint8_t sd_proto, uint8_t *lane)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t reg;
	uint32_t tmp_mac_id;
	uint32_t tmp_mac_proto;
	int i;

	for (i = 0; i < desc->num_lanes; i++) {
		reg = serdes_get_pssr0(desc, i, sd_proto);

		tmp_mac_id = ((reg & desc->mac_mask) >> PSSR0_MAC_ID_SHIFT) + 1;
		if (mac_id == (int) tmp_mac_id) {
			tmp_mac_proto = (reg & PSSR0_PROTS_MASK) >> PSSR0_PROTS_SHIFT;
			switch( tmp_mac_proto ) {
				/* verify against MAC protocols */
				case PSSR0_PROTS_SGMII:
				case PSSR0_PROTS_XAUI:
				case PSSR0_PROTS_XFI:
				case PSSR0_PROTS_CAUI:
					*lane = (uint8_t)i;
					return 0;
			}
		}
	}

	pr_err("No lane that matches to mac_id[%d] was found sd_proto[%x] \n", mac_id, sd_proto);
	return -EINVAL;
}

static void serdes_rstctl_ops(struct serdes_desc *desc,
		       int mac_id,
		       uint8_t master_lane,
		       uint32_t flags)
{
	uint32_t rr_ctl, *pRRSTCTL_master, *pTRSTCTL_master, tmp;
	struct serdes_mem_map *regs;

	regs = (struct serdes_mem_map *)desc->vaddr;

	/* pointer to LNmRRSTCTL */
	pRRSTCTL_master = (uint32_t *)&regs->lane_info[master_lane].lnarrstctl;

	/* pointer to LNmTRSTCTL */
	pTRSTCTL_master = (uint32_t *)&regs->lane_info[master_lane].lnatrstctl;

	/* stop rx and tx master lane */
	if (flags & RRSTCTL_STP_REQ_MASK) {
		iowrite32(RRSTCTL_STP_REQ_MASK, pRRSTCTL_master);
		timer_udelay(10);

		iowrite32(TRSTCTL_STP_REQ_MASK, pTRSTCTL_master);
		timer_udelay(10);

		pr_debug("mac(%d): Stopped lnarrstctl %08p = %08x\n", mac_id, pRRSTCTL_master, ioread32(pRRSTCTL_master));
		pr_debug("mac(%d): Stopped lnatrstctl %08p = %08x\n", mac_id, pTRSTCTL_master, ioread32(pTRSTCTL_master));
	}

	if (flags & RRSTCTL_DIS_MASK) {/* disable rx and tx master lane */
		iowrite32(RRSTCTL_DIS_MASK, pRRSTCTL_master);
		timer_udelay(10);

		iowrite32(TRSTCTL_DIS_MASK, pTRSTCTL_master);
		timer_udelay(10);

		pr_debug("mac(%d): Disabled lnarrstctl %08p = %08x\n", mac_id, pRRSTCTL_master, ioread32(pRRSTCTL_master));
		pr_debug("mac(%d): Disabled lnatrstctl %08p = %08x\n", mac_id, pTRSTCTL_master, ioread32(pTRSTCTL_master));
	}

	if (flags == 0) {
		/* enable the rx lane before reset, if it is disabled */
		rr_ctl = ioread32(pRRSTCTL_master);
		if (rr_ctl & RRSTCTL_DIS_MASK) {
			iowrite32(0x0, pRRSTCTL_master);
			timer_udelay(10);
			pr_debug("mac(%d): Enabled lnarrstctl %08p = %08x\n", mac_id, pRRSTCTL_master, ioread32(pRRSTCTL_master));
		}

		/* enable the tx lane before reset if it is disabled */
		rr_ctl = ioread32(pTRSTCTL_master);
		if (rr_ctl & TRSTCTL_DIS_MASK) {
			iowrite32(0x0, pTRSTCTL_master);
			timer_udelay(10);
			pr_debug("mac(%d): Enabled lnatrstctl %08p = %08x\n", mac_id, pTRSTCTL_master, ioread32(pTRSTCTL_master));
		}

		/* reset rx  master lane */
		iowrite32(RRSTCTL_RST_REQ_MASK | RRSTCTL_RST_EN_MASK, pRRSTCTL_master);
		timer_udelay(10);

		/* reset tx  master lane */
		iowrite32(TRSTCTL_RST_REQ_MASK, pTRSTCTL_master);
		timer_udelay(10);

		pr_debug("mac(%d): Reset lnarrstctl %08p = %08x\n", mac_id, pRRSTCTL_master, ioread32(pRRSTCTL_master));
		pr_debug("mac(%d): Reset lnatrstctl %08p = %08x\n", mac_id, pTRSTCTL_master, ioread32(pTRSTCTL_master));
	}
}

void serdes_disable_lane(enum enet_interface enet_if,
			 struct serdes_desc *desc,
			 int mac_id,
			 uint8_t master_lane)
{
	uint32_t flags;
	if (enet_if == FSL_ENET_IF_SGMII ||
			enet_if == FSL_ENET_IF_SGMII_BASEX) {
		flags = RRSTCTL_STP_REQ_MASK | RRSTCTL_DIS_MASK;
		pr_debug("mac(%d): Disabling serdes lane %d\n", mac_id, master_lane);
		serdes_rstctl_ops(desc, mac_id,
				  master_lane, flags);
	}
}

void serdes_enable_lane(struct serdes_desc *desc,
		int mac_id,
		uint8_t master_lane,
		uint8_t no_lanes,
		enum enet_interface enet_if)
{
	uint32_t flags;

	if (enet_if == FSL_ENET_IF_SGMII ||
	    enet_if == FSL_ENET_IF_SGMII_BASEX) {
		flags = 0;
		pr_debug("mac(%d): Enabling serdes lane %d\n", mac_id, master_lane);
		serdes_rstctl_ops(desc, mac_id,
				  master_lane, flags);
		/* reset the lane if CDR lock is lost */
		serdes_reset_receiver_lane(desc,
					   mac_id,
					   master_lane,
					   no_lanes,
					   enet_if);
	}
}

void serdes_reset_lane(struct serdes_desc *desc, int lane)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *trstctl, *rrstctl,*recr2;

	trstctl = &(regs->lane_info[lane].lnatrstctl);
	rrstctl = &(regs->lane_info[lane].lnarrstctl);
	recr2 = &(regs->lane_info[lane].lnarecr[2]);

	/* halt the lane and wait for it to actually halt*/
	iowrite32(ioread32(trstctl) | TRSTCTL_HLT_REQ_MASK, trstctl);
	while((ioread32(trstctl) & TRSTCTL_HLT_REQ_MASK) >> TRSTCTL_HLT_REQ_SHIFT) {}

	iowrite32(ioread32(rrstctl) | TRSTCTL_HLT_REQ_MASK, rrstctl);
	while((ioread32(rrstctl) & TRSTCTL_HLT_REQ_MASK) >> TRSTCTL_HLT_REQ_SHIFT) {}

	/* reconfigure */
	iowrite32(ioread32(recr2) & ~(RECR2_RXEQ_BST_MASK), recr2);
	timer_udelay(1);

	/* unreset the lane */
	iowrite32(ioread32(trstctl) | TRSTCTL_RST_REQ_MASK, trstctl);
	timer_udelay(1);

	iowrite32(ioread32(rrstctl) | TRSTCTL_RST_REQ_MASK, rrstctl);
	timer_udelay(1);

}

void serdes_enable_1000base_kx_an(struct serdes_desc *desc,
                                  int lane,
                                  int dpmac_id)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;;
	uint32_t *tgcr0, *pllcr1, *pccr8;
	uint32_t tpll_les = 0, sgmii_kx_mask;

	tgcr0 = &(regs->lane_info[lane].lnatgcr[0]);
	tpll_les = ioread32(tgcr0) & TGCR0_TPLL_LES_MASK;

	if (tpll_les) /* tpll_les=1: use PLLS */
		pllcr1 = &(regs->pll_cfg[1].pllxcr[1]);
	else /* tpll_les=0: use PLLF */
		pllcr1 = &(regs->pll_cfg[0].pllxcr[1]);

	iowrite32(ioread32(pllcr1) | PLLXCR1_EX_DLY_SEL, pllcr1);

	pccr8 = &(regs->pcc8);

	/* The bit that should be 'on' per mac:
	 * mac=1 (serdes_id=0) or mac=9 (serdes_id=1) -> bit=31
	 * mac=2 (serdes_id=0) or mac=10 (serdes_id=1) -> bit=27
	 * mac=3 (serdes_id=0) or mac=11 (serdes_id=1) -> bit=23
	 * mac=4 (serdes_id=0) or mac=12 (serdes_id=1) -> bit=19
	 * mac=5 (serdes_id=0) or mac=13 (serdes_id=1) -> bit=15
	 * mac=6 (serdes_id=0) or mac=14 (serdes_id=1) -> bit=11
	 * mac=7 (serdes_id=0) or mac=15 (serdes_id=1) -> bit=7
	 * mac=8 (serdes_id=0) or mac=16 (serdes_id=1) -> bit=3
	 */
	if (dpmac_id % 8)
		sgmii_kx_mask = 0x1 << (31 - 4 * ((dpmac_id % 8) - 1));
	else
		sgmii_kx_mask = 0x8;


	iowrite32(ioread32(pccr8) | sgmii_kx_mask, pccr8);
}

void serdes_init_1000base_kx(struct serdes_desc *desc,
                             int lane,
                             int dpmac_id)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;;
	uint32_t *rgcr1, *tecr0;

	rgcr1 = &(regs->lane_info[lane].lnargcr[1]);
	tecr0 = &(regs->lane_info[lane].lnatecr[0]);

	iowrite32(ioread32(rgcr1) & GCR1_KX_MASK, rgcr1);
	timer_udelay(1);

	iowrite32(ioread32(tecr0) & TECR0_AMP_RED_MASK, tecr0);
	timer_udelay(1);

	serdes_enable_1000base_kx_an(desc, lane, dpmac_id);
}

void serdes_set_tx_equalization_values(struct serdes_desc *desc,
                                       struct serdes_kr_cfg kr_cfg)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *trstctl, *rrstctl, *tecr0, *tecr1, val1, val2;

	trstctl = &(regs->lane_info[kr_cfg.lane].lnatrstctl);
	rrstctl = &(regs->lane_info[kr_cfg.lane].lnarrstctl);
	tecr0 = &(regs->lane_info[kr_cfg.lane].lnatecr[0]);
	tecr1 = &(regs->lane_info[kr_cfg.lane].lnatecr[1]);

	val1 = TECR0_INIT_VAL |
		kr_cfg.ratio_preq << TECR0_RATIO_PREQ_SHIFT |
		kr_cfg.ratio_pst1q << TECR0_RATIO_RATIO_PST1Q;

	val2 = 	kr_cfg.adpt_eq << TECR1_ADPT_EQ;

	/* halt the lane and wait for it to actually halt */
	iowrite32(ioread32(trstctl) | TRSTCTL_HLT_REQ_MASK, trstctl);
	while((ioread32(trstctl) & TRSTCTL_HLT_REQ_MASK) >> TRSTCTL_HLT_REQ_SHIFT) {}

	iowrite32(ioread32(rrstctl) | TRSTCTL_HLT_REQ_MASK, rrstctl);
	while((ioread32(rrstctl) & TRSTCTL_HLT_REQ_MASK) >> TRSTCTL_HLT_REQ_SHIFT) {}

	iowrite32(val1, tecr0);
	timer_udelay(1);

	iowrite32(val2, tecr1);
	timer_udelay(1);

	/* release reset */
	iowrite32(ioread32(trstctl) | TRSTCTL_RST_REQ_MASK, trstctl);
	timer_udelay(1);

	iowrite32(ioread32(rrstctl) | TRSTCTL_RST_REQ_MASK, rrstctl);
	timer_udelay(1);

}

int serdes_check_bin_status(struct serdes_desc *desc,
                            enum serdes_10gbase_kr_bins bin_sel, int lane)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	int i, timeout, negative_count = 0, early = 0;
	uint32_t bin_snap_shot[NUM_OF_SNAPSHOTS];
	uint32_t *recr3, *recr4;
	uint32_t reg;

	recr3 = &(regs->lane_info[lane].lnarecr[3]);
	recr4 = &(regs->lane_info[lane].lnarecr[4]);

	for (i = 0; i < NUM_OF_SNAPSHOTS; i++) {
		/* wait RECR3_EQ_SNAP_DN has cleared */
		timeout = 100;
		while ((ioread32(recr3) & RECR3_EQ_SNAP_DN)) {
				timer_udelay(1);
				timeout--;
				if (timeout == 0)
					break;
		}

		/* set RECR4[BIN_DATA_SEL] to BinM1/BinLong */
		reg = ioread32(recr4);
		reg &= ~RECR4_BIN_DATA_SEL_MASK;
		if (bin_sel == SERDES_10GBASE_KR_BIN_M1)
			reg |= RECR4_DATA_SEL_BIN_M1;
		else
			reg |= RECR4_DATA_SEL_BIN_LONG;

		iowrite32(reg, recr4);

		/* start snap shot */
		iowrite32(ioread32(recr3) | RECR3_EQ_SNAP_STRT_MASK, recr3);

		/* wait for SNP done */
		timeout = 100;

		do {
			timer_udelay(1);
		} while (!(ioread32(recr3) & RECR3_EQ_SNAP_DN) && timeout--);

		/* read and save the snap shot */
		bin_snap_shot[i] = (ioread32(recr4) &
				RECR4_EQ_BIN_DATA_MASK) >> RECR4_EQ_BIN_DATA_SHIFT;
		if (bin_snap_shot[i] & RECR4_EQ_BIN_DATA_SIGN_MASK)
			negative_count++;

		/* terminate the snap shot by setting RECR3[EQ_SNAP_STRT] */
		iowrite32(ioread32(recr3) & ~RECR3_EQ_SNAP_STRT_MASK, recr3);
	}

	if (((bin_sel == SERDES_10GBASE_KR_BIN_M1) &&
		negative_count > BIN_M1_THRESHOLD) ||
	    ((bin_sel == SERDES_10GBASE_KR_BIN_LONG &&
		    negative_count > BIN_LONG_THRESHOLD))) {
		early = 1;
	}

	return early;
}

/* there is no way of telling which SerDes is used in dpmac.c;
 * the purpose of this api is to tell if serdes is SFI compatible and to get the values
 */
int is_serdes_sfi_capable(struct serdes_eq_settings *sfi_settings)
{
	sfi_settings->eq_amp_red = SERDES_28G_SFI_EQ_AMP_RED;
	sfi_settings->eq_post1q = SERDES_28G_SFI_EQ_POST1Q;
	sfi_settings->eq_preq = SERDES_28G_SFI_EQ_PREQ;
	sfi_settings->eq_type = SERDES_28G_SFI_EQ_TYPE;
	sfi_settings->sgn_preq = SERDES_28G_SFI_SGN_PREQ;
	sfi_settings->sgn_post1q = SERDES_28G_SFI_SGN_POST1Q;

	return 1;
}

int serdes_eq_setup(struct serdes_desc *desc, int dpmac_id, struct serdes_eq_settings *serdes_cfg)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	struct serdes_mac_info *dpmac = NULL;
	struct dcfg_desc dcfg_desc = { 0 };
	uint32_t *tecr0_reg, tecr0_val;
	uint8_t master_lane, no_lanes, lane;
	uint8_t sd_proto = 0;

	sys_get_desc(SOC_MODULE_DCFG,
				SOC_DB_NO_MATCH_FIELDS,
				&dcfg_desc,
				NULL);

	if (dcfg_desc.sd[desc->id].valid) {
			sd_proto = (uint8_t)dcfg_get_serdes_protocol(dcfg_desc.sd[desc->id].rcwsr_id,
					dcfg_desc.sd[desc->id].rcwsr_mask);
	} else {
		pr_err("Could not find serdes protocol for dpmac %d\n", dpmac_id);
		return -EINVAL;
	}

	/* get master lane number from dpmac_id and serdes_desc */
	if (serdes_mac_to_lane(desc, dpmac_id, sd_proto, &master_lane))
		return -EEXIST;

	/* find if mac has multiple lanes */
	no_lanes = get_no_lanes(desc, dpmac_id, master_lane, sd_proto);

	pr_info("serdes_cfg: amp=%#x, post1q=%#x, preq=%#x, eq_type=%#x\n",
			serdes_cfg->eq_amp_red, serdes_cfg->eq_post1q, serdes_cfg->eq_preq, serdes_cfg->eq_type);

	/* update fields that require change */
	/* iterate through all mac lanes and apply new settings */
	for (lane = master_lane; lane < (master_lane + no_lanes); lane++) {
		tecr0_reg = &(regs->lane_info[desc->num_lanes - lane - 1].lnatecr[0]);
		tecr0_val = ioread32(tecr0_reg);

		/* update bits if necessary */
		SERDES_SET_CFG(SERDES_28G_TECR0, serdes_cfg->eq_type,    tecr0_val, EQ_TYPE);
		SERDES_SET_CFG(SERDES_28G_TECR0, serdes_cfg->sgn_preq,   tecr0_val, SGN_PREQ);
		SERDES_SET_CFG(SERDES_28G_TECR0, serdes_cfg->eq_preq,    tecr0_val, EQ_PREQ);
		SERDES_SET_CFG(SERDES_28G_TECR0, serdes_cfg->sgn_post1q, tecr0_val, SGN_POST1Q);
		SERDES_SET_CFG(SERDES_28G_TECR0, serdes_cfg->eq_post1q,  tecr0_val, EQ_POST1Q);
		SERDES_SET_CFG(SERDES_28G_TECR0, serdes_cfg->eq_amp_red, tecr0_val, EQ_AMP_RED);
		//pr_info("serdes_eq_setup: dpmac %d lane %d, %#x --> %#x\n", dpmac_id, lane, tecr0_reg, tecr0_val);

		/* write the updated tecr0 value */
		if (ioread32(tecr0_reg) != tecr0_val)
			iowrite32(tecr0_val, tecr0_reg);
	}

	return 0;
}

int get_serdes_eq_setup(struct serdes_desc *desc, int dpmac_id, struct serdes_eq_settings *attr)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	struct dcfg_desc dcfg_desc = { 0 };
	uint32_t *tecr0_reg, tecr0_val;
	uint8_t master_lane = 0;
	uint8_t sd_proto = 0;

	sys_get_desc(SOC_MODULE_DCFG,
				SOC_DB_NO_MATCH_FIELDS,
				&dcfg_desc,
				NULL);

	if (dcfg_desc.sd[desc->id].valid) {
			sd_proto = (uint8_t)dcfg_get_serdes_protocol(dcfg_desc.sd[desc->id].rcwsr_id,
					dcfg_desc.sd[desc->id].rcwsr_mask);
	} else {
		pr_err("Could not find serdes protocol for dpmac %d\n", dpmac_id);
		return -EINVAL;
	}

	/* get master lane number from dpmac_id and serdes_desc */
	if (serdes_mac_to_lane(desc, dpmac_id, sd_proto, &master_lane))
		  return -EINVAL;

	tecr0_reg = &(regs->lane_info[desc->num_lanes - master_lane - 1].lnatecr[0]);
	tecr0_val = ioread32(tecr0_reg);

	SERDES_GET_CFG(SERDES_28G_TECR0, tecr0_val, attr->eq_type, EQ_TYPE);
	SERDES_GET_CFG(SERDES_28G_TECR0, tecr0_val, attr->sgn_preq, SGN_PREQ);
	SERDES_GET_CFG(SERDES_28G_TECR0, tecr0_val, attr->eq_preq, EQ_PREQ);
	SERDES_GET_CFG(SERDES_28G_TECR0, tecr0_val, attr->sgn_post1q, SGN_POST1Q);
	SERDES_GET_CFG(SERDES_28G_TECR0, tecr0_val, attr->eq_post1q, EQ_POST1Q);
	SERDES_GET_CFG(SERDES_28G_TECR0, tecr0_val, attr->eq_amp_red, EQ_AMP_RED);

	return 0;
}

void convert_xfi2usxgmiia(struct serdes_desc *desc, int dpmac_id)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *trstctl, *rrstctl, *tecr0, *tecr1, *pccC, sxgmii_mask;
	uint8_t lane, lane_for_regs;
	struct dcfg_desc dcfg_desc = { 0 };
	uint8_t sd_proto = 0;
	unsigned int timeout = 100000;
	
	sys_get_desc(SOC_MODULE_DCFG,
				SOC_DB_NO_MATCH_FIELDS,
				&dcfg_desc,
				NULL);
	
	if (dcfg_desc.sd[desc->id].valid){
			sd_proto = (uint8_t)dcfg_get_serdes_protocol(dcfg_desc.sd[desc->id].rcwsr_id,
					dcfg_desc.sd[desc->id].rcwsr_mask);
	}
	else
	{
		pr_err("Could not find serdes protocol for dpmac %d\n", dpmac_id);
		return;
	}
	
	if (serdes_mac_to_lane(desc, dpmac_id, sd_proto, &lane))
		return;
	
	lane_for_regs = desc->num_lanes - lane - 1;
		
	trstctl = &(regs->lane_info[lane_for_regs].lnatrstctl);
	rrstctl = &(regs->lane_info[lane_for_regs].lnarrstctl);
	tecr0 = &(regs->lane_info[lane_for_regs].lnatecr[0]);
	tecr1 = &(regs->lane_info[lane_for_regs].lnatecr[1]);
	pccC = &(regs->pccC);

	sxgmii_mask = 0x1 << (4 * (lane + 1) - 1);

	/* halt the lane and wait for it to actually halt */
	iowrite32(ioread32(trstctl) | TRSTCTL_HLT_REQ_MASK, trstctl);
	while(((ioread32(trstctl) & TRSTCTL_HLT_REQ_MASK) >> TRSTCTL_HLT_REQ_SHIFT)
			&& --timeout) {
		timer_udelay(10);
	}
	
	if(!timeout) {
		pr_err("Timeout: TX halting process not completed, lane in reset mode\n");
		return;
	}

	timeout = 100000;
	iowrite32(ioread32(rrstctl) | TRSTCTL_HLT_REQ_MASK, rrstctl);
	while(((ioread32(rrstctl) & TRSTCTL_HLT_REQ_MASK) >> TRSTCTL_HLT_REQ_SHIFT)
			&& --timeout) {
		timer_udelay(10);
	}

	if(!timeout) {
		pr_err("Timeout: RX halting process not completed, lane in reset mode\n");
		return;
	}
	/* check if custom eq settings are already applied;
	 * if so, do not apply the SXGMII TECR0 values
	 */
	if (dpc.macs[dpmac_id - 1].serdes_cfg.cfg != SERDES_CFG_CUSTOM) {
		iowrite32((ioread32(tecr0) & ~TECR0_SXGMII_CHANGE_MASK)| TECR0_SXGMII_INIT_VAL, tecr0);
		timer_udelay(1);
	}

	iowrite32((ioread32(tecr1) & ~TECR1_SXGMII_CHANGE_MASK) | TECR1_ADPT_EQ_SXGMII, tecr1);
	timer_udelay(1);

	iowrite32((ioread32(pccC) & ~sxgmii_mask) , pccC);

	/* release reset */
	iowrite32(ioread32(trstctl) | TRSTCTL_RST_REQ_MASK, trstctl);
	timer_udelay(1);

	iowrite32(ioread32(rrstctl) | TRSTCTL_RST_REQ_MASK, rrstctl);
	timer_udelay(1);
}

#ifdef TKT320141

void serdes_reset_protocol(struct serdes_desc *desc,
								int mac_id,
								uint8_t master_lane,
								uint8_t no_lanes,
								enum enet_interface enet_if)
{
	uint32_t *pGaCR0 = NULL;
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	
	switch (enet_if)
	{
		case FSL_ENET_IF_XFI:
			if (no_lanes == 4)
				pGaCR0 = (master_lane == 3) ? ((uint32_t *)&regs->e40gbcr[0]) : 
						((master_lane == 7) ? ((uint32_t *)&regs->e40gacr[0]) : NULL);
			break;	

		case FSL_ENET_IF_CAUI:
			if (no_lanes == 4)
				pGaCR0 = (master_lane == 3) ? ((uint32_t *)&regs->e100gbcr[0]) : 
						((master_lane == 7) ? ((uint32_t *)&regs->e100gacr[0]) : NULL);
			else if (no_lanes == 2)
				pGaCR0 = (master_lane == 5) ? ((uint32_t *)&regs->e50gbcr[0]) : 
						((master_lane == 7) ? ((uint32_t *)&regs->e50gacr[0]) : NULL);
			else if (no_lanes == 1)
				pGaCR0 = (uint32_t *)&regs->e25gacr[master_lane][0];
			break;
			
		default:
			break;
	}

	if (pGaCR0 != NULL)
	{
		/* reset E25G/E40G/E100G protocol */
		iowrite32(EXXGaCR0_RST_MASK | EXXGaCR0_PD_MASK, pGaCR0);
		timer_udelay(1);
		iowrite32(EXXGaCR0_PD_MASK, pGaCR0);
		timer_udelay(1);
		iowrite32(0x00000000, pGaCR0);
		timer_udelay(1);
		iowrite32(EXXGaCR0_RST_MASK, pGaCR0);
	}
}

int get_cdr_lock(struct serdes_desc *desc, uint8_t lane)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *rrstctl_ptr = (uint32_t *)&regs->lane_info[lane].lnarrstctl;
	uint32_t rrstctl = ioread32(rrstctl_ptr);

#if 0
	pr_info("lane = %d, rrstctl_ptr = %#x, val = %#x\n", lane, rrstctl_ptr, rrstctl);
#endif
	return !!(rrstctl & RRSTCTL_CDR_LOCK_MASK);
}

/*
 * Resets the SerDes receiver lane if CDR_LOCK is not set
 * Return values:
 *  0 when CDR_LOCK = 1, no reset is performed
 *  1 when CDR_LOCK = 0, receiver lane reset was triggered
 */
int serdes_reset_receiver_lane(struct serdes_desc *desc,
								int mac_id,
								uint8_t master_lane,
								uint8_t no_lanes,
								enum enet_interface enet_if)
{
	uint32_t rr_ctl, *pRRSTCTL_master, *pRRSTCTL_slave;
	uint8_t tries, master_reset = 0, i;
	struct serdes_mem_map *regs;

	regs = (struct serdes_mem_map *)desc->vaddr;

	/* pointer to LNmRRSTCTL */
	pRRSTCTL_master = (uint32_t *)&regs->lane_info[master_lane].lnarrstctl;

	/* check the CDR lock on all the lanes associated with the port;
	 * if the CDR is not locked on any of the lanes then perform a reset of the
	 * master lane
	 */
	for (i = 0; i < no_lanes; i++)
	{
		pRRSTCTL_slave = (uint32_t *)&regs->lane_info[master_lane - i].lnarrstctl;

		/* attempt to reset the lane 2 times */
		tries = 2;
		while (tries-- > 0) {
			rr_ctl = ioread32(pRRSTCTL_slave);
			/* perform serdes lane reset if either the CDR is not locked or
			 * the PCS indicates link down */
			if (!(rr_ctl & RRSTCTL_CDR_LOCK_MASK))
			{
//				pr_info("CDR not LOCKED - serdes: %d, master_lane: %d, no_lanes: %d, MAC: %d, pRRSTCTL_master: %#x, pRRSTCTL_slave: %#x, rr_ctl: %#x\n",
//						desc->id, master_lane, no_lanes, mac_id, pRRSTCTL_master, pRRSTCTL_slave, rr_ctl);

				/* reset the lane; send reset request */
				iowrite32(RRSTCTL_RST_REQ_MASK | RRSTCTL_RST_EN_MASK, pRRSTCTL_master);
//				serdes_reset_protocol(desc, mac_id, master_lane, no_lanes, enet_if);
				timer_udelay(10);
				master_reset = 1;
//				rr_ctl = ioread32(pRRSTCTL_slave);
//				pr_info("CDR after reset - serdes: %d, master_lane: %d, no_lanes: %d, MAC: %d, pRRSTCTL_master: %#x, pRRSTCTL_slave: %#x, rr_ctl: %#x\n",
//						desc->id, master_lane, no_lanes, mac_id, pRRSTCTL_master, pRRSTCTL_slave, rr_ctl);
			}
			else
				break;
		}

		/* no need to continue checking CDR lock on other lanes since lane reset
		 * was already performed on the master lane
		 */
		if (master_reset)
			break;
	}

	return master_reset;
}

void serdes_wa_cdr_lock()
{
	struct serdes_desc serdes_desc = { 0 };
	struct dcfg_desc dcfg_desc = { 0 };
	struct serdes_mac_info mac_info = { 0 };
	int iter = 0, disable, phy_id;
	uint8_t sd_proto = 0, master_lane = 0, no_lanes = 0;
	int lane = 0, i;
	uint32_t link_type;
	uint32_t *pE40GaCR0 = NULL;

	/* skip for simulator */
	if (IS_SIM)
		return;

	sys_get_desc(SOC_MODULE_DCFG,
			SOC_DB_NO_MATCH_FIELDS,
			&dcfg_desc,
			NULL);

	while (soc_db_get_desc(SOC_MODULE_SERDES,
						   SOC_DB_NO_MATCH_FIELDS,
						   &serdes_desc, &iter) == 0) {
		if (dcfg_desc.sd[serdes_desc.id].valid)
			sd_proto = (uint8_t)dcfg_get_serdes_protocol(dcfg_desc.sd[serdes_desc.id].rcwsr_id,
					dcfg_desc.sd[serdes_desc.id].rcwsr_mask);
		else
			continue;

		for (i = 0; i < serdes_desc.num_lanes; i++) {
			memset(&mac_info, 0, sizeof (struct serdes_mac_info));
			master_lane = serdes_desc.num_lanes - (uint8_t)i - 1;
			no_lanes = (uint8_t)i;

			/* obtain MAC id based on lane */
			serdes_get_mac_info(&serdes_desc, &mac_info, &i, sd_proto);
			no_lanes = (uint8_t)i - no_lanes + 1;

			dpc_get_mac_info(mac_info.mac_id, &disable, &link_type,
								&phy_id, 0, 0, 0, 0);

			/* apply workaround only if:
			 * - mac is valid
			 * - mac type is not TYPE_NONE in dpc
			 */
			if (!mac_info.valid ||
				(link_type == DPMAC_LINK_TYPE_NONE) || (link_type == DPMAC_LINK_TYPE_RECYCLE))
				continue;

			serdes_reset_receiver_lane(&serdes_desc,
										mac_info.mac_id,
										master_lane,
										no_lanes,
										mac_info.enet_if);
		}
	}
}
#endif

void serdes_wa_gain_tecr()
{
	struct serdes_desc serdes_desc = { 0 };
	struct dcfg_desc dcfg_desc = { 0 };
	struct serdes_mac_info mac_info = { 0 };
	int iter = 0, disable, phy_id;
	uint8_t sd_proto = 0, master_lane = 0, no_lanes = 0;
	int lane = 0, i;
	uint32_t link_type;
	uint32_t *pTECR0 = NULL;
	struct serdes_mem_map *regs = NULL;

	/* skip for simulator */
	if (IS_SIM)
		return;

	sys_get_desc(SOC_MODULE_DCFG,
			SOC_DB_NO_MATCH_FIELDS,
			&dcfg_desc,
			NULL);

	while (soc_db_get_desc(SOC_MODULE_SERDES,
						   SOC_DB_NO_MATCH_FIELDS,
						   &serdes_desc, &iter) == 0) {
		if (dcfg_desc.sd[serdes_desc.id].valid)
			sd_proto = (uint8_t)dcfg_get_serdes_protocol(dcfg_desc.sd[serdes_desc.id].rcwsr_id,
					dcfg_desc.sd[serdes_desc.id].rcwsr_mask);
		else
			continue;

		for (i = 0; i < serdes_desc.num_lanes; i++) {
			memset(&mac_info, 0, sizeof (struct serdes_mac_info));
			master_lane = serdes_desc.num_lanes - (uint8_t)i - 1;
			no_lanes = (uint8_t)i;

			/* obtain MAC id based on lane */
			serdes_get_mac_info(&serdes_desc, &mac_info, &i, sd_proto);
			no_lanes = (uint8_t)i - no_lanes + 1;

			dpc_get_mac_info(mac_info.mac_id, &disable, &link_type,
								&phy_id, 0, 0, 0, 0);

			/* apply workaround only if:
			 * - mac is valid
			 * - mac type is not TYPE_NONE in dpc
			 */
			if (!mac_info.valid ||
				(link_type == DPMAC_LINK_TYPE_NONE) || (link_type == DPMAC_LINK_TYPE_RECYCLE))
				continue;

#if 0
			/* Set gain for 25G ports (no_lane = 1) */
			if ((mac_info.enet_if == FSL_ENET_IF_CAUI) && no_lanes == 1)
			{
				uint32_t tecr0_val;
				regs = (struct serdes_mem_map *)serdes_desc.vaddr;
				pTECR0 = (uint32_t *)&regs->lane_info[serdes_desc.num_lanes - (i+1)].lnatecr[0];
				tecr0_val = ioread32(pTECR0);
				pr_info("tecr0(%#x)_val 25G = 0x%8x\n", pTECR0, tecr0_val);
				tecr0_val &= 0xFFFFFFC0;
				tecr0_val |= 0x00000020; /* 1.1 * 800mV amplitude */
				iowrite32(tecr0_val, pTECR0);
			}
#endif
			/* Set gain for 40G ports (no_lane = 4) */
			if ((mac_info.enet_if == FSL_ENET_IF_XFI) && no_lanes == 4)
			{
				uint32_t tecr0_val;
				int k;

				regs = (struct serdes_mem_map *)serdes_desc.vaddr;

				for (k = 0; k < no_lanes; k++)
				{
					pTECR0 = (uint32_t *)&regs->lane_info[serdes_desc.num_lanes - (i - k + 1)].lnatecr[0];
					tecr0_val = ioread32(pTECR0);
					tecr0_val &= 0xFFFFE0C0; // Full amplitude + de-emphasis ratio of 1
					iowrite32(tecr0_val, pTECR0);
				}
			}
		}
	}
}

#ifdef ERR050369
void serdes_apply_caui_err050369(struct serdes_desc *desc, int dpmac_id)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	struct dcfg_desc dcfg_desc = { 0 };
	uint32_t *reg_ptr, reg_val;
	uint8_t lane, lane_for_regs, no_lanes, lane_iter;
	uint8_t sd_proto = 0;
	unsigned int timeout = 100000;

	/* ERR050369 only applies for LX2 Rev2 silicons */
	if (!soc_db_is_lx2_rev2()) {
		return;
	}

	/* find out what SerDes protocol is in use */
	sys_get_desc(SOC_MODULE_DCFG, SOC_DB_NO_MATCH_FIELDS, &dcfg_desc, NULL);
	if (dcfg_desc.sd[desc->id].valid){
			sd_proto = (uint8_t)dcfg_get_serdes_protocol(dcfg_desc.sd[desc->id].rcwsr_id, dcfg_desc.sd[desc->id].rcwsr_mask);
	}
	else {
		pr_err("Could not find serdes protocol for dpmac %d\n", dpmac_id);
		return;
	}

	/* compute the serdes memory map structure index */
	if (serdes_mac_to_lane(desc, dpmac_id, sd_proto, &lane))
		return;

	no_lanes = get_no_lanes(desc, dpmac_id, lane, sd_proto);
	//pr_debug("dpmac %d: master lane=%d, lane_for_regs=%d, no_lanes=%d\n",
	//		dpmac_id, lane, lane_for_regs, no_lanes);

	/* Reset must occur in a specific order: for the multi-lane protocols, HLT_REQ needs to be
	 * done first on all the lanes of a port, with "lane 0" of the port halted last, and the
	 * reconfiguration waiting until "lane 0" is halted. Similarly, RST_REQ needs to be done
	 * on all lanes of a port after all lanes are reconfigured, with "lane 0" of the port reset last.
	 */

	for (lane_iter = no_lanes; lane_iter > 0; lane_iter--) {
		lane_for_regs = desc->num_lanes - lane_iter - lane;

		/* halt lane before anything */
		timeout = 100;
		reg_ptr = &regs->lane_info[lane_for_regs].lnarrstctl;
		//pr_debug("halt  %d: master lane=%d, lane_for_regs=%d, no_lanes=%d\n",
		//		dpmac_id, lane, lane_for_regs, no_lanes);
		reg_val = ioread32(reg_ptr) | RRSTCTL_HLT_REQ_MASK;
		iowrite32(reg_val, reg_ptr);

		while ((ioread32(reg_ptr) & RRSTCTL_HLT_REQ_MASK) && --timeout) {
			timer_udelay(10);
		}

		/* RGCR0 */
		reg_ptr = &regs->lane_info[lane_for_regs].lnargcr[0];
		reg_val = (ioread32(reg_ptr) & ~ERR050369_RGCR0_MASK) | ERR050369_RGCR0_VAL;
		iowrite32(reg_val, reg_ptr);

		/* RGCR1 */
		reg_ptr = &regs->lane_info[lane_for_regs].lnargcr[1];
		reg_val = (ioread32(reg_ptr) & ~ERR050369_RGCR1_MASK) | ERR050369_RGCR1_VAL;
		iowrite32(reg_val, reg_ptr);

		/* RECR0 */
		reg_ptr = &regs->lane_info[lane_for_regs].lnarecr[0];
		reg_val = (ioread32(reg_ptr) & ~ERR050369_RECR0_MASK) | ERR050369_RECR0_VAL;
		iowrite32(reg_val, reg_ptr);

		/* RECR2 */
		reg_ptr = &regs->lane_info[lane_for_regs].lnarecr[2];
		reg_val = (ioread32(reg_ptr) & ~ERR050369_RECR2_MASK) | ERR050369_RECR2_VAL;
		iowrite32(reg_val, reg_ptr);

		/* RSCCR0 */
		reg_ptr = &regs->lane_info[lane_for_regs].lnarsccr[0];
		reg_val = (ioread32(reg_ptr) & ~ERR050369_RSCCR0_MASK) | ERR050369_RSCCR0_VAL;
		iowrite32(reg_val, reg_ptr);

		/* PLLFCR9 */
		reg_ptr = &regs->pll_cfg[0].pllxcr[9];
		reg_val = (ioread32(reg_ptr) & ~ERR050369_PLLFCR9_MASK) | ERR050369_PLLFCR9_VAL;
		iowrite32(reg_val, reg_ptr);

		/* TGCR1 */
		reg_ptr = &regs->lane_info[lane_for_regs].lnatgcr[1];
		reg_val = (ioread32(reg_ptr) & ~ERR050369_TGCR1_MASK) | ERR050369_TGCR1_VAL;
		iowrite32(reg_val, reg_ptr);
	}

	for (lane_iter = no_lanes; lane_iter > 0; lane_iter--) {
		lane_for_regs = desc->num_lanes - lane_iter - lane;
		//pr_debug("reset %d: master lane=%d, lane_for_regs=%d, no_lanes=%d\n",
		//		dpmac_id, lane, lane_for_regs, no_lanes);
		/* reset */
		reg_ptr = &regs->lane_info[lane_for_regs].lnarrstctl;
		reg_val = RRSTCTL_RST_EN_MASK | RRSTCTL_RST_REQ_MASK;
		iowrite32(reg_val, reg_ptr);
		timeout = 10;
		while (!(ioread32(reg_ptr) & RRSTCTL_RST_DONE_MASK) && --timeout) {
			timer_udelay(10);
		}
	}
}
#endif /* ERR050369 */

static void caui_setup_fec(struct serdes_desc *desc, int dpmac_id, uint8_t master_lane, uint8_t no_lanes, enum dpmac_fec_mode fec_mode)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *protocol_reg = NULL;
	uint32_t protocol_bits, protocol_mask, protocol_val;

	/* figure out if it's a 25G or 100G interface by number of lanes */
	if (no_lanes == 1) {
		/* CAUI-1 E25GaCR2 */
		protocol_reg = (uint32_t *)&regs->e25gacr[master_lane][2];
	} else if (no_lanes == 4) {
		/* CAUI-4 E100GaCR2 */
		if (dpmac_id == 1)
			protocol_reg = (uint32_t *)&regs->e100gacr[2];
		else if (dpmac_id == 2)
			protocol_reg = (uint32_t *)&regs->e100gbcr[2];
	}

	if (!protocol_reg) {
		pr_err("%sFEC not configurable for MAC[%d]\n",
				(fec_mode == DPMAC_FEC_FC) ?
						"FC-": ((fec_mode == DPMAC_FEC_RS) ? "RS-" : ""),
				dpmac_id);
		return;
	} else {
		if (fec_mode == DPMAC_FEC_NONE)
			pr_warn("FEC disabled for MAC[%d]\n", dpmac_id);
		else
			pr_warn("%sFEC enabled for MAC[%d]\n", (fec_mode == DPMAC_FEC_FC) ? "FC-":"RS-", dpmac_id);
	}

	/* setup protocol bits based on FEC mode */
	protocol_bits = 0;
	protocol_mask = 0;
	switch (fec_mode) {
		case DPMAC_FEC_FC:
			if (no_lanes == 1) {
				protocol_bits = E25GACR2_FEC_ENA;
				protocol_mask = E25GACR2_FEC_ALL_MASK;
			}
			break;
		case DPMAC_FEC_RS:
			if (no_lanes == 1) {
				protocol_bits = E25GACR2_FEC91_ENA;
				protocol_mask = E25GACR2_FEC_ALL_MASK;
			}
			else if (no_lanes == 4) {
				protocol_bits = E100GACR2_FEC91_ENA;
				protocol_mask = E100GACR2_FEC_ALL_MASK;
			}
			break;
		case DPMAC_FEC_NONE:
		default:
			protocol_bits = 0;
			protocol_mask = E25GACR2_FEC_ALL_MASK | E100GACR2_FEC_ALL_MASK;
			break;
	}

	/* calculus of new ExxGaCR2 value:
	 * 1. removal of existent FEC bits (if any)
	 * 2. applying the new settings */
	protocol_val = ioread32(protocol_reg);
	protocol_val &= ~protocol_mask;
	protocol_val |= protocol_bits;
	iowrite32(protocol_val, protocol_reg);
}

static void xfi_set_fault(struct serdes_desc *desc, int dpmac_id, uint8_t master_lane,
			uint8_t no_lanes, enum serdes_fault_type fault_type, uint8_t en)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *protocol_reg = NULL;
	uint32_t protocol_bits, protocol_val;

	/* figure out if it's a 10G or 40G interface by number of lanes */
	if (no_lanes == 1) {
		/* SXGMIIaCR2 */
		protocol_reg = (uint32_t *)&regs->sxgmiiacr[master_lane][2];
	} else if (no_lanes == 4) {
		/* E40GaCR2 */
		if (dpmac_id == 1)
			protocol_reg = (uint32_t *)&regs->e40gacr[2];
		/* E40GbCR2 */
		else if (dpmac_id == 2)
			protocol_reg = (uint32_t *)&regs->e40gbcr[2];
	}

	if (!protocol_reg) {
		pr_err("%s not configurable for MAC[%d]\n",
				(fault_type == SERDES_REMOTE_FAULT) ?
						"REMOTE FAULT": "LOCAL FAULT", dpmac_id);
		return;
	}

	protocol_bits = 0;
	switch (fault_type) {
		case SERDES_REMOTE_FAULT:
			if (no_lanes == 1)
				protocol_bits = SXGMII_REM_FT;
			else if (no_lanes == 4)
				protocol_bits = E40GNCR2_REM_FT;
			break;
		case SERDES_LOCAL_FAULT:
			if (no_lanes == 1)
				protocol_bits = SXGMII_LOC_FT;
			else if (no_lanes == 4)
				protocol_bits = E40GNCR2_LOC_FT;
			break;
		default:
			protocol_bits = 0;
			break;
	}

	protocol_val = ioread32(protocol_reg);
	if (en)
		protocol_val |= protocol_bits;
	else
		protocol_val &= ~protocol_bits;

	iowrite32(protocol_val, protocol_reg);
}

static void caui_set_fault(struct serdes_desc *desc, int dpmac_id, uint8_t master_lane,
				uint8_t no_lanes, enum serdes_fault_type fault_type, uint8_t en)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	uint32_t *protocol_reg = NULL;
	uint32_t protocol_bits, protocol_val;

	/* figure out if it's a 25G, 50G or 100G interface by number of lanes */
	if (no_lanes == 1) {
		/* E25aCR2 */
		protocol_reg = (uint32_t *)&regs->e25gacr[master_lane][2];
	} else if (no_lanes == 2) {
		/* E50GaCR2 */
		if (dpmac_id == 1)
			protocol_reg = (uint32_t *)&regs->e50gacr[2];
		/* E50GbCR2 */
		else if (dpmac_id == 2)
			protocol_reg = (uint32_t *)&regs->e50gbcr[2];
	} else if (no_lanes == 4) {
		/* E100GaCR2 */
		if (dpmac_id == 1)
			protocol_reg = (uint32_t *)&regs->e100gacr[2];
		/* E100GbCR2 */
		else if (dpmac_id == 2)
			protocol_reg = (uint32_t *)&regs->e100gbcr[2];
	}

	if (!protocol_reg) {
		pr_err("%s not configurable for MAC[%d]\n",
				(fault_type == SERDES_REMOTE_FAULT) ?
						"REMOTE FAULT": "LOCAL FAULT", dpmac_id);
		return;
	}

	protocol_bits = 0;
	switch (fault_type) {
		case SERDES_REMOTE_FAULT:
			if (no_lanes == 1)
				protocol_bits = SXGMII_REM_FT;
			else if (no_lanes == 2)
				protocol_bits = E50GNCR2_REM_FT;
			else if (no_lanes == 4)
				protocol_bits = E100GNCR2_REM_FT;
			break;
		case SERDES_LOCAL_FAULT:
			if (no_lanes == 1)
				protocol_bits = SXGMII_LOC_FT;
			else if (no_lanes == 2)
				protocol_bits = E50GNCR2_LOC_FT;
			else if (no_lanes == 4)
				protocol_bits = E100GNCR2_LOC_FT;
			break;
		default:
			protocol_bits = 0;
			break;
	}

	protocol_val = ioread32(protocol_reg);
	if (en)
		protocol_val |= protocol_bits;
	else
		protocol_val &= ~protocol_bits;

	iowrite32(protocol_val, protocol_reg);
}

void serdes_setup_fec_dispatch(struct serdes_desc *desc, int dpmac_id, enum dpmac_fec_mode fec_mode)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	struct serdes_mac_info mac_info = { 0 };
	struct dcfg_desc dcfg_desc = { 0 };
	uint8_t master_lane, no_lanes;
	uint8_t sd_proto = 0;
	int lane;

	sys_get_desc(SOC_MODULE_DCFG,
				SOC_DB_NO_MATCH_FIELDS,
				&dcfg_desc,
				NULL);

	if (dcfg_desc.sd[desc->id].valid) {
			sd_proto = (uint8_t)dcfg_get_serdes_protocol(dcfg_desc.sd[desc->id].rcwsr_id,
					dcfg_desc.sd[desc->id].rcwsr_mask);
	} else {
		pr_err("Could not find serdes protocol for dpmac %d\n", dpmac_id);
		return;
	}

	/* get master lane number from dpmac_id and serdes_desc */
	if (serdes_mac_to_lane(desc, dpmac_id, sd_proto, &master_lane))
		return;

	/* find if mac has multiple lanes */
	no_lanes = get_no_lanes(desc, dpmac_id, master_lane, sd_proto);

	/* get mac info and interface type */
	lane = (int)master_lane;
	serdes_get_mac_info(desc, &mac_info, &lane, sd_proto);

#if 0
	pr_err("dpmac_id=%d, mac_info.mac_id=%d, mac_info.valid=%d, mac_info.enet_if = %#x, master_lane=%d, sd_proto=%d\n",
			dpmac_id, mac_info.mac_id, mac_info.valid,  mac_info.enet_if, master_lane, sd_proto);
#endif

	/* dispatch based on enet_if */
	switch (mac_info.enet_if) {
		case FSL_ENET_IF_CAUI:
				caui_setup_fec(desc, dpmac_id, master_lane, no_lanes, fec_mode);
				break;
		/* add other interfaces here */
		default:
			pr_err("FEC configuration not implemented/supported for MAC[%d]\n", dpmac_id);
			break;
	}
}

void serdes_set_fault(struct serdes_desc *desc, int dpmac_id,
						enum serdes_fault_type fault_type, uint8_t en)
{
	struct serdes_mem_map *regs = (struct serdes_mem_map *)desc->vaddr;
	struct serdes_mac_info mac_info = { 0 };
	struct dcfg_desc dcfg_desc = { 0 };
	uint8_t master_lane, no_lanes;
	uint8_t sd_proto = 0;
	int lane;

	sys_get_desc(SOC_MODULE_DCFG,
				SOC_DB_NO_MATCH_FIELDS,
				&dcfg_desc,
				NULL);

	if (dcfg_desc.sd[desc->id].valid) {
			sd_proto = (uint8_t)dcfg_get_serdes_protocol(dcfg_desc.sd[desc->id].rcwsr_id,
					dcfg_desc.sd[desc->id].rcwsr_mask);
	} else {
		pr_err("Could not find serdes protocol for dpmac %d\n", dpmac_id);
		return;
	}

	/* get master lane number from dpmac_id and serdes_desc */
	if (serdes_mac_to_lane(desc, dpmac_id, sd_proto, &master_lane))
		return;

	/* find if mac has multiple lanes */
	no_lanes = get_no_lanes(desc, dpmac_id, master_lane, sd_proto);

	/* get mac info and interface type */
	lane = (int)master_lane;
	serdes_get_mac_info(desc, &mac_info, &lane, sd_proto);

#if 0
	pr_err("dpmac_id=%d, mac_info.mac_id=%d, mac_info.valid=%d, mac_info.enet_if = %#x, master_lane=%d, sd_proto=%d\n",
			dpmac_id, mac_info.mac_id, mac_info.valid, mac_info.enet_if, master_lane, sd_proto);
#endif

	/* dispatch based on enet_if */
	switch (mac_info.enet_if) {
		case FSL_ENET_IF_XFI:
			xfi_set_fault(desc, dpmac_id, master_lane, no_lanes, fault_type, en);
			break;
		case FSL_ENET_IF_CAUI:
			caui_set_fault(desc, dpmac_id, master_lane, no_lanes, fault_type, en);
			break;
		/* add other interfaces here */
		default:
			pr_err("PCS Remote Fault not supported for MAC[%d], type: %d\n",
					dpmac_id, mac_info.enet_if);
			break;
	}
}
