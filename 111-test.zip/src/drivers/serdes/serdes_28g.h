/*
 * Copyright 2013-2020 NXP
 */

/**
 @File          serdes.h

 @Description   Internal header file for SerDes unit routines
 *//***************************************************************************/
#ifndef __SERDES_H
#define __SERDES_H

#define NUM_OF_SERDES_PLLS 2

/* Register PLLxCR0 defines */
#define PLLXCR0_REFCLK_SEL_MASK		0x001F0000
#define PLLXCR0_REFCLK_SEL_SHIFT	16
#define PLLXCR0_REFCLK_SEL_100MHZ	0x0
#define PLLXCR0_REFCLK_SEL_125MHZ	0x1
#define PLLXCR0_REFCLK_SEL_156MHZ	0x2
#define PLLXCR0_REFCLK_SEL_161MHZ	0x4


/* Register PLLxCR1 defines */
#define PLLXCR1_FRATE_SEL_MASK		0x1F000000
#define PLLXCR1_FRATE_SEL_SHIFT		24
#define PLLSCR1_FRATE_SEL_SGMII_2_5	0x1
#define PLLFCR1_FRATE_SEL_SGMII_2_5	0x10001

/* Register LNxPSSR0 defines */
#define PSSR0_PROTS_MASK        0x7C000000
#define PSSR0_PROTS_SHIFT       26
#define PSSR0_PROTS_SGMII       1
#define PSSR0_PROTS_XAUI        4
#define PSSR0_PROTS_XFI         10
#define PSSR0_PROTS_QSGMII      1
#define PSSR0_PROTS_CAUI		26 /* binary: 11010 */

#define PSSR0_MAC_ID_SHIFT      16

#define PSSR0_IS_QSGMII_MASK    0x03000000
#define PSSR0_IS_QSGMII_SHIFT   24
/* in Serdes for LX2160 the bits used for QSGMII are now used for rates */
#define PSSR0_RATE_5_10_50G	0x01
#define PSSR0_RATE_40G		0x11
#define PSSR0_RATE_100G		0x10

/* TECR0 defines - needs review and code updates where necessary */
#define TECR0_TEQ_TYPE_KR_VAL	0x20000000
#define TECR0_SGN_PREQ_KR_VAL	0x00800000
#define TECR0_SGN_POSTQ1_KR_VAL	0x00008000
#define TECR0_INIT_VAL		(TECR0_TEQ_TYPE_KR_VAL |	\
				 TECR0_SGN_PREQ_KR_VAL |	\
				 TECR0_SGN_POSTQ1_KR_VAL)
#define TECR0_RATIO_PREQ_SHIFT	16
#define TECR0_RATIO_RATIO_PST1Q	8
#define TECR1_ADPT_EQ		24
#define TECR0_AMP_RED_MASK	0xFFFFFFC0

/* TECR0 defines, but for SXGMII - needs review and code updates where necessary */
#define TECR0_EQ_PREQ_SXGMII	0x00800000
#define TECR0_EQ_PST1_SXGMII	0x00008000
#define TECR1_ADPT_EQ_SXGMII	0x30000000
#define TECR0_SXGMII_INIT_VAL	(TECR0_EQ_PREQ_SXGMII |	\
				 TECR0_EQ_PST1_SXGMII )
#define TECR0_SXGMII_CHANGE_MASK   0x708f9f3f
#define TECR1_SXGMII_CHANGE_MASK   0x3f000000

/* RECR3 defines */
#define RECR3_EQ_SNAP_DN	0x40000000
#define RECR3_EQ_SNAP_STRT_MASK	0x80000000

/* RECR4 defines */
#define RECR4_BIN_DATA_SEL_MASK		0x000F0000
#define RECR4_DATA_SEL_BIN_M1		0x000C0000
#define RECR4_DATA_SEL_BIN_LONG		0x000D0000
#define RECR4_EQ_BIN_DATA_MASK		0x000001FF
#define RECR4_EQ_BIN_DATA_SHIFT		0
#define RECR4_EQ_BIN_DATA_SIGN_MASK	0x100

/* LNxRRSTCTL */
#define RRSTCTL_CDR_LOCK_MASK		0x00001000
#define RRSTCTL_CDR_LOCK2_MASK		0x00002000
#define RRSTCTL_RST_REQ_MASK		0x80000000
#define RRSTCTL_RST_REQ_SHIFT		31
#define RRSTCTL_HLT_REQ_MASK		0x08000000
#define RRSTCTL_HLT_REQ_SHIFT		27
#define RRSTCTL_RST_B_MASK			0x00000020
#define RRSTCTL_RST_EN_MASK			0x00000010
#define RRSTCTL_RST_DN_MASK			0x00000080
#define RRSTCTL_RST_DONE_MASK		0x40000000
#define RRSTCTL_STP_REQ_MASK		0x04000000
#define RRSTCTL_DIS_MASK		0x01000000

#ifdef ERR050369
/*
	1.RGCR0   0x1EA0844 + m*0x100 = 0300_0330
	2.RGCR1   0x1EA0848 + m*0x100 = 1000_0000
	3.RECR0   0x1EA0850 + m*0x100 = 0000_0085
	4.RECR2   0x1EA0858 + m*0x100 = A100_0023
	5.RSCCR0  0x1EA0874 + m*0x100 = 0000_2020
	6.        0x1EA0428           = 0310_0000
	7.TGCR1   0x1EA0828 + m*0x100 = 0000_0000
 */
#define ERR050369_RGCR0_MASK		0x03000330
#define ERR050369_RGCR0_VAL			0x03000330
#define ERR050369_TGCR1_MASK		0x00000300
#define ERR050369_TGCR1_VAL			0x00000000
#define ERR050369_RGCR1_MASK		0x50000000
#define ERR050369_RGCR1_VAL			0x10000000
#define ERR050369_RECR0_MASK		0x0000009F
#define ERR050369_RECR0_VAL			0x00000085
#define ERR050369_RECR2_MASK		0x30000003
#define ERR050369_RECR2_VAL			0x20000003
#define ERR050369_RSCCR0_MASK		0x00000300
#define ERR050369_RSCCR0_VAL		0x00000000
#define ERR050369_PLLFCR9_MASK		0x03100000
#define ERR050369_PLLFCR9_VAL		0x03100000
#define ERR050369_RRSTCTL_VAL		0x480000b0
#define ERR050369_RRSTCTL_VAL2		0x80000010
#endif

/* E25GaCR0, E40GaCR0, E100GaCR0 */
#define EXXGaCR0_RST_MASK		0x80000000
#define EXXGaCR0_PD_MASK		0x40000000

/* RECR2 defines */
#define RECR2_RXEQ_BST_MASK	0x30000000

/* TGCR0 defines */
#define TGCR0_TPLL_LES_MASK	0x08000000
#define TGCR0_USE_SLOW_PLL_SHIFT	28
#define TGCR0_USE_SLOW_PLL_MASK	0x10000000

/* GCR1 defines */
#define GCR1_KX_MASK		0xF888FFFF

/* LNxTCSR0 defines */
#define TCSR0_SD_LPBK_SEL_MASK	0x30000000
#define TCSR0_SD_LPBK_DIG_LB	0x10000000

/* LNxTRSTCTL defines */
#define TRSTCTL_HLT_REQ_MASK	0x08000000
#define TRSTCTL_HLT_REQ_SHIFT	27
#define TRSTCTL_RST_REQ         0x80000000
#define TRSTCTL_EN              0x00000020
#define TRSTCTL_RST_REQ_MASK	TRSTCTL_RST_REQ|TRSTCTL_EN
#define TRSTCTL_STP_REQ_MASK	0x04000000
#define TRSTCTL_DIS_MASK	0x01000000

/* Snap shot defines */
#define NUM_OF_SNAPSHOTS		5
#define BIN_M1_THRESHOLD		3
#define BIN_LONG_THRESHOLD		2

/* PLLXCRo defines */
#define PLLXCR1_EX_DLY_SEL		0x10

/* USXGMII */
#define SXGMIIA_XFI				0x80000000

/* E25GACR2 FEC91_ENA - RS-FEC */
#define E25GACR2_FEC91_ENA		0x00100000

/* E25GACR2 FEC_ENA - FC-FEC (Base-R/Firecode) */
#define E25GACR2_FEC_ENA		0x00800000

/* E100GACR2 FEC91_ENA - RS-FEC for 4 lanes */
#define E100GACR2_FEC91_ENA		0x00F00000

#define E25GACR2_FEC_ALL_MASK	(E25GACR2_FEC91_ENA | E25GACR2_FEC_ENA)
#define E100GACR2_FEC_ALL_MASK	(E100GACR2_FEC91_ENA)

#define SXGMII_REM_FT			0x00004000
#define E25GNCR2_REM_FT			0x20000000
#define E40GNCR2_REM_FT			0x10000000
#define E50GNCR2_REM_FT			0x10000000
#define E100GNCR2_REM_FT		0x10000000

#define SXGMII_LOC_FT			0x00008000
#define E25GNCR2_LOC_FT			0x40000000
#define E40GNCR2_LOC_FT			0x20000000
#define E50GNCR2_LOC_FT			0x20000000
#define E100GNCR2_LOC_FT		0x20000000

#define SERDES_28G_SFI_EQ_AMP_RED	0x7
#define SERDES_28G_SFI_EQ_POST1Q	0x3
#define SERDES_28G_SFI_EQ_PREQ		0x0
#define SERDES_28G_SFI_EQ_TYPE		0x1
#define SERDES_28G_SFI_SGN_PREQ		0x1
#define SERDES_28G_SFI_SGN_POST1Q	0x1

struct lnatecr0 {
	uint8_t res1:1;
	uint8_t eq_type:3;
	uint8_t res2:4;
	uint8_t sgn_preq:1;
	uint8_t res3:3;
	uint8_t eq_preq:4;
	uint8_t sgn_post1q:1;
	uint8_t res4:2;
	uint8_t eq_post1q:5;
	uint8_t res5:2;
	uint8_t eq_amp_red:6;
} __packed;

/* definition of LNaTECR0 defines */
#define SERDES_28G_TECR0_EQ_AMP_RED_MASK		0x0000003F
#define SERDES_28G_TECR0_EQ_AMP_RED_OFFSET		0
#define SERDES_28G_TECR0_EQ_POST1Q_MASK			0x00001F00
#define SERDES_28G_TECR0_EQ_POST1Q_OFFSET		8
#define SERDES_28G_TECR0_SGN_POST1Q_MASK		0x00008000
#define SERDES_28G_TECR0_SGN_POST1Q_OFFSET		15
#define SERDES_28G_TECR0_EQ_PREQ_MASK			0x000F0000
#define SERDES_28G_TECR0_EQ_PREQ_OFFSET			16
#define SERDES_28G_TECR0_SGN_PREQ_MASK			0x00800000
#define SERDES_28G_TECR0_SGN_PREQ_OFFSET		23
#define SERDES_28G_TECR0_EQ_TYPE_MASK			0x70000000
#define SERDES_28G_TECR0_EQ_TYPE_OFFSET			28

struct serdes_mem_map {
	uint32_t rstctl;	/* 0x0 - SerDes Reset Control Register */
	uint32_t gr0;		/* 0x4 - SerDes General Control Register 0 */
	uint32_t tcr0;		/* 0x8 - SerDes Test Control/Status Register */
	uint8_t res01[0x20 - 0xc];
	uint32_t lcapcr[4];	/* 0x20 - SerDes Left End Cap Control Register */
	uint8_t res02[0x40 - 0x30];
	uint32_t rcapcr[4];	/* 0x40 - SerDes Right End Cap Control Register */
	uint32_t rcappmr;	/* 0x50 - SerDes Right End Cap Process Monitor Register (RCAPPMR) */
	uint8_t res03[0xF0 - 0x54];
	uint32_t bcb0;		/* 0xf0 - SerDes Control Block Register */
	uint8_t res04[0x100 - 0xF4];
	uint32_t spare_cr_sr[5]; /* SerDes Control Block Spare Register */
	uint8_t res05[0x400 - 0x114];

	struct {
	uint32_t pllxrstctl;	/* 0x400 - SerDes PLLn Reset Control Register */
	uint32_t pllxcr[10];	/* 0x404 - SerDes PLLn Control/Status Register */
	uint32_t pllxsscr[4];	/* 0x430 - SerDes PLLn Speed Switch Control Register */
	uint8_t res06[0x4F0 - 0x440];
	uint32_t pllxcb[2];		/* 0x4f0 - SerDes PLLn Control Block Register */
	uint8_t res07[0x500 - 0x4F4];
	} pll_cfg[NUM_OF_SERDES_PLLS]; /* Serdes 2 starts at 0x500 */

	uint8_t res08[0x800 - 0x600];

	struct {
	uint32_t lnagcr0;		/* 0x800 - SerDes Lane m General Control Register */
	uint8_t res09[0x820 - 0x804];
	uint32_t lnatrstctl;	/* 0x820 - SerDes Lane m TX Reset Control Register */
	uint32_t lnatgcr[3];	/* 0x824 - SerDes Lane m TX General Control Register */
	uint32_t lnatecr[2];	/* 0x830 - SerDes Lane m TX Equalization Register */
	uint8_t res10[0x840 - 0x838];
	uint32_t lnarrstctl;	/* 0x840 - SerDes Lane m RX Reset Control Register */
	uint32_t lnargcr[2];	/* 0x844 - SerDes Lane m RX General Control Register */
	uint8_t res11[0x850 - 0x84C];
	uint32_t lnarecr[5];	/* 0x850 - SerDes Lane m RX Equalization Register */
	uint8_t res12[0x868 - 0x864];
	uint32_t lnarccr[2];	/* 0x868 - SerDes Lane m RX Calibration Register */
	uint32_t lnarcpcr0;		/* 0x870 - SerDes Lane m RX Clock Path Register */
	uint32_t lnarsccr[2];	/* 0x874 - SerDes Lane m RX Sampler Calibration Control Register */
	uint8_t res13[0x880 - 0x87C];
	uint32_t lnattlcr[4];	/* 0x880 - SerDes Lane m Transition Tracking Loop Register */
	uint8_t res14[0x8A0 - 0x890];
	uint32_t lnatcsr[5];	/* 0x8A0 - SerDes Lane m Test Control/Status Register */
	uint8_t res15[0x8C0 - 0x8B4];
	uint32_t lnarxcb[2];	/* 0x8C0 - SerDes Lane m RX Control Block Register */
	uint8_t res16[0x8D0 - 0x8C8];
	uint32_t lnarxss[3];	/* 0x8D0 - SerDes Lane m RX Speed Switch Register */
	uint8_t res17[0x8E0 - 0x8DC];
	uint32_t lnatxcb[2];	/* 0x8E0 - SerDes Lane m TX Control Block Register */
	uint8_t res18[0x8F0 - 0x8E8];
	uint32_t lnatxss[3];	/* 0x8F0 - SerDes Lane m TX Speed Switch Register */
	uint8_t res19[0x900 - 0x8FC];
	} lane_info[NUM_OF_SERDES_LANES]; /* Lane 2 - 0x900, Lane 3 - 0xA00, etc */

	uint32_t lnapss_lnhpss[8];	/* 0x1000 -  Lane m Protocol Select Status Register */
	uint8_t res20[0x1080 - 0x1020];
	uint32_t pcc0;			/* 0x1080 - Protocol Configuration Register 0 */
	uint8_t res21[0x1088 - 0x1084];
	uint32_t pcc2;			/* 0x1088 - Protocol Configuration Register 2 */
	uint8_t res22[0x10A0 - 0x108C];
	uint32_t pcc8;			/* 0x10A0 - Protocol Configuration Register 8 */
	uint32_t pcc9;			/* 0x10A4 - Protocol Configuration Register 9 */
	uint8_t res23[0x10AC - 0x10A8];
	uint32_t pccB;			/* 0x10AC - Protocol Configuration Register B */
	uint32_t pccC;			/* 0x10B0 - Protocol Configuration Register C */
	uint32_t pccD;			/* 0x10B4 - Protocol Configuration Register D */
	uint32_t pccE;			/* 0x10B8 - Protocol Configuration Register E */
	uint8_t res24[0x1100 - 0x10BC];

	/* from 1100h to 1800h there be dragons (PCI/PEX SATA regs) */
	uint8_t pci_sata_regs[0x1800 - 0x1100];

	uint32_t sgmiiacr[NUM_OF_SERDES_LANES][4]; 		/* 0x1800 - SGMIIA Protocol Control Register */
	uint32_t qsgmiiacr[NUM_OF_SERDES_LANES/2][4]; 	/* 0x1880 - QSGMIIA Protocol Control Register only 4 lanes */
	uint32_t qxgmiiacr[NUM_OF_SERDES_LANES/2][4]; 	/* 0x18C0 - QXGMIIA Protocol Control Register only 4 lanes */
	uint8_t res25[0x1A04 - 0x1900];
	uint32_t anltacr[NUM_OF_SERDES_LANES];		/* 0x1A04 - ANLTm Protocol Control Register 1 */
	uint8_t res26[0x1A80 - 0x1A24];
	uint32_t sxgmiiacr[NUM_OF_SERDES_LANES][4]; 	/* 0x1A80 - SXGMIIA Protocol Control Register */
	uint32_t e25gacr[NUM_OF_SERDES_LANES][4]; 		/* 0x1B00 - E25G Protocol Control Register */
	uint8_t res27[0x1C00 - 0x1B80];
	uint32_t e40gacr[4]; 		/* 0x1C00 - E40G Protocol Control Register, lane A */
	uint8_t res28[0x1C40 - 0x1C10];
	uint32_t e40gbcr[4];		/* 0x1C40 - E40G Protocol Control Register, lane B */
	uint8_t res29[0x1DA0 - 0x1C50];
	uint32_t e50gacr[4];		/* 0x1DA0 - E50G Protocol Control Register, lane A */
	uint8_t res30[0x1DC0 - 0x1DB0];
	uint32_t e50gbcr[4];		/* 0x1DC0 - E50G Protocol Control Register, lane B */
	uint8_t res31[0x1E00 - 0x1DD0];
	uint32_t e100gacr[4];		/* 0x1E00 - E100G Protocol Control Register, lane A */
	uint8_t res32[0x1E20 - 0x1E10];
	uint32_t e100gbcr[4];		/* 0x1E20 - E100G Protocol Control Register, lane B */
};

#endif /* SERDES_H */
