/*
 * Copyright 2013-2020 NXP
 */

/**
 @File          serdes.h

 @Description   Internal header file for SerDes unit routines
 *//***************************************************************************/
#ifndef __SERDES_H
#define __SERDES_H

#define NUM_OF_SERDES_PLLS 2

/* Register PLLxCR0 defines */
#define PLLXCR0_FRATE_SEL_MASK		0x000F0000
#define PLLXCR0_FRATE_SEL_SHIFT		16
#define PLLXCR0_FRATE_SEL_SGMII_2_5	0x9

/* Register LNxPSSR0 defines */
#define PSSR0_PROTS_MASK        0x7C000000
#define PSSR0_PROTS_SHIFT       26
#define PSSR0_PROTS_SGMII       1
#define PSSR0_PROTS_XAUI        4
#define PSSR0_PROTS_XFI         10
#define PSSR0_PROTS_QSGMII      1
#define PSSR0_PROTS_CAUI		26 /* binary: 11010 */

#define PSSR0_MAC_ID_SHIFT      16

#define PSSR0_IS_QSGMII_MASK    0x03000000
#define PSSR0_IS_QSGMII_SHIFT   24
/* in Serdes for LX2160 the bits used for QSGMII are now used for rates */
#define PSSR0_RATE_5_10_50G	0x01
#define PSSR0_RATE_40G		0x11
#define PSSR0_RATE_100G		0x10

/* TECR0 defines */
#define TECR0_TEQ_TYPE_KR_VAL	0x20000000
#define TECR0_SGN_PREQ_KR_VAL	0x04000000
#define TECR0_SGN_POSTQ1_KR_VAL	0x00c00000
#define TECR0_INIT_VAL		(TECR0_TEQ_TYPE_KR_VAL |	\
				 TECR0_SGN_PREQ_KR_VAL |	\
				 TECR0_SGN_POSTQ1_KR_VAL)
#define TECR0_RATIO_PREQ_SHIFT	22
#define TECR0_RATIO_RATIO_PST1Q	16
#define TECR0_ADPT_EQ		8
#define TECR0_AMP_RED_MASK	0xFFFFFFC0

/* RECR1 defines */
#define RECR1_EQ_BSNP_DN	0x00000004

/* TCSR1 defines */
#define TCSR1_CDR_SEL_MASK		0x00070000
#define TCSR1_CDR_SEL_BIN_M1		6
#define TCSR1_CDR_SEL_BIN_LONG		7
#define TCSR1_EQ_SNPBIN_DATA_MASK	0x0000ffc0
#define TCSR1_EQ_SNPBIN_DATA_SHIFT	6
#define TCSR1_EQ_SNPBIN_DATA_SIGN_MASK	0x100

/* TCSR3 defines */
#define TCSR3_CDR_LOCK_MASK	0x08000000

/* RECR0 defines */
#define RECRO_RXEQ_BST_MASK	0x10000000

/* GCR0 defines */
#define GCR0_RRST_B_MASK	0x00400000
#define GCR0_TRST_B_MASK	0x00200000
#define GCR0_TX_RX_RST_MASK	(GCR0_TRST_B_MASK | GCR0_TRST_B_MASK)
#define GCR0_TPLL_LES_MASK	0x08000000
#define GCR0_RPLL_LES_SHIFT	31

/* GCR1 defines */
#define GCR1_KX_MASK		0xFF803FFF
#define GCR1_REQ_BIN_SNP_MASK	0x00000040

/* Snap shot defines */
#define NUM_OF_SNAPSHOTS		5
#define BIN_M1_THRESHOLD		3
#define BIN_LONG_THRESHOLD		2

/* PLLXCRo defines */
#define PLLXCR0_DLYDIV_SEL		0x1

struct lnxtecr0 {
        uint8_t res1:2;
        uint8_t eq_type:2;
        uint8_t res2:1;
        uint8_t sgn_preq:1;
        uint8_t eq_preq:4;
        uint8_t sgn_post1q:1;
        uint8_t eq_post1q:5;
        uint8_t res3:2;
        uint8_t adapt_eq:6;
        uint8_t res4:2;
        uint8_t eq_amp_red:6;
} __packed;

/* definition of LNaTECR0 defines */
#define SERDES_10G_TECR0_EQ_AMP_RED_MASK		0x0000003F
#define SERDES_10G_TECR0_EQ_AMP_RED_OFFSET		0
#define SERDES_10G_TECR0_ADAPT_EQ_MASK			0x00003F00
#define SERDES_10G_TECR0_ADAPT_EQ_OFFSET		8
#define SERDES_10G_TECR0_EQ_POST1Q_MASK			0x001F0000
#define SERDES_10G_TECR0_EQ_POST1Q_OFFSET		16
#define SERDES_10G_TECR0_SGN_POST1Q_MASK		0x00200000
#define SERDES_10G_TECR0_SGN_POST1Q_OFFSET		21
#define SERDES_10G_TECR0_EQ_PREQ_MASK			0x03C00000
#define SERDES_10G_TECR0_EQ_PREQ_OFFSET			22
#define SERDES_10G_TECR0_SGN_PREQ_MASK			0x04000000
#define SERDES_10G_TECR0_SGN_PREQ_OFFSET		26
#define SERDES_10G_TECR0_EQ_TYPE_MASK			0x30000000
#define SERDES_10G_TECR0_EQ_TYPE_OFFSET			28

struct serdes_mem_map {
	struct {
		uint32_t pllxrstctl; /* 0x000 - SerDes PLL1 Reset Control */
		uint32_t pllxcr0; /* 0x004 - SerDes PLL1 Control 0 */
		uint32_t pllxcr1; /* 0x008 - SerDes PLL1 Control 1 */
		uint32_t pllxsr2; /* 0x00c - SerDes PLL1 Status 2 */
		uint32_t pllxcr3; /* 0x010 - SerDes PLL1 Control 3 */
		uint32_t pllxcr4; /* 0x014 - SerDes PLL1 Control 4 */
		uint32_t pllxcr5; /* 0x018 - SerDes PLL1 Control 5 */
		uint8_t res01[0x20 - 0x1c];
	} pll_cfg[NUM_OF_SERDES_PLLS];

	uint8_t res02[0x90 - 0x40];
	uint32_t tcalcr; /* 0x090 - SerDes Transmit Calibration Control */
	uint32_t tcalcr1; /* 0x094 - SerDes Transmit Calibration Control 1 */
	uint8_t res03[0xa0 - 0x98];
	uint32_t rcalcr; /* 0x0a0 - Serdes Receive Calibration Control */
	uint32_t rcalcr1; /* 0x0a4 - Serdes Receive Calibration Control 1 */
	uint8_t res04[0xb0 - 0xa8];
	uint32_t gr0; /* 0x0b0 - General Control 0 */
	uint8_t res05[0x100 - 0xb4];

	struct {
		uint32_t lnxpssr0; /* Lane X Protocol Select Status 0 */
		uint8_t res06[0x20 - 0x04];
	} lane_info[NUM_OF_SERDES_LANES];

	uint32_t pccr0; /* 0x200 - Protocol configuration 0 */
	uint8_t res07[0x208 - 0x204];
	uint32_t pccr2; /* 0x208 - Protocol configuration 2 */
	uint8_t res08[0x210 - 0x20c];
	uint32_t pccr4; /* 0x210 - Protocol configuration 4 */
	uint32_t pccr5; /* 0x214 - Protocol configuration 5 */
	uint8_t res09[0x220 - 0x218];
	uint32_t pccr8; /* 0x220 - Protocol configuration 8 */
	uint32_t pccr9; /* 0x224 - Protocol configuration 9 */
	uint8_t res10[0x800 - 0x228];

	struct {
		uint32_t lnxgcr0; /* 0x800 - General Control 0 */
		uint32_t lnxgcr1; /* 0x804 - General Control 1 */
		uint32_t lnxgcr2; /* 0x808 - General Control 2 */
		uint32_t lnxsscr0; /* 0x80c - Speed Switch Control 0 */
		uint32_t lnxrecr0; /* 0x810 - Receive Equalization Control 0 */
		uint32_t lnxrecr1; /* 0x814 - Receive Equalization Control 1 */
		uint32_t lnxtecr0; /* 0x818 - Transmit Equalization Control 0 */
		uint32_t lnxsscr1; /* 0x81c - Speed Switch Control 1 */
		uint32_t lnxttlcr0; /* 0x820 - TTL Control 0 */
		uint32_t lnxttlcr1; /* 0x824 - TTL Control 1 */
		uint32_t lnxttlcr2; /* 0x828 - TTL Control 2 */
		uint8_t res01[0x830 - 0x82c];
		uint32_t lnxtcsr0; /* 0x830 - Test Control/Status 0 */
		uint32_t lnxtcsr1; /* 0x834 - Test Control/Status 1 */
		uint32_t lnxtcsr2; /* 0x838 - Test Control/Status 2 */
		uint32_t lnxtcsr3; /* 0x83c - Test Control/Status 3 */
	} lane_control[NUM_OF_SERDES_LANES];
};

#endif /* SERDES_H */
