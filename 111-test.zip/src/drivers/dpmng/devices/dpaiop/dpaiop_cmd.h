/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPAIOP_CMD_H
#define _DPAIOP_CMD_H

/* default version for all dpaiop commands */
#define DPAIOP_CMD_VER_BASE							CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPAIOP_CMD_V0								CMDHDR_CMD_VERSION(0)
#define DPAIOP_CMD_V1								CMDHDR_CMD_VERSION(1)
#define DPAIOP_CMD_V2								CMDHDR_CMD_VERSION(2)

/* add your new command version number here
 * Ex:
 * #define DPAIOP_CMD_CREATE_VER_1                MC_CMD_HDR_VERSION(DPAIOP_CMD_VER_BASE + 1) or
 * #define DPAIOP_CMD_CREATE_VER                  MC_CMD_HDR_VERSION(3)
 */

/* Command IDs */
#define DPAIOP_CMD_CODE_CLOSE                      0x800
#define DPAIOP_CMD_CODE_OPEN                       0x80a
#define DPAIOP_CMD_CODE_CREATE                     0x90a
#define DPAIOP_CMD_CODE_DESTROY                    0x900
#define DPAIOP_CMD_CODE_GET_API_VERSION            0xa0a

#define DPAIOP_CMD_CODE_GET_ATTR                   0x004
#define DPAIOP_CMD_CODE_RESET                      0x005

#define DPAIOP_CMD_CODE_SET_IRQ                    0x010
#define DPAIOP_CMD_CODE_GET_IRQ                    0x011
#define DPAIOP_CMD_CODE_SET_IRQ_ENABLE             0x012
#define DPAIOP_CMD_CODE_GET_IRQ_ENABLE             0x013
#define DPAIOP_CMD_CODE_SET_IRQ_MASK               0x014
#define DPAIOP_CMD_CODE_GET_IRQ_MASK               0x015
#define DPAIOP_CMD_CODE_GET_IRQ_STATUS             0x016
#define DPAIOP_CMD_CODE_CLEAR_IRQ_STATUS           0x017

#define DPAIOP_CMD_CODE_LOAD                       0x280
#define DPAIOP_CMD_CODE_RUN                        0x281
#define DPAIOP_CMD_CODE_GET_SL_VERSION             0x282
#define DPAIOP_CMD_CODE_GET_STATE                  0x283
#define DPAIOP_CMD_CODE_SET_TIME_OF_DAY            0x284
#define DPAIOP_CMD_CODE_GET_TIME_OF_DAY            0x285

#define DPAIOP_CMD_CODE_SET_RESETABLE              0x286
#define DPAIOP_CMD_CODE_GET_RESETABLE              0x287

#endif /* _DPAIOP_CMD_H */
