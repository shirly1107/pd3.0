/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpaiop.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_dpaiop_mc.h"
#include "fsl_dpmng_mc.h"
#include "fsl_resman.h"
#include "fsl_io.h"

#include "aiop_elf_loader.h"
#include "drivers/fsl_mc.h"
#include "fsl_malloc.h"
#include "fsl_ctlu.h"
#include "fsl_dpci_mc.h"
#include "kernel/device.h"
#include "dpc.h"

#include "fsl_dptbl.h"
#include "fsl_dpparser.h"
#include "fsl_dpkg.h"
#include "fsl_resman.h"
#include "fsl_soc.h"
#include "fsl_mpic.h"
#include "fsl_timer.h"
#include "fsl_ldpaa.h"

#include "fsl_aiop_common.h"
#include "drivers/fsl_aiop.h"
#include "fsl_dppmu.h"

#include "dpaiop.h"
#include "aiop.h"
#include "dpparser.h"

static const struct memory_partition_list aiop_ddr_mem_partitions = {
		.mem_part_ids = {MEM_PART_SYSTEM_DDR2, MEM_PART_SYSTEM_DDR1,
				MEM_PART_LAST /* mark end of list*/ }
};

extern int aiop_evm_cmdif_open(struct cmdif_desc *cidesc,
                               void *v_data, uint32_t size);

static void resources_authorization(struct dpaiop *dpaiop)
{
	CHECK_COND_RET(dpaiop);
	
	if (dpaiop->authorized)
		return;

	dpaiop->authorized = 1;

	return;
}

static void resources_deauthorization(struct dpaiop *dpaiop)
{
	CHECK_COND_RET(dpaiop);

	if (!dpaiop->authorized)
		return;

	dpaiop->authorized = 0;
	dpaiop->amq.icid = (uint16_t)-1;
}

static void set_mc_info(struct dpaiop *dpaiop,
		        const struct dpmng_dev_cfg *dev_cfg)
{
	dpaiop->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dpaiop->dpmng);

	dpaiop->id = dev_cfg->id;
	dpaiop->device = dev_cfg->device;
}


static int win_cfg_check(struct dpaiop *dpaiop, const struct aiop_atu_win_cfg *win_cfg)
{
	uint32_t addr_mask;

	if (win_cfg->num == 0) {
		if (win_cfg->base_addr) {
			pr_err("Window #0 is default and doesn't have a "
			"base address");
			return -EINVAL;
		}
		if ((win_cfg->instr_access) || (win_cfg->data_access)) {
			pr_err("'Instruction access' or 'Data access' cannot "
			"be set for default window #0");
			return -EINVAL;
		}
	} else {
		if (win_cfg->num >= AIOP_ATU_NUM_OF_WINDOWS) {
			pr_err("Window number exceeds maximal value of %d",
			       AIOP_ATU_NUM_OF_WINDOWS - 1);
			return -EINVAL;
		}

		/* Check this window number isn't already in use */
		if (aiop_tile_atu_win_in_use(&dpaiop->desc,
		                        win_cfg->num)) {
			pr_err("Window %d already in use", win_cfg->num);
			return -EINVAL;
		}

		if (!is_power_of_2(win_cfg->size)) {
			pr_err("Window size must be a power-of-2");
			return -EINVAL;
		}
		if ((win_cfg->size > AIOP_MAX_ATU_OWS)
			|| (win_cfg->size < AIOP_MIN_ATU_OWS)) {
			pr_err("Window size must be between 64KB up to 2GB");
			return -EINVAL;
		}

		/* Checking that the provided addresses are aligned to the
		 * window size */
		addr_mask = (uint32_t)(win_cfg->size - 1);
		if (win_cfg->base_addr & addr_mask) {
			pr_err("Window base address must be aligned to window "
			"size");
			return -EINVAL;
		}
		if (win_cfg->trans_addr & addr_mask) {
			pr_err("Window translation address must be aligned to "
			"window size");
			return -EINVAL;
		}

		if ((win_cfg->instr_access) && (win_cfg->data_access)) {
			pr_err("'Instruction access' and 'Data access' cannot "
			"both be set");
			return -EINVAL;
		}

	}
	return 0;
}

static int init_tables(struct dpaiop *dpaiop, struct ctlu *ctlu,
	const struct ctlu_desc *ctlu_desc)
{
	struct dptbl_mng_cfg dptbl_mng_cfg;
	struct dptbl_mng *dptbl_mng;
	uint32_t sys_ddr_tables = 0, size = 0;
	int err;
	enum ctlu_type type = ctlu_get_type(ctlu);
	uint32_t num_peb_entries = 0;
	uint32_t num_dpddr_entries = 0;
	uint32_t num_sys_ddr_entries = 0;
	struct mem_paddrs *mem_paddrs;
	void *trans_addr;
	struct dpmng_amq mc_amq;

	dpmng_get_amq(&mc_amq);

	if (type == CTLU_AIOP)
	{
		num_peb_entries = dpaiop->cfg.ctlu_peb_num_entries;
		num_dpddr_entries = dpaiop->cfg.ctlu_dp_ddr_num_entries;
		num_sys_ddr_entries =dpaiop->cfg.ctlu_sys_ddr_num_entries;
		mem_paddrs = &dpaiop->ctlu_paddrs;
	}
	else
	{
		num_peb_entries = dpaiop->cfg.mflu_peb_num_entries;
		num_dpddr_entries = dpaiop->cfg.mflu_dp_ddr_num_entries;
		num_sys_ddr_entries =dpaiop->cfg.mflu_sys_ddr_num_entries;
		mem_paddrs = &dpaiop->mflu_paddrs;
	}

	memset(&dptbl_mng_cfg, 0, sizeof(dptbl_mng_cfg));

	dptbl_mng_cfg.ctlu = ctlu;

	/* initialize external table 1*/
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[0].mem_type = DPTBL_PEB;
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[0].num_entries = num_peb_entries;

	if (num_peb_entries)
	{
		err = fsl_get_mem(
				 dptbl_get_tbl_size_by_entries(
						dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[0].num_entries),
				MEM_PART_PEB, 64, &mem_paddrs->peb);
		CHECK_COND_RETVAL(err == 0, err);
		dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[0].tbl_paddr = mem_paddrs->peb;
	}
	else
		pr_info("No AIOP tables allocated in PEB\n");

	/*initialize external table 2 */
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[1].mem_type = DPTBL_EXT_MEMORY_1; /* DPDDR */
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[1].num_entries = num_dpddr_entries;

	if (num_dpddr_entries)
	{
		size = dptbl_get_tbl_size_by_entries(dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[1].num_entries);
		err = fsl_get_mem(size,
			MEM_PART_DP_DDR, 64, &mem_paddrs->dp_ddr);
		CHECK_COND_RETVAL(err == 0, err);

		trans_addr = dpmng_mc_set_soc_window(mem_paddrs->dp_ddr, &mc_amq);
		memset32(trans_addr, 0, size);

		dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[1].tbl_paddr = mem_paddrs->dp_ddr;
	}
	else
		pr_info("No AIOP tables allocated in DP-DDR\n");

	/* initialize  SYS DDR table */
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[2].mem_type = DPTBL_EXT_MEMORY_2;
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[2].num_entries =
			num_sys_ddr_entries;

	if (num_sys_ddr_entries)
	{
		/* include in the SYS DDR allocated section both the size of the SYS
		 * DDR tables and the table descriptors table */
		sys_ddr_tables = dptbl_get_tbl_size_by_entries(
				dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[2].num_entries);
		CHECK_COND_RETVAL((sys_ddr_tables % AIOP_LU_TABLES_ALIGN) == 0,
						-EINVAL);
		size = (sys_ddr_tables + dptbl_get_int_list_size(ctlu));
		err = fsl_get_mem_mp(size, &aiop_ddr_mem_partitions,
							AIOP_LU_TABLES_ALIGN, &mem_paddrs->sys_ddr);
		CHECK_COND_RETVAL(err == 0, err);
		trans_addr = dpmng_mc_set_soc_window(mem_paddrs->sys_ddr, &mc_amq);
		memset32(trans_addr, 0, size);

		dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[2].tbl_paddr = mem_paddrs->sys_ddr;
	}
	else
		pr_info("No AIOP tables allocated in System DDR\n");

	/* define the base for the table descriptors table */
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.int_list_paddr = mem_paddrs->sys_ddr
			+ sys_ddr_tables;

	dptbl_mng = dptbl_mng_init(&dptbl_mng_cfg);
	CHECK_COND_RETVAL(dptbl_mng, -ENODEV, "dptbl_mng_init() failed.\n");

	sys_add_handle(dptbl_mng, FSL_MOD_TABLES_MNG, 2,
		dpaiop->id /*iop_id*/, type /* CTLU type */);

	if (ctlu_desc->options & CTLU_DESC_OPT_USE_AS_MFLU)
		/* some SoC's do not have MFLU. CTLU is used for both. In order for
		 * devices to be able to get the appropriate handle in both flavors,
		 * we set here the MFLU tables handle as the CLTU handle. */
		sys_add_handle(dptbl_mng,
		               FSL_MOD_TABLES_MNG,
				2,
				dpaiop->id, /*iop_id*/
				CTLU_AIOP_MFLU /* CTLU type */);

	return 0;
}

static int cfg_aiop_tile(struct dpaiop *dpaiop)
{
	struct aiop_tile_cfg *cfg = &dpaiop->cfg;

	if ((cfg->tasks_per_core > AIOP_TILE_NTASKS_MAX)
	    || (!is_power_of_2(cfg->tasks_per_core))) {
		pr_err("Number of tasks must be a power of 2 that doesn't "
			"exceed %d", AIOP_TILE_NTASKS_MAX);
		return -EINVAL;
	}

	if ((uint32_t)(cfg->tasks_per_core * 16)
	    <= cfg->defcfg.ws_cfg.high_prio_threshold)
	{
		pr_err("High priority task threshold equals or exceeds the "
			"total number of available tasks, so no low priority "
			"work will ever get scheduled");
		return -EINVAL;
	}

	pr_debug("Initialize AIOP SRAMs and tasks per core (tpc=%d)",
			dpaiop->cfg.tasks_per_core);
	aiop_tile_init(&dpaiop->desc, dpaiop->cfg.tasks_per_core);

	return 0;
}

static int cfg_aiop_ws(struct dpaiop *dpaiop,
		       const struct aiop_ws_cfg *cfg)
{
	if (!is_power_of_2(cfg->high_prio_threshold)) {
		pr_err("High priority task reservation threshold must be "
		"power-of-2");
		return -EINVAL;
	}

	if (cfg->high_prio_threshold > 128) {
		pr_err("High priority task reservation threshold must not "
		"exceed 128 tasks");
		return -EINVAL;
	}

	aiop_tile_ws_init(&dpaiop->desc, cfg);

	return 0;
}

static int cfg_aiop_fdma(struct dpaiop *dpaiop,
        	 	 const struct aiop_fdma_cfg *cfg)
{
	int err;

	if (cfg->sru_size & (AIOP_FDMA_SRU_ALIGN - 1)) {
		pr_err("SRU size must be aligned to 64 bytes");
		return -EINVAL;
	}

	/* if this is the first time, or if required memory is
	* different than existing - allocate memory */
	if (!dpaiop->sru_base) {
		struct mem_desc dpddr_desc = {0};

		/* release previous memory */
		/*if (dpaiop->sru_base)
		 fsl_xfree(dpaiop->sru_base); */
		err = sys_get_desc(SOC_MODULE_DPDDR, SOC_DB_NO_MATCH_FIELDS, &dpddr_desc, NULL);
		if ((err == 0) && (dpddr_desc.size >= cfg->sru_size))
			err = fsl_get_mem(cfg->sru_size,
					MEM_PART_DP_DDR,
					AIOP_FDMA_SRU_ALIGN,
					&dpaiop->sru_base);
		if (err) /* either no DP DDR or no memory in DP DDR */
		{
			pr_info("DP-DDR is insufficient, allocating SRU memory from System DDR\n");
			err = fsl_get_mem_mp(cfg->sru_size, &aiop_ddr_mem_partitions,
						AIOP_FDMA_SRU_ALIGN,
						&dpaiop->sru_base);
		}
		CHECK_COND_RETVAL(err == 0, -ENOMEM);
	}

	aiop_tile_fdma_init(&dpaiop->desc, dpaiop->sru_base, cfg);

	return 0;
}

static int cfg_aiop_tman(struct dpaiop *dpaiop,
			 struct aiop_tile_regs *regs,
                   	 const struct aiop_tman_cfg *cfg)
{
	int err;

	/* if no memory already exists */
	if (!dpaiop->tman_ctrl_mem) {
		struct mem_desc dpddr_desc = {0};

		err = sys_get_desc(SOC_MODULE_DPDDR, SOC_DB_NO_MATCH_FIELDS, &dpddr_desc, NULL);
		if ((err == 0) && (dpddr_desc.size >= (uint32_t)TMAN_MEM_SIZE))
			err = fsl_get_mem((uint32_t)TMAN_MEM_SIZE,
					MEM_PART_DP_DDR,
					AIOP_TMAN_CTRL_ALIGN,
					&dpaiop->tman_ctrl_mem);
		if (err) /* either no DP DDR or no memory in DP DDR */
		{
			pr_info("DP DDR is insufficient, allocating TMAN memory from System DDR\n");
			err = fsl_get_mem_mp((uint32_t)TMAN_MEM_SIZE,
			                     &aiop_ddr_mem_partitions,
			                     AIOP_TMAN_CTRL_ALIGN,
			                     &dpaiop->tman_ctrl_mem);
		}
		CHECK_COND_RETVAL(err == 0, -ENOMEM);
	}

	err = aiop_tile_tman_init(&dpaiop->desc, dpaiop->tman_ctrl_mem, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int cfg_tile(struct dpaiop *dpaiop)
{
	struct aiop_tile_regs *regs = dpaiop->regs;
	struct aiop_tile_cfg *cfg = &dpaiop->cfg;
	int err, i;

	/* General tile initializations */
	err = cfg_aiop_tile(dpaiop);
	CHECK_COND_RETVAL(err == 0, err);

	/* Initialize tile blocks */
	aiop_tile_cdma_init(&dpaiop->desc, &(cfg->cdma_cfg));
	aiop_tile_osm_init(&dpaiop->desc, &(cfg->defcfg.osm_cfg));

	if (dpaiop->desc.ste_support)
		aiop_tile_ste_init(&dpaiop->desc, &(cfg->ste_cfg));

	err = cfg_aiop_ws(dpaiop, &(cfg->defcfg.ws_cfg));
	CHECK_COND_RETVAL(err == 0, err);

	err = cfg_aiop_fdma(dpaiop, &(cfg->fdma_cfg));
	CHECK_COND_RETVAL(err == 0, err);

	err = cfg_aiop_tman(dpaiop, regs, &(cfg->tman_cfg));
	CHECK_COND_RETVAL(err == 0, err);

	for (i = 0; i < cfg->num_atu_win; i++)
	{
		if (cfg->atu_cfg[i].size)
		{
			pr_debug("ATU Window #%d (0x%08x) paddr: 0x%08x%08x --> vaddr: 0x%08x%08x\n",
				        cfg->atu_cfg[i].num,
				        (uint32_t)cfg->atu_cfg[i].size,
				        UINT32_HI(cfg->atu_cfg[i].trans_addr),
				        UINT32_LO(cfg->atu_cfg[i].trans_addr),
				        UINT32_HI(cfg->atu_cfg[i].base_addr),
				        UINT32_LO(cfg->atu_cfg[i].base_addr));
			err = win_cfg_check(dpaiop, &cfg->atu_cfg[i]);
			CHECK_COND_RETVAL(err == 0, err);
			err = aiop_tile_atu_win_enable(&dpaiop->desc, &cfg->atu_cfg[i]);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}

	return 0;
}
static uint32_t get_adjusted_ows(uint32_t ows, const uint32_t max_ows) {
	if (!is_power_of_2(ows)) {
		NEXT_POWER_OF_2(ows, ows);
	}
	/* adjust window size in order to be max permitted size by ATU
	 and smaller than allocated size */
	while (ows > max_ows)
		ows >>= 1;
	return ows;
}
/* Due to the ATU implementation the [32-16] bits of the physical translated
 address must be aligned to the out-bound window size (a.k.a. OWS).
 */
static int get_mem_for_aiop_atu(int mem_partition_id,
		struct mem_rgn_atu_window_cfg* cfg,
		const uint32_t min_atu_ows,
		const uint32_t max_atu_ows)
{
	uint32_t ows = (uint32_t)MIN(max_atu_ows, cfg->phy_size);
	int err = -ENOMEM;
	char mem_part_name[32];
	int show_message = 0;
	get_partition_name(mem_partition_id, mem_part_name, sizeof(mem_part_name));
	/* adjust window size in order to be max permitted size by ATU
	 and smaller than allocated size */
	ows = get_adjusted_ows(ows, (uint32_t)MIN(max_atu_ows, cfg->phy_size));
	/* find block that can be aligned to the OWS */
	do {
		cfg->phy_base_addr = 0UL;
		if (!(cfg->virt_base_addr & (ows - 1))) {
			if( show_message && will_log(NO_ID, LOG_LEVEL_ERROR) ) {
				fsl_print("MEM #%d(%s): try to get 0x%x%08x/0x%x (bytes/alignment)\n",
						mem_partition_id, mem_part_name, UINT32_HI(cfg->phy_size), UINT32_LO(cfg->phy_size), ows);
			}
			err = fsl_get_mem(cfg->phy_size, mem_partition_id, ows,
					&cfg->phy_base_addr);
			if (err || cfg->phy_base_addr == ILLEGAL_BASE)
				pr_err(
				"MEM #%d(%s): fail get 0x%x%08x/0x%x (bytes/alignment)\n",
				mem_partition_id, mem_part_name, UINT32_HI(cfg->phy_size),
				UINT32_LO(cfg->phy_size), ows);
			show_message = 1;
		}
		/* try use a smaller ows or alignment */
		if (cfg->phy_base_addr == 0 ||
			cfg->phy_base_addr == ILLEGAL_BASE)
			ows >>= 1;
	} while((cfg->phy_base_addr == 0 || cfg->phy_base_addr == ILLEGAL_BASE) &&
			ows >= min_atu_ows);

	/* found a memory block aligned to OWS */
	if (cfg->phy_base_addr != 0 && cfg->phy_base_addr != ILLEGAL_BASE) {
		cfg->ows_alignment = ows;
		pr_debug(
		"MEM #%d(%s): get 0x%x%08x/0x%x (bytes/alignment) from 0x%x%08x\n",
		mem_partition_id, mem_part_name,
		UINT32_HI(cfg->phy_size), UINT32_LO(cfg->phy_size), ows,
		UINT32_HI(cfg->phy_base_addr), UINT32_LO(cfg->phy_base_addr));
		if( show_message && will_log(NO_ID, LOG_LEVEL_ERROR) ) {
			fsl_print("MEM #%d(%s): successful allocated 0x%x%08x/0x%x (bytes/alignment)\n",
					mem_partition_id, mem_part_name, UINT32_HI(cfg->phy_size), UINT32_LO(cfg->phy_size), ows);
		}
	} else {
		pr_err(
		"MEM #%d(%s): can't get 0x%x%08x/0x%x (bytes/alignment)\n",
		mem_partition_id, mem_part_name,
		UINT32_HI(cfg->phy_size), UINT32_LO(cfg->phy_size), ows);
	}
	return err;
}

static int allocate_aiop_rsrcs(struct dpaiop *dpaiop,
		struct aiop_init_info* aiop_init)
{
	int err;
	uint8_t available_atu_wins;
	struct resman_res_req req;
	char str[16];
	int *tmp_array;
	struct mem_rgn_atu_window_cfg* dpddr_cfg = &dpaiop->cfg.dpddr_atu_cfg;
	struct mem_rgn_atu_window_cfg* sysddr_cfg = &dpaiop->cfg.sysddr_atu_cfg;
	struct mem_rgn_atu_window_cfg* peb_cfg = &dpaiop->cfg.peb_atu_cfg;
	const struct aiop_app_init_info *aiop_app_info = &aiop_init->app_info;
	struct mem_desc dpddr_desc = {0};

	/* allocate memory from all partitions for AIOP SW */
	peb_cfg->phy_size = ioread64be(&aiop_app_info->peb_size);
	if (peb_cfg->phy_size) {
		CHECK_COND_RETVAL(peb_cfg->phy_size >= AIOP_MIN_ATU_OWS, -EINVAL,
		"The supplied PEB size 0x%x must be bigger than 64KB\n",
		UINT32_LO(peb_cfg->phy_size));
		peb_cfg->virt_base_addr = PTR_TO_UINT(dpaiop->desc.peb_vaddr);
		err = get_mem_for_aiop_atu(MEM_PART_PEB, peb_cfg,
				AIOP_MIN_ATU_OWS, /* min ows */
				(uint32_t)dpaiop->desc.peb_atu_size); /* max ows */
		dpaiop->mem_paddrs.peb = peb_cfg->phy_base_addr;
		CHECK_COND_RETVAL(err == 0 && peb_cfg->ows_alignment, -EINVAL,
		"Can't allocated 0x%x bytes from PEB\n", UINT32_LO(peb_cfg->phy_size));
		peb_cfg->virt_size = (uint32_t)dpaiop->desc.peb_atu_size;
		peb_cfg->max_atu_wins = 1;
	}
	/* default window 0 isn't configurable */
	available_atu_wins = AIOP_ATU_NUM_OF_WINDOWS - AIOP_ATU_STATIC_WIN_NO - 1;
	dpddr_cfg->phy_size = ioread64be(&aiop_app_info->dp_ddr_size);
	sysddr_cfg->phy_size = ioread64be(&aiop_app_info->sys_ddr1_size);
	if (dpddr_cfg->phy_size) {
		uint32_t min_dpddr_atu_ows;
		err = sys_get_desc(SOC_MODULE_DPDDR, SOC_DB_NO_MATCH_FIELDS,
				&dpddr_desc, NULL);
		CHECK_COND_RETVAL( err == 0 &&
		(dpddr_cfg->phy_size >= AIOP_MIN_ATU_OWS &&
		dpddr_cfg->phy_size <= dpddr_desc.size), -EINVAL,
		"No DP-DDR support or the supplied DP-DDR size 0x%x%08x"
		"is not within valid range [0x%x..0x%x%08x]\n",
		UINT32_HI(dpddr_cfg->phy_size), UINT32_LO(dpddr_cfg->phy_size),
		AIOP_MIN_ATU_OWS,
		UINT32_HI(dpddr_desc.size), UINT32_LO(dpddr_desc.size));
		dpddr_cfg->virt_base_addr = PTR_TO_UINT(dpaiop->desc.dp_ddr_vaddr);
		/* if there is no system ddr dp-ddr can use all atu windows */
		if (sysddr_cfg->phy_size) {
			/* allocate evenly the remaining atu wins between dpddr & sys-ddr*/
			dpddr_cfg->max_atu_wins = available_atu_wins / 2;
			dpddr_cfg->virt_size = (uint32_t) dpaiop->desc.dp_ddr_atu_size;
			min_dpddr_atu_ows =
					dpddr_cfg->virt_size / MAX(dpddr_cfg->max_atu_wins, 1);
			min_dpddr_atu_ows = get_adjusted_ows(min_dpddr_atu_ows,
								min_dpddr_atu_ows);
		} else {
			dpddr_cfg->max_atu_wins = available_atu_wins;
			dpddr_cfg->virt_size = (uint32_t)(4 * GIGABYTE -
					PTR_TO_UINT(dpaiop->desc.dp_ddr_vaddr));
			min_dpddr_atu_ows = AIOP_MIN_ATU_OWS;
		}
		err = get_mem_for_aiop_atu(MEM_PART_DP_DDR,
				dpddr_cfg,
				min_dpddr_atu_ows,
				(uint32_t) dpaiop->desc.dp_ddr_atu_size);
		dpaiop->mem_paddrs.dp_ddr = dpaiop->cfg.dpddr_atu_cfg.phy_base_addr;
		CHECK_COND_RETVAL(err == 0 && dpddr_cfg->ows_alignment, -EINVAL,
		"Can't allocated 0x%x%08x bytes from DP-DDR\n",
		UINT32_HI(dpddr_cfg->phy_size), UINT32_LO(dpddr_cfg->phy_size));
		/* the ows fits the entire virtual space */
		if (dpddr_cfg->ows_alignment == dpddr_cfg->virt_size)
			dpddr_cfg->max_atu_wins = 1;
		available_atu_wins -= dpddr_cfg->max_atu_wins;
	}
	if (sysddr_cfg->phy_size) {
		uint32_t min_sysddr_atu_ows;
		CHECK_COND_RETVAL(sysddr_cfg->phy_size >= AIOP_MIN_ATU_OWS, -EINVAL,
		"The supplied system DDR size (0x%x) should be at least 0x%x\n",
		UINT32_LO(sysddr_cfg->phy_size), AIOP_MIN_ATU_OWS);
		/* if there is no dp-ddr system ddr can use all atu windows and the
		 3GB AIOP space*/
		if (!dpddr_cfg->phy_size) {
		/* ls1088a and old AIOP SL */
#ifdef LS1088A_OBSOLETE_SYS_DDR_VADDR
			struct aiopsl_version aiopsl_ver = {0};
			aiopsl_ver.major = ioread32be(&aiop_init->sl_info.aiop_rev_major);
			aiopsl_ver.minor = ioread32be(&aiop_init->sl_info.aiop_rev_minor);
			aiopsl_ver.rev = ioread32be(&aiop_init->sl_info.aiop_revision);
			if (AIOPSL_SUPPORTS_OBSOLETE_SYS_DDR_VADDR(aiopsl_ver)) {
				sysddr_cfg->virt_base_addr = LS1088A_OBSOLETE_SYS_DDR_VADDR;
			} else {
				/* for LS1088A - AIOP SL version >= 7.3.0 */
				sysddr_cfg->virt_base_addr = AIOP_DEFAULT_DPDDR_VADDR;
			}
#else
			sysddr_cfg->virt_base_addr = PTR_TO_UINT(dpaiop->desc.dp_ddr_vaddr);
#endif
			sysddr_cfg->virt_size =
					(uint32_t)(4 * GIGABYTE - sysddr_cfg->virt_base_addr);
			min_sysddr_atu_ows =
					sysddr_cfg->virt_size / MAX(available_atu_wins, 1);
			min_sysddr_atu_ows = get_adjusted_ows(min_sysddr_atu_ows,
						min_sysddr_atu_ows);
		} else {
			sysddr_cfg->virt_size = AIOP_SYS_DDR_ATU_SIZE;
			sysddr_cfg->virt_base_addr = AIOP_SYS_DDR_VADDR;
			min_sysddr_atu_ows = AIOP_MIN_ATU_OWS;
		}
		sysddr_cfg->max_atu_wins = available_atu_wins;
		err = get_mem_for_aiop_atu(MEM_PART_SYSTEM_DDR1,
				sysddr_cfg,
				min_sysddr_atu_ows,
				AIOP_SYS_DDR_ATU_SIZE);
		dpaiop->mem_paddrs.sys_ddr = sysddr_cfg->phy_base_addr;
		CHECK_COND_RETVAL(err == 0 && sysddr_cfg->ows_alignment, -EINVAL,
		"Can't allocated 0x%x%08x bytes from system DDR\n",
		UINT32_HI(sysddr_cfg->phy_size), UINT32_LO(sysddr_cfg->phy_size));
	}


	/* allocate SP's for AIOP use */
	dpaiop->spid_count = ioread32be(&aiop_app_info->spid_count);
	if (dpaiop->spid_count)
	{
		memset(&req, 0, sizeof(struct resman_res_req));
		snprintf(str, sizeof(str), "sp.aiop%d", dpaiop->id);
		strcpy(req.type, str);
		req.num = dpaiop->spid_count;
		req.options = DPRC_RES_REQ_OPT_ALIGNED;
		tmp_array = (int *)fsl_malloc(req.num *sizeof(int));
		CHECK_COND_RETVAL(tmp_array, -ENOMEM, "No Memory\n");

		//err = resman_bind(dpaiop->resman_device, &req, tmp_array);
		err = resman_bind(dpaiop->device, &req, tmp_array);
		if (err)
		{
			fsl_free(tmp_array);
			return err;
		}
		dpaiop->base_spid = *tmp_array;
		fsl_free(tmp_array);
	}

	return 0;
}

static int add_atu_cfg_window(struct aiop_tile_cfg *cfg,
		const struct resman_container_attributes *attributes,
		const uint64_t virt_base_addr, const uint64_t phy_base_addr,
		const uint64_t ows) {
	uint8_t index;
	index = (uint8_t) cfg->num_atu_win;
	CHECK_COND_RETVAL(index < (AIOP_ATU_NUM_OF_WINDOWS - 1), -EINVAL);
	cfg->num_atu_win += 1;
	cfg->atu_cfg[index].num = ( index + 1);
	cfg->atu_cfg[index].amq.bmt = attributes->bmt;
	cfg->atu_cfg[index].amq.pl = attributes->pl;
	cfg->atu_cfg[index].amq.va = attributes->va;
	cfg->atu_cfg[index].amq.icid = (uint16_t)attributes->icid;
	cfg->atu_cfg[index].data_access = 0;
	cfg->atu_cfg[index].instr_access = 0;
	cfg->atu_cfg[index].base_addr = virt_base_addr;
	cfg->atu_cfg[index].trans_addr = phy_base_addr;
	cfg->atu_cfg[index].size = ows;
	if (ows) {
		pr_debug(
		"Set ATU window #%d: size=0x%08x, vaddr=0x%08x, paddr=0x%x%08x\n",
		cfg->atu_cfg[index].num, UINT32_LO(ows), UINT32_LO(virt_base_addr),
		UINT32_HI(phy_base_addr), UINT32_LO(phy_base_addr));
	}
	return 0;
}

static int build_atu_windows_for_mem_rgn(struct dpaiop *dpaiop,
		int atu_type_id,
		const struct resman_container_attributes *attributes)
{
	struct mem_rgn_atu_window_cfg* mem_cfg;
	uint64_t virt_addr = 0UL;
	uint64_t phy_addr = 0UL;
	uint64_t ows = 0UL;
	uint64_t tmp_ows = 0UL;

	int err = 0;
	const char* atu_type_name;
	switch (atu_type_id) {
		case PEB_ATU:
			mem_cfg = &dpaiop->cfg.peb_atu_cfg;
			atu_type_name = MEM_MNG_PEB_NAME;
		break;
		case DPDDR_ATU:
			mem_cfg = &dpaiop->cfg.dpddr_atu_cfg;
			atu_type_name = MEM_MNG_DPDDR_NAME;
		break;
		case SYS_DDR_ATU:
			mem_cfg = &dpaiop->cfg.sysddr_atu_cfg;
			atu_type_name = "SYSTEM DDR";
		break;
		default:
			return -EINVAL;
	}

	if(!mem_cfg->phy_size ||
		mem_cfg->phy_base_addr == 0 ||
		mem_cfg->phy_base_addr == ILLEGAL_BASE) {
		pr_info("%s: skip configure ATU; no memory was allocated\n",
				atu_type_name);
		return 0;
	}

	pr_info("Setting AIOP access to %s...\n", atu_type_name);
	virt_addr = mem_cfg->virt_base_addr;
	phy_addr = mem_cfg->phy_base_addr;
	const uint64_t max_vaddr = (uint64_t)mem_cfg->virt_base_addr +
			mem_cfg->virt_size;
	const uint64_t max_paddr = (uint64_t)mem_cfg->phy_base_addr +
			mem_cfg->phy_size;
	mem_cfg->no_atu_wins = 0;
	mem_cfg->virt_mapped_size = 0;
	do {
		ows = tmp_ows = mem_cfg->ows_alignment;
		/* find suitable ows: both virtual and physical addresses
		are aligned to it and occupies most space from available
		AIOP virtual space */
		tmp_ows <<= 1;
		while ( (tmp_ows <= AIOP_MAX_ATU_OWS) &&
				(virt_addr & (tmp_ows - 1)) == 0 &&
				(phy_addr  & (tmp_ows - 1)) == 0 &&
				((virt_addr + tmp_ows) <= max_vaddr) &&
				((phy_addr + tmp_ows) <= max_paddr)) {
				ows = tmp_ows;
				tmp_ows <<= 1;
		}
		/* couldn't find any bigger ows try adjust the ows downwards */
		if ((ows == mem_cfg->ows_alignment) &&
			( ((virt_addr + ows) > max_vaddr) ||
				((phy_addr + ows) > max_paddr)) ) {
			tmp_ows = mem_cfg->ows_alignment >> 1;
			while (tmp_ows > AIOP_MIN_ATU_OWS) {
				if ((virt_addr & (tmp_ows - 1)) == 0 &&
					(phy_addr  & (tmp_ows - 1)) == 0 &&
					((virt_addr + tmp_ows) <= max_vaddr) &&
					((phy_addr + tmp_ows) <= max_paddr)) {
					ows = tmp_ows;
					break;
				}
				tmp_ows >>= 1;
			}
		}
		/* exit if no ows fits the current configuration */
		if (!((virt_addr & (ows - 1)) == 0 &&
			(phy_addr  & (ows - 1)) == 0 &&
			((virt_addr + ows) <= max_vaddr) &&
			((phy_addr + ows) <= max_paddr)))
			break;
		err = add_atu_cfg_window(&dpaiop->cfg, attributes, virt_addr,
				phy_addr, ows);
		/* exit if the ATU windows limit was exceeded */
		if (err)
			break;
		virt_addr += ows;
		phy_addr += ows;
		mem_cfg->virt_mapped_size += ows;
		mem_cfg->no_atu_wins++;
	} while (phy_addr < max_paddr &&
			mem_cfg->no_atu_wins < mem_cfg->max_atu_wins);
	CHECK_COND_RETVAL(mem_cfg->no_atu_wins > 0, -ENOMEM,
	"Fail to allocate ATU windows for %s", atu_type_name);
	if (virt_addr > mem_cfg->virt_base_addr) {
		pr_info(
		"%s: bytes 0x%08x/0x%x%08x (available/allocated) can be accessed"
		" directly by AIOP from virtual address 0x%08x\n",
		atu_type_name, UINT32_LO(virt_addr - mem_cfg->virt_base_addr),
		UINT32_HI(mem_cfg->phy_size), UINT32_LO(mem_cfg->phy_size),
		mem_cfg->virt_base_addr);

		if (phy_addr < mem_cfg->phy_base_addr + mem_cfg->phy_size) {
			pr_warn(
				"Couldn't map the entire allocated size 0x%x%08x ...\n",
				UINT32_HI(mem_cfg->phy_size), UINT32_LO(mem_cfg->phy_size));
			if ( (virt_addr < mem_cfg->virt_base_addr + mem_cfg->virt_size) &&
				 (mem_cfg->virt_size > mem_cfg->phy_size) )
				pr_warn("the allocated size must be a power of 2 ...\n");
			else
				pr_warn(
				"the allocated size exceeds AIOP's %s space (0x%08x) ...\n",
				atu_type_name, UINT32_LO(mem_cfg->virt_size));
			pr_warn(
			"bytes from physical address 0x%x%08x are not directly accessible"
			" by AIOP cores\n", UINT32_HI(phy_addr), UINT32_LO(phy_addr));
		}
	}
	return err;
}

/**************************************************************************//**
 AIOP API routines
 *//***************************************************************************/
static int build_aiop_cfg(struct dpaiop *dpaiop,
		struct aiop_app_init_info *aiop_app_info,
		struct resman_container_attributes *attributes,
		struct dpaiop_load_cfg *ld_cfg)
{
	int err, i;
	struct mc_desc mc_desc;
	struct soc_mc_portal_desc soc_mc_portal_desc = {0};
	struct aiop_tile_cfg *cfg = &dpaiop->cfg;

	/* get mc descriptor */
	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, SOC_DB_NO_MATCH_FIELDS, &mc_desc, NULL);
	CHECK_COND_RETVAL(err == 0, err);

	/* get first portal descriptor (this is the portals base) */
	soc_mc_portal_desc.portal_id = 0;
	err = sys_get_desc(SOC_MODULE_SOC_MC_PORTAL, SOC_DB_NO_MATCH_FIELDS, &soc_mc_portal_desc, NULL);
	CHECK_COND_RETVAL(err == 0, err);

	/* Set AIOP tile parameters */
	if (ld_cfg->tpc == USE_AIOP_IMAGE_TPC)
		cfg->tasks_per_core =
				(uint8_t)ioread32be(&aiop_app_info->tasks_per_core);
	else
		cfg->tasks_per_core = ld_cfg->tpc;
	cfg->cdma_cfg.amq.bmt = attributes->bmt;
	cfg->cdma_cfg.amq.pl = attributes->pl;
	cfg->cdma_cfg.amq.va = ld_cfg->options & DPAIOP_LOAD_OPT_ERRATA_VA_ENABLED
							? 1 : attributes->va;
	cfg->cdma_cfg.amq.icid = (uint16_t)attributes->icid;
	cfg->cdma_cfg.bdi = attributes->bdi;
	cfg->cdma_cfg.context_read_attr =
			CACHE_AXI4_RW_MEM_NON_COHERENT_NO_ALLOCATE_NO_LOOKUP;
	cfg->cdma_cfg.context_write_attr =
			CACHE_AXI4_RW_MEM_NON_COHERENT_NO_ALLOCATE_NO_LOOKUP;

	cfg->fdma_cfg.sru_size = ioread32be(&aiop_app_info->sru_size);
	cfg->fdma_cfg.hcl = ioread32be(&aiop_app_info->hcl);
	cfg->fdma_cfg.amq.bmt = attributes->bmt;
	cfg->fdma_cfg.amq.pl = attributes->pl;
	cfg->fdma_cfg.amq.va = attributes->va;
	cfg->fdma_cfg.amq.icid = (uint16_t)attributes->icid;
	cfg->fdma_cfg.data_read_attr =
			CACHE_AXI4_RW_MEM_NON_COHERENT_NO_ALLOCATE_NO_LOOKUP;
	cfg->fdma_cfg.data_write_attr =
			CACHE_AXI4_RW_MEM_NON_COHERENT_NO_ALLOCATE_NO_LOOKUP;
	cfg->fdma_cfg.sru_read_attr =
			CACHE_AXI4_RW_MEM_NON_COHERENT_NO_ALLOCATE_NO_LOOKUP;
	cfg->fdma_cfg.sru_write_attr =
			CACHE_AXI4_RW_MEM_NON_COHERENT_NO_ALLOCATE_NO_LOOKUP;

	cfg->ste_cfg.amq.bmt = attributes->bmt;
	cfg->ste_cfg.amq.pl = attributes->pl;
	cfg->ste_cfg.amq.va = ld_cfg->options & DPAIOP_LOAD_OPT_ERRATA_VA_ENABLED
							? 1 : attributes->va;
	cfg->ste_cfg.amq.icid = (uint16_t)attributes->icid;
	cfg->ste_cfg.data_read_attr =
			CACHE_AXI4_RW_MEM_NON_COHERENT_NO_ALLOCATE_NO_LOOKUP;
	cfg->ste_cfg.data_write_attr =
			CACHE_AXI4_RW_MEM_NON_COHERENT_NO_ALLOCATE_NO_LOOKUP;

	cfg->tman_cfg.amq.bmt = attributes->bmt;
	cfg->tman_cfg.amq.pl = attributes->pl;
	cfg->tman_cfg.amq.va = attributes->va;
	cfg->tman_cfg.amq.icid = (uint16_t)attributes->icid;
	cfg->tman_cfg.bdi = 0;

	cfg->defcfg.osm_cfg.err_mng.relinquish_concurrent = AIOP_ERR_DETECT;

	cfg->tman_cfg.freq = (sys_get_platform_clk()/1000);
	cfg->tman_cfg.freq_frac = (sys_get_platform_clk() % 1000);

	cfg->num_atu_win = 0;
	for( i = 0; i < AIOP_ATU_STATIC_WIN_NO - 1; i++)
	{
		add_atu_cfg_window(cfg, attributes, 0, 0, 0);
	}

	/* Open ATU window to MC-Portals: */
	cfg->atu_cfg[MC_PORTALS_ATU].base_addr = AIOP_MC_PORTALS_VADDR;
	cfg->atu_cfg[MC_PORTALS_ATU].trans_addr = soc_mc_portal_desc.paddr;
	cfg->atu_cfg[MC_PORTALS_ATU].size = 64*MEGABYTE;
	cfg->atu_cfg[MC_PORTALS_ATU].amq.bmt = 0;
	/* bmt, pl, va, icid are set in add_atu_cfg_window above */

	/* Open ATU window to CCSR:  */
	cfg->atu_cfg[CCSR_ATU].base_addr = AIOP_CCSR_VADDR;
	cfg->atu_cfg[CCSR_ATU].trans_addr = mc_desc.ccsr_paddr;
	cfg->atu_cfg[CCSR_ATU].size = mc_desc.ccsr_size;
	cfg->atu_cfg[CCSR_ATU].amq.bmt = 0;
	/* bmt, pl, va, icid are set in add_atu_cfg_window above */

	/* Open ATU windows for PEB, DP-DDR and System DDR */
	build_atu_windows_for_mem_rgn(dpaiop, PEB_ATU, attributes);
	build_atu_windows_for_mem_rgn(dpaiop, DPDDR_ATU, attributes);
	build_atu_windows_for_mem_rgn(dpaiop, SYS_DDR_ATU, attributes);

	cfg->ctlu_peb_num_entries = aiop_app_info->ctlu_peb_num_entries;
	cfg->ctlu_dp_ddr_num_entries = aiop_app_info->ctlu_dp_ddr_num_entries;
	cfg->ctlu_sys_ddr_num_entries = aiop_app_info->ctlu_sys_ddr_num_entries;
	cfg->mflu_peb_num_entries = aiop_app_info->mflu_peb_num_entries;
	cfg->mflu_dp_ddr_num_entries = aiop_app_info->mflu_dp_ddr_num_entries;
	cfg->mflu_sys_ddr_num_entries = aiop_app_info->mflu_sys_ddr_num_entries;

	return 0;
}



static int get_ctlu_str(int iop_id, enum ctlu_type type, char *str)
{
	switch (type) {
	case CTLU_EIOP_EGRESS:
		sprintf(str,"wr%d.ctlue", iop_id);
		break;
	case CTLU_EIOP_INGRESS:
		sprintf(str,"wr%d.ctlui", iop_id);
		break;
	case CTLU_AIOP:
		sprintf(str,"aiop%d.ctlu", iop_id);
		break;
	case CTLU_AIOP_MFLU:
		sprintf(str,"aiop%d.mflu", iop_id);
		break;
	default:
		return -EINVAL;
	}
	return 0;
}

static int init_parser(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	struct dpparser_cfg dpparser_cfg;
	struct dpparser *dpparser;
	struct resman_res_req req;
	int err;

	memset(&dpparser_cfg, 0, sizeof(dpparser_cfg));

	dpparser_cfg.ctlu = ctlu;
	dpparser_cfg.cycle_limit = DPPARSER_PCLIM_MAX;
	dpparser_cfg.options = 0;
	dpparser_cfg.num_profiles = ctlu_desc->num_dpparser_profiles;
	dpparser_cfg.options = 0;
	dpparser = dpparser_init(&dpparser_cfg);
	CHECK_COND_RETVAL(dpparser, -ENODEV);

	sys_add_handle(dpparser, FSL_MOD_PARSER, 2,
	/*iop_id*/ctlu_desc->iop_id,
	               /* CTLU type */ctlu_desc->type);

	/* Create resman parser profile pool */
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = (uint32_t)ctlu_desc->num_dpparser_profiles;
	dpparser_get_resource_str(dpparser, req.type);
	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(
	        sys_get_unique_handle(FSL_MOD_RESMAN), &req)) != 0
	        // don't exit if the resource already exists as we are after a AIOP reset
	        // and the AIOP application is just reloading;
	    && (err != -EEXIST))
		return err;

	return 0;
}

static int init_kg(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	struct dpkg_cfg dpkg_cfg;
	struct dpkg *dpkg;
	struct resman_res_req req;
	int err;

	memset(&dpkg_cfg, 0, sizeof(dpkg_cfg));

	dpkg_cfg.ctlu = ctlu;
	dpkg_cfg.num_profiles = ctlu_desc->num_dpkg_profiles;
	dpkg = dpkg_init(&dpkg_cfg);
	if (dpkg == NULL)
		return -ENODEV;

	sys_add_handle(dpkg, FSL_MOD_KG, 2, /*iop_id*/ctlu_desc->iop_id,
		/* CTLU type */ ctlu_get_type(ctlu));

	if (ctlu_desc->options & CTLU_DESC_OPT_USE_AS_MFLU)
		/* some SoC's do not have MFLU. CTLU is used for both. In order for
		 * devices to be able to get the appropriate handle in both flavors,
		 * we set here the MFLU dpkg handle as the CLTU handle. */
		sys_add_handle(dpkg,
		               FSL_MOD_KG,
				2, /*iop_id*/
				ctlu_desc->iop_id, /* CTLU type */
				CTLU_AIOP_MFLU);

	/* Create resman Keygen profiles pool */
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = (uint32_t)ctlu_desc->num_dpkg_profiles;
	dpkg_get_resource_str(dpkg, req.type);
	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(
	        sys_get_unique_handle(FSL_MOD_RESMAN), &req)) != 0
        // don't exit if the resource already exists as we are after a AIOP reset
        // and the AIOP application is just reloading;
	    && (err != -EEXIST))
		return err;

	return 0;
}

static void free_ctlu(struct dpaiop *dpaiop, enum ctlu_type type)
{
	void *handle;

	if ((handle = sys_get_handle(FSL_MOD_PARSER, /*num of ids*/2,
				/* iop_id */dpaiop->id,
				/*ctlu type */type))
			!= NULL) {
			dpparser_done((struct dpparser *)handle);
			sys_remove_handle(FSL_MOD_PARSER, 2, /* iop_id */
						dpaiop->id, /*ctlu type */
						type);
		}

		if ((handle = sys_get_handle(FSL_MOD_KG, 2,/* iop_id */
					dpaiop->id, /*ctlu type */
					type))
			!= NULL) {
			dpkg_done((struct dpkg *)handle);
			sys_remove_handle(FSL_MOD_KG, 2,
				/* iop_id */dpaiop->id, /*ctlu type */
				type);
		}

		if ((handle = sys_get_handle(FSL_MOD_TABLES_MNG, 2,
					/* iop_id */dpaiop->id,
					/*ctlu type */type))
			!= NULL) {
			dptbl_mng_done((struct dptbl_mng *)handle);
			sys_remove_handle(FSL_MOD_TABLES_MNG, 2,/* iop_id */
				dpaiop->id, /*ctlu type */
				type);

		}

		if ((handle = sys_get_handle(FSL_MOD_CTLU, 2, /* iop_id */
					dpaiop->id, /*ctlu type */
					type))
			!= NULL) {
			ctlu_done((struct ctlu *)handle);
			sys_remove_handle(FSL_MOD_CTLU, 2,
				/* iop_id */dpaiop->id, /*ctlu type */
				type);

		}

		return;

	}

#ifdef DUMP_DDR_MEM_PROFILE
/******************************************************************************/
static void aiop_dump_profile_from_ddr(struct dpaiop *dpaiop, int pp_id)
{
	int				err;
	dma_addr_t			aiop_ddr_base, iova;
	struct dpparser_profile_map	profile_map;

	aiop_ddr_base = dpaiop->mem_paddrs.sys_ddr;
	iova = aiop_ddr_base + pp_id * sizeof(struct dpparser_profile_map);
	/* Copy data from AIOP DDR to MC */
	err = dpmng_dev_memcpy(dpaiop->device, &profile_map, iova,
			       sizeof(struct dpparser_profile_map), 1);
	if (err)
		pr_err("Error reading profile %d from AIOP DDR\n", pp_id);
		return;
	}
	dump_profile(&profile_map, pp_id, "Read from AIOP DDR");
}

#else
	#define aiop_dump_profile_from_ddr(_a, _b)
#endif	/* DUMP_DDR_MEM_PROFILE */

/******************************************************************************/
static int aiop_copy_profile_to_ddr(struct dpaiop *dpaiop, int pp_id,
				    struct dpparser_profile_map *profile_map)
{
	int		err;
	dma_addr_t	aiop_ddr_base, iova;

	aiop_ddr_base = dpaiop->mem_paddrs.sys_ddr;
	iova = aiop_ddr_base + pp_id * sizeof(struct dpparser_profile_map);
	/* Copy profile data into AIOP DDR */
	err = dpmng_dev_memcpy(dpaiop->device, profile_map, iova,
			       sizeof(struct dpparser_profile_map), 0);
	if (err) {
		pr_err("Error writing profile %d into AIOP DDR\n", pp_id);
		return err;
	}
	pr_info("Profile %d was written into AIOP DDR at phys : 0x%x-%08x\n",
		pp_id, (uint32_t)(iova >> 32), (uint32_t)iova);
	return 0;
}

/******************************************************************************/
static int aiop_cfg_default_parse_profiles(struct dpaiop *dpaiop,
					   enum ctlu_type type)
{
	struct dpparser				*dpparser;
	int					err;
	char					res_type[16];
	struct dpparser_profile_opt_cfg		cfg;
	struct dpparser_profile_map		*profile_map;

	dpaiop->ingress_pp_id = -1;
	dpaiop->egress_pp_id = -1;
	dpaiop->ingress_start_hxs = 0;	/* ETH HXS */
	dpaiop->egress_start_hxs = 0;	/* ETH HXS */
	/* Get device handle */
	dpparser = (struct dpparser *)sys_get_handle(FSL_MOD_PARSER, 2,
						     dpaiop->id, type);
	if (!dpparser)
		return -ENODEV;
	dpparser_get_resource_str(dpparser, res_type);
	/******************************************/
	/* Allocate AIOP Ingress parse profile ID */
	/******************************************/
	err = dpparser_find_profile(dpparser, NULL, NULL, 0,
				    &dpaiop->ingress_pp_id);
	if (err) {
		err = allocate_resource(dpaiop->device, res_type, 1, 1, 0,
					&dpaiop->ingress_pp_id,
					"AIOP-PROFILE-ID");
		if (err)
			return err;
	}
	/******************************************/
	/* Allocate AIOP Egress parse profile ID  */
	/******************************************/
	err = dpparser_find_profile(dpparser, NULL, NULL, 0,
				    &dpaiop->egress_pp_id);
	if (err) {
		err = allocate_resource(dpaiop->device, res_type, 1, 1, 0,
					&dpaiop->egress_pp_id,
					"AIOP-PROFILE-ID");
		if (err)
			return err;
	}
	/*
	 * Enables the system-level defined AIOP ingress/egress soft parsers.
	 * Such parsers are configured on the parse profile named 'Default' and
	 * have the 'enable' bit set. If there is a soft parser parsing a
	 * header placed before the ETH header its PC is returned in
	 * ingress_start_hxs/egress_start_hxs AIOP globals.
	 */
	/********************************************/
	/* Initialize AIOP Ingress parse profile ID */
	/********************************************/
	memset(&cfg, 0, sizeof(struct dpparser_profile_opt_cfg));
	cfg.mpls_next_hxs = HXS_NULL;
	cfg.options = DPPARSER_MPLS_LABEL_INTERPRETATION_DISABLE;
	cfg.options |= DPPARSER_PPP_DISABLE_MTU_CHECK;
	/**/
	err = dpparser_init_profile(dpparser, dpaiop->ingress_pp_id, NULL,
				    &cfg);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	err = dpparser_attach_default_soft_parser(dpparser, dpaiop->ingress_pp_id,
						&dpaiop->ingress_start_hxs,
						0, NULL);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	if (dpaiop->ingress_start_hxs)
		pr_info("AIOP INGRESS start HXS set to 0x%x\n",
			dpaiop->ingress_start_hxs);
	/* Copy profile into AIOP DDR */
	err = dpparser_get_profile_map(dpparser, dpaiop->ingress_pp_id,
				       &profile_map);
	if (err) {
		pr_err("Cannot find profile %d\n", dpaiop->ingress_pp_id);
		return err;
	}
	/* Temporarily bypass copying of parser profiles into AIOP DDR space.
	 * This is causing a context fault in Linux because the address used by MC
	 * is physical but transactions go through IOMMU so an IOVA address must
	 * be provisioned instead. */
#if 0
	err = aiop_copy_profile_to_ddr(dpaiop, dpaiop->ingress_pp_id,
				       profile_map);
	if (err)
		return err;
	/* Dump the profile written into AIOP DDR */
	aiop_dump_profile_from_ddr(dpaiop, dpaiop->ingress_pp_id);
#endif
	/*******************************************/
	/* Initialize AIOP Egress parse profile ID */
	/*******************************************/
	err = dpparser_init_profile(dpparser, dpaiop->egress_pp_id, NULL,
				    &cfg);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	err = dpparser_attach_default_soft_parser(dpparser, dpaiop->egress_pp_id,
						&dpaiop->egress_start_hxs,
						1, NULL);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	if (dpaiop->egress_start_hxs)
		pr_info("AIOP EGRESS start HXS set to 0x%x\n",
			dpaiop->egress_start_hxs);
	/* Copy profile into AIOP DDR */
	err = dpparser_get_profile_map(dpparser, dpaiop->egress_pp_id,
				       &profile_map);
	if (err) {
		pr_err("Cannot find profile %d\n", dpaiop->egress_pp_id);
		return err;
	}
	/* Temporarily bypass copying of parser profiles into AIOP DDR space.
	 * This is causing a context fault in Linux because the address used by MC
	 * is physical but transactions go through IOMMU so an IOVA address must
	 * be provisioned instead. */
#if 0
	err = aiop_copy_profile_to_ddr(dpaiop, dpaiop->egress_pp_id,
				       profile_map);
	if (err)
		return err;
	/* Dump the profile written into AIOP DDR */
	aiop_dump_profile_from_ddr(dpaiop, dpaiop->egress_pp_id);
#endif
	return 0;
}

static int cfg_ctlus(struct dpaiop *dpaiop)
{
	int err = 0, iter = 0;
	struct ctlu_desc ctlu_desc;
	struct ctlu_cfg ctlu_cfg;
	struct ctlu *ctlu;

	memset(&ctlu_desc, 0, sizeof(struct ctlu_desc));
	ctlu_desc.iop_id = dpaiop->aiop_id;

	while (sys_get_desc(SOC_MODULE_CTLU, SOC_DB_CTLU_DESC_IOP_ID,
				&ctlu_desc, &iter)
		== 0) {
		if (!((ctlu_desc.type == CTLU_AIOP)
			|| (ctlu_desc.type == CTLU_AIOP_MFLU)))
			continue;

		/*******************************************/
		/* initialize CTLU general internal module */
		/*******************************************/
		memset(&ctlu_cfg, 0, sizeof(ctlu_cfg));
		ctlu = ctlu_init(&ctlu_desc, &ctlu_cfg);
		if (!ctlu)
			return err;

		/***********************/
		/* Parser init         */
		/***********************/
		if (ctlu_desc.type == CTLU_AIOP) {
			err |= init_parser(ctlu, &ctlu_desc);
			if (err) {
				free_ctlu(dpaiop, ctlu_desc.type);
				return -ENODEV;
			}
			err = aiop_cfg_default_parse_profiles(dpaiop,
							      ctlu_desc.type);
			CHECK_COND_RETVAL(err == 0, err);
		}

		/**********************/
		/* Key generator init */
		/**********************/
		err = init_kg(ctlu, &ctlu_desc);
		CHECK_COND_RETVAL(err == 0, err);

		/***********************/
		/* Tables manager init */
		/***********************/
		err = init_tables(dpaiop, ctlu, &ctlu_desc);
		if (err) {
			free_ctlu(dpaiop, ctlu_desc.type);
			return -ENODEV;
		}

		sys_add_handle(ctlu, FSL_MOD_CTLU, 2, /*iop_id*/
				ctlu_desc.iop_id, /* CTLU type */
				ctlu_desc.type);

		if (ctlu_desc.options & CTLU_DESC_OPT_USE_AS_MFLU)
			/* some SoC's do not have MFLU. CTLU is used for both. In order for
			 * devices to be able to get the appropriate handle in both flavors,
			 * we set here the MFLU handle as the CLTU handle. */
			sys_add_handle(ctlu,
					FSL_MOD_CTLU,
					2, /*iop_id*/
					ctlu_desc.iop_id, /* CTLU type */
					CTLU_AIOP_MFLU);

		ctlu_enable(ctlu);
	}

	return 0;
}

static int free_dpci(struct dpaiop *dpaiop)
{
	int err = 0;
	struct dpci_attr dpci_attr;
	struct resman *resman = \
		(struct resman *)sys_get_unique_handle(FSL_MOD_RESMAN);

	CHECK_COND_RETVAL(resman, -ENODEV);

	CHECK_COND_RETVAL(dpaiop->dpci, -EINVAL);

	memset(&dpci_attr, 0, sizeof(struct dpci_attr));
	err = dpci_get_attributes(dpaiop->dpci, &dpci_attr);
	CHECK_COND_RETVAL(err == 0, err);

/*
	err = resman_close_dev(resman,
	       device,
	       "dpci",
	       NO_PORTAL_ID,
	       1);
*/

	dpci_destroy(dpaiop->dpci);
	
	err = sys_remove_handle(FSL_MOD_CMDIF_CL_REGS, 1, 0);
	CHECK_COND_RETVAL(err == 0, err);
	err = sys_remove_handle(FSL_MOD_DPCI, 1, dpci_attr.id);
	CHECK_COND_RETVAL(err == 0, err);

	dpaiop->dpci = NULL;

	return err;
}

static int init_dpci(struct dpaiop *dpaiop)
{
	struct dpci_cfg dpci_cfg;
	struct dpci_rx_queue_cfg queue_cfg;
	int err = 0;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct resman *resman = NULL;
	void *device = NULL;
	struct dpci_attr dpci_attr;

	memset(&dpci_attr, 0, sizeof(struct dpci_attr));
	memset(&dpci_cfg, 0, sizeof(struct dpci_cfg));
	memset(&queue_cfg, 0, sizeof(struct dpci_rx_queue_cfg));

	resman = (struct resman *)sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	device = resman_open_dev(resman, "dpci", RESMAN_NO_DEVICE_ID,
	                         NO_PORTAL_ID, 1, NULL);
	CHECK_COND_RETVAL(device, -ENODEV);

	dpaiop->dpci = dpci_allocate();
	CHECK_COND_RETVAL(dpaiop->dpci, -ENOMEM);

	dev_cfg.id = device_get_id(device);
	dev_cfg.device = device;
	dev_cfg.ctx.type = DPMNG_CTX_TYPE_MC;

	dpmng_get_amq(&(dev_cfg.ctx.amq));

	dpci_cfg.num_of_priorities = 2;
	err = dpci_init(dpaiop->dpci, &dpci_cfg, &dev_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	err = dpci_set_dev_ctx(dpaiop->dpci, &(dev_cfg.ctx));
	CHECK_COND_RETVAL(err == 0, err);

	queue_cfg.dest_cfg.dest_type = DPCI_DEST_NONE;
	queue_cfg.dest_cfg.priority = 1;
	queue_cfg.user_ctx = 0;
	err = dpci_set_rx_queue(dpaiop->dpci, 0, &queue_cfg);
	CHECK_COND_RETVAL(err == 0, err);
	queue_cfg.dest_cfg.priority = 0;
	queue_cfg.user_ctx = 0;
	err = dpci_set_rx_queue(dpaiop->dpci, 1, &queue_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	err = dpci_get_attributes(dpaiop->dpci, &dpci_attr);
	CHECK_COND_RETVAL(err == 0, err);

	err = sys_add_handle(dpaiop->dpci, FSL_MOD_CMDIF_CL_REGS, 1, 0);
	CHECK_COND_RETVAL(err == 0, err);
	err = sys_add_handle(dpaiop->dpci, FSL_MOD_DPCI, 1, dpci_attr.id);
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}

static int dpaiop_open_cmdif_client(struct dpaiop *dpaiop)
{
	int err;

	CHECK_COND_RETVAL(dpaiop->dpci, -ENODEV);

	if (!dpaiop->command_buffer)
		dpaiop->command_buffer = fsl_malloc(64 * (EVM_NUM_OF_BUFFERS+1));
	CHECK_COND_RETVAL(dpaiop->command_buffer, -ENOMEM, "No Memory\n");

	dpaiop->buf_num_send = 0;

	if (!dpaiop->cidesc.regs) {
		dpaiop->cidesc.regs = dpaiop->dpci;
		/* Only no response commands can be sent through
		 * dpaiop->cidesc */
		err = aiop_evm_cmdif_open(&dpaiop->cidesc,
		                          dpaiop->command_buffer, 64);
		if (err) {
			dpaiop->cidesc.regs = NULL;
			pr_err("aiop_evm_cmdif_open failed\n");
			return -ENAVAIL;
		}
	}

	return 0;
}

int dpaiop_send_event(struct dpaiop *dpaiop, uint64_t *data, uint32_t size)
{
	int err = 0;

	if (!dpaiop->cidesc.regs || !dpaiop->command_buffer)
		err = dpaiop_open_cmdif_client(dpaiop);
	CHECK_COND_RETVAL(err == 0, err);
	dpaiop->buf_num_send++;
	if(dpaiop->buf_num_send > EVM_NUM_OF_BUFFERS)
		dpaiop->buf_num_send = 1;
	memcpy((void*)((uint64_t)dpaiop->command_buffer+(64*dpaiop->buf_num_send)), data, size);

	/* Only no response commands can be sent through dpaiop->cidesc */
	err = cmdif_send(&dpaiop->cidesc,
	                 (uint16_t)(EVM_EVENT_SEND | CMDIF_NORESP_CMD),
	                 size, /*size*/
	                 CMDIF_PRI_HIGH, /*priority*/
	                 (uint64_t)((uint64_t)dpaiop->command_buffer+(64*dpaiop->buf_num_send)), /*data*/
	                 NULL, NULL);

	return err;

}

static int get_container_attributes(int aiop_container_id,
	struct resman_container_attributes *attributes)
{
	void *resman, *dprc;
	int err = 0;

	resman = (struct resman *)sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);
	
	dprc = resman_get_container(resman, aiop_container_id);
	CHECK_COND_RETVAL(dprc, -ENODEV);

	memset(attributes, 0, sizeof(struct resman_container_attributes));
	err = resman_get_attributes(dprc, attributes);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static void free_tile_runtime_resources(struct dpaiop *dpaiop)
{
	struct aiop_tile_cfg *cfg = &dpaiop->cfg;
	int i;

	mpic_disable_intr((uint32_t)dpaiop->desc.irq_rec_err);
	mpic_disable_intr((uint32_t)dpaiop->desc.irq_cat_err);

	for (i = 0; i < cfg->num_atu_win; i++)
	{
		if (cfg->atu_cfg[i].size)
			aiop_tile_atu_win_disable(&dpaiop->desc, cfg->atu_cfg[i].num);
	}

	free_ctlu(dpaiop, CTLU_AIOP);
	free_ctlu(dpaiop, CTLU_AIOP_MFLU);

	if (dpaiop->spid_count)
		resman_unbind_all(dpaiop->device);

	if (dpaiop->mem_paddrs.dp_ddr) {
		fsl_put_mem(dpaiop->mem_paddrs.dp_ddr);
		dpaiop->mem_paddrs.dp_ddr = 0;
		memset(&dpaiop->cfg.dpddr_atu_cfg, 0x0,
				sizeof(struct mem_rgn_atu_window_cfg));
	}
	if (dpaiop->mem_paddrs.sys_ddr) {
		fsl_put_mem(dpaiop->mem_paddrs.sys_ddr);
		dpaiop->mem_paddrs.sys_ddr = 0;
		memset(&dpaiop->cfg.sysddr_atu_cfg, 0x0,
				sizeof(struct mem_rgn_atu_window_cfg));
	}
	if (dpaiop->mem_paddrs.peb) {
		fsl_put_mem(dpaiop->mem_paddrs.peb);
		dpaiop->mem_paddrs.peb = 0;
		memset(&dpaiop->cfg.peb_atu_cfg, 0x0,
				sizeof(struct mem_rgn_atu_window_cfg));
	}
	if (dpaiop->mflu_paddrs.dp_ddr) {
		fsl_put_mem(dpaiop->mflu_paddrs.dp_ddr);
		dpaiop->mflu_paddrs.dp_ddr = 0;
	}
	if (dpaiop->mflu_paddrs.sys_ddr) {
		fsl_put_mem(dpaiop->mflu_paddrs.sys_ddr);
		dpaiop->mflu_paddrs.sys_ddr = 0;
	}
	if (dpaiop->mflu_paddrs.peb) {
		fsl_put_mem(dpaiop->mflu_paddrs.peb);
		dpaiop->mflu_paddrs.peb = 0;
	}
	if (dpaiop->ctlu_paddrs.dp_ddr) {
		fsl_put_mem(dpaiop->ctlu_paddrs.dp_ddr);
		dpaiop->ctlu_paddrs.dp_ddr = 0;
	}
	if (dpaiop->ctlu_paddrs.sys_ddr) {
		fsl_put_mem(dpaiop->ctlu_paddrs.sys_ddr);
		dpaiop->ctlu_paddrs.sys_ddr = 0;
	}
	if (dpaiop->ctlu_paddrs.peb) {
		fsl_put_mem(dpaiop->ctlu_paddrs.peb);
		dpaiop->ctlu_paddrs.peb = 0;
	}
	if (dpaiop->sru_base) {
		fsl_put_mem(dpaiop->sru_base);
		dpaiop->sru_base = 0;
	}
	if (dpaiop->tman_ctrl_mem) {
		fsl_put_mem(dpaiop->tman_ctrl_mem);
		dpaiop->tman_ctrl_mem = 0;
	}
	/* free aiop command line args & reset */
	if (dpaiop->args_buffer) {
		fsl_free(dpaiop->args_buffer);
	}
	dpaiop->args_buffer = NULL;
	dpaiop->args_size = 0;
}


static int load_image(struct dpaiop *dpaiop, uint8_t *img_addr, phys_addr_t *aiop_boot_s_paddr)
{
	struct aiop_tile_cfg *cfg = &dpaiop->cfg;
	int err;

	dpmng_mc_lock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
	//dpmng_mc_lock_ccsr_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	/* save in aiop memory map */
	/* Define SRAM address translation */
	dpaiop->mem_map[0].phy_base_addr = dpaiop->desc.sram_paddr;
	dpaiop->mem_map[0].mem_size = dpaiop->desc.sram_size;
	dpaiop->mem_map[0].vrt_base_addr = (dma_addr_t)dpaiop->desc.sram_vaddr;

	/* Define IRAM address translation */
	dpaiop->mem_map[1].phy_base_addr = dpaiop->desc.iram_paddr;
	dpaiop->mem_map[1].mem_size = dpaiop->desc.iram_size;
	dpaiop->mem_map[1].vrt_base_addr = (dma_addr_t)dpaiop->desc.iram_vaddr;

	/* Define DPDDR address translation */
	if (cfg->dpddr_atu_cfg.no_atu_wins > 0) {
		dpaiop->mem_map[2].phy_base_addr = cfg->dpddr_atu_cfg.phy_base_addr;
		dpaiop->mem_map[2].mem_size = cfg->dpddr_atu_cfg.virt_mapped_size;
		dpaiop->mem_map[2].vrt_base_addr = cfg->dpddr_atu_cfg.virt_base_addr;
	}
	/* Define SYS_DDR address translation */
	if (cfg->sysddr_atu_cfg.no_atu_wins > 0) {
		dpaiop->mem_map[3].phy_base_addr = cfg->sysddr_atu_cfg.phy_base_addr;
		dpaiop->mem_map[3].mem_size = cfg->sysddr_atu_cfg.virt_mapped_size;
		dpaiop->mem_map[3].vrt_base_addr = cfg->sysddr_atu_cfg.virt_base_addr;
	}
	err = eld_load_image((void *)dpaiop, img_addr, (size_t)0,
				aiop_boot_s_paddr);
	if (err) {
		/* restore the SoC window mapping */
		dpmng_mc_unlock_soc_window(
			sys_get_unique_handle(FSL_MOD_DPMNG));
		//dpmng_mc_unlock_ccsr_window(
		//sys_get_unique_handle(FSL_MOD_DPMNG));
		return err;
	}

	/* restore the SoC window mapping */
	dpmng_mc_unlock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
	//dpmng_mc_unlock_ccsr_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	return 0;
}

static uint64_t check_available_clusters(uint8_t num_clusters, uint64_t cores_mask)
{

	uint64_t available_cores_mask = 0;
	int i;

	for (i = 0; i < num_clusters; i++)
		available_cores_mask |= (0xf << i*4);


	if ((cores_mask & available_cores_mask) != cores_mask)
		pr_warn("aiop_drv_tile_run called for cores of non available clusters (avail clusters: %d).\n Continuing without unavailable cores\n",
		        num_clusters);

	return (cores_mask & available_cores_mask);
}

static void set_aiop_sl_params(struct dpaiop *dpaiop)
{
	uint64_t tmp_64;
	struct aiop_init_info *aiop_boot_s_vaddr;
	struct aiop_app_init_info *aiop_app_info;
	struct aiop_sl_init_info *aiop_sl_info;
	struct aiop_tile_cfg *cfg = &dpaiop->cfg;
	struct dpci_attr dpci_attr;
	enum log_mode use_log_buf;
	enum console_mode use_uart;
	int uart_id;
	struct dpmng_amq mc_amq;
	
	dpci_get_attributes(dpaiop->dpci, &dpci_attr);

	/* Use the SoC window to write to SRAM */
	dpmng_mc_lock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	dpmng_get_amq(&mc_amq);
	aiop_boot_s_vaddr = (struct aiop_init_info *)dpmng_mc_set_soc_window(dpaiop->boot_s_paddr, &mc_amq);

	aiop_app_info = &aiop_boot_s_vaddr->app_info;
	aiop_sl_info = &aiop_boot_s_vaddr->sl_info;

	iowrite32be(sys_get_platform_clk(), &aiop_sl_info->platform_clk);

	iowrite64be((dpmng_get_mc_mem_base() + 0x06000000LL), &aiop_sl_info->log_buf_paddr);
	/* if AIOP exists in DPC */
	use_log_buf = (dpc.aiop.log.dpc_mask & DPC_LOG_MASK_MODE) ?
			dpc.aiop.log.mode : LOG_MODE_ON;
	if (use_log_buf == LOG_MODE_ON)
		iowrite32be(16 * MEGABYTE, &aiop_sl_info->log_buf_size);
	else
		iowrite32be(0, &aiop_sl_info->log_buf_size);

	use_uart = (dpc.aiop.console.dpc_mask & DPC_CONSOLE_MASK_MODE) ?
			dpc.aiop.console.mode : CONSOLE_MODE_ON;
	uart_id = (dpc.aiop.console.dpc_mask & DPC_CONSOLE_MASK_UART_ID) ?
			dpc.aiop.console.uart_id : 3;

	if (use_uart == CONSOLE_MODE_ON)
		iowrite32be((uint32_t)uart_id, &aiop_sl_info->uart_port_id);
	else
		iowrite32be(0, &aiop_sl_info->uart_port_id);

	iowrite64be(dpaiop->options, &aiop_sl_info->options);
	iowrite32be((uint32_t)dpaiop->aiop_attributes.portal_id, &aiop_sl_info->mc_portal_id);
	iowrite32be((uint32_t)dpci_attr.id, &aiop_sl_info->mc_dpci_id);
	iowrite32be((uint32_t)dpaiop->base_spid, &aiop_sl_info->base_spid);

	/* Ingress PPID and start HXS */
	iowrite32be((uint32_t)dpaiop->ingress_pp_id,
		    &aiop_sl_info->ingress_pp_id);
	iowrite16be((uint16_t)dpaiop->ingress_start_hxs,
		    &aiop_sl_info->ingress_start_hxs);
	/* Egress PPID and start HXS */
	iowrite32be((uint32_t)dpaiop->egress_pp_id,
		    &aiop_sl_info->egress_pp_id);
	iowrite16be((uint16_t)dpaiop->egress_start_hxs,
		    &aiop_sl_info->egress_start_hxs);

	if (dpaiop->args_size)
	{
		iowrite32be(dpaiop->args_size, &aiop_sl_info->args_size);
		memcpy(aiop_sl_info->args, dpaiop->args_buffer, dpaiop->args_size);
		if (will_log(NO_ID, LOG_LEVEL_DEBUG)) {
			pr_debug("AIOP arguments (%d):\n", dpaiop->args_size);
			mem_disp(aiop_sl_info->args, (int)aiop_sl_info->args_size);
		}
	}


	/* set virt addresses for all blocks */
	if (cfg->dpddr_atu_cfg.no_atu_wins > 0)
	{
		iowrite64be(cfg->dpddr_atu_cfg.phy_base_addr,
				&aiop_sl_info->dp_ddr_paddr);
		iowrite64be(cfg->dpddr_atu_cfg.virt_base_addr,
				&aiop_sl_info->dp_ddr_vaddr);
	}

	if (cfg->peb_atu_cfg.no_atu_wins > 0)
	{
		iowrite64be(cfg->peb_atu_cfg.phy_base_addr, &aiop_sl_info->peb_paddr);
		iowrite64be(cfg->peb_atu_cfg.virt_base_addr, &aiop_sl_info->peb_vaddr);
	}

	if (cfg->sysddr_atu_cfg.no_atu_wins > 0)
	{
		iowrite64be(cfg->sysddr_atu_cfg.phy_base_addr,
				&aiop_sl_info->sys_ddr1_paddr);
		iowrite64be(cfg->sysddr_atu_cfg.virt_base_addr,
				&aiop_sl_info->sys_ddr1_vaddr);
	}

	iowrite64be(cfg->atu_cfg[MC_PORTALS_ATU].trans_addr, &aiop_sl_info->mc_portals_paddr);
	iowrite64be(cfg->atu_cfg[MC_PORTALS_ATU].base_addr, &aiop_sl_info->mc_portals_vaddr);

	iowrite64be(cfg->atu_cfg[CCSR_ATU].trans_addr, &aiop_sl_info->ccsr_paddr);
	iowrite64be(cfg->atu_cfg[CCSR_ATU].base_addr, &aiop_sl_info->ccsr_vaddr);

	pr_debug("AIOP Struct fields:\n");
	tmp_64 = ioread64be(&aiop_sl_info->sys_ddr1_paddr);
	pr_debug("SYS DDR phys: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->sys_ddr1_vaddr);
	pr_debug("SYS DDR virt: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->peb_paddr);
	pr_debug("PEB DDR phys: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->peb_vaddr);
	pr_debug("PEB DDR virt:  0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
        if (aiop_app_info->dp_ddr_size)
        {
		tmp_64 = ioread64be(&aiop_sl_info->dp_ddr_paddr);
		pr_debug(
			"DP DDR phys: 0x%08x%08x\n", UINT32_HI(tmp_64), UINT32_LO(tmp_64));
		tmp_64 = ioread64be(&aiop_sl_info->dp_ddr_vaddr);
		pr_debug(
			"DP DDR virt:  0x%08x%08x\n", UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	}
	tmp_64 = ioread64be(&aiop_sl_info->ccsr_paddr);
	pr_debug("CCSR phys: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->ccsr_vaddr);
	pr_debug("CCSR virt: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->mc_portals_paddr);
	pr_debug("MC Portals phys: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->mc_portals_vaddr);
	pr_debug("MC Portals virt: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));

	dpmng_mc_unlock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	return;
}


#ifdef FUTURE_SUPPORT
static int check_load_state(struct dpaiop *dpaiop)
{
	uint32_t status = 0;
	int err;

	if (dpaiop->status == DPAIOP_STATE_BOOT_ONGOING)
	{
		err = dpaiop_get_state(dpaiop, &status);
		CHECK_COND_RETVAL(err == 0, err);
	}

	switch (status) {
	case (DPAIOP_STATE_LOAD_ERROR):
	case (DPAIOP_STATE_BOOT_ERROR):
	case (DPAIOP_STATE_RUNNING):
		dpaiop_reset(dpaiop);
	case (DPAIOP_STATE_LOAD_DONE):
	case (DPAIOP_STATE_RESET_DONE):
		break;
	case (DPAIOP_STATE_RESET_ONGOING):
	case (DPAIOP_STATE_LOAD_ONGIONG):
	case (DPAIOP_STATE_BOOT_ONGOING):
		pr_err("Bad state (0x%08x)\n", dpaiop->status);
		return -EACCES;
		break;
	}

	return 0;
}
#endif /* FUTURE_SUPPORT */

static int runtime_init(struct dpaiop *dpaiop)
{
	int err;

	/* re-initialize all registers as before */
	err = cfg_tile(dpaiop);
	CHECK_COND_RETVAL(err == 0, err);
	//aiop_tile_restore_ep_table(dpaiop->aiop_tile);
	//aiop_tile_restore_sp_table(dpaiop->aiop_tile);

	/* initialize CTLU and MFLU */
	err = cfg_ctlus(dpaiop);
	CHECK_COND_RETVAL(err == 0, err);

	err = mpic_enable_intr((uint32_t)dpaiop->desc.irq_cat_err);
	CHECK_COND_RETVAL(err == 0, err);
	err = mpic_enable_intr((uint32_t)dpaiop->desc.irq_rec_err);
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}

static int invoke_inter(void *dpaiop, uint8_t index, uint32_t event)
{
	CHECK_COND_RETVAL(dpaiop, -ENODEV);

	event_send(&(((struct dpaiop *)dpaiop)->irqs[index]), event);

	return 0;
}

/* converts AIOP effective addresses to physical addresses MC can map/DMA to */
int dpaiop_virt2phys(struct dpaiop *dpaiop,  uintptr_t aiop_vaddr,
			phys_addr_t *paddr)
{
	uint64_t size;
	phys_addr_t pbase;
	int i;
	uint32_t vbase;

	/* if address is in SRAM */
	vbase = (uint32_t)dpaiop->desc.sram_vaddr;
	pbase = dpaiop->desc.sram_paddr;
	size = (uint64_t)dpaiop->desc.sram_size;

	if (((uint32_t)aiop_vaddr >= vbase) &&
			((uint32_t)aiop_vaddr < (uint64_t)vbase + size))
	{
		*paddr = (pbase + (uint64_t)((uint32_t)aiop_vaddr - vbase));
		return 0;
	}

	for (i = 0; i < AIOP_ATU_NUM_OF_WINDOWS; i++)
	{
		/* if ATU window is enabled */
		if (aiop_tile_get_atu(&dpaiop->desc, i,
				(void *)&vbase, &pbase, &size) == 0)
		{
			if (((uint32_t)aiop_vaddr >= vbase) &&
					((uint32_t)aiop_vaddr < (uint64_t)vbase + size))
			{
				*paddr = (pbase + (uint64_t)((uint32_t)aiop_vaddr - vbase));
				return 0;
			}
		}
	}

	return -ENODEV;
}

int dpaiop_init(struct dpaiop *dpaiop,
		const struct dpaiop_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg)
{
	int i, err;
	struct aiop_tile_desc aiop_tile_desc;
	mpic_intr_params_t intr_params = {0};

	CHECK_COND_RETVAL(cfg->aiop_id == dev_cfg->id, -EINVAL);

	set_mc_info(dpaiop, dev_cfg);

	/* Init tile */
	aiop_tile_desc.tile_id = cfg->aiop_id;

	err = sys_get_desc(SOC_MODULE_AIOP, SOC_DB_AIOP_TILE_DESC_ID, &aiop_tile_desc, NULL);
	if (err) {
		pr_err("Failed to create DPAIOP! tile_id %d is not supported\n", aiop_tile_desc.tile_id);
		return -EINVAL;
	}

	dpaiop->aiop_container_id = cfg->aiop_container_id;
	dpaiop->status = DPAIOP_STATE_RESET_DONE;
	dpaiop->desc = aiop_tile_desc;
	dpaiop->regs = (struct aiop_tile_regs *)aiop_tile_desc.vaddr;
	dpaiop->aiop_tile = sys_get_handle(FSL_MOD_AIOP_TILE, 1, 0);

	CHECK_COND_RETVAL(dpaiop->aiop_tile, -ENAVAIL);
	dpaiop->args_buffer = NULL;
	dpaiop->args_size = 0;
	
	/* create dpci */
	err = init_dpci(dpaiop);
	CHECK_COND_RETVAL(err == 0, err);

	intr_params.polarity = OS_MPIC_INTR_POLARITY_HIGH;
	intr_params.priority = 8;
	intr_params.sense = OS_MPIC_INTR_SENSE_LEVEL;
	intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;
	err = mpic_set_config_intr((uint32_t)aiop_tile_desc.irq_rec_err, 0, aiop_err_isr, (mpic_arg)(dpaiop->aiop_tile), &intr_params);
	CHECK_COND_RETVAL(err == 0, err);

	err = mpic_set_config_intr((uint32_t)aiop_tile_desc.irq_cat_err, 0, aiop_cat_err_isr, (mpic_arg)(dpaiop->aiop_tile), &intr_params);
	CHECK_COND_RETVAL(err == 0, err);

	aiop_tile_set_isr_params(dpaiop->aiop_tile, invoke_inter, dpaiop, 0);

	for (i = 0; i < DPAIOP_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpaiop->irqs[i]), MC_IRQ_TYPE_MSI);

	dpaiop->resetable = 1;

	return 0;
}

struct dpaiop * dpaiop_allocate(void)
{
	struct dpaiop *dpaiop;

	dpaiop = (struct dpaiop *)fsl_xmalloc(sizeof(struct dpaiop), 0,
						CORE_CACHELINE_SIZE);
	if (dpaiop)
		memset(dpaiop, 0, sizeof(struct dpaiop));
	return dpaiop;
}

void dpaiop_deallocate(struct dpaiop *dpaiop)
{
	fsl_xfree(dpaiop);
}

void dpaiop_destroy(struct dpaiop *dpaiop)
{
	int err;
	int tmp;

	tmp = dpaiop->resetable;
	dpaiop->resetable = 0;
	dpaiop_reset(dpaiop);
	dpaiop->resetable = tmp;

	free_tile_runtime_resources(dpaiop);

	mpic_free_intr((uint32_t)dpaiop->desc.irq_rec_err);
	mpic_free_intr((uint32_t)dpaiop->desc.irq_cat_err);

	free_dpci(dpaiop);

	err = resman_unbind_all(dpaiop->device);
	CHECK_COND_RET(err == 0);
}

int dpaiop_reset(struct dpaiop *dpaiop)
{
	int err = 0;
	uint32_t idle_bits = 0, is_busy = 0, cores_mask = 0, status = 0;
	struct dppmu_desc dppmu_desc = {0};
	struct aiop_tile_cfg *cfg = &dpaiop->cfg;
	int tries = 0;
	uint32_t condition = 0;

	if( !dpaiop->resetable ) {
		pr_warn("dpaiop.%d reset disabled... skip reset command\n", dpaiop->id);
		return 0;
	}

	pr_debug("Commence AIOP HW reset ...\n");

	if (dpaiop->status == DPAIOP_STATE_RESET_ONGOING)
	{
		pr_err("Bad state (0x%08x)\n", dpaiop->status);
		return -EACCES;
	}

	/* Don't attempt to reset since there is no power management unit to
	  gracefully halt AIOP cores and request reset on the AIOP tile. */
	err = sys_get_desc(SOC_MODULE_DPPMU, SOC_DB_NO_MATCH_FIELDS, &dppmu_desc, NULL);
	if (err || dppmu_desc.disable)
	{
		pr_err("Cannot reset AIOP tile: DP-PMU module disabled or unavailable for current SoC.\n");
		return -ENOTSUP;
	}
	resources_deauthorization(dpaiop);

	dpaiop->status = DPAIOP_STATE_RESET_ONGOING;
	/* Soft reset STE state machines */
	if (dpaiop->desc.ste_support)
		aiop_tile_ste_reset(&dpaiop->desc, &(cfg->ste_cfg));

	/* 1. The management complex prepares the AIOP for reset by doing the following: */

	/* Pause the TMan's Wall Clock: write TMan's TMSC[STOP] bit and then
	   poll TMan's TMSS[BUSY] bit for entry into the 'non-busy' state */
	aiop_tile_tman_stop(&dpaiop->desc);
	tries = DPAIOP_RESET_WAIT_FOR_TMAN_TRIES;
	do
	{
		/* Reading TMSS[BUSY] = 0 does not imply that there are no active timers in the system.
		   TMan generated tasks are disabled in the next step. */
		aiop_tile_tman_is_busy(&dpaiop->desc, &is_busy);
		if (is_busy)
		{
			timer_udelay(DPAIOP_RESET_WAIT_FOR_TMAN_DELAY);
		}
	}
	while (is_busy && tries--);
	if (is_busy)
	{
		pr_err("AIOP reset timeout: fail to stop TMAN\n");
		return -ETIMEDOUT;
	}
	/* 2. MC software quieses the QMan channels associated with AIOP */
	/* Disable the creation of any new tasks into AIOP from any sources (QMan or TMan)
	 by disabling the Work scheduler. */
	aiop_tile_ws_enable(&dpaiop->desc, AIOP_WS_DISABLE);

	/* Disable all debug interrupt requests (UDE and DEVT) to the AIOP cores */
	aiop_tile_disable_dbg_intr_requests(&dpaiop->desc);

	/* 3. MC software polls WRKS's CIDLE[IDLE] for all bits being set, which
     indicates there are no more tasks to be completed and all cores are idle */
	if (dpaiop->desc.num_clusters == 1)
		cores_mask = 0xF;
	else if (dpaiop->desc.num_clusters == 4)
		cores_mask = 0x0000FFFF;
	else
		return -EINVAL;
	tries = DPAIOP_RESET_WAIT_FOR_WRKS_TRIES;
	do
	{
		/* Reset value before each attempt to retrieve the current idle cores as
		   some cores might non-idle on first tries */
		idle_bits = 0;
		aiop_ws_get_cores_idle(&dpaiop->desc, &idle_bits);
		condition = (idle_bits & cores_mask) ^ cores_mask;
		if (condition)
		{
			timer_udelay(DPAIOP_RESET_WAIT_FOR_WRKS_DELAY);
		}
	}
	while (condition && tries--);
	if (condition)
	{
		pr_err("AIOP reset timeout: fail to stop WRKS\n WRKS_CIDLE[IDLE]=%d", (idle_bits & cores_mask));
		return -ETIMEDOUT;
	}
	/* 4. Request a graceful halt of all cores of an empty AIOP using
	   DP-PMU's TPH10SETR0 and poll for completion. */
	cores_mask = dppmu_desc.ph10_aiop_core_mask;
	tries = DPAIOP_RESET_WAIT_FOR_TPH10_TRIES;
	dppmu_ph10_state_request(&dppmu_desc, cores_mask);
	do {
		/* Reset value before each attempt to retrieve the current idle cores as
		   some cores might non-idle on first tries */
		status = 0;
		dppmu_ph10_state_status(&dppmu_desc, &status);
		condition = (status & cores_mask) ^ cores_mask;
		if (condition)
		{
			timer_udelay(DPAIOP_RESET_WAIT_FOR_TPH10_DELAY);
		}
	}
	while (condition && tries--);
	if (condition)
	{
		pr_err("AIOP reset timeout: fail to put cores in TPH10 state\n TPH10SR0=%d", (status & cores_mask));
		return -ETIMEDOUT;
	}

	/* Request a graceful stop of an empty AIOP using DP-PMU's PCPH15SETR0
	   and poll for completion */
	cores_mask = dppmu_desc.ph15_aiop_core_mask;
	tries = DPAIOP_RESET_WAIT_FOR_PH15_TRIES;
	dppmu_ph15_state_request(&dppmu_desc, cores_mask);
	do {
		/* Reset value before each attempt to retrieve the current idle cores as
		   some cores might non-idle on first tries */
		status = 0;
		dppmu_ph15_state_status(&dppmu_desc, &status);
		condition = (status & cores_mask) ^ cores_mask;
		if (condition)
		{
			timer_udelay(DPAIOP_RESET_WAIT_FOR_PH15_DELAY);
		}
	}
	while (condition && tries--);
	if (condition)
	{
		pr_err("AIOP reset timeout: fail to put cores in PH15 state\n TPH10SR0=%d", (status & cores_mask));
		return -ETIMEDOUT;
	}

	/* Request a reset of the tile by writing to DP-PMU's RSTCR[REQ]
	   and poll for completion */
	tries = DPAIOP_RESET_WAIT_FOR_TILE_RESET_TRIES;
	dppmu_aiop_tile_reset_request(&dppmu_desc);
	do {
		/* Reset value before each attempt to retrieve the current idle cores as
		   some cores might non-idle on first tries */
		status = 0;
		dppmu_aiop_tile_reset_status(&dppmu_desc, &status);
		if (status)
		{
			timer_udelay(DPAIOP_RESET_WAIT_FOR_TILE_RESET_DELAY);
		}
	}
	while (status);
	if (status)
	{
		pr_err("AIOP reset timeout: fail to reset AIOP tile");
		return -ETIMEDOUT;
	}
	/* Free all allocated resources */
	free_tile_runtime_resources(dpaiop);

	aiop_tile_restore_ep_table(dpaiop->aiop_tile);
	aiop_tile_restore_sp_table(dpaiop->aiop_tile);

	dpaiop->status = DPAIOP_STATE_RESET_DONE;

	pr_debug("Complete AIOP HW reset\n");

	return 0;
}

int dpaiop_get_attributes(struct dpaiop *dpaiop, struct dpaiop_attr *attributes)
{
	attributes->id = dpaiop->id;

	return 0;
}

int dpaiop_set_dev_ctx(struct dpaiop *dpaiop,
		       const struct dpmng_dev_ctx *dev_ctx)
{
	if (memcmp(&dpaiop->amq, &(dev_ctx->amq), sizeof(struct dpmng_amq)) != 0) {
		CHECK_COND_RETVAL(!dpaiop->enabled, -EINVAL);
		resources_deauthorization(dpaiop);

		dpaiop->amq = dev_ctx->amq;
		dpaiop->amq.bdi =
			(dev_ctx->type == DPMNG_CTX_TYPE_AIOP) ? 1 : 0;

		resources_authorization(dpaiop);
	}

	return 0;
}

int dpaiop_set_irq(struct dpaiop *dpaiop,
	uint8_t irq_index,
	const struct mc_irq_cfg *irq_cfg)
{
	if (irq_index >= DPAIOP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPAIOP_MAX_IRQ_NUM);
		return -EINVAL;
	}

	mc_set_irq(&(dpaiop->irqs[irq_index]), irq_cfg);
	return 0;
}

int dpaiop_get_irq(struct dpaiop *dpaiop,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg)
{
	int err;

	if (irq_index >= DPAIOP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPAIOP_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq(&(dpaiop->irqs[irq_index]), irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);
				
	return 0;
}

int dpaiop_set_irq_enable(struct dpaiop *dpaiop, uint8_t irq_index, uint8_t en)
{
	int err;

	if (irq_index >= DPAIOP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPAIOP_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_set_irq_enable(&(dpaiop->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dpaiop_get_irq_enable(struct dpaiop *dpaiop, uint8_t irq_index, uint8_t *en)
{
	int err;

	if (irq_index >= DPAIOP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPAIOP_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_enable(&(dpaiop->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dpaiop_set_irq_mask(struct dpaiop *dpaiop, uint8_t irq_index, uint32_t mask)
{
	int err;

	if (irq_index >= DPAIOP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPAIOP_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_set_irq_mask(&(dpaiop->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpaiop_get_irq_mask(struct dpaiop *dpaiop, uint8_t irq_index, uint32_t *mask)
{
	int err;

	if (irq_index >= DPAIOP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPAIOP_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_mask(&(dpaiop->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dpaiop_get_irq_status(struct dpaiop *dpaiop, uint8_t irq_index, uint32_t *status)
{
	int err;

	if (irq_index >= DPAIOP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPAIOP_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_status(&(dpaiop->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dpaiop_clear_irq_status(struct dpaiop *dpaiop,
	uint8_t irq_index,
	uint32_t status)
{
	int err;

	if (irq_index >= DPAIOP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPAIOP_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_clear_irq_status(&(dpaiop->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}


int dpaiop_run(struct dpaiop *dpaiop, const struct dpaiop_run_cfg *run_cfg)
{
	uint64_t cores_mask;

	if (dpaiop->status != DPAIOP_STATE_LOAD_DONE)
	{
		pr_err("Bad state. AIOP can't be run without load or reset\n");
		return -EACCES;
	}

	dpaiop->status = DPAIOP_STATE_BOOT_ONGOING;

	if ((run_cfg->options & RUN_OPTIONS_MASK) != run_cfg->options)
	{
		dpaiop->status = DPAIOP_STATE_BOOT_ERROR;
		pr_err("Invalid run options\n");
		return -EINVAL;
	}

	if (run_cfg->args_size > AIOP_MAX_COMMAND_LINE_ARGS)
	{
		dpaiop->status = DPAIOP_STATE_BOOT_ERROR;
		pr_err("Invalid run options: aiop command line args size (%d) exceed max %d\n",
				run_cfg->args_size, AIOP_MAX_COMMAND_LINE_ARGS);
		return -EINVAL;
	}
	/* clear previous command line */
	if (dpaiop->args_buffer) {
		fsl_free(dpaiop->args_buffer);
	}
	dpaiop->args_buffer = NULL;
	dpaiop->args_size = 0;
	/* copy aiop start params */
	if (run_cfg->args_size > 0 && run_cfg->args_buffer) {
		dpaiop->args_size = run_cfg->args_size;
		dpaiop->args_buffer = fsl_malloc(run_cfg->args_size);
		memcpy(dpaiop->args_buffer, run_cfg->args_buffer, dpaiop->args_size);
	}

	dpaiop->options |= (run_cfg->options & ~RUN_INTERNAL_OPTIONS);

	/* set options and args in SW AIOP structure */
	/* set AIOP SW parameters */
	set_aiop_sl_params(dpaiop);

	cores_mask = check_available_clusters(dpaiop->desc.num_clusters, run_cfg->cores_mask);

	/* Releasing cores for boot */
	aiop_tile_release_cores_boot(&dpaiop->desc, cores_mask);

	pr_info("Running AIOP Boot....\n");

	return 0;
}

int dpaiop_load(struct dpaiop *dpaiop, struct dpaiop_load_cfg *load_cfg)
{

	uint8_t *img_addr = (uint8_t *)load_cfg->img_iova;
	uint32_t core_out_of_reset_addr = *(uint32_t *)(img_addr + 0x18);
	struct aiop_tile_cfg cfg;
	int err;
	struct aiop_init_info *aiop_boot_s = NULL;
	struct aiop_tile_desc aiop_tile_desc;
	void *trans_vaddr;
	struct dpmng_amq mc_amq;

	pr_debug("Commence loading AIOP application...\n");

	if (!(LIBELF_IS_ELF((uint8_t *)load_cfg->img_iova)))
	{
		pr_err("Elf not found\n");
		return -EINVAL;
	}

	if (dpaiop->status != DPAIOP_STATE_RESET_DONE)
	{
		pr_err("Bad state. AIOP must be preceded by reset\n");
		return -EACCES;
	}

	dpaiop->status = DPAIOP_STATE_LOAD_ONGIONG;

	dpmng_get_amq(&mc_amq);

	/*clear SRAM */
	trans_vaddr = dpmng_mc_set_soc_window(dpaiop->desc.sram_paddr, &mc_amq);

	memset(trans_vaddr, 0, dpaiop->desc.sram_size);

	if ((load_cfg->options & LOAD_OPTIONS_MASK) != load_cfg->options)
	{
		dpaiop->status = DPAIOP_STATE_LOAD_ERROR;
		pr_err("Invalid load options\n");
		return -EINVAL;
	}

	/* Get AIOP parameters Structure from image, also verify elf */
	/* load AIOP app structure from image (This happens first to make sure elf exists) */
	err = eld_get_aiop_struct(img_addr, (void**) &aiop_boot_s);
	if (err)
	{
		dpaiop->status = DPAIOP_STATE_LOAD_ERROR;
		return err;
	}

	/* Get container attributes and verify ownership */
	err = get_container_attributes(dpaiop->aiop_container_id, &dpaiop->aiop_attributes);
	if (err)
	{
		dpaiop->status = DPAIOP_STATE_LOAD_ERROR;
		return err;
	}

	/* Allocate and save memory dedicated for AIOP */
	err = allocate_aiop_rsrcs(dpaiop, aiop_boot_s);
	if (err)
	{
		dpaiop->status = DPAIOP_STATE_LOAD_ERROR;
		return err;
	}

	/* get aiop tile descriptor */
	memset(&aiop_tile_desc, 0, sizeof(struct aiop_tile_desc));
	aiop_tile_desc.tile_id = dpaiop->id;
	err = sys_get_desc(SOC_MODULE_AIOP, SOC_DB_AIOP_TILE_DESC_ID,
	                   &aiop_tile_desc, NULL);
	CHECK_COND_RETVAL(err == 0, err);

	/* get AIOP cfg parameters */
	memset(&cfg, 0, sizeof(struct aiop_tile_cfg));
	err = build_aiop_cfg(dpaiop, &aiop_boot_s->app_info,
							&dpaiop->aiop_attributes, load_cfg);
	if (err)
	{
		dpaiop->status = DPAIOP_STATE_LOAD_ERROR;
		return err;
	}

	/* re-initialize AIOP */
	err = runtime_init(dpaiop);
	if (err)
	{
		dpaiop->status = DPAIOP_STATE_LOAD_ERROR;
		return err;
	}

	err = load_image(dpaiop, img_addr, &dpaiop->boot_s_paddr);
	if (err)
	{
		dpaiop->status = DPAIOP_STATE_LOAD_ERROR;
		return err;
	}

	/* clear bits to be used only by MC */
	dpaiop->options = load_cfg->options & ~LOAD_INTERNAL_OPTIONS;;

	dpaiop->sl_version.major = (uint16_t)ioread32be(&aiop_boot_s->sl_info.aiop_rev_major);
	dpaiop->sl_version.minor = (uint16_t)ioread32be(&aiop_boot_s->sl_info.aiop_rev_minor);
	dpaiop->sl_version.revision = (uint16_t)ioread32be(&aiop_boot_s->sl_info.aiop_revision);

	dpaiop->status = DPAIOP_STATE_LOAD_DONE;
	pr_info("Loaded AIOP version %d.%d,%d\n", dpaiop->sl_version.major,
		dpaiop->sl_version.minor,
		dpaiop->sl_version.revision);

	/* Setting core's out-of-reset address (__sys_start) in RBASE */
	aiop_tile_write_rbase(&dpaiop->desc, core_out_of_reset_addr);

	aiop_tile_enable(&dpaiop->desc);

	pr_debug("Complete loading AIOP application\n");

	return 0;
}

int dpaiop_get_sl_version(struct dpaiop *dpaiop, struct dpaiop_sl_version *version)
{
	*version = dpaiop->sl_version;

	return 0;
}

int dpaiop_get_state(struct dpaiop *dpaiop, uint32_t *state)
{
	uint32_t val, boot_fail_val;

	/* if last status was set for AIOP boot, check that boot had completed */
	if (dpaiop->status == DPAIOP_STATE_BOOT_ONGOING)
	{
		val = aiop_tile_get_cores_boot_status(&dpaiop->desc);
		if (val & 0x1)
		{
			/* boot completed, check for errors */
			boot_fail_val = aiop_tile_get_core_gpr(&dpaiop->desc, 0);
			if (boot_fail_val == 0)
				dpaiop->status = DPAIOP_STATE_RUNNING;
			else
			{
				pr_err("AIOP boot failed\n");
				dpaiop->status = DPAIOP_STATE_BOOT_ERROR;
			}
		}
	}

	*state = dpaiop->status;

	return 0;
}

int dpaiop_set_time_of_day(struct dpaiop *dpaiop,
                           uint64_t time_of_day)
{
    uint64_t timestamp;

    /* Reading TMan's current timestamp (in usecs) */
    aiop_tile_tman_get_timestamp(&dpaiop->desc, &timestamp);

    /* Calculating base-time-of-day */
    dpaiop->base_time_of_day = (time_of_day - (timestamp / 1000));

    /* Write base-time-of-day to AIOP's MGPR1 (high) and MGPR0 (low) */
    /* To avoid AIOP reading the registers while MC updates them, MGPR1 is set to all F's
       to mark that these registers are currently being updated */
    aiop_tile_set_mng_gpr(&dpaiop->desc, 1, 0xFFFFFFFF);
    aiop_tile_set_mng_gpr(&dpaiop->desc, 0, (uint32_t)(dpaiop->base_time_of_day));
    aiop_tile_set_mng_gpr(&dpaiop->desc, 1, (uint32_t)(dpaiop->base_time_of_day >> 32));

    return 0;
}

int dpaiop_get_time_of_day(struct dpaiop *dpaiop,
                           uint64_t *time_of_day)
{
    uint64_t timestamp;

    /* Reading TMan's current timestamp (in usecs) */
    aiop_tile_tman_get_timestamp(&dpaiop->desc, &timestamp);

    *time_of_day = (dpaiop->base_time_of_day + (timestamp / 1000));

    return 0;
}


int dpaiop_set_resetable(struct dpaiop *dpaiop, int resetable)
{
	dpaiop->resetable = resetable;
	return 0;
}

int dpaiop_get_resetable(struct dpaiop *dpaiop, int *resetable)
{
	*resetable = dpaiop->resetable;
	return 0;
}
