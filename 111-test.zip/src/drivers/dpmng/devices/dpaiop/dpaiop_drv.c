/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpaiop_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_cmdif.h"
#include "fsl_cmdif_mc.h"
#include "fsl_resman.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "kernel/device.h"
#include "dplib/fsl_dpaiop_cmd.h"
#include "dtc/dtc.h"
#include "fsl_sys.h"
#include "fsl_platform.h"
#include "fsl_aiop_common.h"
#include "fsl_dpaiop_mc.h"
#include "dpaiop_cmd.h"
#include "legacy_dpaiop_dplib.h"
#include "dpaiop.h"

/* DPAIOP last supported API version */
#define DPAIOP_V0_API_VER_MAJOR				1
#define DPAIOP_V0_API_VER_MINOR				3

/* Contains load parameters as they are passed by GPP in MCP */
struct dpaiop_load_gpp_cfg {
	uint64_t options;
	uint64_t img_iova;
	uint32_t img_size;
	uint8_t tpc; // available from mc 10.1.0, used on load_v1
};

int dpaiop_drv_init(void);
static int load_cmd(struct device*, struct mc_cmd_data*,
					struct dpaiop_load_gpp_cfg*);

/*                cmd, param, offset, width, type, arg_name */
#define DPAIOP_LO_CREATE(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  32, int,     cfg->aiop_id);\
	MC_RSP_OP(cmd, 0, 32, 32, int, 	    cfg->aiop_container_id);\
} while (0)

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpaiop *dpaiop;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	return dpaiop_set_dev_ctx(dpaiop, dev_ctx);
}

static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpaiop_cfg dpaiop_cfg = { 0 };
	struct dpaiop_cfg *cfg = &dpaiop_cfg;
	int err;

#ifndef ENGR357301
	/* Init may only be called once when AIOP reset is supported.
	 If re-called, returns without effect. */
	dpaiop = sys_get_handle(FSL_MOD_DPAIOP, 1, 0);
	if (dpaiop)
		return 0;
#endif
	dpaiop = device_get_priv(dev);

	DPAIOP_CMD_CREATE(cmd_data, cfg);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpaiop) {
		/* NULL */
		dpaiop = dpaiop_allocate();
		if (!dpaiop) {
			pr_err("No memory for dpaiop\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpaiop_init(dpaiop, cfg, &dev_cfg);
		if (err) {
			return err;
		}
		device_set_priv(dev, dpaiop);
		sys_add_handle(dpaiop, FSL_MOD_DPAIOP, 1, dev_cfg.id);

		assign(dev, &(dev_cfg.ctx));
	} else
		return -EINVAL;

	return 0;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop = NULL;

	UNUSED(cmd_data);

#ifndef ENGR357301
	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	dpaiop_destroy(dpaiop);

	sys_remove_handle(FSL_MOD_DPAIOP, 1, device_get_id(dev));
	dpaiop_deallocate(dpaiop);
#else
	UNUSED(dpaiop);
#endif
	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
#ifndef ENGR357301
	struct dpaiop *dpaiop;
	struct dpmng_dev_ctx dev_ctx;
	int err;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	err = dpaiop_reset(dpaiop);
	if (!err) {
		resman_get_dev_ctx(dev, &dev_ctx, 1);
		device_set_enable(dev, 0);
		err = assign(dev, &dev_ctx);
	}
	return err;
#endif

	UNUSED(cmd_data);
	return  -ENOTSUP;
}

static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	struct dpaiop_attr attr = { 0 };
	int err;

	dpaiop = device_get_priv(dev);
	CHECK_COND_RETVAL(dpaiop, -ENODEV);

	err = dpaiop_get_attributes(dpaiop, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.version.major = DPAIOP_V0_API_VER_MAJOR;
	attr.version.minor = DPAIOP_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPAIOP_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	struct dpaiop_attr attr = { 0 };
	int err;

	dpaiop = device_get_priv(dev);
	CHECK_COND_RETVAL(dpaiop, -ENODEV);

	err = dpaiop_get_attributes(dpaiop, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPAIOP_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	DPAIOP_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dpaiop_set_irq(dpaiop, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpaiop *dpaiop;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	return dpaiop_set_irq(dpaiop, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	/* Read parameters from portal */
	DPAIOP_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpaiop_get_irq(dpaiop, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPAIOP_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpaiop *dpaiop;
	int err;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	err = dpaiop_get_irq(dpaiop, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;

	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	uint8_t irq_index;
	uint8_t enable_state;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	/* Read parameters from portal */
	DPAIOP_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, enable_state);

	return dpaiop_set_irq_enable(dpaiop, irq_index, enable_state);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
#ifdef FUTURE_SUPPORT
	struct dpaiop *dpaiop;
	uint8_t irq_index;
	uint8_t enable_state;
	int err;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	/* Read parameters from portal */
	DPAIOP_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpaiop_get_irq_enable(dpaiop, irq_index, &enable_state);

	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPAIOP_RSP_GET_IRQ_ENABLE(cmd_data, enable_state);

	return 0;
#endif /* FUTURE_SUPPORT */

	return -ENOTSUP;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	uint8_t irq_index;
	uint32_t mask;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	/* Read parameters from portal */
	DPAIOP_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpaiop_set_irq_mask(dpaiop, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
#ifdef FUTURE_SUPPORT
	struct dpaiop *dpaiop;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;
	/* Read parameters from portal */
	DPAIOP_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpaiop_get_irq_mask(dpaiop, irq_index, &mask);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPAIOP_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
#endif /* FUTURE_SUPPORT */

	return -ENOTSUP;

}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
#ifdef FUTURE_SUPPORT
	struct dpaiop *dpaiop;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	/* Read parameters from portal */
	DPAIOP_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpaiop_get_irq_status(dpaiop, irq_index, &status);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPAIOP_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
#endif /* FUTURE_SUPPORT */

	return -ENOTSUP;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	uint8_t irq_index;
	uint32_t status;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	/* Read parameters from portal */
	DPAIOP_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpaiop_clear_irq_status(dpaiop, irq_index, status);
}

struct dpaiop_run_gpp_cfg{
	uint64_t cores_mask;
	uint64_t options;
	uint64_t args_iova;
	uint32_t args_size;
};

static int run(struct device *dev, struct mc_cmd_data *cmd_data)
{
	int err;
	struct dpaiop *dpaiop;
	struct dpaiop_run_gpp_cfg gpp_run_cfg = { 0 };
	struct dpaiop_run_gpp_cfg *cfg = &gpp_run_cfg;
	struct dpaiop_run_cfg run_cfg = { 0 };

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	/* Read parameters from portal */
	DPAIOP_CMD_RUN(cmd_data, cfg);

	pr_debug("AIOP run arguments:\n core_mask=0x%x%x\n options=0x%x%x\n args_size=%d\n address=0x%x%x\n",
			UINT32_HI(cfg->cores_mask), UINT32_LO(cfg->cores_mask),
			UINT32_HI(cfg->options), UINT32_LO(cfg->options),
			cfg->args_size,
			UINT32_HI(cfg->args_iova), UINT32_LO(cfg->args_iova));
	run_cfg.cores_mask = cfg->cores_mask;
	run_cfg.options = cfg->options;
	if (cfg->args_size)	{
		run_cfg.args_size = cfg->args_size;
		run_cfg.args_buffer = fsl_malloc(run_cfg.args_size);
		err = dpmng_dev_memcpy(dev, run_cfg.args_buffer, cfg->args_iova,
				run_cfg.args_size, 1);
		if (err) {
			if (run_cfg.args_buffer)
				fsl_free(run_cfg.args_buffer);
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}
	err = dpaiop_run(dpaiop, &run_cfg);

	if (run_cfg.args_buffer)
		fsl_free(run_cfg.args_buffer);

	return err;
}
#if 0

static int reset_aiop(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct aiop_tile *aiop_tile;
	int container_id;
	int aiop_tile_id;
	int portal_id;
	void *resman;

	DPMNG_CMD_RESET_AIOP(cmd_data, container_id, aiop_tile_id);

	/* check that the container_id matches the portal_id the command was received on */
	portal_id = (int)u64_dec(swap_uint64(cmd_data->params[3]), 32, 32);
	resman = (struct resman *)sys_get_unique_handle(FSL_MOD_RESMAN);
	if (resman == NULL)
		return -ENODEV;

	if (resman_is_parent_portal(resman, portal_id, container_id) == 0)
		return EPERM;
	aiop_tile = sys_get_handle(FSL_MOD_AIOP_TILE, 1, dev->id);
	if (!aiop_tile){
		pr_err("No handle for AIOP tile\n");
		return -ENODEV;
	}
	return aiop_drv_tile_reset(aiop_tile, container_id);
}
#endif

static int load_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop_load_gpp_cfg gpp_load_cfg = { 0 };

	DPAIOP_CMD_LOAD_V0(cmd_data, &gpp_load_cfg);
	return load_cmd(dev, cmd_data, &gpp_load_cfg);
}

static int load_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop_load_gpp_cfg gpp_load_cfg = { 0 };

	DPAIOP_CMD_LOAD(cmd_data, &gpp_load_cfg);

	if ((gpp_load_cfg.tpc > AIOP_TILE_NTASKS_MAX)
			|| (!is_power_of_2(gpp_load_cfg.tpc))) {
		pr_warn("Invalid task per core value: %d. It must be a power of 2"
				" and less than %d. Use TPC value provided by AIOP image.",
				gpp_load_cfg.tpc, AIOP_TILE_NTASKS_MAX);
		gpp_load_cfg.tpc = USE_AIOP_IMAGE_TPC;
	}
	return load_cmd(dev, cmd_data, &gpp_load_cfg);
}

static int set_resetable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	int resetable;
	struct dpaiop *dpaiop;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	DPAIOP_CMD_SET_RESETABLE(cmd_data, resetable);

	return dpaiop_set_resetable(dpaiop, resetable);
}

static int get_resetable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	int resetable;
	struct dpaiop *dpaiop;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	dpaiop_get_resetable(dpaiop, &resetable);
	DPAIOP_RSP_GET_RESETABLE(cmd_data, resetable);

	return 0;
}

static int load_cmd(struct device* dev, struct mc_cmd_data* cmd_data,
					struct dpaiop_load_gpp_cfg* cfg)
{
	struct dpaiop *dpaiop;
	struct dpaiop_load_cfg load_cfg = { 0 };
	int err;
	
	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	load_cfg.options = cfg->options;
	load_cfg.img_size = cfg->img_size;
	load_cfg.img_iova = DPAIOP_ELF_LOAD_ADDRESS_LPVOID;
	load_cfg.tpc = cfg->tpc;
	/* Skip copying the elf if the provided address is the same
	  with the MC elf load address (0x0700_0000) */
	pr_info("Start loading AIOP image from I/O virtual address 0x%x%x ... \n",
			UINT32_HI(cfg->img_iova), UINT32_LO(cfg->img_iova));
	if (dpmng_is_same_local_mc_address(dev, cfg->img_iova,
										DPAIOP_ELF_LOAD_ADDRESS) == 0)
	{
		/* before copy the entire image check if at cfg->img_iova is
		a real ELF file: check if the first 3 chars are 'ELF'.*/
		err = dpmng_dev_memcpy(dev, load_cfg.img_iova, cfg->img_iova, 4, 1);
		if (err)
		{
			pr_err("Error reading extended DMA parameters or copy AIOP image.");
			return err;
		}
		if ( !(LIBELF_IS_ELF((uint8_t *)load_cfg.img_iova)) )
		{
			pr_err("Not a valid ELF file.\n");
			return -EINVAL;
		}
		err = dpmng_dev_memcpy(dev, load_cfg.img_iova, cfg->img_iova,
				load_cfg.img_size, 1);
		if (err)
		{
			pr_err("Error reading extended DMA parameters or copy AIOP image.");
			return err;
		}
	}
	return dpaiop_load(dpaiop, &load_cfg);
}

static int get_sl_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	struct dpaiop_sl_version ver = { 0 };
	struct dpaiop_sl_version *version = &ver;
	int err;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	err = dpaiop_get_sl_version(dpaiop, version);
	if (err)
		return err;

	DPAIOP_RSP_GET_SL_VERSION(cmd_data, version);

	return 0;
}

static int get_state(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	uint32_t state;
	int err;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	err = dpaiop_get_state(dpaiop, &state);
	if (err)
		return err;

	DPAIOP_RSP_GET_STATE(cmd_data, state);

	return 0;
}

static int set_time_of_day(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	uint64_t time_of_day;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	DPAIOP_CMD_SET_TIME_OF_DAY(cmd_data, time_of_day);

	return dpaiop_set_time_of_day(dpaiop, time_of_day);
}

static int get_time_of_day(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpaiop *dpaiop;
	uint64_t time_of_day;
	int err;

	dpaiop = device_get_priv(dev);
	if (!dpaiop)
		return -ENODEV;

	err = dpaiop_get_time_of_day(dpaiop, &time_of_day);
	if (err)
		return err;

	DPAIOP_RSP_GET_TIME_OF_DAY(cmd_data, time_of_day);

	return 0;
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPAIOP_VER_MAJOR;
    uint32_t minor = DPAIOP_VER_MINOR;

    DPAIOP_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int dpaiop_drv_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpaiop_open on DPAIOP %d\n", device_get_id(dev));
	return 0;
}

static int dpaiop_drv_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpaiop_close on DPAIOP %d\n", device_get_id(dev));
	return 0;
}

static int dpaiop_drv_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev,
			struct mc_cmd_data *cmd_data);
		char *cmd_str;
		uint8_t ver;
		/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPAIOP_CMD_CODE_CREATE, init, "dpaiop_init", DPAIOP_CMD_VER_BASE},
			{ DPAIOP_CMD_CODE_DESTROY, destroy, "dpaiop_destroy", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_RESET, reset, "dpaiop_reset", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_GET_ATTR, get_attributes_v0, "dpaiop_get_attributes", DPAIOP_CMD_V0 },
			{ DPAIOP_CMD_CODE_SET_IRQ, set_irq, "dpaiop_set_irq", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_GET_IRQ, get_irq, "dpaiop_get_irq", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpaiop_set_irq_enable", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpaiop_get_irq_enable", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpaiop_set_irq_mask", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpaiop_get_irq_mask", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpaiop_get_irq_status", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpaiop_clear_irq_status", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_RUN, run, "dpaiop_run", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_LOAD, load_v0, "dpaiop_load", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_GET_SL_VERSION, get_sl_version, "dpaiop_get_sl_version", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_GET_STATE, get_state, "dpaiop_get_state", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_SET_TIME_OF_DAY, set_time_of_day, "dpaiop_set_time_of_day", DPAIOP_CMD_VER_BASE },
			{ DPAIOP_CMD_CODE_GET_TIME_OF_DAY, get_time_of_day, "dpaiop_get_time_of_day", DPAIOP_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPAIOP_CMD_CODE_GET_API_VERSION, get_api_version, "dpaiop_get_api_version", DPAIOP_CMD_V1},
			{ DPAIOP_CMD_CODE_GET_ATTR, get_attributes_v1, "dpaiop_get_attributes", DPAIOP_CMD_V1 },
			{ DPAIOP_CMD_CODE_LOAD, load_v1, "dpaiop_load", DPAIOP_CMD_V2 },
			{ DPAIOP_CMD_CODE_SET_RESETABLE, set_resetable, "dpaiop_set_resetable", DPAIOP_CMD_V1 },
			{ DPAIOP_CMD_CODE_GET_RESETABLE, get_resetable, "dpaiop_get_resetable", DPAIOP_CMD_V1 }
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) && 
                      ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
			if (cmd == DPAIOP_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPAIOP %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev,
							cmd_data);
		}

	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}

static int dpaiop_drv_probe_cb(void *lo, int node_off)
{
	int err = 0;
	struct dpaiop_cfg dpaiop_cfg = { 0 };
	struct dpaiop_cfg *cfg = &dpaiop_cfg;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	int id;
	uint64_t val;
	int destroy = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(resman, "dpaiop", (uint16_t)id, NO_PORTAL_ID,
							DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPAIOP %.4x\n", id);
	getprop_val(lo, node_off, "aiop_container_id", 0, 0, &val);
	dpaiop_cfg.aiop_container_id = (int)val;
	dpaiop_cfg.aiop_id = id;

	DPAIOP_LO_CREATE(cmd_data, cfg);

	/* create object */
	err = dpaiop_drv_ctrl_cb(dev, DPAIOP_CMD_VER_BASE, DPAIOP_CMD_CODE_CREATE,
			NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpaiop", NO_PORTAL_ID, destroy);

	return err;
}

static int dpaiop_drv_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}

	dev = resman_open_dev(resman, "dpaiop", (uint16_t)id, NO_PORTAL_ID, 0, NULL);
	if (!dev) {
		pr_err("Can't open DPAIOP 0x%.4x\n", id);
		return -ENODEV;
	}

        err |= dpaiop_drv_ctrl_cb(dev, DPAIOP_CMD_VER_BASE, DPAIOP_CMD_CODE_DESTROY,
                                    NO_PORTAL_ID, NULL);
	err |= resman_close_dev(resman, dev, "dpaiop", NO_PORTAL_ID, 0);

	return err;
}

static char *dpaiop_drv_match[] = { "fsl,dpaiop", "dpaiop" };

int dpaiop_drv_init(void)
{
	t_sys_dtc_mod_params lo_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	struct resman_res_req req;
	struct aiop_tile_desc aiop_tile_desc;
	struct aiop_ep_entry_cfg ep_entry;
	int err, i, iter = 0;
	struct aiop_tile *aiop_tile = NULL;

	pr_info("Executing dpaiop_drv_init...\n");
	
	lo_params.num_compats = ARRAY_SIZE(dpaiop_drv_match);
	lo_params.compatibles = dpaiop_drv_match;
	lo_params.f_prob_module = dpaiop_drv_probe_cb;
	lo_params.f_remove_module = dpaiop_drv_remove_cb;
	sys_dtc_register_module(&lo_params);

	cmdif_ops.open_cb = dpaiop_drv_open_cb;
	cmdif_ops.close_cb = dpaiop_drv_close_cb;
	cmdif_ops.ctrl_cb = dpaiop_drv_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPAIOP, &cmdif_ops);

	strcpy(dev_type_param.device_type, "dpaiop");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPAIOP_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPAIOP_VER_MAJOR;
	dev_type_param.ver_minor = DPAIOP_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	resman_register_device_operation(resman, "dpaiop", &dev_type_param);

	memset (&aiop_tile_desc, 0, sizeof(aiop_tile_desc));
	
	while (sys_get_desc(SOC_MODULE_AIOP, 0, &aiop_tile_desc, &iter) == 0) {

		pr_info("AIOP %d CCSR: 0x%08x%08x\n",iter - 1, UINT32_HI(aiop_tile_desc.paddr), UINT32_LO(aiop_tile_desc.paddr));
		
		/* Initialize basic AIOP tile handle */
		err = aiop_tile_early_init(&aiop_tile_desc);
		if (err)
			return err;

		/* create ep and sp pools */
		memset(&req, 0, sizeof(struct resman_res_req));
		snprintf(req.type, sizeof(req.type), "ep.aiop%d",
				aiop_tile_desc.tile_id);
		req.id_base_align = AIOP_EPID_DPNI_START;
		req.num = aiop_tile_desc.num_ep - req.id_base_align;
		req.options |= DPRC_RES_REQ_OPT_EXPLICIT;
		err = resman_create_res_pool(resman, &req);
		if (err)
			return err;

		/* set default value of -1 to all DPNI EPIDs */
		ep_entry.pc = 0;
		ep_entry.parameter = (uint32_t)-1;
		aiop_tile = sys_get_handle(FSL_MOD_AIOP_TILE,
				               1,
				               aiop_tile_desc.tile_id);
		CHECK_COND_RETVAL(aiop_tile, -ENODEV);

		for (i = req.id_base_align; i < aiop_tile_desc.num_ep; i++)
		{
			err = aiop_tile_ws_set_ep_entry(
				aiop_tile,
				(uint32_t)i,
				&ep_entry);
			if (err)
				return err;
		}

		memset(&req, 0, sizeof(struct resman_res_req));
		snprintf(req.type, sizeof(req.type), "sp.aiop%d",
				aiop_tile_desc.tile_id);
		req.id_base_align = AIOP_SPID_DPNI_START;
		req.num = aiop_tile_desc.num_sp - req.id_base_align;
		req.options |= DPRC_RES_REQ_OPT_EXPLICIT;
		err = resman_create_res_pool(resman, &req);
		if (err)
			return err;
		
		memset (&aiop_tile_desc, 0, sizeof(aiop_tile_desc));
	}

	return 0;
}
