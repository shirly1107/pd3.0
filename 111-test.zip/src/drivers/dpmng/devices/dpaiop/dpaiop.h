/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpaiop.h

 @Description   DPAIOP internal structures and definitions.
*//***************************************************************************/
#ifndef __DPAIOP_H
#define __DPAIOP_H

#include "kernel/fsl_spinlock.h"
#include "fsl_dpaiop_mc.h"
#include "fsl_event_pipe.h"
#include "fsl_resman.h"
#include "drivers/fsl_aiop.h"
#include "fsl_aiop_common.h"
#include "fsl_cmdif_client.h"


#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPAIOP

#define AIOP_CCSR_VADDR		0x10000000
#define AIOP_MC_PORTALS_VADDR	0x0c000000
#define AIOP_SYS_DDR_VADDR	(2 * GIGABYTE)
#define AIOP_SYS_DDR_ATU_SIZE	(2 * GIGABYTE)
#define AIOP_MAX_ATU_OWS	(2 * GIGABYTE)
#define AIOP_MIN_ATU_OWS	(64 * KILOBYTE)
#define AIOP_DEFAULT_DPDDR_VADDR	(1 * GIGABYTE)

/* the following ATU windows are always available: MC portals, CCSR and PEB*/
#define AIOP_ATU_STATIC_WIN_NO 3

#ifdef LS1088A_OBSOLETE_SYS_DDR_VADDR
struct aiopsl_version {
	uint32_t major;
	uint32_t minor;
	uint32_t rev;
};
#define AIOPSL_SUPPORTS_OBSOLETE_SYS_DDR_VADDR(ver) \
((aiopsl_ver.major <= 7) && (aiopsl_ver.minor < 3))
#endif

#define LOAD_OPTIONS_MASK 		0xffffffff00000000
#define RUN_OPTIONS_MASK 		0x00000000ffffffff
/* clear these bits before passing to AIOP SW */
#define RUN_INTERNAL_OPTIONS 		0x0000000000000000
#define LOAD_INTERNAL_OPTIONS 		0x8000000000000000

#define DPAIOP_LOAD_OPT_ERRATA_VA_ENABLED 	0x8000000000000000

#define AIOP_TILE_NTASKS_MAX            16

/* During AIOP image load use task per core value provided by application */
#define USE_AIOP_IMAGE_TPC	0

#define MAX_NUM_OF_MEM_MAP_ENTRIES	8

#define TMAN_MEM_SIZE               (3.5*MEGABYTE)

#define EVM_EVENT_SEND         2
#define EVM_CMDSZ_EVENT_SEND   64
#define EVM_NUM_OF_BUFFERS	   16



#define MC_PORTALS_ATU 		0
#define CCSR_ATU		1
#define PEB_ATU			2
#define DPDDR_ATU		3
#define SYS_DDR_ATU		4

struct mem_rgn_atu_window_cfg {
	uint32_t virt_base_addr;
	uint32_t ows_alignment; /* the alignment of phy_base_addr */
	phys_addr_t phy_base_addr;
	/* the size viewed by AIOP cores; it can be less than actual
	allocated size from physical memory */
	uint32_t virt_size; /* max virtual size for this memory type */
	uint32_t virt_mapped_size; /* actual virtual size */
	uint64_t phy_size; /* actual memory allocated size */
	uint8_t max_atu_wins; /* max ATU windows to be used by this config. */
	uint8_t no_atu_wins; /* number of configured atu windows */
};

struct mem_paddrs {
	phys_addr_t sys_ddr;
	phys_addr_t dp_ddr;
	phys_addr_t peb;
};

struct vrt2phy_mem_rgn_entry {
	phys_addr_t phy_base_addr; /**< Physical base address of AIOP memory region */
    dma_addr_t vrt_base_addr; /**< Virtual base address of AIOP memory region */
    uint64_t mem_size;        /**< size (in bytes) of AIOP memory region */
};


struct aiop_tile_cfg {
	uint8_t tasks_per_core; /* Number of in-flight per-core tasks;
	 Supported values are 1, 2, 4, 8 or 16; */
	struct aiop_fdma_cfg fdma_cfg; /* FDMA initialization parameters */
	struct aiop_cdma_cfg cdma_cfg; /* CDMA initialization parameters */
	struct aiop_tman_cfg   tman_cfg;     /* Timer manager initialization parameters */
	struct aiop_ste_cfg ste_cfg; /* Statistics engine initialization parameters */
	struct aiop_tile_defcfg defcfg; /* Additional parameters -
	 should be cleared for defaults, or set required values. */
	uint8_t	num_atu_win;
	struct aiop_atu_win_cfg atu_cfg[AIOP_ATU_NUM_OF_WINDOWS];

	/* required to compute ATU windows for PEB, DP-DDR and system DDR */
	struct mem_rgn_atu_window_cfg peb_atu_cfg;
	struct mem_rgn_atu_window_cfg dpddr_atu_cfg;
	struct mem_rgn_atu_window_cfg sysddr_atu_cfg;

	uint32_t ctlu_peb_num_entries;
	uint32_t ctlu_dp_ddr_num_entries;
	uint32_t ctlu_sys_ddr_num_entries;
	uint32_t mflu_peb_num_entries;
	uint32_t mflu_dp_ddr_num_entries;
	uint32_t mflu_sys_ddr_num_entries;

};

struct dpaiop {
	/* Object */
	int id;
	struct dpmng *dpmng;
	struct device *device;

	int enabled;
	int authorized;
	struct mc_irq irqs[DPAIOP_MAX_IRQ_NUM];

	int aiop_id;
	int aiop_container_id;
	struct dpmng_amq amq;
	struct resman_container_attributes aiop_attributes;
	uint64_t options;
	uint32_t args_size;
	void *args_buffer;
	struct aiop_tile_desc desc;
	void *dpci;
	uint32_t status;
	struct aiop_tile_regs *regs;
	struct vrt2phy_mem_rgn_entry mem_map[MAX_NUM_OF_MEM_MAP_ENTRIES];
	struct aiop_tile_cfg cfg;

	phys_addr_t boot_s_paddr;

	int base_spid;
	uint32_t spid_count;

	struct dpaiop_sl_version sl_version;
	
	uint64_t base_time_of_day;

	/* save for freeing */
	struct mem_paddrs mem_paddrs;
	struct mem_paddrs ctlu_paddrs;
	struct mem_paddrs mflu_paddrs;

	phys_addr_t sru_base;
	phys_addr_t tman_ctrl_mem;
	/* CMDIF */
	void *command_buffer;
	struct cmdif_desc cidesc;
	int buf_num_send;
	
	struct aiop_tile *aiop_tile;
	/* Parse profile ID */
	int32_t		ingress_pp_id;
	int32_t		egress_pp_id;
	/* Parse start HXS */
	uint16_t	ingress_start_hxs;
	uint16_t	egress_start_hxs;

	int resetable;
};

#endif /* __DPAIOP_H */
