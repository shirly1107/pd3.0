/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpaiop_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_cmdif.h"
#include "fsl_cmdif_mc.h"
#include "fsl_resman.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "kernel/device.h"
#include "dplib/fsl_dpaiop_cmd.h"
#include "dtc/dtc.h"
#include "fsl_sys.h"
#include "fsl_platform.h"
#include "fsl_aiop_common.h"
#include "fsl_dpaiop_mc.h"

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	UNUSED(dev);
	UNUSED(dev_ctx);

	pr_err("DPAIOP is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int destroy_by_resman(struct device *dev)
{
	return 0;
}

static int reset_by_resman(struct device *dev)
{
	return 0;
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	UNUSED(dev);
	UNUSED(irq_cfg);
	UNUSED(irq_index);

	pr_err("DPAIOP is not supported in this SOC!\n");
	return -ENOTSUP;
}


static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	UNUSED(dev);
	UNUSED(irq_cfg);
	UNUSED(irq_index);

	pr_err("DPAIOP is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpaiop_drv_open_cb(void *dev, int portal_id)
{
	UNUSED(dev);
	UNUSED(portal_id);
	
	pr_err("DPAIOP is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpaiop_drv_close_cb(void *dev, int portal_id)
{
	UNUSED(dev);
	UNUSED(portal_id);
	
	pr_err("DPAIOP is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpaiop_drv_ctrl_cb(void *dev, uint16_t cmd, int portal_id, uint8_t *data)
{
	UNUSED(dev);
	UNUSED(portal_id);
	UNUSED(cmd);
	UNUSED(data);
	
	pr_err("DPAIOP is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpaiop_drv_probe_cb(void *lo, int node_off)
{
	UNUSED(lo);
	UNUSED(node_off);

	pr_warn("DPAIOP defined in DPL - Not supported in this SOC!\n");
	return 0;
}

static int dpaiop_drv_remove_cb(void *lo, int node_off)
{
	UNUSED(lo);
	UNUSED(node_off);
	
	return 0;
}

static char *dpaiop_drv_match[] = { "fsl,dpaiop", "dpaiop" };

int dpaiop_drv_init(void)
{
	t_sys_dtc_mod_params lo_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	struct resman_res_req req;
	struct aiop_tile_desc aiop_tile_desc;
	struct aiop_ep_entry_cfg ep_entry;
	int err, i, iter = 0;

	lo_params.num_compats = ARRAY_SIZE(dpaiop_drv_match);
	lo_params.compatibles = dpaiop_drv_match;
	lo_params.f_prob_module = dpaiop_drv_probe_cb;
	lo_params.f_remove_module = dpaiop_drv_remove_cb;
	sys_dtc_register_module(&lo_params);

	cmdif_ops.open_cb = dpaiop_drv_open_cb;
	cmdif_ops.close_cb = dpaiop_drv_close_cb;
	cmdif_ops.ctrl_cb = dpaiop_drv_ctrl_cb;
	cmdif_register_module(CMDIF_MOD_DPAIOP, &cmdif_ops);

	strcpy(dev_type_param.device_type, "dpaiop");
	dev_type_param.irq_count = DPAIOP_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPAIOP_VER_MAJOR;
	dev_type_param.ver_minor = DPAIOP_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	ASSERT_COND(resman);

	resman_register_device_operation(resman, "dpaiop", &dev_type_param);

	memset (&aiop_tile_desc, 0, sizeof(aiop_tile_desc));
	while (sys_get_desc(SOC_MODULE_AIOP, 0, &aiop_tile_desc, &iter) == 0) {
		/* create ep and sp pools */
		memset(&req, 0, sizeof(struct resman_res_req));
		snprintf(req.type, sizeof(req.type), "ep.aiop%d",
				aiop_tile_desc.tile_id);
		req.id_base_align = AIOP_EPID_DPNI_START;
		req.num = aiop_tile_desc.num_ep - req.id_base_align;
		req.options |= DPRC_RES_REQ_OPT_EXPLICIT;
		err = resman_create_res_pool(
			sys_get_unique_handle(FSL_MOD_RESMAN), &req);
		if (err)
			return err;

		/* set default value of -1 to all DPNI EPIDs */
		ep_entry.pc = 0;
		ep_entry.parameter = (uint32_t)-1;
		for (i = req.id_base_align; i < req.num; i++)
			aiop_tile_write_ep(&aiop_tile_desc, (uint32_t)i, &ep_entry);

		memset(&req, 0, sizeof(struct resman_res_req));
		snprintf(req.type, sizeof(req.type), "sp.aiop%d",
				aiop_tile_desc.tile_id);
		req.id_base_align = 0;
		req.num = aiop_tile_desc.num_sp;
		req.options |= DPRC_RES_REQ_OPT_EXPLICIT;
		err = resman_create_res_pool(
			sys_get_unique_handle(FSL_MOD_RESMAN), &req);
		if (err)
			return err;
		memset (&aiop_tile_desc, 0, sizeof(aiop_tile_desc));
	}

	return 0;
}
