/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpcon.h

 @Description   DPCON internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPCON_H
#define __DPCON_H

#include "kernel/fsl_spinlock.h"
#include "fsl_event_pipe.h"
#include "fsl_dpcon_mc.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPCON
// Number of resources required by DPCON
#define DPCON_REQ_RES_NUM 1
#define DPCON_REQ_RES_ALIGN 1

struct dpcon {
	uint16_t 	id;
	enum dpmng_ctx_type ctx_type;
	struct device	*device;
	struct qbman_block *qbman;
	struct dpmng	   *dpmng;
	uint8_t		num_priorities;
	int		channel_id;
	uint32_t	virt_channel_id;
	struct dpmng_amq amq;
	int		enabled;
	int 		authorized;
	int		cdan;
	int		static_dequeue;
	uint16_t	wqid;

	enum dpcon_channel_type_cfg channel_type;
	struct mc_irq	irqs[DPCON_MAX_IRQ_NUM];
};

#endif /* __DPCON_H */
