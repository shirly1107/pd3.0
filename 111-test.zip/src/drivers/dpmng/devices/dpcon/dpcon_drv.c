/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpcon_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "fsl_sys.h"
#include "dtc/dtc.h"
#include "dplib/fsl_dpcon_cmd.h"
#include "fsl_event_pipe.h"
#include "fsl_resman.h"
#include "fsl_dpcon_mc.h"
#include "dpcon_cmd.h"
#include "legacy_dpcon_dplib.h"

/* DPCON last supported API version */
#define DPCON_V0_API_VER_MAJOR				2
#define DPCON_V0_API_VER_MINOR				2

int dpcon_drv_init(void);

/*            cmd,  cfg, param, offset, width,  type,  	arg_name */
#define DPCON_LO_CREATE(cmd, cfg) \
	MC_RSP_OP(cmd, 0, 0,  8,  uint8_t,  cfg->num_priorities)

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpcon *dpcon;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	return dpcon_assign_init(dpcon, dev_ctx);
}

static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpcon_cfg dpcon_cfg = { 0 };
	struct dpcon_cfg *cfg = &dpcon_cfg;
	int err;

	DPCON_CMD_CREATE(cmd_data, cfg);

	/* default to two priorities */
	if (!cfg->num_priorities)
		cfg->num_priorities = 2;

	dpcon = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpcon) {
		/* NULL */
		dpcon = dpcon_allocate();
		if (!dpcon) {
			pr_err("No memory for dpcon\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpcon_init(dpcon, cfg, &dev_cfg);
		if (err) {
			/* TODO should we call dpcon_free() or something else? */
			return err;
		}
		device_set_priv(dev, dpcon);
		sys_add_handle(dpcon, FSL_MOD_DPCON, 1, dev_cfg.id);
	} else
		// TODO check for special cases
		return -EINVAL;

	return 0;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;

	UNUSED(cmd_data);

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	dpcon_destroy(dpcon);

	sys_remove_handle(FSL_MOD_DPCON, 1, device_get_id(dev));
	dpcon_deallocate(dpcon);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	device_set_enable(dev, 1);

	dpcon_enable(dpcon);

	return 0;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	int err;

	UNUSED(cmd_data);

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	err = dpcon_disable(dpcon);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;

	UNUSED(cmd_data);

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	dpcon_reset(dpcon, 0);
	device_set_enable(dev, 0);

	return 0;
}

static int reset_by_resman(struct device *dev)
{
	struct dpcon *dpcon;
	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	/* mark that this is a reset initiated by a container reset */
	dpcon_reset(dpcon, 1);
	device_set_enable(dev, 0);

	return 0;
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	struct dpcon_attr attr = { 0 };
	int err;

	dpcon = device_get_priv(dev);
	CHECK_COND_RETVAL(dpcon, -ENODEV);

	err = dpcon_get_attributes(dpcon, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.version.major = DPCON_V0_API_VER_MAJOR;
	attr.version.minor = DPCON_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCON_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	struct dpcon_attr attr = { 0 };
	int err;

	dpcon = device_get_priv(dev);
	CHECK_COND_RETVAL(dpcon, -ENODEV);

	err = dpcon_get_attributes(dpcon, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCON_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	int en;
	int err;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	err = dpcon_is_enabled(dpcon, &en);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPCON_RSP_IS_ENABLED(cmd_data, en);
	}

	return err;
}

static int set_notification(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	struct dpcon_notification_cfg tmp_cfg = { 0 };
	struct dpcon_notification_cfg *cfg = &tmp_cfg;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	/* Read parameters from portal */
	DPCON_CMD_SET_NOTIFICATION(cmd_data, cfg);

	return dpcon_set_notification(dpcon, cfg);
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	DPCON_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dpcon_set_irq(dpcon, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpcon *dpcon;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	return dpcon_set_irq(dpcon, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	/* Read parameters from portal */
	DPCON_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpcon_get_irq(dpcon, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCON_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpcon *dpcon;
	int err;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	err = dpcon_get_irq(dpcon, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;

	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	uint8_t irq_index;
	uint8_t en;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	/* Read parameters from portal */
	DPCON_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, en);

	return dpcon_set_irq_enable(dpcon, irq_index, en);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	uint8_t irq_index;
	uint8_t en;
	int err;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	/* Read parameters from portal */
	DPCON_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpcon_get_irq_enable(dpcon, irq_index, &en);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCON_RSP_GET_IRQ_ENABLE(cmd_data, en);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	uint8_t irq_index;
	uint32_t mask;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	/* Read parameters from portal */
	DPCON_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpcon_set_irq_mask(dpcon, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	/* Read parameters from portal */
	DPCON_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpcon_get_irq_mask(dpcon, irq_index, &mask);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCON_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	/* Read parameters from portal */
	DPCON_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpcon_get_irq_status(dpcon, irq_index, &status);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCON_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpcon *dpcon;
	uint8_t irq_index;
	uint32_t status;

	dpcon = device_get_priv(dev);
	if (!dpcon)
		return -ENODEV;

	/* Read parameters from portal */
	DPCON_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpcon_clear_irq_status(dpcon, irq_index, status);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPCON_VER_MAJOR;
    uint32_t minor = DPCON_VER_MINOR;

    DPCON_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int dpcon_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpcon_open on DPCON %d\n", device_get_id(dev));
	return 0;
}

static int dpcon_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpcon_close on DPCON %d\n", device_get_id(dev));
	return 0;
}

static int dpcon_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev,
			struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPCON_CMD_CODE_CREATE, init, "dpcon_init", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_DESTROY, destroy, "dpcon_destroy", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_ENABLE, enable, "dpcon_enable", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_DISABLE, disable, "dpcon_disable", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_RESET, reset, "dpcon_reset", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_GET_ATTR, get_attributes_v0,"dpcon_get_attributes", DPCON_CMD_V0 },
			{ DPCON_CMD_CODE_IS_ENABLED, is_enabled, "is_enabled", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_SET_NOTIFICATION, set_notification, "dpcon_set_notification", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_SET_IRQ, set_irq, "dpcon_set_irq", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_GET_IRQ, get_irq, "dpcon_get_irq", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpcon_set_irq_enable", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpcon_get_irq_enable", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpcon_set_irq_mask", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpcon_get_irq_mask", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpcon_get_irq_status", DPCON_CMD_VER_BASE },
			{ DPCON_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpcon_clear_irq_status", DPCON_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPCON_CMD_CODE_GET_API_VERSION, get_api_version, "dpcon_get_api_version", DPCON_CMD_V1 },
			{ DPCON_CMD_CODE_GET_ATTR, get_attributes_v1, "dpcon_get_attributes", DPCON_CMD_V1 },
		};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
			if (cmd == DPCON_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPCON %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev,
							cmd_data);
		}

	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}

static int dpcon_probe_cb(void *lo, int node_off)
{
	int err = 0;
	struct dpcon_cfg dpcon_cfg = { 0 };
	struct dpcon_cfg *cfg = &dpcon_cfg;
	int dpcon_id;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	uint64_t val;
	int destroy = 0;

	getprop_val(lo, node_off, "num_priorities", 0, 0, &val);
	cfg->num_priorities = (uint8_t)val;
	err = (uint16_t)get_node_id(lo, node_off, &dpcon_id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(resman, "dpcon", (uint16_t)dpcon_id, NO_PORTAL_ID,
			DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPCON %.4x\n", dpcon_id);
	DPCON_LO_CREATE(cmd_data, cfg);
	/* create object */
	err = dpcon_ctrl_cb(dev, DPCON_CMD_VER_BASE, DPCON_CMD_CODE_CREATE,
			NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpcon", NO_PORTAL_ID, destroy);

	return err;
}

static char *dpcon_match[] = { "fsl,dpcon", "dpcon" };

static int dpcon_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}

	dev = resman_open_dev(resman, "dpcon", (uint16_t)id, NO_PORTAL_ID, 0, NULL);
	if (!dev) {
		pr_err("Can't open DPCON 0x%.4x\n", id);
		return -ENODEV;
	}

        err |= dpcon_ctrl_cb(dev, DPCON_CMD_VER_BASE, DPCON_CMD_CODE_DESTROY,
                                NO_PORTAL_ID, NULL);
	err |= resman_close_dev(resman, dev, "dpcon", NO_PORTAL_ID, 0);
	return err;
}

int dpcon_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params;
	struct cmdif_module_ops cmdif_ops;
	struct dp_dev_type_param dev_type_param = {0};
	struct resman *resman;
	int err;

	pr_info("Executing dpcon_drv_init...\n");

	dtc_params.num_compats = ARRAY_SIZE(dpcon_match);
	dtc_params.compatibles = dpcon_match;
	dtc_params.f_prob_module = dpcon_probe_cb;
	dtc_params.f_remove_module = dpcon_remove_cb;
	sys_dtc_register_module(&dtc_params);

	cmdif_ops.open_cb = dpcon_open_cb;
	cmdif_ops.close_cb = dpcon_close_cb;
	cmdif_ops.ctrl_cb = dpcon_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPCON, &cmdif_ops);
	strcpy(dev_type_param.device_type, "dpcon");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPCON_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPCON_VER_MAJOR;
	dev_type_param.ver_minor = DPCON_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);
	err = resman_register_device_operation(resman, "dpcon",
						&dev_type_param);
	return err;
}
