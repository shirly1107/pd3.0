/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPCON_CMD_H
#define _DPCON_CMD_H

/* default version for all dpcon commands */
#define DPCON_CMD_VER_BASE								CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPCON_CMD_V0									CMDHDR_CMD_VERSION(0)
#define DPCON_CMD_V1									CMDHDR_CMD_VERSION(1)

/* add your new command version number here
 * Ex:
 * #define DPCON_CMD_CREATE_VER_1                MC_CMD_HDR_VERSION(DPCON_CMD_VER_BASE + 1) or
 * #define DPCON_CMD_CREATE_VER                  MC_CMD_HDR_VERSION(3)
 */

/* Command IDs */
#define DPCON_CMD_CODE_CLOSE                            0x800
#define DPCON_CMD_CODE_OPEN                             0x808
#define DPCON_CMD_CODE_CREATE                           0x908
#define DPCON_CMD_CODE_DESTROY                          0x900
#define DPCON_CMD_CODE_GET_API_VERSION                  0xa08

#define DPCON_CMD_CODE_ENABLE                           0x002
#define DPCON_CMD_CODE_DISABLE                          0x003
#define DPCON_CMD_CODE_GET_ATTR                         0x004
#define DPCON_CMD_CODE_RESET                            0x005
#define DPCON_CMD_CODE_IS_ENABLED                       0x006

#define DPCON_CMD_CODE_SET_IRQ                          0x010
#define DPCON_CMD_CODE_GET_IRQ                          0x011
#define DPCON_CMD_CODE_SET_IRQ_ENABLE                   0x012
#define DPCON_CMD_CODE_GET_IRQ_ENABLE                   0x013
#define DPCON_CMD_CODE_SET_IRQ_MASK                     0x014
#define DPCON_CMD_CODE_GET_IRQ_MASK                     0x015
#define DPCON_CMD_CODE_GET_IRQ_STATUS                   0x016
#define DPCON_CMD_CODE_CLEAR_IRQ_STATUS                 0x017

#define DPCON_CMD_CODE_SET_NOTIFICATION                 0x100

#endif /* _DPCON_CMD_H */
