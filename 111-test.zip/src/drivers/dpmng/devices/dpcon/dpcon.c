/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpcon.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "fsl_platform.h"
#include "drivers/fsl_qbman_ctrl.h"
#include "drivers/fsl_qbman_portal_ex.h"
#include "fsl_event_pipe.h"
#include "fsl_resman.h"
#include "fsl_dpmng_mc.h"
#include "fsl_dpio_mc.h"

#include "dpcon.h"

static int check_dpcon_cfg(const struct dpcon *dpcon,
	const struct dpcon_cfg *cfg)
{
	CHECK_COND_RETVAL(cfg, -EINVAL);

	if (!((cfg->num_priorities >= 1) &&
		(cfg->num_priorities <= QMAN_CHANNEL_WQ_PRIO_NUM))) {
		pr_err("ID[%d]: num_priorities must be between 1-8\n", dpcon->id);
		return -EINVAL;
	}

	return 0;
}

static const char* get_dpcon_ch_type(enum dpcon_channel_type_cfg channel_type,
		uint8_t label) {
	switch(channel_type) {
		case DPCON_SWP_CHANNEL_8WQ:
			return label ? "8WQ-CH-id" : "swpch.8wq";
		case DPCON_SWP_CHANNEL_2WQ:
			return label ? "2WQ-CH-id" : "swpch.2wq";
		case DPCON_DCP_CHANNEL:
			return label ? "DCP-8WQ" : "dcp.aiop.ch";
	};
	return "";
}

static int resources_authorization(struct dpcon *dpcon)
{
	struct qbman_swp *sw_portal;
	int err;

	CHECK_COND_RETVAL(dpcon, -EINVAL);

	if (dpcon->authorized)
		return 0;

	/* no authorization needed to DCP channels */
	if (dpcon->channel_type == DPCON_DCP_CHANNEL) {
		dpcon->authorized = 1;
		return 0;
	}

	dpmng_get_swportal(dpcon->dpmng, (void**)&sw_portal);
	err = resource_authorization(sw_portal, dpcon->amq.bdi,
					dpcon->amq.icid,
					qbman_auth_type_channel,
					&dpcon->virt_channel_id,
					(uint32_t)dpcon->channel_id,
					QBMAN_AUTH_SWP, "WQ-CH-ID");
	dpmng_put_swportal(dpcon->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(err == 0, err);

	dpcon->authorized = 1;

	if (dpcon->cdan)
		/* set the destination WQ to get the CDAN */
		qbman_block_set_wq_ch_cdan(
			dpcon->qbman, (uint16_t)dpcon->channel_id,
			(uint32_t)dpcon->amq.bdi, dpcon->wqid,
			(uint16_t)dpcon->virt_channel_id);

	return 0;
}

static int resources_deauthorization(struct dpcon *dpcon)
{
	struct qbman_swp *sw_portal;
	int err;

	CHECK_COND_RETVAL(dpcon, -EINVAL);

	if (!dpcon->authorized)
		return 0;
	/* no authorization needed to DCP channels */
	if (dpcon->channel_type != DPCON_DCP_CHANNEL) {
		dpmng_get_swportal(dpcon->dpmng, (void**)&sw_portal);
		err = resource_deauthorization(sw_portal, dpcon->amq.bdi,
				dpcon->amq.icid,
				qbman_auth_type_channel,
				dpcon->virt_channel_id, QBMAN_AUTH_SWP,
				"WQ-CH-ID");
		dpmng_put_swportal(dpcon->dpmng, (void*)sw_portal);
		CHECK_COND_RETVAL(err == 0, err);
	}
	dpcon->authorized = 0;

	dpcon->amq.icid = (uint16_t)-1;

	return 0;
}

static void dpcon_set_mc_info(struct dpcon *dpcon,
	const struct dpmng_dev_cfg *dev_cfg)
{
	dpcon->id = dev_cfg->id;
	CHECK_COND_RET(dev_cfg->device);
	dpcon->device = dev_cfg->device;
	dpcon->ctx_type = dev_cfg->ctx.type;
	dpcon->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dpcon->dpmng);
	dpcon->qbman = sys_get_unique_handle(FSL_MOD_QBMAN);
	CHECK_COND_RET(dpcon->qbman);
}

static int allocate_channel_resources(struct dpcon *dpcon,
		enum dpmng_ctx_type ctx_type) {
	int err = 0;
	/* if in AIOP context try allocate first DCP channel; if the
	the AIOP container does not have any DCP channels then try get a SWP
	channel. Based on AIOP container resources and rights the user can
	decide if he wants a DCP or SWP channel.*/
	if (ctx_type == DPMNG_CTX_TYPE_AIOP) {
		err = allocate_resource(dpcon->device,
				(char*)get_dpcon_ch_type(DPCON_DCP_CHANNEL, 0),
				DPCON_REQ_RES_NUM,
				DPCON_REQ_RES_ALIGN,
				0, /*no options*/
				&dpcon->channel_id,
				(char*)get_dpcon_ch_type(DPCON_DCP_CHANNEL, 1));
		CHECK_COND_RETVAL(!err, err,
		"DPCON[%d]: fail to allocate DCP AIOP channel", dpcon->id);
		dpcon->channel_type = DPCON_DCP_CHANNEL;
	} else {
		if (dpcon->num_priorities <= 2) {
			/* First try to allocate 2WQ channel.
			 * if not available try 8WQ channel */
			/* 2WQ-CHANNEL-ID */
			dpcon->channel_type = DPCON_SWP_CHANNEL_2WQ;
			if ((err = allocate_resource(dpcon->device,
				(char*)get_dpcon_ch_type(DPCON_SWP_CHANNEL_2WQ, 0),
				DPCON_REQ_RES_NUM,
				DPCON_REQ_RES_ALIGN,
				0, /*no options*/
				&dpcon->channel_id,
				(char*)get_dpcon_ch_type(DPCON_DCP_CHANNEL, 1))) != 0) {
				pr_err("Ignore above error message, continue with 8WQ "
						"channel allocation...\n");
				/* 8WQ-CHANNEL-ID */
				dpcon->channel_type = DPCON_SWP_CHANNEL_8WQ;
				if ((err = allocate_resource(dpcon->device,
						(char*)get_dpcon_ch_type(DPCON_SWP_CHANNEL_8WQ, 0),
						DPCON_REQ_RES_NUM,
						DPCON_REQ_RES_ALIGN,
						0, /*no options*/
						&dpcon->channel_id,
						(char*)get_dpcon_ch_type(DPCON_SWP_CHANNEL_8WQ, 1)))
						!= 0) {
					dpcon->channel_type = DPCON_CHANNEL_NONE;
					return err;
				}
			}
		} else {
			/* 8WQ-CHANNEL-ID */
			dpcon->channel_type = DPCON_SWP_CHANNEL_8WQ;
			if ((err = allocate_resource(dpcon->device,
					(char*)get_dpcon_ch_type(DPCON_SWP_CHANNEL_8WQ, 0),
					DPCON_REQ_RES_NUM,
					DPCON_REQ_RES_ALIGN,
					0, /*no options*/
					&dpcon->channel_id,
					(char*)get_dpcon_ch_type(DPCON_SWP_CHANNEL_8WQ, 1)))
					!= 0) {
				dpcon->channel_type = DPCON_CHANNEL_NONE;
				return err;
			}
		}
	}
	return err;
}

int dpcon_assign_init(struct dpcon *dpcon,
		const struct dpmng_dev_ctx *dev_ctx) {
	int err = 0;
	enum dpcon_channel_type_cfg saved_channel_type = dpcon->channel_type;
	int saved_channel_id = dpcon->channel_id;;
	obj_info(dpcon->id, "start assign init: CH[%xh], type=%s, priorities=%d\n",
			dpcon->channel_id,
			get_dpcon_ch_type(dpcon->channel_type, 1),
			dpcon->num_priorities);
	// before each assign that involves AIOP containers must deallocate the
	// current resources as AIOP uses DCP channels instead of SWP.
	if (dev_ctx->type != dpcon->ctx_type) {
		dpcon_reset(dpcon, 0);
		err = allocate_channel_resources(dpcon, dev_ctx->type);
		if (!err)
			err = resources_deauthorization(dpcon);
		if (!err)
			err = resman_unbind(dpcon->device,
				(char*)get_dpcon_ch_type(saved_channel_type, 0),
				saved_channel_id);
	}
	if (!err)
		err = dpcon_set_dev_ctx(dpcon, dev_ctx);

	obj_info(dpcon->id, "assign init %s: CH[%xh], type=%s, priorities=%d\n",
			err ? "failed" : "succeed", dpcon->channel_id,
			get_dpcon_ch_type(dpcon->channel_type, 1),
			dpcon->num_priorities);
	return err;
}

int dpcon_init(struct dpcon *dpcon,
	const struct dpcon_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
	int i, err;

	obj_info(dpcon->id, "start init: priorities=%d\n", cfg->num_priorities);
	dpcon_set_mc_info(dpcon, dev_cfg);

	if ((err = check_dpcon_cfg(dpcon, cfg)) != 0) {
		pr_err("ID[%d]: check_dpcon_cfg() failed\n", dpcon->id);
		return err;
	}

	dpcon->num_priorities = cfg->num_priorities;
	err = allocate_channel_resources(dpcon, dpcon->ctx_type);
	CHECK_COND_RETVAL(!err, err, "Fail to allocate channel\n");

	dpcon->amq.icid = (uint16_t)-1;

	for (i = 0; i < DPCON_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpcon->irqs[i]), MC_IRQ_TYPE_MSI);

	err = dpcon_set_dev_ctx(dpcon, &dev_cfg->ctx);
	if (err)
		resman_unbind_all(dpcon->device);

	obj_info(dpcon->id, "init %s: CH[%xh], type=%s, priorities=%d\n",
			!!err ? "failed" : "succeed",
			dpcon->channel_id,
			get_dpcon_ch_type(dpcon->channel_type, 1),
			dpcon->num_priorities);
	return err;
}

struct dpcon * dpcon_allocate(void)
{
	struct dpcon *dpcon;

	dpcon = (struct dpcon *)fsl_xmalloc(sizeof(struct dpcon), 0,
						CORE_CACHELINE_SIZE);
	if (dpcon)
		memset(dpcon, 0, sizeof(struct dpcon));
	return dpcon;
}

void dpcon_deallocate(struct dpcon *dpcon)
{
	fsl_xfree(dpcon);
}

void dpcon_destroy(struct dpcon *dpcon)
{
	int err;

	dpcon_reset(dpcon, 0);
	
	err = resources_deauthorization(dpcon);
	CHECK_COND_RET(err == 0);

	err = resman_unbind_all(dpcon->device);
	CHECK_COND_RET(err == 0);

}

void dpcon_enable(struct dpcon *dpcon)
{
	struct qbman_swp *sw_portal;

	dpcon->enabled = 1;

	if (dpcon->cdan) {
		qbman_block_enable_wq_ch_cdan(dpcon->qbman,
						(uint16_t)dpcon->channel_id,
						1);

		dpmng_get_swportal(dpcon->dpmng, (void**)&sw_portal);
		qbman_swp_CDAN_enable(sw_portal, (uint16_t)dpcon->channel_id);
		dpmng_put_swportal(dpcon->dpmng, (void*)sw_portal);
	}

}

int dpcon_disable(struct dpcon *dpcon)
{
	struct qbman_swp *sw_portal;

	if (dpcon->cdan) {
		dpmng_get_swportal(dpcon->dpmng, (void**)&sw_portal);
		qbman_swp_CDAN_disable(sw_portal, (uint16_t)dpcon->channel_id);
		dpmng_put_swportal(dpcon->dpmng, (void*)sw_portal);

		qbman_block_enable_wq_ch_cdan(dpcon->qbman,
						(uint16_t)dpcon->channel_id,
						0);
	}

	dpcon->enabled = 0;

	return 0;
}

int dpcon_is_enabled(struct dpcon *dpcon, int *en)
{
	*en = dpcon->enabled;

	return 0;
}

void dpcon_reset(struct dpcon *dpcon, int clear_channel)
{
	pr_info("reseting DPCON[%d], CH[%d] ... \n", dpcon->id, dpcon->channel_id);
	/* drain the channel and the contained FQs here in order to avoid
	clearing 'Truly Scheduled' FQs on WQ at DPNI reset.
	DCP channels are cleared by the connected HW block; eg. AIOP.*/
	if (clear_channel && dpcon->channel_id >= 0 &&
		dpcon->channel_type != DPCON_DCP_CHANNEL)
		dpmng_clear_channel((uint32_t)dpcon->channel_id);

	dpcon_disable(dpcon);

	dpcon->cdan = 0;
	dpcon->static_dequeue = 0;
}

int dpcon_get_attributes(struct dpcon *dpcon, struct dpcon_attr *attributes)
{
	attributes->id = dpcon->id;
	attributes->num_priorities = dpcon->num_priorities;
	attributes->qbman_ch_id = (uint16_t)dpcon->virt_channel_id;

	return 0;
}

int dpcon_set_dev_ctx(struct dpcon *dpcon, const struct dpmng_dev_ctx *dev_ctx)
{
	int err = 0;

	if (memcmp(&dpcon->amq, &(dev_ctx->amq), sizeof(struct dpmng_amq))
		!= 0) {
		CHECK_COND_RETVAL(!dpcon->enabled, -EINVAL);
		if ((err = resources_deauthorization(dpcon)) != 0) {
			pr_err("ID[%d]: resources_deauthorization failed \n", dpcon->id);
			return err;
		}

		dpcon->amq = dev_ctx->amq;

		//TODO - handle this better (update on assign)
		dpcon->amq.bdi = (dev_ctx->type == DPMNG_CTX_TYPE_GPP) ? 0 : 1;

		if ((err = resources_authorization(dpcon)) != 0) {
			pr_err("ID[%d]: resources_authorization failed \n", dpcon->id);
			return err;
		}
	}

	/* set new context */
	if (!err)
		dpcon->ctx_type = dev_ctx->type;
	return 0;
}

int dpcon_set_notification(struct dpcon *dpcon,
	struct dpcon_notification_cfg *cfg)
{
	struct dpio *dpio;
	struct qbman_swp *sw_portal;
	int err;

	CHECK_COND_RETVAL(cfg, -EINVAL);

	if (cfg->dpio_id == DPCON_INVALID_DPIO_ID) {
		dpcon->cdan = 0;

		/* Now need to disable the CDAN */
		dpmng_get_swportal(dpcon->dpmng, (void**)&sw_portal);
		qbman_swp_CDAN_disable(sw_portal, (uint16_t)dpcon->channel_id);
		dpmng_put_swportal(dpcon->dpmng, (void*)sw_portal);

		qbman_block_enable_wq_ch_cdan(dpcon->qbman,
						(uint16_t)dpcon->channel_id,
						0);
	} else {
		if (dpcon->static_dequeue) {
			pr_err("ID[%d]: remove this dpcon from static dequeue\n", dpcon->id);
			return -EINVAL;
		}

		dpio = sys_get_handle(FSL_MOD_DPIO, 1, cfg->dpio_id);
		if (!dpio) {
			pr_err("ID[%d]: dpio_id is invalid\n", dpcon->id);
			return -EINVAL;
		}

		if (!dpio_is_priority_in_range(dpio, cfg->priority)) {
			pr_err("ID[%d]: priority not in range\n", dpcon->id);
			return -EINVAL;
		}
		err = dpio_get_destwq(dpio, cfg->priority, &dpcon->wqid);
		CHECK_COND_RETVAL(err == 0, err);

		/* set the destination WQ to get the CDAN */
		qbman_block_set_wq_ch_cdan(
			dpcon->qbman, (uint16_t)dpcon->channel_id,
			(unsigned int)dpcon->amq.bdi, dpcon->wqid,
			(uint16_t)dpcon->virt_channel_id);

		/* Now need to enable the CDAN */
		qbman_block_enable_wq_ch_cdan(dpcon->qbman,
						(uint16_t)dpcon->channel_id,
						1);

		dpmng_get_swportal(dpcon->dpmng, (void**)&sw_portal);
		qbman_swp_CDAN_set_context_enable(
			sw_portal, (uint16_t)dpcon->channel_id, cfg->user_ctx);
		dpmng_put_swportal(dpcon->dpmng, (void*)sw_portal);

		dpcon->cdan = 1;
	}

	return 0;
}

int dpcon_get_destwq(struct dpcon *dpcon, uint8_t priority, uint16_t *destwq)
{
	if (!dpcon_is_priority_in_range(dpcon, priority))
		return -EINVAL;

	if (dpcon->ctx_type == DPMNG_CTX_TYPE_AIOP &&
		dpcon->channel_type == DPCON_DCP_CHANNEL) {
		uint16_t wqid_base;
		wqid_base = dpmng_get_dcp_wqid(dpcon->dpmng,
				QBMAN_DCP_AIOP,
				(uint8_t)dpcon->channel_id);
		*destwq = (uint16_t)(wqid_base << 3 | priority);
	} else
		*destwq = (uint16_t)(dpcon->channel_id << 3 | priority);

	return 0;
}

int dpcon_is_aiop_dcp_channel_type(struct dpcon* dpcon) {
	return dpcon->ctx_type == DPMNG_CTX_TYPE_AIOP &&
			dpcon->channel_type == DPCON_DCP_CHANNEL;
}

/* return '1' for in-range and '0' for not in-range */
int dpcon_is_priority_in_range(struct dpcon *dpcon, uint8_t priority)
{
	if (priority >= dpcon->num_priorities) {
		pr_err("ID[%d]: priority not in range, should be smaller than %d\n", dpcon->id, dpcon->num_priorities);
		return 0;
	}

	return 1;
}

int dpcon_is_cdan_enabled(struct dpcon *dpcon)
{
	return dpcon->cdan;
}

uint16_t dpcon_get_channel_id(struct dpcon *dpcon)
{
	return (uint16_t)dpcon->channel_id;
}

void dpcon_set_static_dequeue(struct dpcon *dpcon, int enable)
{
	dpcon->static_dequeue = enable;
}

int dpcon_set_irq(struct dpcon *dpcon,
	uint8_t irq_index,
	const struct mc_irq_cfg *irq_cfg)
{
	UNUSED(irq_index);
	UNUSED(irq_cfg);

	pr_err("ID[%d]: IRQs are not supported\n", dpcon->id);
	return -ENOTSUP;
}

int dpcon_get_irq(struct dpcon *dpcon,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg)
{
	UNUSED(irq_index);
	UNUSED(irq_cfg);

	pr_err("ID[%d]: IRQs are not supported\n", dpcon->id);
	return -ENOTSUP;
}

int dpcon_set_irq_enable(struct dpcon *dpcon, uint8_t irq_index, uint8_t en)
{
	UNUSED(irq_index);
	UNUSED(en);

	pr_err("ID[%d]: IRQs are not supported\n", dpcon->id);
	return -ENOTSUP;
}

int dpcon_get_irq_enable(struct dpcon *dpcon, uint8_t irq_index, uint8_t *en)
{
	UNUSED(irq_index);
	UNUSED(en);

	pr_err("ID[%d]: IRQs are not supported\n", dpcon->id);
	return -ENOTSUP;
}

int dpcon_set_irq_mask(struct dpcon *dpcon, uint8_t irq_index, uint32_t mask)
{
	UNUSED(irq_index);
	UNUSED(mask);

	pr_err("ID[%d]: IRQs are not supported\n", dpcon->id);
	return -ENOTSUP;
}

int dpcon_get_irq_mask(struct dpcon *dpcon, uint8_t irq_index, uint32_t *mask)
{
	UNUSED(irq_index);
	UNUSED(mask);

	pr_err("ID[%d]: IRQs are not supported\n", dpcon->id);
	return -ENOTSUP;
}

int dpcon_get_irq_status(struct dpcon *dpcon,
	uint8_t irq_index,
	uint32_t *status)
{
	UNUSED(irq_index);
	UNUSED(status);

	pr_err("ID[%d]: IRQs are not supported\n", dpcon->id);
	return -ENOTSUP;
}

int dpcon_clear_irq_status(struct dpcon *dpcon,
	uint8_t irq_index,
	uint32_t status)
{
	UNUSED(irq_index);
	UNUSED(status);

	pr_err("ID[%d]: IRQs are not supported\n", dpcon->id);
	return -ENOTSUP;
}
