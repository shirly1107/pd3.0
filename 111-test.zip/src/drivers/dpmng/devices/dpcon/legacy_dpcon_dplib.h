/*
 * Copyright 2013-2020 NXP
 */

#ifndef _LEGACY_DPCON_DPLIB_H
#define _LEGACY_DPCON_DPLIB_H

/* 
 * File used to maintain compatibility with older version of dplib/flib
 * All previous version of dpcon commands should be placed here
 * 
 */
/**********************************************/
/**********************************************/
/********* V0 version of dpcon commands ******/
/**********************************************/
/**********************************************/

/*                cmd, param, offset, width, type, arg_name */
#define DPCON_RSP_GET_ATTRIBUTES_V0(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, int,      (attr)->id);\
	MC_RSP_OP(cmd, 0, 32, 16, uint16_t, (attr)->qbman_ch_id);\
	MC_RSP_OP(cmd, 0, 48,  8, uint8_t,  (attr)->num_priorities);\
	MC_RSP_OP(cmd, 1,  0, 16, uint16_t, (attr)->version.major);\
	MC_RSP_OP(cmd, 1, 16, 16, uint16_t, (attr)->version.minor);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPCON_CMD_SET_IRQ(cmd, irq_index, irq_cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,  irq_index);\
	MC_CMD_OP(cmd, 0, 32, 32, uint32_t, irq_cfg->val);\
	MC_CMD_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr);\
	MC_CMD_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPCON_CMD_GET_IRQ(cmd, irq_index) \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index)

/*                cmd, param, offset, width, type, arg_name */
#define DPCON_RSP_GET_IRQ(cmd, type, irq_cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, irq_cfg->val);\
	MC_RSP_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr);\
	MC_RSP_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
	MC_RSP_OP(cmd, 2, 32, 32, int,	    type);\
} while (0)

#endif /* _DPCON_CMD_H */
