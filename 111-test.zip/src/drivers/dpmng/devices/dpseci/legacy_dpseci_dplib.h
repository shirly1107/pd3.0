/*
 * Copyright 2013-2020 NXP
 */

#ifndef _LEGACY_DPSECI_DPLIB_H
#define _LEGACY_DPSECI_DPLIB_H

/* 
 * File used to maintain compatibility with older version of dplib/flib
 * All previous version of dpseci commands should be placed here
 * 
 */
/**********************************************/
/**********************************************/
/********* V0 version of dpseci commands ******/
/**********************************************/
/**********************************************/

/*                cmd, param, offset, width, type, arg_name */
#define DPSECI_RSP_GET_ATTRIBUTES_V0(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, int,      (attr)->id); \
	MC_RSP_OP(cmd, 1,  0,  8, uint8_t,  (attr)->num_tx_queues); \
	MC_RSP_OP(cmd, 1,  8,  8, uint8_t,  (attr)->num_rx_queues); \
	MC_RSP_OP(cmd, 5,  0, 16, uint16_t, (attr)->version.major);\
	MC_RSP_OP(cmd, 5, 16, 16, uint16_t, (attr)->version.minor);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSECI_CMD_SET_IRQ(cmd, irq_index, irq_cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,  irq_index);\
	MC_CMD_OP(cmd, 0, 32, 32, uint32_t, irq_cfg->val);\
	MC_CMD_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr);\
	MC_CMD_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSECI_CMD_GET_IRQ(cmd, irq_index) \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index)

/*                cmd, param, offset, width, type, arg_name */
#define DPSECI_RSP_GET_IRQ(cmd, type, irq_cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, irq_cfg->val); \
	MC_RSP_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr);\
	MC_RSP_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
	MC_RSP_OP(cmd, 2, 32, 32, int,	    type); \
} while (0)

/**********************************************/
/**********************************************/
/********* V1 version of dpseci commands ******/
/**********************************************/
/**********************************************/

/*                cmd, param, offset, width, type, arg_name */
#define DPSECI_CMD_CREATE_v1(cmd, cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,  cfg->priorities[0]);\
	MC_CMD_OP(cmd, 0, 8,  8,  uint8_t,  cfg->priorities[1]);\
	MC_CMD_OP(cmd, 0, 16, 8,  uint8_t,  cfg->priorities[2]);\
	MC_CMD_OP(cmd, 0, 24, 8,  uint8_t,  cfg->priorities[3]);\
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  cfg->priorities[4]);\
	MC_CMD_OP(cmd, 0, 40, 8,  uint8_t,  cfg->priorities[5]);\
	MC_CMD_OP(cmd, 0, 48, 8,  uint8_t,  cfg->priorities[6]);\
	MC_CMD_OP(cmd, 0, 56, 8,  uint8_t,  cfg->priorities[7]);\
	MC_CMD_OP(cmd, 1, 0,  8,  uint8_t,  cfg->num_tx_queues);\
	MC_CMD_OP(cmd, 1, 8,  8,  uint8_t,  cfg->num_rx_queues);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSECI_RSP_GET_SEC_ATTR(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0, 16, uint16_t,  attr->ip_id);\
	MC_RSP_OP(cmd, 0, 16,  8,  uint8_t,  attr->major_rev);\
	MC_RSP_OP(cmd, 0, 24,  8,  uint8_t,  attr->minor_rev);\
	MC_RSP_OP(cmd, 0, 32,  8,  uint8_t,  attr->era);\
	MC_RSP_OP(cmd, 1,  0,  8,  uint8_t,  attr->deco_num);\
	MC_RSP_OP(cmd, 1,  8,  8,  uint8_t,  attr->zuc_auth_acc_num);\
	MC_RSP_OP(cmd, 1, 16,  8,  uint8_t,  attr->zuc_enc_acc_num);\
	MC_RSP_OP(cmd, 1, 32,  8,  uint8_t,  attr->snow_f8_acc_num);\
	MC_RSP_OP(cmd, 1, 40,  8,  uint8_t,  attr->snow_f9_acc_num);\
	MC_RSP_OP(cmd, 1, 48,  8,  uint8_t,  attr->crc_acc_num);\
	MC_RSP_OP(cmd, 2,  0,  8,  uint8_t,  attr->pk_acc_num);\
	MC_RSP_OP(cmd, 2,  8,  8,  uint8_t,  attr->kasumi_acc_num);\
	MC_RSP_OP(cmd, 2, 16,  8,  uint8_t,  attr->rng_acc_num);\
	MC_RSP_OP(cmd, 2, 32,  8,  uint8_t,  attr->md_acc_num);\
	MC_RSP_OP(cmd, 2, 40,  8,  uint8_t,  attr->arc4_acc_num);\
	MC_RSP_OP(cmd, 2, 48,  8,  uint8_t,  attr->des_acc_num);\
	MC_RSP_OP(cmd, 2, 56,  8,  uint8_t,  attr->aes_acc_num);\
} while (0)

#endif /* _LEGACY_DPSECI_DPLIB_H */
