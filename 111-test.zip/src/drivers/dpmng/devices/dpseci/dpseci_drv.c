/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpseci_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "fsl_sys.h"
#include "dtc/dtc.h"
#include "dplib/fsl_dpseci_cmd.h"
#include "fsl_dpmng_mc.h"
#include "fsl_event_pipe.h"
#include "fsl_dpseci_mc.h"
#include "fsl_resman.h"
#include "fsl_opr.h"
#include "dpseci_cmd.h"
#include "legacy_dpseci_dplib.h"

/* DPSECI last supported API version */
#define DPSECI_V0_API_VER_MAJOR				4
#define DPSECI_V0_API_VER_MINOR				1

int dpseci_drv_init(void);


/*            cmd,  cfg, param, offset, width,  type,  	arg_name */
#define DPSECI_LO_CREATE(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  8,  uint8_t,  cfg->priorities[0]);\
	MC_RSP_OP(cmd, 0, 8,  8,  uint8_t,  cfg->priorities[1]);\
	MC_RSP_OP(cmd, 0, 16, 8,  uint8_t,  cfg->priorities[2]);\
	MC_RSP_OP(cmd, 0, 24, 8,  uint8_t,  cfg->priorities[3]);\
	MC_RSP_OP(cmd, 0, 32, 8,  uint8_t,  cfg->priorities[4]);\
	MC_RSP_OP(cmd, 0, 40, 8,  uint8_t,  cfg->priorities[5]);\
	MC_RSP_OP(cmd, 0, 48, 8,  uint8_t,  cfg->priorities[6]);\
	MC_RSP_OP(cmd, 0, 56, 8,  uint8_t,  cfg->priorities[7]);\
	MC_RSP_OP(cmd, 1, 0,  8,  uint8_t,  cfg->num_tx_queues);\
	MC_RSP_OP(cmd, 1, 8,  8,  uint8_t,  cfg->num_rx_queues);\
	MC_RSP_OP(cmd, 2, 0,  32, uint32_t, cfg->options);\
	MC_RSP_OP(cmd, 3, 0,  8,  uint8_t,  cfg->priorities[8]);\
	MC_RSP_OP(cmd, 3, 8,  8,  uint8_t,  cfg->priorities[9]);\
	MC_RSP_OP(cmd, 3, 16, 8,  uint8_t,  cfg->priorities[10]);\
	MC_RSP_OP(cmd, 3, 24, 8,  uint8_t,  cfg->priorities[11]);\
	MC_RSP_OP(cmd, 3, 32, 8,  uint8_t,  cfg->priorities[12]);\
	MC_RSP_OP(cmd, 3, 40, 8,  uint8_t,  cfg->priorities[13]);\
	MC_RSP_OP(cmd, 3, 48, 8,  uint8_t,  cfg->priorities[14]);\
	MC_RSP_OP(cmd, 3, 56, 8,  uint8_t,  cfg->priorities[15]);\
} while (0)

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpseci *dpseci;

	CHECK_COND_RETVAL(dev, -EINVAL);
	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	return dpseci_set_dev_ctx(dpseci, dev_ctx);
}

static int init_common(struct device *dev, struct dpseci_cfg *cfg) {
	struct dpseci *dpseci;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cfg, -EINVAL);

	if (cfg->priorities[0] == 0) {
		cfg->priorities[0] = cfg->priorities[1];
		cfg->priorities[1] = cfg->priorities[2];
	}

	dpseci = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpseci) {
		/* NULL */
		dpseci = dpseci_allocate();
		if (!dpseci) {
			pr_err("No memory for dpseci\n");
			return -ENOMEM;
		}
		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpseci_init(dpseci, cfg, &dev_cfg);
		CHECK_COND_RETVAL(err == 0, -EINVAL);

		device_set_priv(dev, dpseci);
		sys_add_handle(dpseci, FSL_MOD_DPSECI, 1, dev_cfg.id);

		assign(dev, &(dev_cfg.ctx));
	}
	else
		return -EINVAL;

	return 0;
}

static int init_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci_cfg dpseci_cfg = { 0 };
	struct dpseci_cfg *cfg = &dpseci_cfg;
	int err = 0;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	DPSECI_CMD_CREATE_v1(cmd_data, cfg);

	cfg->options = 0;
	for (int i = 8; i < DPSECI_MAX_QUEUE_NUM; i++)
		cfg->priorities[i] = 0;

	err = init_common(dev, cfg);

	return err;
}

static int init_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci_cfg dpseci_cfg = { 0 };
	struct dpseci_cfg *cfg = &dpseci_cfg;
	int err = 0;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	DPSECI_CMD_CREATE(cmd_data, cfg);

	for (int i = 8; i < DPSECI_MAX_QUEUE_NUM; i++)
		cfg->priorities[i] = 0;

	err = init_common(dev, cfg);

	return err;
}

static int init_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci_cfg dpseci_cfg = { 0 };
	struct dpseci_cfg *cfg = &dpseci_cfg;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	DPSECI_CMD_CREATE(cmd_data, cfg);

	return init_common(dev, cfg);
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	int err;

	UNUSED(cmd_data);
	CHECK_COND_RETVAL(dev, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	device_set_enable(dev, 1);

	err = dpseci_enable(dpseci);
	if (err)
		device_set_enable(dev, 0);

	return err;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	int err;

	UNUSED(cmd_data);
	CHECK_COND_RETVAL(dev, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_disable(dpseci);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	int err;

	UNUSED(cmd_data);
	CHECK_COND_RETVAL(dev, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_destroy(dpseci);
	CHECK_COND_RETVAL(err == 0, err, "failed to destroy DPSECI\n");

	sys_remove_handle(FSL_MOD_DPSECI, 1, device_get_id(dev));
	dpseci_deallocate(dpseci);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	CHECK_COND_RETVAL(dev, -EINVAL);
	return destroy(dev, NULL);
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	struct dpmng_dev_ctx dev_ctx;
	int err;

	UNUSED(cmd_data);
	CHECK_COND_RETVAL(dev, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_reset(dpseci);
	if (!err) {
		resman_get_dev_ctx(dev, &dev_ctx, 1);
		device_set_enable(dev, 0);
		err = assign(dev, &dev_ctx);
	}
	return err;
}

static int reset_by_resman(struct device *dev)
{
	CHECK_COND_RETVAL(dev, -EINVAL);
	return reset(dev, NULL);
}

static int set_rx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	uint8_t queue;
	struct dpseci_rx_queue_cfg queue_cfg;
	struct dpseci_rx_queue_cfg *cfg = &queue_cfg;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	memset(cfg, 0, sizeof(struct dpseci_rx_queue_cfg));
	DPSECI_CMD_SET_RX_QUEUE(cmd_data, queue, cfg);

	return dpseci_set_rx_queue(dpseci, queue, cfg);
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	struct dpseci_attr attr = { 0 };
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_get_attributes(dpseci, &attr);
	CHECK_COND_RETVAL(err == 0, err);

	attr.version.major = DPSECI_V0_API_VER_MAJOR;
	attr.version.minor = DPSECI_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	struct dpseci_attr attr = { 0 };
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_get_attributes(dpseci, &attr);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return err;
}

static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	int en;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_is_enabled(dpseci, &en);
	if(!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSECI_RSP_IS_ENABLED(cmd_data, en);
	}

	return err;
}

static int get_rx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	int err;
	struct dpseci_rx_queue_attr attributes = { 0 };
	struct dpseci_rx_queue_attr *attr = &attributes;
	uint8_t queue_index;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	DPSECI_CMD_GET_RX_QUEUE(cmd_data, queue_index);

	err = dpseci_get_rx_queue(dpseci, queue_index, attr);
	if(!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSECI_RSP_GET_RX_QUEUE(cmd_data, attr);
	}

	return err;
}

static int get_tx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	int err;
	struct dpseci_tx_queue_attr attributes = { 0 };
	struct dpseci_tx_queue_attr *attr = &attributes;
	uint8_t queue_index;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	DPSECI_CMD_GET_TX_QUEUE(cmd_data, queue_index);

	err = dpseci_get_tx_queue(dpseci, queue_index, attr);
	if(!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSECI_RSP_GET_TX_QUEUE(cmd_data, attr);
	}

	return err;
}

static int get_sec_attr(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	struct dpseci_sec_attr attributes = { 0 };
	struct dpseci_sec_attr *attr = &attributes;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_get_sec_attr(dpseci, attr);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_SEC_ATTR(cmd_data, attr);

	return 0;
}

static int get_sec_attr_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	struct dpseci_sec_attr attributes = { 0 };
	struct dpseci_sec_attr *attr = &attributes;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_get_sec_attr(dpseci, attr);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_SEC_ATTR_v2(cmd_data, attr);

	return 0;
}

static int get_sec_counters(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	struct dpseci_sec_counters sec_counters = { 0 };
	struct dpseci_sec_counters *counters = &sec_counters;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_get_sec_counters(dpseci, counters);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_SEC_COUNTERS(cmd_data, counters);

	return 0;
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	DPSECI_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dpseci_set_irq(dpseci, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpseci *dpseci;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(irq_cfg, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	return dpseci_set_irq(dpseci, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
	uint8_t irq_index;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	/* Read parameters from portal */
	DPSECI_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpseci_get_irq(dpseci, irq_index, irq_cfg);
	CHECK_COND_RETVAL(err == 0, -EINVAL);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpseci *dpseci;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(irq_cfg, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_get_irq(dpseci, (uint8_t)irq_index, irq_cfg);
	return err;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	uint8_t irq_index;
	uint8_t en;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	/* Read parameters from portal */
	DPSECI_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, en);

	return dpseci_set_irq_enable(dpseci, irq_index, en);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	uint8_t irq_index;
	uint8_t en;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	/* Read parameters from portal */
	DPSECI_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpseci_get_irq_enable(dpseci, irq_index, &en);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_IRQ_ENABLE(cmd_data, en);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	uint8_t irq_index;
	uint32_t mask;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	/* Read parameters from portal */
	DPSECI_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpseci_set_irq_mask(dpseci, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	/* Read parameters from portal */
	DPSECI_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpseci_get_irq_mask(dpseci, irq_index, &mask);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	uint8_t irq_index;
	uint32_t status;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	/* Read parameters from portal */
	DPSECI_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpseci_get_irq_status(dpseci, irq_index, &status);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	uint8_t irq_index;
	uint32_t status;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	/* Read parameters from portal */
	DPSECI_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpseci_clear_irq_status(dpseci, irq_index, status);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPSECI_VER_MAJOR;
    uint32_t minor = DPSECI_VER_MINOR;

	CHECK_COND_RETVAL(cmd_data, -EINVAL);

    DPSECI_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int set_opr(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	uint8_t options, index;
	struct opr_cfg or_cfg = { 0 };
	struct opr_cfg *cfg = &or_cfg;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	/* Read parameters from portal */
	DPSECI_CMD_SET_OPR(cmd_data, index, options, cfg);

	err = dpseci_set_opr(dpseci, index, options, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int get_opr(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	struct opr_cfg or_cfg;
	struct opr_qry or_qry;
	uint8_t index;
	int err;

	CHECK_COND_RETVAL(dev, -EINVAL);
	CHECK_COND_RETVAL(cmd_data, -EINVAL);

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	/* Read parameters from portal */
	DPSECI_CMD_GET_OPR(cmd_data, index);

	err = dpseci_get_opr(dpseci, index, &or_cfg, &or_qry);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_OPR(cmd_data, &or_cfg, &or_qry);

	return 0;
}

static int dpseci_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpseci_open on DPSECI %d\n", device_get_id(dev));
	return 0;
}

static int dpseci_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpseci_close on DPSECI %d\n", device_get_id(dev));
	return 0;
}


static int set_congestion_notification(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	struct dpseci_congestion_notification_cfg cfg;

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	DPSECI_CMD_SET_CONGESTION_NOTIFICATION(cmd_data, &cfg);

	return dpseci_set_congestion_notification(dpseci, &cfg);
}

static int get_congestion_notification(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpseci *dpseci;
	struct dpseci_congestion_notification_cfg cfg;
	int err;

	dpseci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpseci, -ENODEV);

	err = dpseci_get_congestion_notification(dpseci, &cfg);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSECI_RSP_GET_CONGESTION_NOTIFICATION(cmd_data, &cfg);

	return 0;
}

static int dpseci_ctrl_cb(void *dev,
                        uint8_t cmd_ver,
                        uint16_t cmd,
                        int portal_id,
                        uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev, struct mc_cmd_data *cmd_data);
		char *cmd_str;
		uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPSECI_CMD_CODE_CREATE, init_v1, "dpseci_init", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_ENABLE, enable, "dpseci_enable", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_DISABLE, disable, "dpseci_disable", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_DESTROY, destroy, "dpseci_destroy", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_RESET, reset, "dpseci_reset", DPSECI_CMD_VER_BASE},
			{ DPSECI_CMD_CODE_SET_RX_QUEUE, set_rx_queue, "dpseci_set_rx_queue", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_GET_ATTR, get_attributes_v0, "dpseci_get_attributes", DPSECI_CMD_V0 },
			{ DPSECI_CMD_CODE_IS_ENABLED, is_enabled, "dpseci_is_enabled", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_GET_RX_QUEUE, get_rx_queue, "dpseci_get_rx_queue", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_GET_TX_QUEUE, get_tx_queue, "dpseci_get_tx_queue", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_GET_SEC_COUNTERS, get_sec_counters, "dpseci_get_sec_counters", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_GET_SEC_ATTR, get_sec_attr, "dpseci_get_sec_attr", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_SET_IRQ, set_irq, "dpseci_set_irq", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_GET_IRQ, get_irq, "dpseci_get_irq", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpseci_set_irq_enable", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpseci_get_irq_enable", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpseci_set_irq_mask", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpseci_get_irq_mask", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpseci_get_irq_status", DPSECI_CMD_VER_BASE },
			{ DPSECI_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpseci_clear_irq_status", DPSECI_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPSECI_CMD_CODE_GET_API_VERSION, get_api_version, "dpseci_get_api_version", DPSECI_CMD_V1 },
			{ DPSECI_CMD_CODE_GET_ATTR, get_attributes_v1, "dpseci_get_attributes", DPSECI_CMD_V1 },
			{ DPSECI_CMD_CODE_SET_OPR, set_opr, "dpseci_set_opr", DPSECI_CMD_V1 },
			{ DPSECI_CMD_CODE_GET_OPR, get_opr, "dpseci_get_opr", DPSECI_CMD_V1 },
			{ DPSECI_CMD_CODE_CREATE, init_v2, "dpseci_init", DPSECI_CMD_V2 },
			{ DPSECI_CMD_CODE_SET_CONGESTION_NOTIFICATION, set_congestion_notification, "dpseci_set_congestion_notification", DPSECI_CMD_V1 },
			{ DPSECI_CMD_CODE_GET_CONGESTION_NOTIFICATION, get_congestion_notification, "dpseci_get_congestion_notification", DPSECI_CMD_V1 },
			{ DPSECI_CMD_CODE_GET_SEC_ATTR, get_sec_attr_v2, "dpseci_get_sec_attr", DPSECI_CMD_V2 },
			{ DPSECI_CMD_CODE_CREATE, init_v3, "dpseci_init", DPSECI_CMD_V3 }
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))){
			if (cmd == DPSECI_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPSECI %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev, cmd_data);
		}

	pr_err("Invalid command %d\n",cmd);
	return -ENOTSUP;
}

static uint32_t get_options(void *lo, int node_off)
{
	char *opt_str;
	int total_len;
	int len;
	int i = 0;
	uint32_t options = 0;
	struct {
		char *opt_str;
		uint32_t options;
	} map[] = {
			{ "DPSECI_OPT_HAS_OPR", DPSECI_OPT_HAS_OPR },
			{ "DPSECI_OPT_OPR_SHARED", DPSECI_OPT_OPR_SHARED },
			{ "DPSECI_OPT_HAS_CG", DPSECI_OPT_HAS_CG }
	};

	opt_str = (char *)fdt_getprop(lo, node_off, "options", &total_len);

	if (opt_str && (int)(*opt_str) != 0 ) {
		while (total_len > 0){
			while (i < (ARRAY_SIZE(map) - 1) && strcmp(opt_str,map[i].opt_str))
				i++;
			if (!strcmp(opt_str,map[i].opt_str))
				options |= map[i].options;
			len = (int)strlen(opt_str) + 1;
			total_len -= len;
			opt_str = PTR_MOVE(opt_str, len );
			i=0;
		}
	}

	return options;
}

static int dpseci_probe_cb(void *lo, int node_off)
{
	int err = 0;
	int i;
	struct dpseci_cfg dpseci_cfg = { 0 };
	struct dpseci_cfg *cfg = &dpseci_cfg;
	int dpseci_id;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	uint32_t val32;
	uint64_t val;
	int destroy = 0;

	CHECK_COND_RETVAL(lo, -EINVAL);

	cfg->options = get_options(lo, node_off);

	getprop_val(lo, node_off, "num_tx_queues", 0, 0, &val);
	cfg->num_tx_queues = (uint8_t)val;

	getprop_val(lo, node_off, "num_rx_queues", 0, 0, &val);
	cfg->num_rx_queues = (uint8_t)val;

	for (i = 0 ; i < DPSECI_MAX_QUEUE_NUM ; i++){
		getprop_array(lo, node_off, "priorities", i, &val32);
		cfg->priorities[i] = (uint8_t)val32;
	}
	err = (uint16_t)get_node_id(lo, node_off, &dpseci_id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman){
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(
			resman, "dpseci",
			(uint16_t)dpseci_id,
			NO_PORTAL_ID, DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPSECI %.4x\n", dpseci_id);

	/* create object */
	DPSECI_LO_CREATE(cmd_data, cfg);
	err = dpseci_ctrl_cb(dev, DPSECI_CMD_V3, DPSECI_CMD_CODE_CREATE,
				NO_PORTAL_ID, (uint8_t *)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpseci",
				NO_PORTAL_ID, destroy);

	return err;
}

static char *dpseci_match[] = { "fsl,dpseci", "dpseci" };

static int dpseci_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	CHECK_COND_RETVAL(lo, -EINVAL);

	err = get_node_id(lo, node_off, &id);
	CHECK_COND_RETVAL(err == 0, -EINVAL);

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV, "Can't find resman");

	dev = resman_open_dev(
	        resman, "dpseci",
	        (uint16_t)id,
	        NO_PORTAL_ID, 0, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't open DPSECI 0x%.4x\n");

	err |= dpseci_ctrl_cb(dev, DPSECI_CMD_VER_BASE, DPSECI_CMD_CODE_DESTROY,
	                        NO_PORTAL_ID, NULL);
	err |= resman_close_dev(resman, dev, "dpseci", NO_PORTAL_ID, 0);
	return err;
}

int dpseci_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	int err;

	pr_info("Executing dpseci_drv_init...\n");
	
	dtc_params.num_compats = ARRAY_SIZE(dpseci_match);
	dtc_params.compatibles = dpseci_match;
	dtc_params.f_prob_module = dpseci_probe_cb;
	dtc_params.f_remove_module = dpseci_remove_cb;
	sys_dtc_register_module(&dtc_params);

	cmdif_ops.open_cb = dpseci_open_cb;
	cmdif_ops.close_cb = dpseci_close_cb;
	cmdif_ops.ctrl_cb = dpseci_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPSECI, &cmdif_ops);
	strcpy(dev_type_param.device_type, "dpseci");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPSECI_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPSECI_VER_MAJOR;
	dev_type_param.ver_minor = DPSECI_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset =   reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	err = resman_register_device_operation(resman, "dpseci",
	                                       &dev_type_param);
	return err;
}
