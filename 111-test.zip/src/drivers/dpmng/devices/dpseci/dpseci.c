/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpseci.c

 @Description   DPSECI library implementation

Data Path SEC Interface internal routines

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_event_pipe.h"

#include "fsl_dpmng_mc.h"
#include "fsl_dpcon_mc.h"
#include "fsl_dpio_mc.h"
#include "fsl_dpbp_mc.h"
#include "fsl_sec.h"
#include "dpseci.h"
#include "coherent_access.h"
#include "fsl_timer.h"

static int dpseci_has_opr(struct dpseci *dpseci)
{
	CHECK_COND_RETVAL(dpseci, -EINVAL);

	return dpmng_soc_has_orp() && (dpseci->options & DPSECI_OPT_HAS_OPR);
}

static int max_index_for_opr(struct dpseci *dpseci)
{
	CHECK_COND_RETVAL(dpseci, -EINVAL);

	if (dpseci->options & DPSECI_OPT_OPR_SHARED) {
		return 1;
	}

	return dpseci->num_rx_queues;
}

static struct opr_info* get_opr_info(struct dpseci *dpseci, uint8_t index)
{
	if (dpseci->options & DPSECI_OPT_OPR_SHARED) {
		return &dpseci->rx_queue_info[0].opr;
	}

	return &dpseci->rx_queue_info[index].opr;
}

static inline int dpseci_has_cg(struct dpseci *dpseci)
{
	return (int)(dpseci->options & DPSECI_OPT_HAS_CG);
}

static int resources_allocation(struct dpseci *dpseci)
{
	int tmp1[32] = { 0 };
	int tmp2[32] = { 0 };
	int err, j;

	CHECK_COND_RETVAL(dpseci, -EINVAL);

	/* FQIDs */
	if ((err = allocate_resource(dpseci->device, "fq", dpseci->num_tx_queues,
					1, 0, &(tmp1[0]), "DPSECI-Q"))
		!= 0)
		return err;

	if ((err = allocate_resource(dpseci->device, "fq", dpseci->num_rx_queues,
					0, 0, &(tmp2[0]), "DPSECI-Q"))
		!= 0)
		return err;

	for (j = 0; j < dpseci->num_tx_queues; j++)
		dpseci->tx_queue_info[j].tx_fqid = (uint32_t)tmp1[j];
	for (j = 0; j < dpseci->num_rx_queues; j++)
		dpseci->rx_queue_info[j].rx_fqid = (uint32_t)tmp2[j];

	/* CGIDs */
	if (dpseci_has_cg(dpseci)) {
		err = allocate_resource(dpseci->device, "cg", 1, 0, 0,
				&(dpseci->cg_info.cgid), "DPSECI-CG");
		CHECK_COND_RETVAL(err == 0, err, "ID[%d]: CG allocation failed\n", dpseci->id);
	}

	if (dpseci_has_opr(dpseci)) {	
		for (j = 0; j < max_index_for_opr(dpseci); j++) {
			err = allocate_resource(dpseci->device, OPR_RES_TYPE_STR, 1, 1, 0, 
					&(get_opr_info(dpseci, (uint8_t)j)->id), OPR_ERR_STR);
			CHECK_COND_RETVAL(err == 0, err, "ID[%d]: OPR resource allocation failed\n", dpseci->id);
		}
	}

	return 0;
}

static int resources_deallocation(struct dpseci *dpseci)
{
	CHECK_COND_RETVAL(dpseci, -EINVAL);

	return resman_unbind_all(dpseci->device);
}

static int cg_authorization_configuration(struct dpseci *dpseci,
	int cgid,
	uint32_t *virt_cgid)
{
	struct qbman_swp *sw_portal = NULL;
	struct qbman_attr attr;
	int err;

	CHECK_COND_RETVAL(dpseci_has_cg(dpseci), -EINVAL);
	CHECK_COND_RETVAL(dpseci, -ENODEV);
	CHECK_COND_RETVAL(cgid >= 0, -EINVAL);
	CHECK_COND_RETVAL(virt_cgid != NULL, -EINVAL);

	dpmng_get_swportal(dpseci->dpmng, (void **)&sw_portal);

	err = resource_authorization(sw_portal, dpseci->amq.bdi,
					dpseci->amq.icid,
					qbman_auth_type_cgid, virt_cgid,
					(uint32_t)cgid, QBMAN_AUTH_SWP, "CGID");
	if (!err) {
		err = qbman_cgr_query(sw_portal, (uint32_t)cgid, &attr);
		if (!err) {
			qbman_cgr_attr_set_cscn_vcgid(&attr, *virt_cgid, dpseci->amq.bdi);
			qbman_cgr_attr_set_cg_icid(&attr, dpseci->amq.icid,
					dpseci->amq.pl, dpseci->amq.va);
			err = qbman_cgr_configure(sw_portal, (uint32_t)cgid, &attr);
		}
	}

	dpmng_put_swportal(dpseci->dpmng, (void *)sw_portal);
	return err;
}

static int resources_authorization(struct dpseci *dpseci)
{
	struct qbman_swp *sw_portal = NULL;
	int i, err;

	CHECK_COND_RETVAL(dpseci, -EINVAL);

	if (dpseci->authorized)
		return 0;

	dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);

	/* FQIDs */
	for (i = 0; i < dpseci->num_tx_queues; i++) {
		if ((err = resource_authorization(
			sw_portal, dpseci->amq.bdi, dpseci->amq.icid,
			qbman_auth_type_fqid,
			&dpseci->tx_queue_info[i].tx_virt_fqid,
			dpseci->tx_queue_info[i].tx_fqid,
			(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-FQID"))
			!= 0) {
			dpmng_put_swportal(dpseci->dpmng, sw_portal);
			return err;
		}
	}

	for (i = 0; i < dpseci->num_rx_queues; i++) {
		if ((err = resource_authorization(
			sw_portal, dpseci->amq.bdi, dpseci->amq.icid,
			qbman_auth_type_fqid,
			&dpseci->rx_queue_info[i].rx_virt_fqid,
			dpseci->rx_queue_info[i].rx_fqid,
			(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-FQID"))
			!= 0) {
			dpmng_put_swportal(dpseci->dpmng, sw_portal);
			return err;
		}
	}

	/* Congestion Group */
	if (dpseci_has_cg(dpseci)) {
		err = cg_authorization_configuration(dpseci, dpseci->cg_info.cgid,
				&dpseci->cg_info.virt_cgid);
		if (err) {
			dpmng_put_swportal(dpseci->dpmng, sw_portal);
			return err;
		}
	}

	if (dpseci_has_opr(dpseci)) {			
		for (i = 0; i < max_index_for_opr(dpseci); i++) {
			err = auth_oprid(sw_portal, dpseci->amq.bdi, dpseci->amq.icid,
					get_opr_info(dpseci, (uint8_t)i));
			if (err) {
				dpmng_put_swportal(dpseci->dpmng, sw_portal);
				return err;
			}
		}
	}
	
	dpseci->authorized = 1;

	return 0;
}

static int resources_deauthorization(struct dpseci *dpseci)
{
	struct qbman_swp *sw_portal = NULL;
	int i, err;

	CHECK_COND_RETVAL(dpseci, -EINVAL);

	if (!dpseci->authorized)
		return 0;

	dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);
	for (i = 0; i < dpseci->num_tx_queues; i++) {
		/* FQIDs */
		if ((err = resource_deauthorization(
			sw_portal, dpseci->amq.bdi, dpseci->amq.icid,
			qbman_auth_type_fqid,
			dpseci->tx_queue_info[i].tx_virt_fqid,
			(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-FQID"))
			!= 0) {
			dpmng_put_swportal(dpseci->dpmng, sw_portal);
			return err;
		}
	}

	for (i = 0; i < dpseci->num_rx_queues; i++) {
		if ((err = resource_deauthorization(
			sw_portal, dpseci->amq.bdi, dpseci->amq.icid,
			qbman_auth_type_fqid,
			dpseci->rx_queue_info[i].rx_virt_fqid,
			(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-FQID"))
			!= 0) {
			dpmng_put_swportal(dpseci->dpmng, sw_portal);
			return err;
		}
	}
	
	/* Congestion Group */
	if (dpseci_has_cg(dpseci)) {
		err = resource_deauthorization(
			sw_portal, dpseci->amq.bdi,
			dpseci->amq.icid, qbman_auth_type_cgid,
			dpseci->cg_info.virt_cgid, QBMAN_AUTH_SWP,
			"CGID");
		if (err != 0) {
			dpmng_put_swportal(dpseci->dpmng, (void *)sw_portal);
			return err;
		}
	}

	//OPR
	if (dpseci_has_opr(dpseci)) {
		for (i = 0; i < max_index_for_opr(dpseci); i++) {
			err = deauth_oprid(sw_portal, dpseci->amq.bdi, dpseci->amq.icid,
					get_opr_info(dpseci, (uint8_t)i));
			if (err) {
				dpmng_put_swportal(dpseci->dpmng, (void*)sw_portal);
				return err;
			}
		}
	}
	
	dpmng_put_swportal(dpseci->dpmng, sw_portal);
	dpseci->authorized = 0;
	dpseci->amq.icid = (uint16_t)-1;

	return 0;
}

static inline int check_dest_cfg(struct dpseci *dpseci,
	const struct dpseci_dest_cfg *cfg)
{
	struct dpcon *dpcon;
	struct dpio *dpio;
	int err;

	CHECK_COND_RETVAL(dpseci, -ENODEV);
	CHECK_COND_RETVAL(cfg, -EINVAL);

	switch (cfg->dest_type) {
	case DPSECI_DEST_DPIO:
		dpio = sys_get_handle(FSL_MOD_DPIO, 1, cfg->dest_id);
		CHECK_COND_RETVAL(dpio, -EINVAL);
		err = !dpio_is_priority_in_range(dpio, cfg->priority);
		break;
	case DPSECI_DEST_DPCON:
		dpcon = sys_get_handle(FSL_MOD_DPCON, 1, cfg->dest_id);
		CHECK_COND_RETVAL(dpcon, -EINVAL);
		err = !dpcon_is_priority_in_range(dpcon, cfg->priority);
		break;
	default:
		err = -EINVAL;
		break;
	}
	return err;
}

static inline int get_dest_wq(const struct dpseci_dest_cfg *cfg,
	uint16_t *dest_wqid)
{
	struct dpcon *dpcon;
	struct dpio *dpio;
	int err;

	CHECK_COND_RETVAL(cfg, -EINVAL);
	CHECK_COND_RETVAL(dest_wqid, -EINVAL);

	switch (cfg->dest_type) {
	case DPSECI_DEST_DPIO:
		dpio = sys_get_handle(FSL_MOD_DPIO, 1, cfg->dest_id);
		CHECK_COND_RETVAL(dpio, -EINVAL);
		err = dpio_get_destwq(dpio, cfg->priority, dest_wqid);
		break;
	case DPSECI_DEST_DPCON:
		dpcon = sys_get_handle(FSL_MOD_DPCON, 1, cfg->dest_id);
		CHECK_COND_RETVAL(dpcon, -EINVAL);
		err = dpcon_get_destwq(dpcon, cfg->priority, dest_wqid);
		break;
	default:
		err = -EINVAL;
		break;
	}
	return err;
}

static int check_congestion_notification(struct dpseci *dpseci,
	const struct dpseci_congestion_notification_cfg *cfg)
{
	int err;

	CHECK_COND_RETVAL(dpseci, -ENODEV);
	CHECK_COND_RETVAL(cfg, -EINVAL);
	CHECK_COND_RETVAL(dpseci_has_cg(dpseci), -EINVAL);

	if ((cfg->notification_mode & DPSECI_CGN_MODE_NOTIFY_DEST_ON_ENTER)
		|| (cfg->notification_mode & DPSECI_CGN_MODE_NOTIFY_DEST_ON_EXIT)) {
		err = check_dest_cfg(dpseci, &cfg->dest_cfg);
		CHECK_COND_RETVAL(err == 0, err);
	}

	if (((cfg->notification_mode & DPSECI_CGN_MODE_WRITE_MEM_ON_ENTER)
		|| (cfg->notification_mode & DPSECI_CGN_MODE_WRITE_MEM_ON_EXIT))
		&& !IS_ALIGNED(cfg->message_iova, 16)) {
		pr_err("ID[%d]: message_iova must be 16B aligned\n", dpseci->id);
		return -EINVAL;
	}
	return 0;
}

static int congestion_notification_fill(
	const struct dpseci_congestion_notification_cfg *cfg,
	struct qbman_attr *cgr_desc,
	int reset)
{
	uint16_t destwq;
	int err;

	CHECK_COND_RETVAL(cfg, -EINVAL);
	CHECK_COND_RETVAL(cgr_desc, -EINVAL);

	/* clear old settings */
	qbman_cgr_attr_set_cs_thres(cgr_desc, 0);
	qbman_cgr_attr_set_cs_thres_x(cgr_desc, 0);
	qbman_cgr_attr_set_cscn_wq_ctrl(cgr_desc, 0, 0, 0);
	qbman_cgr_attr_set_cscn_wqid(cgr_desc, 0);
	qbman_cgr_attr_set_cscn_in_memory(cgr_desc, 0, 0, 0, 0);
	qbman_cgr_attr_set_cscn_ctx(cgr_desc, 0);

	if (reset)
		return 0;

	qbman_cgr_attr_set_mode(cgr_desc, cfg->units, 0);
	qbman_cgr_attr_set_cs_thres(cgr_desc, cfg->threshold_entry);
	qbman_cgr_attr_set_cs_thres_x(cgr_desc, cfg->threshold_exit);

	if (cfg->dest_cfg.dest_type != DPSECI_DEST_NONE) {
		qbman_cgr_attr_set_cscn_wq_ctrl(
			cgr_desc,
			(cfg->notification_mode & DPSECI_CGN_MODE_NOTIFY_DEST_ON_ENTER) ?
				1 : 0,
			(cfg->notification_mode & DPSECI_CGN_MODE_NOTIFY_DEST_ON_EXIT) ?
				1 : 0,
			(cfg->notification_mode & DPSECI_CGN_MODE_INTR_COALESCING_DISABLED) ?
				1 : 0);
		err = get_dest_wq(&cfg->dest_cfg, &destwq);
		CHECK_COND_RETVAL(err == 0, err);
		qbman_cgr_attr_set_cscn_wqid(cgr_desc, (uint32_t)destwq);
	}

	qbman_cgr_attr_set_cscn_in_memory(
		cgr_desc,
		(cfg->notification_mode & DPSECI_CGN_MODE_WRITE_MEM_ON_ENTER) ? 1 : 0,
		(cfg->notification_mode & DPSECI_CGN_MODE_WRITE_MEM_ON_EXIT) ? 1 : 0,
		cfg->message_iova,
		(cfg->notification_mode & DPSECI_CGN_MODE_COHERENT_WRITE) ? 1 : 0);
	qbman_cgr_attr_set_cscn_ctx(cgr_desc, cfg->message_ctx);

	return 0;
}

/*
 * Queues that were already connected to destination, we only want to
 * enable/disable queues by disable/enable CG
 */
static int queues_set_rejection_mode(struct dpseci *dpseci,
	uint8_t queue,
	int en)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	uint32_t fqctrl, cgid;
	int err;

	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(queue < dpseci->num_tx_queues, -EINVAL);

	cgid = (uint32_t)dpmng_get_cgid(dpseci->dpmng);

	dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);

	/* TX-FQID*/
	qbman_fq_attr_clear(&fqdesc);
	err = qbman_fq_query(sw_portal,
				dpseci->tx_queue_info[queue].tx_fqid,
				&fqdesc);
	if (err != 0) {
		pr_err("queues_set_rejection_mode failed\n");
		dpmng_put_swportal(dpseci->dpmng, sw_portal);
		return err;
	}

	qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
	if (!en) {
		if (dpseci->tx_queue_info[queue].cgid_en) {
			cgid = (uint32_t)dpseci->cg_info.cgid;
		} else {
			fqctrl &= ~QBMAN_FQCTRL_CGR;
			cgid = 0;
		}
	} else
		fqctrl |= QBMAN_FQCTRL_CGR;

	qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);
	qbman_fq_attr_set_cgrid(&fqdesc, cgid);

	err = qbman_fq_configure(
		sw_portal, dpseci->tx_queue_info[queue].tx_fqid, &fqdesc);
	if (err != 0) {
		pr_err("queues_set_rejection_mode failed\n");
		dpmng_put_swportal(dpseci->dpmng, sw_portal);
		return err;
	}

	dpmng_put_swportal(dpseci->dpmng, sw_portal);
	return 0;
}

static int config_tx_queue(struct dpseci *dpseci, uint8_t queue)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	struct qbman_attr state;
	uint32_t fqctrl;
	uint16_t wqid_base;
	int err, ps = 0;

	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(queue < dpseci->num_tx_queues, -EINVAL);

	ps = qbman_cacheable_pfdr();
	dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);

	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_ctx(
		&fqdesc, 0,
		(uint32_t)dpseci->rx_queue_info[queue].rx_virt_fqid);
	qbman_fq_attr_set_erfqid(
		&fqdesc, dpseci->rx_queue_info[queue].rx_fqid);
	qbman_fq_attr_set_icid(&fqdesc, dpseci->amq.icid, dpseci->amq.pl);
	qbman_fq_attr_set_mctl(&fqdesc, dpseci->amq.bdi, 0, dpseci->amq.va, ps, 0);
	qbman_fq_attr_set_vfqid(&fqdesc,
				dpseci->tx_queue_info[queue].tx_virt_fqid);

	/* set congestion avoidance */
	if (dpseci->tx_queue_info[queue].cgid_en) {
		qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
		fqctrl |= QBMAN_FQCTRL_CGR;
		qbman_fq_attr_set_cgrid(&fqdesc, (uint32_t)dpseci->cg_info.cgid);
		qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);
	}

	err = qbman_fq_configure(
		sw_portal, dpseci->tx_queue_info[queue].tx_fqid, &fqdesc);
	if (err != 0) {
		pr_err("qbman_fq_configure failed\n");
		dpmng_put_swportal(dpseci->dpmng, sw_portal);
		return err;
	}

	wqid_base = dpmng_get_dcp_wqid(dpseci->dpmng, QBMAN_DCP_SEC, 0);
	qbman_fq_attr_set_destwq(
		&fqdesc,
		(uint32_t)(wqid_base << 3
				| dpseci->tx_queue_info[queue].tx_priority
					- 1));

	err = qbman_fq_configure(
		sw_portal, dpseci->tx_queue_info[queue].tx_fqid, &fqdesc);

	if (err != 0) {
		dpmng_put_swportal(dpseci->dpmng, sw_portal);
		pr_err( "qbman_fq_configure failed\n");
		return err;
	}

	err = qbman_fq_query_state(
		sw_portal, dpseci->tx_queue_info[queue].tx_fqid, &state);
	if (err != 0) {
		dpmng_put_swportal(dpseci->dpmng, sw_portal);
		pr_err("DPSECI ID[%d]: qbman_fq_query failed\n", dpseci->id);
		return err;
	}

	if (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_parked) {
		err = qbman_swp_fq_schedule(
			sw_portal, dpseci->tx_queue_info[queue].tx_fqid);
		if (err != 0) {
			pr_err("qbman_swp_fq_schedule failed\n");
			dpmng_put_swportal(dpseci->dpmng, sw_portal);
			return err;
		}
	}

	dpmng_put_swportal(dpseci->dpmng, sw_portal);

	return 0;
}

static int config_rx_queue(struct dpseci *dpseci, uint8_t queue)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	struct qbman_attr state;
	uint32_t fqctrl;
	int err = 0, ps = 0;

	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(queue < dpseci->num_rx_queues, -EINVAL);

	ps = qbman_cacheable_pfdr();
	dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);

	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_ctx(
		&fqdesc,
		(uint32_t)(dpseci->rx_queue_info[queue].user_ctx >> 32),
		(uint32_t)(dpseci->rx_queue_info[queue].user_ctx));
	qbman_fq_attr_set_icid(&fqdesc, dpseci->amq.icid, dpseci->amq.pl);
	qbman_fq_attr_set_mctl(&fqdesc, dpseci->amq.bdi, 0, dpseci->amq.va, ps, 0);
	qbman_fq_attr_set_vfqid(&fqdesc,
				dpseci->rx_queue_info[queue].rx_virt_fqid);
	qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
	fqctrl |= QBMAN_FQCTRL_STASH;
	if (dpseci->rx_queue_info[queue].order_preservation_en)
		fqctrl |= QBMAN_FQCTRL_HOLDACTIVE;

	/* set congestion avoidance */
	if (dpseci->rx_queue_info[queue].cgid_en) {
		fqctrl |= QBMAN_FQCTRL_CGR;
		qbman_fq_attr_set_cgrid(&fqdesc, (uint32_t)dpseci->cg_info.cgid);
	}
	qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);

	err = qbman_fq_configure(
		sw_portal, dpseci->rx_queue_info[queue].rx_fqid, &fqdesc);
	if (err != 0) {
		pr_err("qbman_fq_configure failed\n");
		dpmng_put_swportal(dpseci->dpmng, sw_portal);
		return err;
	}

	dpmng_put_swportal(dpseci->dpmng, sw_portal);

	if (dpseci->rx_queue_info[queue].rx_dest_cfg.dest_type
		!= DPSECI_DEST_NONE) {
		uint16_t destwq;
		if (dpseci->rx_queue_info[queue].rx_dest_cfg.dest_type
			== DPSECI_DEST_DPIO) {
			struct dpio *dpio =
				sys_get_handle(
					FSL_MOD_DPIO,
					1,
					dpseci->rx_queue_info[queue].rx_dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpio, -ENAVAIL);
			err = dpio_get_destwq(
					dpio,
					dpseci->rx_queue_info[queue].rx_dest_cfg.priority,
					&destwq);
			CHECK_COND_RETVAL(err == 0, err);
			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			qbman_fq_attr_set_fqctrl(
				&fqdesc, fqctrl | QBMAN_FQCTRL_FQDAN);
		} else { /*DPSECI_DPCON */
			struct dpcon *dpcon =
				sys_get_handle(
					FSL_MOD_DPCON,
					1,
					dpseci->rx_queue_info[queue].rx_dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpcon, -ENAVAIL);
			err = dpcon_get_destwq(
					dpcon,
					dpseci->rx_queue_info[queue].rx_dest_cfg.priority,
					&destwq);
			CHECK_COND_RETVAL(err == 0, err);
			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			qbman_fq_attr_set_fqctrl(
				&fqdesc, fqctrl & ~QBMAN_FQCTRL_FQDAN);
		}
		qbman_fq_attr_set_destwq(&fqdesc, destwq);

		dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);
		err = qbman_fq_configure(
			sw_portal, dpseci->rx_queue_info[queue].rx_fqid,
			&fqdesc);
		if (err != 0) {
			dpmng_put_swportal(dpseci->dpmng, sw_portal);
			pr_err("qbman_fq_configure failed\n");
			return err;
		}

		err = qbman_fq_query_state(
			sw_portal, dpseci->rx_queue_info[queue].rx_fqid,
			&state);
		if (err != 0) {
			dpmng_put_swportal(dpseci->dpmng, sw_portal);
			pr_err("DPSECI ID[%d]: qbman_fq_query failed\n", dpseci->id);
			return err;
		}

		if (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_parked) {
			err = qbman_swp_fq_schedule(
				sw_portal,
				dpseci->rx_queue_info[queue].rx_fqid);
			if (err != 0) {
				pr_err("qbman_swp_fq_schedule failed\n");
				dpmng_put_swportal(dpseci->dpmng, sw_portal);
				return err;
			}
		}
		dpmng_put_swportal(dpseci->dpmng, sw_portal);
	}
	return 0;
}

static int queues_configuration(struct dpseci *dpseci)
{
	uint8_t queue;
	int err;

	CHECK_COND_RETVAL(dpseci, -EINVAL);

	for (queue = 0; queue < dpseci->num_tx_queues; queue++) {
		if ((err = config_tx_queue(dpseci, queue)) != 0) {
			return err;
		}
	}
	for (queue = 0; queue < dpseci->num_rx_queues; queue++) {
				if ((err = config_rx_queue(dpseci, queue)) != 0) {
			return err;
		}
	}
	return 0;
}

static int clear_rx_fqid(struct dpseci *dpseci,
	struct dpseci_rx_queue_info *rx_queue_info)
{
	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(rx_queue_info, -EINVAL);

	if (!rx_queue_info->retire_storage)
		rx_queue_info->retire_storage =
			(struct qbman_result *)fsl_xmalloc(
				sizeof(struct qbman_result), 0, 64);
	CHECK_COND_RETVAL(rx_queue_info->retire_storage, -ENOMEM);

	dpmng_clear_fqid(rx_queue_info->rx_fqid,
				rx_queue_info->retire_storage,
				&rx_queue_info->retire_pending);

	if (rx_queue_info->retire_pending == 1)
		return 0;

	rx_queue_info->user_ctx = 0;
	memset(&rx_queue_info->rx_dest_cfg, 0, sizeof(struct dpseci_dest_cfg));

	return 0;
}

static int clear_tx_fqid(struct dpseci *dpseci,
	struct dpseci_tx_queue_info *tx_queue_info)
{
	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(tx_queue_info, -EINVAL);

	if (!tx_queue_info->retire_storage)
		tx_queue_info->retire_storage =
			(struct qbman_result *)fsl_xmalloc(
				sizeof(struct qbman_result), 0, 64);
	CHECK_COND_RETVAL(tx_queue_info->retire_storage, -ENOMEM);

	 dpmng_clear_fqid(tx_queue_info->tx_fqid,
				tx_queue_info->retire_storage,
				&tx_queue_info->retire_pending);

	if (tx_queue_info->retire_pending == 1)
		return 0;

	return 0;
}

static int clear_queues(struct dpseci *dpseci)
{
	struct qbman_swp *sw_portal;
	int i;

	CHECK_COND_RETVAL(dpseci, -EINVAL);

	dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);
	for (i = 0; i < dpseci->num_tx_queues; i++)
		clear_tx_fqid(dpseci, &dpseci->tx_queue_info[i]);
	for (i = 0; i < dpseci->num_rx_queues; i++)
		clear_rx_fqid(dpseci, &dpseci->rx_queue_info[i]);

	dpmng_put_swportal(dpseci->dpmng, sw_portal);

	return 0;
}

static int drain_rx_queue(struct dpseci *dpseci, uint32_t queue)
{
	struct qbman_swp *swp;
	struct qbman_pull_desc pulldesc;
	const struct qbman_result *dq_storage = NULL;
	int err, timeout = DPSECI_RESET_TIMEOUT, found = 0;
	struct qbman_fd fd_dq;
	const struct qbman_fd *__fd;
	struct qbman_attr state;
	uint32_t fqid;

	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(queue < dpseci->num_tx_queues, -EINVAL);

	fqid = dpseci->rx_queue_info[queue].rx_fqid;
	
	dpmng_get_swportal(dpseci->dpmng, (void **)&swp);
	err = qbman_fq_query_state(swp, fqid, &state);
	dpmng_put_swportal(dpseci->dpmng, (void *)swp);
	if (err) {
		pr_err("DPSECI ID[%d]: qbman_fq_query failed\n", dpseci->id);
		return err;
	}
	if (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_oos) {
		pr_warn("DPSECI ID[%d]: queue can't be emptied\n", dpseci->id);
		return 0;
	}

	/* Drain FQ */
	dpmng_get_swportal(dpseci->dpmng, (void **)&swp);
	do {
		qbman_pull_desc_clear(&pulldesc);
		qbman_pull_desc_set_storage(&pulldesc, NULL, 0, 0);
		qbman_pull_desc_set_numframes(&pulldesc, 1);
		qbman_pull_desc_set_token(&pulldesc, 0xab);
		qbman_pull_desc_set_fq(&pulldesc, fqid);
		err = qbman_swp_pull(swp, &pulldesc);
		if (err) {
			dpmng_put_swportal(dpseci->dpmng, swp);
			return err;
		}

		dq_storage = qbman_swp_dqrr_next(swp);
		if (!dq_storage)
			break;

		if (!qbman_result_is_DQ(dq_storage)) {
			dpmng_put_swportal(dpseci->dpmng, swp);
			pr_err("DPSECI ID[%d]: QBMAN dequeue result not valid %d\n",
					dpseci->id);
			return -EFAULT;
		}

		/* check response FD for flush command on RX queue */
		if (!found && (qbman_result_DQ_flags(dq_storage)
			 & QBMAN_DQ_STAT_VALIDFRAME)) {
			__fd = qbman_result_DQ_fd(dq_storage);
			memcpy((uint8_t *)&fd_dq, (uint8_t *)__fd,
				sizeof(struct qbman_fd));
			if ((fd_dq.simple.frc == 0x50000020) && !fd_dq.simple.ctrl
				&& !fd_dq.simple.flc_lo && !fd_dq.simple.flc_hi ) {
				found = 1;
				qbman_swp_dqrr_consume(swp, dq_storage);
				break;
			}
			timeout = DPSECI_RESET_TIMEOUT;
		}
		qbman_swp_dqrr_consume(swp, dq_storage);
	} while (!(qbman_result_DQ_flags(dq_storage) & QBMAN_DQ_STAT_FQEMPTY)
			&& --timeout);

	dpmng_put_swportal(dpseci->dpmng, (void *)swp);

	if (!timeout) {
		pr_warn("DPSECI ID[%d]: Timeout when emptying queue %d\n",
			dpseci->id, fqid);
	}

	if (!found) {
		pr_warn("DPSECI ID[%d]: Flush on queue %d not confirmed\n",
				dpseci->id, fqid);
	}

	return 0;
}

static int flush_sec_tx_queue(struct dpseci *dpseci, uint32_t queue)
{
	struct qbman_swp *swp = NULL;
	struct qbman_fd fd_eq;
	struct qbman_eq_desc eqdesc;
	struct qbman_attr state;
	int err = 0;
	uint32_t fqid = 0;
	
	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(queue < dpseci->num_tx_queues, -EINVAL);
	
	fqid = dpseci->tx_queue_info[queue].tx_fqid;

	dpmng_get_swportal(dpseci->dpmng, (void **)&swp);
	err = qbman_fq_query_state(swp, fqid, &state);
	if (err) {
		dpmng_put_swportal(dpseci->dpmng, swp);
		pr_err("DPSECI ID[%d]: qbman_fq_query failed\n", dpseci->id);
		return err;
	}

	if ((qbman_fq_state_retirement_pending(&state))
		|| (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_retired)
		|| (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_oos)) {
		dpmng_put_swportal(dpseci->dpmng, swp);
		pr_err("DPSECI ID[%d]: TX queue not in valid state\n",
			dpseci->id);
		return -EFAULT;
	}
	
	memset(&fd_eq, 0, sizeof(struct qbman_fd));	
	fd_eq.simple.ctrl |= DPSECI_RESET_FD_CTRL;
	fd_eq.simple.frc |= DPSECI_RESET_FLUSH_Q_ABORT;
	qbman_eq_desc_clear(&eqdesc);
	qbman_eq_desc_set_no_orp(&eqdesc, 0);

	qbman_eq_desc_set_fq(&eqdesc, fqid);


	err = qbman_swp_enqueue(swp, &eqdesc, &fd_eq);
	dpmng_put_swportal(dpseci->dpmng, swp);
	return err;
}

static int flush_sec(struct dpseci *dpseci)
{
	struct qbman_swp *swp = NULL;
	struct qbman_attr state, fqdesc;
	int err, timeout;
	uint32_t fqid;
	uint8_t queue;

	CHECK_COND_RETVAL(dpseci, -EINVAL);

	/* prepare RX queue before sending flush FD */
	for (queue = 0; queue < dpseci->num_rx_queues; queue++) {
		fqid = dpseci->rx_queue_info[queue].rx_fqid;
		dpmng_get_swportal(dpseci->dpmng, (void **)&swp);
		err = qbman_fq_query_state(swp, fqid, &state);
		if (err) {
			dpmng_put_swportal(dpseci->dpmng, swp);
			pr_err("DPSECI ID[%d]: qbman_fq_query_state failed\n", dpseci->id);
			return err;
		}
		if ((qbman_fq_state_retirement_pending(&state))
			|| (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_retired)
			|| (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_oos)) {
			dpmng_put_swportal(dpseci->dpmng, swp);
			pr_warn("DPSECI ID[%d]: RX queue not in valid state\n",
				dpseci->id);
			return 0;
		}

		if (qbman_fq_state_schedstate(&state) != qbman_fq_schedstate_parked) {
			err = qbman_fq_query(swp, fqid, &fqdesc);
			if (err != 0) {
				dpmng_put_swportal(dpseci->dpmng, swp);
				pr_err("ID[%d]: qbman_fq_query failed\n",
					dpseci->id);
				return err;
			}

			qbman_fq_attr_set_destwq(&fqdesc, DPSECI_DEST_NONE);
			err = qbman_fq_configure(swp, fqid, &fqdesc);
			if (err != 0) {
				dpmng_put_swportal(dpseci->dpmng, swp);
				pr_err("qbman_fq_configure failed\n");
				return err;
			}
			timeout = 1000;
			do {
				err = qbman_fq_query_state(swp, fqid, &state);
				if (err) {
					dpmng_put_swportal(dpseci->dpmng, swp);
					pr_err("DPSECI ID[%d]: qbman_fq_query failed\n",
							dpseci->id);
					return err;
				}
				if (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_parked) {
					dpmng_put_swportal(dpseci->dpmng, swp);
					break;
				} else
					timer_udelay(10);
			} while (--timeout);
			if (!timeout) {
				dpmng_put_swportal(dpseci->dpmng, swp);
				pr_warn("DPSECI ID[%d]: set RX queue to parked failed\n",
						dpseci->id);
				return 0;
			}
		}
		dpmng_put_swportal(dpseci->dpmng, swp);
	}

	/* send FD for flush operation */
	for (queue = 0; queue < dpseci->num_tx_queues; queue++) {
		err = flush_sec_tx_queue(dpseci, queue);
		if (!err) {
			/* empty Rx queues */
			err = drain_rx_queue(dpseci, queue); 
			CHECK_COND_RETVAL(err == 0, err);
		} else {
			pr_warn("DPSECI ID[%d]: Could not flush SEC\n", dpseci->id);
			return 0;
		}
	}

	return 0;
}

struct dpseci *dpseci_allocate(void)
{
	struct dpseci *dpseci;

	dpseci = (struct dpseci *)fsl_malloc(sizeof(struct dpseci));
	if (dpseci)
		memset(dpseci, 0, sizeof(struct dpseci));
	return dpseci;
}

void dpseci_deallocate(struct dpseci *dpseci)
{
	fsl_free(dpseci);
}

static void dpseci_set_mc_info(struct dpseci *dpseci,
		       	       const struct dpmng_dev_cfg *dev_cfg)
{
	dpseci->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dpseci->dpmng);

	dpseci->id = dev_cfg->id;
	dpseci->device = dev_cfg->device;
}

int dpseci_set_dev_ctx(struct dpseci *dpseci,
		       const struct dpmng_dev_ctx *dev_ctx)
{
	int err;

	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(dev_ctx, -EINVAL);

	if (memcmp(&dpseci->amq, &(dev_ctx->amq), sizeof(struct dpmng_amq)) != 0) {
		CHECK_COND_RETVAL(!dpseci->en, -EINVAL);
		if ((err = resources_deauthorization(dpseci)) != 0) {
			pr_err("ID[%d]: resources_deauthorization failed \n", dpseci->id);
			return err;
		}

		dpseci->amq = dev_ctx->amq;

		//TODO - handle this better (update on assign)
		dpseci->amq.bdi =
			(dev_ctx->type == DPMNG_CTX_TYPE_AIOP) ? 1 : 0;

		if ((err = resources_authorization(dpseci)) != 0) {
			pr_err("ID[%d]: resources_authorization failed \n", dpseci->id);
			return err;
		}
	}

	if ((err = queues_configuration(dpseci)) != 0) {
		pr_err("ID[%d]:  initial_configuration after authorization failed \n", dpseci->id);
		return err;
	}
	return 0;
}

int dpseci_init(struct dpseci *dpseci,
		const struct dpseci_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg)
{
	int i, err;
	uint8_t queue;
	struct qbman_swp *sw_portal;

	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(cfg, -EINVAL);
	CHECK_COND_RETVAL(dev_cfg, -EINVAL);

	dpseci_set_mc_info(dpseci, dev_cfg);

	if (!cfg->priorities[0]) {
		pr_err("Priorities were not configured for DPSECI\n");
		return -EINVAL;
	}
	
	//Copy options
	dpseci->options = cfg->options;

	/* temp - backward compatibility, if API without num_rx_queues is used
	 * count the number of priorities configured in the array
	 */
	if(cfg->num_rx_queues == 0 && cfg->num_tx_queues == 0){
		for (i = 0; i < DPSECI_MAX_QUEUE_NUM; i++) {
			if (cfg->priorities[i]) {
				if (i == DPSECI_MAX_SOC_QUEUE_NUM) {
					pr_err("Too many priorities provided, SoC supports at most %d queues\n",
					       DPSECI_MAX_SOC_QUEUE_NUM);
					return -EINVAL;
				}

				if (!IN_RANGE(1, cfg->priorities[i], 8)) {
					pr_err("Priority (%d) not in valid range (1-8)\n",
							cfg->priorities[i]);
					return -EINVAL;
				}

				dpseci->num_tx_queues++;
				dpseci->tx_queue_info[i].tx_priority = cfg->priorities[i];
			}
			else
				break;
		}
		dpseci->num_rx_queues =	dpseci->num_tx_queues;
	}
	else if(cfg->num_tx_queues != cfg->num_rx_queues) //tmp
	{
		pr_err("Dpseci num_tx_queues must be equal to num_rx_queues \n");
			return -EINVAL;
	}
	else
	{
		if(cfg->num_tx_queues > DPSECI_MAX_SOC_QUEUE_NUM)
		{
			pr_err("Dpseci num_tx_queues must be equal or smaller than maximum number of TX queues: %d  \n", DPSECI_MAX_SOC_QUEUE_NUM);
			return -EINVAL;
		}
#if 0
		if(cfg->num_rx_queues > DPSECI_MAX_SOC_QUEUE_NUM)
		{
			pr_err("Dpseci num_rx_queues must be equal or smaller than maximum number of RX queues: %d  \n", DPSECI_MAX_SOC_QUEUE_NUM);
			return -EINVAL;
		}
#endif
		dpseci->num_tx_queues = cfg->num_tx_queues;
		for (i = 0; i < dpseci->num_tx_queues; i++)
			dpseci->tx_queue_info[i].tx_priority =
							cfg->priorities[i];

		dpseci->num_rx_queues = cfg->num_rx_queues;
	}

	if ((err = resources_allocation(dpseci)) != 0) {
		resources_deallocation(dpseci);
		pr_err("resources_allocation failed\n");
		return err;
	}

	dpseci->amq.icid = (uint16_t)-1;

	err = queues_configuration(dpseci);
	if (err != 0) {
		pr_err("ID[%d]: queues_configuration failed\n", dpseci->id);
		dpseci_destroy(dpseci);
		return err;
	}

	for (i = 0; i < dpseci->num_tx_queues; i++) {
		err = queues_set_rejection_mode(dpseci, (uint8_t)i, 1);
		CHECK_COND_RETVAL(err == 0, -EFAULT);
	}
	
	for (i = 0; i < DPSECI_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpseci->irqs[i]), MC_IRQ_TYPE_MSI);
	
	if (dpseci_has_opr(dpseci)) {
		dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);
		//Create OPRs
		for (queue = 0; queue < max_index_for_opr(dpseci); queue++) {
			//Create the OPR entries
			err = create_opr(sw_portal,	get_opr_info(dpseci, queue), 0);
			if (err != 0) {
				dpmng_put_swportal(dpseci->dpmng, (void*)sw_portal);
				return err;
			}
		}
		
		for (queue = 0; queue < dpseci->num_rx_queues; queue++) {
			/* Adding/remove ORP support for queue */
			err = config_orp_fq(sw_portal, (int)dpseci->rx_queue_info[queue].rx_fqid,
					get_opr_info(dpseci, queue));
			if (err != 0) {
				dpmng_put_swportal(dpseci->dpmng, (void*)sw_portal);
				return err;
			}
		}
	}
	
	return 0;
}

int dpseci_destroy(struct dpseci *dpseci)
{
	int err;
	uint8_t queue;
	struct qbman_swp *sw_portal;

	CHECK_COND_RETVAL(dpseci, -EINVAL);

	if (dpseci->en) {
		if ((err = dpseci_disable(dpseci)) != 0) {
			pr_err("dpseci_disable failed\n");
			return err;
		}
	}

	err = resources_deauthorization(dpseci);
	CHECK_COND_RETVAL(err == 0, err);
	err = clear_queues(dpseci);
	CHECK_COND_RETVAL(err == 0, err);
	for (queue = 0; queue < dpseci->num_tx_queues; queue++)
		dpseci->tx_queue_info[queue].tx_virt_fqid = 0;
	for (queue = 0; queue < dpseci->num_rx_queues; queue++)
	{
		memset(&dpseci->rx_queue_info[queue].rx_dest_cfg,
				0, sizeof(struct dpseci_dest_cfg));
		dpseci->rx_queue_info[queue].rx_virt_fqid = 0;
	}
	
	//Retire OPRs
	if (dpseci_has_opr(dpseci)) {
		err = dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);
		for (queue = 0; queue < max_index_for_opr(dpseci); queue++) {
			err = retire_opr(sw_portal, get_opr_info(dpseci, queue));
			if (err != 0) {
				dpmng_put_swportal(dpseci->dpmng, &sw_portal);
				return err;
			}
		}

		dpmng_put_swportal(dpseci->dpmng, &sw_portal);
	}
	
	err = resources_deallocation(dpseci);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpseci_enable(struct dpseci *dpseci)
{
	int err;
	uint8_t queue;

	CHECK_COND_RETVAL(dpseci, -EINVAL);

	for (queue = 0; queue < dpseci->num_tx_queues; queue++) {
		err = queues_set_rejection_mode(dpseci, queue, 0);
		CHECK_COND_RETVAL(err == 0, -EFAULT);
	}
	dpseci->en = 1;
	
	//Create opr and set queues
	if (dpseci_has_opr(dpseci)) {
#if 0
		struct qbman_swp *sw_portal;
		dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);
		//Create OPRs
		for (queue = 0; queue < max_index_for_opr(dpseci); queue++) {
			//Create the OPR entries
			err = create_opr(sw_portal,	get_opr_info(dpseci, queue), 0);
			if (err != 0) {
				dpmng_put_swportal(dpseci->dpmng, (void*)sw_portal);
				return err;
			}
		}

		for (queue = 0; queue < dpseci->num_rx_queues; queue++) {
			/* Adding/remove ORP support for queue */
			err = config_orp_fq(sw_portal, (int)dpseci->rx_queue_info[queue].rx_fqid,
					get_opr_info(dpseci, queue));
			if (err != 0) {
				dpmng_put_swportal(dpseci->dpmng, (void*)sw_portal);
				return err;
			}
		}
#endif		
	}

	return 0;
}

int dpseci_disable(struct dpseci *dpseci)
{
	uint8_t queue;
	int err;

	CHECK_COND_RETVAL(dpseci, -EINVAL);

	for (queue = 0; queue < dpseci->num_tx_queues; queue++) {
		err = queues_set_rejection_mode(dpseci, queue, 1);
		CHECK_COND_RETVAL(err == 0, -EFAULT);
	}
	dpseci->en = 0;

	return 0;
}

int dpseci_is_enabled(struct dpseci *dpseci, int *en)
{
	CHECK_COND_RETVAL(dpseci, -EINVAL);

	if (dpseci->en == 1)
		*en = 1;
	else
		*en = 0;

	return 0;
}

int dpseci_get_rx_queue(struct dpseci *dpseci,
	uint8_t queue,
	struct dpseci_rx_queue_attr *attr)
{
	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(attr, -EINVAL);

	if (queue >= dpseci->num_rx_queues) {
		pr_err("queue index not in range\n");
		return -EINVAL;
	}

	attr->fqid = dpseci->rx_queue_info[queue].rx_virt_fqid;
	attr->user_ctx = dpseci->rx_queue_info[queue].user_ctx;
	attr->order_preservation_en = dpseci->rx_queue_info[queue].order_preservation_en;
	memcpy(&attr->dest_cfg, &dpseci->rx_queue_info[queue].rx_dest_cfg,
		sizeof(struct dpseci_dest_cfg));

	return 0;
}

int dpseci_get_tx_queue(struct dpseci *dpseci,
	uint8_t queue,
	struct dpseci_tx_queue_attr *attr)
{
	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(attr, -EINVAL);

	if (queue >= dpseci->num_tx_queues) {
		pr_err("queue index not in range\n");
		return -EINVAL;
	}

	attr->fqid = dpseci->tx_queue_info[queue].tx_virt_fqid;
	attr->priority = dpseci->tx_queue_info[queue].tx_priority;

	return 0;
}

static int sanity_dpseci_set_rx_queue(struct dpseci *dpseci,
		uint8_t queue,
		const struct dpseci_rx_queue_cfg *cfg)
{
	if (queue != DPSECI_ALL_QUEUES
		&& queue >= dpseci->num_rx_queues) {
		pr_err("queue index not in range\n");
		return -EINVAL;
	}

	if (!cfg->options)
		return 0;

	if (cfg->options & DPSECI_QUEUE_OPT_DEST) {
		if (cfg->dest_cfg.dest_type == DPSECI_DEST_DPCON) {
			struct dpcon *dpcon = sys_get_handle(
				FSL_MOD_DPCON, 1, cfg->dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpcon, -EINVAL, "dpcon_id is invalid\n");
			if (!dpcon_is_priority_in_range(
				dpcon, cfg->dest_cfg.priority)) {
				pr_err("dpcon priority not in range\n");
				return -EINVAL;
			}
		}

		if (cfg->dest_cfg.dest_type == DPSECI_DEST_DPIO) {
			struct dpio *dpio = sys_get_handle(
				FSL_MOD_DPIO, 1, cfg->dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpio, -EINVAL, "dpio_id is invalid\n");
			if (!dpio_is_priority_in_range(
				dpio, cfg->dest_cfg.priority)) {
				pr_err("priority not in range\n");
				return -EINVAL;
			}
		}
	}
	return 0;

}

int dpseci_set_rx_queue(struct dpseci *dpseci,
	uint8_t queue,
	const struct dpseci_rx_queue_cfg *cfg)
{
	uint8_t i, j, k;
	int err;

	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(cfg, -EINVAL);

	err = sanity_dpseci_set_rx_queue(dpseci, queue, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	if (!cfg->options)
			return 0;

	if (queue == DPSECI_ALL_QUEUES) {
		i = 0;
		j = dpseci->num_rx_queues;
	} else {
		i = queue;
		j = queue + 1;
	}

	k = i;
	if(cfg->options & DPSECI_QUEUE_OPT_DEST && cfg->dest_cfg.dest_type == DPSECI_DEST_NONE)
	{
		for (; k < j; k++) {
			if (dpseci->rx_queue_info[k].rx_dest_cfg.dest_type != DPSECI_DEST_NONE) {
				clear_rx_fqid(dpseci, &dpseci->rx_queue_info[k]);
				if (dpseci->rx_queue_info[k].retire_pending)
					return -ENOTSUP;
			}
		}
	}

	for (; i < j; i++) {
		if (cfg->options & DPSECI_QUEUE_OPT_USER_CTX)
			dpseci->rx_queue_info[i].user_ctx = cfg->user_ctx;

		if (cfg->options & DPSECI_QUEUE_OPT_DEST)
			memcpy(&dpseci->rx_queue_info[i].rx_dest_cfg,
				&(cfg->dest_cfg),
				sizeof(struct dpseci_dest_cfg));

		if (cfg->options & DPSECI_QUEUE_OPT_ORDER_PRESERVATION)
			dpseci->rx_queue_info[i].order_preservation_en =
				cfg->order_preservation_en;

		err = config_rx_queue(dpseci, i);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return 0;
}

int dpseci_get_sec_attr(struct dpseci *dpseci,
	struct dpseci_sec_attr *attr)
{
	struct caam_attr caam_attr;
	struct sec_desc desc;
	int		err, iter = 0;

	CHECK_COND_RETVAL(attr, -EINVAL);
	UNUSED(dpseci);

	err = sys_get_desc(SOC_MODULE_SEC, 0, &desc, &iter);
	CHECK_COND_RETVAL(err == 0, err);
	
	err = caam_get_attributes(&desc, &caam_attr);
	CHECK_COND_RETVAL(err == 0, err);

	attr->ip_id 			= caam_attr.ip_id;
	attr->major_rev 		= caam_attr.major_rev;
	attr->minor_rev 		= caam_attr.minor_rev;
	attr->era 				= caam_attr.era;
	attr->deco_num 			= caam_attr.deco_num;
	attr->zuc_auth_acc_num 	= caam_attr.zuc_auth_acc_num;
	attr->zuc_enc_acc_num 	= caam_attr.zuc_enc_acc_num;
	attr->snow_f8_acc_num 	= caam_attr.snow_f8_acc_num;
	attr->snow_f9_acc_num 	= caam_attr.snow_f9_acc_num;
	attr->crc_acc_num 		= caam_attr.crc_acc_num;
	attr->pk_acc_num 		= caam_attr.pk_acc_num;
	attr->kasumi_acc_num 	= caam_attr.kasumi_acc_num;
	attr->rng_acc_num 		= caam_attr.rng_acc_num;
	attr->md_acc_num 		= caam_attr.md_acc_num;
	attr->arc4_acc_num		= caam_attr.arc4_acc_num;
	attr->des_acc_num 		= caam_attr.des_acc_num;
	attr->aes_acc_num 		= caam_attr.aes_acc_num;
	attr->ccha_acc_num 		= caam_attr.ccha_acc_num;
	attr->ptha_acc_num 		= caam_attr.ptha_acc_num;

	return 0;
}

int dpseci_get_sec_counters(struct dpseci *dpseci,
	struct dpseci_sec_counters *counters) 
{
	struct caam_counters	caam_counters;
	struct sec_desc desc;
	int		err, iter = 0;

	CHECK_COND_RETVAL(counters, -EINVAL);

	UNUSED(dpseci);
	err = sys_get_desc(SOC_MODULE_SEC, 0, &desc, &iter);
	CHECK_COND_RETVAL(err == 0, err);

	err = caam_get_counters(&desc, &caam_counters);
	CHECK_COND_RETVAL(err == 0, err);
	
	counters->dequeued_requests = caam_counters.dequeued_requests;
	counters->ob_enc_requests 	= caam_counters.ob_enc_requests;
	counters->ib_dec_requests 	= caam_counters.ib_dec_requests;
	counters->ob_enc_bytes 		= caam_counters.ob_enc_bytes;
	counters->ob_prot_bytes 	= caam_counters.ob_prot_bytes;
	counters->ib_dec_bytes 		= caam_counters.ib_dec_bytes;
	counters->ib_valid_bytes 	= caam_counters.ib_valid_bytes;

	return 0;
}

int dpseci_get_attributes(struct dpseci *dpseci, struct dpseci_attr *attr)
{
	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(attr, -EINVAL);

	attr->id = (int)dpseci->id;
	attr->num_tx_queues = dpseci->num_tx_queues;
	attr->num_rx_queues = dpseci->num_rx_queues;
	attr->options = dpseci->options;

	return 0;
}

int dpseci_reset(struct dpseci *dpseci)
{
	int err = 0;
	uint8_t queue, i;
	struct qbman_swp *sw_portal = NULL;

	CHECK_COND_RETVAL(dpseci, -EINVAL);

	err = resources_deauthorization(dpseci);
	CHECK_COND_RETVAL(err == 0, err);

	err = flush_sec(dpseci);
	CHECK_COND_RETVAL(err == 0, err);

	if (dpseci->en) {
		err = dpseci_disable(dpseci);
		CHECK_COND_RETVAL(err == 0, err);
	}
	
	err = clear_queues(dpseci);
	CHECK_COND_RETVAL(err == 0, err);

	for (queue = 0; queue < dpseci->num_rx_queues; queue++) {
		memset(&dpseci->rx_queue_info[queue].rx_dest_cfg,
			0, sizeof(struct dpseci_dest_cfg));
		dpseci->rx_queue_info[queue].rx_virt_fqid = 0;
	}

	for (queue = 0; queue < dpseci->num_tx_queues; queue++) {
		dpseci->tx_queue_info[queue].tx_virt_fqid = 0;
		if ((err = queues_set_rejection_mode(dpseci, queue, 1))
			!= 0)
			return err;
	}

	if (dpseci_has_opr(dpseci)) {	
		dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);
		for (i = 0; i < max_index_for_opr(dpseci); i++) {
			err = retire_opr(sw_portal, get_opr_info(dpseci, i));
			if (err != 0) {
				dpmng_put_swportal(dpseci->dpmng, &sw_portal);
				return err;
			}
		}
		err = dpmng_put_swportal(dpseci->dpmng, &sw_portal);
	}

	return err;
}

static int set_congestion_notification(struct dpseci *dpseci,
	struct dpseci_cg_info *cg_cfg,
	const struct dpseci_congestion_notification_cfg *cfg)
{
	struct qbman_swp *swp;
	struct qbman_attr cgr_desc;
	uint8_t i;
	int err;

	CHECK_COND_RETVAL(dpseci, -ENODEV);
	CHECK_COND_RETVAL(cfg, -EINVAL);
	CHECK_COND_RETVAL(cg_cfg, -EINVAL);
	CHECK_COND_RETVAL(cfg->threshold_entry != 0, -EINVAL);
	CHECK_COND_RETVAL(dpseci_has_cg(dpseci), -EINVAL);

	err = check_congestion_notification(dpseci, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	dpmng_get_swportal(dpseci->dpmng, (void **)&swp);
	err = qbman_cgr_query(swp, (uint32_t)cg_cfg->cgid, &cgr_desc);
	dpmng_put_swportal(dpseci->dpmng, (void *)swp);
	CHECK_COND_RETVAL(err == 0, err);

	err = congestion_notification_fill(cfg, &cgr_desc, 0);
	CHECK_COND_RETVAL(err == 0, err);

	dpmng_get_swportal(dpseci->dpmng, (void **)&swp);
	err = qbman_cgr_configure(swp, (uint32_t)cg_cfg->cgid, &cgr_desc);
	dpmng_put_swportal(dpseci->dpmng, (void *)swp);
	CHECK_COND_RETVAL(err == 0, err);

	/* Set the CGR on relevant FQIDs */
	for (i = 0; i < dpseci->num_tx_queues; i++) {
		dpseci->tx_queue_info[i].cgid_en = 1;
		config_tx_queue(dpseci, i);
	}

	for (i = 0; i < dpseci->num_rx_queues; i++) {
		dpseci->rx_queue_info[i].cgid_en = 1;
		config_rx_queue(dpseci, i);
	}

	memcpy(&cg_cfg->cg_notify, cfg,
			sizeof(struct dpseci_congestion_notification_cfg));
	return 0;
}

static int clear_congestion_notification(struct dpseci *dpseci,
	struct dpseci_cg_info *cg_cfg,
	const struct dpseci_congestion_notification_cfg *cfg)
{
	struct qbman_swp *swp;
	struct qbman_attr cgr_desc;
	uint8_t i;
	int err;

	CHECK_COND_RETVAL(dpseci, -ENODEV);
	CHECK_COND_RETVAL(cfg, -EINVAL);
	CHECK_COND_RETVAL(cg_cfg, -EINVAL);
	CHECK_COND_RETVAL(cfg->threshold_entry == 0, -EINVAL);
	CHECK_COND_RETVAL(dpseci_has_cg(dpseci), -EINVAL);

	if (cg_cfg->notification_enable) {
		/* Unset the CGR on relevant FQIDs */
		for (i = 0; i < dpseci->num_tx_queues; i++) {
			dpseci->tx_queue_info[i].cgid_en = 0;
			config_tx_queue(dpseci, i);
		}
		for (i = 0; i < dpseci->num_rx_queues; i++) {
			dpseci->rx_queue_info[i].cgid_en = 0;
			config_rx_queue(dpseci, i);
		}
		cg_cfg->notification_enable = 0;

		dpmng_get_swportal(dpseci->dpmng, (void **)&swp);
		err = qbman_cgr_query(swp, (uint32_t)cg_cfg->cgid, &cgr_desc);
		dpmng_put_swportal(dpseci->dpmng, (void *)swp);
		CHECK_COND_RETVAL(err == 0, err);

		err = congestion_notification_fill(cfg, &cgr_desc, 1);
		CHECK_COND_RETVAL(err == 0, err);

		dpmng_get_swportal(dpseci->dpmng, (void **)&swp);
		err = qbman_cgr_configure(swp, (uint32_t)cg_cfg->cgid, &cgr_desc);
		dpmng_put_swportal(dpseci->dpmng, (void *)swp);
		CHECK_COND_RETVAL(err == 0, err);
	}

	memcpy(&cg_cfg->cg_notify, cfg,
			sizeof(struct dpseci_congestion_notification_cfg));
	return 0;
}

int dpseci_set_congestion_notification(struct dpseci *dpseci,
	const struct dpseci_congestion_notification_cfg *cfg)
{
	CHECK_COND_RETVAL(dpseci, -ENODEV);
	CHECK_COND_RETVAL(cfg, -EINVAL);
	CHECK_COND_RETVAL(dpseci_has_cg(dpseci), -EINVAL);

	if (cfg->threshold_entry != 0)
		return set_congestion_notification(dpseci, &dpseci->cg_info, cfg);

	return clear_congestion_notification(dpseci, &dpseci->cg_info, cfg);
}

int dpseci_get_congestion_notification(struct dpseci *dpseci,
	struct dpseci_congestion_notification_cfg *cfg)
{
	CHECK_COND_RETVAL(dpseci, -ENODEV);
	CHECK_COND_RETVAL(cfg, -EINVAL);
	CHECK_COND_RETVAL(dpseci_has_cg(dpseci), -EINVAL);

	memcpy(cfg, &dpseci->cg_info.cg_notify,
		sizeof(struct dpseci_congestion_notification_cfg));

	return 0;
}

int dpseci_set_irq(struct dpseci *dpseci,
		  uint8_t irq_index,
		  const struct mc_irq_cfg *irq_cfg)
{
	UNUSED(irq_index);
	UNUSED(irq_cfg);

	pr_err("ID[%d]: IRQs are not supported\n", dpseci->id);
	return -ENOTSUP;
}

int dpseci_get_irq(struct dpseci *dpseci,
		  uint8_t irq_index,
		  struct mc_irq_cfg *irq_cfg)
{
	UNUSED(irq_index);
	UNUSED(irq_cfg);

	pr_err("ID[%d]: IRQs are not supported\n", dpseci->id);
	return -ENOTSUP;
}

int dpseci_set_irq_enable(struct dpseci *dpseci, uint8_t irq_index, uint8_t en)
{
	UNUSED(irq_index);
	UNUSED(en);

	pr_err("ID[%d]: IRQs are not supported\n", dpseci->id);
	return -ENOTSUP;
}

int dpseci_get_irq_enable(struct dpseci *dpseci, uint8_t irq_index, uint8_t *en)
{
	UNUSED(irq_index);
	UNUSED(en);

	pr_err("ID[%d]: IRQs are not supported\n", dpseci->id);
	return -ENOTSUP;
}

int dpseci_set_irq_mask(struct dpseci *dpseci,
			uint8_t irq_index,
			uint32_t mask)
{
	UNUSED(irq_index);
	UNUSED(mask);

	pr_err("ID[%d]: IRQs are not supported\n", dpseci->id);
	return -ENOTSUP;
}

int dpseci_get_irq_mask(struct dpseci *dpseci,
			uint8_t irq_index,
			uint32_t *mask)
{
	UNUSED(irq_index);
	UNUSED(mask);

	pr_err("ID[%d]: IRQs are not supported\n", dpseci->id);
	return -ENOTSUP;
}

int dpseci_get_irq_status(struct dpseci *dpseci,
			  uint8_t irq_index,
			  uint32_t *status)
{
	UNUSED(irq_index);
	UNUSED(status);

	pr_err("ID[%d]: IRQs are not supported\n", dpseci->id);
	return -ENOTSUP;
}

int dpseci_clear_irq_status(struct dpseci *dpseci,
			    uint8_t irq_index,
			    uint32_t status)
{
	UNUSED(irq_index);
	UNUSED(status);

	pr_err("ID[%d]: IRQs are not supported\n", dpseci->id);
	return -ENOTSUP;
}

int dpseci_set_opr(struct dpseci *dpseci, uint8_t index, uint8_t options, struct opr_cfg *cfg) {
	int err = 0;
	struct qbman_swp *sw_portal = NULL;
	struct opr_info *info = NULL;
	int dpseci_enabled;
	
	CHECK_COND_RETVAL(dpseci_has_opr(dpseci), -EINVAL);

	dpseci_is_enabled(dpseci, &dpseci_enabled);
	CHECK_COND_RETVAL(dpseci_enabled == 0, -EINVAL);
	
	if (!(dpseci->options & DPSECI_OPT_OPR_SHARED)) {
		CHECK_COND_RETVAL( index < dpseci->num_rx_queues, -EINVAL);
	}

	info = get_opr_info(dpseci, index);

	//Check options
	if (options & OPR_OPT_CREATE) {
		
		err = configure_opr(cfg, info);
		CHECK_COND_RETVAL(err == 0, err);
	} else if (options & OPR_OPT_RETIRE) {

		dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);
		err = retire_opr(sw_portal, info);
		dpmng_put_swportal(dpseci->dpmng, (void*)sw_portal);
		
		CHECK_COND_RETVAL(err == 0, err);
	} else {
		pr_err("ID[%d]: Invalid options for OPR\n", dpseci->id);
		return -EINVAL;
	} 

	dpmng_put_swportal(dpseci->dpmng, (void*)sw_portal);
	return err;
}

int dpseci_get_opr(struct dpseci *dpseci, uint8_t index, struct opr_cfg *cfg, struct opr_qry *qry) {
	struct qbman_swp *sw_portal = NULL;
	int err = 0;

	CHECK_COND_RETVAL(dpseci, -EINVAL);
	CHECK_COND_RETVAL(cfg, -EINVAL);
	CHECK_COND_RETVAL(qry, -EINVAL);

	memset(cfg, 0, sizeof(struct opr_cfg));
	memset(qry, 0, sizeof(struct opr_qry));

	if (!(dpseci->options & DPSECI_OPT_OPR_SHARED)) {
		CHECK_COND_RETVAL( index < dpseci->num_rx_queues, -EINVAL);
	}

	dpmng_get_swportal(dpseci->dpmng, (void**)&sw_portal);

	err = query_opr(sw_portal, get_opr_info(dpseci, index), cfg, qry);
	dpmng_put_swportal(dpseci->dpmng, (void*)sw_portal);

	return err;
}
