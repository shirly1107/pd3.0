/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPSECI_CMD_H
#define _DPSECI_CMD_H

/* default version for all dpseci commands */
#define DPSECI_CMD_VER_BASE								CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPSECI_CMD_V0									CMDHDR_CMD_VERSION(0)
#define DPSECI_CMD_V1									CMDHDR_CMD_VERSION(1)
#define DPSECI_CMD_V2									CMDHDR_CMD_VERSION(2)
#define DPSECI_CMD_V3									CMDHDR_CMD_VERSION(3)

/* add your new command version number here
 * Ex:
 * #define DPSECI_CMD_CREATE_VER_1                      MC_CMD_HDR_VERSION(DPSECI_CMD_VER_BASE + 1) or
 * #define DPSECI_CMD_CREATE_VER                        MC_CMD_HDR_VERSION(3)
 */

/* Command IDs */
#define DPSECI_CMD_CODE_CLOSE                              0x800
#define DPSECI_CMD_CODE_OPEN                               0x809
#define DPSECI_CMD_CODE_CREATE                             0x909
#define DPSECI_CMD_CODE_DESTROY                            0x900
#define DPSECI_CMD_CODE_GET_API_VERSION                    0xa09

#define DPSECI_CMD_CODE_ENABLE                             0x002
#define DPSECI_CMD_CODE_DISABLE                            0x003
#define DPSECI_CMD_CODE_GET_ATTR                           0x004
#define DPSECI_CMD_CODE_RESET                              0x005
#define DPSECI_CMD_CODE_IS_ENABLED                         0x006

#define DPSECI_CMD_CODE_SET_IRQ                            0x010
#define DPSECI_CMD_CODE_GET_IRQ                            0x011
#define DPSECI_CMD_CODE_SET_IRQ_ENABLE                     0x012
#define DPSECI_CMD_CODE_GET_IRQ_ENABLE                     0x013
#define DPSECI_CMD_CODE_SET_IRQ_MASK                       0x014
#define DPSECI_CMD_CODE_GET_IRQ_MASK                       0x015
#define DPSECI_CMD_CODE_GET_IRQ_STATUS                     0x016
#define DPSECI_CMD_CODE_CLEAR_IRQ_STATUS                   0x017

#define DPSECI_CMD_CODE_SET_RX_QUEUE                       0x194
#define DPSECI_CMD_CODE_GET_RX_QUEUE                       0x196
#define DPSECI_CMD_CODE_GET_TX_QUEUE                       0x197
#define DPSECI_CMD_CODE_GET_SEC_ATTR                       0x198
#define DPSECI_CMD_CODE_GET_SEC_COUNTERS                   0x199

#define DPSECI_CMD_CODE_SET_OPR         	               0x19A
#define DPSECI_CMD_CODE_GET_OPR			                   0x19B

#define DPSECI_CMD_CODE_SET_CONGESTION_NOTIFICATION        0x170
#define DPSECI_CMD_CODE_GET_CONGESTION_NOTIFICATION        0x171

#endif /* _DPSECI_CMD_H */
