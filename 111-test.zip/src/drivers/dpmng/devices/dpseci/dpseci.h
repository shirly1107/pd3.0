/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpseci.h

 @Description   DPSECI internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPSECI_H
#define __DPSECI_H

#include "fsl_dpseci_mc.h"
#include "kernel/fsl_spinlock.h"
#include "fsl_dptbl.h"
#include "fsl_opr.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPSECI

#define DPSECI_RESET_TIMEOUT 1000
#define DPSECI_RESET_FLUSH_Q_ABORT	0x0B
/* flush FD CTRL - set DD, SC, DROPP,  CBMT, VA */
#define DPSECI_RESET_FD_CTRL	(9201 << 14)

#define DPSECI_MAX_SOC_QUEUE_NUM	SOC_NUM_OF_CORES

struct dpseci_rx_queue_info {
	uint32_t rx_fqid;
	uint32_t rx_virt_fqid;
	int order_preservation_en;
	struct dpseci_dest_cfg rx_dest_cfg;
	uint64_t user_ctx;
	struct opr_info opr;
	int cgid_en;

	int retire_pending;
	struct qbman_result *retire_storage;
};

struct dpseci_tx_queue_info {
	uint8_t tx_priority;
	uint32_t tx_fqid;
	uint32_t tx_virt_fqid;
	int cgid_en;

	int retire_pending;
	struct qbman_result *retire_storage;
};

struct dpseci_cg_info {
	struct dpseci_congestion_notification_cfg cg_notify;
	uint32_t virt_cgid;
	int cgid;
	int notification_enable;
};

struct dpseci {
	/* parameters for run-time (in order to be in cache) */
	uint32_t id;
	int en;
	int authorized;
	spinlock_t lock;
	uint32_t options;
	struct device *device;
	struct dpmng_amq amq;
	struct dpmng *dpmng;
	struct dpseci_rx_queue_info rx_queue_info[DPSECI_MAX_SOC_QUEUE_NUM];
	struct dpseci_tx_queue_info tx_queue_info[DPSECI_MAX_QUEUE_NUM];
	struct dpseci_cg_info cg_info;
	uint8_t num_tx_queues;
	uint8_t num_rx_queues;
	uint8_t sec_if_id;

	uint8_t irq_count;
	struct mc_irq irqs[DPSECI_MAX_IRQ_NUM];
};

#endif /* __DPSECI_H */
