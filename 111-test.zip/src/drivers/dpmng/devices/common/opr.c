/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          opr.c

 @Description   Driver implementation

 Order Point Record common driver functions

 @Cautions      None.
 *//***************************************************************************/
#include "opr.h"
#include "fsl_malloc.h"			/* fsl_malloc */
#include "common/fsl_string.h"			/* memcpy */
#include "fsl_errors.h"				/* errors */
#include "fsl_platform.h"			/* sys_get_handle */
#include "fsl_resman.h"				/* get SWP */
#include "fsl_opr.h"
#include "fsl_timer.h"

int check_opr_cfg (struct opr_cfg *cfg) {
	CHECK_COND_RETVAL(cfg->oprrws <= OPR_MAX_OPRRWS, -EINVAL);
	CHECK_COND_RETVAL(cfg->oloe <= OPR_MAX_OLOE, -EINVAL);
	CHECK_COND_RETVAL(cfg->oeane <= OPR_MAX_OEANE, -EINVAL);
	CHECK_COND_RETVAL(cfg->olws <= OPR_MAX_OLWS, -EINVAL);
	CHECK_COND_RETVAL(cfg->oa <= OPR_MAX_OA, -EINVAL);
	
	return 0;
}

int configure_opr(struct opr_cfg *cfg, struct opr_info *info) {
	int err = 0;
	uint32_t oprc;
	
	CHECK_COND_RETVAL(info != NULL, -EFAULT);
	CHECK_COND_RETVAL(info->state != OPR_ENABLED, -EEXIST);
	
	err = check_opr_cfg(cfg);
	CHECK_COND_RETVAL(err == 0, err);
	
	oprc = 0;
	oprc |= cfg->oprrws << OPR_CONFIG_OPRRWS_O;
	oprc |= cfg->oloe << OPR_CONFIG_OLOE_O;
	oprc |= cfg->oeane << OPR_CONFIG_OEANE_O;
	oprc |= cfg->olws << OPR_CONFIG_OLWS_O;
	oprc |= cfg->oa << OPR_CONFIG_OA_O;
	
	info->cfg = oprc;
	info->state = OPR_SET;
	
	return err;
}

int retire_opr(struct qbman_swp *s, struct opr_info *info) {
	int err = 0;
	struct qbman_attr desc;
	uint32_t rip = 1, timeout = 100;
	
	CHECK_COND_RETVAL(info != NULL, -EFAULT);
	
	if (info->state == OPR_NOT_SET)
		return 0;
	
	if (info->state == OPR_ENABLED) {
		err = qbman_opr_retire(s, (uint16_t)info->id);
		CHECK_COND_RETVAL(err == 0, err);
	}
	
	while (rip && --timeout)
	{
		err = qbman_opr_query(s, (uint16_t)info->id, &desc);
		CHECK_COND_RETVAL(err == 0, err);
	
		qbman_qpr_attr_get_rip(&desc, &rip);
		timer_sleep(5);
	}
	if( rip && timeout==0 ) {
		pr_err("ID[%d] Opr retire timeout\n",info->id);
		return -ETIMEDOUT;
	}
	info->cfg = OPR_NOT_SET;
	info->state = OPR_NOT_SET;
	
	return err;
}

int create_opr(struct qbman_swp *sw_portal, struct opr_info *info, uint32_t en) {
	int err = 0;
	
	CHECK_COND_RETVAL(info != NULL, -EFAULT);
		
	if (info->state == OPR_SET) {
		err = qbman_opr_configure(sw_portal, (uint16_t)info->id, en, info->cfg, (uint16_t)info->vid);
		CHECK_COND_RETVAL(err == 0, err);
		
		if (!en)
			info->state = OPR_CREATED;
		else
			info->state = OPR_ENABLED;
	}

	return err;
}


int query_opr(struct qbman_swp *sw_portal, struct opr_info *info, struct opr_cfg *cfg, struct opr_qry *qry) {
	struct qbman_attr desc;
	int err = 0;
	uint32_t rip, en, orpc, voprid, nesn, ea_hseq, ea_tseq, ndsn, ea_hptr, ea_tptr;
	uint32_t ea_hseq_nlis, ea_tseq_nlis;
	uint32_t oprrws, oa, olws, oeane, oloe;
	
	CHECK_COND_RETVAL(info != NULL, -EFAULT);	
	CHECK_COND_RETVAL(info->state != OPR_NOT_SET, -ENOENT);
	
	if (info->state == OPR_SET) {
		qry->opr_id = (uint16_t)info->id;
		qry->opr_vid = (uint16_t)info->vid;
		return err;
	}
	
	err = qbman_opr_query(sw_portal, (uint16_t)info->id, &desc);
	CHECK_COND_RETVAL(err == 0, err);
	
    qbman_qpr_attr_get_rip(&desc, &rip);
    qbman_qpr_attr_get_en(&desc, &en);
    qbman_qpr_attr_get_orpc(&desc, &orpc);
    qbman_qpr_attr_get_voprid(&desc, &voprid);
	qbman_qpr_attr_get_ea_hptr(&desc, &ea_hptr);
	qbman_qpr_attr_get_ea_tptr(&desc, &ea_tptr);
    qbman_qpr_attr_get_nesn(&desc, &nesn);
    qbman_qpr_attr_get_ea_hseq(&desc, &ea_hseq);
    qbman_qpr_attr_get_ea_hseq_nlis(&desc, &ea_hseq_nlis);
    qbman_qpr_attr_get_ea_tseq(&desc, &ea_tseq);
    qbman_qpr_attr_get_ea_tseq_nlis(&desc, &ea_tseq_nlis);
    qbman_qpr_attr_get_ndsn(&desc, &ndsn);
    
    qry->enable = (char)en;
    qry->rip = (char)rip;
	qry->ndsn = (uint16_t)ndsn;
	qry->nesn = (uint16_t)nesn;
	qry->ea_hseq = (uint16_t)ea_hseq;
	qry->hseq_nlis = (char)ea_hseq_nlis;
	qry->ea_tseq = (uint16_t)ea_tseq;
	qry->tseq_nlis = (char)ea_tseq_nlis;
	qry->ea_tptr = (uint16_t)ea_tptr;
	qry->ea_hptr = (uint16_t)ea_hptr;
	qry->opr_id = (uint16_t)info->id;
	qry->opr_vid = (uint16_t)voprid;
	
	qbman_qpr_attr_get_oprrws(&desc, &oprrws);
	qbman_qpr_attr_get_oa(&desc, &oa);
	qbman_qpr_attr_get_olws(&desc, &olws);
	qbman_qpr_attr_get_oeane(&desc, &oeane);
	qbman_qpr_attr_get_oloe(&desc, &oloe);
	
	cfg->oprrws = (uint8_t)oprrws;
	cfg->oa = (uint8_t)oa;
	cfg->olws = (uint8_t)olws;
	cfg->oeane = (uint8_t)oeane;
	cfg->oloe = (uint8_t)oloe;
	
	return err;
}

int auth_oprid(struct qbman_swp *sw_portal, int bdi, uint16_t icid, struct opr_info *info)
{
    int err = 0;
    
    CHECK_COND_RETVAL(info != NULL, -EFAULT);
    
	err = resource_authorization(
			sw_portal, bdi, icid,
			qbman_auth_type_orpid, &info->vid, info->id,
			(QBMAN_AUTH_SWP), "OPRID");
	
    return err;
}

int deauth_oprid(struct qbman_swp *sw_portal, int bdi, uint16_t icid, struct opr_info *info)
{
    int err = 0;
    
    CHECK_COND_RETVAL(info != NULL, -EFAULT);
	
	err = resource_deauthorization(
			sw_portal, bdi, icid,
			qbman_auth_type_orpid, info->vid,
			(QBMAN_AUTH_SWP), "OPRID");
	CHECK_COND_RETVAL(err == 0, err);
	
	info->vid = OPR_NOT_SET;
	
	return err;
}

int config_orp_fq(struct qbman_swp *sw_portal, int fqid, struct opr_info *info)
{
	int err = 0;
	struct qbman_attr qbman_attr;
	uint32_t fqctrl;
	
	CHECK_COND_RETVAL(info != NULL, -EFAULT);

	err = qbman_fq_query(sw_portal, (uint32_t)fqid, &qbman_attr);
	CHECK_COND_RETVAL(err == 0, err);
	
	qbman_fq_attr_get_fqctrl(&qbman_attr, &fqctrl);

	if (info->state == OPR_ENABLED || info->state == OPR_CREATED) {
		fqctrl |= QBMAN_FQCTRL_ODP;
		qbman_fq_attr_set_opridsz(&qbman_attr, info->id, 0);
	} else {
		fqctrl &= ~(QBMAN_FQCTRL_ODP);
		qbman_fq_attr_set_opridsz(&qbman_attr, 0, 0);
	}
    
    qbman_fq_attr_set_fqctrl(&qbman_attr, fqctrl);

    err = qbman_fq_configure(sw_portal, (uint32_t)fqid, &qbman_attr);
    CHECK_COND_RETVAL(err == 0, err);

	return err;
}

