/*
 * Copyright 2020 NXP
 */
 
/* To configure flow control over recycle ports the CEETM channel must
 * be configured in LNI using an index from 0 to 7 to be linked with wriop
 * configuration */

#include "fsl_dbg.h"

#include "flow_control.h"


/* list of channel index used to perform flow control over recycle ports */
static int fc_ch_list[8] = {0, 1, 2, 3, 4, 5, 6, 7};
int list_idx = 0;


int fc_get_next_channel_idx()
{
	int ret_val;

	if( list_idx < 8 ) {
		ret_val = fc_ch_list[list_idx];
		list_idx++;
	} else {
		ret_val = FLOW_CONTROL_INVALID_INDEX;
	}

	return ret_val;
}

void fc_release_channel_idx(int idx)
{
	list_idx--;

	if( list_idx < 0 ) {
		pr_err("flow control: cannot release channel index: %d\n", idx);
	}
	else {
		fc_ch_list[list_idx] = idx;
	}
}
