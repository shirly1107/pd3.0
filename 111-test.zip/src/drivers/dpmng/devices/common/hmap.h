/*
 * Copyright 2013-2020 NXP
 */

#ifndef _HMAP_H
#define _HMAP_H

#include "fsl_hmap.h"			/* hmap API */

/**************************************************************************//**
@Description   hash map is a collection of apis that maps keys to data.
		It is temporary workaround and should be removed when an
		appropriate OS support provided
 *//***************************************************************************/
#define HMAP_MAX_KEY	128

struct hmap_entry {
	uint8_t	     	key[HMAP_MAX_KEY];
	hmap_data	data;
	int		inuse;
};

struct hmap {
	int 			size;
	size_t 			key_size;
	struct hmap_entry	*table;
};

#endif /* _HMAP_H */
