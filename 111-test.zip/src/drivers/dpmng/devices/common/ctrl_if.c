/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          ctrl_if.c

 @Description   control interface library implementation

 @Cautions      None.
 *//***************************************************************************/
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "drivers/fsl_qbman_ctrl.h"
#include "drivers/fsl_qbman_portal.h"
#include "fsl_resman.h"
#include "dpmng.h"
#include "fsl_malloc.h"
#include "fsl_qbman.h"
#include "fsl_eiop_ifp.h"
#include "fsl_dpbp_mc.h"
#include "fsl_eiop.h"
#include "fsl_dpkg.h"
#include "fsl_dptbl.h"
#include "fsl_ctlu.h"
#include "ctrl_if.h"
#include "fsl_dppolicer.h"
#include "fsl_dpcon_mc.h"
#include "fsl_dpio_mc.h"
#include "fsl_dpparser.h"
#include "eiop_ifp.h"

/*resources_authorization*/ 
static int ctrl_if_resources_authorization(struct ctrl_if *ctrl_if);

static int ctrl_if_rx_qdid_authorization(struct ctrl_if *ctrl_if);
static int ctrl_if_rx_err_fqid_authorization(struct ctrl_if *ctrl_if);
static int ctrl_if_rx_fqids_authorization(struct ctrl_if *ctrl_if);

static int ctrl_if_tx_ifs_qdid_authorization(struct ctrl_if *ctrl_if);
static int ctrl_if_tx_conf_err_fqid_authorization(struct ctrl_if *ctrl_if);

static int config_tx_qbman_post_auth(struct ctrl_if *ctrl_if);
static int config_rx_qbman_post_auth(struct ctrl_if *ctrl_if);
/*resources_authorization*/ 

/*resources_deauthorization*/
static void ctrl_if_resources_deauthorization(struct ctrl_if *ctrl_if);

static void ctrl_if_rx_err_fqid_deauthorization(struct ctrl_if *ctrl_if);
static void ctrl_if_rx_qdid_deauthorization(struct ctrl_if *ctrl_if);
static void ctrl_if_rx_fqids_deauthorization(struct ctrl_if *ctrl_if);

static void ctrl_if_tx_ifs_qdid_deauthorization(struct ctrl_if *ctrl_if);
static void ctrl_if_tx_conf_err_fqid_deauthorization(struct ctrl_if *ctrl_if);
/*resources_deauthorization*/

/*resources_allocation*/
static int ctrl_if_allocate_rx_qdid(struct ctrl_if *ctrl_if);
static int ctrl_if_allocate_rx_qpr(struct ctrl_if *ctrl_if);
static int ctrl_if_allocate_fqs(struct ctrl_if *ctrl_if);
static int ctrl_if_allocate_ifps(struct ctrl_if *ctrl_if);
static int ctrl_if_allocate_internal_kid(struct ctrl_if *ctrl_if);
static int ctrl_if_allocate_internal_plid(struct ctrl_if *ctrl_if);
/*resources_allocation*/

/*save_and_init_cfg*/
static int ctrl_if_save_and_init_cfg(struct ctrl_if *ctrl_if,
		const struct ctrl_if_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg);
static void ctrl_if_save_init_generic(struct ctrl_if *ctrl_if,
		const struct ctrl_if_cfg *cfg);
static void ctrl_if_save_init_handlers (struct ctrl_if *ctrl_if,
		const struct ctrl_if_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg);
static int ctrl_if_save_init_rx_side_cfg(struct ctrl_if *ctrl_if,
		const struct ctrl_if_cfg *cfg);
static int ctrl_if_save_init_tx_side_cfg(struct ctrl_if *ctrl_if,
		const struct ctrl_if_cfg *cfg);
static void ctrl_if_set_defaults_internal(struct ctrl_if *ctrl_if);
/*save_and_init_cfg*/

/*connect if_id*/
static int check_ctrl_if_connect_if_id(struct ctrl_if *ctrl_if, int if_id);
static void ctrl_if_fill_if_id_ceetm_info(struct ctrl_if *ctrl_if, int if_id,
		const struct ctrl_if_connect_if_id_cfg *cfg);
static int init_if_ceetm_qprid (struct ctrl_if *ctrl_if, int qprid,
		int lfqid);
static int init_if_ceetm_dct (struct ctrl_if *ctrl_if,
		struct ctrl_if_ceetm_info *ceetm_info);
static int init_if_ceetm_lfq (struct ctrl_if *ctrl_if,
		struct ctrl_if_ceetm_info *ceetm_info, int *if_lfqid);
static uint16_t if_ceetm_cqid(int cqchid, uint16_t cq);
/*connect if_id*/

/*ctrl_if_internal_initialize */
static int ctrl_if_internal_initialize (struct ctrl_if *ctrl_if);
static int ctrl_if_internal_ceetm_initialize(struct ctrl_if *ctrl_if);
static int ctrl_if_internal_kid_initialize(struct ctrl_if *ctrl_if);
static int ctrl_if_internal_tid_initialize(struct ctrl_if *ctrl_if);
static int ctrl_if_internal_plid_initialize(struct ctrl_if *ctrl_if);
/*ctrl_if_internal_initialize */
	
/*config_fqid */
static int config_fqid	(struct dpmng *dpmng,
		struct dpmng_amq *ctrl_if_amq,
		struct ctrl_if_queue_info  *queue_info);
static int clear_fqid (struct ctrl_if_queue_info *queue);
/*config_fqid */

static int ctrl_if_init_qman( struct ctrl_if *ctrl_if);
static void ctrl_if_init_desc(struct ctrl_if *ctrl_if);
static int ctrl_if_initialize(struct ctrl_if *ctrl_if);
static void ctrl_if_en(struct ctrl_if *ctrl_if);
static void ctrl_if_ifp_init(struct ctrl_if *ctrl_if,
		struct eiop_ifp_desc *ifp_desc, struct eiop_ifp_cfg *ifp_cfg);

static void ctrl_if_eiop_ifp_init(struct ctrl_if *ctrl_if);
static int clear_rx_side(struct ctrl_if *ctrl_if);
static void free_internal_resourses(struct ctrl_if *ctrl_if);
static int init_if_ceetm_lfq (struct ctrl_if *ctrl_if,
		struct ctrl_if_ceetm_info *ceetm_info, int *if_lfqid);
static int check_tx_buffer_layout_cfg(
		const struct ctrl_if_buffer_layout *layout);
static void ctrl_if_init_ifp_desc(struct eiop_ifp_desc *ifp_desc, int eiop_id);

static int config_tx_qbman_post_auth(struct ctrl_if *ctrl_if)
{
	struct ctrl_if_queue_info  *queue_info;
	int err;

	queue_info = &ctrl_if->tx_side_cfg.conf_err_queue_cfg;
	err =  config_fqid(ctrl_if->dpmng,
			&ctrl_if->amq,
			queue_info);
	CHECK_COND_RETVAL(!err, err,
			"Ctrl_IF: tx_err conf_fqid initialization failed");

	ctrl_if->destroy.num_of_init_fqis++;

	return 0;
}

static int ctrl_if_tx_conf_err_fqid_authorization (struct ctrl_if *ctrl_if)
{
	struct qbman_swp *sw_portal;
	int err;

	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);
	err = resource_authorization(
			sw_portal,
			ctrl_if->amq.bdi,
			ctrl_if->amq.icid,
			qbman_auth_type_fqid,
			(uint32_t*)&ctrl_if->tx_side_cfg.conf_err_queue_cfg.virt_fqid,
			(uint32_t)ctrl_if->tx_side_cfg.conf_err_queue_cfg.fqid,
			(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-CONF-ERR-Q");
	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(!err, err);

	ctrl_if->destroy.authorized_obj |= CTRL_IF_DESTROY_AUTHORIZED_TX_CONF_ERR_FQID;
	return 0;
}

static int ctrl_if_tx_ifs_qdid_authorization (struct ctrl_if *ctrl_if)
{
	struct qbman_swp *sw_portal;
	int i, err;

	/* Tx QDID */
	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);
	for (i = 0; i < ctrl_if->num_ifs; i++) {
		err = resource_authorization(
				sw_portal,
				ctrl_if->amq.bdi,
				ctrl_if->amq.icid,
				qbman_auth_type_qdid,
				(uint32_t *)&ctrl_if->tx_side_cfg.iface[i].virt_qdid,
				(uint32_t)ctrl_if->tx_side_cfg.iface[i].qdid,
				(uint32_t)(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
				"QDID");
		if(err)
			break;

		ctrl_if->tx_side_cfg.iface[i].destroy_options |= CTRL_IF_DESTROY_AUTHORIZED_QDID;
	}

	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(err==0, err, "Failed qdid authorization for if %d\n", i);

	return 0;
}

static int ctrl_if_rx_fqids_authorization (struct ctrl_if *ctrl_if)
{
	struct qbman_swp *sw_portal;
	int i, err;

	/* RxErr fqid  */
	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);
	for (i = 0; i < ctrl_if->max_num_of_rx_flows + 1; i++) {
		err = resource_authorization(
				sw_portal, ctrl_if->amq.bdi, ctrl_if->amq.icid,
				qbman_auth_type_fqid,
				(uint32_t*)&ctrl_if->rx_side_cfg.queue_cfg[i].virt_fqid,
				(uint32_t)ctrl_if->rx_side_cfg.queue_cfg[i].fqid,
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-Q");
		if (err)
			break;

		ctrl_if->destroy.num_of_authorized_fqids++;
	}

	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);

	return err;
}

static int ctrl_if_rx_err_fqid_authorization (struct ctrl_if *ctrl_if)
{
	struct qbman_swp *sw_portal;
	int err;

	/* RxErr fqid  */
	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);

	/*rx_err_fqid*/
	err = resource_authorization(
			sw_portal,
			ctrl_if->amq.bdi,
			ctrl_if->amq.icid,
			qbman_auth_type_fqid,
			(uint32_t *)&ctrl_if->rx_side_cfg.err_queue_cfg.virt_fqid,
			(uint32_t)ctrl_if->rx_side_cfg.err_queue_cfg.fqid,
			(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-ERR-Q");
	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(!err, err);

	ctrl_if->destroy.authorized_obj |=
			CTRL_IF_DESTROY_AUTHORIZED_RX_ERR_FQID;

	return 0;
}

static int ctrl_if_rx_qdid_authorization (struct ctrl_if *ctrl_if)
{
	struct qbman_swp *sw_portal;
	int err;

	/* Rx QDID */
	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);
	err = resource_authorization(
			sw_portal,
			ctrl_if->amq.bdi,
			ctrl_if->amq.icid,
			qbman_auth_type_qdid,
			(uint32_t *)&ctrl_if->rx_side_cfg.virt_qdid,
			(uint32_t)ctrl_if->rx_side_cfg.qdid,
			(uint32_t)(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
			"QDID");
	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(!err, err);

	ctrl_if->destroy.authorized_obj |= CTRL_IF_DESTROY_AUTHORIZED_QDID;

	return 0;
}

static void ctrl_if_rx_qdid_deauthorization (struct ctrl_if *ctrl_if)
{
	struct qbman_swp *sw_portal;
	int err;

	/* QDID */
	if (!(ctrl_if->destroy.authorized_obj & CTRL_IF_DESTROY_AUTHORIZED_QDID))
		return;

	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);

	err = resource_deauthorization(
			sw_portal,
			ctrl_if->amq.bdi,
			ctrl_if->amq.icid,
			qbman_auth_type_qdid,
			(uint32_t)ctrl_if->rx_side_cfg.virt_qdid,
			(uint32_t)(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
			"QDID");
	ASSERT_COND(err == 0);
	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);

	ctrl_if->destroy.authorized_obj &= ~CTRL_IF_DESTROY_AUTHORIZED_QDID;
}

static void ctrl_if_rx_err_fqid_deauthorization(struct ctrl_if *ctrl_if)
{
	struct qbman_swp *sw_portal;
	int err;

	if (!(ctrl_if->destroy.authorized_obj & CTRL_IF_DESTROY_AUTHORIZED_RX_ERR_FQID))
		return;

	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);
	err = resource_deauthorization(
			sw_portal,
			ctrl_if->amq.bdi,
			ctrl_if->amq.icid,
			qbman_auth_type_fqid,
			(uint32_t)ctrl_if->rx_side_cfg.err_queue_cfg.virt_fqid,
			(uint32_t)(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
			"RX-ERR-Q");
	ASSERT_COND(err == 0);
	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);

	ctrl_if->destroy.authorized_obj &=
			~CTRL_IF_DESTROY_AUTHORIZED_RX_ERR_FQID;
}

static void ctrl_if_rx_fqids_deauthorization(struct ctrl_if *ctrl_if)
{
	struct qbman_swp *sw_portal;
	int err;
	int i;

	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);
		
	for (i = 0; i < ctrl_if->destroy.num_of_authorized_fqids; i++) {
			err = resource_deauthorization(
				sw_portal, ctrl_if->amq.bdi, ctrl_if->amq.icid,
				qbman_auth_type_fqid,
				(uint32_t)ctrl_if->rx_side_cfg.queue_cfg[i].virt_fqid,
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-Q");
			ASSERT_COND(err == 0);
	}
	ctrl_if->destroy.num_of_authorized_fqids = 0;
	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);
	
}

static void ctrl_if_tx_conf_err_fqid_deauthorization(struct ctrl_if *ctrl_if)
{
	struct qbman_swp *sw_portal;
	int err;

	if (!(ctrl_if->destroy.authorized_obj & CTRL_IF_DESTROY_AUTHORIZED_TX_CONF_ERR_FQID))
		return;

	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);
	err = resource_deauthorization(
			sw_portal,
			ctrl_if->amq.bdi,
			ctrl_if->amq.icid,
			qbman_auth_type_fqid,
			(uint32_t)ctrl_if->tx_side_cfg.conf_err_queue_cfg.virt_fqid,
			(uint32_t)(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
			"TX-CONF-ERR-Q");
	ASSERT_COND(err == 0);
	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);

	ctrl_if->destroy.authorized_obj &=
			~CTRL_IF_DESTROY_AUTHORIZED_TX_CONF_ERR_FQID;
}

static void ctrl_if_tx_ifs_qdid_deauthorization(struct ctrl_if *ctrl_if)
{
	struct qbman_swp *sw_portal;
	int i, err;

	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);
	for(i = 0; i < ctrl_if->num_ifs; i++)
	{
		if (!(ctrl_if->tx_side_cfg.iface[i].destroy_options &
				CTRL_IF_DESTROY_AUTHORIZED_QDID))
			continue;

		err = resource_deauthorization(
				sw_portal,
				ctrl_if->amq.bdi,
				ctrl_if->amq.icid,
				qbman_auth_type_qdid,
				(uint32_t)ctrl_if->tx_side_cfg.iface[i].virt_qdid,
				(uint32_t)(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
				"QDID");
		ASSERT_COND(err == 0);
		ctrl_if->tx_side_cfg.iface[i].destroy_options &=
				~CTRL_IF_DESTROY_AUTHORIZED_QDID;
	}

	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);
}

static int config_fqid(struct dpmng *dpmng,
		struct dpmng_amq *ctrl_if_amq,
		struct ctrl_if_queue_info  *queue_info)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr state;
	struct qbman_attr fqdesc;
	uint32_t fqctrl;
	struct dpio *dpio;
	struct dpcon *dpcon;
	uint16_t destwq;
	int err, ps = 0;

	dpmng_get_swportal(dpmng, (void**)&sw_portal);
	err = qbman_fq_query_state(sw_portal, (uint32_t)queue_info->fqid,
			&state);
	dpmng_put_swportal(dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(!err, err, "qbman_fq_query failed\n");

	if (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_oos)
		/* new FQID, clear descriptor */
		qbman_fq_attr_clear(&fqdesc);
	else {
		/* working FQID, fill the descriptor with its current values */
		dpmng_get_swportal(dpmng, (void**)&sw_portal);
		err = qbman_fq_query(sw_portal, (uint32_t)queue_info->fqid,
				&fqdesc);
		dpmng_put_swportal(dpmng, (void*)sw_portal);
		CHECK_COND_RETVAL(!err, err, "qbman_fq_query failed\n");
	}

	ps = qbman_cacheable_pfdr();
	qbman_fq_attr_set_ctx(&fqdesc, (uint32_t)(queue_info->user_ctx >> 32),
			(uint32_t)queue_info->user_ctx);
	qbman_fq_attr_set_icid(&fqdesc, ctrl_if_amq->icid, ctrl_if_amq->pl);
	qbman_fq_attr_set_mctl(&fqdesc, ctrl_if_amq->bdi, 0, ctrl_if_amq->va,
			ps, 0);
	qbman_fq_attr_set_vfqid(&fqdesc, (uint32_t)queue_info->virt_fqid);
	qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
	fqctrl |= QBMAN_FQCTRL_STASH;

	if (queue_info->cgid_en) {
		fqctrl |= QBMAN_FQCTRL_CGR;
		qbman_fq_attr_set_cgrid(&fqdesc, (uint32_t)queue_info->cgid);
	}

	if (queue_info->order_preservation_en)
		fqctrl |= QBMAN_FQCTRL_HOLDACTIVE;

	qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);

	dpmng_get_swportal(dpmng, (void**)&sw_portal);
	err = qbman_fq_configure(sw_portal, (uint32_t)queue_info->fqid,
			&fqdesc);
	dpmng_put_swportal(dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(!err, err, "qbman_fq_configure failed\n");

	dpmng_get_swportal(dpmng, (void**)&sw_portal);
	err = qbman_fq_query_state(sw_portal, (uint32_t)queue_info->fqid,
			&state);
	dpmng_put_swportal(dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(!err, err, "qbman_fq_query failed\n");

	if (queue_info->dest_cfg.dest_type != CTRL_IF_DEST_NONE) {
		if (queue_info->dest_cfg.dest_type == CTRL_IF_DEST_DPIO) {
			dpio = sys_get_handle(FSL_MOD_DPIO, 1,
					queue_info->dest_cfg.dest_id);
			CHECK_COND_RETVAL( dpio!=NULL, err, "dpio module not found\n");

			err = dpio_get_destwq(dpio,
					queue_info->dest_cfg.priority,
					&destwq);
			CHECK_COND_RETVAL( err==0, err, "dpio_get_destwq failed\n");

			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			qbman_fq_attr_set_fqctrl(&fqdesc,
					fqctrl | QBMAN_FQCTRL_FQDAN);
		} else { /* DPNI_DEST_DPCON */
			dpcon = sys_get_handle(FSL_MOD_DPCON, 1,
					queue_info->dest_cfg.dest_id);
			CHECK_COND_RETVAL( dpcon!=NULL, err, "dpcon module not found\n");

			err = dpcon_get_destwq(dpcon,
					queue_info->dest_cfg.priority,
					&destwq);
			CHECK_COND_RETVAL( err==0, err, "dpcon_get_destwq failed\n");

			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			qbman_fq_attr_set_fqctrl(&fqdesc,
					fqctrl & ~QBMAN_FQCTRL_FQDAN);
		}

		qbman_fq_attr_set_destwq(&fqdesc, (uint32_t)destwq);

		dpmng_get_swportal(dpmng, (void**)&sw_portal);
		err = qbman_fq_configure(sw_portal, (uint32_t)queue_info->fqid,
						&fqdesc);
		dpmng_put_swportal(dpmng, (void*)sw_portal);
		CHECK_COND_RETVAL(!err, err, "qbman_fq_configure failed\n");

		if (qbman_fq_state_schedstate(&state) ==
				qbman_fq_schedstate_parked) {

			dpmng_get_swportal(dpmng, (void**)&sw_portal);

			err = qbman_swp_fq_schedule(
				sw_portal, (uint32_t)queue_info->fqid);
			dpmng_put_swportal(dpmng, (void*)sw_portal);
			CHECK_COND_RETVAL(!err, err,
					"qbman_swp_fq_schedule failed\n");
		}
	}

	return 0;
}
static int check_ctrl_if_destroy(struct ctrl_if *ctrl_if)
{
	int i = 0;

	for (i = 0; i < ctrl_if->num_ifs; i++)
		CHECK_COND_RETVAL(!ctrl_if->tx_side_cfg.iface[i].connected,
				-EINVAL,
				"ctrl_if if = %d should be priori disconnected.\n");

	return 0;
}
static int clear_fqid(struct ctrl_if_queue_info *queue)
{
	dpmng_clear_fqid((uint32_t)queue->fqid,
			queue->retire_storage,
			&queue->retire_pending);

	if (queue->retire_pending == 1)
		return 0;

	return 0;
}

static int clear_rx_side(struct ctrl_if *ctrl_if)
{
	int max_num_of_rx_flows, i;

	if (ctrl_if->destroy.num_of_init_fqis <= ctrl_if->max_num_of_rx_flows)
		max_num_of_rx_flows = ctrl_if->destroy.num_of_init_fqis;
	else
		max_num_of_rx_flows = ctrl_if->max_num_of_rx_flows;

	/* RX-Q */
	for (i = 0; i < max_num_of_rx_flows; i++)
		clear_fqid(&ctrl_if->rx_side_cfg.queue_cfg[i]);

	/* RX-ERR-Q */
	if (ctrl_if->destroy.num_of_init_fqis > ctrl_if->max_num_of_rx_flows)
		clear_fqid(&ctrl_if->rx_side_cfg.err_queue_cfg);

	return 0;
}

static int clear_tx_side(struct ctrl_if *ctrl_if)
{
	/* TX-ERR-Q */
	if(ctrl_if->destroy.num_of_init_fqis > ctrl_if->max_num_of_rx_flows + 1)
		clear_fqid(&ctrl_if->tx_side_cfg.conf_err_queue_cfg);

	return 0;
}

static void free_internal_resourses(struct ctrl_if *ctrl_if)
{
	int i, err;

	/*free and clear internal structure of queue*/
	for (i = 0; i < ctrl_if->max_num_of_rx_flows; i++) {
		if (ctrl_if->rx_side_cfg.queue_cfg[i].retire_storage) {
			fsl_xfree(ctrl_if->rx_side_cfg.queue_cfg[i].retire_storage);
			ctrl_if->rx_side_cfg.queue_cfg[i].retire_storage = NULL;
		}
		memset(&ctrl_if->rx_side_cfg.queue_cfg[i], 0,
				sizeof(struct ctrl_if_queue_info));
	}

	/*free and clear internal structure of rx_err_queue*/
	if (ctrl_if->rx_side_cfg.err_queue_cfg.retire_storage) {
		fsl_xfree(ctrl_if->rx_side_cfg.err_queue_cfg.retire_storage);
		ctrl_if->rx_side_cfg.err_queue_cfg.retire_storage = NULL;
	}
	memset(&ctrl_if->rx_side_cfg.err_queue_cfg, 0,
			sizeof(struct ctrl_if_queue_info));

	/*free and clear internal structure of tx_conf_err_queue*/
	if (ctrl_if->tx_side_cfg.conf_err_queue_cfg.retire_storage) {
		fsl_xfree(ctrl_if->tx_side_cfg.conf_err_queue_cfg.retire_storage);
		ctrl_if->tx_side_cfg.conf_err_queue_cfg.retire_storage = NULL;
	}
	memset(&ctrl_if->tx_side_cfg.conf_err_queue_cfg, 0, sizeof(struct ctrl_if_queue_info));

	if (ctrl_if->tx_side_cfg.iface)
		fsl_free(ctrl_if->tx_side_cfg.iface);

	if (ctrl_if->internal.kid != -1)
	{
		err = dpkg_profile_delete(ctrl_if->dpkg_ing,
				ctrl_if->internal.kid);
		ASSERT_COND(err == 0);
	}

	if (ctrl_if->internal.tid != -1)
	{
		err = dptbl_delete(ctrl_if->internal.dptbl);
		ASSERT_COND(err == 0);
	}
}

static int ctrl_if_internal_plid_initialize(struct ctrl_if *ctrl_if)
{
	struct dppolicer_profile_cfg policer_profile;
	int err;

	/* reset policer profile */
	memset(&policer_profile, 0x0, sizeof(struct dppolicer_profile_cfg));

	/* Color blind, discard red */
	policer_profile.options = DPPOLICER_OPT_COLOR_BLIND |
			DPPOLICER_OPT_DISCARD_RED;

	policer_profile.alg = DPPPLICER_PASS_THROUGH;

	/* Set drop priority numbers to match QMan */
	policer_profile.green_drop_pri = CTRL_IF_POLCIER_DROPP_GREEN;
	policer_profile.yellow_drop_pri = CTRL_IF_POLCIER_DROPP_YELLOW;
	policer_profile.red_drop_pri = CTRL_IF_POLCIER_DROPP_RED;
	policer_profile.default_color = DPPPLICER_GREEN;

	/* Init police profile */
	err = dppolicer_init_profile(
			ctrl_if->dppolicer_ing,		/* Policer handle */
			ctrl_if->rx_side_cfg.plid,	/* Policer id */
			NULL,				/* Private command parameters */
			&policer_profile);		/* configuration */

	return err;
}

static int ctrl_if_allocate_rx_qdid(struct ctrl_if *ctrl_if)
{
	int res_arr[CTRL_IF_MAX_NUM_OF_FLOWS+2];
	int err;

	err =  allocate_resource(ctrl_if->dprc,
			"qd",
			2, /*number - for Rx  + 1 for replic internal*/
			1, /* Base align */
			0, /* Options */
			res_arr,/* Address to store */
			"QDID");
	CHECK_COND_RETVAL(!err, err);

	ctrl_if->rx_side_cfg.qdid = res_arr[0];
	ctrl_if->internal.qdid = res_arr[1];

	return 0;
}

static int ctrl_if_allocate_rx_qpr(struct ctrl_if *ctrl_if)
{
	int err;

	err = allocate_resource(ctrl_if->dprc,
			"qpr",
			1, /*number - 1 for Rx + 1 for internal*/
			1, /* Base align */
			0,/* Options */
			&ctrl_if->rx_side_cfg.qprid,/* Address to store */
			"QPRs");
	CHECK_COND_RETVAL(!err, err);

	err = allocate_resource(ctrl_if->dprc,
			"qpr",
			CTRL_IF_MAX_NAM_OF_QPRIS, /*number - 1 for Rx + 1 for internal*/
			1, /* Base align */
			0,/* Options */
			ctrl_if->internal.qprid,/* Address to store */
			"QPRs");

	return err;
}

static int ctrl_if_allocate_fqs(struct ctrl_if *ctrl_if)
{
	int res_arr[CTRL_IF_MAX_NUM_OF_FLOWS+2];
	int fqs_number, fs_wa_temp, i, err;

	fqs_number = ctrl_if->max_num_of_rx_flows;	/*defaul 0 = 1*/
	fqs_number += 1;				/*for rx_err_fqid*/
	fqs_number += 1;				/*for txconf*/
	NEXT_POWER_OF_2((ctrl_if->max_num_of_rx_flows), fs_wa_temp);
	ctrl_if->rx_side_cfg.fs_wa_temp = fs_wa_temp;

	err = allocate_resource(ctrl_if->dprc,
			"fq",
			(uint32_t)fqs_number,	/*number*/
			1,			/* Base align */
			0,			/* Options */
			res_arr,		/* Address to store */
			"FQs");
	CHECK_COND_RETVAL(!err, err);

	for(i = 0; i < ctrl_if->max_num_of_rx_flows; i++)
		ctrl_if->rx_side_cfg.queue_cfg[i].fqid = res_arr[i];
	ctrl_if->rx_side_cfg.err_queue_cfg.fqid = 
			res_arr[(ctrl_if->max_num_of_rx_flows)];
	ctrl_if->tx_side_cfg.conf_err_queue_cfg.fqid = 
			res_arr[(ctrl_if->max_num_of_rx_flows + 1)];

	return 0;
}

static int ctrl_if_allocate_ifps(struct ctrl_if *ctrl_if)
{
	int res_arr[CTRL_IF_MAX_NUM_OF_FLOWS+2];
	char type[16];
	int i, err;

	snprintf(type, sizeof(type), "ifp.wr%d", ctrl_if->eiop_id ); /* WRIOP ID */
	err = allocate_resource(ctrl_if->dprc, /*Resource manager handle */
			type,		/* Resource type */
			(uint32_t)(ctrl_if->num_ifs + 1), /* Number of resources -
					Tx - ifp per interface +
					Rx - one per ctrl_if*/
			1,		/* Base align */
			0,		/* Options */
			res_arr ,	/* Address to store */
			"IFPID");
	CHECK_COND_RETVAL(!err, err);

	for (i = 0; i < ctrl_if->num_ifs; i++)
		ctrl_if->tx_side_cfg.iface[i].eiop_info.ifp_desc.ifp_id =
				res_arr[i];

	ctrl_if->rx_side_cfg.eiop_info.ifp_desc.ifp_id = res_arr[i];

	return 0;
}

static int ctrl_if_allocate_internal_kid(struct ctrl_if *ctrl_if)
{
	char type[16];

	snprintf(type, sizeof(type), "kp.wr%d.ctlui", ctrl_if->eiop_id);
	return  allocate_resource(ctrl_if->dprc,
			type,
			1,
			1,
			0,
			&ctrl_if->internal.kid,
			"KIDs");
}

static int ctrl_if_allocate_internal_plid(struct ctrl_if *ctrl_if)
{
	char type[16];

	snprintf(type, sizeof(type), "plcr.wr%d.ctlui", ctrl_if->eiop_id ); /* WRIOP ID */
	return allocate_resource(ctrl_if->dprc, /*Resource manager handle */
			type,		/* Resource type */
			1,		/* Number of resources*/
			1,		/* Base align */
			0,		/* Options */
			&ctrl_if->rx_side_cfg.plid, /* Address to store */
			"PLCR");	/* Error string */
}

static int ctrl_if_resourses_allocation(struct ctrl_if *ctrl_if)
{
	int err = 0;

	ASSERT_COND(ctrl_if->max_num_of_rx_flows <= (CTRL_IF_MAX_NUM_OF_FLOWS));

	err = ctrl_if_allocate_rx_qdid(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_allocate_rx_qpr(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_allocate_fqs(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_allocate_ifps(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_allocate_internal_kid(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_allocate_internal_plid(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	return 0;
}

static int ctrl_if_init_qman( struct ctrl_if *ctrl_if)
{

	struct qbman_swp *sw_portal;
	uint16_t qprid[16];
	int err;

	memset(qprid, 0, sizeof( uint16_t) * 16);
	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);

	err = qbman_qpr_configure(
			sw_portal, (uint16_t)ctrl_if->rx_side_cfg.qprid,
			(uint32_t)ctrl_if->rx_side_cfg.queue_cfg[0].fqid, /*fqid_base*/
			(uint16_t)ctrl_if->rx_side_cfg.fs_wa_temp, /*dist_size*/
			(uint32_t)1 /*cgid*/);
	CHECK_COND_GOTO(!err, qpr_fail,
			"Cntrl_If: qbman_qpr_configure failed for rx-qprid %d\n",
			ctrl_if->rx_side_cfg.qprid);

	qprid[0] = (uint16_t)ctrl_if->rx_side_cfg.qprid;

	/* Config QDR */
	err = qbman_qd_configure(sw_portal, (uint16_t)ctrl_if->rx_side_cfg.qdid,
			qprid);
	CHECK_COND_GOTO(!err, qd_fail, "Cntrl_If: qbman_qd_configure failed\n");

	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);
	return 0;

qd_fail:
qpr_fail:
	dpmng_put_swportal(ctrl_if->dpmng, (void*)sw_portal);
	return err;
}

static void ctrl_if_init_ifp_desc(struct eiop_ifp_desc *ifp_desc,
		 int eiop_id)
{
	int err;
	ifp_desc->eiop_id = eiop_id;
	err = sys_get_desc(SOC_MODULE_EIOP_IFP,
			(SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID),
			ifp_desc, NULL);

	ASSERT_COND(err == 0);
	ASSERT_COND(ifp_desc->vaddr);
}

static int ctrl_if_internal_ceetm_dct(struct ctrl_if *ctrl_if,
						struct dpmng_accesspoint *ap)
{
	struct dpmng_amq amq;
	struct eiop_fcead fcead;
	uint32_t ceetmid;
	void *swp;
	int err;

	ceetmid = qbman_ceetmid_compose((uint8_t)ap->dcp_id, /*! DCP Id */
			(uint8_t)ap->ceetm_id); /*! CEETM Id */

	/* Obtain AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	memset(&fcead, 0x0, sizeof(struct eiop_fcead));
	EIOP_FCEAD_SET_IFPID(&fcead,
			ctrl_if->rx_side_cfg.eiop_info.ifp_desc.ifp_id);

	dpmng_get_swportal(ctrl_if->dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* Configure DCT */
	err = qbman_dct_configure(swp, ceetmid,		/* CEETM ID */
			(uint16_t)(ap->dctidx[0]),	/* dct index */
			amq.bdi,			/* BDI */
			amq.va,				/* Virtaul Address */
			amq.icid,			/* icid */
			amq.pl,				/* Privilege level */
			((uint64_t)fcead.command1 << 32) | /* Context "hi" */
			(uint64_t)fcead.command2);	/* Context "lo" */

	dpmng_put_swportal(ctrl_if->dpmng, (void **)&(swp));
	return err;
}

static int ctrl_if_internal_ceetm_cq(struct ctrl_if *ctrl_if,
		struct dpmng_accesspoint *ap)
{
	uint32_t ceetmid;
	uint16_t cqid;
	void *swp;
	int ps, err;

	/* Compose CEETM ID*/
	ceetmid = qbman_ceetmid_compose((uint8_t)ap->dcp_id, /* DCP ID */
			(uint8_t)ap->ceetm_id); /* Instance ID */

	cqid = if_ceetm_cqid(ap->cqchid, 0);
	ps = qbman_cacheable_pfdr();

	/* CEETM Class Congestion Group */
	dpmng_get_swportal(ctrl_if->dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* CEETM CQ configuration */
	err = qbman_cq_configure(swp,	/* SW portal */
			ceetmid,	/* CEETMID */
			cqid,		/* CQID */
			(uint8_t)0,	/* CGID */
			ps,		/* PFDR Stashing*/
			0);		/* PFDR Pool 0 */
	dpmng_put_swportal(ctrl_if->dpmng, (void **)&(swp));
	return err;
}

static int ctrl_if_internal_ceetm_lfq(struct ctrl_if *ctrl_if,
		struct dpmng_accesspoint *ap)
{
	uint32_t lfqid;
	uint16_t cqid;
	void *swp;
	int err;

	/* Make LFQID */
	lfqid = qbman_lfqid_compose((uint8_t)ap->dcp_id, /* DCP */
			(uint8_t)ap->ceetm_id, /* Inst ID */
			(uint16_t)(ap->lfqmtidx[0]));

	cqid = if_ceetm_cqid(ap->cqchid, 0);

	dpmng_get_swportal(ctrl_if->dpmng, (void **)&(swp));

	/* Configure LFQID */
	err = qbman_lfq_configure(swp,			/* SW Portal */
			lfqid,				/* LFQID */
			cqid,				/* CQ ID */
			(uint16_t)(ap->dctidx[0]),	/* DCTIDX */
			0);				/* Error FQID */
	dpmng_put_swportal(ctrl_if->dpmng, (void **)&(swp));
	return err;
}

static int ctrl_if_internal_ceetm_set_ap_to_lni(struct ctrl_if *ctrl_if,
		struct dpmng_accesspoint *ap)
{
	uint32_t ceetmid;
	void *swp;
	int err;

	/*! Compose CEETM */
	ceetmid = qbman_ceetmid_compose((uint8_t)ap->dcp_id,
			(uint8_t)ap->ceetm_id);

	/* Get software portal */
	dpmng_get_swportal(ctrl_if->dpmng, &swp);
	ASSERT_COND(swp);

	err = qbman_cchannel_configure(swp,	/* SW Portal */
			ceetmid,		/* Composed CEETM ID */
			(uint8_t)ap->cqchid,	/* Channel ID */
			(uint8_t)ap->lniid,	/* LNI ID */
			0);			/* shaped/un-shaped */
	dpmng_put_swportal(ctrl_if->dpmng, &swp);
	return err;
}

static int ctrl_if_internal_ceetm_qpri(struct ctrl_if *ctrl_if,
		struct dpmng_accesspoint *ap)
{
	uint32_t lfqid;
	void *swp;
	int i, err;

	lfqid = qbman_lfqid_compose(
			(uint8_t)ap->dcp_id, /* DCP */
			(uint8_t)ap->ceetm_id, /* Instance ID */
			(uint16_t)ap->lfqmtidx[0]);/* lfqmtidx */

	dpmng_get_swportal(ctrl_if->dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* map QPri->LFQID*/
	for(i = 0; i < CTRL_IF_MAX_NAM_OF_QPRIS; i++) {
		err = qbman_qpr_configure(swp,		/* Software portal */
				(uint16_t)(ctrl_if->internal.qprid[i]), /* QPRIID*/
				lfqid,			/* LFQID base */
				1,			/* distribution */
				0);			/* CGID */
		if (err)
			break;
	}
	dpmng_put_swportal(ctrl_if->dpmng, (void **)&(swp));
	return err;
}

static int ctrl_if_internal_ceetm_qdr(struct ctrl_if *ctrl_if,
		struct dpmng_accesspoint *ap)
{
	uint16_t qprid[16];
	void *swp;
	int i, err;

	dpmng_get_swportal(ctrl_if->dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* (QDR) Queuing Destination Record Configure */
	for(i = 0; i < CTRL_IF_MAX_NAM_OF_QPRIS; i++)
		qprid[i] = (uint16_t)ctrl_if->internal.qprid[i];

	for(i = CTRL_IF_MAX_NAM_OF_QPRIS; i< 16; i++)
		qprid[i] = (uint16_t)ctrl_if->internal.qprid[0];

	err = qbman_qd_configure(swp,	/* Software portal */
			(uint16_t)(ctrl_if->internal.qdid), /* QDID */
			qprid);		/* Array of QPRID's */
	dpmng_put_swportal(ctrl_if->dpmng, (void **)&(swp));
	return err;
}

static int ctrl_if_internal_resources_allocation(struct ctrl_if *ctrl_if,
		struct dpmng_accesspoint *ap)
{
	char type[16];
	int err;

	snprintf(type, sizeof(type), "cqch.ctm%d.ins%d", ap->dcp_id,
			ap->ceetm_id);
	err = allocate_resource(ctrl_if->dprc, type, 1, 1, 0,
			&ap->cqchid, "CQ-Channel");
	CHECK_COND_RETVAL(!err, err);

	/* LFQID_INFO */
	snprintf(type, sizeof(type), "lfqmt.ctm%d.ins%d",
			ap->dcp_id, ap->ceetm_id);
	err = allocate_resource(ctrl_if->dprc,type, 1, 1, 0,
			ap->lfqmtidx, "LFQID");
	CHECK_COND_RETVAL(!err, err);

	/* LFQID_INFO */
	snprintf(type, sizeof(type), "dct.ctm%d.ins%d",
			ap->dcp_id, ap->ceetm_id);
	err = allocate_resource(ctrl_if->dprc , type, 1, 1, 0,
			ap->dctidx, "DCTIDX");
	CHECK_COND_RETVAL(!err, err);

	err = dpmng_connection_virt_lniid(ctrl_if->dpmng, ap);
	CHECK_COND_RETVAL(!err, err);

	return 0;
}

static int ctrl_if_internal_ceetm_initialize(struct ctrl_if *ctrl_if)
{
	struct dpmng_accesspoint ap;
	int err;

	memset(&ap, 0, sizeof(struct dpmng_accesspoint));
	ap.iop_id = ctrl_if->eiop_id; /*! WRIOP ID */
	ap.ceetm_id = 0;
	ap.dcp_id = 0;
#if 0
	int dcp_id; /*! Direct Connect Portal ID */
	int lniid; /*! Logical Network Interface ID */
	int cqchid; /*! CQ Channel */
	int ceetm_id; /*! CEETM ID */
	int ifpid; /*! IFPID */
	int dctidx[8]; /*! DCTable index */
	int lfqmtidx[64]; /*! Logical frame queue index */
	
	err =  dpmng_allocate_accesspoint(ctrl_if->dpmng,
	        &ap);
#endif

	err = ctrl_if_internal_resources_allocation(ctrl_if, &ap);
	CHECK_COND_RETVAL(!err, err);

	/* De-queue context (DCT) with IFP of receive*/
	err = ctrl_if_internal_ceetm_dct(ctrl_if, &ap);
	CHECK_COND_RETVAL(!err, err);

	/* CEETM Class Queue (CQ) */
	err = ctrl_if_internal_ceetm_cq(ctrl_if,  &ap);
	CHECK_COND_RETVAL(!err, err);

	/* CEETM LFQ */
	err = ctrl_if_internal_ceetm_lfq(ctrl_if,  &ap);
	CHECK_COND_RETVAL(!err, err);

	/* CEETM Queue Priority (QPRI)*/
	err = ctrl_if_internal_ceetm_qpri(ctrl_if, &ap);
	CHECK_COND_RETVAL(!err, err);

	/* CEETM Queue Destination Record (QDR)*/
	err = ctrl_if_internal_ceetm_qdr(ctrl_if, &ap);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_internal_ceetm_set_ap_to_lni(ctrl_if, &ap);
	CHECK_COND_RETVAL(!err, err);

	return 0;
}

static int ctrl_if_internal_kid_initialize(struct ctrl_if *ctrl_if)
{
	struct dpkg_profile_cfg kg_cfg; /* KID conf */
	int err;

	/* Clear Configuration Parameters */
	memset(&kg_cfg, 0x0, sizeof(struct dpkg_profile_cfg));

	/* VLAN -> FDB KG */
	kg_cfg.num_extracts = 1; /* SMAC, DMAC */

	/* DMAC */
	kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_CONTEXT;
	kg_cfg.extracts[0].extract.from_context.src =
			DPKG_FROM_FCV_FD_FLC_FOR_REPLIC_SRC_QDID;

	err = dpkg_profile_create(ctrl_if->dpkg_ing, /* kg handle */
			ctrl_if->internal.kid, /* KID */
			&kg_cfg); /* Configuration */

	return err;
}

static int ctrl_if_internal_tid_initialize(struct ctrl_if *ctrl_if)
{
	struct dptbl_cfg cfg;
	struct dptbl_rule rule;
	struct dptbl_action action;
	uint8_t *key;
	int i = 0, err;

	/*! Create ACL table */
	memset(&cfg, 0, sizeof(struct dptbl_cfg));
	cfg.type = DPTBL_TYPE_EXACT_MATCH;
	cfg.mem_type = DPTBL_PEB;
	cfg.max_rules = (uint32_t)ctrl_if->num_ifs;
	cfg.max_key_size = 2;
	cfg.options = DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;

	ctrl_if->internal.dptbl = dptbl_init(ctrl_if->dptbl_ing, &cfg);

	if (ctrl_if->internal.dptbl == NULL)
		return -EINVAL;

	dptbl_get_id(ctrl_if->internal.dptbl, &ctrl_if->internal.tid);

	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.size = 2;

	memset(&action, 0, sizeof(struct dptbl_action));
	action.next_action = DPTBL_ACTION_DONE;
	action.options = DPTBL_ACTION_SET_QDID |
			DPTBL_ACTION_SET_IFP_ID |
			DPTBL_ACTION_SET_OPAQUE;
	action.qd_id = ctrl_if->rx_side_cfg.virt_qdid;
	action.ifp_id = ctrl_if->rx_side_cfg.eiop_info.ifp_desc.ifp_id;
	key = (uint8_t *)fsl_malloc(sizeof(uint8_t) * cfg.max_key_size);
	CHECK_COND_RETVAL(key, -ENOMEM,
			"malloc for internal ctrl_if data structure failed.\n");

	rule.rule_cfg.exact.key = key;
	for(i = 0; i < ctrl_if->num_ifs; i++) {
		memcpy(rule.rule_cfg.exact.key,
				&(ctrl_if->tx_side_cfg.iface[i].qdid),
				cfg.max_key_size);
		/* Annotate the FLC with the source port index as well as the source virt_qdid */
		action.opaque = ((uint64_t)i << 32) | ctrl_if->tx_side_cfg.iface[i].virt_qdid;
		err = dptbl_add_rule(ctrl_if->internal.dptbl, &rule, &action, 0);
		if (err)
			break;
	}
	fsl_free(key);

	return 0;
}

static int ctrl_if_internal_initialize (struct ctrl_if *ctrl_if)
{
	int err;

	err = ctrl_if_internal_ceetm_initialize(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_internal_kid_initialize(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_internal_tid_initialize(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_internal_plid_initialize(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	return 0;
}

static int ctrl_if_initialize(struct ctrl_if *ctrl_if)
{
	int i, err;

	err = ctrl_if_init_qman(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	for (i = 0; i < ctrl_if->num_ifs; i++)
		ctrl_if_init_ifp_desc(&ctrl_if->tx_side_cfg.iface[i].eiop_info.ifp_desc,
				ctrl_if->eiop_id);

	ctrl_if_init_ifp_desc(&ctrl_if->rx_side_cfg.eiop_info.ifp_desc,
			ctrl_if->eiop_id);

	err = ctrl_if_internal_initialize(ctrl_if);
	return err;
}

static void ctrl_if_set_defaults_internal(struct ctrl_if *ctrl_if)
{
	ctrl_if->internal.kid = -1;
	ctrl_if->internal.tid = -1;
}

static void ctrl_if_save_init_handlers (struct ctrl_if *ctrl_if,
		const struct ctrl_if_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg)
{
	ctrl_if->dprc = dev_cfg->device;
	ASSERT_COND(ctrl_if->dprc);

	ctrl_if->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	ASSERT_COND(ctrl_if->dpmng);

	/*! Ingress Key Generation */
	ctrl_if->dpkg_ing = sys_get_handle(FSL_MOD_KG,
			2,			/*! number of params */
			ctrl_if->eiop_id,	/*! iop_id */
			CTLU_EIOP_INGRESS);	/*! Ingress */
	ASSERT_COND(ctrl_if->dpkg_ing);

	/*! Ingress Tables */
	ctrl_if->dptbl_ing = sys_get_handle(FSL_MOD_TABLES_MNG,
			2,			/*! number of params */
			ctrl_if->eiop_id,	/*! iop_id */
			CTLU_EIOP_INGRESS);	/*! Ingress */
	ASSERT_COND(ctrl_if->dptbl_ing);

	/* Policer */
	ctrl_if->dppolicer_ing = sys_get_handle(FSL_MOD_POLICER, 2,
			0, CTLU_EIOP_INGRESS);
	ASSERT_COND(ctrl_if->dppolicer_ing);
}

static void ctrl_if_save_init_generic(struct ctrl_if *ctrl_if,
		const struct ctrl_if_cfg *cfg)
{
	ctrl_if->eiop_id = cfg->eiop_id;
	ctrl_if->num_ifs = cfg->num_ifs;
	ctrl_if->max_num_of_rx_flows = CTRL_IF_MAX_NUM_OF_RX_FLOWS;

	if (cfg->adv.mfl == 0)
		ctrl_if->mfl = CTRL_IF_MAX_FRAME_LENGTH;
	else
		ctrl_if->mfl = cfg->adv.mfl;

	ctrl_if->amq.icid = (uint16_t)-1;
}

static int ctrl_if_save_init_rx_side_cfg(struct ctrl_if *ctrl_if,
		const struct ctrl_if_cfg *cfg)
{
	struct ctrl_if_queue_info *info;
	int i;

	for (i = 0; i < ctrl_if->max_num_of_rx_flows; i++) {
		info = &ctrl_if->rx_side_cfg.queue_cfg[i];
		info->retire_storage = (struct qbman_result *)fsl_xmalloc(
				sizeof(struct qbman_result), 0, 64);
		CHECK_COND_RETVAL(info->retire_storage, -ENOMEM);

		memset(info->retire_storage, 0,
				sizeof(struct qbman_result));
	}

	ctrl_if->rx_side_cfg.err_queue_cfg.retire_storage =
			(struct qbman_result *)fsl_xmalloc(
			sizeof(struct qbman_result), 0, 64);
	CHECK_COND_RETVAL(ctrl_if->rx_side_cfg.err_queue_cfg.retire_storage,
			-ENOMEM);

	memset(ctrl_if->rx_side_cfg.err_queue_cfg.retire_storage, 0,
			sizeof(struct qbman_result));

	ctrl_if->rx_side_cfg.eiop_info.ifp_desc.ifp_id = -1;
	ctrl_if->rx_side_cfg.err_queue_cfg.virt_fqid = -1;
	ctrl_if->rx_side_cfg.virt_qdid = -1;

	for(i = 0; i < ctrl_if->max_num_of_rx_flows; i++) {
		info = &ctrl_if->rx_side_cfg.queue_cfg[i];
		info->virt_fqid = -1;
		info->dest_cfg.dest_type = CTRL_IF_DEST_NONE;
	}
	ctrl_if->rx_side_cfg.plid = -1;

	return 0;
}

static int ctrl_if_save_init_tx_side_cfg(struct ctrl_if *ctrl_if,
		const struct ctrl_if_cfg *cfg)
{
	struct ctrl_if_info *iface;
	int i;

	/*! Allocate Interface dataBase */
	ASSERT_COND(ctrl_if->num_ifs);
	ctrl_if->tx_side_cfg.iface = (struct ctrl_if_info *)fsl_malloc(
			sizeof(struct ctrl_if_info) * /*!< Interface dateBase size */
					ctrl_if->num_ifs); /*!< Number of Interfaces */
	CHECK_COND_RETVAL(ctrl_if->tx_side_cfg.iface, -ENOMEM);

	memset(ctrl_if->tx_side_cfg.iface, 0,
			sizeof(struct ctrl_if_info) * ctrl_if->num_ifs);

	ctrl_if->tx_side_cfg.conf_err_queue_cfg.retire_storage =
			(struct qbman_result *)fsl_xmalloc(
					sizeof(struct qbman_result), 0, 64);
	CHECK_COND_RETVAL(ctrl_if->tx_side_cfg.conf_err_queue_cfg.retire_storage,
			-ENOMEM);

	memset(ctrl_if->tx_side_cfg.conf_err_queue_cfg.retire_storage, 0,
			sizeof(struct qbman_result));

	for (i = 0; i < ctrl_if->num_ifs; i++) {
		iface = &ctrl_if->tx_side_cfg.iface[i];
		iface->qdid = (uint16_t)cfg->src_qdid[i];
		iface->queue_cfg.virt_fqid = -1;
		iface->queue_cfg.dest_cfg.dest_type = CTRL_IF_DEST_NONE;
	}

	ctrl_if->tx_side_cfg.tx_conf_disable = 1;
	return 0;
}

static int ctrl_if_save_and_init_cfg(struct ctrl_if *ctrl_if,
		const struct ctrl_if_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg)
{
	int err = 0;

	/*save parameters from cfg file*/
	ctrl_if_save_init_generic(ctrl_if,cfg);
	ctrl_if_save_init_handlers(ctrl_if,cfg,dev_cfg);

	err = ctrl_if_save_init_rx_side_cfg(ctrl_if,cfg);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_save_init_tx_side_cfg(ctrl_if,cfg);
	ctrl_if_set_defaults_internal(ctrl_if);

	return err;
}

static int config_rx_qbman_post_auth(struct ctrl_if *ctrl_if)
{
	struct ctrl_if_queue_info *queue_info;
	int i, err;

	/*The order is important for destroy -
	 * First - regular queues. after r_err_fqid,
	 * after txconf
	 */
	for (i = 0; i < ctrl_if->max_num_of_rx_flows; i++)
	{
		queue_info = &ctrl_if->rx_side_cfg.queue_cfg[i];
		err =  config_fqid(ctrl_if->dpmng, &ctrl_if->amq,
				queue_info);
		CHECK_COND_RETVAL(!err, err,
				"Ctrl_IF: queue %d initialization failed", i);

		ctrl_if->destroy.num_of_init_fqis++;
	}

	queue_info = &ctrl_if->rx_side_cfg.err_queue_cfg;
	err =  config_fqid(ctrl_if->dpmng, &ctrl_if->amq,
			queue_info);
	CHECK_COND_RETVAL(!err, err,
			"Ctrl_IF: rx_err fqid initialization failed");

	ctrl_if->destroy.num_of_init_fqis++;
	return 0;
}

static int ctrl_if_resources_authorization(struct ctrl_if *ctrl_if)
{
	int err;

	/* Rx QDID */
	err = ctrl_if_rx_qdid_authorization(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	/*rx_err_fqid*/
	err = ctrl_if_rx_err_fqid_authorization(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	/*Rx_FQIDs*/
	err = ctrl_if_rx_fqids_authorization(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	/*tx conf_err fqid*/
	err = ctrl_if_tx_conf_err_fqid_authorization(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_tx_ifs_qdid_authorization(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = config_rx_qbman_post_auth(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	err = config_tx_qbman_post_auth(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	return 0;
}


static void ctrl_if_resources_deauthorization(struct ctrl_if *ctrl_if)
{

	struct qbman_swp *sw_portal;

	dpmng_get_swportal(ctrl_if->dpmng, (void**)&sw_portal);

	/* QDID */
	ctrl_if_rx_qdid_deauthorization(ctrl_if);

	/* Rx err Fqid */
	ctrl_if_rx_err_fqid_deauthorization(ctrl_if);

	/*Rx fqids as max_rx_flows*/
	ctrl_if_rx_fqids_deauthorization(ctrl_if);

	/*Tx conf err Fqid*/
	ctrl_if_tx_conf_err_fqid_deauthorization(ctrl_if);

	/*Tx Qdid*/
	ctrl_if_tx_ifs_qdid_deauthorization(ctrl_if);
}

static void ctrl_if_ifp_init(struct ctrl_if *ctrl_if,
		struct eiop_ifp_desc *ifp_desc,
		struct eiop_ifp_cfg *ifp_cfg)
{
	struct dpbp_attr attr;
	int i, err;

	ASSERT_COND(ctrl_if->destroy.authorized_obj &
			CTRL_IF_DESTROY_AUTHORIZED_QDID);
	ifp_cfg->default_cfg.qd_id = (int)ctrl_if->rx_side_cfg.virt_qdid;

	/*AMQ initialization*/
	if (ctrl_if->amq.bdi)
		ifp_cfg->defcfg.options |=
			EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION;
	if (ctrl_if->amq.pl)
		ifp_cfg->defcfg.options |=
			EIOP_IFP_DEFCFG_OPT_SET_PRIVIL_LEVEL;
	if (ctrl_if->amq.bdi)
		ifp_cfg->defcfg.options |=
			EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION;
	if (ctrl_if->amq.pl)
		ifp_cfg->defcfg.options |=
			EIOP_IFP_DEFCFG_OPT_SET_PRIVIL_LEVEL;
	if (ctrl_if->amq.va)
		ifp_cfg->defcfg.options |=
			EIOP_IFP_DEFCFG_OPT_SET_VIRT_ADDR;
	ifp_cfg->defcfg.icid = ctrl_if->amq.icid;

	memset(&attr, 0, sizeof(struct dpbp_attr));

	/* Main pools */
	ifp_cfg->num_of_pools_used = ctrl_if->pools_cfg.num_dpbp;
	for (i = 0; i < ctrl_if->pools_cfg.num_dpbp; i++) {
		dpbp_get_attributes(ctrl_if->pools_cfg.pools[i].dpbp, &attr);
		ifp_cfg->pools_cfg[i].id = attr.bpid;
		ifp_cfg->pools_cfg[i].size =
				ctrl_if->pools_cfg.pools[i].buffer_size;
		if (ctrl_if->amq.bmt)
			ifp_cfg->pools_cfg[i].options |= EIOP_IFP_BUF_POOL_OPT_BMT;
	}

	/* Backup pools */
	ifp_cfg->defcfg.num_of_backup_pools_used =
			ctrl_if->backup_pools_cfg.num_dpbp;

	for (i = 0; i < ctrl_if->backup_pools_cfg.num_dpbp; i++) {
		dpbp_get_attributes(ctrl_if->backup_pools_cfg.pools[i].dpbp,
				&attr);
		ifp_cfg->defcfg.backup_pool_cfg[i].id =
				attr.bpid;
		ifp_cfg->defcfg.backup_pool_cfg[i].size =
				ctrl_if->backup_pools_cfg.pools[i].buffer_size;
		if (ctrl_if->amq.bmt)
			ifp_cfg->defcfg.backup_pool_cfg[i].options |=
					EIOP_IFP_BUF_POOL_OPT_BMT;
	}

	ASSERT_COND(ctrl_if->destroy.authorized_obj &
			CTRL_IF_DESTROY_AUTHORIZED_RX_ERR_FQID);
	ifp_cfg->rx_err_fqid =
			(int)ctrl_if->rx_side_cfg.err_queue_cfg.virt_fqid;

	ASSERT_COND(ctrl_if->destroy.authorized_obj &
			CTRL_IF_DESTROY_AUTHORIZED_TX_CONF_ERR_FQID);
	ifp_cfg->tx_err_fqid =
			(int)ctrl_if->tx_side_cfg.conf_err_queue_cfg.virt_fqid;

	ifp_cfg->max_frame_length = ctrl_if->mfl;

	memcpy(&ifp_cfg->defcfg.tx_buf_layout, &ctrl_if->tx_buf_layout,
			sizeof(struct buf_layout));
	memcpy(&ifp_cfg->defcfg.txconf_buf_layout, &ctrl_if->txconf_buf_layout,
			sizeof(struct buf_layout));
	memcpy(&ifp_cfg->defcfg.rx_buf_layout, &ctrl_if->rx_buf_layout,
			sizeof(struct buf_layout));

	/*for settings errors - to save what was set before init*/
	ifp_cfg->errors_settings = ctrl_if->rx_side_cfg.errors_settings;

	err = eiop_ifp_init(ifp_desc, ifp_cfg);
	return;
}

static int check_common_pools_cfg(const struct ctrl_if_pools_cfg *cfg)
{
	CHECK_COND_RETVAL(cfg->num_dpbp <= CTRL_IF_MAX_DPBP, -EINVAL,
			"ctrl_if: num of pools must be smaller than %d\n",
			(CTRL_IF_MAX_DPBP+1));

	return 0;
}

static int check_pool_cfg(const struct ctrl_if_pool_cfg *cfg)
{
	CHECK_COND_RETVAL(cfg->buffer_size, -EINVAL,
			"Cntrl_if: buffer-size can't be '0'\n");

	CHECK_COND_RETVAL(cfg->buffer_size % 64 == 0, -EINVAL,
			"Cntrl_if:  buffer-size is not multiple of 64\n");

#if 0
	if (cfg->buffer_size > 65472) {
		pr_err("Cntrl_if: buffer-size must be up to 65472\n");
		return -EINVAL;
	}
#endif
	return 0;
}

static int check_tx_buffer_layout_cfg(const struct ctrl_if_buffer_layout *layout)
{
	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_PARSER_RESULT) {
		pr_err("Ctrl_if: 'DPNI_BUF_LAYOUT_OPT_PARSER_RESULT' can't be used for TX\n");
		return -EINVAL;
	}

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_DATA_HEAD_ROOM) {
		pr_err("Ctrl_if: 'DPNI_BUF_LAYOUT_OPT_DATA_HEAD_ROOM' can't be used for TX\n");
		return -EINVAL;
	}

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_DATA_TAIL_ROOM) {
		pr_err("Ctrl_if: 'DPNI_BUF_LAYOUT_OPT_DATA_TAIL_ROOM' can't be used for TX\n");
		return -EINVAL;
	}

	return 0;
}

static int check_tx_conf_buffer_layout_cfg(const struct ctrl_if_buffer_layout *layout)
{
	uint32_t unsupported_opt = CTRL_IF_BUF_LAYOUT_OPT_PARSER_RESULT |
			CTRL_IF_BUF_LAYOUT_OPT_DATA_ALIGN |
			CTRL_IF_BUF_LAYOUT_OPT_PRIVATE_DATA_SIZE |
			CTRL_IF_BUF_LAYOUT_OPT_DATA_HEAD_ROOM |
			CTRL_IF_BUF_LAYOUT_OPT_DATA_TAIL_ROOM;

	CHECK_COND_RETVAL(!(layout->options & unsupported_opt), -EINVAL,
			"Ctrl If: unsupported layout options set for Tx-Conf traffic (%08x)!\n");

	return 0;
}

static void ctrl_if_ifp_set_pcd(struct ctrl_if *ctrl_if,
		struct eiop_ifp_desc *ifp_desc)
{
	struct eiop_ifp_rx_pcd_cfg ifp_pcd_cfg;
	int err;

	/* Setup Ingress flow */
	memset(&ifp_pcd_cfg, 0, sizeof(struct eiop_ifp_rx_pcd_cfg));
	ifp_pcd_cfg.activate_modules = (EIOP_IFP_ACTIVATE_MODULE_PARSER
			| EIOP_IFP_ACTIVATE_MODULE_LOOKUP);

	dpparser_get_hdr_code(NET_PROT_ETH, &ifp_pcd_cfg.parser.start_hxs);
	ifp_pcd_cfg.parser.profile_id = 0;

	ifp_pcd_cfg.default_lookup.dpkg_profile_id = ctrl_if->internal.kid;
	ifp_pcd_cfg.default_lookup.dptbl_id = ctrl_if->internal.tid;

	err = eiop_ifp_rx_pcd_set(ifp_desc,
			&ifp_pcd_cfg);
	ASSERT_COND(err == 0);
}

int ctrl_if_enable(struct ctrl_if *ctrl_if)
{
	int err;
	struct eiop_ifp_cfg *ifp_cfg;

	/*init ifp for Rx side*/
	if (ctrl_if->rx_enabled)
		return 0;

	ifp_cfg = &ctrl_if->rx_side_cfg.eiop_info.init;
	ifp_cfg->default_cfg.options = EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_PASSTHRU;
	ctrl_if_ifp_init(ctrl_if,
		&(ctrl_if->rx_side_cfg.eiop_info.ifp_desc),
		&(ctrl_if->rx_side_cfg.eiop_info.init));

	ctrl_if_ifp_set_pcd(
			ctrl_if,
			&ctrl_if->rx_side_cfg.eiop_info.ifp_desc);

	err = eiop_ifp_set_enqueue_ifp(
			&ctrl_if->rx_side_cfg.eiop_info.ifp_desc,
			ctrl_if->rx_side_cfg.eiop_info.ifp_desc.ifp_id);
	ASSERT_COND(err == 0);

	eiop_ifp_tx_enable(&ctrl_if->rx_side_cfg.eiop_info.ifp_desc);

	err = eiop_ifp_rx_enable(&ctrl_if->rx_side_cfg.eiop_info.ifp_desc);
	if (!err)
		ctrl_if->rx_enabled = 1;
	return err;
}

int ctrl_if_disable(struct ctrl_if *ctrl_if)
{
	int err;

	/*init ifp for Rx side*/
	err =  eiop_ifp_rx_graceful_stop(&ctrl_if->rx_side_cfg.eiop_info.ifp_desc);
	CHECK_COND_RETVAL(!err, err);

	ctrl_if->rx_enabled = 0;

	err = eiop_ifp_tx_graceful_stop(&ctrl_if->rx_side_cfg.eiop_info.ifp_desc);
	CHECK_COND_RETVAL(!err, err);

	return 0;
}

int ctrl_if_enable_if_id(struct ctrl_if *ctrl_if, int if_id)
{
	struct ctrl_if_info *if_info;

	CHECK_COND_RETVAL(if_id < ctrl_if->num_ifs, -EINVAL,
			"if_id = %d should be in the range - 0 - %d \n",
			if_id, ctrl_if->num_ifs - 1);

	if_info = &ctrl_if->tx_side_cfg.iface[if_id];

	CHECK_COND_RETVAL(if_info->connected, -EINVAL,
			"prior enable of if = %d connect this if to ctrl_if\n",
			if_id);

	ctrl_if_ifp_init(ctrl_if,
			&if_info->eiop_info.ifp_desc,
			&if_info->eiop_info.init);

	eiop_ifp_tx_enable(&if_info->eiop_info.ifp_desc);
	if_info->enabled = 1;
	ctrl_if->num_ifs_enabled += 1;

	if(ctrl_if->num_ifs_enabled == ctrl_if->num_ifs)
		ctrl_if->tx_enabled = 1;

	return 0;
}

int ctrl_if_disable_if_id(struct ctrl_if *ctrl_if, int if_id)
{
	struct ctrl_if_info *if_info;
	int err;

	CHECK_COND_RETVAL(if_id < ctrl_if->num_ifs, -EINVAL,
			"if_id = %d should be in the range - 0 - %d \n",
			if_id, ctrl_if->num_ifs - 1);

	if_info = &ctrl_if->tx_side_cfg.iface[if_id];

	if (if_info->enabled == 0)
		return 0;

	err =  eiop_ifp_tx_graceful_stop(&if_info->eiop_info.ifp_desc);
	if (!err)
		if_info->enabled = 0;
	
	ASSERT_COND(ctrl_if->num_ifs_enabled);
	ctrl_if->num_ifs_enabled -= 1;

	if(ctrl_if->num_ifs_enabled == 0)
		ctrl_if->tx_enabled = 0;

	return 0;
}

int ctrl_if_get_rx_flow_attr(struct ctrl_if *ctrl_if, uint16_t flow_id,
		struct ctrl_if_attr *attr)
{
	struct ctrl_if_queue_info *info;

	if (flow_id >= ctrl_if->max_num_of_rx_flows) {
		pr_err("flow_id (%d) must be smaller than %d\n",
				flow_id, ctrl_if->max_num_of_rx_flows);
		return -EINVAL;
	}

	attr->ifp_id = ctrl_if->rx_side_cfg.eiop_info.ifp_desc.ifp_id;
	attr->virt_err_fqid = ctrl_if->rx_side_cfg.err_queue_cfg.virt_fqid;
	attr->virt_qdid = ctrl_if->rx_side_cfg.virt_qdid;
	attr->internal_qdid = ctrl_if->internal.qdid;
	attr->plid = ctrl_if->rx_side_cfg.plid;

	info = &ctrl_if->rx_side_cfg.queue_cfg[flow_id];
	ASSERT_COND(info);

	attr->virt_fqid = info->virt_fqid;
	return 0;
}

int ctrl_if_get_tx_if_id_attr(struct ctrl_if *ctrl_if, uint16_t if_id,
		struct ctrl_if_attr *attr)
{
	CHECK_COND_RETVAL(if_id < ctrl_if->num_ifs, -EINVAL,
			"ID[%d]: if_id (%d) must be smaller than %d\n",
			if_id, ctrl_if->num_ifs - 1);

	attr->virt_fqid = ctrl_if->tx_side_cfg.iface[if_id].queue_cfg.virt_fqid;
	attr->virt_err_fqid = ctrl_if->tx_side_cfg.conf_err_queue_cfg.virt_fqid;
	attr->virt_qdid = ctrl_if->tx_side_cfg.iface[if_id].virt_qdid;

	return 0;
}

int ctrl_if_set_max_frame_length(struct ctrl_if *ctrl_if,
		uint16_t max_frame_length)
{
	int err;

	err = eiop_ifp_set_max_frame_length(&ctrl_if->rx_side_cfg.eiop_info.ifp_desc,
			max_frame_length);
	CHECK_COND_RETVAL(!err, err,
			"Cntrl_If: setting MFL for control IF failed\n");

	ctrl_if->mfl = max_frame_length;

	return 0;
}

int ctrl_if_destroy(struct ctrl_if *ctrl_if)
{
	int err;

	err = check_ctrl_if_destroy(ctrl_if);
	CHECK_COND_RETVAL(!err, err);

	if (ctrl_if->rx_enabled)
		ctrl_if_disable(ctrl_if);

	ctrl_if_resources_deauthorization(ctrl_if);

	clear_tx_side(ctrl_if);
	clear_rx_side(ctrl_if);

	free_internal_resourses(ctrl_if);

#if 0
	for (i = 0; i < ctrl_if->max_num_of_flows; i++) {
		dpmng_clear_fqid(dpni, &dpni->tc_rx[i].rx_queues[j]);
		memset(&dpni->tc_rx[i].dist_extract_cfg, 0,
			sizeof(struct dpkg_profile_cfg));
		dpni->tc_rx[i].dist_size = 1;
		dpni->tc_rx[i].valid = 0;
	}
#endif
	return 0;
}

#if 0
	void dpni_destroy(struct dpni *dpni)
	{
		struct linkmngr_endpoint endpoint1;
		struct linkmngr_endpoint endpoint2;
		enum linkmngr_state state;
		int err;

		if (dpni->enabled)
			dpni_disable(dpni);

		err = resources_deauthorization(dpni);
		ASSERT_COND(!err);

		memset(&endpoint1, 0x0, sizeof(struct linkmngr_endpoint));
		memset(&endpoint2, 0x0, sizeof(struct linkmngr_endpoint));
		endpoint1.type = FSL_MOD_DPNI;
		endpoint1.id = (uint16_t)dpni->id;
		linkmngr_get_connection(dpni->linkmngr, &state, &endpoint1,
					&endpoint2);
		if (state != LINKMNGR_STATE_IDLE)
			if (linkmngr_set_connection(dpni->linkmngr,
							LINKMNGR_EVENT_DISCONNECT,
							&endpoint1, &endpoint2)
				!= 0)
				pr_warn("ID[%d]: linkmngr_set_connection (DISCONNECT) failed\n", dpni->id);

		clear_tx_side(dpni);

		clear_rx_side(dpni);

		delete_ctlu(dpni);

		err = resources_deallocation(dpni);
		ASSERT_COND(!err);

		free_internal_resources(dpni);
	}
#endif

static uint16_t if_ceetm_cqid(int cqchid, uint16_t cq)
{
	struct qbman_desc desc;
	uint32_t cqid, num_cqs;
	int err;

	memset(&desc, 0x0, sizeof(struct qbman_desc));

	err = sys_get_desc(SOC_MODULE_QBMAN,	/* module */
			0,			/* match options*/
			&desc,			/* descriptor */
			NULL);			/* iterator */
	ASSERT_COND(err == 0);
	num_cqs = desc.ceetm_num_strict_pri_q + desc.ceetm_num_weight_pri_q;

	cqid = (cqchid * (num_cqs)) | cq;

	return (uint16_t)cqid;
}

static int init_if_ceetm_lfq (struct ctrl_if *ctrl_if,
		struct ctrl_if_ceetm_info *ceetm_info, int *if_lfqid)
{
	struct qbman_swp *swp;
	uint32_t lfqid;
	int err;

	dpmng_get_swportal(ctrl_if->dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* Make LFQID */
	lfqid = qbman_lfqid_compose(
			(uint8_t)ceetm_info->dcp_id,	/* DCP */
			(uint8_t)ceetm_info->ceetm_id,	/* Inst ID */
			(uint16_t)(ceetm_info->lfqmtidx));

	err = qbman_lfq_configure(
			swp,
			lfqid,
			(uint16_t)ceetm_info->cq_id,
			(uint16_t)ceetm_info->dctidx,
			0); /* Error FQID */

	dpmng_put_swportal(ctrl_if->dpmng, (void*)swp);
	CHECK_COND_RETVAL(!err, err, "qbman_lfq_configure failed\n");

	*if_lfqid = (int)lfqid;
	return 0;
}

static int init_if_ceetm_dct (struct ctrl_if *ctrl_if,
		struct ctrl_if_ceetm_info *ceetm_info)
{
	struct eiop_fcead fcead;
	struct qbman_swp *swp;
	uint32_t ceetm_id;
	int err;

	memset(&fcead, 0, sizeof(struct eiop_fcead));
	EIOP_FCEAD_SET_IFPID(&fcead,
			ceetm_info->ifp_id);
	EIOP_FCEAD_SET_L3CSG(&fcead, 0);
	EIOP_FCEAD_SET_L4CSG(&fcead, 0);
	EIOP_FCEAD_SET_FQID(&fcead, 0);
	EIOP_FCEAD_SET_EBDD(&fcead, 0);

	if (!ctrl_if->tx_side_cfg.tx_conf_disable) {
		EIOP_FCEAD_SET_FQID(&fcead,
				ctrl_if->tx_side_cfg.conf_err_queue_cfg.virt_fqid);
		EIOP_FCEAD_SET_FQIDT(&fcead,
				ctrl_if->tx_side_cfg.tx_conf_only_errors_frames);
		EIOP_FCEAD_SET_EBDD(&fcead,
				!ctrl_if->tx_side_cfg.tx_conf_only_errors_frames);
	}

	ceetm_id = qbman_ceetmid_compose(
			(uint8_t)ceetm_info->dcp_id,	/*! DCP Id */
			(uint8_t)ceetm_info->ceetm_id);	/*! CEETM Id */

	dpmng_get_swportal(ctrl_if->dpmng, (void **)&(swp));

	err = qbman_dct_configure(swp,
			(uint8_t)ceetm_id,
			(uint16_t)ceetm_info->dctidx,
			ctrl_if->amq.bdi,
			ctrl_if->amq.va,
			ctrl_if->amq.icid,
			ctrl_if->amq.pl,
			((uint64_t)fcead.command1 << 32)
			| (uint64_t)fcead.command2);
	dpmng_put_swportal(ctrl_if->dpmng, (void*)swp);
	CHECK_COND_RETVAL(!err, err, "qbman_dct_configure failed\n");

	return 0;
}

static int init_if_ceetm_qprid (struct ctrl_if *ctrl_if,
		int qprid, int lfqid)
{
	struct qbman_swp *swp;
	int err;

	dpmng_get_swportal(ctrl_if->dpmng, (void **)&(swp));

	err = qbman_qpr_configure(swp, (uint16_t)qprid, (uint32_t)lfqid, 1, 0);
	dpmng_put_swportal(ctrl_if->dpmng, (void*)swp);
	return err;
}

static void ctrl_if_fill_if_id_ceetm_info(struct ctrl_if *ctrl_if,
		int if_id, const struct ctrl_if_connect_if_id_cfg *cfg)
{
	struct ctrl_if_ceetm_info *iface_ceetm_info;
	struct ctrl_if_tx_side_cfg *txcfg;

	iface_ceetm_info = &ctrl_if->tx_side_cfg.iface[if_id].ceetm_info;
	txcfg = &ctrl_if->tx_side_cfg;

	iface_ceetm_info->ifp_id = txcfg->iface[if_id].eiop_info.ifp_desc.ifp_id;
	iface_ceetm_info->tx_conf_err = txcfg->conf_err_queue_cfg.fqid;
	iface_ceetm_info->dctidx = cfg->ap->dctidx[cfg->dctidx_idx];
	iface_ceetm_info->ceetm_id = cfg->ap->ceetm_id;
	iface_ceetm_info->dcp_id = cfg->ap->dcp_id;
	iface_ceetm_info->lfqmtidx = cfg->ap->lfqmtidx[cfg->lfqmtidx_idx];
	iface_ceetm_info->cq_id = if_ceetm_cqid(cfg->ap->cqchid,
			(uint16_t)cfg->cq_id);
}

static int check_ctrl_if_connect_if_id(struct ctrl_if *ctrl_if, int if_id)
{
	struct ctrl_if_info *iface;

	CHECK_COND_RETVAL(if_id < ctrl_if->num_ifs, -EINVAL,
			"if_id = %d is out of range. The range is 0 - %d\n",
			if_id, ctrl_if->num_ifs);

	iface = &ctrl_if->tx_side_cfg.iface[if_id];

	ASSERT_COND(!iface->connected);
	ASSERT_COND(!iface->enabled);

	return 0;
}

int ctrl_if_connect_if_id(struct ctrl_if *ctrl_if,
		int if_id, const struct ctrl_if_connect_if_id_cfg *cfg)
{
	struct ctrl_if_info *iface;
	int err;

	ASSERT_COND(cfg->ap);

	iface = &ctrl_if->tx_side_cfg.iface[if_id];

	err = check_ctrl_if_connect_if_id(ctrl_if, if_id);
	CHECK_COND_RETVAL(!err, err);

	ctrl_if_fill_if_id_ceetm_info(ctrl_if,if_id, cfg);

	/* CEETM LFQ */
	err = init_if_ceetm_lfq(ctrl_if, &iface->ceetm_info,
			&iface->queue_cfg.fqid);
	CHECK_COND_RETVAL(!err, err, "init_if_ceetm_cq\n");

	err = init_if_ceetm_qprid(ctrl_if, cfg->qprid, iface->queue_cfg.fqid);
	CHECK_COND_RETVAL(!err, err, "init_if_ceetm_qprid\n");

#if 0
	dpmng_get_swportal(ctrl_if->dpmng, (void**)&swp);
	/* Lfqid */
	/* CEETM LFQ authorization*/
	if ((err = resource_authorization(
				swp,
				ctrl_if->amq.bdi,
				ctrl_if->amq.icid,
				qbman_auth_type_fqid,
				(uint32_t*)&iface->queue_cfg.virt_fqid,
				(uint32_t)iface->queue_cfg.fqid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "LFQ"))
		!= 0) {
		dpmng_put_swportal(ctrl_if->dpmng, (void*)swp);
		return err;
	}
	dpmng_put_swportal(ctrl_if->dpmng, (void*)swp);
	iface->options |= CTRL_IF_INFO_QUEUE_AUTHORIZED;
#endif

	/* De-queue handle (DCT)*/
	err = init_if_ceetm_dct(ctrl_if, &iface->ceetm_info);
	CHECK_COND_RETVAL(!err, err);

	iface->connected = 1;

	/*update next_ifp - important for virtual interface*/
	err = eiop_ifp_set_enqueue_ifp( &iface->eiop_info.ifp_desc,
			cfg->next_ifp);
	CHECK_COND_RETVAL(!err, err);

	return 0;
}

int ctrl_if_disconnect_if_id(struct ctrl_if *ctrl_if, int if_id)
{
	struct ctrl_if_info *iface;

	CHECK_COND_RETVAL(if_id < ctrl_if->num_ifs, -EINVAL,
			"if_id = %d is out of range.  The range is 0 - %d\n",
			if_id, ctrl_if->num_ifs);

#if 0
	iface = &ctrl_if->tx_side_cfg.iface[if_id];

	if (iface->options & CTRL_IF_INFO_QUEUE_AUTHORIZED) {
		dpmng_get_swportal(ctrl_if->dpmng, (void**)&swp);
		err = resource_deauthorization(
						swp,
						ctrl_if->amq.bdi,
						ctrl_if->amq.icid,
						qbman_auth_type_fqid,
						(uint32_t)iface->queue_cfg.virt_fqid,
						(uint32_t)(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
						"QDID");
		ASSERT_COND(err == 0);
		dpmng_put_swportal(ctrl_if->dpmng, (void*)swp);
	}
#endif

	iface = &ctrl_if->tx_side_cfg.iface[if_id];
	ASSERT_COND(!iface->enabled);

	iface->queue_cfg.virt_fqid = -1;
	iface->connected = 0;

	return 0;
}

int ctrl_if_set_tx_confirmation(struct ctrl_if *ctrl_if, int en)
{
	struct ctrl_if_info *iface;
	int i, err;

	if (ctrl_if->tx_side_cfg.tx_conf_disable == !en)
		return 0;

	ctrl_if->tx_side_cfg.tx_conf_disable = !en;

	/* De-queue handle (DCT)*/
	for (i = 0; i < ctrl_if->num_ifs; i++) {
		iface = &ctrl_if->tx_side_cfg.iface[i];
		if (!iface->connected)
			continue;

		/* De-queue handle (DCT)*/
		err = init_if_ceetm_dct(ctrl_if, &iface->ceetm_info);
		CHECK_COND_RETVAL(!err, err, "init_if_ceetm_dct failed\n");
	}

	return 0;
}

struct ctrl_if *ctrl_if_allocate()
{
	struct ctrl_if *ctrl_if = NULL;

	ctrl_if = (struct ctrl_if *)fsl_malloc(sizeof(struct ctrl_if));
	if (ctrl_if)
		memset(ctrl_if, 0, sizeof(struct ctrl_if));
	return ctrl_if;
}

void ctrl_if_deallocate(struct ctrl_if *ctrl_if)
{
	fsl_free(ctrl_if);
}

int ctrl_if_set_tx_conf_buffer_layout( struct ctrl_if *ctrl_if,
		const struct ctrl_if_buffer_layout *layout)
{
	struct buf_layout *txconf_buf_layout;
	int err;

	CHECK_COND_RETVAL(!ctrl_if->tx_enabled, -EACCES,
			"Cntrl_if: all interfaces should be disabled before changing tx_buffer_layout\n");

	if (!layout->options)
		return 0;

	err = check_tx_conf_buffer_layout_cfg(layout);
	CHECK_COND_RETVAL(!err, err);

	txconf_buf_layout = &ctrl_if->txconf_buf_layout;

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_FRAME_STATUS)
		txconf_buf_layout->pass_fas = layout->pass_frame_status;

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_TIMESTAMP)
		txconf_buf_layout->pass_ts = layout->pass_timestamp;

	return 0;
}

int ctrl_if_set_rx_buffer_layout( struct ctrl_if *ctrl_if,
		const struct ctrl_if_buffer_layout *layout)
{
	struct buf_layout *rx_buf_layout;

	CHECK_COND_RETVAL(!ctrl_if->rx_enabled, -EACCES,
			"Cntrl_if:  must be disabled\n");

	if (!layout->options)
		return 0;

	rx_buf_layout = &ctrl_if->rx_buf_layout;

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_DATA_ALIGN)
		rx_buf_layout->data_align = layout->data_align;

	if (layout->options &CTRL_IF_BUF_LAYOUT_OPT_FRAME_STATUS)
		rx_buf_layout->pass_fas = layout->pass_frame_status;

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_PARSER_RESULT)
		rx_buf_layout->pass_pr = layout->pass_parser_result;

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_PRIVATE_DATA_SIZE)
		rx_buf_layout->priv_data_size =
				ROUND_UP(layout->private_data_size, 64);

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_TIMESTAMP)
		rx_buf_layout->pass_ts = layout->pass_timestamp;

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_DATA_HEAD_ROOM)
		rx_buf_layout->data_headroom = layout->data_head_room;

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_DATA_TAIL_ROOM)
		rx_buf_layout->data_tailroom = layout->data_tail_room;

	return 0;
}

int ctrl_if_set_tx_buffer_layout( struct ctrl_if *ctrl_if,
		const struct ctrl_if_buffer_layout *layout)
{
	struct buf_layout *tx_buf_layout;
	int err;

	CHECK_COND_RETVAL(!ctrl_if->tx_enabled, -EACCES,
			"Cntrl_if: all interfaces should be disabled before changing tx_buffer_layout\n");

	if (!layout->options)
		return 0;

	err =  check_tx_buffer_layout_cfg(layout);
	CHECK_COND_RETVAL(!err, err);

	tx_buf_layout = &ctrl_if->tx_buf_layout;

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_DATA_ALIGN)
		tx_buf_layout->data_align = layout->data_align;

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_FRAME_STATUS)
		tx_buf_layout->pass_fas = layout->pass_frame_status;

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_PRIVATE_DATA_SIZE)
		tx_buf_layout->priv_data_size =
			ROUND_UP(layout->private_data_size, 64);

	if (layout->options & CTRL_IF_BUF_LAYOUT_OPT_TIMESTAMP)
		tx_buf_layout->pass_ts = layout->pass_timestamp;

	return 0;
}

int ctrl_if_set_pools(struct ctrl_if *ctrl_if,
		const struct ctrl_if_pools_cfg *cfg)
{
	struct ctrl_if_pools_int_cfg *pools_cfg;
	int i, err;

	ASSERT_COND(ctrl_if);

	CHECK_COND_RETVAL(!ctrl_if->rx_enabled, -EACCES,
			"ctrl_if must be disabled\n");

	err = check_common_pools_cfg(cfg);
	CHECK_COND_RETVAL(!err, err);

	ctrl_if->backup_pools_cfg.num_dpbp = 0;
	ctrl_if->pools_cfg.num_dpbp = 0;

	for (i = 0; i < cfg->num_dpbp; i++) {
		struct dpbp *dpbp;

		dpbp = sys_get_handle(FSL_MOD_DPBP, 1, cfg->pools[i].dpbp_id);
		CHECK_COND_RETVAL(dpbp, -EINVAL,
				"Cntrl_if: dpbp_id %d not found\n",
				cfg->pools[i].dpbp_id);

		if (cfg->pools[i].backup_pool)
			pools_cfg = &ctrl_if->backup_pools_cfg;
		else
			pools_cfg = &ctrl_if->pools_cfg;

		pools_cfg->pools[ctrl_if->pools_cfg.num_dpbp].dpbp = dpbp;
		pools_cfg->pools[ctrl_if->pools_cfg.num_dpbp].buffer_size =
				cfg->pools[i].buffer_size;

		err = check_pool_cfg(&pools_cfg->pools[ctrl_if->pools_cfg.num_dpbp]);
		CHECK_COND_RETVAL(!err, err);

		pools_cfg->num_dpbp++;
	}
	CHECK_COND_RETVAL(ctrl_if->pools_cfg.num_dpbp, -EINVAL,
			"Ctrl_if: must have at least one regular pool\n");

	return 0;
}

int ctrl_if_create(struct ctrl_if *ctrl_if, const struct ctrl_if_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg)
{
	int err;

	err = ctrl_if_save_and_init_cfg(ctrl_if, cfg, dev_cfg);
	CHECK_COND_GOTO(!err, err_out);

	err = ctrl_if_resourses_allocation(ctrl_if);
	CHECK_COND_GOTO(!err, err_out);

	err = ctrl_if_set_dev_ctx(ctrl_if, &dev_cfg->ctx);
	CHECK_COND_GOTO(!err, err_out);

	err = ctrl_if_initialize(ctrl_if);
	CHECK_COND_GOTO(!err, err_out);

	return 0;

err_out:
	ctrl_if_destroy(ctrl_if);
	return err;
}

int ctrl_if_set_dev_ctx (struct ctrl_if *ctrl_if,
		const struct dpmng_dev_ctx *dev_ctx)
{
	int err = 0;

	if (!memcmp(&ctrl_if->amq, &(dev_ctx->amq), sizeof(struct dpmng_amq)))
		return 0;

	//ASSERT_COND(!dpni->enabled);
	ctrl_if_resources_deauthorization( ctrl_if);

	memcpy(&ctrl_if->amq, &dev_ctx->amq, sizeof(struct dpmng_amq));

	ctrl_if->amq.bdi = (dev_ctx->type == DPMNG_CTX_TYPE_GPP) ? 0 : 1;

	err = ctrl_if_resources_authorization(ctrl_if);

	return err;
}

int ctrl_if_set_errors_behavior(struct ctrl_if *ctrl_if,
		struct ctrl_if_error_cfg *cfg)
{
	struct eiop_ifp_err_cfg err_cfg;
	uint32_t errors;

	errors = cfg->errors;
	memset(&err_cfg, 0, sizeof(struct eiop_ifp_err_cfg));

	if (cfg->error_action == CTRL_IF_ERROR_ACTION_DISCARD) {
		err_cfg.action = EIOP_IFP_ERR_DROP;
		errors |= CTRL_IF_ERRORS_TO_DISCARD;
	} else {
		err_cfg.action = (cfg->error_action == CTRL_IF_ERROR_ACTION_CONTINUE) ?
				EIOP_IFP_ERR_ENQ : EIOP_IFP_ERR_ENQ_TO_ERR_Q;

		if (cfg->set_frame_annotation)
			err_cfg.options = (EIOP_IFP_ERR_CFG_OPT_SET_FD_STATUS
					| EIOP_IFP_ERR_CFG_OPT_SET_FD_ERR);
	}

	eiop_ifp_set_err_behavior(&ctrl_if->rx_side_cfg.eiop_info.ifp_desc,
			errors, &err_cfg);

	ctrl_if->rx_side_cfg.errors_settings = EIOP_IFP_CFG_OPT_ERROR_SKIP_CFG;

	return 0;
}

static void ctrl_if_rx_reset_counters(struct ctrl_if *ctrl_if)
{
	ctrl_if_set_rx_counter(ctrl_if, E_INGRESS_FC, 0);
	ctrl_if_set_rx_counter(ctrl_if, E_INGRESS_BC, 0);
	ctrl_if_set_rx_counter(ctrl_if, E_INGRESS_FFC, 0);
	ctrl_if_set_rx_counter(ctrl_if, E_INGRESS_FDC, 0);
	ctrl_if_set_rx_counter(ctrl_if, E_INGRESS_MFC, 0);
	ctrl_if_set_rx_counter(ctrl_if, E_INGRESS_MBC, 0);
	ctrl_if_set_rx_counter(ctrl_if, E_INGRESS_BFC, 0);
	ctrl_if_set_rx_counter(ctrl_if, E_INGRESS_BBC, 0);
}

static int ctrl_if_reset_tx_if_id_counter(struct ctrl_if *ctrl_if, int if_id)
{
	int err = 0;

	err =  ctrl_if_set_tx_if_id_counter(ctrl_if, if_id, E_EGRESS_FC, 0);
	CHECK_COND_RETVAL(!err, err);

	err = ctrl_if_set_tx_if_id_counter(ctrl_if, if_id, E_EGRESS_BC, 0);
	ASSERT_COND(err == 0);

	err = ctrl_if_set_tx_if_id_counter(ctrl_if, if_id, E_EGRESS_FDC, 0);
	ASSERT_COND(err == 0);

	err = ctrl_if_set_tx_if_id_counter(ctrl_if, if_id, E_EGRESS_MFC, 0);
	ASSERT_COND(err == 0);

	err = ctrl_if_set_tx_if_id_counter(ctrl_if, if_id, E_EGRESS_MBC, 0);
	ASSERT_COND(err == 0);

	err = ctrl_if_set_tx_if_id_counter(ctrl_if, if_id, E_EGRESS_BFC, 0);
	ASSERT_COND(err == 0);

	err = ctrl_if_set_tx_if_id_counter(ctrl_if, if_id, E_EGRESS_BBC, 0);
	ASSERT_COND(err == 0);

	err = ctrl_if_set_tx_if_id_counter(ctrl_if, if_id, E_EGRESS_STDC, 0);
	ASSERT_COND(err == 0);

	return 0;
}

int ctrl_if_get_rx_counter(struct ctrl_if *ctrl_if, enum counter_type counter,
	uint64_t *value)
{
	*value = eiop_ifp_get_counter(
			&ctrl_if->rx_side_cfg.eiop_info.ifp_desc, counter);

	return 0;
}

int ctrl_if_set_rx_counter(struct ctrl_if *ctrl_if, enum counter_type counter,
	uint64_t value)
{
	eiop_ifp_set_counter(&ctrl_if->rx_side_cfg.eiop_info.ifp_desc,
			counter, value);

	return 0;
}

int ctrl_if_get_tx_if_id_counter(struct ctrl_if *ctrl_if, int if_id,
		enum counter_type counter, uint64_t *value)
{
	struct ctrl_if_info *if_info;

	CHECK_COND_RETVAL(if_id < ctrl_if->num_ifs, -EINVAL,
			"if_id = %d should be in the range - 0 - %d \n",
			if_id, ctrl_if->num_ifs - 1);

	if_info = &ctrl_if->tx_side_cfg.iface[if_id];
	*value = eiop_ifp_get_counter(
			&if_info->eiop_info.ifp_desc, counter);

	return 0;
}

int ctrl_if_set_tx_if_id_counter(struct ctrl_if *ctrl_if, int if_id,
		enum counter_type counter, uint64_t value)
{
	struct ctrl_if_info *if_info;

	CHECK_COND_RETVAL(if_id < ctrl_if->num_ifs, -EINVAL,
			"if_id = %d should be in the range - 0 - %d \n",
			if_id, ctrl_if->num_ifs - 1);

	if_info = &ctrl_if->tx_side_cfg.iface[if_id];
	eiop_ifp_set_counter(&if_info->eiop_info.ifp_desc,
			counter, value);

	return 0;
}

static inline int check_dest_cfg(struct ctrl_if *ctrl_if,
	const struct ctrl_if_dest_cfg *cfg)
{
	struct dpio *dpio;

	if (cfg->dest_type == CTRL_IF_DEST_DPIO) {
		dpio = sys_get_handle(FSL_MOD_DPIO, 1, cfg->dest_id);
		CHECK_COND_RETVAL(dpio, -EINVAL, "dpio_id is invalid\n");

		CHECK_COND_RETVAL(dpio_is_priority_in_range(dpio, cfg->priority),
				-EINVAL, "priority not in range\n");
	}

	return 0;
}

int ctrl_if_set_rx_flow(struct ctrl_if *ctrl_if, uint16_t flow_id,
	const struct ctrl_if_queue_cfg *cfg)
{
	struct ctrl_if_queue_info *info;
	int err;

	CHECK_COND_RETVAL(flow_id < ctrl_if->max_num_of_rx_flows, -EINVAL,
			"flow_id (%d) must be smaller than %d\n",
			flow_id, ctrl_if->max_num_of_rx_flows);

	if (cfg->options == 0)
		return 0;

	if (cfg->options & CTRL_IF_QUEUE_OPT_DEST) {
		err = check_dest_cfg(ctrl_if, &cfg->dest_cfg);
		CHECK_COND_RETVAL(!err, err);
	}

	info = &ctrl_if->rx_side_cfg.queue_cfg[flow_id];
	ASSERT_COND(info);

	if (cfg->options & CTRL_IF_QUEUE_OPT_DEST)
		memcpy(&info->dest_cfg, &cfg->dest_cfg,
				sizeof(struct ctrl_if_dest_cfg));
	if (cfg->options & CTRL_IF_QUEUE_OPT_USER_CTX)
		info->user_ctx = cfg->user_ctx;

	err = config_fqid(ctrl_if->dpmng, &ctrl_if->amq, info);
	return err;
}

int ctrl_if_set_rx_err_queue(struct ctrl_if *ctrl_if,
		const struct ctrl_if_queue_cfg *cfg)
{
	struct ctrl_if_queue_info *info;
	int err;

	if (cfg->options == 0)
		return 0;

	if (cfg->options & CTRL_IF_QUEUE_OPT_DEST) {
		err = check_dest_cfg(ctrl_if, &cfg->dest_cfg);
		CHECK_COND_RETVAL(!err, err);
	}

	info = &ctrl_if->rx_side_cfg.err_queue_cfg;
	CHECK_COND_RETVAL(info, -EINVAL, "RX_ERR queue configuration not found!");

	if (cfg->options & CTRL_IF_QUEUE_OPT_DEST)
		memcpy(&info->dest_cfg, &cfg->dest_cfg,
				sizeof(struct ctrl_if_dest_cfg));
	if (cfg->options & CTRL_IF_QUEUE_OPT_USER_CTX)
		info->user_ctx = cfg->user_ctx;

	err = config_fqid(ctrl_if->dpmng, &ctrl_if->amq, info);
	return err;
}

int ctrl_if_set_tx_err_conf_queue(struct ctrl_if *ctrl_if,
		const struct ctrl_if_queue_cfg *cfg)
{
	struct ctrl_if_queue_info *info;
	int err;

	if (cfg->options == 0)
		return 0;

	if (cfg->options & CTRL_IF_QUEUE_OPT_DEST) {
		err = check_dest_cfg(ctrl_if, &cfg->dest_cfg);
		CHECK_COND_RETVAL(!err, err);
	}

	info = &ctrl_if->tx_side_cfg.conf_err_queue_cfg;
	CHECK_COND_RETVAL(info, -EINVAL, "TX_ERR_CONF queue configuration not found!");

	if (cfg->options & CTRL_IF_QUEUE_OPT_DEST)
		memcpy(&info->dest_cfg, &cfg->dest_cfg,
				sizeof(struct ctrl_if_dest_cfg));
	if (cfg->options & CTRL_IF_QUEUE_OPT_USER_CTX)
		info->user_ctx = cfg->user_ctx;

	err = config_fqid(ctrl_if->dpmng, &ctrl_if->amq, info);

	return err;
}
