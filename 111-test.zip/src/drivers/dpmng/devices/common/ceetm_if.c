/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          ceetm_if.c

 @Description   Driver implementation

 @Cautions      None.
 *//***************************************************************************/
#include "ceetm_if.h"
#include "fsl_hmap.h"
#include "fsl_resman.h"
#include "fsl_qbman.h"
#include "fsl_eiop.h"
#include "drivers/fsl_qbman_ctrl.h"
#include "qbman_private.h"

static int create_save_params(struct ceetm_if *ceetm_if,
	struct ceetm_if_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg);

static int ccqs_default(struct ceetm_if *ceetm_if);
static int ccgs_default(struct ceetm_if *ceetm_if);

static void make_accesspoint_key(
	const struct dpmng_accesspoint *ap,
	hmap_key key);

static void get_accesspoint_from_key(
	struct dpmng_accesspoint *ap,
	const hmap_key key);

static int create_allocate_resources(struct ceetm_if *ceetm_if);

static void create_save_handles(struct ceetm_if *ceetm_if);

static int connect_accesspoint_allocate_resources(struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap);

static int disconnect_accesspoint_free_resources(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap);

static int ccqs_configure_accesspoints(struct ceetm_if *ceetm_if);

static int ccqs_configure_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap);

static int ccq_configure_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccqidx
	);

static int qpri_configure_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccqidx,
	int qprid);

static int scheduler_configure_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap
        );

static int configure_qdr(
	struct ceetm_if *ceetm_if
	);

static uint16_t get_ccqid(int ccqidx, enum ceetm_if_sched_mode mode);

static uint16_t get_composed_ccqid(uint16_t cqid,
	const struct dpmng_accesspoint  *ap);

static int ccqs_configure_qdbin(struct ceetm_if *ceetm_if);

static int configure_dct(struct ceetm_if *ceetm_if, int qdbinidx);

static int ccqs_configure_params_integrity(
	struct ceetm_if *ceetm_if, const struct ceetm_if_ccqs_cfg *ccqs);

static int ccqs_configure_params_save(
	struct ceetm_if *ceetm_if, const struct ceetm_if_ccqs_cfg *ccqs);

static int ccqs_configure(struct ceetm_if *ceetm_if);

static int ccg_configure_params_integrity(
	struct ceetm_if *ceetm_if,
	int cgidx,
	const struct ceetm_if_ccg_cfg *ccg);

static int ccg_configure_params_save(
	struct ceetm_if *ceetm_if,
	int cgidx,
	const struct ceetm_if_ccg_cfg *ccg);

static int ccg_configure(struct ceetm_if *ceetm_if, int cgidx);

static int ccg_configure_params_get(
	struct ceetm_if *ceetm_if,
	int cgidx,
	const struct ceetm_if_ccg_cfg *ccg);

static int ccgs_configure(struct ceetm_if *ceetm_if);

static int ccg_configure_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccgidx);

static int ccg_configure_accesspoint_mode_none(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccgidx);

static int ccg_configure_accesspoint_mode_tail(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccgidx);

static int ccg_configure_accesspoint_mode_wred(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccgidx);

static uint32_t get_ccg_count_mode(enum ceetm_if_ccg_unit unit);

static int scheduler_configure_accesspoint_eligibility(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap);

static int scheduler_configure_accesspoint_weights(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap);

static uint32_t normalize_delta_weight(uint32_t delta_weight);

static int set_transmit_rate_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	uint32_t committed_rate,
	uint32_t max_rate);

static uint32_t get_transmit_burst_size(uint32_t rate, uint32_t duration);

static int configure_disconnect(struct ceetm_if *ceetm_if);
static int qpri_configure_disconnect(struct ceetm_if *ceetm_if, int qprid);
static int get_attributes_num_ccqs(struct ceetm_if *ceetm_if);

struct ceetm_if *ceetm_if_create(struct ceetm_if_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
/*
 * 	- Allocate structure ceetm_if
 * 	- allocate hmap
 * 	- save parameters
 * 	- Initialize early_drop default
 * 	- Initialize tx_selection default
 * */
	int err = 0;
	struct ceetm_if *ceetm_if = NULL;

	/* Allocate structure ceetm_if */
	ceetm_if = (struct ceetm_if *)fsl_malloc(sizeof(struct ceetm_if));
	if (ceetm_if == NULL)
		return ceetm_if;

	/* reset database */
	memset(ceetm_if, 0x0, sizeof(struct ceetm_if));

	/* allocate hmap */
	ceetm_if->hmap_ap = hmap_create(CEETM_IF_MAX_QDBIN, KEY_SIZE);
	if (ceetm_if->hmap_ap == NULL)
		return NULL;

	/* save parameters */
	err = create_save_params(ceetm_if, cfg, dev_cfg);
	if (err != 0) {
		ceetm_if_destroy(ceetm_if);
		return NULL;
	}

	/* save handles */
	create_save_handles(ceetm_if);

	/* allocate required resources */
	err = create_allocate_resources(ceetm_if);
	if (err != 0) {
		ceetm_if_destroy(ceetm_if);
		return NULL;
	}

	/* Map QDID to QPri */
	err = configure_qdr(ceetm_if);
	if (err != 0) {
		ceetm_if_destroy(ceetm_if);
		return NULL;
	}

	/* associate qpri with default lfq */
	err = configure_disconnect(ceetm_if);
	if (err != 0) {
		ceetm_if_destroy(ceetm_if);
		return NULL;
	}

	/* Initialize tx_selection default */
	err = ccqs_default(ceetm_if);
	if (err != 0) {
		ceetm_if_destroy(ceetm_if);
		return NULL;
	}

	/* Initialize early_drop default */
	err = ccgs_default(ceetm_if);
	if (err != 0) {
		ceetm_if_destroy(ceetm_if);
		return NULL;
	}

	return ceetm_if;
}

static int create_save_params(struct ceetm_if *ceetm_if,
	struct ceetm_if_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
	int err = 0, i;

	if (cfg->num_qdbin > CEETM_IF_MAX_QDBIN)
		return -EINVAL;

	if (cfg->num_qpri > CEETM_IF_MAX_QPRI)
		return -EINVAL;

	memcpy(&(ceetm_if->dev), dev_cfg, sizeof(struct dpmng_dev_cfg));

	ceetm_if->num_qdbin = cfg->num_qdbin; 	/* distribution */
	ceetm_if->num_qpri = cfg->num_qpri;	/* number of queue priorities */
	ceetm_if->lfqid = cfg->lfqid;		/* disconnect lfq */

	for (i = 0; i < ceetm_if->num_qpri; i++) {
		ceetm_if->qpri[i].in_use = cfg->qpri[i].in_use;
	}
	return err;
}

static void create_save_handles(struct ceetm_if *ceetm_if)
{

	ceetm_if->handle.dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	ASSERT_COND(ceetm_if->handle.dpmng);
}

static int ccqs_default(struct ceetm_if *ceetm_if)
{
	int err = 0, i, ps = 0;
	struct ceetm_if_ccqs_cfg ccqs;

	memset(&ccqs, 0x0, sizeof(struct ceetm_if_ccqs_cfg));


	for (i = 0; i < ceetm_if->num_qpri; i++) {
		ccqs.ccqidx[i] = CEETM_IF_MAX_CCQIDX - 1;
	}

	ps = qbman_cacheable_pfdr();
	for (i = 0; i < CEETM_IF_MAX_CCQIDX; i++) {
		ccqs.ccq[i].mode = CEETM_IF_SCHED_STRICT_PRIORITY;
		ccqs.ccq[i].delta_bandwidth = 0;/* weighted Bandwidth */
		ccqs.ccq[i].ccgidx = 0;		/* congestion group index */
		ccqs.ccq[i].pps = 0;		/* PFDR Pool Selection */
		ccqs.ccq[i].ps = ps;		/* PFDR stashing */
	}

	/* Configure class queues */
	err = ceetm_if_ccqs_configure(ceetm_if, &ccqs);

	return err;
}

static int ccgs_default(struct ceetm_if *ceetm_if)
{
	int err = 0, i;
	struct ceetm_if_ccg_cfg 	ccg;

	memset(&ccg, 0x0, sizeof(struct ceetm_if_ccg_cfg));
	ccg.mode = CEETM_IF_CCG_MODE_NONE;

	for (i = 0; i < CEETM_IF_MAX_CCGIDX; i++) {
		/* Configure congestion group */
		err = ceetm_if_ccg_configure(ceetm_if, i, &ccg);
		if (err != 0)
			return err;
	}

	return err;
}

void ceetm_if_destroy(struct ceetm_if *ceetm_if)
{
	/*
	 * 	- Free hmap
	 * 	- free memory
	 */

	/* free hmap */
	if (ceetm_if->hmap_ap != NULL)
		hmap_destroy(ceetm_if->hmap_ap);

	/* free memory */
	fsl_free(ceetm_if);
}

int ceetm_if_connect_accesspoint(struct ceetm_if *ceetm_if,
                        const struct dpmng_accesspoint  *ap,
                        const struct dpmng_amq  *amq)
{
	/*
	 * 	- Verify Parameters
	 * 	- Add accesspoint to accesspoint database
	 * 	- Update qdbin database
	 * 	- ceetm_if_configure()
	 * */
	int err = 0;
	struct ceetm_if_qdbin	*qdbin;
	int i, max_qdbin_idx;
	struct ceetm_if *ceetm_if_lag_master = NULL;

	if (ceetm_if->is_lag_enabled)
		max_qdbin_idx = ceetm_if->lag_if_cfg.num_lag_ports;
	else
		max_qdbin_idx = ceetm_if->num_qdbin;

	if (ceetm_if->is_lag_enabled)
	{
		if (ceetm_if->lag_if_cfg.lag_master == NULL)
		{
			ceetm_if_lag_master = ceetm_if;
			ceetm_if_lag_master->lag_if_cfg.last_used_lfq_idx = 0;
		}
		else
			ceetm_if_lag_master = ceetm_if->lag_if_cfg.lag_master;
	}
	else
		ceetm_if_lag_master = ceetm_if;

	for (i = 0; i < max_qdbin_idx; i++) {
		/* obtain qdbin */
		qdbin = &(ceetm_if->qdbin[i]);

		/* make key and save key */
		make_accesspoint_key(ap, qdbin->key);

		/* the AP is a single one so only add it once to the database */
		if (i == 0) {
			/* Add accesspoint to accesspoint database */
			err = hmap_add_key(ceetm_if->hmap_ap, qdbin->key);
			if ((err != 0) && (err != -EEXIST))
				return err;
		}

		/* Update qdbin database */
		memcpy(&(qdbin->amq), amq, sizeof(struct dpmng_amq));
		qdbin->ifpid = ap->ifpid;
		qdbin->valid = 1;
	}

	/* allocate lfq, dct */
	err = connect_accesspoint_allocate_resources(ceetm_if, ap);
	if (err != 0)
		return err;

	/* configure ceetm congestion groups */
	err = ccgs_configure(ceetm_if);
	if (err != 0)
		return err;

	/* configure ceetm class queues */
	err = ccqs_configure(ceetm_if);
	if (err != 0)
		return err;

	return err;
}

int ceetm_if_disconnect_accesspoint(struct ceetm_if *ceetm_if,
                        const struct dpmng_accesspoint  *ap)
{
	/*
	 *  - make key
	 *  - go over all qdbins database and find accesspoint
	 *  - if accesspoint found - mark as invalid
	 *  - remove accesspoint from accesspoint database
	 *  - free resources (lfq, dct)
	 * */

	int 			err = 0, i, cmp, count;
        uint8_t 		key[KEY_SIZE];  /* accesspoint key */
        struct ceetm_if_qdbin 	*qdbin;

	/* make key */
	make_accesspoint_key(ap, key);

        /* go over all qdbins database and find accesspoint */
        for (i = 0; i < ceetm_if->num_qdbin; i++) {
        	qdbin = &(ceetm_if->qdbin[i]);

        	if (qdbin->valid == 0)
        		continue;

		cmp = memcmp(qdbin->key, key, KEY_SIZE);
		if (cmp != 0)
			continue;

		/* accesspoint found */
		qdbin->valid = 0;
        }

        /* Remove accesspoint from accesspoint database */
        err = hmap_remove_key(ceetm_if->hmap_ap, key);
        if (err != 0)
        	return err;

	/* Obtain count of accesspoints */
	count = hmap_get_count(ceetm_if->hmap_ap);
	if (count == 0) {
		/* free resources (lfq, dct) */
		err = disconnect_accesspoint_free_resources(ceetm_if, ap);
		if (err != 0)
			return err;

		err = configure_disconnect(ceetm_if);
		if (err != 0)
			return err;
	}
	else {
		/* configure ceetm class queues */
		err = ccqs_configure(ceetm_if);
		if (err != 0)
			return err;
	}

	return err;
}

static void get_accesspoint_from_key(
	struct dpmng_accesspoint *ap,
	const hmap_key key)
{
	uint32_t	u_key;

	/* reset accesspoint */
	memset(ap, 0x0, sizeof(struct dpmng_accesspoint));

	/* Make uint32 key from string */
	u_key = MAKE_UINT32(MAKE_UINT16(key[3], key[2]),
	                    MAKE_UINT16(key[1], key[0]));

	/* set accesspoint */
	ap->iop_id 	= (int)u32_dec(u_key, 0, 4);
	ap->dcp_id 	= (int)u32_dec(u_key, 4, 4);
	ap->ceetm_id 	= (int)u32_dec(u_key, 8, 8);
	ap->cqchid	= (int)u32_dec(u_key, 16, 16);
}

static void make_accesspoint_key(
	const struct dpmng_accesspoint *ap,
	hmap_key key)
{
	uint32_t u_key;

	/* Make uint32 key */
	u_key = u32_enc(0, 4, (uint32_t)ap->iop_id);
	u_key |= u32_enc(4, 4, (uint32_t)ap->dcp_id);
	u_key |= u32_enc(8, 8, (uint32_t)ap->ceetm_id);
	u_key |= u32_enc(16, 16, (uint32_t)ap->cqchid);

	/* make string key */
	key[0] = UINT8_LO(UINT16_LO(u_key));
	key[1] = UINT8_HI(UINT16_LO(u_key));
	key[2] = UINT8_LO(UINT16_HI(u_key));
	key[3] = UINT8_HI(UINT16_HI(u_key));
}

static int create_allocate_resources(struct ceetm_if *ceetm_if)
{
/*
 * 	-QDID
 * 	-QPRI
 *
 * */
	int err = 0, i, qprid[CEETM_IF_MAX_QPRI];

	/* QDID */
        err = allocate_resource(ceetm_if->dev.device, /*Res manager handle */
                                "qd", 		/* Resource type */
                                1, 		/* Number of resources*/
                                1, 		/* Base align */
                                0, 		/* Options */
                                &(ceetm_if->qdid), /* Address */
                                "QDID"); 	/* Error string */
        if (err != 0)
                return err;

        /* QPRI */
        err = allocate_resource(ceetm_if->dev.device, /*Res manager handle */
                                "qpr", 			/* Resource type */
                                (uint32_t)ceetm_if->num_qpri,/* # of resources */
                                1, 			/* Base align */
                                0, 			/* Options */
                                &(qprid[0]), 		/* Address */
                                "QPR"); 		/* Error string */
        if (err != 0)
                return err;

        /* copy QPRI ID into database */
        for (i = 0; i < ceetm_if->num_qpri; i++)
        	ceetm_if->qpri[i].id = qprid[i];

	return err;
}

static int connect_accesspoint_allocate_resources(struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap)
{
	/*
	 * 	- Obtain count of accesspoints
	 * 	- if the first access point
	 * 		a) allocate LFQ
	 * 		b) allocate DCT
	 * */
	int err = 0, count, i, lfqidx = 0;
	struct ceetm_if_qpri	*qpri;
	int max_qdbin_idx;

	if (ceetm_if->is_lag_enabled)
			max_qdbin_idx = ceetm_if->lag_if_cfg.num_lag_ports;
		else
			max_qdbin_idx = ceetm_if->num_qdbin;

	/* Obtain count of accesspoints */
	count = hmap_get_count(ceetm_if->hmap_ap);

	if (count > 1)
		return err;

	/* Allocate LFQ */
	for (i = 0; i < ceetm_if->num_qpri; i++){
		/* obtain qpri */
		qpri = &(ceetm_if->qpri[i]);

		/* Is QPri in use? */
		if (qpri->in_use == 0)
			continue;

		/* allocate LFQ from resource manager */
		/* for the time being take if from the first access point */
		memcpy(&(ceetm_if->qpri[i].lfqmtidx[0]),
		       &(ap->lfqmtidx[lfqidx]),
		       (uint32_t)(max_qdbin_idx * sizeof(int)));

		/* move index on */
		lfqidx += max_qdbin_idx;
	}

	/* allocate DCT */
	for (i = 0; i < max_qdbin_idx; i++) {
		ceetm_if->qdbin[i].dctidx = ap->dctidx[i];
	}
	return err;
}

static int disconnect_accesspoint_free_resources(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap)
{
	int err = 0;

	/* Free resources here */
	/* LFQ */
	/* DCT */
	return err;
}

static int ccqs_configure(struct ceetm_if *ceetm_if)
{
/*
 * 	- Go over accesspoints
 * 	- Go over traffic classes
 * 		a) configure weight
 * 		b) configure congestion group
 * 		- Go over QPri
 * 			c) Map QPri to LFQ
 * 			- Go over LFQ
 * 				d) Configure CQ
 * 				e) Configure LFQ
 *
 * */
	int err = 0;


	err = ccqs_configure_qdbin(ceetm_if);
	if (err != 0)
		return err;

	err = ccqs_configure_accesspoints(ceetm_if);

	return err;
}

static int ccqs_configure_accesspoints(struct ceetm_if *ceetm_if)
{
	int err = 0, iter, iter_status;
	void *info;
	uint8_t key[KEY_SIZE];
	struct dpmng_accesspoint  ap;

	/* Go over accesspoints */
	iter_status = hmap_get_start_iterator(ceetm_if->hmap_ap, &iter);

	while (iter_status == 0) {
		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(ceetm_if->hmap_ap, &iter, key,
						(void **)&info);

		/* obtain accesspoint */
		get_accesspoint_from_key(&ap, key);

		/* Configure accesspoint */
		err = ccqs_configure_accesspoint(ceetm_if, &ap);
		if (err != 0)
			return err;
	}
	return err;
}

static int ccqs_configure_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap)
{
	int err = 0, i;
	struct ceetm_if_ccqs_cfg *ccqs;
	int ccqidx;
	int	configure[CEETM_IF_MAX_CCQIDX];		/* class queue */
	struct ceetm_if *ceetm_if_lag_master = NULL;

	if (ceetm_if->is_lag_enabled)
	{
		ceetm_if_lag_master = (ceetm_if->lag_if_cfg.lag_master) ?
					ceetm_if->lag_if_cfg.lag_master : ceetm_if;
	}
	else
		ceetm_if_lag_master = ceetm_if;

	/* init traffic classes configured map */
	memset(&configure, 0x0, sizeof(int) * CEETM_IF_MAX_CCQIDX);

	/* Obtain transmission selection */
	ccqs = &(ceetm_if->ccqs);

	/* Go over traffic classes */
	for (i = 0; i < ceetm_if->num_qpri; i++) {

		/* Is QPri in use?*/
		if (ceetm_if->qpri[i].in_use == 0)
			continue;

		/* Obtain traffic class */
		ccqidx = ccqs->ccqidx[i];

		/* configure traffic class */
		if (configure[ccqidx] == 0) {
			err = ccq_configure_accesspoint(
				ceetm_if, 	/* Context */
			        ap, 		/* Access point */
			        ccqidx);	/* Traffic class id */
			if (err != 0)
				return err;

			/* mark as already configured */
			configure[ccqidx] = 1;
		}

		/* Configure QPri */
		err = qpri_configure_accesspoint(
			ceetm_if, 	/* Context */
		        ap, 		/* Access point */
		        ccqidx,		/* Traffic class id */
		        i		/* QPri ID */
		        );
		if (err != 0)
			return err;

	}

	if (ceetm_if->is_lag_enabled)
		ceetm_if_lag_master->lag_if_cfg.last_used_lfq_idx++;

	/* Scheduler configure */
	err = scheduler_configure_accesspoint(
		ceetm_if, 	/* Context */
	        ap 		/* Access point */
	        );
	return err;
}

static int configure_qdr(struct ceetm_if *ceetm_if)
{
	int err = 0, i;
	uint16_t qprids[CEETM_IF_MAX_QPRI];
	struct qbman_swp *swp;

	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* reset array */
	memset(qprids, 0x0, sizeof(uint16_t) * CEETM_IF_MAX_QPRI);

	/* Initialize QPR array */
	for (i = 0; i < ceetm_if->num_qpri; i++) {
		qprids[i] = (uint16_t)(ceetm_if->qpri[i].id);
	}

	/* (QDR) Queuing Destination Record Configure */
	err = qbman_qd_configure(
		swp, 				/* QMan Software portal */
		(uint16_t)(ceetm_if->qdid), 	/* QDID */
		qprids); 			/* Array of QPRID's */

	return err;
}

static int ccq_configure_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccqidx
	)
{
/*
 * 	- get software portal
 * 	- convert ccqidx to cqid
 * 	- obtain cgid
 * 	- compose ceetmid
 * 	- qbman_cq_configure
 * */
	int err = 0;
	struct qbman_swp *swp;
	uint16_t 	ccqid;
	uint32_t	ceetmid;
	struct ceetm_if_ccq_cfg	*ccq;

	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* Compose CEETM ID*/
	ceetmid = qbman_ceetmid_compose(
			(uint8_t)ap->dcp_id, 	/* DCP ID */
			(uint8_t)ap->ceetm_id); /* Instance ID */


	/* obtain class congestion group id */
	ccq = &(ceetm_if->ccqs.ccq[ccqidx]);

	/* obtain CEETM class queue id (ccqid) */
	ccqid = get_ccqid(ccqidx, ccq->mode);

	/* get composed class queue id */
	ccqid = get_composed_ccqid(ccqid, ap);

        /* CEETM CQ configuration */
        err = qbman_cq_configure(
                swp,            	/* QMan SW portal */
                ceetmid,        	/* CEETMID */
                ccqid,          	/* CQID */
                ccq->ccgidx,    	/* CGID */
                ccq->ps,		/* PFDR Stashing */
                ccq->pps);    		/* PFDR pool id */
        if (err != 0)
                return err;

	return err;
}

static uint16_t get_ccqid(int ccqidx, enum ceetm_if_sched_mode mode)
{
	int err = 0;
	struct qbman_desc desc;
	int cqid;

	memset(&desc, 0x0, sizeof(struct qbman_desc));

	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				0, /* match options*/
				&desc, /* descriptor */
				NULL); /* iterator */
	ASSERT_COND(err == 0);

	/* Numerically higher traffic class has higher priority */
	cqid = (CEETM_IF_MAX_CCQIDX - 1) - ccqidx;

	/* Weighted class queues start from ceetm_weight_pri_q_base */
	cqid = (mode == CEETM_IF_SCHED_STRICT_PRIORITY) ?
		cqid : (cqid + (int)desc.ceetm_weight_pri_q_base);

	return (uint16_t)cqid;
}

static uint16_t get_composed_ccqid(uint16_t cqid,
	const struct dpmng_accesspoint  *ap)
{
	/*
	 * 	bits 0 - 3	Class Queue
	 * 	bits 4 - 12	Ceetm Channel
	 * */
	
	return (uint16_t)((ap->cqchid << 4) | cqid);
}

static int qpri_configure_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccqidx,
	int qprid)
{
/*
 * 	- go over qdbin
 * 	- if qdbin valid
 * 		compose lfq
 * 		obtain cqid
 *
 * 		- qbman_lfq_configure
 * 		- qbman_qpr_configure
 * */
	int err = 0, i = 0;
	void 		*swp;
	uint16_t 	ccqid;
	uint32_t 	lfqid = 0, ccgid, lfqidx = 0, max_qdbin_idx = 0;
	struct ceetm_if_ccq_cfg *ccq;
	struct ceetm_if *ceetm_if_lag_master = NULL;
	struct dpmng_accesspoint ap_lag_master = {0};

	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* if this interface is part of a LAG group then the master
	 * should already be known at this point; if not part of a LAG
	 * group the master "is" the interface itself
	 */

	if (ceetm_if->is_lag_enabled)
		max_qdbin_idx = (uint32_t)ceetm_if->lag_if_cfg.num_lag_ports;
	else
		max_qdbin_idx = (uint32_t)ceetm_if->num_qdbin;

	if (ceetm_if->is_lag_enabled)
	{
		ceetm_if_lag_master = (ceetm_if->lag_if_cfg.lag_master) ?
					ceetm_if->lag_if_cfg.lag_master : ceetm_if;
		lfqidx = (uint32_t)ceetm_if_lag_master->lag_if_cfg.last_used_lfq_idx;
	}
	else
		ceetm_if_lag_master = ceetm_if;

	/* obtain class congestion group id */
	ccq = &(ceetm_if->ccqs.ccq[ccqidx]);

	/* obtain CEETM class queue id (ccqid) */
	ccqid = get_ccqid(ccqidx, ccq->mode);

	/* get composed class queue id */
	ccqid = get_composed_ccqid(ccqid, ap);
	
	/* get accesspoint */
	if ((ceetm_if->is_lag_enabled) && (ceetm_if->lag_if_cfg.lag_master != NULL))
		get_accesspoint_from_key(&ap_lag_master, ceetm_if_lag_master->qdbin[lfqidx].key);
	else
		memcpy(&ap_lag_master, ap, sizeof(struct dpmng_accesspoint));

	lfqid = qbman_lfqid_compose(
			(uint8_t)ap_lag_master.dcp_id, 		/* DCP ID */
			(uint8_t)ap_lag_master.ceetm_id, 		/* CEETM instance */
			(uint16_t)(ceetm_if_lag_master->qpri[qprid].lfqmtidx[lfqidx]));

	/* Mapping LFQID/CQ/DCT */
	err = qbman_lfq_configure(
		swp,            /* QMan SW Portal */
		lfqid,          /* LFQID */
		ccqid,           /* CQ ID */
		(uint16_t)(ceetm_if_lag_master->qdbin[lfqidx].dctidx), /* DCTIDX */
		0);               /* Error FQID */
	if (err != 0)
		return err;
	
	/* obtain class congestion group id */
	ccgid = (uint32_t)ceetm_if->ccqs.ccq[ccqidx].ccgidx;

	/* Compose LFQID */
	lfqid = qbman_lfqid_compose(
		(uint8_t)ap_lag_master.dcp_id, 		/* DCP ID */
		(uint8_t)ap_lag_master.ceetm_id, 		/* CEETM instance */
		(uint16_t)(ceetm_if->qpri[qprid].lfqmtidx[0]));

	/* Mapping QPri to LFQID */
	 err = qbman_qpr_configure(
			 swp,                    /* QMan Software portal */
			 (uint16_t)(ceetm_if->qpri[qprid].id),   /* QPRIID*/
			 lfqid,                  /* LFQID base */
			 max_qdbin_idx,          /* distribution */
			 ccgid);                 /* CGID */

	return err;
}

static int ccqs_configure_qdbin(struct ceetm_if *ceetm_if)
{
	int err = 0, i;
	int max_qdbin_idx;

	if (ceetm_if->is_lag_enabled)
		max_qdbin_idx = ceetm_if->lag_if_cfg.num_lag_ports;
	else
		max_qdbin_idx = ceetm_if->num_qdbin;

	for (i = 0; i < max_qdbin_idx; i++) {
		if (ceetm_if->qdbin[i].valid == 0)
				continue;

		/* Configure dequeue context */
		err = configure_dct(ceetm_if, i);
		if (err != 0)
			return err;
	}	
	return err;
}

static int configure_dct(struct ceetm_if *ceetm_if, int idx)
{
	int err = 0;
	void 				*swp;
	struct dpmng_accesspoint 	ap;
	uint32_t 			ceetmid;
	struct ceetm_if_qdbin		*qdbin;
	struct eiop_fcead 		fcead;
	struct ceetm_if *ceetm_if_lag_master = NULL;

	/* if this interface is part of a LAG group then the master
	 * should already be known at this point; if not part of a LAG
	 * group the master "is" the interface itself
	 */
	if (ceetm_if->is_lag_enabled)
	{
		ceetm_if_lag_master = (ceetm_if->lag_if_cfg.lag_master) ?
					ceetm_if->lag_if_cfg.lag_master : ceetm_if;
	}
	else
		ceetm_if_lag_master = ceetm_if;
	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* get accesspoint */
	get_accesspoint_from_key(&ap, ceetm_if_lag_master->qdbin[idx].key);

	/* compose ceetmid */
	ceetmid = qbman_ceetmid_compose(
		(uint8_t)ap.dcp_id, 	/* DCP Id */
		(uint8_t)ap.ceetm_id); /* CEETM Id */

	/* obtain qdbin*/
	qdbin = &(ceetm_if_lag_master->qdbin[idx]);

	/* Setting IFP in de-queue context */
	memset(&fcead, 0x0, sizeof(struct eiop_fcead));
	EIOP_FCEAD_SET_IFPID(&fcead,  (&(ceetm_if->qdbin[idx]))->ifpid);

	/* Configure DCT */
	err = qbman_dct_configure(
			swp,            	/* QMan Software Portal */
			ceetmid,       		/* CEETM ID */
			(uint16_t)(qdbin->dctidx),/* dct index */
			qdbin->amq.bdi,        	/* BDI */
			qdbin->amq.va,         	/* Virtual Address */
			qdbin->amq.icid,       	/* icid */
			qdbin->amq.pl,         	/* Privilege level */
			((uint64_t)fcead.command1 << 32) | /* Context "hi" */
			(uint64_t)fcead.command2/* Context "lo" */
			);

	return err;
}

static int scheduler_configure_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap
        )
{
/*
 * 	- Configure A and B group ER/CR eligible
 * 	- qbman_cscheduler_set_cq_weight
 * 	- qbman_cscheduler_configure
 * */
	int err = 0;

	/* group A & B CR/ER eligibility*/
	err = scheduler_configure_accesspoint_eligibility(ceetm_if, ap);
	if (err != 0)
		return err;

	/* weights of credit based class queues */
	err = scheduler_configure_accesspoint_weights(ceetm_if, ap);
	if (err != 0)
		return err;


	return err;
}

static int scheduler_configure_accesspoint_eligibility(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap)
{
	int err = 0;
	struct qbman_attr 	attr;
	uint8_t 		cq_idx;
	uint32_t		ceetmid;
	struct qbman_swp 	*swp;
	int shaped = 1;

	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* Clear schedulaer attributes */
	qbman_cscheduler_attr_clear(&attr);

	/* QMan spec 193 */
	/* Set the combined group flag in the group priority configuration */
	/* 1 means the groups A and B are combined */
	qbman_cscheduler_set_group_b(&attr, 1);

	/* Set the priority of group A 0-7*/
	qbman_cscheduler_set_prio_a(&attr, 7);

	for (cq_idx = 0; cq_idx < CEETM_IF_MAX_CCQIDX; cq_idx++) {
		/* Committed rate eligibility 1 = CQ is CR eligible,
		 * the CQ index from 0 to 7 */
		qbman_cscheduler_set_crem_cq(&attr, cq_idx, shaped);

		/* Excess rate eligibility 1 = CQ is CR eligible,
		 * the CQ index from 0 to 7 */
		qbman_cscheduler_set_erem_cq(&attr, cq_idx, shaped);
	}

	/* Set group A's CR eligibility, 1 = group A is CR eligible */
	qbman_cscheduler_set_crem_group_a(&attr, shaped);

	/* Set group A's ER eligibility, 1 = group A is ER eligible */
	qbman_cscheduler_set_erem_group_a(&attr, shaped);

 	/* compose ceetmid */
	ceetmid = qbman_ceetmid_compose(
			(uint8_t)ap->dcp_id, 	/* DCP Id */
			(uint8_t)ap->ceetm_id); /* CEETM Id */

	/* Configure scheduler */
	err = qbman_cscheduler_configure(
			swp,
	                ceetmid,
	                (uint8_t)ap->cqchid,
			&attr);

	return err;
}

static int scheduler_configure_accesspoint_weights(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap)
{
	int err = 0, i, ccqidx;
	int	configured[CEETM_IF_MAX_CCQIDX];
	uint32_t	delta_weight, ceetmid;
	struct qbman_swp *swp;
	struct qbman_attr 	attr;
	struct ceetm_if_ccqs_cfg   	*ccqs;
	uint16_t	cqid;
	int csms;

	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* Obtain class queues configuration */
	ccqs = &(ceetm_if->ccqs);

	/* init traffic classes configured map */
	memset(&configured, 0x0, sizeof(int) * CEETM_IF_MAX_CCQIDX);

	/* Clear schedulaer attributes */
	qbman_cscheduler_attr_clear(&attr);

 	/* compose ceetmid */
	ceetmid = qbman_ceetmid_compose(
			(uint8_t)ap->dcp_id, 	/* DCP Id */
			(uint8_t)ap->ceetm_id); /* CEETM Id */

	/* Query attributes */
	err = qbman_cscheduler_query(swp, ceetmid, (uint8_t)ap->cqchid, 1,
				     &attr);
	if (err != 0)
		return err;

	for (i = 0; i < ceetm_if->num_qpri; i++) {
		if (ceetm_if->qpri[i].in_use == 0)
			continue;

		/* Obtain class queue index */
		ccqidx = ccqs->ccqidx[i];

		if (configured[ccqidx] == 1)
			continue;

		/* mark as already configured */
		configured[ccqidx] = 1;

		if (ccqs->ccq[ccqidx].mode == CEETM_IF_SCHED_WEIGHTED) {

			/* Obtain traffic class normalized weight */
			delta_weight = normalize_delta_weight(
				ccqs->ccq[ccqidx].delta_bandwidth);

			/* get CCQ ID */
			cqid = get_ccqid(ccqidx, CEETM_IF_SCHED_WEIGHTED);

			qbman_cscheduler_get_csms(&attr, &csms);

			/* set traffic class bandwidth */
			qbman_cscheduler_set_cq_weight(
				&attr,
				cqid,
				delta_weight,
				csms);
		}
	}

	/* Configure scheduler */
	err = qbman_cscheduler_configure(
			swp,
	                ceetmid,
	                (uint8_t)ap->cqchid,
			&attr);

	return err;
}

static uint32_t normalize_delta_weight(uint32_t delta_weight)
{
	return (delta_weight * CEETM_IF_SCHED_MAX_CCQ_WEIGHT)/\
		CEETM_IF_SCHED_UPPER_BOUND;
}

int ceetm_if_ccqs_configure(struct ceetm_if *ceetm_if,
        const struct ceetm_if_ccqs_cfg *ccqs)
{
	int err = 0;

	err = ccqs_configure_params_integrity(ceetm_if, ccqs);
	if (err != 0)
		return err;

	err = ccqs_configure_params_save(ceetm_if, ccqs);
	if (err != 0)
		return err;

	err = ccqs_configure(ceetm_if);

	return err;
}

int ceetm_if_ccg_configure(struct ceetm_if *ceetm_if,
                        int cgidx,
                        const struct ceetm_if_ccg_cfg *ccg)
{
	int err = 0;

	err = ccg_configure_params_integrity(ceetm_if, cgidx, ccg);
	if (err != 0)
		return err;

	err = ccg_configure_params_save(ceetm_if, cgidx, ccg);
	if (err != 0)
		return err;

	err = ccg_configure(ceetm_if, cgidx);

	return err;
}

void ceetm_if_ccg_get_config(struct ceetm_if *ceetm_if,
        int cgidx,
        const struct ceetm_if_ccg_cfg *ccg)
{
	ccg_configure_params_get(ceetm_if, cgidx, ccg);
}

static int ccqs_configure_params_integrity(
	struct ceetm_if *ceetm_if, const struct ceetm_if_ccqs_cfg *ccqs)
{
	int err = 0, i;
	uint8_t ccqidx, ccgidx;

	/* check ccq indexes */
	for (i = 0; i < ceetm_if->num_qpri; i++) {
		if (ceetm_if->qpri[i].in_use == 0)
			continue;

		/* obtain class queue index */
		ccqidx = ccqs->ccqidx[i];

		/* check range */
		if (ccqidx >= CEETM_IF_MAX_CCQIDX)
			return -EINVAL;

		/* obtain congestion index */
		ccgidx = ccqs->ccq[ccqidx].ccgidx;

		/* check range */
		if (ccgidx >= CEETM_IF_MAX_CCGIDX)
			return -EINVAL;
	}
	return err;
}

static int ccqs_configure_params_save(
	struct ceetm_if *ceetm_if, const struct ceetm_if_ccqs_cfg *ccqs)
{
	int err = 0;

	/* copy class queue parameters */
	memcpy(&(ceetm_if->ccqs), ccqs, sizeof(struct ceetm_if_ccqs_cfg));

	return err;
}

static int ccg_configure_params_integrity(
	struct ceetm_if *ceetm_if,
	int ccgidx,
	const struct ceetm_if_ccg_cfg *ccg)
{
	int err = 0;

	if (ccgidx >= CEETM_IF_MAX_CCGIDX)
		return -EINVAL;

	return err;
}

static int ccg_configure_params_save(
	struct ceetm_if *ceetm_if,
	int cgidx,
	const struct ceetm_if_ccg_cfg *ccg)
{
	int err = 0;

	memcpy(&(ceetm_if->ccg[cgidx]), ccg, sizeof(struct ceetm_if_ccg_cfg));

	return err;
}

static int ccg_configure_params_get(
	struct ceetm_if *ceetm_if,
	int cgidx,
	const struct ceetm_if_ccg_cfg *ccg)
{
	int err = 0;

	memcpy(ccg, &(ceetm_if->ccg[cgidx]), sizeof(struct ceetm_if_ccg_cfg));

	return err;
}

static int ccg_configure(struct ceetm_if *ceetm_if, int ccgidx)
{
	/*
	 * 	- go over all accesspoints
	 * 	- configure congestion group ccg_configure_accesspoint()
	 *
	 * */
        int err = 0;
        int iter, iter_status;
        void *info;
        uint8_t key[KEY_SIZE];
        struct dpmng_accesspoint  ap;

        /* Go over accesspoints */
        iter_status = hmap_get_start_iterator(ceetm_if->hmap_ap, &iter);

        while (iter_status == 0) {
                /* Retrieve vlan at iterator and updates iterator */
                iter_status = hmap_iterate(ceetm_if->hmap_ap, &iter, key,
                                                (void **)&info);

                /* obtain accesspoint */
                get_accesspoint_from_key(&ap, key);

                /* Configure accesspoint */
                err = ccg_configure_accesspoint(ceetm_if, &ap, ccgidx);
                if (err != 0)
                        return err;
        }

        return err;
}

static int ccgs_configure(struct ceetm_if *ceetm_if)
{
	/*
	 * 	- go over cqs configuration
	 * 	- configure all congestion groups
	 * */
	int err = 0, i;
	int	configure[CEETM_IF_MAX_CCGIDX];		/* class queue */
	uint8_t	ccqidx, ccgidx;
	struct ceetm_if_ccqs_cfg *ccqs;

	/* init traffic classes configured map */
	memset(&configure, 0x0, sizeof(int) * CEETM_IF_MAX_CCGIDX);

	/* Obtain transmission selection */
	ccqs = &(ceetm_if->ccqs);

	for (i = 0; i < ceetm_if->num_qpri; i++) {
		/* Is QPri in use?*/
		if (ceetm_if->qpri[i].in_use == 0)
			continue;

		/* Obtain traffic class */
		ccqidx = ccqs->ccqidx[i];

                /* obtain class congestion group index */
                ccgidx = ccqs->ccq[ccqidx].ccgidx;

                if (configure[ccgidx] == 0) {
                	err = ccg_configure(ceetm_if, ccgidx);
                	if (err != 0)
                		return err;

                	configure[ccgidx] = 1;
                }
	}
	return err;
}

static int ccg_configure_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccgidx)
{
	int err = 0;
	struct ceetm_if_ccg_cfg *ccg;

	/* Obtain Congestion groups */
	ccg = &(ceetm_if->ccg[ccgidx]);

	switch (ccg->mode) {
		case CEETM_IF_CCG_MODE_NONE:
			err = ccg_configure_accesspoint_mode_none(
				ceetm_if,
				ap,
				ccgidx);
			break;
		case CEETM_IF_CCG_MODE_TAIL:
			err = ccg_configure_accesspoint_mode_tail(
				ceetm_if,
				ap,
				ccgidx);
			break;
		case CEETM_IF_CCG_MODE_WRED:
			err = ccg_configure_accesspoint_mode_wred(
				ceetm_if,
				ap,
				ccgidx);
			break;
		default:
			err = -ENOTSUP;	/* Operation not supported */
			break;
	}

	return err;
}

static int ccg_configure_accesspoint_mode_none(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccgidx)
{
	int err = 0;
	struct qbman_attr 	attr;
	struct qbman_swp 	*swp;
	uint32_t 		ceetmid;

	/* Get ceetm id */
	ceetmid = qbman_ceetmid_compose(
		(uint8_t)ap->dcp_id, 		/* DCP Id */
		(uint8_t)ap->ceetm_id); 	/* CEETM Id */

	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* Clear attributes */
	qbman_ccgr_attr_clear(&attr);

	/* Disable tail drop */
	qbman_cgr_attr_set_td_ctrl(&attr, 0);

	/* Disable green drop priority */
	qbman_cgr_attr_wred_set_edp(&attr, CEETM_IF_DROPP_GREEN, 0);

	/* Disable yellow drop priority */
	qbman_cgr_attr_wred_set_edp(&attr, CEETM_IF_DROPP_YELLOW, 0);

	/* Configure wred drop */
	err = qbman_ccgr_configure(
		swp,				/* Software portal */
	        ceetmid, 			/* CEETM id */
	        (uint8_t)ap->cqchid,		/* channel id */
	        (uint8_t)ccgidx,		/* CCGR id */
	        &attr);				/* Attribute */

	return err;
}

static int ccg_configure_accesspoint_mode_tail(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccgidx)
{
	int err = 0;
	struct qbman_swp *swp;
	uint32_t ceetmid, count_mode;
	struct qbman_attr 	attr;
	struct ceetm_if_ccg_cfg *ccg;

	/* Obtain Congestion groups */
	ccg = &(ceetm_if->ccg[ccgidx]);

	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* Get ceetm id */
	ceetmid = qbman_ceetmid_compose(
		(uint8_t)ap->dcp_id, 	/* DCP Id */
		(uint8_t)ap->ceetm_id); 	/* CEETM Id */

	/* Clear attributes */
	qbman_ccgr_attr_clear(&attr);

	/* Set tail drop threshold */
	qbman_cgr_attr_set_td_thres(&attr, ccg->tail_drop_threshold);

	/* get count mode byte/farme 0-byte count, 1-frame count */
	count_mode = get_ccg_count_mode(ccg->units);

	/* set count mode */
	qbman_cgr_attr_set_mode(&attr,
		count_mode,			/* byte/frame count*/
		1);		 		/* reject count mode */

	/* Enable tail drop */
	qbman_cgr_attr_set_td_ctrl(&attr, 1);

	/* Configure tail drop */
	err = qbman_ccgr_configure(
		swp,				/* Software portal */
	        ceetmid, 			/* CEETM id */
	        (uint8_t)ap->cqchid,		/* channel id */
	        (uint8_t)ccgidx,		/* CCGR id */
	        &attr);				/* Attribute */

	return err;
}

static uint32_t get_ccg_count_mode(enum ceetm_if_ccg_unit unit) {

	uint32_t count_mode = 0;

	switch (unit) {
		case CEETM_IF_CCG_UNIT_BYTES:
			count_mode = 0;
			break;
		case CEETM_IF_CCG_UNIT_PACKETS:
			count_mode = 1;
			break;
		case CEETM_IF_CCG_UNIT_BUFFERS:
			count_mode = 2;
			break;
		default:
			break;
	}
	return count_mode;
}

static int ccg_configure_accesspoint_mode_wred(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	int ccgidx)
{
	int err = 0;
	struct qbman_swp 	*swp;
	uint32_t ceetmid, count_mode;
	struct qbman_attr 	attr;
	uint32_t		parm_dp;
	struct ceetm_if_ccg_cfg *ccg;

	/* Obtain Congestion groups */
	ccg = &(ceetm_if->ccg[ccgidx]);

	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* Get ceetm id */
	ceetmid = qbman_ceetmid_compose(
		(uint8_t)ap->dcp_id, 	/* DCP Id */
		(uint8_t)ap->ceetm_id); 	/* CEETM Id */

	/* Configure tail drop */
	qbman_ccgr_attr_clear(&attr);

	/* green drop priority */
	parm_dp = qbman_cgr_attr_wred_dp_compose(
		ccg->green.min_threshold, 	/* Minimum threshold */
		ccg->green.max_threshold,	/* Maximum threshold */
		ccg->green.drop_probability);	/* Maximum probability */

	/* Set green parameters */
	qbman_cgr_attr_wred_set_parm_dp(&attr, CEETM_IF_DROPP_GREEN, parm_dp);

	/* Enable green drop priority */
	qbman_cgr_attr_wred_set_edp(&attr, CEETM_IF_DROPP_GREEN, 1);

	/* Yellow drop priority */
	parm_dp = qbman_cgr_attr_wred_dp_compose(
		ccg->yellow.min_threshold, 	/* Minimum threshold */
		ccg->yellow.max_threshold,	/* Maximum threshold */
		ccg->yellow.drop_probability);/* Maximum probability */

	/* Set yellow parameters */
	qbman_cgr_attr_wred_set_parm_dp(&attr, CEETM_IF_DROPP_YELLOW, parm_dp);

	/* Enable yellow drop priority */
	qbman_cgr_attr_wred_set_edp(&attr, CEETM_IF_DROPP_YELLOW, 1);

	/* get count mode byte/farme 0-byte count, 1-frame count */
	count_mode = get_ccg_count_mode(ccg->units);

	/* configure count mode */
	qbman_cgr_attr_set_mode(&attr,
		count_mode,			/* byte/frame count*/
		1);		 		/* reject count mode */

	/* Configure wred drop */
	err = qbman_ccgr_configure(
		swp,				/* Software portal */
	        ceetmid, 			/* CEETM id */
	        (uint8_t)ap->cqchid,		/* channel id */
	        (uint8_t)ccgidx,		/* CCGR id */
	        &attr);				/* Attribute */

	return err;
}

int ceetm_if_set_transmit_rate(struct ceetm_if *ceetm_if,
                                uint32_t committed_rate,
                                uint32_t max_rate)
{
/*
 * 	- Go over all accesspoints
 * 	- configure committed and excess rates
 * */
	int err = 0, iter_status, iter;
	void *info;
	uint8_t key[KEY_SIZE];
	struct dpmng_accesspoint  ap;

	/* Go over accesspoints */
	iter_status = hmap_get_start_iterator(ceetm_if->hmap_ap, &iter);

	while (iter_status == 0) {

		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(ceetm_if->hmap_ap, &iter, key,
						(void **)&info);

		/* obtain accesspoint */
		get_accesspoint_from_key(&ap, key);

		/* Configure accesspoint */
		err = set_transmit_rate_accesspoint(
			ceetm_if,
			&ap,
			committed_rate,
			max_rate
			);
		if (err != 0)
			return err;
	}
	return err;
}

static int set_transmit_rate_accesspoint(
	struct ceetm_if *ceetm_if,
	const struct dpmng_accesspoint  *ap,
	uint32_t committed_rate,
	uint32_t max_rate)
{
	int err = 0;
	struct qbman_attr	attr;
	uint32_t		committed_bs, excess_bs, excess_rate;
	struct qbman_swp 	*swp;
	uint32_t 		ceetmid;

	excess_rate = max_rate - committed_rate;

	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* Get ceetm id */
	ceetmid = qbman_ceetmid_compose(
		(uint8_t)ap->dcp_id, 	/* DCP Id */
		(uint8_t)ap->ceetm_id); 	/* CEETM Id */

	/* query the shaper attribute structure */
	qbman_cchannel_shaper_query(
		swp,
		ceetmid,
		(uint8_t)ap->cqchid,
		&attr);

	/* Set commit rate to channel shaper */
	qbman_shaper_set_commit_rate(
		&attr, (uint64_t)committed_rate * CEETM_IF_MBIT_PER_SECOND);

	/* Get committed rate burst size */
	committed_bs = get_transmit_burst_size(
		committed_rate, CEETM_IF_BURST_DURATION);

	/* The token bucket limit,
	 * which is related to maximum burst size for shaper */
	qbman_shaper_set_crtbl(&attr, committed_bs);

	 /* Setting excess rate limiter */
	qbman_shaper_set_excess_rate(
		&attr, (uint64_t)excess_rate * CEETM_IF_MBIT_PER_SECOND);

	/* Get excess rate burst size */
	excess_bs = get_transmit_burst_size(
		excess_rate, CEETM_IF_BURST_DURATION);

	qbman_shaper_set_ertbl(&attr, excess_bs);

	/* Configure the CEETM channel shaper */
	err = qbman_cchannel_shaper_configure(
		swp, 				/* Software portal */
	        ceetmid, 			/* DCP + instance */
	        (uint32_t)ap->cqchid, 		/* Channel */
	        &attr);				/* Attributes */

	return err;
}

static uint32_t get_transmit_burst_size(uint32_t rate, uint32_t duration)
{
	uint32_t burst_size = 0, max_tbl;
	
	burst_size = (rate * CEETM_IF_MBIT_PER_SECOND * duration)/\
			(CEETM_IF_MS_IN_SECOND * 8);
	max_tbl = ceetm_if_get_max_tbl();
	
	if (burst_size > max_tbl) {
		pr_warn("Calculated burst size of 0x%x is bigger than max burst size 0x%x\n", burst_size, max_tbl);
		burst_size = max_tbl;
	}
		
	return burst_size;
}

void ceetm_if_get_attributes(struct ceetm_if *ceetm_if,
	struct ceetm_if_attr *attr)
{
	int i, k, j;
	struct dpmng_accesspoint 	ap;

	attr->num_qpri = ceetm_if->num_qpri;	/* QPri number */
	attr->num_qdbin = ceetm_if->num_qdbin;	/* distribution number */

	if (ceetm_if->lag_if_cfg.lag_master != NULL)
		attr->qdid = ceetm_if->lag_if_cfg.lag_master->qdid;
	else
		attr->qdid = ceetm_if->qdid;		/* QDID */

	attr->num_ccqs = get_attributes_num_ccqs(ceetm_if);
	memcpy(&(attr->ccqs), &(ceetm_if->ccqs), sizeof(struct ceetm_if_ccqs_cfg));

	for (i = 0; i < ceetm_if->num_qpri; i++) {
		attr->qpri[i].in_use = ceetm_if->qpri[i].in_use;

		/* save qprid (queue priority record id ) */
		attr->qpri[i].id = ceetm_if->qpri[i].id;

		if (ceetm_if->qpri[i].in_use == 0)
			continue;

		for (k = 0, j = 0; k < ceetm_if->num_qdbin; k++) {
			/* Is distribution valid? */
			if (ceetm_if->qdbin[k].valid == 0)
				continue;

			/* Obtain access point from the key */
			get_accesspoint_from_key(&ap, ceetm_if->qdbin[k].key);

			/* Compose LFQID */
			attr->qpri[i].lfqid[j] = qbman_lfqid_compose(
				(uint8_t)ap.dcp_id, 	/* DCP ID */
				(uint8_t)ap.ceetm_id, 	/* CEETM instance */
				(uint16_t)(ceetm_if->qpri[i].lfqmtidx[j]));
			j++;
		}
	}
	attr->lag_master = ceetm_if->lag_if_cfg.lag_master;
}

uint32_t ceetm_if_get_max_tbl(void)
{
	uint32_t qman_version = qbman_block_get_version();
	
	if ((qman_version & 0xFFFF0000) < QMAN_REV_5000)
			return 0xF7FF;
	
	return 0x37FFF;
}

static int configure_disconnect(struct ceetm_if *ceetm_if)
{
	int err = 0, i;

	for (i = 0; i < ceetm_if->num_qpri; i++) {
		/* Is QPri in use?*/
		if (ceetm_if->qpri[i].in_use == 0)
			continue;

		err = qpri_configure_disconnect(ceetm_if, i);
		if (err != 0)
			return err;
	}
	return err;
}

static int qpri_configure_disconnect(struct ceetm_if *ceetm_if, int id)
{
	int err = 0, max_qdbin_idx;
	struct qbman_swp *swp;

	/* Get software portal */
	dpmng_get_swportal(ceetm_if->handle.dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	if (ceetm_if->is_lag_enabled)
		max_qdbin_idx = ceetm_if->lag_if_cfg.num_lag_ports;
	else
		max_qdbin_idx = ceetm_if->num_qdbin;

	/* Mapping QPri to LFQID */
	err = qbman_qpr_configure(
		swp, /* QMan Software portal */
		(uint16_t)(ceetm_if->qpri[id].id), /* QPRIID*/
		(uint32_t)ceetm_if->lfqid, /* LFQID base */
		(uint32_t)max_qdbin_idx, /* distribution */
		0); /* CGID */
	if (err != 0)
		return err;

	return err;
}

static int get_attributes_num_ccqs(struct ceetm_if *ceetm_if)
{
	int ccqidx, num_ccqs = 0, i;
	int configured[CEETM_IF_MAX_CCQIDX];
	struct ceetm_if_ccqs_cfg   	*ccqs;

	/* Obtain class queue configuration */
	ccqs = &(ceetm_if->ccqs);

	/* init class queues configured database */
	memset(&configured, 0x0, sizeof(int) * CEETM_IF_MAX_CCQIDX);

	/* count class queues */
	for (i = 0; i < ceetm_if->num_qpri; i++) {
		if (ceetm_if->qpri[i].in_use == 0)
			continue;

		/* Obtain class queue index */
		ccqidx = ccqs->ccqidx[i];

		if (configured[ccqidx] == 1)
			continue;

		/* mark as already configured */
		configured[ccqidx] = 1;

		/* count */
		num_ccqs++;
	}
	return num_ccqs;
}

void set_ceetm_lag_conf(struct ceetm_if *ceetm_if, struct ceetm_if *ceetm_if_master, int group_id, int num_ifs)
{
	ceetm_if->is_lag_enabled = 1;
	ceetm_if->lag_if_cfg.lag_group_index = group_id;
	ceetm_if->lag_if_cfg.num_lag_ports = num_ifs;
	if (ceetm_if_master != NULL)
		ceetm_if->lag_if_cfg.lag_master = ceetm_if_master;
}

int ceetm_if_is_lag_master(struct ceetm_if *ceetm_if)
{
	return (ceetm_if->lag_if_cfg.lag_master == NULL)? 1 : 0;
}

