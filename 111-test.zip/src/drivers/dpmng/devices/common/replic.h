/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          replic.h

 @Description   one_line_brief_description

 @Cautions      None.
 *//***************************************************************************/

#ifndef __REPLIC_H
#define __REPLIC_H

#include "fsl_types.h"
#include "common/fsl_string.h"			/* memcpy */
#include "fsl_errors.h"				/* errors */
#include "fsl_platform.h"			/* sys_get_handle */
#include "fsl_resman.h"				/* get SWP */
#include "fsl_dpmng_mc.h"			/* get SWP */
#include "fsl_replic.h"

/**************************************************************************//**
@Description   replic - Replication Group module used for handling 
						multicast groups, flooding etc.

 *//***************************************************************************/
struct replic_element {
    int             inuse;      /*! in use flag */
    int             rrid;     /*! ID */
    uint64_t        opaque;
};

struct replic {
        /*! data base */
        struct replic_element 	*element;
        int 			num_elements;
        int 			head_id;

        /* Handles */
        struct device  		*dprc;      	/*! Resource manager */
};

#endif /* __REPLIC_H */

