/*
 * Copyright 2013-2020 NXP
 */

#ifndef _CEETM_IF_H
#define _CEETM_IF_H

#include "fsl_types.h"
#include "fsl_ceetm_if.h"

#define KEY_SIZE			4
#define CEETM_IF_DROPP_GREEN		0
#define CEETM_IF_DROPP_YELLOW		1
#define CEETM_IF_DROPP_RED		2
#define CEETM_IF_SCHED_MAX_CCQ_WEIGHT 	24800
#define CEETM_IF_SCHED_UPPER_BOUND 	10000
#define CEETM_IF_SCHED_LOWER_BOUND 	100
#define CEETM_IF_BURST_DURATION  	5	/* five milliseconds */
#define CEETM_IF_MS_IN_SECOND		1000UL
#define CEETM_IF_KBIT_PER_SECOND	1000UL
#define CEETM_IF_MBIT_PER_SECOND	(CEETM_IF_KBIT_PER_SECOND * \
						CEETM_IF_KBIT_PER_SECOND)
#define CEETM_IF_GBIT_PER_SECOND	(CEETM_IF_KBIT_PER_SECOND * \
						CEETM_IF_MBIT_PER_SECOND)

/**
 * @brief	CEETM IF internal data types 
 *
 */

struct ceetm_if_handle {
	struct dpmng        	*dpmng;     	/* General manager */
};

/* ceetm interface database */
struct ceetm_if_qpri {
        int id;                 /* qpri id */
        int lfqmtidx[CEETM_IF_MAX_QDBIN];  /* lfq consecutive indices */
        int in_use;             /* 1 = used for ceetm configuration */
                                /* 0 - reserved for control port */
        int last_used_idx;
};

struct ceetm_if_qdbin {
        int                     valid;          /* distribution valid */
        int                     dctidx;         /* de-queue context */
        int                     ifpid;          /* IFP for de-queue context */
        struct dpmng_amq        amq;            /* access management qualifier */
        uint8_t                 key[KEY_SIZE];  /* accesspoint key - iop, dct ceetm and cqch ids*/
};

struct ceetm_if_lag_cfg {
	struct ceetm_if *lag_master; /*points to NULL if interface is master, 
								   to master interface otherwise */
	int lag_group_index; /*index in the lag group - useful for determining first lfq index*/
	int num_lag_ports;
	int last_used_lfq_idx;
};

struct ceetm_if {
        int qdid;               /* qdid */
        int num_qpri;           /* number of QPRs */
        int num_qdbin;          /* distribution size */
        int lfqid;		/* disconnect lfq */
        struct ceetm_if_qpri    qpri[CEETM_IF_MAX_QPRI];/* QPRs information */
        struct hmap             *hmap_ap;               /* accesspoints collection */
        struct ceetm_if_qdbin   qdbin[CEETM_IF_MAX_QDBIN];/* distribution */

        /* Features */
        struct ceetm_if_ccg_cfg		ccg[CEETM_IF_MAX_CCGIDX];/* early configuration */
        struct ceetm_if_ccqs_cfg   	ccqs;           /* tx selection */

        struct dpmng_dev_cfg 	dev;	/* device configuration */
        struct ceetm_if_handle  handle;
        
        /* LAG */
        int is_lag_enabled;
		struct ceetm_if_lag_cfg lag_if_cfg; /*points to NULL if LAG not enabled,
		 	 	 	 	 	 	 	 	 	 to LAG configuration if enabled*/	
};

#endif /* _CEETM_IF_H */
