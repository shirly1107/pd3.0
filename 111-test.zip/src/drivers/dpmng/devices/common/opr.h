/*
 * Copyright 2013-2020 NXP
 */

#ifndef _OPR_H
#define _OPR_H

//OPR Config offsets
#define OPR_CONFIG_OPRRWS_O 0
#define OPR_CONFIG_OLOE_O 7
#define OPR_CONFIG_OEANE_O 6
#define OPR_CONFIG_OLWS_O 4
#define OPR_CONFIG_OA_O 3

#define OPR_CONFIG_DISABLED 0
#define OPR_CONFIG_ENABLED 1

#define OPR_MAX_OPRRWS 5
#define OPR_MAX_OLOE 1
#define OPR_MAX_OEANE 1
#define OPR_MAX_OLWS 3
#define OPR_MAX_OA 1

#endif /* _OPR_H */
