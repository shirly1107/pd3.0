/*
 * Copyright 2020 NXP
 */

#define FLOW_CONTROL_INVALID_INDEX		-1

/* return next valid index to be used in flow control configuration */
int fc_get_next_channel_idx();

/* release the index to be used in flow control configuration */
void fc_release_channel_idx(int idx);
