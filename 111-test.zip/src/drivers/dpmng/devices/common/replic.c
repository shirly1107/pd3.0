/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          replic.c

 @Description   Driver implementation

 @Cautions      None.
 *//***************************************************************************/
#include "replic.h"

int replic_query_element_rrid(int rrid,
                        struct replic_element_info *rr)
{
	int err;
	struct qbman_swp 	*swp;
	uint16_t		qdid, next_rrid, icid;
	uint32_t 		fqid;
        struct dpmng 		*dpmng;
        
	dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	ASSERT_COND(dpmng);
	
        /* Get software portal */
        dpmng_get_swportal(dpmng, (void **)&(swp));
       	ASSERT_COND(swp);

	err = qbman_rr_query(
		swp,
		(uint16_t)rrid,			/*! Replication Record ID */
		&qdid,				/*! QDID */
		&next_rrid,			/*! next RR  */
		&icid, 				/*! ICID */
		&fqid,				/*! return fqid */
		NULL);
	if (err != 0)
		return err;

	rr->icid = icid;			/*! ICID */
	rr->next_rrid = next_rrid;		/*! next RR  */
	rr->qdid = qdid;			/*! QDID */
	rr->fqid = (int)fqid;			/*! Return FQID */
	return err;
}

int replic_config_element_rrid(int rrid,
                         struct replic_element_info *rr)
{
	int err = 0;
	struct qbman_swp 	*swp;
	struct dpmng 		*dpmng;
	/*
	 * QMan 4.1 Block Guide:
	 * RD - Return Destination (qman_4.1 and later versions)
	 *	0 = original FD will be returned on a queue, RTN_FQID_DCPID contains
	 * 		a FQID or a CEETM LFQID.
	 *	1 = original FD will be returned on a dedicated interface to WRIOP,
	 *		RTN_FQID_DCPID contains a DCP portal ID.
	 */
	uint8_t rd = 1;		/* Assume Rev2 - QMan 4.1 */

#ifdef TKT220573
	rd = 0;
#endif
	dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	ASSERT_COND(dpmng);
	
	dpmng_get_swportal(dpmng, (void **)&(swp));
       	ASSERT_COND(swp);

	err = qbman_rr_configure(swp, 		/* Software Portal */
		(uint16_t)rrid,			/* Replication Record ID */
		(uint16_t)rr->qdid,		/* QDID */
		(uint16_t)rr->next_rrid,	/* Next RPL */
		rr->icid,			/* ICID */
		(uint32_t)(rr->fqid),		/* Return FQID */
		rd);
	if (err != 0)
		return err;
	
	return err;
}

/**************************************************************************//**
@Description   replic - Replication Group module
			used for handling multicast groups, flooding etc. 

 *//***************************************************************************/
struct replic *replic_create(struct replic_cfg *cfg)
{
/*
 * 	Allocate object
 * 	Save handles
 * 	Allocate elements memory
 * 	Replication records
 */
	struct replic *replic;
	int err, i;
	int *arr;
	ASSERT_COND(cfg);
	if (cfg->num_elements < 1)
		return NULL;
		
	/*! Allocate object */
	replic = (struct replic *)fsl_malloc(sizeof(struct replic));
	if (replic == NULL)
		return replic;
	
	memset(replic, 0, sizeof(struct replic));

	/*! Save */
	replic->dprc = cfg->dprc;
	replic->num_elements = cfg->num_elements;
		
	/*! Allocate elements memory */
	replic->element = (struct replic_element *)fsl_malloc(
		sizeof(struct replic_element) * cfg->num_elements);
	if (replic->element == NULL) {
		pr_err("elements malloc failed\n");
		replic_destroy(replic);
		return NULL;		
	}
	memset(replic->element, 0x0, 
		sizeof(struct replic_element) * cfg->num_elements);
	
	arr = (int *)fsl_malloc(replic->num_elements * (sizeof(int)));
	if (arr == NULL) {
		fsl_free(replic->element);
		fsl_free(replic);
		return NULL;
	}
	
	err = allocate_resource(
				replic->dprc,		/* Resource mngr hndl */
				"rplr",			/* Resource type */
				(uint32_t)replic->num_elements, 			/* Number of resources*/
				1, 			/* Base align */
				0,			/* Options */
				arr,/* Address */
				"RPLR");		/* Error string */
		if (err != 0) {
			pr_err("allocate_resource failed\n");
			replic_destroy(replic);
			fsl_free(arr);
			return NULL;	
		}
		for (i = 0; i < replic->num_elements; i++) {
				replic->element[i].rrid = arr[i];
				
		}
	fsl_free(arr);
#if 0			
	for (i = 0; i < replic->num_elements; i++) {
		err = allocate_resource(
			replic->dprc,		/* Resource mngr hndl */
			"rplr",			/* Resource type */
			1, 			/* Number of resources*/
			1, 			/* Base align */
			0,			/* Options */
			&(replic->element[i].rrid),/* Address */
			"RPLR");		/* Error string */
		if (err != 0) {
			pr_err("allocate_resource failed\n");
			replic_destroy(replic);
			return NULL;		
		}
	}
#endif

	return replic;
}

void replic_destroy(struct replic *replic)
{
/*
 * Release Replication Records
 * free element array
 * free object
 */
	int i;
	/* Release Replication Records */
	for (i = 0; i < replic->num_elements; i++) {
		deallocate_resource(
			replic->dprc,			/* Resource mngr hndl */
			"rplr",				/* Resource type */
			replic->element[i].rrid,	/* Address */
			"RPLR");			/* Error string */
	}
	
	/* free element array */
	if (replic->element != NULL)
		fsl_free(replic->element);
	
	/* free object */
	fsl_free(replic);
}


int replic_add_element(struct replic *replic, 
		int id, 
		struct replic_element_info *element_info)
{
/*	
 * 	check conf params
 * */
	int err = 0, count, next_rrid = 0;
	struct replic_element_info head_rr;
	
	ASSERT_COND(replic);
	if (id >= replic->num_elements)
		return -EACCES;
	
	if (replic->element[id].inuse == 1)
		return -EEXIST;
	
	count = replic_get_element_inuse_count(replic);
	
	if (count != 0) {
		/* Get head RR */
		err = replic_query_element_rrid(
			replic->element[replic->head_id].rrid, 
			&head_rr);
		if (err != 0)
			return err;
		
		next_rrid = head_rr.next_rrid;
	}
	
	/* Configure new RRID*/
	element_info->next_rrid = next_rrid;
	err = replic_config_element_rrid(
		replic->element[id].rrid, 
		element_info);
	if (err != 0)
		return err;
	
	/* Configure head RR*/
	if (count != 0) {
		head_rr.next_rrid = replic->element[id].rrid;
		err = replic_config_element_rrid(
			replic->element[replic->head_id].rrid, &head_rr);
		if (err != 0)
			return err;
	}
	else
		replic->head_id = id;
	
	/*! Updata data base */
	replic->element[id].inuse = 1;
	replic->element[id].opaque = 0;
	
	return err;
}

int replic_remove_element(struct replic *replic, int id)
{
/*
 * Go over RR link list and find required id
 * Update link list
 * Update database
 */
	int err = 0, rmv_rrid, curr_rrid, found = 0, element_id;
	struct replic_element_info curr_rr, rmv_rr;
	
	ASSERT_COND(replic);
	if (id >= replic->num_elements)
		return -EINVAL;
	
	if (replic->element[id].inuse == 0)
		return -EINVAL;
		
	rmv_rrid = replic->element[id].rrid;
	curr_rrid = replic->element[replic->head_id].rrid;
		
	err = replic_query_element_rrid(curr_rrid, &curr_rr);
	if (err )
		return err;
	
	
	if (curr_rrid == rmv_rrid) {
		/* get the element_id of the next element */
		if (curr_rr.next_rrid) {
			err = replic_get_element(replic, curr_rr.next_rrid, &element_id);
			if (err)
				return err;
			/* set the head */
			replic->head_id = element_id;
		}
	}
	else {	
		do {
			err = replic_query_element_rrid(curr_rrid, &curr_rr);
			if (err != 0)
				return err;
			
			if (curr_rr.next_rrid == rmv_rrid)
			{
				found = 1;
				break;
			}
			else
				curr_rrid = curr_rr.next_rrid;	
			
		}while ((curr_rrid != rmv_rrid) && (curr_rrid != 0));
		
		if (found == 0)
			return -ENAVAIL;	/*! resource not found */
		
		/*! Read remove rrid */
		err = replic_query_element_rrid(rmv_rrid, &rmv_rr);
		if (err != 0)
			return err;
		
		/*! Update previous record */
		curr_rr.next_rrid = rmv_rr.next_rrid;
		err = replic_config_element_rrid(curr_rrid, &curr_rr);
		if (err != 0)
			return err;
	}
	
	/*! Update database */
	replic->element[id].inuse = 0;
	replic->element[id].opaque = 0;
	
	return err;
}

void replic_remove_all(struct replic *replic)
{
	int i;
	
	for (i = 0; i < replic->num_elements; i++) {
		replic->element[i].inuse = 0;
		replic->element[i].opaque = 0;
	}
}

int replic_get_element_inuse_count(struct replic *replic)
{
	int i, count = 0;
	
	ASSERT_COND(replic);
	for (i = 0; i < replic->num_elements; i++) {
		if (replic->element[i].inuse == 1)
			count++;
	}
	
	return count;
}

int replic_get_element_rrid(struct replic *replic, 
	int element_id, int *rrid) 
{	
	ASSERT_COND(replic);

	if (element_id >= replic->num_elements)
		return -EINVAL;
	
	*rrid = replic->element[element_id].rrid;
	
	return 0;
}

int replic_get_element_head(struct replic *replic, int *head_id)
{
	ASSERT_COND(replic);
	/* check if the replic has a head or not */
	if (replic_is_empty(replic))
		return -ENAVAIL;
	else		
		*head_id = replic->head_id;
	
	return 0;
}

int replic_is_empty(struct replic *replic)
{
	return !replic_get_element_inuse_count(replic);
}

int replic_get_element(struct replic *replic, int rrid, int *element)
{
	int i, err = 0;
	
	ASSERT_COND(replic);
	for (i = 0; i < replic->num_elements; i++) {
		if (replic->element[i].rrid == rrid) {
			*element = i;
			return err;
		}
	}
	return -ENAVAIL;
}

int replic_set_element_opaque(struct replic *replic, 
                              int element_id, 
                              uint64_t opaque)
{
	ASSERT_COND(replic);

	if (element_id >= replic->num_elements)
		return -EINVAL;

	replic->element[element_id].opaque = opaque;
	
	return 0;
}

int replic_get_element_opaque(struct replic *replic, 
                              int element_id, 
                              uint64_t *opaque)
{
	ASSERT_COND(replic);

	if (element_id >= replic->num_elements)
		return -EINVAL;

	*opaque = replic->element[element_id].opaque;
	
	return 0;
}
