/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          hmap.c

 @Description   Driver implementation

 @Cautions      None.
 *//***************************************************************************/
#include "hmap.h"
#include "fsl_malloc.h"			/* fsl_malloc */
#include "common/fsl_string.h"			/* memcpy */
#include "fsl_errors.h"				/* errors */
#include "fsl_platform.h"			/* sys_get_handle */
#include "fsl_resman.h"				/* get SWP */

/**
 * @brief	Hash Map implementation 
 *
 */
struct hmap *hmap_create(int size, size_t key_size)
{
	struct hmap *hmap;
	
	if(key_size > HMAP_MAX_KEY)
		return NULL;
	
	/*! Allocate hmap */
	hmap = (struct hmap *)fsl_malloc(sizeof(struct hmap));
	if (hmap == NULL)
		return hmap;
	
	/*! init hmap */
	memset(hmap, 0, sizeof(struct hmap));
	
	/*! Allocate table */
	hmap->table = (struct hmap_entry *)fsl_malloc(
		sizeof(struct hmap_entry) * size); 
	if (hmap->table == NULL) {
		hmap_destroy(hmap);
		return NULL;
	}
	
	/*! init table */	
	memset(hmap->table, 0, sizeof(struct hmap_entry) * size);
	
	/*! save configuration */
	hmap->key_size = key_size;		/*! key size */
	hmap->size = size; 			/*! lookup table size */
	
	return hmap;
}

void hmap_destroy(struct hmap *hmap)
{
	if (hmap == NULL)
		return;
	
	/*! Release table */
	if (hmap->table != NULL)
		fsl_free(hmap->table);
	
	/*! Release hash database */
	fsl_free(hmap);	
}

int hmap_set_data(struct hmap *hmap, int index, hmap_data data)
{
	int err = 0;
		
	if (index >= hmap->size)
		return -EINVAL;
	
	hmap->table[index].data = data;
	
	return err;
}

int hmap_get_data(struct hmap *hmap, int index, hmap_data *data)
{
	int err = 0;

	if (hmap == NULL)
		return -EFAULT;		/* bad address detected */

	if (index >= hmap->size)
		return -EINVAL;
	
	
	*data = hmap->table[index].data;
	
	return err;
}

int hmap_get_count(struct hmap *hmap)
{
	int	i, count;
	
	for(i = 0, count = 0; i < hmap->size; i++){
		if(hmap->table[i].inuse == 1)
			count++;
	}
	return count;
}

/*! 
 * 
 * Jenkins One At A Time Hash 
 * http://en.wikipedia.org/wiki/Jenkins_hash_function
 */
static uint32_t hmap_hash_function(hmap_key key, size_t len)
{
	uint32_t hash, i;
    
	for(hash = i = 0; i < len; ++i)
	{
		hash += key[i];
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}
    
	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);
    
	return hash;
}

int hmap_add_key(struct hmap *hmap, hmap_key key)
{
	uint32_t hash, i;
	int cmp;
	
	/*! Calculate hash */
	hash = hmap_hash_function(key, hmap->key_size) % hmap->size;
	
	/*! Find the available slot */
	for(i = 0; i < hmap->size; i++) {
		if(hmap->table[hash].inuse == 0){
			hmap->table[hash].inuse = 1;
			memcpy(hmap->table[hash].key, key, hmap->key_size);
			return 0;
		}
		
		cmp = memcmp(hmap->table[hash].key, key, hmap->key_size);	
		if (cmp == 0)
			return -EEXIST;		/*! Resource already exists */
		
		/*! Increment with roll over */
		hash++;
		hash = (hash == hmap->size) ? 0 : hash;
	}
	return -ENOSPC;		/*! No space left (resource is full) */
}

int hmap_lookup(struct hmap *hmap, const hmap_key key, hmap_data *data)
{
	uint32_t hash, i;
	int cmp;
	
	/*! Calculate hash */
	hash = hmap_hash_function(key, hmap->key_size) % hmap->size;
	
	/*! lookup */
	for(i = 0; i < hmap->size; i++) {
		if (hmap->table[hash].inuse == 1) {
			cmp = memcmp(hmap->table[hash].key, key, hmap->key_size);
			if (cmp == 0) {
				*data = hmap->table[hash].data;
				return 0;			
			}
		}
		
		hash++;
		hash = (hash == hmap->size) ? 0 : hash;
	}
	return -ENAVAIL;		/*! not found */
}

int hmap_ternary_lookup(struct hmap *hmap, hmap_key key, 
	struct hmap_mask *mask, hmap_data *data)
{
	uint32_t i;
	int cmp;
	
	if((mask->start + mask->size) > hmap->key_size)
		return -EINVAL;		/*! Invalid argument */
	
	/*! lookup */
	for(i = 0; i < hmap->size; i++) {
		if (hmap->table[i].inuse == 1) {
			cmp = memcmp(
				&(hmap->table[i].key[mask->start]), 
				key, 
				mask->size);
			if (cmp == 0) {
				*data = hmap->table[i].data;
				memcpy(key, hmap->table[i].key, hmap->key_size);
				return 0;			
			}
		}		
	}
	return -ENAVAIL;		/*! not found */
}


int hmap_remove_key(struct hmap *hmap, hmap_key key)
{
	uint32_t hash, i;
	int cmp;
	
	/*! Calculate hash */
	hash = hmap_hash_function(key, hmap->key_size) % hmap->size;
	
	/*! lookup */
	for(i = 0; i < hmap->size; i++) {
		if (hmap->table[hash].inuse == 1) {
			cmp = memcmp(hmap->table[hash].key, key, hmap->key_size);
			if (cmp == 0) {
				hmap->table[hash].inuse = 0;
				return 0;			
			}
		}
		
		hash++;
		hash = (hash == hmap->size) ? 0 : hash;
	}
	return -ENAVAIL;		/*! not found */
}

void hmap_remove_all(struct hmap *hmap) 
{
	int i;
	
	for(i = 0; i < hmap->size; i++)
		hmap->table[i].inuse = 0;
}

int hmap_next_iterator(struct hmap *hmap, int iterator)
{
	int i;
	
	for(i = iterator; i < hmap->size; i++) {
		if (hmap->table[i].inuse == 1) {
			return i;
		}
	}
	return i;
}


int hmap_get_start_iterator(struct hmap *hmap, int *iterator)
{
	*iterator = hmap_next_iterator(hmap, 0);

	if (*iterator >= hmap->size)
		return -ENODEV;		/*! Empty */
	
	return 0;
}

int hmap_iterate(struct hmap *hmap, int *iterator,
            hmap_key key, hmap_data *data)
{
	if (*iterator >= hmap->size)
		return -EACCES;		/*! Illegal access */
	
	if (hmap->table[*iterator].inuse != 1)
		return -EINVAL;		/*! Invalid or conflicting arguments */	
	
	/* return key and data */
	*data = hmap->table[*iterator].data;
	memcpy(key, hmap->table[*iterator].key, hmap->key_size);
			
	/* Update iterator */
	*iterator = hmap_next_iterator(hmap, *iterator + 1);		
	
	return (*iterator < hmap->size) ? 0 : -ENODEV;
}
