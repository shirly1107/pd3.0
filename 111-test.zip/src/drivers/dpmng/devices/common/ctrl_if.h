/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          ctrl_if.h

 @Description   dpmng internal structures and definitions.
 *//***************************************************************************/
#ifndef __CTRL_IF_H
#define __CTRL_IF_H

#include "kernel/device.h"
#include "fsl_types.h"
//#include "fsl_dpmng_mc.h"
//#include "fsl_eiop_ifp.h"
#include "fsl_ctrl_if.h"
#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPMNG


#define CTRL_IF_DESTROY_AUTHORIZED_QDID		0x80000000
#define CTRL_IF_DESTROY_AUTHORIZED_RX_ERR_FQID	0x40000000
#define CTRL_IF_DESTROY_AUTHORIZED_TX_CONF_ERR_FQID	0x20000000

#define CTRL_IF_POLCIER_DROPP_GREEN	0
#define CTRL_IF_POLCIER_DROPP_YELLOW	1
#define CTRL_IF_POLCIER_DROPP_RED		2

#define CTRL_IF_ERRORS_TO_DISCARD	(EIOP_IFP_ERR_KS | 		\
					EIOP_IFP_ERR_MNL | 		\
					EIOP_IFP_ERR_TID | 		\
					EIOP_IFP_ERR_PIE | 		\
					EIOP_IFP_ERR_PARSER_CL| 	\
					EIOP_IFP_ERR_PARSER_ISF | 	\
					EIOP_IFP_ERR_PARSER_BL)

/************************************************************************
 * 					DPMNG_CNTRL_IF
 ***********************************************************************/
#define CTRL_IF_MAX_NUM_OF_FLOWS	100
#define CTRL_IF_MAX_DPBP			8
#define CTRL_IF_MAX_FRAME_LENGTH	1536	/* Maximum Frame Length */
#define CTRL_IF_MAX_NUM_OF_RX_FLOWS	1
#define CTRL_IF_MAX_NAM_OF_QPRIS	8

struct ctrl_if_ceetm_info {
	int ifp_id;
	int tx_conf_err;
	int dctidx;
	int dcp_id;
	int ceetm_id;
	int lfqmtidx;
	int cq_id;

};

struct ctrl_if_eiop_info {
	int next_ifpid;
	struct eiop_ifp_desc ifp_desc;
	struct eiop_ifp_cfg init;
	//int lfqid;
};

struct ctrl_if_queue_info {
	int fqid;
	int virt_fqid;
	uint64_t user_ctx;
	struct ctrl_if_dest_cfg dest_cfg;
//	enum dpni_flc_type flc_type;
	uint64_t flc_opaque;
	int cgid_en;
	int cgid;
	int order_preservation_en;

	int retire_pending;
	struct qbman_result *retire_storage;
};

struct ctrl_if_pool_cfg {
	struct dpbp *dpbp;
	uint16_t buffer_size;

};
struct ctrl_if_pools_int_cfg {
	uint8_t num_dpbp;
	struct ctrl_if_pool_cfg pools[CTRL_IF_MAX_DPBP];
};

struct ctrl_if_destroy{
	int authorized_obj;
	int num_of_init_fqis; /*include : regular rx_fqid, rx_err_fqid*/
	int num_of_authorized_fqids; /*include : regular rx_fqid*/

};

struct ctrl_if_rx_side_cfg {
	struct ctrl_if_queue_info queue_cfg[CTRL_IF_MAX_NUM_OF_FLOWS];
	struct ctrl_if_queue_info err_queue_cfg;
	int 				qdid;		/*! egress queue */
	int 				virt_qdid;
	int					qprid;/*! Queue Priority*/
	struct ctrl_if_eiop_info eiop_info;
//	int 				fqid_base;
	int 				fs_wa_temp;
	enum eiop_ifp_cfg_err_mode errors_settings;
	int 				plid;
};

#define CTRL_IF_INFO_QUEUE_AUTHORIZED 0x80000000
#define CTRL_IF_INFO_DCT_INIT		  0x40000000
#define CTRL_IF_INFO_QUEUE_INIT		  0x20000000

struct ctrl_if_info {
	struct ctrl_if_eiop_info eiop_info;
	struct ctrl_if_queue_info queue_cfg;
	//int options;
	struct ctrl_if_ceetm_info  ceetm_info;
	uint16_t qdid;
	int virt_qdid;
	int connected;
	int enabled;
	int destroy_options;
};


struct ctrl_if_tx_side_cfg {
	struct ctrl_if_info *iface;
	struct ctrl_if_queue_info conf_err_queue_cfg;
	int tx_conf_disable;
	int tx_conf_only_errors_frames;
};

struct ctrl_if_internal {
	int 				qdid;		
	int 				qprid[CTRL_IF_MAX_NAM_OF_QPRIS];
	int					kid;    
	int 				tid;
	struct dptbl *dptbl;
};

struct ctrl_if {
	struct dpmng 		*dpmng;
	struct device  		*dprc;      	/* Resource manager */
    struct dpkg     	*dpkg_ing;  /*! DpKg ingress */
    struct dptbl_mng 	*dptbl_ing;
    struct dppolicer 	*dppolicer_ing;

	int 				rx_enabled;
	int 				tx_enabled;
	
	int 				eiop_id;
	struct dpmng_amq 	amq;
	
	struct ctrl_if_destroy destroy;
    
	struct buf_layout tx_buf_layout; /**<defining the frame layout*/
	struct buf_layout txconf_buf_layout; /**<defining the frame layout*/
	struct buf_layout rx_buf_layout; /**<defining the frame layout*/
	struct ctrl_if_pools_int_cfg pools_cfg;
	struct ctrl_if_pools_int_cfg backup_pools_cfg;

	int 				num_ifs;
	int 				num_ifs_enabled;
	struct ctrl_if_tx_side_cfg tx_side_cfg;

	int 					max_num_of_rx_flows;
	struct ctrl_if_rx_side_cfg rx_side_cfg;
	uint16_t 					mfl;
	
	struct ctrl_if_internal internal;
	//uint16_t 		src_qdid[64];
	//struct ctrl_if_queue_info tx_conf_err_queue_cfg;
};

#endif /* __CTRL_IF_H */
