/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpmcp_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif.h"
#include "fsl_cmdif_mc.h"
#include "dtc/dtc.h"
#include "fsl_sys.h"
#include "fsl_event_pipe.h"
#include "fsl_dpmcp_mc.h"
#include "fsl_resman.h"
#include "kernel/device.h"
#include "dplib/fsl_dpmcp_cmd.h"
#include "dpmcp_cmd.h"
#include "legacy_dpmcp_dplib.h"

/* DPMCP last supported API version */
#define DPMCP_V0_API_VER_MAJOR				3
#define DPMCP_V0_API_VER_MINOR				0

int dpmcp_drv_init(void);

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpmcp *dpmcp;

	dpmcp = device_get_priv(dev);
	if (!dpmcp)
		return -ENODEV;

	return dpmcp_set_dev_ctx(dpmcp, dev_ctx);
}

static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmcp *dpmcp;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpmcp_cfg dpmcp_cfg = { 0 };
	struct dpmcp_cfg *cfg = &dpmcp_cfg;
	int err;

	dpmcp = device_get_priv(dev);

	DPMCP_CMD_CREATE(cmd_data, cfg);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpmcp) {
		/* NULL */
		dpmcp = dpmcp_allocate();
		if (!dpmcp) {
			pr_err("No memory for dpmcp\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpmcp_init(dpmcp, cfg, &dev_cfg);
		if (err) {
			return err;
		}
		device_set_priv(dev, dpmcp);
		sys_add_handle(dpmcp, FSL_MOD_DPMCP, 1, dev_cfg.id);

		assign(dev, &(dev_cfg.ctx));
	} else
		return -EINVAL;

	return 0;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
        struct dpmcp *dpmcp;

        UNUSED(cmd_data);

        dpmcp = device_get_priv(dev);
        if (!dpmcp)
                return -ENODEV;

        dpmcp_destroy(dpmcp);

        sys_remove_handle(FSL_MOD_DPMCP, 1, device_get_id(dev));
        dpmcp_deallocate(dpmcp);

        return 0;
}

static int destroy_by_resman(struct device *dev)
{
        return destroy(dev, NULL);
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmcp *dpmcp;
	struct dpmng_dev_ctx dev_ctx;
	int err;

	UNUSED(cmd_data);

	dpmcp = device_get_priv(dev);
	if (!dpmcp)
		return -ENODEV;

	err = cmdif_reset_portal_ctrl_cb((void *)dev, device_get_id(dev));
	if (!err) {
		resman_get_dev_ctx(dev, &dev_ctx, 1);
		device_set_enable(dev, 0);
		err = assign(dev, &dev_ctx);
	}

	return err;
}


static int reset_by_resman(struct device *dev)
{
        return reset(dev, NULL);
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmcp *dpmcp;
	struct dpmcp_attr attr = { 0 };
	int err;

	dpmcp = device_get_priv(dev);
	CHECK_COND_RETVAL(dpmcp, -ENODEV);

	err = dpmcp_get_attributes(dpmcp, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.version.major = DPMCP_V0_API_VER_MAJOR;
	attr.version.minor = DPMCP_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMCP_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmcp *dpmcp;
	struct dpmcp_attr attr = { 0 };
	int err;

	dpmcp = device_get_priv(dev);
	CHECK_COND_RETVAL(dpmcp, -ENODEV);

	err = dpmcp_get_attributes(dpmcp, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMCP_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmcp *dpmcp;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dpmcp = device_get_priv(dev);
	if (!dpmcp)
		return -ENODEV;

	DPMCP_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dpmcp_set_irq(dpmcp, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpmcp *dpmcp;

	dpmcp = device_get_priv(dev);
	if (!dpmcp)
		return -ENODEV;

	return dpmcp_set_irq(dpmcp, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmcp *dpmcp;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dpmcp = device_get_priv(dev);
	if (!dpmcp)
		return -ENODEV;

	/* Read parameters from portal */
	DPMCP_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpmcp_get_irq(dpmcp, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMCP_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpmcp *dpmcp;
	int err;

	dpmcp = device_get_priv(dev);
	if (!dpmcp)
		return -ENODEV;

	err = dpmcp_get_irq(dpmcp, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;
	
	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
        struct dpmcp *dpmcp;
        uint8_t irq_index;
        uint8_t enable_state;

        dpmcp = device_get_priv(dev);
        if (!dpmcp)
                return -ENODEV;

        /* Read parameters from portal */
        DPMCP_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, enable_state);

        return dpmcp_set_irq_enable(dpmcp, irq_index, enable_state);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
        struct dpmcp *dpmcp;
        uint8_t irq_index;
        uint8_t enable_state;
        int err;

        dpmcp = device_get_priv(dev);
        if (!dpmcp)
                return -ENODEV;

        /* Read parameters from portal */
        DPMCP_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpmcp_get_irq_enable(dpmcp, irq_index, &enable_state);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMCP_RSP_GET_IRQ_ENABLE(cmd_data, enable_state);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
        struct dpmcp *dpmcp;
        uint8_t irq_index;
        uint32_t mask;

        dpmcp = device_get_priv(dev);
        if (!dpmcp)
                return -ENODEV;

        /* Read parameters from portal */
        DPMCP_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

        return dpmcp_set_irq_mask(dpmcp, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmcp *dpmcp;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpmcp = device_get_priv(dev);
	if (!dpmcp)
		return -ENODEV;

	/* Read parameters from portal */
	DPMCP_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpmcp_get_irq_mask(dpmcp, irq_index, &mask);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMCP_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmcp *dpmcp;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpmcp = device_get_priv(dev);
	if (!dpmcp)
		return -ENODEV;

	/* Read parameters from portal */
	DPMCP_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpmcp_get_irq_status(dpmcp, irq_index, &status);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMCP_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPMCP_VER_MAJOR;
    uint32_t minor = DPMCP_VER_MINOR;

    DPMCP_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int dpmcp_drv_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpmcp_open on DPMCP %d\n", device_get_id(dev));
        return 0;
}

static int dpmcp_drv_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpmcp_close on DPMCP %d\n", device_get_id(dev));
        return 0;
}

static int dpmcp_drv_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
        struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
        int i;
        struct {
                int code;
                int (*function)(struct device *dev,
                        struct mc_cmd_data *cmd_data);
                char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
        } map_commands[] = {
				{ DPMCP_CMD_CODE_CREATE, init, "dpmcp_init", DPMCP_CMD_VER_BASE },
				{ DPMCP_CMD_CODE_DESTROY, destroy, "dpmcp_destroy", DPMCP_CMD_VER_BASE },
				{ DPMCP_CMD_CODE_GET_ATTR, get_attributes_v0, "dpmcp_get_attributes", DPMCP_CMD_V0 },
				{ DPMCP_CMD_CODE_SET_IRQ, set_irq, "dpmcp_set_irq", DPMCP_CMD_VER_BASE },
				{ DPMCP_CMD_CODE_GET_IRQ, get_irq, "dpmcp_get_irq", DPMCP_CMD_VER_BASE }, 
				{ DPMCP_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpmcp_set_irq_enable", DPMCP_CMD_VER_BASE },
				{ DPMCP_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpmcp_get_irq_enable", DPMCP_CMD_VER_BASE },
				{ DPMCP_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpmcp_set_irq_mask", DPMCP_CMD_VER_BASE },
				{ DPMCP_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpmcp_get_irq_mask", DPMCP_CMD_VER_BASE },
				{ DPMCP_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpmcp_get_irq_status", DPMCP_CMD_VER_BASE },

				/* New command handlers start here */
				{ DPMCP_CMD_CODE_GET_API_VERSION, get_api_version, "dpmcp_get_api_version", DPMCP_CMD_V1 },
				{ DPMCP_CMD_CODE_GET_ATTR, get_attributes_v1, "dpmcp_get_attributes_v1", DPMCP_CMD_V1 },
        };

        if (cmd == DPMCP_CMD_CODE_RESET)
                return reset((struct device *)dev, cmd_data);

        for (i = 0; i < ARRAY_SIZE(map_commands); i++)
                if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
        			if (cmd == DPMCP_CMD_CODE_CREATE)
        				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
        			else
        				pr_info("Handling command: %s on DPMCP %d\n", map_commands[i].cmd_str, device_get_id(dev));
        			return map_commands[i].function((struct device *)dev,
                                                        cmd_data);
                }

        pr_err("Invalid command %d\n", cmd);
        return -ENOTSUP;
}

static int dpmcp_drv_probe_cb(void *lo, int node_off)
{
        int err = 0;
        struct dpmcp_cfg dpmcp_cfg = { 0 };
        struct dpmcp_cfg *cfg = &dpmcp_cfg;
        struct mc_cmd_data cmd = { 0 };
        struct mc_cmd_data *cmd_data = &cmd;
        struct device *dev;
        struct resman *resman;
        int id;
        int destroy = 0;

        err = get_node_id(lo, node_off, &id);
        if (err)
                return err;

        resman = sys_get_unique_handle(FSL_MOD_RESMAN);
        if (!resman) {
                pr_err("Can't find resman");
                return -ENODEV;
        }
        /* create & open resman device */
        dev = resman_open_dev(resman, "dpmcp", (uint16_t)id, NO_PORTAL_ID,
				DPRC_OPEN_DEV_ONLY, NULL);
        CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPMCP %.4x\n", id);
        cfg->portal_id = id;
        /* create object */
        err = dpmcp_drv_ctrl_cb(dev, DPMCP_CMD_VER_BASE,
				DPMCP_CMD_CODE_CREATE, NO_PORTAL_ID, (uint8_t*)cmd_data);
        if (err)
                destroy = 1;

        err = resman_close_dev(resman, dev, "dpmcp", NO_PORTAL_ID, destroy);

        return err;
}

static int dpmcp_drv_remove_cb(void *lo, int node_off)
{
        struct resman *resman;
        struct device *dev;
        int id;
        int err = 0;

        err = get_node_id(lo, node_off, &id);
        if (err)
                return err;

        resman = sys_get_unique_handle(FSL_MOD_RESMAN);
        if (!resman) {
                pr_err("Can't find resman");
                return -ENODEV;
        }

        dev = resman_open_dev(resman, "dpmcp", (uint16_t)id, NO_PORTAL_ID, 0, NULL);
        if (!dev) {
                pr_err("Can't open DPMCP 0x%.4x\n", id);
                return -ENODEV;
        }

        err |= dpmcp_drv_ctrl_cb(dev, DPMCP_CMD_VER_BASE, DPMCP_CMD_CODE_DESTROY,
                                  NO_PORTAL_ID,  NULL);
        err |= resman_close_dev(resman, dev, "dpmcp", NO_PORTAL_ID, 0);

        return err;
}

static char *dpmcp_drv_match[] = { "fsl,dpmcp", "dpmcp" };

int dpmcp_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;

	pr_info("Executing dpmcp_drv_init...\n");
	
	dtc_params.num_compats = ARRAY_SIZE(dpmcp_drv_match);
	dtc_params.compatibles = dpmcp_drv_match;
	dtc_params.f_prob_module = dpmcp_drv_probe_cb;
	dtc_params.f_remove_module = dpmcp_drv_remove_cb;
	sys_dtc_register_module(&dtc_params);

	cmdif_ops.open_cb = dpmcp_drv_open_cb;
	cmdif_ops.close_cb = dpmcp_drv_close_cb;
	cmdif_ops.ctrl_cb = dpmcp_drv_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPMCP, &cmdif_ops);

	strcpy(dev_type_param.device_type, "dpmcp");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPMCP_MAX_IRQ_NUM;
	dev_type_param.region_count = 1;
	dev_type_param.region_types[0] = DPRC_REGION_TYPE_MCP;
	dev_type_param.ver_major = DPMCP_VER_MAJOR;
	dev_type_param.ver_minor = DPMCP_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;
	
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	resman_register_device_operation(resman, "dpmcp", &dev_type_param);
	return 0;
}
