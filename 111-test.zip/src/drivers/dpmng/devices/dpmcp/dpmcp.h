/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpmcp.h

 @Description   DPMCP internal structures and definitions.
*//***************************************************************************/
#ifndef __DPMCP_H
#define __DPMCP_H

#include "fsl_dpmcp_mc.h"
#include "fsl_event_pipe.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPMCP

struct dpmcp {
	uint16_t	id;
	struct dpmng    *dpmng;
	struct device	*device;
	struct mc_irq irqs[DPMCP_MAX_IRQ_NUM];
};

#endif /* __DPMCP_H */
