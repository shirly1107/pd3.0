/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPMCP_CMD_H
#define _DPMCP_CMD_H

/* default version for all dpmcp commands */
#define DPMCP_CMD_VER_BASE									CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPMCP_CMD_V0										CMDHDR_CMD_VERSION(0)
#define DPMCP_CMD_V1										CMDHDR_CMD_VERSION(1)

/* add your new command version number here
 * Ex:
 * #define DPMCP_CMD_CREATE_VER_1                MC_CMD_HDR_VERSION(DPMCP_CMD_VER_BASE + 1) or
 * #define DPMCP_CMD_CREATE_VER                  MC_CMD_HDR_VERSION(3)
 */

/* Command IDs */
#define DPMCP_CMD_CODE_CLOSE                               0x800
#define DPMCP_CMD_CODE_OPEN                                0x80b
#define DPMCP_CMD_CODE_CREATE                              0x90b
#define DPMCP_CMD_CODE_DESTROY                             0x900
#define DPMCP_CMD_CODE_GET_API_VERSION                     0xa0b

#define DPMCP_CMD_CODE_GET_ATTR                            0x004
#define DPMCP_CMD_CODE_RESET                               0x005

#define DPMCP_CMD_CODE_SET_IRQ                             0x010
#define DPMCP_CMD_CODE_GET_IRQ                             0x011
#define DPMCP_CMD_CODE_SET_IRQ_ENABLE                      0x012
#define DPMCP_CMD_CODE_GET_IRQ_ENABLE                      0x013
#define DPMCP_CMD_CODE_SET_IRQ_MASK                        0x014
#define DPMCP_CMD_CODE_GET_IRQ_MASK                        0x015
#define DPMCP_CMD_CODE_GET_IRQ_STATUS                      0x016

#endif /* _FSL_DPMCP_CMD_H */
