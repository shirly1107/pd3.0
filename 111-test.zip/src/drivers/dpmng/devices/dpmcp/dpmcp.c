/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpmcp.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_platform.h"
#include "fsl_resman.h"
#include "dpmcp.h"

int dpmcp_init(struct dpmcp *dpmcp,
	       const struct dpmcp_cfg *cfg,
	       const struct dpmng_dev_cfg *dev_cfg)
{
	int i;
	
	dpmcp->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RETVAL(dpmcp->dpmng, -EINVAL);

	dpmcp->id = dev_cfg->id;
	dpmcp->device = dev_cfg->device;

	for (i = 0; i < DPMCP_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpmcp->irqs[i]), MC_IRQ_TYPE_AUTO_CLEAR);
	
	return 0;
}

struct dpmcp * dpmcp_allocate(void)
{
	struct dpmcp *dpmcp;

	dpmcp = (struct dpmcp *)fsl_xmalloc(sizeof(struct dpmcp), 0,
						CORE_CACHELINE_SIZE);
	if (dpmcp)
		memset(dpmcp, 0, sizeof(struct dpmcp));

	return dpmcp;
}

void dpmcp_deallocate(struct dpmcp *dpmcp)
{
	fsl_xfree(dpmcp);
}

void dpmcp_destroy(struct dpmcp *dpmcp)
{
	int err;

	err = resman_unbind_all(dpmcp->device);

	CHECK_COND_RET(err == 0);
}

int dpmcp_get_attributes(struct dpmcp *dpmcp, struct dpmcp_attr *attributes)
{
	attributes->id = dpmcp->id;

	return 0;
}

int dpmcp_set_dev_ctx(struct dpmcp *dpmcp, const struct dpmng_dev_ctx *dev_ctx)
{
	UNUSED(dpmcp);
	UNUSED(dev_ctx);

	return 0;
}

int dpmcp_set_irq(struct dpmcp *dpmcp,
		 uint8_t irq_index,
		 const struct mc_irq_cfg *irq_cfg)
{
	if (irq_index >= DPMCP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMCP_MAX_IRQ_NUM);
		return -EINVAL;
	}

	mc_set_irq(&(dpmcp->irqs[irq_index]), irq_cfg);
	return 0;
}

int dpmcp_get_irq(struct dpmcp *dpmcp,
        	 uint8_t irq_index,
        	 struct mc_irq_cfg *irq_cfg)
{
	int err;
	
	if (irq_index >= DPMCP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMCP_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_get_irq(&(dpmcp->irqs[irq_index]), irq_cfg);
    CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dpmcp_set_irq_enable(struct dpmcp *dpmcp, uint8_t irq_index, uint8_t en)
{
	int err;
	
	if (irq_index >= DPMCP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMCP_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err =  mc_set_irq_enable(&(dpmcp->irqs[irq_index]), en);
    CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dpmcp_get_irq_enable(struct dpmcp *dpmcp, uint8_t irq_index, uint8_t *en)
{
	int err;
	
	if (irq_index >= DPMCP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMCP_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_get_irq_enable(&(dpmcp->irqs[irq_index]), en);
    CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dpmcp_set_irq_mask(struct dpmcp *dpmcp, uint8_t irq_index, uint32_t mask)
{
	int err;
	
	if (irq_index >= DPMCP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMCP_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_set_irq_mask(&(dpmcp->irqs[irq_index]), mask);
    CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dpmcp_get_irq_mask(struct dpmcp *dpmcp, uint8_t irq_index, uint32_t *mask)
{
	int err;
	
	if (irq_index >= DPMCP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMCP_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_get_irq_mask(&(dpmcp->irqs[irq_index]), mask);
    CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dpmcp_get_irq_status(struct dpmcp *dpmcp,
			 uint8_t irq_index,
			 uint32_t *status)
{
	int err;
	
	if (irq_index >= DPMCP_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMCP_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_get_irq_status(&(dpmcp->irqs[irq_index]), status);
    CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dpmcp_invoke_inter(struct dpmcp *dpmcp)
{
	event_send(&(dpmcp->irqs[0]), DPMCP_IRQ_EVENT_CMD_DONE);

	return 0;
}
