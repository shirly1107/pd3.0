/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpsp_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "dtc/dtc.h"
#include "fsl_sys.h"
#include "fsl_event_pipe.h"
#include "dplib/fsl_dpsparser_cmd.h"
#include "fsl_dpsparser_mc.h"
#include "dpsparser_cmd.h"
#include "dpsparser.h"
#include "dpsparser_blob.h"

/******************************************************************************/
static char *dpsparser_drv_match[] = { "fsl,dpsparser", "dpsparser" };

/******************************************************************************/
static struct dpsparser	*dpsparser_drv;

/******************************************************************************/
static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpsparser	*dpsparser;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	return dpsparser_set_dev_ctx(dpsparser, dev_ctx);
}

/******************************************************************************/
static void dpsparser_set_mc_info(struct dpsparser *dpsparser,
				  const struct dpmng_dev_cfg *dev_cfg)
{
	dpsparser->id = dev_cfg->id;
	CHECK_COND_RET(dev_cfg->device);
	dpsparser->device = dev_cfg->device;
	dpsparser->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dpsparser->dpmng);
}

/******************************************************************************/
static int check_dpsparser_cfg(const struct dpsparser *dpsparser,
			       const struct dpsparser_cfg *cfg)
{
	return 0;
}

/******************************************************************************/
static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	struct dpmng_dev_cfg	dev_cfg = {0};
	struct dpsparser_cfg	dpsparser_cfg = {0};
	static uint8_t		inst_count;
	int			err;

	dpsparser = device_get_priv(dev);
	/* Should be NULL unless special cases: reset, etc. */
	if (dpsparser)
		return -EINVAL;
	/* Only one instance is allowed */
	if (inst_count) {
		pr_err("A DPSPARSER instance already exists\n");
		return -EEXIST;
	}
	inst_count++;
	dev_cfg.id = device_get_id(dev);
	dev_cfg.device = dev;
	resman_get_dev_ctx(dev, &dev_cfg.ctx, 1);
	dpsparser = dpsparser_drv;
	ASSERT_COND(dpsparser);
	dpsparser_set_mc_info(dpsparser, &dev_cfg);
	err = check_dpsparser_cfg(dpsparser, &dpsparser_cfg);
	if (err) {
		pr_err("check_dpsparser_cfg failed\n");
		return err;
	}
	dpsparser->amq.icid = (uint16_t)-1;
#ifdef DPSPARSER_IRQ
	for (i = 0; i < DPSPARSER_MAX_IRQ_NUM; i++)
		mc_init_irq(&dpsparser->irqs[i], MC_IRQ_TYPE_MSI);
#endif
	dpsparser_set_dev_ctx(dpsparser, &dev_cfg.ctx);
	device_set_priv(dev, dpsparser);
	pr_info("Created DPSPARSER %d\n", dev_cfg.id);
	return 0;
}

/******************************************************************************/
static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	 /* 
	 *Workaround: DO NOT destroy DPSPARSER object because it needs to be available on Apply DPL
	 * 			Apply DPL destroys all objects created by uboot 
	 * 			but DPSPARSER object should be kept 
	 * 			and SP configuration to be reused on routine: dpparser_attach_soft_parser 
	*/
	pr_info("Workaround: Do not destroy DPSPARSER %d\n", device_get_id(dev));
#if 0 	
	struct dpsparser	*dpsparser;

	UNUSED(cmd_data);
	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	dpsparser_destroy(dpsparser);
	sys_remove_handle(FSL_MOD_DPSPARSER, 1, device_get_id(dev));
	fsl_xfree(dpsparser);
	dpsparser_drv = 0;
	pr_info("Destroyed DPSPARSER %d\n", device_get_id(dev));
#endif
	
	return 0;
}

/******************************************************************************/
static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

/******************************************************************************/
static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;

	UNUSED(cmd_data);
	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	device_set_enable(dev, 1);
	dpsparser_enable(dpsparser);
	return 0;
}

/******************************************************************************/
static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	int			err;

	UNUSED(cmd_data);
	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	err = dpsparser_disable(dpsparser);
	if (!err)
		device_set_enable(dev, 0);
	return err;
}

/******************************************************************************/
static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;

	UNUSED(cmd_data);
	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	dpsparser_reset(dpsparser);
	device_set_enable(dev, 0);
	return 0;
}

/******************************************************************************/
static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}

/******************************************************************************/
static int get_attributes(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	int			err;
	struct dpsparser_attr	attr = {0};

	dpsparser = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsparser, -ENODEV);
	err = dpsparser_get_attributes(dpsparser, &attr);
	CHECK_COND_RETVAL(!err, err);
	attr.version.major = DPSPARSER_VER_MAJOR;
	attr.version.minor = DPSPARSER_VER_MINOR;
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSPARSER_RSP_GET_ATTRIBUTES(cmd_data, &attr);
	return 0;
}

/******************************************************************************/
static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	int			en, err;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	err = dpsparser_is_enabled(dpsparser, &en);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSPARSER_RSP_IS_ENABLED(cmd_data, en);
	}
	return err;
}

/******************************************************************************/
static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	uint8_t			irq_index;
	struct mc_irq_cfg	mc_irq_cfg = {0};
	struct mc_irq_cfg	*irq_cfg = &mc_irq_cfg;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	DPSPARSER_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);
	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;
	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);
	return dpsparser_set_irq(dpsparser, irq_index, irq_cfg);
}

/******************************************************************************/
static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg,
			     int irq_index)
{
	struct dpsparser	*dpsparser;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	return dpsparser_set_irq(dpsparser, (uint8_t)irq_index, irq_cfg);
}

/******************************************************************************/
static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	struct mc_irq_cfg	mc_irq_cfg = { 0 };
	struct mc_irq_cfg	*irq_cfg = &mc_irq_cfg;
	uint8_t			irq_index;
	int			err;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	/* Read parameters from portal */
	DPSPARSER_CMD_GET_IRQ(cmd_data, irq_index);
	err = dpsparser_get_irq(dpsparser, irq_index, irq_cfg);
	if (err)
		return err;
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSPARSER_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);
	return 0;
}

/******************************************************************************/
static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg,
			     int irq_index)
{
	struct dpsparser	*dpsparser;
	int			err;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	err = dpsparser_get_irq(dpsparser, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;
	return 0;
}

/******************************************************************************/
static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	uint8_t			irq_index;
	uint8_t			enable_state;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	/* Read parameters from portal */
	DPSPARSER_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, enable_state);
	return dpsparser_set_irq_enable(dpsparser, irq_index, enable_state);
}

/******************************************************************************/
static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	uint8_t			irq_index;
	uint8_t			enable_state;
	int			err;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	/* Read parameters from portal */
	DPSPARSER_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);
	err = dpsparser_get_irq_enable(dpsparser, irq_index, &enable_state);
	if (err)
		return err;
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSPARSER_RSP_GET_IRQ_ENABLE(cmd_data, enable_state);
	return 0;
}

/******************************************************************************/
static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	uint8_t			irq_index;
	uint32_t		mask;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	/* Read parameters from portal */
	DPSPARSER_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);
	return dpsparser_set_irq_mask(dpsparser, irq_index, mask);
}

/******************************************************************************/
static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	uint8_t			irq_index;
	uint32_t		mask;
	int			err;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	/* Read parameters from portal */
	DPSPARSER_CMD_GET_IRQ_MASK(cmd_data, irq_index);
	err = dpsparser_get_irq_mask(dpsparser, irq_index, &mask);
	if (err)
		return err;
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSPARSER_RSP_GET_IRQ_MASK(cmd_data, mask);
	return 0;
}

/******************************************************************************/
static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	uint8_t			irq_index;
	uint32_t		status;
	int			err;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	/* Read parameters from portal */
	DPSPARSER_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);
	err = dpsparser_get_irq_status(dpsparser, irq_index, &status);
	if (err)
		return err;
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSPARSER_RSP_GET_IRQ_STATUS(cmd_data, status);
	return 0;
}

/******************************************************************************/
static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsparser	*dpsparser;
	uint8_t			irq_index;
	uint32_t		status;

	dpsparser = device_get_priv(dev);
	if (!dpsparser)
		return -ENODEV;
	/* Read parameters from portal */
	DPSPARSER_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);
	return dpsparser_clear_irq_status(dpsparser, irq_index, status);
}

/******************************************************************************/
static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
	DPSPARSER_RSP_GET_API_VERSION(cmd_data, DPSPARSER_VER_MAJOR,
				      DPSPARSER_VER_MINOR);
	return 0;
}

/******************************************************************************/
static int apply_spb(struct device *dev, struct mc_cmd_data *cmd_data)
{
	uint64_t	blob_addr;
	struct dpsparser	*dpsparser;
	int			err = 0;
	
	pr_info("Handling command: apply_spb on DPSPARSER %d\n", device_get_id(dev));
	
	dpsparser = device_get_priv(dev);
	if (!dpsparser) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_NO_DPSP_HANDLE));
		err = MC_ERROR_SPB_ID_BLOB_NO_DPSP_HANDLE;
	}

	if (err == 0) {
		if (dpsparser->applied) {
			pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_ALREADY_APPLIED));
			err = MC_ERROR_SPB_ID_BLOB_ALREADY_APPLIED;
		}
	}
	
	if (err == 0) {
		/* Read parameters from portal */
		DPSPARSER_CMD_BLOB_SET_ADDR(cmd_data, blob_addr);
		
		/* Setup blob address */
		dpsparser_set_blob_address((void*)blob_addr);

		/* Initialize BLOB parsing */
		err = dpsparser_blob_parse(dpsparser);
	}
	
	if (err) {
		pr_err("apply_spb : dpsparser_blob_parse failed with error code = %d \n", err);
	} else {
		pr_info("apply_spb : dpsparser_blob_parse succeeded. \n");
	}
	
	/* Report MC Error code in command parameters */
	DPSPARSER_CMD_BLOB_REPORT_ERROR(cmd_data, err);

	return 0;
}

/******************************************************************************/
static int dpsparser_drv_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpsparser_open on DPSPARSER %d\n",
		device_get_id(dev));
	return 0;
}

/******************************************************************************/
static int dpsparser_drv_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpsparser_close on DPSPARSER %d\n",
		device_get_id(dev));
	return 0;
}

/******************************************************************************/
static int dpsparser_drv_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd,
				 int portal_id, uint8_t *data)
{
	struct mc_cmd_data	*cmd_data = (struct mc_cmd_data *)data;
	int			i;
	struct {
		int	code;
		int	(*function)(struct device *dev,
				    struct mc_cmd_data *cmd_data);
		char	*cmd_str;
		uint8_t	ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
		{ DPSPARSER_CMD_CODE_CREATE, init,
			"dpsparser_init", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_DESTROY, destroy,
			"dpsparser_destroy", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_RESET, reset,
			"dpsparser_reset", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_ENABLE, enable,
			"dpsparser_enable", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_DISABLE, disable,
			"dpsparser_disable", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_GET_ATTR, get_attributes,
			"dpsparser_get_attributes", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_IS_ENABLED, is_enabled,
			"dpsparser_is_enabled", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_SET_IRQ, set_irq,
			"dpsparser_set_irq", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_GET_IRQ, get_irq,
			"dpsparser_get_irq", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable,
			"dpsparser_set_irq_enable", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable,
			"dpsparser_get_irq_enable", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_SET_IRQ_MASK, set_irq_mask,
			"dpsparser_set_irq_mask", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_GET_IRQ_MASK, get_irq_mask,
			"dpsparser_get_irq_mask", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_GET_IRQ_STATUS, get_irq_status,
			"dpsparser_get_irq_status", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status,
			"dpsparser_clear_irq_status", DPSPARSER_CMD_VER_BASE },
		{ DPSPARSER_CMD_CODE_GET_API_VERSION, get_api_version,
			"dpsparser_get_api_version", DPSPARSER_CMD_VER_BASE },
		/* New command handlers start here */
		{ DPSPARSER_CMD_CODE_APPLY_SPB, apply_spb,
			"dpsparser_apply_spb", DPSPARSER_CMD_VER_BASE },
	};
	
	UNUSED(portal_id);
	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if (cmd == map_commands[i].code &&
		    (cmd_ver == MC_CMD_HDR_NO_VER ||
		     cmd_ver == map_commands[i].ver)) {
			if (cmd == DPSPARSER_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n",
					map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPSPARSER %d\n",
					map_commands[i].cmd_str,
					device_get_id(dev));
			return map_commands[i].function((struct device *)dev,
							cmd_data);
		}
	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}

/******************************************************************************/
static int dpsparser_drv_probe_cb(void *lo, int node_off)
{
	int			err = 0;
	struct mc_cmd_data	cmd = {0};
	struct mc_cmd_data	*cmd_data = &cmd;
	struct device		*dev;
	struct resman		*resman;
	int			destroy = 0;
	int			id;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* Create & open resman device */
	dev = resman_open_dev(resman, "dpsparser", (uint16_t)id, NO_PORTAL_ID,
			      DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPSPARSER %.4x\n", id);
	/* Create object */
	err = dpsparser_drv_ctrl_cb(dev, DPSPARSER_CMD_VER_BASE,
				    DPSPARSER_CMD_CODE_CREATE,
				    NO_PORTAL_ID, (uint8_t *)cmd_data);
	if (err)
		destroy = 1;
	err = resman_close_dev(resman, dev, "dpsparser", NO_PORTAL_ID, destroy);
	return err;
}

/******************************************************************************/
static int dpsparser_drv_remove_cb(void *lo, int node_off)
{
	struct resman		*resman;
	struct device		*dev;
	int			id;
	int			err = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	dev = resman_open_dev(resman, "dpsparser", (uint16_t)id, NO_PORTAL_ID,
			      0, NULL);
	if (!dev) {
		pr_err("Can't open DPSPARSER 0x%.4x\n", id);
		return -ENODEV;
	}
	err |= dpsparser_drv_ctrl_cb(dev, DPSPARSER_CMD_VER_BASE,
				    DPSPARSER_CMD_CODE_DESTROY,
				    NO_PORTAL_ID, NULL);
	err |= resman_close_dev(resman, dev, "dpsparser", NO_PORTAL_ID, 0);
	return err;
}

/******************************************************************************/
int dpsparser_drv_init(void)
{
	t_sys_dtc_mod_params		lo_params = {0};
	struct cmdif_module_ops		cmdif_ops = {0};
	struct dp_dev_type_param	dev_type_param = {0};
	struct resman			*resman;
	int				err;

	pr_info("Executing dpsparser_drv_init...\n");
	/* Call-backs */
	lo_params.num_compats = ARRAY_SIZE(dpsparser_drv_match);
	lo_params.compatibles = dpsparser_drv_match;
	lo_params.f_prob_module = dpsparser_drv_probe_cb;
	lo_params.f_remove_module = dpsparser_drv_remove_cb;
	sys_dtc_register_module(&lo_params);
	/* Command interface */
	cmdif_ops.open_cb = dpsparser_drv_open_cb;
	cmdif_ops.close_cb = dpsparser_drv_close_cb;
	cmdif_ops.ctrl_cb = dpsparser_drv_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPSPARSER, &cmdif_ops);
	/* Parameters & call-backs */
	strcpy(dev_type_param.device_type, "dpsparser");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPSPARSER_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPSPARSER_VER_MAJOR;
	dev_type_param.ver_minor = DPSPARSER_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;
	/* Register object */
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);
	resman_register_device_operation(resman, "dpsparser", &dev_type_param);
	dpsparser_drv = (struct dpsparser *)
		fsl_xmalloc(sizeof(struct dpsparser), 0, CORE_CACHELINE_SIZE);
	if (!dpsparser_drv) {
		pr_err("No memory for DPSPARSER\n");
		return -ENOMEM;
	}
	memset(dpsparser_drv, 0, sizeof(struct dpsparser));
	err = dpsparser_initialize(dpsparser_drv);
	if (err)
		return err;
	sys_add_handle(dpsparser_drv, FSL_MOD_DPSPARSER, 1, 1);
	return 0;
}
