/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpsparser_blob_check.h

 @Description   DPSPARSER BLOB CHECK internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPSPARSER_BLOB_DBG_H
#define __DPSPARSER_BLOB_DBG_H

/******************************************************************************/
#include "fsl_types.h"
#include "dpsparser_blob.h"

/******************************************************************************/
/* Define this macro to enable BLOB dump functions */
//#define	SOFT_PARSER_BLOB_DUMP
/* Define this macro to simulate a loaded soft parser BLOB */
//#define	SOFT_PARSER_BLOB_CHECK

/******************************************************************************/
#ifdef SOFT_PARSER_BLOB_DUMP
	int dpsparser_dump_blob_bytes(uint32_t bytes);
	void dpsparser_blob_dump_file_header_sect(struct sp_file_header *fhead);
	void dpsparser_blob_dump_name_sect(struct sp_blob_name *bname);
	void dpsparser_blob_dump_bytecode_sect(struct sp_byte_code *bc);
	void dpsparser_blob_dump_sp_profile_sect(struct sp_profile_cfg *pr);
	void dpsparser_blob_dump_protocol_cfg(struct sp_protocol_cfg *pr);
	void dpsparser_blob_dump_sp_params_sect(struct sp_parameters *params);
	void dpsparser_blob_dump_param_cfg(struct sp_param_cfg *param);
	void dpsparser_blob_dump_sp_params_sect_v1(struct sp_parameters_v1 *params);
	void dpsparser_blob_dump_param_cfg_v1(struct sp_param_cfg_v1 *param);
	void dpsparser_blob_dump_sp_protocols_sect_v1(struct sp_protocols_v1 *pr);
	void dpsparser_blob_dump_protocol_cfg_v1(struct sp_protocol_cfg_v1 *pr);
#else
	#define dpsparser_dump_blob_bytes(_a)
	#define dpsparser_blob_dump_file_header_sect(_a)
	#define dpsparser_blob_dump_name_sect(_a)
	#define dpsparser_blob_dump_bytecode_sect(_a)
	#define dpsparser_blob_dump_sp_profile_sect(_a)
	#define dpsparser_blob_dump_protocol_cfg(_a)
	#define dpsparser_blob_dump_sp_params_sect(_a)
	#define dpsparser_blob_dump_param_cfg(_a)
	#define dpsparser_blob_dump_sp_protocols_sect_v1(_a)
	#define dpsparser_blob_dump_protocol_cfg_v1(_a)
	#define dpsparser_blob_dump_sp_params_sect_v1(_a)
	#define dpsparser_blob_dump_param_cfg_v1(_a)
#endif	/* SOFT_PARSER_BLOB_DUMP */

#ifdef SOFT_PARSER_BLOB_CHECK
	/* Enough memory to describe and define soft parser on 3 HW
	 * parsers (12 KB) */
	#define SP_BLOB_SIZE	(64 * KILOBYTE)

	extern uint8_t	*sp_blob_waddr;

	struct dpsparser;

	int dpsparser_write_blob(struct dpsparser *dpsparser);
#else
	#define dpsparser_write_blob(_a)	0
#endif	/* SOFT_PARSER_BLOB_CHECK */

#endif	/* __DPSPARSER_BLOB_DBG_H */
