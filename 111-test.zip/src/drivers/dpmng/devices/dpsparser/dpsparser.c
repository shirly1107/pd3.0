/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpsparser.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_platform.h"
#include "fsl_resman.h"

#include "fsl_dpsparser_mc.h"
#include "fsl_dpsparser_cmd.h"
#include "dpsparser.h"
#include "dpsparser_blob.h"
#include "dpsparser_blob_dbg.h"

#include "fsl_dpparser.h"

static char* mc_err_msg_apply_spb[] = MC_ERROR_MSG_APPLY_SPB;

/******************************************************************************/
/* Define this macro to print soft parser debug information */
/*#define SOFT_PARSER_DEBUG*/

#ifdef SOFT_PARSER_DEBUG
/******************************************************************************/
static void dpsparser_print_name(uint8_t *name, uint8_t len)
{
	int		i;
	uint8_t		*pch;

	pch = name;
	for (i = 0; i < len && *pch; i++)
		fsl_print("%c", *pch++);
	fsl_print("\n");
}
#endif	/* SOFT_PARSER_DEBUG */

/******************************************************************************/
static void resources_authorization(struct dpsparser *dpsparser)
{
	CHECK_COND_RET(dpsparser);
	if (dpsparser->authorized)
		return;
	dpsparser->authorized = 1;
}

/******************************************************************************/
static void resources_deauthorization(struct dpsparser *dpsparser)
{
	CHECK_COND_RET(dpsparser);
	if (!dpsparser->authorized)
		return;
	dpsparser->authorized = 0;
	dpsparser->amq.icid = (uint16_t)-1;
}

/******************************************************************************/
static int invoke_inter(void *dpsparser, uint8_t index, uint32_t event)
{
	CHECK_COND_RETVAL(dpsparser, -EINVAL);
	event_send(&(((struct dpsparser *)dpsparser)->irqs[index]), event);
	return 0;
}

/******************************************************************************/
char* get_error_msg(int error)
{
	int err_arr_size = ARRAY_SIZE(mc_err_msg_apply_spb);
	
	if (0 < error && error < err_arr_size)
		return mc_err_msg_apply_spb[error];
	else
		return MC_ERROR_MSG_SPB_UNKNOWN;
}

#ifdef TKT011436
/**************************************************************************//**
 @Function     dpsparser_restore
*//***************************************************************************/
int dpsparser_restore(const struct dpsparser *dpsparser)
{
	int	err = 0;

	if (!dpsparser->parsers) {
		pr_err("No parser found\n");
		return -ENODEV;
	}

	if (dpsparser->parsers->eiop_ingress_initialized) {
		/* Disable PCLIM check */
		parser_ctrl_set_pclim(0, CTLU_EIOP_INGRESS);
		pr_debug("Ingress Parser Rev = %08x\n", 
				parser_ctrl_get_ip_rev_1(CTLU_EIOP_EGRESS));
	}
	if (dpsparser->parsers->eiop_egress_initialized) {
		/* Disable PCLIM check */
		parser_ctrl_set_pclim(0, CTLU_EIOP_EGRESS);
		pr_debug("Egress Parser Rev = %08x\n",
				parser_ctrl_get_ip_rev_1(CTLU_EIOP_EGRESS));
	}
	if (dpsparser->parsers->aiop_ctlu_initialized) {
		/* Disable PCLIM check */
		parser_ctrl_set_pclim(0, CTLU_AIOP);
		pr_debug("AIOP Parser Rev = %08x\n",
				parser_ctrl_get_ip_rev_1(CTLU_AIOP));
	}

	pr_debug("IP revision : MAJ = %d MIN = %d\n",
		dpsparser->ip_rev_major, dpsparser->ip_rev_minor);

#ifdef SOFT_PARSER_BLOB_CHECK
	//Do not parse blob on init because the blob is loaded via mc commands
	/* Initialize BLOB parsing */
	err = dpsparser_blob_parse(dpsparser);
	if (err)
		return err;
#endif

	return 0;
}
#endif /* TKT011436 */

/******************************************************************************/
int dpsparser_initialize(struct dpsparser *dpsparser)
{
	uint32_t ip_rev;

	dpsparser->parsers = sys_get_handle(FSL_MOD_PARSER_CTRL, 1, 0);
	if (!dpsparser->parsers) {
		pr_err("No parser found\n");
		return -ENODEV;
	}
	ip_rev = 0;
	if (dpsparser->parsers->eiop_ingress_initialized) {
		/* Disable PCLIM check */
		parser_ctrl_set_pclim(0, CTLU_EIOP_INGRESS);
		/* Get IP_REV */
		ip_rev = parser_ctrl_get_ip_rev_1(CTLU_EIOP_INGRESS);
		pr_info("Ingress Parser Rev = %08x\n", ip_rev);
	}
	if (dpsparser->parsers->eiop_egress_initialized) {
		/* Disable PCLIM check */
		parser_ctrl_set_pclim(0, CTLU_EIOP_EGRESS);
		/* Get IP_REV */
		if (!ip_rev)
			ip_rev = parser_ctrl_get_ip_rev_1(CTLU_EIOP_EGRESS);
		pr_info("Egress Parser Rev = %08x\n",
			parser_ctrl_get_ip_rev_1(CTLU_EIOP_EGRESS));
	}
	if (dpsparser->parsers->aiop_ctlu_initialized) {
		/* Disable PCLIM check */
		parser_ctrl_set_pclim(0, CTLU_AIOP);
		/* Get IP_REV */
		if (!ip_rev)
			ip_rev = parser_ctrl_get_ip_rev_1(CTLU_AIOP);
		pr_info("AIOP Parser Rev = %08x\n",
			parser_ctrl_get_ip_rev_1(CTLU_AIOP));
	}
	dpsparser->ip_rev_major = (uint8_t)(ip_rev >> 8);
	dpsparser->ip_rev_minor = (uint8_t)ip_rev;
	pr_info("IP revision : MAJ = %d MIN = %d\n",
		dpsparser->ip_rev_major, dpsparser->ip_rev_minor);

#ifdef SOFT_PARSER_BLOB_CHECK
	//Do not parse blob on init because the blob is loaded via mc commands
	/* Initialize BLOB parsing */
	{
		int err = dpsparser_blob_parse(dpsparser);
		if (err)
			return err;
	}
#endif

	return 0;
}

/******************************************************************************/
void dpsparser_destroy(struct dpsparser *dpsparser)
{
	int	err;

	dpsparser_reset(dpsparser);
	resources_deauthorization(dpsparser);
	err = resman_unbind_all(dpsparser->device);
	CHECK_COND_RET(err == 0);
}

/******************************************************************************/
int dpsparser_enable(struct dpsparser *dpsparser)
{
	dpsparser->enabled = 1;
	return 0;
}

/******************************************************************************/
int dpsparser_disable(struct dpsparser *dpsparser)
{
	dpsparser->enabled = 0;
	return 0;
}

/******************************************************************************/
int dpsparser_is_enabled(struct dpsparser *dpsparser, int *en)
{
	*en = dpsparser->enabled;
	return 0;
}

/******************************************************************************/
void dpsparser_reset(struct dpsparser *dpsparser)
{
}

/******************************************************************************/
int dpsparser_get_attributes(struct dpsparser *dpsparser,
			     struct dpsparser_attr *attributes)
{
	attributes->id = dpsparser->id;
	return 0;
}

/******************************************************************************/
int dpsparser_set_dev_ctx(struct dpsparser *dpsparser,
			  const struct dpmng_dev_ctx *dev_ctx)
{
	if (memcmp(&dpsparser->amq, &dev_ctx->amq,
		   sizeof(struct dpmng_amq)) != 0) {
		CHECK_COND_RETVAL(!dpsparser->enabled, -EINVAL);
		resources_deauthorization(dpsparser);
		dpsparser->amq = dev_ctx->amq;
		dpsparser->amq.bdi =
			(dev_ctx->type == DPMNG_CTX_TYPE_GPP) ? 0 : 1;
		resources_authorization(dpsparser);
	}
	return 0;
}

/******************************************************************************/
int dpsparser_set_irq(struct dpsparser *dpsparser, uint8_t irq_index,
		      const struct mc_irq_cfg *irq_cfg)
{
	if (irq_index >= DPSPARSER_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index,
		       DPSPARSER_MAX_IRQ_NUM);
		return -EINVAL;
	}
	mc_set_irq(&dpsparser->irqs[irq_index], irq_cfg);
	return 0;
}

/******************************************************************************/
int dpsparser_get_irq(struct dpsparser *dpsparser, uint8_t irq_index,
		      struct mc_irq_cfg *irq_cfg)
{
	int		err;

	if (irq_index >= DPSPARSER_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index,
		       DPSPARSER_MAX_IRQ_NUM);
		return -EINVAL;
	}
	err = mc_get_irq(&dpsparser->irqs[irq_index], irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);
	return 0;
}

/******************************************************************************/
int dpsparser_set_irq_enable(struct dpsparser *dpsparser, uint8_t irq_index,
			     uint8_t en)
{
	int	err;

	if (irq_index >= DPSPARSER_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index,
		       DPSPARSER_MAX_IRQ_NUM);
		return -EINVAL;
	}
	err = mc_set_irq_enable(&dpsparser->irqs[irq_index], en);
	CHECK_COND_RETVAL(err == 0, err);
	return 0;
}

/******************************************************************************/
int dpsparser_get_irq_enable(struct dpsparser *dpsparser, uint8_t irq_index,
			     uint8_t *en)
{
	int	err;

	if (irq_index >= DPSPARSER_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index,
		       DPSPARSER_MAX_IRQ_NUM);
		return -EINVAL;
	}
	err = mc_get_irq_enable(&dpsparser->irqs[irq_index], en);
	CHECK_COND_RETVAL(err == 0, err);
	return 0;
}

/******************************************************************************/
int dpsparser_set_irq_mask(struct dpsparser *dpsparser, uint8_t irq_index,
			   uint32_t mask)
{
	int	err;

	if (irq_index >= DPSPARSER_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index,
		       DPSPARSER_MAX_IRQ_NUM);
		return -EINVAL;
	}
	err = mc_set_irq_mask(&dpsparser->irqs[irq_index], mask);
	CHECK_COND_RETVAL(err == 0, err);
	/* Set interrupts on parser events */
	return 0;
}

/******************************************************************************/
int dpsparser_get_irq_mask(struct dpsparser *dpsparser, uint8_t irq_index,
			   uint32_t *mask)
{
	int	err;

	if (irq_index >= DPSPARSER_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index,
		       DPSPARSER_MAX_IRQ_NUM);
		return -EINVAL;
	}
	err = mc_get_irq_mask(&dpsparser->irqs[irq_index], mask);
	CHECK_COND_RETVAL(err == 0, err);
	return 0;
}

/******************************************************************************/
int dpsparser_get_irq_status(struct dpsparser *dpsparser, uint8_t irq_index,
			     uint32_t *status)
{
	int	err;

	if (irq_index >= DPSPARSER_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index,
		       DPSPARSER_MAX_IRQ_NUM);
		return -EINVAL;
	}
	err = mc_get_irq_status(&dpsparser->irqs[irq_index], status);
	CHECK_COND_RETVAL(err == 0, err);
	return 0;
}

/******************************************************************************/
int dpsparser_clear_irq_status(struct dpsparser *dpsparser, uint8_t irq_index,
			       uint32_t status)
{
	int	err;

	if (irq_index >= DPSPARSER_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index,
		       DPSPARSER_MAX_IRQ_NUM);
		return -EINVAL;
	}
	err = mc_clear_irq_status(&dpsparser->irqs[irq_index], status);
	CHECK_COND_RETVAL(err == 0, err);
	return 0;
}

/******************************************************************************/
void dpsparser_exceptions(struct dpsparser *dpsparser)
{
	CHECK_COND_RET(dpsparser);
}

/******************************************************************************/
static int dpsparser_validate_sp_params(uint32_t offset, uint32_t sz,
					uint32_t flags)
{
	if (offset % 4) {
		pr_err("Offset %d is not a 4 multiple\n", offset);
		return MC_ERROR_SPB_ID_BLOB_PARAM_OFFSET_MULT_4;
	}
	if (offset < 0x40) {
		pr_err("Offset %d can't be less than 0x40\n", offset);
		return MC_ERROR_SPB_ID_BLOB_PARAM_OFFSET_LESS_0x40;
	}
	if (sz % 4) {
		pr_err("Byte-code size %d is not a 4 multiple\n", sz);
		return MC_ERROR_SPB_ID_BLOB_BYTECODE_SIZE_MULT_4;
	}
	if (!sz) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_BYTECODE_SIZE_ZERO));
		return MC_ERROR_SPB_ID_BLOB_BYTECODE_SIZE_ZERO;
	}
	if (offset + sz >= 0xffe) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_BYTECODE_OVERWRITE_0xFFE));
		return MC_ERROR_SPB_ID_BLOB_BYTECODE_OVERWRITE_0xFFE;
	}
	if (!flags) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_TARGET_PARSER));
		return MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_TARGET_PARSER;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_check_bc(struct parser_layout *layout, uint32_t offset,
			      uint32_t sz)
{
	uint32_t	nsp_eaddr, osp_saddr, osp_eaddr;
	uint16_t	i;
	int		err;

	err = 0;
	nsp_eaddr = (uint32_t)offset + sz;
	for (i = 0; i < layout->sp_count; i++) {
		osp_saddr = 2 * (uint32_t)layout->sp[i].pc;
		osp_eaddr = osp_saddr + layout->sp[i].size - 1;
		/* Start address inside or
		 * End address inside or
		 * Start address less, end address greater (inclusion) */
		if ((offset >= osp_saddr && offset < osp_eaddr) ||
		    (nsp_eaddr >= osp_saddr && nsp_eaddr < osp_eaddr) ||
		    (offset < osp_saddr && nsp_eaddr > osp_eaddr)) {

			pr_err("Bytecode PC = 0x%03x is overlapped\n",
			       layout->sp[i].pc);
			err = MC_ERROR_SPB_ID_BLOB_BYTECODE_OVERLAPPED;
			break;
		}
	}
	return err;
}

/******************************************************************************/
int dpsparser_load_bytecode(struct dpsparser *dpsparser, uint8_t *bcode,
			    uint32_t offset, uint32_t sz, uint32_t flags)
{
	int			err;
	uint16_t		idx;
	struct soft_parser	sp;

	CHECK_COND_RETVAL(dpsparser, -1);
	CHECK_COND_RETVAL(bcode, -1);
	if (!dpsparser->parsers) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_PARSER_SUPPORT));
		return MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_PARSER_SUPPORT;
	}
	/* Validate SP parameters */
	err = dpsparser_validate_sp_params(offset, sz, flags);
	if (err)
		return err;
	/* Check if SP byte-code overlaps a registered SP byte-code */
	if ((flags & WRIOP_INGRESS_PARSER) &&
	    dpsparser->parsers->eiop_ingress_initialized) {
		err = dpsparser_check_bc(&dpsparser->ingress_sp, offset, sz);
		if (err)
			return err;
	}
	if ((flags & WRIOP_EGRESS_PARSER) &&
	    dpsparser->parsers->eiop_egress_initialized) {
		err = dpsparser_check_bc(&dpsparser->egress_sp, offset, sz);
		if (err)
			return err;
	}
	if ((flags & AIOP_PARSER) &&
	    dpsparser->parsers->aiop_ctlu_initialized) {
		err = dpsparser_check_bc(&dpsparser->aiop_sp, offset, sz);
		if (err)
			return err;
	}
	/* Write SP byte-code in the parser instructions memory */
	sp.pc = (uint16_t)(offset / 2);
	sp.size = (uint16_t)sz;
	sp.byte_code = bcode;
	if ((flags & WRIOP_INGRESS_PARSER) &&
	    dpsparser->parsers->eiop_ingress_initialized) {
		if (dpsparser->ingress_sp.sp_count == MAX_BYTECODE_SECTIONS) {
			pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_EXCEEDED_WRIOP_ingress));
			return MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_EXCEEDED_WRIOP_ingress;
		}
		err = parser_ctrl_load_soft_parser(&sp, CTLU_EIOP_INGRESS);
		if (err)
			return err;
		/*parser_ctrl_dump_mem(CTLU_EIOP_INGRESS);*/
		idx = dpsparser->ingress_sp.sp_count;
		/* Clear; set PC and size */
		memset(&dpsparser->ingress_sp.sp[idx], 0,
		       sizeof(struct bytecode_info));
		dpsparser->ingress_sp.sp[idx].pc = sp.pc;
		dpsparser->ingress_sp.sp[idx].size = sp.size;
		dpsparser->ingress_sp.sp[idx].flags = WRIOP_INGRESS_PARSER;
		dpsparser->ingress_sp.sp_count++;
	}
	if ((flags & WRIOP_EGRESS_PARSER) &&
	    dpsparser->parsers->eiop_egress_initialized) {
		if (dpsparser->egress_sp.sp_count == MAX_BYTECODE_SECTIONS) {
			pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_EXCEEDED_WRIOP_egress));
			return MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_EXCEEDED_WRIOP_egress;
		}
		err = parser_ctrl_load_soft_parser(&sp, CTLU_EIOP_EGRESS);
		if (err)
			return err;
		/*parser_ctrl_dump_mem(CTLU_EIOP_EGRESS);*/
		idx = dpsparser->egress_sp.sp_count;
		/* Clear and set PC an size */
		memset(&dpsparser->egress_sp.sp[idx], 0,
		       sizeof(struct bytecode_info));
		dpsparser->egress_sp.sp[idx].pc = sp.pc;
		dpsparser->egress_sp.sp[idx].size = sp.size;
		dpsparser->egress_sp.sp[idx].flags = WRIOP_EGRESS_PARSER;
		dpsparser->egress_sp.sp_count++;
	}
	if ((flags & AIOP_PARSER) &&
	    dpsparser->parsers->aiop_ctlu_initialized) {
		if (dpsparser->aiop_sp.sp_count == MAX_BYTECODE_SECTIONS) {
			pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_EXCEEDED_AIOP));
			return MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_EXCEEDED_AIOP;
		}
		err = parser_ctrl_load_soft_parser(&sp, CTLU_AIOP);
		if (err)
			return err;
		/*parser_ctrl_dump_mem(CTLU_AIOP);*/
		idx = dpsparser->aiop_sp.sp_count;
		/* Clear and set PC an size */
		memset(&dpsparser->aiop_sp.sp[idx], 0,
		       sizeof(struct bytecode_info));
		dpsparser->aiop_sp.sp[idx].pc = sp.pc;
		dpsparser->aiop_sp.sp[idx].size = sp.size;
		dpsparser->aiop_sp.sp[idx].flags = AIOP_PARSER;
		dpsparser->aiop_sp.sp_count++;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_check_sp_profile_name(struct parser_layout *layout, char *profile_name)
{
	int	i, err;

	/* Protocol name */
	err = 0;
	for (i = 0; i < layout->profile_count; i++)
		if (!memcmp(layout->profiles[i].name, profile_name, MAX_SP_PROFILE_ID_SIZE)) {
			pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_PROFILE_DUPLICATED));
			err = MC_ERROR_SPB_ID_BLOB_PROFILE_DUPLICATED;
			break;
		}
	/* SP Profile already registered */
	if (err)
		return err;

	return 0;
}

/******************************************************************************/
static int dpsparser_check_profile_name(struct dpsparser *dpsparser, char *profile_name)
{
	int	err;

	if (dpsparser->parsers->eiop_ingress_initialized) {
		err = dpsparser_check_sp_profile_name(&dpsparser->ingress_sp, profile_name);
		if (err)
			return err;
	}
	if (dpsparser->parsers->eiop_egress_initialized) {
		err = dpsparser_check_sp_profile_name(&dpsparser->egress_sp, profile_name);
		if (err)
			return err;
	}
	if (dpsparser->parsers->aiop_ctlu_initialized) {
		err = dpsparser_check_sp_profile_name(&dpsparser->aiop_sp, profile_name);
		if (err)
			return err;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_add_protocols(struct parser_layout *layout, struct profile_info *profile, struct sp_profile_cfg *sp_profile)
{
	uint16_t	i, j, pc;
	
	/* Check Number of protocols */
	if (sp_profile->proto_no > MAX_PROTOCOLS) {
		pr_err("Protocols %d limit exceeded\n", MAX_PROTOCOLS);
		return MC_ERROR_SPB_ID_BLOB_PROTOCOL_NO_EXCEEDED;
	}
	
	for (i = 0; i < sp_profile->proto_no; i++) {
	
		pc = sp_profile->protocol_cfg[i].seq_start / 2;
		/* Check if the protocol code is loaded onto the parser */
		for (j = 0; j < layout->sp_count; j++) {
			if (pc >= layout->sp[j].pc && pc < layout->sp[j].pc + layout->sp[j].size)
				break;
		}
		/* Not loaded */
		if (j == layout->sp_count)
			return -1;
		
		memcpy(profile->proto[i].name, sp_profile->protocol_cfg[i].sp_name, 8);
		profile->proto[i].pc = pc;
		profile->proto[i].lnk = (enum sparser_link)sp_profile->protocol_cfg[i].base_proto;

		profile->proto[i].num_params = 0;
		profile->proto[i].par_arr_usage_bits = 0;
		
		#ifdef SOFT_PARSER_DEBUG
		fsl_print("Dump of added protocol :\n");
		fsl_print("\t name    = ");
		dpsparser_print_name(profile->proto[i].name, 8);
		fsl_print("\t pc      = 0x%x\n", profile->proto[i].pc);
		fsl_print("\t lnk     = 0x%x\n", (uint32_t)profile->proto[i].lnk);
		#endif	/* SOFT_PARSER_DEBUG */
	}
	profile->proto_count = sp_profile->proto_no;
	return 0;
}

/******************************************************************************/
static int dpsparser_add_profile(struct parser_layout *layout, struct sp_profile_cfg *sp_profile)
{
	int		err;

	/* Check Number of Profiles */
	if (layout->profile_count == MAX_PROFILES) {
		pr_err("Profiles limit exceeded: %d\n", MAX_PROFILES);
		return MC_ERROR_SPB_ID_BLOB_PROFILES_NO_EXCEEDED;
	}
	if (layout->profile_count == layout->alloc_profile_count) {
		pr_err("Allocated profiles limit exceeded: %d\n", layout->alloc_profile_count);
		return MC_ERROR_SPB_ID_BLOB_PROFILES_NO_EXCEEDED;
	}

	/* Add profile */
	memcpy(layout->profiles[layout->profile_count].name, sp_profile->profile_name, MAX_SP_PROFILE_ID_SIZE);
	layout->profiles[layout->profile_count].en_flags = sp_profile->enable_flags;
	
	layout->profiles[layout->profile_count].proto_count = 0;
	memset(layout->profiles[layout->profile_count].proto, 0, MAX_PROTOCOLS * sizeof(struct protocol_info));
	
	/* Add protocols */
	err = dpsparser_add_protocols(layout, &layout->profiles[layout->profile_count], sp_profile);
	if (err)
		return err;

#ifdef SOFT_PARSER_DEBUG
	fsl_print("Dump of added profile :\n");
	fsl_print("\t name    = ");
	dpsparser_print_name(layout->profiles[layout->profile_count].name, 8);
	fsl_print("\t enabled = 0x%x\n", layout->profiles[layout->profile_count].en_flags);
#endif	/* SOFT_PARSER_DEBUG */
	
	layout->profile_count++;
	return 0;
}

/******************************************************************************/
int dpsparser_set_profile(struct dpsparser *dpsparser, struct sp_profile_cfg *sp_profile)
{
	int		err;
	
	/* Check the profile name is unique across the BLOB */
	err = dpsparser_check_profile_name(dpsparser, sp_profile->profile_name);
	if (err)
		return err;

	/* Set the profile on all parsers it was enabled on */
	uint8_t flags = sp_profile->enable_flags;
	
	if (dpsparser->parsers->eiop_ingress_initialized && (flags & ENABLE_ON_WRIOP_INGRESS)) {
		err = dpsparser_add_profile(&dpsparser->ingress_sp, sp_profile);
		if (err)
			return err;
	}
	if (dpsparser->parsers->eiop_egress_initialized && (flags & ENABLE_ON_WRIOP_EGRESS)) {
		err = dpsparser_add_profile(&dpsparser->egress_sp, sp_profile);
		if (err)
			return err;
	}
	if (dpsparser->parsers->aiop_ctlu_initialized && (flags & (ENABLE_ON_AIOP_INGRESS | ENABLE_ON_AIOP_EGRESS))) {
		err = dpsparser_add_profile(&dpsparser->aiop_sp, sp_profile);
		if (err)
			return err;
	}
	
	return 0;
}

static int dpsparser_check_pname(struct parser_layout *layout, char *sp_name)
{
	int	i, j, err;

	/* Protocol name */
	err = 0;
	for (i = 0; i < layout->profile_count; i++) {
		for (j = 0; j < layout->profiles[i].proto_count; j++) {
			if (!memcmp(layout->profiles[i].proto[j].name, sp_name, 8)) {
				pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_PROTOCOL_DUPLICATED));
				err = MC_ERROR_SPB_ID_BLOB_PROTOCOL_DUPLICATED;
				break;
			}
		}
	}
	/* Protocol already registered */
	if (err)
		return err;

	return 0;
}

/******************************************************************************/
static int dpsparser_check_protocol_name(struct dpsparser *dpsparser,
					 char *sp_name)
{
	int	err;

	if (dpsparser->parsers->eiop_ingress_initialized) {
		err = dpsparser_check_pname(&dpsparser->ingress_sp, sp_name);
		if (err)
			return err;
	}
	if (dpsparser->parsers->eiop_egress_initialized) {
		err = dpsparser_check_pname(&dpsparser->egress_sp, sp_name);
		if (err)
			return err;
	}
	if (dpsparser->parsers->aiop_ctlu_initialized) {
		err = dpsparser_check_pname(&dpsparser->aiop_sp, sp_name);
		if (err)
			return err;
	}
	return 0;
}

/******************************************************************************/
/* Backward compatibility Blob: v1 */

static int dpsparser_add_protocol_v1(struct parser_layout *layout,
				  uint8_t en_flags, uint16_t seq_start,
				  enum sparser_link base_proto, char *sp_name)
{
	uint16_t	i, pc;

	pc = seq_start / 2;
	/* Check if the protocol code is loaded onto the parser */
	for (i = 0; i < layout->sp_count; i++)
		if (pc >= layout->sp[i].pc &&
		    pc < layout->sp[i].pc + layout->sp[i].size)
			break;
	/* Not loaded */
	if (i == layout->sp_count)
		return 0;
	
	//----------------------------------------------------
	/* Migrate v1 to current version */
	
	// Add Default Profile if there is none:
	if (layout->profile_count == 0) {
		memset(layout->profiles[0].name, 0, MAX_SP_PROFILE_ID_SIZE);
		layout->profile_count++;
	}
	layout->profiles[0].en_flags |= en_flags;
	//----------------------------------------------------

	/* Number of protocols */
	if (layout->profiles[0].proto_count == MAX_PROTOCOLS) {
		pr_err("Protocols %d limit exceeded\n", MAX_PROTOCOLS);
		return MC_ERROR_SPB_ID_BLOB_PROTOCOL_NO_EXCEEDED;
	}
	/* Add protocol */
	memcpy(layout->profiles[0].proto[layout->profiles[0].proto_count].name, sp_name, 8);
	layout->profiles[0].proto[layout->profiles[0].proto_count].pc = pc;
	layout->profiles[0].proto[layout->profiles[0].proto_count].lnk = base_proto;
	//en_flags have been moved from protocol to profile (and it is set above at migration)
	//layout->profiles[0].proto[layout->profiles[0].proto_count].en_flags = en_flags;
#ifdef SOFT_PARSER_DEBUG
	fsl_print("Dump of added protocol :\n");
	fsl_print("\t name    = ");
	dpsparser_print_name(layout->profiles[0].proto[layout->profiles[0].proto_count].name, 8);
	fsl_print("\t enabled = 0x%x\n", layout->profiles[0].proto[layout->profiles[0].proto_count].en_flags);
	fsl_print("\t pc      = 0x%x\n", layout->profiles[0].proto[layout->profiles[0].proto_count].pc);
	fsl_print("\t lnk     = 0x%x\n", (uint32_t)layout->profiles[0].proto[layout->profiles[0].proto_count].lnk);
#endif	/* SOFT_PARSER_DEBUG */
	layout->profiles[0].proto_count++;
	return 0;
}

int dpsparser_set_protocol_v1(struct dpsparser *dpsparser, char *sp_name,
			   enum sparser_link base_proto, uint8_t flags,
			   uint16_t seq_start)
{
	int		err;

	/* Check the protocol name is unique across the BLOB */
	err = dpsparser_check_protocol_name(dpsparser, sp_name);
	if (err)
		return err;
	/* Set the protocol parameters on all parsers it was loaded on */
	if (dpsparser->parsers->eiop_ingress_initialized) {
		err = dpsparser_add_protocol_v1(&dpsparser->ingress_sp,
					     flags & ENABLE_ON_WRIOP_INGRESS,
					     seq_start, base_proto, sp_name);
		if (err)
			return err;
	}
	if (dpsparser->parsers->eiop_egress_initialized) {
		err = dpsparser_add_protocol_v1(&dpsparser->egress_sp,
					     flags & ENABLE_ON_WRIOP_EGRESS,
					     seq_start, base_proto, sp_name);
		if (err)
			return err;
	}
	if (dpsparser->parsers->aiop_ctlu_initialized) {
		err = dpsparser_add_protocol_v1(&dpsparser->aiop_sp,
					     flags & (ENABLE_ON_AIOP_INGRESS |
						      ENABLE_ON_AIOP_EGRESS),
					     seq_start, base_proto, sp_name);
		if (err)
			return err;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_set_proto_param(struct parser_layout *layout,
				     char *profile_name, char *proto_name, uint8_t flags,
				     char *pname, uint8_t poffset,
				     uint8_t psize, uint8_t *pvalue)
{
	uint16_t		i;
	uint64_t		usage_bit_mask;
	struct profile_info		*profile;
	struct protocol_info	*proto;
	int			err;

	/* Not initialized/existing parser */
	if (!layout)
		return 0;
	/* No soft parser loaded on this parser or not defined profiles */
	if (!layout->sp_count || !layout->profile_count)
		return 0;

	if (profile_name == NULL) {
		/* Use Default profile */

		/* No default profile found in this parser */
		if (layout->profile_count == 0)
			return 0;
		
		profile = &layout->profiles[DEFAULT_PROFILE_IDX];
	} else {
		/* Find the profile by name */
		err = -ENOENT;
		for (i = 0; i < layout->profile_count; i++) {
			if (!memcmp(layout->profiles[i].name, profile_name, MAX_SP_PROFILE_ID_SIZE)) {
				err = 0;
				break;
			}
		}
		/* Profile not found in this parser */
		if (err)
			return 0;

		profile = &layout->profiles[i];
	}

	/* Find the protocol by name */
	err = -ENOENT;
	for (i = 0; i < profile->proto_count; i++) {
		if (!memcmp(profile->proto[i].name, proto_name, 8)) {
			err = 0;
			break;
		}
	}
	/* Protocol not found in this profile */
	if (err)
		return 0;
	
	proto = &profile->proto[i];
	
	if (poffset > PAR_ARRAY_SIZE) {
		pr_err("Offset exceeds the %d limit\n",
		       PAR_ARRAY_SIZE);
		return MC_ERROR_SPB_ID_BLOB_PARAM_OFFSET_EXCEEDED;
	}
	if (psize > 64) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_PARAM_SIZE_EXCEEDED));
		return MC_ERROR_SPB_ID_BLOB_PARAM_SIZE_EXCEEDED;
	}
	if (poffset + psize > PAR_ARRAY_SIZE) {
		pr_err("Offset plus size exceeds the %d limit\n",
		       PAR_ARRAY_SIZE);
		return MC_ERROR_SPB_ID_BLOB_PARAM_OFFSET_SIZE_EXCEEDED;
	}
	
	/* Check limit */
	if (proto->num_params == PAR_ARRAY_SIZE) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_PARAM_NO_EXCEEDED));
		return MC_ERROR_SPB_ID_BLOB_PARAM_NO_EXCEEDED;
	}
	/* Check the parameter name is unique per profile */
	err = 0;
	for (i = 0; i < proto->num_params; i++)
		if (!memcmp(proto->par_array[i].name, pname, 8)) {
			err = MC_ERROR_SPB_ID_BLOB_PARAM_NAME_DUPLICATED;
			pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_PARAM_NAME_DUPLICATED));
			break;
		}
	/* Name already used */
	if (err)
		return err;

	/* Check if this parameter overlaps another one */
	usage_bit_mask = 0;
	for (i = 0; i < psize; i++)
		usage_bit_mask |= 1ULL << (63 - poffset - i);
	if (usage_bit_mask & proto->par_arr_usage_bits) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_PARAM_OVERLAPPED));
		return MC_ERROR_SPB_ID_BLOB_PARAM_OVERLAPPED;
	}
	/* Set usage information */
	proto->par_arr_usage_bits |= usage_bit_mask;
	/* Store parameter information */
	i = proto->num_params;
	proto->par_array[i].offset = poffset;
	proto->par_array[i].flags = flags;
	proto->par_array[i].size = psize;
	if (psize)
		memcpy(proto->par_array[i].value, pvalue, psize);
	memcpy(proto->par_array[i].name, pname, 8);
#ifdef SOFT_PARSER_DEBUG
	fsl_print("Dump of added parameter :\n");
	fsl_print("\t name   = ");
	dpsparser_print_name(proto->par_array[i].name, 8);
	fsl_print("\t offset = %d\n", proto->par_array[i].offset);
	fsl_print("\t flags  = 0x%x\n", proto->par_array[i].flags);
	fsl_print("\t size   = %d\n", proto->par_array[i].size);
	if (!psize) {
		fsl_print("\t value  = 0 (default)\n");
	} else {
		int	j;

		fsl_print("\t value  = ");
		for (j = 0; j < proto->par_array[i].size; j++) {
			fsl_print("%02x ", proto->par_array[i].value[j]);
			if (!((j + 1) % 8))
				fsl_print("\n\t          ");
		}
		fsl_print("\n");
	}
	fsl_print("Parameter Array Usage bits = %08x-%08x\n",
		  (uint32_t)(proto->par_arr_usage_bits >> 32),
		  (uint32_t)proto->par_arr_usage_bits);
#endif	/* SOFT_PARSER_DEBUG */
	proto->num_params++;
	return 0;
}

/******************************************************************************/
int dpsparser_set_param(struct dpsparser *dpsparser, char *profile_name, char *proto_name,
			uint8_t flags, char *pname, uint16_t poffset,
			uint16_t psize, uint8_t *pvalue)
{
	int		err;

	/* Set protocol parameters */
	if (dpsparser->parsers->eiop_ingress_initialized) {
		err = dpsparser_set_proto_param(&dpsparser->ingress_sp,
						profile_name, proto_name, flags, pname,
						(uint8_t)poffset,
						(uint8_t)psize, pvalue);
		if (err)
			return err;
	}
	if (dpsparser->parsers->eiop_egress_initialized) {
		err = dpsparser_set_proto_param(&dpsparser->egress_sp,
						profile_name, proto_name, flags, pname,
						(uint8_t)poffset,
						(uint8_t)psize, pvalue);
		if (err)
			return err;
	}
	if (dpsparser->parsers->aiop_ctlu_initialized) {
		err = dpsparser_set_proto_param(&dpsparser->aiop_sp,
						profile_name, proto_name, flags, pname,
						(uint8_t)poffset,
						(uint8_t)psize, pvalue);
		if (err)
			return err;
	}
	return 0;
}

/******************************************************************************/
static struct parser_layout	*dpsparser_get_layout(struct dpsparser *dpsparser, enum ctlu_type type)
{
	struct parser_layout *layout = NULL;

	switch (type) {
	case CTLU_EIOP_INGRESS:
		if (dpsparser->parsers->eiop_ingress_initialized) {
			layout = &dpsparser->ingress_sp;
		}
		break;
	case CTLU_EIOP_EGRESS:
		if (dpsparser->parsers->eiop_egress_initialized) {
			layout = &dpsparser->egress_sp;
		}
		break;
	case CTLU_AIOP:
		if (dpsparser->parsers->aiop_ctlu_initialized) {
			layout = &dpsparser->aiop_sp;
		}
		break;
	default:
		break;
	}
	
	return layout;
}

/******************************************************************************/
int dpsparser_get_default_profile(struct dpsparser *dpsparser, enum ctlu_type type, struct profile_info **pinfo)
{
	struct parser_layout *layout = dpsparser_get_layout(dpsparser, type);
	
	*pinfo = NULL;
	
	/* Not initialized/existing parser */
	if (!layout)
		return -1;
	/* No soft parser loaded on this parser or not defined profiles */
	if (!layout->sp_count || !layout->profile_count)
		return -1;
	
	/* Default profile info */
	struct profile_info *def_profile = &layout->profiles[DEFAULT_PROFILE_IDX];
	*pinfo = def_profile;
	
	return 0;
}

/******************************************************************************/
int dpsparser_get_profile_by_name(struct dpsparser *dpsparser, 
					enum ctlu_type type, uint8_t *sp_prof, struct profile_info **pinfo)
{
	struct parser_layout *layout = dpsparser_get_layout(dpsparser, type);
	int i;
	
	*pinfo = NULL;
	
	/* Not initialized/existing parser */
	if (!layout)
		return -1;
	/* No soft parser loaded on this parser or not defined profiles */
	if (!layout->sp_count || !layout->profile_count)
		return -1;

	struct profile_info *profile = NULL;

	if (sp_prof == NULL) {
		/* Return Default Profile for NULL */
		profile = &layout->profiles[DEFAULT_PROFILE_IDX];
	}
	else {
		if (strlen(sp_prof) == 0) {
			/* Return Default Profile for empty profile name */
			profile = &layout->profiles[DEFAULT_PROFILE_IDX];
		}
		else {
			for (i = 0; i < layout->profile_count; i++) {
				if (strcmp(sp_prof, layout->profiles[i].name) == 0) {
					profile = &layout->profiles[i];
					break;
				}
			}
		}
	}
	/* The requested SP Profile name does NOT exists registered on this parser */
	if (profile == NULL)
		return -ENODEV;
	
	*pinfo = profile;
	
	return 0;
}

/******************************************************************************/
int dpsparser_build_profile(struct dpsparser *dpsparser, enum ctlu_type type, uint8_t *sp_prof,
				    struct profile_info *pinfo)
{
	struct parser_layout *layout = dpsparser_get_layout(dpsparser, type);
	int err;
	
	/* Not initialized/existing parser */
	if (!layout)
		return 0;
	/* No soft parser loaded on this parser or not defined profiles */
	if (!layout->sp_count || !layout->profile_count)
		return 0;

	/* Get profile info */
	struct profile_info *profile = NULL;
	err = dpsparser_get_profile_by_name(dpsparser, type, sp_prof, &profile);
	if (err)
		return err;

	/* Return requested profile data: */
	*pinfo = *profile;
	
	return 0;
}
