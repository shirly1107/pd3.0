/*
 * Copyright 2013-2020 NXP
 */

#ifndef __DPSPARSER_CMD_H
#define __DPSPARSER_CMD_H

/* Default version for all dpsparser commands */
#define DPSPARSER_CMD_VER_BASE	CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)

/* add your new command version number here
 * Ex:
 * #define DPSPARSER_CMD_CREATE_VER_1				\
 *			MC_CMD_HDR_VERSION(DPSPARSER_CMD_VER_BASE + 1) or
 * #define DPSPARSER_CMD_CREATE_VER	 MC_CMD_HDR_VERSION(3)
 */

/* Command IDs */
#define DPSPARSER_CMD_CODE_CLOSE                               0x800
#define DPSPARSER_CMD_CODE_OPEN                                0x811
#define DPSPARSER_CMD_CODE_CREATE                              0x911
#define DPSPARSER_CMD_CODE_DESTROY                             0x900
#define DPSPARSER_CMD_CODE_GET_API_VERSION                     0xa11

#define DPSPARSER_CMD_CODE_ENABLE                              0x002
#define DPSPARSER_CMD_CODE_DISABLE                             0x003
#define DPSPARSER_CMD_CODE_GET_ATTR                            0x004
#define DPSPARSER_CMD_CODE_RESET                               0x005
#define DPSPARSER_CMD_CODE_IS_ENABLED                          0x006

#define DPSPARSER_CMD_CODE_SET_IRQ                             0x110
#define DPSPARSER_CMD_CODE_GET_IRQ                             0x111
#define DPSPARSER_CMD_CODE_SET_IRQ_ENABLE                      0x112
#define DPSPARSER_CMD_CODE_GET_IRQ_ENABLE                      0x113
#define DPSPARSER_CMD_CODE_SET_IRQ_MASK                        0x114
#define DPSPARSER_CMD_CODE_GET_IRQ_MASK                        0x115
#define DPSPARSER_CMD_CODE_GET_IRQ_STATUS                      0x116
#define DPSPARSER_CMD_CODE_CLEAR_IRQ_STATUS                    0x117

#define DPSPARSER_CMD_CODE_APPLY_SPB						   0x118

#endif /* __DPSPARSER_CMD_H */
