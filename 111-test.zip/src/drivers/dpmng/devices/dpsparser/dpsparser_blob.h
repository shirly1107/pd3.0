/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpsparser_blob.h

 @Description   DPSPARSER BLOB internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPSPARSER_BLOB_H
#define __DPSPARSER_BLOB_H

/******************************************************************************/
#include "fsl_types.h"

/** BLOB magic number */
#define BLOB_MAGIC_BE			0x53504243	/* SPBC */

/* BLOB version version */
#define BLOB_VER_MAJOR				1
#define BLOB_VER_MINOR				1

/******************************************************************************/
/** Mandatory section, only one must exist and it must be placed 1st in file.
 * This is a fixed size structure. */
#pragma pack(push, 1)

struct sp_file_header {
	/** MAGIC ID, used by MC to verify that a valid blob is loaded.
	 *
	 * Must be 0x43425053, or "SPBC" ASCII */
	uint32_t	magic;
	/** SP blob file version, split into 2B major and 2B minor.
	 * Minor version must be incremented for backward compatible extensions.
	 * Major version must be incremented for changes which are not backward
	 * compatible. */
	uint32_t	blob_ver;
	/** Parser HW block revision that is compatible with this file.
	 * May change with SoC. MC firmware must check compatibility with HW.
	 *
	 * Value : TBD */
	uint32_t	ip_rev;
	/** Blob length. Should be a multiple of 4 */
	uint32_t	length;
};

#pragma pack(pop)

/******************************************************************************/
/** Blob sections tags */
enum sp_section_tag {
	/**  Blob name */
	NAME_SECT		= 0x00,
	/**  Soft Parser byte-code */
	BYTE_CODE_SECT		= 0x01,
	/**  Soft Parser Profiles */
	SP_PROFILES_SECT	= 0x02,
	/**  Parameters array */
	SP_PARAMETERS_SECT	= 0x03
};

/******************************************************************************/
#pragma pack(push, 1)

struct sp_blob_section {
	/** Size of section, in bytes */
	uint32_t	size;
	/** Identifies the type of section */
	uint32_t	tag;
};

#pragma pack(pop)

/******************************************************************************/
/* Optional section, if present only one should exist. */
#pragma pack(push, 1)

struct sp_blob_name {
	/** Section info :
	 *	- Size includes : size, TAG, reserved, and name. Must be at
	 *	least 16B.
	 *	- TAG = 0 */
	struct	sp_blob_section	sect;
	/** Reserved */
	uint64_t		reserved;
	/** Name string, in ASCII, of variable size. This is used only for
	 * debug and logging. Name may end with one or more '\0', but this
	 * termination is not required. */
	uint8_t			*name;
};

#pragma pack(pop)

/******************************************************************************/
/* At least one such section should exist, multiple may be present. This is a
 * variable size structure. */
#pragma pack(push, 1)

struct sp_byte_code {
	/** Section info :
	 *	- Size includes : size, TAG, flags, offset and byte code.
	 *	Must be at least 16B.
	 *	- TAG = 1 */
	struct	sp_blob_section	sect;
	/** Controls on which parser this byte-code section is loaded to.
	 *  Following bits are defined (bit 0 = value 0x00000001):
	 *	- Bit 31: load to WRIOP INGRESS parser memory
	 *	- Bit 30: load to WRIOP EGRESS parser memory
	 *	- Bit 29: load to AIOP parser memory
	 *	- TBD */
	uint32_t		flags;
	/** Offset in parser memory to load this byte-code section to.
	 * Should be 4 bytes aligned. */
	uint32_t		offset;
	/* Soft Parser byte-code to be loaded at given offset */
	uint8_t			*byte_code;
};

#pragma pack(pop)

/******************************************************************************/
/* This is a fixed size (16B) structure, part of the sp-profile blob section.
 * Each cell unit in the figure below is 1 byte.  All numeric fields are LE. */
#pragma pack(push, 1)

struct sp_protocol_cfg {
	/* Name of this parse protocol. This is used to identify the protocol
	 * in firmware API for run-time operations. Must not be null. Must be
	 * padded with '\0' up to 8 bytes. Name must be unique to the blob. */
	uint8_t			sp_name[8];
	/* Reserved */
	uint8_t			reserved_1;
	/* Reserved */
	uint8_t			reserved_2;
	/* Entry point in the soft parser byte-code. This must fall within one
	 * of the byte-code sections. Soft parser will execute this byte-code
	 * if the profile is enabled and a selected base-protocol is identified
	 * in the frame. */
	uint16_t		seq_start;
	/* Identifies a base standard protocol as underlying for the custom
	 * protocol defined by this profile. For instance, a custom L4 protocol
	 * may use IPv4 or IPv6 as base protocol.
	 *
	 * Special cases (no underlying protocol HXS) :
	 *	- LNK_BEFORE_FIRST_HXS : Soft parser is executed before any
	 *	protocol (before ETH). */
	uint32_t base_proto;
};

#pragma pack(pop)

#define MAX_PROTOCOLS			64

/******************************************************************************/
/* At least one such section should exist, multiple may be present. This is a
 * variable size structure. */
#pragma pack(push, 1)

struct sp_profile_cfg {
	/** Section info :
	 *	- Size includes : size, TAG, reserved and a variable number of
	 *	profiles. Must be at least 16B.
	 *	- TAG = 2 */
	struct	sp_blob_section		sect;
	/** Reserved */
	uint64_t	reserved_1;
	
	uint8_t		profile_name[8];
	/* These flags control the default behavior of this profile. Implicitly
	 * all profiled are disabled after a blob is loaded and can be enabled
	 * though networking object API. Optionally profiles can be enabled
	 * automatically using these flags. This can be useful to force enable
	 * parsing of a custom protocol across the entire system.
	 *	- 0x80: enable on all WRIOP ingress (includes traffic through
	 *	physical ports, recycle ports),
	 *	- 0x40: enable on all WRIOP egress (includes traffic through
	 *	physical ports, recycle ports),
	 *	- 0x20: enable on AIOP ingress parsing profile (applicable to
	 *	AIOP parser accelerator calls from AIOP code),
	 *	- 0x10: enable on AIOP egress parsing profile (applicable to
	 *	AIOP parser accelerator calls from AIOP code) */
	uint8_t		enable_flags;
	uint8_t		proto_no;
	uint8_t		reserved_2[6];

	/* Soft Parser protocol configuration */
	struct	sp_protocol_cfg		protocol_cfg[MAX_PROTOCOLS];
};

#pragma pack(pop)

/******************************************************************************/
/* This is a fixed size (20B) structure, part of the sp-parameters blob
 * section. */
#pragma pack(push, 1)

struct sp_param_cfg {
	/* Size, in bytes of this array entry. Must be a multiple of 4. Must be
	 * at least 24. Note that entry-size may be different than
	 * 24 + param-size, if:
	 *	- there are padding bytes added to value, to make it a multiple
	 *	of 4B.  For example, if param-size = 1 and one byte of value is
	 *	provided, the entire param-cfg structure is 32B.
	 *	- value is missing or incomplete. This is allowed, missing bytes
	 *	are assumed 0. For example, if no value is supplied, the size of
	 *	this structure is 24B. */
	uint16_t	entry_size;
	/* Offset of this parameter in the parameter space of soft parser
	 * (examination array in the hardware documentation). Supported values
	 * are 0 to 63. */
	uint16_t	param_offset;
	/* Size of this parameter. Parameters cannot overlap. Supported values
	 * are 0 to 63. */
	uint16_t	param_size;
	/* Parameter flags. Following bits are defined (bit 0 = value 0x01):
	 *	7 - read only, cannot be changed at run-time. */
	uint8_t		flags;
	/* Reserved */
	uint8_t		reserved;
	/* Identifies the profile this parameter applies to. It is used to
	 * identify the parameter in run-time APIs. This field must match the
	 * name field on one of the profiles configuration structures. */
	uint8_t		profile_name[8];
	/* Identifies the protocol this parameter applies to. It is used to
	 * identify the parameter in run-time APIs. This field must match the
	 * name field on one of the profiles configuration structures. */
	uint8_t		proto_name[8];
	/* Name of this parameter, used to identify the parameter in firmware
	 * API for run-time operations. Must be unique for the given protocol.
	 * Name may end with one or multiple '\0'. */
	uint8_t		param_name[8];
	/* Value of the parameter, padded to 4B alignment.  Padding bytes
	 * should be 0. This field is optional, if missing the default parameter
	 * value is 0. Note that this field is provided as a byte array to the
	 * soft parser, so its endianness must match the one expected by soft
	 * parser. */
	uint8_t		value[64];
};

#pragma pack(pop)

/******************************************************************************/
/* Optional section, multiple may be present. This is a variable size structure.
 * Section must be placed after sp-protocols section(s). */
#pragma pack(push, 1)

struct sp_parameters {
	/** Section info :
	 *	- Size includes : size, TAG, reserved and a variable number of
	 *	parameters. Must be at least 16B.
	 *	- TAG = 3 */
	struct	sp_blob_section		sect;
	/** Reserved  */
	uint64_t			reserved;
	/* Soft Parser parameter configuration */
	struct	sp_param_cfg		*param_cfg;
};

#pragma pack(pop)

/******************************************************************************/
/* Backward compatibility structures */

/* Backward compatibility Blob: v1 */

#pragma pack(push, 1)

struct sp_protocol_cfg_v1 {
	/* Name of this parse protocol. This is used to identify the protocol
	 * in firmware API for run-time operations. Must not be null. Must be
	 * padded with '\0' up to 8 bytes. Name must be unique to the blob. */
	uint8_t			sp_name[8];
	/* These flags control the default behavior of this profile. Implicitly
	 * all profiled are disabled after a blob is loaded and can be enabled
	 * though networking object API. Optionally profiles can be enabled
	 * automatically using these flags. This can be useful to force enable
	 * parsing of a custom protocol across the entire system.
	 *	- 0x80: enable on all WRIOP ingress (includes traffic through
	 *	physical ports, recycle ports),
	 *	- 0x40: enable on all WRIOP egress (includes traffic through
	 *	physical ports, recycle ports),
	 *	- 0x20: enable on AIOP ingress parsing profile (applicable to
	 *	AIOP parser accelerator calls from AIOP code),
	 *	- 0x10: enable on AIOP egress parsing profile (applicable to
	 *	AIOP parser accelerator calls from AIOP code) */
	uint8_t			flags;
	/* Reserved */
	uint8_t			reserved;
	/* Entry point in the soft parser byte-code. This must fall within one
	 * of the byte-code sections. Soft parser will execute this byte-code
	 * if the profile is enabled and a selected base-protocol is identified
	 * in the frame. */
	uint16_t		seq_start;
	/* Identifies a base standard protocol as underlying for the custom
	 * protocol defined by this profile. For instance, a custom L4 protocol
	 * may use IPv4 or IPv6 as base protocol.
	 *
	 * Special cases (no underlying protocol HXS) :
	 *	- LNK_BEFORE_FIRST_HXS : Soft parser is executed before any
	 *	protocol (before ETH). */
	uint32_t base_proto;
};

#pragma pack(pop)

#pragma pack(push, 1)

struct sp_protocols_v1 {
	/** Section info :
	 *	- Size includes : size, TAG, reserved and a variable number of
	 *	profiles. Must be at least 16B.
	 *	- TAG = 2 */
	struct	sp_blob_section		sect;
	/** Reserved */
	uint64_t			reserved;
	/* Soft Parser protocol configuration */
	struct	sp_protocol_cfg_v1		*protocol_cfg;
};

#pragma pack(pop)

#pragma pack(push, 1)

struct sp_param_cfg_v1 {
	/* Size, in bytes of this array entry. Must be a multiple of 4. Must be
	 * at least 24. Note that entry-size may be different than
	 * 24 + param-size, if:
	 *	- there are padding bytes added to value, to make it a multiple
	 *	of 4B.  For example, if param-size = 1 and one byte of value is
	 *	provided, the entire param-cfg structure is 32B.
	 *	- value is missing or incomplete. This is allowed, missing bytes
	 *	are assumed 0. For example, if no value is supplied, the size of
	 *	this structure is 24B. */
	uint16_t	entry_size;
	/* Offset of this parameter in the parameter space of soft parser
	 * (examination array in the hardware documentation). Supported values
	 * are 0 to 63. */
	uint16_t	param_offset;
	/* Size of this parameter. Parameters cannot overlap. Supported values
	 * are 0 to 63. */
	uint16_t	param_size;
	/* Parameter flags. Following bits are defined (bit 0 = value 0x01):
	 *	7 - read only, cannot be changed at run-time. */
	uint8_t		flags;
	/* Reserved */
	uint8_t		reserved;
	/* Identifies the protocol this parameter applies to. It is used to
	 * identify the parameter in run-time APIs. This field must match the
	 * name field on one of the profiles configuration structures. */
	uint8_t		proto_name[8];
	/* Name of this parameter, used to identify the parameter in firmware
	 * API for run-time operations. Must be unique for the given protocol.
	 * Name may end with one or multiple '\0'. */
	uint8_t		param_name[8];
	/* Value of the parameter, padded to 4B alignment.  Padding bytes
	 * should be 0. This field is optional, if missing the default parameter
	 * value is 0. Note that this field is provided as a byte array to the
	 * soft parser, so its endianness must match the one expected by soft
	 * parser. */
	uint8_t		value[64];
};

#pragma pack(pop)

#pragma pack(push, 1)

struct sp_parameters_v1 {
	/** Section info :
	 *	- Size includes : size, TAG, reserved and a variable number of
	 *	parameters. Must be at least 16B.
	 *	- TAG = 3 */
	struct	sp_blob_section		sect;
	/** Reserved  */
	uint64_t			reserved;
	/* Soft Parser parameter configuration */
	struct	sp_param_cfg_v1		*param_cfg;
};

#pragma pack(pop)

/******************************************************************************/


/******************************************************************************/
/* Soft Parsers BLOB loading address. Must be in memory space accessible to
 * the MC cores.
 * Should be written by an external tool (uBoot, a GPP application, ...) */
extern void *sp_blob_address;

/******************************************************************************/
struct dpsparser;

/******************************************************************************/
void dpsparser_set_blob_address(void *blob_addr);
int dpsparser_blob_parse(struct dpsparser *dpsparser);
void dpsparser_blob_parse_end(struct dpsparser *dpsparser);

#endif	/* __DPSPARSER_BLOB_H */
