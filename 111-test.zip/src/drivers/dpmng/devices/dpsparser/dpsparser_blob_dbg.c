/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpsparser_blob_check.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_platform.h"
#include "fsl_resman.h"

#include "fsl_dpsparser_mc.h"
#include "fsl_dpsparser_cmd.h"
#include "dpsparser.h"
#include "dpsparser_blob.h"
#include "dpsparser_blob_dbg.h"

#ifdef SOFT_PARSER_BLOB_DUMP
/******************************************************************************/
int dpsparser_dump_blob_bytes(uint32_t bytes)
{
	uint8_t		*raddr;
	uint32_t	i;

	if (!sp_blob_address)
		return -1;
	raddr = (uint8_t *)sp_blob_address;
	fsl_print("BLOB at 0x%08x\n", (uint32_t)raddr);
	fsl_print("\t %04x : ", 0);
	for (i = 0; i < bytes; i++) {
		fsl_print("%02x ", *raddr++);
		if (!((i + 1) % 16))
			fsl_print("\n\t %04x : ", i + 1);
	}
	if ((i + 1) % 16)
		fsl_print("\n");
	return 0;
}

/******************************************************************************/
void dpsparser_blob_dump_file_header_sect(struct sp_file_header *fhead)
{
	uint8_t		*pch;

	pch = (uint8_t *)&fhead->magic;
	fsl_print("BLOB 'file-header' section\n");
	fsl_print("\t magic    = 0x%08x (%c%c%c%c)\n",
		  fhead->magic, *pch, *(pch + 1), *(pch + 2), *(pch + 3));
	fsl_print("\t blob_ver = 0x%08x (MAJ = %d MIN = %d)\n", fhead->blob_ver,
		  (uint16_t)(fhead->blob_ver >> 16), (uint16_t)fhead->blob_ver);
	fsl_print("\t ip_rev   = 0x%08x (MAJ = %d MIN = %d)\n", fhead->ip_rev,
		  (uint16_t)(fhead->ip_rev >> 16), (uint16_t)fhead->ip_rev);
	fsl_print("\t length   = %d\n", fhead->length);
}

/******************************************************************************/
void dpsparser_blob_dump_name_sect(struct sp_blob_name *bname)
{
	int		i, name_len;
	uint8_t		*pch;

	name_len = (int)bname->sect.size - sizeof(struct sp_blob_section) -
						sizeof(uint64_t);
	fsl_print("BLOB 'blob-name' section\n");
	fsl_print("\t size     = %d\n", bname->sect.size);
	fsl_print("\t tag      = %d\n", bname->sect.tag);
	fsl_print("\t reserved = 0x%x-%08x\n",
		  (uint32_t)(bname->reserved >> 32), (uint32_t)bname->reserved);
	fsl_print("\t name     = ");
	if (!name_len) {
		fsl_print("'null'\n");
	} else {
		pch = bname->name;
		i = 0;
		do {
			fsl_print("%c", *pch++);
			i++;
			if (!((i + 1) % 16))
				fsl_print("\n\t            ");
		} while (i < name_len && *pch != 0);
		fsl_print("\n");
	}
}

/******************************************************************************/
void dpsparser_blob_dump_bytecode_sect(struct sp_byte_code *bc)
{
	int		i, sz;
	uint8_t		*pch;

	fsl_print("BLOB 'bytecode' section\n");
	fsl_print("\t size      = %d\n", bc->sect.size);
	fsl_print("\t tag       = %d\n", bc->sect.tag);
	fsl_print("\t flags     = 0x%08x\n", bc->flags);
	fsl_print("\t byte_code = 0x%08x\n", (uint32_t)bc->byte_code);
	pch = bc->byte_code;
	sz = (int)bc->sect.size - sizeof(struct sp_blob_section) -
						2 * sizeof(uint32_t);
	fsl_print("\t    ");
	for (i = 0; i < sz; i++) {
		fsl_print("%02x ", *pch++);
		if (!((i + 1) % 16))
			fsl_print("\n\t    ");
	}
	fsl_print("\n");
}

/******************************************************************************/
void dpsparser_blob_dump_sp_profile_sect(struct sp_profile_cfg *pr)
{
	int	pr_count, i;
	uint8_t		*pch;
	
	pr_count = ((int)pr->sect.size -
		    (sizeof(struct sp_blob_section) + 24)) /
		    sizeof(struct sp_protocol_cfg);
	fsl_print("BLOB 'sp-profiles' section (%d 'protocol-cfg')\n",
		  pr_count);
	fsl_print("\t size     = %d\n", pr->sect.size);
	fsl_print("\t tag      = %d\n", pr->sect.tag);
	fsl_print("\t reserved = 0x%x-%08x\n", (uint32_t)(pr->reserved_1 >> 32),
		  (uint32_t)pr->reserved_1);
	fsl_print("\t profile_name   = ");
	pch = &pr->profile_name[0];
	for (i = 0; i < 8 && *pch; i++)
		fsl_print("%c", *pch++);
	fsl_print("\n");
	fsl_print("\t flags        = 0x%02x\n", pr->enable_flags);
	fsl_print("\t protocol_no  = 0x%02x\n", pr->proto_no);
	fsl_print("\t reserved_2   = 0x%02x\n", pr->reserved_2);
}

/******************************************************************************/
/* Backward compatibility Blob: v1 */
void dpsparser_blob_dump_sp_protocols_sect_v1(struct sp_protocols_v1 *pr)
{
	int	pr_count;

	pr_count = ((int)pr->sect.size -
		    (sizeof(struct sp_blob_section) + sizeof(uint64_t))) /
		    sizeof(struct sp_protocol_cfg_v1);
	fsl_print("BLOB 'sp-protocols' section (%d 'protocol-cfg')\n",
		  pr_count);
	fsl_print("\t size     = %d\n", pr->sect.size);
	fsl_print("\t tag      = %d\n", pr->sect.tag);
	fsl_print("\t reserved = 0x%x-%08x\n", (uint32_t)(pr->reserved >> 32),
		  (uint32_t)pr->reserved);
}

void dpsparser_blob_dump_protocol_cfg_v1(struct sp_protocol_cfg_v1 *pr)
{
	int		i;
	uint8_t		*pch;

	fsl_print("BLOB 'protocol-cfg'\n");
	fsl_print("\t sp_name   = ");
	pch = &pr->sp_name[0];
	for (i = 0; i < 8 && *pch; i++)
		fsl_print("%c", *pch++);
	fsl_print("\n");
	fsl_print("\t flags      = 0x%02x\n", pr->flags);
	fsl_print("\t reserved   = 0x%02x\n", pr->reserved);
	fsl_print("\t seq_start  = 0x%03x\n", pr->seq_start);
	fsl_print("\t base_proto = 0x%x\n", (uint32_t)pr->base_proto);
}

void dpsparser_blob_dump_sp_params_sect_v1(struct sp_parameters_v1 *params)
{
	fsl_print("BLOB 'sp-parameters' section\n");
	fsl_print("\t size     = %d\n", params->sect.size);
	fsl_print("\t tag      = %d\n", params->sect.tag);
	fsl_print("\t reserved = 0x%x-%08x\n",
		  (uint32_t)(params->reserved >> 32),
		  (uint32_t)params->reserved);
}

void dpsparser_blob_dump_param_cfg_v1(struct sp_param_cfg_v1 *param)
{
	int		i, diff;
	uint8_t		*pch;

	fsl_print("BLOB 'param-cfg'\n");
	fsl_print("\t entry_size   = %d\n", param->entry_size);
	fsl_print("\t param_offset = %d\n", param->param_offset);
	fsl_print("\t param_size   = %d\n", param->param_size);
	fsl_print("\t flags        = 0x%x\n", param->flags);
	fsl_print("\t reserved     = 0x%x\n", param->reserved);
	fsl_print("\t proto_name   = ");
	pch = &param->proto_name[0];
	for (i = 0; i < 8 && *pch; i++)
		fsl_print("%c", *pch++);
	fsl_print("\n");
	fsl_print("\t param_name   = ");
	pch = &param->param_name[0];
	for (i = 0; i < 8 && *pch; i++)
		fsl_print("%c", *pch++);
	fsl_print("\n");
	if (!param->param_size) {
		fsl_print("\t value        = 0 (default)\n");
		return;
	}
	/* value (variable size) */
	diff = (int)param->entry_size -
			(int)offsetof(struct sp_param_cfg, value);
	fsl_print("\t value        = ");
	for (i = 0; i < diff; i++) {
		fsl_print("%02x ", param->value[i]);
		if (!((i + 1) % 8))
			fsl_print("\n\t                ");
	}
	fsl_print("\n");
}


/******************************************************************************/
void dpsparser_blob_dump_protocol_cfg(struct sp_protocol_cfg *pr)
{
	int		i;
	uint8_t		*pch;

	fsl_print("BLOB 'protocol-cfg'\n");
	fsl_print("\t sp_name   = ");
	pch = &pr->sp_name[0];
	for (i = 0; i < 8 && *pch; i++)
		fsl_print("%c", *pch++);
	fsl_print("\n");
	fsl_print("\t reserved_1   = 0x%02x\n", pr->reserved_1);
	fsl_print("\t reserved_2   = 0x%02x\n", pr->reserved_2);
	fsl_print("\t seq_start  = 0x%03x\n", pr->seq_start);
	fsl_print("\t base_proto = 0x%x\n", (uint32_t)pr->base_proto);
}

/******************************************************************************/
void dpsparser_blob_dump_sp_params_sect(struct sp_parameters *params)
{
	fsl_print("BLOB 'sp-parameters' section\n");
	fsl_print("\t size     = %d\n", params->sect.size);
	fsl_print("\t tag      = %d\n", params->sect.tag);
	fsl_print("\t reserved = 0x%x-%08x\n",
		  (uint32_t)(params->reserved >> 32),
		  (uint32_t)params->reserved);
}

/******************************************************************************/
void dpsparser_blob_dump_param_cfg(struct sp_param_cfg *param)
{
	int		i, diff;
	uint8_t		*pch;

	fsl_print("BLOB 'param-cfg'\n");
	fsl_print("\t entry_size   = %d\n", param->entry_size);
	fsl_print("\t param_offset = %d\n", param->param_offset);
	fsl_print("\t param_size   = %d\n", param->param_size);
	fsl_print("\t flags        = 0x%x\n", param->flags);
	fsl_print("\t reserved     = 0x%x\n", param->reserved);
	fsl_print("\t profile_name   = ");
	pch = &param->profile_name[0];
	for (i = 0; i < 8 && *pch; i++)
		fsl_print("%c", *pch++);
	fsl_print("\n");
	fsl_print("\t proto_name   = ");
	pch = &param->proto_name[0];
	for (i = 0; i < 8 && *pch; i++)
		fsl_print("%c", *pch++);
	fsl_print("\n");
	fsl_print("\t param_name   = ");
	pch = &param->param_name[0];
	for (i = 0; i < 8 && *pch; i++)
		fsl_print("%c", *pch++);
	fsl_print("\n");
	if (!param->param_size) {
		fsl_print("\t value        = 0 (default)\n");
		return;
	}
	/* value (variable size) */
	diff = (int)param->entry_size -
			(int)offsetof(struct sp_param_cfg, value);
	fsl_print("\t value        = ");
	for (i = 0; i < diff; i++) {
		fsl_print("%02x ", param->value[i]);
		if (!((i + 1) % 8))
			fsl_print("\n\t                ");
	}
	fsl_print("\n");
}

#endif	/* SOFT_PARSER_BLOB_DUMP */

/******************************************************************************/
#ifdef SOFT_PARSER_BLOB_CHECK

uint8_t			*sp_blob_waddr;
static uint32_t		*blob_length_ptr;
static uint32_t		blob_length;

/*******************************************************************************
 * CUSTOM_HEADER_AFTER_ETHERNET soft parser. This SP has 2 parameters and it
 * calls a "library" routine that computes the "running sum"
 *	- EterType filed	: offset = 0, size = 2 value = 0xEE00
 *	- Header length		: offset = 2, size = 1 value = 46
 * */
static uint8_t sp_after_eth[] = {
	0xb7, 0x9e, 0x10, 0x13, 0x00, 0x79, 0x07, 0xfe, 0x33, 0x21,
	0x00, 0x81, 0x00, 0x02, 0x10, 0x20, 0x00, 0x52, 0x00, 0x10,
	0x00, 0x80, 0xbf, 0x9f, 0x29, 0x23, 0x33, 0x21, 0x28, 0x41,
	0x10, 0x20, 0x29, 0x02, 0x00, 0x4c, 0x28, 0x65, 0x03, 0xe0,
	0x18, 0x00, 0x87, 0x3c, 0x00, 0x44, 0x00, 0x00
};

/* Loaded at the minimum PC */
#define AFTER_ETH_ADDR	0x40

/*******************************************************************************
 * CUSTOM_HEADER_BEFORE_ETHERNET soft parser. This SP has one parameter and it
 * calls a "library" routine that computes the "running sum".
 *	- Header length		: offset = 32, size = 1 value = 32
 * */
uint8_t sp_before_eth[] = {
	0x00, 0x04, 0x29, 0x42, 0x03, 0xe0, 0x12, 0x00, 0x29, 0x02,
	0x18, 0x00, 0x87, 0x3c, 0x00, 0x02, 0x18, 0x00, 0x00, 0x00
};

/* Loaded just after the 'sp_after_eth' soft parser */
#define BEFORE_ETH_ADDR		0x70
#define BEFORE_ETH_LADDR	0x40

/******************************************************************************/
/* The soft parser library routines are loaded by MC software in the early
 * initialization phase of a parser.
 * The SPs in this library must occupy contiguous space into the internal memory
 * of the parser. Only one SP driver entry is reserved to keep information
 * about all SPs in the library.
 *
 * The SPs in this library may be :
 *	- routine SPs. Sequences of instructions performing certain operation
 *	(by example compute the Running Sum). The routines may be called by
 *	user defined SPs and ends by executing a RETURN instruction.
 *	- soft HXSs. May be SPs performing a certain operation on the packet
 *	(by example :skip a custom header, skip a standard header).
 *
 * Library routines are loaded at the end of the Parser instructions memory.
 *	Loading address = (0x7FC - sizeof(sp_aiop_lib_parsers)) / 2;
 * Size of this array must be a multiple of 4.
 *
 * The sp_wriop_lib_parsers array keeps the following soft parsers routines :
 * 1. routine computing the "Running Sum".
 * Attributes :
 *	- Routine
 *	- Loading address (PC) : 0x73c
 *	- Size : 388 bytes
 *	- Parameters : None
 */
static uint8_t sp_running_sum[] __attribute__((aligned(4))) = {
	/* This is a routine computes the "Running Sum" on a header of a given
	 * length. The length of the header must be set by the calling soft
	 * parser into the GPRV0 register of the Parse Array.
	 * The routine reserves, for internal computations, the GPRV1 and GPRV2
	 * registers. The working registers are not preserved.
	 * The "Running Sum" value in the Parse Array is updated with the
	 * computed value. The "Window Offset" register is set to point at the
	 * beginning of the next header. Calling soft parser may advance to the
	 * next header just after the routine returns.
	 *
	 * Byte-code size	: 388 bytes (0x0184).
	 * Loading Address (PC)	: (0xffc - 0x184) / 2 = 0x73c;
	 */
	0x06, 0x00, 0x30, 0x12, 0x01, 0x86, 0x29, 0x06, 0x01, 0x06,
	0x30, 0x13, 0x00, 0x4b, 0x29, 0x0a, 0x30, 0x32, 0x00, 0x05,
	0x00, 0x78, 0x40, 0x18, 0x00, 0x52, 0x00, 0x01, 0x29, 0x06,
	0x33, 0x72, 0x00, 0xdc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
	0xff, 0xff, 0x9f, 0xff, 0x00, 0x06, 0xbf, 0xff, 0x00, 0x06,
	0x00, 0xdc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
	0x29, 0x6e, 0x07, 0x10, 0x18, 0x00, 0x44, 0x18, 0x30, 0x52,
	0x02, 0x1f, 0x00, 0x08, 0x00, 0x7b, 0x40, 0x13, 0x00, 0x4a,
	0x29, 0x0a, 0x33, 0x72, 0x00, 0xdc, 0xff, 0xff, 0xff, 0xff,
	0xff, 0xff, 0xff, 0xff, 0x9f, 0xff, 0x00, 0x06, 0x00, 0xdc,
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x29, 0x6e,
	0x07, 0x08, 0x30, 0x52, 0x02, 0x7f, 0x00, 0x00, 0x00, 0x01,
	0x00, 0x02, 0x00, 0x03, 0x00, 0x30, 0x40, 0x0f, 0x40, 0x10,
	0x40, 0x21, 0x40, 0x31, 0x02, 0x7f, 0x00, 0x04, 0x00, 0x05,
	0x00, 0x06, 0x00, 0x07, 0x00, 0x30, 0x40, 0x38, 0x40, 0x48,
	0x40, 0x59, 0x40, 0x69, 0x00, 0x07, 0x33, 0x72, 0x00, 0xdc,
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x83, 0x8f,
	0x01, 0x0f, 0x00, 0x06, 0x00, 0xdc, 0xff, 0xff, 0xff, 0xff,
	0xff, 0xff, 0xff, 0xff, 0x29, 0x6e, 0x07, 0x01, 0x00, 0x07,
	0x33, 0x72, 0x00, 0xdc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
	0xff, 0xff, 0x87, 0x9f, 0x00, 0x06, 0x00, 0xdc, 0xff, 0xff,
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x29, 0x6e, 0x07, 0x02,
	0x00, 0x07, 0x33, 0x72, 0x00, 0xdc, 0xff, 0xff, 0xff, 0xff,
	0xff, 0xff, 0xff, 0xff, 0x8b, 0xaf, 0x01, 0x0f, 0x00, 0x06,
	0x00, 0xdc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
	0x29, 0x6e, 0x07, 0x03, 0x00, 0x07, 0x33, 0x72, 0x00, 0xdc,
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x8f, 0xbf,
	0x00, 0x06, 0x00, 0xdc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
	0xff, 0xff, 0x29, 0x6e, 0x07, 0x04, 0x00, 0x07, 0x33, 0x72,
	0x00, 0xdc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
	0x93, 0xcf, 0x01, 0x0f, 0x00, 0x06, 0x00, 0xdc, 0xff, 0xff,
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x29, 0x6e, 0x07, 0x05,
	0x00, 0x07, 0x33, 0x72, 0x00, 0xdc, 0xff, 0xff, 0xff, 0xff,
	0xff, 0xff, 0xff, 0xff, 0x97, 0xdf, 0x00, 0x06, 0x00, 0xdc,
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x29, 0x6e,
	0x07, 0x06, 0x00, 0x07, 0x33, 0x72, 0x00, 0xdc, 0xff, 0xff,
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x9b, 0xef, 0x01, 0x0f,
	0x00, 0x06, 0x00, 0xdc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
	0xff, 0xff, 0x29, 0x6e, 0x07, 0x07, 0x00, 0x07
};

/* Loaded at the end of memory */
#define RUNNING_SUM_ADDR		(2 * 0x73c)

/******************************************************************************/
static int dpsparser_blob_write_file_header(struct dpsparser *dpsparser)
{
	uint32_t		val32;

	if (!sp_blob_waddr)
		return -ENODEV;
	/* MAGIC (LE) */
	STORE_CPU_TO_LE32_WT(BLOB_MAGIC_BE, (uint32_t *)sp_blob_waddr);
	sp_blob_waddr += sizeof(uint32_t);
	/* BLOB_VER (LE) */
	val32 = (BLOB_VER_MAJOR << 16) | BLOB_VER_MINOR;
	STORE_CPU_TO_LE32_WT(val32, (uint32_t *)sp_blob_waddr);
	sp_blob_waddr += sizeof(uint32_t);
	/* IP_REV (LE) */
	val32 = ((uint32_t)dpsparser->ip_rev_major << 16) |
		 (uint32_t)dpsparser->ip_rev_minor;
	STORE_CPU_TO_LE32_WT(val32, (uint32_t *)sp_blob_waddr);
	sp_blob_waddr += sizeof(uint32_t);
	/* Length (4) - Blob length. Should be a multiple of 4.
	 * Now the length is unknown. It is updated at the end of BLOB
	 * writes. */
	STORE_CPU_TO_LE32_WT(sizeof(struct sp_file_header),
			     (uint32_t *)sp_blob_waddr);
	blob_length_ptr = (uint32_t *)sp_blob_waddr;
	sp_blob_waddr += sizeof(uint32_t);
	blob_length = sizeof(struct sp_file_header);
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_write_section(struct sp_blob_section *sect)
{
	if (!sp_blob_waddr)
		return -ENODEV;
	/* Size (LE) */
	STORE_CPU_TO_LE32_WT(sect->size, (uint32_t *)sp_blob_waddr);
	sp_blob_waddr += sizeof(uint32_t);
	/* TAG (LE) */
	STORE_CPU_TO_LE32_WT(sect->tag, (uint32_t *)sp_blob_waddr);
	sp_blob_waddr += sizeof(uint32_t);
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_write_name_sect(const char *name)
{
	struct sp_blob_section	sect;
	int			i, len, err, pad_len;
	char			*pch;

	if (!sp_blob_waddr)
		return -ENODEV;
	len = (int)strlen(name);
	if (len % 4) {
		pr_warn("BLOB : \"%s\" name length is not a 4 multiple\n",
			name);
		pad_len = 4 * (len / 4 + 1) - len;
		pr_warn("BLOB : Padded with %d NULLs\n", pad_len);
	} else {
		pad_len = 0;
	}
	/* Size + TAG */
	sect.size = sizeof(struct sp_blob_section) +	/* Size + TAG */
			sizeof(uint64_t) +		/* Reserved (8) */
			len + pad_len;			/* name length */
	sect.tag = (uint32_t)NAME_SECT;
	err = dpsparser_blob_write_section(&sect);
	if (err)
		return err;
	/* Reserved (8) */
	sp_blob_waddr += 8;
	/* Name. At most 16 characters. */
	pch = (char *)name;
	for (i = 0; i < len; i++)
		*sp_blob_waddr++ = (uint8_t)*pch++;
	for (i = 0; i < pad_len; i++)
		*sp_blob_waddr++ = 0;
	blob_length += sect.size;
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_write_bc_sect(const uint8_t *bc, uint16_t bc_sz,
					uint32_t offset, uint32_t flags)
{
	struct sp_blob_section	sect;
	int			err;

	if (!sp_blob_waddr)
		return -ENODEV;
	if (bc_sz % 4) {
		pr_err("BLOB : Byte-code size %d is not a 4 multiple\n", bc_sz);
		return -EINVAL;
	}
	if (!bc_sz) {
		pr_err("BLOB : Byte-code size can't be zero\n");
		return -EINVAL;
	}
	if (offset % 4) {
		pr_err("BLOB : Offset %d is not a 4 multiple\n", offset);
		return -EINVAL;
	}
	if (offset < 0x40) {
		pr_err("BLOB : Offset %d can't be less than 0x40\n", offset);
		return -EINVAL;
	}
	if (offset + bc_sz >= 0xffe) {
		pr_err("BLOB : Byte-code can't overwrite the 0xFFE address\n");
		return -EINVAL;
	}
	if (!flags) {
		pr_err("BLOB : No hardware parser selected as target\n");
		return -EINVAL;
	}
	/* Size + TAG */
	sect.size = sizeof(struct sp_blob_section) +	/* Size + TAG */
			sizeof(uint32_t) +		/* flags */
			sizeof(uint32_t) +		/* offset */
			bc_sz;				/* byte-code size */
	sect.tag = (uint32_t)BYTE_CODE_SECT;
	err = dpsparser_blob_write_section(&sect);
	if (err)
		return err;
	/* Flags (LE) */
	STORE_CPU_TO_LE32_WT(flags, (uint32_t *)sp_blob_waddr);
	sp_blob_waddr += sizeof(uint32_t);
	/* Offset (LE) */
	STORE_CPU_TO_LE32_WT(offset, (uint32_t *)sp_blob_waddr);
	sp_blob_waddr += sizeof(uint32_t);
	/* Byte-code. */
	memcpy(sp_blob_waddr, bc, bc_sz);
	sp_blob_waddr += bc_sz;
	blob_length += sect.size;
	return 0;
}

/******************************************************************************/
static int
dpsparser_blob_write_sp_protocols_sect(struct sp_protocol_cfg *proto,
				       uint16_t num_proto)
{
	struct sp_blob_section	sect;
	struct sp_protocol_cfg	*pr;
	int			i, err;

	if (!sp_blob_waddr)
		return -ENODEV;
	/* Size + TAG */
	sect.size = sizeof(struct sp_blob_section) +	/* Size + TAG */
		sizeof(uint64_t) +			/* Reserved (8) */
		num_proto * sizeof(struct sp_protocol_cfg); /* Protocols size */
	sect.tag = (uint32_t)SP_PROTOCOLS_SECT;
	err = dpsparser_blob_write_section(&sect);
	if (err)
		return err;
	/* Reserved (8) */
	sp_blob_waddr += 8;
	if (!num_proto)
		return 0;
	/* Protocols */
	pr = proto;
	for (i = 0; i < num_proto; i++, pr++) {
		/* sp_name (8) */
		memcpy(sp_blob_waddr, pr->sp_name, 8);
		sp_blob_waddr += 8;
		/* flags (1) */
		*sp_blob_waddr++ = pr->flags;
		/* Reserved (1) */
		sp_blob_waddr++;
		/* seq-start (2) */
		STORE_CPU_TO_LE16_WT(pr->seq_start, (uint16_t *)sp_blob_waddr);
		sp_blob_waddr += sizeof(uint16_t);
		/* base-proto (4) */
		switch (pr->base_proto) {
		case LNK_ETH_HXS:
		case LNK_LLC_SNAP_HXS:
		case LNK_VLAN_HXS:
		case LNK_PPPOE_PPP_HXS:
		case LNK_MPLS_HXS:
		case LNK_ARP_HXS:
		case LNK_IP_HXS:
		case LNK_IPV4_HXS:
		case LNK_IPV6_HXS:
		case LNK_GRE_HXS:
		case LNK_MINENCAP_HXS:
		case LNK_OTHER_L3_SHELL_HXS:
		case LNK_TCP_HXS:
		case LNK_UDP_HXS:
		case LNK_IPSEC_HXS:
		case LNK_SCTP_HXS:
		case LNK_DCCP_HXS:
		case LNK_OTHER_L4_SHELL_HXS:
		case LNK_GTP_HXS:
		case LNK_ESP_HXS:
		case LNK_VXLAN_HXS:
		case LNK_L5_SHELL_HXS:
		case LNK_FINAL_SHELL_HXS:
		case LNK_BEFORE_FIRST_HXS:
			break;
		default:
			pr_err("BLOB : Invalid base protocol %d\n",
			       (uint32_t)pr->base_proto);
			return -EINVAL;
		}
		STORE_CPU_TO_LE32_WT((uint32_t)pr->base_proto,
				     (uint32_t *)sp_blob_waddr);
		sp_blob_waddr += sizeof(uint32_t);
	}
	blob_length += sect.size;
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_write_sp_parameters_sect(struct sp_param_cfg *params,
						   uint16_t num_params)
{
	struct sp_blob_section	sect;
	struct sp_param_cfg	*param;
	uint32_t		param_size;
	int			i, j, err, diff;

	if (!sp_blob_waddr)
		return -ENODEV;
	/* Compute parameters size */
	param = params;
	param_size = 0;
	for (i = 0; i < num_params; i++, param++)
		param_size += param->entry_size;
	/* Size + TAG */
	sect.size = sizeof(struct sp_blob_section) +	/* Size + TAG */
		sizeof(uint64_t) +			/* reserved (8) */
		param_size;				/* Parameters size */
	sect.tag = (uint32_t)SP_PARAMETERS_SECT;
	err = dpsparser_blob_write_section(&sect);
	if (err)
		return err;
	/* Reserved (8) */
	sp_blob_waddr += sizeof(uint64_t);
	if (!params)
		return 0;
	/* Parameters */
	param = params;
	for (i = 0; i < num_params; i++, param++) {
		/* entry_size (2) */
		STORE_CPU_TO_LE16_WT(param->entry_size,
				     (uint16_t *)sp_blob_waddr);
		sp_blob_waddr += sizeof(uint16_t);
		/* param_offset (2) */
		STORE_CPU_TO_LE16_WT(param->param_offset,
				     (uint16_t *)sp_blob_waddr);
		sp_blob_waddr += sizeof(uint16_t);
		/* param_size (2) */
		STORE_CPU_TO_LE16_WT(param->param_size,
				     (uint16_t *)sp_blob_waddr);
		sp_blob_waddr += sizeof(uint16_t);
		/* flags (1) */
		*sp_blob_waddr++ = param->flags;
		/* reserved (1) */
		sp_blob_waddr++;
		/* proto_name (8) */
		memcpy(sp_blob_waddr, param->proto_name, 8);
		sp_blob_waddr += 8;
		/* param_name (8) */
		memcpy(sp_blob_waddr, param->param_name, 8);
		sp_blob_waddr += 8;
		if (!param->param_size)
			continue;
		diff = (int)param->entry_size -
				(int)offsetof(struct sp_param_cfg, value);
		if (diff <= 0) {
			pr_err("Invalid parameter configuration\n");
			return -EINVAL;
		}
		if (diff % 4) {
			pr_err("Not aligned value\n");
			return -EINVAL;
		}
		/* value (variable size) */
		for (j = 0; j < diff; j++)
			*sp_blob_waddr++ = param->value[j];
	}
	blob_length += sect.size;
	return 0;
}

#ifdef BLOB_SP_TEST_1
/******************************************************************************/
/* 1 SP, with parameters, is loaded for WRIOP and AIOP ingress. It parses a
 * custom header, placed after ETH, having the EType 0xEE00 and length of 46
 * bytes. It is followed by a L2 header.
 *
 * The SP calls a routine that computes the running sum. That routine is also
 * loaded.
 * */
int dpsparser_write_blob(struct dpsparser *dpsparser)
{
	struct sp_protocol_cfg	sp_pcfg;
	struct sp_param_cfg	sp_param_cfg[2];
	int			err;

	/*********************/
	/* Write file-header */
	/*********************/
	err = dpsparser_blob_write_file_header(dpsparser);
	if (err)
		return err;
	pr_info("[BLOB] : 'file-header' section written\n");
	/******************************/
	/* Write blob-name [optional] */
	/******************************/
	err = dpsparser_blob_write_name_sect("Test-BLOB");
	if (err)
		return err;
	pr_info("[BLOB] : 'blob-name' section written\n");
	/******************/
	/* Write bytecode */
	/******************/
	/* CUSTOM_HEADER_AFTER_ETHERNET soft parser */
	err = dpsparser_blob_write_bc_sect(sp_after_eth, sizeof(sp_after_eth),
					   AFTER_ETH_ADDR,
					   WRIOP_INGRESS_PARSER |
					   AIOP_PARSER);
	if (err)
		return err;
	pr_info("[BLOB] : 'bytecode' section written\n");
	/* Running sum routine */
	err = dpsparser_blob_write_bc_sect(sp_running_sum,
					   sizeof(sp_running_sum),
					   RUNNING_SUM_ADDR,
					   WRIOP_INGRESS_PARSER |
					   AIOP_PARSER);
	if (err)
		return err;
	pr_info("[BLOB] : 'bytecode' section written\n");
	/**********************/
	/* Write sp-protocols */
	/**********************/
	memset(&sp_pcfg, 0, sizeof(struct sp_protocol_cfg));
	/* Add CUSTOM_HEADER_AFTER_ETHERNET soft parser */
	memcpy(sp_pcfg.sp_name, "AfterETH", 8);
	sp_pcfg.flags = (uint8_t)ENABLE_ON_WRIOP_INGRESS |
			(uint8_t)ENABLE_ON_AIOP_INGRESS;
	sp_pcfg.seq_start = AFTER_ETH_ADDR;
	sp_pcfg.base_proto = LNK_ETH_HXS;
	err = dpsparser_blob_write_sp_protocols_sect(&sp_pcfg, 1);
	if (err)
		return err;
	pr_info("[BLOB] : 'sp-protocols' section written\n");
	/***********************/
	/* Write sp-parameters */
	/***********************/
	memset(&sp_param_cfg[0], 0, 2 * sizeof(struct sp_param_cfg));
	/***************************/
	/* AfterETH - Parameter #0 */
	/***************************/
	sp_param_cfg[0].entry_size = 24;
	sp_param_cfg[0].param_offset = 0;
	sp_param_cfg[0].param_size = 2;
	sp_param_cfg[0].flags = 0x80;
	/* Reserved is 0 */
	memcpy(sp_param_cfg[0].proto_name, "AfterETH", 8);
	strcpy(sp_param_cfg[0].param_name, "EType");
	sp_param_cfg[0].value[0] = 0xEE;
	sp_param_cfg[0].value[1] = 0x00;
	sp_param_cfg[0].value[2] = 0x00;
	sp_param_cfg[0].value[3] = 0x00;
	sp_param_cfg[0].entry_size += 4;
	/***************************/
	/* AfterETH - Parameter #1 */
	/***************************/
	sp_param_cfg[1].entry_size = 24;
	sp_param_cfg[1].param_offset = 2;
	sp_param_cfg[1].param_size = 1;
	sp_param_cfg[1].flags = 0x80;
	/* Reserved is 0 */
	memcpy(sp_param_cfg[1].proto_name, "AfterETH", 8);
	strcpy(sp_param_cfg[1].param_name, "HdrLen");
	sp_param_cfg[1].value[0] = 46;
	sp_param_cfg[1].value[1] = 0;
	sp_param_cfg[1].value[2] = 0;
	sp_param_cfg[1].value[3] = 0;
	sp_param_cfg[1].entry_size += 4;
	err = dpsparser_blob_write_sp_parameters_sect(&sp_param_cfg[0], 2);
	if (err)
		return err;
	pr_info("[BLOB] : 'sp-parameters' section written\n");
	/* Update length of the BLOB in the 'file-header' section*/
	STORE_CPU_TO_LE32_WT(blob_length, blob_length_ptr);
	/* Dump BLOB */
	dpsparser_dump_blob_bytes((uint32_t)sp_blob_waddr -
				  (uint32_t)sp_blob_address);
	return 0;
}

#endif	/* BLOB_SP_TEST_1 */

#define BLOB_SP_TEST_2

#ifdef BLOB_SP_TEST_2
/******************************************************************************/
/* 1 SP, with parameters, is loaded for WRIOP and AIOP ingress. It parses a
 * custom header, placed at the packet begin and having the length of 32 bytes.
 * It is followed by an ETH header.
 *
 * The SP calls a routine that computes the running sum. That routine is also
 * loaded.
 * */
int dpsparser_write_blob(struct dpsparser *dpsparser)
{
	struct sp_protocol_cfg	sp_pcfg;
	struct sp_param_cfg	sp_param_cfg;
	int			err;

	/*********************/
	/* Write file-header */
	/*********************/
	err = dpsparser_blob_write_file_header(dpsparser);
	if (err)
		return err;
	pr_info("[BLOB] : 'file-header' section written\n");
	/******************************/
	/* Write blob-name [optional] */
	/******************************/
	err = dpsparser_blob_write_name_sect("Test-BLOB");
	if (err)
		return err;
	pr_info("[BLOB] : 'blob-name' section written\n");
	/******************/
	/* Write bytecode */
	/******************/
	/* CUSTOM_HEADER_BEFORE_ETHERNET soft parser */
	err = dpsparser_blob_write_bc_sect(sp_before_eth, sizeof(sp_before_eth),
					   BEFORE_ETH_LADDR,
					   WRIOP_INGRESS_PARSER |
					   AIOP_PARSER);
	if (err)
		return err;
	pr_info("[BLOB] : 'bytecode' section written\n");
	/* Running sum routine */
	err = dpsparser_blob_write_bc_sect(sp_running_sum,
					   sizeof(sp_running_sum),
					   RUNNING_SUM_ADDR,
					   WRIOP_INGRESS_PARSER |
					   AIOP_PARSER);
	if (err)
		return err;
	pr_info("[BLOB] : 'bytecode' section written\n");
	/**********************/
	/* Write sp-protocols */
	/**********************/
	memset(&sp_pcfg, 0, sizeof(struct sp_protocol_cfg));
	/* CUSTOM_HEADER_AFTER_ETHERNET soft parser */
	memcpy(sp_pcfg.sp_name, "BefFirst", 8);
	sp_pcfg.flags = (uint8_t)ENABLE_ON_WRIOP_INGRESS |
			(uint8_t)ENABLE_ON_AIOP_INGRESS;
	sp_pcfg.seq_start = BEFORE_ETH_LADDR;
	sp_pcfg.base_proto = LNK_BEFORE_FIRST_HXS;
	err = dpsparser_blob_write_sp_protocols_sect(&sp_pcfg, 1);
	if (err)
		return err;
	pr_info("[BLOB] : 'sp-protocols' section written\n");
	/***********************/
	/* Write sp-parameters */
	/***********************/
	memset(&sp_param_cfg, 0, sizeof(struct sp_param_cfg));
	/* BefFirst - Parameter #0 */
	sp_param_cfg.entry_size = 24;
	sp_param_cfg.param_offset = 32;
	sp_param_cfg.param_size = 1;
	sp_param_cfg.flags = 0x80;
	/* Reserved is 0 */
	memcpy(sp_param_cfg.proto_name, "BefFirst", 8);
	strcpy(sp_param_cfg.param_name, "HdrLen");
	sp_param_cfg.value[0] = 32;
	sp_param_cfg.value[1] = 0;
	sp_param_cfg.value[2] = 0;
	sp_param_cfg.value[3] = 0;
	sp_param_cfg.entry_size += 4;
	err = dpsparser_blob_write_sp_parameters_sect(&sp_param_cfg, 1);
	if (err)
		return err;
	pr_info("[BLOB] : 'sp-parameters' section written\n");
	/* Update length of the BLOB in the 'file-header' section*/
	STORE_CPU_TO_LE32_WT(blob_length, blob_length_ptr);
	/* Dump BLOB */
	dpsparser_dump_blob_bytes((uint32_t)sp_blob_waddr -
				  (uint32_t)sp_blob_address);
	return 0;
}

#endif	/* BLOB_SP_TEST_2 */

#endif	/* SOFT_PARSER_BLOB_CHECK */
