/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpsparser.h

 @Description   DPSPARSER internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPSPARSER_H
#define __DPSPARSER_H

/******************************************************************************/
#include "parser_ctrl.h"
#include "dpparser.h"
#include "dpsparser_blob.h"

/******************************************************************************/
#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPSPARSER

#define DPSPARSER_MAX_IRQ_NUM		1
#define DPSPARSER_IRQ_INDEX		0

/* Memory available to store soft parsers in a HW parser
 *	- 4 KB
 *	- 64 bytes are reserved for HXS-es and 4 bytes for the special
 *	addresses 0x7fe and 0x7ff
 * => 4028 bytes */
#define SPARSER_MEM	(4 * KILOBYTE - 68)

/** Maximum number of bytecode sections on a HW parser. 
 * Each bytecode section can contain multiple custom protocols  
 * (each minimal custom protocol having approximately 32 bytes).
 * This maximum value is large enough to store 
 * information for all custom protocols loaded on a HW parser. */
#define MAX_BYTECODE_SECTIONS		64

/** WRIOP INGRESS parser */
#define WRIOP_INGRESS_PARSER		0x80000000

/** WRIOP EGRESS parser */
#define WRIOP_EGRESS_PARSER		0x40000000

/** AIOP parser memory */
#define AIOP_PARSER			0x20000000

/** Maximum number of parse profiles on a HW parser. */
#define MAX_PROFILES			64

/** Size of the parameters array in a parse profile */
#define PAR_ARRAY_SIZE			64

/** Number of soft parser that may be enabled by a parse profile */
#define MAX_LNK_SP			(32 + 1)

/** Maximum number of protocols on a HW parser. (each soft parser having
 * approximately 32 bytes). This maximum value is large enough to store
 * information on all SPs loaded on a HW parser. */
#define MAX_PROTOCOLS			64

/**************************************************************************//**
 @Group		DPSPARSER_Enumerations DPSPARSER Enumerations

 @Description	DPSPARSER Enumerations

 @{
*//***************************************************************************/

/**************************************************************************//**
@enum	sparser_link

@Description Soft parser linking in the parse tree

@{
*//***************************************************************************/
enum sparser_link {
	/**  Called from Ethernet HXS */
	LNK_ETH_HXS		= 1,
	/**  Called from LLC+SNAP HXS */
	LNK_LLC_SNAP_HXS	= 2,
	/**  Called from VLAN HXS */
	LNK_VLAN_HXS		= 3,
	/**  Called from PPPoE+PPP HXS */
	LNK_PPPOE_PPP_HXS	= 4,
	/**  Called from MPLS HXS */
	LNK_MPLS_HXS		= 5,
	/**  Called from ARP HXS */
	LNK_ARP_HXS		= 6,
	/**  Called from IP HXS */
	LNK_IP_HXS		= 7,
	/**  Called from IPv4 HXS */
	LNK_IPV4_HXS		= 8,
	/**  Called from IPv6 HXS */
	LNK_IPV6_HXS		= 9,
	/**  Called from GRE HXS */
	LNK_GRE_HXS		= 10,
	/**  Called from MinEncap HXS */
	LNK_MINENCAP_HXS	= 11,
	/**  Called from Other L3 Shell HXS */
	LNK_OTHER_L3_SHELL_HXS	= 12,
	/**  Called from TCP HXS */
	LNK_TCP_HXS		= 13,
	/**  Called from UDP HXS */
	LNK_UDP_HXS		= 14,
	/**  Called from IPSec HXS */
	LNK_IPSEC_HXS		= 15,
	/**  Called from SCTP HXS */
	LNK_SCTP_HXS		= 16,
	/**  Called from DCCP HXS */
	LNK_DCCP_HXS		= 17,
	/**  Called from Other L4 Shell HXS */
	LNK_OTHER_L4_SHELL_HXS	= 18,
	/**  Called from GTP HXS */
	LNK_GTP_HXS		= 19,
	/**  Called from ESP HXS */
	LNK_ESP_HXS		= 20,
	 /**  Called from VXLAN HXS */
	LNK_VXLAN_HXS		= 21,
	/**  Called from L5 (and above) Shell HXS */
	LNK_L5_SHELL_HXS	= 30,
	/**  Called from Final Shell HXS */
	LNK_FINAL_SHELL_HXS	= 31,
	/**  Called before first HXS (Ethernet) */
	LNK_BEFORE_FIRST_HXS	= 256
};

/** @} */ /* end of sparser_link */

/**************************************************************************//**
@enum	sparser_enable

@Description Soft parser linking in the parse tree

@{
*//***************************************************************************/
enum sparser_enable {
	/**  Enable on all WRIOP ingress */
	ENABLE_ON_WRIOP_INGRESS = 0x80,
	/**  Enable on all WRIOP egress */
	ENABLE_ON_WRIOP_EGRESS = 0x40,
	/**  Enable on AIOP ingress parse profile */
	ENABLE_ON_AIOP_INGRESS = 0x20,
	/**  Enable on AIOP egress parse profile */
	ENABLE_ON_AIOP_EGRESS = 0x10
};

/** @} */ /* end of sparser_enable */

/** @} */ /* end of group DPSPARSER_Enumerations */

/******************************************************************************/
struct bytecode_info {
	/* Byte-code loading address (starting PC) */
	uint16_t		pc;
	/* Number of bytes in the Soft Parser byte-code. Must be a multiple of
	 * four bytes. */
	uint16_t		size;
	/* SP loading targets :
	 *	WRIOP_INGRESS_PARSER,
	 *	WRIOP_EGRESS_PARSER
	 *	AIOP_PARSER */
	uint32_t		flags;
};

/******************************************************************************/
struct sp_params {
	/** Parameter name */
	uint8_t		name[8];
	/** Parameter offset */
	uint8_t		offset;
	/** Parameter flags */
	uint8_t		flags;
	/** Parameter size (in bytes) */
	uint8_t		size;
	/** Parameter value */
	uint8_t		value[64];
};

/******************************************************************************/
struct protocol_info {
	/** Soft parser name */
	uint8_t			name[8];
	/** SP loading address as starting PC */
	uint16_t		pc;		// = seq_start / 2
	/** SP link position in the parse tree */
	enum sparser_link	lnk;	//base_protocol

	/** Number of SP parameters in 'par_array' */
	uint8_t			num_params;
	/* SP parameters */
	struct sp_params	par_array[PAR_ARRAY_SIZE];
	/** Parse profile parameters array usage */
	uint64_t		par_arr_usage_bits;
};

/******************************************************************************/

#define UNLINKED_PROFILE_ID 	-1

struct profile_info {
	/** Parse profile name */
	uint8_t			name[MAX_SP_PROFILE_ID_SIZE];
	uint8_t			en_flags;
	
	/** Count of Protocols */
	uint16_t		proto_count;
	/** Configured Protocols */
	struct protocol_info	proto[MAX_PROTOCOLS];
};

/******************************************************************************/

/* Default profile Index - initially applied by default on all DPNI */
#define DEFAULT_PROFILE_IDX 	0

struct parser_layout {
	/** Count of loaded Soft Parsers */
	uint16_t		sp_count;
	/** Loaded byte-code information */
	struct bytecode_info	sp[MAX_BYTECODE_SECTIONS];
	
	uint16_t		profile_count;
	uint16_t		alloc_profile_count;
	struct profile_info	*profiles;
};

/******************************************************************************/
struct dpsparser {
	uint16_t		id;
	struct dpmng		*dpmng;
	struct device		*device;
	int			enabled;
	int			authorized;
	/** Configuration was successfully applied on HW */
	int			applied;
	struct dpmng_amq	amq;
	struct mc_irq		irqs[DPSPARSER_MAX_IRQ_NUM];
	/** Parser major revision number */
	uint8_t			ip_rev_major;
	/** Parser minor revision number */
	uint8_t			ip_rev_minor;
	/** Blob loaded backward compatible version */
	uint8_t			blob_bc_ver;
	/** HW parsers */
	struct parser_ctrl	*parsers;
	/** WRIOP ingress soft parsers */
	struct parser_layout	ingress_sp;
	/** WRIOP egress soft parsers */
	struct parser_layout	egress_sp;
	/** AIOP soft parsers */
	struct parser_layout	aiop_sp;
};

/******************************************************************************/
int dpsparser_drv_init(void);

int dpsparser_load_bytecode(struct dpsparser *dpsparser, uint8_t *bcode,
			    uint32_t offset, uint32_t sz, uint32_t flags);

int dpsparser_set_profile(struct dpsparser *dpsparser, struct sp_profile_cfg *sp_profile);

int dpsparser_set_protocol_v1(struct dpsparser *dpsparser, char *sp_name,
			   enum sparser_link base_proto, uint8_t flags,
			   uint16_t seq_start);

int dpsparser_set_param(struct dpsparser *dpsparser, char *profile_name, char *proto_name,
			uint8_t flags, char *pname, uint16_t poffset,
			uint16_t psize, uint8_t *pvalue);

int dpsparser_get_default_profile(struct dpsparser *dpsparser, enum ctlu_type type, struct profile_info **pinfo);

int dpsparser_get_profile_by_name(struct dpsparser *dpsparser, enum ctlu_type type, uint8_t *sp_prof, 
					struct profile_info **pinfo);

int dpsparser_build_profile(struct dpsparser *dpsparser, enum ctlu_type type, uint8_t *sp_prof,
				    struct profile_info *pinfo);

char* get_error_msg(int error);

#endif /* __DPSPARSER_H */
