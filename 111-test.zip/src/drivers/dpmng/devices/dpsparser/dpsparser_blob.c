/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpsparser_blob.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_platform.h"
#include "fsl_resman.h"

#include "fsl_dpsparser_mc.h"
#include "fsl_dpsparser_cmd.h"
#include "dpsparser.h"
#include "dpsparser_blob.h"
#include "dpsparser_blob_dbg.h"


#ifdef SOFT_PARSER_BLOB_CHECK
//---------- SPC Blob test ---------//

//SPC generated blob
//after_ethernet_blob.h : OK
//protocol enabled-on-init: wriop_ingress, aiop_ingress
uint8_t blob[] = {   \
	0x43, 0x42, 0x50, 0x53, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x03, 0x00, 0x7c, 0x01, 0x00, 0x00, \
	0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	0x41, 0x46, 0x54, 0x45, 0x54, 0x48, 0x00, 0x00, 0xd8, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, \
	0x00, 0x00, 0x00, 0xe0, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb7, 0x9e, 0x02, 0x1f, 0xee, 0x00, \
	0x00, 0x78, 0x00, 0x2a, 0x18, 0x00, 0x07, 0xfe, 0x18, 0x00, 0x00, 0x2a, 0x32, 0x31, 0x33, 0x20, \
	0x00, 0x4a, 0x00, 0x80, 0x00, 0x02, 0x08, 0x91, 0x08, 0x00, 0x33, 0x21, 0x28, 0x41, 0x33, 0x21, \
	0x00, 0x55, 0x00, 0x2e, 0x28, 0x65, 0x02, 0x1f, 0x00, 0x2e, 0x28, 0x1b, 0x33, 0x73, 0x00, 0xfd, \
	0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x1f, 0x30, 0xd0, 0x02, 0x1f, 0x00, 0x07, \
	0x00, 0x7a, 0x00, 0x63, 0x00, 0x05, 0x2f, 0x0f, 0x00, 0x00, 0x30, 0x7f, 0xc3, 0x8f, 0x00, 0x52, \
	0x00, 0x01, 0x07, 0x01, 0x2f, 0x0f, 0x00, 0x05, 0x00, 0x7a, 0x00, 0x48, 0x30, 0xd0, 0x00, 0xda, \
	0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x78, 0x00, 0x5e, 0x30, 0x7f, \
	0x02, 0x8f, 0x00, 0x00, 0x30, 0xf2, 0x30, 0x7f, 0x00, 0x06, 0x18, 0x00, 0x00, 0x73, 0x00, 0x00, \
	0x9f, 0xff, 0x30, 0xf2, 0x00, 0x06, 0x29, 0x1e, 0x07, 0x08, 0x30, 0xd0, 0x00, 0x52, 0x00, 0x08, \
	0x28, 0x1a, 0x00, 0x05, 0x00, 0x7a, 0x00, 0x41, 0x30, 0xf2, 0x18, 0x00, 0x00, 0x73, 0x06, 0x00, \
	0x29, 0x1e, 0x30, 0xf2, 0x00, 0xdc, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x6e, \
	0x03, 0xe0, 0x02, 0x1f, 0x00, 0x2e, 0x00, 0x81, 0x00, 0x44, 0x18, 0x00, 0x07, 0xff, 0x00, 0x00, \
	0x20, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	0x61, 0x66, 0x74, 0x65, 0x74, 0x68, 0x00, 0x00, 0xa0, 0x00, 0x40, 0x00, 0x01, 0x00, 0x00, 0x00, \
	0x5c, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	0x18, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x61, 0x66, 0x74, 0x65, 0x74, 0x68, 0x00, 0x00, \
	0x70, 0x61, 0x72, 0x61, 0x6d, 0x31, 0x00, 0x00, 0x18, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, \
	0x64, 0x61, 0x70, 0x00, 0x00, 0x00, 0x00, 0x00, 0x70, 0x61, 0x72, 0x61, 0x6d, 0x32, 0x00, 0x00, \
	0x1c, 0x00, 0x02, 0x00, 0x02, 0x00, 0x00, 0x00, 0x75, 0x64, 0x70, 0x69, 0x70, 0x73, 0x65, 0x63, \
	0x70, 0x61, 0x72, 0x61, 0x6d, 0x33, 0x00, 0x00, 0x12, 0x34, 0x00, 0x00, };


//SPC generated blob
//protocol disabled-on-init
/*
uint8_t blob[] = {   \
	0x43, 0x42, 0x50, 0x53, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x03, 0x00, 0x20, 0x01, 0x00, 0x00, \
	0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	0x41, 0x46, 0x54, 0x45, 0x54, 0x48, 0x00, 0x00, 0xd8, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, \
	0x00, 0x00, 0x00, 0xe0, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb7, 0x9e, 0x02, 0x1f, 0xee, 0x00, \
	0x00, 0x78, 0x00, 0x2a, 0x18, 0x00, 0x07, 0xfe, 0x18, 0x00, 0x00, 0x2a, 0x32, 0x31, 0x33, 0x20, \
	0x00, 0x4a, 0x00, 0x80, 0x00, 0x02, 0x08, 0x91, 0x08, 0x00, 0x33, 0x21, 0x28, 0x41, 0x33, 0x21, \
	0x00, 0x55, 0x00, 0x2e, 0x28, 0x65, 0x02, 0x1f, 0x00, 0x2e, 0x28, 0x1b, 0x33, 0x73, 0x00, 0xfd, \
	0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x1f, 0x30, 0xd0, 0x02, 0x1f, 0x00, 0x07, \
	0x00, 0x7a, 0x00, 0x63, 0x00, 0x05, 0x2f, 0x0f, 0x00, 0x00, 0x30, 0x7f, 0xc3, 0x8f, 0x00, 0x52, \
	0x00, 0x01, 0x07, 0x01, 0x2f, 0x0f, 0x00, 0x05, 0x00, 0x7a, 0x00, 0x48, 0x30, 0xd0, 0x00, 0xda, \
	0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x78, 0x00, 0x5e, 0x30, 0x7f, \
	0x02, 0x8f, 0x00, 0x00, 0x30, 0xf2, 0x30, 0x7f, 0x00, 0x06, 0x18, 0x00, 0x00, 0x73, 0x00, 0x00, \
	0x9f, 0xff, 0x30, 0xf2, 0x00, 0x06, 0x29, 0x1e, 0x07, 0x08, 0x30, 0xd0, 0x00, 0x52, 0x00, 0x08, \
	0x28, 0x1a, 0x00, 0x05, 0x00, 0x7a, 0x00, 0x41, 0x30, 0xf2, 0x18, 0x00, 0x00, 0x73, 0x06, 0x00, \
	0x29, 0x1e, 0x30, 0xf2, 0x00, 0xdc, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x6e, \
	0x03, 0xe0, 0x02, 0x1f, 0x00, 0x2e, 0x00, 0x81, 0x00, 0x44, 0x18, 0x00, 0x07, 0xff, 0x00, 0x00, \
	0x20, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	0x61, 0x66, 0x74, 0x65, 0x74, 0x68, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x01, 0x00, 0x00, 0x00, \
};
*/

//---------- SPC Blob test ---------//
int spc_dpsparser_write_blob(struct dpsparser *dpsparser)
{
	int i, size;
	
	size = sizeof(blob);
	pr_info("[SPC_BLOB] : SPC generated BLOB ( test: 06 ) / blob size = %d \n", size);
	
	for (i=0; i<size; i++)
		sp_blob_waddr[i] = blob[i];
}
#endif


/******************************************************************************/
/* Soft Parsers BLOB loading address. Must be in memory space accessible to
 * the MC cores.
 * Should be written by an external tool (uBoot, a GPP application, ...) */
void *sp_blob_address;


/* Current byte read position */
static uint8_t			*sp_blob_raddr;
/* Number of bytes to read from BLOB */
static int32_t			blob_bytes;
/* blob-name optional section */
static struct sp_blob_name	blob_name;

/******************************************************************************/
static void dpsparser_blob_free(void)
{
#ifdef SOFT_PARSER_BLOB_CHECK
	if (sp_blob_address) {
		fsl_xfree(sp_blob_address);
		fsl_print("[BLOB] Free BLOB at 0x%08x\n", sp_blob_address);
	}
#endif
	sp_blob_address = 0;
}

/******************************************************************************/
static int dpsparser_blob_init(struct dpsparser *dpsparser)
{
#ifdef SOFT_PARSER_BLOB_CHECK
	int	err;

	sp_blob_address = fsl_xmalloc(SP_BLOB_SIZE, 0, CORE_CACHELINE_SIZE);
	if (!sp_blob_address) {
		fsl_print("[BLOB] : ERROR - Allocate %d KB\n",
			  SP_BLOB_SIZE / KILOBYTE);
		return -ENOMEM;
	}
	memset(sp_blob_address, 0, SP_BLOB_SIZE);
	fsl_print("[BLOB] : Allocated %d KB\n", SP_BLOB_SIZE / KILOBYTE);
	sp_blob_waddr = (uint8_t *)sp_blob_address;
	
	//---------- SPC Blob test ---------//
	err = spc_dpsparser_write_blob(dpsparser);
	//err = dpsparser_write_blob(dpsparser);
	
	if (err)
		return err;
#endif
	sp_blob_raddr = (uint8_t *)sp_blob_address;
	if (!sp_blob_raddr) {
		pr_err("apply spb : BLOB address is not not set\n");
		return MC_ERROR_SPB_ID_BLOB_NO_ADDRESS_SET;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_check_file_header_sect(struct sp_file_header *fhead,
						 struct dpsparser *dpsparser)
{
	uint32_t	maj, min;

	/* Validate BLOB magic number */
	if (fhead->magic != BE32_TO_CPU(BLOB_MAGIC_BE)) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_MAGIC));
		return MC_ERROR_SPB_ID_MAGIC;
	}
	
	/* Validate BLOB version against SPARSER API version */
	maj = (fhead->blob_ver >> 16) & 0xFFFF;
	min = fhead->blob_ver & 0xFFFF;
	if (maj == BLOB_VER_MAJOR && min == BLOB_VER_MINOR) {
		pr_info("BLOB: Loading currently supported Blob version: v%d.%d\n", BLOB_VER_MAJOR, BLOB_VER_MINOR);
		dpsparser->blob_bc_ver = 0;
	}
	/* Check older blob versions for backward compatibility */
	else if (maj == 1 && min == 0) {
		pr_info("BLOB: Loading old backward compatible Blob version: v1.0\n");
		dpsparser->blob_bc_ver = 1;
	}
	else {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_VER));
		return MC_ERROR_SPB_ID_BLOB_VER;
	}

	/* Validate BLOB IP version against parser HW version */
	maj = (fhead->ip_rev >> 16) & 0xFFFF;
	min = fhead->ip_rev & 0xFFFF;
	if (maj != dpsparser->ip_rev_major || min != dpsparser->ip_rev_minor) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_IP_REV));
		return MC_ERROR_SPB_ID_BLOB_IP_REV;
	}
	if (fhead->length % 4) {
		pr_err("BLOB : Blob length %d is not a multiple of 4\n", fhead->length);
		return MC_ERROR_SPB_ID_BLOB_LENGTH;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_get_file_header_sect(struct sp_file_header *fhead)
{
	if (!sp_blob_raddr)
		return -ENODEV;
	pr_info("BLOB: Header information: \n");
	memset(fhead, 0, sizeof(struct sp_file_header));
	/* MAGIC (BE) */
	fhead->magic = LOAD_LE32_TO_CPU((uint32_t *)sp_blob_raddr);
	pr_info("BLOB: magic = 0x%08x \n", fhead->magic);
	sp_blob_raddr += sizeof(uint32_t);
	/* BLOB_VER (BE) */
	fhead->blob_ver = LOAD_LE32_TO_CPU((uint32_t *)sp_blob_raddr);
	pr_info("BLOB: version = 0x%08x \n", fhead->blob_ver);
	sp_blob_raddr += sizeof(uint32_t);
	/* IP_REV (LE) */
	fhead->ip_rev = LOAD_LE32_TO_CPU((uint32_t *)sp_blob_raddr);
	pr_info("BLOB: ip_rev = 0x%08x \n", fhead->ip_rev);
	sp_blob_raddr += sizeof(uint32_t);
	/* Blob length. Should be a multiple of 4 */
	fhead->length = LOAD_LE32_TO_CPU((uint32_t *)sp_blob_raddr);
	pr_info("BLOB: length = 0x%08x \n", fhead->length);
	sp_blob_raddr += sizeof(uint32_t);
	/* Update number of read bytes */
	blob_bytes = (int32_t)(fhead->length - sizeof(struct sp_file_header));
	if (blob_bytes <= 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH));
		return MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_get_name_sect(struct sp_blob_name *bname,
					struct sp_blob_section *sect)
{
	int	name_len;

	if (!sp_blob_raddr)
		return -ENODEV;
	memset(bname, 0, sizeof(struct sp_blob_name));
	bname->sect.size = sect->size;
	bname->sect.tag = sect->tag;
	/* Reserved (8) - Skip */
	sp_blob_raddr += sizeof(uint64_t);
	/* name */
	name_len = (int)sect->size - sizeof(struct sp_blob_section) -
						sizeof(uint64_t);
	if (!name_len)
		return 0;
	if (name_len < 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_NAME_NEGATIVE_LENGTH));
		return MC_ERROR_SPB_ID_NAME_NEGATIVE_LENGTH;
	}
	if (name_len % 4) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_NAME_LENGTH_NOT_MULT_4));
		return MC_ERROR_SPB_ID_NAME_LENGTH_NOT_MULT_4;
	}
	bname->name = fsl_xmalloc((uint32_t)name_len, 0, CORE_CACHELINE_SIZE);
	if (!bname->name) {
		pr_err("[BLOB] : Allocate %d bytes for BLOB name\n", name_len);
		return -ENOMEM;
	}
	memcpy(bname->name, sp_blob_raddr, (uint32_t)name_len);
	sp_blob_raddr += (uint32_t)name_len;
	/* Update number of read bytes */
	blob_bytes -= sect->size;
	if (blob_bytes <= 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH));
		return MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_get_bytecode_sect(struct sp_byte_code *bcode,
					    struct sp_blob_section *sect,
					    uint32_t *sz)
{
	int	bc_size;

	if (!sp_blob_raddr)
		return -ENODEV;
	memset(bcode, 0, sizeof(struct sp_byte_code));
	bcode->sect.size = sect->size;
	bcode->sect.tag = sect->tag;
	/* Flags (LE) */
	bcode->flags = LOAD_LE32_TO_CPU((uint32_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint32_t);
	if (!bcode->flags) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_NO_TARGET_HW));
		return MC_ERROR_SPB_ID_NO_TARGET_HW;
	}
	/* Offset (LE) */
	bcode->offset = LOAD_LE32_TO_CPU((uint32_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint32_t);
	/* Bytecode */
	bc_size = (int)sect->size - sizeof(struct sp_blob_section) -
						2 * sizeof(uint32_t);
	if (bc_size < 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_SP_SIZE_NEGATIVE));
		return MC_ERROR_SPB_ID_BLOB_SP_SIZE_NEGATIVE;
	}
	bcode->byte_code = sp_blob_raddr;
	sp_blob_raddr += (uint32_t)bc_size;
	if (bc_size == 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_SIZE_ZERO));
		return MC_ERROR_SPB_ID_BLOB_SIZE_ZERO;
	}
	*sz = (uint32_t)bc_size;
	/* Update number of read bytes */
	blob_bytes -= sect->size;
	if (blob_bytes <= 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH));
		return MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_get_sp_profiles_sect(struct sp_profile_cfg *pr,
						struct sp_blob_section *sect,
						uint32_t *num_pr)
{
	int	pr_count;

	if (!sp_blob_raddr)
		return -ENODEV;
	memset(pr, 0, sizeof(struct sp_profile_cfg));
	pr->sect.size = sect->size;
	pr->sect.tag = sect->tag;
	
	/* Reserved (8) */
	sp_blob_raddr += sizeof(uint64_t);

	/* Profile name (8) */
	memcpy(pr->profile_name, sp_blob_raddr, 8);
	sp_blob_raddr += 8;

	/* Flags (1) + ItemsNo (1) + Reserved (6) = (8) */
	pr->enable_flags = (uint8_t)(*sp_blob_raddr);
	sp_blob_raddr += 1;
	pr->proto_no = (uint8_t)(*sp_blob_raddr);
	sp_blob_raddr += 1;
	/* Reserved (6) */	
	sp_blob_raddr += 6;
	
	pr_count = ((int)sect->size -
		    (sizeof(struct sp_blob_section) + 24 )) /
		    sizeof(struct sp_protocol_cfg);
	if (pr_count < 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_NEGATIVE_PROT_NO));
		return MC_ERROR_SPB_ID_BLOB_NEGATIVE_PROT_NO;
	}
	if (pr_count != pr->proto_no) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_PROT_NO));
		return MC_ERROR_SPB_ID_BLOB_INVALID_PROT_NO;
	}
	*num_pr = (uint32_t)pr_count;
	/* Update number of read bytes */
	blob_bytes -= sect->size;
	if (blob_bytes < 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH));
		return MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_get_protocol_cfg(struct sp_protocol_cfg *pr)
{
	int		i, len;
	uint8_t		*pch;

	if (!sp_blob_raddr)
		return -ENODEV;
	memset(pr, 0, sizeof(struct sp_protocol_cfg));
	/* sp_name (8) */
	memcpy(pr->sp_name, sp_blob_raddr, 8);
	sp_blob_raddr += 8;
	/* Reserved (1) */
	sp_blob_raddr++;
	/* Reserved (1) */
	sp_blob_raddr++;
	/* seq-start (2) */
	pr->seq_start = LOAD_LE16_TO_CPU((uint16_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint16_t);
	/* base-proto (4) */
	pr->base_proto = LOAD_LE32_TO_CPU((uint32_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint32_t);
	/* Validate protocol name */
	pch = &pr->sp_name[0];
	len = 0;
	for (i = 0; i < 8 && *pch != 0; i++)
		len++;
	if (!len) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_NULL_PROT_NAME));
		return MC_ERROR_SPB_ID_BLOB_NULL_PROT_NAME;
	}

#if VALIDATION_EXCLUDED
	/* Validate seq-start */
	if (pr->seq_start % 4) {
		pr_err("BLOB : SP 'seq-start' %03x is not a multiple of 4\n",
		       pr->seq_start);
		return -EINVAL;
	}
#endif	
	if (pr->seq_start < 0x40 || pr->seq_start >= 0xffc) {
		pr_err("BLOB : SP 'seq-start' %03x is not in [0x40, 0xffc0)\n",
		       pr->seq_start);
		return MC_ERROR_SPB_ID_BLOB_SP_SEQ_START_NOT_IN_RANGE;
	}
	/* Validate base protocol */
	switch (pr->base_proto) {
	case LNK_ETH_HXS:
	case LNK_LLC_SNAP_HXS:
	case LNK_VLAN_HXS:
	case LNK_PPPOE_PPP_HXS:
	case LNK_MPLS_HXS:
	case LNK_ARP_HXS:
	case LNK_IP_HXS:
	case LNK_IPV4_HXS:
	case LNK_IPV6_HXS:
	case LNK_GRE_HXS:
	case LNK_MINENCAP_HXS:
	case LNK_OTHER_L3_SHELL_HXS:
	case LNK_TCP_HXS:
	case LNK_UDP_HXS:
	case LNK_IPSEC_HXS:
	case LNK_SCTP_HXS:
	case LNK_DCCP_HXS:
	case LNK_OTHER_L4_SHELL_HXS:
	case LNK_GTP_HXS:
	case LNK_ESP_HXS:
	case LNK_VXLAN_HXS:
	case LNK_L5_SHELL_HXS:
	case LNK_FINAL_SHELL_HXS:
	case LNK_BEFORE_FIRST_HXS:
		break;
	default:
		pr_err("BLOB : Invalid base protocol %d\n",
		       (uint32_t)pr->base_proto);
		return MC_ERROR_SPB_ID_BLOB_INVALID_BASE_PROT;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_get_sp_params_sect(struct sp_parameters *params,
					     struct sp_blob_section *sect,
					     int *parms_size)
{
	if (!sp_blob_raddr)
		return -ENODEV;
	memset(params, 0, sizeof(struct sp_parameters));
	params->sect.size = sect->size;
	params->sect.tag = sect->tag;
	/* Reserved (8) */
	sp_blob_raddr += sizeof(uint64_t);
	*parms_size = (int)sect->size - sizeof(struct sp_blob_section) -
					sizeof(uint64_t);
	if (*parms_size <= 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_PARAM_SECT));
		return MC_ERROR_SPB_ID_BLOB_INVALID_PARAM_SECT;
	}
	/* Update number of read bytes */
	blob_bytes -= sect->size;
	if (blob_bytes < 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH));
		return MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH;
	}
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_get_param_cfg(struct sp_param_cfg *param,
					int *parms_size)
{
	int	i, value_size_in_blob;

	if (!sp_blob_raddr)
		return -ENODEV;
	if (*parms_size < offsetof(struct sp_param_cfg, value)) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_PARAMETER));
		return MC_ERROR_SPB_ID_BLOB_INVALID_PARAMETER;
	}
	memset(param, 0, sizeof(struct sp_param_cfg));
	/* entry_size (2) */
	param->entry_size = LOAD_LE16_TO_CPU((uint16_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint16_t);
	/* param_offset (2) */
	param->param_offset = LOAD_LE16_TO_CPU((uint16_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint16_t);
	/* param_size (2) */
	param->param_size = LOAD_LE16_TO_CPU((uint16_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint16_t);
	/* flags (1) */
	param->flags = *sp_blob_raddr++;
	/* reserved (1) */
	sp_blob_raddr++;
	/* profile_name (8) */
	memcpy(param->profile_name, sp_blob_raddr, 8);
	sp_blob_raddr += 8;
	/* protocol_name (8) */
	memcpy(param->proto_name, sp_blob_raddr, 8);
	sp_blob_raddr += 8;
	/* param_name (8) */
	memcpy(param->param_name, sp_blob_raddr, 8);
	sp_blob_raddr += 8;
	if (!param->param_size) {
		*parms_size -= param->entry_size;
		return 0;
	}
	if (param->entry_size < 24) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_PARAM_CONFIG));
		return MC_ERROR_SPB_ID_BLOB_INVALID_PARAM_CONFIG;
	}
	value_size_in_blob = (int)param->entry_size - (int)offsetof(struct sp_param_cfg, value);

#if VALIDATION_EXCLUDED
	if (value_size_in_blob % 4) {
		pr_err("Not aligned value\n");
		return MC_ERROR_SPB_ID_BLOB_VALUE_NOT_ALIGNED;
	}
#endif
	/* read value (variable size from blob)
	 * by default value was set to zero if it's not defined in blob */
	if (value_size_in_blob > 0) {
		for (i = 0; i < value_size_in_blob; i++)
			param->value[i] = *sp_blob_raddr++;
	}
	*parms_size -= param->entry_size;
	return 0;
}

/******************************************************************************/
static int dpsparser_blob_get_sect_preamble(struct sp_blob_section *sect)
{
	int	err;

	if (!sp_blob_raddr)
		return -ENODEV;
	memset(sect, 0, sizeof(struct sp_blob_section));
	/* Size */
	sect->size = LOAD_LE32_TO_CPU((uint32_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint32_t);
	/* TAG */
	sect->tag = LOAD_LE32_TO_CPU((uint32_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint32_t);
	/* Check if it is a valid section */
	switch ((enum sp_section_tag)sect->tag) {
	case NAME_SECT:
	case BYTE_CODE_SECT:
	case SP_PROFILES_SECT:
	case SP_PARAMETERS_SECT:
		err = 0;
		break;
	default:
		err = 1;
	}
	if (err) {
		pr_err("BLOB : Invalid section TAG detected : %d (0x%08x)\n",
		       sect->tag, sect->tag);
		return MC_ERROR_SPB_ID_BLOB_INVALID_SECT_TAG;
	}
	if (!sect->size) {
		pr_err("BLOB : TAG = %d - Section size = 0\n", sect->tag);
		return MC_ERROR_SPB_ID_BLOB_ZERO_SECT_SIZE;
	}
	if (sect->size % 4) {
		pr_err("BLOB : TAG = %d - Size not a 4 multiple\n", sect->tag);
		return MC_ERROR_SPB_ID_BLOB_SECT_SIZE_MULT_4;
	}
	if (sect->size > SPARSER_MEM) {
		pr_err("BLOB : TAG = %d - Size %d seems too big\n", sect->tag,
		       sect->size);
		return MC_ERROR_SPB_ID_BLOB_SECT_SIZE_BIG;
	}
	return 0;
}

/******************************************************************************/
/* Backward compatibility Blob: v1 */

static int dpsparser_blob_get_protocol_cfg_v1(struct sp_protocol_cfg_v1 *pr)
{
	int		i, len;
	uint8_t		*pch;
	enum sparser_link base_proto;

	if (!sp_blob_raddr)
		return -ENODEV;
	memset(pr, 0, sizeof(struct sp_protocol_cfg_v1));
	/* sp_name (8) */
	memcpy(pr->sp_name, sp_blob_raddr, 8);
	sp_blob_raddr += 8;
	/* flags (1) */
	pr->flags = *sp_blob_raddr++;
	/* Reserved (1) */
	sp_blob_raddr++;
	/* seq-start (2) */
	pr->seq_start = LOAD_LE16_TO_CPU((uint16_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint16_t);
	/* base-proto (4) */
	pr->base_proto = LOAD_LE32_TO_CPU((uint32_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint32_t);
	/* Validate protocol name */
	pch = &pr->sp_name[0];
	len = 0;
	for (i = 0; i < 8 && *pch != 0; i++)
		len++;
	if (!len) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_NULL_PROT_NAME));
		return MC_ERROR_SPB_ID_BLOB_NULL_PROT_NAME;
	}

#if VALIDATION_EXCLUDED
	/* Validate seq-start */
	if (pr->seq_start % 4) {
		pr_err("BLOB : SP 'seq-start' %03x is not a multiple of 4\n",
		       pr->seq_start);
		return -EINVAL;
	}
#endif	
	if (pr->seq_start < 0x40 || pr->seq_start >= 0xffc) {
		pr_err("BLOB : SP 'seq-start' %03x is not in [0x40, 0xffc0)\n",
		       pr->seq_start);
		return MC_ERROR_SPB_ID_BLOB_SP_SEQ_START_NOT_IN_RANGE;
	}
	/* Validate base protocol */
	base_proto = (enum sparser_link)pr->base_proto;
	switch (base_proto) {
	case LNK_ETH_HXS:
	case LNK_LLC_SNAP_HXS:
	case LNK_VLAN_HXS:
	case LNK_PPPOE_PPP_HXS:
	case LNK_MPLS_HXS:
	case LNK_ARP_HXS:
	case LNK_IP_HXS:
	case LNK_IPV4_HXS:
	case LNK_IPV6_HXS:
	case LNK_GRE_HXS:
	case LNK_MINENCAP_HXS:
	case LNK_OTHER_L3_SHELL_HXS:
	case LNK_TCP_HXS:
	case LNK_UDP_HXS:
	case LNK_IPSEC_HXS:
	case LNK_SCTP_HXS:
	case LNK_DCCP_HXS:
	case LNK_OTHER_L4_SHELL_HXS:
	case LNK_GTP_HXS:
	case LNK_ESP_HXS:
	case LNK_VXLAN_HXS:
	case LNK_L5_SHELL_HXS:
	case LNK_FINAL_SHELL_HXS:
	case LNK_BEFORE_FIRST_HXS:
		break;
	default:
		pr_err("BLOB : Invalid base protocol %d\n",
		       pr->base_proto);
		return MC_ERROR_SPB_ID_BLOB_INVALID_BASE_PROT;
	}
	return 0;
}

static int dpsparser_blob_get_sp_protocols_sect_v1(struct sp_protocols_v1 *pr,
						struct sp_blob_section *sect,
						uint32_t *num_pr)
{
	int	pr_count;

	if (!sp_blob_raddr)
		return -ENODEV;
	memset(pr, 0, sizeof(struct sp_protocols_v1));
	pr->sect.size = sect->size;
	pr->sect.tag = sect->tag;
	/* Reserved (8) */
	sp_blob_raddr += sizeof(uint64_t);
	pr_count = ((int)sect->size -
		    (sizeof(struct sp_blob_section) + sizeof(uint64_t))) /
		    sizeof(struct sp_protocol_cfg_v1);
	if (pr_count < 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_NEGATIVE_PROT_NO));
		return MC_ERROR_SPB_ID_BLOB_NEGATIVE_PROT_NO;
	}
	if (!pr_count) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_ZERO_PROT_NO));
		return MC_ERROR_SPB_ID_BLOB_ZERO_PROT_NO;
	}
	*num_pr = (uint32_t)pr_count;
	/* Update number of read bytes */
	blob_bytes -= sect->size;
	if (blob_bytes < 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH));
		return MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH;
	}
	return 0;
}

static int dpsparser_blob_alloc_profile_sect_v1(struct dpsparser *dpsparser, struct sp_blob_section	*psect)
{
	
	/* Allocate profiles array of 1 item (in blob v1 was only 1 profile) */

	dpsparser->ingress_sp.profiles = (struct profile_info *)
			fsl_xmalloc(1 * sizeof(struct profile_info), 0, CORE_CACHELINE_SIZE);
	if (!dpsparser->ingress_sp.profiles) {
		pr_err("No memory for ingress_sp profiles\n");
		return -ENOMEM;
	}
	memset(dpsparser->ingress_sp.profiles, 0, sizeof(struct profile_info));
	dpsparser->ingress_sp.alloc_profile_count = 1;

	dpsparser->egress_sp.profiles = (struct profile_info *)
			fsl_xmalloc(1 * sizeof(struct profile_info), 0, CORE_CACHELINE_SIZE);
	if (!dpsparser->egress_sp.profiles) {
		pr_err("No memory for egress_sp profiles\n");
		return -ENOMEM;
	}
	memset(dpsparser->egress_sp.profiles, 0, sizeof(struct profile_info));
	dpsparser->egress_sp.alloc_profile_count = 1;

	dpsparser->aiop_sp.profiles = (struct profile_info *)
			fsl_xmalloc(1 * sizeof(struct profile_info), 0, CORE_CACHELINE_SIZE);
	if (!dpsparser->aiop_sp.profiles) {
		pr_err("No memory for aiop_sp profiles\n");
		return -ENOMEM;
	}
	memset(dpsparser->aiop_sp.profiles, 0, sizeof(struct profile_info));
	dpsparser->aiop_sp.alloc_profile_count = 1;

	pr_debug("BLOB: Allocated 1 profile for each sp\n");
	
	return 0;
}

static int dpsparser_blob_load_sp_profiles_sect_v1(struct dpsparser *dpsparser, struct sp_blob_section *sect)
{
	struct sp_protocols_v1		sp_protos;
	struct sp_protocol_cfg_v1	sp_pcfg;
	uint32_t		num_pr;
	int err;

	err = dpsparser_blob_get_sp_protocols_sect_v1(&sp_protos, sect, &num_pr);
	if (err)
		return err;
	dpsparser_blob_dump_sp_protocols_sect_v1(&sp_protos);
	
	do {
		err = dpsparser_blob_get_protocol_cfg_v1(&sp_pcfg);
		if (err)
			return err;
		dpsparser_blob_dump_protocol_cfg_v1(&sp_pcfg);
		
		err = dpsparser_set_protocol_v1(dpsparser,
					     sp_pcfg.sp_name,
					     (enum sparser_link)sp_pcfg.base_proto,
					     sp_pcfg.flags,
					     sp_pcfg.seq_start);
		if (err)
			return err;
		
		num_pr--;
	} while (num_pr && !err);
	
	pr_info("BLOB: SP Profiles loaded from old backward compatible Blob v1.0 successfully migrated to currently supported version\n");
	
	return 0;
}

static int dpsparser_blob_get_sp_params_sect_v1(struct sp_parameters_v1 *params,
					     struct sp_blob_section *sect,
					     int *parms_size)
{
	if (!sp_blob_raddr)
		return -ENODEV;
	memset(params, 0, sizeof(struct sp_parameters_v1));
	params->sect.size = sect->size;
	params->sect.tag = sect->tag;
	/* Reserved (8) */
	sp_blob_raddr += sizeof(uint64_t);
	*parms_size = (int)sect->size - sizeof(struct sp_blob_section) -
					sizeof(uint64_t);
	if (*parms_size <= 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_PARAM_SECT));
		return MC_ERROR_SPB_ID_BLOB_INVALID_PARAM_SECT;
	}
	/* Update number of read bytes */
	blob_bytes -= sect->size;
	if (blob_bytes < 0) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH));
		return MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH;
	}
	return 0;
}

static int dpsparser_blob_get_param_cfg_v1(struct sp_param_cfg_v1 *param,
					int *parms_size)
{
	int	i, value_size_in_blob;

	if (!sp_blob_raddr)
		return -ENODEV;
	if (*parms_size < offsetof(struct sp_param_cfg_v1, value)) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_PARAMETER));
		return MC_ERROR_SPB_ID_BLOB_INVALID_PARAMETER;
	}
	memset(param, 0, sizeof(struct sp_param_cfg_v1));
	/* entry_size (2) */
	param->entry_size = LOAD_LE16_TO_CPU((uint16_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint16_t);
	/* param_offset (2) */
	param->param_offset = LOAD_LE16_TO_CPU((uint16_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint16_t);
	/* param_size (2) */
	param->param_size = LOAD_LE16_TO_CPU((uint16_t *)sp_blob_raddr);
	sp_blob_raddr += sizeof(uint16_t);
	/* flags (1) */
	param->flags = *sp_blob_raddr++;
	/* reserved (1) */
	sp_blob_raddr++;
	/* protocol_name (8) */
	memcpy(param->proto_name, sp_blob_raddr, 8);
	sp_blob_raddr += 8;
	/* param_name (8) */
	memcpy(param->param_name, sp_blob_raddr, 8);
	sp_blob_raddr += 8;
	if (!param->param_size) {
		*parms_size -= param->entry_size;
		return 0;
	}
	if (param->entry_size < 24) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_INVALID_PARAM_CONFIG));
		return MC_ERROR_SPB_ID_BLOB_INVALID_PARAM_CONFIG;
	}
	value_size_in_blob = (int)param->entry_size - (int)offsetof(struct sp_param_cfg, value);

#if VALIDATION_EXCLUDED
	if (value_size_in_blob % 4) {
		pr_err("Not aligned value\n");
		return MC_ERROR_SPB_ID_BLOB_VALUE_NOT_ALIGNED;
	}
#endif
	/* read value (variable size from blob)
	 * by default value was set to zero if it's not defined in blob */
	if (value_size_in_blob > 0) {
		for (i = 0; i < value_size_in_blob; i++)
			param->value[i] = *sp_blob_raddr++;
	}
	*parms_size -= param->entry_size;
	return 0;
}

static int dpsparser_blob_load_sp_params_sect_v1(struct dpsparser *dpsparser, struct sp_blob_section *sect)
{
	struct sp_parameters_v1	sp_params;
	struct sp_param_cfg_v1	sp_param;
	int			parms_size, err;
	
	err = dpsparser_blob_get_sp_params_sect_v1(&sp_params, sect, &parms_size);
	if (err)
		return err;
	dpsparser_blob_dump_sp_params_sect_v1(&sp_params);
	do {
		err = dpsparser_blob_get_param_cfg_v1(&sp_param,
						   &parms_size);
		if (err)
			break;
		dpsparser_blob_dump_param_cfg_v1(&sp_param);
		err = dpsparser_set_param(dpsparser,
					  NULL,
					  sp_param.proto_name,
					  sp_param.flags,
					  sp_param.param_name,
					  sp_param.param_offset,
					  sp_param.param_size,
					  sp_param.value);
		if (err)
			break;
	} while (parms_size > 0 && !err);
	
	if (!err)
		pr_info("BLOB: SP Params loaded from old backward compatible Blob v1.0 successfully migrated to currently supported version\n");

	return err;
}

/******************************************************************************/

static int dpsparser_blob_alloc_profile_sect(struct dpsparser *dpsparser, struct sp_blob_section *psect)
{
	struct sp_blob_section sect;
	uint8_t	*blob_raddr = sp_blob_raddr;
	uint8_t	*sect_raddr;
	uint8_t enable_flags;
	uint16_t profiles_count = 0;
	uint16_t ingress_profiles_cnt = 0;
	uint16_t egress_profiles_cnt = 0;
	uint16_t aiop_profiles_cnt = 0;
	
	if (!blob_raddr)
		return -ENODEV;

	/* return to section head */
	blob_raddr -= sizeof(struct sp_blob_section);
	
	while (1) {
		sect_raddr = blob_raddr;
		/* Size */
		sect.size = LOAD_LE32_TO_CPU((uint32_t *)sect_raddr);
		sect_raddr += sizeof(uint32_t);
		/* TAG */
		sect.tag = LOAD_LE32_TO_CPU((uint32_t *)sect_raddr);
		sect_raddr += sizeof(uint32_t);
		
		/* Reserved (8) */
		sect_raddr += sizeof(uint64_t);

		/* Profile name (8) */
		sect_raddr += 8;

		/* Flags (1) */
		enable_flags = (uint8_t)(*sect_raddr);
		sect_raddr += 1;
		
		/* flags */
		
		if (sect.tag != SP_PROFILES_SECT) {
			break;
		}

		profiles_count++;
		
		if (enable_flags & ENABLE_ON_WRIOP_INGRESS) {
			ingress_profiles_cnt++;
		}
		if (enable_flags & ENABLE_ON_WRIOP_EGRESS) {
			egress_profiles_cnt++;
		}
		if (enable_flags & (ENABLE_ON_AIOP_INGRESS | ENABLE_ON_AIOP_EGRESS)) {
			aiop_profiles_cnt++;
		}

		/* jump to next section */
		blob_raddr += sect.size;
	}

	/* Check Number of Profiles */
	if (profiles_count > MAX_PROFILES) {
		pr_err("Profiles %d limit exceeded\n", MAX_PROFILES);
		return MC_ERROR_SPB_ID_BLOB_PROFILES_NO_EXCEEDED;
	}
	/* if (profiles_count == 0): 0 profiles count is valid */

	/* Allocate profiles array of profiles_count items for each parser */

	if (ingress_profiles_cnt > 0) {
		dpsparser->ingress_sp.profiles = (struct profile_info *)
				fsl_xmalloc(ingress_profiles_cnt * sizeof(struct profile_info), 0, CORE_CACHELINE_SIZE);
		if (!dpsparser->ingress_sp.profiles) {
			pr_err("No memory for ingress_sp profiles\n");
			return -ENOMEM;
		}
		memset(dpsparser->ingress_sp.profiles, 0, sizeof(struct profile_info));
		dpsparser->ingress_sp.alloc_profile_count = ingress_profiles_cnt;
		pr_debug("BLOB: Allocated %d profiles for ingress_sp\n", ingress_profiles_cnt);
	}

	if (egress_profiles_cnt > 0) {
		dpsparser->egress_sp.profiles = (struct profile_info *)
				fsl_xmalloc(egress_profiles_cnt * sizeof(struct profile_info), 0, CORE_CACHELINE_SIZE);
		if (!dpsparser->egress_sp.profiles) {
			pr_err("No memory for egress_sp profiles\n");
			return -ENOMEM;
		}
		memset(dpsparser->egress_sp.profiles, 0, sizeof(struct profile_info));
		dpsparser->egress_sp.alloc_profile_count = egress_profiles_cnt;
		pr_debug("BLOB: Allocated %d profiles for egress_sp\n", egress_profiles_cnt);
	}

	if (aiop_profiles_cnt > 0) {
		dpsparser->aiop_sp.profiles = (struct profile_info *)
				fsl_xmalloc(aiop_profiles_cnt * sizeof(struct profile_info), 0, CORE_CACHELINE_SIZE);
		if (!dpsparser->aiop_sp.profiles) {
			pr_err("No memory for aiop_sp profiles\n");
			return -ENOMEM;
		}
		memset(dpsparser->aiop_sp.profiles, 0, sizeof(struct profile_info));
		dpsparser->aiop_sp.alloc_profile_count = aiop_profiles_cnt;
		pr_debug("BLOB: Allocated %d profiles for aiop_sp\n", aiop_profiles_cnt);
	}
	
	return 0;
}

/******************************************************************************/

static int dpsparser_blob_load_sp_profiles_sect(struct dpsparser *dpsparser, struct sp_blob_section	*sect)
{
	struct sp_profile_cfg	sp_profile;
	struct sp_protocol_cfg	sp_pcfg;
	uint32_t		num_pr, idx;
	int err;
	
	err = dpsparser_blob_get_sp_profiles_sect(&sp_profile, sect, &num_pr);
	if (err)
		return err;

	for (idx = 0; idx < num_pr; idx++) {
		err = dpsparser_blob_get_protocol_cfg(&sp_pcfg);
		if (err)
			return err;
		dpsparser_blob_dump_protocol_cfg(&sp_pcfg);
		
		/* set protocol in profile: */
		sp_profile.protocol_cfg[idx] = sp_pcfg;				
	}

	dpsparser_blob_dump_sp_profile_sect(&sp_profile);
	
	err = dpsparser_set_profile(dpsparser, &sp_profile);

	return err;	
}

/******************************************************************************/

static int dpsparser_blob_load_sp_params_sect(struct dpsparser *dpsparser, struct sp_blob_section *sect)
{
	struct sp_parameters	sp_params;
	struct sp_param_cfg		sp_param;
	int			parms_size, err;
	
	err = dpsparser_blob_get_sp_params_sect(&sp_params, sect, &parms_size);
	if (err)
		return err;
	dpsparser_blob_dump_sp_params_sect(&sp_params);
	do {
		err = dpsparser_blob_get_param_cfg(&sp_param,
						   &parms_size);
		if (err)
			break;
		dpsparser_blob_dump_param_cfg(&sp_param);
		err = dpsparser_set_param(dpsparser,
					  sp_param.profile_name,
					  sp_param.proto_name,
					  sp_param.flags,
					  sp_param.param_name,
					  sp_param.param_offset,
					  sp_param.param_size,
					  sp_param.value);
		if (err)
			break;
	} while (parms_size > 0 && !err);
	
	return err;
}

/******************************************************************************/

void dpsparser_set_blob_address(void *blob_addr)
{
	sp_blob_address = blob_addr;
}

int dpsparser_blob_parse(struct dpsparser *dpsparser)
{
	struct sp_file_header	fhead;
	struct sp_blob_section	sect;
	struct sp_byte_code	bcode;
	uint32_t		sz;
	uint8_t			num_bytecode_sect, num_profile_sect;
	int				err;

	blob_bytes = 0;
	num_bytecode_sect = 0;
	num_profile_sect = 0;
	/* Initialize BLOB read */
	err = dpsparser_blob_init(dpsparser);
	if (err)
		return err;
	pr_info("Parsing soft parser BLOB loaded at 0x%08x ...\n", (uint32_t)sp_blob_address);
	
	/********************/
	/* Read file-header */
	/********************/
	err = dpsparser_blob_get_file_header_sect(&fhead);
	if (err)
		return err;
	pr_info("BLOB: 'file-header' section\n");
	err = dpsparser_blob_check_file_header_sect(&fhead, dpsparser);
	if (err)
		return err;
	pr_info("BLOB: 'file-header' : Valid\n");
	dpsparser_blob_dump_file_header_sect(&fhead);
	do {
		/****************************************/
		/* Read and validate a section preamble */
		/****************************************/
		err = dpsparser_blob_get_sect_preamble(&sect);
		if (err)
			continue;
		switch ((enum sp_section_tag)sect.tag) {
		case NAME_SECT:
		default:
			/******************/
			/* Read blob-name */
			/******************/
			pr_info("BLOB-NAME section\n");
			err = dpsparser_blob_get_name_sect(&blob_name, &sect);
			dpsparser_blob_dump_name_sect(&blob_name);
			break;
		case BYTE_CODE_SECT:
			pr_info("BYTE-CODE section\n");
			err = dpsparser_blob_get_bytecode_sect(&bcode, &sect,
							       &sz);
			if (err)
				break;
			/* Register it in DPSPARSER and and load it on the
			 * target HW parsers */
			err = dpsparser_load_bytecode(dpsparser,
						      bcode.byte_code,
						      bcode.offset, sz,
						      bcode.flags);
			dpsparser_blob_dump_bytecode_sect(&bcode);
			if (!err)
				num_bytecode_sect++;
			break;
		case SP_PROFILES_SECT:
			pr_info("SP-PROFILES section\n");
			if (!num_bytecode_sect) {
				pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_NO_BYTECODE_SECT_BEFORE));
				err = MC_ERROR_SPB_ID_BLOB_NO_BYTECODE_SECT_BEFORE;
				break;
			}
						
			switch (dpsparser->blob_bc_ver)
			{
			/* load current blob version */
			case 0:
				if (num_profile_sect == 0) {
					err = dpsparser_blob_alloc_profile_sect(dpsparser, &sect);
				}
				err = dpsparser_blob_load_sp_profiles_sect(dpsparser, &sect);
				break;
			/* load backward compatible blob versions */
			case 1:
				if (num_profile_sect == 0) {
					err = dpsparser_blob_alloc_profile_sect_v1(dpsparser, &sect);
				}
				err = dpsparser_blob_load_sp_profiles_sect_v1(dpsparser, &sect);
				break;
			default:
				pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_UNSUPPORTED_VERSION));
				err = MC_ERROR_SPB_ID_BLOB_UNSUPPORTED_VERSION;
				break;
			}
			if (!err)
				num_profile_sect++;
			break;
		case SP_PARAMETERS_SECT:
			pr_info("SP-PARAMETERS section\n");
			if (!num_profile_sect) {
				pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_NO_SP_PROTO_SECT_BEFORE));
				err = MC_ERROR_SPB_ID_BLOB_NO_SP_PROTO_SECT_BEFORE;
				break;
			}
			switch (dpsparser->blob_bc_ver)
			{
			/* load current blob version */
			case 0:
				err = dpsparser_blob_load_sp_params_sect(dpsparser, &sect);
				break;
			/* load backward compatible blob versions */
			case 1:
				err = dpsparser_blob_load_sp_params_sect_v1(dpsparser, &sect);
				break;
			default:
				pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_UNSUPPORTED_VERSION));
				err = MC_ERROR_SPB_ID_BLOB_UNSUPPORTED_VERSION;
				break;
			}
			break;
		}
		if (err)
			break;
	} while (blob_bytes > 0 && !err);
	if (err)
		return err;

	if (!num_bytecode_sect) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_NO_BYTECODE_SECT_DEFINED));
		err = MC_ERROR_SPB_ID_BLOB_NO_BYTECODE_SECT_DEFINED;
	}
	if (err)
		return err;

	if (!num_profile_sect) {
		pr_err(get_error_msg(MC_ERROR_SPB_ID_BLOB_NO_SP_PROTO_SECT_DEFINED));
		err = MC_ERROR_SPB_ID_BLOB_NO_SP_PROTO_SECT_DEFINED;
	}
	if (err)
		return err;

	if (!err) {
		dpsparser->applied = 1;
		pr_info("Soft Parser BLOB parsing : Completed\n");
	} else
		pr_err("Soft Parser BLOB parsing : Error detected\n");
	return err;
}

/******************************************************************************/
void dpsparser_blob_parse_end(struct dpsparser *dpsparser)
{
#ifdef SOFT_PARSER_BLOB_CHECK
	dpsparser_blob_free();
#endif
	if (!blob_name.name)
		return;
	fsl_xfree(blob_name.name);
	fsl_print("[BLOB-NAME] Free allocated BLOB name\n");
	blob_name.name = 0;
}
