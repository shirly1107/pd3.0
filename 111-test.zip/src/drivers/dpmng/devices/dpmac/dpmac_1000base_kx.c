/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpmac_1000base_kx.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/
#include "backplane.h"
#include "dpmac.h"
#include "fsl_dbg.h"
#include "fsl_timer.h"

int dpmac_set_1000base_kx_link(struct dpmac *dpmac)
{
	int err, tries, link_down;
	uint16_t data;
	uint8_t lane;

	err = serdes_mac_to_lane(&dpmac->serdes_desc, dpmac->id, 0, &lane);
	if (err)
		return err;

	/* Lane reset and reconfiguration */
	serdes_reset_lane(&dpmac->serdes_desc, lane);

	/* 1000Base_kx SerDes update */
	serdes_init_1000base_kx(&dpmac->serdes_desc, lane, dpmac->id);

	/* Adjust link timer for SGMII  -
	 For SerDes 1000BaseX auto-negotiation the timer should be 10 ms.
	 The link_timer register is configured in units of the clock.
	 - When running as 1G SGMII, SerDes clock is 125 MHz, so
	 unit = 1 / (125*10^6 Hz) = 8 ns.
	 10 ms in units of 8 ns = 10ms / 8ns = 1250000 = 0x1312d0
	 - When running as 2.5G SGMII, SerDes clock is 312.5 MHz, so
	 unit = 1 / (312.5*10^6 Hz) = 3.2 ns.
	 10 ms in units of 3.2 ns = 10ms / 3.2ns = 3125000 = 0x2faf08.
	 Since link_timer value of 1G SGMII will be too short for 2.5 SGMII,
	 we always set up here a value of 2.5 SGMII. */
	MII_WRITE(dpmac, KX_PCS, MDIO_SGMII_LINK_TMR_H, LINK_TMR_U,
		MDIO_CLAUSE45);
	MII_WRITE(dpmac, KX_PCS, MDIO_SGMII_LINK_TMR_L, LINK_TMR_L,
		MDIO_CLAUSE45);

	/* SGMII_CR : disable SGMII AN and reset PCS state machine. */
	MII_READ(dpmac, KX_PCS, MDIO_SGMII_CR, &data, MDIO_CLAUSE45);
	data |= MDIO_SGMII_CR_RST;
	data &= ~MDIO_SGMII_CR_AN_EN;
	MII_WRITE(dpmac, KX_PCS, MDIO_SGMII_CR, data, MDIO_CLAUSE45);

	/* Initialize SGMII IF Mode register:
	 * 	SGMII_EN=0
	 * 	USE_SGMII_AN=0
	 * 	SGMII_SPEED=10
	 */
	MII_WRITE(dpmac, KX_PCS, MDIO_SGMII_IF_MODE, MDIO_SGMII_IF_MODE_1G,
		  MDIO_CLAUSE45);

	/* Initialize 1000Base-KX AN Advertisement Register 1 */
	data = MDIO_KX_AN_ADVERT1_TRANS_NONCE | MDIO_KX_AN_ADVERT1_A0;
	MII_WRITE(dpmac, KX_AN, MDIO_KX_AN_ADVERT1, data, MDIO_CLAUSE45);

	/* Read 1000Base-KX AN Status Register to clear any previous status */
	MII_READ(dpmac, KX_AN, MDIO_KX_AN_SR, &data, MDIO_CLAUSE45);

	/* Initialize 1000Base-KX (Clause 45) AN Control Register:
	 * 	AN_ENAB=1
	 * 	RST_AN=1
	 */
	data = MDIO_KX_AN_CR_BP_AN_ENAB | MDIO_KX_AN_CR_RESTART_BP_AN;
	MII_WRITE(dpmac, KX_AN, MDIO_KX_AN_CR, data, MDIO_CLAUSE45);

	tries = 10000;
	do {
		link_down = dpmac_get_1000base_kx_link_state(dpmac);
		if (!link_down)
			break;
		timer_udelay(1);
	} while (--tries);

	if (!tries) {
		pr_err("ID[%d]: 1GBase-KX link is down\n", dpmac->id);
		return -EINVAL;
	}

	return 0;
}

int dpmac_get_1000base_kx_link_state(struct dpmac *dpmac)
{
	uint16_t data;

	/* Read twice, known issue */
	MII_READ(dpmac, KX_PCS, MDIO_KX_PCS_SR, &data, MDIO_CLAUSE45);
	MII_READ(dpmac, KX_PCS, MDIO_KX_PCS_SR, &data, MDIO_CLAUSE45);

	return ((data & MDIO_KX_PCS_SR_LINK_STAT) ? 0 : -EINVAL);
}
