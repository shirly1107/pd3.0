/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpmac_10gbase_kr.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/
#include "backplane.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "fsl_timer.h"
#include "dpmac.h"

/* Initialize state machine */
static void init_state_machine(struct training_state_machine *s_m)
{
	s_m->bin_m1_late_early = 1;
	s_m->bin_long_late_early = 0;
	s_m->bin_m1_stop = 0;
	s_m->bin_long_stop = 0;
	s_m->tx_complete = 0;
	s_m->an_ok = 0;
	s_m->link_up = 0;
	s_m->running = 0;
	s_m->sent_init = 0;
	s_m->m1_min_max_cnt = 0;
	s_m->long_min_max_cnt = 0;

	pr_debug("Exit\n");
}

/* Update link device (LD) coefficients */
inline static void ld_coe_update(struct xgkr_inst *inst, struct dpmac *dpmac)
{
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_LD_COEF_UPDATE,
	          (uint16_t)inst->ld_update, MDIO_CLAUSE45);

	pr_debug("Exit\n");
}

/* Update link device (LD) status */
inline static void ld_coe_status(struct xgkr_inst *inst, struct dpmac *dpmac)
{
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_LD_SRR,
	          (uint16_t)inst->ld_status, MDIO_CLAUSE45);

	pr_debug("Exit\n");
}

/* Check if transmit is complete, if so announce ready to receive */
inline static void recheck(struct xgkr_inst *inst, struct dpmac *dpmac)
{
	struct training_state_machine *s_m = &inst->t_s_m;

	if (s_m->bin_long_stop && s_m->bin_m1_stop) {
		s_m->tx_complete = 1;
		inst->ld_status |= RX_READY_MASK;
		ld_coe_status(inst, dpmac);
		/* tell LP we are ready */
		MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_PMD_SR,
		          MDIO_XFI_10GKR_PMD_SR_RX_STAT, MDIO_CLAUSE45);
	}

	pr_debug("Exit\n");
}

inline static void check_clear_preset(struct xgkr_inst *inst,
                                      uint32_t status_cop1,
                                      uint32_t status_coz,
                                      uint32_t status_com1)
{
	if ((status_cop1 == COE_UPDATED || status_cop1 == COE_MAX) &&
	    (status_coz == COE_UPDATED || status_coz == COE_MAX) &&
	    (status_com1 == COE_UPDATED || status_com1 == COE_MAX))
		inst->ld_update &= ~PRESET_MASK;
}

inline static void check_clear_initialize(struct xgkr_inst *inst,
                                          uint32_t status_cop1,
                                          uint32_t status_coz,
                                          uint32_t status_com1)
{
	if (status_cop1 != COE_NOTUPDATED &&
	    status_coz != COE_NOTUPDATED &&
	    status_com1 != COE_NOTUPDATED)
		inst->ld_update &= ~INIT_MASK;
}

inline static void check_hold_cop1(struct dpmac *dpmac,
                                   struct xgkr_inst *inst,
                                   struct training_state_machine *s_m,
                                   uint32_t req_cop1,
                                   uint32_t status_cop1)
{
	/* request to HOLD cop1 */
	inst->ld_update &= ~COP1_MASK;
	/* Stop If we have reached the limit for a parameter */
	if ((req_cop1 == DECREMENT && status_cop1 == COE_MIN) ||
	    (req_cop1 == INCREMENT && status_cop1 == COE_MAX)) {
		s_m->long_min_max_cnt++;
		if (s_m->long_min_max_cnt >= TIMEOUT_LONG) {
			s_m->bin_long_stop = 1;
			recheck(inst, dpmac);
		}
	}
}

inline static void check_hold_com1(struct dpmac *dpmac,
                                   struct xgkr_inst *inst,
                                   struct training_state_machine *s_m,
                                   uint32_t req_com1,
                                   uint32_t status_com1)
{
	/* request to HOLD com1 */
	inst->ld_update &= ~COM1_MASK;
	/* Stop If we have reached the limit for a parameter */
	if ((req_com1 == DECREMENT && status_com1 == COE_MIN) ||
	    (req_com1 == INCREMENT && status_com1 == COE_MAX)) {
		s_m->m1_min_max_cnt++;
		if (s_m->m1_min_max_cnt >= TIMEOUT_M1) {
			s_m->bin_m1_stop = 1;
			recheck(inst, dpmac);
		}
	}
}

inline static void check_bins_stop_cond(struct dpmac *dpmac,
                                        struct xgkr_inst *inst,
                                        struct training_state_machine *s_m,
                                        int bin_m1_early,
                                        int bin_long_early)
{
	if (!s_m->bin_m1_stop && !s_m->bin_m1_late_early && bin_m1_early)
		s_m->bin_m1_stop = 1;

	if (!s_m->bin_long_stop && s_m->bin_long_late_early && !bin_long_early)
		s_m->bin_long_stop = 1;

	if (s_m->bin_m1_stop || s_m->bin_long_stop)
		recheck(inst, dpmac);
}

inline static void preform_coeff_update(struct dpmac *dpmac,
                                        struct xgkr_inst *inst,
                                        struct training_state_machine *s_m,
                                        uint32_t status_com1,
                                        uint32_t status_cop1,
                                        int bin_m1_early,
                                        int bin_long_early)
{
	uint32_t temp;

	if (!s_m->bin_long_stop) {
	/* BinM1 correction means changing COM1 */
		if (!status_com1 && !(inst->ld_update & COM1_MASK)) {
		/* Avoid BinM1Late by requesting an immediate decrement. */
			if (!bin_m1_early) {
				/* request decrement c(-1) */
				temp = DECREMENT << COM1_SHIFT;
				inst->ld_update |= temp;
				ld_coe_update(inst, dpmac);
				s_m->bin_m1_late_early = bin_m1_early;
			}
		}

		/* BinLong correction means changing COP1 */
		if (!status_cop1 && !(inst->ld_update & COP1_MASK)) {
		/* Locate BinLong transition point (if any)
		 * while avoiding BinM1Late.
		 */
			if (bin_long_early) {
				/* request increment c(1) */
				temp = INCREMENT << COP1_SHIFT;
				inst->ld_update |= temp;
			} else {
				/* request decrement c(1) */
				temp = DECREMENT << COP1_SHIFT;
				inst->ld_update |= temp;
			}
			ld_coe_update(inst, dpmac);
			s_m->bin_long_late_early = bin_long_early;
		}
		/* We try to finish BinLong before we do BinM1 */
		return;
	}

	if (!s_m->bin_m1_stop) {
		/* BinM1 correction means changing COM1 */
		if (!status_com1 && !(inst->ld_update & COM1_MASK)) {
			/* Locate BinM1 transition point (if any) */
			if (bin_m1_early) {
				/* request increment c(-1) */
				temp = INCREMENT << COM1_SHIFT;
				inst->ld_update |= temp;
			} else {
				/* request decrement c(-1) */
				temp = DECREMENT << COM1_SHIFT;
				inst->ld_update |= temp;
			}

			ld_coe_update(inst, dpmac);
			s_m->bin_m1_late_early = bin_m1_early;
		}
	}
}

/*
 * Set TX equalization control bits for SerDes lane to 10GBASE-KR,
 * initialize status and coefficients
 */
static void init_inst(struct xgkr_inst *inst,
                      int reset,
                      struct dpmac *dpmac)
{
	/* set SerDesx_LNnTECR0 to 10GBASE-KR */
	if (reset) {
		inst->kr_cfg.ratio_preq = RATIO_PREQ;
		inst->kr_cfg.ratio_pst1q = RATIO_PST1Q;
		inst->kr_cfg.adpt_eq = ADPT_EQ;
		serdes_set_tx_equalization_values(&dpmac->serdes_desc,
		                                  inst->kr_cfg);
	}

	inst->ld_status &= RX_READY_MASK;
	ld_coe_status(inst, dpmac);

	/* initialize state machine */
	init_state_machine(&inst->t_s_m);

	/* set coefficients to hold (00) */
	inst->ld_update = 0;
	ld_coe_update(inst, dpmac);

	/* ld receiver is requesting that training continue */
	inst->ld_status &= ~RX_READY_MASK;
	ld_coe_status(inst, dpmac);

	pr_debug("Exit\n");
}

/* Reset link training */
static void reset_lt(struct dpmac *dpmac)
{
	/* Reset PMD control */
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_PMD_CR1,
	          MDIO_XFI_PMD_CR1_PMD_RESET_MASK, MDIO_CLAUSE45);

	/* Disable link training */
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_PMD_CR,
	          MDIO_XFI_10GKR_PMD_CR_TRAIN_DIS, MDIO_CLAUSE45);

	/* Set zeros to MDIO_XFI_10GKR_LD_COEF_UPDATE */
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_LD_COEF_UPDATE, 0,
	          MDIO_CLAUSE45);

	/* Set zeros to MDIO_XFI_10GKR_LD_SRR */
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_LD_SRR, 0, MDIO_CLAUSE45);

	/* Set zeros to MDIO_XFI_10GKR_PMD_SR */
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_PMD_SR, 0, MDIO_CLAUSE45);

	/* Set zeros to MDIO_XFI_10GKR_LP_COEF_UPDATE */
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_LP_COEF_UPDATE, 0,
	          MDIO_CLAUSE45);

	/* Set zeros to MDIO_XFI_10GKR_LP_SRR */
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_LP_SRR, 0, MDIO_CLAUSE45);

	pr_debug("Exit\n");
}

/* Start auto-negotiation to detect link partner */
static int start_an(struct dpmac *dpmac)
{
	uint16_t reg16;
	int tries;

	/* Reset link training */
	reset_lt(dpmac);

	/* Reset PCS control */
	MII_WRITE(dpmac, XFI_PCS, MDIO_XFI_PCS_CR1, MDIO_XFI_PCS_CR1_RESET,
	          MDIO_CLAUSE45);

	/* Advertise 10GBase-KR capability */
	MII_WRITE(dpmac, XFI_AN, MDIO_XFI_AN_ADVERT1,
	          MDIO_XFI_AN_ADVERT1_KR_ADV, MDIO_CLAUSE45);

	/* Start Auto Negotiation */
	MII_WRITE(dpmac, XFI_AN, MDIO_XF_AN_CR,
	          MDIO_XF_AN_CR_AN_EN_AND_RESTART, MDIO_CLAUSE45);

	/* check if auto-negotiation set to 10GBase-KR */
	tries = 10000;
	do {
		MII_READ(dpmac, XFI_AN, MDIO_XFI_BP_STAT, &reg16, MDIO_CLAUSE45);
	} while (!(reg16 & MDIO_XFI_BP_STAT_10GBASE_KR) && --tries);

	if (!tries) {
		pr_err ("ID[%d]: Couldn't detect 10GBase-KR link partner\n");
		return -EINVAL;
	}

	return 0;
}

/* Start link training */
static int start_lt(struct dpmac *dpmac)
{
	/* 10GBase-KR startup protocol enabled */
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_PMD_CR,
	          MDIO_XFI_10GKR_PMD_CR_TRAIN_EN, MDIO_CLAUSE45);

	return 0;
}

/* Stop link training */
static void stop_lt(struct dpmac *dpmac)
{
	MII_WRITE(dpmac, XFI_PMD, MDIO_XFI_10GKR_PMD_CR,
	          MDIO_XFI_10GKR_PMD_CR_TRAIN_DIS, MDIO_CLAUSE45);

	pr_debug("Exit\n");
}

static void initialize(struct xgkr_inst *inst, struct dpmac *dpmac)
{
	inst->kr_cfg.ratio_preq = RATIO_PREQ;
	inst->kr_cfg.ratio_pst1q = RATIO_PST1Q;
	inst->kr_cfg.adpt_eq = ADPT_EQ;

	serdes_set_tx_equalization_values(&dpmac->serdes_desc,
	                                  inst->kr_cfg);

	/* reset coefficients */
	inst->ld_status &= ~(COP1_MASK | COZ_MASK | COM1_MASK);

	/* update coefficients */
	inst->ld_status |= COE_UPDATED << COP1_SHIFT | COE_UPDATED << COZ_SHIFT
	                   | COE_UPDATED << COM1_SHIFT;

	ld_coe_status(inst, dpmac);

	pr_debug("Exit\n");
}

/* Check if receiver is ready */
static int check_rx_ready(struct dpmac *dpmac)
{
	int err = 0;
	uint16_t reg16;

	MII_READ(dpmac, XFI_PMD, MDIO_XFI_10GKR_LP_SRR, &reg16, MDIO_CLAUSE45);

	if (!(reg16 & RX_READY_MASK))
		err = -EINVAL;

	return err;
}

/* Set coefficients to maximum */
static void preset(struct xgkr_inst *inst, struct dpmac *dpmac)
{
	/* set coefficients to maximum- these are all MAX values from the IEEE802.3 perspective */
	inst->kr_cfg.ratio_pst1q = POST_COE_MAX;
	inst->kr_cfg.adpt_eq = ZERO_COE_MAX;
	inst->kr_cfg.ratio_preq = PRE_COE_MAX;

	serdes_set_tx_equalization_values(&dpmac->serdes_desc,
	                                  inst->kr_cfg);

	/* set coefficients status to maximum */
	inst->ld_status &= ~(COP1_MASK | COZ_MASK | COM1_MASK);
	inst->ld_status |= COE_MAX << COP1_SHIFT | COE_MAX << COZ_SHIFT
	                   | COE_MAX << COM1_SHIFT;
	ld_coe_status(inst, dpmac);

	pr_debug("Exit\n");
}

/* Check HW restrictions for coefficient values */
static int is_ld_valid(uint32_t *ld_coe)
{
	uint32_t ratio_pst1q = *ld_coe;
	uint32_t adpt_eq = *(ld_coe + 1);
	uint32_t ratio_preq = *(ld_coe + 2);

	/* HW restrictions of coefficient values */
	if ((ratio_pst1q + adpt_eq + ratio_preq) > 48)
		return 0;

	if (((ratio_pst1q + adpt_eq + ratio_preq) * 4)
	    >= ((adpt_eq - ratio_pst1q - ratio_preq) * 17))
		return 0;

	if (ratio_preq > ratio_pst1q)
		return 0;

	if (ratio_preq > 8)
		return 0;

	if (adpt_eq < 26)
		return 0;

	if (ratio_pst1q > 16)
		return 0;

	return 1;
}

/* Calculate new coefficients value according to LP request */
static int inc_dec(struct xgkr_inst *inst,
                   int field,
                   int request,
                   struct dpmac *dpmac)
{
	uint32_t ld_limit[3], ld_coe[3];
	int step[3];

	ld_coe[0] = inst->kr_cfg.ratio_pst1q;
	ld_coe[1] = inst->kr_cfg.adpt_eq;
	ld_coe[2] = inst->kr_cfg.ratio_preq;

	/* Information specific to the Freescale SerDes for 10GBase-KR:
	 * Incrementing C(+1) means *decrementing* RATIO_PST1Q
	 * Incrementing C(0) means *incrementing* ADPT_EQ
	 * Incrementing C(-1) means *decrementing* RATIO_PREQ
	 */
	step[0] = -1;
	step[1] = 1;
	step[2] = -1;

	switch (request) {
	case INCREMENT:
		ld_limit[0] = POST_COE_MAX;
		ld_limit[1] = ZERO_COE_MAX;
		ld_limit[2] = PRE_COE_MAX;
		if (ld_coe[field] != ld_limit[field])
			ld_coe[field] += step[field];
		else {
			/* MAX */
			pr_debug("Exit\n");
			return 2;
		}
		break;
	case DECREMENT:
		ld_limit[0] = POST_COE_MIN;
		ld_limit[1] = ZERO_COE_MIN;
		ld_limit[2] = PRE_COE_MIN;
		if (ld_coe[field] != ld_limit[field])
			ld_coe[field] -= step[field];
		else {
			/* MIN */
			pr_debug("Exit\n");
			return 1;
		}
		break;
	default:
		break;
	}

	/* Check HW restrictions for coefficient values */
	if (is_ld_valid(ld_coe)) {
		/* accept new ld */
		inst->kr_cfg.ratio_pst1q = ld_coe[0];
		inst->kr_cfg.adpt_eq = ld_coe[1];
		inst->kr_cfg.ratio_preq = ld_coe[2];
		serdes_set_tx_equalization_values(&dpmac->serdes_desc,
		                                  inst->kr_cfg);
	} else {
		if (request == DECREMENT) {
			/* MIN */
			pr_debug("Exit\n");
			return 1;
		}
		if (request == INCREMENT) {
			/* MAX */
			pr_debug("Exit\n");
			return 2;
		}
	}

	pr_debug("Exit\n");
	return 0;
}

/* Update LD status according to previous operation */
static void min_max_updated(struct xgkr_inst *inst, int field, int new_ld)
{
	uint32_t ld_coe[] = { COE_UPDATED, COE_MIN, COE_MAX };
	uint32_t mask, val;

	switch (field) {
	case COE_COP1:
		mask = COP1_MASK;
		val = ld_coe[new_ld] << COP1_SHIFT;
		break;
	case COE_COZ:
		mask = COZ_MASK;
		val = ld_coe[new_ld] << COZ_SHIFT;
		break;
	case COE_COM1:
		mask = COM1_MASK;
		val = ld_coe[new_ld] << COM1_SHIFT;
		break;
	default:
		return;
		break;
	}

	/* update ld status */
	inst->ld_status &= ~mask;
	inst->ld_status |= val;

	pr_debug("Exit\n");
}

/* Check LP request and act accordingly */
static void check_request(struct xgkr_inst *inst,
                          struct dpmac *dpmac,
                          int request)
{
	int cop1_req, coz_req, com1_req;
	uint32_t old_status;
	int new_ld_sta;

	/* check coefficient update request:
	 * 11 = reserved
	 * 10 = decrement
	 * 01 = increment
	 * 00 = hold
	 * */
	cop1_req = (request & COP1_MASK) >> COP1_SHIFT;
	coz_req = (request & COZ_MASK) >> COZ_SHIFT;
	com1_req = (request & COM1_MASK) >> COM1_SHIFT;

	/* IEEE802.3-2008, 72.6.10.2.5
	 * Ensure we only act on INCREMENT/DECREMENT when we are in NOT UPDATED (=00)
	 */
	old_status = inst->ld_status;

	/* if inst->ld_status is not updated calculate new status */
	if (cop1_req && !(inst->ld_status & COP1_MASK)) {
		new_ld_sta = inc_dec(inst, COE_COP1, cop1_req, dpmac);
		min_max_updated(inst, COE_COP1, new_ld_sta);
	}

	/* if inst->ld_status is not updated calculate new status */
	if (coz_req && !(inst->ld_status & COZ_MASK)) {
		new_ld_sta = inc_dec(inst, COE_COZ, coz_req, dpmac);
		min_max_updated(inst, COE_COZ, new_ld_sta);
	}

	/* if inst->ld_status is not updated calculate new status */
	if (com1_req && !(inst->ld_status & COM1_MASK)) {
		new_ld_sta = inc_dec(inst, COE_COM1, com1_req, dpmac);
		min_max_updated(inst, COE_COM1, new_ld_sta);
	}

	/* update status */
	if (old_status != inst->ld_status)
		ld_coe_status(inst, dpmac);

	pr_debug("Exit\n");
}

static int check_train_frame_lock(struct dpmac *dpmac, uint16_t reg16)
{
	int err;

	/* If MDIO_XFI_10GKR_PMD_SR_SUP_STAT and
	 * MDIO_XFI_10GKR_PMD_SR_FRAME_LOCK are on - frame lock detected
	 */
	if ((reg16 & MDIO_XFI_10GKR_PMD_SR_SUP_STAT) &&
	    (reg16 & MDIO_XFI_10GKR_PMD_SR_FRAME_LOCK))
		err = 0;
	else
		err = -EINVAL;

	return err;

}

/* Check if link is up */
static int check_an_link(struct dpmac *dpmac)
{
	uint16_t val;
	int timeout = 100;

	while (timeout--) {
		MII_READ(dpmac, XFI_AN, MDIO_XF_AN_SR, &val, MDIO_CLAUSE45);

		/* check if link is up */
		if (val & MDIO_XF_AN_SR_LNK_STAT)
			return 1;
		//usleep_range(100, 500); TODO
	}

	pr_debug("Exit\n");
	return 0;
}

/* Check if link training failed */
static int is_link_training_fail(struct dpmac *dpmac)
{
	uint16_t val;

	MII_READ(dpmac, XFI_PMD, MDIO_XFI_10GKR_PMD_SR, &val, MDIO_CLAUSE45);
	if (!(val & MDIO_XFI_10GKR_PMD_SR_TRAIN_FAIL) && (val & MDIO_XFI_10GKR_PMD_SR_RX_STAT)) {
		/* check if link is up */
		if (check_an_link(dpmac)) {
			pr_debug("Exit\n");
			return 0;
		}pr_debug("Exit\n");
		return 1;
	}

	pr_debug("Exit\n");
	return 1;
}

/* Receiver training process */
static void train_rx(struct xgkr_inst *inst, struct dpmac *dpmac)
{
	uint32_t old_ld_status = 0;
	uint16_t request;

	/* get request from LP (link partner) and save old status */
	MII_READ(dpmac, XFI_PMD, MDIO_XFI_10GKR_LP_COEF_UPDATE, &request, MDIO_CLAUSE45);
	request = request & (LD_ALL_MASK);

	/* IEEE802.3-2008, 72.6.10.2.5
	 * Ensure we always go to NOT UDPATED for status reporting in
	 * response to HOLD requests.
	 * IEEE802.3-2008, 72.6.10.2.3.1/2
	 * ... but only if PRESET/INITIALIZE are not active to ensure
	 * we keep status until they are released!
	 */
	if (!(request & (PRESET_MASK | INIT_MASK))) {

		/* coefficient (+1) request is hold (=00)
		 * update coefficient status to not updated */
		if (!(request & COP1_MASK))
			inst->ld_status &= ~COP1_MASK;

		/* coefficient (0) request is hold (=00)
		 * update coefficient status to not updated */
		if (!(request & COZ_MASK))
			inst->ld_status &= ~COZ_MASK;

		/* coefficient (-1) request is hold (=00)
		 * update coefficient status to not updated*/
		if (!(request & COM1_MASK))
			inst->ld_status &= ~COM1_MASK;

		/* update status */
		if (old_ld_status != inst->ld_status)
			ld_coe_status(inst, dpmac);
	}

	/* As soon as the LP shows ready, no need to do any more updates */
	if (check_rx_ready(dpmac)) {
		/* LP receiver has determined that training is complete and is prepared to receive data */
		if (inst->ld_status & (COP1_MASK | COZ_MASK | COM1_MASK)) {
			inst->ld_status &= ~(COP1_MASK | COZ_MASK | COM1_MASK);
			ld_coe_status(inst, dpmac);
		}
	} else {
		if (request & (PRESET_MASK | INIT_MASK)) {
			/* only act on PRESET/INITIALIZE if all status is NOT UPDATED */
			if (!(inst->ld_status &
				(COP1_MASK | COZ_MASK | COM1_MASK))) {
				if (request & PRESET_MASK)
					preset(inst, dpmac);
				if (request & INIT_MASK)
					initialize(inst, dpmac);
			}
		}

		/* LP Coefficient are not in HOLD */
		if (request & REQUEST_MASK)
			check_request(inst, dpmac, request & REQUEST_MASK);
	}

	pr_debug("Exit\n");
}

/* Transmitter training process */
static void train_tx(struct xgkr_inst *inst, struct dpmac *dpmac)
{
	struct training_state_machine *s_m = &inst->t_s_m;
	int bin_m1_early, bin_long_early;
	uint32_t lp_status, old_ld_update;
	uint32_t status_cop1, status_coz, status_com1;
	uint32_t req_cop1, req_coz, req_com1, req_preset, req_init;
	uint16_t request;

	/* We start by checking the current LP status. If we got any responses,
	 * we can clear up the appropriate update request so that the
	 * subsequent code may easily issue new update requests if needed.
	 */

	/* check LP status for all coefficients */
	MII_READ(dpmac, XFI_PMD, MDIO_XFI_10GKR_LP_SRR, &request, MDIO_CLAUSE45);
	lp_status = (uint32_t)request & REQUEST_MASK;

	status_cop1 = (lp_status & COP1_MASK) >> COP1_SHIFT;
	status_coz = (lp_status & COZ_MASK) >> COZ_SHIFT;
	status_com1 = (lp_status & COM1_MASK) >> COM1_SHIFT;

	/* check old request for coefficient update */
	old_ld_update = inst->ld_update;
	req_cop1 = (old_ld_update & COP1_MASK) >> COP1_SHIFT;
	req_coz = (old_ld_update & COZ_MASK) >> COZ_SHIFT;
	req_com1 = (old_ld_update & COM1_MASK) >> COM1_SHIFT;
	req_preset = old_ld_update & PRESET_MASK;
	req_init = old_ld_update & INIT_MASK;

	/* IEEE802.3-2008, 72.6.10.2.3.1
	 * We may clear PRESET when ALL coefficients show UPDATED or MAX.
	 */
	if (req_preset)
		check_clear_preset(inst, status_cop1, status_coz, status_com1);

	/* IEEE802.3-2008, 72.6.10.2.3.2
	 * We may clear INITIALIZE when no coefficients show NOT UPDATED.
	 */
	if (req_init)
		check_clear_initialize(inst, status_cop1, status_coz, status_com1);

	/* IEEE802.3-2008, 72.6.10.2.3.2
	 * we send initialize to the other side to ensure default settings
	 * for the LP. Naturally, we should do this only once.
	 */
	if (!s_m->sent_init) {
		if (!lp_status && !(old_ld_update & (LD_ALL_MASK))) {
			inst->ld_update |= INIT_MASK;
			s_m->sent_init = 1;
		}
	}

	/* IEEE802.3-2008, 72.6.10.2.3.3
	 * We set coefficient requests to HOLD when we get the information
	 * about any updates. On clearing our prior response, we also update
	 * our internal status.
	 */
	if ((status_cop1 != COE_NOTUPDATED) && (req_cop1))
		check_hold_cop1(dpmac, inst, s_m, req_cop1, status_cop1);

	if ((status_coz != COE_NOTUPDATED) && (req_coz))
		inst->ld_update &= ~COZ_MASK; /* request to HOLD coz */

	if ((status_com1 != COE_NOTUPDATED) && (req_com1))
		check_hold_com1(dpmac, inst, s_m, req_com1, status_com1);

	if (old_ld_update != inst->ld_update) {
		ld_coe_update(inst, dpmac);
		/* Redo these status checks and updates until we have no more
		 * changes, to speed up the overall process.
		 */
		recheck(inst, dpmac);
	}

	/* snapshot and select bin */
	bin_m1_early = serdes_check_bin_status(&dpmac->serdes_desc,
	                                       SERDES_10GBASE_KR_BIN_M1,
	                                       inst->kr_cfg.lane);
	bin_long_early = serdes_check_bin_status(&dpmac->serdes_desc,
	                                         SERDES_10GBASE_KR_BIN_LONG,
	                                         inst->kr_cfg.lane);

	check_bins_stop_cond(dpmac, inst, s_m, bin_m1_early, bin_long_early);

	/* IEEE802.3-2008, 72.6.10.2.3.3
	 * We only request coefficient updates when no PRESET/INITIALIZE is
	 * pending! We also only request coefficient updates when the
	 * corresponding status is NOT UPDATED and nothing is pending.
	 */
	if (!(inst->ld_update & (PRESET_MASK | INIT_MASK)))
		preform_coeff_update(dpmac, inst, s_m, status_com1, status_cop1,
		                     bin_m1_early, bin_long_early);

	pr_debug("Exit\n");
}

static int preform_link_training(struct dpmac *dpmac, struct xgkr_inst *inst)
{
	int rx_ok, tx_ok;

	rx_ok = !!check_rx_ready(dpmac);
	tx_ok = inst->t_s_m.tx_complete;

	if (rx_ok && tx_ok)
		return 0;

	/* receive process */
	if (!rx_ok) {
		train_rx(inst, dpmac);
	}

	/* transmit process */
	if (!tx_ok)
		train_tx(inst, dpmac);

	timer_udelay(100);

	return LINK_TRAIN_CONTINUE;
}

int dpmac_set_10gbase_kr_link(struct dpmac *dpmac)
{
	struct xgkr_inst inst;
	int i, err;
	uint16_t reg16 = 0;
	uint8_t lane;
	uint64_t curr_time, target_time;

	err = serdes_mac_to_lane(&dpmac->serdes_desc, dpmac->id, 0, &lane);
	if (err)
		return err;

	memset(&inst, 0, sizeof(struct xgkr_inst));
	inst.kr_cfg.lane = lane;

	/* Set SerDes lane to 10GBASE-KR, initialize status and coefficients */
	init_inst(&inst, 1, dpmac);

	/* start auto-negotiation */
	err = start_an(dpmac);
	if (err)
		return err;

	/* The link training occurs after auto-negotiation has determined the link
	 *  to be a 10G Base-KR link
	 */
	start_lt(dpmac);

	for (i = 0; i < 2;) {
		curr_time = timer_current_time();
		target_time = curr_time + 500;
		while (timer_current_time() < target_time) {
			MII_READ(dpmac, XFI_PMD, MDIO_XFI_10GKR_PMD_SR, &reg16, MDIO_CLAUSE45);
			/* Training failed - retry */
			if (reg16 & MDIO_XFI_10GKR_PMD_SR_TRAIN_FAIL) {
				serdes_reset_lane(&dpmac->serdes_desc, lane);
				start_lt(dpmac);

			/* Training and frame lock detected */
			} else if (check_train_frame_lock(dpmac, reg16) == 0) {
				break;
			}

			timer_udelay(100);
		}

		/* Training and frame lock not detected */
		if (check_train_frame_lock(dpmac, reg16) != 0) {
			i++;
			continue;
		}

		/* the LT should be finished in 500ms, failed or OK */
		curr_time = timer_current_time();
		target_time = curr_time + 500;

		while (timer_current_time() < target_time) {
			/* check if the LT is already failed */
			MII_READ(dpmac, XFI_PMD, MDIO_XFI_10GKR_PMD_SR, &reg16, MDIO_CLAUSE45);
			if (reg16 & MDIO_XFI_10GKR_PMD_SR_TRAIN_FAIL) {
				serdes_reset_lane(&dpmac->serdes_desc, lane);
				break;
			}

			if (preform_link_training(dpmac, &inst) == 0)
				break;
		}

		i++;

		/* check LT result */
		if (is_link_training_fail(dpmac)) {
			/* reset state machine */
			init_inst(&inst, 0, dpmac);
			continue;
		} else {
			stop_lt(dpmac);
			inst.t_s_m.running = 0;
			inst.t_s_m.link_up = 1;
			break;
		}
	}

	if (!inst.t_s_m.link_up) {
		/* reset state machine */
		init_inst(&inst, 0, dpmac);
		return -EINVAL;
	}

	return 0;
}

int dpmac_get_10gbase_kr_link_state(struct dpmac *dpmac)
{
	uint16_t data;

	/* Read twice, known issue */
	MII_READ(dpmac, XFI_AN, MDIO_XF_AN_SR, &data, MDIO_CLAUSE45);
	MII_READ(dpmac, XFI_AN, MDIO_XF_AN_SR, &data, MDIO_CLAUSE45);

	return ((data & MDIO_XF_AN_SR_LNK_STAT) ? 0 : -EINVAL);
}
