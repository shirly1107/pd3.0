/*
 * Copyright 2013-2020 NXP
 */

#ifndef _LEGACY_DPMAC_DPLIB_H
#define _LEGACY_DPMAC_DPLIB_H

/* 
 * File used to maintain compatibility with older version of dplib/flib
 * All previous version of dpmac commands should be placed here
 * 
 */
/**********************************************/
/**********************************************/
/********* V0 version of dpmac commands ******/
/**********************************************/
/**********************************************/

/*                cmd, param, offset, width, type,      arg_name */
#define DPMAC_RSP_GET_ATTRIBUTES_V0(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, int,                  (attr)->phy_id);\
	MC_RSP_OP(cmd, 0, 32, 32, int,                  (attr)->id);\
	MC_RSP_OP(cmd, 1,  0, 16, uint16_t,             (attr)->version.major);\
	MC_RSP_OP(cmd, 1, 16, 16, uint16_t,             (attr)->version.minor);\
	MC_RSP_OP(cmd, 1, 32,  8, enum dpmac_link_type, (attr)->link_type);\
	MC_RSP_OP(cmd, 1, 40,  8, enum dpmac_eth_if,    (attr)->eth_if);\
	MC_RSP_OP(cmd, 2,  0, 32, uint32_t,             (attr)->max_rate);\
} while (0)

/*                cmd, param, offset, width, type,	arg_name */
#define DPMAC_RSP_GET_ATTRIBUTES_V1(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0,  8, uint8_t,  (attr)->eth_if);\
	MC_RSP_OP(cmd, 0,  8,  8, uint8_t,  (attr)->link_type);\
	MC_RSP_OP(cmd, 0, 16, 16, uint16_t, (attr)->id);\
	MC_RSP_OP(cmd, 0, 32, 32, uint32_t, (attr)->max_rate);\
} while (0)

/*                cmd, param, offset, width, type,	arg_name */
#define DPMAC_RSP_GET_ATTRIBUTES_V2(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0,  8, uint8_t,  (attr)->eth_if);\
	MC_RSP_OP(cmd, 0,  8,  8, uint8_t,  (attr)->link_type);\
	MC_RSP_OP(cmd, 0, 16, 16, uint16_t, (attr)->id);\
	MC_RSP_OP(cmd, 0, 32, 32, uint32_t, (attr)->max_rate);\
	MC_RSP_OP(cmd, 1,  0,  8, uint8_t,  (attr)->fec_mode);\
	MC_RSP_OP(cmd, 2,  0,  1, uint8_t,  (attr)->serdes_cfg.sgn_post1q);\
	MC_RSP_OP(cmd, 2,  1,  1, uint8_t,  (attr)->serdes_cfg.sgn_preq);\
	MC_RSP_OP(cmd, 2,  8,  8, uint8_t,  (attr)->serdes_cfg.cfg);\
	MC_RSP_OP(cmd, 2, 16,  8, uint8_t,  (attr)->serdes_cfg.eq_amp_red);\
	MC_RSP_OP(cmd, 2, 24,  8, uint8_t,  (attr)->serdes_cfg.eq_post1q);\
	MC_RSP_OP(cmd, 2, 32,  8, uint8_t,  (attr)->serdes_cfg.eq_preq);\
	MC_RSP_OP(cmd, 2, 40,  8, uint8_t,  (attr)->serdes_cfg.eq_type);\
} while (0)

#define DPMAC_CMD_CREATE_v0(cmd, cfg) \
	MC_CMD_OP(cmd, 0, 0,  32, int,      cfg->mac_id)

/*                cmd, param, offset, width, type, arg_name */
#define DPMAC_CMD_MDIO_READ(cmd, cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,   uint8_t,   cfg->cl45); \
	MC_CMD_OP(cmd, 0, 8,  8,   uint8_t,   cfg->phy_addr); \
	MC_CMD_OP(cmd, 0, 16, 16,  uint16_t,  cfg->reg); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPMAC_RSP_MDIO_READ(cmd, data) \
	MC_RSP_OP(cmd, 0, 0, 16, uint16_t, data)

/*                cmd, param, offset, width, type, arg_name */
#define DPMAC_CMD_MDIO_WRITE(cmd, cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,   uint8_t,   cfg->cl45); \
	MC_CMD_OP(cmd, 0, 8,  8,   uint8_t,   cfg->phy_addr); \
	MC_CMD_OP(cmd, 0, 16, 16,  uint16_t,  cfg->reg); \
	MC_CMD_OP(cmd, 0, 32, 16,  uint16_t,  cfg->data); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPMAC_CMD_SET_IRQ(cmd, irq_index, irq_cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,  irq_index);\
	MC_CMD_OP(cmd, 0, 32, 32, uint32_t, irq_cfg->val);\
	MC_CMD_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr); \
	MC_CMD_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPMAC_CMD_GET_IRQ(cmd, irq_index) \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index)

/*                cmd, param, offset, width, type, arg_name */
#define DPMAC_RSP_GET_IRQ(cmd, type, irq_cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, irq_cfg->val); \
	MC_RSP_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr); \
	MC_RSP_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
	MC_RSP_OP(cmd, 2, 32, 32, int,	    type); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPMAC_RSP_GET_LINK_CFG_V1(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  64, uint64_t, cfg->options); \
	MC_RSP_OP(cmd, 1, 0,  32, uint32_t, cfg->rate); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPMAC_CMD_SET_LINK_STATE_V1(cmd, cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  64, uint64_t, cfg->options); \
	MC_CMD_OP(cmd, 1, 0,  32, uint32_t, cfg->rate); \
	MC_CMD_OP(cmd, 2, 0,  1,  int,      cfg->up); \
} while (0)

#endif /* _LEGACY_DPMAC_DPLIB_H */
