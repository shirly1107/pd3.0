/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpmac.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_timer.h"

#include "fsl_eiop_port.h"
#include "fsl_eiop_memac.h"
#include "fsl_linkman.h"
#include "fsl_resman.h"
#include "fsl_dpmng_mc.h"

#include "dpmac.h"
#include "dpc.h"
#include "backplane.h"
#include "dpc.h"

extern int in_dpl_processing;

static struct pcs_fec_regs pcs_fc_fec_regs[] = {
		{ 0x8010, 0x0307, 0, 0 },
		{    0x0, 0x8000, 1, 0 },
};

static struct pcs_fec_regs pcs_rs_fec_regs[] = {
		{ 0x8010, 0x0005, 0, 0 },
		{ 0x8002, 0x4fff, 0, 0 },
		{ 0x8008, 0x68c1, 0, 1 },
		{ 0x8009, 0x0021, 0, 1 },
		{    0x0, 0x8000, 1, 0 },
};

static struct pcs_fec_regs pcs_no_fec_regs[] = {
		{ 0x8010, 0x0303, 0, 0 },
		{ 0x8002, 0x3fff, 0, 0 },
		{ 0x8008, 0x7690, 0, 1 },
		{ 0x8009, 0x0047, 0, 1 },
		{    0x0, 0x2040, 1, 0 }, // 0x8000 may be the command for applying settings
};

#ifdef TKT320141
extern int serdes_reset_receiver_lane(struct serdes_desc *desc,
	int mac_id, uint8_t master_lane, uint8_t no_lanes, enum enet_interface);
#endif
extern int serdes_eq_setup(struct serdes_desc *, int, struct serdes_eq_settings *);
extern void serdes_setup_fec_dispatch(struct serdes_desc *, int, enum dpmac_fec_mode);
extern void serdes_set_fault(struct serdes_desc *, int, enum serdes_fault_type, uint8_t);
/*****************************************************************************/
/*                      Internal routines                                    */
/*****************************************************************************/
static int mii_write_phy_reg(struct dpmac *dpmac, uint8_t phyAddr, uint32_t reg,
                             uint16_t data, int clause)
{
	return eiop_memac_mii_write_phy_reg(dpmac->mac_mii_regs,
	                                    phyAddr,
	                                    reg,
	                                    data,
	                                    clause);
}

static int mii_read_phy_reg(struct dpmac *dpmac, uint8_t phyAddr, uint32_t reg,
                            uint16_t *p_Data, int clause)
{
	return eiop_memac_mii_read_phy_reg(dpmac->mac_mii_regs,
	                                   phyAddr,
	                                   reg,
	                                   p_Data,
	                                   clause);
}

static void port_enable(struct dpmac *dpmac)
{
	/* Enable PP */
	eiop_port_rx_enable(&(dpmac->port_desc));
	eiop_port_tx_enable(&(dpmac->port_desc));
}

static int port_disable(struct dpmac *dpmac)
{
	int err;

	err = eiop_port_rx_graceful_stop(&(dpmac->port_desc));
	if (err != 0)
		return err;


	err = eiop_port_tx_graceful_stop(&(dpmac->port_desc));
	if (err != 0)
		return err;

	return 0;
}

static int mac_disable (struct dpmac *dpmac)
{
	int err;

	err = eiop_memac_rx_graceful_stop(&(dpmac->mac_desc));
	if (err)
		return err;
	err = eiop_memac_tx_graceful_stop(&(dpmac->mac_desc));
	if (err)
		return err;

	return 0;
}

static int port_init(struct dpmac *dpmac, int ifpid)
{
	int err;
	struct eiop_port_init_params port_params;
	uint32_t rate;

	/* eiop_params */
	rate = dpmac->rate;
	port_params.type = EIOP_ETHERNET_PORT;
	port_params.default_ingress_ifpid = (uint16_t)ifpid;
	switch (rate) {
	case (1000):
		port_params.rate = EIOP_PORT_RATE_1_G;
		break;
	case (2500):
		port_params.rate = EIOP_PORT_RATE_2_5_G;
		break;
	case (10000):
		port_params.rate = EIOP_PORT_RATE_10_G;
		break;
	case (25000):
		port_params.rate = EIOP_PORT_RATE_25_G;
		break;
	case (40000):
		port_params.rate = EIOP_PORT_RATE_40_G;
		break;
	case (50000):
		port_params.rate = EIOP_PORT_RATE_50_G;
		break;
	case (100000):
		port_params.rate = EIOP_PORT_RATE_100_G;
		break;
	}

	if(!dpmac->restore){
		/*! Get connection descriptor */
		memset(&(dpmac->connection_desc),
			0x0,
			sizeof(struct pport_connections_desc));
		dpmac->connection_desc.mac_id = dpmac->id;
		dpmac->connection_desc.eiop_id = dpmac->eiop_id;
		err = sys_get_desc(SOC_MODULE_EIOP_PPORT_CON,
						   SOC_DB_PORT_CON_DESC_MAC_ID |
						   SOC_DB_PORT_CON_DESC_EIOP_ID,
						   &(dpmac->connection_desc),
						   NULL);
		if (err != 0)
			return err;
	
		/*! Get physical port descriptor */
		dpmac->port_desc.eiop_id = dpmac->connection_desc.eiop_id;
		dpmac->port_desc.port_id = dpmac->connection_desc.port_id;
		err = sys_get_desc(SOC_MODULE_EIOP_PORT,
						   SOC_DB_PORT_DESC_EIOP_ID | SOC_DB_PORT_DESC_ID,
						   &(dpmac->port_desc),
						   NULL);
	
		dpmac->ppid = dpmac->port_desc.port_id;
	
		if (err != 0)
			return err;
	}
	/*! Initialize physical port */
	err = eiop_port_init(&(dpmac->port_desc), &port_params, 0);

	return err;
}

static int port_set_ifp(struct dpmac *dpmac)
{
	int err;

	err = port_disable(dpmac);
	if (err != 0)
		return err;

	err = eiop_port_set_default_ingress_ifpid(&(dpmac->port_desc),
							dpmac->ifpid);

	/* PPID should be always enabled */
	port_enable(dpmac);

	return err;
}

static int invoke_inter(struct dpmac *dpmac, uint8_t index, uint32_t event)
{
	event_send(&(dpmac->irqs[index]), event);

	return 0;
}

static int dpmac_save_descriptors(struct dpmac *dpmac, int mac_id)
{
	struct eiop_memac_desc eiop_memac_desc = {0};
	struct eiop_port_desc eiop_port_desc = {0};
	struct serdes_desc serdes_desc = {0};
	int err;

	/* Get descriptors */
	eiop_memac_desc.mac_id = mac_id;
	err = sys_get_desc(SOC_MODULE_EIOP_MEMAC,
	                   SOC_DB_MAC_DESC_ID,
	                   &eiop_memac_desc,
	                   NULL);
	if (err) {
		pr_err("ID[%d]: Invalid MAC Id", mac_id);
		return -ENODEV;
	}

	if (eiop_memac_desc.disable) {
		pr_err ("ID[%d] disabled, can't initialize\n", mac_id);
		return -ENODEV;
	}

	eiop_port_desc.port_id = mac_id;
	err = sys_get_desc(SOC_MODULE_EIOP_PORT,
	                   SOC_DB_PORT_DESC_ID,
			   &eiop_port_desc,
			   NULL);
	if (err) {
		pr_err("Failed to create DPMAC! MAC id %d is not supported\n", eiop_port_desc.port_id);
		return -EINVAL;
	}

	serdes_desc.id = eiop_memac_desc.serdes_id;
	err = sys_get_desc(SOC_MODULE_SERDES,
	                   SOC_DB_SERDES_DESC_ID,
	                   &serdes_desc,
	                   NULL);
	if (err) {
		pr_err("Failed to receive SerDes:%d descriptor\n", eiop_memac_desc.serdes_id);
		return -ENODEV;
	}

	/* Copy descriptor */
	memcpy(&(dpmac->mac_desc), &(eiop_memac_desc),
		sizeof(struct eiop_memac_desc));
	memcpy(&(dpmac->port_desc), &(eiop_port_desc),
		sizeof(struct eiop_port_desc));
	memcpy(&(dpmac->serdes_desc), &(serdes_desc),
		sizeof(struct serdes_desc));
	
	return 0;
}

static void dpmac_init_handles(struct dpmac *dpmac)
{
        /*! Link manager 2.0 */
        dpmac->handles.linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
        CHECK_COND_RET(dpmac->handles.linkman);

        dpmac->handles.dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
        CHECK_COND_RET(dpmac->handles.dpmng);
}


static void setup_sgmii_internal_phy(struct dpmac *dpmac, uint8_t phy_addr)
{
	uint16_t reg16;
	enum enet_mode enet_mode;

	/* In case the higher MACs are used
	 (i.e. the MACs that should support 10G),
	 speed=10000 is provided for SGMII ports. Temporary modify enet mode
	 to 1G one, so MII functions can work correctly. */
	enet_mode = dpmac->enet_mode;
	dpmac->enet_mode =
		_MAKFSL_ENET_MODE(_ENET_INTERFACE_FROM_MODE(dpmac->enet_mode),
			1000);

	/* The difference between SGMII and SGMII2.5 is the auto negotiation.
	 * In SGMII2.5 auto negotiation should be disabled
	 * for SGMII2.5G:
	 * 	Set SGMII_EN + Speed 1G
	 * for SGMII:
	 * 	Set SGMII_EN + AN 
	 */
	if (dpmac->enet_if == FSL_ENET_IF_SGMII_BASEX)
		reg16 = PHY_SGMII_IF_MODE_1000X;
	else
		reg16 = PHY_SGMII_IF_MODE_SGMII;

	if ((dpmac->rate == 2500))
		reg16 |= PHY_SGMII_IF_MODE_SPEED_1G;
	else {
		if (dpmac->mac_desc.autoneg)
			reg16 |= PHY_SGMII_IF_MODE_AN;
	}

	if (!(reg16 & PHY_SGMII_IF_MODE_AN)) {
		reg16 |= PHY_SGMII_IF_MODE_SPEED_1G;
	}

	mii_write_phy_reg(dpmac, phy_addr, 0x14, reg16, MDIO_CLAUSE22);

	/* Device ability according to SGMII specification */
	if (dpmac->enet_if == FSL_ENET_IF_SGMII_BASEX)
		reg16 = PHY_SGMII_DEV_ABILITY_1000X;
	else
		reg16 = PHY_SGMII_DEV_ABILITY_SGMII | PHY_SGMII_DEV_ABILITY_ACK;
	mii_write_phy_reg(dpmac, phy_addr, 0x4, reg16, MDIO_CLAUSE22);

	/* Setup SGMII link timer according to manual;
	 * previous settings: 0x0007,0xa120
	 */
	mii_write_phy_reg(dpmac, phy_addr, 0x13, 0x0003, MDIO_CLAUSE22);
	mii_write_phy_reg(dpmac, phy_addr, 0x12, 0x06a0, MDIO_CLAUSE22);

	/* Set 1G + Full Duplex */
	reg16 = PHY_SGMII_CR_1G | PHY_SGMII_CR_FD;
	/* Set and restart auto negotiation for SGMII (not SGMII2.5) */
	if ((dpmac->mac_desc.autoneg) && (dpmac->rate == 1000))
		reg16 |= PHY_SGMII_CR_AN_EN | PHY_SGMII_CR_RESET_AN;

	mii_write_phy_reg(dpmac, phy_addr, 0x0, reg16, MDIO_CLAUSE22);

	/* Restore original enet mode */
	dpmac->enet_mode = enet_mode;
}

static void print_internal_phy_info(struct dpmac *dpmac, uint8_t phy_addr)
{
	uint16_t reg16;

	pr_debug("ID[%d]: Internal PHY [Address %d] information:\n",
	         dpmac->id, phy_addr);
	mii_read_phy_reg(dpmac, phy_addr, 0x11, &reg16, MDIO_CLAUSE22);
	pr_debug("SGMII Design Revision register = 0x%x\n", reg16);

	mii_read_phy_reg(dpmac, phy_addr, 0x0, &reg16, MDIO_CLAUSE22);
	pr_debug("SGMII control register = 0x%x\n", reg16);

	mii_read_phy_reg(dpmac, phy_addr, 0x1, &reg16, MDIO_CLAUSE22);
	pr_debug("SGMII status register = 0x%x\n", reg16);

	mii_read_phy_reg(dpmac, phy_addr, 0x4, &reg16, MDIO_CLAUSE22);
	pr_debug("SGMII Device Ability register = 0x%x\n", reg16);

	mii_read_phy_reg(dpmac, phy_addr, 0x5, &reg16, MDIO_CLAUSE22);
	pr_debug("SGMII Partner Ability register = 0x%x\n", reg16);

	mii_read_phy_reg(dpmac, phy_addr, 0x14, &reg16, MDIO_CLAUSE22);
	pr_debug("SGMII IF Mode register = 0x%x\n", reg16);
}

static int xfi_pcs_link_check(struct dpmac *dpmac)
{
	uint16_t reg16 = 0;
	int err;

	if (!dpmac->mac_desc.debug_link_check)
		return 0;

	err = mii_read_phy_reg(dpmac,
	                       GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_PCS),
	                       MDIO_XFI_PCS_SR1,
	                       &reg16,
	                       MDIO_CLAUSE45);
	if (err) {
		pr_err("ID[%d]: MDIO_XFI_PCS_SR1 read Failed!\n", dpmac->id);
		return -EACCES;
	}

	err = mii_read_phy_reg(dpmac,
	                       GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_PCS),
	                       MDIO_XFI_PCS_SR1,
	                       &reg16,
	                       MDIO_CLAUSE45);
	if (err) {
		pr_err("ID[%d]: MDIO_XFI_PCS_SR1 read Failed!\n", dpmac->id);
		return -EACCES;
	}


	if (!(reg16 & PCS_RX_LNK_STAT_MASK))
		return -EINVAL;
	return 0;
}

static int internal_phy_link_check(struct dpmac *dpmac)
{
	uint16_t reg16 = 0;
	uint8_t phy_addr = PHY_MDIO_ADDR;
	int err;

	if (!dpmac->mac_desc.debug_link_check)
		return 0;

	if (dpmac->eth_if == DPMAC_ETH_IF_QSGMII)
		phy_addr = (uint8_t)((PHY_MDIO_ADDR << 2) |
				     dpmac->mac_desc.qsgmii_phy_addr);

	err = mii_read_phy_reg(dpmac,
	                       phy_addr,
	                       MDIO_SGMII_SR,
	                       &reg16,
	                       MDIO_CLAUSE22);
	if (err) {
		pr_err("ID[%d]: MDIO_SGMII_SR read Failed!\n", dpmac->id);
		return -EACCES;
	}

	err = mii_read_phy_reg(dpmac,
	                       phy_addr,
	                       MDIO_SGMII_SR,
	                       &reg16,
	                       MDIO_CLAUSE22);
	if (err) {
		pr_err("ID[%d]: MDIO_SGMII_SR read Failed!\n", dpmac->id);
		return -EACCES;
	}

	if (!(reg16 & LINK_STAT_MASK))
		return -EINVAL;

	return 0;
}

static void print_internal_phy_info_usxgmii(struct dpmac *dpmac)
{
	uint16_t reg16;

	pr_debug("ID[%d]: Internal PHY [Address %d] information:\n",
	         dpmac->id, GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII));
	
	mii_read_phy_reg(dpmac, GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII), MDIO_USXGMII_STATUS, &reg16, MDIO_CLAUSE45);
	pr_debug("USXGMII status register = 0x%x \n", reg16);
	
	mii_read_phy_reg(dpmac, GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII), MDIO_USXGMII_CONTROL, &reg16, MDIO_CLAUSE45);
	pr_debug("USXGMII control register = 0x%x \n", reg16);

	mii_read_phy_reg(dpmac, GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII), MDIO_USXGMII_DEV_ABILITY, &reg16, MDIO_CLAUSE45);
	pr_debug("USXGMII Device Ability register = 0x%x \n", reg16);

	mii_read_phy_reg(dpmac, GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII), MDIO_USXGMII_PARTNER_ABILITY, &reg16, MDIO_CLAUSE45);
	pr_debug("USXGMII Partner Ability register = 0x%x \n", reg16);
	
	mii_read_phy_reg(dpmac, GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII), MDIO_USXGMII_LINK_TIMER1, &reg16, MDIO_CLAUSE45);
	pr_debug("USXGMII Link timer 1 = 0x%x \n", reg16);

	mii_read_phy_reg(dpmac, GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII), MDIO_USXGMII_LINK_TIMER2, &reg16, MDIO_CLAUSE45);
	pr_debug("USXGMII Link timer 2 = 0x%x\n", reg16);

}


static int convert_internal_phy_xfi2usxgmiia(struct dpmac *dpmac)
{
	int err;

	err = mii_write_phy_reg(dpmac,
			                GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII),
			                MDIO_USXGMII_LINK_TIMER1,
			                LINK_TIMER_1_VALUE,
	                        MDIO_CLAUSE45);
	if (err) {
		pr_err("ID[%d]: MDIO_USXGMII_LINK_TIMER1 write Failed!\n", dpmac->id);
		return -EACCES;
	}

	err = mii_write_phy_reg(dpmac,
                            GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII),
			                MDIO_USXGMII_LINK_TIMER2,
			                LINK_TIMER_2_VALUE,
	                        MDIO_CLAUSE45);
	if (err) {
		pr_err("ID[%d]: MDIO_USXGMII_LINK_TIMER2 write Failed!\n", dpmac->id);
		return -EACCES;
	}

	err = mii_write_phy_reg(dpmac,
			                GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII),
			                MDIO_USXGMII_DEV_ABILITY,
                            DV_AB_LINK_STATUS|DV_AB_DUPLEX_MODE|DV_AB_10_GB|
                            DV_AB_EEE_SUPORT|DV_AB_EEE_CLOCK_STOP|DV_AB_USXGMII,
	                        MDIO_CLAUSE45);
	if (err) {
		pr_err("ID[%d]: MDIO_USXGMII_DEV_ABILITY write Failed!\n", dpmac->id);
		return -EACCES;
	}
	
	/* it needs more than 1us to settle */
	timer_udelay(2);
	
	err = mii_write_phy_reg(dpmac,
			GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII),
			                MDIO_USXGMII_CONTROL,
			                CR_AUTONEG_ENABLE | CR_RESTART_AUTONEG,
	                        MDIO_CLAUSE45);
	if (err) {
		pr_err("ID[%d]: MDIO_USXGMII_CONTROL write Failed!\n", dpmac->id);
		return -EACCES;
	}

	return 0;
}

static int pcs_setup_fec(struct dpmac *dpmac, struct pcs_fec_regs *pcs_regs, int regs_count)
{
	int err = 0, i = 0, errata = 0;

	/* Only 25G interfaces require extra PCS settings, additional to protocol config bits */
	if (!dpmac_is_25g_mac(dpmac))
		return 0;

	/* find out if extra settings must be applied per MAC due to errata/workaround/etc */
	if ((dpmac->id == 3) || (dpmac->id == 5) || (dpmac->id == 9))
		errata = 1;

	for (i = 0; i < regs_count; i++)
	{
		/* some settings apply _ONLY_ for specific dpmacs */
		if (!errata && pcs_regs[i].errata)
			continue;

		/* when manual says delay, wait 1ms before write */
		if (pcs_regs[i].wait)
			timer_udelay(1000);

		/* perform the actual write */
		err = mii_write_phy_reg(dpmac,
								GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_PCS),
								pcs_regs[i].reg,
								pcs_regs[i].data,
								MDIO_CLAUSE45);

		if (err) {
			pr_err("Error while writing register %#x for MAC[%d].\n", pcs_regs[i].reg, dpmac->id);
			return -EACCES;
		}
	}

	return err;
}

static int dpmac_configure_fec_mode(struct dpmac *dpmac, enum dpmac_fec_mode fec_mode)
{
	int err = 0;

	/* nothing to configure; get out */
	if (dpmac->fec_mode == fec_mode) {
		pr_warn("No change in FEC mode for MAC[%d]\n", dpmac->id);
		return 0;
	}

	//pcs_setup_fec(dpmac, pcs_no_fec_regs);

	/* setup protocol registers */
	serdes_setup_fec_dispatch(&dpmac->serdes_desc, dpmac->id, fec_mode);

	/* apply PCS settings for specific FEC mode */
	switch (fec_mode) {
		case DPMAC_FEC_RS:
			err = pcs_setup_fec(dpmac, pcs_rs_fec_regs, GET_FEC_REGS_COUNT(pcs_rs_fec_regs));
			break;
		case DPMAC_FEC_FC:
			err = pcs_setup_fec(dpmac, pcs_fc_fec_regs, GET_FEC_REGS_COUNT(pcs_fc_fec_regs));
			break;
		default:
			break;
	}

	/* if all went good, update dpmac->fec_mode */
	if (!err)
		dpmac->fec_mode = fec_mode;

	return err;
}

int dpmac_hw_init(struct dpmac *dpmac, int mac_id)
{	
	struct linkman_endpoint ep1, ep2;
	struct linkman_connection_attr connection_attr;
	struct linkman_control control;
	int tmp_mac_id, err, i = 0;
	uint8_t phy_addr;
	struct serdes_eq_settings *serdes_cfg_ptr;
	uint32_t flags;
	
	if (dpmac->enabled)
		dpmac_disable(dpmac);

	/*
	 * Disable the serdes lane for SFMII interfaces.
	 * On a custom design it was observed that SGMII interface
	 * didn't work as expected if traffic was received during
	 * physical port initialization.
	 * Stopping the lanes should prevent any software initialization issue
	 * that might happen on the QMAN/WRIOP port,
	 * while traffic is received.
	 */
	serdes_disable_lane(dpmac->enet_if,
			    &dpmac->serdes_desc,
			    dpmac->id,
			    dpmac->mac_desc.master_lane);

	/* At restore stage, we need just to reconfigure the DPMAC 
	 * DISCONNECT <-> CONNECT will be made later after HW restore
	 */
	if(!dpmac->restore){
		/* Disconnect */
		memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
		memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
		memset(&connection_attr, 0x0, sizeof(struct linkman_connection_attr));
		memset(&control, 0x0, sizeof(struct linkman_control));
	
		ep1.type = FSL_MOD_DPMAC;
		ep1.id = (uint16_t)dpmac->id;
		err = linkman_get_connection(dpmac->handles.linkman,
							   &ep1,
							   &ep2,
							   &connection_attr);
		
		if ((!err) && connection_attr.state != LINKMAN_STATE_IDLE) {
			control.event = LINKMAN_EVENT_DISCONNECT;
			if (linkman_set_connection(dpmac->handles.linkman,
										&control,
										&ep1,
										&ep2) != 0)
				pr_warn("ID[%d]: linkman_set_connection (DISCONNECT) failed\n",
						dpmac->id);
		}
	}

	/* Reset */
	eiop_memac_reset(&(dpmac->mac_desc));
	dpmac_reset_counters(dpmac);

	/* retain configs from runtime - `dpmac_set_params()` */
	if(!dpmac->restore){
		eiop_memac_defconfig(&dpmac->cfg);
		dpmac->cfg.promiscuous_mode_enable = 1;
		dpmac->cfg.disable_flt_hdl = dpmac->mac_desc.disable_flt_hdl;
	}

#ifdef TKT508412
	/* LX2160_rev1 needs workaround for a issue described in trac ticket #906 */
	if (dpmac->mac_desc.type == E_EMAC_1G_10G_25G_TYPE)
		if (eiop_wriop_apply_TKT508412_fix()) {
			dpmac->cfg.cmd_frame_enable = 1;
			dpmac->cfg.pause_forward_enable = 1;
		}
#endif /* TKT508412 */

	/* Initialize */
	err = eiop_memac_init(&dpmac->mac_desc,
	                      &dpmac->cfg,
	                      dpmac->enet_if,
	                      dpmac->rate,
	                      dpmac->exceptions);
	if (err) {
		pr_err ("[%d]: Hardware initialization failed\n", dpmac->id);
		return err;
	}

	if (IS_SIM)
		goto skip_config;

	/*
	 * We don't configure serdes for backplane: let the driver handle it
	 * skip serdes configuration but do the mac internals:
	 * 	- IF_XFI: nothing
	 * 	- IF_CAUI: apply errata workaround ERR050369
	 */
	if (dpmac->link_type == DPMAC_LINK_TYPE_BACKPLANE)
		goto mac_internals;

	/*set as default SerDes cfg*/
	dpmac->serdes_cfg_mode = SERDES_CFG_DEFAULT;

	/* pointer to serdes_cfg structure kept in dpc.macs[] internals */
	serdes_cfg_ptr = (struct serdes_eq_settings *)&dpc.macs[dpmac->id - 1].serdes_cfg;

	/* initialize SerDes internals */
	if (dpc.macs[dpmac->id - 1].dpc_mask & DPC_MAC_MASK_SERDES_CFG) {
		/* custom TECR0 settings are supported for ALL interface types, except RGMII */
		switch (serdes_cfg_ptr->cfg) {
		case SERDES_CFG_CUSTOM:
			/* RGMII will fail when getting lane number; adding a error message to be consistent with other. */
			if (dpmac->enet_if == FSL_ENET_IF_RGMII) {
				pr_err("SerDes custom equalization NOT supported for MAC[%d]\n", dpmac->id);
				break;
			}
			else if (dpmac->enet_if == FSL_ENET_IF_QSGMII){
				tmp_mac_id = dpmac->mac_desc.mac_id;
				err = -1;
				while((i < 4) && err){
					err = serdes_eq_setup(&dpmac->serdes_desc, mac_id, serdes_cfg_ptr);
					tmp_mac_id--;
					i++;
				}
				if (err){
					pr_err("Error to match serdes lane for QSGMII\n");
					break;
				}
			} else {
				pr_debug("Applying custom SerDes settings for MAC[%d], enet_if = %#x\n", dpmac->id, dpmac->enet_if);
				err = serdes_eq_setup(&dpmac->serdes_desc, dpmac->mac_desc.mac_id, serdes_cfg_ptr);
				if (err){
					pr_err("Error to apply serdes cfg\n");
					break;
				}
			}
			dpmac->serdes_cfg_mode = SERDES_CFG_CUSTOM;
			break;
		case SERDES_CFG_SFI:
			if (is_serdes_sfi_capable(serdes_cfg_ptr) && dpmac->enet_if == FSL_ENET_IF_XFI) {
				pr_debug("SerDes SFI equalization applied for MAC[%d]\n", dpmac->id);
				err = serdes_eq_setup(&dpmac->serdes_desc, dpmac->mac_desc.mac_id, serdes_cfg_ptr);
				if(err)
					return err;
				dpmac->serdes_cfg_mode = SERDES_CFG_SFI;
			} else
				pr_err("SerDes SFI equalization NOT supported for MAC[%d]\n", dpmac->id);
			break;
		case SERDES_CFG_DEFAULT:
		default:
			break;
		}
	}

	switch (dpmac->mac_desc.converted) {
	case SERDES_IF_CONVERT_NOT_SUPPORTED:
		pr_err("DPMAC[%d]: protocol conversion not supported.\n",
				dpmac->id);
		break;
	case SERDES_IF_CONVERT_SUCCESS:
		pr_info("DPMAC[%d]: protocol conversion from %s to %s succeeded !\n",
				dpmac->id,
				serdes_get_enet_if_str(dpmac->mac_desc.enet_prev),
				serdes_get_enet_if_str(dpmac->enet_if));
		break;
	case SERDES_IF_CONVERT_FAILURE:
		pr_err("DPMAC[%d]: protocol conversion from %s to %s failed.\n",
				dpmac->id,
				serdes_get_enet_if_str(dpmac->enet_if),
				serdes_get_enet_if_str(dpmac->mac_desc.enet_prev));
		break;
	default:
	}

mac_internals:
	/* initialize MAC internals */
	switch (dpmac->enet_if) {
	case FSL_ENET_IF_SGMII:
	case FSL_ENET_IF_SGMII_BASEX:
		phy_addr = PHY_MDIO_ADDR;
		setup_sgmii_internal_phy(dpmac, phy_addr);
		print_internal_phy_info(dpmac, phy_addr);
		break;
	case FSL_ENET_IF_QSGMII:
		phy_addr = (uint8_t)((PHY_MDIO_ADDR << 2) | dpmac->mac_desc.qsgmii_phy_addr);
		setup_sgmii_internal_phy(dpmac, phy_addr);
		print_internal_phy_info(dpmac, phy_addr);		
		break;
	case FSL_ENET_IF_USXGMII:
		/* should I convert to USXGMII */
		convert_xfi2usxgmiia(&dpmac->serdes_desc, dpmac->mac_desc.mac_id);
		convert_internal_phy_xfi2usxgmiia(dpmac);
		print_internal_phy_info_usxgmii(dpmac);
		break;
	case FSL_ENET_IF_XFI:
		break;
	case FSL_ENET_IF_CAUI:
#ifdef ERR050369
		serdes_apply_caui_err050369(&dpmac->serdes_desc, dpmac->mac_desc.mac_id);
#endif
		/* if fec_mode property is not specified, use RS-FEC as default for 25G/100G */
		if (!(dpc.macs[dpmac->id - 1].dpc_mask & DPC_MAC_MASK_FEC_MODE))
			dpmac_configure_fec_mode(dpmac, DPMAC_FEC_RS);
		else
			dpmac_configure_fec_mode(dpmac, dpc.macs[dpmac->id - 1].fec_mode);
		break;
	default:
		break;
	}

skip_config:
	/* Set link state structure to zeros */
	if(!dpmac->restore)
		memset(&dpmac->link_cfg, 0, sizeof (struct linkman_link_state));

	/* Initialize Physical port with default IFP */
	port_init(dpmac, DEFAULT_IFP_ID);

	/* Enable port - PPID should be always enabled */
	port_enable(dpmac);

	/* enable the serdes lane for SFMII interfaces */
	serdes_enable_lane(&dpmac->serdes_desc,
			   dpmac->id,
			   dpmac->mac_desc.master_lane,
			   dpmac->mac_desc.no_lanes,
			   dpmac->enet_if);

	return 0;
}

static int event_linkdown(struct dpmac 			 *dpmac,        		
                          const struct linkman_control   *control,
                          struct linkman_endpoint        *self,  	
                          const struct linkman_endpoint  *peer, 	
                          struct linkman_action          *action)
{
	uint32_t irq_mask;
	int err;
	UNUSED(self);
	UNUSED(peer);

	if (!(self->valid_fields & LINKMAN_FIELD_DPMAC_RX_DIS)) {
		/* Disable RX (MAC and Port) and notify peer */
		/* MAC graceful stop */
		err = eiop_memac_rx_graceful_stop(&(dpmac->mac_desc));
		if (err)
			return err;

		self->valid_fields |= LINKMAN_FIELD_DPMAC_RX_DIS;

		return LINKMAN_ECONT;
	}

	/* Disable TX flow */
	eiop_memac_tx_graceful_stop(&(dpmac->mac_desc));

	dpmac->enabled = 0;

	dpmac_get_irq_mask(dpmac, DPMAC_IRQ_INDEX, &irq_mask);
	if ( (dpmac->link_type == DPMAC_LINK_TYPE_PHY || dpmac->link_type == DPMAC_LINK_TYPE_BACKPLANE)
			&& control->cmd == LINKMAN_CMD_DISABLE
			&& (irq_mask & DPMAC_IRQ_EVENT_LINK_CFG_REQ) )
		invoke_inter(dpmac, DPMAC_IRQ_INDEX, DPMAC_IRQ_EVENT_LINK_DOWN_REQ);

	if (dpmac->link_type == DPMAC_LINK_TYPE_PHY && control->cmd == LINKMAN_CMD_LINKDOWN_FROM_DISCONNECT)
		invoke_inter(dpmac, DPMAC_IRQ_INDEX, DPMAC_IRQ_EVENT_LINK_DOWN_REQ);

	return 0;

}

static int event_disconnect(struct dpmac 			*dpmac,        		
                            struct linkman_endpoint		*self,  	
                            const struct linkman_endpoint  	*peer, 	
                            struct linkman_action          	*action)
{
	int err;
	
	UNUSED(self);
	UNUSED(peer);

	if (!(peer->valid_fields & LINKMAN_FIELD_CLEAR_TX_FRAMES))
		return LINKMAN_ECONT;

	/* Set link state structure to zeros */
	memset(&dpmac->link_cfg, 0, sizeof (struct linkman_link_state));
	
	err = eiop_port_rx_graceful_stop(&(dpmac->port_desc));
	
	if (err)
		return err;
	
	/* PPID is always enabled */
	eiop_port_rx_enable(&(dpmac->port_desc));
	
	/* Disable TX flow */
	eiop_port_tx_graceful_stop(&(dpmac->port_desc));

	/* PPID is always enabled */
	eiop_port_tx_enable(&(dpmac->port_desc));
	
	/* Remove DPNI handle for a new connection */
	if(peer->type == FSL_MOD_DPNI)
		dpmac->dpni = NULL;

	return 0;
}

static void adjust_hardware(struct dpmac 			*dpmac,
                            struct linkman_endpoint		*self,
                            const struct linkman_endpoint  	*peer,
                            struct linkman_action          	*action)
{
	int full_duplex = 1;
	int ignore_rx_pause = 0;	/* More likely */
	int enable_tx_pause = 1;	/* More likely */
	int enable_pfc_pause = 0;
	int fixed = 0;

	if (action->state.options & DPMAC_LINK_OPT_HALF_DUPLEX)
		full_duplex = 0;

	if (dpmac->link_type == DPMAC_LINK_TYPE_FIXED )
	    fixed = 1;

	eiop_memac_adjust_link(&dpmac->mac_desc,
                               dpmac->enet_if,
                               action->state.rate,
                               full_duplex,
                               fixed);

	/* According to 802.3x, clause 28:
	 *   ASYM_PAUSE	|  OPT_PAUSE	|   TX	|   RX	|
	 * ----------------------------------------------
	 *	0	|	0	|  off	|  off	|
	 * ----------------------------------------------
	 *	0	|	1	|  on	|  on	|
	 * ----------------------------------------------
	 *	1	|	0	|  on	|  off	|
	 * ----------------------------------------------
	 *	1	| 	1	|  off	|  on	|
	 *
	 * According to the table above:
	 * - when OPT_PAUSE = 0 --> RX pause frames are off
	 * - when OPT_PAUSE = 1 --> RX pause frames are on
	 * - when OPT_PAUSE XOR OPT_ASYM = 0 --> TX pause frames are off
	 * - when OPT_PAUSE XOR OPT_ASYM = 1 --> TX pause frames are on
	 */

	/* Check for Priority Flow control */
	if( action->state.options & DPMAC_LINK_OPT_PFC_PAUSE )
		enable_pfc_pause = 1;

	eiop_memac_set_pfc_mode(&dpmac->mac_desc, enable_pfc_pause);

	/* Check if RX pause frames should be IGNORED */
	if (!(action->state.options & DPMAC_LINK_OPT_PAUSE))
		ignore_rx_pause = 1;

	eiop_memac_set_rx_ignore_pause_frames(&dpmac->mac_desc,
	                                      ignore_rx_pause);

	/* Check if TX pause frames should be disabled */
	if (!( (!!(action->state.options & DPMAC_LINK_OPT_PAUSE)) ^
		(!!(action->state.options & DPMAC_LINK_OPT_ASYM_PAUSE)) ))
		enable_tx_pause = 0;

	eiop_memac_set_tx_pause_frames(&dpmac->mac_desc, enable_tx_pause);

	dpmac_enable(dpmac);

	if (dpmac->link_type == DPMAC_LINK_TYPE_PHY)
		action->request = LINKMAN_REQUEST_COMPLETE_CB;

}

static int event_connect(struct dpmac 			*dpmac,
                         struct linkman_endpoint       	*self,
                         const struct linkman_endpoint  *peer,
                         struct linkman_action          *action)

{
	int err = -ENOTSUP; /*! Operation not supported */

	/*! Verify self endpoint integrity */
	if (self->type != FSL_MOD_DPMAC)
		return -EINVAL; /*! Invalid argument */

	switch (peer->type) {
	case FSL_MOD_DPNI:
		/* Get peer DPNI handle */
		dpmac->dpni = sys_get_handle(FSL_MOD_DPNI, 1, peer->id);
	case FSL_MOD_DPSW:
	case FSL_MOD_DPDMUX:
		err = LINKMAN_ECONT;
		/* Provide DPMAC parameters */
		if (peer->valid_fields & LINKMAN_FIELD_IFPID) {
			/* Save ifp */
			dpmac->ifpid = peer->ifpid;
			/* Set IFP to physical port */
			err = port_set_ifp(dpmac);
		}
		break;
	default:
		break;
	}

	return err;
}

static int event_linkup_fixed(struct dpmac 		    *dpmac,
                              struct linkman_endpoint       *self,
                              const struct linkman_endpoint *peer,
                              struct linkman_action         *action)
{
	int err;

	if (dpmac->link_type == DPMAC_LINK_TYPE_FIXED) {
		err = dpmac_check_internal_physical_link(dpmac);
		if (err) {
			pr_err("ID[%d]: Internal physical link is down\n",
			       dpmac->id);
			return err;
		}
	}

#if 0
	else if (dpmac->link_type == DPMAC_LINK_TYPE_BACKPLANE) {
		if (dpmac->eth_if == DPMAC_ETH_IF_SGMII) {
			err = dpmac_set_1000base_kx_link(dpmac);
			if (err)
				return err;
		}
	}
#endif

	if (dpmac->eth_if != DPMAC_ETH_IF_RGMII)
		if (peer->options & LINKMAN_LINK_OPT_AUTONEG) {
			/* Auto negotiation, set DPMAC defaults */
			self->rate = dpmac->rate;
			self->options |= LINKMAN_LINK_OPT_AUTONEG;
			self->options |= LINKMAN_LINK_OPT_PAUSE;
			self->options |= LINKMAN_LINK_OPT_ASYM_PAUSE;
			self->options |= LINKMAN_LINK_OPT_PFC_PAUSE;
		} else {
			/* Check if rate matches DPMAC rate */
			if (peer->rate != dpmac->rate) {
				pr_err("ID[%d]: Auto Negotiation is off: Requested link rate (%dMbps) dosn't match supported rate(%dMbps)\n",
						dpmac->id,
						peer->rate,
						dpmac->rate);
				return -EINVAL;
			}

			self->rate = dpmac->rate;
			self->options = peer->options;
			self->advertising = peer->advertising;
		}
	/* 	For RGMII, Type FIXED, Auto negotiation is always off, permit to set custom rate*/
	else {
		/* verify the requested rate*/
		if (peer->rate > dpmac->rate) {
			pr_err("ID[%d]: Requested link rate (%dMbps) is bigger than supported (%dMbps)\n",
					dpmac->id,
					peer->rate,
					dpmac->rate);
			return -EINVAL;
		}

		if(!peer->rate)
			self->rate = dpmac->rate;
		else
			self->rate = peer->rate;

		self->options = peer->options;
		self->options &= ~LINKMAN_LINK_OPT_AUTONEG;
		self->advertising = peer->advertising;

	}

	/* Save information for link manager */
	action->state.rate = self->rate;
	action->state.options = self->options & peer->options;
	action->state.advertising = self->advertising;

	/* Save the link parameters for DPMAC use */
	dpmac->link_cfg.rate = self->rate;
	dpmac->link_cfg.options = self->options;
	dpmac->link_cfg.advertising = self->advertising;

	/* update options to be used in connection state machine */
	self->options = self->options & peer->options;

	self->valid_fields |= LINKMAN_FIELD_LINK_STATE;
	self->link_state_available = 1;

	adjust_hardware(dpmac, self, peer, action);

	return 0;
}

static int event_linkup_from_phy(struct dpmac 		       *dpmac,
				 struct linkman_endpoint       *self,
				 const struct linkman_endpoint *peer,
				 struct linkman_action         *action)
{
	/* Save information for link manager */
	action->state.rate = self->rate;
	action->state.options = self->options;
	action->state.advertising = self->advertising;

	self->valid_fields |= LINKMAN_FIELD_LINK_STATE;
	self->link_state_available = 1;

	adjust_hardware(dpmac, self, peer, action);

	return 0;
}

static int event_linkup_phy(struct dpmac 		  *dpmac,
                            const struct linkman_control   *control,
                            struct linkman_endpoint       *self,
                            const struct linkman_endpoint *peer,
                            struct linkman_action         *action)
{
	uint32_t irq_mask;
	if (peer->options & LINKMAN_LINK_OPT_AUTONEG) {
	/* Auto negotiation enabled */
		dpmac->link_cfg.options |= DPMAC_LINK_OPT_AUTONEG;
		dpmac->link_cfg.options |= DPMAC_LINK_OPT_PAUSE;
		dpmac->link_cfg.options |= DPMAC_LINK_OPT_ASYM_PAUSE;
		dpmac->link_cfg.options |= DPMAC_LINK_OPT_PFC_PAUSE;

		dpmac->link_cfg.options = dpmac->link_cfg.options & peer->options;
		self->options = dpmac->link_cfg.options;
		action->state.options = dpmac->link_cfg.options;

		dpmac->link_cfg.advertising = peer->advertising;
	} else {
		/* Auto negotiation disabled */
		if (peer->rate > dpmac->rate) {
			pr_err("ID[%d]: Requested link rate (%dMbps) is bigger than supported (%dMbps)\n",
			       dpmac->id,
			       peer->rate,
			       dpmac->rate);
			return -EINVAL;
			}

		/* Save link configuration */
		dpmac->link_cfg.rate = peer->rate;
		dpmac->link_cfg.options = peer->options;
		dpmac->link_cfg.advertising = peer->advertising;
	}

	/* Notify Linkman that auto-negotiation is required */
	action->request = LINKMAN_REQUEST_NEGOTIATION;

	/* Notify peer that link up cannot be completed */
	self->valid_fields |= LINKMAN_FIELD_LINK_STATE;
	if (!(peer->valid_fields & LINKMAN_FIELD_LINK_STATE))
		return LINKMAN_ECONT;

	self->link_state_available = 0;

	dpmac_get_irq_mask(dpmac, DPMAC_IRQ_INDEX, &irq_mask);
	if( dpmac->link_type == DPMAC_LINK_TYPE_PHY || dpmac->link_type == DPMAC_LINK_TYPE_BACKPLANE )
		if (((control->cmd == LINKMAN_CMD_ENABLE) || (peer->ep_enabled && control->cmd == LINKMAN_CMD_LINKUP_FROM_CONNECT)) && (irq_mask & DPMAC_IRQ_EVENT_LINK_UP_REQ))
			invoke_inter(dpmac, DPMAC_IRQ_INDEX, DPMAC_IRQ_EVENT_LINK_UP_REQ);
		else if ((irq_mask & DPMAC_IRQ_EVENT_LINK_CFG_REQ) && (control->cmd != LINKMAN_CMD_SILENTLY))
			invoke_inter(dpmac, DPMAC_IRQ_INDEX, DPMAC_IRQ_EVENT_LINK_CFG_REQ);

	return 0;

}

static int event_linkup(struct dpmac 			*dpmac,
                        const struct linkman_control   *control,
                        struct linkman_endpoint       	*self,
                        const struct linkman_endpoint 	*peer,
                        struct linkman_action         	*action)
{
	int is_cfg_changed;
	struct linkman_link_state link_state;

	/* Check if link configuration parameters are available */
	if ((peer->valid_fields & LINKMAN_FIELD_LINK_CFG) == 0)
		return LINKMAN_ECONT;

	/* Check if new configuration request is different from current
	 * state, if the requests are the same, we don't need to notify
	 * the PHY driver, we can refer to this cases like fixed-link.
	 */
	link_state.rate = peer->rate;
	link_state.options = peer->options;
	link_state.advertising = peer->advertising;
	is_cfg_changed = memcmp(&dpmac->link_cfg,
	                        &link_state,
	                        sizeof(struct linkman_link_state));

	if (((dpmac->link_type == DPMAC_LINK_TYPE_PHY) ||
		(dpmac->link_type == DPMAC_LINK_TYPE_BACKPLANE)) && is_cfg_changed) {
		if (dpmac->linkup_from_phy)
			return event_linkup_from_phy(dpmac, self, peer, action);
		else
			return event_linkup_phy(dpmac, control, self, peer, action);

	} else if ((dpmac->link_type == DPMAC_LINK_TYPE_FIXED) ||
		!is_cfg_changed) {

		return event_linkup_fixed(dpmac, self, peer, action);
	}

	return 0;
}

static int event_negotiation_ok(struct dpmac 			*dpmac,
                                struct linkman_endpoint       	*self,
                                const struct linkman_endpoint 	*peer,
                                struct linkman_action         	*action)
{
	action->state.rate = self->rate;
	action->state.options = self->options;
	action->state.advertising = self->advertising;

	adjust_hardware(dpmac, self, peer, action);

	return 0;
}

#ifdef TKT011436 
static void dpmac_errata_A011436_check(void *handle, int is_was_linkup)
{
	struct dpmac *dpmac = (struct dpmac *)handle;
	uint32_t ievent;
	uint32_t event_mask;
	int err;

	/* Errata occurencce check for DPNI <-> DPMAC connection */
	if(dpc_get_A011436_state(DPC_ERRATA_STATE_MASK) && dpmac->dpni)
		if((dpmac->eth_if == DPMAC_ETH_IF_XFI) ||
		   (dpmac->eth_if == DPMAC_ETH_IF_USXGMII)) {

			event_mask = MEMAC_IEVNT_REM_FAULT | MEMAC_IEVNT_LOC_FAULT;
			ievent = eiop_memac_get_event(&(dpmac->mac_desc),event_mask);
			/* A-011436 errata is reproduced in case of TX + Local Fault or Remote Fault */
			if(is_was_linkup && ievent)
			{
				pr_warn("DPMAC[%d] - Fault received for running interface - Remote_fault = %s, Local_fault = %s\n", 
						dpmac->id,		
							(eiop_memac_get_event(&(dpmac->mac_desc), MEMAC_IEVNT_REM_FAULT)) ? "true" : "false",
									(eiop_memac_get_event(&(dpmac->mac_desc), MEMAC_IEVNT_LOC_FAULT)) ? "true" : "false");
				
				/* Check Errata occurrence, apply WA if occurred */
				err = resman_errata_workaround(dpmac->id, RESMAN_ERRATA_CHECK_WORKAROUND);
				CHECK_COND_RET(!err, "resman_errata_workaround Failed\n");
			}
			// Clear the faults
			eiop_memac_ack_event(&(dpmac->mac_desc), ievent);
		}
}
#endif /* TKT011436 */

#ifdef TKT320141
static void dpmac_periodic_cdr_lock_check(void *handle)
{
	struct dpmac *dpmac = (struct dpmac *)handle;
	int link_down = 1, reset = 0, err = 0;

	/* execute only if not in DPL processing */
	if (in_dpl_processing)
		return;

	/* the SerDes receiver lane reset workaround will be applied
	 * for XFI, CAUI and USXGMII interfaces
	 */
	if ((dpmac->eth_if != DPMAC_ETH_IF_XFI) &&
		(dpmac->eth_if != DPMAC_ETH_IF_USXGMII) &&
		(dpmac->eth_if != DPMAC_ETH_IF_CAUI))
		return;

#if 0
	/* xfi_pcs_link_check will return 0 when link is UP
	 * any other return value will be translated to a link DOWN
	 */
	link_down = !!xfi_pcs_link_check(dpmac);

	if (link_down) {
		/* link down can be caused by CDR failing to lock */
		reset =	serdes_reset_receiver_lane(&dpmac->serdes_desc,
									dpmac->id,
									dpmac->mac_desc.master_lane,
									dpmac->mac_desc.no_lanes,
									dpmac->enet_if);

		/* when link is down and CDR_LOCK is set maybe it's time to restart AN for USXGMII */
		if (!reset && dpmac->eth_if == FSL_ENET_IF_USXGMII) {
			err = mii_write_phy_reg(dpmac,
									GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, MDD_USXGMII),
									MDIO_USXGMII_CONTROL,
									CR_AUTONEG_ENABLE | CR_RESTART_AUTONEG,
									MDIO_CLAUSE45);
			if (err)
				pr_err("ID[%d]: MDIO_USXGMII_CONTROL write Failed!\n", dpmac->id);
		}
	}
#else
	/* remove any internal MDIO access for the time being; just reset receiver lane if CDR_LOCK=0 */
	reset =	serdes_reset_receiver_lane(&dpmac->serdes_desc,
								dpmac->id,
								dpmac->mac_desc.master_lane,
								dpmac->mac_desc.no_lanes,
								dpmac->enet_if);
#endif
}
#endif /* TKT320141 */

static void dpmac_periodic_phy_link_check(void *handle){
#ifdef TKT320141
	dpmac_periodic_cdr_lock_check(handle);
#endif /* TKT320141 */
#ifdef TKT011436
	struct dpmac *dpmac = (struct dpmac *)handle;
	int err, link_up = 0;
	struct linkman_endpoint ep1, ep2;
	struct linkman_connection_attr connection_attr;

	/* execute only if not in DPL processing */
	if (in_dpl_processing)
		return;

	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	memset(&connection_attr, 0x0, sizeof(struct linkman_connection_attr));

	ep1.type = FSL_MOD_DPMAC;
	ep1.id = (uint16_t)dpmac->id;

	/* Get current linkman state */
	err = linkman_get_connection(dpmac->handles.linkman,
	                             &ep1,
	                             &ep2,
	                             &connection_attr);
	CHECK_COND_RET(!err, "Failed to get connection\n");

	/* Verify errata occurrence for type PHY conenction */
	dpmac_errata_A011436_check(handle, (connection_attr.state == LINKMAN_STATE_LINKUP));
#endif /* TKT011436 */
}

static void dpmac_periodic_physical_link_check(void *handle)
{
	struct dpmac *dpmac = (struct dpmac *)handle;
	int err, link_down, generate_event = 0;
	struct linkman_endpoint ep1, ep2;
	struct linkman_control control; 
	struct linkman_connection_attr connection_attr;

	/* execute only if not in DPL processing */
	if (in_dpl_processing)
		return;

	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));
	memset(&connection_attr, 0x0, sizeof(struct linkman_connection_attr));

	ep1.type = FSL_MOD_DPMAC;
	ep1.id = (uint16_t)dpmac->id;

	/* Get current linkman state */
	err = linkman_get_connection(dpmac->handles.linkman,
	                             &ep1,
	                             &ep2,
	                             &connection_attr);
	if (err)
		return;

	if (dpmac->link_type == DPMAC_LINK_TYPE_FIXED) {
		/* Get current physical link state */
		link_down = dpmac_check_internal_physical_link(dpmac);

	} 
#if 0	
	else if (dpmac->link_type == DPMAC_LINK_TYPE_BACKPLANE) {
		if (dpmac->eth_if == DPMAC_ETH_IF_SGMII) {
			/* Get current physical link state */
			link_down = dpmac_get_1000base_kx_link_state(dpmac);

			/* If link is down, try to bring it up */
			if (link_down)
				link_down = dpmac_set_1000base_kx_link(dpmac);
		} else {
			return;
		}
	}
#endif
	else {
		return;
	}

	/* Linkman state is up, physical link is down */
	if (connection_attr.state == LINKMAN_STATE_LINKUP && link_down) {
		generate_event = 1;
		control.event = LINKMAN_EVENT_LINKDOWN;
	}

	/* Linkman state is not up, physical link is up */
	if (connection_attr.state == LINKMAN_STATE_CONNECTED && !link_down) {
		generate_event = 1;
		control.event = LINKMAN_EVENT_LINKUP;
	}

	/* Generate linkup/linkdown event, if needed */
	if (generate_event) {
		ep1.options = dpmac->link_cfg.options;
		ep1.rate = dpmac->link_cfg.rate;
		ep1.advertising = dpmac->link_cfg.advertising;
		linkman_set_connection(dpmac->handles.linkman, &control,
		                       &ep1, &ep2);
	}
#ifdef TKT011436 
	/* Verify errata occurrence for type FIXED connection*/
	dpmac_errata_A011436_check(handle, (connection_attr.state == LINKMAN_STATE_LINKUP));
#endif /* TKT011436 */

}


int dpmac_event_cb(void *handle,
                   const struct linkman_control   *control,
                   struct linkman_endpoint        *self,
                   const struct linkman_endpoint  *peer,
                   struct linkman_action          *action)
{
	int err = 0;

	switch (control->event) {
		case LINKMAN_EVENT_CONNECT:
			err = event_connect(handle, self, peer, action);
			action->request = LINKMAN_REQUEST_COMPLETE_CB;
			break;
		case LINKMAN_EVENT_DISCONNECT:
			err = event_disconnect(handle, self, peer, action);
			action->request = LINKMAN_REQUEST_COMPLETE_CB;
			break;
		case LINKMAN_EVENT_LINKUP:
			err = event_linkup(handle, control, self, peer, action);
			break;
		case LINKMAN_EVENT_NEGOTIATION_OK:
			err = event_negotiation_ok(handle, self, peer, action);
			break;
		case LINKMAN_EVENT_LINKDOWN:
		case LINKMAN_EVENT_NEGOTIATION_FAIL:
			err = event_linkdown(handle, control, self, peer, action);
			break;
	}

	return err;
}

int dpmac_event_complete_cb(void *handle,
                            const struct linkman_control   *control,
                            struct linkman_endpoint        *self,
                            const struct linkman_endpoint  *peer,
                            struct linkman_action          *action)
{
	uint32_t irq_mask;
	struct dpmac *dpmac = (struct dpmac *)handle;

	dpmac_get_irq_mask(dpmac, DPMAC_IRQ_INDEX, &irq_mask);

	/* Return if no MSI is desired to be sent */
	if(control->cmd != LINKMAN_CMD_SILENTLY)
		return 0;

	switch (control->event) {
	case LINKMAN_EVENT_CONNECT:
	case LINKMAN_EVENT_DISCONNECT:
		if (irq_mask & DPMAC_IRQ_EVENT_ENDPOINT_CHANGED)
			invoke_inter(dpmac, DPMAC_IRQ_INDEX, DPMAC_IRQ_EVENT_ENDPOINT_CHANGED);
		break;
	default:
		if ((dpmac->link_type == DPMAC_LINK_TYPE_PHY || dpmac->link_type == DPMAC_LINK_TYPE_BACKPLANE) &&
		    (irq_mask & DPMAC_IRQ_EVENT_LINK_CHANGED))
			invoke_inter(dpmac, DPMAC_IRQ_INDEX, DPMAC_IRQ_EVENT_LINK_CHANGED);
		break;
	}

	return 0;
}

/*****************************************************************************/
/*                            API routines                                   */
/*****************************************************************************/
void dpmac_deallocate(struct dpmac *dpmac)
{
	fsl_free(dpmac);
}

void dpmac_destroy(struct dpmac *dpmac)
{
	struct linkman_endpoint ep1, ep2;
	struct linkman_connection_attr connection_attr;
	struct linkman_control control;
	int err;

	if (dpmac->enabled)
		dpmac_disable(dpmac);

	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	memset(&connection_attr, 0x0, sizeof(struct linkman_connection_attr));
	memset(&control, 0x0, sizeof(struct linkman_control));

	ep1.type = FSL_MOD_DPMAC;
	ep1.id = (uint16_t)dpmac->id;
	err = linkman_get_connection(dpmac->handles.linkman,
	                       &ep1,
	                       &ep2,
	                       &connection_attr);
	
	
	if ((!err) && (connection_attr.state != LINKMAN_STATE_IDLE)) {
		control.event = LINKMAN_EVENT_DISCONNECT;
		if (linkman_set_connection(dpmac->handles.linkman,
		                           &control,
		                           &ep1,
		                           &ep2) != 0)
			pr_warn("ID[%d]: linkman_set_connection (DISCONNECT) failed\n",
			        dpmac->id);
	}

	if (!IS_SIM && dpmac->timer) {
		/* Free the timer of this DPMAC,
		 * timer_free calls timer_stop, so no need to call it
		 */
		timer_free(dpmac->timer);
	}
}

int dpmac_is_enabled(struct dpmac *dpmac, int *en)
{
	*en = dpmac->enabled;

	return 0;
}

int dpmac_get_attributes(struct dpmac *dpmac, union dpmac_attr *attributes)
{
	attributes->v1.id = dpmac->id;
	attributes->v1.link_type = dpmac->link_type;
	attributes->v1.eth_if = dpmac->eth_if;
	attributes->v1.max_rate = dpmac->rate;

	/* for backward compatibility update phy_id also*/
	attributes->v0.phy_id = dpmac->phy_id;

	return 0;
}

int dpmac_set_dev_ctx(struct dpmac *dpmac, const struct dpmng_dev_ctx *dev_ctx)
{
	return 0;
}

int dpmac_get_port_mac_addr(struct dpmac *dpmac, uint8_t addr[6])
{
	if (dpmac->id > DPC_MAX_MACS) {
		pr_err("Port MAC address storage is available only for %d ports\n",
				DPC_MAX_MACS);
		return -ENOSPC;
	}
	/* DPMAC ID starts from 1, but entries in dpc array start from 0 */
	memcpy(addr, dpc.macs[dpmac->id - 1].port_mac_addr, 6);

	return 0;
}

int dpmac_set_irq(struct dpmac *dpmac,
		 uint8_t irq_index,
		 const struct mc_irq_cfg *irq_cfg)
{
	if (irq_index >= DPMAC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMAC_MAX_IRQ_NUM);
		return -EINVAL;
	}

	mc_set_irq(&(dpmac->irqs[irq_index]), irq_cfg);
	return 0;
}

int dpmac_get_irq(struct dpmac *dpmac,
        	 uint8_t irq_index,
        	 struct mc_irq_cfg *irq_cfg)
{
	int err;
	
	if (irq_index >= DPMAC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMAC_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_get_irq(&(dpmac->irqs[irq_index]), irq_cfg);
	if (err)
		return err;
	
	return 0;
}

int dpmac_set_irq_enable(struct dpmac *dpmac, uint8_t irq_index, uint8_t en)
{
	int err;
	
	if (irq_index >= DPMAC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMAC_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_set_irq_enable(&(dpmac->irqs[irq_index]), en);
	if (err)
		return err;
	
	return 0;
}

int dpmac_get_irq_enable(struct dpmac *dpmac, uint8_t irq_index, uint8_t *en)
{
	int err;
	
	if (irq_index >= DPMAC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMAC_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_get_irq_enable(&(dpmac->irqs[irq_index]), en);
	if (err)
		return err;

	return 0;
}

int dpmac_set_irq_mask(struct dpmac *dpmac, uint8_t irq_index, uint32_t mask)
{
	int err;
	
	if (irq_index >= DPMAC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMAC_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_set_irq_mask(&(dpmac->irqs[irq_index]), mask);
	if (err)
		return err;
	
	return 0;
}

int dpmac_get_irq_mask(struct dpmac *dpmac, uint8_t irq_index, uint32_t *mask)
{
	int err;
	
	if (irq_index >= DPMAC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMAC_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_get_irq_mask(&(dpmac->irqs[irq_index]), mask);
	if (err)
		return err;
	
	return 0;
}

int dpmac_get_irq_status(struct dpmac *dpmac, uint8_t irq_index, uint32_t *status)
{
	int err;
	
	if (irq_index >= DPMAC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMAC_MAX_IRQ_NUM);
		return -EINVAL;
	}

    err = mc_get_irq_status(&(dpmac->irqs[irq_index]), status);
	if (err)
		return err;
	
	return 0;
}

int dpmac_clear_irq_status(struct dpmac *dpmac,
			  uint8_t irq_index,
			  uint32_t status)
{
	int err;
	
	if (irq_index >= DPMAC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPMAC_MAX_IRQ_NUM);
		return -EINVAL;
	}

     err = mc_clear_irq_status(&(dpmac->irqs[irq_index]), status);
	if (err)
		return err;
	
	return 0;
}

/*****************************************************************************/
struct dpmac *dpmac_allocate(void)
{
	struct dpmac *dpmac = NULL;

	dpmac = (struct dpmac *)fsl_malloc(sizeof(struct dpmac));
	if (dpmac)
		memset(dpmac, 0, sizeof(struct dpmac));

	return dpmac;
}

static struct link_type_list_names  {
	enum dpmac_link_type type;
	char *name;
} link_type_list_names[] = {
		{DPMAC_LINK_TYPE_NONE, "DPMAC_LINK_TYPE_NONE"},
		{DPMAC_LINK_TYPE_FIXED, "DPMAC_LINK_TYPE_FIXED"},
		{DPMAC_LINK_TYPE_PHY, "DPMAC_LINK_TYPE_PHY"},
		{DPMAC_LINK_TYPE_BACKPLANE, "DPMAC_LINK_TYPE_BACKPLANE"},
		{DPMAC_LINK_TYPE_RECYCLE, "DPMAC_LINK_TYPE_RECYCLE"}
    
};

char *get_link_type_name(enum dpmac_link_type type) {
	int i;
	
	for (i = 0; i < ARRAY_SIZE(link_type_list_names); ++i)
		if (link_type_list_names[i].type == type)
			return link_type_list_names[i].name;
	
	return "UNKNOWN";
}

/*****************************************************************************/
int dpmac_init(struct dpmac *dpmac, int mac_id)
{	
	int i, err;
	
	/* Save all required descriptors */
	err = dpmac_save_descriptors(dpmac, mac_id);
	if (err)
		return err;

	/* Save DPMAC handles */
	dpmac_init_handles(dpmac);

	dpmac->id = mac_id;
	dpmac->enet_if = (enum enet_interface)dpmac->mac_desc.enet_if;
	dpmac->rate = dpmac->mac_desc.rate;

	switch(dpmac->enet_if) {
	case (FSL_ENET_IF_RGMII):
		dpmac->eth_if = DPMAC_ETH_IF_RGMII;
		break;
	case (FSL_ENET_IF_SGMII):
	case (FSL_ENET_IF_SGMII_BASEX):
		dpmac->eth_if = DPMAC_ETH_IF_SGMII;
		break;
	case (FSL_ENET_IF_QSGMII):
		dpmac->eth_if = DPMAC_ETH_IF_QSGMII;
		break;
	case (FSL_ENET_IF_XFI):
		dpmac->eth_if = DPMAC_ETH_IF_XFI;
		break;
	case (FSL_ENET_IF_XGMII):
		dpmac->eth_if = DPMAC_ETH_IF_XAUI;
		break;
	case (FSL_ENET_IF_CAUI):
		dpmac->eth_if = DPMAC_ETH_IF_CAUI;
		break;
	case (FSL_ENET_IF_USXGMII):
		dpmac->eth_if = DPMAC_ETH_IF_USXGMII;
	}

	if (dpmac->eth_if == DPMAC_ETH_IF_QSGMII) {
		struct eiop_memac_desc qsgmii_master_desc;

		/* Get the QSGMII Master id */
		qsgmii_master_desc.mac_id = dpmac->mac_desc.qsgmii_master;
		err = sys_get_desc(SOC_MODULE_EIOP_MEMAC,
		                   SOC_DB_MAC_DESC_ID,
		                   &qsgmii_master_desc,
		                   NULL);
		CHECK_COND_RETVAL(err == 0, err);

		/* Save MDIO offset of Master QSGMII MAC */
		dpmac->mac_mii_regs = (struct memac_mii_access_mem_map *)
			((int)(qsgmii_master_desc.vaddr) + MEMAC_TO_MII_OFFSET);
	} else {
		dpmac->mac_mii_regs = (struct memac_mii_access_mem_map *)
			((int)(dpmac->mac_desc.vaddr) + MEMAC_TO_MII_OFFSET);
	}
	/* General */
	dpmac->eiop_id = dpmac->port_desc.eiop_id;

	/* mEMAC exceptions */
	dpmac->exceptions = MEMAC_DEFAULT_EXCEPTIONS;

	/* Set link state structure to zeros */
	memset(&dpmac->link_cfg, 0, sizeof (struct linkman_link_state));

	/* Save board information */
	dpmac->link_type = dpc.macs[dpmac->id - 1].link_type;
	pr_debug("dpmac.%d: has link_type %s USXGMII\n", dpmac->id, get_link_type_name(dpmac->link_type));
	/* do not save here dpc's fec_mode; this will get set from dpmac_hw_init */
	dpmac->fec_mode = DPMAC_FEC_NONE;
	dpmac->phy_id = dpc.macs[dpmac->id - 1].phy_id;

	/* In a case of fixed link, DPMAC uses its defaults */
	if (dpmac->link_type == DPMAC_LINK_TYPE_FIXED)
		dpmac->link_cfg.rate = dpmac->rate;

	if (dpmac->link_type == DPMAC_LINK_TYPE_FIXED &&
	    !dpmac->mac_desc.debug_link_check) {
		pr_warn("debug_link_check option set to false for  DPMAC %d with link_type DPMAC_LINK_TYPE_FIXED. "
			"Link will always be reported as up!\n",
			dpmac->id);

	} else if (dpmac->link_type != DPMAC_LINK_TYPE_FIXED &&
			    !dpmac->mac_desc.debug_link_check) {
		pr_warn("debug_link_check option has no effect  for DPMAC %d "
			"with a link_type other than DPMAC_LINK_TYPE_FIXED!\n",
			dpmac->id);
	}

	/* HW init */
	dpmac_hw_init(dpmac, dpmac->id);

	/* Register timer for fixed-link and type-phy MACs
	 * This is required for periodic check for PCS state
	 * (Run those checks only on HW)
	 */
	if (!IS_SIM) {
		void (*timer_callback)(void *) = NULL;

		switch (dpmac->link_type) {
			case DPMAC_LINK_TYPE_FIXED:
				timer_callback = &dpmac_periodic_physical_link_check;
				break;
			case DPMAC_LINK_TYPE_PHY:
#if defined(TKT320141) || defined(TKT011436 )
				timer_callback = &dpmac_periodic_phy_link_check;
				break;
#endif /* TKT320141 || TKT011436  */
			case DPMAC_LINK_TYPE_BACKPLANE:
			case DPMAC_LINK_TYPE_NONE:
			default:
				timer_callback = NULL;
				break;
		}

		if (timer_callback) {
			dpmac->timer = timer_create();
			if(!dpmac->timer)
				return -EINVAL;

			err = timer_init(dpmac->timer,
							 1000,
							 timer_callback,
							 (void *)dpmac,
							 E_TIMER_MODE_PERIODIC,
							 0);
			if (err)
				return -EINVAL;

			timer_start(dpmac->timer);
		}
	}
#if 0
	if (dpmac->eth_if == DPMAC_ETH_IF_SGMII)
		dpmac_config_sgmii(dpmac, 0);
#endif

	for (i = 0; i < DPMAC_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpmac->irqs[i]), MC_IRQ_TYPE_MSI);
	
	return 0;
}

/*****************************************************************************/
int dpmac_reset(struct dpmac *dpmac)
{
	int err;

	err = dpmac_hw_init(dpmac, dpmac->id);

	/* Set link state structure to zeros */
	memset(&dpmac->link_cfg, 0, sizeof (struct linkman_link_state));
	dpmac->linkup_from_phy = 0;

	return err;
}

/*****************************************************************************/
int dpmac_enable(struct dpmac *dpmac)
{
	if (dpmac->enabled)
		return 0;

	/* Enable PP */
	eiop_port_rx_enable(&(dpmac->port_desc));
	eiop_port_tx_enable(&(dpmac->port_desc));

	/* Enable mEMAC */
	eiop_memac_enable(&(dpmac->mac_desc), ENABLE_MODE_RX, ENABLE_MODE_TX);

	dpmac->enabled = 1;

	return 0;
}

/*****************************************************************************/
int dpmac_disable(struct dpmac *dpmac)
{
	int err;

	err = port_disable(dpmac);
	if (err != 0)
		return err;

	err = mac_disable(dpmac);
	if (err != 0)
			return err;

	dpmac->enabled = 0;

	return 0;
}

/*****************************************************************************/
int dpmac_get_rate(struct dpmac *dpmac, uint32_t *rate)
{
	*rate = dpmac->rate;

	return 0;
}

/*****************************************************************************/
int dpmac_set_max_frame_length(struct dpmac *dpmac, uint16_t length)
{
	eiop_memac_set_max_frame_len(&(dpmac->mac_desc), length);

	return 0;
}

/*****************************************************************************/
int dpmac_get_max_frame_length(struct dpmac *dpmac, uint16_t *length)
{
	*(length) = eiop_memac_get_max_frame_len(&(dpmac->mac_desc));

	return 0;
}

#ifdef FUTURE_SUPPORT
int dpmac_set_promiscuous(struct dpmac * dpmac, int enable)
{
	eiop_memac_set_promiscuous(&(dpmac->mac_desc), enable);

	return 0;
}

int dpmac_get_promiscuous(struct dpmac * dpmac, int *status)
{
	*(status) = eiop_memac_get_promiscuous(&(dpmac->mac_desc));

	return 0;
}
#endif /* FUTURE_SUPPORT */

int dpmac_set_ptp(struct dpmac *dpmac, struct dpmac_ptp_cfg *cfg)
{
	int checksum_update = 0;

	if (cfg->options & DPMAC_PTP_OPT_CHECKSUM_CORRECTION)
		checksum_update = 1;

	eiop_memac_set_ptp(&(dpmac->mac_desc), cfg->enable, cfg->offset,
			   checksum_update, cfg->peer_delay);

	return 0;
}

int dpmac_get_ptp(struct dpmac *dpmac, struct dpmac_ptp_cfg *cfg)
{
	int checksum_update;
	int options = 0;

	eiop_memac_get_ptp(&(dpmac->mac_desc), &(cfg->enable), &(cfg->offset),
			   &checksum_update);

	if (checksum_update)
		options |= DPMAC_PTP_OPT_CHECKSUM_CORRECTION;

	cfg->options = options;

	return 0;
}

#ifdef FUTURE_SUPPORT
int dpmac_add_mac_addr(struct dpmac *dpmac, uint8_t *addr)
{
	uint8_t index = 0;

	eiop_memac_add_addr_in_paddr(&(dpmac->mac_desc), addr, index);

	return 0;
}

int dpmac_remove_mac_addr(struct dpmac *dpmac, const uint8_t *addr)
{
	uint8_t index = 0;

	eiop_memac_clear_addr_in_paddr(&(dpmac->mac_desc), index);

	return 0;
}
#endif /* FUTURE_SUPPORT */

int dpmac_set_ifg_mode(struct dpmac *dpmac, struct dpmac_ifg_cfg *cfg)
{
	int err = 0, err1 = 0;
	uint32_t ceetmid;
	void *swp;

	eiop_memac_set_wan(&(dpmac->mac_desc), cfg->ipg_mode);
	
	eiop_memac_set_ipg_len(&(dpmac->mac_desc), cfg->ipg_length);
	
	/*! Compose ceetm id */
	ceetmid = qbman_ceetmid_compose((uint8_t)dpmac->connection_desc.dcp_id,
					(uint8_t)dpmac->connection_desc.ceetm_id);

	err = dpmng_get_swportal(dpmac->handles.dpmng, &(swp));
	
	CHECK_COND_RETVAL(err==0, err);

	err1 = qbman_lni_shaper_disable(swp, ceetmid,
						(uint32_t)dpmac->connection_desc.lni_id,
					/* 12 = 8 (mac preamble + start of frame) + 4 FCS*/						
						(uint32_t)cfg->ipg_length + 12);
	
	/*! Put software portal */
	err = dpmng_put_swportal(dpmac->handles.dpmng, swp);
	
	CHECK_COND_RETVAL(err==0, err);	
	CHECK_COND_RETVAL(err1==0, err1, "Fail to execute qbman_lni_shaper_disable");

	dpmac->cfg.wan_mode_enable = cfg->ipg_mode;
	dpmac->cfg.tx_ipg_length = cfg->ipg_length;
	
	return 0;
}

int dpmac_get_ifg_mode(struct dpmac *dpmac, struct dpmac_ifg_cfg *cfg)
{
	cfg->ipg_mode = (enum dpmac_ifg_mode)dpmac->cfg.wan_mode_enable;
	cfg->ipg_length = (uint8_t)dpmac->cfg.tx_ipg_length;

	return 0;
}

int dpmac_set_loopback(struct dpmac *dpmac, int enable)
{
	if( dpmac->loopback == enable )
		return 0;

	/* Disable mEMAC */
	eiop_memac_disable(&(dpmac->mac_desc), ENABLE_MODE_RX, ENABLE_MODE_TX);

	/* Set loop-back */
	eiop_memac_set_loopback(&(dpmac->mac_desc), enable);

	if (enable || dpmac->enabled)
	{
		/* Enable mEMAC */
		eiop_memac_enable(&(dpmac->mac_desc), ENABLE_MODE_RX, ENABLE_MODE_TX);
	}

	dpmac->loopback = enable;

	return 0;
}

int dpmac_get_loopback(struct dpmac *dpmac, int *status)
{
	*(status) = eiop_memac_get_loopback(&(dpmac->mac_desc));

	return 0;
}

#ifdef WOL_SUPPORT
int dpmac_set_wol(struct dpmac *dpmac, int enable)
{
	eiop_memac_set_wol(&(dpmac->mac_desc), enable);

	return 0;
}

int dpmac_get_wol(struct dpmac *dpmac, int *status)
{
	*(status) = eiop_memac_get_wol(&(dpmac->mac_desc));

	return 0;
}
#endif /* WOL_SUPPORT */

int dpmac_get_statistics(struct dpmac *dpmac, struct dpmac_counters *dpmac_counters)
{
	dpmac_counters->pkts_64 = eiop_emac_get_counter(&(dpmac->mac_desc),
							E_MEMAC_COUNTER_R64);
	dpmac_counters->pkts_65_to_127 = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_R127);
	dpmac_counters->pkts_128_to_255 = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_R255);
	dpmac_counters->pkts_256_to_511 = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_R511);
	dpmac_counters->pkts_512_to_1023 = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_R1023);
	dpmac_counters->pkts_1024_to_1518 = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_R1518);
	dpmac_counters->pkts_1519_to_1522 = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_R1519X);
	dpmac_counters->fragments = eiop_emac_get_counter(&(dpmac->mac_desc),
							E_MEMAC_COUNTER_RFRG);
	dpmac_counters->jabbers = eiop_emac_get_counter(&(dpmac->mac_desc),
							E_MEMAC_COUNTER_RJBR);
	dpmac_counters->drop_events = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_RDRP);
	dpmac_counters->crc_align_errors = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_RALN);
	dpmac_counters->undersize_pkts = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_TUND);
	dpmac_counters->oversize_pkts = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_ROVR);
	dpmac_counters->rx_pause = eiop_emac_get_counter(&(dpmac->mac_desc),
							E_MEMAC_COUNTER_RXPF);
	dpmac_counters->tx_pause = eiop_emac_get_counter(&(dpmac->mac_desc),
							E_MEMAC_COUNTER_TXPF);
	dpmac_counters->if_in_octets = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_ROCT);
	dpmac_counters->if_in_ucast_pkts = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_RUCA);
	dpmac_counters->if_in_mcast_pkts = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_RMCA);
	dpmac_counters->if_in_bcast_pkts = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_RBCA);
	dpmac_counters->if_in_pkts = dpmac_counters->if_in_ucast_pkts
					+ dpmac_counters->if_in_mcast_pkts
					+ dpmac_counters->if_in_bcast_pkts;
	dpmac_counters->if_in_discards = 0;
	dpmac_counters->if_in_errors = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_RERR);
	dpmac_counters->if_out_octets = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_TOCT);
	dpmac_counters->if_out_ucast_pkts = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_TUCA);
	dpmac_counters->if_out_mcast_pkts = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_TMCA);
	dpmac_counters->if_out_bcast_pkts = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_TBCA);
	dpmac_counters->if_out_pkts = dpmac_counters->if_out_ucast_pkts
					+ dpmac_counters->if_out_mcast_pkts
					+ dpmac_counters->if_out_bcast_pkts;
	dpmac_counters->if_out_discards = 0;
	dpmac_counters->if_out_errors = eiop_emac_get_counter(
		&(dpmac->mac_desc), E_MEMAC_COUNTER_TERR);

	return 0;
}

int dpmac_get_counter(struct dpmac *dpmac,
		      enum dpmac_counter type,
		      uint64_t *counter)
{
	switch (type) {
		case DPMAC_CNT_ING_FRAME_64:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_R64);
			break;
		case DPMAC_CNT_ING_FRAME_127:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_R127);
			break;
		case DPMAC_CNT_ING_FRAME_255:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_R255);
			break;
		case DPMAC_CNT_ING_FRAME_511:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_R511);
			break;
		case DPMAC_CNT_ING_FRAME_1023:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_R1023);
			break;
		case DPMAC_CNT_ING_FRAME_1518:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_R1518);
			break;
		case DPMAC_CNT_ING_FRAME_1519_MAX:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_R1519X);
			break;
		case DPMAC_CNT_ING_FRAG:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RFRG);
			break;
		case DPMAC_CNT_ING_JABBER:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RJBR);
			break;
		case DPMAC_CNT_ING_FRAME_DISCARD:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RDRP);
			break;
		case DPMAC_CNT_ING_ALIGN_ERR:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RALN);
			break;
		case DPMAC_CNT_EGR_UNDERSIZED:
			if ( dpmac->mac_desc.type == E_EMAC_40G_50G_100G_TYPE ) {
				pr_debug("ID[%d]: counter not supported\n", dpmac->id);
				*counter = 0;
				return 0;
			}
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_TUND);
			break;
		case DPMAC_CNT_ING_OVERSIZED:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_ROVR);
			break;
		case DPMAC_CNT_ING_VALID_PAUSE_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RXPF);
			break;
		case DPMAC_CNT_EGR_VALID_PAUSE_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_TXPF);
			break;
		case DPMAC_CNT_ING_BYTE:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_ROCT);
			break;
		case DPMAC_CNT_ING_MCAST_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RMCA);
			break;
		case DPMAC_CNT_ING_BCAST_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RBCA);
			break;
		case DPMAC_CNT_ING_ALL_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RPKT);
			break;
		case DPMAC_CNT_ING_UCAST_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RUCA);
			break;
		case DPMAC_CNT_ING_ERR_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RERR);
			break;
		case DPMAC_CNT_EGR_BYTE:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_TOCT);
			break;
		case DPMAC_CNT_EGR_MCAST_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_TMCA);
			break;
		case DPMAC_CNT_EGR_BCAST_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_TBCA);
			break;
		case DPMAC_CNT_EGR_UCAST_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_TUCA);
			break;
		case DPMAC_CNT_EGR_ERR_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_TERR);
			break;
		case DPMAC_CNT_ING_GOOD_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                 E_MEMAC_COUNTER_RFRM);
			break;
		case DPMAC_CNT_EGR_GOOD_FRAME:
			*counter = eiop_emac_get_counter(&(dpmac->mac_desc),
			                                  E_MEMAC_COUNTER_TFRM);
			break;
		default:
			pr_err("ID[%d]: counter not supported\n", dpmac->id);
			return -EINVAL;
	}

	return 0;
}

int dpmac_reset_counters(struct dpmac *dpmac)
{
	eiop_memac_reset_stat(&(dpmac->mac_desc));

	return 0;
}

void dpmac_interrupt_handler(int mac_id)
{
	struct dpmac *dpmac;
	uint32_t ievent, imask;

	dpmac = sys_get_handle(FSL_MOD_DPMAC, 1, mac_id);
	CHECK_COND_RET(dpmac);

	ievent = eiop_memac_get_event(&(dpmac->mac_desc), 0xffffffff);
	imask = eiop_memac_get_interrupt_mask(&(dpmac->mac_desc));

	/* Imask include both error and notification/event bits.
	 Leaving only error bits enabled by imask.
	 The imask error bits are shifted by 16 bits offset from
	 their corresponding location in the ievent - hence the >> 16 */
	ievent &= ((imask & MEMAC_ALL_ERRS_IMASK) >> 16);

	eiop_memac_ack_event(&(dpmac->mac_desc), ievent);

	if (ievent & MEMAC_IEVNT_MGI) {
		pr_info("Magic Packet Interrupt\n");
	}
}

/*****************************************************************************/
/*				GPP functions				     */
/*****************************************************************************/
int dpmac_mdio_read(struct dpmac *dpmac, struct dpmac_mdio_cfg *cfg)
{
	return eiop_memac_mii_read_phy_reg(dpmac->mac_mii_regs,
	                            cfg->phy_addr,
	                            cfg->reg,
	                            &cfg->data,
	                            cfg->cl45);
}

int dpmac_mdio_write(struct dpmac *dpmac, struct dpmac_mdio_cfg *cfg)
{
	return eiop_memac_mii_write_phy_reg(dpmac->mac_mii_regs,
				    cfg->phy_addr,
				    cfg->reg,
				    cfg->data,
				    cfg->cl45);
}

int dpmac_get_link_cfg(struct dpmac *dpmac, struct dpmac_link_cfg *cfg)
{
	if (dpmac->link_cfg.options & LINKMAN_LINK_OPT_AUTONEG) {
		cfg->options |= DPMAC_LINK_OPT_AUTONEG;
		if (dpmac->link_cfg.options & DPMAC_LINK_OPT_PAUSE)
			cfg->options |= DPMAC_LINK_OPT_PAUSE;
		if (dpmac->link_cfg.options & DPMAC_LINK_OPT_ASYM_PAUSE)
			cfg->options |= DPMAC_LINK_OPT_ASYM_PAUSE;
		if (dpmac->link_cfg.options & DPMAC_LINK_OPT_PFC_PAUSE)
			cfg->options |= DPMAC_LINK_OPT_PFC_PAUSE;
	} else {
		/* Copy rate */
		cfg->rate = dpmac->link_cfg.rate;
		cfg->options = dpmac->link_cfg.options;
	}
	
	cfg->advertising = dpmac->link_cfg.advertising;
	return 0;
}

int dpmac_get_serdes_eq_setup(struct dpmac *dpmac, union dpmac_attr *attr)
{

	int mac_id, err = -1, i = 0;

	attr->v2.serdes_cfg.cfg = dpmac->serdes_cfg_mode;
	attr->v2.fec_mode = dpmac->fec_mode;

	if (dpmac->enet_if == FSL_ENET_IF_RGMII){

		pr_info("Serdes eq settings not available for RGMI ports\n");
		return 0;

	} else if (dpmac->enet_if == FSL_ENET_IF_QSGMII){
		mac_id = dpmac->mac_desc.mac_id;

		while((i < 4) && err){
			err = get_serdes_eq_setup(&dpmac->serdes_desc, mac_id, &attr->v2.serdes_cfg);
			mac_id--;
			i++;
		}
		if (err){
			pr_err("Error to match serdes lane for QSGMII\n");
			return err;
		}

	} else {

		return get_serdes_eq_setup(&dpmac->serdes_desc, dpmac->mac_desc.mac_id, &attr->v2.serdes_cfg);
	}

	return 0;
}

int dpmac_set_link_state(struct dpmac *dpmac,
                         struct dpmac_link_state *link_state)
{
	struct linkman_endpoint ep1, ep2;
	struct linkman_control control;
	struct linkman_connection_attr connection_attr;
	int err;

	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));
	memset(&connection_attr, 0x0, sizeof(struct linkman_connection_attr));
	
	if (link_state->advertising & ~DPMAC_ADVERTISED_MASK)
	{
		pr_err("[%d]: Illegal advertised speed\n", dpmac->id);
		return -EINVAL;
	}
	if (link_state->supported & ~DPMAC_ADVERTISED_MASK)
	{
		pr_err("[%d]: Illegal supported speed\n", dpmac->id);
		return -EINVAL;
	}

	ep1.type = FSL_MOD_DPMAC;
	ep1.id = (uint16_t)dpmac->id;
	ep1.options = link_state->options;
	ep1.rate = link_state->rate;
	ep1.advertising = link_state->advertising;
	control.supported = link_state->supported;

	/* Get current state, in order to determine which event is required.
	 * If there's no connection, return '0', it's not an error (the rest of
	 * the function is irrelevant in this case).
	 */
	err = linkman_get_connection(dpmac->handles.linkman, &ep1, &ep2,
	                             &connection_attr);
	if (err)
		return 0;

	/* Link down requested */
	if (!link_state->up) {
		switch(connection_attr.state) {
		case LINKMAN_STATE_LINKUP:
			control.event = LINKMAN_EVENT_LINKDOWN;
			break;
		case LINKMAN_STATE_NEGOTIATION:
			control.event = LINKMAN_EVENT_NEGOTIATION_FAIL;
			break;
		case LINKMAN_STATE_CONNECTED:
			return 0;
		case LINKMAN_STATE_IDLE:
			/* link down requested and link is idle, ignore.. */
			return 0;
		default:
			pr_err("[%d]: Illegal link down request\n", dpmac->id);
			return -EINVAL;
		}
	}

	/* Link up requested */
	if (link_state->up) {
		switch(connection_attr.state) {
		case LINKMAN_STATE_CONNECTED:
			control.event = LINKMAN_EVENT_LINKUP;
			dpmac->linkup_from_phy = 1;
			break;
		case LINKMAN_STATE_NEGOTIATION:
			if (link_state->rate > dpmac->rate) {
				control.event = LINKMAN_EVENT_NEGOTIATION_FAIL;
				pr_err("DPMAC[%d]: Requested link rate (%dMbps) is bigger than supported (%dMbps)\n",
					dpmac->id, link_state->rate, dpmac->rate);
				linkman_set_connection(dpmac->handles.linkman,
				                       &control, &ep1, &ep2);
				return -EINVAL;
			}
			control.event = LINKMAN_EVENT_NEGOTIATION_OK;
			break;
		case LINKMAN_STATE_LINKUP:
			/* New link state is the same as previous */
			if (dpmac->link_cfg.options == link_state->options &&
			    dpmac->link_cfg.rate == link_state->rate) {
			    	    pr_debug("[%d]: Current link state and requested link state are the same\n",
			    	           dpmac->id);
			    	    return 0;
			}

			/* Link state was updated - first set linkdown */
			control.event = LINKMAN_EVENT_LINKDOWN;
			err = linkman_set_connection(dpmac->handles.linkman,
			                             &control, &ep1, &ep2);
			if (err) {
				pr_err("ID[%d]: Can't set linkdown before updating new link state\n",
				       dpmac->id);
				return err;
			}

			/* Prepare call for link up */
			memset(&control, 0x0, sizeof(struct linkman_control));
			memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
			dpmac->linkup_from_phy = 1;
			control.event = LINKMAN_EVENT_LINKUP;	
		}
	}

	err = linkman_set_connection(dpmac->handles.linkman,
	                             &control,
	                             &ep1,
	                             &ep2);
	if (!err) {
		/* Save current link state if link is up */
		dpmac->link_cfg.options = link_state->options;
		dpmac->link_cfg.rate = link_state->rate;
		dpmac->link_cfg.advertising = link_state->advertising;
	}

	dpmac->linkup_from_phy = 0;

	return 0;
}

int dpmac_check_internal_physical_link(struct dpmac *dpmac)
{
	int err = 0;

#ifdef EMULATOR
	/* physical ports of emulation machines (ZeBu or PXP) don't have peers,
	 * frames injection is done manually */
	return 0;
#endif /* EMULATOR */

#ifdef ENGR00352475
	if (IS_SIM)
		return 0;
#endif /* ENGR00352475 */
	/* Not relevant for loopback mode */
	if (dpmac->loopback)
		return 0;

	/* In a case of XFI - check PCS status */
	if ((dpmac->eth_if == DPMAC_ETH_IF_XFI) ||
		(dpmac->eth_if == DPMAC_ETH_IF_USXGMII) ||
		(dpmac->eth_if == DPMAC_ETH_IF_CAUI))
		err = xfi_pcs_link_check(dpmac);

	/* QSGMII/SGMII - check internal PHY link */
	else if (dpmac->eth_if == DPMAC_ETH_IF_SGMII ||
		dpmac->eth_if == DPMAC_ETH_IF_QSGMII)
		err = internal_phy_link_check(dpmac);

	/* XAUI doesn't have internal PHY or PCS */

/* Following logic requires thorough testing on all platforms */
#if 0
	uint32_t ievent;
	if ((dpmac->eth_if == DPMAC_ETH_IF_XFI) ||
		(dpmac->eth_if == DPMAC_ETH_IF_USXGMII) ||
		(dpmac->eth_if == DPMAC_ETH_IF_CAUI)) {

		// Check REM_FAULT and LOCAL_FAULT indications
		ievent = eiop_memac_get_event(&(dpmac->mac_desc),
						MEMAC_IEVNT_REM_FAULT | MEMAC_IEVNT_LOC_FAULT);

		if (ievent) {
			// If LOC_FAULT present then clear TX_ENABLE
			eiop_memac_disable(&(dpmac->mac_desc), 0, ENABLE_MODE_TX);
		}

		// Clear the faults
		eiop_memac_ack_event(&(dpmac->mac_desc), ievent);

		// Check REM_FAULT indication
		ievent = eiop_memac_get_event(&(dpmac->mac_desc), MEMAC_IEVNT_REM_FAULT);

		if (ievent) {
			// If REM_FAULT present then clear TX_ENABLE
			eiop_memac_disable(&(dpmac->mac_desc), 0, ENABLE_MODE_TX);
			err |= ievent;
		}
		else {
			// Check LOC_FAULT indication
			ievent = eiop_memac_get_event(&(dpmac->mac_desc), MEMAC_IEVNT_LOC_FAULT);

			if (ievent) {
				// If LOC_FAULT present then clear TX_ENABLE
				eiop_memac_disable(&(dpmac->mac_desc), 0, ENABLE_MODE_TX);
				err |= ievent;

				serdes_set_fault(&dpmac->serdes_desc, dpmac->id, SERDES_REMOTE_FAULT, 1);
			}
			else
			{
				serdes_set_fault(&dpmac->serdes_desc, dpmac->id, SERDES_REMOTE_FAULT, 0);
				eiop_memac_enable(&(dpmac->mac_desc), 0, ENABLE_MODE_TX);
			}
		}
	}
#endif
#ifdef TKT320141
	if ((dpmac->eth_if == DPMAC_ETH_IF_XFI) ||
		(dpmac->eth_if == DPMAC_ETH_IF_USXGMII) ||
		(dpmac->eth_if == DPMAC_ETH_IF_CAUI) ||
		(dpmac->eth_if == DPMAC_ETH_IF_SGMII))
		serdes_reset_receiver_lane(&dpmac->serdes_desc,
				dpmac->id,
				dpmac->mac_desc.master_lane,
				dpmac->mac_desc.no_lanes,
				dpmac->enet_if);
#endif

	return err;
}

int dpmac_set_port_cgp(struct dpmac *dpmac, struct eiop_cgp *cgp, int cmd)
{
	eiop_port_set_cgp(&dpmac->port_desc, cgp, cmd);
	return 0;
}

void dpmac_dump(struct dpmac *dpmac)
{
	eiop_port_dump_regs(&dpmac->port_desc);
	eiop_memac_dump_regs(&dpmac->mac_desc);
}

int dpmac_config_sgmii(struct dpmac *dpmac, int phy_loop) /* 0-no loop ; 1-loop */
{
	uint8_t phy_addr;
	struct dpmac_mdio_cfg cfg;

	memset(&cfg, 0, sizeof(struct dpmac_mdio_cfg));

	switch(dpmac->id) {
		case(9) :
			phy_addr = 0x1c;
			break;
		case(10) :
			phy_addr = 0x1d;
			break;
		case(11) :
			phy_addr = 0x1e;
			break;
		case(12) :
			phy_addr = 0x1f;
			break;
		default:
			return -EINVAL;
	}

	/* 1st write/read */
	cfg.phy_addr = phy_addr;
	cfg.data = 0x8000;
	cfg.reg = 0;

	dpmac_mdio_write(dpmac, &cfg);
	cfg.data = 0;
	dpmac_mdio_read(dpmac, &cfg);
	if (cfg.data == 0xFFFF)
		return -ENAVAIL;

	/* 2nd write/read */
	if (phy_loop == 1) /* loopback */
		cfg.data = 0x1000;
	else
		cfg.data = 0x200;
	cfg.reg = 9;

	dpmac_mdio_write(dpmac, &cfg);
	cfg.data = 0;
	dpmac_mdio_read(dpmac, &cfg);
	if (cfg.data == 0xFFFF)
		return -ENAVAIL;

	/* 3rd write/read */
	if (phy_loop == 0) { /* no-loopback */
		cfg.data = 0xc01;
		cfg.reg = 4;

		dpmac_mdio_write(dpmac, &cfg);
		cfg.data = 0;
		dpmac_mdio_read(dpmac, &cfg);
		if (cfg.data == 0xFFFF)
			return -ENAVAIL;
	}

	/* 4th write/read */
	if (phy_loop == 1)  /* loopback */
		cfg.data = 0x4140;
	else
		cfg.data = 0x120;
	cfg.reg = 0;

	dpmac_mdio_write(dpmac, &cfg);
	cfg.data = 0;
	dpmac_mdio_read(dpmac, &cfg);
	if (cfg.data == 0xFFFF)
		return -ENAVAIL;

	return 0;
}

void dpmac_set_tx_pause_frames(struct dpmac *dpmac, int enable)
{
	eiop_memac_set_tx_pause_frames(&dpmac->mac_desc, enable);
}

void dpmac_set_rx_ignore_pause_frame(struct dpmac *dpmac, int enable)
{
	eiop_memac_set_rx_ignore_pause_frames(&dpmac->mac_desc, enable);
}

int dpmac_get_ppid(struct dpmac *dpmac)
{
	return eiop_port_get_ppid(&dpmac->port_desc);
}

int dpmac_is_10g_mac(struct dpmac *dpmac)
{
	return ((dpmac->enet_if == FSL_ENET_IF_XFI) || (dpmac->enet_if == FSL_ENET_IF_USXGMII));
}

int dpmac_is_25g_mac(struct dpmac *dpmac)
{
	return ((dpmac->enet_if == FSL_ENET_IF_CAUI) && (dpmac->mac_desc.no_lanes == 1));
}

int dpmac_is_50g_mac(struct dpmac *dpmac)
{
	return ((dpmac->enet_if == FSL_ENET_IF_CAUI) && (dpmac->mac_desc.no_lanes == 2));
}

int dpmac_is_100g_mac(struct dpmac *dpmac)
{
	return ((dpmac->enet_if == FSL_ENET_IF_CAUI) && (dpmac->mac_desc.no_lanes == 4));
}

struct dpmac *dpmac_get_handle(struct dpmac *dpmac)
{
	return (struct dpmac *)sys_get_handle(FSL_MOD_DPMAC, 1, dpmac->id);
}

int dpmac_get_id(struct dpmac *dpmac)
{
	return dpmac->id;
}

enum dpmac_link_type dpmac_get_link_type(struct dpmac *dpmac)
{
	return dpmac->link_type;
}

void dpmac_set_link_type(enum dpmac_link_type link_type, struct dpmac *dpmac)
{
	dpmac->link_type = link_type;
}

void dpmac_set_linkup_from_phy(int linkup_from_phy, struct dpmac *dpmac)
{
	dpmac->linkup_from_phy = linkup_from_phy;
}

int dpmac_get_eiop_id(struct dpmac *dpmac)
{
	return dpmac->eiop_id;
}

struct dpni *dpmac_get_dpni(struct dpmac *dpmac)
{
	return dpmac->dpni;
}

int dpmac_check_empty(struct dpmac *dpmac, int tries, uint32_t tmp)
{
	void *tmp_regs;

	/*pointer to Egress Port area registers*/
	tmp_regs = (void *)UINT_TO_PTR(PTR_TO_UINT(dpmac->port_desc.vaddr) +
			EIOP_PORT_EGRESS_OFFSET);
	/*pointer to FPM Port registers*/
	tmp_regs = (struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(tmp_regs) +
				EIOP_FPM_PORT_OFFSET);

	tries = 10;
	/* eiop_port_tx_disable(eiop_port_desc->vaddr); */
	
	/* MAC is in loopback, if IFP passed (!BSY), must pass also TX_PORT if no errata*/
	do {
		tmp = ioread32(&((struct eiop_fpm_port *)tmp_regs)->st) &
				EIOP_PORT_TX_ST_BSY;
	} while((tmp == EIOP_PORT_TX_ST_BSY) && --tries);
	if ((tmp == EIOP_PORT_TX_ST_BSY) && tries == 0) {
		tmp = ioread32(&((struct eiop_fpm_port *)tmp_regs)->st);
		pr_err("mEMAC Errata A-011436 occured. Remaining %d pending frames\n", (tmp & EIOP_PORT_TX_ST_NTSKS));
		return -ETIMEDOUT;
	}

	return 0;
}
