/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPMAC_CMD_H
#define _DPMAC_CMD_H

/* default version for all dpni commands */
#define DPMAC_CMD_VER_BASE                       CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPMAC_CMD_V0							CMDHDR_CMD_VERSION(0)
#define DPMAC_CMD_V1							CMDHDR_CMD_VERSION(1)
#define DPMAC_CMD_V2							CMDHDR_CMD_VERSION(2)
#define DPMAC_CMD_V3							CMDHDR_CMD_VERSION(3)

/* add your new command version number here
 * Ex:
 * #define DPMAC_CMD_CREATE_VER_1                MC_CMD_HDR_VERSION(DPMAC_CMD_VER_BASE + 1) or
 * #define DPMAC_CMD_CREATE_VER                  MC_CMD_HDR_VERSION(3)
 */

/* Command IDs */
#define DPMAC_CMD_CODE_CLOSE                       0x800
#define DPMAC_CMD_CODE_OPEN                        0x80c
#define DPMAC_CMD_CODE_CREATE                      0x90c
#define DPMAC_CMD_CODE_DESTROY                     0x900
#define DPMAC_CMD_CODE_GET_API_VERSION             0xa0c

#define DPMAC_CMD_CODE_GET_ATTR                    0x004
#define DPMAC_CMD_CODE_RESET                       0x005

#define DPMAC_CMD_CODE_SET_IRQ                     0x010
#define DPMAC_CMD_CODE_GET_IRQ                     0x011
#define DPMAC_CMD_CODE_SET_IRQ_ENABLE              0x012
#define DPMAC_CMD_CODE_GET_IRQ_ENABLE              0x013
#define DPMAC_CMD_CODE_SET_IRQ_MASK                0x014
#define DPMAC_CMD_CODE_GET_IRQ_MASK                0x015
#define DPMAC_CMD_CODE_GET_IRQ_STATUS              0x016
#define DPMAC_CMD_CODE_CLEAR_IRQ_STATUS            0x017

#define DPMAC_CMD_CODE_MDIO_READ                   0x0c0
#define DPMAC_CMD_CODE_MDIO_WRITE                  0x0c1
#define DPMAC_CMD_CODE_GET_LINK_CFG                0x0c2
#define DPMAC_CMD_CODE_SET_LINK_STATE              0x0c3
#define DPMAC_CMD_CODE_GET_COUNTER                 0x0c4

#define DPMAC_CMD_CODE_GET_MAC_ADDR                0x0c5
#define DPMAC_CMD_CODE_SET_PARAMS				   0x0c6

#endif /* _DPMAC_CMD_H */
