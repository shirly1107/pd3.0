/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          backplane.h

 @Description   Backplane structures and definitions.
 *//***************************************************************************/
#ifndef __BACKPLANE_H
#define __BACKPLANE_H

#include "fsl_types.h"
#include "fsl_serdes.h"
#include "fsl_eiop_memac.h"

struct dpmac;

/* 10GBase-KR state machine */
struct training_state_machine {
	int bin_m1_late_early;
	int bin_long_late_early;
	int bin_m1_stop;
	int bin_long_stop;
	int tx_complete;
	int an_ok;
	int link_up;
	int running;
	int sent_init;
	int m1_min_max_cnt;
	int long_min_max_cnt;
};

struct xgkr_inst {
	struct training_state_machine t_s_m;
	struct serdes_kr_cfg kr_cfg;
	uint32_t ld_update;
	uint32_t ld_status;
};

enum coe_update {
	COE_NOTUPDATED = 0,
	COE_UPDATED = 1,
	COE_MIN = 2,
	COE_MAX = 3,
	COE_INV = 4
};

enum coe_field {
	COE_COP1,
	COE_COZ,
	COE_COM1
};

/* 1000_BASE_KX */
/* 1000Base-KX Registers Families */
#define KX_PCS			0x3
#define KX_AN			0x7
#define KX_VS1			0x1d

/* MDIO PCS Registers */
#define MDIO_SGMII_CR		0x8000
#define MDIO_SGMII_LINK_TMR_L	0x8012
#define MDIO_SGMII_LINK_TMR_H	0x8013
#define MDIO_SGMII_IF_MODE	0x8014

/* MDIO_SGMII_CR values */
#define MDIO_SGMII_CR_RST	0x8000
#define MDIO_SGMII_CR_AN_EN	0x1000

/* MDIO_SGMII_IF_MODE values */
#define MDIO_SGMII_IF_MODE_1G	0x0008

/* MDIO SGMII Values */
#define LINK_TMR_U		0x002f
#define LINK_TMR_L		0xaf08
#define SGMII_SPEED		0x0008

/* 1000Base-KX Auto-Negotiation Registers */
#define MDIO_KX_AN_CR		0x0
#define MDIO_KX_AN_SR		0x1
#define MDIO_KX_AN_ADVERT1	0x11

/* Auto-Negotiation Values */
#define MDIO_KX_AN_CR_BP_AN_ENAB	0x1000
#define MDIO_KX_AN_CR_RESTART_BP_AN	0x0200
#define MDIO_KX_AN_ADVERT1_TRANS_NONCE	0x0008
#define MDIO_KX_AN_ADVERT1_A0		0x0020
#define LNK_STAT			0x0004
#define AN_COMP				0x0020

/* 1000Base-KX PCS registers */
#define MDIO_KX_PCS_CR			0x0
#define MDIO_KX_PCS_SR			0x1

/* PCS Values */
#define MDIO_KX_PCS_SR_LINK_STAT	0x0004

#define MII_WRITE(dpmac, phy_fam, phy_reg, data, clause) \
	eiop_memac_mii_write_phy_reg( \
			(struct memac_mii_access_mem_map *)dpmac->mac_mii_regs, \
			GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, phy_fam), \
			phy_reg, \
			data, \
			clause);

#define MII_READ(dpmac, phy_fam, phy_reg, data, clause) \
	eiop_memac_mii_read_phy_reg( \
			(struct memac_mii_access_mem_map *)dpmac->mac_mii_regs, \
			GET_PHY_AND_DEVICE_ADDR(PHY_MDIO_ADDR, phy_fam), \
			phy_reg, \
			data, \
			clause);

/* 10GBase-KR Registers Families */
#define XFI_PMD			0x1
#define XFI_PCS			0x3
#define XFI_AN			0x7
#define XFI_VS1			0x1e

/* XFI PMA/PMD registers */
#define MDIO_XFI_PMD_CR1		0x0
#define MDIO_XFI_10GKR_PMD_CR		0x0096
#define MDIO_XFI_10GKR_PMD_SR		0x0097
#define MDIO_XFI_10GKR_LP_COEF_UPDATE	0x0098
#define MDIO_XFI_10GKR_LP_SRR		0x0099
#define MDIO_XFI_10GKR_LD_COEF_UPDATE	0x009a
#define MDIO_XFI_10GKR_LD_SRR		0x009b

/* MDIO_XFI_PMD_CR1 defines */
#define MDIO_XFI_PMD_CR1_PMD_RESET_MASK 0x1

/* MDIO_XFI_10GKR_PMD_CR defines */
#define MDIO_XFI_10GKR_PMD_CR_TRAIN_DIS	0x1
#define MDIO_XFI_10GKR_PMD_CR_TRAIN_EN	0x0003

/* MDIO_XFI_10GKR_PMD_SR defines */
#define MDIO_XFI_10GKR_PMD_SR_RX_STAT		0x0001
#define MDIO_XFI_10GKR_PMD_SR_FRAME_LOCK	0x0002
#define MDIO_XFI_10GKR_PMD_SR_SUP_STAT		0x0004
#define MDIO_XFI_10GKR_PMD_SR_TRAIN_FAIL	0x0008

/* XFI PCS registers */
#define MDIO_XFI_PCS_CR1		0x0000

/* MDIO_XFI_PCS_CR1 defines */
#define MDIO_XFI_PCS_CR1_RESET		0x8000

/* XFI Auto-Negotiation registers */
#define MDIO_XF_AN_CR			0x0000
#define MDIO_XF_AN_SR			0x0001
#define MDIO_XFI_AN_ADVERT1		0x0011
#define MDIO_XFI_AN_LP_BASE_PG_ABIL1	0x0014
#define MDIO_XFI_BP_STAT		0x0030

/* MDIO_XF_AN_CR defines */
#define MDIO_XF_AN_CR_AN_EN_AND_RESTART	0x1200
#define MDIO_XF_AN_CR_EXT_NP_CTRL	0x2000

/* MDIO_XF_AN_SR defines */
#define MDIO_XF_AN_SR_LNK_STAT		0x0004

/* MDIO_XFI_AN_ADVERT1 defines */
#define MDIO_XFI_AN_ADVERT1_KR_ADV	0x85

/* MDIO_XFI_BP_STAT defines */
#define MDIO_XFI_BP_STAT_10GBASE_KR	0x0008

/* XFI Vendor-Specific 1 registers */
#define MDIO_XFI_VND_PCS_INT		0x2
#define MDIO_XFI_VND_PCS_INT_MSK	0x3
#define MDIO_XFI_VND_AN_INT		0x4
#define MDIO_XFI_VND_AN_INT_MSK		0x5
#define MDIO_XFI_VND_LT_INT		0x6
#define MDIO_XFI_VND_LT_INT_MSK		0x7

/* MDIO_XFI_VND_PCS_INT_MASK defines */
#define MDIO_XFI_VND_PCS_INT_MSK_VAL	0x3FF

/* MDIO_XFI_VND_AN_INT_MASK_VAL defines */
#define MDIO_XFI_VND_AN_INT_MSK_VAL	0x1F

/* MDIO_XFI_VND_LT_INT_MASK defines */
#define MDIO_XFI_VND_LT_INT_MSK_VAL	0xF

/* SerDesx_LNnTECR0 - Defaults for 10Gbase-KR*/
#define RATIO_PREQ			0x2
#define RATIO_PST1Q			0xd
#define ADPT_EQ				0x20

#define RX_READY_MASK			0x8000	/* ready mask for LD_SRR (ld_status) */

/* Coefficient defines */
#define PRESET_MASK			0x2000		/* preset the transmitter coefficients */
#define INIT_MASK			0x1000		/* initialize the transmitter coefficients */
#define COP1_MASK			0x30	/* coefficient (+1) reserved */
#define COZ_MASK			0xc	/* coefficient (0) reserved */
#define COM1_MASK			0x3	/* coefficient (-1) reserved */
#define LD_ALL_MASK			(PRESET_MASK |	\
					 INIT_MASK |	\
					 COP1_MASK |	\
					 COZ_MASK |	\
					 COM1_MASK)
#define REQUEST_MASK			(COP1_MASK |	\
                    			 COZ_MASK |	\
                    			 COM1_MASK)

#define COP1_SHIFT			4	/* shift for COP1_STAT field */
#define COZ_SHIFT			2	/* shift for COZ_STAT field */
#define COM1_SHIFT			0	/* shift for COM1_STAT field */

#define PRE_COE_MAX			0x0
#define PRE_COE_MIN			0x8
#define POST_COE_MAX			0x0
#define POST_COE_MIN			0x10
#define ZERO_COE_MAX			0x30
#define ZERO_COE_MIN			0x0

#define INCREMENT			1
#define DECREMENT			2
#define TIMEOUT_LONG			3
#define TIMEOUT_M1			3

#define LINK_TRAIN_CONTINUE		1


int dpmac_set_1000base_kx_link(struct dpmac *dpmac);

int dpmac_get_1000base_kx_link_state(struct dpmac *dpmac);

int dpmac_set_10gbase_kr_link(struct dpmac *dpmac);

int dpmac_get_10gbase_kr_link_state(struct dpmac *dpmac);

#endif /* __BACKPLANE_H */
