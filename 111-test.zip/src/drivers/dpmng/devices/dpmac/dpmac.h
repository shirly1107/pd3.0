/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpmac.h

 @Description   DPMAC internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPMAC_H
#define __DPMAC_H

#include "kernel/fsl_spinlock.h"
#include "fsl_event_pipe.h"
#include "fsl_dpmac_mc.h"
#include "fsl_serdes.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPMAC

enum enable_mode {
	ENABLE_MODE_NONE		= 0,
	ENABLE_MODE_RX			= 1,
	ENABLE_MODE_TX   		= 2
};


#define NUM_OF_PFC_PRIORITIES	8
#define DEFAULT_IFP_ID		0

#define MEMAC_DEFAULT_EXCEPTIONS    		\
	((uint32_t)(MEMAC_IMASK_MGI))

struct dpmac_handles {
	struct linkman     	*linkman;   	/*! Link manager 2.0 */
	struct dpmng        	*dpmng;     	/*! General manager */
};


struct dpmac {
	struct device	*device;
	int		enabled;

	/* IRQ related parameters */
	struct dpmng_amq amq;
	struct mc_irq irqs[DPMAC_MAX_IRQ_NUM];

	/* EIOP parameters */
	int eiop_id;

	/* MAC related parameters */
	int id;
	struct memac_mii_access_mem_map *mac_mii_regs;
	struct memac_cfg cfg;
	int loopback;
	enum enet_mode enet_mode;
	enum enet_interface enet_if;
	uint32_t rate;
	enum dpmac_eth_if eth_if;
	uint32_t exceptions;

	/* Physical port parameters */
	int ppid;
	int ifpid;

	/* Descriptors */
	struct eiop_memac_desc mac_desc;
	struct eiop_port_desc port_desc;
	struct pport_connections_desc connection_desc;
	struct serdes_desc serdes_desc;

	/* Link parameters */
	struct linkman_link_state link_cfg;
	struct dpni *dpni;

	/* Handles used in DPMAC */
	struct dpmac_handles handles;
	void* timer;

	/* DPC information */
	enum dpmac_link_type link_type;
	enum dpmac_fec_mode fec_mode;
	int phy_id;

	/* SerDes configuration mode*/
	enum serdes_eq_cfg_mode serdes_cfg_mode;

	int linkup_from_phy;

	int restore;
};

/* Internal PHY access */
#define PHY_MDIO_ADDR               0
/* Offset from the MEM map to the MDIO memory map */
#define MEMAC_TO_MII_OFFSET         0x030

#define GET_PHY_AND_DEVICE_ADDR(phy_addr, device_addr) \
    ((phy_addr << 5) | device_addr)

/* SGMII regs */
#define MDIO_SGMII_SR		0x1
/* MDIO_SGMII_SR fields */
#define LINK_STAT_MASK		0x0004
/* MDIO USXGMII CR fields */
#define CR_AUTONEG_ENABLE    0x1000
#define CR_RESTART_AUTONEG   0x0200
/* MDIO USXGMII DEV_ABILITY fields*/
#define DV_AB_LINK_STATUS    0x8000
#define DV_AB_DUPLEX_MODE    0x1000
#define DV_AB_10_GB          0x0600
#define DV_AB_EEE_SUPORT     0x0100
#define DV_AB_EEE_CLOCK_STOP 0x0080
#define DV_AB_USXGMII        0x0001
/* MDIO Link Timer value ~3ms
 * SerDes defaults are T1=0xC4B4, T2=0x4
 * validation used T1=0x60EC, T2=0xE
 */
#define LINK_TIMER_1_VALUE  0x71fc
#define LINK_TIMER_2_VALUE  0x000E

/* SerDes MDIO Device addresses */
#define MDD_PMD                 0x1
#define MDD_PCS                 0x3
#define MDD_AN                  0x7
#define MDD_USXGMII             0x1f
#define MDD_VENDOR_SPESIFIC_1   0x1e

/* XFI PCS regs */
#define MDIO_XFI_PCS_SR1	1

/* USXGMII regs */
#define MDIO_USXGMII_CONTROL         0x0
#define MDIO_USXGMII_STATUS          0x1
#define MDIO_USXGMII_DEV_ABILITY     0x4
#define MDIO_USXGMII_PARTNER_ABILITY 0x5
#define MDIO_USXGMII_LINK_TIMER1     0x12
#define MDIO_USXGMII_LINK_TIMER2     0x13

/* RS-FEC(CL91) & FC-FEC(CL74) related stuff */
struct pcs_fec_regs {
	uint32_t reg;
	uint16_t data;
	uint8_t wait;
	uint8_t errata; /* used for errata implementations, etc */
};

#define GET_FEC_REGS_COUNT(x)	(sizeof((x))/sizeof(struct pcs_fec_regs))

/* MDIO_XFI_PCS_SR1 fields */
#define PCS_RX_LNK_STAT_MASK 	0x0004

#endif /* __DPMAC_H */
