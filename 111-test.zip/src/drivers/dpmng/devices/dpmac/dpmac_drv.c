/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpmac_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "kernel/device.h"
#include "fsl_soc.h"
#include "fsl_sys.h"
#include "fsl_platform.h"
#include "fsl_cmdif_mc.h"
#include "dplib/fsl_dpmac_cmd.h"
#include "fsl_dprc_mc.h"
#include "fsl_linkman.h"
#include "fsl_resman.h"
#include "fsl_eiop_port.h"
#include "fsl_eiop_memac.h"
#include "fsl_dpmac_mc.h"
#include "dtc/dtc.h"
#include "dpmac_cmd.h"
#include "dpmac.h"
#include "legacy_dpmac_dplib.h"

/* DPMAC last supported APi version */
#define DPMAC_V0_API_VER_MAJOR				3
#define DPMAC_V0_API_VER_MINOR				2

int dpmac_drv_init(void);
int init_common(struct device* dev, struct dpmac_cfg *cfg);
int get_attributes_common(struct device* dev, union dpmac_attr *attr);

/*                cmd, param, offset, width, type, arg_name */
#define DPMAC_LO_CREATE(cmd, cfg) \
	MC_RSP_OP(cmd, 0, 0,  32, int,      cfg->mac_id);

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpmac *dpmac;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	return dpmac_set_dev_ctx(dpmac, dev_ctx);
}

/*
 * Real initialization function shared by all version of initialization callbacks
 */
int init_common(struct device* dev, struct dpmac_cfg *cfg)
{
	struct dpmac *dpmac;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	int err;
	
	dpmac = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpmac) {
		/* NULL */
		dpmac = dpmac_allocate();
		if (!dpmac) {
			pr_err("No memory for dpmac\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpmac_init(dpmac, cfg->mac_id);
		if (err) {
			return err;
		}
		device_set_priv(dev, dpmac);
		sys_add_handle(dpmac, FSL_MOD_DPMAC, 1, dev_cfg.id);

		assign(dev, &(dev_cfg.ctx));
	} else
		return -EINVAL;

	return 0;
	
}

/*
 * Real get attributes implementation shared by all version of get_attributes callbacks
 */
int get_attributes_common(struct device* dev, union dpmac_attr *attr)
{
	struct dpmac *dpmac = device_get_priv(dev);
	CHECK_COND_RETVAL(dpmac, -ENODEV);

	return dpmac_get_attributes(dpmac, attr);
}

static int init_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac_cfg dpmac_cfg = { 0 };
	struct dpmac_cfg *cfg = &dpmac_cfg;

	DPMAC_CMD_CREATE_v0(cmd_data, cfg);
	
	return init_common(dev, cfg);
}

static int init_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac_cfg dpmac_cfg = { 0 };
	struct dpmac_cfg *cfg = &dpmac_cfg;

	DPMAC_CMD_CREATE(cmd_data, cfg);
	
	return init_common(dev, cfg);
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;

	UNUSED(cmd_data);

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	dpmac_destroy(dpmac);

	sys_remove_handle(FSL_MOD_DPMAC, 1, device_get_id(dev));
	dpmac_deallocate(dpmac);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	struct dpmng_dev_ctx dev_ctx;
	int err;

	UNUSED(cmd_data);

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	err = dpmac_reset(dpmac);
	if (!err) {
		resman_get_dev_ctx(dev, &dev_ctx, 1);
		device_set_enable(dev, 0);
		err = assign(dev, &dev_ctx);
	}

	return err;
}

static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}

#ifdef TKT011436
static int restore_by_resman(struct device *dev)
{
	struct dpmac *dpmac;
	int err;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	pr_info("DPMAC[%d] restore after WRIOP reset\n", dpmac->id);

	dpmac->restore = 1;

	err = dpmac_hw_init(dpmac, dpmac->id);
	CHECK_COND_RETVAL(!err, err);

	dpmac->restore = 0;
	dpmac->linkup_from_phy = 0;

	return err;
}
#endif /* TKT011436 */

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	union dpmac_attr attr = { 0 };

	int err = get_attributes_common(dev, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.v0.version.major = DPMAC_V0_API_VER_MAJOR;
	attr.v0.version.minor = DPMAC_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMAC_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr.v0);

	return err;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	union dpmac_attr attr = { 0 };

	int err = get_attributes_common(dev, &attr);
	CHECK_COND_RETVAL(!err, err);

	/* pack response */
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMAC_RSP_GET_ATTRIBUTES_V1(cmd_data, &attr.v1);

	return err;
}

static int get_attributes_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	union dpmac_attr attr = { 0 };
	struct dpmac *dpmac;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	int err = get_attributes_common(dev, &attr);
	CHECK_COND_RETVAL(!err, err);

	err = dpmac_get_serdes_eq_setup(dpmac, &attr);
	CHECK_COND_RETVAL(!err, err);

	/* pack response */
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMAC_RSP_GET_ATTRIBUTES_V2(cmd_data, &attr.v2);

	return err;
}

static int get_attributes_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	union dpmac_attr attr = { 0 };
	struct dpmac *dpmac;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	int err = get_attributes_common(dev, &attr);
	CHECK_COND_RETVAL(!err, err);

	err = dpmac_get_serdes_eq_setup(dpmac, &attr);
	CHECK_COND_RETVAL(!err, err);
	
	err = dpmac_get_ifg_mode(dpmac, &(attr.v3.ifg_cfg));
	CHECK_COND_RETVAL(!err, err);

	/* pack response */
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMAC_RSP_GET_ATTRIBUTES_V3(cmd_data, &attr.v3);

	return err;
}

static int set_params(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac_ifg_cfg cfg;
	struct dpmac *dpmac;
	uint32_t flags;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;
	
	DPMAC_CMD_SET_PARAMS(cmd_data, &cfg, flags);
	
	if (flags & DPMAC_SET_PARAMS_IFG)
		return dpmac_set_ifg_mode(dpmac, &cfg);
	
	return 0;
}


static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	DPMAC_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dpmac_set_irq(dpmac, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpmac *dpmac;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	return dpmac_set_irq(dpmac, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	/* Read parameters from portal */
	DPMAC_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpmac_get_irq(dpmac, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMAC_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpmac *dpmac;
	int err;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	err = dpmac_get_irq(dpmac, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;
	
	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	uint8_t irq_index;
	uint8_t en;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	/* Read parameters from portal */
	DPMAC_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, en);

	return dpmac_set_irq_enable(dpmac, irq_index, en);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	uint8_t irq_index;
	uint8_t en;
	int err;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	/* Read parameters from portal */
	DPMAC_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpmac_get_irq_enable(dpmac, irq_index, &en);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMAC_RSP_GET_IRQ_ENABLE(cmd_data, en);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	uint8_t irq_index;
	uint32_t mask;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	/* Read parameters from portal */
	DPMAC_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpmac_set_irq_mask(dpmac, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	/* Read parameters from portal */
	DPMAC_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpmac_get_irq_mask(dpmac, irq_index, &mask);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMAC_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	/* Read parameters from portal */
	DPMAC_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpmac_get_irq_status(dpmac, irq_index, &status);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPMAC_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	uint8_t irq_index;
	uint32_t status;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	/* Read parameters from portal */
	DPMAC_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpmac_clear_irq_status(dpmac, irq_index, status);
}

static int mdio_read(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	struct dpmac_mdio_cfg read_cfg = { 0 };
	struct dpmac_mdio_cfg *cfg = &read_cfg;
	int err;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	DPMAC_CMD_MDIO_READ(cmd_data, cfg);

	err = dpmac_mdio_read(dpmac, cfg);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPMAC_RSP_MDIO_READ(cmd_data, cfg->data);
	}
	return err;
}

static int mdio_write(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	struct dpmac_mdio_cfg write_cfg = { 0 };
	struct dpmac_mdio_cfg *cfg = &write_cfg;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	DPMAC_CMD_MDIO_WRITE(cmd_data, cfg);

	return dpmac_mdio_write(dpmac, cfg);
}

static int get_link_cfg(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpmac *dpmac;
	struct dpmac_link_cfg link_cfg;
	struct dpmac_link_cfg *cfg = &link_cfg;
	int err;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	memset(cfg, 0, sizeof(struct dpmac_link_cfg));

	err = dpmac_get_link_cfg(dpmac, cfg);
	if (err)
		return err;
	
	if (ver < 2)
		DPMAC_RSP_GET_LINK_CFG_V1(cmd_data, cfg);
	else
		DPMAC_RSP_GET_LINK_CFG(cmd_data, cfg);

	return 0;
}

static int get_link_cfg_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_link_cfg(dev, cmd_data, 1);
}

static int get_link_cfg_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_link_cfg(dev, cmd_data, 2);
}


static int set_link_state(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpmac *dpmac;
	struct dpmac_link_state link_state;
	struct dpmac_link_state *cfg = &link_state;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	memset(cfg, 0, sizeof(struct dpmac_link_state));
	
	if (ver < 2)
	{
		DPMAC_CMD_SET_LINK_STATE_V1(cmd_data, cfg);
		cfg->advertising = 0;
		cfg->supported = 0;
		cfg->state_valid = 1;
	}
	else
		DPMAC_CMD_SET_LINK_STATE(cmd_data, cfg);

	return dpmac_set_link_state(dpmac, cfg);
}

static int set_link_state_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_link_state(dev, cmd_data, 1);
}
static int set_link_state_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_link_state(dev, cmd_data, 2);
}

static int get_link_speed(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	UNUSED(cmd_data);

	return 0;
}

static int get_counter(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	enum dpmac_counter type;
	uint64_t counter;
	int err;

	dpmac = device_get_priv(dev);
	if (!dpmac)
		return -ENODEV;

	DPMAC_CMD_GET_COUNTER(cmd_data, type);

	err = dpmac_get_counter(dpmac, type, &counter);
	if (err)
		return err;

	DPMAC_RSP_GET_COUNTER(cmd_data, counter);

	return 0;
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPMAC_VER_MAJOR;
    uint32_t minor = DPMAC_VER_MINOR;

    DPMAC_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int dpmac_get_mac_addr(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpmac *dpmac;
	int err;
	uint8_t addr[6];

	dpmac = device_get_priv(dev);
	CHECK_COND_RETVAL(dpmac, -ENODEV);

	err = dpmac_get_port_mac_addr(dpmac, addr);

	DPMAC_RSP_GET_PORT_MAC_ADDR(cmd_data, addr);

	return 0;
}

/* Command portal related functions */
static int dpmac_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpmac_open on DPMAC %d\n", device_get_id(dev));

	return 0;
}

static int dpmac_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpmac_close on DPMAC %d\n", device_get_id(dev));
	return 0;
}

static int dpmac_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev, struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = { { DPMAC_CMD_CODE_CREATE, init_v0, "dpmac_create", DPMAC_CMD_V0 },
	     		{ DPMAC_CMD_CODE_DESTROY, destroy, "dpmac_destroy", DPMAC_CMD_VER_BASE },


	     		{ DPMAC_CMD_CODE_RESET, reset, "dpmac_reset", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_GET_ATTR, get_attributes_v0, "dpmac_get_attributes", DPMAC_CMD_V0 },
	     		{ DPMAC_CMD_CODE_SET_IRQ, set_irq, "dpmac_set_irq", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_GET_IRQ, get_irq, "dpmac_get_irq", DPMAC_CMD_VER_BASE }, {
	     			DPMAC_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable,
	     			"dpmac_set_irq_enable", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable,
	     			"dpmac_get_irq_enable", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpmac_set_irq_mask", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpmac_get_irq_mask", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_GET_IRQ_STATUS, get_irq_status,
	     			"dpmac_get_irq_status", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status,
	     			"dpmac_clear_irq_status", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_MDIO_READ, mdio_read, "dpmac_mdio_read", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_MDIO_WRITE, mdio_write, "dpmac_mdio_write", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_GET_LINK_CFG, get_link_cfg_v1, "dpmac_get_link_cfg", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_SET_LINK_STATE, set_link_state_v1, "dpmac_set_link_state", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_GET_COUNTER, get_counter, "dpmac_get_counter", DPMAC_CMD_VER_BASE },

	     		/* New command handlers start here */
                { DPMAC_CMD_CODE_GET_API_VERSION, get_api_version, "dpmac_get_api_version", DPMAC_CMD_V1 },
                { DPMAC_CMD_CODE_CREATE, init_v1, "dpmac_init", DPMAC_CMD_V1},
                { DPMAC_CMD_CODE_GET_ATTR, get_attributes_v1, "dpmac_get_attributes", DPMAC_CMD_V1 },
	     		{ DPMAC_CMD_CODE_GET_LINK_CFG, get_link_cfg_v2, "dpmac_get_link_cfg", DPMAC_CMD_V2 },
	     		{ DPMAC_CMD_CODE_SET_LINK_STATE, set_link_state_v2, "dpmac_set_link_state", DPMAC_CMD_V2 },
	     		{ DPMAC_CMD_CODE_GET_MAC_ADDR, dpmac_get_mac_addr ,"dpmac_get_mac_addr", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_GET_ATTR, get_attributes_v2, "dpmac_get_attributes", DPMAC_CMD_V2 },
	     		{ DPMAC_CMD_CODE_SET_PARAMS, set_params, "dpmac_set_params", DPMAC_CMD_VER_BASE },
	     		{ DPMAC_CMD_CODE_GET_ATTR, get_attributes_v3, "dpmac_get_attributes", DPMAC_CMD_V3 },

	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))){
			if (cmd == DPMAC_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPMAC %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function(dev, cmd_data);
		}
	pr_err("Invalid command %d\n",cmd);
	return -ENOTSUP;
}

static int dpmac_probe_cb(void *lo, int node_off)
{
	int err = 0, prev_err = 0;
	struct dpmac_cfg dpmac_cfg = { 0 };
	struct dpmac_cfg *cfg = &dpmac_cfg;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	int id;
	int destroy = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(resman, "dpmac", (uint16_t)id, NO_PORTAL_ID,
			DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPMAC %.4x\n", id);
	cfg->mac_id = id;

	DPMAC_LO_CREATE(cmd_data, cfg);
	/* create object */
	prev_err = dpmac_ctrl_cb(dev, DPMAC_CMD_VER_BASE,
			DPMAC_CMD_CODE_CREATE, NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (prev_err) {
		pr_err("CREATE failed for MAC ID[%d]. The MAC is not enabled through"
				"SerDes protocol or ECx_PMUX (RGMII)\n", id);
		destroy = 1;
	}

	err = resman_close_dev(resman, dev, "dpmac", NO_PORTAL_ID, destroy);

	if( err )
		/* close_dev() error: return this error to upper layers */
		return err;
	else
		/* close_dev() OK: return result of DPMAC_CMDID_CREATE command;
		 * upper layers need to know if CREATE command is successful */
		return prev_err;
}

static int dpmac_remove_cb(void *lo, int node_off)
{
	UNUSED(node_off);
	return 0;
}

static char *dpmac_match[] = { "dpmac", "fsl,dpmac" };

int dpmac_drv_init(void)
{
	int err = 0;
	t_sys_dtc_mod_params lo_params= { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	struct linkman *linkman;

	pr_info("Executing dpmac_drv_init...\n");
	
	/*! Register layout */
	lo_params.num_compats = ARRAY_SIZE(dpmac_match);
	lo_params.compatibles = dpmac_match;
	lo_params.f_prob_module = dpmac_probe_cb;
	lo_params.f_remove_module = dpmac_remove_cb;
	err = sys_dtc_register_module(&lo_params);
	if (err != 0)
		return err;

	/*! Register command interface */
	cmdif_ops.open_cb = dpmac_open_cb;
	cmdif_ops.close_cb = dpmac_close_cb;
	cmdif_ops.ctrl_cb = dpmac_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	err = cmdif_register_module(CMDIF_MOD_DPMAC, &cmdif_ops);
	if (err != 0)
		return err;

	/*! Register resman */
	strcpy(dev_type_param.device_type, "dpmac");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPMAC_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPMAC_VER_MAJOR;
	dev_type_param.ver_minor = DPMAC_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;
#ifdef TKT011436
	dev_type_param.f_restore_after_eiop_reset = restore_by_resman;
#endif /* TKT011436 */

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman)
		return err;
	err = resman_register_device_operation(resman, "dpmac", &dev_type_param);
	if (err != 0)
		return err;

	/* Register to Link Manager */
	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	CHECK_COND_RETVAL(linkman, -ENODEV);
	err = linkman_register_cb(linkman, 
	                          FSL_MOD_DPMAC, 
	                          dpmac_event_cb,
	                          dpmac_event_complete_cb);

	return err;
}
