/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpdmai.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_event_pipe.h"

#include "fsl_dpmng_mc.h"
#include "fsl_dpcon_mc.h"
#include "fsl_dpio_mc.h"
#include "fsl_dpbp_mc.h"
#include "fsl_dpdmai_mc.h"

#include "dpdmai.h"

static int resources_allocation(struct dpdmai *dpdmai)
{
	int tmp[2 * DPDMAI_MAX_QUEUES * DPDMAI_PRIO_NUM] = { 0 };
	uint32_t num_queues;
	uint8_t queue_idx, prio_idx, prio_num, queue_type;
	int cgid[DPDMAI_PRIO_NUM] = { 0 };
	int err, i, j;

	/* FQIDs */
	num_queues = (uint32_t) (2 * dpdmai->priorities_num * dpdmai->num_queues);
	err = allocate_resource(dpdmai->device, "fq", num_queues,
					1, 0, &(tmp[0]), "DPDMAI-Q");
	CHECK_COND_RETVAL(err == 0, err, "dpdmai - cannot allocate fqid (requested number: %d)", num_queues);

	j = 0;
	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for( prio_idx = 0 ; prio_idx < dpdmai->priorities_num ; prio_idx++ ) {
			dpdmai->rx_queue_info[queue_idx][prio_idx].rx_fqid = (uint32_t)tmp[j++];
			pr_debug("dpdmai - Allocated Rx queue %d\n", dpdmai->rx_queue_info[queue_idx][prio_idx].rx_fqid);

			dpdmai->tx_queue_info[queue_idx][prio_idx].tx_fqid = (uint32_t)tmp[j++];
			pr_debug("dpdmai - Allocated Tx queue %d\n", dpdmai->tx_queue_info[queue_idx][prio_idx].tx_fqid);
		}
	}

	/* DPDMAI has 2 types of queues: Rx, Tx */
	for (queue_type = 0; queue_type < 2; queue_type++) {
		for (i = 0; i < DPDMAI_PRIO_NUM; i++)
			cgid[i] = DPDMAI_INVALID_ID;
		if (dpdmai->cg_per_priority)
			prio_num = dpdmai->priorities_num;
		else
			prio_num = 1; /* one CG for all priorities */

		err = allocate_resource(dpdmai->device, "cg", prio_num, 1, 0,
					cgid, "CG-id");	
		if (err)
			return err;

		for (i = 0; i < prio_num; i++) {
			if (queue_type == 0)
				dpdmai->rx_cgr_info[i].cgid = cgid[i];
			else
				dpdmai->tx_cgr_info[i].cgid = cgid[i];
		}
	}

	return 0;
}

static int resources_deallocation(struct dpdmai *dpdmai)
{
	int err;
	uint8_t queue_idx, prio_idx;
	int prio_num;
	int i;

	/* FQID */
	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for( prio_idx = 0 ; prio_idx < dpdmai->priorities_num ; prio_idx++ ) {
			err = deallocate_resource(dpdmai->device, "fq",
					(int)dpdmai->tx_queue_info[queue_idx][prio_idx].tx_fqid, "DPDMAI-Q");
			CHECK_COND_RETVAL(err == 0, err, "dpdmai - Unable to free fqid %d\n", dpdmai->tx_queue_info[queue_idx][prio_idx].tx_fqid);
			err = deallocate_resource(dpdmai->device, "fq",
					(int)dpdmai->rx_queue_info[queue_idx][prio_idx].rx_fqid, "DPDMAI-Q");
			CHECK_COND_RETVAL(err == 0, err, "dpdmai - Unable to free fqid %d\n", dpdmai->rx_queue_info[queue_idx][prio_idx].rx_fqid);
			pr_debug("\nDeallocate Tx queue %d\n", dpdmai->tx_queue_info[queue_idx][prio_idx].tx_fqid);
			pr_debug("\nDeallocate Rx queue %d\n", dpdmai->rx_queue_info[queue_idx][prio_idx].rx_fqid);
		}
	}

	/* CG */
	if ( dpdmai->cg_per_priority )
		prio_num = dpdmai->priorities_num;
	else
		prio_num = 1;

	for (i = 0 ; i < prio_num ; i++) {
		deallocate_resource(dpdmai->device, "cg", dpdmai->rx_cgr_info[i].cgid, "CG-id");
		deallocate_resource(dpdmai->device, "cg", dpdmai->tx_cgr_info[i].cgid, "CG-id");
	}

	return 0;
}

static int resources_authorization(struct dpdmai *dpdmai)
{
	struct qbman_swp *sw_portal = NULL;
	uint8_t queue_idx, prio_idx, prio_num, queue_type;
	uint32_t cgid, virtual_cgid;
	struct qbman_attr attr;
	int err;

	CHECK_COND_RETVAL(dpdmai, -EINVAL);

	if (dpdmai->authorized)
		return 0;

	dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);

	/* FQIDs */
	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for( prio_idx = 0 ; prio_idx < dpdmai->priorities_num ; prio_idx++ ) {
			err = resource_authorization(sw_portal, dpdmai->amq.bdi, dpdmai->amq.icid,
					qbman_auth_type_fqid,
					&dpdmai->tx_queue_info[queue_idx][prio_idx].tx_virt_fqid,
					dpdmai->tx_queue_info[queue_idx][prio_idx].tx_fqid,
					(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-FQID");
			CHECK_COND_RETVAL(err == 0, err, "dpdmai - resource_authorization()\n");
			err = resource_authorization(sw_portal, dpdmai->amq.bdi, dpdmai->amq.icid,
						qbman_auth_type_fqid,
						&dpdmai->rx_queue_info[queue_idx][prio_idx].rx_virt_fqid,
						dpdmai->rx_queue_info[queue_idx][prio_idx].rx_fqid,
						(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-FQID");
			CHECK_COND_RETVAL(err == 0, err, "dpdmai - resource_authorization\n");

			pr_debug("\nAuthorize Tx queue %d, (virt %d)\n",
					dpdmai->tx_queue_info[queue_idx][prio_idx].tx_fqid,
					dpdmai->tx_queue_info[queue_idx][prio_idx].tx_virt_fqid);
			pr_debug("\nAuthorize Rx queue %d, (virt %d)\n\n",
					dpdmai->rx_queue_info[queue_idx][prio_idx].rx_fqid,
					dpdmai->rx_queue_info[queue_idx][prio_idx].rx_virt_fqid);
		}
	}

	/* DPDMAI has 2 types of queues: Rx, Tx */
	for (queue_type = 0; queue_type < 2; queue_type++) {
		if (dpdmai->cg_per_priority)
			prio_num = dpdmai->priorities_num;
		else
			prio_num = 1; /* one CG for all priorities */
		
		for (prio_idx = 0; prio_idx < prio_num; prio_idx++) {
			
			if (queue_type == 0)
				cgid = (uint32_t)dpdmai->rx_cgr_info[prio_idx].cgid;
			else
				cgid = (uint32_t)dpdmai->tx_cgr_info[prio_idx].cgid;
		
			err = resource_authorization(sw_portal, dpdmai->amq.bdi, dpdmai->amq.icid,
					qbman_auth_type_cgid,
					&virtual_cgid,
					cgid,
					(QBMAN_AUTH_SWP), "CGID");
			if (err) {
				dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
				return err;
			}
			if (virtual_cgid >= MAX_CGID_VIRT_ID ) {
				pr_warn("ID[%d]: Virtual congestion group id is above 256\n",
						dpdmai->id);
			}
			
			if (queue_type == 0)
				dpdmai->rx_cgr_info[prio_idx].virtual_cgid = (int)virtual_cgid;
			else
				dpdmai->tx_cgr_info[prio_idx].virtual_cgid = (int)virtual_cgid;
			
			err = qbman_cgr_query(sw_portal, (uint32_t)cgid, &attr);
			if (err) {
				dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
				return err;
			}
			qbman_cgr_attr_set_cscn_vcgid(&attr, virtual_cgid,
							dpdmai->amq.bdi);
			qbman_cgr_attr_set_cg_icid(&attr, dpdmai->amq.icid,
							dpdmai->amq.pl,
							dpdmai->amq.va);
		}
	}
	
	dpdmai->authorized = 1;

	return 0;
}

static int resources_deauthorization(struct dpdmai *dpdmai)
{
	struct qbman_swp *sw_portal = NULL;
	uint8_t queue_idx, prio_idx;
	int prio_num;
	int i;
	int err;

	CHECK_COND_RETVAL(dpdmai, -EINVAL);

	if (!dpdmai->authorized)
		return 0;

	dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);

	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for( prio_idx = 0 ; prio_idx < dpdmai->priorities_num ; prio_idx++ ) {
			/* FQIDs */
			err = resource_deauthorization(sw_portal, dpdmai->amq.bdi, dpdmai->amq.icid,
						qbman_auth_type_fqid,
						dpdmai->tx_queue_info[queue_idx][prio_idx].tx_virt_fqid,
						(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-FQID");
			CHECK_COND_RETVAL(err == 0, err, "dpdmai - resource_deauthorization\n");
			err = resource_deauthorization(sw_portal, dpdmai->amq.bdi, dpdmai->amq.icid,
					qbman_auth_type_fqid,
					dpdmai->rx_queue_info[queue_idx][prio_idx].rx_virt_fqid,
					(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-FQID");
			CHECK_COND_RETVAL(err == 0, err, "dpdmai - resource_deauthorization\n");

			pr_debug("\nDeauthorize Tx queue %d, (virt %d)\n",
					dpdmai->tx_queue_info[queue_idx][prio_idx].tx_fqid,
					dpdmai->tx_queue_info[queue_idx][prio_idx].tx_virt_fqid);
			pr_debug("\nDeauthorize Rx queue %d, (virt %d)\n\n",
					dpdmai->rx_queue_info[queue_idx][prio_idx].rx_fqid,
					dpdmai->rx_queue_info[queue_idx][prio_idx].rx_virt_fqid);
		}
	}

	if ( dpdmai->cg_per_priority )
		prio_num = dpdmai->priorities_num;
	else
		prio_num = 1;

	for (i = 0 ; i < prio_num ; i++) {
		resource_deauthorization(sw_portal, dpdmai->amq.bdi, dpdmai->amq.icid,
				qbman_auth_type_cgid,
				(uint32_t)dpdmai->rx_cgr_info[i].virtual_cgid,
				(QBMAN_AUTH_SWP), "CGID");
		resource_deauthorization(sw_portal, dpdmai->amq.bdi, dpdmai->amq.icid,
				qbman_auth_type_cgid,
				(uint32_t)dpdmai->tx_cgr_info[i].virtual_cgid,
				(QBMAN_AUTH_SWP), "CGID");
	}

	dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
	dpdmai->authorized = 0;
	dpdmai->amq.icid = (uint16_t)-1;

	return 0;
}

/*
 * Queues that were already connected to destination, we only want to
 * enable/disable queues by disable/enable CG
 */
static int queues_set_rejection_mode(struct dpdmai *dpdmai,
	uint8_t queue_id, uint8_t priority,
	int en)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	uint32_t fqctrl, cgid;
	int err;

	CHECK_COND_RETVAL(dpdmai, -EINVAL);

	cgid = (uint32_t)dpmng_get_cgid(dpdmai->dpmng);

	dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);

	/* TX-FQID */
	qbman_fq_attr_clear(&fqdesc);
	err = qbman_fq_query(sw_portal,
				dpdmai->tx_queue_info[queue_id][priority].tx_fqid,
				&fqdesc);
	if (err != 0) {
		pr_err("queues_set_rejection_mode failed\n");
		dpmng_put_swportal(dpdmai->dpmng, (void*)&sw_portal);
		return err;
	}

	qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
	if (!en) {
		fqctrl &= ~QBMAN_FQCTRL_CGR;
		cgid = 0;
	} else
		fqctrl |= QBMAN_FQCTRL_CGR;

	qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);
	qbman_fq_attr_set_cgrid(&fqdesc, cgid);

	err = qbman_fq_configure(
		sw_portal, dpdmai->tx_queue_info[queue_id][priority].tx_fqid, &fqdesc);
	if (err != 0) {
		pr_err("queues_set_rejection_mode failed\n");
		dpmng_put_swportal(dpdmai->dpmng, (void*)&sw_portal);
		return err;
	}

	dpmng_put_swportal(dpdmai->dpmng, (void*)&sw_portal);

	if (en)
		pr_debug("\nEnable rejection mode for queue %d\n",
		         dpdmai->tx_queue_info[queue_id][priority].tx_fqid);
	else
		pr_debug("\nDisable rejection mode for queue %d\n",
			 dpdmai->tx_queue_info[queue_id][priority].tx_fqid);
	return 0;
}

static int config_tx_queue(struct dpdmai *dpdmai, uint8_t queue_id, uint8_t priority)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	struct qbman_attr state;
	uint16_t wqid_base;
	int err, ps = 0;

	enum qbman_fq_schedstate_e schedstate;

	ps = qbman_cacheable_pfdr();
	dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);

	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_ctx(
		&fqdesc, 0,
		(uint32_t)dpdmai->rx_queue_info[queue_id][priority].rx_virt_fqid);
	qbman_fq_attr_set_erfqid(
		&fqdesc, dpdmai->rx_queue_info[queue_id][priority].rx_fqid);
	qbman_fq_attr_set_icid(&fqdesc, dpdmai->amq.icid, dpdmai->tx_pl_bit);
	qbman_fq_attr_set_mctl(&fqdesc, dpdmai->amq.bdi, 0, dpdmai->amq.va, ps, 0);
	qbman_fq_attr_set_vfqid(&fqdesc,
				dpdmai->tx_queue_info[queue_id][priority].tx_virt_fqid);
	err = qbman_fq_configure(
		sw_portal, dpdmai->tx_queue_info[queue_id][priority].tx_fqid, &fqdesc);
	if (err != 0) {
		pr_err("qbman_fq_configure failed\n");
		dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
		return err;
	}


	wqid_base = dpmng_get_dcp_wqid(dpdmai->dpmng, QBMAN_DCP_QDMA, 0);
	qbman_fq_attr_set_destwq(
		&fqdesc,
		(uint32_t)((wqid_base << 3)
				| dpdmai->tx_queue_info[queue_id][priority].tx_priorities
					- 1));

	err = qbman_fq_configure(
		sw_portal, dpdmai->tx_queue_info[queue_id][priority].tx_fqid, &fqdesc);

	if (err != 0) {
		dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
		pr_err( "qbman_fq_configure failed\n");
		return err;
	}

	err = qbman_fq_query_state(
		sw_portal, dpdmai->tx_queue_info[queue_id][priority].tx_fqid, &state);
	if (err != 0) {
		dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
		pr_err("qbman_fq_query_state failed\n");
		return err;
	}

	if (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_parked) {
		err = qbman_swp_fq_schedule(
			sw_portal, dpdmai->tx_queue_info[queue_id][priority].tx_fqid);
		if (err != 0) {
			pr_err("qbman_swp_fq_schedule failed\n");
			dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
			return err;
		}
	}

	err = qbman_fq_query_state(
		sw_portal, dpdmai->tx_queue_info[queue_id][priority].tx_fqid, &state);
	if (err != 0) {
		dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
		pr_err("qbman_fq_query_state failed\n");
		return err;
	}

	schedstate = (enum qbman_fq_schedstate_e)
		qbman_fq_state_schedstate(&state);

	pr_debug("\nConfigure Tx queue %d (new state %d)\n",
			dpdmai->tx_queue_info[queue_id][priority].tx_fqid,
			schedstate);

	dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);

	return 0;
}

static int config_rx_queue(struct dpdmai *dpdmai, uint8_t queue_id, uint8_t priority)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	struct qbman_attr state;
	uint32_t fqctrl;
	int err, ps = 0;

	enum qbman_fq_schedstate_e schedstate;

	ps = qbman_cacheable_pfdr();
	dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);

	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_ctx(
		&fqdesc,
		(uint32_t)(dpdmai->rx_queue_info[queue_id][priority].user_ctx >> 32),
		(uint32_t)(dpdmai->rx_queue_info[queue_id][priority].user_ctx));
	qbman_fq_attr_set_icid(&fqdesc, dpdmai->amq.icid, dpdmai->rx_pl_bit);
	qbman_fq_attr_set_mctl(&fqdesc, dpdmai->amq.bdi, 0, dpdmai->amq.va, ps, 0);
	qbman_fq_attr_set_vfqid(&fqdesc,
				dpdmai->rx_queue_info[queue_id][priority].rx_virt_fqid);
	err = qbman_fq_configure(
		sw_portal, dpdmai->rx_queue_info[queue_id][priority].rx_fqid, &fqdesc);
	if (err != 0) {
		pr_err("qbman_fq_configure failed\n");
		dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
		return err;
	}

	dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);

	if (dpdmai->rx_queue_info[queue_id][priority].rx_dest_cfg.dest_type
		!= DPDMAI_DEST_NONE) {
		uint16_t destwq;
		if (dpdmai->rx_queue_info[queue_id][priority].rx_dest_cfg.dest_type
			== DPDMAI_DEST_DPIO) {
			struct dpio *dpio =
				sys_get_handle(
					FSL_MOD_DPIO,
					1,
					dpdmai->rx_queue_info[queue_id][priority].rx_dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpio, -ENAVAIL);
			err =
				dpio_get_destwq(
					dpio,
					dpdmai->rx_queue_info[queue_id][priority].rx_dest_cfg.priority,
					&destwq);
			CHECK_COND_RETVAL(err == 0, err);
			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			qbman_fq_attr_set_fqctrl(
				&fqdesc, fqctrl | QBMAN_FQCTRL_FQDAN);
		} else { /*DPDMAI_DPCON */
			struct dpcon *dpcon =
				sys_get_handle(
					FSL_MOD_DPCON,
					1,
					dpdmai->rx_queue_info[queue_id][priority].rx_dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpcon, -ENAVAIL);
			err =
				dpcon_get_destwq(
					dpcon,
					dpdmai->rx_queue_info[queue_id][priority].rx_dest_cfg.priority,
					&destwq);
			CHECK_COND_RETVAL(err == 0, err);
			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			qbman_fq_attr_set_fqctrl(
				&fqdesc, fqctrl & ~QBMAN_FQCTRL_FQDAN);
		}
		qbman_fq_attr_set_destwq(&fqdesc, destwq);

		dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);
		err = qbman_fq_configure(
			sw_portal, dpdmai->rx_queue_info[queue_id][priority].rx_fqid,
			&fqdesc);
		if (err != 0) {
			dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
			pr_err("qbman_fq_configure failed\n");
			return err;
		}

		err = qbman_fq_query_state(
			sw_portal, dpdmai->rx_queue_info[queue_id][priority].rx_fqid,
			&state);
		if (err != 0) {
			pr_err("qbman_fq_query_state failed\n");
			dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
			return err;
		}

		if (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_parked) {
			err = qbman_swp_fq_schedule(
				sw_portal,
				dpdmai->rx_queue_info[queue_id][priority].rx_fqid);
			if (err != 0) {
				pr_err("qbman_swp_fq_schedule failed\n");
				dpmng_put_swportal(dpdmai->dpmng,
							(void*)sw_portal);
				return err;
			}
		}
		err = qbman_fq_query_state(
			sw_portal, dpdmai->rx_queue_info[queue_id][priority].rx_fqid,
			&state);
		if (err != 0) {
			pr_err("qbman_fq_query_state failed\n");
			dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
			return err;
		}

		schedstate = (enum qbman_fq_schedstate_e)
			qbman_fq_state_schedstate(&state);

		pr_debug("\nConfigure Rx queue %d (new state %d)\n",
				dpdmai->rx_queue_info[queue_id][priority].rx_fqid,
				schedstate);

		dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
	}

	return 0;
}

static int queues_configuration(struct dpdmai *dpdmai)
{
	uint8_t queue_idx, prio_idx;
	int err;

	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for (prio_idx = 0; prio_idx < dpdmai->priorities_num; prio_idx++) {
			err = config_tx_queue(dpdmai, queue_idx, prio_idx);
			CHECK_COND_RETVAL(err == 0, err, "dpdmai - error configuring tx queue %d priority %d\n", queue_idx, prio_idx);
			err = config_rx_queue(dpdmai, queue_idx, prio_idx);
			CHECK_COND_RETVAL(err == 0, err, "dpdmai - error configuring rx queue %d priority %d\n", queue_idx, prio_idx);
		}
	}

	return 0;
}

static int clear_rx_fqid(struct dpdmai *dpdmai,
	struct dpdmai_rx_queue_info *rx_queue_info)
{
	CHECK_COND_RETVAL(dpdmai, -EINVAL);

	if (!rx_queue_info->retire_storage)
		rx_queue_info->retire_storage =
			(struct qbman_result *)fsl_xmalloc(
				sizeof(struct qbman_result), 0, 64);
	CHECK_COND_RETVAL(rx_queue_info->retire_storage, -ENOMEM);

	dpmng_clear_fqid(rx_queue_info->rx_fqid, rx_queue_info->retire_storage,
				&rx_queue_info->retire_pending);

	if (rx_queue_info->retire_pending == 1)
		return 0;

	rx_queue_info->user_ctx = 0;
	memset(&rx_queue_info->rx_dest_cfg, 0, sizeof(struct dpdmai_dest_cfg));

	return 0;
}

static int clear_tx_fqid(struct dpdmai *dpdmai,
	struct dpdmai_tx_queue_info *tx_queue_info)
{
	CHECK_COND_RETVAL(dpdmai, -EINVAL);

	if (!tx_queue_info->retire_storage)
		tx_queue_info->retire_storage =
			(struct qbman_result *)fsl_xmalloc(
				sizeof(struct qbman_result), 0, 64);
	CHECK_COND_RETVAL(tx_queue_info->retire_storage, -ENOMEM);

	dpmng_clear_fqid(tx_queue_info->tx_fqid, tx_queue_info->retire_storage,
				&tx_queue_info->retire_pending);

	if (tx_queue_info->retire_pending == 1)
		return 0;

	return 0;
}

static int clear_queues(struct dpdmai *dpdmai)
{
	struct qbman_swp *sw_portal;
	uint8_t queue_idx, prio_idx;

	CHECK_COND_RETVAL(dpdmai, -EINVAL);

	dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);

	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for ( prio_idx = 0; prio_idx < dpdmai->priorities_num; prio_idx++) {
			clear_tx_fqid(dpdmai, &dpdmai->tx_queue_info[queue_idx][prio_idx]);
			clear_rx_fqid(dpdmai, &dpdmai->rx_queue_info[queue_idx][prio_idx]);
		}
	}
	dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);

	return 0;
}

static void congestion_notification_fill(const struct dpdmai_congestion_notification_cfg *cfg,
	struct qbman_attr *cgr_desc, int reset)
{
	/* clear old settings */
	qbman_cgr_attr_set_mode(cgr_desc, 0, 0);
	qbman_cgr_attr_set_cs_thres(cgr_desc, 0);
	qbman_cgr_attr_set_cs_thres_x(cgr_desc, 0);
	qbman_cgr_attr_set_cscn_in_memory(cgr_desc, 0, 0, 0, 0);
	qbman_cgr_attr_set_cscn_ctx(cgr_desc, 0);
	if (reset)
		return;
	
	qbman_cgr_attr_set_mode(cgr_desc, cfg->units, 0);
	qbman_cgr_attr_set_cs_thres(cgr_desc, cfg->threshold_entry);
	qbman_cgr_attr_set_cs_thres_x(cgr_desc, cfg->threshold_exit);

	qbman_cgr_attr_set_cscn_in_memory(
		cgr_desc,
		(cfg->notification_mode & DPDMAI_CGN_MODE_WRITE_MEM_ON_ENTER) ? 1 : 0,
		(cfg->notification_mode & DPDMAI_CGN_MODE_WRITE_MEM_ON_EXIT) ? 1 : 0,
		cfg->message_iova,
		(cfg->notification_mode & DPDMAI_CGN_MODE_COHERENT_WRITE) ? 1 : 0);
	qbman_cgr_attr_set_cscn_ctx(cgr_desc, cfg->message_ctx);
}

static int check_congestion_notification(struct dpdmai *dpdmai,
	int early_drop_enable,
	enum dpdmai_congestion_unit early_drop_units,
	const struct dpdmai_congestion_notification_cfg *cfg)
{
	if (early_drop_enable && (cfg->units != early_drop_units)) {
		pr_err("ID[%d]: notification units %d must match the early-drop units %d\n", dpdmai->id, cfg->units, early_drop_units);
		return -EINVAL;
	}

	if (((cfg->notification_mode & DPDMAI_CGN_MODE_WRITE_MEM_ON_ENTER)
		|| (cfg->notification_mode & DPDMAI_CGN_MODE_WRITE_MEM_ON_EXIT))
		&& !IS_ALIGNED(cfg->message_iova, 16)) {
		pr_err("ID[%d]: message_iova must be 16B aligned\n", dpdmai->id);
		return -EINVAL;
	}

	return 0;
}

static int set_cgr_enable(struct dpdmai *dpdmai, 
		struct dpdmai_congestion_notification_cfg *cfg, uint32_t cgid)
{
	struct qbman_attr cgr_desc;
	struct qbman_swp *sw_portal;
	int err;

	dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);
	
	err = qbman_cgr_query(sw_portal, cgid, &cgr_desc);

	if (err) {
		dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
		return err;
	}
	
	congestion_notification_fill(cfg, &cgr_desc, 0);

	err = qbman_cgr_configure(sw_portal, cgid, &cgr_desc);
	
	dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
	if (err)
		return err;

	return 0;
}

static int set_cgr_disable(struct dpdmai *dpdmai, 
		struct dpdmai_congestion_notification_cfg *cfg, uint32_t cgid)
{
	struct qbman_attr cgr_desc;
	struct qbman_swp *sw_portal;
	int err;

	CHECK_COND_RETVAL(cgid != DPDMAI_INVALID_ID, -EINVAL);
	dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);
	
	err = qbman_cgr_query(sw_portal, cgid, &cgr_desc);
	if (err) {
		dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
		return err;
	}
	
	congestion_notification_fill(cfg, &cgr_desc, 1);

	err = qbman_cgr_configure(sw_portal, cgid, &cgr_desc);
	
	dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
	if (err)
		return err;

	return 0;
}

static int config_queue_cgid(struct dpdmai *dpdmai, uint32_t fqid, uint32_t cgid, int cgid_en)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	struct qbman_attr state;
	uint32_t fqctrl;
	int err;
	struct qbman_desc qbman_desc;
	int iter = 0;
	uint32_t fqstate = 0;

	memset(&qbman_desc, 0, sizeof(qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, &iter);
	if (err) {
		pr_err("Could not obtain QBMAN descriptor\n");
		return err;
	}

	dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);
	err = qbman_fq_query_state(sw_portal, fqid, &state);
	dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d]: qbman_fq_query failed\n", dpdmai->id);
		return err;
	}
	fqstate = qbman_fq_state_schedstate(&state);
	if (fqstate == qbman_fq_schedstate_oos)
		/* new FQID, clear descriptor */
		qbman_fq_attr_clear(&fqdesc);
	else
	/* Avoid F2h error after Initialize FQ command due to invalid FQ state.
	This occurs if one or more of the FQ specified in the command are in
	the Retired state or have their retirement pending (R) bit asserted.*/
	if (fqstate == qbman_fq_schedstate_retired) {
		CHECK_COND_RETVAL(0, -EINVAL,
				"Fail to configure retired FQ[%d] due to invalid state\n");
	} else if (qbman_fq_state_retirement_pending(&state)) {
		CHECK_COND_RETVAL(0, -EINVAL,
				"Fail to configure FQ[%d]: retirement pending\n");
	} else {
		/* working FQID, fill the descriptor with its current values */
		dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);
		err = qbman_fq_query(sw_portal, fqid, &fqdesc);
		dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_fq_query failed\n", dpdmai->id);
			return err;
		}
	}

	qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
	
	if (cgid_en) {
		fqctrl |= QBMAN_FQCTRL_CGR;
		qbman_fq_attr_set_cgrid(&fqdesc, cgid);
	} else {
		fqctrl &= ~QBMAN_FQCTRL_CGR;
		qbman_fq_attr_set_cgrid(&fqdesc, 0);
	}

	qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);

	dpmng_get_swportal(dpdmai->dpmng, (void**)&sw_portal);
	err = qbman_fq_configure(sw_portal, fqid, &fqdesc);
	dpmng_put_swportal(dpdmai->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d]: qbman_fq_configure failed\n", dpdmai->id);
		return err;
	}

	return 0;
}

static int set_rx_congestion_notification(struct dpdmai *dpdmai,
	struct dpdmai_cgr_info *info,
	struct dpdmai_congestion_notification_cfg *cfg)
{
	uint32_t cgid;
	int err, i;

	cgid = (uint32_t)dpdmai->rx_cgr_info[info->prio].cgid;
	
	if (cfg->threshold_entry != 0) {
		err = check_congestion_notification(dpdmai, 0, (enum dpdmai_congestion_unit)0, cfg);
		if (err) {
			pr_err("ID[%d]: dpdmai congestion configuration check failed\n", dpdmai->id);
			return err;
		}
		
		err = set_cgr_enable(dpdmai, cfg, cgid);
		CHECK_COND_RETVAL(err == 0, err);
		
		info->notification_enable = 1;
		/* Set the CGR on relevant FQID */
		for (i = 0; i < dpdmai->num_queues; i++) {
			config_queue_cgid(dpdmai, dpdmai->rx_queue_info[i][info->prio].rx_fqid, cgid, 1);
		}
	}
	else if (info->notification_enable) {
		/* Unset the CGR from relevant FQID */
		for (i = 0; i < dpdmai->num_queues; i++) {
			config_queue_cgid(dpdmai, dpdmai->rx_queue_info[i][info->prio].rx_fqid, 0, 0);
		}

		info->notification_enable = 0;
		err = set_cgr_disable(dpdmai, cfg, cgid);
		CHECK_COND_RETVAL(err == 0, err);
	}
	
	memcpy(&info->cg_notify, cfg,
		sizeof(struct dpdmai_congestion_notification_cfg));
	
	return 0;
}

static int set_tx_congestion_notification(struct dpdmai *dpdmai,
	struct dpdmai_cgr_info *info,
	struct dpdmai_congestion_notification_cfg *cfg)
{
	uint32_t cgid;
	int err, i;

	cgid = (uint32_t)dpdmai->tx_cgr_info[info->prio].cgid;

	if (cfg->threshold_entry != 0) {
		err = check_congestion_notification(dpdmai, 0, (enum dpdmai_congestion_unit)0, cfg);
		if (err) {
			pr_err("ID[%d]: dpdmai congestion configuration check failed\n", dpdmai->id);
			return err;
		}

		err = set_cgr_enable(dpdmai, cfg, cgid);
		CHECK_COND_RETVAL(err == 0, err);
		
		info->notification_enable = 1;
		/* Set the CGR on relevant FQID */
		for (i = 0; i < dpdmai->num_queues; i++) {
			config_queue_cgid(dpdmai, dpdmai->tx_queue_info[i][info->prio].tx_fqid, cgid, 1);
		}
	}
	else if (info->notification_enable) {
		/* Unset the CGR from relevant FQID */
		for (i = 0; i < dpdmai->num_queues; i++) {
			config_queue_cgid(dpdmai, dpdmai->tx_queue_info[i][info->prio].tx_fqid, 0, 0);
		}

		info->notification_enable = 0;
		err = set_cgr_disable(dpdmai, cfg, cgid);
		CHECK_COND_RETVAL(err == 0, err);
	}
	
	memcpy(&info->cg_notify, cfg,
		sizeof(struct dpdmai_congestion_notification_cfg));
	
	return 0;
}

struct dpdmai *dpdmai_allocate(void)
{
	struct dpdmai *dpdmai;

	dpdmai = (struct dpdmai *)fsl_malloc(sizeof(struct dpdmai));
	if (dpdmai)
		memset(dpdmai, 0, sizeof(struct dpdmai));

	return dpdmai;
}

void dpdmai_deallocate(struct dpdmai *dpdmai)
{
	fsl_free(dpdmai);
}

static void dpdmai_set_mc_info(struct dpdmai *dpdmai,
		       	       const struct dpmng_dev_cfg *dev_cfg)
{
	dpdmai->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dpdmai->dpmng);

	dpdmai->id = dev_cfg->id;
	dpdmai->device = dev_cfg->device;
}

int dpdmai_set_dev_ctx(struct dpdmai *dpdmai,
		       const struct dpmng_dev_ctx *dev_ctx)
{
	int err;

	if (memcmp(&dpdmai->amq, &(dev_ctx->amq), sizeof(struct dpmng_amq)) != 0) {
		CHECK_COND_RETVAL(!dpdmai->en, -EINVAL);
		if ((err = resources_deauthorization(dpdmai)) != 0) {
			pr_err("ID[%d]: resources_deauthorization failed \n", dpdmai->id);
			return err;
		}

		dpdmai->amq = dev_ctx->amq;

		//TODO - handle this better (update on assign)
		dpdmai->amq.bdi =
			(dev_ctx->type == DPMNG_CTX_TYPE_AIOP) ? 1 : 0;

		if ((err = resources_authorization(dpdmai)) != 0) {
			pr_err("ID[%d]: resources_authorization failed \n", dpdmai->id);
			return err;
		}
	}

	if ((err = queues_configuration(dpdmai)) != 0) {
		pr_err("ID[%d]:  initial_configuration after authorization failed \n", dpdmai->id);
		return err;
	}
	return 0;
}

int dpdmai_set_rx_pl(struct dpdmai *dpdmai, struct dpmng_dev_ctx *dev_ctx)
{
	dpdmai->rx_pl_bit = dev_ctx->amq.pl;
	return 0;
}
int dpdmai_set_tx_pl(struct dpdmai *dpdmai, struct dpmng_dev_ctx *dev_ctx)
{
	dpdmai->tx_pl_bit = dev_ctx->amq.pl;
	return 0;
}

int dpdmai_init(struct dpdmai *dpdmai,
		const struct dpdmai_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg)
{
	int i, err;
	uint8_t queue_idx, prio_idx;

	if (!cfg->priorities[0]) {
		pr_err("Priorities were not configured for DPDMAI\n");
		return -EINVAL;
	}

	// default values for num_rx/tx_queues
	dpdmai->num_queues = cfg->num_queues ? cfg->num_queues : 1;

	dpdmai_set_mc_info(dpdmai, dev_cfg);
	
	dpdmai->cg_per_priority = !!(cfg->adv.options & DPDMAI_OPT_CG_PER_PRIORITY);

	for( prio_idx = 0 ; prio_idx < DPDMAI_PRIO_NUM ; prio_idx++ ) {
		if( cfg->priorities[prio_idx] ) {
			CHECK_COND_RETVAL(IN_RANGE(1, cfg->priorities[prio_idx], 8), -EINVAL,
					"Priority (%d) not in valid range (1-8)\n", cfg->priorities[prio_idx]);
			dpdmai->priorities_num++;
		}
	}

	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for( prio_idx = 0 ; prio_idx < dpdmai->priorities_num ; prio_idx++ ) {
			dpdmai->tx_queue_info[queue_idx][prio_idx].tx_priorities = cfg->priorities[prio_idx];
		}
	}

	pr_debug("dpdmai resources_allocation()\n");

	if ((err = resources_allocation(dpdmai)) != 0) {
		resources_deallocation(dpdmai);
		pr_err("resources_allocation failed\n");
		return err;
	}

	dpdmai->amq.icid = (uint16_t)-1;

	err = queues_configuration(dpdmai);
	if (err != 0) {
		pr_err("ID[%d]: queues_configuration failed\n", dpdmai->id);
		dpdmai_destroy(dpdmai);
		return err;
	}

	/* CG enabled for queues*/
	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for (prio_idx = 0; prio_idx < dpdmai->priorities_num; prio_idx++) {
			err = queues_set_rejection_mode(dpdmai, queue_idx, prio_idx, 1);
			CHECK_COND_RETVAL(err == 0, err, "dpdmai - queues_set_rejection_mode() return error\n");
		}
	}

	for (i = 0; i < DPDMAI_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpdmai->irqs[i]), MC_IRQ_TYPE_MSI);

	return 0;
}

void dpdmai_destroy(struct dpdmai *dpdmai)
{
	int err;

	if (dpdmai->en)
		dpdmai_disable(dpdmai);

	err = resources_deauthorization(dpdmai);
	CHECK_COND_RET(err == 0);

	clear_queues(dpdmai);

	err = resources_deallocation(dpdmai);
	CHECK_COND_RET(err == 0);
}

int dpdmai_enable(struct dpdmai *dpdmai)
{
	int err;
	uint8_t queue_idx, prio_idx;

	/* CG disabled for queues*/
	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for (prio_idx = 0; prio_idx < dpdmai->priorities_num; prio_idx++) {
			err = queues_set_rejection_mode(dpdmai, queue_idx, prio_idx, 0);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}
	dpdmai->en = 1;

	return 0;
}

int dpdmai_disable(struct dpdmai *dpdmai)
{
	uint8_t queue_idx, prio_idx;
	int err;

	/* CG enabled for queues*/
	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for( prio_idx = 0 ; prio_idx < dpdmai->priorities_num ; prio_idx++) {
			err = queues_set_rejection_mode(dpdmai, queue_idx, prio_idx, 1);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}
	dpdmai->en = 0;

	return 0;
}

int dpdmai_is_enabled(struct dpdmai *dpdmai, int *en)
{
	if (dpdmai->en == 1)
		*en = 1;
	else
		*en = 0;

	return 0;
}

int dpdmai_get_rx_queue(struct dpdmai *dpdmai, uint8_t queue_id,
	uint8_t priority,
	struct dpdmai_rx_queue_attr *attr)
{
	CHECK_COND_RETVAL( priority < dpdmai->priorities_num, -EINVAL, "dpdmai - priority value %d invalid; object has %d priorities\n",
			priority, dpdmai->priorities_num);
	CHECK_COND_RETVAL( queue_id < dpdmai->num_queues, -EINVAL, "dpdmai - queue index %d invalid; object has %d queues\n",
			priority, dpdmai->num_queues);

	attr->fqid = dpdmai->rx_queue_info[queue_id][priority].rx_virt_fqid;
	attr->user_ctx = dpdmai->rx_queue_info[queue_id][priority].user_ctx;
	memcpy(&attr->dest_cfg, &dpdmai->rx_queue_info[queue_id][priority].rx_dest_cfg,
		sizeof(struct dpdmai_dest_cfg));

	return 0;
}

int dpdmai_get_tx_queue(struct dpdmai *dpdmai,
	uint8_t queue_id,
	uint8_t priority,
	struct dpdmai_tx_queue_attr *attr)
{
	CHECK_COND_RETVAL( priority < dpdmai->priorities_num, -EINVAL, "dpdmai - priority value %d invalid; object has %d priorities\n",
			priority, dpdmai->priorities_num);
	CHECK_COND_RETVAL( queue_id < dpdmai->num_queues, -EINVAL, "dpdmai - queue index %d invalid; object has %d queues\n",
			priority, dpdmai->num_queues);

	attr->fqid = dpdmai->tx_queue_info[queue_id][priority].tx_virt_fqid;

	return 0;
}

int dpdmai_set_rx_queue(struct dpdmai *dpdmai,
	uint8_t queue_id,
	uint8_t priority,
	const struct dpdmai_rx_queue_cfg *cfg)
{
	uint8_t i, j, k;
	int err;
	uint8_t q_start, q_stop;

	CHECK_COND_RETVAL( priority == DPDMAI_ALL_QUEUES || priority < dpdmai->priorities_num, -EINVAL, "dpdmai - priority value %d invalid; object has %d priorities\n",
			priority, dpdmai->priorities_num);

	CHECK_COND_RETVAL( queue_id == DPDMAI_ALL_QUEUES || queue_id < dpdmai->num_queues, -EINVAL, "dpdmai - queue index %d invalid; object has %d queues\n",
			priority, dpdmai->num_queues);

	if (!cfg->options)
		return 0; // nothing to do, just return success

	if (cfg->options & DPDMAI_QUEUE_OPT_DEST) {
		if (cfg->dest_cfg.dest_type == DPDMAI_DEST_DPCON) {
			struct dpcon *dpcon = sys_get_handle(
				FSL_MOD_DPCON, 1, cfg->dest_cfg.dest_id);
			if (!dpcon) {
				pr_err("dpcon_id is invalid\n");
				return -EINVAL;
			}
			if (!dpcon_is_priority_in_range(
				dpcon, cfg->dest_cfg.priority)) {
				pr_err("dpcon priority not in range\n");
				return -EINVAL;
			}
		}

		if (cfg->dest_cfg.dest_type == DPDMAI_DEST_DPIO) {
			struct dpio *dpio = sys_get_handle(
				FSL_MOD_DPIO, 1, cfg->dest_cfg.dest_id);
			if (!dpio) {
				pr_err("dpio_id is invalid\n");
				return -EINVAL;
			}
			if (!dpio_is_priority_in_range(
				dpio, cfg->dest_cfg.priority)) {
				pr_err("priority not in range\n");
				return -EINVAL;
			}
		}
	}

	if( queue_id == DPDMAI_ALL_QUEUES ) {
		q_start = 0;
		q_stop = dpdmai->num_queues;
	}
	else {
		q_start = queue_id;
		q_stop = queue_id+1;
	}

	for( queue_id = q_start ; queue_id < q_stop ; queue_id++ ) {
		if (priority == DPDMAI_ALL_QUEUES) {
			i = 0;
			j = dpdmai->priorities_num;
		} else {
			i = priority;
			j = priority + 1;
		}

		k = i;
		for (; k < j; k++) {
			if ((cfg->options & DPDMAI_QUEUE_OPT_DEST)
				&& (cfg->dest_cfg.dest_type == DPDMAI_DEST_NONE)
				&& (dpdmai->rx_queue_info[queue_id][k].rx_dest_cfg.dest_type
					!= DPDMAI_DEST_NONE)) {
				pr_err( "ID[%d]: Cannot change back to parked mode\n", dpdmai->id);
				return -ENOTSUP;
			}
		}
		for (; i < j; i++) {
			if (cfg->options & DPDMAI_QUEUE_OPT_USER_CTX)
				dpdmai->rx_queue_info[queue_id][i].user_ctx = cfg->user_ctx;

			if (cfg->options & DPDMAI_QUEUE_OPT_DEST)
				memcpy(&dpdmai->rx_queue_info[queue_id][i].rx_dest_cfg,
					&(cfg->dest_cfg),
					sizeof(struct dpdmai_dest_cfg));

			err = config_rx_queue(dpdmai, queue_id, i);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}

	return 0;
}

int dpdmai_set_rx_congestion_notification(struct dpdmai *dpdmai,
	uint8_t priority,
	struct dpdmai_congestion_notification_cfg *cfg)
{
	struct dpdmai_cgr_info *info;
	uint8_t prio = priority;
	int err;
	
	if (prio >= DPDMAI_PRIO_NUM) {
		pr_err("Invalid priority\n");
		return -EINVAL;
	}
	if (dpdmai->cg_per_priority == 0 && prio != 0) {
		pr_err("Invalid priority: priority makes no sense if option DPDMAI_OPT_CG_PER_PRIORITY is not set\n");
		return -EINVAL;
	}
	if (cfg->threshold_entry > 0 && cfg->threshold_exit >= cfg->threshold_entry) {
		pr_err("Invalid threshold_exit: exit congestion state threshold must be below the enter congestion state threshold\n");
		return -EINVAL;
	}

	/* priority makes no sense if option DPDMAI_OPT_CG_PER_PRIORITY is not set, 
	 * so in this case must be zero: one CG for all priorities */
	if (dpdmai->cg_per_priority == 0)
		prio = 0;
	
	info = &dpdmai->rx_cgr_info[prio];
	info->prio = prio;
	
	err = set_rx_congestion_notification(dpdmai, info, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;	
}

int dpdmai_set_tx_congestion_notification(struct dpdmai *dpdmai,
	uint8_t priority,
	struct dpdmai_congestion_notification_cfg *cfg)
{
	struct dpdmai_cgr_info *info;
	uint8_t prio = priority;
	int err;
	
	if (prio >= DPDMAI_PRIO_NUM) {
		pr_err("Invalid priority\n");
		return -EINVAL;
	}
	if (dpdmai->cg_per_priority == 0 && prio != 0) {
		pr_err("Invalid priority: priority makes no sense if option DPDMAI_OPT_CG_PER_PRIORITY is not set\n");
		return -EINVAL;
	}
	if (cfg->threshold_entry > 0 && cfg->threshold_exit >= cfg->threshold_entry) {
		pr_err("Invalid threshold_exit: exit congestion state threshold must be below the enter congestion state threshold\n");
		return -EINVAL;
	}
	
	/* priority makes no sense if option DPDMAI_OPT_CG_PER_PRIORITY is not set, 
	 * so in this case must be zero: one CG for all priorities */
	if (dpdmai->cg_per_priority == 0)
		prio = 0;
	
	info = &dpdmai->tx_cgr_info[prio];
	info->prio = prio;
	
	err = set_tx_congestion_notification(dpdmai, info, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;	
}

int dpdmai_get_rx_congestion_notification(struct dpdmai *dpdmai,
	uint8_t priority,
	struct dpdmai_congestion_notification_cfg *cfg)
{
	struct dpdmai_cgr_info *info;
	uint8_t prio = priority;
	
	if (prio >= DPDMAI_PRIO_NUM) {
		pr_err("Invalid priority\n");
		return -EINVAL;
	}
	if (dpdmai->cg_per_priority == 0 && prio != 0) {
		pr_err("Invalid priority: priority makes no sense if option DPDMAI_OPT_CG_PER_PRIORITY is not set\n");
		return -EINVAL;
	}
	
	/* priority makes no sense if option DPDMAI_OPT_CG_PER_PRIORITY is not set, 
	 * so in this case must be zero: one CG for all priorities */
	if (dpdmai->cg_per_priority == 0)
		prio = 0;
	
	info = &dpdmai->rx_cgr_info[prio];
	info->prio = prio;
	
	memcpy(cfg, &info->cg_notify,
		sizeof(struct dpdmai_congestion_notification_cfg));
	
	return 0;
}

int dpdmai_get_tx_congestion_notification(struct dpdmai *dpdmai,
	uint8_t priority,
	struct dpdmai_congestion_notification_cfg *cfg)
{
	struct dpdmai_cgr_info *info;
	uint8_t prio = priority;
	
	if (prio >= DPDMAI_PRIO_NUM) {
		pr_err("Invalid priority\n");
		return -EINVAL;
	}
	if (dpdmai->cg_per_priority == 0 && prio != 0) {
		pr_err("Invalid priority: priority makes no sense if option DPDMAI_OPT_CG_PER_PRIORITY is not set\n");
		return -EINVAL;
	}
	
	/* priority makes no sense if option DPDMAI_OPT_CG_PER_PRIORITY is not set, 
	 * so in this case must be zero: one CG for all priorities */
	if (dpdmai->cg_per_priority == 0)
		prio = 0;
	
	info = &dpdmai->tx_cgr_info[prio];
	info->prio = prio;
	
	memcpy(cfg, &info->cg_notify,
		sizeof(struct dpdmai_congestion_notification_cfg));
	
	return 0;
}

int dpdmai_get_attributes(struct dpdmai *dpdmai, struct dpdmai_attr *attr)
{
	attr->id = (int)dpdmai->id;
	attr->num_of_priorities = dpdmai->priorities_num;
	attr->num_of_queues = dpdmai->num_queues;

	/* Setting options */
	attr->options =
		dpdmai->cg_per_priority ? DPDMAI_OPT_CG_PER_PRIORITY : 0;

	return 0;
}

int dpdmai_reset(struct dpdmai *dpdmai)
{
	int err;
	uint8_t queue_idx, prio_idx;

	if (dpdmai->en) {
		if ((err = dpdmai_disable(dpdmai)) != 0) {
			pr_err("dpdmai_disable failed\n");
			return err;
		}
	}

	err = resources_deauthorization(dpdmai);
	CHECK_COND_RETVAL(err == 0, err);
	err = clear_queues(dpdmai);
	CHECK_COND_RETVAL(err == 0, err);

	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for( prio_idx = 0 ; prio_idx < dpdmai->priorities_num ; prio_idx++ ) {
			memset(&dpdmai->rx_queue_info[queue_idx][prio_idx].rx_dest_cfg,
					0, sizeof(struct dpdmai_dest_cfg));
			dpdmai->rx_queue_info[queue_idx][prio_idx].rx_virt_fqid = 0;
			dpdmai->tx_queue_info[queue_idx][prio_idx].tx_virt_fqid = 0;
		}
	}

	for( queue_idx = 0 ; queue_idx < dpdmai->num_queues ; queue_idx++ ) {
		for( prio_idx = 0 ; prio_idx < dpdmai->priorities_num ; prio_idx++ ) {
			err = queues_set_rejection_mode(dpdmai, queue_idx, prio_idx, 1);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}

	return 0;
}

int dpdmai_set_irq(struct dpdmai *dpdmai,
		  uint8_t irq_index,
		  const struct mc_irq_cfg *irq_cfg)
{
	UNUSED(irq_index);
	UNUSED(irq_cfg);

	pr_err("ID[%d]: IRQs are not supported\n", dpdmai->id);
	return -ENOTSUP;
}

int dpdmai_get_irq(struct dpdmai *dpdmai,
		  uint8_t irq_index,
		  struct mc_irq_cfg *irq_cfg)
{
	UNUSED(irq_index);
	UNUSED(irq_cfg);

	pr_err("ID[%d]: IRQs are not supported\n", dpdmai->id);
	return -ENOTSUP;
}

int dpdmai_set_irq_enable(struct dpdmai *dpdmai, uint8_t irq_index, uint8_t en)
{
	UNUSED(irq_index);
	UNUSED(en);

	pr_err("ID[%d]: IRQs are not supported\n", dpdmai->id);
	return -ENOTSUP;
}

int dpdmai_get_irq_enable(struct dpdmai *dpdmai, uint8_t irq_index, uint8_t *en)
{
	UNUSED(irq_index);
	UNUSED(en);

	pr_err("ID[%d]: IRQs are not supported\n", dpdmai->id);
	return -ENOTSUP;
}

int dpdmai_set_irq_mask(struct dpdmai *dpdmai,
			uint8_t irq_index,
			uint32_t mask)
{
	UNUSED(irq_index);
	UNUSED(mask);

	pr_err("ID[%d]: IRQs are not supported\n", dpdmai->id);
	return -ENOTSUP;
}

int dpdmai_get_irq_mask(struct dpdmai *dpdmai,
			uint8_t irq_index,
			uint32_t *mask)
{
	UNUSED(irq_index);
	UNUSED(mask);

	pr_err("ID[%d]: IRQs are not supported\n", dpdmai->id);
	return -ENOTSUP;
}

int dpdmai_get_irq_status(struct dpdmai *dpdmai,
			  uint8_t irq_index,
			  uint32_t *status)
{
	UNUSED(irq_index);
	UNUSED(status);

	pr_err("ID[%d]: IRQs are not supported\n", dpdmai->id);
	return -ENOTSUP;
}

int dpdmai_clear_irq_status(struct dpdmai *dpdmai,
			    uint8_t irq_index,
			    uint32_t status)
{
	UNUSED(irq_index);
	UNUSED(status);

	pr_err("ID[%d]: IRQs are not supported\n", dpdmai->id);
	return -ENOTSUP;
}
