/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpdmai.h

 @Description   DPDMAI internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPDMAI_H
#define __DPDMAI_H

#include "fsl_dpdmai_mc.h"
#include "kernel/fsl_spinlock.h"
#include "fsl_dptbl.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPDMAI

#define DPDMAI_INVALID_ID			(-1)

struct dpdmai_rx_queue_info {
	uint32_t rx_fqid;
	uint32_t rx_virt_fqid;
	struct dpdmai_dest_cfg rx_dest_cfg;
	uint64_t user_ctx;

	int retire_pending;
	struct qbman_result *retire_storage;
};

struct dpdmai_tx_queue_info {
	uint8_t tx_priorities;
	uint32_t tx_fqid;
	uint32_t tx_virt_fqid;

	int retire_pending;
	struct qbman_result *retire_storage;
};

struct dpdmai_cgr_info {
	int cgid;
	int virtual_cgid;
	uint8_t prio;
	int notification_enable;
	struct dpdmai_congestion_notification_cfg cg_notify;
};

struct dpdmai {
	/* parameters for run-time (in order to be in cache) */
	uint32_t id;
	int en;
	int authorized;
	spinlock_t lock;
	struct device *device;
	struct dpmng_amq amq;
	struct dpmng *dpmng;
	struct dpdmai_rx_queue_info rx_queue_info[DPDMAI_MAX_QUEUES][DPDMAI_PRIO_NUM];
	struct dpdmai_tx_queue_info tx_queue_info[DPDMAI_MAX_QUEUES][DPDMAI_PRIO_NUM];

	struct dpdmai_cgr_info rx_cgr_info[DPDMAI_PRIO_NUM];
	struct dpdmai_cgr_info tx_cgr_info[DPDMAI_PRIO_NUM];
	
	uint8_t priorities_num;
	uint8_t num_queues;

   	/* features */
	int cg_per_priority; /* by default is 0: one CG for all priorities */

	struct mc_irq irqs[DPDMAI_MAX_IRQ_NUM];
	int tx_pl_bit;
	int rx_pl_bit;
};

#endif /* __DPDMAI_H */
