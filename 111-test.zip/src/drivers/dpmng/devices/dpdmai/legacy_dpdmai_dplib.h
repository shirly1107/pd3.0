/*
 * Copyright 2013-2020 NXP
 */

#ifndef _LEGACY_DPDMAI_DPLIB_H
#define _LEGACY_DPDMAI_DPLIB_H

/* 
 * File used to maintain compatibility with older version of dplib/flib
 * All previous version of dpdmai commands should be placed here
 * 
 */
/**********************************************/
/**********************************************/
/********* V0 version of dpdmai commands ******/
/**********************************************/
/**********************************************/

/*                cmd, param, offset, width, type, arg_name */
#define DPDMAI_CMD_CREATE_V0(cmd, cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,	cfg->num_queues);\
	MC_CMD_OP(cmd, 0, 8,  8,  uint8_t,  cfg->priorities[0]);\
	MC_CMD_OP(cmd, 0, 16, 8,  uint8_t,  cfg->priorities[1]);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMAI_RSP_GET_ATTRIBUTES_V0(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, int,      (attr)->id); \
	MC_RSP_OP(cmd, 0, 32,  8, uint8_t,  (attr)->num_of_priorities); \
	MC_RSP_OP(cmd, 1,  0, 16, uint16_t, (attr)->version.major);\
	MC_RSP_OP(cmd, 1, 16, 16, uint16_t, (attr)->version.minor);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMAI_CMD_SET_IRQ(cmd, irq_index, irq_cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,  irq_index);\
	MC_CMD_OP(cmd, 0, 32, 32, uint32_t, irq_cfg->val);\
	MC_CMD_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr);\
	MC_CMD_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMAI_CMD_GET_IRQ(cmd, irq_index) \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMAI_RSP_GET_IRQ(cmd, type, irq_cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, irq_cfg->val); \
	MC_RSP_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr);\
	MC_RSP_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
	MC_RSP_OP(cmd, 2, 32, 32, int,	    type); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMAI_CMD_GET_TX_QUEUE_V1(cmd, priority) \
	MC_CMD_OP(cmd, 0, 40, 8,  uint8_t,  priority)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMAI_CMD_GET_RX_QUEUE_V1(cmd, priority) \
	MC_CMD_OP(cmd, 0, 40, 8,  uint8_t,  priority)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMAI_CMD_SET_RX_QUEUE_V1(cmd, priority, cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  32, int,      cfg->dest_cfg.dest_id); \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  cfg->dest_cfg.priority); \
	MC_CMD_OP(cmd, 0, 40, 8,  uint8_t,  priority); \
	MC_CMD_OP(cmd, 0, 48, 4,  enum dpdmai_dest, cfg->dest_cfg.dest_type); \
	MC_CMD_OP(cmd, 1, 0,  64, uint64_t, cfg->user_ctx); \
	MC_CMD_OP(cmd, 2, 0,  32, uint32_t, cfg->options);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMAI_RSP_GET_ATTRIBUTES_V1(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, int,     (attr)->id); \
	MC_RSP_OP(cmd, 0, 32,  8, uint8_t, (attr)->num_of_priorities); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMAI_RSP_GET_ATTRIBUTES_V2(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, int,     (attr)->id); \
	MC_RSP_OP(cmd, 0, 32,  8, uint8_t, (attr)->num_of_priorities); \
	MC_RSP_OP(cmd, 0, 40,  8, uint8_t, (attr)->num_of_queues); \
} while (0)

#endif /* _LEGACY_DPDMAI_DPLIB_H */
