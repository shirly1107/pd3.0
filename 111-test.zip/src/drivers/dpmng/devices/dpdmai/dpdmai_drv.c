/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpdma_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "fsl_sys.h"
#include "dtc/dtc.h"
#include "dplib/fsl_dpdmai_cmd.h"
#include "fsl_dpmng_mc.h"
#include "fsl_event_pipe.h"

#include "fsl_dpdmai_mc.h"
#include "fsl_resman.h"
#include "dpdmai_cmd.h"
#include "legacy_dpdmai_dplib.h"

/* DPDMAI last supported API version */
#define DPDMAI_V0_API_VER_MAJOR				2
#define DPDMAI_V0_API_VER_MINOR				2

int dpdmai_drv_init(void);


/*            cmd,  cfg, param, offset, width,  type,  	arg_name */
#define DPDMAI_LO_CREATE(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 8,  8,  uint8_t,  cfg->priorities[0]);\
	MC_RSP_OP(cmd, 0, 16, 8,  uint8_t,  cfg->priorities[1]);\
} while (0)

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpdmai *dpdmai;
	struct dpmng_dev_ctx tmp_dev_ctx;

	dpdmai = device_get_priv(dev);

	if (!dpdmai)
		return -ENODEV;

#ifdef DPDMAI_LX2_PL_BIT
	resman_update_dev_ctx_pl(dev, &tmp_dev_ctx, 1);
	dpdmai_set_tx_pl(dpdmai, &tmp_dev_ctx);
	resman_get_dev_ctx(dev, &tmp_dev_ctx, 1);
	dpdmai_set_rx_pl(dpdmai, &tmp_dev_ctx);
#else
	resman_get_dev_ctx(dev, &tmp_dev_ctx, 1);
	dpdmai_set_rx_pl(dpdmai, &tmp_dev_ctx);
	dpdmai_set_tx_pl(dpdmai, &tmp_dev_ctx);
#endif

	return dpdmai_set_dev_ctx(dpdmai, dev_ctx);
}

static int init_common(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpdmai *dpdmai;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpdmai_cfg dpdmai_cfg = { 0 };
	struct dpdmai_cfg *cfg = &dpdmai_cfg;
	int err;

	if( ver < 3 ) {
		DPDMAI_CMD_CREATE_V0(cmd_data, cfg);
	} else {
		DPDMAI_CMD_CREATE(cmd_data, cfg);
	}
	
	if( ver < 2 ) {
		cfg->num_queues = 0;
	}

	CHECK_COND_RETVAL(!(cfg->num_queues>DPDMAI_MAX_QUEUES), -EINVAL, "Invalid value %d for num_queues. "
			"The value shoudl be smaller than %d", cfg->num_queues, DPDMAI_MAX_QUEUES);

	dpdmai = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpdmai) {
		/* NULL */
		dpdmai = dpdmai_allocate();
		if (!dpdmai) {
			pr_err("No memory for dpdmai\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		dpdmai_set_tx_pl(dpdmai, &(dev_cfg.ctx));
		dpdmai_set_rx_pl(dpdmai, &(dev_cfg.ctx));

		err = dpdmai_init(dpdmai, cfg, &dev_cfg);
		if (err) {
			dpdmai_deallocate(dpdmai);
			return err;
		}

		device_set_priv(dev, dpdmai);
		sys_add_handle(dpdmai, FSL_MOD_DPDMAI, 1, dev_cfg.id);

		assign(dev, &(dev_cfg.ctx));
	}
	else
		return -EINVAL;

	return 0;
}

static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return init_common(dev, cmd_data, 1);
}

static int init_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return init_common(dev, cmd_data, 2);
}

static int init_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return init_common(dev, cmd_data, 3);
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	int err;


	UNUSED(cmd_data);

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	device_set_enable(dev, 1);

	err = dpdmai_enable(dpdmai);
	if (err)
		device_set_enable(dev, 0);

	return err;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	int err;

	UNUSED(cmd_data);

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	err = dpdmai_disable(dpdmai);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;

	UNUSED(cmd_data);

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	dpdmai_destroy(dpdmai);

	sys_remove_handle(FSL_MOD_DPDMAI, 1, device_get_id(dev));
	dpdmai_deallocate(dpdmai);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	struct dpmng_dev_ctx dev_ctx;
	int err;

	UNUSED(cmd_data);

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	err = dpdmai_reset(dpdmai);
	if (!err) {
		resman_get_dev_ctx(dev, &dev_ctx, 1);
		device_set_enable(dev, 0);
		err = assign(dev, &dev_ctx);
	}
	return err;
}

static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}


static int set_rx_queue_common(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpdmai *dpdmai;
	uint8_t priority;
	struct dpdmai_rx_queue_cfg queue_cfg;
	struct dpdmai_rx_queue_cfg *cfg = &queue_cfg;
	uint8_t queue_idx;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	memset(cfg, 0, sizeof(struct dpdmai_rx_queue_cfg));

	if( ver < 2 ) {
		DPDMAI_CMD_SET_RX_QUEUE_V1(cmd_data, priority, cfg);
		queue_idx = 0;
	} else {
		DPDMAI_CMD_SET_RX_QUEUE(cmd_data, priority, cfg, queue_idx);
	}

	return dpdmai_set_rx_queue(dpdmai, queue_idx, priority, cfg);
}

static int set_rx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_rx_queue_common(dev, cmd_data, 1);
}

static int set_rx_queue_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_rx_queue_common(dev, cmd_data, 2);
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	struct dpdmai_attr attr = { 0 };
	int err;

	dpdmai = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmai, -ENODEV);

	err = dpdmai_get_attributes(dpdmai, &attr);
	CHECK_COND_RETVAL(err == 0, err);

	attr.version.major = DPDMAI_V0_API_VER_MAJOR;
	attr.version.minor = DPDMAI_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMAI_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	struct dpdmai_attr attr = { 0 };
	int err;

	dpdmai = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmai, -ENODEV);

	err = dpdmai_get_attributes(dpdmai, &attr);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMAI_RSP_GET_ATTRIBUTES_V1(cmd_data, &attr);

	return 0;
}

static int get_attributes_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	struct dpdmai_attr attr = { 0 };
	int err;

	dpdmai = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmai, -ENODEV);

	err = dpdmai_get_attributes(dpdmai, &attr);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMAI_RSP_GET_ATTRIBUTES_V2(cmd_data, &attr);

	return 0;
}

static int get_attributes_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	struct dpdmai_attr attr = { 0 };
	int err;

	dpdmai = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmai, -ENODEV);

	err = dpdmai_get_attributes(dpdmai, &attr);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMAI_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	int en;
	int err;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	err = dpdmai_is_enabled(dpdmai, &en);
	if(!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDMAI_RSP_IS_ENABLED(cmd_data, en);
	}

	return err;
}

static int get_rx_queue_common(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpdmai *dpdmai;
	int err;
	struct dpdmai_rx_queue_attr attributes = { 0 };
	struct dpdmai_rx_queue_attr *attr = &attributes;
	uint8_t priority;
	uint8_t queue_idx;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	if( ver < 1 ) {
		DPDMAI_CMD_GET_RX_QUEUE_V1(cmd_data, priority);
		queue_idx = 0;
	}
	else {
		DPDMAI_CMD_GET_RX_QUEUE(cmd_data, priority, queue_idx);
	}

	err = dpdmai_get_rx_queue(dpdmai, queue_idx, priority, attr);
	if(!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDMAI_RSP_GET_RX_QUEUE(cmd_data, attr);
	}

	return err;
}

static int get_rx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_rx_queue_common(dev, cmd_data, 1);
}

static int get_rx_queue_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_rx_queue_common(dev, cmd_data, 2);
}

static int get_tx_queue_common(struct device *dev, struct mc_cmd_data *cmd_data, int version)
{
	struct dpdmai *dpdmai;
	int err;
	struct dpdmai_tx_queue_attr attributes = { 0 };
	struct dpdmai_tx_queue_attr *attr = &attributes;
	uint8_t priority;
	uint8_t queue_idx;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	if( version < 2 ) {
		DPDMAI_CMD_GET_TX_QUEUE_V1(cmd_data, priority);
		queue_idx = 0;
	}
	else {
		DPDMAI_CMD_GET_TX_QUEUE(cmd_data, priority, queue_idx);
	}

	err = dpdmai_get_tx_queue(dpdmai, queue_idx, priority, attr);
	if(!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDMAI_RSP_GET_TX_QUEUE(cmd_data, attr);
	}

	return err;
}

static int get_tx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_tx_queue_common(dev, cmd_data, 1);
}

static int get_tx_queue_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_tx_queue_common(dev, cmd_data, 2);
}

static int set_rx_congestion_notification(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t priority;
	struct dpdmai_congestion_notification_cfg cg_cfg;
	struct dpdmai_congestion_notification_cfg *cfg = &cg_cfg;

	memset(cfg, 0, sizeof(struct dpdmai_congestion_notification_cfg));

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_SET_CONGESTION_NOTIFICATION(cmd_data, priority, cfg);

	return dpdmai_set_rx_congestion_notification(dpdmai, priority, cfg);
}

static int set_tx_congestion_notification(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t priority;
	struct dpdmai_congestion_notification_cfg cg_cfg;
	struct dpdmai_congestion_notification_cfg *cfg = &cg_cfg;

	memset(cfg, 0, sizeof(struct dpdmai_congestion_notification_cfg));

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_SET_CONGESTION_NOTIFICATION(cmd_data, priority, cfg);

	return dpdmai_set_tx_congestion_notification(dpdmai, priority, cfg);
}

static int get_rx_congestion_notification(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t priority;
	struct dpdmai_congestion_notification_cfg cg_cfg;
	struct dpdmai_congestion_notification_cfg *cfg = &cg_cfg;
	int err;

	memset(cfg, 0, sizeof(struct dpdmai_congestion_notification_cfg));

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_GET_CONGESTION_NOTIFICATION(cmd_data, priority);

	err = dpdmai_get_rx_congestion_notification(dpdmai, priority, cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMAI_RSP_GET_CONGESTION_NOTIFICATION(cmd_data, priority, cfg);

	return 0;
}

static int get_tx_congestion_notification(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t priority;
	struct dpdmai_congestion_notification_cfg cg_cfg;
	struct dpdmai_congestion_notification_cfg *cfg = &cg_cfg;
	int err;

	memset(cfg, 0, sizeof(struct dpdmai_congestion_notification_cfg));

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_GET_CONGESTION_NOTIFICATION(cmd_data, priority);

	err = dpdmai_get_tx_congestion_notification(dpdmai, priority, cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMAI_RSP_GET_CONGESTION_NOTIFICATION(cmd_data, priority, cfg);

	return 0;
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dpdmai = device_get_priv(dev);
    	if (!dpdmai)
    		return -ENODEV;

    	DPDMAI_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

    	if (resman_is_irq_cfg_allowed(dev) == 0)
    		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

        return dpdmai_set_irq(dpdmai, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpdmai *dpdmai;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	return dpdmai_set_irq(dpdmai, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
	uint8_t irq_index;
	int err;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpdmai_get_irq(dpdmai, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMAI_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpdmai *dpdmai;
	int err;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	err = dpdmai_get_irq(dpdmai, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;

	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t irq_index;
	uint8_t en;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, en);

	return dpdmai_set_irq_enable(dpdmai, irq_index, en);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t irq_index;
	uint8_t en;
	int err;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpdmai_get_irq_enable(dpdmai, irq_index, &en);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMAI_RSP_GET_IRQ_ENABLE(cmd_data, en);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t irq_index;
	uint32_t mask;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpdmai_set_irq_mask(dpdmai, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpdmai_get_irq_mask(dpdmai, irq_index, &mask);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMAI_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpdmai_get_irq_status(dpdmai, irq_index, &status);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMAI_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmai *dpdmai;
	uint8_t irq_index;
	uint32_t status;

	dpdmai = device_get_priv(dev);
	if (!dpdmai)
		return -ENODEV;

	/* Read parameters from portal */
	DPDMAI_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpdmai_clear_irq_status(dpdmai, irq_index, status);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPDMAI_VER_MAJOR;
    uint32_t minor = DPDMAI_VER_MINOR;

    DPDMAI_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int dpdmai_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpdmai_open on DPDMAI %d\n", device_get_id(dev));
	return 0;
}

static int dpdmai_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpdmai_close on DPDMAI %d\n", device_get_id(dev));
	return 0;
}

static int dpdmai_ctrl_cb(void *dev,
                        uint8_t cmd_ver,
                        uint16_t cmd,
                        int portal_id,
                        uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev, struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPDMAI_CMD_CODE_CREATE, init, "dpdmai_init", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_ENABLE, enable, "dpdmai_enable", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_DISABLE, disable, "dpdmai_disable", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_DESTROY, destroy, "dpdmai_destroy", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_RESET, reset, "dpdmai_reset", DPDMAI_CMD_VER_BASE},
			{ DPDMAI_CMD_CODE_SET_RX_QUEUE, set_rx_queue, "dpdmai_set_rx_queue", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_GET_ATTR, get_attributes_v0, "dpdmai_get_attributes", DPDMAI_CMD_V0 },
			{ DPDMAI_CMD_CODE_IS_ENABLED, is_enabled, "dpdmai_is_enabled", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_GET_RX_QUEUE, get_rx_queue, "dpdmai_get_rx_queue", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_GET_TX_QUEUE, get_tx_queue, "dpdmai_get_tx_queue", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_SET_IRQ, set_irq, "dpdmai_set_irq", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_GET_IRQ, get_irq, "dpdmai_get_irq", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpdmai_set_irq_enable", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpdmai_get_irq_enable", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpdmai_set_irq_mask", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpdmai_get_irq_mask", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpdmai_get_irq_status", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpdmai_clear_irq_status", DPDMAI_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPDMAI_CMD_CODE_GET_API_VERSION, get_api_version, "dpdmai_get_api_version", DPDMAI_CMD_V1 },
			{ DPDMAI_CMD_CODE_GET_ATTR, get_attributes_v1, "dpdmai_get_attributes", DPDMAI_CMD_V1 },
			{ DPDMAI_CMD_CODE_CREATE, init_v2, "dpdmai_init", DPDMAI_CMD_V2 },
			{ DPDMAI_CMD_CODE_CREATE, init_v3, "dpdmai_init", DPDMAI_CMD_V3 },
			{ DPDMAI_CMD_CODE_GET_TX_QUEUE, get_tx_queue_v2, "dpdmai_get_tx_queue", DPDMAI_CMD_V2 },
			{ DPDMAI_CMD_CODE_GET_RX_QUEUE, get_rx_queue_v2, "dpdmai_get_rx_queue", DPDMAI_CMD_V2 },
			{ DPDMAI_CMD_CODE_SET_RX_QUEUE, set_rx_queue_v2, "dpdmai_set_rx_queue", DPDMAI_CMD_V2 },
			{ DPDMAI_CMD_CODE_GET_ATTR, get_attributes_v2, "dpdmai_get_attributes", DPDMAI_CMD_V2 },
			{ DPDMAI_CMD_CODE_GET_ATTR, get_attributes_v3, "dpdmai_get_attributes", DPDMAI_CMD_V3 },
			{ DPDMAI_CMD_CODE_SET_RX_CONGESTION_NOTIFICATION, set_rx_congestion_notification, "dpdmai_set_rx_congestion_notification", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_SET_TX_CONGESTION_NOTIFICATION, set_tx_congestion_notification, "dpdmai_set_tx_congestion_notification", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_GET_RX_CONGESTION_NOTIFICATION, get_rx_congestion_notification, "dpdmai_get_rx_congestion_notification", DPDMAI_CMD_VER_BASE },
			{ DPDMAI_CMD_CODE_GET_TX_CONGESTION_NOTIFICATION, get_tx_congestion_notification, "dpdmai_get_tx_congestion_notification", DPDMAI_CMD_VER_BASE },
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))){
			if (cmd == DPDMAI_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPDMAI %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev, cmd_data);
		}

	pr_err("Invalid command %d\n",cmd);
	return -ENOTSUP;
}

static uint32_t get_options(void *lo, int node_off)
{
	char *opt_str;
	int total_len;
	int len;
	int i = 0;
	uint32_t options = 0;
	struct {
		char *opt_str;
		uint32_t options;
	} map[] = {
	                    { "DPDMAI_OPT_CG_PER_PRIORITY", DPDMAI_OPT_CG_PER_PRIORITY }
	};

	opt_str = (char *)fdt_getprop(lo, node_off, "options", &total_len);

	if (opt_str && (int)(*opt_str) != 0 ) {
		while (total_len > 0){
			while (i < (ARRAY_SIZE(map) - 1) && strcmp(opt_str,map[i].opt_str))
				i++;
			if (!strcmp(opt_str,map[i].opt_str))
				options |= map[i].options;
			len = (int)strlen(opt_str) + 1;
			total_len -= len;
			opt_str = PTR_MOVE(opt_str, len );
			i=0;
		}
	}

	return options;
}

static int dpdmai_probe_cb(void *lo, int node_off)
{
	int err = 0;
	int i;
	struct dpdmai_cfg dpdmai_cfg = { 0 };
	struct dpdmai_cfg *cfg = &dpdmai_cfg;
	int dpdmai_id;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	uint32_t val32;
	uint64_t val;
	int destroy = 0;

	getprop_val(lo, node_off, "num_queues", 0, 0, &val);
	cfg->num_queues = (uint8_t)val;

	for (i = 0 ; i < DPDMAI_PRIO_NUM ; i++){
		getprop_array(lo, node_off, "priorities", i, &val32);
		cfg->priorities[i] = (uint8_t)val32;
	}
	err = (uint16_t)get_node_id(lo, node_off, &dpdmai_id);
	if (err)
		return err;

	/* DPDMAI cfg */
	dpdmai_cfg.adv.options = get_options(lo, node_off);
	
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman){
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(
			resman, "dpdmai",
			(uint16_t)dpdmai_id,
			NO_PORTAL_ID, DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPDMAI %.4x\n", dpdmai_id);
	DPDMAI_LO_CREATE(cmd_data, cfg);
	/* create object */
	err = dpdmai_ctrl_cb(dev, DPDMAI_CMD_VER_BASE, DPDMAI_CMD_CODE_CREATE,
			NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpdmai",
		                       NO_PORTAL_ID, destroy);

	return err;
}

static int dpdmai_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman){
		pr_err("Can't find resman");
		return -ENODEV;
	}

	dev = resman_open_dev(
	        resman, "dpdmai",
	        (uint16_t)id,
	        NO_PORTAL_ID, 0, NULL);
	if (!dev){
		pr_err("Can't open DPDMAI 0x%.4x\n", id);
		return -ENODEV;
	}

        err |= dpdmai_ctrl_cb(dev, DPDMAI_CMD_VER_BASE, DPDMAI_CMD_CODE_DESTROY, NO_PORTAL_ID, NULL);
        err |= resman_close_dev(resman, dev, "dpdmai",
			                       NO_PORTAL_ID, 0);
	return err;
}

static char *dpdmai_match[] = { "fsl,dpdmai", "dpdmai" };

int dpdmai_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	int err;

	pr_info("Executing dpdmai_drv_init...\n");
	
	dtc_params.num_compats = ARRAY_SIZE(dpdmai_match);
	dtc_params.compatibles = dpdmai_match;
	dtc_params.f_prob_module = dpdmai_probe_cb;
	dtc_params.f_remove_module = dpdmai_remove_cb;
	sys_dtc_register_module(&dtc_params);

	cmdif_ops.open_cb = dpdmai_open_cb;
	cmdif_ops.close_cb = dpdmai_close_cb;
	cmdif_ops.ctrl_cb = dpdmai_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPDMAI, &cmdif_ops);
	strcpy(dev_type_param.device_type, "dpdmai");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPDMAI_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPDMAI_VER_MAJOR;
	dev_type_param.ver_minor = DPDMAI_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	err = resman_register_device_operation(resman, "dpdmai",
	                                       &dev_type_param);
	return err;
}
