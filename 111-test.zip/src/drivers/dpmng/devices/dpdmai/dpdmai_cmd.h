/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPDMAI_CMD_H
#define _DPDMAI_CMD_H

/* default version for all ddpmai commands */
#define DPDMAI_CMD_VER_BASE								CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPDMAI_CMD_V0									CMDHDR_CMD_VERSION(0)
#define DPDMAI_CMD_V1									CMDHDR_CMD_VERSION(1)
#define DPDMAI_CMD_V2									CMDHDR_CMD_VERSION(2)
#define DPDMAI_CMD_V3									CMDHDR_CMD_VERSION(3)

/* add your new command version number here
 * Ex:
 * #define DPDMAI_CMD_CREATE_VER_1                       MC_CMD_HDR_VERSION(DPDMAI_CMD_VER_BASE + 1) or
 * #define DPDMAI_CMD_CREATE_VER                         MC_CMD_HDR_VERSION(3)
 */

/* Command IDs */
#define DPDMAI_CMD_CODE_CLOSE                           0x800
#define DPDMAI_CMD_CODE_OPEN                            0x80E
#define DPDMAI_CMD_CODE_CREATE                          0x90E
#define DPDMAI_CMD_CODE_DESTROY                         0x900
#define DPDMAI_CMD_CODE_GET_API_VERSION                 0xa0E

#define DPDMAI_CMD_CODE_ENABLE                          0x002
#define DPDMAI_CMD_CODE_DISABLE                         0x003
#define DPDMAI_CMD_CODE_GET_ATTR                        0x004
#define DPDMAI_CMD_CODE_RESET                           0x005
#define DPDMAI_CMD_CODE_IS_ENABLED                      0x006

#define DPDMAI_CMD_CODE_SET_IRQ                         0x010
#define DPDMAI_CMD_CODE_GET_IRQ                         0x011
#define DPDMAI_CMD_CODE_SET_IRQ_ENABLE                  0x012
#define DPDMAI_CMD_CODE_GET_IRQ_ENABLE                  0x013
#define DPDMAI_CMD_CODE_SET_IRQ_MASK                    0x014
#define DPDMAI_CMD_CODE_GET_IRQ_MASK                    0x015
#define DPDMAI_CMD_CODE_GET_IRQ_STATUS                  0x016
#define DPDMAI_CMD_CODE_CLEAR_IRQ_STATUS                0x017

#define DPDMAI_CMD_CODE_SET_RX_QUEUE                    0x1A0
#define DPDMAI_CMD_CODE_GET_RX_QUEUE                    0x1A1
#define DPDMAI_CMD_CODE_GET_TX_QUEUE                    0x1A2

#define DPDMAI_CMD_CODE_SET_RX_CONGESTION_NOTIFICATION  0x1A4
#define DPDMAI_CMD_CODE_SET_TX_CONGESTION_NOTIFICATION  0x1A5
#define DPDMAI_CMD_CODE_GET_RX_CONGESTION_NOTIFICATION  0x1A6
#define DPDMAI_CMD_CODE_GET_TX_CONGESTION_NOTIFICATION  0x1A7

#endif /* _DPDMAI_CMD_H */
