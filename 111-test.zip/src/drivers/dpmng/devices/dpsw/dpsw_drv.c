/*
 * Copyright 2013-2021 NXP
 */

/**************************************************************************//*
 @File          dpsw_drv.c

 @Description   Driver implementation

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "dplib/fsl_dpsw_cmd.h"
#include "fsl_event_pipe.h"
#include "fsl_dpsw_mc.h"
#include "fsl_sys.h"
#include "dtc/dtc.h"
#include "dpmng.h"
#include "fsl_resman.h"
#include "dpsw_cmd.h"
#include "legacy_dpsw_dplib.h"

#define DPSW_CMD_EXTRACT_EXT_PARAMS		10
#define DPSW_CMD_EARLY_DROP_EXT_PARAMS		13

/* DPSW last supported API version */
#define DPSW_V0_API_VER_MAJOR				7
#define DPSW_V0_API_VER_MINOR				0

int dpsw_drv_init(void);

/*                cmd, param, offset, width, type, arg_name */
#define DPSW_LO_CREATE(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  16, uint16_t, cfg->num_ifs);\
	MC_RSP_OP(cmd, 0, 16,  8, uint8_t,  cfg->adv.max_fdbs);\
	MC_RSP_OP(cmd, 0, 24,  8, uint8_t,  cfg->adv.max_meters_per_if);\
	MC_RSP_OP(cmd, 0, 32,  4, enum dpsw_component_type,  \
			cfg->adv.component_type);\
	MC_RSP_OP(cmd, 1, 0,  16, uint16_t, cfg->adv.max_vlans);\
	MC_RSP_OP(cmd, 1, 16, 16, uint16_t, cfg->adv.max_fdb_entries);\
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t, cfg->adv.fdb_aging_time);\
	MC_RSP_OP(cmd, 1, 48, 16, uint16_t, cfg->adv.max_fdb_mc_groups);\
	MC_RSP_OP(cmd, 2, 0,  64, uint64_t, cfg->adv.options);\
	MC_RSP_OP(cmd, 3, 0,   8,  uint8_t, cfg->adv.lag[0]);\
	MC_RSP_OP(cmd, 3, 8,   8,  uint8_t, cfg->adv.lag[1]);\
	MC_RSP_OP(cmd, 3, 16,  8,  uint8_t, cfg->adv.lag[2]);\
	MC_RSP_OP(cmd, 3, 24,  8,  uint8_t, cfg->adv.lag[3]);\
	MC_RSP_OP(cmd, 3, 32,  8,  uint8_t, cfg->adv.lag[4]);\
	MC_RSP_OP(cmd, 3, 40,  8,  uint8_t, cfg->adv.lag[5]);\
	MC_RSP_OP(cmd, 3, 48,  8,  uint8_t, cfg->adv.lag[6]);\
	MC_RSP_OP(cmd, 3, 56,  8,  uint8_t, cfg->adv.lag[7]);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSW_LO_CREATE_V2(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  16, uint16_t, cfg->num_ifs);\
	MC_RSP_OP(cmd, 0, 16,  8, uint8_t,  cfg->adv.max_fdbs);\
	MC_RSP_OP(cmd, 0, 24,  8, uint8_t,  cfg->adv.max_meters_per_if);\
	MC_RSP_OP(cmd, 0, 32,  4, enum dpsw_component_type,  \
			cfg->adv.component_type);\
	MC_RSP_OP(cmd, 0, 48, 16, uint16_t,	cfg->adv.mem_size);\
	MC_RSP_OP(cmd, 1, 0,  16, uint16_t, cfg->adv.max_vlans);\
	MC_RSP_OP(cmd, 1, 16, 16, uint16_t, cfg->adv.max_fdb_entries);\
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t, cfg->adv.fdb_aging_time);\
	MC_RSP_OP(cmd, 1, 48, 16, uint16_t, cfg->adv.max_fdb_mc_groups);\
	MC_RSP_OP(cmd, 2, 0,  64, uint64_t, cfg->adv.options);\
	MC_RSP_OP(cmd, 3, 0,   8,  uint8_t, cfg->adv.lag[0]);\
	MC_RSP_OP(cmd, 3, 8,   8,  uint8_t, cfg->adv.lag[1]);\
	MC_RSP_OP(cmd, 3, 16,  8,  uint8_t, cfg->adv.lag[2]);\
	MC_RSP_OP(cmd, 3, 24,  8,  uint8_t, cfg->adv.lag[3]);\
	MC_RSP_OP(cmd, 3, 32,  8,  uint8_t, cfg->adv.lag[4]);\
	MC_RSP_OP(cmd, 3, 40,  8,  uint8_t, cfg->adv.lag[5]);\
	MC_RSP_OP(cmd, 3, 48,  8,  uint8_t, cfg->adv.lag[6]);\
	MC_RSP_OP(cmd, 3, 56,  8,  uint8_t, cfg->adv.lag[7]);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSW_LO_CREATE_V3(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  16, uint16_t, cfg->num_ifs);\
	MC_RSP_OP(cmd, 0, 16,  8, uint8_t,  cfg->adv.max_fdbs);\
	MC_RSP_OP(cmd, 0, 24,  8, uint8_t,  cfg->adv.max_meters_per_if);\
	MC_RSP_OP(cmd, 0, 32,  4, enum dpsw_component_type,  \
			cfg->adv.component_type);\
	MC_RSP_OP(cmd, 0, 40, 4,  enum dpsw_flooding_cfg, cfg->adv.flooding_cfg);\
	MC_RSP_OP(cmd, 0, 44, 4,  enum dpsw_broadcast_cfg, cfg->adv.broadcast_cfg);\
	MC_RSP_OP(cmd, 0, 48, 16, uint16_t, cfg->adv.mem_size);\
	MC_RSP_OP(cmd, 1, 0,  16, uint16_t, cfg->adv.max_vlans);\
	MC_RSP_OP(cmd, 1, 16, 16, uint16_t, cfg->adv.max_fdb_entries);\
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t, cfg->adv.fdb_aging_time);\
	MC_RSP_OP(cmd, 1, 48, 16, uint16_t, cfg->adv.max_fdb_mc_groups);\
	MC_RSP_OP(cmd, 2, 0,  64, uint64_t, cfg->adv.options);\
	MC_RSP_OP(cmd, 3, 0,   8,  uint8_t, cfg->adv.lag[0]);\
	MC_RSP_OP(cmd, 3, 8,   8,  uint8_t, cfg->adv.lag[1]);\
	MC_RSP_OP(cmd, 3, 16,  8,  uint8_t, cfg->adv.lag[2]);\
	MC_RSP_OP(cmd, 3, 24,  8,  uint8_t, cfg->adv.lag[3]);\
	MC_RSP_OP(cmd, 3, 32,  8,  uint8_t, cfg->adv.lag[4]);\
	MC_RSP_OP(cmd, 3, 40,  8,  uint8_t, cfg->adv.lag[5]);\
	MC_RSP_OP(cmd, 3, 48,  8,  uint8_t, cfg->adv.lag[6]);\
	MC_RSP_OP(cmd, 3, 56,  8,  uint8_t, cfg->adv.lag[7]);\
} while (0)

static int read_if_id_bitmap(uint16_t *if_id, uint16_t *num_ifs, struct mc_cmd_data *cmd_data, int start_param)
{
	int bitmap[DPSW_MAX_IF] = { 0 };
	int i, j = 0;
	int count = 0;

	for (i = 0; i < DPSW_MAX_IF; i++)
	{
		bitmap[i] = (int)u64_dec(swap_uint64(cmd_data->params[start_param + i / 64]), i % 64, 1);
		count += bitmap[i];
	}

	*num_ifs = (uint16_t)count;

	for (i = 0; (j < count) && (i < DPSW_MAX_IF); i++){
		if (bitmap[i]){
			if_id[j] = (uint16_t)i;
			j++;
		}
	}

	return 0;
}

static void build_if_id_bitmap(const uint16_t *if_id,
			       const uint16_t num_ifs,
	struct mc_cmd_data *cmd_data,
	int start_param)
{
	int i;
	int count = 0;

	for (i = 0; (count < num_ifs) && (i < DPSW_MAX_IF); i++){
		cmd_data->params[start_param + (if_id[i] / 64)] |= swap_uint64(u64_enc(
			(if_id[i] % 64), 1, 1));
		if (if_id[i] % 64)
			count++;
	}
}

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpsw *dpsw;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	return dpsw_set_dev_ctx(dpsw, dev_ctx);
}

static int init_common(struct device *dev, struct dpsw_cfg *cfg, int ver)
{
	struct dpsw *dpsw;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	int err;

	if (ver < 2)
		cfg->adv.mem_size = 0;

	dpsw = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpsw) {
		/*! Allocate L2 switch */
		dpsw = dpsw_allocate();
		CHECK_COND_RETVAL(dpsw, -ENOMEM, "No memory for dpsw\n");

		/* Get device parameters */
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);
		dev_cfg.device = dev;
		dev_cfg.id = device_get_id(dev);
		/*! Init switch */
		err = dpsw_init(dpsw, cfg, &dev_cfg);

		if (err) {
			dpsw_deallocate(dpsw);
			return err;
		}

		/*! Register in resource manager */
		device_set_priv(dev, dpsw);

		/*! System registration */
		sys_add_handle(dpsw, FSL_MOD_DPSW, 1, dev_cfg.id);

		/* Pass AMQ to L2 switch */
		assign(dev, &(dev_cfg.ctx));
	}
	else
		return -EINVAL;

	return 0;
}

static int init_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw_cfg dpsw_cfg;
	struct dpsw_cfg *cfg = &dpsw_cfg;

	memset(cfg, 0, sizeof(struct dpsw_cfg));
	DPSW_CMD_CREATE(cmd_data, cfg);

	return init_common(dev, cfg, 1);
}

static int init_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw_cfg dpsw_cfg;
	struct dpsw_cfg *cfg = &dpsw_cfg;

	memset(cfg, 0, sizeof(struct dpsw_cfg));
	DPSW_CMD_CREATE_V2(cmd_data, cfg);

	return init_common(dev, cfg, 2);
}

static int init_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw_cfg dpsw_cfg;
	struct dpsw_cfg *cfg = &dpsw_cfg;

	memset(cfg, 0, sizeof(struct dpsw_cfg));
	DPSW_CMD_CREATE_V3(cmd_data, cfg);

	return init_common(dev, cfg, 3);
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_attr attr = { 0 };
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	err = dpsw_get_attributes(dpsw, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.version.major = DPSW_V0_API_VER_MAJOR;
	attr.version.minor = DPSW_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSW_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_attr attr = { 0 };
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	err = dpsw_get_attributes(dpsw, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSW_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int get_attributes_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw_attr attr = { 0 };
	struct dpsw *dpsw;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	err = dpsw_get_attributes(dpsw, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSW_RSP_GET_ATTRIBUTES_V2(cmd_data, &attr);

	return 0;
}

static int fdb_dump(struct device *dev, struct mc_cmd_data *cmd_data)
{
	uint16_t fdb_id;
	uint64_t snapshot_iova;
	uint32_t iova_size;
	uint16_t table_size = 0;
	int err;

	DPSW_CMD_FDB_READ_TABLE(cmd_data, fdb_id, snapshot_iova, iova_size);

	err = dpsw_dump_fdb_table(dev, fdb_id, snapshot_iova, (int)iova_size, &table_size);
	CHECK_COND_RETVAL(err==0, err);

	DPSW_RSP_FDB_FDB_DUMP(cmd_data, table_size);

	return 0;
}

static int lag_set(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_lag_cfg lag_cfg = { 0 };
	struct dpsw_lag_cfg *cfg = &lag_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_SET_LAG(cmd_data, cfg);

	return dpsw_lag_set(dpsw, cfg);
}

static int lag_get(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint8_t group_id;
	struct dpsw_lag_cfg lag_cfg= { 0 };
	struct dpsw_lag_cfg *cfg = &lag_cfg;
	int err = 0;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_GET_LAG(cmd_data, group_id);

	err = dpsw_lag_get(dpsw, group_id, cfg);
	if (!err)
	{
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_GET_LAG(cmd_data, cfg);
	}
	return err;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;

	UNUSED(cmd_data);

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	dpsw_destroy(dpsw);

	sys_remove_handle(FSL_MOD_DPSW, 1, device_get_id(dev));
	dpsw_deallocate(dpsw);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	int err;

	UNUSED(cmd_data);

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	device_set_enable(dev, 1);

	err = dpsw_enable(dpsw);
	if (err)
		device_set_enable(dev, 0);

	return err;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	int err;

	UNUSED(cmd_data);

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	err = dpsw_disable(dpsw);
	if (!err){
		device_set_enable(dev, 0);
		return 0;
	}

	return err;
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	int err;

	UNUSED(cmd_data);

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	err = dpsw_reset(dpsw);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}
#if 0 //removed unsupported functions
static int set_policer(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_policer_cfg policer_cfg;
	struct dpsw_policer_cfg *cfg = &policer_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_policer_cfg));

	DPSW_CMD_SET_POLICER(cmd_data, cfg);

	return dpsw_set_policer(dpsw, cfg);
}

static int set_buffer_depletion(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_buffer_depletion_cfg buffer_depletion = { 0 };
	struct dpsw_buffer_depletion_cfg *cfg = &buffer_depletion;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_SET_BUFFER_DEPLETION(cmd_data, cfg);

	return dpsw_set_buffer_depletion(dpsw, cfg);
}
#endif
static int set_reflection_if(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_SET_REFLECTION_IF(cmd_data, if_id);

	return dpsw_set_reflection_if(dpsw, if_id);
}
#if 0
static int set_parser_error_action(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_parser_error_action_cfg action_cfg;
	struct dpsw_parser_error_action_cfg *cfg = &action_cfg;
	uint64_t paddr;
	uint32_t size;
	struct {
		uint64_t params[8];
	}ext_data;
	int param = 0;
	int offset = 0;
	int i;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_parser_error_action_cfg));

	DPSW_CMD_SET_PARSER_ERROR_ACTION(CMD_READ);

	/* Read from DMA */
	err = dpmng_dma(dev, paddr, &ext_data, size);
	if (err)
		return err;
	
	for (i = 0; i < 8; i++){
		cfg->prot[i] = (enum net_prot)u64_dec(swap_uint64(ext_data.params[param]), offset, 8);
		offset += 8;
		if (offset == 64){
			offset = 0;
			param++;
		}
	}

	return dpsw_set_parser_error_action(dpsw, cfg);
}
#endif

#if 0 //removed unsupported functions
static int set_ptp_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_ptp_v2_cfg ptp_v2 = { 0 };
	struct dpsw_ptp_v2_cfg *cfg = &ptp_v2;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_SET_PTP_V2(cmd_data, cfg);

	return dpsw_set_ptp_v2(dpsw, cfg);
}
#endif
static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	int en;
	int err = 0;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	err = device_get_enable(dev, &en);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_IS_ENABLED(cmd_data, en);
	}
	return err;
}

static int if_set_tci(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_tci_cfg tci_cfg = { 0 };
	struct dpsw_tci_cfg *cfg = &tci_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_SET_TCI(cmd_data, if_id, cfg);

	return dpsw_if_set_tci(dpsw, if_id, cfg);
}

static int if_get_tci(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_tci_cfg tci_cfg = { 0 };
	struct dpsw_tci_cfg *cfg = &tci_cfg;
	int err = 0;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_GET_TCI(cmd_data, if_id);

	err = dpsw_if_get_tci(dpsw, if_id, cfg);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_IF_GET_TCI(cmd_data, cfg);
	}
	return err;
}

static int if_set_stp(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_stp_cfg stp_state_cfg = { 0 };
	struct dpsw_stp_cfg *cfg = &stp_state_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_SET_STP(cmd_data, if_id, cfg);

	return dpsw_if_set_stp(dpsw, if_id, cfg);
}

static int if_set_accepted_frames(struct device *dev,
                                  struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_accepted_frames_cfg accepted_frames_cfg;
	struct dpsw_accepted_frames_cfg *cfg = &accepted_frames_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_accepted_frames_cfg));

	DPSW_CMD_IF_SET_ACCEPTED_FRAMES(cmd_data, if_id, cfg);

	return dpsw_if_set_accepted_frames(dpsw, if_id, cfg);
}

static int set_if_accept_all_vlan(struct device *dev,
                                  struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	int accept_all;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_SET_ACCEPT_ALL_VLAN(cmd_data, if_id, accept_all);

	return dpsw_if_set_accept_all_vlan(dpsw, if_id, accept_all);
}

static int if_get_counter_common(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	enum dpsw_counter type;
	uint64_t counter;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_GET_COUNTER(cmd_data, if_id, type);

	if ((ver < 2) && (type > DPSW_CNT_EGR_STP_FRAME_DISCARD))
		return -ENOTSUP;

	err = dpsw_if_get_counter(dpsw, if_id, type, &counter);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_IF_GET_COUNTER(cmd_data, counter);
	}
	return err;
}

static int if_get_counter_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_get_counter_common(dev, cmd_data, 1);
}

static int if_get_counter_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_get_counter_common(dev, cmd_data, 2);
}

static int if_set_counter_common(struct device *dev, struct mc_cmd_data *cmd_data, int version)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	enum dpsw_counter type;
	uint64_t counter;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_SET_COUNTER(cmd_data, if_id, type, counter);

	if((version < 2) && (type > DPSW_CNT_EGR_STP_FRAME_DISCARD))
		return -ENOTSUP;

	return dpsw_if_set_counter(dpsw, if_id, type, counter);
}

static int if_set_counter_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_set_counter_common(dev, cmd_data, 1);
}

static int if_set_counter_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_set_counter_common(dev, cmd_data, 2);
}

static int if_set_tx_selection_common(struct device *dev, struct mc_cmd_data *cmd_data,
									  int ver)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_tx_selection_cfg tmp_cfg;
	struct dpsw_tx_selection_cfg *cfg = &tmp_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_tx_selection_cfg));
	DPSW_CMD_IF_SET_TX_SELECTION(cmd_data, if_id, cfg);

	if (ver < 2 && cfg->priority_selector == DPSW_PRIORITY_SELECTOR_NO_CHANGE) {
		pr_err("Invalid value for PRIORITY_SELECTOR field\n");
		return -EINVAL;
	}

	return dpsw_if_set_tx_selection(dpsw, if_id, cfg);
}

static int if_set_tx_selection_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_set_tx_selection_common(dev, cmd_data, 1);
}

static int if_set_tx_selection_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_set_tx_selection_common(dev, cmd_data, 2);
}

static int if_set_prio_selector(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_prio_selector_cfg tmp_cfg;
	struct dpsw_prio_selector_cfg *cfg = &tmp_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_prio_selector_cfg));
	DPSW_CMD_IF_SET_PRIO_SELECTOR(cmd_data, if_id, cfg);

	return dpsw_if_set_prio_selector(dpsw, if_id, cfg);
}

static int if_add_reflection(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_reflection_cfg reflection_cfg;
	struct dpsw_reflection_cfg *cfg = &reflection_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_reflection_cfg));

	DPSW_CMD_IF_ADD_REFLECTION(cmd_data, if_id, cfg);

	return dpsw_if_add_reflection(dpsw, if_id, cfg);
}

static int if_remove_reflection(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_reflection_cfg reflection_cfg;
	struct dpsw_reflection_cfg *cfg = &reflection_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_reflection_cfg));

	DPSW_CMD_IF_REMOVE_REFLECTION(cmd_data,if_id, cfg);

	return dpsw_if_remove_reflection(dpsw, if_id, cfg);
}

static int if_set_flooding_metering(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_metering_cfg meter_cfg;
	struct dpsw_metering_cfg *cfg = &meter_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_metering_cfg));

	DPSW_CMD_IF_SET_FLOODING_METERING(cmd_data, if_id, cfg);

	return dpsw_if_set_flooding_metering(dpsw, if_id, cfg);
}

static int if_set_metering(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	uint8_t tc_id;
	struct dpsw_metering_cfg meter_cfg;
	struct dpsw_metering_cfg *cfg = &meter_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_metering_cfg));

	DPSW_CMD_IF_SET_METERING(cmd_data, if_id, tc_id, cfg);

	return dpsw_if_set_metering(dpsw, if_id, tc_id, cfg);
}

static int if_set_early_drop(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint8_t tc_id;
	uint16_t if_id;
	struct dpsw_early_drop_cfg early_drop_cfg;
	struct dpsw_early_drop_cfg *cfg = &early_drop_cfg;
	uint64_t		early_drop_iova;
	uint64_t ext_params[DPSW_CMD_EARLY_DROP_EXT_PARAMS] = { 0 };
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_early_drop_cfg));

	/* Read parameters from portal */
	DPSW_CMD_IF_SET_EARLY_DROP(cmd_data, if_id, tc_id, early_drop_iova);

	/* Read from DMA */
	err = dpmng_dev_memcpy(dev, ext_params, early_drop_iova,
			DPSW_CMD_EARLY_DROP_EXT_PARAMS * sizeof(uint64_t),
			1);
	CHECK_COND_RETVAL(err == 0, err, "Error reading extended DMA parameters\n");

	/* Read extension */
	DPSW_EXT_EARLY_DROP(ext_params, cfg);

	return dpsw_if_tc_set_early_drop(dpsw, if_id, tc_id, cfg);
}

static int add_custom_tpid(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_custom_tpid_cfg custom_tpid_cfg = { 0 };
	struct dpsw_custom_tpid_cfg *cfg = &custom_tpid_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_ADD_CUSTOM_TPID(cmd_data, cfg);

	return dpsw_add_custom_tpid(dpsw, cfg);
}

static int remove_custom_tpid(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_custom_tpid_cfg custom_tpid_cfg = { 0 };
	struct dpsw_custom_tpid_cfg *cfg = &custom_tpid_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_REMOVE_CUSTOM_TPID(cmd_data, cfg);

	return dpsw_remove_custom_tpid(dpsw, cfg);
}
#if 0 //removed unsupported functions
static int if_set_transmit_rate(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_transmit_rate_cfg rate_cfg = { 0 };
	struct dpsw_transmit_rate_cfg *cfg = &rate_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_SET_TRANSMIT_RATE(cmd_data, if_id, cfg);

	return dpsw_if_set_transmit_rate(dpsw, if_id, cfg);
}

static int if_tc_set_bandwidth(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	uint8_t tc_id;
	struct dpsw_bandwidth_cfg bw_cfg;
	struct dpsw_bandwidth_cfg *cfg = &bw_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_bandwidth_cfg));

	DPSW_CMD_IF_TC_SET_BANDWIDTH(cmd_data, if_id, tc_id, cfg);

	return dpsw_if_tc_set_bandwidth(dpsw, if_id, tc_id, cfg);
}
#endif
static int if_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_ENABLE(cmd_data, if_id);

	return dpsw_if_enable(dpsw, if_id);
}

static int if_disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_DISABLE(cmd_data, if_id);

	return dpsw_if_disable(dpsw, if_id);
}

#if 0 //removed unsupported functions
static int if_tc_set_queue_congestion(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	uint8_t tc_id;
	struct dpsw_queue_congestion_cfg q_cfg = { 0 };
	struct dpsw_queue_congestion_cfg *cfg = &q_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_TC_SET_Q_CONGESTION(cmd_data, if_id, tc_id, cfg);

	return dpsw_if_tc_set_queue_congestion(dpsw, if_id, tc_id, cfg);
}

static int if_tc_set_pfc(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	uint8_t tc_id;
	struct dpsw_pfc_cfg pfc_cfg = { 0 };
	struct dpsw_pfc_cfg *cfg = &pfc_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_TC_SET_PFC(cmd_data, if_id, tc_id, cfg);

	return dpsw_if_tc_set_pfc(dpsw, if_id, tc_id, cfg);
}

static int if_tc_set_cn(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	uint8_t tc_id;
	struct dpsw_cn_cfg cn_cfg = { 0 };
	struct dpsw_cn_cfg *cfg = &cn_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_TC_SET_CN(cmd_data, if_id, tc_id, cfg);

	return dpsw_if_tc_set_cn(dpsw, if_id, tc_id, cfg);
}
#endif
static int if_get_attributes(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_if_attr attrib = { 0 };
	struct dpsw_if_attr *attr = &attrib;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_GET_ATTR(cmd_data, if_id);

	err = dpsw_if_get_attributes(dpsw, if_id, attr);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_IF_GET_ATTR(cmd_data, attr);
	}
	return err;
}
#if 0 //removed unsupported functions
static int if_set_macsec(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_macsec_cfg macsec_cfg = { 0 };
	struct dpsw_macsec_cfg *cfg = &macsec_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_SET_MACSEC(cmd_data, if_id, cfg);

	return dpsw_if_set_macsec(dpsw, if_id, cfg);
}
#endif
static int vlan_add(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t vlan_id;
	struct dpsw_vlan_cfg vlan_cfg = { 0 };
	struct dpsw_vlan_cfg *cfg = &vlan_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_ADD(cmd_data, vlan_id, cfg);

	return dpsw_vlan_add(dpsw, vlan_id, cfg);
}

static int vlan_add_if(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t vlan_id;
	struct dpsw_vlan_if_cfg vlan_cfg = { 0 };
	struct dpsw_vlan_if_cfg *cfg = &vlan_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_ADD_IF(cmd_data, vlan_id);

	read_if_id_bitmap(cfg->if_id, &(cfg->num_ifs), cmd_data, 1);

	return dpsw_vlan_add_if(dpsw, vlan_id, cfg);
}

static int vlan_add_if_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw_vlan_if_cfg vlan_cfg = { 0 };
	struct dpsw_vlan_if_cfg *cfg = &vlan_cfg;
	struct dpsw *dpsw;
	uint16_t vlan_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_ADD_IF_V2(cmd_data, vlan_id, cfg);

	read_if_id_bitmap(cfg->if_id, &(cfg->num_ifs), cmd_data, 1);

	return dpsw_vlan_add_if(dpsw, vlan_id, cfg);
}

static int vlan_add_if_untagged(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t vlan_id;
	struct dpsw_vlan_if_cfg vlan_cfg = { 0 };
	struct dpsw_vlan_if_cfg *cfg = &vlan_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_ADD_IF_UNTAGGED(cmd_data, vlan_id);
	read_if_id_bitmap(cfg->if_id,&(cfg->num_ifs), cmd_data, 1);

	return dpsw_vlan_add_if_untagged(dpsw, vlan_id, cfg);
}

static int vlan_add_if_flooding(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t vlan_id;
	struct dpsw_vlan_if_cfg vlan_cfg = { 0 };
	struct dpsw_vlan_if_cfg *cfg = &vlan_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_ADD_IF_FLOODING(cmd_data, vlan_id);
	read_if_id_bitmap(cfg->if_id, &(cfg->num_ifs), cmd_data, 1);

	return dpsw_vlan_add_if_flooding(dpsw, vlan_id, cfg);
}

static int vlan_remove_if(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t vlan_id;
	struct dpsw_vlan_if_cfg vlan_cfg = { 0 };
	struct dpsw_vlan_if_cfg *cfg = &vlan_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_REMOVE_IF(cmd_data, vlan_id);
	read_if_id_bitmap(cfg->if_id, &(cfg->num_ifs), cmd_data, 1);

	return dpsw_vlan_remove_if(dpsw, vlan_id, cfg);
}

static int vlan_remove_if_untagged(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t vlan_id;
	struct dpsw_vlan_if_cfg vlan_cfg = { 0 };
	struct dpsw_vlan_if_cfg *cfg = &vlan_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_REMOVE_IF_UNTAGGED(cmd_data, vlan_id);
	read_if_id_bitmap(cfg->if_id, &(cfg->num_ifs), cmd_data, 1);

	return dpsw_vlan_remove_if_untagged(dpsw, vlan_id, cfg);
}

static int vlan_remove_if_flooding(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t vlan_id;
	struct dpsw_vlan_if_cfg vlan_cfg = { 0 };
	struct dpsw_vlan_if_cfg *cfg = &vlan_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_REMOVE_IF_FLOODING(cmd_data, vlan_id);
	read_if_id_bitmap(cfg->if_id, &(cfg->num_ifs), cmd_data, 1);

	return dpsw_vlan_remove_if_flooding(dpsw, vlan_id, cfg);
}

static int vlan_remove(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t vlan_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_REMOVE(cmd_data, vlan_id);

	return dpsw_vlan_remove(dpsw, vlan_id);
}

static int fdb_add(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t fdb_id;
	struct dpsw_fdb_cfg fdb_cfg = { 0 };
	struct dpsw_fdb_cfg *cfg = &fdb_cfg;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_FDB_ADD(cmd_data, cfg);

	err = dpsw_fdb_add(dpsw, &fdb_id, cfg);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_FDB_ADD(cmd_data, fdb_id);
	}
	return err;
}

static int fdb_remove(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t fdb_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_FDB_REMOVE(cmd_data, fdb_id);

	return dpsw_fdb_remove(dpsw, fdb_id);
}

static int fdb_add_unicast(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_fdb_unicast_cfg unicast_cfg;
	struct dpsw_fdb_unicast_cfg *cfg = &unicast_cfg;
	uint16_t			fdb_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_fdb_unicast_cfg));

	DPSW_CMD_FDB_ADD_UNICAST(cmd_data, fdb_id, cfg);

	return dpsw_fdb_add_unicast(dpsw, fdb_id, cfg);
}

static int fdb_remove_unicast(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_fdb_unicast_cfg unicast_cfg;
	struct dpsw_fdb_unicast_cfg *cfg = &unicast_cfg;
	uint16_t			fdb_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_fdb_unicast_cfg));

	DPSW_CMD_FDB_REMOVE_UNICAST(cmd_data, fdb_id, cfg);

	return dpsw_fdb_remove_unicast(dpsw, fdb_id, cfg);
}
static int fdb_add_multicast(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_fdb_multicast_cfg multicast_cfg;
	struct dpsw_fdb_multicast_cfg *cfg = &multicast_cfg;
	uint16_t			fdb_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_fdb_multicast_cfg));

	DPSW_CMD_FDB_ADD_MULTICAST(cmd_data, fdb_id, cfg);
	read_if_id_bitmap(cfg->if_id, &(cfg->num_ifs), cmd_data, 2);

	return dpsw_fdb_add_multicast(dpsw, fdb_id, cfg);
}

static int fdb_remove_multicast(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_fdb_multicast_cfg multicast_cfg;
	struct dpsw_fdb_multicast_cfg *cfg = &multicast_cfg;
	uint16_t			fdb_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_fdb_multicast_cfg));

	DPSW_CMD_FDB_REMOVE_MULTICAST(cmd_data, fdb_id, cfg);
	read_if_id_bitmap(cfg->if_id, &(cfg->num_ifs), cmd_data, 2);

	return dpsw_fdb_remove_multicast(dpsw, fdb_id, cfg);
}

static int fdb_set_learning_mode(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t			fdb_id;
	enum dpsw_learning_mode	 mode;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_FDB_SET_LEARNING_MODE(cmd_data, fdb_id, mode);

	return dpsw_fdb_set_learning_mode(dpsw, fdb_id, mode);
}

static int fdb_get_attributes(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t			fdb_id;
	struct dpsw_fdb_attr attrib = { 0 };
	struct dpsw_fdb_attr *attr = &attrib;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_FDB_GET_ATTR(cmd_data, fdb_id);

	err = dpsw_fdb_get_attributes(dpsw, fdb_id, attr);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_FDB_GET_ATTR(cmd_data, attr);
	}
	return err;
}

static int fdb_get_multicast(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t			fdb_id;
	struct dpsw_fdb_multicast_cfg mcast_cfg;
	struct dpsw_fdb_multicast_cfg *cfg = &mcast_cfg;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(cfg, 0, sizeof(struct dpsw_fdb_multicast_cfg));

	DPSW_CMD_FDB_GET_MULTICAST(cmd_data, fdb_id);

	err = dpsw_fdb_get_multicast(dpsw, fdb_id, cfg);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_FDB_GET_MULTICAST(cmd_data, cfg);
		build_if_id_bitmap(cfg->if_id, cfg->num_ifs, cmd_data, 2);
	}
	return err;
}

static int fdb_get_unicast(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t			fdb_id;
	struct dpsw_fdb_unicast_cfg unicast_cfg;
	struct dpsw_fdb_unicast_cfg *cfg = &unicast_cfg;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	memset(&unicast_cfg, 0, sizeof(struct dpsw_fdb_unicast_cfg));

	DPSW_CMD_FDB_GET_UNICAST(cmd_data, fdb_id);

	err = dpsw_fdb_get_unicast(dpsw, fdb_id, cfg);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_FDB_GET_UNICAST(cmd_data, cfg);
	}
	return err;
}

static int if_set_max_frame_length(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
        uint16_t if_id;
        uint16_t frame_length;

        dpsw = device_get_priv(dev);
        CHECK_COND_RETVAL(dpsw, -ENODEV);

    	DPSW_CMD_IF_SET_MAX_FRAME_LENGTH(cmd_data, if_id, frame_length);

        return dpsw_if_set_max_frame_length(dpsw, if_id, frame_length);
}

static int if_get_max_frame_length(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t	if_id;
	uint16_t	frame_length;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_GET_MAX_FRAME_LENGTH(cmd_data, if_id);

	err = dpsw_if_get_max_frame_length(dpsw, if_id, &frame_length);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_IF_GET_MAX_FRAME_LENGTH(cmd_data, frame_length);
	}
	return err;
}

static int if_set_link_cfg(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_link_cfg link_cfg = { 0 };
	struct dpsw_link_cfg *cfg = &link_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);
	
	if (ver < 2)
	{
		DPSW_CMD_IF_SET_LINK_CFG_V1(cmd_data, if_id, cfg);
		cfg->advertising = 0;
	}
	else
		DPSW_CMD_IF_SET_LINK_CFG(cmd_data, if_id, cfg);
	
	return dpsw_if_set_link_cfg(dpsw, if_id, cfg);
}

static int if_set_link_cfg_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_set_link_cfg(dev, cmd_data, 1);
}
static int if_set_link_cfg_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_set_link_cfg(dev, cmd_data, 2);
}


static int if_get_link_state(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpsw *dpsw;
	uint16_t if_id;
	struct dpsw_link_state link_state = { 0 };
	struct dpsw_link_state *state = &link_state;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_GET_LINK_STATE(cmd_data, if_id);

	err = dpsw_if_get_link_state(dpsw, if_id, state);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	if (ver < 2)
		DPSW_RSP_IF_GET_LINK_STATE_V1(cmd_data, state);
	else
		DPSW_RSP_IF_GET_LINK_STATE(cmd_data, state);

	return 0;
}

static int if_get_link_state_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_get_link_state(dev, cmd_data, 1);
}
static int if_get_link_state_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_get_link_state(dev, cmd_data, 2);
}

static int vlan_get_if(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t	vlan_id;
	struct dpsw_vlan_if_cfg if_cfg= { 0 };
	struct dpsw_vlan_if_cfg *cfg = &if_cfg;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_GET_IF(cmd_data, vlan_id);

	err = dpsw_vlan_get_if(dpsw, vlan_id, cfg);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_VLAN_GET_IF(cmd_data, cfg);
		build_if_id_bitmap(cfg->if_id, cfg->num_ifs, cmd_data, 1);
	}
	return err;
}

static int vlan_get_if_flooding(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t	vlan_id;
	struct dpsw_vlan_if_cfg if_cfg= { 0 };
	struct dpsw_vlan_if_cfg *cfg = &if_cfg;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_GET_IF_FLOODING(cmd_data, vlan_id);

	err = dpsw_vlan_get_if_flooding(dpsw, vlan_id, cfg);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_VLAN_GET_IF_FLOODING(cmd_data, cfg);
		build_if_id_bitmap(cfg->if_id, cfg->num_ifs, cmd_data, 1);
	}
	return err;
}

static int vlan_get_if_untagged(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t	vlan_id;
	struct dpsw_vlan_if_cfg if_cfg= { 0 };
	struct dpsw_vlan_if_cfg *cfg = &if_cfg;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_GET_IF_UNTAGGED(cmd_data, vlan_id);

	err = dpsw_vlan_get_if_untagged(dpsw, vlan_id, cfg);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_VLAN_GET_IF_UNTAGGED(cmd_data, cfg);
		build_if_id_bitmap(cfg->if_id, cfg->num_ifs, cmd_data, 1);
	}
	return err;
}

static int vlan_get_attributes(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t	vlan_id;
	struct dpsw_vlan_attr vlan_attr = { 0 };
	struct dpsw_vlan_attr *attr = &vlan_attr;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_VLAN_GET_ATTR(cmd_data, vlan_id);

	err = dpsw_vlan_get_attributes(dpsw, vlan_id, attr);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_VLAN_GET_ATTR(cmd_data, attr);
	}
	return err;
}

static int if_set_flooding(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
        uint16_t if_id;
        int en;

    	dpsw = device_get_priv(dev);
    	CHECK_COND_RETVAL(dpsw, -ENODEV);

    	DPSW_CMD_IF_SET_FLOODING(cmd_data, if_id, en);

        return dpsw_if_set_flooding(dpsw, if_id, en);
}

static int if_set_broadcast(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
        uint16_t if_id;
        int en;

    	dpsw = device_get_priv(dev);
    	CHECK_COND_RETVAL(dpsw, -ENODEV);

    	DPSW_CMD_IF_SET_BROADCAST(cmd_data, if_id, en);

        return dpsw_if_set_broadcast(dpsw, if_id, en);
}

static int if_set_multicast(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
        uint16_t if_id;
        int en;

    	dpsw = device_get_priv(dev);
    	CHECK_COND_RETVAL(dpsw, -ENODEV);

    	DPSW_CMD_IF_SET_MULTICAST(cmd_data, if_id, en);

        return dpsw_if_set_multicast(dpsw, if_id, en);
}

static int acl_add(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
    uint16_t acl_id;
    struct dpsw_acl_cfg acl_cfg = { 0 };
    struct dpsw_acl_cfg *cfg = &acl_cfg;
    int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_ACL_ADD(cmd_data, cfg);

	err = dpsw_acl_add(dpsw, &acl_id, cfg);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_ACL_ADD(cmd_data, acl_id);
	}
	return err;
}

static int acl_remove(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
    uint16_t acl_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_ACL_REMOVE(cmd_data, acl_id);

	return dpsw_acl_remove(dpsw, acl_id);
}

static int acl_add_entry(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
    uint16_t acl_id;
    struct dpsw_acl_entry_cfg acl_entry_cfg = { 0 };
    struct dpsw_acl_entry_cfg *cfg = &acl_entry_cfg;
    struct dpsw_acl_key key = { 0 };
	uint64_t ext_params[DPSW_CMD_EXTRACT_EXT_PARAMS] = { 0 };
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_ACL_ADD_ENTRY(cmd_data, acl_id, cfg);

	/* Read from DMA */
	err = dpmng_dev_memcpy(dev, ext_params, cfg->key_iova,
			DPSW_CMD_EXTRACT_EXT_PARAMS * sizeof(uint64_t),
			1);
	CHECK_COND_RETVAL(err == 0, err, "Error reading extended DMA parameters\n");

	/* Read extension */
	cfg->key = &key;
	DPSW_EXT_ACL_ENTRY(ext_params, cfg->key);

	return dpsw_acl_add_entry(dpsw, acl_id, cfg);
}

static int acl_remove_entry(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
    uint16_t acl_id;
    struct dpsw_acl_entry_cfg acl_entry_cfg = { 0 };
    struct dpsw_acl_entry_cfg *cfg = &acl_entry_cfg;
	uint64_t ext_params[DPSW_CMD_EXTRACT_EXT_PARAMS] = { 0 };
    struct dpsw_acl_key key = { 0 };
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_ACL_REMOVE_ENTRY(cmd_data, acl_id, cfg);

	/* Read from DMA */
	err = dpmng_dev_memcpy(dev, ext_params, cfg->key_iova,
			DPSW_CMD_EXTRACT_EXT_PARAMS * sizeof(uint64_t),
			1);
	CHECK_COND_RETVAL(err == 0, err, "Error reading extended DMA parameters\n");

	/* Read extention */
	cfg->key = &key;
	DPSW_EXT_ACL_ENTRY(ext_params, cfg->key);

	return dpsw_acl_remove_entry(dpsw, acl_id, cfg);
}

static int acl_add_if(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
    uint16_t acl_id;
    struct dpsw_acl_if_cfg acl_if_cfg = { 0 };
    struct dpsw_acl_if_cfg *cfg = &acl_if_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_ACL_ADD_IF(cmd_data, acl_id, cfg);
	read_if_id_bitmap(cfg->if_id, &(cfg->num_ifs), cmd_data, 1);

	return dpsw_acl_add_if(dpsw, acl_id, cfg);
}

static int acl_remove_if(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t acl_id;
	struct dpsw_acl_if_cfg acl_if_cfg = { 0 };
	struct dpsw_acl_if_cfg *cfg = &acl_if_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_ACL_REMOVE_IF(cmd_data, acl_id, cfg);
	read_if_id_bitmap(cfg->if_id, &(cfg->num_ifs), cmd_data, 1);

	return dpsw_acl_remove_if(dpsw, acl_id, cfg);
}

static int acl_get_attr(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint16_t acl_id;
	struct dpsw_acl_attr acl_attr = { 0 };
	struct dpsw_acl_attr *attr = &acl_attr;
	int err;
	
	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_ACL_GET_ATTR(cmd_data, acl_id);

	err = dpsw_acl_get_attributes(dpsw, acl_id, attr);
	CHECK_COND_RETVAL(err == 0, err);
	
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSW_RSP_ACL_GET_ATTR(cmd_data, attr);
	
	return err;
}

static int ctrl_if_get_attr(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_ctrl_if_attr ctrl_if_attr = { 0 };
	struct dpsw_ctrl_if_attr *attr = &ctrl_if_attr;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	err = dpsw_ctrl_if_get_attributes(dpsw, attr);
	CHECK_COND_RETVAL(err == 0, err);
	
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSW_RSP_CTRL_IF_GET_ATTR(cmd_data, attr);
	
	return err;
}

static int ctrl_if_set_pools(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_ctrl_if_pools_cfg pools_cfg = { 0 };
	struct dpsw_ctrl_if_pools_cfg *cfg = &pools_cfg;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_CTRL_IF_SET_POOLS(cmd_data, cfg);
	
	return dpsw_ctrl_if_set_pools(dpsw, cfg);
}

static int ctrl_if_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);
	
	return dpsw_ctrl_if_enable(dpsw);
}

static int ctrl_if_disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);
	
	return dpsw_ctrl_if_disable(dpsw);
}

static int ctrl_if_set_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw_ctrl_if_queue_cfg rx_cfg = { 0 };
	struct dpsw_ctrl_if_queue_cfg *cfg = &rx_cfg;
	struct dpsw *dpsw;
	enum dpsw_queue_type qtype;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_CTRL_IF_SET_QUEUE(cmd_data, qtype, cfg);

	return dpsw_ctrl_if_set_queue(dpsw, qtype, cfg);
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
        uint8_t irq_index;
        struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

    	dpsw = device_get_priv(dev);
    	CHECK_COND_RETVAL(dpsw, -ENODEV);

    	DPSW_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

        return dpsw_set_irq(dpsw, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpsw *dpsw;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	return dpsw_set_irq(dpsw, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpsw_get_irq(dpsw, irq_index, irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSW_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpsw *dpsw;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	err = dpsw_get_irq(dpsw, (uint8_t)irq_index, irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint8_t irq_index;
	uint8_t en;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, en);

	return dpsw_set_irq_enable(dpsw, irq_index, en);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint8_t irq_index;
	uint8_t en;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpsw_get_irq_enable(dpsw, irq_index, &en);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSW_RSP_GET_IRQ_ENABLE(cmd_data, en);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint8_t irq_index;
	uint32_t mask;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpsw_set_irq_mask(dpsw, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpsw_get_irq_mask(dpsw, irq_index, &mask);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSW_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpsw_get_irq_status(dpsw, irq_index, &status);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSW_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	uint8_t irq_index;
	uint32_t status;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	/* Read parameters from portal */
	DPSW_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpsw_clear_irq_status(dpsw, irq_index, status);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPSW_VER_MAJOR;
    uint32_t minor = DPSW_VER_MINOR;

    DPSW_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int dpsw_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpsw_open on DPSW %d\n", device_get_id(dev));
	return 0;
}

static int dpsw_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpsw_close on DPSW %d[%d]\n", device_get_id(dev));
	return 0;
}

static int if_get_port_mac_addr(struct device *dev, struct mc_cmd_data *cmd_data)
{
	uint8_t mac_addr[6];
	struct dpsw *dpsw;
	uint16_t if_id;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_GET_PORT_MAC_ADDR(cmd_data, if_id);

	err = dpsw_if_get_port_mac_addr(dpsw, if_id, mac_addr);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_IF_GET_PORT_MAC_ADDR(cmd_data, mac_addr);
	}

	return err;
}

static int if_set_taildrop(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw_taildrop_cfg cfg;
	struct dpsw *dpsw;
	uint16_t if_id;
	uint8_t tc_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_SET_TAILDROP(cmd_data, if_id, tc_id, (&cfg));

	return dpsw_if_set_taildrop(dpsw, if_id, tc_id, &cfg);
}

static int if_get_taildrop(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_taildrop_cfg cfg;
	uint16_t if_id;
	uint8_t tc_id;
	int err = 0;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_GET_TAILDROP(cmd_data, if_id, tc_id);

	err = dpsw_if_get_taildrop(dpsw, if_id, tc_id, &cfg);
	if( !err ) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPSW_RSP_IF_GET_TAILDROP(cmd_data, (&cfg));
	}

	return err;
}

static int table_dump(struct device *dev, struct mc_cmd_data *cmd_data)
{
	uint16_t table_type, table_index;
	uint64_t snapshot_iova;
	uint32_t iova_size;
	uint16_t table_size = 0;
	int err;

	DPSW_CMD_DUMP_TABLE(cmd_data, table_type, table_index, snapshot_iova, iova_size);

	err = dpsw_table_dump(dev, table_type, table_index, snapshot_iova, (int)iova_size, &table_size);
	CHECK_COND_RETVAL(err==0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPSW_RSP_DUMP_TABLE(cmd_data, table_size);

	return 0;
}

static int if_set_errors_behavior(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw *dpsw;
	struct dpsw_error_cfg error_cfg = { 0 };
	struct dpsw_error_cfg *cfg = &error_cfg;
	uint16_t if_id;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_SET_ERRORS_BEHAVIOR(cmd_data, if_id, cfg);

	return dpsw_if_set_errors_behavior(dpsw, if_id, cfg);
}

static int set_egress_flood(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpsw_egress_flood_cfg flood_cfg = {0};
	struct dpsw_egress_flood_cfg *cfg = &flood_cfg;
	int err;

	DPSW_CMD_SET_EGRESS_FLOOD(cmd_data, cfg);
	read_if_id_bitmap(cfg->if_id, &cfg->num_ifs, cmd_data, 1);

	err = dpsw_set_egress_flood(dev, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int if_set_learning_mode(struct device *dev, struct mc_cmd_data *cmd_data)
{
	enum dpsw_learning_mode mode;
	struct dpsw *dpsw;
	uint16_t if_id;
	int err;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	DPSW_CMD_IF_SET_LEARNING_MODE(cmd_data, if_id, mode);

	err = dpsw_if_set_learning_mode(dpsw, if_id, mode);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int dpsw_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev, struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */                
	} map_commands[] = {
			{ DPSW_CMD_CODE_CREATE, init_v1, "dpsw_init", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_CREATE, init_v2, "dpsw_init", DPSW_CMD_V2 },
			{ DPSW_CMD_CODE_GET_ATTR, get_attributes_v0, "dpsw_get_attributes", DPSW_CMD_V0 },
			{ DPSW_CMD_CODE_DESTROY, destroy, "dpsw_destroy", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_ENABLE, enable, "dpsw_enable", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_DISABLE, disable, "dpsw_disable", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_RESET, reset, "dpsw_reset", DPSW_CMD_VER_BASE },
#if 0 //removed unsupported functions
			{ DPSW_CMD_CODE_SET_POLICER, set_policer, "dpsw_policer", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_SET_BUFFER_DEPLETION, set_buffer_depletion, "dpsw_set_buffer_depletion", DPSW_CMD_VER_BASE },
#endif
			{ DPSW_CMD_CODE_SET_REFLECTION_IF, set_reflection_if, "dpsw_set_reflection_if", DPSW_CMD_VER_BASE },
			/*{ DPSW_CMD_CODE_SET_PARSER_ERROR_ACTION, set_parser_error_action, "dpsw_set_parser_error_action", DPSW_CMD_VER_BASE },*/
			{ DPSW_CMD_CODE_IS_ENABLED, is_enabled, "dpsw_is_enabled", DPSW_CMD_VER_BASE },
#if 0 //removed unsupported functions
			{ DPSW_CMD_CODE_SET_PTP_V2, set_ptp_v2, "dpsw_set_ptp_v2", DPSW_CMD_VER_BASE },
#endif
			{ DPSW_CMD_CODE_IF_SET_TCI, if_set_tci, "dpsw_if_set_tci", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_GET_TCI, if_get_tci, "dpsw_if_get_tci", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_STP, if_set_stp, "dpsw_if_set_stp", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_ACCEPTED_FRAMES, if_set_accepted_frames, "dpsw_if_set_accepted_frames", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_SET_IF_ACCEPT_ALL_VLAN, set_if_accept_all_vlan, "dpsw_set_if_accept_all_vlan", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_GET_COUNTER, if_get_counter_v1, "dpsw_if_get_counter", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_COUNTER, if_set_counter_v1, "dpsw_if_set_counter", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_TX_SELECTION, if_set_tx_selection_v1, "dpsw_if_set_tx_selection", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_ADD_REFLECTION, if_add_reflection, "dpsw_if_add_reflection", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_REMOVE_REFLECTION, if_remove_reflection, "dpsw_if_remove_reflection", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_FLOODING_METERING, if_set_flooding_metering, "dpsw_if_set_flooding_metering", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_METERING, if_set_metering, "dpsw_if_set_metering", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_EARLY_DROP, if_set_early_drop, "dpsw_if_set_early_drop", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_ADD_CUSTOM_TPID, add_custom_tpid, "dpsw_add_custom_tpid", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_REMOVE_CUSTOM_TPID, remove_custom_tpid, "dpsw_remove_custom_tpid", DPSW_CMD_VER_BASE },
#if 0 //removed unsupported functions
			{ DPSW_CMD_CODE_IF_SET_TRANSMIT_RATE, if_set_transmit_rate, "dpsw_if_set_transmit_rate", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_TC_SET_BW, if_tc_set_bandwidth, "dpsw_if_tc_set_bandwidth", DPSW_CMD_VER_BASE },
#endif
			{ DPSW_CMD_CODE_IF_ENABLE, if_enable, "dpsw_if_enable", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_DISABLE, if_disable, "dpsw_if_disable", DPSW_CMD_VER_BASE },
#if 0 //removed unsupported functions
			{ DPSW_CMD_CODE_IF_TC_SET_Q_CONGESTION, if_tc_set_queue_congestion, "dpsw_if_tc_set_queue_congestion", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_TC_SET_PFC, if_tc_set_pfc, "dpsw_if_tc_set_pfc", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_TC_SET_CN, if_tc_set_cn, "dpsw_if_tc_set_cn", DPSW_CMD_VER_BASE },
#endif
			{ DPSW_CMD_CODE_IF_GET_ATTR, if_get_attributes, "dpsw_if_get_attributes", DPSW_CMD_VER_BASE },
#if 0
			{ DPSW_CMD_CODE_IF_SET_MACSEC, if_set_macsec, "dpsw_if_set_macsec", DPSW_CMD_VER_BASE },
#endif
			{ DPSW_CMD_CODE_IF_SET_MAX_FRAME_LENGTH, if_set_max_frame_length, "dpsw_if_set_max_frame_length", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_ADD, vlan_add, "dpsw_vlan_add", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_ADD_IF, vlan_add_if, "dpsw_vlan_add_if", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_ADD_IF_UNTAGGED, vlan_add_if_untagged, "dpsw_vlan_add_if_untagged", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_ADD_IF_FLOODING, vlan_add_if_flooding, "dpsw_vlan_add_if_flooding", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_REMOVE_IF , vlan_remove_if, "dpsw_vlan_remove_if", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_REMOVE_IF_UNTAGGED, vlan_remove_if_untagged, "dpsw_vlan_remove_if_untagged", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_REMOVE_IF_FLOODING, vlan_remove_if_flooding, "dpsw_vlan_remove_if_flooding", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_REMOVE, vlan_remove, "dpsw_vlan_remove", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_FDB_ADD, fdb_add, "dpsw_fdb_add", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_FDB_REMOVE, fdb_remove, "dpsw_fdb_remove", DPSW_CMD_VER_BASE }, { DPSW_CMD_CODE_FDB_ADD_UNICAST, fdb_add_unicast, "dpsw_fdb_add_unicast", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_FDB_REMOVE_UNICAST, fdb_remove_unicast, "dpsw_fdb_remove_unicast", DPSW_CMD_VER_BASE }, 
			{ DPSW_CMD_CODE_FDB_ADD_MULTICAST, fdb_add_multicast, "dpsw_fdb_add_multicast", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_FDB_REMOVE_MULTICAST, fdb_remove_multicast, "dpsw_fdb_remove_multicast", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_FDB_SET_LEARNING_MODE, fdb_set_learning_mode, "dpsw_fdb_set_learning_mode", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_FDB_GET_ATTR, fdb_get_attributes, "dpsw_fdb_get_attributes", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_GET_MAX_FRAME_LENGTH, if_get_max_frame_length, "dpsw_if_get_max_frame_length", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_GET_LINK_STATE, if_get_link_state_v1, "dpsw_if_get_link_state", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_LINK_CFG, if_set_link_cfg_v1, "dpsw_if_set_link_cfg", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_FDB_GET_MULTICAST, fdb_get_multicast, "dpsw_fdb_get_multicast", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_FDB_GET_UNICAST, fdb_get_unicast, "dpsw_fdb_get_unicast", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_GET_IF, vlan_get_if, "dpsw_vlan_get_if", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_GET_IF_FLOODING, vlan_get_if_flooding, "dpsw_vlan_get_if_flooding", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_GET_IF_UNTAGGED, vlan_get_if_untagged, "dpsw_vlan_get_if_untagged", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_VLAN_GET_ATTRIBUTES, vlan_get_attributes, "dpsw_vlan_get_attributes", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_FLOODING, if_set_flooding, "dpsw_if_set_flooding", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_BROADCAST, if_set_broadcast, "dpsw_if_set_broadcast", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_MULTICAST, if_set_multicast, "dpsw_if_set_multicast", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_ACL_ADD, acl_add, "dpsw_acl_add", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_ACL_REMOVE, acl_remove, "dpsw_acl_remove", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_ACL_ADD_ENTRY, acl_add_entry, "dpsw_acl_add_entry", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_ACL_REMOVE_ENTRY, acl_remove_entry, "dpsw_acl_remove_entry", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_ACL_ADD_IF, acl_add_if, "dpsw_acl_add_if", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_ACL_REMOVE_IF, acl_remove_if, "dpsw_acl_remove_if", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_ACL_GET_ATTR, acl_get_attr, "dpsw_acl_get_attr", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_CTRL_IF_GET_ATTR, ctrl_if_get_attr, "dpsw_ctrl_if_get_attr", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_CTRL_IF_SET_POOLS, ctrl_if_set_pools, "dpsw_ctrl_if_set_pools", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_CTRL_IF_ENABLE, ctrl_if_enable, "dpsw_ctrl_if_enable", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_CTRL_IF_DISABLE, ctrl_if_disable, "dpsw_ctrl_if_disable", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_SET_IRQ, set_irq, "dpsw_set_irq", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_GET_IRQ, get_irq, "dpsw_get_irq", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpsw_set_irq_enable", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpsw_get_irq_enable", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpsw_set_irq_mask", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpsw_get_irq_mask", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpsw_get_irq_status", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpsw_clear_irq_status", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_GET_PORT_MAC_ADDR, if_get_port_mac_addr, "dpsw_if_get_port_mac_addr", DPSW_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPSW_CMD_CODE_GET_API_VERSION, get_api_version, "dpsw_get_api_version", DPSW_CMD_V1 },
			{ DPSW_CMD_CODE_GET_ATTR, get_attributes_v1, "dpsw_get_attributes", DPSW_CMD_V1 },
			{ DPSW_CMD_CODE_FDB_DUMP, fdb_dump, "dpsw_fdb_dump", DPSW_CMD_V1 },
			{ DPSW_CMD_CODE_SET_LAG, lag_set , "dpsw_lag_set", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_GET_LAG, lag_get, "dpsw_lag_get", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_GET_LINK_STATE, if_get_link_state_v2, "dpsw_if_get_link_state", DPSW_CMD_V2 },
			{ DPSW_CMD_CODE_IF_SET_LINK_CFG, if_set_link_cfg_v2, "dpsw_if_set_link_cfg", DPSW_CMD_V2 },
			{ DPSW_CMD_CODE_CTRL_IF_SET_QUEUE, ctrl_if_set_queue, "dpsw_ctrl_if_set_queue", DPSW_CMD_V1 },
			{ DPSW_CMD_CODE_IF_GET_COUNTER, if_get_counter_v2, "dpsw_if_get_counter", DPSW_CMD_V2 },
			{ DPSW_CMD_CODE_IF_SET_COUNTER, if_set_counter_v2, "dpsw_if_set_counter", DPSW_CMD_V2 },
			{ DPSW_CMD_CODE_IF_SET_TAILDROP, if_set_taildrop, "dpsw_if_set_taildrop", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_GET_TAILDROP, if_get_taildrop, "dpsw_if_get_taildrop", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_TABLE_DUMP, table_dump, "dpsw_dump_table", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_IF_SET_ERRORS_BEHAVIOR, if_set_errors_behavior, "dpsw_if_set_errors_behavior", DPSW_CMD_VER_BASE },
			{ DPSW_CMD_CODE_CREATE, init_v3, "dpsw_init", DPSW_CMD_V3 },
			{ DPSW_CMD_CODE_VLAN_ADD_IF, vlan_add_if_v2, "dpsw_vlan_add_if", DPSW_CMD_V2 },
			{ DPSW_CMD_CODE_SET_EGRESS_FLOOD, set_egress_flood, "dpsw_set_egress_flood", DPSW_CMD_V1 },
			{ DPSW_CMD_CODE_GET_ATTR, get_attributes_v2, "dpsw_get_attributes", DPSW_CMD_V2 },
			{ DPSW_CMD_CODE_IF_SET_LEARNING_MODE, if_set_learning_mode, "dpsw_if_set_learning_mode", DPSW_CMD_V1},
			{ DPSW_CMD_CODE_IF_SET_TX_SELECTION, if_set_tx_selection_v2, "dpsw_if_set_tx_selection", DPSW_CMD_V2 },
			{ DPSW_CMD_CODE_IF_SET_PRIO_SELECTOR, if_set_prio_selector, "dpsw_if_set_prio_selector", DPSW_CMD_VER_BASE },
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))){
			if (cmd == DPSW_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPSW %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev, cmd_data);
		}
	pr_err("Invalid command %d\n",cmd);
	return -ENOTSUP;
}

static uint64_t get_options(void *lo, int node_off)
{
	char *opt_str;
	int total_len;
	int len;
	int i = 0;
	uint64_t options = 0;
	struct {
		char *opt_str;
		uint64_t options;
	} map[] = {
	                    { "DPSW_OPT_FLOODING_DIS", DPSW_OPT_FLOODING_DIS },
	                    { "DPSW_OPT_CTRL_IF_DIS", DPSW_OPT_CTRL_IF_DIS },
	                     { "DPSW_OPT_MULTICAST_DIS", DPSW_OPT_MULTICAST_DIS },
	                     { "DPSW_OPT_FLOODING_METERING_DIS", DPSW_OPT_FLOODING_METERING_DIS },
	                     { "DPSW_OPT_METERING_EN", DPSW_OPT_METERING_EN },
	                     { "DPSW_OPT_BP_PER_IF", DPSW_OPT_BP_PER_IF },
	                    { "DPSW_OPT_LAG_DIS", DPSW_OPT_LAG_DIS }
	};

	opt_str = (char *)fdt_getprop(lo, node_off, "options", &total_len);

	if (opt_str && (int)(*opt_str) != 0 ) {
		while (total_len > 0){
			while (i < (ARRAY_SIZE(map) - 1) && strcmp(opt_str,map[i].opt_str))
				i++;
			if (!strcmp(opt_str,map[i].opt_str))
				options |= map[i].options;
			len = (int)strlen(opt_str) + 1;
			total_len -= len;
			opt_str = PTR_MOVE(opt_str, len );
			i=0;
		}
	}

	return options;
}

static enum dpsw_flooding_cfg get_flooding_cfg(void *lo, int node_off)
{
	struct {
		char *str;
		enum dpsw_flooding_cfg cfg;
	} map[] = {
		{ "DPSW_FLOODING_PER_VLAN", DPSW_FLOODING_PER_VLAN },
		{ "DPSW_FLOODING_PER_FDB", DPSW_FLOODING_PER_FDB}
	};
	char *flooding_cfg_str;
	int len, i;

	flooding_cfg_str = (char *)fdt_getprop(lo, node_off, "flooding_cfg", &len);
	if (!flooding_cfg_str)
		goto default_flooding_cfg;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (strcmp(map[i].str, flooding_cfg_str) == 0)
			return map[i].cfg;
	}

default_flooding_cfg:
	return DPSW_FLOODING_PER_VLAN;
}

static enum dpsw_broadcast_cfg get_broadcast_cfg(void *lo, int node_off)
{
	struct {
		char *str;
		enum dpsw_broadcast_cfg cfg;
	} map[] = {
		{ "DPSW_BROADCAST_PER_OBJECT", DPSW_BROADCAST_PER_OBJECT },
		{ "DPSW_BROADCAST_PER_FDB", DPSW_BROADCAST_PER_FDB}
	};
	char *broadcast_cfg_str;
	int len, i;

	broadcast_cfg_str = (char *)fdt_getprop(lo, node_off, "broadcast_cfg", &len);
	if (!broadcast_cfg_str)
		goto default_broadcast_cfg;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (strcmp(map[i].str, broadcast_cfg_str) == 0)
			return map[i].cfg;
	}

default_broadcast_cfg:
	return DPSW_BROADCAST_PER_OBJECT;
}

static enum dpsw_component_type get_component_type_cfg(void *lo, int node_off)
{
	struct {
		char *str;
		enum dpsw_component_type cfg;
	} map[] = {
		{ "DPSW_COMPONENT_TYPE_C_VLAN", DPSW_COMPONENT_TYPE_C_VLAN },
		{ "DPSW_COMPONENT_TYPE_S_VLAN", DPSW_COMPONENT_TYPE_S_VLAN }
	};
	char *flooding_cfg_str;
	int len, i;

	flooding_cfg_str = (char *)fdt_getprop(lo, node_off, "component_type", &len);
	if (!flooding_cfg_str)
		goto default_flooding_cfg;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (strcmp(map[i].str, flooding_cfg_str) == 0)
			return map[i].cfg;
	}

default_flooding_cfg:
	return DPSW_COMPONENT_TYPE_C_VLAN;
}

static int getprop_lag(void *lo, int node_off, uint8_t lag_index, uint8_t *lag_cfg)
{
	char lag_str[STR_MAX_SIZE] = { 0 };
	uint32_t val;
	int i,err;

	*lag_cfg = 0;
	snprintf(lag_str,sizeof(lag_str),"lag%d",lag_index);

	for (i=0;i<DPSW_MAX_LAG;i++)
	{
		err = getprop_array(lo, node_off, lag_str, i, &val);
		CHECK_COND_RETVAL(err == 0,err);

		if ((*lag_cfg>0)&&(val==0))
			break;

		*lag_cfg|=( 1 << val);
	}

	return 0;
}

static int dpsw_probe_cb(void *lo, int node_off)
{
//	int i = 0;
	int err = 0;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	struct dpsw_cfg dpsw_cfg = { 0 };
	struct dpsw_cfg *cfg = &dpsw_cfg;
//	int subnode_off;
	int id;
	uint64_t val;
	int destroy = 0;
	uint8_t i;

	/* get dpsw ID */
	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	/* DPSW cfg */
	dpsw_cfg.adv.options = get_options(lo, node_off);
	getprop_val(lo, node_off, "max_vlans", 0, 0, &val);
	dpsw_cfg.adv.max_vlans = (uint16_t)val;
	getprop_val(lo, node_off, "max_fdbs", 0, 0, &val);
	dpsw_cfg.adv.max_fdbs = (uint8_t)val;
	getprop_val(lo, node_off, "num_fdb_entries", 0, 0, &val);
	dpsw_cfg.adv.max_fdb_entries = (uint16_t)val;
	getprop_val(lo, node_off, "fdb_aging_time", 0, 0, &val);
	dpsw_cfg.adv.fdb_aging_time = (uint16_t)val;
	getprop_val(lo, node_off, "max_fdb_mc_groups", 0, 0, &val);
	dpsw_cfg.adv.max_fdb_mc_groups = (uint16_t)val;
	getprop_val(lo, node_off, "max_meters_per_if", 0, 0, &val);
	dpsw_cfg.adv.max_meters_per_if = (uint8_t)val;
	getprop_val(lo, node_off, "mem_size", 0, 0, &val);
	dpsw_cfg.adv.mem_size = (uint16_t)val;
	getprop_val(lo, node_off, "component_type", 0, 0, &val);
	dpsw_cfg.adv.component_type = get_component_type_cfg(lo, node_off);
	
	if(getprop_val(lo, node_off, "num_ifs", 0, 0, &val)){
		pr_err("'num_ifs' is a required field for layout dpsw\n");
		return -EINVAL;
	}
	dpsw_cfg.num_ifs = (uint16_t)val;

	dpsw_cfg.adv.flooding_cfg = get_flooding_cfg(lo, node_off);
	dpsw_cfg.adv.broadcast_cfg = get_broadcast_cfg(lo, node_off);

	for (i=0;i<DPSW_MAX_LAG;i++)
	{
		err = getprop_lag(lo, node_off,i+1,&dpsw_cfg.adv.lag[i]);
		if (err != 0)
			break;
	}

#if 0 //removed if_cfg
	i = 0;
	subnode_off = fdt_first_subnode(lo, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND)
	{
		dpsw_cfg.if_cfg[i].num_tcs = (uint8_t)getprop_val(lo, subnode_off,
		                                                     "num_tcs");
		dpsw_cfg.if_cfg[i].options = get_options(lo, subnode_off);
		dpsw_cfg.if_cfg[i].iop_id = (int)getprop_val(lo, subnode_off,"iop_id");

		i++;
		subnode_off = fdt_next_subnode(lo, subnode_off);
	}
#endif

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV, "Can't find resman\n");
	/* create & open resman device */
	dev = resman_open_dev(resman, "dpsw", (uint16_t)id,
							NO_PORTAL_ID, DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPSW %.4x\n",id);

	DPSW_LO_CREATE_V3(cmd_data, cfg);
	/* create object */
	err = dpsw_ctrl_cb(dev, DPSW_CMD_V3, DPSW_CMD_CODE_CREATE,
	                    NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpsw", NO_PORTAL_ID, destroy);

	return err;
}

static int dpsw_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	err = get_node_id(lo, node_off, &id);
	CHECK_COND_RETVAL(err == 0, err);

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV, "Can't find resman\n");

	dev = resman_open_dev(
	        resman, "dpsw",
	        (uint16_t)id,
	        NO_PORTAL_ID, 0, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't open DPSW %.4x\n",id);

	err |= dpsw_ctrl_cb(dev, DPSW_CMD_VER_BASE, DPSW_CMD_CODE_DESTROY, NO_PORTAL_ID, NULL);
	err |= resman_close_dev(resman, dev, "dpsw", NO_PORTAL_ID, 0);
	return err;
}

static char *dpsw_match[] = { "fsl,dpsw", "dpsw" };

int dpsw_drv_init(void)
{
	int err = 0;
	t_sys_dtc_mod_params dtc_params= { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	struct linkman *linkman;

	pr_info("Executing dpsw_drv_init...\n");
	
	/*! Register layout */
	dtc_params.num_compats = ARRAY_SIZE(dpsw_match);
	dtc_params.compatibles = dpsw_match;
	dtc_params.f_prob_module = dpsw_probe_cb;
	dtc_params.f_remove_module = dpsw_remove_cb;
	err = sys_dtc_register_module(&dtc_params);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Register command interface */
	cmdif_ops.open_cb = dpsw_open_cb;
	cmdif_ops.close_cb = dpsw_close_cb;
	cmdif_ops.ctrl_cb = dpsw_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	err = cmdif_register_module(CMDIF_MOD_DPSW, &cmdif_ops);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Register resman */
	strcpy(dev_type_param.device_type, "dpsw");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPSW_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPSW_VER_MAJOR;
	dev_type_param.ver_minor = DPSW_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	err = resman_register_device_operation(resman, "dpsw", &dev_type_param);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Register link manager */
	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	CHECK_COND_RETVAL(linkman, -ENODEV);
	err = linkman_register_cb(linkman, 
	                          FSL_MOD_DPSW, 
	                          dpsw_event_cb,
	                          dpsw_event_complete_cb);

	return err;
}

