/*
 * Copyright 2013-2021 NXP
 */

#ifndef _DPSW_CMD_H
#define _DPSW_CMD_H

/* default version for all dpsw commands */
#define DPSW_CMD_VER_BASE								CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPSW_CMD_V0										CMDHDR_CMD_VERSION(0)
#define DPSW_CMD_V1										CMDHDR_CMD_VERSION(1)
#define DPSW_CMD_V2										CMDHDR_CMD_VERSION(2)
#define DPSW_CMD_V3										CMDHDR_CMD_VERSION(3)

/* Command IDs */
#define DPSW_CMD_CODE_CLOSE                                0x800
#define DPSW_CMD_CODE_OPEN                                 0x802
#define DPSW_CMD_CODE_CREATE                               0x902
#define DPSW_CMD_CODE_DESTROY                              0x900
#define DPSW_CMD_CODE_GET_API_VERSION                      0xa02

#define DPSW_CMD_CODE_ENABLE                               0x002
#define DPSW_CMD_CODE_DISABLE                              0x003
#define DPSW_CMD_CODE_GET_ATTR                             0x004
#define DPSW_CMD_CODE_RESET                                0x005
#define DPSW_CMD_CODE_IS_ENABLED                           0x006

#define DPSW_CMD_CODE_SET_IRQ                              0x010
#define DPSW_CMD_CODE_GET_IRQ                              0x011
#define DPSW_CMD_CODE_SET_IRQ_ENABLE                       0x012
#define DPSW_CMD_CODE_GET_IRQ_ENABLE                       0x013
#define DPSW_CMD_CODE_SET_IRQ_MASK                         0x014
#define DPSW_CMD_CODE_GET_IRQ_MASK                         0x015
#define DPSW_CMD_CODE_GET_IRQ_STATUS                       0x016
#define DPSW_CMD_CODE_CLEAR_IRQ_STATUS                     0x017

#define DPSW_CMD_CODE_SET_REFLECTION_IF                    0x022

#define DPSW_CMD_CODE_ADD_CUSTOM_TPID                      0x024

#define DPSW_CMD_CODE_REMOVE_CUSTOM_TPID                   0x026

#define DPSW_CMD_CODE_IF_SET_TCI                           0x030
#define DPSW_CMD_CODE_IF_SET_STP                           0x031
#define DPSW_CMD_CODE_IF_SET_ACCEPTED_FRAMES               0x032
#define DPSW_CMD_CODE_SET_IF_ACCEPT_ALL_VLAN               0x033
#define DPSW_CMD_CODE_IF_GET_COUNTER                       0x034
#define DPSW_CMD_CODE_IF_SET_COUNTER                       0x035
#define DPSW_CMD_CODE_IF_SET_TX_SELECTION                  0x036
#define DPSW_CMD_CODE_IF_ADD_REFLECTION                    0x037
#define DPSW_CMD_CODE_IF_REMOVE_REFLECTION                 0x038
#define DPSW_CMD_CODE_IF_SET_FLOODING_METERING             0x039
#define DPSW_CMD_CODE_IF_SET_METERING                      0x03A
#define DPSW_CMD_CODE_IF_SET_EARLY_DROP                    0x03B
#define DPSW_CMD_CODE_IF_SET_PRIO_SELECTOR				   0x03C
#define DPSW_CMD_CODE_IF_ENABLE                            0x03D
#define DPSW_CMD_CODE_IF_DISABLE                           0x03E

#define DPSW_CMD_CODE_IF_GET_ATTR                          0x042

#define DPSW_CMD_CODE_IF_SET_MAX_FRAME_LENGTH              0x044
#define DPSW_CMD_CODE_IF_GET_MAX_FRAME_LENGTH              0x045
#define DPSW_CMD_CODE_IF_GET_LINK_STATE                    0x046
#define DPSW_CMD_CODE_IF_SET_FLOODING                      0x047
#define DPSW_CMD_CODE_IF_SET_BROADCAST                     0x048
#define DPSW_CMD_CODE_IF_SET_MULTICAST                     0x049
#define DPSW_CMD_CODE_IF_GET_TCI                           0x04A

#define DPSW_CMD_CODE_IF_SET_LINK_CFG                      0x04C

#define DPSW_CMD_CODE_VLAN_ADD                             0x060
#define DPSW_CMD_CODE_VLAN_ADD_IF                          0x061
#define DPSW_CMD_CODE_VLAN_ADD_IF_UNTAGGED                 0x062
#define DPSW_CMD_CODE_VLAN_ADD_IF_FLOODING                 0x063
#define DPSW_CMD_CODE_VLAN_REMOVE_IF                       0x064
#define DPSW_CMD_CODE_VLAN_REMOVE_IF_UNTAGGED              0x065
#define DPSW_CMD_CODE_VLAN_REMOVE_IF_FLOODING              0x066
#define DPSW_CMD_CODE_VLAN_REMOVE                          0x067
#define DPSW_CMD_CODE_VLAN_GET_IF                          0x068
#define DPSW_CMD_CODE_VLAN_GET_IF_FLOODING                 0x069
#define DPSW_CMD_CODE_VLAN_GET_IF_UNTAGGED                 0x06A
#define DPSW_CMD_CODE_VLAN_GET_ATTRIBUTES                  0x06B

#define DPSW_CMD_CODE_FDB_GET_MULTICAST                    0x080
#define DPSW_CMD_CODE_FDB_GET_UNICAST                      0x081
#define DPSW_CMD_CODE_FDB_ADD                              0x082
#define DPSW_CMD_CODE_FDB_REMOVE                           0x083
#define DPSW_CMD_CODE_FDB_ADD_UNICAST                      0x084
#define DPSW_CMD_CODE_FDB_REMOVE_UNICAST                   0x085
#define DPSW_CMD_CODE_FDB_ADD_MULTICAST                    0x086
#define DPSW_CMD_CODE_FDB_REMOVE_MULTICAST                 0x087
#define DPSW_CMD_CODE_FDB_SET_LEARNING_MODE                0x088
#define DPSW_CMD_CODE_FDB_GET_ATTR                         0x089
#define DPSW_CMD_CODE_FDB_DUMP                             0x08A

#define DPSW_CMD_CODE_ACL_ADD                              0x090
#define DPSW_CMD_CODE_ACL_REMOVE                           0x091
#define DPSW_CMD_CODE_ACL_ADD_ENTRY                        0x092
#define DPSW_CMD_CODE_ACL_REMOVE_ENTRY                     0x093
#define DPSW_CMD_CODE_ACL_ADD_IF                           0x094
#define DPSW_CMD_CODE_ACL_REMOVE_IF                        0x095
#define DPSW_CMD_CODE_ACL_GET_ATTR                         0x096

#define DPSW_CMD_CODE_CTRL_IF_GET_ATTR                     0x0A0
#define DPSW_CMD_CODE_CTRL_IF_SET_POOLS                    0x0A1
#define DPSW_CMD_CODE_CTRL_IF_ENABLE                       0x0A2
#define DPSW_CMD_CODE_CTRL_IF_DISABLE                      0x0A3
#define DPSW_CMD_CODE_SET_LAG							   0x0A4
#define DPSW_CMD_CODE_GET_LAG							   0x0A5
#define DPSW_CMD_CODE_CTRL_IF_SET_QUEUE                    0x0A6

#define DPSW_CMD_CODE_IF_GET_PORT_MAC_ADDR                 0x0A7

#define DPSW_CMD_CODE_IF_SET_TAILDROP                      0x0A8
#define DPSW_CMD_CODE_IF_GET_TAILDROP                      0x0A9

#define DPSW_CMD_CODE_TABLE_DUMP                           0x0AA
#define DPSW_CMD_CODE_IF_SET_ERRORS_BEHAVIOR               0x0AB

#define DPSW_CMD_CODE_SET_EGRESS_FLOOD                     0x0AC
#define DPSW_CMD_CODE_IF_SET_LEARNING_MODE                 0x0AD

#endif /* _DPSW_CMD_H */
