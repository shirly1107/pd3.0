/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
@File          	dpsw.h

@Description   	DPSW library implementation
		It contains:
		-# internal L2 switch database
		-# Internal L2 switch pound defines
		-# Internal L2 switch MACROs

@Cautions      	None.
*//***************************************************************************/

#ifndef _DPSW_H
#define _DPSW_H

/* STL (Standard Template Library )*/
#include "common/fsl_string.h"			/* memcpy */
#include "fsl_errors.h"				/* errors */
/* Operating System */
#include "fsl_platform.h"				/* sys_get_handle */
/* QMan & BMan */
#include "drivers/fsl_qbman_portal.h"		/* BMan */
#include "drivers/fsl_qbman_portal_ex.h"	/* CEETM */
#include "fsl_qbman.h"				/* qbman_desc */
/* WRIOP */
#include "fsl_eiop_ifp.h"			/* IFP */
#include "fsl_eiop.h"				/* Dequeue Context */
/* Services */
#include "fsl_resman.h"				/* Resource Manager */
#include "fsl_linkman.h"			/* Link Manager */
#include "fsl_dpmng_mc.h"			/* get SWP */
/* System API */
#include "fsl_sys.h"			/* sys_get_handle */

#include "fsl_dpparser.h"
#include "fsl_dppolicy.h"
#include "fsl_dpkg.h"
#include "fsl_dptbl.h"
#include "fsl_dptbl_l2switch.h"        		/* FDB, VLAN */
#include "fsl_event_pipe.h"
#include "fsl_qbman.h"				/* qbman_desc */
#include "fsl_ctlu.h"
#include "fsl_dpqos.h"

#include "fsl_types.h"
#include "fsl_replic.h"
#include "fsl_hmap.h"
/* L2 switch API */
#include "fsl_dpsw_mc.h"		/* Internal (DPSW) API */
#include "fsl_dpmac_mc.h"		/* Internal (DPMAC) API */
#include "fsl_ctrl_if.h"
#include "fsl_ceetm_if.h"		/* ceetm interface */

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPSW
/**************************************************************************//**
@Collection    L2 Switch MACROS

@{
 *//***************************************************************************/

/**************************************************************************//**
@Collection    L2 Switch/D-Mux defines

@{
 *//***************************************************************************/
#define DPSW_MAX_QPRI (DPSW_MAX_PRIORITIES + 1)

#define DPSW_MAX_VLAN           32      /* Maximum number of VLAN's */
#define DPSW_MAX_FDB            32      /* Maximum number of FDB */
#define DPSW_INVALID_FDB	0xFFFF
#define DPSW_MAX_FRAME_LENGTH	1536	/* Maximum Frame Length */

#define DPSW_BP_MEMORY_ALIGN	256		/*! alignment in bytes */
#define DPSW_BP_BUFFER_SIZE	256		/*! size of one buffer */
#define DPSW_BP_QUEUES_NO	8	/*! Number of queues */
#define DPSW_BP_FRAMES_PER_QUEUE	8	/*! Number of frames per queue */
#define DPSW_BP_NO			DPSW_MAX_IF	/*! L2 Switch number of buffer pools */
#define DPSW_BP_CHUNK		7
#define DPSW_CQID_BASE		8
#define DPSW_ACL_KEY_SIZE		56	/*! ACL key size */

/* Default Parameters */
#define DEFAULT_VLAN_ID		1	/* VLAN ID */
#define DEFAULT_DEI		0	/* DEI */
#define DEFAULT_PCP		7	/* PCP */
#define DEFAULT_MAX_VLAN	8	/* Max VLAN's */
#define DEFAULT_MAX_FDB		8	/* Max FDB's */
#define DEFAULT_NUM_FBD_ENTRIES	64	/* Number of FDB Entries */
#define DEFAULT_FDB_AGING_TIME	256	/* Aging time  */
#define DEFAULT_FDB_MC_GROUPS	8	/* Number of Multi-cast groups  */
#define DEFAULT_MAX_METERS	4	/* Number of meters per interface */
#define DEFAULT_BURST_DURATION  5	/* five milliseconds */

#define KBIT_PER_SECOND	1000UL
#define MBIT_PER_SECOND	(KBIT_PER_SECOND * KBIT_PER_SECOND)
#define GBIT_PER_SECOND	(KBIT_PER_SECOND * MBIT_PER_SECOND)
#define MS_IN_SECOND	1000UL

/* IRQ MACROS */
//#define DPSW_INDEX_IRQ_IF 	0

#define DPSW_REPLIC_CHID       	0xFF0
#define DPSW_ACL_VOID		(uint16_t)-1
#define SCHEDULER_UPPER_BOUND 	10000
#define SCHEDULER_LOWER_BOUND 	100

#define DPSW_DROPP_GREEN	0
#define DPSW_DROPP_YELLOW	1
#define DPSW_DROPP_RED		2

#define DPSW_ERRORS_TO_DISCARD		(EIOP_IFP_ERR_KS | 		\
					EIOP_IFP_ERR_MNL | 		\
					EIOP_IFP_ERR_TID | 		\
					EIOP_IFP_ERR_PIE | 		\
					EIOP_IFP_ERR_PARSER_CL| 	\
					EIOP_IFP_ERR_PARSER_ISF | 	\
					EIOP_IFP_ERR_PARSER_BL)

/**
 * @brief	L2 switch buffer pool descriptor
 *
 */
struct dpsw_buffer_pool_desc {
        enum memory_partition_id        memory_type;
        size_t                          memory_size;
        uint32_t                        buffer_size;
};

struct dpsw_id {
	int         inuse;      /*! in use flag */
	int         id;     	/*! ID */
};

struct dpsw_handle {
	struct dpparser    	*dpparser_ing;  /* Ingress Parser */
	struct dpparser     	*dpparser_egr;  /* Egress Parser */
	struct dppolicy_mng 	*dppolicy_ing;  /* Ingress FALU */
	struct dpkg     	*dpkg_ing;  	/* Ingress Key Generation */
	struct dpkg     	*dpkg_egr;  	/* Egress Key Generation */
	struct dptbl_mng    	*dptbl_ing; 	/* Ingress Tables */
	struct dpqos_mng 	*dpqos_ing;	/* QoS tables */
	struct linkman     	*linkman;   	/* Link manager 2.0 */
	struct dpmng        	*dpmng;     	/* General manager */
	struct device  		*dprc;      	/* Resource manager */
	struct dppolicer 	*dppolicer_ing; /* Policer */
};

struct dpsw_wq {
	int         	qdid;       		/*! QDID */
	int             qprid; 			/*! Queue pri record ID */
	int         	fqid;       		/*! Frame Queue ID */
};

/**************************************************************************//**
@Collection    Internal structures

@{
 *//***************************************************************************/
/**************************************************************************//**
@Description   Replication Record

*//***************************************************************************/
struct dpsw_quartet_rrid {
	int    root;
	int    mirr;
	int    swl;
	int    swl_mirr;
};

struct dpsw_replic {
	struct dpsw_quartet_rrid    	rrid;
	int				rrid_root_inuse;
	uint16_t		root_if_id;
	struct replic               	*replic;
	uint8_t 		if_list[DPSW_MAX_IF]; /* interface is already in flooding replicator for this vlan */
};

struct dpsw_irq {
        uint16_t        event;
        int             pending;
};

struct dpsw_metering {
	int plid;
};

/**************************************************************************//**
@Description   L2 Switch/D-Mux Interface internal structure

 *//***************************************************************************/

#define DPSW_LINKRES_CONNECTION_ALLOCATED	0x00000001ul
#define DPSW_LINKRES_AP_CONNECTED			0x00000002ul
#define DPSW_LINKRES_ALLOC_BW				0x00000004ul
#define DPSW_LINKRES_CHANNEL_ALLOCATED		0x00000008ul
#define DPSW_LINKRES_LFQ_ALLOCATED			0x00000010ul

struct dpsw_if {
	int				enabled;	/* Enable/Disable */

	/*! resources */
	struct dpsw_quartet_rrid	rrid;		/* RR Quartet*/
	struct dpmng_accesspoint	ap;		/* access-point */
	int		ap_valid;
	int 				conn_id;	/* connection id */
	uint16_t			acl_id;		/* ACL ID */
	int				flooding_plid;
		
        struct ceetm_if                 *ceetm_if;        
        enum dpsw_priority_selector     priority_selector; /* IEEE802.1Q/DSCP */

	/*! features */
	int 				accept_all_vlan;/* the device will
						discard/accept incoming frames
						for VLANs that do not include
						this Port */
	enum dpsw_accepted_frames 	admit_untagged;/* When this is
						admitTagged, the device will
						discard untagged frames or
						Priority-Tagged frames received
						on this port. When admitAll,
						untagged frames or Priority-
						Tagged frames received on this
						port will be accepted */

	int 	broadcast_enable;		/* enable broadcast */
	int 	flooding_enable;		/* enable flooding */
	int 	multicast_enable;		/* enable multicast */

	struct hmap			*hmap_metering;/* PLID database */

	/*! handlers */
	struct dpqos			*dpqos;	/* QoS Mapping handler */

	/* Interrupt */
	struct dpsw_irq			irq;

	/* Link configuration */
	struct dpsw_link_cfg		link_cfg;
	int fc_idx;

	/*Link Aggregation*/
	int lag_enabled; /*If LAG is enabled for this interface*/
	int lag_group_id; /*LAG group ID*/

	uint32_t link_res_flags; /* keep track of the resources allocated during
								connection procedure. Used to deallocate
								resources when an error appeared while connecting */
	struct dpmac *dpmac;

	/* Learning per interface */
	enum dpsw_learning_mode		learning_mode;
	int learning_requested;

	/* Replicator flag. Checks that the if is added only one time */
	int linkup_replic_updated;

	/* NUmber of LFQ resources allocated for this interface */
	int num_lfq;
};

/**************************************************************************//**
@Description   L2 Switch/D-Mux FDB structure

 *//***************************************************************************/
struct dpsw_fdb {
	struct dptbl		*hndl;		/**< fdb CTLU handle */
	uint16_t 		max_entries; 	/**< maximum FDB entries */
	uint16_t 		aging_time; 	/**< Aging time in seconds */
	enum dpsw_learning_mode	learning_mode;	/*! Learning */
	struct hmap		*hmap_mcast;	/*! Multi-cast group */
	uint16_t		ref_cnt;	/*! reference count */

	/* Broadcast replicator */
	struct dpsw_replic      broadcast;       /* broadcast */
	uint16_t		bcast_ifs[DPSW_MAX_IF];
	uint16_t		bcast_num_ifs;

	/* Flooding replicator */
	struct dpsw_replic	flooding;
	uint16_t		flooding_ifs[DPSW_MAX_IF];
	uint16_t		flooding_num_ifs;
};

struct dpsw_vlan_if {
	/*! Flags */
	int assigned;			/*! port assigned to this VLAN */
	int untagged;			/*! boolean Un-tagged Flag */
	int mirr;			/*! mirroring enabled */
	int flooding_enable;			/*! flooding enabled */
	/*! States */
	enum dpsw_stp_state 		stp_state;	/*! STP State */
	uint16_t fdb_id;
};
/**************************************************************************//**
@Description   L2 Switch/D-Mux vlan structure

 *//***************************************************************************/
struct dpsw_vlan {
	uint16_t 		fdb_id;		/*! Handle to associated FDB */
	struct dpsw_vlan_if 	*iface;		/*! Ports information */
	struct dpsw_replic	flooding;	/*! flooding */
};

/**************************************************************************//**
@Description	Policy
*//***************************************************************************/
struct dpsw_policy {
	struct dppolicy		*hndl;		/*! Policy handle */
	int			id;		/*! Policy ID */
};

struct dpsw_vlan_tbl {
	struct dpsw_id		kg;		/*! FALU->VLAN */
	struct dptbl		*tbl;		/*! VLAN table CTLU handle */
};

struct dpsw_acl {
	struct dptbl	*hndl;			/*! acl CTLU handle */
	uint16_t 	max_entries; 		/*! maximum entries */
};

/**************************************************************************//**
@Description   L2 Switch/D-Mux structure
 *//***************************************************************************/
struct dpsw {
	/**< General info */
	struct {
		uint32_t major;
		uint32_t minor;
	} version;
	int			id;		/*! Switch ID */
	int     		ceetm_id;

	/* Buffer pools */
	struct dpbp		*dpbp[DPSW_BP_NO];

	struct dpsw_buffer_pool_desc buffer_pools[DPSW_BP_NO]; /* Buffer Pools */
	int 			num_buffer_pools;	/* Number of pools */
	int				bp_per_if;

	struct dpsw_policy	policy;
	struct dpsw_id		fdb_kg;		/* VLAN->FDB */
	struct dpsw_wq		wq_void;	/* void FQID and QDID */
	struct dpsw_id		prp_virt_ing;	/* Parser Profile ID, Ingress*/
	struct dpsw_id		prp_phys_ing;	/* Parser Profile ID, Ingress*/
	struct dpsw_id		prp_egr;	/* Parser Profile ID, Egress */
	struct dpsw_wq		wq_replic;	/* Replication work queue */
	/**< Interface information */
	uint16_t 		num_ifs; 	/* Number of interfaces */
	struct 	dpsw_if 	*iface; 	/* Interfaces dbase */

	/**< FDB configuration */
	uint16_t		max_fdb_entries;/*! FDB num of entries*/
	uint16_t   		fdb_aging_time; /*! FDB aging time */
	struct hmap		*hmap_fdb;	/*! FDB database */

	uint8_t			max_fdbs;	/*! Maximum FDB */
	uint16_t		max_fdb_mc_groups;
	uint16_t		max_acls;	/*! Maximum ACLs */
	uint8_t			max_meters_per_if;
				/*! Number of multicast groups per each FDB */
	/**< VLAN information */
	struct hmap		*hmap_vlan;
	uint16_t		mem_size;	/*! Maximum amount of memory used*/
	uint16_t		max_vlans;	/*! Maximum VLAN */
	struct dpsw_vlan_tbl	vlan_ing;	/*! Ingress CTLU table */
	struct dpsw_vlan_tbl	vlan_egr;	/*! Egress CTLU table */

	/* ACL */
	struct dptbl		*acl_void_tbl;	/*! Table handle */
	struct dpsw_id		acl_kg;		/*! ACL KG */
	struct hmap		*hmap_acl;	/*! ACL database */

	/* Broadcast */
        struct dpsw_replic      broadcast;       /* broadcast */

	/* Interrupt handling */
	struct mc_irq 		irqs[DPSW_MAX_IRQ_NUM];

	struct dpmng_dev_ctx 	dev_ctx;
	
   	/* Miscellaneous */
   	struct dpsw_handle	handle;		/*! handlers */

   	/* reflection */
   	uint16_t 		mirr_if_id;	/*! reflection interface */

   	/* learning */
   	struct ctrl_if 		*ctrl_if;

   	/* features */
	int 			flooding_enable;/* enable flooding */
	int 			multicast_enable;/* enable multicast */
	int 			ctrl_if_enable;	/* enable control port */
	int			flooding_metering_enable;
	int			metering_enable;
	int 		lag_enable;/* enable link aggregation */
	enum dpsw_component_type component_type;/*C-VLAN or S-VLAN component */
	enum dpsw_flooding_cfg flooding_cfg;
	enum dpsw_broadcast_cfg broadcast_cfg;
	
	/* Link aggregation*/
	struct dpsw_id	lag_kg;
	struct dpsw_lag_cfg lag_cfg[DPSW_MAX_LAG];
	int num_lag_groups;

#ifdef TKT508412
	struct dptbl *pfc_multicast_fltr_tbl;
	int pfc_multicast_fltr_kid;
#endif
};

#endif /* _DPSW_H */


