/*
 * Copyright 2013-2020 NXP
 */

#ifndef _LEGACY_DPSW_DPLIB_H
#define _LEGACY_DPSW_DPLIB_H

/* 
 * File used to maintain compatibility with older version of dplib/flib
 * All previous version of dpsw commands should be placed here
 */

/**********************************************/
/**********************************************/
/********* V0 version of dpsw commands ******/
/**********************************************/
/**********************************************/

/*                cmd, param, offset, width, type, arg_name */
#define DPSW_RSP_GET_ATTRIBUTES_V0(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0, 16, uint16_t, (attr)->num_ifs);\
	MC_RSP_OP(cmd, 0, 16,  8, uint8_t,  (attr)->max_fdbs);\
	MC_RSP_OP(cmd, 0, 24,  8, uint8_t,  (attr)->num_fdbs);\
	MC_RSP_OP(cmd, 0, 32, 16, uint16_t, (attr)->max_vlans);\
	MC_RSP_OP(cmd, 0, 48, 16, uint16_t, (attr)->num_vlans);\
	MC_RSP_OP(cmd, 1,  0, 16, uint16_t, (attr)->version.major);\
	MC_RSP_OP(cmd, 1, 16, 16, uint16_t, (attr)->version.minor);\
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t, (attr)->max_fdb_entries);\
	MC_RSP_OP(cmd, 1, 48, 16, uint16_t, (attr)->fdb_aging_time);\
	MC_RSP_OP(cmd, 2,  0, 32, int,      (attr)->id);\
	MC_RSP_OP(cmd, 2, 32, 16, uint16_t, (attr)->mem_size);\
	MC_RSP_OP(cmd, 2, 48, 16, uint16_t, (attr)->max_fdb_mc_groups);\
	MC_RSP_OP(cmd, 3,  0, 64, uint64_t, (attr)->options);\
	MC_RSP_OP(cmd, 4,  0,  8, uint8_t,  (attr)->max_meters_per_if);\
	MC_RSP_OP(cmd, 4,  8,  4, enum dpsw_component_type, \
					(attr)->component_type);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSW_CMD_SET_IRQ(cmd, irq_index, irq_cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,  irq_index);\
	MC_CMD_OP(cmd, 0, 32, 32, uint32_t, irq_cfg->val);\
	MC_CMD_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr);\
	MC_CMD_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSW_CMD_GET_IRQ(cmd, irq_index) \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index)

/*                cmd, param, offset, width, type, arg_name */
#define DPSW_RSP_GET_IRQ(cmd, type, irq_cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, irq_cfg->val); \
	MC_RSP_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr);\
	MC_RSP_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
	MC_RSP_OP(cmd, 2, 32, 32, int,	    type); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSW_CMD_IF_SET_LINK_CFG_V1(cmd, if_id, cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  16, uint16_t, if_id);\
	MC_CMD_OP(cmd, 1, 0,  32, uint32_t, cfg->rate);\
	MC_CMD_OP(cmd, 2, 0,  64, uint64_t, cfg->options);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSW_RSP_IF_GET_LINK_STATE_V1(cmd, state) \
do { \
	MC_RSP_OP(cmd, 0, 32, 1,  int,      state->up);\
	MC_RSP_OP(cmd, 1, 0,  32, uint32_t, state->rate);\
	MC_RSP_OP(cmd, 2, 0,  64, uint64_t, state->options);\
} while (0)

#endif /* _LEGACY_DPSW_DPLIB_H */
