/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpsw_drv.c

 @Description   Driver implementation

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "dplib/fsl_dpsw_cmd.h"
#include "fsl_event_pipe.h"
#include "fsl_dpsw_mc.h"
#include "fsl_sys.h"
#include "dtc/dtc.h"
#include "dpmng.h"
#include "fsl_resman.h"

int dpsw_drv_init(void);

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	UNUSED(dev);
	UNUSED(dev_ctx);

	pr_err("DPSW is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int destroy_by_resman(struct device *dev)
{
	return 0;
}

static int reset_by_resman(struct device *dev)
{
	return 0;
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	UNUSED(dev);
	UNUSED(irq_cfg);
	UNUSED(irq_index);

	pr_err("DPSW is not supported in this SOC!\n");
	return -ENOTSUP;
}


static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	UNUSED(dev);
	UNUSED(irq_cfg);
	UNUSED(irq_index);

	pr_err("DPSW is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpsw_open_cb(void *dev, int portal_id)
{
	UNUSED(dev);
	UNUSED(portal_id);
	
	pr_err("DPSW is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpsw_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(dev);
	UNUSED(portal_id);
	
	pr_err("DPSW is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpsw_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	UNUSED(dev);
	UNUSED(cmd_ver);
	UNUSED(cmd);
	UNUSED(portal_id);
	UNUSED(data);

	pr_err("DPSW is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpsw_probe_cb(void *lo, int node_off)
{
	UNUSED(lo);
	UNUSED(node_off);
	
	pr_warn("DPSW defined in DPL - Not supported in this SOC!\n");
	return 0;
}

static int dpsw_remove_cb(void *lo, int node_off)
{
	UNUSED(lo);
	UNUSED(node_off);
	
	return 0;
}

static char *dpsw_match[] = { "fsl,dpsw", "dpsw" };

int dpsw_drv_init(void)
{
	int err = 0;
	t_sys_dtc_mod_params dtc_params= { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;

	/*! Register layout */
	dtc_params.num_compats = ARRAY_SIZE(dpsw_match);
	dtc_params.compatibles = dpsw_match;
	dtc_params.f_prob_module = dpsw_probe_cb;
	dtc_params.f_remove_module = dpsw_remove_cb;
	err = sys_dtc_register_module(&dtc_params);
	if (err != 0)
		return err;

	/*! Register command interface */
	cmdif_ops.open_cb = dpsw_open_cb;
	cmdif_ops.close_cb = dpsw_close_cb;
	cmdif_ops.ctrl_cb = dpsw_ctrl_cb;
	err = cmdif_register_module(CMDIF_MOD_DPSW, &cmdif_ops);
	if (err != 0)
		return err;

	/*! Register resman */
	strcpy(dev_type_param.device_type, "dpsw");
	dev_type_param.irq_count = DPSW_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPSW_VER_MAJOR;
	dev_type_param.ver_minor = DPSW_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	ASSERT_COND(resman);

	err = resman_register_device_operation(resman, "dpsw", &dev_type_param);
	if (err != 0)
		return err;

	return err;
}

int dpsw_get_ap_ppid(struct dpsw *dpsw, int if_id, int *ppid)
{
	return -EINVAL;
}

int dpsw_clean_flow_control_config(struct dpsw *dpsw, int if_id)
{
	return -EINVAL;
}
