/*
 * Copyright 2013-2021 NXP
 */

/**************************************************************************//*
 @File           dpsw.c

 @Description    Library implementation
 MC Implementation API's defined in fsl_dpsw.h
 The following modules MUST be initialized before API use
 -# Resource manager
 -# Link Manager
 -# Portal Command interface
 -# QMan/BMan
 -# WRIOP
 -# CTLU
 -# DPMAC

 @Cautions      None.
 *//***************************************************************************/
/* L2 Switch internal declarations*/
#include "dpsw.h"                               /* Internal database */
#include "fsl_dpbp_mc.h"
#include "fsl_dpni_mc.h"
#include "fsl_dppolicer.h"
#include "hmap.h"
#include "device.h"
#include "soc_db.h"
#include "fsl_timer.h"
#include "flow_control.h"

/* local flags used in flow control configuration */
#define DPSW_ENABLE_FC_SENDING		0x0001
#define DPSW_ENABLE_FC_RESPONSE		0x0002
#define DPSW_UPDATE_FC				0x8000

/*
 * Add here the buffer pools for dpsw
 * Increase DPSW_BP_NO and modify the function init_dpsw_buffer_pool
 */
static int init_dpsw_buffer_pool(struct dpsw *dpsw, int bp_per_if)
{
	int i, size = 0;
	size_t mem_limit;
	struct qbman_desc qbman_desc;
	struct mem_desc pebm_desc;
	struct dpsw_buffer_pool_desc *buffer_pools;
	size_t mem_size;

	buffer_pools = dpsw->buffer_pools;

	if( bp_per_if ) {
		dpsw->num_buffer_pools = dpsw->num_ifs;
	}
	else {
		dpsw->num_buffer_pools = 1;
	}

	/* if mem_size property has been specified, use it instead of performing any calculus
	 * mem_size represents the number of 256byte buffers.
	 */
	if (dpsw->mem_size) {
		mem_size = (size_t) dpsw->mem_size * DPSW_BP_BUFFER_SIZE;
	} else {
		mem_size = (size_t) dpsw->num_ifs * DPSW_BP_QUEUES_NO * DPSW_BP_FRAMES_PER_QUEUE * DPSW_MAX_FRAME_LENGTH;
	}

	if( bp_per_if ) {
		mem_size = mem_size / dpsw->num_ifs;
	}

	for( i = 0 ; i < dpsw->num_buffer_pools ; i++ ) {
		buffer_pools[i].memory_type = MEM_PART_PEB;
		buffer_pools[i].memory_size = mem_size;
		buffer_pools[i].buffer_size = DPSW_BP_BUFFER_SIZE;
	}

	/*
	 * make sure that, if we need more than PEBM - PFDR,
	 * we won't fail, but limit the memory size.
	 */
	sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
					&qbman_desc, NULL);
	sys_get_desc(SOC_MODULE_PEBM, 0, &pebm_desc, NULL);
	mem_limit = (size_t) (pebm_desc.size - (uint64_t)qbman_desc.pfdr_peb_size);

	if( bp_per_if ) {
		mem_limit /= dpsw->num_buffer_pools;
	}

	for( i = 0 ; i < dpsw->num_buffer_pools ; i++ ) {
		CHECK_COND_RETVAL( mem_limit > DPSW_BP_BUFFER_SIZE, -ENOMEM, "Not enough PEB to allocate for dpsw\n");
		if (buffer_pools[i].memory_size > mem_limit)
			buffer_pools[i].memory_size = mem_limit;
	}

	for (i = 0 ; i < dpsw->num_buffer_pools ; i++)
		size += buffer_pools[i].memory_size;
	pr_info("SWID[%d] Size of memory occupied is %d\n", dpsw->id, size);

	return 0;
}

/**
 * @brief       static functions declaration
 */
int event_phys(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);

int event_virt(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);

/* Virtual events */
int event_connect_virt(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	struct linkman_endpoint  *peer,
        	const struct linkman_control   *control,
        	struct linkman_action          *action);

int event_disconnect_virt(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);

int event_linkup_virt(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	const struct linkman_control   *control,
        	struct linkman_action          *action);

int event_linkdown_virt(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);

/* physical events */
int event_connect_phys(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);
int event_disconnect_phys(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);

int event_linkup_phys(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);

int event_linkdown_phys(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);

int event_negotiation_ok(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);

int event_negotiation_fail(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);

static int virt_connection_control_integrity(struct dpsw *dpsw,
                const struct linkman_control   *control);

static int is_virt_connection_shaped(
                const struct linkman_control   *control);

static int endpoint_integrity(struct dpsw *dpsw,
	struct linkman_endpoint *endpoint);

static int add_channel(struct dpsw *dpsw,
	const struct linkman_endpoint *self,
	const struct linkman_endpoint *peer);

static int if_associate_with_lni(struct dpsw *dpsw, uint16_t if_id, int shaped);

static int virt_link_rates(
        const struct linkman_endpoint   *ep1,
        const struct linkman_endpoint   *ep2,
        const struct linkman_control   *control,
        struct linkman_link_state       *link_state,
        uint32_t *max_rate
        );

static int ctrl_if_connect(struct dpsw *dpsw, uint16_t if_id, int next_ifp);
static int ctrl_if_disconnect(struct dpsw *dpsw, uint16_t if_id);
static int ctrl_if_linkup(struct dpsw *dpsw, uint16_t if_id);
static int ctrl_if_linkdown(struct dpsw *dpsw, uint16_t if_id);

static int link_event(struct dpsw *dpsw,
	enum linkman_event event, enum linkman_cmd cmd,
	uint16_t if_id);

static void irq_if_trigger(struct dpsw *dpsw, uint16_t if_id, uint16_t event);
static uint32_t irq_if_compose_message(struct dpsw *dpsw,
	uint16_t if_id,
	uint16_t event);
static int irq_get_pending_if(struct dpsw *dpsw, uint16_t *if_id);
static uint16_t irq_if_restore_event(struct dpsw *dpsw, uint16_t if_id);
static void irq_if_save_event(struct dpsw *dpsw,
	uint16_t if_id,
	uint16_t event);

/* Auxiliary */
static int if_eiop_ifp_enable(struct dpsw *dpsw, uint16_t id);
static int if_eiop_ifp_disable(struct dpsw *dpsw, uint16_t id);
static int is_if_eiop_ifp_enable(struct dpsw *dpsw, uint16_t id);
static int if_eiop_ifp_clear_counters(struct dpsw *dpsw, uint16_t if_id);
static int eiop_ifp_clear_counters(struct dpsw *dpsw);


static int if_eiop_ifp_set_prpid(struct dpsw *dpsw, uint16_t if_id, int prpid);
static int if_eiop_ifp_next(struct dpsw *dpsw, uint16_t id, int ifpid);
static int qdid_to_ifid(struct dpsw *dpsw, int vqdid, uint16_t *if_id);

/* FDB */
static int fdb_entry_query(struct dpsw *dpsw,
	uint16_t fdb_id,
	const uint8_t *mac_addr,
	struct dptbl_l2switch_fdb_action *entry);

static int fdb_entry_remove(struct dpsw *dpsw,
	uint16_t fdb_id,
	const uint8_t *mac_addr);

static int fdb_add_broadcast(struct dpsw *dpsw, struct dpsw_fdb *fdb);

/* dpsw_init */
static int dpsw_init_bman_bps(struct dpsw *dpsw);
static int dpsw_init_bman_bp(struct dpsw *dpsw, int id);
static void dpsw_init_handle(struct dpsw *dpsw);
static int init_wq_void(struct dpsw *dpsw);
static int init_wq_void_fq(struct dpsw *dpsw);
static int init_wq_replic_fq(struct dpsw *dpsw);
static int init_params_integrity(const struct dpsw_cfg *src_cfg,
	struct dpsw_cfg *dst_cfg);
static int dpsw_init_ctlu_prp(struct dpsw *dpsw);
static int dpsw_init_ctlu_prp_egr(struct dpsw *dpsw);
static int dpsw_init_ctlu_prp_ing(struct dpsw *dpsw);
static int init_allocate(struct dpsw *dpsw, const struct dpsw_cfg *cfg);
static int init_allocate_iface(struct dpsw *dpsw, const struct dpsw_cfg *cfg);
static int init_allocate_vlan(struct dpsw *dpsw, const struct dpsw_cfg *cfg);
static int init_allocate_fdb(struct dpsw *dpsw, const struct dpsw_cfg *cfg);
static void init_save_params(struct dpsw *dpsw,
	const struct dpsw_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg);
static void init_internal_database(struct dpsw *dpsw);
static int init_allocate_resources(struct dpsw *dpsw);
static int init_allocate_resources_ifp(struct dpsw *dpsw);
static int init_allocate_resources_plid(struct dpsw *dpsw);
static int init_allocate_resources_flooding_plid(struct dpsw *dpsw);
static int init_infrastructure(struct dpsw *dpsw);
static int init_ctlu(struct dpsw *dpsw);
static int init_ctlu_policy(struct dpsw *dpsw);
static int init_ctrl_if(struct dpsw *dpsw);
/*! ACL */
static int init_ctlu_acl(struct dpsw *dpsw);
static int init_ctlu_acl(struct dpsw *dpsw);
static int init_ctlu_acl_database(struct dpsw *dpsw);
static int init_ctlu_acl_void_tbl(struct dpsw *dpsw);
static int init_ctlu_acl_kg(struct dpsw *dpsw);
static int acl_get_key(struct dpsw *dpsw, uint16_t *key);
static int acl_make_rule(struct dpsw *dpsw,
	const struct dpsw_acl_entry_cfg *cfg,
	uint8_t *key,
	uint8_t *mask,
	struct dptbl_rule *rule);
static int acl_make_action(struct dpsw *dpsw,
	const struct dpsw_acl_entry_cfg *cfg,
	struct dptbl_action *action);
static void acl_set_key(uint8_t *key,
	const struct dpsw_acl_fields *fields);
static void acl_align_key(struct dpsw_acl_fields *result,
	const struct dpsw_acl_fields *key,
	const struct dpsw_acl_fields *mask);

static int init_ctlu_vlan(struct dpsw *dpsw);
static int init_ctlu_vlan_kg(struct dpsw *dpsw);
static int init_ctlu_fdb_kg(struct dpsw *dpsw);
static int init_ctlu_lag_kg(struct dpsw *dpsw);
static int init_replic(struct dpsw *dpsw);
static int init_replic_unicast(struct dpsw *dpsw);
static int init_replic_multicast(struct dpsw *dpsw);
static int init_replic_flooding(struct dpsw *dpsw);
static int if_in_list(uint16_t *if_id, uint16_t num_ifs, int interface);
static int init_replic_broadcast(struct dpsw *dpsw);
static int init_wq_qpri(struct dpsw *dpsw, struct dpsw_wq *wq);
static int init_wq_qdr(struct dpsw *dpsw, struct dpsw_wq *wq);
static int init_if_eiop(struct dpsw *dpsw, uint16_t id);
static int init_if_eiop_qos(struct dpsw *dpsw, uint16_t if_id);
static int init_if_eiop_ifp(struct dpsw *dpsw, uint16_t id);
static int init_if_eiop_ifp_core(struct dpsw *dpsw, uint16_t id);
static int init_if_eiop_ifp_extension(struct dpsw *dpsw, uint16_t id);
static int init_vlan(struct dpsw *dpsw);
static int init_learning(struct dpsw *dpsw);
static int init_default(struct dpsw *dpsw);
static int init_default_tci(struct dpsw *dpsw);
static int init_default_untagged(struct dpsw *dpsw);
static int init_deafult_ceetm_if(struct dpsw *dpsw);
static int init_default_ceetm_if_tx_selection(struct dpsw *dpsw);
static int init_default_ceetm_if_early_drop(struct dpsw *dpsw);
static int init_default_flooding_metering(struct dpsw *dpsw);

/* debugging */
static void dpsw_dump(struct dpsw *dpsw);
int dbg_replic(struct dpsw *dpsw, int rrid);

/* dpsw_vlan_add_if */
static int vlan_tbl_update(struct dpsw *dpsw, uint16_t vlan_id);
static int vlan_tbl_assigned_update(struct dpsw *dpsw, uint16_t vlan_id);
static int vlan_tbl_admit_untagged_update(struct dpsw *dpsw, uint16_t vlan_id);
static int vlan_tbl_accept_all_vlan_update(struct dpsw *dpsw, uint16_t vlan_id);

static int vlan_tbl_remove(struct dpsw *dpsw, uint16_t vlan_id);
static int vlan_tbl_assigned_remove(struct dpsw *dpsw, uint16_t vlan_id);
static int vlan_tbl_admit_untagged_remove(struct dpsw *dpsw, uint16_t vlan_id);
static int vlan_tbl_accept_all_vlan_remove(struct dpsw *dpsw, uint16_t vlan_id);

static int vlan_tbl_if_update(struct dpsw *dpsw, uint16_t if_id);
static int vlan_tbl_if_assigned_update(struct dpsw *dpsw, uint16_t if_id);
static int vlan_tbl_if_admit_untagged_update(struct dpsw *dpsw, uint16_t if_id);
static int vlan_tbl_if_accept_all_vlan_update(struct dpsw *dpsw,
	uint16_t if_id);

static int vlan_tbl_vif_update(struct dpsw *dpsw,
	uint16_t vlan_id, uint16_t if_id);
static int vlan_tbl_vif_assigned_update(struct dpsw *dpsw,
	uint16_t vlan_id, uint16_t if_id);
static int vlan_tbl_vif_admit_untagged_update(struct dpsw *dpsw,
	uint16_t vlan_id, uint16_t if_id);
static int vlan_tbl_vif_accept_all_vlan_update(struct dpsw *dpsw,
	uint16_t vlan_id, uint16_t if_id);

static int vlan_tbl_if_remove(struct dpsw *dpsw, uint16_t if_id);
static int vlan_tbl_if_assigned_remove(struct dpsw *dpsw, uint16_t if_id);
static int vlan_tbl_if_admit_untagged_remove(struct dpsw *dpsw, uint16_t if_id);
static int vlan_tbl_if_accept_all_vlan_remove(struct dpsw *dpsw,
	uint16_t if_id);

static int vlan_tbl_entry_update(struct dpsw *dpsw,
	enum ctlu_type ctlu_type,
	uint16_t vlan_id,
	uint16_t if_id);
static uint32_t vlan_if_get_options(struct dpsw *dpsw,
	enum ctlu_type ctlu_type,
	uint16_t vlan_id,
	uint16_t if_id);
uint32_t vlan_if_get_stp_options(struct dpsw *dpsw,
	enum ctlu_type ctlu_type,
	uint16_t vlan_id,
	uint16_t if_id);
uint32_t vlan_if_get_learning_mode_options(struct dpsw *dpsw,
	uint16_t vlan_id,
	uint16_t if_id);
static int vlan_if_dbase_add(struct dpsw *dpsw,
	uint16_t vlan_id,
	uint16_t if_id,
	uint16_t fdb_id);
static int vlan_if_dbase_remove(struct dpsw *dpsw,
	uint16_t vlan_id,
	uint16_t if_id);
static int vlan_if_get_action(struct dpsw *dpsw,
	enum ctlu_type ctlu_type,
	uint16_t vlan_id,
	uint16_t if_id,
	struct dptbl_l2switch_vlan_action *action);
static int vlan_if_get_rule(struct dpsw *dpsw,
	uint16_t vlan_id,
	uint16_t if_id,
	struct dptbl_l2switch_vlan_rule_cfg *rule,
	uint32_t *key);
static int vlan_add_if_params_integrity(struct dpsw *dpsw,
        uint16_t vlan_id,
        const struct dpsw_vlan_if_cfg *cfg);

static int vlan_remove_if_params_integrity(struct dpsw *dpsw,
        uint16_t vlan_id,
        const struct dpsw_vlan_if_cfg *cfg);

int is_vlan_if_assigned(struct dpsw *dpsw, uint16_t vlan_id, uint16_t if_id);
static int vlan_tbl_entry_remove(struct dpsw *dpsw,
	enum ctlu_type ctlu_type,
	uint16_t vlan_id,
	uint16_t if_id);
static int vlan_remove_all(struct dpsw *dpsw);
static int fdb_remove_all(struct dpsw *dpsw);
static int acl_remove_all(struct dpsw *dpsw);
static int dpsw_learning_params_integrity(struct dpsw *dpsw,
	enum dpsw_learning_mode mode);

static int acl_add_entry_params_integrity(struct dpsw *dpsw,
	uint16_t acl_id,
	const struct dpsw_acl_entry_cfg *cfg);

/* dpsw_destroy */
static int destroy_disconnect(struct dpsw *dpsw);
static int destroy_ctrl_if(struct dpsw *dpsw);
static int destroy_if(struct dpsw *dpsw);
static int destroy_ctlu(struct dpsw *dpsw);
static int destroy_resources(struct dpsw *dpsw);
static int destroy_deallocate(struct dpsw *dpsw);
static int destroy_deallocate_iface(struct dpsw *dpsw);
static int destroy_deallocate_iface_metering(struct dpsw *dpsw);
static int destroy_deallocate_vlan(struct dpsw *dpsw);
static int destroy_deallocate_fdb(struct dpsw *dpsw);
static int destroy_deallocate_acl(struct dpsw *dpsw);
static int destroy_deallocate_broadcast(struct dpsw *dpsw, struct dpsw_fdb *fdb);
static int destroy_bman_bp(struct dpsw *dpsw);
static int destroy_deallocate_ceetm_if(struct dpsw *dpsw);

/* dpsw_fdb_add */
static int fdb_get_key(struct dpsw *dpsw, uint16_t *key);

/* dpsw_vlan_add */
static int vlan_ifs_cnt(struct dpsw *dpsw, uint16_t vlan_id, uint16_t *cnt);
static int vlan_untagged_ifs_cnt(struct dpsw *dpsw,
	uint16_t vlan_id,
	uint16_t *cnt);

/*! dpsw_vlan_add_if_flooding */
static int vlan_flooding_params_integrity(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg);

/*! dpsw_vlan_add_if_untagged */
static int vlan_untagged_params_integrity(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg,
	int untagged);

int vlan_if_untagged(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg,
	int untagged);

/* dpsw_fdb_add_multicast */
/* dpsw_fdb_remove_multicast */
static int fdb_multicast_params_integrity(struct dpsw *dpsw,
	uint16_t fdb_id,
	const struct dpsw_fdb_multicast_cfg *cfg);

/*! dpsw_if_add_reflection */
static int reflection_ingress_vlan(struct dpsw *dpsw,
	uint16_t if_id,
	uint16_t vlan_id,
	int mirr);

static int reflection_ingress_all(struct dpsw *dpsw, uint16_t if_id, int mirr);

/*! dpsw_set_reflection_if */
static int set_quartet_unicast(struct dpsw *dpsw);
static int set_quartet_multicast(struct dpsw *dpsw);
static int set_quartet_flooding(struct dpsw *dpsw);
static int set_quartet_broadcast(struct dpsw *dpsw);

/*Replication */
static int replic_init(struct dpsw *dpsw, struct dpsw_replic *replic);

static int replic_cleanup(struct dpsw *dpsw, struct dpsw_replic *replic);

static int replic_broadcast_set_default(struct dpsw *dpsw, uint16_t fdb_id);

static int replic_flooding_set_default(struct dpsw *dpsw, uint16_t fdb_id);

static int replic_init_quartet(struct dpsw *dpsw,
	struct dpsw_quartet_rrid *rrid,
	int root_qdid,
	int root_next_rrid);

static int replic_configure_quartet(struct dpsw *dpsw,
	struct dpsw_quartet_rrid *rrid,
	int root_qdid,
	int root_next_rrid);

static int replic_configure_quartet_root(struct dpsw *dpsw,
	struct dpsw_quartet_rrid *rrid,
	int root_qdid,
	int root_next_rrid);

static int replic_configure_quartet_mirr(struct dpsw *dpsw,
	struct dpsw_quartet_rrid *rrid);

static int replic_configure_quartet_swl(struct dpsw *dpsw,
	struct dpsw_quartet_rrid *rrid);

static int replic_add(struct dpsw *dpsw,
	struct dpsw_replic *replic,
	const struct dpsw_vlan_if_cfg *if_cfg);

static int replic_remove(struct dpsw *dpsw,
	struct dpsw_replic *replic,
	const struct dpsw_vlan_if_cfg *if_cfg);

static void replic_copy_to_vlan_if(struct dpsw *dpsw,
	struct dpsw_vlan_if_cfg *vlan_if,
	const struct dpsw_fdb_multicast_cfg *multicast_if,
	uint16_t fdb_id);

static void replic_copy_to_multicast_if(struct dpsw_fdb_multicast_cfg *multicast_if,
	const struct dpsw_vlan_if_cfg *vlan_if);

static int replic_get_ifs(struct dpsw *dpsw,
	const struct dpsw_replic *replic,
	struct dpsw_vlan_if_cfg *cfg);

static uint16_t replic_get_ifs_cnt(struct dpsw *dpsw,
	const struct dpsw_replic *replic);

/*! dpsw_acl_add_if */
static int acl_if_params_integrity(struct dpsw *dpsw,
	uint16_t acl_id,
	const struct dpsw_acl_if_cfg *acl_ifs);
static int acl_if_set_reference(struct dpsw *dpsw,
	uint16_t acl_id,
	const struct dpsw_acl_if_cfg *acl_ifs);
static int acl_get_reference_count(struct dpsw *dpsw, uint16_t acl_id);
static int acl_add_to_ifps(struct dpsw *dpsw,
	struct dptbl *tbl,
	const struct dpsw_acl_if_cfg *acl_if);
static int acl_add_to_ifp(struct dpsw *dpsw, int acl_id, uint16_t if_id);

/* dpsw_if_set_flooding_metering */
/* dpsw_if_set_metering */
static int metering_configure(struct dpsw *dpsw,
        		int plid,
        		struct dpsw_metering_cfg *cfg);

int set_if_plid(struct dpsw *dpsw, uint16_t if_id, uint8_t tc_id);

int flooding_metering_params_integrity(struct dpsw *dpsw,
                        uint16_t if_id,
                        struct dpsw_metering_cfg *cfg);

int metering_params_integrity(struct dpsw *dpsw,
                        uint16_t if_id,
                        uint8_t tc_id,
                        struct dpsw_metering_cfg *cfg);

static int link_state_common_denominator(
	const struct linkman_endpoint	*ep1,
	const struct linkman_endpoint 	*ep2,
	uint32_t committed_rate,
	struct linkman_link_state *link_state);

/* dpsw_if_tx_selection */
static int if_set_tx_selection_params_integrity(struct dpsw *dpsw,
	uint16_t if_id,
        const struct dpsw_tx_selection_cfg *ts);
static int if_set_tx_selection(
	struct dpsw *dpsw,
	uint16_t if_id,
	const struct dpsw_tx_selection_cfg *ts);

static int is_if_link_up(struct dpsw *dpsw, uint16_t if_id, int *link_up);

/* CEETM Interface */
static int init_ceetm_if(struct dpsw  *dpsw, uint16_t if_id);
static int if_set_early_drop_params_integrity(
	struct dpsw *dpsw,
        uint16_t if_id,
        uint8_t tc_id,
        const struct dpsw_early_drop_cfg *drop_cfg);

static int if_set_early_drop(
	struct dpsw *dpsw,
        uint16_t if_id,
        uint8_t tc_id,
        const struct dpsw_early_drop_cfg *drop_cfg);

static enum ceetm_if_ccg_unit get_early_drop_unit(
	enum dpsw_early_drop_unit unit);
static enum ceetm_if_ccg_mode get_early_drop_mode(
	enum dpsw_early_drop_mode mode);
static enum ceetm_if_sched_mode get_schedule_mode(
	enum dpsw_schedule_mode mode);
static int get_iface_qdid(struct dpsw *dpsw, uint16_t if_id, int *qdid);
static int get_iface_unused_qprid(
	struct dpsw *dpsw, uint16_t if_id, int *qprid);

static int __dpsw_set_egress_flood(struct dpsw *dpsw,
				   struct dpsw_egress_flood_cfg *cfg);

/*! Global variables */
static uint16_t fdb_key = 0; /*! Used for fdb id generation */

static int dpsw_get_remote_ppid(struct dpsw *dpsw, int if_id, int *ppid)
{
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr link_attr;
	void *object;
	int err;

	*ppid = -1;

		memset(&endpoint1, 0, sizeof(endpoint1));
		memset(&endpoint2, 0, sizeof(endpoint2));
		memset(&link_attr, 0, sizeof(link_attr));

		endpoint1.type = FSL_MOD_DPSW;
		endpoint1.id = (uint16_t)dpsw->id;
		endpoint1.if_id = (uint16_t)if_id;
		err = linkman_get_connection(dpsw->handle.linkman, &endpoint1, &endpoint2, &link_attr);
		CHECK_COND_RETVAL(err==0, err, "Could not get connected object to dpsw.%d [%d]\n", dpsw->id, if_id);

		object = sys_get_handle(endpoint2.type, 1, endpoint2.id);
		CHECK_COND_RETVAL(object, -ENODEV, "[ID: %d] Could not get connected object\n", dpsw->id);
		switch( endpoint2.type ) {
		case FSL_MOD_DPNI:
			err = dpni_get_ap_ppid((struct dpni *)object, ppid);
			CHECK_COND_RETVAL(err==0, err, "dpni_get_ap_ppid() return error\n");
			break;
		default:
			pr_err("Invalid connection peer object\n");
			err = -EINVAL;
			break;
		}

	return err;
}

static int dpsw_get_ppid(struct dpsw *dpsw, int if_id, int *ppid)
{
	struct dpsw_if *iface;
	int err;

	*ppid = -1;

	iface = &(dpsw->iface[if_id]);
	if( iface->dpmac ) {
		*ppid = dpmac_get_ppid(iface->dpmac);
		err = 0;
	} else {
		dpsw_get_remote_ppid(dpsw, if_id, ppid);
		return 0;
	}

	return err;
}

static int dpsw_config_ppid_priority(struct dpsw *dpsw, int if_id,
		uint16_t cgid, char type, uint8_t prio_mask, int cmd)
{
	int ppid = -1;
	struct eiop_cgp cgp = { 0 };
	struct eiop_port_desc eiop_port_desc = {0};
	int err = 0;

	err = !(type==EIOP_CGP_CONGESTION_GROUP || type==EIOP_CGP_BUFFER_DEPLETION);
	CHECK_COND_RETVAL(err==0, -EINVAL, "Invalid congestion group type: %d\n", type);

	err = dpsw_get_ppid(dpsw, if_id, &ppid);
	CHECK_COND_RETVAL(err==0, err, "Could not get ppid; flow control feature will not work\n");
	eiop_port_desc.port_id = ppid;
	err = sys_get_desc(SOC_MODULE_EIOP_PORT, SOC_DB_PORT_DESC_ID, &eiop_port_desc, NULL);
	CHECK_COND_RETVAL(err==0, err, "Could not get eiop port descriptor; flow control feature will not work\n");

	cgp.type = type;
	cgp.id   = cgid;
	cgp.bits = prio_mask;
	eiop_port_set_cgp(&eiop_port_desc, &cgp, cmd);

	return 0;
}

static int dpsw_if_update_bp_config(struct dpsw *dpsw, int if_id, uint32_t flags)
{
	struct dpbp_attr dpbp_attr;
	struct dpbp	*dpbp;
	int pool_idx;
	int err = 0;
	struct dpsw_if  *iface;
	int cmd;
	uint8_t prio_mask;

	if( !(flags & DPSW_UPDATE_FC) )
		return 0;

	if( dpsw->bp_per_if )
		pool_idx = if_id;
	else
		pool_idx = 0;

	dpbp = dpsw->dpbp[pool_idx];

	err = dpbp_get_attributes(dpbp, &dpbp_attr);
	CHECK_COND_RETVAL( err==0, err, "DPSW.%d[%d]: dpbp_get_attributes() call failed\n", dpsw->id, if_id);

	iface = &dpsw->iface[if_id];

	if( iface->dpmac ) {
		if( flags & DPSW_ENABLE_FC_SENDING ) {
			cmd = 2; /* write whole field */
			prio_mask = 0xff;
		}
		else {
			cmd = 2; /* write whole field */
			prio_mask = 0x00;
		}
	}
	else {
		if( iface->fc_idx == FLOW_CONTROL_INVALID_INDEX )
			return 0;

		if( flags & DPSW_ENABLE_FC_SENDING ) {
			cmd = 1;
			prio_mask = 0x01 << iface->fc_idx;
		}
		else {
			cmd = 0;
			prio_mask = 0x01 << iface->fc_idx;
		}
	}

	err = dpsw_config_ppid_priority(dpsw, if_id,
			dpbp_attr.bpid, EIOP_CGP_BUFFER_DEPLETION,
			prio_mask, cmd);
	CHECK_COND_RETVAL( err==0, err, "DPSW.%d[%d]: dpsw_config_ppid_priority() failed\n", dpsw->id, if_id);

	return err;
}

static int dpsw_if_update_channel_fc(struct dpsw *dpsw, int if_id, uint32_t flags)
{
	int err = 0;
	struct dpmng_accesspoint  *ap;
	uint32_t ceetmid;
	struct dpsw_if  *iface;
	struct qbman_attr tcfc_attr = {0};
	struct qbman_swp *sw_portal;
	int enable;

	if( !(flags & DPSW_UPDATE_FC) )
		return 0;

	dpmng_get_swportal(dpsw->handle.dpmng, (void **)&(sw_portal));

	iface = &dpsw->iface[if_id];
	if( iface->fc_idx == FLOW_CONTROL_INVALID_INDEX )
		return 0;

	ap = &iface->ap;

	ceetmid = qbman_ceetmid_compose(
			(uint8_t)ap->dcp_id,
			(uint8_t)ap->ceetm_id);
	qbman_ceetm_tcfc_query(sw_portal, ceetmid, (uint8_t)ap->lniid, &tcfc_attr);

	enable = 0;
	if( flags & DPSW_ENABLE_FC_RESPONSE ) {
		enable = 1;
	}

	qbman_ceetm_tcfc_set_lnitcfcc(&tcfc_attr, 1, 0, (uint8_t)ap->cqchid, (uint8_t)iface->fc_idx, enable);

	qbman_ceetm_tcfc_configure(sw_portal, ceetmid, (uint8_t)ap->lniid, &tcfc_attr);

	dpmng_put_swportal(dpsw->handle.dpmng, (void*)sw_portal);

	return err;
}

static void dpsw_init_handle(struct dpsw *dpsw)
{
	/*! Ingress Parser */
	dpsw->handle.dpparser_ing = sys_get_handle(FSL_MOD_PARSER, 2, /*! number of params */
							0, /*! iop_id */
							CTLU_EIOP_INGRESS); /*! Ingress */
	CHECK_COND_RET(dpsw->handle.dpparser_ing);

	/*! Egress Parser */
	dpsw->handle.dpparser_egr = sys_get_handle(FSL_MOD_PARSER, 2, /*! number of params */
							0, /*! iop_id */
							CTLU_EIOP_EGRESS); /*! Egress */
	CHECK_COND_RET(dpsw->handle.dpparser_egr);

	/*! Ingress FALU */
	dpsw->handle.dppolicy_ing = sys_get_handle(FSL_MOD_POLICIES_MNG, 2, /*! number of params */
							0, /*! iop_id */
							CTLU_EIOP_INGRESS); /*! Ingress */
	CHECK_COND_RET(dpsw->handle.dppolicy_ing);

	/*! Ingress Key Generation */
	dpsw->handle.dpkg_ing = sys_get_handle(FSL_MOD_KG, 2, /*! number of params */
						0, /*! iop_id */
						CTLU_EIOP_INGRESS); /*! Ingress */
	CHECK_COND_RET(dpsw->handle.dpkg_ing);

	dpsw->handle.dpkg_egr = sys_get_handle(FSL_MOD_KG, 2, /*! number of params */
						0, /*! iop_id */
						CTLU_EIOP_EGRESS); /*! egress */
	CHECK_COND_RET(dpsw->handle.dpkg_egr);

	/*! Ingress Tables */
	dpsw->handle.dptbl_ing = sys_get_handle(FSL_MOD_TABLES_MNG, 2, /*! number of params */
						0, /*! iop_id */
						CTLU_EIOP_INGRESS); /*! Ingress */
	CHECK_COND_RET(dpsw->handle.dptbl_ing);

	/*! Ingress QoS */
	dpsw->handle.dpqos_ing = sys_get_handle(FSL_MOD_QoS_MNG, 2, /*! number of params */
						0, /*! iop_id */
						CTLU_EIOP_INGRESS); /*! Ingress */
	CHECK_COND_RET(dpsw->handle.dpqos_ing);

	/*! Link manager 2.0 */
	dpsw->handle.linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	CHECK_COND_RET(dpsw->handle.linkman);

	/*! General manager */
	dpsw->handle.dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dpsw->handle.dpmng);

	/* Policer */
	dpsw->handle.dppolicer_ing = sys_get_handle(FSL_MOD_POLICER, 2,
	                                            0,
	                                            CTLU_EIOP_INGRESS);
	CHECK_COND_RET(dpsw->handle.dppolicer_ing);
}

static int dpsw_init_ctlu_prp(struct dpsw *dpsw)
{
	/**
	 -# PRP  Parser Profile
	 */
	int err = 0;

	/* Egress */
	err = dpsw_init_ctlu_prp_egr(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/* Ingress */
	err = dpsw_init_ctlu_prp_ing(dpsw);

	return err;
}

static int dpsw_init_ctlu_prp_egr(struct dpsw *dpsw)
{
	int err = 0;
	char type[16];

	/* Egress Parser Profile */
	dpparser_get_resource_str(dpsw->handle.dpparser_egr, type);

	/* Allocate resource */
	err = allocate_resource(
		dpsw->handle.dprc, 	/* Resource manager handle */
		type, 			/* Resource type */
		1, 			/* Number of resources */
		1, 			/* Base align */
		0, 			/* Options */
		&(dpsw->prp_egr.id), 	/* Address to store */
		"PRPID"); 		/* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* Initialize Parser profile */
	err = dpparser_init_profile(
		dpsw->handle.dpparser_egr,
		dpsw->prp_egr.id,
		NULL, 			/* Private command parameters */
		NULL);			/* Parser parameters structure */
	CHECK_COND_RETVAL(err == 0, err);

	/* Profile is in use, for destroy */
	dpsw->prp_egr.inuse = 1;

	return err;
}

static int dpsw_init_ctlu_prp_ing(struct dpsw *dpsw)
{
	int err = 0;
	char type[16];
	struct dpparser_profile_opt_cfg		parser_profile;

/************************ Physical ********************************************/

	dpparser_get_resource_str(dpsw->handle.dpparser_ing, type);

	/* Allocate resource */
	err = allocate_resource(
		dpsw->handle.dprc, 	/* Resource manager handle */
		type, 			/* Resource type */
		1, 			/* Number of resources */
		1, 			/* Base align */
		0, 			/* Options */
		&(dpsw->prp_phys_ing.id), 	/* Address to store */
		"PRPID"); 		/* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* Initialize Parser profile */
	err = dpparser_init_profile(
		dpsw->handle.dpparser_ing,
		dpsw->prp_phys_ing.id,
		NULL,
		NULL);
	CHECK_COND_RETVAL(err == 0, err);

	/* Profile is in use, for destroy */
	dpsw->prp_phys_ing.inuse = 1;

/************************ Virtual ********************************************/

	/* Allocate resource */
	err = allocate_resource(
		dpsw->handle.dprc, 	/* Resource manager handle */
		type, 			/* Resource type */
		1, 			/* Number of resources */
		1, 			/* Base align */
		0, 			/* Options */
		&(dpsw->prp_virt_ing.id), /* Address to store */
		"PRPID"); 		/* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* Initialize Parser profile */
	memset(&parser_profile, 0x0, sizeof(struct dpparser_profile_opt_cfg));
	parser_profile.num_of_disable_fd_err_report = 2;
	parser_profile.disable_fd_err_report[0] = HXS_IPV4;
	parser_profile.disable_fd_err_report[1] = HXS_IPV6;

	err = dpparser_init_profile(
		dpsw->handle.dpparser_ing,
		dpsw->prp_virt_ing.id,
		NULL,
		&parser_profile);	/* Parser parameters structure */
	CHECK_COND_RETVAL(err == 0, err);

	/* Profile is in use, for destroy */
	dpsw->prp_virt_ing.inuse = 1;

	return err;
}

static int dpsw_init_bman_bp(struct dpsw *dpsw, int id)
{
	/*
	 * Allocate dpbp
	 * Initialize dpbp
	 * dpbp_allocate_buffers
	 */
	int err = 0;
	struct dpbp_cfg dpbp_cfg;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpsw_buffer_pool_desc *buffer_pools;
	struct dpbp_hw_notification_cfg bp_notification_cfg;

	/*! Allocate DPBP */
	dpsw->dpbp[id] = dpbp_allocate();
	CHECK_COND_RETVAL(dpsw->dpbp[id], -EINVAL);

	/*! Init dpbp */
	dev_cfg.device = dpsw->handle.dprc;

	/* Init buffer pool */
	err = dpbp_init(dpsw->dpbp[id], &dpbp_cfg, &dev_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Set amq */
	dpmng_get_amq(&(dev_cfg.ctx.amq));

	err = dpbp_set_dev_ctx(dpsw->dpbp[id], &(dev_cfg.ctx));
	CHECK_COND_RETVAL(err == 0, err);

	/*! *Enable */
	dpbp_enable(dpsw->dpbp[id]);

	/*! Allocate buffres */
	buffer_pools = dpsw->buffer_pools;
	err = dpbp_allocate_buffers(
		dpsw->dpbp[id], 			/* Context */
	        buffer_pools[id].memory_type, 	/* PEB memory */
	        buffer_pools[id].memory_size, 	/* Memory size */
	        buffer_pools[id].buffer_size); 	/* Buffre size */

	/* Configure depletion thresholds */
	memset(&bp_notification_cfg, 0, sizeof(bp_notification_cfg));
	bp_notification_cfg.depletion_entry = 120;
	bp_notification_cfg.depletion_exit = 184;
	err = dpbp_set_hw_notifications(dpsw->dpbp[id], &bp_notification_cfg);
	CHECK_COND_RETVAL(err == 0, err, "ID[%d] interface %d - dpbp_set_hw_notifications() return error\n", dpsw->id, id);

	return err;
}

static int dpsw_init_bman_bps(struct dpsw *dpsw)
{
/*
 * 	Find number of buffer pools (num_of_pools)
 * 	for each buffer pool
 * 		-Allocate dpbp
 * 		-Initialize dpbp
 * 		-dpbp_allocate_buffers
 */
	int err = 0, i;

	/* dynamically initialize the size of SW based on no of ports */
	err = init_dpsw_buffer_pool(dpsw, dpsw->bp_per_if);
	CHECK_COND_RETVAL( err == 0 , err, "Failed to allocate PEB for buffer pools\n");

	if (dpsw->num_buffer_pools > IFP_MAX_NUM_OF_EXT_POOLS)
		return -EINVAL;

	for (i = 0; i < dpsw->num_buffer_pools; i++) {
		err = dpsw_init_bman_bp(dpsw, i);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int init_wq_void(struct dpsw *dpsw)
{
	int err = 0;

	err = init_wq_void_fq(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	err = init_wq_qpri(dpsw, &(dpsw->wq_void));
	CHECK_COND_RETVAL(err == 0, err);

	err = init_wq_qdr(dpsw, &(dpsw->wq_void));

	return err;
}

static int init_wq_void_fq(struct dpsw *dpsw)
{
	/**
	 -# Allocate FQID
	 -# Get software portal
	 -# Configure FQID
	 */
	int err;
	struct qbman_attr fqdesc;
	struct qbman_swp *swp;
	struct dpmng_amq amq;

	/* Allocate FQID */
	/* Get software portal */
	dpmng_get_swportal(dpsw->handle.dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -ENAVAIL);

	err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				"fq", /* Resource type */
				1, /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				&(dpsw->wq_void.fqid), /* Address */
				"FQID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* Get ICID */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	/* Configure FQID */
	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_fqctrl(&fqdesc,
		QBMAN_FQCTRL_HOLDACTIVE | QBMAN_FQCTRL_TAILDROP);
	qbman_fq_attr_set_icid(&fqdesc, amq.icid, amq.pl);

	qbman_fq_attr_set_tdthresh(&fqdesc, 0);

	err = qbman_fq_configure(swp, (uint32_t)(dpsw->wq_void.fqid), &fqdesc);

	return err;
}

static int init_wq_replic_fq(struct dpsw *dpsw)
{
	/**
	 -# Allocate FQID
	 -# Get software portal
	 -# Configure FQID
	 */

	int err;
	struct qbman_attr fqdesc;
	struct qbman_swp *swp;
	struct dpmng_amq amq;
	enum qbman_fq_schedstate_e ss;
	//uint32_t		ss;
	struct qbman_attr state;

	/* Get software portal */
	dpmng_get_swportal(dpsw->handle.dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -ENAVAIL);

	/*! Allocate FQID */
	err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				"fq", /* Resource type */
				1, /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				&(dpsw->wq_replic.fqid), /* Address */
				"FQID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* Get AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	/* Configure FQID */
	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_fqctrl(&fqdesc, QBMAN_FQCTRL_HOLDACTIVE);
	qbman_fq_attr_set_icid(&fqdesc, amq.icid, amq.pl);
	qbman_fq_attr_set_mctl(&fqdesc, amq.bdi, 0, 0, 0, 0);

	/* dest_wq = 0xFF0 << 3 = 0x7F80 */
	qbman_fq_attr_set_destwq(&fqdesc, DPSW_REPLIC_CHID << 3);
	err = qbman_fq_configure(swp, (uint32_t)(dpsw->wq_replic.fqid),
					&fqdesc);
	CHECK_COND_RETVAL(err == 0, err);

	err = qbman_fq_query_state(swp, (uint32_t)dpsw->wq_replic.fqid,
					&state);
	CHECK_COND_RETVAL(err == 0, err);

	ss = (enum qbman_fq_schedstate_e)qbman_fq_state_schedstate(&state);
	if (ss == qbman_fq_schedstate_parked) {
		/*! Override parked mode - frames can be dequeued by WRIOP */
		err = qbman_swp_fq_schedule(
			swp, /* Software portal */
			(uint32_t)dpsw->wq_replic.fqid);/* Frame queue */
	}

	return err;
}

static int init_wq_qpri(struct dpsw *dpsw, struct dpsw_wq *wq)
{
	int err;
	struct qbman_swp *swp;

	dpmng_get_swportal(dpsw->handle.dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -ENAVAIL);

	/* QPRI         Priority Record */
	err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				"qpr", /* Resource type */
				1, /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				&(wq->qprid), /* Address */
				"QPR"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* map QPri->FQID*/
	err = qbman_qpr_configure(swp, /* Software portal */
					(uint16_t)(wq->qprid), /* QPRIID*/
					(uint32_t)(wq->fqid), /* FQID base */
					1, /* distribution */
					0); /* CGID */

	return err;
}

static int init_wq_qdr(struct dpsw *dpsw, struct dpsw_wq *wq)
{
	int err, i;
	uint16_t qprids[16];
	struct qbman_swp *swp;

	dpmng_get_swportal(dpsw->handle.dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -ENAVAIL);

	/* Allocate QDID */
	err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				"qd", /* Resource type */
				1, /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				&(wq->qdid), /* Address */
				"QDID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* Initialize QPR array */
	for (i = 0; i < DPSW_MAX_PRIORITIES; i++) {
		qprids[i] = (uint16_t)wq->qprid;
	}

	/* (QDR) Queuing Destination Record Configure */
	err = qbman_qd_configure(swp, /* Software portal */
					(uint16_t)(wq->qdid), /* QDID */
					qprids); /* Array of QPRID's */

	return err;
}

/**************************************************************************//**
 @Collection    L2 Switch Implementation

 @{
 *//***************************************************************************/
struct dpsw *dpsw_allocate()
{
	struct dpsw *dpsw = NULL;

	dpsw = (struct dpsw *)fsl_malloc(sizeof(struct dpsw));

	if (dpsw != NULL)
		memset(dpsw, 0, sizeof(struct dpsw));
	return dpsw;
}

void dpsw_deallocate(struct dpsw *dpsw)
{
	if (dpsw != NULL)
		fsl_free(dpsw);
}

int dpsw_init(struct dpsw *dpsw,
	const struct dpsw_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
	int i, err;
	struct dpsw_cfg dst_cfg;

	pr_info("dpsw_init\n");

	/* Verify parameters integrity */
	err = init_params_integrity(cfg, &dst_cfg);
	CHECK_COND_GOTO(err == 0, clean_up, "init_params_integrity : %d)\n", err);

	/* Allocate MC L2 switch Memory */
	err = init_allocate(dpsw, &dst_cfg);
	CHECK_COND_GOTO(err == 0, clean_up, "init_allocate : %d)\n", err);

	/* Initialize data base */
	init_save_params(dpsw, &dst_cfg, dev_cfg);

	/* Internal L2 switch data structure */
	init_internal_database(dpsw);

	err = init_allocate_resources(dpsw);
	CHECK_COND_GOTO(err == 0, clean_up, "init_allocate_resources : %d)\n", err);

	/* Init L2 switch */
	err = init_infrastructure(dpsw);
	CHECK_COND_GOTO(err == 0, clean_up, "init_infrastructure : %d)\n", err);

	/* Set VLAN configuration */
	err = init_vlan(dpsw);
	CHECK_COND_GOTO(err == 0, clean_up, "init_vlan : %d)\n", err);

	/* Set defaults */
	err = init_default(dpsw);
	CHECK_COND_GOTO(err == 0, clean_up, "init_default : %d)\n", err);

	/* Enable L2 switch */
	err = dpsw_enable(dpsw);
	CHECK_COND_GOTO(err == 0, clean_up, "dpsw_enable : %d)\n", err);

	for (i = 0; i < DPSW_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpsw->irqs[i]), MC_IRQ_TYPE_MSI);

	/* Debugging */
	dpsw_dump(dpsw); /* L2 Switch database */

	return err;

clean_up:
	dpsw_destroy(dpsw);
	return err;
}

static int init_params_integrity(const struct dpsw_cfg *src_cfg,
	struct dpsw_cfg *dst_cfg)
{
	memcpy(dst_cfg, src_cfg, sizeof(struct dpsw_cfg));

	/* Integrity */

	dst_cfg->adv.max_fdbs =
		(dst_cfg->adv.max_fdbs == 0) ?
			DEFAULT_MAX_FDB : dst_cfg->adv.max_fdbs;

	dst_cfg->adv.max_fdb_entries =
		(dst_cfg->adv.max_fdb_entries == 0) ?
			DEFAULT_NUM_FBD_ENTRIES : dst_cfg->adv.max_fdb_entries;

	dst_cfg->adv.max_fdb_mc_groups =
		(dst_cfg->adv.max_fdb_mc_groups == 0) ?
			DEFAULT_FDB_MC_GROUPS : dst_cfg->adv.max_fdb_mc_groups;

	dst_cfg->adv.max_vlans =
		(dst_cfg->adv.max_vlans == 0) ?
			DEFAULT_MAX_VLAN : dst_cfg->adv.max_vlans;

	dst_cfg->adv.max_meters_per_if =
		(dst_cfg->adv.max_meters_per_if == 0) ?
			DEFAULT_MAX_METERS : dst_cfg->adv.max_meters_per_if;

        dst_cfg->adv.fdb_aging_time =
                (dst_cfg->adv.fdb_aging_time == 0) ?
                        DEFAULT_FDB_AGING_TIME : dst_cfg->adv.fdb_aging_time;

	/* Range */
	if ((dst_cfg->num_ifs == 0) || (dst_cfg->num_ifs >= DPSW_MAX_IF))
		return -EINVAL; /* Invalid argument */

	if ((dst_cfg->adv.max_vlans == 0)
		|| (dst_cfg->adv.max_vlans > DPSW_MAX_VLAN))
		return -EINVAL; /* Invalid argument */

	if ((dst_cfg->adv.max_fdbs == 0)
		|| (dst_cfg->adv.max_fdbs > DPSW_MAX_FDB))
		return -EINVAL; /* Invalid argument */
	return 0;
}

static int init_allocate(struct dpsw *dpsw, const struct dpsw_cfg *cfg)
{
	/**
	 -# Interface
	 -# VLAN
	 -# FDB
	 -# memset
	 */
	int err;

	/*! Interface dataBase */
	err = init_allocate_iface(dpsw, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/*! VLAN dataBase */
	err = init_allocate_vlan(dpsw, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/*! FDB dataBase */
	err = init_allocate_fdb(dpsw, cfg);

	return err;
}

static int init_allocate_iface(struct dpsw *dpsw, const struct dpsw_cfg *cfg)
{
	/*! Allocate Interface dataBase */
	dpsw->iface = (struct dpsw_if *)fsl_malloc(sizeof(struct dpsw_if) * /*!< Interface dateBase size */
	cfg->num_ifs); /*!< Number of Interfaces */
	CHECK_COND_RETVAL(dpsw->iface, -ENOMEM);/*!< Out of memory */

	/*! Reset dataBase*/
	memset(dpsw->iface, 0x0, sizeof(struct dpsw_if) * cfg->num_ifs);

	return 0;
}

static int init_allocate_vlan(struct dpsw *dpsw, const struct dpsw_cfg *cfg)
{
	/*
	 * Allocate hmap
	 * go over each vlan
	 *      allocate  struct dpsw_vlan + struct dpsw_vlan_if
	 *      set data into hmap
	 */
	int err = 0, i;
	struct dpsw_vlan *vlan;

	/*! Allocate hmap */
	dpsw->hmap_vlan = hmap_create(cfg->adv.max_vlans, 2);
	CHECK_COND_RETVAL(dpsw->hmap_vlan, -ENOMEM); /*!< Out of memory */

	for (i = 0; i < cfg->adv.max_vlans; i++) {
		/*! allocate  struct dpsw_vlan */
		vlan = fsl_malloc(sizeof(struct dpsw_vlan));
		CHECK_COND_RETVAL(vlan, -ENOMEM); /*!< Out of memory */

		memset(vlan, 0x0, sizeof(struct dpsw_vlan));

		/*! struct dpsw_vlan_if */
		vlan->iface = fsl_malloc(
			sizeof(struct dpsw_vlan_if) * cfg->num_ifs);
		CHECK_COND_RETVAL(dpsw->iface, -ENOMEM); /*!< Out of memory */

		memset(vlan->iface, 0x0,
			sizeof(struct dpsw_vlan_if) * cfg->num_ifs);

		/*! set data into hmap */
		err = hmap_set_data(dpsw->hmap_vlan, i, vlan);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int init_allocate_fdb(struct dpsw *dpsw, const struct dpsw_cfg *cfg)
{
	/*
	 * Allocate hmap
	 * go over each fdb
	 *      allocate  struct dpsw_fdb
	 *      set data into hmap
	 */
	int err = 0, i;
	struct dpsw_fdb *fdb;

	/*! Allocate hmap */
	dpsw->hmap_fdb = hmap_create(cfg->adv.max_fdbs, 2);
	CHECK_COND_RETVAL(dpsw->hmap_fdb, -ENOMEM); /*!< Out of memory */

	for (i = 0; i < cfg->adv.max_fdbs; i++) {
		/*! allocate  struct dpsw_fdb */
		fdb = fsl_malloc(sizeof(struct dpsw_fdb));
		CHECK_COND_RETVAL(fdb, -ENOMEM); /*!< Out of memory */

		memset(fdb, 0x0, sizeof(struct dpsw_fdb));

		/*! set data into hmap */
		err = hmap_set_data(dpsw->hmap_fdb, i, fdb);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static void init_save_params(struct dpsw *dpsw,
	const struct dpsw_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
	unsigned int i,j, num_ifs; /**< Interface iterator */
	struct dpsw_if *iface; /**< Interface database */

	/* Save L2 Switch configuration */
	/* options */
	dpsw->multicast_enable = !(cfg->adv.options & DPSW_OPT_MULTICAST_DIS);
	dpsw->flooding_enable = !(cfg->adv.options & DPSW_OPT_FLOODING_DIS);
	dpsw->ctrl_if_enable = !(cfg->adv.options & DPSW_OPT_CTRL_IF_DIS);
	dpsw->flooding_metering_enable =
		!(cfg->adv.options & DPSW_OPT_FLOODING_METERING_DIS);
	dpsw->metering_enable = !!(cfg->adv.options & DPSW_OPT_METERING_EN);
	dpsw->metering_enable = (cfg->adv.max_meters_per_if == 0) ?
		0 : dpsw->metering_enable;
	dpsw->bp_per_if = !!(cfg->adv.options & DPSW_OPT_BP_PER_IF);
	dpsw->lag_enable = !(cfg->adv.options & DPSW_OPT_LAG_DIS);

	/* Parameters */
	dpsw->max_vlans = cfg->adv.max_vlans; /* Max VLAN's */
	dpsw->max_fdbs = cfg->adv.max_fdbs; /* Max FDB's */
	dpsw->max_fdb_entries = cfg->adv.max_fdb_entries;/* FDB Entries */
	dpsw->max_fdb_mc_groups = cfg->adv.max_fdb_mc_groups;/* MC groups */
	dpsw->fdb_aging_time = cfg->adv.fdb_aging_time; /* aging */
	dpsw->num_ifs = cfg->num_ifs; /* Number ifaces */
	dpsw->max_acls = cfg->num_ifs; /* Number of ACLs */
	dpsw->max_meters_per_if = cfg->adv.max_meters_per_if;
	dpsw->component_type = cfg->adv.component_type;
	dpsw->flooding_cfg = cfg->adv.flooding_cfg;
	dpsw->broadcast_cfg = cfg->adv.broadcast_cfg;
	dpsw->mem_size = cfg->adv.mem_size;

	dpsw->num_lag_groups = 0;
	for (i=0;i<DPSW_MAX_LAG;i++) {
		dpsw->lag_cfg[i].group_id = (uint8_t)i+1;
		num_ifs = 0;
		if (cfg->adv.lag[i]!=0)
		{
			for (j=0;j<cfg->num_ifs;j++)
				if (((1<<j)&cfg->adv.lag[i])==(1<<j))
				{
					dpsw->lag_cfg[i].if_id[num_ifs] = (uint8_t)j;
					num_ifs++;
				}
			dpsw->num_lag_groups++;
		}
		dpsw->lag_cfg[i].num_ifs = (uint8_t)num_ifs;
	}

	/* Save MC information */
	dpsw->handle.dprc = dev_cfg->device;
	dpsw->id = dev_cfg->id;
	memcpy(&(dpsw->dev_ctx), &(dev_cfg->ctx), sizeof(struct dpmng_dev_ctx));

	/* Init interface deafults */
	for (i = 0; i < cfg->num_ifs; i++) {
		iface = &(dpsw->iface[i]); /*! Get interface */
		iface->multicast_enable = 1; /* multicast enable */
		iface->broadcast_enable = 1; /* broadcast enable */
		iface->flooding_enable = 1; /* flooding enable */
		iface->learning_requested = 0;
	}
}

static void init_internal_database(struct dpsw *dpsw)
{
	/**
	 *      Traffic class mapping
	 *      Interrupts
	 *      Handles
	 */
	int i;
	struct dpsw_tx_selection_cfg ts;
	struct dpsw_if *iface;

	/*! L2 switch dataBase */
	dpsw->mirr_if_id = 0; /*! default mirroring interface */

	/*! Interface dBase*/
	ts.priority_selector = DPSW_PRIORITY_SELECTOR_PCP;/* Priority Code
	 Point */
	memset(ts.tc_id, 0x0, DPSW_MAX_PRIORITIES);
	for (i = 0; i < dpsw->num_ifs; i++) {
		/*! obtain if */
		iface = &(dpsw->iface[i]);

		/*! accept VLANs that include in this port Port*/
		iface->accept_all_vlan = 0;

		/*! Accept tag and un-tag */
		iface->admit_untagged = DPSW_ADMIT_ALL;

		/*! acl reference */
		iface->acl_id = DPSW_ACL_VOID;

		iface->link_cfg.options = 0;
		/* Auto-Negotiation */
		iface->link_cfg.options |= DPSW_LINK_OPT_AUTONEG;

		/* IRQ */
		iface->irq.pending = 0;

		/* flow control */
		iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
	}

	/*! Handles */
	dpsw_init_handle(dpsw);
}

static int init_allocate_resources(struct dpsw *dpsw)
{
	int err = 0;

	/* IFP */
	err = init_allocate_resources_ifp(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/* Policer profile */
	err = init_allocate_resources_plid(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/* Flooding Policer profile */
	err = init_allocate_resources_flooding_plid(dpsw);

	return err;
}

static int init_allocate_resources_ifp(struct dpsw *dpsw)
{
	int err, i;
	int id[DPSW_MAX_IF];
        uint32_t num_res;
	char type[16];

	/*! Allocate IFP */
        num_res = (uint32_t)dpsw->num_ifs;
	snprintf(type, sizeof(type), "ifp.wr%d", 0 ); /* WRIOP ID */
        err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
                                type, /* Resource type */
                                num_res, /* Number of resources*/
                                1, /* Base align */
                                0, /* Options */
                                &(id[0]), /* Address to store */
                                "IFPID"); /* Error string */
        CHECK_COND_RETVAL(err == 0, err);

        /* Copy IFP to internal database */
        for (i = 0; i < dpsw->num_ifs; i++)
        	dpsw->iface[i].ap.ifpid = id[i];

        return err;
}


static int init_allocate_resources_plid(struct dpsw *dpsw)
{
	int err = 0, j;
	uint16_t i;
	struct dpsw_if	*iface;
	struct dpsw_metering *metering;
	int id[DPSW_MAX_IF * DPSW_MAX_TC];
	uint32_t num_res;
        char type[16];

	if (dpsw->metering_enable == 0)
		return err;

	/* Allocate policer ids */
        num_res = (uint32_t)dpsw->num_ifs * dpsw->max_meters_per_if;
        snprintf(type, sizeof(type), "plcr.wr%d.ctlui", 0 ); /* WRIOP ID */
        err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
                                type, /* Resource type */
                                num_res, /* Number of resources*/
                                1, /* Base align */
                                0, /* Options */
                                &(id[0]), /* Address to store */
                                "PLCR"); /* Error string */
        CHECK_COND_RETVAL(err == 0, err);


	for(i = 0; i < dpsw->num_ifs; i++) {
		iface = &(dpsw->iface[i]);

		/*! Allocate hmap */
		iface->hmap_metering = hmap_create(dpsw->max_meters_per_if, 1);
		CHECK_COND_RETVAL(iface->hmap_metering, -ENOMEM); /*!< Out of memory */

	        for (j = 0; j < dpsw->max_meters_per_if; j++) {

	        	/* allocate  struct dpsw_metering */
	        	metering = fsl_malloc(sizeof(struct dpsw_metering));
	        	CHECK_COND_RETVAL(metering, -ENOMEM); /*!< Out of memory */

	                metering->plid = id[i * dpsw->max_meters_per_if + j];

	                /*! set data into hmap */
	                err = hmap_set_data(iface->hmap_metering, j, metering);
	                CHECK_COND_RETVAL(err == 0, err);
	        }
	}
	return err;
}

static int init_allocate_resources_flooding_plid(struct dpsw *dpsw)
{
	int err = 0, i;
	int id[DPSW_MAX_IF];
        uint32_t num_res;
        char type[16];

        if (dpsw->flooding_metering_enable == 0)
        	return err;

	/*! Allocate Ingress policer */
        num_res = (uint32_t)dpsw->num_ifs;
        snprintf(type, sizeof(type), "plcr.wr%d.ctlui", 0 ); /* WRIOP ID */
        err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
                                type, /* Resource type */
                                num_res, /* Number of resources*/
                                1, /* Base align */
                                0, /* Options */
                                &(id[0]), /* Address to store */
                                "PLCR"); /* Error string */
        CHECK_COND_RETVAL(err == 0, err);

        /* Copy IFP to internal database */
        for (i = 0; i < dpsw->num_ifs; i++)
        	dpsw->iface[i].flooding_plid = id[i];

	return err;
}

static int init_infrastructure(struct dpsw *dpsw)
{
	/*
	 *      BMan/Buffer Pool
	 *      QMan/CEETM
	 *      EIOP/MAC/IFP
	 *      CTLU/FALU/VLAN/FDB
	 */
	int err;
	uint16_t i; /**< Interface iterator */

	/* Buffer Pool */
	err = dpsw_init_bman_bps(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "swlib_init_bman_bp : %d)\n", err);

	/* CTLU */
	err = init_ctlu(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu : %d)\n", err);

	/* Error queue */
	err = init_wq_void(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "init_wq_void : %d)\n", err);

	/* CEETM Interface */
	for (i = 0; i < dpsw->num_ifs; i++) {
		err = init_ceetm_if(dpsw, i);
		CHECK_COND_RETVAL(err == 0, err);
	}

	for (i = 0; i < DPSW_MAX_LAG; i++)
	{
		if (dpsw->lag_cfg[i].num_ifs > 0)
		{
			err = dpsw_if_lag_configure(dpsw,&dpsw->lag_cfg[i]);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}

	/* Control interface */
	err = init_ctrl_if(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "init_ctrl_if : %d)\n", err);

	/* ifp */
	for (i = 0; i < dpsw->num_ifs; i++) {
		err = init_if_eiop(dpsw, i);
		CHECK_COND_RETVAL(err == 0, err, "init_if_eiop : %d)\n", err);
	}

	if (dpsw->ctrl_if_enable)
		ctrl_if_set_tx_confirmation(dpsw->ctrl_if, 1);

	/* Replication */
	err = init_replic(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "init_replic : %d)\n", err);

	return err;
}

static int init_ctlu(struct dpsw *dpsw)
{
	int err;

	/* CTLU VLAN Table */
	err = init_ctlu_vlan(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_vlan : %d)\n", err);

	/* Key Generation FALU->VLAN*/
	err = init_ctlu_vlan_kg(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_vlan_kg : %d)\n", err);

	/* Key Generation VLAN->MAC */
	err = init_ctlu_fdb_kg(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_fdb_kg : %d)\n", err);

	if(dpsw->lag_enable)
	{
		/* Key Generation LAG */
		err = init_ctlu_lag_kg(dpsw);
		CHECK_COND_RETVAL(err == 0, err, "init_ctlu_lag_kg : %d)\n", err);
	}

	/* Policy */
	err = init_ctlu_policy(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_policy : %d)\n", err);

	err = dpsw_init_ctlu_prp(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "dpsw_init_ctlu_prp : %d)\n", err);

	/* ACL */
	err = init_ctlu_acl(dpsw);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_acl : %d)\n", err);

	return err;
}

static int init_replic(struct dpsw *dpsw)
{
	int err;

	/* Unicast */
	err = init_replic_unicast(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/* Multicast */
	err = init_replic_multicast(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/* Flooding */
	err = init_replic_flooding(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/* Broadcast */
	err = init_replic_broadcast(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/* Replication Frame Queue */
	err = init_wq_replic_fq(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/* Replication Queue Priority */
	err = init_wq_qpri(dpsw, &(dpsw->wq_replic));
	CHECK_COND_RETVAL(err == 0, err);

	/* Replication Queue (QDID) */
	err = init_wq_qdr(dpsw, &(dpsw->wq_replic));

	return err;
}

static int init_replic_unicast(struct dpsw *dpsw)
{
	/*
	 *      for each interface
	 *              allocate rrid quartet
	 *              configure quartet
	 */
	int err = 0, qdid;
	uint16_t	i;
	struct dpsw_if *iface;

	for (i = 0; i < dpsw->num_ifs; i++) {
		/*! Obtain interface */
		iface = &(dpsw->iface[i]);

		err = get_iface_qdid(dpsw, i, &qdid);
		CHECK_COND_RETVAL(err == 0, err);

		/*! Init quartet */
		err = replic_init_quartet(dpsw, /*! context */
						&(iface->rrid), /* quartet */
						qdid, 	/* Root QDID */
						0); 	/* Next root RRID*/
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int init_replic_multicast(struct dpsw *dpsw)
{
	int err = 0, i, j;
	struct dpsw_fdb *fdb;
	struct dpsw_replic *replic;

	/* Check multicast is enabled */
	if (dpsw->multicast_enable == 0)
		return err;

	/* Init multicast replication per fdb */
	for (i = 0; i < dpsw->max_fdbs; i++) {
		/*! Obtain FDB */
		err = hmap_get_data(dpsw->hmap_fdb, i, (hmap_data *)&fdb);
		CHECK_COND_RETVAL(err == 0, err);

		/* Create multicast hmap */
		fdb->hmap_mcast = hmap_create(dpsw->max_fdb_mc_groups, 6);
		CHECK_COND_RETVAL(fdb->hmap_mcast, -ENOMEM);

		for (j = 0; j < dpsw->max_fdb_mc_groups; j++) {
			/*! Allocate replic */
			replic = fsl_malloc(sizeof(struct dpsw_replic));
			CHECK_COND_RETVAL(replic, -ENOMEM);

			/*! Init replic */
			err = replic_init(dpsw, replic);
			CHECK_COND_RETVAL(err == 0, err);

			/*! set hmap data */
			err = hmap_set_data(fdb->hmap_mcast, j, replic);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}
	return err;
}

static int init_replic_flooding(struct dpsw *dpsw)
{
	struct dpsw_vlan *vlan;
	struct dpsw_fdb *fdb;
	int err = 0, i;

	/* Check flooding is enabled */
	if (dpsw->flooding_enable == 0)
		return err;

	/* Init flooding replication stuff */
	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_FDB) {
		for (i = 0; i < dpsw->max_fdbs; i++) {
			err = hmap_get_data(dpsw->hmap_fdb, i, (void **)&fdb);
			if ((err != 0) || (fdb == NULL)) {
				pr_warn("could not get FDB %d\n", i);
				continue;
			}

			err = replic_init(dpsw, &(fdb->flooding));
			CHECK_COND_RETVAL(err == 0, err);
		}
	} else {
		for (i = 0; i < dpsw->max_vlans; i++) {
			err = hmap_get_data(dpsw->hmap_vlan, i, (void **)&vlan);
			CHECK_COND_RETVAL(err == 0, err);

			err = replic_init(dpsw, &(vlan->flooding));
			CHECK_COND_RETVAL(err == 0, err);
		}
	}
	return err;
}

static int if_in_list(uint16_t *if_id, uint16_t num_ifs, int interface)
{
	int i;

	for (i = 0; i < num_ifs; i++)
		if (if_id[i] == interface)
			return 1;
	return 0;
}

static int init_replic_broadcast(struct dpsw *dpsw)
{
	/*
	 *      -Initialize replication database
	 *      -Create replication link list
	 */
	struct dpsw_fdb *fdb;
	int err = 0, i;

	if (dpsw->broadcast_cfg == DPSW_BROADCAST_PER_FDB) {
		for (i = 0; i < dpsw->max_fdbs; i++) {
			err = hmap_get_data(dpsw->hmap_fdb, i, (hmap_data *)&fdb);
			if ((err != 0) || (fdb == NULL)) {
				pr_warn("could not get FDB %d\n", i);
				continue;
			}

			/* Initialize replication database for FDB #i */
			err = replic_init(dpsw, &(fdb->broadcast));
			CHECK_COND_RETVAL(err == 0, err);
		}
	} else {
		/* Initialize replication database */
		err = replic_init(dpsw, &(dpsw->broadcast));
		CHECK_COND_RETVAL(err == 0, err);
	}

	return err;
}

static int add_if_to_replic_broadcast(struct dpsw *dpsw, int if_id)
{
	struct dpsw_vlan_if_cfg flood_cfg = {0};
	struct dpsw_replic *replic;
	struct dpsw_if *iface;
	int iter_status, iter;
	struct dpsw_fdb *fdb;
	uint16_t fdb_id;
	int err = 0;
	uint8_t key[2];

	iface = &(dpsw->iface[if_id]);

	if (iface->lag_enabled && !ceetm_if_is_lag_master(iface->ceetm_if)) {
		pr_info("LAG: no broadcast replic entry for slave interface %d\n", if_id);
		return 0;
	}

	if (!iface->broadcast_enable)
		return err;

	if (dpsw->broadcast_cfg == DPSW_BROADCAST_PER_FDB) {
		/* Search all FDBs to check in which one the provided if_id is
		 * contained in
		 */
		iter_status = hmap_get_start_iterator(dpsw->hmap_fdb, &iter);
		while (iter_status == 0) {
			iter_status = hmap_iterate(dpsw->hmap_fdb, &iter, key,
							(hmap_data *)&fdb);
			fdb_id = MAKE_UINT16(key[0], key[1]);

			/* If the interface is not in the broadcast egress flooding
			 * domain of this FDB, skip
			 */
			if (!if_in_list(fdb->bcast_ifs, fdb->bcast_num_ifs, if_id))
				continue;

			/* Build the broadcast configuration */
			replic = &fdb->broadcast;
			flood_cfg.fdb_id = fdb_id;
			flood_cfg.num_ifs = 1;
			flood_cfg.if_id[0] = (uint16_t)if_id;

			/* Add the interface to this FDB's broadcast replicator */
			err = replic_add(dpsw, replic, &flood_cfg);
			if (err) {
				pr_warn("DPSW: cannot add IF%d to FDB#%d broadcast replicator... continue\n",
					if_id, fdb_id);
				continue;
			}

			pr_debug("[FDB #%d] [%10s] [%10s] the following %d interface(s): %d\n",
				 flood_cfg.fdb_id, "broadcast", "added", 1, flood_cfg.if_id[0]);
		}
	} else {
		flood_cfg.num_ifs = 1;
		flood_cfg.if_id[0] = (uint16_t)if_id;
		err = replic_add(dpsw, &(dpsw->broadcast), &flood_cfg);
	}

	return err;
}

static int remove_if_from_replic_broadcast(struct dpsw *dpsw, int if_id)
{
	struct dpsw_vlan_if_cfg if_cfg = {0};
	struct dpsw_replic *replic;
	int iter_status, iter;
	struct dpsw_fdb *fdb;
	uint16_t fdb_id;
	uint8_t key[2];
	int err = 0;

	if (dpsw->broadcast_cfg == DPSW_BROADCAST_PER_FDB) {
		/* Search all FDBs to check in which one the provided if_id is
		 * contained in
		 */
		iter_status = hmap_get_start_iterator(dpsw->hmap_fdb, &iter);
		while (iter_status == 0) {
			iter_status = hmap_iterate(dpsw->hmap_fdb, &iter, key,
							(hmap_data *)&fdb);
			fdb_id = MAKE_UINT16(key[0], key[1]);

			/* If the interface is not in the broadcast egress flooding
			 * domain of this FDB, skip
			 */
			if (!if_in_list(fdb->bcast_ifs, fdb->bcast_num_ifs, if_id))
				continue;

			/* Build the broadcast configuration */
			replic = &fdb->broadcast;
			if_cfg.fdb_id = fdb_id;
			if_cfg.num_ifs = 1;
			if_cfg.if_id[0] = (uint16_t)if_id;

			/* Remove the interface to this FDB's broadcast replicator */
			err = replic_remove(dpsw, replic, &if_cfg);
			if (err) {
				pr_warn("DPSW: cannot remove IF%d from FDB#%d broadcast replicator... continue\n",
					if_id, fdb_id);
				continue;
			}
			pr_debug("[FDB #%d] [%10s] [%10s] the following %d interface(s): %d\n",
				 if_cfg.fdb_id, "broadcast", "removed", 1, if_cfg.if_id[0]);
		}
	} else {
		if_cfg.num_ifs = 1;
		if_cfg.if_id[0] = (uint16_t)if_id;

		err = replic_remove(dpsw, &dpsw->broadcast, &if_cfg);
		CHECK_COND_RETVAL(err == 0, err, "replic_remove returned error\n");
	}

	return err;
}

static int remove_if_from_replic_flooding(struct dpsw *dpsw, int if_id)
{
	struct dpsw_vlan_if_cfg if_cfg = {0};
	int vlan_iterator, iter, iter_status;
	struct dpsw_replic *replic;
	struct dpsw_vlan *vlan;
	struct dpsw_fdb *fdb;
	uint16_t fdb_id;
	uint8_t key[2];
	int err;

	if( dpsw->flooding_enable==0 )
		return 0;

	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_FDB) {
		/* Search all FDBs to check in which one the provided if_id is
		 * contained in
		 */
		iter_status = hmap_get_start_iterator(dpsw->hmap_fdb, &iter);
		while (iter_status == 0) {
			iter_status = hmap_iterate(dpsw->hmap_fdb, &iter, key,
						   (hmap_data *)&fdb);
			fdb_id = MAKE_UINT16(key[0], key[1]);

			/* If the interface is not in the broadcast egress flooding
			 * domain of this FDB, skip
			 */
			if (!if_in_list(fdb->flooding_ifs, fdb->flooding_num_ifs, if_id))
				continue;

			/* Build the flooding configuration */
			replic = &fdb->flooding;
			if_cfg.fdb_id = fdb_id;
			if_cfg.num_ifs = 1;
			if_cfg.if_id[0] = (uint16_t)if_id;

			/* Remove the interface to this FDB's flooding replicator */
			err = replic_remove(dpsw, replic, &if_cfg);
			if (err) {
				pr_warn("DPSW: cannot remove IF%d from FDB#%d flooding replicator... continue\n",
					if_id, fdb_id);
				continue;
			}

			pr_debug("[FDB #%d] [%10s] [%10s] the following %d interface(s): %d\n",
				 if_cfg.fdb_id, "flooding", "removed", 1, if_cfg.if_id[0]);
		}
	} else {
		/* DPSW_FLOODING_PER_VLAN */
		iter_status = hmap_get_start_iterator(dpsw->hmap_vlan, &vlan_iterator);
		while (iter_status == 0) {
			iter_status = hmap_iterate(dpsw->hmap_vlan, &vlan_iterator, key,
						   (hmap_data *)&vlan);
			if (vlan->iface[if_id].assigned && vlan->iface[if_id].flooding_enable) {
				memset(&if_cfg, 0, sizeof(if_cfg));
				if_cfg.num_ifs = 1;
				if_cfg.if_id[0] = (uint16_t)if_id;
				err = replic_remove(dpsw, &(vlan->flooding), &if_cfg);
				if (err) {
					pr_warn("DPSW: cannot remove IF%d from flooding replicator... continue\n", if_id);
					continue;
				}
			}
		}
	}

	return 0;
}

static int add_if_to_replic_flooding(struct dpsw *dpsw, int if_id)
{
	int vlan_iterator, iter, iter_status;
	struct dpsw_vlan_if_cfg if_cfg;
	struct dpsw_replic *replic;
	struct dpsw_vlan *vlan;
	struct dpsw_fdb *fdb;
	uint16_t fdb_id;
	uint8_t key[2];
	int err = 0;

	memset(&if_cfg, 0, sizeof(if_cfg));
	if_cfg.num_ifs = 1;
	if_cfg.if_id[0] = (uint16_t)if_id;

	if( dpsw->flooding_enable==0 )
		return 0;

	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_FDB) {
		/* Search all FDBs to check in which one the provided if_id is
		 * contained in
		 */
		iter_status = hmap_get_start_iterator(dpsw->hmap_fdb, &iter);
		while (iter_status == 0) {
			iter_status = hmap_iterate(dpsw->hmap_fdb, &iter, key,
						   (hmap_data *)&fdb);
			fdb_id = MAKE_UINT16(key[0], key[1]);

			/* If the interface is not in the broadcast egress flooding
			 * domain of this FDB, skip
			 */
			if (!if_in_list(fdb->flooding_ifs, fdb->flooding_num_ifs, if_id))
				continue;

			/* Build the flooding configuration */
			replic = &fdb->flooding;
			if_cfg.fdb_id = fdb_id;
			if_cfg.num_ifs = 1;
			if_cfg.if_id[0] = (uint16_t)if_id;

			/* Add the interface to this FDB's flooding replicator */
			err = replic_add(dpsw, replic, &if_cfg);
			if (err) {
				pr_warn("DPSW: cannot add IF%d to FDB#%d flooding replicator... continue\n",
					if_id, fdb_id);
				continue;
			}

			pr_debug("[FDB #%d] [%10s] [%10s] the following %d interface(s): %d\n",
				 if_cfg.fdb_id, "flooding", "added", 1, if_cfg.if_id[0]);
		}
	} else {
		/* DPSW_FLOODING_PER_VLAN */
		iter_status = hmap_get_start_iterator(dpsw->hmap_vlan, &vlan_iterator);
		while (iter_status == 0) {
			iter_status = hmap_iterate(dpsw->hmap_vlan, &vlan_iterator, key,
						   (hmap_data *)&vlan);
			if (vlan->iface[if_id].assigned && vlan->iface[if_id].flooding_enable) {
				err = replic_add(dpsw, &(vlan->flooding), &if_cfg);
				if( err ) {
					pr_warn("DPSW: cannot add IF%d to flooding replicator... continue\n", if_id);
					continue;
				}
			}
		}
	}

	return err;
}

static int init_if_eiop(struct dpsw *dpsw, uint16_t if_id)
{
	/* PaRser Profile (PRP)*/
	int err;

	/* InterFace Profile (IFP)*/
	err = init_if_eiop_ifp(dpsw, if_id);
	CHECK_COND_RETVAL(err == 0, err, "init_if_eiop_ifp : %d)\n", err);

	/*! DPQOS */
	err = init_if_eiop_qos(dpsw, if_id);

	return err;
}

static int init_if_eiop_qos(struct dpsw *dpsw, uint16_t if_id)
{
	/*!
	 *      -Allocate dpqos object
	 *      -Init QoS mapping
	 *              a)VPRI
	 *              b)DSCP
	 * */
	int err = 0, i;
	struct dpsw_if *iface;
	struct dpqos_rule rule;
	struct dpqos_action action;

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! Allocate dpqos object */
	iface->dpqos = dpqos_init(dpsw->handle.dpqos_ing, iface->ap.ifpid);
	CHECK_COND_RETVAL(iface->dpqos, -EFAULT);

	/* Init VPRI QoS mapping */
	memset(&rule, 0x0, sizeof(struct dpqos_rule));
	memset(&action, 0x0, sizeof(struct dpqos_action));
	rule.method = DPQOS_METHOD_BASED_ON_VLAN;
	action.options = DPQOS_ACTION_SET_QPRI;
	action.next_action = DPQOS_ACTION_DONE;

	for (i = 0; i < 8; i++) {
		/*! Set QoS mapping */
		rule.priority = i;
		action.qpri = i;

		/*! add an entry */
		err = dpqos_add_rule(iface->dpqos, &rule, &action);
		if (err != 0)
			break;
	}

	/* Init DSCP QoS mapping */
	memset(&rule, 0x0, sizeof(struct dpqos_rule));
	memset(&action, 0x0, sizeof(struct dpqos_action));
	rule.method = DPQOS_METHOD_BASED_ON_IP;
	action.options = DPQOS_ACTION_SET_QPRI;
	action.next_action = DPQOS_ACTION_DONE;

	for (i = 0; i < 64; i++) {
		/*! Set QoS mapping */
		rule.priority = i;
		action.qpri = i >> 3; /*! Class selector. 3 high bits */

		/*! add an entry */
		err = dpqos_add_rule(iface->dpqos, &rule, &action);
		if (err != 0)
			break;
	}
	return err;
}

#ifdef TKT508412
static int dpsw_filter_flow_control_multicast(struct dpsw *dpsw)
{
	struct dptbl_rule rule;
	struct dptbl_action tbl_deny_action;
	int err;
	uint8_t multicast_mac[] = {0x01, 0x80, 0xc2, 0x00, 0x00, 0x01};

	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = (uint8_t *)multicast_mac;
	rule.rule_cfg.exact.size = 6;

	memset(&tbl_deny_action, 0, sizeof(struct dptbl_action));
	tbl_deny_action.next_action = DPTBL_ACTION_DONE;
	tbl_deny_action.options = DPTBL_ACTION_SET_DISCARD_FLAG;
	err = dptbl_add_rule(dpsw->pfc_multicast_fltr_tbl, &rule, &tbl_deny_action, 0);
	CHECK_COND_RETVAL( err==0, err, "ID[%d]: Failed to add flow control multicast in filter table\n", dpsw->id);

	return 0;
}
#endif

static int init_ctlu_vlan(struct dpsw *dpsw)
{
	int err = 0;
	struct dptbl_l2switch_vlan_cfg vlan_cfg; /* VLAN Table */
	struct dptbl_action miss_action;
	struct dpmng_amq amq;

	/* Clear Configuration Parameters */
	memset(&vlan_cfg, 0x0, sizeof(struct dptbl_l2switch_vlan_cfg));
	memset(&miss_action, 0x0, sizeof(struct dptbl_action));

	/* Obtain AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	/* VLAN ingress lookup table */
	vlan_cfg.max_rules = (uint32_t)(dpsw->max_vlans * dpsw->num_ifs);
	vlan_cfg.action_on_miss = &miss_action;
	vlan_cfg.icid = amq.icid;
	vlan_cfg.aging_threshold = dpsw->fdb_aging_time;
	vlan_cfg.options = DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION
				| DPTBL_OPTIONS_OPTIMIZIED_DISCARD;

	/* Miss Action */
	miss_action.next_action = DPTBL_ACTION_DONE;

	dpsw->vlan_ing.tbl = dptbl_l2switch_vlan_create(dpsw->handle.dptbl_ing, /* Tbl manager handle */
							&vlan_cfg); /* Configuration */

	CHECK_COND_RETVAL(dpsw->vlan_ing.tbl, -ENAVAIL);

	/* VLAN egress lookup table */
	dpsw->vlan_egr.tbl = dptbl_l2switch_vlan_create(dpsw->handle.dptbl_ing, /* Tbl manager handle */
							&vlan_cfg); /* Configuration */

	CHECK_COND_RETVAL(dpsw->vlan_egr.tbl, -ENAVAIL);

	return err;
}

static int init_ctlu_policy(struct dpsw *dpsw)
{
	/**
	 -# Policy
	 -# Error rule
	 -# VLAN rule
	 */
	int err = 0, priority = 0;
	struct dppolicy_cfg policy_cfg; /* Policy */
	struct dppolicy_rule rule; /* Policy rule */
	struct dppolicy_action action; /* Policy Action */
	int tid; /* CTLU Table ID */
	char type[16];

	/* Allocate Policy Resource */
	snprintf(type, sizeof(type), "plcy.wr%d.ctlui", 0 /* EIOP id */);
	err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(dpsw->policy.id), /* Address */
				"POLICY"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* Policy */
	/* Clear Configuration Parameters */
	memset(&policy_cfg, 0x0, sizeof(struct dppolicy_cfg));

	policy_cfg.max_num_of_rules = 2; /* Number of rules */

	dpsw->policy.hndl = dppolicy_init(dpsw->handle.dppolicy_ing, /* Policy handle */
						dpsw->policy.id, /* Policy ID */
						&policy_cfg); /* Policy configuration */
	CHECK_COND_RETVAL(dpsw->policy.hndl, -ENAVAIL, "dppolicy_init failed\n");

	/* 1. Drop un-tagged frames */
	memset(&rule, 0, sizeof(struct dppolicy_rule));
	memset(&action, 0, sizeof(struct dppolicy_action));
	rule.num_of_identifiers = 1; 	/* VLAN Header */
	rule.priority = priority++; 	/* Priority */
	rule.identifiers[0].exclude = 1; /* include */
	rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT;
	rule.identifiers[0].prot = NET_PROT_VLAN; /* at least 1 VLAN */
	rule.identifiers[0].opt = 0; /* no options */
	rule.identifiers[0].hdr_index = 0; /* outer header */
	action.next_action = DPPOLICY_ACTION_DONE; /* Discard */
	action.options = DPPOLICY_ACTION_SET_DISCARD_FLAG;
	err = dppolicy_add_rule(dpsw->policy.hndl, /* Policy handle */
				&rule, /* Rule */
				&action, /* Action */
				0);
	CHECK_COND_RETVAL(err == 0, err, "dppolicy_add_rule 1 failed : %d\n", err);

	/* 2. VLAN present */
	dptbl_get_id( /* Get VLAN Table ID */
	dpsw->vlan_ing.tbl, /* VLAN Handle */
			&tid /* Table ID */
			);

	memset(&rule, 0, sizeof(struct dppolicy_rule));
	memset(&action, 0, sizeof(struct dppolicy_action));
	rule.num_of_identifiers = 1; 	/* VLAN Header */
	rule.priority = priority; 	/* Priority */
	rule.identifiers[0].exclude = 0; /* include */
	rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT;
	rule.identifiers[0].prot = NET_PROT_VLAN; /* at least 1 VLAN */
	rule.identifiers[0].opt = 0; /* no options */
	rule.identifiers[0].hdr_index = 0; /* outer header */

	action.next_action = DPPOLICY_ACTION_LOOKUP; /* lookup */

#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		dptbl_get_id( /* Get VLAN Table ID */
				dpsw->pfc_multicast_fltr_tbl, /* VLAN Handle */
				&tid /* Table ID */
				);
		action.lookup_params.dpkg_profile_id = dpsw->pfc_multicast_fltr_kid;
		action.lookup_params.dptbl_id = tid; /* VLAN TID */
	}
	else {
		dptbl_get_id( /* Get VLAN Table ID */
				dpsw->vlan_ing.tbl, /* VLAN Handle */
				&tid /* Table ID */
				);
		action.lookup_params.dpkg_profile_id = dpsw->vlan_ing.kg.id;/* VLAN KID */
		action.lookup_params.dptbl_id = tid; /* VLAN TID */
	}
#else
	dptbl_get_id( /* Get VLAN Table ID */
			dpsw->vlan_ing.tbl, /* VLAN Handle */
			&tid /* Table ID */
			);
	action.lookup_params.dpkg_profile_id = dpsw->vlan_ing.kg.id;/* VLAN KID */
	action.lookup_params.dptbl_id = tid; /* VLAN TID */
#endif

	err = dppolicy_add_rule(dpsw->policy.hndl, /* Policy handle */
				&rule, /* Rule */
				&action, /* Action */
				0);
	CHECK_COND_RETVAL(err == 0, err, "dppolicy_add_rule 2 failed : %d\n", err);

	return err;
}

static int init_ctrl_if(struct dpsw *dpsw)
{
	int err = 0, qdid;
	uint16_t	i;
	struct ctrl_if_cfg 	ctrl_if;
	struct dpmng_dev_cfg	dpmng_dev;

	if (dpsw->ctrl_if_enable == 0)
		return err;

	dpsw->ctrl_if = ctrl_if_allocate();
	if (dpsw->ctrl_if == NULL)
		return -ENOMEM;

	/* device */
	memset(&dpmng_dev, 0x0, sizeof(struct dpmng_dev_cfg));
	memcpy(&dpmng_dev.ctx, &(dpsw->dev_ctx), sizeof(struct dpmng_dev_ctx));
	dpmng_dev.device = dpsw->handle.dprc;
	dpmng_dev.id = (uint16_t)dpsw->id;

	/* control */
	memset(&ctrl_if, 0x0, sizeof(struct ctrl_if_cfg));
	ctrl_if.num_ifs = dpsw->num_ifs;
	ctrl_if.eiop_id = 0;

	/* Source QDID */
	for (i = 0; i < dpsw->num_ifs; i++) {
                err = get_iface_qdid(dpsw, i, &qdid);
                CHECK_COND_RETVAL(err == 0, err);

		ctrl_if.src_qdid[i] = qdid;
	}

	/* Create */
	err = ctrl_if_create(dpsw->ctrl_if, &ctrl_if, &dpmng_dev);

	return err;
}

static int init_ctlu_acl(struct dpsw *dpsw)
{
	int err = 0;

	/*! Init ACL database */
	err = init_ctlu_acl_database(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Init ACL void table */
	err = init_ctlu_acl_void_tbl(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! ACL Key generation */
	err = init_ctlu_acl_kg(dpsw);

	return err;
}

static int init_ctlu_acl_database(struct dpsw *dpsw)
{
	/*
	 * Allocate hmap
	 * go over each acl
	 *      allocate  struct dpsw_acl
	 *      set data into hmap
	 */
	int err = 0, i;
	struct dpsw_acl *acl;

	/*! Allocate hmap */
	dpsw->hmap_acl = hmap_create(dpsw->num_ifs, 2);
	CHECK_COND_RETVAL(dpsw->hmap_acl, -ENOMEM);

	for (i = 0; i < dpsw->num_ifs; i++) {
		/*! allocate  struct dpsw_acl */
		acl = fsl_malloc(sizeof(struct dpsw_acl));
		CHECK_COND_RETVAL(acl, -ENOMEM);

		/*! reset memory */
		memset(acl, 0x0, sizeof(struct dpsw_acl));

		/*! set data into hmap */
		err = hmap_set_data(dpsw->hmap_acl, i, acl);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int init_ctlu_acl_void_tbl(struct dpsw *dpsw)
{
	int err = 0;
	struct dptbl_cfg cfg;
	struct dpmng_amq amq;

	/* Obtain AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	/*! Create ACL table */
	memset(&cfg, 0, sizeof(struct dptbl_cfg));
	cfg.type = DPTBL_TYPE_TCAM_ACL;
	cfg.mem_type = DPTBL_PEB;
	cfg.max_rules = 1;
	cfg.max_key_size = DPSW_ACL_KEY_SIZE;
	cfg.icid = amq.icid;
	cfg.options = DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;

	dpsw->acl_void_tbl = dptbl_init(dpsw->handle.dptbl_ing, &cfg);

	CHECK_COND_RETVAL(dpsw->acl_void_tbl, -ENAVAIL);

	return err;
}

static int init_ctlu_acl_kg(struct dpsw *dpsw)
{
	int err;
	uint8_t idx;
	struct dpkg_profile_cfg kg_cfg;
	char type[16];

	snprintf(type, sizeof(type), "kp.wr%d.ctlui", 0 /* EIOP id */);
	err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(dpsw->acl_kg.id), /* Address */
				"KID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* Clear Configuration Parameters */
	memset(&kg_cfg, 0x0, sizeof(struct dpkg_profile_cfg));

	/*! L2 Destination MAC address */
	idx = 0;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[idx].extract.from_hdr.prot = NET_PROT_ETH;
	kg_cfg.extracts[idx].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[idx].extract.from_hdr.field = NH_FLD_ETH_DA;

	/*! L2 Source MAC address */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[idx].extract.from_hdr.prot = NET_PROT_ETH;
	kg_cfg.extracts[idx].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[idx].extract.from_hdr.field = NH_FLD_ETH_SA;

	/*! 802.1Q TPID */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_DATA;
	kg_cfg.extracts[idx].extract.from_data.offset = 12;
	kg_cfg.extracts[idx].extract.from_data.size = 2;

	/*! L2 Priority Code Point + DEI 802.1p */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_DATA;
	kg_cfg.extracts[idx].extract.from_data.offset = 14;
	kg_cfg.extracts[idx].extract.from_data.size = 1;
	kg_cfg.extracts[idx].num_of_byte_masks = 1;
	kg_cfg.extracts[idx].masks[0].offset = 0;
	kg_cfg.extracts[idx].masks[0].mask = 0xf0;

	/*! VLAN ID */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[idx].extract.from_hdr.prot = NET_PROT_VLAN;
	kg_cfg.extracts[idx].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[idx].extract.from_hdr.field = NH_FLD_VLAN_TCI;
	kg_cfg.extracts[idx].num_of_byte_masks = 2;
	kg_cfg.extracts[idx].masks[0].offset = 0;
	kg_cfg.extracts[idx].masks[0].mask = 0x0F;
	kg_cfg.extracts[idx].masks[1].offset = 1;
	kg_cfg.extracts[idx].masks[1].mask = 0xFF;

	/*! L2 Ethernet type */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[idx].extract.from_hdr.prot = NET_PROT_ETH;
	kg_cfg.extracts[idx].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[idx].extract.from_hdr.field = NH_FLD_ETH_TYPE;

	/*! L3 Differentiated services code point */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[idx].extract.from_hdr.prot = NET_PROT_IP;
	kg_cfg.extracts[idx].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[idx].extract.from_hdr.field = NH_FLD_IP_TOS_TC;
	kg_cfg.extracts[idx].num_of_byte_masks = 1;
	kg_cfg.extracts[idx].masks[0].offset = 0;
	kg_cfg.extracts[idx].masks[0].mask = 0xfc;

	/*! L3 protocol */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[idx].extract.from_hdr.prot = NET_PROT_IP;
	kg_cfg.extracts[idx].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[idx].extract.from_hdr.field = NH_FLD_IP_PROTO;

	/*! L3 Source IPv4 IP */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[idx].extract.from_hdr.prot = NET_PROT_IP;
	kg_cfg.extracts[idx].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[idx].extract.from_hdr.field = NH_FLD_IP_SRC;

	/*! L3 Destination IPv4 IP */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[idx].extract.from_hdr.prot = NET_PROT_IP;
	kg_cfg.extracts[idx].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[idx].extract.from_hdr.field = NH_FLD_IP_DST;

	/*! L4 Source TCP/UDP Port */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[idx].extract.from_hdr.prot = NET_PROT_TCP;
	kg_cfg.extracts[idx].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[idx].extract.from_hdr.field = NH_FLD_TCP_PORT_SRC;

	/*! L4 Destination TCP/UDP Port */
	idx++;
	kg_cfg.extracts[idx].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[idx].extract.from_hdr.prot = NET_PROT_TCP;
	kg_cfg.extracts[idx].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[idx].extract.from_hdr.field = NH_FLD_TCP_PORT_DST;

	kg_cfg.num_extracts = idx + 1; /* IFP + VLAN */

	err = dpkg_profile_create(dpsw->handle.dpkg_ing, /* kg handle */
					dpsw->acl_kg.id, /* KID */
					&kg_cfg); /* Configuration */
	if (err == 0)
		dpsw->acl_kg.inuse = 1;

	return err;
}

static int acl_get_key(struct dpsw *dpsw, uint16_t *key)
{
	int err;
	hmap_data data;
	uint8_t count = 0;
	static uint16_t acl_key = 0;

	/*! Generate any random number */

	do {
		/*! Check key is not used yet */
		err = hmap_lookup(dpsw->hmap_acl, (hmap_key)&acl_key, &data);
		if (err == 0)
			acl_key++;

		count++;
	} while ((err == 0) && (count < dpsw->num_ifs));

	*key = acl_key;
	acl_key++;

	return (err == 0) ? -ENAVAIL : 0;
}

static int init_ctlu_vlan_kg(struct dpsw *dpsw)
{
	/**
	 -# FALU -> VLAN KG
	 -# KG format
	 00-15  IFP
	 16-19  0000
	 20-31  VLAN ID
	 */
	int err;
	struct dpkg_profile_cfg kg_cfg; /* KID conf */
	char type[16];
#ifdef TKT508412
	struct dptbl_cfg pfc_multicast_fltr_cfg;
	struct dptbl_action next_action;
#endif
	snprintf(type, sizeof(type), "kp.wr%d.ctlui", 0 /* EIOP id */);
	err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(dpsw->vlan_ing.kg.id), /* Address */
				"KID"); /* Error string */
	if (err)
		return err;

	/* Clear Configuration Parameters */
	memset(&kg_cfg, 0x0, sizeof(struct dpkg_profile_cfg));

	kg_cfg.num_extracts = 2; /* IFP + VLAN */
	/* IFP */
	kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_CONTEXT;
	kg_cfg.extracts[0].extract.from_context.src = DPKG_FROM_IFP;
	kg_cfg.extracts[0].num_of_byte_masks = 2;
	kg_cfg.extracts[0].masks[0].mask = 0x0F;
	kg_cfg.extracts[0].masks[0].offset = 0;
	kg_cfg.extracts[0].masks[1].mask = 0xFF;
	kg_cfg.extracts[0].masks[1].offset = 1;

	/* VLAN Extraction */
	kg_cfg.extracts[1].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[1].extract.from_hdr.prot = NET_PROT_VLAN;
	kg_cfg.extracts[1].extract.from_hdr.hdr_index = 0;
	kg_cfg.extracts[1].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[1].extract.from_hdr.field = NH_FLD_VLAN_TCI;
	kg_cfg.extracts[1].num_of_byte_masks = 2;
	kg_cfg.extracts[1].masks[0].mask = 0x0F;
	kg_cfg.extracts[1].masks[0].offset = 0;
	kg_cfg.extracts[1].masks[1].mask = 0xFF;
	kg_cfg.extracts[1].masks[1].offset = 1;

	err = dpkg_profile_create(dpsw->handle.dpkg_ing, /* kg handle */
					dpsw->vlan_ing.kg.id, /* KID */
					&kg_cfg); /* Configuration */
	if (err == 0)
		dpsw->vlan_ing.kg.inuse = 1;
	else
		return err;

	/*! Egress */
	dpkg_get_resource_str(dpsw->handle.dpkg_egr, type);

	err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* options */
				&(dpsw->vlan_egr.kg.id),/* Address */
				"KID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	err = dpkg_profile_create(dpsw->handle.dpkg_egr, /* kg handle */
					dpsw->vlan_egr.kg.id, /* KID */
					&kg_cfg); /* Configuration */
	if (err == 0)
		dpsw->vlan_egr.kg.inuse = 1;

#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		memset(&next_action, 0, sizeof(next_action));
		memset(&pfc_multicast_fltr_cfg, 0, sizeof(pfc_multicast_fltr_cfg));
		pfc_multicast_fltr_cfg.max_key_size = 6; /* MAC ADDR size */
		pfc_multicast_fltr_cfg.max_rules = 2;
		pfc_multicast_fltr_cfg.type = DPTBL_TYPE_EXACT_MATCH;
		pfc_multicast_fltr_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
		pfc_multicast_fltr_cfg.action_on_miss = &next_action;

		next_action.next_action = DPTBL_ACTION_LOOKUP;
		dptbl_get_id(dpsw->vlan_ing.tbl, &next_action.lookup_params.dptbl_id);
		next_action.lookup_params.dpkg_profile_id = dpsw->vlan_ing.kg.id;

		dpsw->pfc_multicast_fltr_tbl = dptbl_init(dpsw->handle.dptbl_ing, &pfc_multicast_fltr_cfg);
		CHECK_COND_RETVAL( dpsw->pfc_multicast_fltr_tbl!=NULL, -ENAVAIL,
				"dpsw[%d]: creating MULTICAST table failed\n", dpsw->id);

		dpsw_filter_flow_control_multicast(dpsw);

		snprintf(type, sizeof(type), "kp.wr%d.ctlui", 0 /* EIOP id */);
		err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(dpsw->pfc_multicast_fltr_kid), /* Address */
				"KID"); /* Error string */
		CHECK_COND_RETVAL(err == 0, err);

		memset(&kg_cfg, 0, sizeof(struct dpkg_profile_cfg));
		kg_cfg.num_extracts = 1;
		kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[0].extract.from_hdr.prot = NET_PROT_ETH;
		kg_cfg.extracts[0].extract.from_hdr.field = NH_FLD_ETH_DA;
		err = dpkg_profile_create(dpsw->handle.dpkg_ing,
				dpsw->pfc_multicast_fltr_kid,
				&kg_cfg);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	}
#endif

	return err;
}

static int init_ctlu_fdb_kg(struct dpsw *dpsw)
{
	/**
	 -# VLAN -> FDB KG
	 */
	int err;
	struct dpkg_profile_cfg kg_cfg; /* KID conf */
	char type[16];

	/* Allocate Resource */
	dpkg_get_resource_str(dpsw->handle.dpkg_ing, type);
	err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(dpsw->fdb_kg.id), /* Address */
				"KID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* Clear Configuration Parameters */
	memset(&kg_cfg, 0x0, sizeof(struct dpkg_profile_cfg));

	/* VLAN -> FDB KG */
	kg_cfg.num_extracts = 3; /* SMAC, DMAC */
	/* SMAC */
	kg_cfg.extracts[1].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[1].extract.from_hdr.prot = NET_PROT_ETH;
	kg_cfg.extracts[1].extract.from_hdr.hdr_index = 0;
	kg_cfg.extracts[1].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[1].extract.from_hdr.field = NH_FLD_ETH_SA;
	kg_cfg.extracts[1].extract.from_hdr.size = 6;
	kg_cfg.extracts[1].extract.from_hdr.offset = 0;

	/* DMAC */
	kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[0].extract.from_hdr.prot = NET_PROT_ETH;
	kg_cfg.extracts[0].extract.from_hdr.hdr_index = 0;
	kg_cfg.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[0].extract.from_hdr.field = NH_FLD_ETH_DA;
	kg_cfg.extracts[0].extract.from_hdr.size = 6;
	kg_cfg.extracts[0].extract.from_hdr.offset = 0;

	/* DMAC */
	kg_cfg.extracts[2].type = DPKG_EXTRACT_FROM_CONTEXT;
	kg_cfg.extracts[2].extract.from_context.src =
		DPKG_FROM_FCV_L2SWITCH_FDB_SPECIFIC;

	err = dpkg_profile_create(dpsw->handle.dpkg_ing, /* kg handle */
					dpsw->fdb_kg.id, /* KID */
					&kg_cfg); /* Configuration */
	if (err == 0)
		dpsw->fdb_kg.inuse = 1;

	return err;
}

static int init_ctlu_lag_kg(struct dpsw *dpsw)
{
	/**
	 -# LAG KG
	 */
	int err;
	struct dpkg_profile_cfg kg_cfg; /* KID conf */
	char type[16];

	/* Allocate Resource */
	dpkg_get_resource_str(dpsw->handle.dpkg_ing, type);
	err = allocate_resource(dpsw->handle.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(dpsw->lag_kg.id), /* Address */
				"KID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/* Clear Configuration Parameters */
	memset(&kg_cfg, 0x0, sizeof(struct dpkg_profile_cfg));

	kg_cfg.num_extracts = 5;

	/* SMAC */
	kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[0].extract.from_hdr.prot = NET_PROT_ETH;
	kg_cfg.extracts[0].extract.from_hdr.hdr_index = 0;
	kg_cfg.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[0].extract.from_hdr.field = NH_FLD_ETH_SA;
	kg_cfg.extracts[0].extract.from_hdr.size = 6;
	kg_cfg.extracts[0].extract.from_hdr.offset = 0;

	/* DMAC */
	kg_cfg.extracts[1].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[1].extract.from_hdr.prot = NET_PROT_ETH;
	kg_cfg.extracts[1].extract.from_hdr.hdr_index = 0;
	kg_cfg.extracts[1].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[1].extract.from_hdr.field = NH_FLD_ETH_DA;
	kg_cfg.extracts[1].extract.from_hdr.size = 6;
	kg_cfg.extracts[1].extract.from_hdr.offset = 0;

	/* L3 SRC */
	kg_cfg.extracts[2].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[2].extract.from_hdr.prot = NET_PROT_IP;
	kg_cfg.extracts[2].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[2].extract.from_hdr.field = NH_FLD_IP_SRC;

	/* L3 DST */
	kg_cfg.extracts[3].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[3].extract.from_hdr.prot = NET_PROT_IP;
	kg_cfg.extracts[3].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[3].extract.from_hdr.field = NH_FLD_IP_DST;

	/* L3 PROTO */
	kg_cfg.extracts[4].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[4].extract.from_hdr.prot = NET_PROT_IP;
	kg_cfg.extracts[4].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[4].extract.from_hdr.field = NH_FLD_IP_PROTO;

	err = dpkg_profile_create(dpsw->handle.dpkg_ing, /* kg handle */
					dpsw->lag_kg.id, /* KID */
					&kg_cfg); /* Configuration */
	if (err == 0)
		dpsw->lag_kg.inuse = 1;

	return err;
}

static int qdid_to_ifid(struct dpsw *dpsw, int qdid, uint16_t *if_id)
{
	int err = -ENODEV, err1 = -ENODEV, iface_qdid;
	uint16_t i;

	for (i = 0; i < dpsw->num_ifs; i++) {
		/* Obtain qdid */
                err1 = get_iface_qdid(dpsw, i, &iface_qdid);
                CHECK_COND_RETVAL(err1 == 0, err1);

		if (iface_qdid == qdid) {
			*if_id = i;
			err = 0;
			break;
		}
	}
	return err;
}

static int init_if_eiop_ifp_core(struct dpsw *dpsw, uint16_t id)
{
	int err, qdid;
	struct eiop_ifp_cfg ifp_params; /**< IFP */
	struct dpsw_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;
	int acl_tid = 0;
	struct dpmng_amq amq;
	int swl_qdid = 0;
	struct dpbp_attr dpbp_attr;
	struct ctrl_if_attr 	ctrl_attr;
	struct dpsw_buffer_pool_desc *buffer_pools;
	int pool_idx;

	/* Interface handle */
	iface = &(dpsw->iface[id]); /* Get interface */

	/*! Obtain AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);
	
	buffer_pools = dpsw->buffer_pools;

	/* Get VLAN Table ID */
	dptbl_get_id(dpsw->acl_void_tbl, /* VLAN Handle */
			&acl_tid /* Table ID */
			);

	/*! Get SW learning QDID */
	if (dpsw->ctrl_if_enable == 1) {
		/* Obtain control attributes */
		ctrl_if_get_rx_flow_attr(dpsw->ctrl_if, 0, &ctrl_attr);

		/* save qdid */
		swl_qdid = (int)ctrl_attr.internal_qdid;
	}

	/* Obtain qdid */
	err = get_iface_qdid(dpsw, id, &qdid);
	CHECK_COND_RETVAL(err == 0, err);

	memset(&ifp_params, 0x00, sizeof(struct eiop_ifp_cfg));
	ifp_params.default_cfg.qd_id = qdid;
	ifp_params.default_cfg.replic_list_id = dpsw->iface[id].rrid.root;

	/*Init buffer pools */
	if( dpsw->bp_per_if ) {
		pool_idx = id;
	}
	else {
		pool_idx = 0;
	}
	ifp_params.num_of_pools_used = 1;

	/* Get attributes */
	err = dpbp_get_attributes(dpsw->dpbp[pool_idx], &dpbp_attr);
	CHECK_COND_RETVAL(err == 0, err);
	/* Init buffer pools in IFP */
	ifp_params.pools_cfg[0].id = dpbp_attr.bpid;
	ifp_params.pools_cfg[0].size = (int)buffer_pools[pool_idx].buffer_size;
	ifp_params.pools_cfg[0].options = (amq.bmt == 1) ?
			EIOP_IFP_BUF_POOL_OPT_BMT | EIOP_IFP_BUF_POOL_OPT_SCARCE_RESOURCE
			:
			EIOP_IFP_BUF_POOL_OPT_SCARCE_RESOURCE;


	ifp_params.max_frame_length = DPSW_MAX_FRAME_LENGTH;
	ifp_params.mng_cmd_ring_paddr = 0x0;
	ifp_params.mng_cmd_icid = amq.icid;
	ifp_params.default_cfg.options =
		EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_REPLIC_ID
		| /* FLCTYPE=0*/EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_OPAQUE; /* ACL */

	ifp_params.default_cfg.opaque = (
		(uint64_t)(acl_tid & 0xFFFF) << 48) | 		/* ACL TID */
		((uint64_t)(dpsw->acl_kg.id & 0xFF) << 40) | 	/* ACL KID */
		((uint64_t)(swl_qdid & 0xFFFF) << 0); 		/* SW learning*/

	ifp_params.rx_err_fqid = dpsw->wq_void.fqid; /**< err FQID */
	ifp_params.tx_err_fqid = dpsw->wq_void.fqid; /**< err FQID */

	/*! AMQ configuration */
	ifp_params.defcfg.options |= EIOP_IFP_DEFCFG_OPT_SET_WRITE_OPTIMIZE;
	ifp_params.defcfg.options |=
		(amq.bdi == 1) ?
			EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION : 0;
	ifp_params.defcfg.options |=
		(amq.pl == 1) ? EIOP_IFP_DEFCFG_OPT_SET_PRIVIL_LEVEL : 0;
	ifp_params.defcfg.options |=
		(amq.va == 1) ? EIOP_IFP_DEFCFG_OPT_SET_VIRT_ADDR : 0;
	ifp_params.defcfg.icid = amq.icid;

	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	ifp_params.defcfg.tx_buf_layout.pass_egr_ad = 1;	// IFERA_FAEADV = 1
	
	ifp_params.errors_settings = EIOP_IFP_CFG_OPT_ERROR_DEFAULT ;

	/*! Init IFP */
	err = eiop_ifp_init(&eiop_ifp_desc, /*reg base */
				&ifp_params); /* params */

	return err;
}

static int init_if_eiop_ifp_extension(struct dpsw *dpsw, uint16_t id)
{
	int err;
	struct eiop_ifp_tx_pcd_cfg ifpext_egr_params; /**< Ext IFP */
	struct eiop_ifp_rx_pcd_cfg ifpext_ing_params; /**< Ext IFP */
	int vlan_tid;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct dpsw_if *iface;

	/* Clear Configuration Parameters */
	memset(&ifpext_ing_params, 0x00, sizeof(struct eiop_ifp_rx_pcd_cfg));
	memset(&ifpext_egr_params, 0x00, sizeof(struct eiop_ifp_tx_pcd_cfg));

	/*! Get descriptor */
	/* Interface handle */
	iface = &(dpsw->iface[id]); /* Get interface */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* iop id */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	/* Turn ON CTLU modules */
	ifpext_ing_params.activate_modules =
		EIOP_IFP_ACTIVATE_MODULE_PARSER | 	/*! Parser */
		EIOP_IFP_ACTIVATE_MODULE_POLICY | 	/*! FALU */
		EIOP_IFP_ACTIVATE_MODULE_QoS_MAPPING | 	/*! QOS Mapping */
		EIOP_IFP_ACTIVATE_MODULE_LOOKUP | 	/*! Lookups */
		(dpsw->lag_enable ? EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION : 0);	/* Hash Generation */

	/* Enable metering */
	if ((dpsw->metering_enable == 1) ||
		(dpsw->flooding_metering_enable == 1)) {
		ifpext_ing_params.activate_modules |=
			EIOP_IFP_ACTIVATE_MODULE_POLICER;
	}

	/* Get ingress VLAN Table ID */
	dptbl_get_id(dpsw->vlan_ing.tbl, /* VLAN Handle */
			&vlan_tid /* Table ID */
			);

	ifpext_ing_params.parser.profile_id = dpsw->prp_virt_ing.id;
	err = dpparser_get_hdr_code(NET_PROT_ETH, &ifpext_ing_params.parser.start_hxs);
	CHECK_COND_RETVAL(err == 0, err);
	ifpext_ing_params.policy.profile_id = dpsw->policy.id;
	ifpext_ing_params.default_lookup.dptbl_id = (uint16_t)(vlan_tid);
	ifpext_ing_params.default_lookup.dpkg_profile_id =
		(uint8_t)(dpsw->vlan_ing.kg.id);
	ifpext_ing_params.default_hash_generation.profile_id =
			(uint8_t)(dpsw->lag_kg.id);
	ifpext_ing_params.default_policer.profile_id = iface->flooding_plid;
	
	err = eiop_ifp_rx_pcd_set(&eiop_ifp_desc, /* registers base */
					&ifpext_ing_params); /* ingress parameters */
	CHECK_COND_RETVAL(err == 0, err);

	/* egress */
	/* Turn OFF CTLU modules */
	ifpext_egr_params.activate_modules =
			EIOP_IFP_ACTIVATE_MODULE_PARSER | 	/*! Parser */
			EIOP_IFP_ACTIVATE_MODULE_LOOKUP; 	/*! Lookups */

	
	/* Get egress VLAN Table ID */
	dptbl_get_id(dpsw->vlan_egr.tbl, /* VLAN Handle */
			&vlan_tid /* Table ID */
			);

	ifpext_egr_params.parser.profile_id = dpsw->prp_egr.id;
	err = dpparser_get_hdr_code(NET_PROT_ETH, &ifpext_egr_params.parser.start_hxs);
	CHECK_COND_RETVAL(err == 0, err);
	ifpext_egr_params.default_lookup.dptbl_id = (uint16_t)(vlan_tid);
	ifpext_egr_params.default_lookup.dpkg_profile_id =
		(uint8_t)(dpsw->vlan_egr.kg.id);

	err = eiop_ifp_tx_pcd_set(&eiop_ifp_desc, /* registers base */
					&ifpext_egr_params); /* egress parameters */

	return err;
}

static int init_if_eiop_ifp(struct dpsw *dpsw, uint16_t id)
{
	int err = 0;

	/*! Init core IFP */
	err = init_if_eiop_ifp_core(dpsw, id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Init extention IFP */
	err = init_if_eiop_ifp_extension(dpsw, id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Clear counters */
	err = if_eiop_ifp_clear_counters(dpsw, id);

	return err;
}

static int endpoint_integrity(struct dpsw *dpsw,
	struct linkman_endpoint *endpoint)
{
	if (endpoint->type != FSL_MOD_DPSW)
		return -EINVAL; /*! Invalid argument */
	if (endpoint->id != dpsw->id)
		return -EINVAL; /*! Invalid argument */
	if (endpoint->if_id >= dpsw->num_ifs)
		return -EINVAL; /*! Invalid argument */
	return 0;
}

static int if_associate_with_lni(struct dpsw *dpsw, uint16_t if_id, int shaped)
{
	int err;
	uint32_t ceetmid;
	void *swp;
	struct dpmng_accesspoint *ap;

	ap = &(dpsw->iface[if_id].ap);

	/*! Compose CEETM */
	ceetmid = qbman_ceetmid_compose((uint8_t)ap->dcp_id,
					(uint8_t)ap->ceetm_id);

	/* Get software portal */
	err = dpmng_get_swportal(dpsw->handle.dpmng, &(swp));
	CHECK_COND_RETVAL(err == 0, err);

	err = qbman_cchannel_configure(swp, /* SW Portal */
					ceetmid, /* Composed CEETM ID */
					(uint8_t)ap->cqchid, /* Channel ID */
					(uint8_t)ap->lniid, /* LNI ID */
					shaped); /* shaped/un-shaped */

	return err;
}

static int link_event(struct dpsw *dpsw,
	enum linkman_event event, enum linkman_cmd cmd,
	uint16_t if_id)
{
	int err;
	struct linkman_endpoint self;
	struct linkman_endpoint peer;
	struct linkman_control 	control;

	memset(&self, 0x0, sizeof(struct linkman_endpoint));
	memset(&peer, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));

	self.type = FSL_MOD_DPSW;
	self.id = (uint16_t)dpsw->id;
	self.if_id = if_id;

	control.event = event;
	control.cmd = cmd;
	err = linkman_set_connection(
		dpsw->handle.linkman, 	/* Context */
		&control, 		/* Event */
		&self, 			/* Self info */
		&peer); 		/* dummy param */

	return err;
}

static int init_vlan(struct dpsw *dpsw)
{
	/*
	 *      dpsw_fdb_add
	 *      dpsw_vlan_add
	 *      dpsw_vlan_add_if
	 */
	int err;
	uint16_t i;
	struct dpsw_fdb_cfg fdb_cfg;
	struct dpsw_vlan_cfg vlan_cfg;
	struct dpsw_vlan_if_cfg vlan_if_cfg;
	uint16_t fid;
	int if_connected;

	/* Add Default FDB table */
	memset(&fdb_cfg, 0x0, sizeof(struct dpsw_fdb_cfg));
	fdb_cfg.fdb_aging_time = dpsw->fdb_aging_time; /* 300 seconds*/
	fdb_cfg.num_fdb_entries = dpsw->max_fdb_entries;/* Max entries */
	fdb_key = 0; /*! fdb id */

	err = dpsw_fdb_add(dpsw, &fid, &fdb_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* Add Default VLAN = 1 */
	memset(&vlan_cfg, 0x0, sizeof(struct dpsw_vlan_cfg));
	vlan_cfg.fdb_id = fid; /* FDB ID */

	err = dpsw_vlan_add(dpsw, DEFAULT_VLAN_ID, &vlan_cfg);
	CHECK_COND_RETVAL(err == 0, err, "dpsw_vlan_add\n");

	/* Add Interfaces to default VLAN = 1 */
	memset(&vlan_if_cfg, 0x0, sizeof(struct dpsw_vlan_if_cfg));
	vlan_if_cfg.num_ifs = dpsw->num_ifs;
	for (i = 0; i < dpsw->num_ifs; i++)
		vlan_if_cfg.if_id[i] = i;

	err = dpsw_vlan_add_if(dpsw, DEFAULT_VLAN_ID, &vlan_if_cfg);
	CHECK_COND_RETVAL(err == 0, err, "dpsw_vlan_add_if : %d)\n", err);

	for (i = 0; i < dpsw->num_ifs; i++) {
		err = is_if_link_up(dpsw, i, &if_connected);
		if( err || !if_connected ) continue;
		add_if_to_replic_flooding(dpsw, i);
		add_if_to_replic_broadcast(dpsw, i);
	}

	return err;
}

static int init_learning(struct dpsw *dpsw)
{
	struct dpsw_fdb_attr fdb_attr = {0};
	uint16_t fdb_id, if_id;
	int err = 0;

	/* By default the learning configuration is per FDB, thus reset any
	 * request that has been made per port */
	for (if_id = 0; if_id < dpsw->num_ifs; if_id++)
		dpsw->iface[if_id].learning_requested = 0;

	/* Enable hardware learning on all FDBs. This will in turn call
	 * vlan_tbl_update and all VLAN entries will be updated */
	for (fdb_id = 0; fdb_id < dpsw->max_fdbs; fdb_id++) {
		err = dpsw_fdb_get_attributes(dpsw, fdb_id, &fdb_attr);
		if (err) /* FDB not created */
			continue;

		err = dpsw_fdb_set_learning_mode(dpsw, fdb_id, DPSW_LEARNING_MODE_HW);
		if (err)
			pr_err("Failed to change learning mode for fdb_id: %d\n", fdb_id);
	}

	/* used in dpsw_reset(), should return true */
	return 0;
}

static int init_default(struct dpsw *dpsw)
{
	int err = 0;
	/* Set default tag control information */
	err = init_default_tci(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/* Transmit frames as un-tagged */
	err = init_default_untagged(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/* default transmission selection */
	err = init_deafult_ceetm_if(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	err = init_default_flooding_metering(dpsw);

	return err;
}

static int init_default_tci(struct dpsw *dpsw)
{
	int err = 0;
	uint16_t i;
	struct dpsw_tci_cfg tci;

	/*! Tag Control Information */
	memset(&tci, 0x0, sizeof(struct dpsw_tci_cfg));
	tci.dei = DEFAULT_DEI;
	tci.pcp = DEFAULT_PCP;
	tci.vlan_id = DEFAULT_VLAN_ID;

	for (i = 0; i < dpsw->num_ifs; i++) {
		/*! Set Tag Control Information */
		err = dpsw_if_set_tci(dpsw, i, &tci);
		if (err != 0)
			break;
	}
	return err;
}

static int init_default_untagged(struct dpsw *dpsw)
{
	int err = 0;
	struct dpsw_vlan_if_cfg vlan_if;
	uint16_t i;

	/*! transmit un-tagged */
	memset(&vlan_if, 0x0, sizeof(struct dpsw_vlan_if_cfg));
	vlan_if.num_ifs = dpsw->num_ifs;

	for (i = 0; i < dpsw->num_ifs; i++) {
		vlan_if.if_id[i] = i;
	}

	/*! Set transmit un-tagged */
	err = dpsw_vlan_add_if_untagged(dpsw, DEFAULT_VLAN_ID, &vlan_if);

	return err;
}

static int init_default_flooding_metering(struct dpsw *dpsw)
{
	int err = 0;
	uint16_t	i;
	struct dpsw_metering_cfg  metering;

	if (dpsw->flooding_metering_enable == 0)
		return err;

	memset(&metering, 0x0, sizeof(struct dpsw_metering_cfg));

	for (i = 0; i < dpsw->num_ifs; i++) {
		err = dpsw_if_set_flooding_metering(dpsw, i, &metering);
		if (err != 0)
			break;
	}

	return err;
}

int dpsw_enable(struct dpsw *dpsw)
{
	int err = 0;
	uint16_t i;

	/* Enable all interfaces */
	for (i = 0; i < dpsw->num_ifs; i++) {
		err = dpsw_if_enable(dpsw, i);
		if (err != 0)
			break;
	}

	return err;
}

int dpsw_if_enable(struct dpsw *dpsw, uint16_t if_id)
{
	struct dpsw_if *iface;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! Enable interface */
	iface->enabled = 1;

	/*! trigger link manager state machine */
	link_event(dpsw, LINKMAN_EVENT_LINKUP, LINKMAN_CMD_ENABLE, if_id);

	return 0;
}

static int if_eiop_ifp_rx_enable(struct dpsw *dpsw, uint16_t id)
{
	int err = 0;
	struct dpsw_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	/*! Obtain Interface */
	iface = &(dpsw->iface[id]);

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /*! iop id */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /*! module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /*! match options*/
				&eiop_ifp_desc, /*! descriptor */
				NULL); /*! iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	/* IFP */
	eiop_ifp_rx_enable(&eiop_ifp_desc);

	return err;
}

static int if_eiop_ifp_tx_enable(struct dpsw *dpsw, uint16_t id)
{
	int err = 0;
	struct dpsw_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	/*! Obtain Interface */
	iface = &(dpsw->iface[id]);

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /*! iop id */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /*! module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /*! match options*/
				&eiop_ifp_desc, /*! descriptor */
				NULL); /*! iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	/* IFP */
	eiop_ifp_tx_enable(&eiop_ifp_desc);

	return err;
}

static int is_if_eiop_ifp_enable(struct dpsw *dpsw, uint16_t id)
{
	int err;
	struct dpsw_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	/*! Obtain Interface */
	iface = &(dpsw->iface[id]);

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	return eiop_ifp_rx_is_enable(&eiop_ifp_desc);
}

static void dpsw_dump(struct dpsw *dpsw)
{
	int 		rtn_fqid, qdid;
	uint16_t	i, j;
	struct dpsw_if 	*iface;
	int err;

	rtn_fqid = dpmng_get_rtn_fqid(dpsw->handle.dpmng);

	pr_info("L2 Switch %d Information:\n", dpsw->id);
	pr_info("Replic QDID %d:\n", dpsw->wq_replic.qdid);
	pr_info("Replic FQID %d:\n", dpsw->wq_replic.fqid);
	pr_info("Replic RTN_FQID %08X:\n", rtn_fqid);
	pr_info("PRPID VIRT ING:\t%d\n", dpsw->prp_virt_ing.id);
	pr_info("PRPID PHYS ING:\t%d\n", dpsw->prp_phys_ing.id);
	pr_info("PRPID EGR:\t%d\n", dpsw->prp_egr.id);
	pr_info("flooding_enable:\t%d\n", dpsw->flooding_enable);
	pr_info("multicast_enable:\t%d\n", dpsw->multicast_enable);
	pr_info("ctrl_if_enable:\t%d\n", dpsw->ctrl_if_enable);
	pr_info("flooding_metering_enable:\t%d\n", dpsw->flooding_metering_enable);
	pr_info("metering_enable:\t%d\n", dpsw->metering_enable);

	for (i = 0; i < dpsw->num_ifs; i++) {
		iface = &(dpsw->iface[i]);

		UNUSED(iface);	/* suppress klockwork warning*/

		/* Obtain qdid */
		err = get_iface_qdid(dpsw, i, &qdid);
		if( err ) continue;

		pr_info("Interface %d:\n", i);
		pr_info("\tIFPID:\t%d\n", iface->ap.ifpid);
		pr_info("\tQDID:\t%d\n", qdid);
	}

	if (dpsw->num_lag_groups > 0)
	{
		for (i = 0; i < dpsw->num_lag_groups; i++)
		{
			if (dpsw->lag_cfg[i].num_ifs > 0)
			{
				pr_info("LAG Group %d\n", dpsw->lag_cfg[i].group_id);

				for ( j = 0; j < dpsw->lag_cfg[i].num_ifs; j++)
					pr_info("\tInterface %d\n", dpsw->lag_cfg[i].if_id[j]);
			}
		}
	}
}

void dpsw_destroy(struct dpsw *dpsw)
{
	/*
	 -# disable all interfaces
	 -# Release all ctlu tables
	 -# Release all Resource manager resources
	 -# unregister external modules
	 -# de-allocate memory
	 */
	/* Disable and disconnect all interfaces */
	destroy_disconnect(dpsw);

	/* Destroy control interface */
	destroy_ctrl_if(dpsw);

	/* Release all CTLU tables  */
	destroy_ctlu(dpsw);

	/* unbind LDPAA resources */
	destroy_resources(dpsw);

	/* free memory */
	destroy_deallocate(dpsw);
}

int dpsw_disable(struct dpsw *dpsw)
{
	int err = 0;
	uint16_t i;
	/* Enable all interfaces */
	for (i = 0; i < dpsw->num_ifs; i++) {
		err = dpsw_if_disable(dpsw, i);
		if (err != 0)
			break;
	}

	return err;
}

int dpsw_if_disable(struct dpsw *dpsw, uint16_t if_id)
{
	struct dpsw_if *iface;
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr attr;
	enum linkman_event event;
	int err;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! Disable interface */
	iface->enabled = 0;

	memset(&endpoint1, 0x0, sizeof(struct linkman_endpoint));
	memset(&endpoint2, 0x0, sizeof(struct linkman_endpoint));
	memset(&attr, 0x0, sizeof(struct linkman_connection_attr));
	endpoint1.type = FSL_MOD_DPSW;
	endpoint1.id = (uint16_t)dpsw->id;
	endpoint1.if_id = if_id;

	event = LINKMAN_EVENT_LINKDOWN;
	err = linkman_get_connection(dpsw->handle.linkman, &endpoint1, &endpoint2, &attr);
	if( !err && attr.state == LINKMAN_STATE_NEGOTIATION )
		event = LINKMAN_EVENT_NEGOTIATION_FAIL;
	else if( !err && attr.state==LINKMAN_STATE_IDLE )
		return 0;

	/*! Trigger link manager state machine */
	err = link_event(dpsw, event, LINKMAN_CMD_DISABLE, if_id);
	if (err) {
		pr_warn("ID[%d]: link_event (DOWN) failed when disabling interface %d\n", dpsw->id, if_id);
	}

	return 0;
}

static int if_eiop_ifp_disable(struct dpsw *dpsw, uint16_t id)
{
	int err;
	struct dpsw_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	if (id >= dpsw->num_ifs)
		return -EINVAL;

	/*! Obtain interface */
	iface = &(dpsw->iface[id]);

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* WRIOP ID */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	/* TX IFP valid disable */
	err = eiop_ifp_tx_graceful_stop(&eiop_ifp_desc);
	CHECK_COND_RETVAL(err == 0, err);

	/* RX IFP valid disable */
	err = eiop_ifp_rx_graceful_stop(&eiop_ifp_desc);

	return err;
}

static int if_eiop_ifp_set_prpid(struct dpsw *dpsw, uint16_t if_id, int prpid)
{
	int err;
	struct dpsw_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	iface = &(dpsw->iface[if_id]);

	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* WRIOP ID */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	err = eiop_ifp_rx_pcd_set_parser_profile_id(&eiop_ifp_desc, prpid);

	return err;
}

static int if_eiop_ifp_next(struct dpsw *dpsw, uint16_t id, int ifpid)
{
	int err;
	struct dpsw_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	iface = &(dpsw->iface[id]);

	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* WRIOP ID */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	/*! Set next IFP */
	err = eiop_ifp_set_enqueue_ifp(&eiop_ifp_desc, ifpid);

	return err;
}

static int destroy_disconnect(struct dpsw *dpsw)
{
	/*
	 *      disable all interfaces
	 *      disconnect all interfaces
	 */
	int err;
	uint16_t i;
	/*! disable all interfaces */
	err = dpsw_disable(dpsw);

	/*! disconnect all interfaces */
	for (i = 0; i < dpsw->num_ifs; i++) {
		/*! trigger link manager state machine */
		link_event(dpsw, LINKMAN_EVENT_DISCONNECT, LINKMAN_CMD_DISABLE, i);
	}
	return err;
}

static int destroy_ctrl_if(struct dpsw *dpsw)
{
	int err = 0;

	if (dpsw == NULL)
		return err;

	if (dpsw->ctrl_if != NULL)	{
		err = ctrl_if_destroy(dpsw->ctrl_if);
		ctrl_if_deallocate(dpsw->ctrl_if);
		dpsw->ctrl_if = NULL;
	}

	return err;
}

static int destroy_if(struct dpsw *dpsw)
{
	int err = 0, i;
	struct dpsw_if *iface;

	if (dpsw == NULL)
		return err;

	if (dpsw->iface == NULL)
		return err;

	for(i = 0; i < dpsw->num_ifs; i++) {
		/* Obtain interface */
		iface = &(dpsw->iface[i]);

		/* Release QoS mapping table */
		if (iface->dpqos != NULL)
			err = dpqos_done(iface->dpqos);
	}
	return err;
}

static int destroy_ctlu(struct dpsw *dpsw)
{
	/*
	 * -# Remove FDBs
	 * -# Remove VLAN
	 * -# Remove FALU entries
	 * -# Delete VALN KG and FDB KG
	 * */
	int err = 0;
	struct dpsw_fdb *fdb;
	struct dpsw_acl *acl;
	int iter_status, iter;
	uint8_t key[2];

	if (dpsw->hmap_acl != NULL) {
		/*! Remove ACLs */
		iter_status = hmap_get_start_iterator(dpsw->hmap_acl, &iter);

		while (iter_status == 0) {
			/* Retrieve vlan at iterator and updates iterator */
			iter_status = hmap_iterate(dpsw->hmap_acl, &iter, key,
							(hmap_data *)&acl);
			if (acl->hndl != NULL)
				dptbl_delete(acl->hndl);
		}

		/*! Remove FDBs */
		iter_status = hmap_get_start_iterator(dpsw->hmap_fdb, &iter);

		while (iter_status == 0) {
			/* Retrieve vlan at iterator and updates iterator */
			iter_status = hmap_iterate(dpsw->hmap_fdb, &iter, key,
							(hmap_data *)&fdb);
			if (fdb->hndl != NULL)
				dptbl_l2switch_fdb_delete(fdb->hndl);
		}
	}

	/*! Remove ingress VLAN */
	if (dpsw->vlan_ing.tbl != NULL)
		dptbl_l2switch_vlan_delete(dpsw->vlan_ing.tbl);

#ifdef TKT508412
	/*! Remove flow control filtering table */
	if( eiop_wriop_apply_TKT508412_fix() && dpsw->pfc_multicast_fltr_tbl!=NULL )
		dptbl_delete(dpsw->pfc_multicast_fltr_tbl);
#endif

	/*! Remove egress VLAN */
	if (dpsw->vlan_egr.tbl != NULL)
		dptbl_l2switch_vlan_delete(dpsw->vlan_egr.tbl);

	/*! Remove ingress VALN KG */
	if (dpsw->vlan_ing.kg.inuse == 1)
		dpkg_profile_delete(dpsw->handle.dpkg_ing,
					dpsw->vlan_ing.kg.id);

#ifdef TKT508412
	/*! Remove flow control KG */
	if( eiop_wriop_apply_TKT508412_fix() )
		dpkg_profile_delete(dpsw->handle.dpkg_ing,
				dpsw->pfc_multicast_fltr_kid);
#endif

	/*! Remove egress VALN KG */
	if (dpsw->vlan_egr.kg.inuse == 1)
		dpkg_profile_delete(dpsw->handle.dpkg_egr,
					dpsw->vlan_egr.kg.id);

	/*! Remove FDB KG */
	if (dpsw->fdb_kg.inuse == 1)
		dpkg_profile_delete(dpsw->handle.dpkg_ing, dpsw->fdb_kg.id);
	
	/*! Remove FDB KG */
	if (dpsw->lag_kg.inuse == 1)
		dpkg_profile_delete(dpsw->handle.dpkg_ing, dpsw->lag_kg.id);

	/*! Remove FALU entries (Policy) */
	if (dpsw->policy.hndl != NULL)
		dppolicy_done(dpsw->policy.hndl);

	/*! Remove Parser Profile */
	if (dpsw->prp_phys_ing.inuse == 1)
		dpparser_delete_profile(dpsw->handle.dpparser_ing,
					dpsw->prp_phys_ing.id, NULL);

	if (dpsw->prp_virt_ing.inuse == 1)
		dpparser_delete_profile(dpsw->handle.dpparser_ing,
					dpsw->prp_virt_ing.id, NULL);

	if (dpsw->prp_egr.inuse == 1)
		dpparser_delete_profile(dpsw->handle.dpparser_egr,
					dpsw->prp_egr.id, NULL);

	/*! Remove ACL kg */
	if (dpsw->acl_kg.inuse == 1)
		dpkg_profile_delete(dpsw->handle.dpkg_ing, dpsw->acl_kg.id);

	/*! Remove ACL */
	if (dpsw->acl_void_tbl != NULL)
		dptbl_delete(dpsw->acl_void_tbl);

	return err;
}

static int destroy_resources(struct dpsw *dpsw)
{
	/*
	 * deallocate all resources
	 * */
	int err = -ENODEV; /*! No such device, or device not configured */

	if (dpsw->handle.dprc)
		err = resman_unbind_all(dpsw->handle.dprc);

	return err;
}

static int destroy_deallocate(struct dpsw *dpsw)
{
	/*
	 * -# free all memories having pointer different than zero
	 * */
	/* ACl dataBase */
	destroy_deallocate_acl(dpsw);

	/* FDB dataBase */
	destroy_deallocate_fdb(dpsw);

	/* VLAN dataBase */
	destroy_deallocate_vlan(dpsw);

	/* broadcast dataBase */
	destroy_deallocate_broadcast(dpsw, NULL);

	/* policer database */
	destroy_deallocate_iface_metering(dpsw);

	/* ceetm interface */
	destroy_deallocate_ceetm_if(dpsw);

	/* Interface dataBase */
	destroy_deallocate_iface(dpsw);

	/* Pool and PEB */
	destroy_bman_bp(dpsw);

	return 0;
}

static int destroy_deallocate_fdb(struct dpsw *dpsw)
{
	int i, j, err; /*!< Iterator */
	struct dpsw_fdb *fdb;
	struct dpsw_replic *replic;

	if (dpsw->hmap_fdb == NULL)
		return 0;

	for (i = 0; i < dpsw->max_fdbs; i++) {
		err = hmap_get_data(dpsw->hmap_fdb, i, (hmap_data *)&fdb);
		if ((err != 0) || (fdb == NULL))
			continue;

		for (j = 0; j < dpsw->max_fdb_mc_groups; j++) {

			if (fdb->hmap_mcast == NULL)
				continue;

			/*! get hmap data */
			err = hmap_get_data(fdb->hmap_mcast, j,
						(hmap_data *)&replic);
			if (err != 0)
				continue;

			/*! destroy replic */
			if (replic && replic->replic)
				replic_destroy(replic->replic);

			/*! free memory */
			if (replic)
				fsl_free(replic);
		}

		if(fdb->hmap_mcast != NULL)
			hmap_destroy(fdb->hmap_mcast);

		destroy_deallocate_broadcast(dpsw, fdb);

		if (dpsw->flooding_cfg == DPSW_FLOODING_PER_FDB) {
			if (fdb->flooding.replic)
				replic_destroy(fdb->flooding.replic);
		}

		fsl_free(fdb);
	}

	/* FDB */
	if (dpsw->hmap_fdb)
		hmap_destroy(dpsw->hmap_fdb);

	return 0;
}

static int destroy_deallocate_iface_metering(struct dpsw *dpsw)
{
	int err = 0, i;
	struct dpsw_if *iface;
	struct dpsw_metering	*metering;

	for (i = 0; i < dpsw->num_ifs; i++) {
		iface = &(dpsw->iface[i]);

		if (iface->hmap_metering == NULL)
			continue;

		err = hmap_get_data(iface->hmap_metering,
		                    i, (hmap_data *)&metering);
		if (err != 0)
			continue;

		if(metering == NULL)
			continue;

		fsl_free(metering);
	}
	return 0;
}

static int destroy_deallocate_ceetm_if(struct dpsw *dpsw)
{
	int err = 0, i;
	struct dpsw_if *iface;

	for (i = 0; i < dpsw->num_ifs; i++) {
		iface = &(dpsw->iface[i]);

		if (iface->ceetm_if == NULL)
			continue;

		ceetm_if_destroy(iface->ceetm_if);
	}
	return err;
}


static int destroy_bman_bp(struct dpsw *dpsw)
{
	/*
	 * Release buffer pool
	 * free PEB memory
	 */
	struct dpsw_buffer_pool_desc *buffer_pools;
	struct dpbp_hw_notification_cfg bp_notification_cfg;
	int i;

	buffer_pools = dpsw->buffer_pools;

	/* Configure depletion thresholds */
	memset(&bp_notification_cfg, 0, sizeof(bp_notification_cfg));

	for (i = 0; i < dpsw->num_buffer_pools; i++) {
		if (dpsw->dpbp[i] != NULL) {
			bp_notification_cfg.depletion_entry = 0;
			bp_notification_cfg.depletion_exit = 0;
			dpbp_set_hw_notifications(dpsw->dpbp[i], &bp_notification_cfg);

			/*! Deallocate buffres */
			dpbp_deallocate_buffers(dpsw->dpbp[i],
			                        buffer_pools[i].memory_size);

			/*! Destroy DPBP */
			dpbp_destroy(dpsw->dpbp[i]);

			/*! Free the space allocated for the structure */
			fsl_free(dpsw->dpbp[i]);
		}
	}

	return 0;
}

static int destroy_deallocate_acl(struct dpsw *dpsw)
{
	/* for each acl
	 *      hmap_get_data
	 *      fsl_free (acl)
	 * hmap_destroy
	 */
	int err, i;
	struct dpsw_acl *acl;

	if (dpsw->hmap_acl == NULL)
		return 0;

	for (i = 0; i < dpsw->max_acls; i++) {
		err = hmap_get_data(dpsw->hmap_acl, i, (hmap_data *)&acl);
		if ((err != 0) || (acl == NULL))
			continue;

		fsl_free(acl);
	}

	hmap_destroy(dpsw->hmap_acl);
	return 0;
}

static int destroy_deallocate_vlan(struct dpsw *dpsw)
{
	/* for each vlan
	 *      hmap_get_data
	 *      replic_destroy(flooding->replic)
	 *      fsl_free (dpsw_vlan_if)
	 *      fsl_free (dpsw_vlan)
	 * hmap_destroy
	 */
	int err, i;
	struct dpsw_vlan *vlan;

	if (dpsw->hmap_vlan == NULL)
		return 0;

	for (i = 0; i < dpsw->max_vlans; i++) {
		err = hmap_get_data(dpsw->hmap_vlan, i, (hmap_data *)&vlan);
		if ((err != 0) || (vlan == NULL))
			continue;

		/*! destroy replic */
		if (dpsw->flooding_cfg == DPSW_FLOODING_PER_VLAN && vlan->flooding.replic)
			replic_destroy(vlan->flooding.replic);

		/*! destroy vlan interfaces database */
		if (vlan->iface)
			fsl_free(vlan->iface);

		fsl_free(vlan);
	}

	hmap_destroy(dpsw->hmap_vlan);
	return 0;
}

static int destroy_deallocate_broadcast(struct dpsw *dpsw, struct dpsw_fdb *fdb)
{
	if (dpsw->broadcast_cfg == DPSW_BROADCAST_PER_FDB) {
		if (fdb && fdb->broadcast.replic)
			replic_destroy(fdb->broadcast.replic);
	} else {
		if (dpsw->broadcast.replic)
			replic_destroy(dpsw->broadcast.replic);
	}

	return 0;
}

static int destroy_deallocate_iface(struct dpsw *dpsw)
{
	struct dpsw_if *iface;
	int if_id;

	for( if_id=0 ; if_id<dpsw->num_ifs ; if_id++ ) {
		iface = &(dpsw->iface[if_id]);
		if( iface->dpqos!=NULL ) {
			fsl_free(iface->dpqos);
			iface->dpqos = NULL;
		}
	}

	/*! deallocate Interface dataBase */
	if (dpsw->iface)
		fsl_free(dpsw->iface);

	return 0;
}

int dpsw_fdb_add(struct dpsw *dpsw,
	uint16_t *fdb_id,
	const struct dpsw_fdb_cfg *cfg)
{
	/**
	 -# Verify fdb_cfg parameters
	 -# Allocate fdb slot in MC database
	 -# Save configuration
	 -# Allocate fdb in CTLU
	 */
	int err = 0;
	uint16_t id;
	struct dpsw_fdb *fdb;
	struct dptbl_l2switch_fdb_cfg fdb_cfg;
	struct dpmng_amq amq;

	/* Obtain AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	/* Find free fdb */
	err = fdb_get_key(dpsw, &id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Add VID key */
	err = hmap_add_key(dpsw->hmap_fdb, (hmap_key)&id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	/* Save configuration */
	*fdb_id = id; /* slot ID */
	fdb->max_entries = cfg->num_fdb_entries; /*total number*/
        fdb->aging_time = (cfg->fdb_aging_time == 0) ?
                        DEFAULT_FDB_AGING_TIME : cfg->fdb_aging_time;
	fdb->ref_cnt = 0;
	fdb->learning_mode = DPSW_LEARNING_MODE_HW;

	/* Allocate fdb in CTLU */
	memset(&fdb_cfg, 0x0, sizeof(struct dptbl_l2switch_fdb_cfg));
	/* Consider broadcast for number of entries */
	fdb_cfg.max_rules = (uint32_t)cfg->num_fdb_entries + 1;
	fdb_cfg.aging_threshold = fdb->aging_time;
	fdb_cfg.icid = amq.icid;
	fdb_cfg.options = DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;

	fdb->hndl = dptbl_l2switch_fdb_create(dpsw->handle.dptbl_ing, /*! Table Handle */
						&fdb_cfg); /*! Configuration */
	if (fdb->hndl == NULL) { /*! Error case */
		hmap_remove_key(dpsw->hmap_fdb, (hmap_key)&id);
		return -ENAVAIL;
	}

	if (dpsw->broadcast_cfg == DPSW_BROADCAST_PER_FDB) {
		/* Initialize broadcast replication database for this new FDB */
		err = replic_broadcast_set_default(dpsw, *fdb_id);
		CHECK_COND_RETVAL(err == 0, err);
	}

	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_FDB) {
		/* Initialize unknown replication database for this new FDB */
		err = replic_flooding_set_default(dpsw, *fdb_id);
		CHECK_COND_RETVAL(err == 0, err);
	}

	/* Add broadcast entry */
	err = fdb_add_broadcast(dpsw, fdb);

	/* Cleanup the flooding replicator */
	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_FDB) {
		err = replic_cleanup(dpsw, &(fdb->flooding));
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int fdb_get_key(struct dpsw *dpsw, uint16_t *key)
{
	int err;
	hmap_data data;
	uint8_t count = 0;

	/*! Generate any random number */

	do {
		/*! Check key is not used yet */
		err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_key, &data);
		if (err == 0)
			fdb_key++;

		count++;
	} while ((err == 0) && (count < dpsw->max_fdbs));

	*key = fdb_key;
	fdb_key++;

	return (err == 0) ? -ENAVAIL : 0;
}

int dpsw_vlan_add(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_cfg *cfg)
{
	/**
	 -# Verify Configuration parameters
	 -# Allocate fdb slot in MC database
	 -# Save VLAN configuration
	 -# Add entries into VLAN lookup table
	 */
	int err;
	struct dpsw_vlan *vlan;
	struct dpsw_fdb *fdb;

	/* Verify VLAN is 12 bits long */
	if ((vlan_id & 0xF000) != 0)
		return -EINVAL;

	/*! Is VID already exist */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err, -EEXIST); /*! Resource already exists */

	/*! Is FDB exist */
	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&(cfg->fdb_id),
				(void **)&fdb);
	CHECK_COND_RETVAL(err == 0, -ENODEV); /*! No such device */

	/*! Add VID key */
	err = hmap_add_key(dpsw->hmap_vlan, (hmap_key)&vlan_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Obtain vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	/* Save VLAN configuration & init database */
	vlan->fdb_id = cfg->fdb_id; /**< associated FDB */
	memset((vlan->iface), 0x00,
		sizeof(struct dpsw_vlan_if) * dpsw->num_ifs);
	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_VLAN) {
		err = replic_cleanup(dpsw, &(vlan->flooding));
		CHECK_COND_RETVAL(err == 0, err);
	}

	/*! Accept all vlan if add an entry for this vlan */
	err = vlan_tbl_accept_all_vlan_update(dpsw, vlan_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Let frames having PVID = vlan_id (untagged) to get in */
	err = vlan_tbl_admit_untagged_update(dpsw, vlan_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update reference count */
	fdb->ref_cnt++;
	return err;
}

int is_vlan_if_assigned(struct dpsw *dpsw, uint16_t vlan_id, uint16_t if_id)
{
	int err = 0;
	struct dpsw_vlan *vlan;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	return vlan->iface[if_id].assigned;
}

static int vlan_ifs_cnt(struct dpsw *dpsw, uint16_t vlan_id, uint16_t *cnt)
{
	int err = 0, i;
	struct dpsw_vlan *vlan;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	for (i = 0, *cnt = 0; i < dpsw->num_ifs; i++) {
		if (vlan->iface[i].assigned == 1)
			(*cnt)++;
	}
	return err;
}
static int vlan_untagged_ifs_cnt(struct dpsw *dpsw,
	uint16_t vlan_id,
	uint16_t *cnt)
{
	int err = 0, i;
	struct dpsw_vlan *vlan;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	for (i = 0, *cnt = 0; i < dpsw->num_ifs; i++) {
		if ((vlan->iface[i].assigned == 1)
			&& (vlan->iface[i].untagged == 1))
			(*cnt)++;
	}
	return err;
}

static int vlan_add_if_params_integrity(struct dpsw *dpsw,
        uint16_t vlan_id,
        const struct dpsw_vlan_if_cfg *cfg)
{
	struct dpsw_vlan *vlan;
	struct dpsw_fdb *fdb;
        int i, err = 0;
        uint16_t if_id;

        /*! Retrieve vlan database */
        err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
        if (err != 0)
                return err;

        if (cfg->num_ifs == 0)
                return -EEXIST; /*! nothing to add */

        if (cfg->num_ifs >= DPSW_MAX_IF)
                return -EINVAL; /*! out of domain */

        for (i = 0; i < cfg->num_ifs; i++) {
                if_id = cfg->if_id[i]; /*! obtain interface ID */

                /*! Is ID OK? */
                if (if_id >= dpsw->num_ifs) {
                        return -EINVAL; /*!< Invalid argument */
                }

                /*! Is port already assigned? */
                if (vlan->iface[if_id].assigned == 1)
                        return -EINVAL; /*!< Invalid argument */
        }

	/* Check if the FDB ID is valid */
	if (cfg->options & DPSW_VLAN_ADD_IF_OPT_FDB_ID) {
		err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&(cfg->fdb_id), (void **)&fdb);
		CHECK_COND_RETVAL(err == 0, -ENODEV, "FDB #%d is not valid!\n", cfg->fdb_id);
	}

        return err;
}

int dpsw_vlan_add_if(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg)
{
	int err = 0, i;
	uint16_t if_id;
	int link_up;
	struct dpsw_vlan_if_cfg replic_cfg;
	struct dpsw_vlan *vlan;
	uint16_t fdb_id;

	err = vlan_add_if_params_integrity(dpsw, vlan_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	memset(&replic_cfg, 0, sizeof(replic_cfg));

	for (i = 0; i < cfg->num_ifs; i++) {
		/*! Obtain interface ID */
		if_id = cfg->if_id[i];

		/* See if the user requested a specific FDB to be used for this VLN entry */
		fdb_id = cfg->options & DPSW_VLAN_ADD_IF_OPT_FDB_ID ?
			cfg->fdb_id : DPSW_INVALID_FDB;

		/*! Add interface into internal database */
		err = vlan_if_dbase_add(dpsw, vlan_id, if_id, fdb_id);
		CHECK_COND_RETVAL(err == 0, err);

		err = is_if_link_up(dpsw, if_id, &link_up);
		if( !err && link_up ) {
			replic_cfg.if_id[replic_cfg.num_ifs] = if_id;
			replic_cfg.num_ifs++;
		}
	}

	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_VLAN && dpsw->flooding_enable) {
		err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
		CHECK_COND_RETVAL(err == 0, err);

		err = replic_add(dpsw, &(vlan->flooding), &replic_cfg);
		CHECK_COND_RETVAL(err == 0, err);
	}

	for (i = 0; i < cfg->num_ifs; i++) {
		/*! Obtain interface ID */
		if_id = cfg->if_id[i];

		/*! Add entry into ingress VLAN table */
		err = vlan_tbl_entry_update(dpsw, /*! Context */
						CTLU_EIOP_INGRESS, /*! CTLU Type */
						vlan_id, /*! VLAN ID */
						if_id); /*! Interface id */
		CHECK_COND_RETVAL(err == 0, err);

		/*! Add entry into egress VLAN table */
		err = vlan_tbl_entry_update(dpsw, /*! Context */
						CTLU_EIOP_EGRESS, /*! CTLU Type */
						vlan_id, /*! VLAN ID */
						if_id); /*! Interface id */
		CHECK_COND_RETVAL(err == 0, err);
	}

	return err;
}

int vlan_if_dbase_add(struct dpsw *dpsw, uint16_t vlan_id, uint16_t if_id, uint16_t fdb_id)
{
	int err;
	struct dpsw_vlan *vlan;

	if (if_id >= dpsw->num_ifs)
		return -ENODEV; /*!< No such device */

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	if (vlan->iface[if_id].assigned == 0) {
		vlan->iface[if_id].assigned = 1; /* attached */
		vlan->iface[if_id].flooding_enable = dpsw->flooding_enable;
		vlan->iface[if_id].untagged = 0;
		vlan->iface[if_id].stp_state = DPSW_STP_STATE_FORWARDING;
		vlan->iface[if_id].fdb_id = fdb_id;
	}

	return err;
}

int vlan_if_get_rule(struct dpsw *dpsw,
	uint16_t vlan_id,
	uint16_t if_id,
	struct dptbl_l2switch_vlan_rule_cfg *rule,
	uint32_t *key)
{
	/*
	 *      Key format
	 *      00-15           IFP
	 *      16-19           0000
	 *      20-31           VLAN ID
	 *
	 */
	struct dpsw_if *iface;

	/* Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/* rule */
	memset(rule, 0x0, sizeof(struct dptbl_l2switch_vlan_rule_cfg));
	*key = ((uint32_t)(iface->ap.ifpid) << 16) | ((uint32_t)(vlan_id));
	rule->key = (uint8_t *)key;

	return 0;
}

static int vlan_if_get_action(struct dpsw *dpsw,
	enum ctlu_type ctlu_type,
	uint16_t vlan_id,
	uint16_t if_id,
	struct dptbl_l2switch_vlan_action *action)
{
	/*
	 *      Get CTLU FDB ID
	 *              a) Find VLAN
	 *              b) Get FDB ID
	 *              c) Get FDB Handle
	 *      Create rule
	 *      Create Action
	 *      Add rule to VLAN lookup table
	 */
	int err = 0, ctlu_fdb_id, qdid;
	struct dpsw_if *iface;
	struct dpsw_vlan *vlan;
	struct dpsw_fdb *fdb;
	uint16_t fdb_id;

	/* Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	/* Get the FDB id to be used for the rule. If the user requested a
	 * specific FDB for this VLAN on this interface IF then use that, if
	 * not, use the FDB id specified per VLAN.
	 */
	if (vlan->iface[if_id].fdb_id != DPSW_INVALID_FDB)
		fdb_id = vlan->iface[if_id].fdb_id;
	else
		fdb_id = vlan->fdb_id;

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	/*Get CTLU FDBID*/
	dptbl_get_id(fdb->hndl, &ctlu_fdb_id);

	/* Obtain qdid */
	err = get_iface_qdid(dpsw, if_id, &qdid);
	CHECK_COND_RETVAL(err == 0, err);

	/* Action */
	memset(action, 0x0, sizeof(struct dptbl_l2switch_vlan_action));

	/*! TID KID */
	action->lookup_fdb_cfg.dptbl_id = ctlu_fdb_id;
	action->lookup_fdb_cfg.dpkg_profile_id = dpsw->fdb_kg.id;

	/*! QDID RPLID */
	action->learning_cfg.qd_id = qdid;
	action->learning_cfg.replic_list_id = iface->rrid.root;

	/*! Flooding */
	action->general_replic_qd_id = dpsw->wq_replic.qdid;
	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_FDB)
		action->flooding_replic_list_id = fdb->flooding.rrid.root;
	else
		action->flooding_replic_list_id = vlan->flooding.rrid.root;

	/*! Policer */
	action->vlan_dppolicer_profile_id = 0;

	/*! Mapping method */
	action->qos_map_method =
		(iface->priority_selector ==
			DPSW_PRIORITY_SELECTOR_PCP) ?
			DPTBL_L2SWITCH_VLAN_ACTION_QoS_BASED_ON_VLAN_PRI :
			DPTBL_L2SWITCH_VLAN_ACTION_QoS_BASED_ON_IP_DSCP;

	action->options = vlan_if_get_options(dpsw, ctlu_type, vlan_id, if_id);

	return err;
}

int vlan_tbl_entry_update(struct dpsw *dpsw,
	enum ctlu_type ctlu_type,
	uint16_t vlan_id,
	uint16_t if_id)
{
	int err;
	struct dptbl_l2switch_vlan_rule_cfg rule;
	struct dptbl_l2switch_vlan_action action;
	uint32_t key;
	struct dptbl *vlan_tbl;

	err = vlan_if_get_rule(dpsw, vlan_id, if_id, &rule, &key);
	CHECK_COND_RETVAL(err == 0, err);

	err = vlan_if_get_action(dpsw, ctlu_type, vlan_id, if_id, &action);
	CHECK_COND_RETVAL(err == 0, err);

	vlan_tbl =
		(ctlu_type == CTLU_EIOP_EGRESS) ?
			dpsw->vlan_egr.tbl : dpsw->vlan_ing.tbl;


	err = dptbl_add_or_modify_rule_l2switch_vlan(vlan_tbl, &rule, &action);

	return err;
}

static int vlan_tbl_update(struct dpsw *dpsw, uint16_t vlan_id)
{
	int err = 0;

	/*! update all entries included in this VLAN */
	err = vlan_tbl_assigned_update(dpsw, vlan_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update all entries having PVID == vlan_id */
	err = vlan_tbl_admit_untagged_update(dpsw, vlan_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update all trunk ports */
	err = vlan_tbl_accept_all_vlan_update(dpsw, vlan_id);

	return err;
}

static int vlan_tbl_assigned_update(struct dpsw *dpsw, uint16_t vlan_id)
{
	/*
	 * for each interface included in VLAN
	 *      if interface assigned to this VLAN
	 *              vlan_tbl_entry_update() for ingress
	 *              vlan_tbl_entry_update() for egress
	 */
	int err = 0;
	uint16_t i;
	struct dpsw_vlan *vlan;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	for (i = 0; i < dpsw->num_ifs; i++) {
		if (vlan->iface[i].assigned == 1) {
			err = vlan_tbl_entry_update(dpsw, /*! Switch Context */
							CTLU_EIOP_INGRESS, /*! CTLU type */
							vlan_id, /*! VLAN ID */
							i); /*! interface ID */
			if (err != 0)
				break;
			err = vlan_tbl_entry_update(dpsw, /*! Switch Context */
							CTLU_EIOP_EGRESS, /*! CTLU type */
							vlan_id, /*! VLAN ID */
							i); /*! interface ID */
			if (err != 0)
				break;
		}
	}
	return err;
}

static int vlan_tbl_admit_untagged_update(struct dpsw *dpsw, uint16_t vlan_id)
{
	/*
	 * for each interface in L2 switch
	 *      if PVID of interface == vlan_id && admit all
	 *              vlan_tbl_entry_update() for ingress
	 */
	int err = 0;
	uint16_t i;
	struct dpsw_tci_cfg tci;
	struct dpsw_if *iface;

	for (i = 0; i < dpsw->num_ifs; i++) {
		/*! Obtain interface */
		iface = &(dpsw->iface[i]);

		/*! Get PVID */
		err = dpsw_if_get_tci(dpsw, i, &tci);
		if (err != 0)
			break;

		/*! Verify admit all and vlan_id matches to PVID */
		if ((iface->admit_untagged == DPSW_ADMIT_ALL)
			&& (tci.vlan_id == vlan_id)) {

			/*! Update ingress CTLU entry in VLAN lookup table */
			err = vlan_tbl_entry_update(dpsw, /*! Switch Context */
							CTLU_EIOP_INGRESS, /*! CTLU type */
							vlan_id, /*! VLAN ID */
							i); /*! interface ID */
			if (err != 0)
				break;
		}
	}
	return err;
}

static int vlan_tbl_accept_all_vlan_update(struct dpsw *dpsw, uint16_t vlan_id)
{
	/*
	 * for each interface in L2 switch
	 *      if interface is trunk
	 *              vlan_tbl_entry_update() for ingress
	 */
	int err = 0;
	uint16_t i;
	struct dpsw_if *iface;

	for (i = 0; i < dpsw->num_ifs; i++) {
		iface = &(dpsw->iface[i]);
		if (iface->accept_all_vlan == 1) {
			err = vlan_tbl_entry_update(dpsw, /*! Switch Context */
							CTLU_EIOP_INGRESS, /*! CTLU type */
							vlan_id, /*! VLAN ID */
							i); /*! interface ID */
			if (err != 0)
				break;
		}
	}
	return err;
}

static int vlan_tbl_remove(struct dpsw *dpsw, uint16_t vlan_id)
{
	int err = 0;

	/*! update all entries included in this VLAN */
	err = vlan_tbl_assigned_remove(dpsw, vlan_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update all entries having PVID == vlan_id */
	err = vlan_tbl_admit_untagged_remove(dpsw, vlan_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update all trunk ports */
	err = vlan_tbl_accept_all_vlan_remove(dpsw, vlan_id);

	return err;
}

static int vlan_tbl_assigned_remove(struct dpsw *dpsw, uint16_t vlan_id)
{
	/*
	 * for each interface included in VLAN
	 *      if interface assigned to this VLAN
	 *              vlan_tbl_entry_remove() for ingress
	 *              vlan_tbl_entry_remove() for egress
	 */
	int err = 0;
	uint16_t i;
	struct dpsw_vlan *vlan;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	for (i = 0; i < dpsw->num_ifs; i++) {
		if (vlan->iface[i].assigned == 1) {
			err = vlan_tbl_entry_remove(dpsw, /*! Switch Context */
							CTLU_EIOP_INGRESS, /*! CTLU type */
							vlan_id, /*! VLAN ID */
							i); /*! interface ID */
			if (err != 0)
				break;

			err = vlan_tbl_entry_remove(dpsw, /*! Switch Context */
							CTLU_EIOP_EGRESS, /*! CTLU type */
							vlan_id, /*! VLAN ID */
							i); /*! interface ID */
			if (err != 0)
				break;
		}
	}
	return err;
}

static int vlan_tbl_admit_untagged_remove(struct dpsw *dpsw, uint16_t vlan_id)
{
	/*
	 * for each interface in L2 switch
	 *      if PVID of interface == vlan_id && admit all
	 *              vlan_tbl_entry_update() for ingress
	 */
	int err = 0;
	uint16_t i;
	struct dpsw_tci_cfg tci;
	struct dpsw_if *iface;

	for (i = 0; i < dpsw->num_ifs; i++) {
		/*! Obtain interface */
		iface = &(dpsw->iface[i]);

		/*! Get PVID */
		err = dpsw_if_get_tci(dpsw, i, &tci);
		if (err != 0)
			break;

		/*! Verify admit all and vlan_id matches to PVID */
		if ((iface->admit_untagged == DPSW_ADMIT_ALL)
			&& (tci.vlan_id == vlan_id)) {

			/*! Update ingress CTLU entry in VLAN lookup table */
			err = vlan_tbl_entry_remove(dpsw, /*! Switch Context */
							CTLU_EIOP_INGRESS, /*! CTLU type */
							vlan_id, /*! VLAN ID */
							i); /*! interface ID */
			if (err != 0)
				break;
		}
	}
	return err;
}

static int vlan_tbl_accept_all_vlan_remove(struct dpsw *dpsw, uint16_t vlan_id)
{
	/*
	 * for each interface in L2 switch
	 *      if interface is trunk
	 *              vlan_tbl_entry_remove() for ingress
	 */
	int err = 0;
	uint16_t i;
	struct dpsw_if *iface;

	for (i = 0; i < dpsw->num_ifs; i++) {
		iface = &(dpsw->iface[i]);
		if (iface->accept_all_vlan == 1) {
			err = vlan_tbl_entry_remove(dpsw, /*! Switch Context */
							CTLU_EIOP_INGRESS, /*! CTLU type */
							vlan_id, /*! VLAN ID */
							i); /*! interface ID */
			if (err != 0)
				break;
		}
	}
	return err;
}

static int vlan_tbl_vif_update(struct dpsw *dpsw,
	uint16_t vlan_id, uint16_t if_id)
{
	int err = 0;

	/* Update vlan where this interface is included */
	err = vlan_tbl_vif_assigned_update(dpsw,  vlan_id, if_id);
	CHECK_COND_RETVAL(err == 0, err);

	/* Update interface PVID */
	err = vlan_tbl_vif_admit_untagged_update(dpsw, vlan_id, if_id);
	CHECK_COND_RETVAL(err == 0, err);

	/* Update trunk port entry */
	err = vlan_tbl_vif_accept_all_vlan_update(dpsw, vlan_id, if_id);

	return err;
}

static int vlan_tbl_vif_assigned_update(struct dpsw *dpsw,
	uint16_t vlan_id, uint16_t if_id)
{
	int err = 0;
	struct dpsw_vlan *vlan;

        /*! Retrieve vlan database */
        err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
        if (err != 0)
                return 0; /* nothing to update */

	if (vlan->iface[if_id].assigned == 1) {
		/*! Ingress VLAN lookup */
		err = vlan_tbl_entry_update(
			dpsw, 			/* Context */
			CTLU_EIOP_INGRESS, 	/* CTLU */
			vlan_id, 		/* VLAN ID */
			if_id); 		/* interface */
		CHECK_COND_RETVAL(err == 0, err);

		/* Egress VLAN lookup*/
		err = vlan_tbl_entry_update(
			dpsw, 			/* Context */
			CTLU_EIOP_EGRESS, 	/* CTLU */
			vlan_id, 		/* VLAN ID */
			if_id); 		/* interface */
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int vlan_tbl_vif_admit_untagged_update(struct dpsw *dpsw,
	uint16_t vlan_id, uint16_t if_id)
{
	int err = 0;
	struct dpsw_vlan *vlan;
	struct dpsw_tci_cfg tci;

	/*! Obtain PVID */
	err = dpsw_if_get_tci(dpsw, if_id, &tci);
	CHECK_COND_RETVAL(err == 0, err);

	if (tci.vlan_id != vlan_id)
		return 0;		/* nothing to update */

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&(tci.vlan_id),
				(void **)&vlan);
	if (err == -ENAVAIL)
		return 0; /*! nothing to update */

	else if (err == 0) {
		/*! Ingress VLAN lookup */
		err = vlan_tbl_entry_update(dpsw, /*! Context */
						CTLU_EIOP_INGRESS, /*! CTLU */
						tci.vlan_id, /*! VLAN ID */
						if_id); /*! interface */
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int vlan_tbl_vif_accept_all_vlan_update(struct dpsw *dpsw,
	uint16_t vlan_id, uint16_t if_id)
{
	int err = 0;
	struct dpsw_vlan *vlan;

	if (dpsw->iface[if_id].accept_all_vlan == 0)
		return err;

        /*! Retrieve vlan database */
        err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
        if (err != 0)
                return 0;	/* nothing to update */

        if (vlan->iface[if_id].assigned == 1)
        	return 0;	/* nothing to update */


	/*! update ingress vlan lookup table */
	err = vlan_tbl_entry_update(
		dpsw, 			/* Context */
		CTLU_EIOP_INGRESS, 	/* CTLU */
		vlan_id, 		/* VLAN ID */
		if_id); 		/* interface */

	return err;
}


static int vlan_tbl_if_update(struct dpsw *dpsw, uint16_t if_id)
{
	int err = 0;

	/*! Update all vlan where this interface is included */
	err = vlan_tbl_if_assigned_update(dpsw, if_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update interface PVID */
	err = vlan_tbl_if_admit_untagged_update(dpsw, if_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update trunk port entries */
	err = vlan_tbl_if_accept_all_vlan_update(dpsw, if_id);

	return err;
}

static int vlan_tbl_if_assigned_update(struct dpsw *dpsw, uint16_t if_id)
{
	/*
	 * for each existing VLAN
	 *      if interface included
	 *              vlan_tbl_entry_remove for ingress
	 *              vlan_tbl_entry_remove for egress
	 */
	int err = 0;
	struct dpsw_vlan *vlan;
	int iter, iter_status;
	uint8_t key[2];
	uint16_t vlan_id;

	iter_status = hmap_get_start_iterator(dpsw->hmap_vlan, &iter);

	while (iter_status == 0) {
		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(dpsw->hmap_vlan, &iter, key,
						(void **)&vlan);

		vlan_id = MAKE_UINT16(key[0], key[1]);

		if (vlan->iface[if_id].assigned == 1) {
			/*! Ingress VLAN lookup */
			err = vlan_tbl_entry_update(dpsw, /*! Context */
							CTLU_EIOP_INGRESS, /*! CTLU */
							vlan_id, /*! VLAN ID */
							if_id); /*! interface */
			if (err != 0)
				break;

			/*! Egress VLAN lookup*/
			err = vlan_tbl_entry_update(dpsw, /*! Context */
							CTLU_EIOP_EGRESS, /*! CTLU */
							vlan_id, /*! VLAN ID */
							if_id); /*! interface */
			if (err != 0)
				break;
		}
	}
	return err;
}

static int vlan_tbl_if_admit_untagged_update(struct dpsw *dpsw, uint16_t if_id)
{
	/*
	 *      if admit all
	 *              find vlan by PVID
	 *                      vlan_tbl_entry_update for ingress
	 */
	int err = 0;
	struct dpsw_vlan *vlan;
	struct dpsw_tci_cfg tci;

	/*! Obtain PVID */
	err = dpsw_if_get_tci(dpsw, if_id, &tci);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&(tci.vlan_id),
				(void **)&vlan);
	if (err == -ENAVAIL)
		return 0; /*! nothing to update */

	else if (err == 0) {
		/*! Ingress VLAN lookup */
		err = vlan_tbl_entry_update(dpsw, /*! Context */
						CTLU_EIOP_INGRESS, /*! CTLU */
						tci.vlan_id, /*! VLAN ID */
						if_id); /*! interface */
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int vlan_tbl_if_accept_all_vlan_update(struct dpsw *dpsw,
	uint16_t if_id)
{
	/*
	 *      if accept all vlans
	 *              for each existing VLAN
	 *                      vlan_tbl_entry_update for ingress
	 */
	int err = 0;
	struct dpsw_vlan *vlan;
	int iter_status, iter;
	uint8_t key[2];
	uint16_t vlan_id;

	if (dpsw->iface[if_id].accept_all_vlan == 0)
		return err;

	iter_status = hmap_get_start_iterator(dpsw->hmap_vlan, &iter);

	while (iter_status == 0) {
		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(dpsw->hmap_vlan, &iter, key,
						(void **)&vlan);

                if (vlan->iface[if_id].assigned == 1)
                	continue;

		vlan_id = MAKE_UINT16(key[0], key[1]);

		/*! update ingress vlan lookup table */
		err = vlan_tbl_entry_update(dpsw, /*! Context */
						CTLU_EIOP_INGRESS, /*! CTLU */
						vlan_id, /*! VLAN ID */
						if_id); /*! interface */
		if (err != 0)
			break;
	}
	return err;
}

static int vlan_tbl_if_remove(struct dpsw *dpsw, uint16_t if_id)
{
	int err = 0;

	/*! Update all vlan where this interface is included */
	err = vlan_tbl_if_assigned_remove(dpsw, if_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update interface PVID */
	err = vlan_tbl_if_admit_untagged_remove(dpsw, if_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update trunk port entries */
	err = vlan_tbl_if_accept_all_vlan_remove(dpsw, if_id);

	return err;
}

static int vlan_tbl_if_assigned_remove(struct dpsw *dpsw, uint16_t if_id)
{
	/*
	 * for each existing VLAN
	 *      if interface included
	 *              vlan_tbl_entry_remove for ingress
	 *              vlan_tbl_entry_remove for egress
	 */
	int err = 0;
	struct dpsw_vlan *vlan;
	int iter_status, iter;
	uint8_t key[2];
	uint16_t vlan_id;

	iter_status = hmap_get_start_iterator(dpsw->hmap_vlan, &iter);

	while (iter_status == 0) {
		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(dpsw->hmap_vlan, &iter, key,
						(void **)&vlan);

		vlan_id = MAKE_UINT16(key[0], key[1]);

		if (vlan->iface[if_id].assigned == 1) {
			/*! Ingress VLAN lookup */
			err = vlan_tbl_entry_remove(dpsw, /*! Context */
							CTLU_EIOP_INGRESS, /*! CTLU */
							vlan_id, /*! VLAN ID */
							if_id); /*! interface */
			if (err != 0)
				break;

			/*! Egress VLAN lookup*/
			err = vlan_tbl_entry_remove(dpsw, /*! Context */
							CTLU_EIOP_EGRESS, /*! CTLU */
							vlan_id, /*! VLAN ID */
							if_id); /*! interface */
			if (err != 0)
				break;
		}
	}
	return err;
}

static int vlan_tbl_if_admit_untagged_remove(struct dpsw *dpsw, uint16_t if_id)
{
	/*
	 *      if admit all
	 *              find vlan by PVID
	 *                      vlan_tbl_entry_remove for ingress
	 */
	int err = 0;
	struct dpsw_tci_cfg tci;
	struct dpsw_vlan *vlan;

	/*! Obtain PVID */
	err = dpsw_if_get_tci(dpsw, if_id, &tci);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&(tci.vlan_id),
				(void **)&vlan);

	if (err == 0) {
		/*! Ingress VLAN lookup */
		err = vlan_tbl_entry_remove(dpsw, /*! Context */
						CTLU_EIOP_INGRESS, /*! CTLU */
						tci.vlan_id, /*! VLAN ID */
						if_id); /*! interface */
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int vlan_tbl_if_accept_all_vlan_remove(struct dpsw *dpsw,
	uint16_t if_id)
{
	/*
	 *      if accept all vlans
	 *              for each existing VLAN
	 *                      vlan_tbl_entry_remove for ingress
	 */
	int err = 0;
	struct dpsw_vlan *vlan;
	int iter_status, iter;
	uint8_t key[2];
	uint16_t vlan_id;

	if (dpsw->iface[if_id].accept_all_vlan == 1)
		return err;

	iter_status = hmap_get_start_iterator(dpsw->hmap_vlan, &iter);

	while (iter_status == 0) {
		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(dpsw->hmap_vlan, &iter, key,
						(void **)&vlan);

                if (vlan->iface[if_id].assigned == 1)
                	continue;

		vlan_id = MAKE_UINT16(key[0], key[1]);

		/*! Ingress VLAN lookup */
		err = vlan_tbl_entry_remove(dpsw, /*! Context */
						CTLU_EIOP_INGRESS, /*! CTLU */
						vlan_id, /*! VLAN ID */
						if_id); /*! interface */
		if (err != 0)
			break;
	}
	return err;
}

uint32_t vlan_if_get_stp_options(struct dpsw *dpsw,
	enum ctlu_type ctlu_type,
	uint16_t vlan_id,
	uint16_t if_id)
{
	uint32_t options = 0;
	struct dpsw_vlan_if *vlan_if;
	struct dpsw_vlan *vlan;
	int err;

	/* Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, options);

	/* obtain VLAN interface */
	vlan_if = &(vlan->iface[if_id]);

	/* supporting accept all VLAN */
	if (vlan_if->assigned == 0)
		return DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_FORWORDING;

	/* Get STP state */
	switch (vlan_if->stp_state) {
		case DPSW_STP_STATE_BLOCKING: /* Blocking state */
			options = DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_BLOCKING;
			if (ctlu_type == CTLU_EIOP_EGRESS)
				options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_EDISC;
			break;
		case DPSW_STP_STATE_LISTENING: /* Listening state */
			options = DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LISTENING;
			if (ctlu_type == CTLU_EIOP_EGRESS)
				options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_EDISC;
			break;
		case DPSW_STP_STATE_LEARNING: /* Learning state */
			options = DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LEARNING;
			if (ctlu_type == CTLU_EIOP_EGRESS)
				options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_EDISC;
			break;
		case DPSW_STP_STATE_FORWARDING: /* Forwarding state */
			options = DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_FORWORDING;
			break;
		default:
			break;
	}
	return options;
}

uint32_t vlan_if_get_learning_mode_options(struct dpsw *dpsw,
	uint16_t vlan_id,
	uint16_t if_id)
{
	enum dpsw_learning_mode mode;
	uint32_t options = 0;
	struct dpsw_fdb *fdb;
	struct dpsw_vlan *vlan;
	struct dpsw_if *iface;
	uint16_t fdb_id;
	int err;

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/* If a specific learning mode was requested on this interface, just
	 * return that without checking the FDB configuration */
	if (iface->learning_requested) {
		mode = iface->learning_mode;
		goto get_learn_options;
	}

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, options);

	/* Get the FDB id to be used for the rule. If the user requested a
	 * specific FDB for this VLAN on this interface IF then use that, if
	 * not, use the FDB id specified per VLAN.
	 */
	if (vlan->iface[if_id].fdb_id != DPSW_INVALID_FDB)
		fdb_id = vlan->iface[if_id].fdb_id;
	else
		fdb_id = vlan->fdb_id;

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, options);

	mode = fdb->learning_mode;

get_learn_options:

	/*! Auto learning */
	switch (mode) {
	case DPSW_LEARNING_MODE_DIS: /*!< Disable Auto-learn */
		break;
	case DPSW_LEARNING_MODE_HW: /*!< Enable HW auto-Learning */
		options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_AUTOMATIC_LEARNING;
		break;
	case DPSW_LEARNING_MODE_NON_SECURE: /*!<None secure learn */
		options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_UNSECURED;
		break;
	case DPSW_LEARNING_MODE_SECURE:/*!< Secure learning */
		options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_SECURED;
		break;
	default:
		break;
	}
	return options;
}

uint32_t vlan_if_get_options(struct dpsw *dpsw,
	enum ctlu_type ctlu_type,
	uint16_t vlan_id,
	uint16_t if_id)
{
	uint32_t options = 0;
	struct dpsw_vlan *vlan;
	struct dpsw_vlan_if *vlan_if;
	struct dpsw_if *iface;
	int err;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, options);

	/*! obtain VLAN interface */
	vlan_if = &(vlan->iface[if_id]);

	/*! obtain interface */
	iface = &(dpsw->iface[if_id]);

	options |= vlan_if_get_stp_options(dpsw, ctlu_type, vlan_id, if_id);

	options |= vlan_if_get_learning_mode_options(dpsw, vlan_id, if_id);

	/* EVMODE, Egress VLAN mode */
	options |=
		(vlan_if->untagged == 1) ?
			DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_REMOVE : 0;

	/*! Mirroring */
	options |=
		(vlan_if->mirr == 1) ?
			DPTBL_L2SWITCH_VLAN_ACTION_SET_MIRRORING : 0;

	/* Set Multicast */
	if ((dpsw->multicast_enable == 1) && (iface->multicast_enable == 1))
		options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_MULTICAST;

	/* Set broadcast */
	if (iface->broadcast_enable == 1)
		options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_BROADCAST;

	/* Set flooding */
	if ((dpsw->flooding_enable == 1) && (iface->flooding_enable == 1))
		options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_FLOODING;

	/*! Set pruning */
	options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_PRUNING;
	return options;
}

int dpsw_vlan_add_if_untagged(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg)
{
	int err = 0;


	err = vlan_if_untagged(dpsw, /*! Context */
				vlan_id, /*! vlan */
				cfg, /*! set of ports */
				1); /*! EVMODE = untagged */

	return err;
}

int vlan_if_untagged(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg,
	int untagged)
{
	/*
	 *      Find VLAN slot
	 *      Mark untagged interfaces
	 *      update VALN flows
	 */
	int err;
	uint16_t i, if_id;
	struct dpsw_vlan *vlan;

	err = vlan_untagged_params_integrity(dpsw, vlan_id, cfg, untagged);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	for (i = 0; i < cfg->num_ifs; i++) {
		if_id = cfg->if_id[i];

		if (vlan->iface[if_id].untagged == (!untagged)) {
			/* Mark untagged interface */
			vlan->iface[if_id].untagged = untagged;

			/* update VALN flow */
			err = vlan_tbl_entry_update(dpsw, /*! Context */
							CTLU_EIOP_EGRESS, /*! CTLU type */
							vlan_id, /*! VLAN ID */
							if_id); /*! interface id */

			if (err != 0)
				break;
		}
	}
	return err;
}

int dpsw_vlan_add_if_flooding(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg)
{
	/*
	 *      Verify parameters integrity
	 *      add interfaces into link list replic_add
	 */
	int err = 0;
	uint16_t i, num_ifs = 0;
	struct dpsw_vlan *vlan;
	struct dpsw_if *iface;
	struct dpsw_vlan_if_cfg vlan_cfg = {0};
	struct linkman_endpoint	ep1, ep2;
	struct linkman_connection_attr connection_attr;

	if (dpsw->flooding_cfg != DPSW_FLOODING_PER_VLAN) {
		pr_err("flooding_cfg != DPSW_FLOODING_PER_VLAN: cannot configure per VLAN flooding\n");
		return -EINVAL;
	}

	/* Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	/* check for all interfaces*/
	for (i = 0; i < cfg->num_ifs; i++)
	{
		iface = &(dpsw->iface[cfg->if_id[i]]);

		if (iface->lag_enabled && !ceetm_if_is_lag_master(iface->ceetm_if))
		{
			pr_info("LAG: slave interface %d not added to flooding domain in VLAN %d\n",
					cfg->if_id[i], vlan_id);
			continue;
		}

		vlan_cfg.if_id[num_ifs++] = cfg->if_id[i];
	}

	vlan_cfg.num_ifs = num_ifs;

	/* Verify Configuration parameters */
	err = vlan_flooding_params_integrity(dpsw, vlan_id, &vlan_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* there are up interfaces to be added into flooding replic now? */
	memset(&vlan_cfg, 0, sizeof(vlan_cfg));
	num_ifs = 0;

	for (i = 0; i < cfg->num_ifs; i++) {
		iface = &(dpsw->iface[cfg->if_id[i]]);

		if (iface->lag_enabled && !ceetm_if_is_lag_master(iface->ceetm_if)) {
			continue;
		}

		/* set flooding indication */
		vlan->iface[cfg->if_id[i]].flooding_enable = dpsw->flooding_enable;

		memset(&ep1, 0, sizeof(ep1));
		memset(&ep2, 0, sizeof(ep1));
		memset(&connection_attr, 0, sizeof(connection_attr));

		ep1.type = FSL_MOD_DPSW;
		ep1.id = (uint16_t)dpsw->id;
		ep1.if_id = cfg->if_id[i];
		err = linkman_get_connection(dpsw->handle.linkman, &ep1, &ep2, &connection_attr);
		if( err ) {
			pr_info("DPSW.%d cannot add interface %d to flooding replicator. No object connected on this interface\n",
					dpsw->id, cfg->if_id[i]);
			continue;
		}
		if( connection_attr.state != LINKMAN_STATE_LINKUP ) {
			pr_info("DPSW.%d interface %d not up, will be added to flooding replic later\n", dpsw->id, cfg->if_id[i]);
			continue;
		}

		vlan_cfg.if_id[num_ifs++] = cfg->if_id[i];
	}

	if( num_ifs == 0 )
		return 0;

	vlan_cfg.num_ifs = num_ifs;

	/*! Add interface into link list */
	err = replic_add(dpsw, &(vlan->flooding), &vlan_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}

static int vlan_untagged_params_integrity(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg,
	int untagged)
{
	int i, err = 0;
	uint16_t if_id;
	struct dpsw_vlan *vlan;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	if (err != 0)
		return err;

	if (cfg->num_ifs == 0)
		return -EEXIST; /*! nothing to add */

	if (cfg->num_ifs >= DPSW_MAX_IF)
		return -EINVAL; /*! out of domain */

	for (i = 0; i < cfg->num_ifs; i++) {
		if_id = cfg->if_id[i]; /*! obtain interface ID */

		/*! Is ID OK? */
		if (if_id >= dpsw->num_ifs) {
			return -EINVAL; /*!< Invalid argument */
		}

		/* Is port belong to VLAN? */
		if (vlan->iface[if_id].assigned == 0)
			return -EINVAL; /* Invalid argument */

		/* Is port already tagged untagged? */
		if (vlan->iface[if_id].untagged == untagged)
			return -EINVAL; /* Invalid argument */

	}
	return err;
}

static int vlan_flooding_params_integrity(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg)
{
	int i, err = 0;
	uint16_t if_id;
	struct dpsw_vlan *vlan;

	/*! Flooding per switch is enabled */
	CHECK_COND_RETVAL(dpsw->flooding_enable, -EACCES);

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	if (err != 0)
		return err;

	if (cfg->num_ifs == 0)
		return -EEXIST; /*! nothing to add */

	if (cfg->num_ifs >= DPSW_MAX_IF)
		return -EINVAL; /*! out of domain */

	for (i = 0; i < cfg->num_ifs; i++) {
		if_id = cfg->if_id[i]; /*! obtain interface ID */

		/*! Is ID OK? */
		if (if_id >= dpsw->num_ifs) {
			return -EINVAL; /*!< Invalid argument */
		}

		/*! Is port belong to VLAN? */
		if (vlan->iface[if_id].assigned == 0)
			return -EINVAL; /*!< Invalid argument */
	}
	return err;
}

static int vlan_remove_if_params_integrity(struct dpsw *dpsw,
        uint16_t vlan_id,
        const struct dpsw_vlan_if_cfg *cfg)
{
        int i, err = 0;
        uint16_t if_id;
        struct dpsw_vlan *vlan;

        /*! Retrieve vlan database */
        err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
        CHECK_COND_RETVAL(err == 0, err);


        if (cfg->num_ifs == 0)
                return -EEXIST; /*! nothing to add */

        if (cfg->num_ifs >= DPSW_MAX_IF)
                return -EINVAL; /*! out of domain */

        for (i = 0; i < cfg->num_ifs; i++) {
                if_id = cfg->if_id[i]; /*! obtain interface ID */

                /*! Is ID OK? */
                if (if_id >= dpsw->num_ifs) {
                        return -EINVAL; /*!< Invalid argument */
                }

                /*! Is port doesn't belong to VLAN? */
                if (vlan->iface[if_id].assigned == 0)
                        return -EINVAL; /*!< Invalid argument */
        }
        return err;
}

int dpsw_vlan_remove_if(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg)
{
	int err = 0, i;
	uint16_t if_id;
	struct dpsw_vlan_if_cfg vlan_if;
	
	memset(&vlan_if, 0, sizeof(struct dpsw_vlan_if_cfg));

	err = vlan_remove_if_params_integrity(dpsw, vlan_id, cfg);
	CHECK_COND_RETVAL(err == 0, err, "Invalid parameters for vlan %d", vlan_id);


	for (i = 0; i < cfg->num_ifs; i++) {

		if_id = cfg->if_id[i]; /*Get Interface ID */

		/* Remove an entry from ingress VLAN table */
		err = vlan_tbl_entry_remove(dpsw, /*! Context */
						CTLU_EIOP_INGRESS, /*! CTLU type */
						vlan_id, /*! VLAN ID */
						if_id); /*! interface id */
		if (err != 0) {
			pr_err("Failded to remove ingress table entry for vlan %d\n", vlan_id);
			break;
		}

		/* Remove an entry from egress VLAN table */
		err = vlan_tbl_entry_remove(dpsw, /*! Context */
						CTLU_EIOP_EGRESS, /*! CTLU type */
						vlan_id, /*! VLAN ID */
						if_id); /*! interface id */
		if (err != 0) {
			pr_err("Failded to remove egress table entry for vlan %d\n", vlan_id);
			break;
		}

		/* Prepare remove structuret */
		vlan_if.if_id[vlan_if.num_ifs] = if_id;
		vlan_if.num_ifs++;
	}

	/* delay between WRIOP and QBMAN configurations */
	timer_udelay(2000);

	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_VLAN)
		dpsw_vlan_remove_if_flooding(dpsw, vlan_id, &vlan_if);

	for( i = 0 ; i < vlan_if.num_ifs ; i++ ) {
		if_id = vlan_if.if_id[i];

		/* Remove an entry from internal database */
		err = vlan_if_dbase_remove(dpsw, vlan_id, if_id);
		CHECK_COND_RETVAL( err==0 , err, "Failed to remove interface %d from vlan %d database\n",
				if_id, vlan_id);
	}

	return err;
}

static int vlan_tbl_entry_remove(struct dpsw *dpsw,
	enum ctlu_type ctlu_type,
	uint16_t vlan_id,
	uint16_t if_id)
{
	int err;
	uint32_t key;
	struct dpsw_if *iface;
	struct dptbl_l2switch_vlan_rule_cfg rule;
	struct dptbl *vlan_tbl;
	struct dpsw_vlan *vlan;

	memset(&rule, 0x0, sizeof(struct dptbl_l2switch_vlan_rule_cfg));

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	/* Compose rule */
	iface = &(dpsw->iface[if_id]);
	key = ((uint32_t)(iface->ap.ifpid) << 16) | ((uint32_t)(vlan_id));
	rule.key = (uint8_t *)&key;

	/*! Obtain CTLU handle */
	vlan_tbl =
		(ctlu_type == CTLU_EIOP_EGRESS) ?
			dpsw->vlan_egr.tbl : dpsw->vlan_ing.tbl;

	/* Remove an entry */
	err = dptbl_remove_rule_l2switch_vlan(vlan_tbl, /* Table handle */
						&rule); /* Rule */

	err = (err == -ENAVAIL) ? 0 : err; /*! Resource not found */

	return err;
}

static int vlan_if_dbase_remove(struct dpsw *dpsw,
	uint16_t vlan_id,
	uint16_t if_id)
{
	int err;
	struct dpsw_vlan_if *vlan_if;
	struct dpsw_vlan *vlan;

	if (if_id >= dpsw->num_ifs)
		return -ENODEV; /*!< No such device */

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	vlan_if = &(vlan->iface[if_id]); /* Obtain interface pointer */

	vlan_if->assigned = 0; /* Mark as detached */

	return err;
}

int dpsw_vlan_remove_if_untagged(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg)
{
	int err = 0;

	err = vlan_if_untagged(dpsw, /*! Context */
				vlan_id, /*! vlan */
				cfg, /*! set of ports */
				0); /*! EVMODE = tagged */

	return err;
}

int dpsw_vlan_remove_if_flooding(struct dpsw *dpsw,
	uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg)
{
	/**
	 * Verify Configuration parameters
	 * Read fdb entry
	 * if_groups_inclusive
	 * rpl_remove_group
	 * if rpl_pool inuse == 0
	 *      remove an entry
	 *
	 */
	int err = 0;
	struct dpsw_vlan *vlan;
	struct dpsw_if *iface;
	struct dpsw_vlan_if_cfg vlan_cfg = {0};
	struct linkman_endpoint	ep1, ep2;
	struct linkman_connection_attr connection_attr;
	uint16_t i, num_ifs = 0;

	if (dpsw->flooding_cfg != DPSW_FLOODING_PER_VLAN) {
		pr_err("flooding_cfg != DPSW_FLOODING_PER_VLAN: cannot configure per VLAN flooding\n");
		return -EINVAL;
	}

	for (i = 0; i < cfg->num_ifs; i++)
	{
		iface = &(dpsw->iface[cfg->if_id[i]]);

		if (iface->lag_enabled && !ceetm_if_is_lag_master(iface->ceetm_if))
		{
			pr_info("LAG: slave interface %d not removed from flooding domain for VLAN %d\n",
					cfg->if_id[i], vlan_id);
			continue;
		}

		vlan_cfg.if_id[num_ifs++] = cfg->if_id[i];
	}

	vlan_cfg.num_ifs = num_ifs;

	/*! Verify Configuration parameters */
	err = vlan_flooding_params_integrity(dpsw, vlan_id, &vlan_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	/* there are up interfaces to be removed from flooding replic now? */
	memset(&vlan_cfg, 0, sizeof(vlan_cfg));
	num_ifs = 0;

	for (i = 0; i < cfg->num_ifs; i++) {
		iface = &(dpsw->iface[cfg->if_id[i]]);

		if (iface->lag_enabled && !ceetm_if_is_lag_master(iface->ceetm_if)) {
			continue;
		}

		if( !vlan->iface[cfg->if_id[i]].flooding_enable ) {
			continue;
		}

		vlan->iface[cfg->if_id[i]].flooding_enable = 0;

		memset(&ep1, 0, sizeof(ep1));
		memset(&ep2, 0, sizeof(ep1));
		memset(&connection_attr, 0, sizeof(connection_attr));

		ep1.type = FSL_MOD_DPSW;
		ep1.id = (uint16_t)dpsw->id;
		ep1.if_id = cfg->if_id[i];
		err = linkman_get_connection(dpsw->handle.linkman, &ep1, &ep2, &connection_attr);
		if( err ) {
			pr_info("DPSW.%d remove %d to flooding replicator. No object connected on this interface\n",
					dpsw->id, cfg->if_id[i]);
			continue;
		}
		if( connection_attr.state != LINKMAN_STATE_LINKUP ) {
			pr_info("DPSW.%d interface %d not up and not present in replicator\n", dpsw->id, cfg->if_id[i]);
			continue;
		}

		vlan_cfg.if_id[num_ifs++] = cfg->if_id[i];
	}

	if( num_ifs == 0 )
		return 0;

	vlan_cfg.num_ifs = num_ifs;
	err = replic_remove(dpsw, &(vlan->flooding), &vlan_cfg);

	dbg_replic(dpsw, vlan->flooding.rrid.root);


	return err;
}

int dpsw_vlan_get_attributes(struct dpsw *dpsw,
	uint16_t vlan_id,
	struct dpsw_vlan_attr *attr)
{
	int err;
	struct dpsw_vlan *vlan;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	/*! FDB ID */
	attr->fdb_id = vlan->fdb_id;

	/*! Number of flooding interfaces */
	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_VLAN)
		attr->num_flooding_ifs = replic_get_ifs_cnt(dpsw, &(vlan->flooding));

	/*! Number interfaces */
	err = vlan_ifs_cnt(dpsw, vlan_id, &(attr->num_ifs));
	CHECK_COND_RETVAL(err == 0, err);

	/*! Number of untagged egress interfaces */
	err = vlan_untagged_ifs_cnt(dpsw, vlan_id, &(attr->num_untagged_ifs));
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}

int dpsw_vlan_get_if(struct dpsw *dpsw,
	uint16_t vlan_id,
	struct dpsw_vlan_if_cfg *cfg)
{
	int err = 0;
	uint16_t i;
	struct dpsw_vlan *vlan;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	for (i = 0, cfg->num_ifs = 0; i < dpsw->num_ifs; i++) {
		if (vlan->iface[i].assigned == 1)
			cfg->if_id[cfg->num_ifs++] = i;
	}
	return err;
}

int dpsw_vlan_get_if_flooding(struct dpsw *dpsw,
	uint16_t vlan_id,
	struct dpsw_vlan_if_cfg *cfg)
{
	int err = 0;
	struct dpsw_vlan *vlan;
	int if_id;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cfg, 0x0, sizeof(struct dpsw_vlan_if_cfg));

	cfg->num_ifs = 0;

	if (dpsw->flooding_enable == 1) {
		for( if_id = 0 ; if_id < dpsw->num_ifs ; if_id++ ) {
			if( vlan->iface[if_id].assigned ) {
				if( vlan->iface[if_id].flooding_enable ) {
					cfg->if_id[cfg->num_ifs] = (uint16_t)if_id;
					cfg->num_ifs++;
				}
			}
		}
	}

	return err;
}

int dpsw_vlan_get_if_untagged(struct dpsw *dpsw,
	uint16_t vlan_id,
	struct dpsw_vlan_if_cfg *cfg)
{
	int err = 0;
	uint16_t i;
	struct dpsw_vlan *vlan;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	for (i = 0, cfg->num_ifs = 0; i < dpsw->num_ifs; i++) {
		if ((vlan->iface[i].assigned == 1)
			&& (vlan->iface[i].untagged == 1))
			cfg->if_id[cfg->num_ifs++] = i;
	}
	return err;
}

int dpsw_fdb_add_unicast(struct dpsw *dpsw,
	uint16_t fdb_id,
	const struct dpsw_fdb_unicast_cfg *cfg)
{
	/**
	 -# Verify Configuration parameters
	 -# Add entriy into FDB lookup table
	 */

	int err = 0, qdid;
	struct dptbl_l2switch_fdb_rule_cfg rule; /* Rule */
	struct dptbl_l2switch_fdb_action action; /* Action */
	uint8_t mac_addr[6]; /* MAC */
	struct dpsw_fdb *fdb;

	memset(&action, 0x0, sizeof(struct dptbl_l2switch_fdb_action));
	memset(&rule, 0x0, sizeof(struct dptbl_l2switch_fdb_rule_cfg));

	/* Verify Configuration parameters */
	if (cfg->if_egress >= dpsw->num_ifs)
		return -EDOM; /* Numerical argument out of domain */

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	CHECK_COND_RETVAL(fdb->hndl, -EFAULT); /* Bad address */

	if ((cfg->mac_addr[0] & 0x01) == 0x01) /*! Is it multi-cast address? */
		return -EFAULT; /* Bad address */

	memcpy(&mac_addr[0], &(cfg->mac_addr[0]), 6);

        /* Obtain qdid */
        err = get_iface_qdid(dpsw, cfg->if_egress, &qdid);
        CHECK_COND_RETVAL(err == 0, err);

	/* rule */
	rule.key = &mac_addr[0];

	/* action */
	action.options =
		(cfg->type == DPSW_FDB_ENTRY_STATIC) ?
			DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS : /* Static Entry*/
			DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_AGING; /* Dynamic */
	action.qd_id = qdid; 					/* QDID */
	action.replic_list_id = dpsw->iface[cfg->if_egress].rrid.root;/* RRID */

	err = dptbl_add_or_modify_rule_l2switch_fdb(fdb->hndl, &rule, &action);

	return err;
}

int dpsw_fdb_get_unicast(struct dpsw *dpsw,
	uint16_t fdb_id,
	struct dpsw_fdb_unicast_cfg *cfg)
{
	/*
	 * Verify parameters
	 * Read an entry from fdb table
	 * convert qdid to interface id
	 */
	int err = 0;
	struct dptbl_l2switch_fdb_action entry;

	memset(&entry, 0x0, sizeof(struct dptbl_l2switch_fdb_action));

	/*! Verify Configuration parameters */
	if ((cfg->mac_addr[0] & 0x01) == 0x01) /*! Is it multi-cast address? */
		return -EFAULT; /* Bad address */

	/*! Read an entry from fdb table */
	err = fdb_entry_query(dpsw, /*! Context */
				fdb_id, /*! FDB ID */
				cfg->mac_addr, /*! Ethernet address */
				&entry); /*! An output entry*/
	CHECK_COND_RETVAL(err == 0, err);

	/*! Convert vqdid to interface id */
	err = qdid_to_ifid(dpsw, entry.qd_id, &(cfg->if_egress));

	/* setup an options */
	cfg->type = (entry.options == DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS)
		? DPSW_FDB_ENTRY_STATIC : DPSW_FDB_ENTRY_DINAMIC;


	return err;
}

int dpsw_get_attributes(struct dpsw *dpsw, struct dpsw_attr *attr)
{
	struct dpsw_buffer_pool_desc *buffer_pools;
	int i;

	buffer_pools = dpsw->buffer_pools;

	attr->id = dpsw->id;
	attr->version.minor = (uint16_t)dpsw->version.minor;
	attr->version.major = (uint16_t)dpsw->version.major;

	/* Setting options */
	attr->options =
		(dpsw->flooding_enable == 0) ? DPSW_OPT_FLOODING_DIS : 0;
	attr->options |=
		(dpsw->multicast_enable == 0) ? DPSW_OPT_MULTICAST_DIS : 0;
	attr->options |= (dpsw->ctrl_if_enable == 0) ? DPSW_OPT_CTRL_IF_DIS : 0;

	attr->options |= (dpsw->metering_enable == 1) ? DPSW_OPT_METERING_EN : 0;

	attr->options |= (dpsw->flooding_metering_enable == 0) ?
			DPSW_OPT_FLOODING_METERING_DIS : 0;

	attr->options |= (dpsw->bp_per_if == 1) ? DPSW_OPT_BP_PER_IF : 0;

	attr->options |= (dpsw->lag_enable == 0) ? DPSW_OPT_LAG_DIS : 0;

	attr->max_vlans = dpsw->max_vlans; /* Maximum Number of VLAN�s */
	attr->max_fdbs = dpsw->max_fdbs; /* Maximum Number of FDB�s */

	attr->mem_size = 0;
	for(i = 0; i < dpsw->num_buffer_pools; i++)
		attr->mem_size += (uint16_t)(buffer_pools[i].memory_size / DPSW_BP_BUFFER_SIZE); /* L2 Switch storage size */

	attr->num_ifs = dpsw->num_ifs; /* Number of interfaces */
	/* Current number of VLAN�s */
	attr->num_vlans = (uint16_t)hmap_get_count(dpsw->hmap_vlan);
	attr->num_fdbs = (uint8_t)hmap_get_count(dpsw->hmap_fdb);

	attr->fdb_aging_time = dpsw->fdb_aging_time;
	attr->max_fdb_entries = dpsw->max_fdb_entries;
	attr->max_fdb_mc_groups = dpsw->max_fdb_mc_groups;
	attr->max_meters_per_if = dpsw->max_meters_per_if;
	attr->component_type = dpsw->component_type;
	attr->flooding_cfg = dpsw->flooding_cfg;
	attr->broadcast_cfg = dpsw->broadcast_cfg;

	return 0;
}

static int dpsw_fdb_dump_write_unicast(struct device *dev, uint64_t iova_addr, struct dpsw_fdb_unicast_cfg *unicast)
{
	struct fdb_dump_entry entry = {0};
	int i;
	int err;

	for( i=0 ; i<6 ; i++ ) {
		entry.mac_addr[i] = unicast->mac_addr[i];
	}
	entry.if_info 	= (uint8_t)unicast->if_egress;
	entry.type 		= unicast->type;
	entry.type		= entry.type | 0x02;

	err = dpmng_dev_memcpy(dev, &entry, iova_addr, sizeof(entry), 0);
	if (err) {
		pr_err("Error writing extended DMA parameters\n");
		return err;
	}

	return 0;
}

static int dpsw_fdb_dump_write_multicast(struct device *dev, uint64_t iova_addr, struct dpsw_fdb_multicast_cfg *multicast)
{
	struct fdb_dump_entry entry = {0};
	int i;
	int err;

	for( i=0 ; i<6 ; i++ ) {
		entry.mac_addr[i] = multicast->mac_addr[i];
	}
	entry.if_info 	= (uint8_t)multicast->num_ifs;
	entry.type 		= multicast->type;
	for( i=0 ; i<multicast->num_ifs ; i++ ) {
		entry.if_mask[multicast->if_id[i]/8] |= (0x01 << (multicast->if_id[i]%8));
	}

	err = dpmng_dev_memcpy(dev, &entry, iova_addr, sizeof(entry), 0);
	if (err) {
		pr_err("Error writing extended DMA parameters\n");
		return err;
	}

	return 0;
}

int dpsw_dump_fdb_table(struct device *dev, uint16_t fdb_id, uint64_t iova_addr, int iova_size, uint16_t *table_size)
{
	struct dpsw_fdb *fdb;
	int err;
	uint64_t ruleid = 0, tmp_rule;
	int modify_create = 0;
	struct dpsw_fdb_unicast_cfg unicast_cfg;
	struct dpsw_fdb_multicast_cfg multicast_cfg;
	uint8_t mac_addr[6];
	struct eiop_desc desc = {0};
	struct dpsw *dpsw;
	int remaining_bytes;
	int entry_size;
	uint16_t num_entries = 0;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	err = soc_db_get_desc(SOC_MODULE_EIOP, SOC_DB_NO_MATCH_FIELDS, &desc, NULL);
	CHECK_COND_RETVAL(err==0, err, "Could not obtain wriop descriptor\n");
	CHECK_COND_RETVAL(desc.wriop_version!=WRIOP_VERSION(1, 0, 0), -ENOSYS, "Could not execute operation in this hw platform\n");

	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err==0, err, "fdb table with id %d not found\n", fdb_id);

	pr_info("%16s %17s %7s %6s\n",
			"RuleId", "mac_addr", "Type", "If_egr");
	entry_size = sizeof(struct fdb_dump_entry);
	remaining_bytes = iova_size;
	do {
		err = dptbl_get_next_ruleid(fdb->hndl, &ruleid);
		if( err ) {
			pr_err("No entry found for ruleid %08x%08x\n", (uint32_t)((ruleid>>32)&0xffffffff), (uint32_t)(ruleid&0xffffffff));
			break;
		}
		if( ruleid==0 ) {
			err = 0;
			break;
		}
		if( remaining_bytes<entry_size ) {
			pr_warn("More entries are available but the allocated area is too small\n");
			break;
		}
		err = dptbl_query_with_ruleid(fdb->hndl, &ruleid, mac_addr, sizeof(mac_addr));
		if( err ) {
			pr_err("Query failed for ruleid %08x%08x\n", 
					(uint32_t)((ruleid>>32)&0xffffffff)  , 
					(uint32_t)(ruleid&0xffffffff) );
			break;
		}
		tmp_rule = ruleid;
		ruleid++;

		/* Don't dump the FDB rule used for broadcast.
		 * It's not added by the user, not present in the FDB hmap,
		 * so just skip it.
		 */
		if (NH_ETH_IS_BROADCAST_ADDR(mac_addr)) {
			continue;
		}

		if( dpsw->multicast_enable && (mac_addr[0]&0x01)==0x01 ) {
			memset(&multicast_cfg, 0, sizeof(multicast_cfg));
			memcpy(multicast_cfg.mac_addr, mac_addr, sizeof(mac_addr));
			err = dpsw_fdb_get_multicast(dpsw, fdb_id, &multicast_cfg);
			if( err ) {
				pr_warn("dpsw_fdb_get_multicast() failed for %02x-%02x-%02x-%02x-%02x-%02x\n",
						multicast_cfg.mac_addr[0], multicast_cfg.mac_addr[1], multicast_cfg.mac_addr[2],
						multicast_cfg.mac_addr[3], multicast_cfg.mac_addr[4], multicast_cfg.mac_addr[5]);
				continue;
			}
			err = dpsw_fdb_dump_write_multicast(dev, iova_addr, &multicast_cfg);
			if( err ) {
				break; // keep in table all the entries found until now
			}
			pr_info("%08x%08x " "%02x-%02x-%02x-%02x-%02x-%02x " "%7s " "%6d" "\n",
					(uint32_t)((tmp_rule>>32)&0xffffffff), (uint32_t)(tmp_rule&0xffffffff),
					multicast_cfg.mac_addr[0], multicast_cfg.mac_addr[1], multicast_cfg.mac_addr[2], multicast_cfg.mac_addr[3], multicast_cfg.mac_addr[4], multicast_cfg.mac_addr[5], 
					(multicast_cfg.type==DPSW_FDB_ENTRY_STATIC)?"STATIC":"DYNAMIC",
					-1);
		} else {
			memset(&unicast_cfg, 0, sizeof(unicast_cfg));
			memcpy(unicast_cfg.mac_addr, mac_addr, sizeof(mac_addr));
			err = dpsw_fdb_get_unicast(dpsw, fdb_id, &unicast_cfg);
			if( err ) {
				pr_warn("dpsw_fdb_get_unicast() failed for %02x-%02x-%02x-%02x-%02x-%02x\n",
						unicast_cfg.mac_addr[0], unicast_cfg.mac_addr[1], unicast_cfg.mac_addr[2],
						unicast_cfg.mac_addr[3], unicast_cfg.mac_addr[4], unicast_cfg.mac_addr[5]);
				continue;
			}
			err = dpsw_fdb_dump_write_unicast(dev, iova_addr, &unicast_cfg);
			if( err ) {
				break; // keep in table all the entries found until now
			}
			pr_info("%08x%08x " "%02x-%02x-%02x-%02x-%02x-%02x " "%7s " "%6d" "\n",
					(uint32_t)((tmp_rule>>32)&0xffffffff), (uint32_t)(tmp_rule&0xffffffff),
					unicast_cfg.mac_addr[0], unicast_cfg.mac_addr[1], unicast_cfg.mac_addr[2], unicast_cfg.mac_addr[3], unicast_cfg.mac_addr[4], unicast_cfg.mac_addr[5],
					(unicast_cfg.type==DPSW_FDB_ENTRY_STATIC)?"STATIC":"DYNAMIC",
					unicast_cfg.if_egress);
		}
		remaining_bytes -= entry_size;
		iova_addr += entry_size;
		num_entries++;
	} while( ruleid!=0 );
	
	*table_size = num_entries;

	return err;
}

static int dpsw_if_update_pfc_settings(struct dpsw *dpsw, int if_id, uint32_t flags)
{
	if( !(flags & DPSW_UPDATE_FC) )
		return 0;

	dpsw_if_update_bp_config(dpsw, if_id, flags);
	dpsw_if_update_channel_fc(dpsw, if_id, flags);

	return 0;
}

static int dpsw_disable_fc(struct dpsw *dpsw)
{
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr link_attr;
	struct dpsw_if *iface;
	uint32_t pfc_flags;
	void *object;
	int if_id;
	int err;

	for( if_id = 0 ; if_id < dpsw->num_ifs ; if_id++ ) {
		iface = &(dpsw->iface[if_id]);

		pfc_flags = DPSW_UPDATE_FC;
		dpsw_if_update_pfc_settings(dpsw, if_id, pfc_flags);

		if( iface->fc_idx == FLOW_CONTROL_INVALID_INDEX )
			continue;

		memset(&endpoint1, 0, sizeof(endpoint1));
		memset(&endpoint2, 0, sizeof(endpoint2));
		memset(&link_attr, 0, sizeof(link_attr));

		endpoint1.type	= FSL_MOD_DPSW;
		endpoint1.id	= (uint16_t)dpsw->id;
		endpoint1.if_id	= (uint16_t)if_id;
		err = linkman_get_connection(dpsw->handle.linkman, &endpoint1, &endpoint2, &link_attr);
		if( err ) {
			
		}
		CHECK_COND_RETVAL(err==0, err, "Could not get connected object to dpni.%d\n", dpsw->id);

		object = sys_get_handle(endpoint2.type, 1, endpoint2.id);
		CHECK_COND_RETVAL(object, -ENODEV, "[ID: %d] Could not get connected object\n", dpsw->id);

		switch( endpoint2.type ) {
		case FSL_MOD_DPNI:
			dpni_clean_flow_control_config(object);
			break;
		default:
			pr_err("ID[%d] - invalid flow control configuration on interface %d, continue\n", if_id);
			break;
		}

		fc_release_channel_idx(iface->fc_idx);
		iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
	}

	return 0;
}

int dpsw_reset(struct dpsw *dpsw)
{
	/*
	 *      Disable all interfaces
	 *      Clear all IFP counters
	 *      Remove all VLANs
	 *      Remove all FDBs
	 *      init_internal_database
	 *      Reconfigure ceetm qman restore 1 Traffic class
	 *      Add VLAN 1
	 *      Attach all interfaces to VLAN 1
	 *      init_default_configuration
	 *      enable all interfaces
	 */
	int err = 0;

	/*! Disable flow control on all interfaces */
	err = dpsw_disable_fc(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Disable all interfaces */
	err = dpsw_disable(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Clear all IFP counters */
	err = eiop_ifp_clear_counters(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Remove all VLANs */
	err = vlan_remove_all(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Remove all FDBs  */
	err = fdb_remove_all(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Remove all ACLs  */
	err = acl_remove_all(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! init internal database */
	init_internal_database(dpsw);

	/*! Add VLAN 1 */
	err = init_vlan(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! init_default_configuration */
	err = init_default(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! init the learning behavior */
	err = init_learning(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! enable all interfaces */
	err = dpsw_enable(dpsw);

	return err;
}

int dpsw_fdb_set_learning_mode(struct dpsw *dpsw,
	uint16_t fdb_id,
	enum dpsw_learning_mode mode)
{
	/*
	 * Update learning mode in FDB database
	 * Update all entries in VLAN lookup table associated with the FDB
	 */
	int err = -ENODEV; /*! device not configured */
	struct dpsw_fdb *fdb;
	struct dpsw_vlan *vlan;
	int iter, iter_status;
	uint8_t key[2];
	uint16_t vlan_id;

	err = dpsw_learning_params_integrity(dpsw, mode);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update learning mode in FDB database */
	fdb->learning_mode = mode;

	iter_status = hmap_get_start_iterator(dpsw->hmap_vlan, &iter);

	while (iter_status == 0) {
		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(dpsw->hmap_vlan, &iter, key,
						(void **)&vlan);

		vlan_id = MAKE_UINT16(key[0], key[1]);

		if (vlan->fdb_id == fdb_id) {
			err = vlan_tbl_update(dpsw, vlan_id);
			if (err != 0)
				break;
		}
	}
	return err;
}

static int dpsw_learning_params_integrity(struct dpsw *dpsw,
	enum dpsw_learning_mode mode) {

	int err = 0;

	switch (mode) {
		case DPSW_LEARNING_MODE_DIS:
		case DPSW_LEARNING_MODE_HW:
			break;
		case DPSW_LEARNING_MODE_NON_SECURE:
		case DPSW_LEARNING_MODE_SECURE:
			if (dpsw->ctrl_if_enable == 0)
				err = -EINVAL;
			break;
		default:
			break;
	}
	return err;
}


int dpsw_set_policer(struct dpsw *dpsw, const struct dpsw_policer_cfg *cfg)
{
	UNUSED(dpsw);
	UNUSED(cfg);
	return 0;
}

int dpsw_if_tc_set_cn(struct dpsw *dpsw,
	uint16_t if_id,
	uint8_t tc_id,
	const struct dpsw_cn_cfg *cfg)
{
	UNUSED(dpsw);
	UNUSED(if_id);
	UNUSED(tc_id);
	UNUSED(cfg);

	return 0;
}

static int set_quartet_unicast(struct dpsw *dpsw)
{
	int err = 0, i;
	struct dpsw_if *iface;

	/*! Update unicast reflection  */
	for (i = 0; i < dpsw->num_ifs; i++) {

		/*! Obtain interface */
		iface = &(dpsw->iface[i]);

		/*! configure quartet mirr */
		err = replic_configure_quartet_mirr(dpsw, &(iface->rrid));
		CHECK_COND_RETVAL(err == 0, err);

		/*! configure quartet software learning */
		err = replic_configure_quartet_swl(dpsw, &(iface->rrid));
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int set_quartet_multicast(struct dpsw *dpsw)
{
	int err = 0, i, j;
	struct dpsw_fdb *fdb;
	struct dpsw_replic *replic;

	if (dpsw->multicast_enable == 0)
		return err;

	/*! Update multicast reflection */
	for (i = 0; i < dpsw->max_fdbs; i++) {
		/*! Obtain FDB */
		err = hmap_get_data(dpsw->hmap_fdb, i, (hmap_data *)&fdb);
		CHECK_COND_RETVAL(err == 0, err);

		for (j = 0; j < dpsw->max_fdb_mc_groups; j++) {
			/*! get hmap data */
			err = hmap_get_data(fdb->hmap_mcast, j,
						(hmap_data *)&replic);
			CHECK_COND_RETVAL(err == 0, err);

			/*! configure quartet mirr */
			err = replic_configure_quartet_mirr(
				dpsw, &(replic->rrid));
			CHECK_COND_RETVAL(err == 0, err);

			/*! configure quartet software learning */
			err = replic_configure_quartet_swl(
				dpsw, &(replic->rrid));
			CHECK_COND_RETVAL(err == 0, err);
		}
	}
	return err;
}

static int set_quartet_flooding(struct dpsw *dpsw)
{
	struct dpsw_vlan *vlan;
	struct dpsw_fdb *fdb;
	int err = 0, i;

	if (dpsw->flooding_enable == 0)
		return err;

	/*! Update flooding reflection */
	if (dpsw->flooding_cfg == DPSW_FLOODING_PER_FDB) {
		for (i = 0; i < dpsw->max_fdbs; i++) {
			err = hmap_get_data(dpsw->hmap_fdb, i, (hmap_data *)&fdb);
			if (err != 0)
				break;

			/*! configure quartet mirr */
			err = replic_configure_quartet_mirr(
				dpsw, &(fdb->flooding.rrid));
			CHECK_COND_RETVAL(err == 0, err);

			/*! configure quartet software learning */
			err = replic_configure_quartet_swl(
				dpsw, &(fdb->flooding.rrid));
			CHECK_COND_RETVAL(err == 0, err);
		}
	} else {
		/* DPSW_FLOODING_PER_VLAN */
		for (i = 0; i < dpsw->max_vlans; i++) {
			err = hmap_get_data(dpsw->hmap_vlan, i, (hmap_data *)&vlan);
			if (err != 0)
				break;

			/*! configure quartet mirr */
			err = replic_configure_quartet_mirr(
				dpsw, &(vlan->flooding.rrid));
			CHECK_COND_RETVAL(err == 0, err);

			/*! configure quartet software learning */
			err = replic_configure_quartet_swl(
				dpsw, &(vlan->flooding.rrid));
			CHECK_COND_RETVAL(err == 0, err);
		}
	}
	return err;
}

static int set_quartet_broadcast(struct dpsw *dpsw)
{
	struct dpsw_fdb *fdb;
	int err = 0, i;

	if (dpsw->broadcast_cfg == DPSW_BROADCAST_PER_FDB) {
		for (i = 0; i < dpsw->max_fdbs; i++) {
			/*! Obtain FDB */
			err = hmap_get_data(dpsw->hmap_fdb, i, (hmap_data *)&fdb);
			CHECK_COND_RETVAL(err == 0, err);

			/*! configure quartet mirr */
			err = replic_configure_quartet_mirr(dpsw, &(fdb->broadcast.rrid));
			CHECK_COND_RETVAL(err == 0, err);

			/*! configure quartet software learning */
			err = replic_configure_quartet_swl(dpsw, &(fdb->broadcast.rrid));
			CHECK_COND_RETVAL(err == 0, err);
		}
	} else {
		/*! configure quartet mirr */
		err = replic_configure_quartet_mirr(dpsw, &(dpsw->broadcast.rrid));
		CHECK_COND_RETVAL(err == 0, err);

		/*! configure quartet software learning */
		err = replic_configure_quartet_swl(dpsw, &(dpsw->broadcast.rrid));
		CHECK_COND_RETVAL(err == 0, err);
	}

	return err;
}

int dpsw_set_reflection_if(struct dpsw *dpsw, uint16_t if_id)
{
	int err = 0;

	/*! Verify parameters */
	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/*! Set reflection interface */
	dpsw->mirr_if_id = if_id;

	/*! Update unicast reflection  */
	err = set_quartet_unicast(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update multicast reflection */
	err = set_quartet_multicast(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update flooding reflection */
	err = set_quartet_flooding(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Broadcast update */
	err = set_quartet_broadcast(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}

int dpsw_if_set_flooding(struct dpsw *dpsw, uint16_t if_id, int en)
{
	int err = 0;
	struct dpsw_if *iface;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL; /*! Invalid argument */

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! Update interface dataBase */
	iface->flooding_enable = en;

	/*! Update related entries in VLAN lookup table */
	err = vlan_tbl_if_update(dpsw, if_id);
	return err;
}

int dpsw_if_set_broadcast(struct dpsw *dpsw, uint16_t if_id, int en)
{
	int err = 0;
	struct dpsw_if *iface;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL; /*! Invalid argument */

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! Update interface dataBase */
	iface->broadcast_enable = en;

	/*! Update related entries in VLAN lookup table */
	err = vlan_tbl_if_update(dpsw, if_id);
	return err;
}

int dpsw_if_set_multicast(struct dpsw *dpsw, uint16_t if_id, int en)
{
	int err = 0;
	struct dpsw_if *iface;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL; /*! Invalid argument */

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! Update interface dataBase */
	iface->multicast_enable = en;

	/*! Update related entries in VLAN lookup table */
	err = vlan_tbl_if_update(dpsw, if_id);
	return err;
}

#ifdef MC_CLI
int dpsw_if_get_qdid(struct dpsw *dpsw, uint16_t if_id, int *qdid)
{
    return get_iface_qdid(dpsw, if_id, qdid);
}
#endif

int dpsw_if_set_tci(struct dpsw *dpsw,
	uint16_t if_id,
	const struct dpsw_tci_cfg *cfg)
{
	/*
	 *      verify parameters
	 *      verify port is disabled
	 *      Obtain prev pvid
	 *      Update with a new pvid
	 *      if port doesn't belong to PVID
	 *              vlan_tbl_if_admit_tagging_remove prev
	 *      vlan_tbl_if_admit_tagging_update new
	 */

	int err = 0, en, assigned;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct eiop_ifp_rx_vlan_cfg eiop_tci;
	struct dpsw_if *iface;
	struct dpsw_tci_cfg prev_tci;
	uint16_t etype;

	/* Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/* Are parameters ok? */
	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/* Ethernet type to insert */
	etype = (dpsw->component_type == DPSW_COMPONENT_TYPE_C_VLAN) ?
		NH_IEEE8021Q_ETYPE :	/* VLAN-tagged frame IEEE8021.Q */
		NH_IEEE8021AD_ETYPE;	/* Provider Bridging IEEE 802.1ad */

	/* Is port disabled? */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EFAULT);

	en = eiop_ifp_rx_is_enable(&eiop_ifp_desc);
	if (en == 1)
		return -EACCES; /*! invalid device state */

	/*! Obtain prev pvid */
	err = dpsw_if_get_tci(dpsw, if_id, &prev_tci);
	CHECK_COND_RETVAL(err == 0, err);

	/* is port belong to PVID */
	assigned = is_vlan_if_assigned(dpsw, prev_tci.vlan_id, if_id);
	if (assigned == 0) {
		/*! remove previous untagged entry*/
		err = vlan_tbl_if_admit_untagged_remove(dpsw, if_id);
		CHECK_COND_RETVAL(err == 0, err);
	}

	/*! Update with a new PVID */
	eiop_tci.action =
		(iface->admit_untagged == DPSW_ADMIT_ALL) ?
			EIOP_IFP_RX_VLAN_ACTION_COND_INSERT :
			EIOP_IFP_RX_VLAN_ACTION_NONE;
	eiop_tci.cond_insert_ethype_not_found = etype;/* 0x8100 or 0x88A8 */
	eiop_tci.insert_vlan_hdr = NH_MAKE_IEEE8021Q_HDR(etype,
		cfg->pcp, /* PCP */
		cfg->dei, /* DEI */
		cfg->vlan_id); /* VLANID */
	err = eiop_ifp_rx_vlan_cfg(&eiop_ifp_desc, &eiop_tci);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update new untagged entry */
	err = vlan_tbl_if_admit_untagged_update(dpsw, if_id);

	return err;
}

int dpsw_if_get_tci(struct dpsw *dpsw,
	uint16_t if_id,
	struct dpsw_tci_cfg *cfg)
{
	int err;
	struct eiop_ifp_rx_vlan_cfg tci;
	struct dpsw_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	iface = &(dpsw->iface[if_id]);

	/* Obtain IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* iop id */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EFAULT);

	memset(&tci, 0x0, sizeof(struct eiop_ifp_rx_vlan_cfg));

	eiop_ifp_get_rx_vlan_cfg(&eiop_ifp_desc, &tci);

	cfg->dei = (uint8_t)NH_GET_IEEE8021Q_DEI(tci.insert_vlan_hdr);
	cfg->pcp = (uint8_t)NH_GET_IEEE8021Q_PCP(tci.insert_vlan_hdr);
	cfg->vlan_id = (uint16_t)NH_GET_IEEE8021Q_VLANID(tci.insert_vlan_hdr);

	return err;
}

int dpsw_if_set_stp(struct dpsw *dpsw,
	uint16_t if_id,
	const struct dpsw_stp_cfg *cfg)
{
	int err;
	struct dpsw_vlan_if *vlan_if;
	struct dpsw_vlan *vlan;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	if (cfg->state < DPSW_STP_STATE_BLOCKING ||
	    cfg->state > DPSW_STP_STATE_FORWARDING) {
		pr_err("STP state %d not known!\n", cfg->state);
		return -EINVAL;
	}

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&(cfg->vlan_id),
				(void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	vlan_if = &(vlan->iface[if_id]);

	/* Save STP state in internal database */
	vlan_if->stp_state = cfg->state;

	/* Update an entry */
	err = vlan_tbl_entry_update(dpsw, /*! Context */
					CTLU_EIOP_INGRESS, /*! CTLU type */
					cfg->vlan_id, /*! VLAN ID */
					if_id); /*! interface id */
	CHECK_COND_RETVAL(err == 0, err);

	err = vlan_tbl_entry_update(dpsw, /*! Context */
					CTLU_EIOP_EGRESS, /*! CTLU type */
					cfg->vlan_id, /*! VLAN ID */
					if_id); /*! interface id */

	return err;
}

int dpsw_if_set_accepted_frames(struct dpsw *dpsw,
	uint16_t if_id,
	const struct dpsw_accepted_frames_cfg *cfg)
{
	/*
	 *      verify parameters
	 *      Obtain pvid
	 *      if accepted_frames == ADMIT_ALL
	 *              vlan_tbl_if_admit_tagging_remove pvid
	 *      save accepted_frames
	 *
	 *      if accepted_frames == ADMIT_ALL
	 *              vlan_tbl_if_admit_tagging_update
	 */

	int err = 0;
	struct dpsw_if *iface;
	struct dpsw_tci_cfg tci;

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! Are parameters ok? */
	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/*! Obtain pvid */
	err = dpsw_if_get_tci(dpsw, if_id, &tci);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update un-tagged */
	iface->admit_untagged = cfg->type;

	/*! Set tci */
	err = dpsw_if_set_tci(dpsw, if_id, &tci);

	return err;
}

int dpsw_if_set_accept_all_vlan(struct dpsw *dpsw,
	uint16_t if_id,
	int accept_all)
{
	int err = 0;
	struct dpsw_if *iface;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! set accept all vlan flag*/
	iface->accept_all_vlan = accept_all;


	if (iface->accept_all_vlan == 1) {
		/*! Update corresponding entries */
		err = vlan_tbl_if_accept_all_vlan_update(dpsw, if_id);
		CHECK_COND_RETVAL(err == 0, err);
	}
	else {
		/*! Update corresponding entries */
		err = vlan_tbl_if_accept_all_vlan_remove(dpsw, if_id);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

int dpsw_if_get_counter(struct dpsw *dpsw,
	uint16_t if_id,
	enum dpsw_counter type,
	uint64_t *counter)
{
	int err = 0;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct dpsw_if *iface;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	iface = &(dpsw->iface[if_id]);

	/* Obtain IFP descriptor */
	memset(&eiop_ifp_desc, 0x0, sizeof(struct eiop_ifp_desc));
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);

	switch (type) {
	case DPSW_CNT_ING_FRAME:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_INGRESS_FC); /**< Ingress frame */
		break;
	case DPSW_CNT_ING_BYTE:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_INGRESS_BC); /**< Ingress byte count */
		break;
	case DPSW_CNT_ING_FLTR_FRAME:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_INGRESS_FFC); /**< Ingress filtered frame */
		break;
	case DPSW_CNT_ING_FRAME_DISCARD:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_INGRESS_FDC); /**< Ingress frame discard */
		break;
	case DPSW_CNT_ING_MCAST_FRAME:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_INGRESS_MFC); /**< Ingress multicast frame */
		break;
	case DPSW_CNT_ING_MCAST_BYTE:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_INGRESS_MBC); /**< Ingress multicast byte */
		break;
	case DPSW_CNT_ING_BCAST_FRAME:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_INGRESS_BFC); /**< Ingress broadcast frame */
		break;
	case DPSW_CNT_ING_BCAST_BYTES:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_INGRESS_BBC); /**< Ingress broadcast byte */
		break;
	case DPSW_CNT_ING_NO_BUFFER_DISCARD:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_INGRESS_OODC); /**< Ingress no buffer discards */
		break;
	case DPSW_CNT_EGR_FRAME:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_EGRESS_FC); /**< Egress frame count */
		break;
	case DPSW_CNT_EGR_BYTE:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_EGRESS_BC); /**< Egress byte count */
		break;
	case DPSW_CNT_EGR_FRAME_DISCARD:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_EGRESS_FDC); /**< Egress frame drop count */
		break;
	case DPSW_CNT_EGR_STP_FRAME_DISCARD:
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc, E_EGRESS_STDC); /**< Egress stp frame drop count */
		break;
	default:
		err = -ENOTSUP; /*!< Operation not supported */
		break;
	}

	return err;
}

int dpsw_if_get_counters(struct dpsw *dpsw,
	uint16_t if_id,
	struct dpsw_counters_cfg *counters)
{
	int err = 0;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct dpsw_if *iface;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	iface = &(dpsw->iface[if_id]);

	/* Obtain IFP descriptor */
	memset(&eiop_ifp_desc, 0x0, sizeof(struct eiop_ifp_desc));
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);

	/*! Ingress frame count */
	counters->ing_frame = eiop_ifp_get_counter(&eiop_ifp_desc,
							E_INGRESS_FC);

	/*! Ingress byte count */
	counters->ing_byte = eiop_ifp_get_counter(&eiop_ifp_desc,
							E_INGRESS_BC);

	/*! Ingress filtered frame count */
	counters->ing_fltr_frame = eiop_ifp_get_counter(&eiop_ifp_desc,
							E_INGRESS_FFC);

	/*! Ingress frame discard count */
	counters->ing_frame_discard = eiop_ifp_get_counter(&eiop_ifp_desc,
								E_INGRESS_FDC);

	/*! Ingress multicast frame count */
	counters->ing_mcast_frame = eiop_ifp_get_counter(&eiop_ifp_desc,
								E_INGRESS_MFC);

	/*! Ingress multicast byte count */
	counters->ing_mcast_byte = eiop_ifp_get_counter(&eiop_ifp_desc,
							E_INGRESS_MBC);

	/*! Ingress broadcast frame count */
	counters->ing_bcast_frame = eiop_ifp_get_counter(&eiop_ifp_desc,
								E_INGRESS_BFC);

	/*! Ingress broad bytes count */
	counters->ing_bcast_bytes = eiop_ifp_get_counter(&eiop_ifp_desc,
								E_INGRESS_BBC);

	/*! Egress frame count */
	counters->egr_frame = eiop_ifp_get_counter(&eiop_ifp_desc,
							E_EGRESS_FC);

	/*! Egress byte count */
	counters->egr_byte = eiop_ifp_get_counter(&eiop_ifp_desc, E_EGRESS_BC);

	/* Egress frame discard counter */
	counters->egr_frame_discard = eiop_ifp_get_counter(&eiop_ifp_desc,
								E_EGRESS_FDC);

	/* Tx multicast frame counter */
	counters->erg_mcast_frame = eiop_ifp_get_counter(&eiop_ifp_desc,
	                                                 E_EGRESS_MFC);

	/* Tx multicast byte counter */
	counters->egr_mcast_byte = eiop_ifp_get_counter(&eiop_ifp_desc,
	                                                 E_EGRESS_MBC);


	/* Tx broadcast frame counter */
	counters->egr_bcast_frame = eiop_ifp_get_counter(&eiop_ifp_desc,
	                                                E_EGRESS_BFC);

	/* Tx broadcast byte counter */
	counters->egr_bcast_bytes = eiop_ifp_get_counter(&eiop_ifp_desc,
	                                                 E_EGRESS_BBC);

	counters->egr_stp_frame_discard = eiop_ifp_get_counter(&eiop_ifp_desc,
	                                                       E_EGRESS_STDC);
	return err;
}

static int eiop_ifp_clear_counters(struct dpsw *dpsw)
{
	int err = 0;
	uint16_t if_id = 0;

	for (if_id = 0; if_id < dpsw->num_ifs; if_id++) {
		err = if_eiop_ifp_clear_counters(dpsw, if_id);
		if (err != 0)
			break;
	}
	return err;
}

static int if_eiop_ifp_clear_counters(struct dpsw *dpsw, uint16_t if_id)
{
	int err = 0;
	enum dpsw_counter type;

	for (type = DPSW_CNT_ING_FRAME; type <= DPSW_CNT_EGR_STP_FRAME_DISCARD;
		type++) {
		err = dpsw_if_set_counter(dpsw, /*! Context */
						if_id, /*! Interface id */
						type, /*! Counter type */
						0); /*! Counter value */
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

int dpsw_if_set_counter(struct dpsw *dpsw,
	uint16_t if_id,
	enum dpsw_counter type,
	uint64_t counter)
{
	int err = 0;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct dpsw_if *iface;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	iface = &(dpsw->iface[if_id]);

	/* Obtain IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EFAULT);

	switch (type) {
	case DPSW_CNT_ING_FRAME:
		eiop_ifp_set_counter(&eiop_ifp_desc, /*! IFP descriptor */
					E_INGRESS_FC, /*! Counter Type */
					counter); /*! Value */
		break;
	case DPSW_CNT_ING_BYTE:
		eiop_ifp_set_counter(&eiop_ifp_desc, /*! IFP descriptor */
					E_INGRESS_BC, /*! Counter Type */
					counter); /*! Value */
		break;
	case DPSW_CNT_ING_FLTR_FRAME: /*! Ingress filtered frame */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_FFC, counter);
		break;
	case DPSW_CNT_ING_FRAME_DISCARD: /*! Ingress frame discard */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_FDC, counter);
		break;
	case DPSW_CNT_ING_MCAST_FRAME: /*! Ingress multicast frame */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_MFC, counter);
		break;
	case DPSW_CNT_ING_MCAST_BYTE: /*! Ingress multicast byte */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_MBC, counter);
		break;
	case DPSW_CNT_ING_BCAST_FRAME: /*! Ingress broadcast frame */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_BFC, counter);
		break;
	case DPSW_CNT_ING_BCAST_BYTES: /*! Ingress broadcast byte */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_BBC, counter);
		break;
	case DPSW_CNT_EGR_FRAME: /*! Egress frame count */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_EGRESS_FC, counter);
		break;
	case DPSW_CNT_EGR_BYTE: /*! Egress byte count */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_EGRESS_BC, counter);
		break;
	case DPSW_CNT_EGR_FRAME_DISCARD: /**< Egress frame drop count */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_EGRESS_FDC, counter);
		break;
	case DPSW_CNT_EGR_STP_FRAME_DISCARD:
		eiop_ifp_set_counter(&eiop_ifp_desc, E_EGRESS_STDC, counter);
		break;
	case DPSW_CNT_ING_NO_BUFFER_DISCARD:/*! Ingress no buffer discarded frames */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_OODC, counter);
		break;
	default:
		err = -ENOTSUP; /*!< Operation not supported */
		break;
	}
	return err;
}


int dpsw_if_add_reflection(struct dpsw *dpsw,
	uint16_t if_id,
	const struct dpsw_reflection_cfg *cfg)
{
	/*
	 * verify parameters - if_id
	 * if filter == DPSW_REFLECTION_FILTER_INGRESS_VLAN
	 *      Verify interface assigned to vlan
	 *      update vlan dB
	 *      Update VLAN lookup table entry
	 * if filter == DPSW_REFLECTION_FILTER_INGRESS_ALL
	 * go over all vlans
	 *      if if_id belong to this vlan
	 *              update vlan dB
	 *              vlan_tbl_entry_update
	 */
	int err = -ENOTSUP; /*! not supported */

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	if (cfg->filter == DPSW_REFLECTION_FILTER_INGRESS_VLAN) {
		err = reflection_ingress_vlan(dpsw, /*! Context */
						if_id, /*! Interface id */
						cfg->vlan_id, /*! VLAN ID */
						1); /*! Mirroring ON */
	} else if (cfg->filter == DPSW_REFLECTION_FILTER_INGRESS_ALL) {
		err = reflection_ingress_all(dpsw, /*! Context */
						if_id, /*! Interface id */
						1); /*! Mirroring ON */

	}
	return err;
}

int dpsw_if_remove_reflection(struct dpsw *dpsw,
	uint16_t if_id,
	const struct dpsw_reflection_cfg *cfg)
{
	int err = -ENOTSUP; /*! not supported */

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	if (cfg->filter == DPSW_REFLECTION_FILTER_INGRESS_VLAN) {
		err = reflection_ingress_vlan(dpsw, /*! Context */
						if_id, /*! Interface id */
						cfg->vlan_id, /*! VLAN ID */
						0); /*! Mirroring OFF */
	} else if (cfg->filter == DPSW_REFLECTION_FILTER_INGRESS_ALL) {
		err = reflection_ingress_all(dpsw, /*! Context */
						if_id, /*! Interface id */
						0); /*! Mirroring OFF */

	}
	return err;
}

static int reflection_ingress_vlan(struct dpsw *dpsw,
	uint16_t if_id,
	uint16_t vlan_id,
	int mirr)
{
	int err;
	struct dpsw_vlan_if *vlan_if;
	struct dpsw_vlan *vlan;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	/*! obtain vlan_if */
	vlan_if = &(vlan->iface[if_id]);

	if (vlan_if->mirr == (!mirr)) {
		/*! update vlan_if dB */
		vlan_if->mirr = mirr;
	}

	err = vlan_tbl_vif_update(dpsw, vlan_id, if_id);

	return err;
}

static int reflection_ingress_all(struct dpsw *dpsw, uint16_t if_id, int mirr)
{
	int err = 0;
	struct dpsw_vlan_if *vlan_if;
	struct dpsw_vlan *vlan;
	int iter, iter_status;
	uint8_t key[2];

	iter_status = hmap_get_start_iterator(dpsw->hmap_vlan, &iter);

	while (iter_status == 0) {
		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(dpsw->hmap_vlan, &iter, key,
						(void **)&vlan);

		//vlan_id = MAKE_UINT16(key[0], key[1]);

		vlan_if = &(vlan->iface[if_id]);
		if (vlan_if->mirr == (!mirr)) {

			/*! update vlan_if dB */
			vlan_if->mirr = mirr;
		}
	}

	err = vlan_tbl_if_update(dpsw, if_id);

	return err;
}

int dpsw_add_custom_tpid(struct dpsw *dpsw,
	const struct dpsw_custom_tpid_cfg *cfg)
{
	int err;

	/* Ingress */
	err = dpparser_add_tpid(dpsw->handle.dpparser_ing,/* Parser Handle */
				dpsw->prp_phys_ing.id, /* Parser Profile ID */
				NULL, cfg->tpid); /* Tag Protocol ID */
	CHECK_COND_RETVAL(err == 0, err);

	err = dpparser_add_tpid(dpsw->handle.dpparser_ing,/* Parser Handle */
				dpsw->prp_virt_ing.id, /* Parser Profile ID */
				NULL, cfg->tpid); /* Tag Protocol ID */
	CHECK_COND_RETVAL(err == 0, err);

	/* Egress */
	err = dpparser_add_tpid(dpsw->handle.dpparser_egr,/* Parser Handle */
				dpsw->prp_egr.id, /* Parser Profile ID */
				NULL, cfg->tpid); /* Tag Protocol
				 Identifier */
	return err;
}

int dpsw_remove_custom_tpid(struct dpsw *dpsw,
	const struct dpsw_custom_tpid_cfg *cfg)
{
	int err;

	/* Ingress */
	err = dpparser_remove_tpid(dpsw->handle.dpparser_ing,/* Parser Handle */
					dpsw->prp_phys_ing.id, /* Parser Profile ID */
					NULL, cfg->tpid); /* Tag Protocol ID */
	CHECK_COND_RETVAL(err == 0, err);

	err = dpparser_remove_tpid(dpsw->handle.dpparser_ing,/* Parser Handle */
					dpsw->prp_virt_ing.id, /* Parser Profile ID */
					NULL, cfg->tpid); /* Tag Protocol ID */
	CHECK_COND_RETVAL(err == 0, err);

	/* Egress */
	err = dpparser_remove_tpid(dpsw->handle.dpparser_egr,/* Parser Handle */
					dpsw->prp_egr.id, /* Parser Profile ID */
					NULL, cfg->tpid); /* Tag Protocol
					 Identifier */
	return err;
}

int dpsw_if_set_transmit_rate(struct dpsw *dpsw,
	uint16_t if_id,
	const struct dpsw_transmit_rate_cfg *cfg)
{
	UNUSED(dpsw);
	UNUSED(if_id);
	UNUSED(cfg);
	return 0;
}

int dpsw_if_tc_set_bandwidth(struct dpsw *dpsw,
	uint16_t if_id,
	uint8_t tc_id,
	const struct dpsw_bandwidth_cfg *cfg)
{
	UNUSED(dpsw);
	UNUSED(if_id);
	UNUSED(tc_id);
	UNUSED(cfg);
	return 0;
}

static int fdb_remove_all(struct dpsw *dpsw)
{
	int err = 0;
	struct dpsw_fdb *fdb;
	int iter_status, iter;
	uint8_t key[2];
	uint16_t fdb_id;

	/*! Remove FDBs */
	iter_status = hmap_get_start_iterator(dpsw->hmap_fdb, &iter);

	while (iter_status == 0) {
		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(dpsw->hmap_fdb, &iter, key,
						(hmap_data *)&fdb);

		/* obtain vlan id from hmap key */
		fdb_id = MAKE_UINT16(key[0], key[1]);

		/*! remove fdb */
		err = dpsw_fdb_remove(dpsw, fdb_id);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int acl_remove_all(struct dpsw *dpsw)
{
	/*
	 *      -Remove all ACLs
	 */
	int err = 0;
	struct dpsw_acl *acl;
	int iter_status, iter;
	uint8_t key[2];
	uint16_t acl_id;

	/*! Remove FDBs */
	iter_status = hmap_get_start_iterator(dpsw->hmap_acl, &iter);

	while (iter_status == 0) {
		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(dpsw->hmap_acl, &iter, key,
						(hmap_data *)&acl);

		/* obtain vlan id from hmap key */
		acl_id = MAKE_UINT16(key[0], key[1]);

		/*! remove fdb */
		err = dpsw_acl_remove(dpsw, acl_id);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int vlan_remove_all(struct dpsw *dpsw)
{
	int err = 0;
	int iter, iter_status;
	uint8_t key[2];
	struct dpsw_vlan *vlan;
	uint16_t vlan_id;

	iter_status = hmap_get_start_iterator(dpsw->hmap_vlan, &iter);

	while (iter_status == 0) {
		/* Retrieves vlan at iterator and updates iterator */
		iter_status = hmap_iterate(dpsw->hmap_vlan, &iter, key,
						(void **)&vlan);

		/* obtain vlan id from hmap key */
		vlan_id = MAKE_UINT16(key[0], key[1]);

		/*! remove vlan */
		err = dpsw_vlan_remove(dpsw, vlan_id);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

int dpsw_vlan_remove(struct dpsw *dpsw, uint16_t vlan_id)
{
	/*
	 -# Remove all interfaces from VLAN flow
	 -# Free VLAN slot
	 */
	int err;
	struct dpsw_vlan *vlan;
	struct dpsw_fdb *fdb;

	/*! Retrieve vlan database */
	err = hmap_lookup(dpsw->hmap_vlan, (hmap_key)&vlan_id, (void **)&vlan);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&(vlan->fdb_id),
				(void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Remove assigned interfaces */
	err = vlan_tbl_assigned_remove(dpsw, vlan_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Remove from accept all */
	err = vlan_tbl_accept_all_vlan_remove(dpsw, vlan_id);
	if (err != 0)
		return err;

	/*! Remove from admit un-tagged */
	err = vlan_tbl_admit_untagged_remove(dpsw, vlan_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! free vlan resource */
	err = hmap_remove_key(dpsw->hmap_vlan, (hmap_key)&vlan_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update reference count */
	fdb->ref_cnt--;

	return err;
}

int dpsw_fdb_remove(struct dpsw *dpsw, uint16_t fdb_id)
{
	/*
	 -# Check FDB ID is exist
	 -# Check no VLAN is referencing this FDB
	 */
	int err;
	struct dpsw_fdb *fdb;

	/* Verify Configuration parameters */

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	CHECK_COND_RETVAL(fdb->hndl, -EFAULT); /* Bad address */

	/*! No VLAN attached */
	if (fdb->ref_cnt > 0)
		return -EBUSY;

	/*! Reset hmap of multicasts */
	if (dpsw->multicast_enable == 1)
		hmap_remove_all(fdb->hmap_mcast);

	/*! Delete fdb from CTLU */
	err = dptbl_l2switch_fdb_delete(fdb->hndl);
	if (err == 0)
		hmap_remove_key(dpsw->hmap_fdb, (hmap_key)&fdb_id);

	fdb->hndl = NULL;
	return err;
}

int dpsw_set_buffer_depletion(struct dpsw *dpsw,
	const struct dpsw_buffer_depletion_cfg *cfg)
{
	UNUSED(dpsw);
	UNUSED(cfg);
	return 0;
}

int dpsw_set_parser_error_action(struct dpsw *dpsw,
	const struct dpsw_parser_error_action_cfg *cfg)
{
	UNUSED(dpsw);
	UNUSED(cfg);
	return 0;
}

int dpsw_set_ptp_v2(struct dpsw *dpsw, const struct dpsw_ptp_v2_cfg *cfg)
{
	UNUSED(dpsw);
	UNUSED(cfg);
	return 0;
}

int dpsw_if_tc_set_queue_congestion(struct dpsw *dpsw,
	uint16_t if_id,
	uint8_t tc_id,
	const struct dpsw_queue_congestion_cfg *cfg)
{
	UNUSED(dpsw);
	UNUSED(cfg);
	UNUSED(if_id);
	UNUSED(tc_id);
	return 0;
}

int dpsw_if_tc_set_pfc(struct dpsw *dpsw,
	uint16_t if_id,
	uint8_t tc_id,
	struct dpsw_pfc_cfg *cfg)
{
	UNUSED(dpsw);
	UNUSED(cfg);
	UNUSED(if_id);
	UNUSED(tc_id);
	return 0;
}

int dpsw_if_get_attributes(struct dpsw *dpsw,
	uint16_t if_id,
	struct dpsw_if_attr *attr)
{
	int 				err;
	struct dpsw_if 			*iface;
	struct linkman_endpoint 	ep1, ep2;
	struct linkman_connection_attr	connection_attr;
	struct ctrl_if_attr 		ctrl_attr;
	struct ceetm_if_attr 		ceetm_if_attr;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/* obtain interface */
	iface = &(dpsw->iface[if_id]); /*! Obtain interface */

	/* Obtain ceetm interface attributes */
	ceetm_if_get_attributes(iface->ceetm_if, &ceetm_if_attr);

	/* Setting options */
	attr->options =
		(iface->flooding_enable == 0) ? DPSW_OPT_FLOODING_DIS : 0;
	attr->options |=
		(iface->multicast_enable == 0) ? DPSW_OPT_MULTICAST_DIS : 0;
	attr->options |=
		(dpsw->ctrl_if_enable == 0) ? DPSW_OPT_CTRL_IF_DIS : 0;

	attr->num_tcs = (uint8_t)ceetm_if_attr.num_ccqs;
	attr->enabled = iface->enabled; /*! Enabled/disabled */
	attr->accept_all_vlan = iface->accept_all_vlan;
	attr->admit_untagged = iface->admit_untagged;

	/*! Obtain link */
	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	ep1.type = FSL_MOD_DPSW;
	ep1.id = (uint16_t)dpsw->id;
	ep1.if_id = if_id;
	err = linkman_get_connection(dpsw->handle.linkman,
	                             &ep1,
	                             &ep2,
	                             &connection_attr);
	CHECK_COND_RETVAL(err == 0, err);

	/* Update rate */
	attr->rate = connection_attr.rate;

	/* get control interface transmit fqid */
	attr->qdid = (uint16_t)-1;

	if (dpsw->ctrl_if_enable == 0)
		return err;

        /* Obtain transmit attributes */
        err = ctrl_if_get_tx_if_id_attr(dpsw->ctrl_if, if_id, &ctrl_attr);
        CHECK_COND_RETVAL(err == 0, err);

        attr->qdid = (uint16_t)ctrl_attr.virt_qdid;

	return err;
}

int dpsw_if_set_macsec(struct dpsw *dpsw,
	uint16_t if_id,
	const struct dpsw_macsec_cfg *cfg)
{
	UNUSED(dpsw);
	UNUSED(cfg);
	UNUSED(if_id);
	return 0;
}

int dpsw_if_set_max_frame_length(struct dpsw *dpsw,
	uint16_t if_id,
	uint16_t frame_length)
{
	int err;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct dpsw_if *iface;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]); /* Get interface */

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id;

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EFAULT);

	/*! Set frame length */
	err = eiop_ifp_set_max_frame_length(&eiop_ifp_desc, frame_length);
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}

int dpsw_if_get_max_frame_length(struct dpsw *dpsw,
	uint16_t if_id,
	uint16_t *frame_length)
{
	int err;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct dpsw_if *iface;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]); /* Get interface */

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* iop id */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EFAULT);

	/*! Get frame length */
	*frame_length = eiop_ifp_get_max_frame_length(&eiop_ifp_desc);

	return err;
}

int dpsw_if_get_link_state(struct dpsw *dpsw,
	uint16_t if_id,
	struct dpsw_link_state *state)
{
	int err = 0;
	struct linkman_endpoint ep1, ep2;
	struct linkman_connection_attr	connection_attr;

	/*! Check parameters */
	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/*! init endpoints */
	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));

	/*! Endpoint information */
	ep1.type = FSL_MOD_DPSW;
	ep1.id = (uint16_t)dpsw->id;
	ep1.if_id = if_id;

	/*! Obtain connection */
	err = linkman_get_connection(
		dpsw->handle.linkman,
		&ep1,
	        &ep2,
	        &connection_attr);
	CHECK_COND_RETVAL(err == 0, err);

	/* copy state to user */
	state->options = connection_attr.options;
	state->rate = connection_attr.rate;
	state->up = (connection_attr.state == LINKMAN_STATE_LINKUP) ? 1 : 0;

	return err;
}

int dpsw_if_set_link_cfg(struct dpsw *dpsw,
	uint16_t if_id,
	struct dpsw_link_cfg *cfg)
{
	struct dpsw_if *iface;
	uint64_t options, new_options;

	/*! Check parameters */
	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/* Obtain interface */
	iface = &(dpsw->iface[if_id]);

	CHECK_COND_RETVAL(iface->enabled == 0, -EACCES, "ID[%d] IF[%d]: interface must be disabled\n", dpsw->id, if_id);

	options = iface->link_cfg.options;

	/* Save link configuration */
	memcpy(&(iface->link_cfg), cfg, sizeof(struct dpsw_link_cfg));

	new_options = options ^ iface->link_cfg.options;

	return 0;
}

int dpsw_fdb_remove_unicast(struct dpsw *dpsw,
	uint16_t fdb_id,
	const struct dpsw_fdb_unicast_cfg *cfg)
{
	int err;
	struct dptbl_l2switch_fdb_rule_cfg rule;
	uint8_t mac_addr[6]; /* MAC */
	struct dpsw_fdb *fdb;

	/* Verify Configuration parameters */

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	CHECK_COND_RETVAL(fdb->hndl, -EFAULT); /* Bad address */

	memcpy(&mac_addr[0], &(cfg->mac_addr[0]), 6);

	/* rule */
	rule.key = &mac_addr[0];

	/* Remove unicast */
	err = dptbl_remove_rule_l2switch_fdb(fdb->hndl, &rule);

	return err;
}

int dpsw_fdb_add_multicast(struct dpsw *dpsw,
	uint16_t fdb_id,
	const struct dpsw_fdb_multicast_cfg *cfg)
{
	/*
	 * Check for cfg integrity fdb_multicast_params_integrity
	 * Obtain hmap
	 * lookup for the key
	 *      add key
	 *      lookup again
	 * Add an entry to Replication list replic_add
	 * add_fdb_entry if required
	 */
	int err = 0, add_key = 0;
	struct hmap *hmap;
	struct dpsw_replic *replic;
	struct dpsw_vlan_if_cfg if_cfg;
	struct dptbl_l2switch_fdb_action fdb_entry;
	struct dptbl_l2switch_fdb_rule_cfg fdb_rule;
	uint8_t mac_addr[6];
	struct dpsw_fdb *fdb;

	/*! Verify Configuration parameters */
	err = fdb_multicast_params_integrity(dpsw, fdb_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Obtain hmap */
	hmap = fdb->hmap_mcast;

	/*! lookup for the key */
	err = hmap_lookup(hmap, (hmap_key)cfg->mac_addr, /*! key */
				(hmap_data *)&replic); /*! data */
	if (err != 0) { /*! Entry not found */
		/*add an entry */
		err = hmap_add_key(hmap, (hmap_key)cfg->mac_addr);
		CHECK_COND_RETVAL(err == 0, err);

		/*! Obtain data */
		err = hmap_lookup(hmap, (hmap_key)cfg->mac_addr, /*! key */
					(hmap_data *)&replic); /*! data */
		CHECK_COND_RETVAL(err == 0, err);

		err = replic_cleanup(dpsw, replic);
		CHECK_COND_RETVAL(err == 0, err);

		add_key = 1;
	}

	/*! Adapt dpsw_fdb_multicast_cfg to dpsw_vlan_if_cfg */
	replic_copy_to_vlan_if(dpsw, &if_cfg, cfg, fdb_id);

	/*! Add interfaces to replication link list */
	err = replic_add(dpsw, replic, &if_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update FDB table */
	if (add_key == 1) {
		/* Action */
		memset(&fdb_entry, 0x0,
			sizeof(struct dptbl_l2switch_fdb_action));
		fdb_entry.options =
			(cfg->type == DPSW_FDB_ENTRY_STATIC) ?
				DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS : /*! Static Entry*/
				DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_AGING; /*! Dynamic */
		fdb_entry.qd_id = dpsw->wq_replic.qdid; /*! QDID */
		fdb_entry.replic_list_id = replic->rrid.root; /*! RRID */

		/* Rule */
		memset(&fdb_rule, 0x0,
			sizeof(struct dptbl_l2switch_fdb_rule_cfg));
		memcpy(&mac_addr[0], cfg->mac_addr, 6);
		fdb_rule.key = mac_addr;

		/* Add entry */
		err = dptbl_add_or_modify_rule_l2switch_fdb(fdb->hndl,
								&fdb_rule,
								&fdb_entry);
	}
	return err;
}

static dpsw_iface_get_qdid(struct dpsw *dpsw, uint16_t if_id, int *qdid)
{
	struct ctrl_if_attr attr;
	int err;

	if (if_id == dpsw->num_ifs) {
		err = ctrl_if_get_rx_flow_attr(dpsw->ctrl_if, 0, &attr);
		*qdid = attr.internal_qdid;
	} else {
		err = get_iface_qdid(dpsw, if_id, qdid);
	}

	return err;
}

static int replic_add(struct dpsw *dpsw,
	struct dpsw_replic *replic,
	const struct dpsw_vlan_if_cfg *if_cfg)
{
	/*
	 * * for each interface
	 *      if_id == 0
	 *              inuse = 1
	 *      replic_add_element
	 * get head rrid
	 * configure quartet
	 */
	int err = 0, replic_head_id, replic_head_rrid, i, qdid, root_qdid;
	struct replic_element_info element_info;
	struct dpmng_amq amq;

	/*! Init element info */
	dpmng_get_amq(&amq);
	element_info.flc = 0;
	//element_info.fqid = dpsw->wq_replic.fqid;
	element_info.fqid = dpmng_get_rtn_fqid(dpsw->handle.dpmng);
	element_info.icid = amq.icid;
	element_info.next_rrid = 0;

	/*! Add required ports to replication list */
	for (i = 0; i < if_cfg->num_ifs; i++) {
		if( replic->if_list[if_cfg->if_id[i]] )
			continue;

		if( replic->rrid_root_inuse == 0 ) {
			replic->root_if_id = if_cfg->if_id[i];
			replic->rrid_root_inuse = 1;
		} else {
			/* Obtain qdid */
			err = dpsw_iface_get_qdid(dpsw, if_cfg->if_id[i], &qdid);
			CHECK_COND_RETVAL(err == 0, err);

			element_info.qdid = qdid;
			err = replic_add_element(replic->replic,
					if_cfg->if_id[i],
					&element_info);
			CHECK_COND_RETVAL(err == 0, err);
		}
		replic->if_list[if_cfg->if_id[i]] = 1;
	}

	/*! get head rrid */
	err = replic_get_element_head(replic->replic, &replic_head_id);
	if (err == 0)
		replic_get_element_rrid(replic->replic, replic_head_id,
					&replic_head_rrid);
	else
		replic_head_rrid = 0;

	/* Obtain root qdid */
	err = dpsw_iface_get_qdid(dpsw, replic->root_if_id, &root_qdid);
	CHECK_COND_RETVAL(err == 0, err);

	/* configure quartet */
	qdid = (replic->rrid_root_inuse == 1) ? root_qdid : dpsw->wq_void.qdid;
	err = replic_configure_quartet_root(dpsw, &(replic->rrid), qdid,
						replic_head_rrid);

	dbg_replic(dpsw, replic->rrid.root);

	return err;
}

static int replic_remove(struct dpsw *dpsw,
	struct dpsw_replic *replic,
	const struct dpsw_vlan_if_cfg *if_cfg)
{
	int err = 0, replic_head_id, replic_head_rrid, i, qdid, root_qdid;
	int count;

	/*! Add required ports to replication list */
	for (i = 0; i < if_cfg->num_ifs; i++) {
		if( !replic->if_list[if_cfg->if_id[i]] )
			continue;

		if( if_cfg->if_id[i] == replic->root_if_id ) {
			count = replic_get_element_inuse_count(replic->replic);
			if( count ) {
				err = replic_get_element_head(replic->replic, &replic_head_id);
				CHECK_COND_RETVAL( err == 0 , err, "replic_get_element_head\n");
				replic->root_if_id = (uint16_t)replic_head_id;
				err = replic_remove_element(replic->replic, replic->root_if_id);
				CHECK_COND_RETVAL( err == 0 , err, "replic_remove_element\n");
			} else {
				replic->rrid_root_inuse = 0;
			}
		} else {
			err = replic_remove_element(replic->replic, if_cfg->if_id[i]);
			CHECK_COND_RETVAL(err == 0, err, "replic_remove_element(%d)\n", if_cfg->if_id[i]);
		}

		replic->if_list[if_cfg->if_id[i]] = 0;
	}

	/*! get head rrid */
	err = replic_get_element_head(replic->replic, &replic_head_id);
	if (err == 0)
		replic_get_element_rrid(replic->replic, replic_head_id,
					&replic_head_rrid);
	else
		replic_head_rrid = 0;

	/* Obtain qdid */
	err = dpsw_iface_get_qdid(dpsw, replic->root_if_id, &root_qdid);
	CHECK_COND_RETVAL(err == 0, err, "dpsw_iface_get_qdid");

	/*! configure quartet */
	qdid = (replic->rrid_root_inuse == 1) ? root_qdid : dpsw->wq_void.qdid;
	err = replic_configure_quartet_root(dpsw, &(replic->rrid), qdid,
						replic_head_rrid);

	return err;
}

static void replic_copy_to_vlan_if(struct dpsw *dpsw,
	struct dpsw_vlan_if_cfg *vlan_if,
	const struct dpsw_fdb_multicast_cfg *multicast_if,
	uint16_t fdb_id)
{
	struct dpsw_if *iface;
	int i;
	uint8_t num_ifs = 0;

	if (!vlan_if)
		return;

	for (i = 0; i < multicast_if->num_ifs; i++)
	{
		/*! Obtain interface */
		iface = &(dpsw->iface[multicast_if->if_id[i]]);

		if (iface->lag_enabled && !ceetm_if_is_lag_master(iface->ceetm_if))
		{
			pr_info("LAG slave interface %d not added to multicast domain associated to FDB %d\n",
					multicast_if->if_id[i], fdb_id);
			continue;
		}

		vlan_if->if_id[num_ifs++] = multicast_if->if_id[i];
	}

	vlan_if->num_ifs = num_ifs;
}

static void replic_copy_to_multicast_if(struct dpsw_fdb_multicast_cfg *multicast_if,
	const struct dpsw_vlan_if_cfg *vlan_if)
{
	multicast_if->num_ifs = vlan_if->num_ifs;
	memcpy(&(multicast_if->if_id[0]), &(vlan_if->if_id[0]),
		vlan_if->num_ifs * sizeof(uint16_t));
}

int dpsw_fdb_get_multicast(struct dpsw *dpsw,
	uint16_t fdb_id,
	struct dpsw_fdb_multicast_cfg *multicast)
{
	/*
	 * Verify Configuration Parameters
	 * Read multi-cast entry from FDB lookup table
	 * Travel Replication Records and get Multicast group
	 */
	int err;
	struct hmap *hmap;
	struct dpsw_replic *replic;
	struct dpsw_vlan_if_cfg vlan_if;
	struct dpsw_fdb *fdb;

	/*! Verify Configuration Parameters */

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	CHECK_COND_RETVAL(fdb->hndl, -EFAULT); /* Bad address */
	
	if ((multicast->mac_addr[0] & 0x01) == 0x00) /*! Is it uc address? */
		return -EFAULT; /* Bad address */

	/*! Obtain hmap */
	hmap = fdb->hmap_mcast;

	/*! lookup for the key */
	err = hmap_lookup(hmap, (hmap_key)multicast->mac_addr, /*! key */
				(hmap_data *)&replic); /*! data */
	CHECK_COND_RETVAL(err == 0, err);

	/* Read interfaces */
	err = replic_get_ifs(dpsw, replic, &vlan_if);
	CHECK_COND_RETVAL(err == 0, err);

	replic_copy_to_multicast_if(multicast, &vlan_if);

	return err;
}

static int fdb_multicast_params_integrity(struct dpsw *dpsw,
	uint16_t fdb_id,
	const struct dpsw_fdb_multicast_cfg *cfg)
{
	int i, cmp;
	uint16_t if_id;
	uint8_t mac_addr[6];

	/* Is multicast enabled */
	CHECK_COND_RETVAL(dpsw->multicast_enable, -EACCES);
	
	/* multicast address */
	if ((cfg->mac_addr[0] & 0x01) == 0x00) /*! Is it unicast-cast address? */
		return -EFAULT; /* Bad address */
	
	/* broadcast address is not allowed */
	memset(mac_addr, 0xFF, 6);
	cmp = memcmp(cfg->mac_addr, mac_addr, 6);
	CHECK_COND_RETVAL(cmp, -EFAULT);

	/* number of interfaces lower range */
	CHECK_COND_RETVAL(cfg->num_ifs, -EINVAL); /*! nothing to add */

	/* number of interfaces upper range */
	if (cfg->num_ifs > dpsw->num_ifs)
		return -EINVAL; /*! invalid argument */

	/* Interface ids are vlaid */
	for (i = 0; i < cfg->num_ifs; i++) {
		if_id = cfg->if_id[i];
		if (if_id >= dpsw->num_ifs) { /*! Verify id is OK */
			return -EINVAL;
		}
	}
	return 0;
}

static int fdb_entry_query(struct dpsw *dpsw,
	uint16_t fdb_id,
	const uint8_t *mac_addr,
	struct dptbl_l2switch_fdb_action *entry)
{
	int err;
	struct dptbl_l2switch_fdb_rule_cfg rule; /* Rule */
	uint8_t addr[6]; /* MAC */
	struct dpsw_fdb *fdb;

	/* rule */
	memset(&rule, 0x0, sizeof(struct dptbl_l2switch_fdb_rule_cfg));
	memcpy(&addr[0], &(mac_addr[0]), 6);
	rule.key = addr;

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Read FDB entry */
	err = dptbl_get_l2switch_fdb(fdb->hndl, &rule, entry);

	return err;
}

static int fdb_add_broadcast(struct dpsw *dpsw, struct dpsw_fdb *fdb)
{
	/*
	 *      -Retrieve fdb database
	 *      -Add an entry to fdb table
	 */
	int err = 0;
	struct dptbl_l2switch_fdb_action fdb_entry;
	struct dptbl_l2switch_fdb_rule_cfg fdb_rule;
	uint8_t mac_addr[6];

	/* Add an entry to fdb table */
	memset(&fdb_entry, 0x0, sizeof(struct dptbl_l2switch_fdb_action));
	fdb_entry.options = DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS; /* Static */
	fdb_entry.qd_id = dpsw->wq_replic.qdid; /* QDID */
	if (dpsw->broadcast_cfg == DPSW_BROADCAST_PER_FDB)
		fdb_entry.replic_list_id = fdb->broadcast.rrid.root; /* RRID */
	else
		fdb_entry.replic_list_id = dpsw->broadcast.rrid.root; /* RRID */

	/* Rule */
	memset(&fdb_rule, 0x0, sizeof(struct dptbl_l2switch_fdb_rule_cfg));
	memset(mac_addr, 0xFF, 6);
	fdb_rule.key = mac_addr;

	/* Add entry */
	err = dptbl_add_or_modify_rule_l2switch_fdb(fdb->hndl, &fdb_rule,
							&fdb_entry);

	return err;
}

static int fdb_entry_remove(struct dpsw *dpsw,
	uint16_t fdb_id,
	const uint8_t *mac_addr)
{
	int err;
	struct dptbl_l2switch_fdb_rule_cfg rule; /* Rule */
	uint8_t addr[6]; /* MAC */
	struct dpsw_fdb *fdb;

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	/* rule */
	memset(&rule, 0x0, sizeof(struct dptbl_l2switch_fdb_rule_cfg));
	memcpy(&addr[0], &(mac_addr[0]), 6);
	rule.key = addr;

	err = dptbl_remove_rule_l2switch_fdb(fdb->hndl, &rule);

	return err;
}

int dpsw_fdb_remove_multicast(struct dpsw *dpsw,
	uint16_t fdb_id,
	const struct dpsw_fdb_multicast_cfg *multicast)
{
	/*
	 * Check for cfg integrity fdb_multicast_params_integrity
	 * Obtain hmap
	 * lookup for the key
	 * Remove an entry from Replication list replic_remove
	 * remove_fdb_entry if required
	 */
	int err = 0;
	struct hmap *hmap;
	struct dpsw_replic *replic;
	struct dpsw_vlan_if_cfg vlan_if;
	struct dpsw_fdb *fdb;

	/*! Verify Configuration parameters */
	err = fdb_multicast_params_integrity(dpsw, fdb_id, multicast);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Obtain hmap */
	hmap = fdb->hmap_mcast;

	/*! lookup for the key */
	err = hmap_lookup(hmap, (hmap_key)multicast->mac_addr, /*! key */
				(hmap_data *)&replic); /*! data */
	CHECK_COND_RETVAL(err == 0, err);

	/*! Adapt dpsw_fdb_multicast_cfg to dpsw_vlan_if_cfg */
	replic_copy_to_vlan_if(dpsw, &vlan_if, multicast, fdb_id);

	/*! Remove interfaces from replication link list */
	err = replic_remove(dpsw, replic, &vlan_if);
	CHECK_COND_RETVAL(err == 0, err);

	/*! is list empty? */
	if ((replic_is_empty(replic->replic) == 1)
		&& (replic->rrid_root_inuse == 0)) {

		/* Remove from database */
		err = hmap_remove_key(hmap, (hmap_key)multicast->mac_addr);
		CHECK_COND_RETVAL(err == 0, err);

		/* Remove an entry */
		err = fdb_entry_remove(dpsw, /*! Context */
					fdb_id, /*! FDB ID */
					multicast->mac_addr); /*! MAC address */
		CHECK_COND_RETVAL(err == 0, err);
	}

	return err;
}

int dpsw_fdb_get_attributes(struct dpsw *dpsw,
	uint16_t fdb_id,
	struct dpsw_fdb_attr *attr)
{
	int err = 0;
	struct dpsw_fdb *fdb;

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
	if (err != 0)
		return err;

	attr->fdb_aging_time = fdb->aging_time;
	attr->learning_mode = fdb->learning_mode;
	attr->max_fdb_entries = fdb->max_entries;
	attr->max_fdb_mc_groups = dpsw->max_fdb_mc_groups;
	attr->num_fdb_mc_groups =
		(dpsw->multicast_enable == 1) ?
			(uint16_t)hmap_get_count(fdb->hmap_mcast) : 0;

	return err;;
}

int dpsw_set_irq(struct dpsw *dpsw,
	uint8_t irq_index,
	const struct mc_irq_cfg *irq_cfg)
{
	if (irq_index >= DPSW_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPSW_MAX_IRQ_NUM);
		return -EINVAL;
	}

	mc_set_irq(&(dpsw->irqs[irq_index]), irq_cfg);
	return 0;
}

int dpsw_get_irq(struct dpsw *dpsw,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg)
{
	int err;

	if (irq_index >= DPSW_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPSW_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq(&(dpsw->irqs[irq_index]), irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpsw_set_irq_enable(struct dpsw *dpsw, uint8_t irq_index, uint8_t en)
{
	int err;

	if (irq_index >= DPSW_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPSW_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_set_irq_enable(&(dpsw->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpsw_get_irq_enable(struct dpsw *dpsw, uint8_t irq_index, uint8_t *en)
{
	int err;

	if (irq_index >= DPSW_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPSW_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_enable(&(dpsw->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpsw_set_irq_mask(struct dpsw *dpsw, uint8_t irq_index, uint32_t mask)
{
	int err;

	if (irq_index >= DPSW_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPSW_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_set_irq_mask(&(dpsw->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpsw_get_irq_mask(struct dpsw *dpsw, uint8_t irq_index, uint32_t *mask)
{
	int err;

	if (irq_index >= DPSW_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPSW_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_mask(&(dpsw->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpsw_get_irq_status(struct dpsw *dpsw, uint8_t irq_index, uint32_t *status)
{
	int err;

	if (irq_index >= DPSW_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPSW_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_status(&(dpsw->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpsw_clear_irq_status(struct dpsw *dpsw,
	uint8_t irq_index,
	uint32_t status)
{
	int err, pending;
	uint16_t if_id, event;

	if (irq_index >= DPSW_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPSW_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_clear_irq_status(&(dpsw->irqs[irq_index]), status);
	if (err)
		return err;

	/* Is any pending messages? */
	pending = irq_get_pending_if(dpsw, &if_id);
	if (pending == 1) {
		/* get event and clear pending */
		event = irq_if_restore_event(dpsw, if_id);

		/* trigger an interrupt */
		irq_if_trigger(dpsw, if_id, event);
	}

	return 0;
}

static void irq_if_trigger(struct dpsw *dpsw, uint16_t if_id, uint16_t event)
{
	uint32_t message, status = 0;
	struct mc_irq *irq;

	/* Get IRQ */
	irq = &(dpsw->irqs[DPSW_IRQ_INDEX_IF]);

	/* Check IRQ status */
	mc_get_irq_status(irq, &status);

	if (status == 0) {
		/* Compose message */
		message = irq_if_compose_message(dpsw, if_id, event);

		/* Send event */
		event_send(irq, message);
	} else
		irq_if_save_event(dpsw, if_id, event);
}

static int irq_get_pending_if(struct dpsw *dpsw, uint16_t *if_id)
{
	uint16_t i;
	int pending = 0;

	for (i = 0; i < dpsw->num_ifs; i++) {
		if (dpsw->iface[i].irq.pending == 1) {
			*if_id = i;
			pending = 1;
			break;
		}
	}
	return pending;
}

static uint16_t irq_if_restore_event(struct dpsw *dpsw, uint16_t if_id)
{
	struct dpsw_irq *irq;

	/* Obtain interface */
	irq = &(dpsw->iface[if_id].irq);

	/* Clear pending */
	irq->pending = 0;

	return irq->event;
}

static void irq_if_save_event(struct dpsw *dpsw,
	uint16_t if_id,
	uint16_t event)
{
	struct dpsw_irq *irq;

	/* Obtain interface */
	irq = &(dpsw->iface[if_id].irq);

	/* Clear pending */
	irq->pending = 1;

	/* Save */
	irq->event = event;
}

static uint32_t irq_if_compose_message(struct dpsw *dpsw,
	uint16_t if_id,
	uint16_t event)
{
	return ((((uint32_t)if_id) << 16) | ((uint32_t)event));
}

static int replic_init(struct dpsw *dpsw, struct dpsw_replic *replic)
{
	int err = 0;
	struct replic_cfg cfg;

	/* reset memory */
	memset(replic, 0x0, sizeof(struct dpsw_replic));

	/*! Init quartet */
	err = replic_init_quartet(dpsw, /*! context */
					&(replic->rrid), /*! quartet */
					dpsw->wq_void.qdid, /*! void QDID */
					0); /*! next rrid */
	CHECK_COND_RETVAL(err == 0, err);

	/*! create replic */
	cfg.dprc = dpsw->handle.dprc;/*! Handle to DPRC */
	if (dpsw->ctrl_if_enable)
		cfg.num_elements = dpsw->num_ifs + 1;
	else
		cfg.num_elements = dpsw->num_ifs;
	replic->replic = replic_create(&cfg);
	CHECK_COND_RETVAL(replic->replic, -ENOMEM);

	return err;
}

static int replic_cleanup(struct dpsw *dpsw, struct dpsw_replic *replic)
{
	int err = 0;

	if (dpsw->flooding_enable == 0)
		return err;

	err = replic_configure_quartet(dpsw, &(replic->rrid),
					dpsw->wq_void.qdid, 0);

	/*! reset replic */
	replic_remove_all(replic->replic);

	memset(replic->if_list, 0, sizeof(replic->if_list));

	replic->rrid_root_inuse = 0;

	return err;
}

static int replic_broadcast_set_default(struct dpsw *dpsw, uint16_t fdb_id)
{
	struct dpsw_egress_flood_cfg flood_cfg = {0};
	uint16_t i;
	int err;

	flood_cfg.num_ifs = dpsw->num_ifs;
	flood_cfg.flood_type = DPSW_BROADCAST;
	flood_cfg.fdb_id = fdb_id;
	for (i = 0; i < dpsw->num_ifs; i++)
		flood_cfg.if_id[i] = i;

	err = __dpsw_set_egress_flood(dpsw, &flood_cfg);
	CHECK_COND_RETVAL(err == 0, err, "__dpsw_set_egress_flood failed");

	return 0;
}

static int replic_flooding_set_default(struct dpsw *dpsw, uint16_t fdb_id)
{
	struct dpsw_egress_flood_cfg flood_cfg = {0};
	uint16_t i;
	int err;

	flood_cfg.num_ifs = dpsw->num_ifs;
	flood_cfg.flood_type = DPSW_FLOODING;
	flood_cfg.fdb_id = fdb_id;
	for (i = 0; i < dpsw->num_ifs; i++)
		flood_cfg.if_id[i] = i;

	err = __dpsw_set_egress_flood(dpsw, &flood_cfg);
	CHECK_COND_RETVAL(err == 0, err, "__dpsw_set_egress_flood failed");

	return 0;
}

static int replic_init_quartet(struct dpsw *dpsw,
	struct dpsw_quartet_rrid *rrid,
	int root_qdid,
	int root_next_rrid)
{
	int err = 0;
	int id[4];

	/*! Allocate RRID quartet */
	err = allocate_resource(dpsw->handle.dprc, /*! Resource mngr hndl*/
				"rplr", /*! Resource type */
				4, /*! Number of resources*/
				4, /*! Base align */
				DPRC_RES_REQ_OPT_ALIGNED, /*! Options */
				&(id[0]), /*! Address */
				"RPLR"); /*! Error string */
	CHECK_COND_RETVAL(err == 0, err);

	/*! Save rrid quartet */
	rrid->root = id[0]; /*! Root */
	rrid->mirr = id[1]; /*! Mirroring */
	rrid->swl = id[2]; /*! Soft learning */
	rrid->swl_mirr = id[3]; /*! SWL + mirroring */

	err = replic_configure_quartet(dpsw, rrid, root_qdid, root_next_rrid);

	return err;
}

static int replic_configure_quartet(struct dpsw *dpsw,
	struct dpsw_quartet_rrid *rrid,
	int root_qdid,
	int root_next_rrid)
{
	int err;
	/*! configure quartet root */
	err = replic_configure_quartet_root(dpsw, rrid, root_qdid,
						root_next_rrid);
	CHECK_COND_RETVAL(err == 0, err);

	/*! configure quartet mirr */
	err = replic_configure_quartet_mirr(dpsw, rrid);
	CHECK_COND_RETVAL(err == 0, err);

	/*! configure quartet software learning */
	err = replic_configure_quartet_swl(dpsw, rrid);

	return err;
}

static int replic_configure_quartet_root(struct dpsw *dpsw,
	struct dpsw_quartet_rrid *rrid,
	int root_qdid,
	int root_next_rrid)
{
	/*
	 * Obtain software portal
	 * Obtain icid
	 * Configure quartet root
	 */
	int err = 0;
	struct qbman_swp *swp;
	struct dpmng_amq amq;
	uint32_t rtn_fqid;
	uint8_t rd = 1;		/* Assume Rev2 - QMan 4.1 */

#ifdef TKT220573
	rd = 0;
#endif

	/*! Obtain software portal */
	dpmng_get_swportal(dpsw->handle.dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -ENAVAIL);

	/*! Obtain ICID */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	/* Obtain Return FQID */
	rtn_fqid = (uint32_t)dpmng_get_rtn_fqid(dpsw->handle.dpmng);

	/*! Configure quartet root */
	err = qbman_rr_configure(swp, /*! Software Portal */
					(uint16_t)rrid->root, /*! RR ID */
					(uint16_t)root_qdid, /*! QDID */
					(uint16_t)root_next_rrid, /*! RRID */
					amq.icid, /*! ICID */
					rtn_fqid, /*! Return FQID */
					rd);
	return err;
}

static int replic_configure_quartet_mirr(struct dpsw *dpsw,
	struct dpsw_quartet_rrid *rrid)
{
	/*
	 * Obtain software portal
	 * Obtain icid
	 * Obtain mirroring QDID
	 * Configure quartet mirroring
	 */

	int err = 0;
	struct qbman_swp *swp;
	struct dpmng_amq amq;
	int mirr_qdid;
	uint32_t rtn_fqid;
	uint8_t rd = 1;		/* Assume Rev2 - QMan 4.1 */

#ifdef TKT220573
	rd = 0;
#endif

	/*! Obtain software portal */
	dpmng_get_swportal(dpsw->handle.dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -ENAVAIL);

	/*! Obtain ICID */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	/*! Obtain mirroring QDID */
	err = get_iface_qdid(dpsw, dpsw->mirr_if_id, &mirr_qdid);
	CHECK_COND_RETVAL(err == 0, err);

	/* Obtain Return FQID */
	rtn_fqid = (uint32_t)dpmng_get_rtn_fqid(dpsw->handle.dpmng);

	/*! Configure quartet mirroring */
	err = qbman_rr_configure(swp, /*! Software Portal */
					(uint16_t)rrid->mirr, /*! RR ID */
					(uint16_t)mirr_qdid, /*! QDID */
					(uint16_t)rrid->root, /*! Next RRID */
					amq.icid, /*! ICID */
					rtn_fqid, /*! Return FQID */
					rd);
	return err;
}

static int replic_configure_quartet_swl(struct dpsw *dpsw,
	struct dpsw_quartet_rrid *rrid)
{
	/*
	 * Obtain software portal
	 * Obtain icid
	 * Obtain control QDID
	 * Configure quartet swl
	 * Configure quartet swl + mirroring
	 */
	int err = 0;
	struct qbman_swp *swp;
	struct dpmng_amq amq;
	int ctrl_qdid;
	uint32_t rtn_fqid;
	struct ctrl_if_attr ctrl_attr;
	uint8_t rd = 1;		/* Assume Rev2 - QMan 4.1 */

#ifdef TKT220573
	rd = 0;
#endif

	if (dpsw->ctrl_if_enable == 0)
		return err;

	/*! Obtain software portal */
	dpmng_get_swportal(dpsw->handle.dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -ENAVAIL);

	/* Obtain ICID */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

        /* Obtain control attributes */
	ctrl_if_get_rx_flow_attr(dpsw->ctrl_if, 0, &ctrl_attr);
	ctrl_qdid = ctrl_attr.internal_qdid;

	/* Obtain Return FQID */
	rtn_fqid = (uint32_t)dpmng_get_rtn_fqid(dpsw->handle.dpmng);

	/*! Configure quartet swl */
	err = qbman_rr_configure(swp, /*! Software Portal */
					(uint16_t)rrid->swl, /*! RR ID */
					(uint16_t)ctrl_qdid, /*! QDID */
					(uint16_t)rrid->root, /*! Next RRID */
					amq.icid, /*! ICID */
					rtn_fqid, /*! Return FQID */
					rd);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Configure quartet swl + mirr */
	err = qbman_rr_configure(swp, /*! Software Portal */
					(uint16_t)rrid->swl_mirr, /*! RR ID */
					(uint16_t)ctrl_qdid, /*! QDID */
					(uint16_t)rrid->mirr, /*! Next RRID */
					amq.icid, /*! ICID */
					rtn_fqid, /*! Return FQID */
					rd);
	return err;
}

static int replic_get_ifs(struct dpsw *dpsw,
	const struct dpsw_replic *replic,
	struct dpsw_vlan_if_cfg *cfg)
{
	int err = 0, id, rrid;
	uint16_t cnt = 0;
	struct replic_element_info rr;

	/*! Include zero element */
	if (replic->rrid_root_inuse == 1) {
		cfg->if_id[cnt] = replic->root_if_id;
		cnt++;
	}

	/*! Get replic head rrid */
	err = replic_get_element_head(replic->replic, &id);
	if (err == 0)
		replic_get_element_rrid(replic->replic, id, &rrid);
	else
		rrid = 0;

	/*! go over link list to obtain interfaces */
	while ((rrid != 0) && (cnt < dpsw->num_ifs)) {
		/*! Get Replication record */
		err = replic_query_element_rrid(rrid, &rr);
		CHECK_COND_RETVAL(err == 0, err);

		/*! Map qdid to interface id */
		err = qdid_to_ifid(dpsw, rr.qdid, &(cfg->if_id[cnt]));
		CHECK_COND_RETVAL(err == 0, err);

		/*! go to the next element */
		rrid = rr.next_rrid;

		/*! Update counter */
		cnt++;
	}

	/*! Save counter to user */
	cfg->num_ifs = cnt;
	return 0;
}

int dbg_replic(struct dpsw *dpsw, int rrid)
{
	int err = 0;
	uint16_t if_id = (uint16_t)(-1);
	struct replic_element_info rr;

    pr_info("Replication Link List\n");

	/*! go over link list to obtain interfaces */
	while (rrid != 0) {
		/*! Get Replication record */
		err = replic_query_element_rrid(rrid, &rr);
		CHECK_COND_RETVAL(err == 0, err);

		/*! Map qdid to interface id */
		qdid_to_ifid(dpsw, rr.qdid, &if_id);

        pr_info("IF:%02X, QDID:%04X, FQID::%04X, RRID:%04X, RRID_NEXT:%04X\n",
                if_id, rr.qdid, rr.fqid, rrid, rr.next_rrid);

		/*! go to the next element */
		rrid = rr.next_rrid;
		if_id = (uint16_t)(-1);
	}

	return 0;
}

static uint16_t replic_get_ifs_cnt(struct dpsw *dpsw,
	const struct dpsw_replic *replic)
{
	int count = 0;

	if (dpsw->flooding_enable == 0)
		return (uint16_t)count;

	count = (replic->rrid_root_inuse == 1) ?
		replic_get_element_inuse_count(replic->replic) + 1 :
		replic_get_element_inuse_count(replic->replic);

	return (uint16_t)count;
}

/**
 * @brief       ACL
 *
 */
int dpsw_acl_add(struct dpsw *dpsw,
	uint16_t *acl_id,
	const struct dpsw_acl_cfg *cfg)
{
	/**
	 -# Verify acl_cfg parameters
	 -# Allocate acl slot in MC database
	 -# Save configuration
	 -# Allocate acl in CTLU
	 */
	int err = 0;
	struct dpsw_acl *acl;
	struct dptbl_cfg acl_cfg;
	struct dpmng_amq amq;

	/* Obtain AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	/* Find free fdb */
	err = acl_get_key(dpsw, acl_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Add ACL key */
	err = hmap_add_key(dpsw->hmap_acl, (hmap_key)acl_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_acl, (hmap_key)acl_id, (void **)&acl);
	CHECK_COND_RETVAL(err == 0, err);

	/* Save configuration */
	acl->max_entries = cfg->max_entries; /*! total number*/

	/*! Create ACL table */
	memset(&acl_cfg, 0, sizeof(struct dptbl_cfg));
	acl_cfg.type = DPTBL_TYPE_TCAM_ACL;
	acl_cfg.mem_type = DPTBL_PEB;
	acl_cfg.max_rules = cfg->max_entries;
	acl_cfg.max_key_size = DPSW_ACL_KEY_SIZE;
	acl_cfg.icid = amq.icid;
	acl_cfg.options = DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;

	acl->hndl = dptbl_init(dpsw->handle.dptbl_ing, &acl_cfg);

	if (acl->hndl == NULL) { /*! Error case */
		hmap_remove_key(dpsw->hmap_acl, (hmap_key)acl_id);
		err = -ENAVAIL;
	}

	return err;
}

int dpsw_acl_remove(struct dpsw *dpsw, uint16_t acl_id)
{
	/*
	 -# Check ACL ID is exist
	 -# Check no IF is referencing this ACL
	 -# Delete table
	 */
	int err;
	struct dpsw_acl *acl;
	struct dpsw_acl_if_cfg acl_ifs;
	uint16_t i;

	/*! Retrieve fdb database */
	err = hmap_lookup(dpsw->hmap_acl, (hmap_key)&acl_id, (void **)&acl);
	CHECK_COND_RETVAL(err == 0, err);

	CHECK_COND_RETVAL(acl->hndl, -EFAULT); /* Bad address */

	/*! De-associate all interfaces */
	memset(&acl_ifs, 0x0, sizeof(struct dpsw_acl_if_cfg));
	for (i = 0; i < dpsw->num_ifs; i++) {
		if (dpsw->iface[i].acl_id == acl_id)
			acl_ifs.if_id[acl_ifs.num_ifs++] = i;
	}
	err = (acl_ifs.num_ifs != 0) ?
		dpsw_acl_remove_if(dpsw, acl_id, &acl_ifs) : 0;
	CHECK_COND_RETVAL(err == 0, err);

	/*! Delete ACL Table */
	err = dptbl_delete(acl->hndl);
	if (err == 0)
		hmap_remove_key(dpsw->hmap_acl, (hmap_key)&acl_id);

	acl->hndl = NULL;
	return err;
}

static int acl_make_rule(struct dpsw *dpsw,
	const struct dpsw_acl_entry_cfg *entry,
	uint8_t *key,
	uint8_t *mask,
	struct dptbl_rule *rule)
{
	/*
	 *      -zero out key, mask and rule
	 *      -copy staff to key
	 *      -copy staff to mask
	 *      -assign key and mask to rule
	 */
	/*! zero out key, mask and rule */
	struct dpsw_acl_fields 	aligned_key;

	memset(rule, 0x0, sizeof(struct dptbl_rule));
	memset(&aligned_key, 0x0, sizeof(struct dpsw_acl_fields));

	/*! copy staff to key & mask */
	acl_align_key(&aligned_key, &(entry->key->match), &(entry->key->mask));
	acl_set_key(key, &aligned_key);
	acl_set_key(mask, &(entry->key->mask));

	/*! assign key and mask to rule */
	rule->rule_cfg.masked.key = key; /*! key */
	rule->rule_cfg.masked.mask = mask; /*! mask */
	rule->rule_cfg.masked.size = DPSW_ACL_KEY_SIZE; /*! size */
	rule->rule_cfg.masked.priority = entry->precedence; /*! priority */

	return 0;
}


static void acl_align_key(struct dpsw_acl_fields *result,
	const struct dpsw_acl_fields *key,
	const struct dpsw_acl_fields *mask)
{
	/* L2 Destination MAC address */
	result->l2_dest_mac[0] = key->l2_dest_mac[0] & mask->l2_dest_mac[0];
	result->l2_dest_mac[1] = key->l2_dest_mac[1] & mask->l2_dest_mac[1];
	result->l2_dest_mac[2] = key->l2_dest_mac[2] & mask->l2_dest_mac[2];
	result->l2_dest_mac[3] = key->l2_dest_mac[3] & mask->l2_dest_mac[3];
	result->l2_dest_mac[4] = key->l2_dest_mac[4] & mask->l2_dest_mac[4];
	result->l2_dest_mac[5] = key->l2_dest_mac[5] & mask->l2_dest_mac[5];

	/* L2 Source MAC address */
	result->l2_source_mac[0] = key->l2_source_mac[0] & mask->l2_source_mac[0];
	result->l2_source_mac[1] = key->l2_source_mac[1] & mask->l2_source_mac[1];
	result->l2_source_mac[2] = key->l2_source_mac[2] & mask->l2_source_mac[2];
	result->l2_source_mac[3] = key->l2_source_mac[3] & mask->l2_source_mac[3];
	result->l2_source_mac[4] = key->l2_source_mac[4] & mask->l2_source_mac[4];
	result->l2_source_mac[5] = key->l2_source_mac[5] & mask->l2_source_mac[5];

	/* 802.1q type protocol identifier */
	result->l2_tpid = key->l2_tpid & mask->l2_tpid;

	/* L2 Priority Code Point + DEI 802.1p */
	result->l2_pcp_dei = key->l2_pcp_dei & mask->l2_pcp_dei;

	/* 802.1q VLAN ID */
	result->l2_vlan_id = key->l2_vlan_id & mask->l2_vlan_id;

	/* L2 Ethernet type */
	result->l2_ether_type = key->l2_ether_type & mask->l2_ether_type;

	/* L3 Differentiated services code point */
	result->l3_dscp = key->l3_dscp & mask->l3_dscp;

	/* L3 next protocol */
	result->l3_protocol = key->l3_protocol & mask->l3_protocol;

	/* L3 Source IPv4 IP */
	result->l3_source_ip = key->l3_source_ip & mask->l3_source_ip;

	/* L3 Destination IPv4 IP */
	result->l3_dest_ip = key->l3_dest_ip & mask->l3_dest_ip;

	/* L4 Source TCP/UDP Port */
	result->l4_source_port = key->l4_source_port & mask->l4_source_port;

	/* L4 Destination TCP/UDP Port */
	result->l4_dest_port = key->l4_dest_port & mask->l4_dest_port;

}


static void acl_set_key(uint8_t *key,
	const struct dpsw_acl_fields *fields)
{
	uint8_t l2_pcp_dei, l3_dscp;

	/*! Reset key */
	memset(key, 0x0, DPSW_ACL_KEY_SIZE);

	/*! update l2_pcp_dei */
	l2_pcp_dei = (fields->l2_pcp_dei) << 4;

	/*! Update DSCP */
	l3_dscp = (fields->l3_dscp) << 2;

	/*! L2 Destination MAC address */
	memcpy(&key[0], &(fields->l2_dest_mac[0]), 6);

	/*! L2 Source MAC address */
	memcpy(&key[6], &(fields->l2_source_mac[0]), 6);

	/*! 802.1q type protocol identifier */
	memcpy(&key[12], &(fields->l2_tpid), 2);

	/*! L2 Priority Code Point + DEI 802.1p */
	memcpy(&key[14], &(l2_pcp_dei), 1);

	/*! 802.1q VLAN ID */
	memcpy(&key[15], &(fields->l2_vlan_id), 2);

	/*! L2 Ethernet type */
	memcpy(&key[17], &(fields->l2_ether_type), 2);

	/*! L3 Differentiated services code point */
	memcpy(&key[19], &(l3_dscp), 1);

	/*! L3 next protocol */
	memcpy(&key[20], &(fields->l3_protocol), 1);

	/*! L3 Source IPv4 IP */
	memcpy(&key[21], &(fields->l3_source_ip), 4);

	/*! L3 Destination IPv4 IP */
	memcpy(&key[25], &(fields->l3_dest_ip), 4);

	/*! L4 Source TCP/UDP Port */
	memcpy(&key[29], &(fields->l4_source_port), 2);

	/*! L4 Destination TCP/UDP Port */
	memcpy(&key[31], &(fields->l4_dest_port), 2);
}

static int acl_make_action(struct dpsw *dpsw,
	const struct dpsw_acl_entry_cfg *entry,
	struct dptbl_action *action)
{
	int err = 0;
	struct ctrl_if_attr attr;

	memset(action, 0, sizeof(struct dptbl_action));

	switch (entry->result.action) {
		case DPSW_ACL_ACTION_DROP:
			/*! Drop action here */
			action->next_action = DPTBL_ACTION_DONE;
			action->options = DPTBL_ACTION_SET_DISCARD_FLAG;
			break;
		case DPSW_ACL_ACTION_REDIRECT:
			/* Verify parameters */
			CHECK_COND_RETVAL(entry->result.if_id < dpsw->num_ifs, -EACCES);
			/* Redirect */
			action->next_action = DPTBL_ACTION_DONE;
			action->options = DPTBL_ACTION_SET_QDID;
			action->options |= DPTBL_ACTION_CLEAR_DISCARD_FLAG;

	                /* Obtain qdid */
	                err = get_iface_qdid(
	                	dpsw,
	                	entry->result.if_id,
	                	&(action->qd_id));
	                CHECK_COND_RETVAL(err == 0, err);
			break;
		case DPSW_ACL_ACTION_ACCEPT:
			/* Accept */
			action->next_action = DPTBL_ACTION_DONE;
			action->options = 0;
			break;
		case DPSW_ACL_ACTION_REDIRECT_TO_CTRL_IF:
			/* Obtain control interface attributes */
			err = ctrl_if_get_rx_flow_attr(dpsw->ctrl_if, 0, &attr);
			CHECK_COND_RETVAL(err == 0, err);

			/* set action */
			action->next_action = DPTBL_ACTION_DONE;
			action->options |= DPTBL_ACTION_CLEAR_DISCARD_FLAG;
			action->options |= DPTBL_ACTION_SET_QDID;
			action->options |= DPTBL_ACTION_SET_POLICER_ID;
			action->options |= DPTBL_ACTION_SET_QOS_MAP_METHOD;
			action->qd_id = attr.internal_qdid;
			action->dppolicer_profile_id = attr.plid;
			action->qos_map_method =  DPTBL_ACTION_NOT_QoS_BASED;
			break;
	}
	return err;
}

int dpsw_acl_add_entry(struct dpsw *dpsw,
	uint16_t acl_id,
	const struct dpsw_acl_entry_cfg *cfg)
{
	/**
	 -# Verify Configuration parameters
	 -# Retrieve acl database
	 -# Build rule
	 -# Build action
	 -# Add/Modify rule - dptbl_add_rule/dptbl_modify_rule
	 */
	int err = 0;
	struct dpsw_acl *acl;
	uint8_t key[DPSW_ACL_KEY_SIZE];
	uint8_t mask[DPSW_ACL_KEY_SIZE];
	struct dptbl_rule rule;
	struct dptbl_action action;

	/*! Verify Configuration parameters */
	err = acl_add_entry_params_integrity(dpsw, acl_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Retrieve acl database */
	err = hmap_lookup(dpsw->hmap_acl, (hmap_key)&acl_id, (void **)&acl);
	CHECK_COND_RETVAL(err == 0, err);

	/*! sanity check */
	CHECK_COND_RETVAL(acl->hndl, -EFAULT); /* Bad address */

	/*! make key */
	err = acl_make_rule(dpsw, cfg, key, mask, &rule);
	CHECK_COND_RETVAL(err == 0, err);

	/*! make action */
	err = acl_make_action(dpsw, cfg, &action);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Add/Modify rule */
	err = dptbl_add_rule(acl->hndl, &rule, &action, 0);
	if (err == -EEXIST) {
		err = dptbl_modify_rule(acl->hndl, &rule, &action);
	}

	return err;
}


static int acl_add_entry_params_integrity(struct dpsw *dpsw,
	uint16_t acl_id,
	const struct dpsw_acl_entry_cfg *cfg)
{
	int err = 0;

	switch (cfg->result.action)
	{
		case DPSW_ACL_ACTION_REDIRECT:
			if (cfg->result.if_id >= dpsw->num_ifs )
				err = -EDOM;
			break;
		case DPSW_ACL_ACTION_REDIRECT_TO_CTRL_IF:
			if (dpsw->ctrl_if_enable == 0)
				err = -EINVAL;
			break;
		default:
			break;
	}
	return err;
}


int dpsw_acl_remove_entry(struct dpsw *dpsw,
	uint16_t acl_id,
	const struct dpsw_acl_entry_cfg *cfg)
{
	/*
	 *      -# Retrieve acl database
	 *      -# build rule
	 *      -# remove an entry - dptbl_remove_rule
	 */
	int err = 0;
	struct dpsw_acl *acl;
	uint8_t key[DPSW_ACL_KEY_SIZE];
	uint8_t mask[DPSW_ACL_KEY_SIZE];
	struct dptbl_rule rule;

	/*! Retrieve acl database */
	err = hmap_lookup(dpsw->hmap_acl, (hmap_key)&acl_id, (void **)&acl);
	CHECK_COND_RETVAL(err == 0, err);

	/*! make key */
	err = acl_make_rule(dpsw, cfg, key, mask, &rule);
	CHECK_COND_RETVAL(err == 0, err);

	/*! remove rule */
	err = dptbl_remove_rule(acl->hndl, &rule);

	return err;
}

int dpsw_acl_add_if(struct dpsw *dpsw,
	uint16_t acl_id,
	const struct dpsw_acl_if_cfg *acl_ifs)
{
	/*!
	 *      -Verify parameters
	 *      -Obtain ACL database
	 *      -Update ACL ID in IFP having an apropriate acl id
	 *      -Increment number of interfaces added to acl
	 */
	int err = 0;
	struct dpsw_acl *acl;

	/*! Check parameters */
	err = acl_if_params_integrity(dpsw, DPSW_ACL_VOID, acl_ifs);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Obtain ACL database */
	err = hmap_lookup(dpsw->hmap_acl, (hmap_key)&acl_id, (void **)&acl);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Add ACL to IFPs */
	err = acl_add_to_ifps(dpsw, acl->hndl, acl_ifs);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update interface to acl reference */
	err = acl_if_set_reference(dpsw, acl_id, acl_ifs);

	return err;
}

static int acl_if_set_reference(struct dpsw *dpsw,
	uint16_t acl_id,
	const struct dpsw_acl_if_cfg *acl_ifs)
{
	int i;

	for (i = 0; i < acl_ifs->num_ifs; i++)
		dpsw->iface[acl_ifs->if_id[i]].acl_id = acl_id;

	return 0;
}

static int acl_get_reference_count(struct dpsw *dpsw, uint16_t acl_id)
{
	int i, count = 0;

	for (i = 0; i < dpsw->num_ifs; i++) {
		if (dpsw->iface[i].acl_id == acl_id)
			count++;
	}
	return count;
}

static int acl_if_params_integrity(struct dpsw *dpsw,
	uint16_t acl_id,
	const struct dpsw_acl_if_cfg *acl_ifs)
{
	uint16_t i;

	/*! Number of interfaces to add low boundary */
	CHECK_COND_RETVAL(acl_ifs->num_ifs, -EEXIST); /*! nothing to add */

	/*! Number of interfaces to add high boundary */
	if (acl_ifs->num_ifs >= DPSW_MAX_IF)
		return -EINVAL; /*! out of domain */

	/*! Interface IDs */
	for (i = 0; i < acl_ifs->num_ifs; i++) {
		if (acl_ifs->if_id[i] >= dpsw->num_ifs)
			return -EINVAL; /*!< Invalid argument */
	}

	/*! ACL reference */
	for (i = 0; i < acl_ifs->num_ifs; i++) {
		if (dpsw->iface[acl_ifs->if_id[i]].acl_id != acl_id)
			return -EEXIST;
	}

	return 0;
}

static int acl_add_to_ifps(struct dpsw *dpsw,
	struct dptbl *tbl,
	const struct dpsw_acl_if_cfg *acl_ifs)
{
	/*
	 *      - Get acl tid
	 *      - set ifp to all required interfaces
	 */
	int err = 0, acl_tid;
	uint16_t i;

	/* Get VLAN Table ID */
	dptbl_get_id(tbl, &acl_tid);

	/*! set ifp to all required interfaces */
	for (i = 0; i < acl_ifs->num_ifs; i++) {
		err = acl_add_to_ifp(dpsw, acl_tid, acl_ifs->if_id[i]);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int acl_add_to_ifp(struct dpsw *dpsw, int acl_tid, uint16_t if_id)
{
	/*
	 *      -Obtain ifp descriptor
	 *      -Calculate opaque
	 *      -Set ACL ID to IFP
	 */
	int err = 0;
	struct dpsw_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;
	uint32_t opaque;

	/*! Reset descriptor */
	memset(&eiop_ifp_desc, 0x0, sizeof(struct eiop_ifp_desc));

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! Get descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);

	/*! Calculate opaque */
	opaque = (uint32_t)((acl_tid << 16) | (dpsw->acl_kg.id << 8));

	/*! Set ACL ID to IFP */
	eiop_ifp_rx_pcd_set_opaque_h(&eiop_ifp_desc, opaque);

	return err;
}

int dpsw_acl_remove_if(struct dpsw *dpsw,
	uint16_t acl_id,
	const struct dpsw_acl_if_cfg *acl_ifs)
{
	/*!
	 *      -Verify parameters
	 *      -Obtain ACL database
	 *      -Update ACL ID in IFP having an apropriate acl id
	 *      -Increment number of interfaces added to acl
	 */
	int err = 0;
	struct dpsw_acl *acl;

	/*! Check parameters */
	err = acl_if_params_integrity(dpsw, acl_id, acl_ifs);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Obtain ACL database */
	err = hmap_lookup(dpsw->hmap_acl, (hmap_key)&acl_id, (void **)&acl);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Add ACL to IFPs */
	err = acl_add_to_ifps(dpsw, dpsw->acl_void_tbl, acl_ifs);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Update interface to ACL reference */
	err = acl_if_set_reference(dpsw, DPSW_ACL_VOID, acl_ifs);

	return err;
}

int dpsw_acl_get_attributes(struct dpsw *dpsw,
	uint16_t acl_id,
	struct dpsw_acl_attr *attr)
{
	int err = 0;
	struct dpsw_acl *acl;
	int num_entries;

	/*! Obtain ACL database */
	err = hmap_lookup(dpsw->hmap_acl, (hmap_key)&acl_id, (void **)&acl);
	CHECK_COND_RETVAL(err == 0, err);

	/* Get number of entries */
	err = dptbl_get_num_of_used_rules(acl->hndl , &num_entries);
	CHECK_COND_RETVAL(err == 0, err);

	attr->max_entries = acl->max_entries;
	attr->num_ifs = (uint16_t)acl_get_reference_count(dpsw, acl_id);
	attr->num_entries = (uint16_t)num_entries;

	return err;
}

/**
 *
 * @brief       Control interface
 *
 */

int dpsw_set_ctrl_if(struct dpsw *dpsw, uint16_t if_id)
{
	int err = 0;

	return err;
}

int dpsw_get_ctrl_if(struct dpsw *dpsw, uint16_t *if_id)
{
	return 0;
}

int dpsw_set_dev_ctx(struct dpsw *dpsw, const struct dpmng_dev_ctx *dev_ctx)
{
	/* Copy AMQ */
	memcpy(&(dpsw->dev_ctx), dev_ctx, sizeof(struct dpmng_dev_ctx));

	if (dpsw->ctrl_if_enable == 1){
		ctrl_if_set_dev_ctx(dpsw->ctrl_if, dev_ctx);
	}
	return 0;
}

int dpsw_if_set_metering(struct dpsw *dpsw,
                        uint16_t if_id,
                        uint8_t tc_id,
                        struct dpsw_metering_cfg *cfg)
{
/*
 *       - define use-case (add/remove/reconfigure)
 *       	-add
 *       		- add key to hmap
 *       	-remove
 *       		- remove key from hmap
 *       		- return 0;
 *       - Configure meter
 *       - Update QoS table (dpqos_add_rule)
 *
 * */
	int err = 0, metering_enable;
        struct dpsw_metering   *metering;
        struct dpsw_if		*iface;

        err = metering_params_integrity(dpsw, if_id, tc_id, cfg);
        CHECK_COND_RETVAL(err == 0, err);

        iface = &(dpsw->iface[if_id]);

        metering_enable = !hmap_lookup(iface->hmap_metering,
                          (hmap_key)&tc_id, (void **)&metering);

        if (metering_enable == 1) {/* meter enabled */
        	if (cfg->mode == DPSW_METERING_MODE_NONE) {
        		/* Remove */
        		err = hmap_remove_key(iface->hmap_metering,
        		                      (hmap_key)&tc_id);
        		CHECK_COND_RETVAL(err == 0, err);

        		/* Update QoS mapping */
        		err = set_if_plid(dpsw, if_id, tc_id);
        		CHECK_COND_RETVAL(err == 0, err);
        	}
        }
        else {/* meter disabled */
        	if (cfg->mode == DPSW_METERING_MODE_NONE) {
        		/* no action */
        		return err;
        	}
        	else {
        		/* add */
        	        err = hmap_add_key(iface->hmap_metering,
        	                           (hmap_key)&tc_id);
        	        CHECK_COND_RETVAL(err == 0, err);

        	        err = hmap_lookup(iface->hmap_metering,
        	                          (hmap_key)&tc_id, (void **)&metering);
        	        CHECK_COND_RETVAL(err == 0, err);
        	}
        }

        /* Configure meter */
        err = metering_configure(dpsw, metering->plid, cfg);
        CHECK_COND_RETVAL(err == 0, err);

	/* Update QoS mapping */
	err = set_if_plid(dpsw, if_id, tc_id);

        return err;
}

int set_if_plid(struct dpsw *dpsw, uint16_t if_id, uint8_t tc_id)
{
	int err = 0, metering_enable, i;
        struct dpsw_metering   *metering;
	struct dpqos_rule rule;
        struct dpqos_action action;
        struct dpsw_if		*iface;
        struct ceetm_if_attr 	attr;

        /* Obtain interface */
        iface = &(dpsw->iface[if_id]);


        /* Enable metering flag */
        metering_enable = !hmap_lookup(iface->hmap_metering,
                          (hmap_key)&tc_id, (void **)&metering);

        /* action */
        if (metering_enable == 1) {
                action.options = DPQOS_ACTION_SET_POLICER_ID |
                			DPQOS_ACTION_SET_QPRI;

                action.dppolicer_profile_id = metering->plid;

        	action.next_action = DPQOS_ACTION_POLICER;
        }
        else {
                action.options = DPQOS_ACTION_SET_QPRI;
                action.next_action = DPQOS_ACTION_DONE;
        }

        /* rule */
        rule.method = (iface->priority_selector ==
        	DPSW_PRIORITY_SELECTOR_PCP) ?
        	DPQOS_METHOD_BASED_ON_VLAN : DPQOS_METHOD_BASED_ON_IP;

        ceetm_if_get_attributes(iface->ceetm_if, &attr);

        for (i = 0; i < DPSW_MAX_PRIORITIES; i++) {
        	if (attr.ccqs.ccqidx[i] == tc_id) {
        	        /* Set priority */
        		rule.priority = i;
        	        action.qpri = i;

        	        /* update QoS entry */
        	        err = dpqos_modify_rule(iface->dpqos, &rule, &action);
        	        if (err != 0)
        	        	return err;
        	}
        }
        return err;
}

int flooding_metering_params_integrity(struct dpsw *dpsw,
                        uint16_t if_id,
                        struct dpsw_metering_cfg *cfg)
{
	if (dpsw->flooding_metering_enable == 0)
		return -EACCES;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	/* Verify metering configuration */
	return 0;
}

int metering_params_integrity(struct dpsw *dpsw,
                        uint16_t if_id,
                        uint8_t tc_id,
                        struct dpsw_metering_cfg *cfg)
{
	CHECK_COND_RETVAL(dpsw->metering_enable, -EACCES);

	CHECK_COND_RETVAL(if_id < dpsw->num_ifs, -EINVAL);

	/* Verify metering configuration */
	CHECK_COND_RETVAL(dpsw->iface[if_id].hmap_metering->key_size == 1, -EINVAL);
	
	return 0;
}

int dpsw_if_set_flooding_metering(struct dpsw *dpsw,
                        uint16_t if_id,
                        struct dpsw_metering_cfg *cfg)
{
	int err = 0;
	struct dpsw_if *iface;

	err = flooding_metering_params_integrity(dpsw, if_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/* Configure Metering */
	err = metering_configure(dpsw, iface->flooding_plid, cfg);

	return err;
}

static int metering_configure(struct dpsw *dpsw,
        		int plid,
        		struct dpsw_metering_cfg *cfg)
{
	int err;
	struct dppolicer_profile_cfg 	policer_profile;

	/* reset policer profile */
	memset(&policer_profile, 0x0, sizeof(struct dppolicer_profile_cfg));

	/* Color blind, discard red */
	policer_profile.options = DPPOLICER_OPT_COLOR_BLIND |
				DPPOLICER_OPT_DISCARD_RED;

	/* algorithm RFC2698/4115 */
	switch (cfg->mode) {
		case DPSW_METERING_MODE_NONE:          /*! metering disabled */
			policer_profile.alg = DPPPLICER_PASS_THROUGH;
			break;
		case DPSW_METERING_MODE_RFC2698:       /*! RFC 2698 */
			policer_profile.alg = DPPPLICER_RFC_2698;
			break;
		case DPSW_METERING_MODE_RFC4115:        /*! RFC 4115 */
			policer_profile.alg = DPPPLICER_RFC_4115;
			break;
		default:
			break;
	}

	/* Set drop priority numbers to match QMan */
	policer_profile.green_drop_pri = DPSW_DROPP_GREEN;	/* Green  */
	policer_profile.yellow_drop_pri = DPSW_DROPP_YELLOW;	/* Yellow  */
	policer_profile.red_drop_pri = DPSW_DROPP_RED;		/* Red  */
	policer_profile.default_color = DPPPLICER_GREEN;

	/* Byte rate configuration */
	policer_profile.non_passthrough_cfg.byte_rate_cfg.frame_len_select =
		DPPPLICER_FULL_FRM_LEN;
	policer_profile.non_passthrough_cfg.byte_rate_cfg.\
		rollback_frame_select = DPPPLICER_ROLLBACK_L2_FRM_LEN;

	/* Rate mode configuration */
	policer_profile.non_passthrough_cfg.rate_mode =
		(cfg->units == DPSW_METERING_UNIT_BYTES) ?
		DPPPLICER_BYTE_RATE_MODE : DPPPLICER_PACKET_RATE_MODE;

	/* Committed rate configuration */
	policer_profile.non_passthrough_cfg.committed_info_rate =
		cfg->cir; 	/* KBits/Second or Packets/Second */
	policer_profile.non_passthrough_cfg.committed_burst_size =
		cfg->cbs; 	/* Bytes/Packets */

	/* Excessive rate configuration */
	policer_profile.non_passthrough_cfg.peak_or_excessive_info_rate =
		cfg->eir;	/* KBits/Second or Packets/Second */
	policer_profile.non_passthrough_cfg.peak_or_excessive_burst_size =
		cfg->ebs; 	/*!< Bytes/Packets */

	/* Init police profile */
	err = dppolicer_init_profile(
		dpsw->handle.dppolicer_ing,	/* Policer handle */
	        plid, 				/* Policer id */
	        NULL, 				/* Private command parameters */
	        &policer_profile);		/* configuration */

	return err;
}

#ifdef MC_CLI
int dpsw_if_get_metering(struct dpsw *dpsw, 
        uint16_t if_id,
        uint8_t tc_id,
        struct dpsw_metering_counters *counters)    
{
       int err = 0;
        struct dpsw_if           *iface;
        struct dpsw_metering   *metering;
 
        iface = &(dpsw->iface[if_id]);
       
        if (iface->hmap_metering == NULL)
             return -ENAVAIL;
        
        err = hmap_lookup(iface->hmap_metering,
                          (hmap_key)&tc_id, (void **)&metering);
        if (err != 0)
             return -ENODEV;
        
       /* get red counter */
       err = dppolicer_get_profile_counter(
             dpsw->handle.dppolicer_ing,
             metering->plid,
               NULL,
               DPPOLICER_CNT_RED,
               &counters->red);
       if (err != 0)
             return err;
       
       /* get yellow counter */
       err = dppolicer_get_profile_counter(
             dpsw->handle.dppolicer_ing,
             metering->plid,
               NULL,
               DPPOLICER_CNT_YELLOW,
               &counters->yellow);
       if (err != 0)
             return err;

       /* get green counter */
       err = dppolicer_get_profile_counter(
             dpsw->handle.dppolicer_ing,
             metering->plid,
               NULL,
               DPPOLICER_CNT_GREEN,
               &counters->green);

       return err;
}
#endif

int dpsw_if_tc_set_early_drop(struct dpsw *dpsw,
                        uint16_t if_id,
                        uint8_t tc_id,
                        const struct dpsw_early_drop_cfg *drop_cfg)
{
	/*
	*       - Verify parameters integrity
	*       - set_early_drop -> int ceetm_if_ccgs_configure()
	*/
	int err = 0;

	err = if_set_early_drop_params_integrity(dpsw, if_id, tc_id, drop_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* update ceetm if */
	err = if_set_early_drop(dpsw, if_id, tc_id, drop_cfg);

	return err;
}

static int if_set_early_drop_params_integrity(
	struct dpsw *dpsw,
        uint16_t if_id,
        uint8_t tc_id,
        const struct dpsw_early_drop_cfg *drop_cfg)
{
	int err = 0;

	if (if_id >= dpsw->num_ifs)
                return -EINVAL;

	/* traffic class is in range */
	if (tc_id >= DPSW_MAX_TC)
		return -EINVAL;

	return err;
}

static int if_set_early_drop(
	struct dpsw *dpsw,
        uint16_t if_id,
        uint8_t tc_id,
        const struct dpsw_early_drop_cfg *drop)
{
	int 			err = 0;
	struct dpsw_if 		*iface;
	struct ceetm_if_ccg_cfg ccg;
	uint32_t tail_drop_threshold;

	/* Obtain interface */
	iface = &(dpsw->iface[if_id]);

	tail_drop_threshold = drop->tail_drop_threshold;
	if( drop->units == DPSW_EARLY_DROP_UNIT_BUFFERS ) {
		tail_drop_threshold *= (DPSW_BP_BUFFER_SIZE / 64);
	}

	/* build configuration */
	memset(&ccg, 0x0, sizeof(struct ceetm_if_ccg_cfg));
	ccg.units = get_early_drop_unit(drop->units);
	ccg.mode = get_early_drop_mode(drop->drop_mode);

	/* tail drop */
	ccg.tail_drop_threshold = tail_drop_threshold;

	/* wred green */
	ccg.green.drop_probability = drop->green.drop_probability;
	ccg.green.max_threshold = drop->green.max_threshold;
	ccg.green.min_threshold = drop->green.min_threshold;

	/* wred yellow */
	ccg.yellow.drop_probability = drop->yellow.drop_probability;
	ccg.yellow.max_threshold = drop->yellow.max_threshold;
	ccg.yellow.min_threshold = drop->yellow.min_threshold;

	/* configure ceetm interface */
	err = ceetm_if_ccg_configure(iface->ceetm_if, tc_id, &ccg);

	return err;
}

static int if_get_early_drop(
	struct dpsw *dpsw,
        uint16_t if_id,
        uint8_t tc_id,
        struct dpsw_early_drop_cfg *drop)
{
	struct ceetm_if_ccg_cfg ccg;
	struct dpsw_if 		*iface;

	iface = &(dpsw->iface[if_id]);
	ceetm_if_ccg_get_config(iface->ceetm_if, tc_id, &ccg);

	memset(drop, 0, sizeof(struct dpsw_early_drop_cfg) );
	switch( ccg.units ) {
	case CEETM_IF_CCG_UNIT_BYTES:
		drop->units = DPSW_EARLY_DROP_UNIT_BYTES;
		break;
	case CEETM_IF_CCG_UNIT_PACKETS:
		drop->units = DPSW_EARLY_DROP_UNIT_PACKETS;
		break;
	case CEETM_IF_CCG_UNIT_BUFFERS:
		drop->units = DPSW_EARLY_DROP_UNIT_BUFFERS;
		break;
	default:
		pr_err("Unknown unit type: %d\n", ccg.units);
		return -EINVAL;
	}

	switch( ccg.mode ) {
	case CEETM_IF_CCG_MODE_NONE:
		drop->drop_mode = DPSW_EARLY_DROP_MODE_NONE;
		break;
	case CEETM_IF_CCG_MODE_TAIL:
		drop->drop_mode = DPSW_EARLY_DROP_MODE_TAIL;
		break;
	case CEETM_IF_CCG_MODE_WRED:
		drop->drop_mode = DPSW_EARLY_DROP_MODE_WRED;
		break;
	default:
		pr_err("Unknown mode type: %d\n", ccg.mode);
		return -EINVAL;
	}

	/* tail drop */
	drop->tail_drop_threshold = ccg.tail_drop_threshold;
	if( drop->units == DPSW_EARLY_DROP_UNIT_BUFFERS ) {
		drop->tail_drop_threshold /= (DPSW_BP_BUFFER_SIZE / 64);
	}

	/* wred green */
	drop->green.drop_probability = ccg.green.drop_probability;
	drop->green.max_threshold = ccg.green.max_threshold;
	drop->green.min_threshold = ccg.green.min_threshold;

	/* wred yellow */
	drop->yellow.drop_probability = ccg.yellow.drop_probability;
	drop->yellow.max_threshold = ccg.yellow.max_threshold;
	drop->yellow.min_threshold = ccg.yellow.min_threshold;

	return 0;
}

static int link_state_common_denominator(
	const struct linkman_endpoint	*ep1,
	const struct linkman_endpoint 	*ep2,
	uint32_t committed_rate,
	struct linkman_link_state *link_state)
{
	int err = 0;

	/* 1 - negotiation, 2 - negotiation */
	if ( ((ep1->options & LINKMAN_LINK_OPT_AUTONEG) != 0) &&
		((ep2->options & LINKMAN_LINK_OPT_AUTONEG) != 0)) {
		link_state->rate = committed_rate;
	}
	/* 1 - negotiation, 2 - fixed */
	else if ( ((ep1->options & LINKMAN_LINK_OPT_AUTONEG) != 0) &&
		((ep2->options & LINKMAN_LINK_OPT_AUTONEG) == 0)) {
		if (committed_rate < ep2->rate)
			return -ENOTSUP;
		link_state->rate = ep2->rate;
	}
	/* 1 - fixed, 2 - negotiation */
	else if ( ((ep1->options & LINKMAN_LINK_OPT_AUTONEG) == 0) &&
		((ep2->options & LINKMAN_LINK_OPT_AUTONEG) != 0)) {
		if (committed_rate < ep1->rate)
			return -ENOTSUP;
		link_state->rate = ep1->rate;
	}
	/* 1 - fixed, 2 - fixed */
	else if ( ((ep1->options & LINKMAN_LINK_OPT_AUTONEG) == 0) &&
		((ep2->options & LINKMAN_LINK_OPT_AUTONEG) == 0)) {
		if (ep1->rate != ep2->rate)
			return -ENOTSUP;
		link_state->rate = ep1->rate;
	}

	/* get common options */
	link_state->options = ep1->options & ep2->options;

	return err;
}

int dpsw_event_complete_cb(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	struct dpsw *dpsw = (struct dpsw *) handle;
	uint16_t event = 0;
	int err = 0;

        /* Verify self end point integrity */
        err = endpoint_integrity(handle, self);
        if (err != 0)
                return err;

	switch(control->event) {
		case LINKMAN_EVENT_DISCONNECT:
		case LINKMAN_EVENT_CONNECT:
			event |= DPSW_IRQ_EVENT_ENDPOINT_CHANGED;
			break;
		case LINKMAN_EVENT_NEGOTIATION_FAIL:
		case LINKMAN_EVENT_NEGOTIATION:
		case LINKMAN_EVENT_LINKDOWN:
			break;
		case LINKMAN_EVENT_NEGOTIATION_OK:
		case LINKMAN_EVENT_LINKUP:
			/* Check that the if is added to replicators only one time */
			if (dpsw->iface[self->if_id].linkup_replic_updated)
				break;
			dpsw->iface[self->if_id].linkup_replic_updated = 1;

			err = add_if_to_replic_broadcast(handle, self->if_id);
			err = add_if_to_replic_flooding(handle, self->if_id);
			break;
		default:
		        break;
	}

	event |= DPSW_IRQ_EVENT_LINK_CHANGED;

	/* trigger irq */
	irq_if_trigger(handle, self->if_id, event);

	return err;
}

int dpsw_event_cb(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
        int err;

        /* Verify end-point integrity */
        err = endpoint_integrity(handle, self);
        CHECK_COND_RETVAL(err == 0, err);

        switch (peer->type) {
        	case FSL_MOD_DPMAC:
        		err = event_phys(handle, control, self, peer, action);
        		break;
        	case FSL_MOD_DPNI:
        		err = event_virt(handle, control, self, peer, action);
        		break;
        	default:
        		err = -ENOTSUP; /* Operation not supported */
        		break;
        }
        return err;
}

int event_phys(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0;

	switch (control->event) {
		case LINKMAN_EVENT_CONNECT:
			err = event_connect_phys(
				handle, self, peer, action);
			break;
		case LINKMAN_EVENT_DISCONNECT:
			err = event_disconnect_phys(
				handle, self, peer, action);
			break;
		case LINKMAN_EVENT_LINKUP:
			/* link up */
			err = event_linkup_phys(handle, self, peer, action);
			break;
		case LINKMAN_EVENT_LINKDOWN:
			/* link down */
			err = event_linkdown_phys(handle, self, peer, action);
			break;
		case LINKMAN_EVENT_NEGOTIATION_OK:
			/* link down */
			err = event_negotiation_ok(handle, self, peer, action);
			break;
		case LINKMAN_EVENT_NEGOTIATION_FAIL:
			/* link down */
			err = event_negotiation_fail(handle, self, peer, action);
			break;
		default:
			err = -ENOTSUP; /* Operation not supported */
			break;
        }
        return err;
}

int event_virt(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0;

	switch (control->event) {
		case LINKMAN_EVENT_CONNECT:
			err = event_connect_virt(
				handle, self, peer, control, action);
			break;
		case LINKMAN_EVENT_DISCONNECT:
			err = event_disconnect_virt(
				handle, self, peer, action);
			break;
		case LINKMAN_EVENT_LINKUP:
			/* link up */
			err = event_linkup_virt(
				handle, self, peer, control, action);
			break;
		case LINKMAN_EVENT_LINKDOWN:
			/* link down */
			err = event_linkdown_virt(handle, self, peer, action);
			break;
		default:
			err = -ENOTSUP; /* Operation not supported */
			break;
        }
        return err;
}

int event_connect_virt(struct dpsw 		*dpsw,
        	struct linkman_endpoint        	*self,
        	struct linkman_endpoint         *peer,
        	const struct linkman_control   	*control,
        	struct linkman_action          	*action)
{
        int err, err1 = 0, idx, ifpid;
        struct dpsw_if *iface;
        struct dpmng_accesspoint ap[2];
        struct dpmng_amq  	amq;
        int channel_ids[DPMNG_MAX_CEETM_CH];
        int num_lfq;
        int ceetm_ch_idx;

        /* nothing to pass from dpsw side */
        self->valid_fields |= LINKMAN_FIELD_INIT;

        /* waiting for data to be passed from dpni side */
		if( (peer->valid_fields & LINKMAN_FIELD_INIT) == 0 ) {
			return LINKMAN_ECONT;
		}

        /* Obtain interface */
        iface = &(dpsw->iface[self->if_id]);

        if ((self->valid_fields & LINKMAN_FIELD_CONN_ID) == 0) {

                /* Verify rates */
                err = virt_connection_control_integrity(dpsw, control);
                CHECK_COND_RETVAL(err == 0, err);

                /* Obtain virtual connection */
                err = dpmng_connection_virt_allocate(dpsw->handle.dpmng,
                                                        &(iface->conn_id));
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags |= DPSW_LINKRES_CONNECTION_ALLOCATED;

                /* indicate connection has been taken */
                self->valid_fields |= LINKMAN_FIELD_CONN_ID;

                /* get accesspoint #1 */
                memset(&(ap[0]), 0x0, sizeof(struct dpmng_accesspoint));
                err = dpmng_connection_get_accesspoint(
                	dpsw->handle.dpmng, 	/* dpmng context */
                        iface->conn_id, 	/* connection id */
                        0, 			/* ap index */
                        control->committed_rate,
                        &(ap[0]));		/* ap #0 */
                CHECK_COND_RETVAL(err == 0, err);

                /* get accesspoint #2 */
                memset(&(ap[1]), 0x0, sizeof(struct dpmng_accesspoint));
                err = dpmng_connection_get_accesspoint(
                	dpsw->handle.dpmng, 	/* dpmng context */
                        iface->conn_id, 	/* connection id */
                        1, 			/* ap index */
                        control->committed_rate,
                        &(ap[1]));		/* ap #1 */
				CHECK_COND_RETVAL(err == 0, err, "ID[%d] AP connection failed for if %d\n", dpsw->id, self->if_id);

                /* decide distribute ap's */
                idx = (dpsw->ceetm_id == ap[0].ceetm_id) ? 0 : 1;

                /* Allocate CEETM channel for L2 switch */
				err = dpmng_connection_alloc_ceetm_channel(dpsw->handle.dpmng,
						channel_ids, ap[idx].dcp_id, ap[idx].ceetm_id,
						1);
				CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate ceetm channel for if %d\n", dpsw->id, self->if_id);

                /* Copy L2 switch accesspoint */
                ifpid = iface->ap.ifpid; /* save temp */
                memcpy(&(iface->ap), &(ap[idx]),
                        sizeof(struct dpmng_accesspoint));
                iface->ap.ifpid = ifpid; /* restore ifp */
				iface->ap.cqchid = channel_ids[0];
                iface->ap_valid = 1;
				iface->link_res_flags |= DPSW_LINKRES_CHANNEL_ALLOCATED;

				/* allocate LFQ for interface */
				num_lfq = 64;
				err = dpmng_connection_alloc_lfqmtidx(dpsw->handle.dpmng,
						iface->ap.lfqmtidx, iface->ap.dcp_id, iface->ap.ceetm_id, num_lfq);
				CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate %d lfq resources\n", dpsw->id, num_lfq);
				iface->link_res_flags |= DPSW_LINKRES_LFQ_ALLOCATED;
				iface->num_lfq = num_lfq;

                /* allocate CEETM channel for NIC */
				err = dpmng_connection_alloc_ceetm_channel(dpsw->handle.dpmng,
						channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id,
						peer->num_channels);
				CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate %d channels to connect if %d\n", dpsw->id, peer->num_channels, self->if_id);

                /* Copy  NIC's accesspoint */
				for( ceetm_ch_idx = 0 ; ceetm_ch_idx < peer->num_channels ; ceetm_ch_idx++ ) {
					memcpy(&(self->ap[ceetm_ch_idx]), &(ap[!idx]), sizeof(struct dpmng_accesspoint));
					self->ap[ceetm_ch_idx].cqchid = channel_ids[ceetm_ch_idx];
				}

                /* Allocate bandwidth */
                err = dpmng_connection_allocate_bandwidth(
                        dpsw->handle.dpmng,             /* Context */
                        &(iface->ap),                   /* Access point */
                        control->committed_rate);       /* Bandwidth */
				if( err ) {
					/* free resources allocated for NIC */
					err1 = dpmng_connection_free_ceetm_channel(dpsw->handle.dpmng,
						channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id,
						peer->num_channels);
					if( err1 ) pr_err("ID[%d] Fail to release %d channel resources allocated for NIC\n", dpsw->id, peer->num_channels);
				}
                CHECK_COND_RETVAL(err == 0, err, "Failed to allocate bandwith\n");
                iface->link_res_flags |= DPSW_LINKRES_ALLOC_BW;

                /* Indicate to peer */
                self->valid_fields |= LINKMAN_FIELD_AP_AVAILABLE;
                self->ap_available = 1;

                self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
                self->allocate_cr = 1;

                /* Obtain AMQ */
                memset(&amq, 0x0, sizeof(struct dpmng_amq));
                dpmng_get_amq(&amq);

                /* connect access point to ceetm */
                err = ceetm_if_connect_accesspoint(
                	iface->ceetm_if, 	/* ceetm context */
                	&(iface->ap),		/* accesspoint */
                	&amq			/* amq */
                	);
				if( err ) {
					/* free resources allocated for NIC */
					err1 = dpmng_connection_free_ceetm_channel(dpsw->handle.dpmng,
						channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id,
						peer->num_channels);
					if( err1 ) pr_err("ID[%d] Fail to release %d channel resources allocated for NIC\n", dpsw->id, peer->num_channels);
				}
				CHECK_COND_RETVAL( err == 0 , err, "ID[%d] AP configuration error\n", dpsw->id);
				iface->link_res_flags |= DPSW_LINKRES_AP_CONNECTED;

                err = if_associate_with_lni(dpsw, self->if_id, 0);
				if( err ) {
					/* free resources allocated for NIC */
					err1 = dpmng_connection_free_ceetm_channel(dpsw->handle.dpmng,
						channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id,
						peer->num_channels);
					if( err1 ) pr_err("ID[%d] Fail to release %d channel resources allocated for NIC\n", dpsw->id, peer->num_channels);
				}
				CHECK_COND_RETVAL( err == 0 , err, "ID[%d] LNI association error\n", dpsw->id);

                /* Set parser profile id */
                err = if_eiop_ifp_set_prpid(dpsw,
                                            self->if_id,
                                            dpsw->prp_virt_ing.id);
				if( err ) {
					/* free resources allocated for NIC */
					err1 = dpmng_connection_free_ceetm_channel(dpsw->handle.dpmng,
						channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id,
						peer->num_channels);
					if( err1 ) pr_err("ID[%d] Fail to release %d channel resources allocated for NIC\n", dpsw->id, peer->num_channels);
				}
				CHECK_COND_RETVAL( err == 0 , err, "ID[%d] parser profile configuration error\n", dpsw->id);

                /* Indicate to peer IFP */
                self->ifpid = iface->ap.ifpid;
                self->valid_fields |= LINKMAN_FIELD_IFPID;
        }

        peer->allocate_cr = 0;

        if ((peer->valid_fields & LINKMAN_FIELD_IFPID) != 0) {
                /* set next ifp */
        	err = if_eiop_ifp_next(dpsw, self->if_id, peer->ifpid);
        	CHECK_COND_RETVAL(err == 0, err);

                /* connect control interface */
                err = ctrl_if_connect(dpsw, self->if_id, peer->ifpid);
                CHECK_COND_RETVAL(err == 0, err);
        }
        else
                return LINKMAN_ECONT;
        
    	/* enable ifp */
        err = if_eiop_ifp_tx_enable(dpsw, self->if_id);
        CHECK_COND_RETVAL(err == 0, err);

        action->request = LINKMAN_REQUEST_COMPLETE_CB;

        return err;
}

static int virt_connection_control_integrity(struct dpsw *dpsw,
                const struct linkman_control   *control)
{
	int err = 0;

	/* Check upper bound of committed rate */
	err = dpmng_is_rate_allowed(
		dpsw->handle.dpmng,
	        control->committed_rate * MBIT_PER_SECOND);
	if (err != 1)
		return -EINVAL;

	/* Check upper bound of max rate */
	err = dpmng_is_rate_allowed(
		dpsw->handle.dpmng,
		control->max_rate * MBIT_PER_SECOND);
	if (err != 1)
		return -EINVAL;

	/* check max rate bigger than committed */
	if (control->max_rate < control->committed_rate)
		return -EINVAL;

	return 0;
}

static int is_virt_connection_shaped(
                const struct linkman_control   *control)
{
	return !((control->committed_rate == 0) && (control->max_rate == 0));
}

static int clean_fdb_entries(struct dpsw *dpsw, uint16_t if_id)
{
	struct eiop_desc eiop_desc;
	struct dpsw_fdb_unicast_cfg unicast_cfg;
	struct dpsw_fdb_multicast_cfg multicast_cfg;
	struct dpsw_fdb_unicast_cfg cfg;
	struct dpsw_fdb *fdb;
	uint16_t fdb_id;
	uint64_t rule_id;
	uint8_t mac_addr[6];
	int multicast_cnt, unicast_cnt;
	int i;
	int err;

	err = soc_db_get_desc(SOC_MODULE_EIOP, SOC_DB_NO_MATCH_FIELDS, &eiop_desc, NULL);
	CHECK_COND_RETVAL(err==0, err, "Could not obtain wriop descriptor\n");
	if( eiop_desc.wriop_version<=WRIOP_VERSION(1, 0, 0) ){
		pr_warn("Could not interrogate FDB tables for this hw platform\n");
		return -ENOSYS;
	}

	for( fdb_id = 0; fdb_id < dpsw->max_fdbs; fdb_id++) {
		err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&fdb_id, (void **)&fdb);
		if ((err != 0) || (fdb == NULL)) {
			continue;
		}

		if( !fdb->hndl ) continue;

		rule_id = 0;
		multicast_cnt = 0;
		unicast_cnt = 0;
		do {
			err = dptbl_get_next_ruleid(fdb->hndl, &rule_id);
			if( err ) {
				pr_err("No entry found for rule_id %08x%08x\n", (uint32_t)((rule_id>>32)&0xffffffff), (uint32_t)(rule_id&0xffffffff));
				break;
			}
			if( rule_id == 0 ) break;

			err = dptbl_query_with_ruleid(fdb->hndl, &rule_id, mac_addr, sizeof(mac_addr));
			if( err ) {
				pr_err("Query fail for rule_id %08x%08x\n", (uint32_t)((rule_id>>32)&0xffffffff), (uint32_t)(rule_id&0xffffffff));
				break;
			}

			rule_id++;

			if( NH_ETH_IS_BROADCAST_ADDR(mac_addr) ) {
				continue;
			}

			if( dpsw->multicast_enable && (mac_addr[0] & 0x01) ) {
				memset(&multicast_cfg, 0, sizeof(multicast_cfg));
				memcpy(multicast_cfg.mac_addr, mac_addr, sizeof(mac_addr));
				err = dpsw_fdb_get_multicast(dpsw, fdb_id, &multicast_cfg);
				if( err ) {
					pr_warn("dpsw_fdb_get_multicast() failed for %02x-%02x-%02x-%02x-%02x-%02x if: %d",
							multicast_cfg.mac_addr[0], multicast_cfg.mac_addr[1], multicast_cfg.mac_addr[2],
							multicast_cfg.mac_addr[3], multicast_cfg.mac_addr[4], multicast_cfg.mac_addr[5],
							if_id);
					continue;
				}
				for( i = 1 ; i < multicast_cfg.num_ifs ; i++ )
					if( multicast_cfg.if_id[i] == if_id ) break;
				if( i != multicast_cfg.num_ifs ) {
					multicast_cfg.num_ifs = 1;
					multicast_cfg.if_id[0] = if_id;
					err = dpsw_fdb_remove_multicast(dpsw, fdb_id, &multicast_cfg);
					if( err ) {
						pr_warn("dpsw_fdb_remove_multicast() failed for %02x-%02x-%02x-%02x-%02x-%02x if: %d",
								multicast_cfg.mac_addr[0], multicast_cfg.mac_addr[1], multicast_cfg.mac_addr[2],
								multicast_cfg.mac_addr[3], multicast_cfg.mac_addr[4], multicast_cfg.mac_addr[5],
								if_id);
						continue;
					}
					else {
						pr_debug("fdb discard %02x-%02x-%02x-%02x-%02x-%02x if: %d\n",
								multicast_cfg.mac_addr[0], multicast_cfg.mac_addr[1], multicast_cfg.mac_addr[2],
								multicast_cfg.mac_addr[3], multicast_cfg.mac_addr[4], multicast_cfg.mac_addr[5],
								if_id);
					}
					multicast_cnt++;
				}
			}
			else {
				memset(&unicast_cfg, 0, sizeof(unicast_cfg));
				memcpy(unicast_cfg.mac_addr, mac_addr, sizeof(mac_addr));
				err = dpsw_fdb_get_unicast(dpsw, fdb_id, &unicast_cfg);
				if( err ) {
					pr_warn("dpsw_fdb_get_unicast() failed for %02x-%02x-%02x-%02x-%02x-%02x if: %d\n",
							unicast_cfg.mac_addr[0], unicast_cfg.mac_addr[1], unicast_cfg.mac_addr[2],
							unicast_cfg.mac_addr[3], unicast_cfg.mac_addr[4], unicast_cfg.mac_addr[5],
							if_id);
					continue;
				}
				if( unicast_cfg.if_egress == if_id && unicast_cfg.type == DPSW_FDB_ENTRY_DINAMIC ) {
					memset(&cfg, 0, sizeof(cfg));
					memcpy(cfg.mac_addr, unicast_cfg.mac_addr, sizeof(unicast_cfg.mac_addr));
					cfg.if_egress = if_id;
					cfg.type = unicast_cfg.type;
					err = dpsw_fdb_remove_unicast(dpsw, 0, &cfg);
					if( err ) {
						pr_err("Failed to discard for %02x-%02x-%02x-%02x-%02x-%02x if: %d\n",
								unicast_cfg.mac_addr[0], unicast_cfg.mac_addr[1], unicast_cfg.mac_addr[2],
								unicast_cfg.mac_addr[3], unicast_cfg.mac_addr[4], unicast_cfg.mac_addr[5],
								if_id);
						continue;
					}
					else {
						pr_debug("fdb discard %02x-%02x-%02x-%02x-%02x-%02x if: %d\n",
								unicast_cfg.mac_addr[0], unicast_cfg.mac_addr[1], unicast_cfg.mac_addr[2],
								unicast_cfg.mac_addr[3], unicast_cfg.mac_addr[4], unicast_cfg.mac_addr[5],
								if_id);
					}
					unicast_cnt++;
				}
			}
		} while( rule_id !=0 );

		pr_info("DPSW if:%d removed %d multicast entries from FDB: %d\n", if_id, multicast_cnt, fdb_id);
		pr_info("DPSW if:%d removed %d unicast entries from FDB: %d\n", if_id, unicast_cnt, fdb_id);
	}

	return 0;
}

int event_disconnect_virt(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0, err1 = 0;
	struct dpsw_if *iface;
	uint32_t pfc_flags;

	/*! Obtain interface */
	iface = &(dpsw->iface[self->if_id]);

	if( !( self->valid_fields & LINKMAN_FIELD_LINK_CFG ) ) {
		/* copy data about link configuration in self and peer structures */
		self->fc_channel_idx = iface->fc_idx;
		self->valid_fields |= LINKMAN_FIELD_LINK_CFG;
		return LINKMAN_ECONT;
	}

	if( !( self->valid_fields & LINKMAN_FIELD_PFC_CONFIG ) ) {
		/* check flow control configuration */
		if( ( self->fc_channel_idx==FLOW_CONTROL_INVALID_INDEX && peer->fc_channel_idx!=FLOW_CONTROL_INVALID_INDEX ) ||
			( self->fc_channel_idx!=FLOW_CONTROL_INVALID_INDEX && peer->fc_channel_idx==FLOW_CONTROL_INVALID_INDEX ) )
		{
			pr_err(	"[ID%d] if%d Invalid flow control configuration ; self(%d) peer(%d); MC will set some default values to continue... "
					"Future flow control configuration may fail\n", dpsw->id, self->if_id, self->fc_channel_idx, peer->fc_channel_idx);
			self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
			iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
		}
		self->valid_fields |= LINKMAN_FIELD_PFC_CONFIG;
		return LINKMAN_ECONT;
	}

	if( self->fc_channel_idx == FLOW_CONTROL_INVALID_INDEX ) {
		/* Flow control not enabled, perform flag exchange*/
		if( !self->fc_disabled ) {
			self->fc_disabled = 1;
		}
		if( !peer->fc_disabled ) {
			return LINKMAN_ECONT;
		}
	}
	else if( iface->fc_idx != FLOW_CONTROL_INVALID_INDEX ) {
		/* flow control is enabled */
		if( !self->fc_disabled ) {
			/* disable flow control settings */
			pfc_flags = DPSW_UPDATE_FC;
			dpsw_if_update_bp_config(dpsw, self->if_id, pfc_flags);
			dpsw_if_update_channel_fc(dpsw, self->if_id, pfc_flags);
			self->fc_disabled = 1;
		}
		if( !peer->fc_disabled ) {
			/* wait for peer to disable flow control settings */
			return LINKMAN_ECONT;
		}
		if( peer->fc_channel_idx != FLOW_CONTROL_INVALID_INDEX ) {
			/* flow control channel index not released by peer */
			if( self->fc_channel_idx != FLOW_CONTROL_INVALID_INDEX ) {
				/* release flow control */
				fc_release_channel_idx(iface->fc_idx);
				iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
				self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
				return LINKMAN_ECONT;
			}
		}
		else {
			/* flow control channel index released by peer */
			iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
			self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
		}
	}

        err = if_eiop_ifp_disable(dpsw, self->if_id);

        remove_if_from_replic_broadcast(dpsw, self->if_id);
        remove_if_from_replic_flooding(dpsw, self->if_id);

        /* Mark that the if has been removed from replicator */
        dpsw->iface[self->if_id].linkup_replic_updated = 0;

        err = clean_fdb_entries(dpsw, self->if_id);
        if( err ) {
			pr_warn("DPSW[%d]: Could not clean FDB tables on disconnect interface %d\n"
					"Entries remaining in FDB may route packets to this port causing error events\n",
					dpsw->id, self->if_id);
			/* continue */
        }

        if (((self->valid_fields & LINKMAN_FIELD_FREE_CONN_ID) == 0)) {

			if( iface->link_res_flags & DPSW_LINKRES_ALLOC_BW ) {
                /* free bandwidth */
                err = dpmng_connection_free_bandwidth(
                        dpsw->handle.dpmng,             /* Context */
                        &(iface->ap)                    /* access point */
                        );
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags &= (~DPSW_LINKRES_ALLOC_BW);
            }

			if( iface->link_res_flags & DPSW_LINKRES_AP_CONNECTED ) {
                /* disconnect accesspoint from ceetm interface */
                err = ceetm_if_disconnect_accesspoint(
                	iface->ceetm_if,		/* CEETM Interface */
                	&(iface->ap));			/* accesspoint */
				CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to disconnect AP for if %d\n", dpsw->id, self->if_id);
				iface->link_res_flags &= (~DPSW_LINKRES_AP_CONNECTED);
			}

                /*! free virtual connection */
            if( iface->link_res_flags & DPSW_LINKRES_CONNECTION_ALLOCATED ) {
				/* disconnect control interface */
				err = ctrl_if_disconnect(dpsw, self->if_id);
				CHECK_COND_RETVAL(err == 0, err, "ID[%d] ctrl if disconnect returned error for interface %d", dpsw->id, self->if_id);

				if( iface->link_res_flags & DPSW_LINKRES_CHANNEL_ALLOCATED ) {
					err1 = dpmng_connection_free_ceetm_channel(dpsw->handle.dpmng,
							&iface->ap.cqchid, iface->ap.dcp_id, iface->ap.ceetm_id,
							1);
					if( err1 ) pr_err("ID[%d] Failed to release 1 channel resource with id %d\n", dpsw->id, iface->ap.cqchid);
					iface->link_res_flags &= (~DPSW_LINKRES_CHANNEL_ALLOCATED);
				}

				if( iface->link_res_flags & DPSW_LINKRES_LFQ_ALLOCATED ) {
						err = dpmng_connection_free_lfqmtidx(dpsw->handle.dpmng,
								iface->ap.lfqmtidx, iface->ap.dcp_id, iface->ap.ceetm_id, iface->num_lfq);
					if( err1 ) pr_err("ID[%d] Failed to release 1 channel resource with id %d\n", dpsw->id, iface->ap.cqchid);
					iface->link_res_flags &= (~DPSW_LINKRES_LFQ_ALLOCATED);
					iface->num_lfq = 0;
				}

				err = dpmng_connection_free(dpsw->handle.dpmng, /*! Context */
                                                iface->conn_id); /*! connection id */
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags &= (~DPSW_LINKRES_CONNECTION_ALLOCATED);
            }
                /*! indicate virtual connection field in valid fields */
                self->valid_fields |= LINKMAN_FIELD_FREE_CONN_ID;

                /* for computability with DMux */
                self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
                self->allocate_cr = 1;
        }

        action->request = LINKMAN_REQUEST_COMPLETE_CB;

        return err;
}

static int virt_link_rates(
        const struct linkman_endpoint   *ep1,
        const struct linkman_endpoint   *ep2,
        const struct linkman_control   *control,
        struct linkman_link_state       *link_state,
        uint32_t *max_rate)
{
        int err = 0;
        int shaped;

        shaped = is_virt_connection_shaped(control);
        if (shaped == 1) {
                /* Calculate link state */
                err = link_state_common_denominator(
                        ep1, ep2,
                        control->committed_rate,
                        link_state);
                CHECK_COND_RETVAL(err == 0, err, "link_state_common_denominator() failed" );

                *max_rate = (link_state->options & LINKMAN_LINK_OPT_AUTONEG) ?
                        control->max_rate : link_state->rate;
        }
        else {
                link_state->rate = 0;
                link_state->options = 0;
                *max_rate = (uint32_t)soc_db_get_recycle_port_bandwidth();
        }

        return err;
}

int event_linkup_virt(struct dpsw               *dpsw,
                struct linkman_endpoint        *self,
                const struct linkman_endpoint  *peer,
                const struct linkman_control   *control,
                struct linkman_action          *action)
{
        int err = LINKMAN_ECONT;
        struct dpsw_if  *iface;
        uint32_t        max_rate;
        struct linkman_link_state       link_state = {0};
        uint64_t		options;
        int ch_idx;
        uint32_t pfc_flags;

        iface = &(dpsw->iface[self->if_id]);

        /* Verify device state is valid */
        CHECK_COND_RETVAL(iface->enabled, -EACCES); /* invalid device state */

        /* Advertise capabilities */
        self->rate = iface->link_cfg.rate;
        if( !(self->valid_fields & LINKMAN_FIELD_LINK_CFG) ) {
        	if( iface->link_cfg.options & DPSW_LINK_OPT_AUTONEG )
        		self->options |= LINKMAN_LINK_OPT_AUTONEG;
        	if( iface->link_cfg.options & DPSW_LINK_OPT_ASYM_PAUSE )
        		self->options |= LINKMAN_LINK_OPT_ASYM_PAUSE;
        	if( iface->link_cfg.options & DPSW_LINK_OPT_PAUSE )
        		self->options |= LINKMAN_LINK_OPT_PAUSE;
        	self->valid_fields |= LINKMAN_FIELD_LINK_CFG;
        }

	if( self->options & LINKMAN_LINK_OPT_ASYM_PAUSE ) {
		/* LINK_OPT_ASYM_PAUSE pause not supported at all, so it must be cleared */
		self->options &= ~(LINKMAN_LINK_OPT_PAUSE | LINKMAN_LINK_OPT_ASYM_PAUSE);
		pr_warn("ID[%d]: LINK_OPT_ASYM_PAUSE combinations not supported for virtual connections... clear and continue", dpsw->id);
		return LINKMAN_ECONT;
	}

	/* wait capabilities from peer */
	if ( !(peer->valid_fields & LINKMAN_FIELD_LINK_CFG) ) {
		return LINKMAN_ECONT;
	}

	/*  check compatible options from peer */
	options = self->options & peer->options;
	if( options != self->options ) {
		if( !(options & LINKMAN_LINK_OPT_PAUSE) && (self->options & LINKMAN_LINK_OPT_PAUSE) ) {
			pr_warn("ID[%d] dpsw: LINKMAN_LINK_OPT_PFC_PAUSE not supported on remote\n", dpsw->id);
		}
	}

	/* Do not remove AUTONEG flag if peer is not configured with AUTONEG capability */
	self->options = options | (self->options & LINKMAN_LINK_OPT_AUTONEG);

	if( self->options & LINKMAN_LINK_OPT_PAUSE ) {
		if( peer->fc_available ) {
			/* channel index allocated by peer */
			iface->fc_idx = peer->fc_channel_idx;
			self->fc_channel_idx = peer->fc_channel_idx;
			self->fc_available = 1;
		}
		else if( iface->fc_idx == FLOW_CONTROL_INVALID_INDEX ) {
			/* first time here, need to get a new channel index*/
			ch_idx = fc_get_next_channel_idx();
			if( ch_idx < 0 ) {
				/* no channel index available */
				self->options &= ~LINKMAN_LINK_OPT_PAUSE;
				pr_err("[ID%d] No channels available to implement flow control for if %d; clear PAUSE flag\n", dpsw->id, self->if_id);
				return LINKMAN_ECONT;	// execute again for peer
			} else {
				/* channel index allocation ok */
				self->fc_channel_idx = ch_idx;
				self->fc_available = 1;
				iface->fc_idx = self->fc_channel_idx;
				return LINKMAN_ECONT;	// execute again to pass same setting to peer
			}
		}
		else {
			/* channel index allocated on a previous call */
			self->fc_channel_idx = iface->fc_idx;
			self->fc_available = 1;
			return LINKMAN_ECONT;
		}

		pfc_flags = DPSW_UPDATE_FC | DPSW_ENABLE_FC_SENDING | DPSW_ENABLE_FC_RESPONSE;
		dpsw_if_update_pfc_settings(dpsw, self->if_id, pfc_flags);
	}
	else {
		/* pause not enabled */
		if( iface->fc_idx != FLOW_CONTROL_INVALID_INDEX ) {
			/* pause was previously enabled 
			 * disable current settings and free flow control resource */
			if( !self->fc_available ) {
				pfc_flags = DPSW_UPDATE_FC;
				dpsw_if_update_pfc_settings(dpsw, self->if_id, pfc_flags);
				self->fc_available = 1;
			}

			/* wait for peer to disable FC*/
			if( !peer->fc_available ) {
				return LINKMAN_ECONT;
			}

			/* if peer does not free the resources */
			if( peer->fc_channel_idx != -1 ) {
				fc_release_channel_idx(iface->fc_idx);
			}

			/* clear data */
			iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
			self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
		}
	}

        /* Is peer capabilities available? */
        if ((peer->valid_fields & LINKMAN_FIELD_LINK_CFG) != 0) {

                /* Obtain committed and maximum rates */
                err = virt_link_rates(
                        self,
                        peer,
                        control,
                        &link_state,
                        &max_rate);
                CHECK_COND_RETVAL(err == 0, err, "virt_link_rates() failed" );

                /* Configure channel scheduler */
                err = ceetm_if_set_transmit_rate(
                	iface->ceetm_if, 	/* Context */
                	link_state.rate, 	/* committed rate */
                	max_rate);		/* maximum rate */
                CHECK_COND_RETVAL(err == 0, err, "ceetm_if_set_transmit_rate() failed" );

                if (max_rate == 0 && link_state.rate == 0)
                	err = if_associate_with_lni(dpsw, self->if_id, 0);
                else
                	err = if_associate_with_lni(dpsw, self->if_id, 1);
                CHECK_COND_RETVAL(err == 0, err, "if_associate_with_lni() failed");

                /* enable ifp */
                err = if_eiop_ifp_rx_enable(dpsw, self->if_id);
                CHECK_COND_RETVAL(err == 0, err, "if_eiop_ifp_rx_enable() failed" );
                err = if_eiop_ifp_tx_enable(dpsw, self->if_id);
                CHECK_COND_RETVAL(err == 0, err, "if_eiop_ifp_tx_enable() failed" );

                /* Enable control interface */
                err = ctrl_if_linkup(dpsw, self->if_id);
                CHECK_COND_RETVAL(err == 0, err, "ctrl_if_linkup() failed" );

                /* Indicate to link manager to save link state */
                link_state.options = self->options;
                memcpy(&(action->state),
                        &link_state, sizeof(struct linkman_link_state));

                /* Request for completion notification */
                action->request = LINKMAN_REQUEST_COMPLETE_CB;
        }
        
        return err;
}

int event_linkdown_virt(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err;

	remove_if_from_replic_broadcast(dpsw, self->if_id);
	remove_if_from_replic_flooding(dpsw, self->if_id);

	/* Mark that the if has been removed from replicator */
	dpsw->iface[self->if_id].linkup_replic_updated = 0;

        /* Disable IFP */
        err = if_eiop_ifp_disable(dpsw, self->if_id);
        CHECK_COND_RETVAL(err == 0, err);

        /* Disable control interface */
        err = ctrl_if_linkdown(dpsw, self->if_id);
        CHECK_COND_RETVAL(err == 0, err);


        /* Request for completion notification */
        action->request = LINKMAN_REQUEST_COMPLETE_CB;

	return err;
}

/* physical events */
int event_connect_phys(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
        int 			err = 0;
        struct dpsw_if 		*iface;
        struct dpmng_amq  	amq;
        int num_lfq;

        /* Obtain interface */
        iface = &(dpsw->iface[self->if_id]);

        /* get connection id */
        err = dpmng_connection_phys_allocate(
        	dpsw->handle.dpmng, 		/* dpmng context */
                peer->id, 			/* mac id */
                &(iface->conn_id)); 		/* connection id */
        CHECK_COND_RETVAL(err == 0, err);
        iface->link_res_flags |= DPSW_LINKRES_CONNECTION_ALLOCATED;

        /* Get access-point from dpmng */
        self->ifpid = iface->ap.ifpid;
        memset(&(iface->ap), 0x0, sizeof(struct dpmng_accesspoint));
        err = dpmng_connection_get_accesspoint(
        	dpsw->handle.dpmng, 		/* dpmng context */
                iface->conn_id, 		/* connection id */
                0, 				/* not used */
                0, 				/* not used */
                &(iface->ap));
        CHECK_COND_RETVAL(err == 0, err);

		err = dpmng_connection_alloc_ceetm_channel(dpsw->handle.dpmng,
				&iface->ap.cqchid, iface->ap.dcp_id, iface->ap.ceetm_id,
				1);
        CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to allocate ceetm channel", dpsw->id);
        iface->link_res_flags |= DPSW_LINKRES_CHANNEL_ALLOCATED;

		/* allocate LFQ for interface */
		num_lfq = 64;
		err = dpmng_connection_alloc_lfqmtidx(dpsw->handle.dpmng,
				iface->ap.lfqmtidx, iface->ap.dcp_id, iface->ap.ceetm_id, num_lfq);
		CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate %d lfq resources\n", dpsw->id, num_lfq);
		iface->link_res_flags |= DPSW_LINKRES_LFQ_ALLOCATED;
		iface->num_lfq = num_lfq;

        /* restore ifp */
        iface->ap.ifpid = self->ifpid;
        iface->ap_valid = 1;

        /* Obtain AMQ */
        memset(&amq, 0x0, sizeof(struct dpmng_amq));
        dpmng_get_amq(&amq);

        /* connect access point */
        err = ceetm_if_connect_accesspoint(
        	iface->ceetm_if,
        	&(iface->ap),
        	&amq);
        CHECK_COND_RETVAL(err == 0, err, "ID[%d] AP connection failed for if %d\n", dpsw->id, self->if_id);
        iface->link_res_flags |= DPSW_LINKRES_AP_CONNECTED;

        /* associate with lni */
        err = if_associate_with_lni(dpsw, self->if_id, 0);
        CHECK_COND_RETVAL(err == 0, err);

        /* Set parser profile id */
        err = if_eiop_ifp_set_prpid(dpsw, self->if_id, dpsw->prp_phys_ing.id);
        CHECK_COND_RETVAL(err == 0, err);

        /* connect control interface */
        err = ctrl_if_connect(dpsw, self->if_id, 0/* not used */);
        CHECK_COND_RETVAL(err == 0, err);

        /* Indicate to peer IFP */
        self->ifpid = iface->ap.ifpid;
        self->valid_fields |= LINKMAN_FIELD_IFPID;
        
        /* enable ifp */
        err = if_eiop_ifp_tx_enable(dpsw, self->if_id);
        CHECK_COND_RETVAL(err == 0, err);

        iface->dpmac = sys_get_handle(FSL_MOD_DPMAC, 1, peer->id);

        action->request = LINKMAN_REQUEST_COMPLETE_CB;

        return err;
}

static int dpsw_empty_all_frames(struct dpsw *dpsw, const struct linkman_endpoint  *peer)
{
	int en, err=0, tries = 50;
	struct dpmac *dpmac;
	uint64_t counter = 0, counter_new = 0;
	uint16_t fdb_id, if_id;
	struct dpsw_fdb_attr fdb_attr = {0};
	enum dpsw_learning_mode fdb_learn_mode[DPSW_MAX_FDB];
	enum dpsw_learning_mode if_learn_mode[DPSW_MAX_IF];
	int fdb_learn_changed[DPSW_MAX_FDB];
	int if_learn_changed[DPSW_MAX_IF];
	struct dpsw_if *iface;

	dpmac = sys_get_handle(FSL_MOD_DPMAC, 1, peer->id);
	CHECK_COND_RETVAL( dpmac!=NULL, -ENOENT, "Could not access mac id: %d\n", peer->id);

	memset(fdb_learn_mode, 0, sizeof(fdb_learn_mode));
	memset(fdb_learn_changed, 0, sizeof(fdb_learn_mode));
	memset(if_learn_changed, 0, sizeof(if_learn_changed));
	memset(if_learn_mode, 0, sizeof(if_learn_mode));

	/* disable automatic learning so that eventual frames received when MAC is in loopback
	 * will not add entries in FDB */
	for( fdb_id  = 0 ; fdb_id < dpsw->max_fdbs ; fdb_id++ ) {
		err = dpsw_fdb_get_attributes(dpsw, fdb_id, &fdb_attr);
		if( err ) /* FDB not configured */
			continue;

		if( fdb_attr.learning_mode == DPSW_LEARNING_MODE_DIS )
			continue;

		fdb_learn_mode[fdb_id] = fdb_attr.learning_mode;
		fdb_learn_changed[fdb_id] = 1;

		err = dpsw_fdb_set_learning_mode(dpsw, fdb_id, DPSW_LEARNING_MODE_DIS);
		if( err ) pr_err("Failed to change learning mode for fdb_id: %d\n", fdb_id);
	}
	for (if_id = 0; if_id < dpsw->num_ifs; if_id++) {
		iface = &(dpsw->iface[if_id]);
		if (!iface->learning_requested)
			continue;

		if_learn_mode[if_id] = iface->learning_mode;
		if_learn_changed[if_id] = 1;

		err = dpsw_if_set_learning_mode(dpsw, if_id, DPSW_LEARNING_MODE_DIS);
		if (err) pr_err("Failed to change learning mode for if_id :%d\n", if_id);
	}

	dpmac_is_enabled(dpmac, &en);

	err = dpmac_set_loopback(dpmac, 1);

	if (!en)
		dpmac_enable(dpmac);

	do{
		counter = counter_new;
		timer_udelay(1);
		dpmac_get_counter (dpmac, DPMAC_CNT_EGR_GOOD_FRAME, &counter_new);
		
	} while ((counter != counter_new) && --tries);

	if (!tries )
	{
		pr_err("DPSW failed to clear all frames from tx\n");
	}

	if (!en)
		err = dpmac_disable(dpmac);

	err = dpmac_set_loopback(dpmac, 0);

	/* restore previous learning mode */
	for( fdb_id  = 0 ; fdb_id < dpsw->max_fdbs ; fdb_id++ ) {
		if( !fdb_learn_changed[fdb_id] ) continue;

		fdb_learn_mode[fdb_id] = fdb_attr.learning_mode;

		err = dpsw_fdb_set_learning_mode(dpsw, fdb_id, fdb_learn_mode[fdb_id]);
		if( err ) pr_err("Failed to change learning mode for fdb_id: %d\n", fdb_id);
	}
	for (if_id = 0; if_id < dpsw->num_ifs; if_id++) {
		iface = &(dpsw->iface[if_id]);
		if (!if_learn_changed[if_id])
			continue;
		err = dpsw_if_set_learning_mode(dpsw, if_id, if_learn_mode[if_id]);
		if (err) pr_err("Failed to change learning mode for if_id :%d\n", if_id);
	}

	return err;
}

int event_disconnect_phys(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
        int err = 0;
        struct dpsw_if *iface;
        struct eiop_ifp_desc eiop_ifp_desc;
        uint32_t pfc_flags;
        
        /* Obtain interface */
        iface = &(dpsw->iface[self->if_id]);

        remove_if_from_replic_broadcast(dpsw, self->if_id);
        remove_if_from_replic_flooding(dpsw, self->if_id);

        /* Mark that the if has been removed from replicator */
        dpsw->iface[self->if_id].linkup_replic_updated = 0;

		err = clean_fdb_entries(dpsw, self->if_id);
		if( err ) {
				pr_warn("DPSW[%d]: Could not clean FDB tables on disconnect interface %d\n"
					"Entries remaining in FDB may route packets to this port causing error events\n",
					dpsw->id, self->if_id);
				/* continue */
	    }

        /* clear flow control configuration for buffer pool */
		pfc_flags = DPSW_UPDATE_FC;
		dpsw_if_update_bp_config(dpsw, self->if_id, pfc_flags);

        eiop_ifp_desc.ifp_id = iface->ap.ifpid;
        eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* WRIOP ID */
        
    	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
    				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
    				&eiop_ifp_desc, /* descriptor */
    				NULL); /* iterator */
    	CHECK_COND_RETVAL(err == 0, err);
 
		err = dpsw_empty_all_frames(dpsw, peer);
		if( err )
			pr_err("Could not empty all frames on disconnect\n");
        
    	/* Stop TX*/
    	err = eiop_ifp_tx_graceful_stop(&eiop_ifp_desc);
    	CHECK_COND_RETVAL(err == 0, err);

    	self->valid_fields |= LINKMAN_FIELD_CLEAR_TX_FRAMES;

        if (((self->valid_fields & LINKMAN_FIELD_FREE_CONN_ID) == 0)) {
            /* free virtual connection */

			if( iface->link_res_flags & DPSW_LINKRES_CONNECTION_ALLOCATED ) {
				if( iface->link_res_flags & DPSW_LINKRES_AP_CONNECTED ) {
					err = ceetm_if_disconnect_accesspoint(
							iface->ceetm_if,	/* CEETM context */
							&(iface->ap));		/* accesspoint */
					CHECK_COND_RETVAL(err == 0, err);
					iface->link_res_flags &= (~DPSW_LINKRES_AP_CONNECTED);
				}
				iface->ap_valid = 0;

				if( iface->link_res_flags & DPSW_LINKRES_CHANNEL_ALLOCATED ) {
					err = dpmng_connection_free_ceetm_channel(dpsw->handle.dpmng,
							&iface->ap.cqchid, iface->ap.dcp_id, iface->ap.ceetm_id, 1);
					if( err ) pr_err("ID[%d] Failed to release 1 channel resource with id %d\n", dpsw->id, iface->ap.cqchid);
					iface->link_res_flags &= (~DPSW_LINKRES_CHANNEL_ALLOCATED);
				}

				if( iface->link_res_flags & DPSW_LINKRES_LFQ_ALLOCATED ) {
					err = dpmng_connection_free_lfqmtidx(dpsw->handle.dpmng,
							iface->ap.lfqmtidx, iface->ap.dcp_id, iface->ap.ceetm_id, iface->num_lfq);
					if( err ) pr_err("ID[%d] Failed to release 1 channel resource with id %d\n", dpsw->id, iface->ap.cqchid);
					iface->link_res_flags &= (~DPSW_LINKRES_LFQ_ALLOCATED);
					iface->num_lfq = 0;
				}

                err = dpmng_connection_free(
                	dpsw->handle.dpmng, 	/* Context */
                        iface->conn_id); 	/* connection id */
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags &= (~DPSW_LINKRES_CONNECTION_ALLOCATED);
            }

                /* disconnect control interface */
                err = ctrl_if_disconnect(dpsw, self->if_id);
                CHECK_COND_RETVAL(err == 0, err);

                /* indicate virtual connection field in valid fields */
                self->valid_fields |= LINKMAN_FIELD_FREE_CONN_ID;
        }

        iface->dpmac = NULL;

        action->request = LINKMAN_REQUEST_COMPLETE_CB;

        return err;
}

int event_linkup_phys(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0;
	struct dpsw_if *iface;
	uint32_t pfc_flags;

	iface = &(dpsw->iface[self->if_id]);

	/* Is end-point enabled? */
	CHECK_COND_RETVAL(iface->enabled, -EACCES);

	if( !(self->valid_fields & LINKMAN_FIELD_LINK_CFG) ) {
		self->valid_fields = LINKMAN_FIELD_LINK_CFG;

		/* Provide Line configuration */
		if( iface->link_cfg.options & DPSW_LINK_OPT_AUTONEG )
			self->options |= DPSW_LINK_OPT_AUTONEG;
		if( iface->link_cfg.options & DPSW_LINK_OPT_PAUSE )
			self->options |= LINKMAN_LINK_OPT_PAUSE;
		if( iface->link_cfg.options & DPSW_LINK_OPT_ASYM_PAUSE )
			self->options |= LINKMAN_LINK_OPT_ASYM_PAUSE;

		self->rate = iface->link_cfg.rate;

		return LINKMAN_ECONT;
	}

	if( self->options & LINKMAN_LINK_OPT_PAUSE ) {
		pfc_flags = DPSW_UPDATE_FC | DPSW_ENABLE_FC_SENDING | DPSW_ENABLE_FC_RESPONSE;
		dpsw_if_update_bp_config(dpsw, self->if_id, pfc_flags);
	}
	else {
		pfc_flags = DPSW_UPDATE_FC;
		dpsw_if_update_bp_config(dpsw, self->if_id, pfc_flags);
	}
	self->ep_enabled = iface->enabled;
	self->valid_fields |= LINKMAN_FIELD_LINK_STATE;

	/* Link state valid? */
	if ((peer->valid_fields & LINKMAN_FIELD_LINK_STATE) == 0)
		return LINKMAN_ECONT;

	/* Link state available */
	if (peer->link_state_available == 0)
		return 0;

	err = event_negotiation_ok(dpsw, self, peer, action);

	return err;
}

int event_linkdown_phys(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
/*
 *      -Verify parameters
 *      -Check MAC disabled RX
 *      -RX graceful stop
 *      -check link is external
 *              -set loopback
 *
 *      -eiop_ifp_tx_graceful_stop
 *
 *
 *      -remove loopback
 * */

	int err = -ENOTSUP; /* Operation not supported */
	struct dpsw_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	remove_if_from_replic_broadcast(dpsw, self->if_id);
	remove_if_from_replic_flooding(dpsw, self->if_id);

	/* Mark that the if has been removed from replicator */
	dpsw->iface[self->if_id].linkup_replic_updated = 0;

	/* Check MAC disabled RX */
	if (!(peer->valid_fields & LINKMAN_FIELD_DPMAC_RX_DIS))
		return LINKMAN_ECONT;

	/* Obtain ifp descriptor */
	iface = &(dpsw->iface[self->if_id]);

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* WRIOP ID */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);

	/* RX graceful stop */
	err = eiop_ifp_rx_graceful_stop(&eiop_ifp_desc);
	CHECK_COND_RETVAL(err == 0, err);


    /* Disable control interface */
    err = ctrl_if_linkdown(dpsw, self->if_id);
    CHECK_COND_RETVAL(err == 0, err);

	/* require completion notification */
	action->request = LINKMAN_REQUEST_COMPLETE_CB;

	return err;
}

int event_negotiation_ok(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0;

        /* enable ifp */
        err = if_eiop_ifp_rx_enable(dpsw, self->if_id);
        CHECK_COND_RETVAL(err == 0, err);

        /* Enable control interface */
        err = ctrl_if_linkup(dpsw, self->if_id);
        CHECK_COND_RETVAL(err == 0, err);

        /* Indicate to lnik manager to save link state */
        action->state.rate = peer->rate;
        action->state.options = peer->options;

        /* Require completion notification */
        action->request = LINKMAN_REQUEST_COMPLETE_CB;
	return err;
}

int event_negotiation_fail(struct dpsw 		*dpsw,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	return 0;
}

int dpsw_if_set_tx_selection(struct dpsw *dpsw, uint16_t if_id,
	struct dpsw_tx_selection_cfg *ts)
{
	/*
	*       - Verify parameters integrity
	*       - Save priority_selector
	*       - Update VLAN table to align priority_selector
	*       - set_tx_selection -> int ceetm_if_ccqs_configure()
	*/
	int err = 0;
	struct dpsw_if *iface;

	/* Obtain interface */
	iface = &(dpsw->iface[if_id]);

        /* Verify parameters integrity */
        err = if_set_tx_selection_params_integrity(dpsw, if_id, ts);
        CHECK_COND_RETVAL(err == 0, err);

        if (iface->priority_selector != ts->priority_selector &&
        	ts->priority_selector != DPSW_PRIORITY_SELECTOR_NO_CHANGE) {

                /* Save priority_selector */
        	iface->priority_selector = ts->priority_selector;

        	/*Update VLAN table to align priority_selector*/
        	err = vlan_tbl_if_update(dpsw, if_id);
        	CHECK_COND_RETVAL(err == 0, err);
        }

        /* update ceetm if */
        err = if_set_tx_selection(dpsw, if_id, ts);

        return err;
}

static int if_set_tx_selection(
	struct dpsw *dpsw,
	uint16_t if_id,
	const struct dpsw_tx_selection_cfg *ts)
{
/*
 * 	obtain interface
 * 	build configuration
 * 	ceetm_if_ccqs_configure()
 * */

	int 				err = 0, i, ccqidx;
	struct dpsw_if 			*iface;
	struct ceetm_if_ccqs_cfg 	ccqs;
	uint8_t pps = QBMAN_PFDR_POOL_BASE;	// PFDR pool select
	struct qbman_desc qbman_desc;
	int iter = 0, ps = 0;

	ps = qbman_cacheable_pfdr();

	/* obtain interface */
	iface = &(dpsw->iface[if_id]);

	memset(&ccqs, 0x0, sizeof(struct ceetm_if_ccqs_cfg));

	memset(&qbman_desc, 0, sizeof(qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, &iter);
	if (err) {
		pr_err("Could not obtain QBMAN descriptor\n");
		return err;
	}
	if( qbman_desc.multiple_pfdr_support ) {
		pps = QBMAN_PFDR_POOL_PEB;
		ps = !pps;
	}

	for(i = 0; i < DPSW_MAX_PRIORITIES; i++) {
		/* User priority to traffic class mapping */
		ccqidx = ccqs.ccqidx[i] = ts->tc_id[i];

		/* traffic class configuration */
		ccqs.ccq[ccqidx].ccgidx = (uint8_t)ccqidx;	/* congestion group */
		ccqs.ccq[ccqidx].delta_bandwidth =
			ts->tc_sched[ccqidx].delta_bandwidth;
		ccqs.ccq[ccqidx].pps = pps;
		ccqs.ccq[ccqidx].ps = ps;
		ccqs.ccq[ccqidx].mode =
			get_schedule_mode(ts->tc_sched[ccqidx].mode);
	}

	/* configure ceetm interface */
	err = ceetm_if_ccqs_configure(iface->ceetm_if, &ccqs);

	return err;
}

static int if_set_tx_selection_params_integrity(
	struct dpsw *dpsw,
	uint16_t if_id,
        const struct dpsw_tx_selection_cfg *ts)
{
        int err = 0, i;
        uint8_t	tc_id;

        if (if_id >= dpsw->num_ifs)
                return -EINVAL;

        for (i = 0; i < DPSW_MAX_PRIORITIES; i++) {
        	/* obtain traffic class */
        	tc_id = ts->tc_id[i];

        	/* traffic class is in range */
                if (tc_id >= DPSW_MAX_TC)
                        return -EINVAL;

                if (ts->tc_sched[tc_id].mode == DPSW_SCHED_STRICT_PRIORITY)
                	continue;

                /* Check lower bound */
		if (ts->tc_sched[tc_id].delta_bandwidth < SCHEDULER_LOWER_BOUND)
			return -EINVAL;

		/* */
		if (ts->tc_sched[tc_id].delta_bandwidth > SCHEDULER_UPPER_BOUND)
			return -EINVAL;
        }
	return err;
}

int dpsw_if_set_prio_selector(struct dpsw *dpsw, uint16_t if_id,
	struct dpsw_prio_selector_cfg *ps)
{
	int err = 0;
	struct dpsw_if *iface;

	/* Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/* Verify parameters integrity */
	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	if (iface->priority_selector != ps->priority_selector &&
		ps->priority_selector != DPSW_PRIORITY_SELECTOR_NO_CHANGE) {
		/* Save priority_selector */
		iface->priority_selector = ps->priority_selector;

		/*Update VLAN table to align priority_selector*/
		err = vlan_tbl_if_update(dpsw, if_id);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return err;
}

static int is_if_link_up(struct dpsw *dpsw, uint16_t if_id, int *link_up)
{
	int err = 0;
	struct linkman_endpoint	ep1, ep2;
	struct linkman_connection_attr	attr;

	/*! Obtain link */
	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	ep1.type = FSL_MOD_DPSW;
	ep1.id = (uint16_t)dpsw->id;
	ep1.if_id = if_id;

	/* get connection attributes*/
	err = linkman_get_connection(dpsw->handle.linkman, &ep1, &ep2, &attr);
	CHECK_COND_RETVAL(err == 0, err);

	*link_up = (attr.state == LINKMAN_STATE_LINKUP) ? 1 : 0;

	return err;
}

int dpsw_ctrl_if_get_attributes(struct dpsw *dpsw,
	struct dpsw_ctrl_if_attr *attr)
{
	int err = 0;
	struct ctrl_if_attr 	rx_attr, tx_attr;

	memset(attr, 0xFF, sizeof(struct dpsw_ctrl_if_attr));

	if (dpsw->ctrl_if_enable == 0)
		return err;

	/* Obtain receive attributes */
	err = ctrl_if_get_rx_flow_attr(dpsw->ctrl_if, 0, &rx_attr);
	CHECK_COND_RETVAL(err == 0, err);

	attr->rx_err_fqid = (uint32_t) rx_attr.virt_err_fqid;
	attr->rx_fqid = (uint32_t) rx_attr.virt_fqid;

	/* Obtain transmit attributes */
	err = ctrl_if_get_tx_if_id_attr(dpsw->ctrl_if, 0, &tx_attr);
	CHECK_COND_RETVAL(err == 0, err);

	attr->tx_err_conf_fqid = (uint32_t)tx_attr.virt_err_fqid;

	return err;
}

int dpsw_ctrl_if_set_pools(struct dpsw *dpsw,
	const struct dpsw_ctrl_if_pools_cfg *dpsw_pools)
{
	int err = 0, i;
	struct ctrl_if_pools_cfg	ctrl_pools;

	CHECK_COND_RETVAL(dpsw->ctrl_if_enable, -EACCES);

	memset(&ctrl_pools, 0x0, sizeof(struct ctrl_if_pools_cfg));

	/* number of buffer pools */
	ctrl_pools.num_dpbp = dpsw_pools->num_dpbp;

	/* Init buffer pool one by one */
	for (i = 0; i < ctrl_pools.num_dpbp; i++) {
		/* Backup pool */
		ctrl_pools.pools[i].backup_pool =
			dpsw_pools->pools[i].backup_pool;

		/* Buffer size */
		ctrl_pools.pools[i].buffer_size =
			dpsw_pools->pools[i].buffer_size;

		/* Buffer pool id */
		ctrl_pools.pools[i].dpbp_id = dpsw_pools->pools[i].dpbp_id;
 	}

	err = ctrl_if_set_pools(dpsw->ctrl_if, &ctrl_pools);

	return err;
}

int dpsw_ctrl_if_set_queue(struct dpsw *dpsw,
	enum dpsw_queue_type qtype,
	const struct dpsw_ctrl_if_queue_cfg *dpsw_queue_cfg)
{
	struct ctrl_if_queue_cfg queue_cfg;

	CHECK_COND_RETVAL(IN_RANGE(DPSW_QUEUE_RX, qtype, DPSW_QUEUE_RX_ERR),
			-ENOTSUP,
			"unexpected QUEUE_TYPE value %d, expected <= %d\n",
			(int)DPSW_QUEUE_RX_ERR);

	memset(&queue_cfg, 0x0, sizeof(struct ctrl_if_queue_cfg));

	queue_cfg.options = dpsw_queue_cfg->options;
	queue_cfg.dest_cfg.dest_type = (enum ctrl_if_dest) dpsw_queue_cfg->dest_cfg.dest_type;
	queue_cfg.dest_cfg.dest_id = dpsw_queue_cfg->dest_cfg.dest_id;
	queue_cfg.dest_cfg.priority = dpsw_queue_cfg->dest_cfg.priority;
	queue_cfg.user_ctx = dpsw_queue_cfg->user_ctx;

	switch (qtype) {
	case DPSW_QUEUE_RX:
		/* There is only one RX queue, it's ok to just pass 0 as the index queue */
		return ctrl_if_set_rx_flow(dpsw->ctrl_if, 0, &queue_cfg);
	case DPSW_QUEUE_RX_ERR:
		return ctrl_if_set_rx_err_queue(dpsw->ctrl_if, &queue_cfg);
	case DPSW_QUEUE_TX_ERR_CONF:
		return ctrl_if_set_tx_err_conf_queue(dpsw->ctrl_if, &queue_cfg);
	}

	return 0;
}

int dpsw_ctrl_if_enable(struct dpsw *dpsw)
{
	int err = -ENAVAIL;

	if (dpsw->ctrl_if_enable == 1)
		err = ctrl_if_enable(dpsw->ctrl_if);

	return err;
}

int dpsw_ctrl_if_disable(struct dpsw *dpsw)
{
	int err = -ENAVAIL;

	if (dpsw->ctrl_if_enable == 1)
		err = ctrl_if_disable(dpsw->ctrl_if);

	return err;
}

static int ctrl_if_connect(struct dpsw *dpsw, uint16_t if_id, int next_ifp)
{
	int err = 0;
        struct ctrl_if_connect_if_id_cfg	ctrl_connect;

        if (dpsw->ctrl_if_enable == 1) {
                memset(&ctrl_connect, 0x0,
                       sizeof(struct ctrl_if_connect_if_id_cfg));

                ctrl_connect.ap = &(dpsw->iface[if_id].ap);
                ctrl_connect.cq_id = 0;
                ctrl_connect.dctidx_idx = 1;
                ctrl_connect.lfqmtidx_idx = 8;
                ctrl_connect.next_ifp = next_ifp;

                /* get qprid reserved for control */
                err = get_iface_unused_qprid(dpsw, if_id, &(ctrl_connect.qprid));

                /* connect control interface */
                err = ctrl_if_connect_if_id(
                        dpsw->ctrl_if,
                        if_id,
                        &ctrl_connect);
        }
        return err;
}

static int ctrl_if_disconnect(struct dpsw *dpsw, uint16_t if_id)
{
	int err = 0;

        if (dpsw->ctrl_if_enable == 1) {
                err = ctrl_if_disconnect_if_id(dpsw->ctrl_if, if_id);
        }
        return err;
}

static int ctrl_if_linkup(struct dpsw *dpsw, uint16_t if_id)
{
	int err = 0;

	if (dpsw->ctrl_if_enable == 1) {
                err = ctrl_if_enable_if_id(dpsw->ctrl_if, if_id);
        }
	return err;
}

static int ctrl_if_linkdown(struct dpsw *dpsw, uint16_t if_id)
{
	int err = 0;

	if (dpsw->ctrl_if_enable == 1) {
                err = ctrl_if_disable_if_id(dpsw->ctrl_if, if_id);
        }
	return err;
}

int dpsw_ctrl_if_get_tx_counters(struct dpsw  *dpsw, uint16_t  if_id,
	struct dpsw_counters_cfg  *counters)
{
	int err = 0;

	if (dpsw->ctrl_if_enable == 0) {
		return err;
	}

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                             if_id,
	                             E_INGRESS_FC,
	                             &(counters->ing_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_INGRESS_BC,
	                             &(counters->ing_byte));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_INGRESS_FFC,
	                             &(counters->ing_fltr_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_INGRESS_FDC,
	                             &(counters->ing_frame_discard));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_INGRESS_MFC,
	                             &(counters->ing_mcast_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_INGRESS_MBC,
	                             &(counters->ing_mcast_byte));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_INGRESS_BFC,
	                             &(counters->ing_bcast_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_INGRESS_BBC,
	                             &(counters->ing_bcast_bytes));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_EGRESS_FC,
	                             &(counters->egr_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_EGRESS_BC,
	                             &(counters->egr_byte));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_EGRESS_FDC,
	                             &(counters->egr_frame_discard));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_EGRESS_MFC,
	                             &(counters->erg_mcast_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_EGRESS_MBC,
	                             &(counters->egr_mcast_byte));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_EGRESS_BFC,
	                             &(counters->egr_bcast_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_EGRESS_BBC,
	                             &(counters->egr_bcast_bytes));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_tx_if_id_counter(dpsw->ctrl_if,
	                                   if_id,
	                             E_EGRESS_STDC,
	                             &(counters->egr_stp_frame_discard));
	return err;
}

int dpsw_ctrl_if_get_rx_counters(struct dpsw  *dpsw,
	struct dpsw_counters_cfg  *counters)
{
	int err = 0;

	if (dpsw->ctrl_if_enable == 0) {
		return err;
	}

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_INGRESS_FC,
	                             &(counters->ing_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_INGRESS_BC,
	                             &(counters->ing_byte));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_INGRESS_FFC,
	                             &(counters->ing_fltr_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_INGRESS_FDC,
	                             &(counters->ing_frame_discard));
	CHECK_COND_RETVAL(err == 0, err);
	
	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_INGRESS_MFC,
	                             &(counters->ing_mcast_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_INGRESS_MBC,
	                             &(counters->ing_mcast_byte));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_INGRESS_BFC,
	                             &(counters->ing_bcast_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_INGRESS_BBC,
	                             &(counters->ing_bcast_bytes));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_EGRESS_FC,
	                             &(counters->egr_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_EGRESS_BC,
	                             &(counters->egr_byte));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_EGRESS_FDC,
	                             &(counters->egr_frame_discard));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_EGRESS_MFC,
	                             &(counters->erg_mcast_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_EGRESS_MBC,
	                             &(counters->egr_mcast_byte));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_EGRESS_BFC,
	                             &(counters->egr_bcast_frame));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_EGRESS_BBC,
	                             &(counters->egr_bcast_bytes));
	CHECK_COND_RETVAL(err == 0, err);

	err = ctrl_if_get_rx_counter(dpsw->ctrl_if,
	                             E_EGRESS_STDC,
	                             &(counters->egr_stp_frame_discard));
	return err;
}

static int init_ceetm_if(struct dpsw  *dpsw, uint16_t if_id)
{
	int 			err = 0, i;
	struct dpsw_if		*iface;
	struct ceetm_if_cfg 	ceetm_cfg;
	struct dpmng_dev_cfg 	dev_cfg;

	/* obtain ceetm interface */
	iface = &(dpsw->iface[if_id]);

	/* init device configuration */
	memcpy(&(dev_cfg.ctx), &(dpsw->dev_ctx), sizeof(struct dpmng_dev_ctx));
	dev_cfg.device = dpsw->handle.dprc;
	dev_cfg.id = (uint16_t)dpsw->id;

	/* init ceetm configuration */
	memset(&ceetm_cfg, 0x0, sizeof(struct ceetm_if_cfg));
	ceetm_cfg.num_qdbin = 1;
	ceetm_cfg.num_qpri = DPSW_MAX_PRIORITIES + 1;	/* priority + ctrl */
	ceetm_cfg.lfqid = dpmng_get_rtn_fqid(dpsw->handle.dpmng);

	for (i = 0; i < DPSW_MAX_PRIORITIES; i++) {
		ceetm_cfg.qpri[i].in_use = 1;		/* priority in use */
	}

	/* create ceetm interface */
	iface->ceetm_if = ceetm_if_create(&ceetm_cfg, &dev_cfg);
	CHECK_COND_RETVAL(iface->ceetm_if, -ENOMEM);

	return err;
}

static int init_deafult_ceetm_if(struct dpsw *dpsw)
{
	int err = 0;

	err = init_default_ceetm_if_tx_selection(dpsw);
	CHECK_COND_RETVAL(err == 0, err);

	err = init_default_ceetm_if_early_drop(dpsw);

	return err;
}

static int init_default_ceetm_if_tx_selection(struct dpsw *dpsw)
{
	int err = 0;
	uint16_t i;
	struct dpsw_tx_selection_cfg  trans_select;

	/* reset configuration parameters */
	memset(&trans_select, 0x0, sizeof(struct dpsw_tx_selection_cfg));

	/* Use VLAN PCP as a source for priority regeneration */
	trans_select.priority_selector = DPSW_PRIORITY_SELECTOR_PCP;

	/* Strict priority method */
	trans_select.tc_sched[7].mode = DPSW_SCHED_STRICT_PRIORITY;

	/* All priorities mapped to traffic class 7 (highest) */
	trans_select.tc_id[0] = 0x7;
	trans_select.tc_id[1] = 0x7;
	trans_select.tc_id[2] = 0x7;
	trans_select.tc_id[3] = 0x7;
	trans_select.tc_id[4] = 0x7;
	trans_select.tc_id[5] = 0x7;
	trans_select.tc_id[6] = 0x7;
	trans_select.tc_id[7] = 0x7;

	for (i = 0; i < dpsw->num_ifs; i++) {
		err = dpsw_if_set_tx_selection(dpsw, i, &trans_select);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int init_default_ceetm_if_early_drop(struct dpsw *dpsw)
{
	int err = 0;
	struct dpsw_early_drop_cfg 	drop;
	uint16_t i;
	uint8_t j;

	memset(&drop, 0x0, sizeof(struct dpsw_early_drop_cfg));
	drop.drop_mode = DPSW_EARLY_DROP_MODE_NONE;
	drop.units = DPSW_EARLY_DROP_UNIT_BUFFERS;
	drop.tail_drop_threshold = DPSW_BP_FRAMES_PER_QUEUE *
								DPSW_MAX_FRAME_LENGTH / 64;

	for (i = 0; i < dpsw->num_ifs; i++) {
		for (j = 0; j < DPSW_MAX_TC; j++) {
			err = dpsw_if_tc_set_early_drop(dpsw, i, j, &drop);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}

	return err;
}

static enum ceetm_if_ccg_unit get_early_drop_unit(
	enum dpsw_early_drop_unit unit)
{
	enum ceetm_if_ccg_unit ceetm_if_unit = CEETM_IF_CCG_UNIT_BYTES;

	switch (unit) {
		case DPSW_EARLY_DROP_UNIT_BYTES:
			ceetm_if_unit = CEETM_IF_CCG_UNIT_BYTES;
			break;
		case DPSW_EARLY_DROP_UNIT_PACKETS:
			ceetm_if_unit = CEETM_IF_CCG_UNIT_PACKETS;
			break;
		case DPSW_EARLY_DROP_UNIT_BUFFERS:
			ceetm_if_unit = CEETM_IF_CCG_UNIT_BUFFERS;
			break;
		default:
			break;
	}
	return ceetm_if_unit;
}

static enum ceetm_if_ccg_mode get_early_drop_mode(
	enum dpsw_early_drop_mode mode)
{
	enum ceetm_if_ccg_mode ceetm_if_mode = CEETM_IF_CCG_MODE_NONE;

	switch (mode) {
		case DPSW_EARLY_DROP_MODE_NONE:
			ceetm_if_mode = CEETM_IF_CCG_MODE_NONE;
			break;
		case DPSW_EARLY_DROP_MODE_TAIL:
			ceetm_if_mode = CEETM_IF_CCG_MODE_TAIL;
			break;
		case DPSW_EARLY_DROP_MODE_WRED:
			ceetm_if_mode = CEETM_IF_CCG_MODE_WRED;
			break;
		default:
			break;
	}
	return ceetm_if_mode;
}

static enum ceetm_if_sched_mode get_schedule_mode(
	enum dpsw_schedule_mode mode)
{
	enum ceetm_if_sched_mode ceetm_if_mode = CEETM_IF_SCHED_STRICT_PRIORITY;

	/* translate scheduling mode */
	switch (mode) {
		case DPSW_SCHED_STRICT_PRIORITY:
			ceetm_if_mode = CEETM_IF_SCHED_STRICT_PRIORITY;
			break;
		case DPSW_SCHED_WEIGHTED:
			ceetm_if_mode = CEETM_IF_SCHED_WEIGHTED;
			break;
		default:
			break;
	}
	return ceetm_if_mode;
}

static int get_iface_qdid(struct dpsw *dpsw, uint16_t if_id, int *qdid)
{
	struct dpsw_if 		*iface;
	struct ceetm_if_attr 	attr = {0};

	/* Obtain interface */
	iface = &(dpsw->iface[if_id]);

	ceetm_if_get_attributes(iface->ceetm_if, &attr);

	*qdid = attr.qdid;	/* update qdid */

	return 0;
}

static int get_iface_unused_qprid(struct dpsw *dpsw,
	uint16_t if_id, int *qprid)
{
	int 			i;
	struct dpsw_if 		*iface;
	struct ceetm_if_attr 	attr;

	/* Obtain interface */
	iface = &(dpsw->iface[if_id]);

	ceetm_if_get_attributes(iface->ceetm_if, &attr);

	for (i = 0; i < attr.num_qpri; i++) {
		if (attr.qpri[i].in_use == 1)
			continue;

		*qprid = attr.qpri[i].id;	/* update qprid */
		break;
	}

	return 0;
}

int dpsw_if_lag_configure (struct dpsw *dpsw, const struct dpsw_lag_cfg *lag_cfg)
{
	struct dpsw_if *iface; /**< Interface database */
	struct ceetm_if *iface_master;
	int err = 0;
	int i;

	if (dpsw->lag_enable == 0)
	{
		pr_err("LAG is disabled, cannot configure.\n");
		return -EINVAL;
	}

	if (lag_cfg->num_ifs > dpsw->num_ifs)
		return -EINVAL;

	for (i = 0; i < lag_cfg->num_ifs; i++) {
		iface = &(dpsw->iface[lag_cfg->if_id[i]]); /*! Get interface */
		if (i == 0)
		{
			set_ceetm_lag_conf(iface->ceetm_if,NULL,lag_cfg->group_id, lag_cfg->num_ifs);
			iface_master = iface->ceetm_if;
		}
		else
		{
			set_ceetm_lag_conf(iface->ceetm_if,iface_master,lag_cfg->group_id,lag_cfg->num_ifs);
		}

		iface->lag_enabled = 1;
	}

	return 0;
}

int dpsw_lag_set(struct dpsw *dpsw,
	const struct dpsw_lag_cfg *lag_cfg)
{
	int err = 0;
	int i,index,j,k;
	struct dpsw_if 		*iface;
	struct dpmng_amq    amq;
	struct dpsw_fdb *fdb;
	struct dpsw_replic *replic;

	if (dpsw->lag_enable == 0)
	{
		pr_err("LAG is disabled, cannot configure.\n");
		return -EINVAL;
	}

	err = dpsw_if_lag_configure(dpsw,lag_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	index = lag_cfg->group_id - 1;
	memset(&dpsw->lag_cfg[index],0,sizeof(struct dpsw_lag_cfg));

	dpsw->lag_cfg[index].group_id = lag_cfg->group_id;
	dpsw->lag_cfg[index].num_ifs = lag_cfg->num_ifs;
	dpsw->num_lag_groups++;

	for (i = 0; i < lag_cfg->num_ifs; i++)
	{
		dpsw->lag_cfg[index].if_id[i] = lag_cfg->if_id[i];
		iface = &(dpsw->iface[lag_cfg->if_id[i]]);

		/* Obtain AMQ */
		memset(&amq, 0x0, sizeof(struct dpmng_amq));
		dpmng_get_amq(&amq);

		/* connect access point to ceetm */
		err = ceetm_if_connect_accesspoint(
			iface->ceetm_if, 	/* ceetm context */
			&(iface->ap),		/* accesspoint */
			&amq			/* amq */
			);
		CHECK_COND_RETVAL(err == 0, err);

		if (i!=0)
		{
			/* Remove the interface from broadcast replicator */
			err = remove_if_from_replic_broadcast(dpsw, lag_cfg->if_id[i]);
			CHECK_COND_RETVAL(err == 0, err);

			/* Remove the interface from the flooding replicators */
			err = remove_if_from_replic_flooding(dpsw, lag_cfg->if_id[i]);
			CHECK_COND_RETVAL(err == 0, err);

			for (j = 0; j < dpsw->max_fdbs; j++) {
				err = hmap_get_data(dpsw->hmap_fdb, j, (hmap_data *)&fdb);
				if ((err != 0) || (fdb == NULL))
					continue;

				for (k = 0; k < dpsw->max_fdb_mc_groups; k++) {

					if (fdb->hmap_mcast == NULL)
						continue;

					/*! get hmap data */
					err = hmap_get_data(fdb->hmap_mcast, k,(hmap_data *)&replic);
					if (err != 0)
						continue;

					/*! destroy replic */
					if (replic && replic->replic) {
						err = replic_remove_element(replic->replic,
													lag_cfg->if_id[i]);
						if( err )
							pr_err("SWID[%d] - replic_remove_element() return error\n", dpsw->id);
					}
				}
			}
		}
	}

	return 0;
}
int dpsw_lag_get(struct dpsw *dpsw, uint8_t group_id,
	struct dpsw_lag_cfg *lag_cfg)
{
	int i;

	if (dpsw->lag_enable == 0)
	{
		pr_err("LAG is disabled.\n");
		return -EINVAL;
	}

	lag_cfg->group_id = group_id;
	lag_cfg->num_ifs = dpsw->lag_cfg[group_id-1].num_ifs;
	for (i=0;i<lag_cfg->num_ifs;i++)
		lag_cfg->if_id[i] = dpsw->lag_cfg[group_id-1].if_id[i];
	return 0;
}

int dpsw_if_get_port_mac_addr(struct dpsw *dpsw, uint16_t if_id, uint8_t addr[6])
{
	struct dpsw_if *iface = &(dpsw->iface[if_id]);
	struct dpmac *dpmac = iface->dpmac;

	memset(addr, 0, 6);
	if (dpmac)
		dpmac_get_port_mac_addr(dpmac, addr);

	return 0;
}

int dpsw_if_set_taildrop(struct dpsw *dpsw, uint16_t if_id, uint8_t tc_id,
		struct dpsw_taildrop_cfg *cfg)
{
	struct dpsw_if *iface = &(dpsw->iface[if_id]);
	struct dpsw_early_drop_cfg 	drop;
	int err = 0;

	memset(&drop, 0x0, sizeof(struct dpsw_early_drop_cfg));
	drop.drop_mode = DPSW_EARLY_DROP_MODE_TAIL;
	drop.units = cfg->units;
	drop.tail_drop_threshold = cfg->threshold;
	if( cfg->enable )
		drop.drop_mode = DPSW_EARLY_DROP_MODE_TAIL;
	else
		drop.drop_mode = DPSW_EARLY_DROP_MODE_NONE;

	err = dpsw_if_tc_set_early_drop(dpsw, if_id, tc_id, &drop);
	CHECK_COND_RETVAL(err == 0, err, "dpsw_if_tc_set_early_drop() failed\n");

	return err;
}

int dpsw_if_get_taildrop(struct dpsw *dpsw, uint16_t if_id, uint8_t tc_id,
		struct dpsw_taildrop_cfg *cfg)
{
	struct dpsw_early_drop_cfg 	drop_cfg;
	int err = 0;

	err = if_get_early_drop(dpsw, if_id, tc_id, &drop_cfg);
	CHECK_COND_RETVAL( err==0, err, "if_get_early_drop() return error");

	if( drop_cfg.drop_mode == DPSW_EARLY_DROP_MODE_TAIL )
		cfg->enable = 1;
	else
		cfg->enable = 0;

	cfg->units = drop_cfg.units;
	cfg->threshold = drop_cfg.tail_drop_threshold;

	return err;
}

int dpsw_get_ap_ppid(struct dpsw *dpsw, int if_id, int *ppid)
{
	struct dpsw_if 		*iface;

	iface = &(dpsw->iface[if_id]);
	if( iface->ap_valid )
		*ppid = iface->ap.ppid;
	else
		return -ENOTSUP;

	return 0;
}

int dpsw_clean_flow_control_config(struct dpsw *dpsw, int if_id)
{
	struct dpsw_if 	*iface;
	uint32_t		pfc_flags;

	iface = &(dpsw->iface[if_id]);
	if( iface->fc_idx==FLOW_CONTROL_INVALID_INDEX )
		return 0;

	pfc_flags = DPSW_UPDATE_FC;
	dpsw_if_update_pfc_settings(dpsw, if_id, pfc_flags);

	iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;

	return 0;
}

static int get_action_result(struct dptbl_action action, uint16_t *result) {
	result[0] = (uint16_t)(action.options >> 16);
	result[1] = (uint16_t)action.options;
	result[2] = (uint16_t)action.replic_id;

	return 0;
}

static int dpsw_dump_vlan_table(struct device *dev, struct dptbl *vlan_tbl, uint16_t table_index, uint64_t iova_addr, int iova_size, uint16_t *table_size)
{
	int err;
	int modify_create = 0;
	uint8_t key[4];
	struct eiop_desc desc = {0};
	struct dpsw *dpsw;
	int remaining_bytes;
	int entry_size;
	int tmp_match_type;
	uint16_t num_entries = 0, vlan_id=0;
	struct dump_table_header header = { 0 };
	struct dump_table_entry entry = { 0 };
	int header_size = 0;
	struct dptbl_l2switch_vlan_rule_cfg rule; /* Rule */
	struct dptbl_l2switch_vlan_action vlan_action;
	uint64_t ruleid;
	
	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);
	
	header_size = sizeof(struct dump_table_header);
	entry_size = sizeof(struct dump_table_entry);
	remaining_bytes = iova_size;
	
	header.table_type = DPSW_VLAN_ING_TABLE;
	header.table_num_entries = 0;
	header.table_max_entries = dpsw->max_vlans * dpsw->num_ifs;
	header.default_action = 0;
	dptbl_get_tbl_type(vlan_tbl, &tmp_match_type);
	header.match_type = (uint8_t)tmp_match_type;

	//convert_header(&header);
	err = dpmng_dev_memcpy(dev, &header, iova_addr, sizeof(header), 0);
	if (err) {
		pr_err("Error writing extended DMA parameters\n");
		return err;
	}

	remaining_bytes -= header_size;
	iova_addr += header_size;
	num_entries = 0;

	do {
		err = dptbl_get_next_ruleid(vlan_tbl, &ruleid);
		if( err ) {
			pr_err("No entry found for ruleid %08x%08x\n", (uint32_t)((ruleid>>32)&0xffffffff), (uint32_t)(ruleid&0xffffffff));
			break;
		}
		
		if( ruleid==0 ) {
			err = 0;
			break;
		}
		
		if( remaining_bytes<entry_size ) {
			pr_warn("More entries are available but the allocated area is too small\n");
			break;
		}
		
		err = dptbl_query_with_ruleid(vlan_tbl, &ruleid, key, sizeof(key));
		if( err ) {
				pr_err("Query failed for ruleid %08x%08x\n", 
						(uint32_t)((ruleid>>32)&0xffffffff)  , 
						(uint32_t)(ruleid&0xffffffff) );
				break;
		}
		
		ruleid++;
		
		/* rule */
		memset(&rule, 0x0, sizeof(struct dptbl_l2switch_vlan_rule_cfg));
		memset(&vlan_action, 0x0, sizeof(struct dptbl_l2switch_vlan_action));
		
		rule.key = key;
		
		/*! Read VLAN entry */
		err = dptbl_get_l2switch_vlan(vlan_tbl, &rule, &vlan_action);	
	
		if (err)
		{
			pr_err("Err getting action for vlan %x %x %x %x\n", rule.key[0],rule.key[1],rule.key[2],rule.key[3]);
			continue;
		}

		memset(&entry, 0, sizeof(entry));
		memcpy(entry.key, rule.key, sizeof(uint32_t));
		memset(entry.mask, 0xff, sizeof(uint32_t));
	
		entry.key_action = 0;
	
		entry.result[0] = (uint16_t)(vlan_action.options >> 16);
		entry.result[1] = (uint16_t)vlan_action.options;
		entry.result[2] = (uint16_t)vlan_action.general_replic_qd_id;
		
		//convert_entry(&entry);
		err = dpmng_dev_memcpy(dev, &entry, iova_addr, sizeof(entry), 0);
		if (err) {
			pr_err("Error writing extended DMA parameters\n");
			*table_size = num_entries;
		}

		remaining_bytes -= entry_size;
		iova_addr += entry_size;
		num_entries++;
	} while (ruleid!=0);

	*table_size = num_entries;
	return 0;
}


static int dpsw_dump_fdb_table_new(struct device *dev, uint16_t table_index, uint64_t iova_addr, int iova_size, uint16_t *table_size)
{
	int err;
	int modify_create = 0;
	uint8_t key[6];
	uint8_t if_mask[8];
	struct eiop_desc desc = {0};
	struct dpsw *dpsw;
	int remaining_bytes;
	int entry_size;
	uint16_t num_entries = 0, vlan_id=0;
	struct dump_table_header header = { 0 };
	struct dump_table_entry entry = { 0 };
	int header_size = 0;
	struct dpsw_fdb *fdb;
	int i, tmp_match_type;
	uint64_t ruleid, tmp_rule;
	struct dpsw_fdb_unicast_cfg unicast_cfg;
	struct dpsw_fdb_multicast_cfg multicast_cfg;
	
	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);
	
	header_size = sizeof(struct dump_table_header);
	entry_size = sizeof(struct dump_table_entry);
	remaining_bytes = iova_size;
	
	header.table_type = DPSW_FDB_TABLE;
	header.table_num_entries = 0;
	header.table_max_entries = dpsw->max_fdb_entries;
	header.default_action = 0;

	//convert_header(&header);
	err = dpmng_dev_memcpy(dev, &header, iova_addr, sizeof(header), 0);
	if (err) {
		pr_err("Error writing extended DMA parameters\n");
		return err;
	}

	remaining_bytes -= header_size;
	iova_addr += header_size;
	num_entries = 0;

	err = soc_db_get_desc(SOC_MODULE_EIOP, SOC_DB_NO_MATCH_FIELDS, &desc, NULL);
	CHECK_COND_RETVAL(err==0, err, "Could not obtain wriop descriptor\n");
	CHECK_COND_RETVAL(desc.wriop_version!=WRIOP_VERSION(1, 0, 0), -ENOSYS, "Could not execute operation in this hw platform\n");

	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&table_index, (void **)&fdb);
	CHECK_COND_RETVAL(err==0, err, "fdb table with id %d not found\n", table_index);
	
	dptbl_get_tbl_type(fdb->hndl, &tmp_match_type);
	header.match_type = (uint8_t)tmp_match_type;
	do {
		err = dptbl_get_next_ruleid(fdb->hndl, &ruleid);
		if( err ) {
			pr_err("No entry found for ruleid %08x%08x\n", (uint32_t)((ruleid>>32)&0xffffffff), (uint32_t)(ruleid&0xffffffff));
			break;
		}
		if( ruleid==0 ) {
			err = 0;
			break;
		}
		if( remaining_bytes<entry_size ) {
			pr_warn("More entries are available but the allocated area is too small\n");
			break;
		}
		err = dptbl_query_with_ruleid(fdb->hndl, &ruleid, key, sizeof(key));
		if( err ) {
			pr_err("Query failed for ruleid %08x%08x\n", 
					(uint32_t)((ruleid>>32)&0xffffffff)  , 
					(uint32_t)(ruleid&0xffffffff) );
			break;
		}
		tmp_rule = ruleid;
		ruleid++;

		memset(&entry, 0, sizeof(entry));
		memcpy(entry.key, key, sizeof(key));
		memset(entry.mask, 0xff, sizeof(key));
	
		entry.key_action = 0;
		
		if( dpsw->multicast_enable && (key[0]&0x01)==0x01 ) {
			memset(&multicast_cfg, 0, sizeof(multicast_cfg));
			memcpy(multicast_cfg.mac_addr, key, sizeof(key));
			err = dpsw_fdb_get_multicast(dpsw, table_index, &multicast_cfg);
			if( err ) {
				continue;
			}
			
			entry.result[0] 	= multicast_cfg.num_ifs;
			entry.result[1] 	= multicast_cfg.type;
			for( i=0 ; i<multicast_cfg.num_ifs ; i++ ) {
				if_mask[multicast_cfg.if_id[i]/8] |= (0x01 << (multicast_cfg.if_id[i]%8));
			}
			
			memcpy(&entry.result[3], if_mask, sizeof(uint16_t));
		} else {
			memset(&unicast_cfg, 0, sizeof(unicast_cfg));
			memcpy(unicast_cfg.mac_addr, key, sizeof(key));
			err = dpsw_fdb_get_unicast(dpsw, table_index, &unicast_cfg);
			if( err ) {
				continue;
			}
			
			entry.result[0] 	= unicast_cfg.if_egress;
			entry.result[1] 		= unicast_cfg.type;
			entry.result[1]		= entry.result[1] | 0x02;
		}

		err = dpmng_dev_memcpy(dev, &entry, iova_addr, sizeof(entry), 0);
		if (err) {
			pr_err("Error writing extended DMA parameters\n");
			*table_size = num_entries;
		}

		remaining_bytes -= entry_size;
		iova_addr += entry_size;
		num_entries++;
	} while( ruleid!=0 );

	*table_size = num_entries;
	return 0;
}

static int dpsw_dump_acl_table(struct device *dev, struct dptbl *tbl, uint64_t iova_addr, int iova_size, uint16_t *table_size)
{
	int err = 0, i;
	int table_num_entries;
	int table_max_entries;
	int real_key_size;
	int match_type;
	int remaining_bytes;
	uint32_t header_size;
	uint32_t entry_size;
	uint32_t max_entries;
	struct dump_table_header header;
	struct dump_table_entry *entries;
	struct dptbl_action action;
	struct dptbl_rule rule;

	*table_size = 0;

	header_size = sizeof(struct dump_table_header);
	entry_size = sizeof(struct dump_table_entry);

	remaining_bytes = iova_size;
	CHECK_COND_RETVAL( remaining_bytes>=header_size, -EINVAL, "Not enough space to store header\n");

	max_entries = (remaining_bytes - header_size) / entry_size;

	dptbl_get_num_of_used_rules(tbl, &table_num_entries);
	dptbl_get_num_of_max_rules(tbl, &table_max_entries);
	dptbl_get_tbl_type(tbl, &match_type);
	// get default action

	memset(&header, 0, header_size);
	header.table_type = DPSW_ACL_TABLE;
	header.match_type = (uint8_t)match_type;
	header.table_num_entries = (uint16_t)table_num_entries;
	header.table_max_entries = (uint16_t)table_max_entries;
	// set default action in header

	err = dpmng_dev_memcpy(dev, &header, iova_addr, header_size, 0);
	if (err) {
		pr_err("Error writing extended DMA parameters\n");
		return err;
	}

	remaining_bytes -= header_size;
	iova_addr += header_size;
	*table_size = 0;

	entries = (struct dump_table_entry *)fsl_malloc(max_entries * entry_size);
	CHECK_COND_RETVAL(entries, -ENOMEM);
	memset(entries, 0, max_entries * entry_size);

	err = dptbl_query(tbl, (void *)entries, (int)max_entries, table_size);
	if (err) {
		pr_err("Error in dptbl_query\n");
		fsl_free(entries);
		return err;
	}

	for (i = 0; i < *table_size; i++) {
		memset(&rule, 0, sizeof(struct dptbl_rule));

		rule.rule_cfg.masked.key = entries[i].key;
		rule.rule_cfg.masked.mask = entries[i].mask;
		dptbl_get_real_key_size(tbl, &real_key_size);
		rule.rule_cfg.masked.size = (uint32_t)real_key_size;

		rule.rule_cfg.exact.key = entries[i].key;
		dptbl_get_real_key_size(tbl, &real_key_size);
		rule.rule_cfg.exact.size = (uint32_t)real_key_size;

		memset(&action, 0x0, sizeof(struct dptbl_action));
		err = dptbl_get_action(tbl, &rule, &action);
		if(err) {
			pr_err("Error getting key action\n");
			continue;
		}

		entries[i].key_action = action.next_action;

		err = get_action_result(action, entries[i].result);
		if (err) {
			pr_err("Error getting action result\n");
			continue;
		}

		err = dpmng_dev_memcpy(dev, &entries[i], iova_addr, entry_size, 0);
		if (err) {
			pr_err("Error writing extended DMA parameters\n");
			fsl_free(entries);
			return err;
		}

		iova_addr += entry_size;
	}

	fsl_free(entries);
	return err;
}

int dpsw_table_dump(struct device *dev, uint16_t table_type, uint16_t table_index, uint64_t iova_addr, int iova_size, uint16_t *table_size)
{
	int err = 0;
	struct dpsw *dpsw;
	uint16_t acl_id;
	struct dpsw_acl *acl;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	if (table_type == DPSW_FDB_TABLE) {
		dpsw_dump_fdb_table_new(dev, table_index, iova_addr, iova_size, table_size);
	}
	else if (table_type == DPSW_VLAN_ING_TABLE){
		dpsw_dump_vlan_table(dev, dpsw->vlan_ing.tbl, table_index, iova_addr, iova_size, table_size);
	}
	else if (table_type == DPSW_VLAN_EGR_TABLE){
		dpsw_dump_vlan_table(dev, dpsw->vlan_egr.tbl, table_index, iova_addr, iova_size, table_size);
	}
	else if (table_type == DPSW_ACL_TABLE) {
		/*! Retrieve acl database */
		acl_id = table_index;
		err = hmap_lookup(dpsw->hmap_acl, (hmap_key)&acl_id, (void **)&acl);
		CHECK_COND_RETVAL(err == 0, err);

		/*! sanity check */
		CHECK_COND_RETVAL(acl->hndl, -EFAULT); /* Bad address */
		dpsw_dump_acl_table(dev, acl->hndl, iova_addr, iova_size, table_size);
	}
	else {
		pr_err("Invalid table type\n");
		err = -EINVAL;
	}

	return err;
}

int dpsw_if_set_errors_behavior(struct dpsw *dpsw, int if_id, struct dpsw_error_cfg *cfg)
{
	
	struct eiop_ifp_err_cfg mem_err_cfg;
	uint32_t errors;
	struct dpsw_if 		*iface;
	struct eiop_ifp_desc eiop_ifp_desc;	
	int err = 0;

	errors = cfg->errors;

	memset(&mem_err_cfg, 0, sizeof(struct eiop_ifp_err_cfg));
	if (cfg->error_action == DPSW_ERROR_ACTION_DISCARD) {
		
		mem_err_cfg.action = EIOP_IFP_ERR_DROP;
		errors |= DPSW_ERRORS_TO_DISCARD;
		
	} else {	
		/* For non-discard case, all errors will be
		 * directed to rx-err before AIOP */
		mem_err_cfg.action = EIOP_IFP_ERR_ENQ;
#if 0
		if (cfg->set_frame_annotation)
			mem_err_cfg.options =
				(EIOP_IFP_ERR_CFG_OPT_SET_FD_STATUS
					| EIOP_IFP_ERR_CFG_OPT_SET_FD_ERR);
#endif
	}
	
	iface = &(dpsw->iface[if_id]);
	
	/* Obtain IFP descriptor */
	memset(&eiop_ifp_desc, 0x0, sizeof(struct eiop_ifp_desc));
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	
	eiop_ifp_set_err_behavior(&eiop_ifp_desc, errors,
					&mem_err_cfg);
	
	return 0;
}

static int __dpsw_set_egress_flood(struct dpsw *dpsw, struct dpsw_egress_flood_cfg *cfg)
{
	struct dpsw_vlan_if_cfg flood_cfg;
	struct dpsw_replic *replic;
	struct dpsw_fdb *fdb;
	int if_connected;
	int i, pos = 0;
	uint16_t j = 0;
	char buf[100];
	int err = 0;

	if (cfg->flood_type == DPSW_BROADCAST &&
	    dpsw->broadcast_cfg != DPSW_BROADCAST_PER_FDB) {
		pr_err("broadcast_cfg != DPSW_BROADCAST_PER_FDB: cannot configure per FDB broadcast\n");
		return -EINVAL;
	}

	if (cfg->flood_type == DPSW_FLOODING &&
	    dpsw->flooding_cfg != DPSW_FLOODING_PER_FDB) {
		pr_err("flooding_cfg != DPSW_FLOODING_PER_FDB: cannot configure per FDB flooding\n");
		return -EINVAL;
	}

	err = hmap_lookup(dpsw->hmap_fdb, (hmap_key)&(cfg->fdb_id), (void **)&fdb);
	CHECK_COND_RETVAL(err == 0, err);

	/* Filter out the interfaces that are currently not up */
	memset(&flood_cfg, 0, sizeof(flood_cfg));
	for (i = 0; i < cfg->num_ifs; i++) {
		/* If this the CTRL IF, then it's always up if it's enabled */
		if (cfg->if_id[i] == dpsw->num_ifs) {
			if (!dpsw->ctrl_if_enable) {
				pr_err("CTRL_IF not enabled, cannot configure flooding on it!\n");
				return -EINVAL;
			}
		} else {
			err = is_if_link_up(dpsw, cfg->if_id[i], &if_connected);
			if (err || !if_connected)
				continue;
		}

		/* The interface is up, add it to the current configuration of
		 * the replicator
		 */
		flood_cfg.if_id[j++] = cfg->if_id[i];
	}
	/* Setup the number of interfaces that can be actually added into the
	 * replicator (ie they are up atm)
	 */
	flood_cfg.fdb_id = cfg->fdb_id;
	flood_cfg.num_ifs = j;

	switch (cfg->flood_type) {
	case DPSW_BROADCAST:
		replic = &fdb->broadcast;
		memcpy(fdb->bcast_ifs, cfg->if_id, sizeof(uint16_t) * DPSW_MAX_IF);
		fdb->bcast_num_ifs = cfg->num_ifs;
		break;
	case DPSW_FLOODING:
		replic = &fdb->flooding;
		memcpy(fdb->flooding_ifs, cfg->if_id, sizeof(uint16_t) * DPSW_MAX_IF);
		fdb->flooding_num_ifs = cfg->num_ifs;
		break;
	default:
		pr_err("flood_type %d unknown!\n", cfg->flood_type);
		return err;
	}

	err = replic_cleanup(dpsw, replic);
	CHECK_COND_RETVAL(err == 0, err, "replic_cleanup() failed!\n");

	err = replic_add(dpsw, replic, &flood_cfg);
	CHECK_COND_RETVAL(err == 0, err, "replic_add() failed!\n");

	/* Debug prints (requested vs configured)*/
	pos = 0;
	memset(buf, 0, 100);
	for (i = 0; i < flood_cfg.num_ifs; i++)
		pos += sprintf(buf + pos, "%d ", flood_cfg.if_id[i]);
	pr_debug("[FDB #%d] [%10s] [%10s] the following %d interface(s): %s\n",
		 flood_cfg.fdb_id, cfg->flood_type == DPSW_BROADCAST ? "broadcast" : "unicast",
		 "configured", cfg->num_ifs, buf);

	memset(buf, 0, 100);
	pos = 0;
	for (i = 0; i < cfg->num_ifs; i++)
		pos += sprintf(buf + pos, "%d ", cfg->flood_type == DPSW_BROADCAST ? fdb->bcast_ifs[i] : fdb->flooding_ifs[i]);
	pr_debug("[FDB #%d] [%10s] [%10s] the following %d interface(s): %s\n",
		 flood_cfg.fdb_id, cfg->flood_type == DPSW_BROADCAST ? "broadcast" : "unicast",
		 "requested", cfg->num_ifs, buf);

	return err;
}

int dpsw_set_egress_flood(struct device *dev, struct dpsw_egress_flood_cfg *cfg)
{
	struct dpsw *dpsw;

	dpsw = device_get_priv(dev);
	CHECK_COND_RETVAL(dpsw, -ENODEV);

	return __dpsw_set_egress_flood(dpsw, cfg);
}

int dpsw_if_set_learning_mode(struct dpsw *dpsw, uint16_t if_id,
			      enum dpsw_learning_mode mode)
{
	struct dpsw_if *iface;
	int err;

	if (if_id >= dpsw->num_ifs)
		return -EINVAL;

	err = dpsw_learning_params_integrity(dpsw, mode);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Obtain interface */
	iface = &(dpsw->iface[if_id]);

	/*! Update interface dataBase */
	iface->learning_requested = 1;
	iface->learning_mode = mode;

	/*! Update related entries in VLAN lookup table */
	err = vlan_tbl_if_update(dpsw, if_id);

	return err;
}
