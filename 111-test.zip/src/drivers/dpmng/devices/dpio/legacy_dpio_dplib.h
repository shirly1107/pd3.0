/*
 * Copyright 2013-2020 NXP
 */

#ifndef _LEGACY_DPIO_DPLIB_H
#define _LEGACY_DPIO_DPLIB_H

/* 
 * File used to maintain compatibility with older version of dplib/flib
 * All previous version of dpio commands should be placed here
 */

/**********************************************/
/********* V0 version of dpio commands ********/
/**********************************************/

/*                cmd, param, offset, width, type, arg_name */
#define DPIO_RSP_GET_ATTRIBUTES_V0(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, int,      (attr)->id);\
	MC_RSP_OP(cmd, 0, 32, 16, uint16_t, (attr)->qbman_portal_id);\
	MC_RSP_OP(cmd, 0, 48,  8,  uint8_t, (attr)->num_priorities);\
	MC_RSP_OP(cmd, 0, 56,  4,  enum dpio_channel_mode, (attr)->channel_mode);\
	MC_RSP_OP(cmd, 1,  0, 64, uint64_t, (attr)->qbman_portal_ce_offset);\
	MC_RSP_OP(cmd, 2,  0, 64, uint64_t, (attr)->qbman_portal_ci_offset);\
	MC_RSP_OP(cmd, 3,  0, 16, uint16_t, (attr)->version.major);\
	MC_RSP_OP(cmd, 3, 16, 16, uint16_t, (attr)->version.minor);\
	MC_RSP_OP(cmd, 3, 32, 32, uint32_t, (attr)->qbman_version);\
	MC_RSP_OP(cmd, 4,  0, 32, uint32_t, (attr)->clk);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPIO_CMD_SET_IRQ(cmd, irq_index, irq_cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,  irq_index);\
	MC_CMD_OP(cmd, 0, 32, 32, uint32_t, irq_cfg->val);\
	MC_CMD_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr);\
	MC_CMD_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPIO_CMD_GET_IRQ(cmd, irq_index) \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index)

/*                cmd, param, offset, width, type, arg_name */
#define DPIO_RSP_GET_IRQ(cmd, type, irq_cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, irq_cfg->val); \
	MC_RSP_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr); \
	MC_RSP_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
	MC_RSP_OP(cmd, 2, 32, 32, int,	    type); \
} while (0)

#endif /* _LEGACY_DPIO_DPLIB_H */
