/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpio.h

 @Description   DPIO internal structures and definitions.
*//***************************************************************************/
#ifndef __DPIO_H
#define __DPIO_H

#include "kernel/fsl_spinlock.h"
#include "drivers/fsl_mc.h"

#include "fsl_event_pipe.h"
#include "fsl_dpio_mc.h"
#include "fsl_qbman.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPIO

#define DPIO_NUM_STATIC_CHANNELS	16
#define DPIO_INVALID_STATIC_CHANNEL	(uint16_t)-1

struct dpio {
	uint16_t		id;
	enum dpio_channel_mode 	channel_mode;
	uint8_t			num_priorities;
	struct device	*device;
	struct qbman_block	*qbman;
	struct dpmng		*dpmng;
	struct qbman_swportal_desc swp_desc;
	int			portal_id;
	int			notification_ch_id;
	struct dpmng_amq	amq;
	int			enabled;
	int 			authorized;
	uint16_t		static_channel_ids[DPIO_NUM_STATIC_CHANNELS];

	struct mc_irq irqs[DPIO_MAX_IRQ_NUM];
};

#endif /* __DPIO_H */
