/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPIO_CMD_H
#define _DPIO_CMD_H

/* default version for all dpio commands */
#define DPIO_CMD_VER_BASE								CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPIO_CMD_V0										CMDHDR_CMD_VERSION(0)
#define DPIO_CMD_V1										CMDHDR_CMD_VERSION(1)
#define DPIO_CMD_V2										CMDHDR_CMD_VERSION(2)

/* Command IDs */
#define DPIO_CMD_CODE_CLOSE                                0x800
#define DPIO_CMD_CODE_OPEN                                 0x803
#define DPIO_CMD_CODE_CREATE                               0x903
#define DPIO_CMD_CODE_DESTROY                              0x900
#define DPIO_CMD_CODE_GET_API_VERSION                      0xa03

#define DPIO_CMD_CODE_ENABLE                               0x002
#define DPIO_CMD_CODE_DISABLE                              0x003
#define DPIO_CMD_CODE_GET_ATTR                             0x004
#define DPIO_CMD_CODE_RESET                                0x005
#define DPIO_CMD_CODE_IS_ENABLED                           0x006

#define DPIO_CMD_CODE_SET_IRQ                              0x010
#define DPIO_CMD_CODE_GET_IRQ                              0x011
#define DPIO_CMD_CODE_SET_IRQ_ENABLE                       0x012
#define DPIO_CMD_CODE_GET_IRQ_ENABLE                       0x013
#define DPIO_CMD_CODE_SET_IRQ_MASK                         0x014
#define DPIO_CMD_CODE_GET_IRQ_MASK                         0x015
#define DPIO_CMD_CODE_GET_IRQ_STATUS                       0x016
#define DPIO_CMD_CODE_CLEAR_IRQ_STATUS                     0x017

#define DPIO_CMD_CODE_SET_STASHING_DEST                    0x120
#define DPIO_CMD_CODE_GET_STASHING_DEST                    0x121
#define DPIO_CMD_CODE_ADD_STATIC_DEQUEUE_CHANNEL           0x122
#define DPIO_CMD_CODE_REMOVE_STATIC_DEQUEUE_CHANNEL        0x123
#define DPIO_CMD_CODE_SET_STASHING_DEST_SOURCE             0x124
#define DPIO_CMD_CODE_GET_STASHING_DEST_SOURCE             0x125
#define DPIO_CMD_CODE_SET_STASHING_DEST_TARGET             0x126

#endif /* _DPIO_CMD_H */
