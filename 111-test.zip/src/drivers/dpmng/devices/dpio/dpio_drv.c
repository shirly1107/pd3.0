/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpio_drv.c

 @Description   driver implementation

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "fsl_sys.h"
#include "dtc/dtc.h"
#include "dplib/fsl_dpio_cmd.h"
#include "fsl_event_pipe.h"

#include "fsl_dpio_mc.h"
#include "fsl_resman.h"
#include "dpio_cmd.h"
#include "legacy_dpio_dplib.h"
#include "fsl_qbman_ctrl.h"

/* DPIO last supported api version */
#define DPIO_V0_API_VER_MAJOR				3
#define DPIO_V0_API_VER_MINOR				2

int dpio_drv_init(void);

/*            cmd, cfg, param, offset, width, type, arg_name */
#define DPIO_LO_CREATE(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 16, 2,  enum dpio_channel_mode, cfg->channel_mode);\
	MC_RSP_OP(cmd, 0, 32, 8,  uint8_t,  cfg->num_priorities);\
} while (0)

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpio *dpio;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	return dpio_set_dev_ctx(dpio, dev_ctx);
}

static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpio_cfg dpio_cfg;
	struct dpio_cfg *cfg = &dpio_cfg;
	int err;

	memset(cfg, 0, sizeof(struct dpio_cfg));

	DPIO_CMD_CREATE(cmd_data, cfg);

	if (!cfg->num_priorities)
		cfg->num_priorities = 2;

	dpio = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpio) {
		/* NULL */
		dpio = dpio_allocate();
		if (!dpio) {
			pr_err("No memory for dpio\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpio_init(dpio, cfg, &dev_cfg);
		if (err) {
			return err;
		}
		device_set_priv(dev, dpio);
		sys_add_handle(dpio, FSL_MOD_DPIO, 1, dev_cfg.id);
	} else
		return -EINVAL;

	return 0;
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;

	UNUSED(cmd_data);

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	device_set_enable(dev, 1);

	dpio_enable(dpio);

	return 0;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	int err;

	UNUSED(cmd_data);

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	err = dpio_disable(dpio);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	int ret;

	UNUSED(cmd_data);

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	ret = dpio_reset(dpio, 0);
	if (ret) {
		pr_err("dpio_reset failed\n");
		return ret;
	}

	device_set_enable(dev, 0);

	return ret;
}

static int reset_by_resman(struct device *dev)
{
	struct dpio *dpio;
	int enabled = 0;
	int ret;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;
	/* workaround for DPNI reset */
	if (dpio_is_enabled(dpio, &enabled) == 0 && !enabled)
		dpio_enable(dpio);

	ret = dpio_reset(dpio, 1);
	if (ret) {
		pr_err("dpio_reset failed\n");
		return ret;
	}

	device_set_enable(dev, 0);

	return ret;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;

	UNUSED(cmd_data);

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	dpio_destroy(dpio);

	sys_remove_handle(FSL_MOD_DPIO, 1, device_get_id(dev));
	dpio_deallocate(dpio);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	struct dpio_attr attr = { 0 };
	int err;

	dpio = device_get_priv(dev);
	CHECK_COND_RETVAL(dpio, -ENODEV);

	err = dpio_get_attributes(dpio, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.version.major = DPIO_V0_API_VER_MAJOR;
	attr.version.minor = DPIO_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPIO_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	struct dpio_attr attr = { 0 };
	int err;

	dpio = device_get_priv(dev);
	CHECK_COND_RETVAL(dpio, -ENODEV);

	err = dpio_get_attributes(dpio, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPIO_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	int en;
	int err;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	err = dpio_is_enabled(dpio, &en);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPIO_RSP_IS_ENABLED(cmd_data, en);
	}

	return err;
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	DPIO_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dpio_set_irq(dpio, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpio *dpio;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	return dpio_set_irq(dpio, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpio_get_irq(dpio, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPIO_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpio *dpio;
	int err;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	err = dpio_get_irq(dpio, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;

	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t irq_index;
	uint8_t en;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, en);

	return dpio_set_irq_enable(dpio, irq_index, en);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t irq_index;
	uint8_t en;
	int err;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpio_get_irq_enable(dpio, irq_index, &en);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPIO_RSP_GET_IRQ_ENABLE(cmd_data, en);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t irq_index;
	uint32_t mask;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpio_set_irq_mask(dpio, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpio_get_irq_mask(dpio, irq_index, &mask);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPIO_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpio_get_irq_status(dpio, irq_index, &status);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPIO_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t irq_index;
	uint32_t status;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpio_clear_irq_status(dpio, irq_index, status);
}

static int set_stashing_destination(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t sdest;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_SET_STASHING_DEST(cmd_data, sdest);

	return dpio_set_stashing_destination(dpio, sdest);
}

static int get_stashing_destination(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t sdest;
	int err;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	err = dpio_get_stashing_destination(dpio, &sdest);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPIO_RSP_GET_STASHING_DEST(cmd_data, sdest);

	return 0;
}

static int set_stashing_destination_source(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t ss;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_SET_STASHING_DEST_SOURCE(cmd_data, ss);

	return dpio_set_stashing_destination_source(dpio, ss>0);
}

static int get_stashing_destination_source(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t ss;
	int err;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	err = dpio_get_stashing_destination_source(dpio, &ss);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPIO_RSP_GET_STASHING_DEST_SOURCE(cmd_data, ss);

	return 0;
}

static int set_stashing_destination_target(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	uint8_t core_id;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_SET_STASHING_DEST_TARGET(cmd_data, core_id);

	return dpio_set_stashing_destination_target(dpio, core_id);
}

static int add_static_dequeue_channel(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	int dpcon_id;
	uint8_t channel_index;
	int err;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_ADD_STATIC_DEQUEUE_CHANNEL(cmd_data, dpcon_id);

	err = dpio_add_static_dequeue_channel(dpio, dpcon_id, &channel_index);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPIO_RSP_ADD_STATIC_DEQUEUE_CHANNEL(cmd_data, channel_index);

	return 0;
}

static int remove_static_dequeue_channel(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpio *dpio;
	int dpcon_id;

	dpio = device_get_priv(dev);
	if (!dpio)
		return -ENODEV;

	/* Read parameters from portal */
	DPIO_CMD_REMOVE_STATIC_DEQUEUE_CHANNEL(cmd_data, dpcon_id);

	return dpio_remove_static_dequeue_channel(dpio, dpcon_id);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPIO_VER_MAJOR;
    uint32_t minor = DPIO_VER_MINOR;

    DPIO_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int dpio_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpio_open on DPIO %d\n", device_get_id(dev));

	return 0;
}

static int dpio_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpio_close on DPIO %d\n", device_get_id(dev));

	return 0;
}

static int dpio_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev,
			struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPIO_CMD_CODE_CREATE, init, "dpio_init", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_ENABLE, enable, "dpio_enable", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_DISABLE, disable, "dpio_disable", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_RESET, reset, "dpio_reset", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_DESTROY, destroy, "dpio_destroy", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_GET_ATTR, get_attributes_v0, "dpio_get_attributes", DPIO_CMD_V0 },
			{ DPIO_CMD_CODE_IS_ENABLED, is_enabled, "dpio_is_enabled", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_SET_IRQ, set_irq, "dpio_set_irq", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_GET_IRQ, get_irq, "dpio_get_irq", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpio_set_irq_enable", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpio_get_irq_enable", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpio_set_irq_mask", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpio_get_irq_mask", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpio_get_irq_status", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpio_clear_irq_status", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_SET_STASHING_DEST, set_stashing_destination, "dpio_set_stashing_destination", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_GET_STASHING_DEST, get_stashing_destination, "dpio_get_stashing_destination", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_ADD_STATIC_DEQUEUE_CHANNEL, add_static_dequeue_channel, "dpio_add_static_dequeue_channel", DPIO_CMD_VER_BASE },
			{ DPIO_CMD_CODE_REMOVE_STATIC_DEQUEUE_CHANNEL, remove_static_dequeue_channel, "dpio_remove_static_dequeue_channel", DPIO_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPIO_CMD_CODE_GET_API_VERSION, get_api_version, "dpio_get_api_version", DPIO_CMD_V1 },
			{ DPIO_CMD_CODE_GET_ATTR, get_attributes_v1, "dpio_get_attributes", DPIO_CMD_V1 },
			{ DPIO_CMD_CODE_SET_STASHING_DEST_SOURCE, set_stashing_destination_source, "dpio_set_stashing_destination_source", DPIO_CMD_V1 },
			{ DPIO_CMD_CODE_GET_STASHING_DEST_SOURCE, get_stashing_destination_source, "dpio_get_stashing_destination_source", DPIO_CMD_V1 },
			{ DPIO_CMD_CODE_SET_STASHING_DEST_TARGET, set_stashing_destination_target, "dpio_set_stashing_destination_target", DPIO_CMD_V1 },
	  };

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
			if (cmd == DPIO_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPIO %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev,
							cmd_data);
		}

	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}

static int dpio_probe_cb(void *lo, int node_off)
{
	int err = 0;
	struct dpio_cfg dpio_cfg;
	struct dpio_cfg *cfg = &dpio_cfg;
	int dpio_id;
	char *enum_str;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	uint64_t val;
	int destroy = 0;

	memset(cfg, 0, sizeof(struct dpio_cfg));

	enum_str = (char *)fdt_getprop(lo, node_off, "channel_mode", NULL);
	if (enum_str) {
		if (!strcmp(enum_str, "DPIO_NO_CHANNEL"))
			cfg->channel_mode = DPIO_NO_CHANNEL;
		else if (!strcmp(enum_str, "DPIO_LOCAL_CHANNEL"))
			cfg->channel_mode = DPIO_LOCAL_CHANNEL;
		else {
			pr_err("DPIO cdan_mode invalid value\n");
			return EDOM;
		}
	}
	getprop_val(lo, node_off, "num_priorities", 0, 0, &val);
	cfg->num_priorities = (uint8_t)val;
	err = (uint16_t)get_node_id(lo, node_off, &dpio_id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(resman, "dpio", (uint16_t)dpio_id, NO_PORTAL_ID,
			DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPIO %.4x\n", dpio_id);
	DPIO_LO_CREATE(cmd_data, cfg);
	/* create object */
	err = dpio_ctrl_cb(dev, DPIO_CMD_VER_BASE, DPIO_CMD_CODE_CREATE,
			NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpio", NO_PORTAL_ID, destroy);

	return err;
}

static char *dpio_match[] = { "fsl,dpio", "dpio" };

static int dpio_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}

	dev = resman_open_dev(resman, "dpio", (uint16_t)id, NO_PORTAL_ID, 0, NULL);
	if (!dev) {
		pr_err("Can't open DPIO 0x%.4x\n", id);
		return -ENODEV;
	}

        err |= dpio_ctrl_cb(dev, DPIO_CMD_VER_BASE, DPIO_CMD_CODE_DESTROY,
                              NO_PORTAL_ID, NULL);
	err |= resman_close_dev(resman, dev, "dpio", NO_PORTAL_ID, 0);

	return err;
}

int dpio_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	int err;

	pr_info("Executing dpio_drv_init...\n");

	dtc_params.num_compats = ARRAY_SIZE(dpio_match);
	dtc_params.compatibles = dpio_match;
	dtc_params.f_prob_module = dpio_probe_cb;
	dtc_params.f_remove_module = dpio_remove_cb;
	sys_dtc_register_module(&dtc_params);

	cmdif_ops.open_cb = dpio_open_cb;
	cmdif_ops.close_cb = dpio_close_cb;
	cmdif_ops.ctrl_cb = dpio_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPIO, &cmdif_ops);
	strcpy(dev_type_param.device_type, "dpio");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPIO_MAX_IRQ_NUM;
	if ((qbman_block_get_version() & 0xFFFF0000) < QMAN_REV_5000)
		dev_type_param.region_count = 2;
	else
		dev_type_param.region_count = 3;
	dev_type_param.ver_major = DPIO_VER_MAJOR;
	dev_type_param.ver_minor = DPIO_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;
	dev_type_param.region_types[0] = DPRC_REGION_TYPE_QMAN_CE;
	dev_type_param.region_types[1] = DPRC_REGION_TYPE_QMAN_CI;
	dev_type_param.region_types[2] = DPRC_REGION_TYPE_QMAN_MB;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);
	err = resman_register_device_operation(resman, "dpio",
						&dev_type_param);
	return err;
}
