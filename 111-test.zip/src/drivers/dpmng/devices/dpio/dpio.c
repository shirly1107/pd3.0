/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpio.c

 @Description   library implementation

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "fsl_platform.h"
#include "drivers/fsl_qbman_ctrl.h"
#include "drivers/fsl_qbman_portal_ex.h"

#include "fsl_resman.h"
#include "fsl_dpmng_mc.h"
#include "fsl_dpcon_mc.h"

#include "dpio.h"

static int check_dpio_cfg(const struct dpio *dpio, const struct dpio_cfg *cfg)
{
	CHECK_COND_RETVAL(dpio, -EINVAL);
	CHECK_COND_RETVAL(cfg, -EINVAL);

	if ((cfg->channel_mode != DPIO_NO_CHANNEL)
		&& !((cfg->num_priorities >= 1) &&
		(cfg->num_priorities <= QMAN_CHANNEL_WQ_PRIO_NUM))) {
		pr_err("ID[%d]: num_priorities must be between 1-%d\n",
				dpio->id,
				QMAN_CHANNEL_WQ_PRIO_NUM);
		return -EINVAL;
	}

	return 0;
}

static void config_swp_post_auth(struct dpio *dpio)
{
	CHECK_COND_RET(dpio);

	qbman_block_set_swp_icid(dpio->qbman, dpio->swp_desc.swportal_id,
					dpio->amq.icid);
	qbman_block_set_swp_iobypass(dpio->qbman, dpio->swp_desc.swportal_id,
					dpio->amq.bmt);
	qbman_block_set_swp_va(dpio->qbman, dpio->swp_desc.swportal_id,
				dpio->amq.va);
	qbman_block_set_swp_sdest(dpio->qbman, dpio->swp_desc.swportal_id, 0);
	if ((qbman_block_get_version() & 0xFFFF0000) >= QMAN_REV_5000)
		qbman_block_set_swp_ss(dpio->qbman, dpio->swp_desc.swportal_id, 1);
	qbman_block_set_swp_isolated(dpio->qbman, dpio->swp_desc.swportal_id,
					!dpio->amq.bdi);
}

static void resources_authorization(struct dpio *dpio)
{
	CHECK_COND_RET(dpio);

	if (dpio->authorized)
		return;

	dpio->authorized = 1;

	config_swp_post_auth(dpio);
}

static void resources_deauthorization(struct dpio *dpio)
{
	CHECK_COND_RET(dpio);

	if (!dpio->authorized)
		return;

	dpio->authorized = 0;
	dpio->amq.icid = (uint16_t)-1;
}

static void dpio_set_mc_info(struct dpio *dpio,
	const struct dpmng_dev_cfg *dev_cfg)
{
	dpio->id = dev_cfg->id;
	CHECK_COND_RET(dev_cfg->device);
	dpio->device = dev_cfg->device;
	dpio->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dpio->dpmng);
	dpio->qbman = sys_get_unique_handle(FSL_MOD_QBMAN);
	CHECK_COND_RET(dpio->qbman);
}

int dpio_init(struct dpio *dpio,
	const struct dpio_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
	int err, i;

	dpio_set_mc_info(dpio, dev_cfg);

	if ((err = check_dpio_cfg(dpio, cfg)) != 0) {
		pr_err("ID[%d]: check_dpio_cfg failed\n", dpio->id);
		return err;
	}

	dpio->channel_mode = cfg->channel_mode;
	dpio->num_priorities = cfg->num_priorities;

	/* SW-Portal */
	if ((err = allocate_resource(dpio->device, "swp", 1, 1, 0,
					&dpio->swp_desc.swportal_id, "SWP-id"))
		!= 0)
		return err;

	dpio->swp_desc.qbman_id = 0;
	err = sys_get_desc(
		SOC_MODULE_QBMAN_PORTAL,
		(SOC_DB_QBMAN_PORTAL_DESC_ID
			| SOC_DB_QBMAN_PORTAL_DESC_QBMAN_ID),
		&dpio->swp_desc, NULL);
	CHECK_COND_RETVAL(err == 0, err);

	for (i = 0; i < DPIO_NUM_STATIC_CHANNELS; i++)
		dpio->static_channel_ids[i] = DPIO_INVALID_STATIC_CHANNEL;

	if (dpio->channel_mode == DPIO_LOCAL_CHANNEL) {
		if (dpio->num_priorities <= 2) {
			/* First try to allocate 2WQ channel.
			 * if not available try 8WQ channel */
			/* 2WQ-CHANNEL-ID */
			if ((err = allocate_resource(
				dpio->device, "swpch.2wq", 1, 1, 0,
				&dpio->notification_ch_id, "2WQ-CH-id"))
				!= 0) {
				pr_err("Ignore above error message, continue with 8WQ channel allocation...\n");
				/* 8WQ-CHANNEL-ID */
				if ((err = allocate_resource(
					dpio->device, "swpch.8wq", 1, 1, 0,
					&dpio->notification_ch_id, "8WQ-CH-id"))
					!= 0)
					return err;
			}
		} else {
			/* 8WQ-CHANNEL-ID */
			if ((err = allocate_resource(
				dpio->device, "swpch.8wq", 1, 1, 0,
				&dpio->notification_ch_id, "8WQ-CH-id"))
				!= 0)
				return err;
		}

		qbman_block_set_swp_channel(
			dpio->qbman, dpio->swp_desc.swportal_id, 0, 1,
			(uint16_t)dpio->notification_ch_id);

		dpio->static_channel_ids[0] =
			(uint16_t)dpio->notification_ch_id;
	}

	dpio->amq.icid = (uint16_t)-1;

	/* init irq 0 to SWP irq type */
	mc_init_irq(&(dpio->irqs[0]), MC_IRQ_TYPE_SWP);
	/* init irqs to MSI irq type */
	for (i = 1; i < DPIO_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpio->irqs[i]), MC_IRQ_TYPE_MSI);

	dpio_set_dev_ctx(dpio, &dev_cfg->ctx);

	return 0;
}

struct dpio *dpio_allocate(void)
{
	struct dpio *dpio;

	dpio = (struct dpio *)fsl_xmalloc(sizeof(struct dpio), 0,
						CORE_CACHELINE_SIZE);
	if (dpio)
		memset(dpio, 0, sizeof(struct dpio));
	return dpio;
}

void dpio_deallocate(struct dpio *dpio)
{
	fsl_xfree(dpio);
}

int dpio_destroy(struct dpio *dpio)
{
	int err = dpio_reset(dpio, 0);

	if (err) {
		pr_err("dpio_reset failed on DPIO%d\n", dpio->id);
		return err;
	}

	resources_deauthorization(dpio);

	return resman_unbind_all(dpio->device);
}

void dpio_enable(struct dpio *dpio)
{
	qbman_block_set_swp_enabled(dpio->qbman, dpio->swp_desc.swportal_id,
					1);
	dpio->enabled = 1;
}

int dpio_disable(struct dpio *dpio)
{
	qbman_block_set_swp_enabled(dpio->qbman, dpio->swp_desc.swportal_id,
					0);

	dpio->enabled = 0;

	return 0;
}

int dpio_is_enabled(struct dpio *dpio, int *en)
{
	*en = dpio->enabled;

	return 0;
}

int dpio_reset(struct dpio *dpio, int clear_channel)
{
	int i, ret;

	pr_info("reseting DPIO[%d], SWP[%d] ... \n",
			dpio->id, dpio->swp_desc.swportal_id);
	if (clear_channel && dpio->enabled && dpio->notification_ch_id > 0)
		dpmng_clear_channel((uint32_t)dpio->notification_ch_id);

	dpio_disable(dpio);

	ret = qbman_block_reset_swp(dpio->qbman, dpio->swp_desc.swportal_id);
	if (ret) {
		pr_err("qbman_block_reset_swp on SWP %d\n",
				dpio->swp_desc.swportal_id);
		return ret;
	}

	for (i = 0; i < DPIO_NUM_STATIC_CHANNELS; i++)
		dpio->static_channel_ids[i] = DPIO_INVALID_STATIC_CHANNEL;

	if (dpio->channel_mode == DPIO_LOCAL_CHANNEL) {
		qbman_block_set_swp_channel(
			dpio->qbman, dpio->swp_desc.swportal_id, 0, 1,
			(uint16_t)dpio->notification_ch_id);
		dpio->static_channel_ids[0] =
			(uint16_t)dpio->notification_ch_id;
	}

	config_swp_post_auth(dpio);

	return ret;
}

int dpio_get_attributes(struct dpio *dpio, struct dpio_attr *attributes)
{
	int err;
	struct qbman_desc qbman_desc;

	memset(&qbman_desc, 0, sizeof(struct qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, NULL);
	CHECK_COND_RETVAL(err == 0, err);

	attributes->id = dpio->id;
	attributes->qbman_portal_id = (uint16_t)dpio->swp_desc.swportal_id;
	attributes->qbman_portal_ce_offset = (uint64_t)(
		dpio->swp_desc.paddr_cena - qbman_desc.portals_paddr);
	attributes->qbman_portal_ci_offset = (uint64_t)(
		dpio->swp_desc.paddr_cinh - qbman_desc.portals_paddr);
	attributes->channel_mode = dpio->channel_mode;
	attributes->num_priorities = dpio->num_priorities;
	attributes->clk = qbman_desc.clk;
	attributes->qbman_version = qbman_block_get_version();

	return 0;
}

int dpio_set_stashing_destination(struct dpio *dpio, uint8_t sdest)
{
	qbman_block_set_swp_sdest(dpio->qbman, dpio->swp_desc.swportal_id,
					sdest);

	return 0;
}

int dpio_set_stashing_destination_target(struct dpio *dpio, uint8_t core_id)
{
	struct qbman_desc qbman_desc;
	int err, iter = 0;
        err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
                                &qbman_desc, &iter);
        if (err)
                return -ENODEV;

	qbman_block_set_swp_sdest(dpio->qbman, dpio->swp_desc.swportal_id,
				  qbman_desc.sdest_core_index[core_id].sdest);

	return 0;
}

int dpio_get_stashing_destination(struct dpio *dpio, uint8_t *sdest)
{
	qbman_block_get_swp_sdest(dpio->qbman, dpio->swp_desc.swportal_id,
					sdest);

	return 0;
}

int dpio_set_stashing_destination_source(struct dpio *dpio, uint8_t ss)
{
	if ((qbman_block_get_version() & 0xFFFF0000) >= QMAN_REV_5000)
		qbman_block_set_swp_ss(dpio->qbman, dpio->swp_desc.swportal_id, ss);
	else
		pr_warn("dpio_set_stashing_destination_source has no effect on this platform.\n");

	return 0;
}

int dpio_get_stashing_destination_source(struct dpio *dpio, uint8_t *ss)
{
	if ((qbman_block_get_version() & 0xFFFF0000) >= QMAN_REV_5000)
		qbman_block_get_swp_ss(dpio->qbman, dpio->swp_desc.swportal_id, ss);
	else
		*ss = 0;

	return 0;
}

int dpio_add_static_dequeue_channel(struct dpio *dpio,
	int dpcon_id,
	uint8_t *channel_index)
{
	struct dpcon *dpcon;
	int i;

	dpcon = sys_get_handle(FSL_MOD_DPCON, 1, dpcon_id);
	if (!dpcon) {
		pr_err("ID[%d]: dpcon_id is invalid\n", dpio->id);
		return -EINVAL;
	}

	if (dpcon_is_cdan_enabled(dpcon)) {
		pr_err("ID[%d]: this DPCON is set with notification (CDAN)\n", dpio->id);
		return -EINVAL;
	}

	for (i = 0; i < DPIO_NUM_STATIC_CHANNELS; i++)
		if (dpio->static_channel_ids[i] == DPIO_INVALID_STATIC_CHANNEL)
			break;
	if (i == DPIO_NUM_STATIC_CHANNELS) {
		pr_err("ID[%d]: All static channels are used\n", dpio->id);
		return -ENOSPC;
	}

	dpcon_set_static_dequeue(dpcon, 1);
	*channel_index = (uint8_t)i;
	dpio->static_channel_ids[i] = dpcon_get_channel_id(dpcon);
	qbman_block_set_swp_channel(dpio->qbman, dpio->swp_desc.swportal_id,
					*channel_index, 1,
					dpio->static_channel_ids[i]);

	return 0;
}

int dpio_remove_static_dequeue_channel(struct dpio *dpio, int dpcon_id)
{
	struct dpcon *dpcon;
	uint16_t channel_id;
	int i;

	dpcon = sys_get_handle(FSL_MOD_DPCON, 1, dpcon_id);
	CHECK_COND_RETVAL(dpcon, -EINVAL, "ID[%d]: dpcon_id is invalid\n", dpio->id);

	channel_id = dpcon_get_channel_id(dpcon);

	for (i = 0; i < DPIO_NUM_STATIC_CHANNELS; i++)
		if (dpio->static_channel_ids[i] == channel_id)
			break;
	if (i == DPIO_NUM_STATIC_CHANNELS) {
		pr_err("ID[%d]: dpcon_id %d wasn't found\n", dpio->id, dpcon_id);
		return -ENAVAIL;
	}

	qbman_block_set_swp_channel(dpio->qbman, dpio->swp_desc.swportal_id,
					(uint8_t)i, 0, channel_id);
	dpio->static_channel_ids[i] = DPIO_INVALID_STATIC_CHANNEL;
	dpcon_set_static_dequeue(dpcon, 0);

	return 0;
}

int dpio_set_dev_ctx(struct dpio *dpio, const struct dpmng_dev_ctx *dev_ctx)
{
	if (memcmp(&dpio->amq, &(dev_ctx->amq), sizeof(struct dpmng_amq))
		!= 0) {
		CHECK_COND_RETVAL(!dpio->enabled, -EINVAL);
		resources_deauthorization(dpio);

		dpio->amq = dev_ctx->amq;
		dpio->amq.bdi = (dev_ctx->type == DPMNG_CTX_TYPE_GPP) ? 0 : 1;

		resources_authorization(dpio);
	}

	return 0;
}

int dpio_get_destwq(struct dpio *dpio, uint8_t priority, uint16_t *destwq)
{
	if (!dpio_is_priority_in_range(dpio, priority))
		return -EINVAL;

	*destwq = (uint16_t)(dpio->notification_ch_id << 3 | priority);

	return 0;
}

/* return '1' for in-range and '0' for not in-range */
int dpio_is_priority_in_range(struct dpio *dpio, uint8_t priority)
{
	if (dpio->channel_mode == DPIO_NO_CHANNEL) {
		pr_err("ID[%d]: Not applicable for this dpio\n", dpio->id);
		return 0;
	}

	if (priority >= dpio->num_priorities) {
		pr_err("ID[%d]: priority not in range, should be smaller than %d\n", dpio->id, dpio->num_priorities);
		return 0;
	}

	return 1;
}

int dpio_set_irq(struct dpio *dpio,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg)

{
	int err = 0;

	if (irq_index >= DPIO_MAX_IRQ_NUM) {
		pr_err("irq_index exceeds the maximum number of IRQs");
		return -EINVAL;
	}

	if (irq_index == DPIO_IRQ_SWP_INDEX) {
		err = qbman_block_set_msi_address(
				dpio->qbman,
				dpio->swp_desc.swportal_id,
				(uint32_t)(irq_cfg->addr >> 32),
				(uint32_t)irq_cfg->addr);
		CHECK_COND_RETVAL(err == 0, err);

		qbman_block_set_swp_msi_data(dpio->qbman,
						dpio->swp_desc.swportal_id,
						(uint16_t)irq_cfg->val);
	}

	mc_set_irq(&(dpio->irqs[irq_index]), irq_cfg);
	return 0;
}

int dpio_get_irq(struct dpio *dpio,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg)
{
	int err;

	if (irq_index >= DPIO_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPIO_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq(&(dpio->irqs[irq_index]), irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpio_set_irq_enable(struct dpio *dpio, uint8_t irq_index, uint8_t en)
{
	int err;

	if (irq_index >= DPIO_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPIO_MAX_IRQ_NUM);
		return -EINVAL;
	}

	if (irq_index == DPIO_IRQ_SWP_INDEX) {
		pr_err("SWP interrupt state must be managed through SWP\n");
		return -ENOTSUP;
	}

	err = mc_set_irq_enable(&(dpio->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpio_get_irq_enable(struct dpio *dpio, uint8_t irq_index, uint8_t *en)
{
	int err;

	if (irq_index >= DPIO_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPIO_MAX_IRQ_NUM);
		return -EINVAL;
	}

	if (irq_index == DPIO_IRQ_SWP_INDEX) {
		pr_err("SWP interrupt state must be managed through SWP\n");
		return -ENOTSUP;
	}

	err = mc_get_irq_enable(&(dpio->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpio_set_irq_mask(struct dpio *dpio, uint8_t irq_index, uint32_t mask)
{
	int err;

	if (irq_index >= DPIO_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPIO_MAX_IRQ_NUM);
		return -EINVAL;
	}

	if (irq_index == DPIO_IRQ_SWP_INDEX) {
		pr_err("SWP interrupt state must be managed through SWP\n");
		return -ENOTSUP;
	}

	err = mc_set_irq_mask(&(dpio->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpio_get_irq_mask(struct dpio *dpio, uint8_t irq_index, uint32_t *mask)
{
	int err;

	if (irq_index >= DPIO_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPIO_MAX_IRQ_NUM);
		return -EINVAL;
	}

	if (irq_index == DPIO_IRQ_SWP_INDEX) {
		pr_err("SWP interrupt state must be managed through SWP\n");
		return -ENOTSUP;
	}

	err = mc_get_irq_mask(&(dpio->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpio_get_irq_status(struct dpio *dpio, uint8_t irq_index, uint32_t *status)
{
	int err;

	if (irq_index >= DPIO_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPIO_MAX_IRQ_NUM);
		return -EINVAL;
	}

	if (irq_index == DPIO_IRQ_SWP_INDEX) {
		pr_err("SWP interrupt state must be managed through SWP\n");
		return -ENOTSUP;
	}

	err = mc_get_irq_status(&(dpio->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpio_clear_irq_status(struct dpio *dpio,
	uint8_t irq_index,
	uint32_t status)
{
	int err;

	if (irq_index >= DPIO_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPIO_MAX_IRQ_NUM);
		return -EINVAL;
	}

	if (irq_index == DPIO_IRQ_SWP_INDEX) {
		pr_err("SWP interrupt state must be managed through SWP\n");
		return -ENOTSUP;
	}

	err = mc_clear_irq_status(&(dpio->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}
