/*
 * Copyright 2013-2021 NXP
 */

#ifndef _DPRC_CMD_H
#define _DPRC_CMD_H


/* default version for all dprc commands */
#define DPRC_CMD_VER_BASE							CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPRC_CMD_V0									CMDHDR_CMD_VERSION(0)
#define DPRC_CMD_V1									CMDHDR_CMD_VERSION(1)
#define DPRC_CMD_V2									CMDHDR_CMD_VERSION(2)
#define DPRC_CMD_V3									CMDHDR_CMD_VERSION(3)

/* Command IDs */
#define DPRC_CMD_CODE_CLOSE                        0x800
#define DPRC_CMD_CODE_OPEN                         0x805
#define DPRC_CMD_CODE_CREATE                       0x905
#define DPRC_CMD_CODE_GET_API_VERSION              0xa05

#define DPRC_CMD_CODE_GET_ATTR                     0x004
#define DPRC_CMD_CODE_RESET_CONT                   0x005

#define DPRC_CMD_CODE_SET_IRQ                      0x010
#define DPRC_CMD_CODE_GET_IRQ                      0x011
#define DPRC_CMD_CODE_SET_IRQ_ENABLE               0x012
#define DPRC_CMD_CODE_GET_IRQ_ENABLE               0x013
#define DPRC_CMD_CODE_SET_IRQ_MASK                 0x014
#define DPRC_CMD_CODE_GET_IRQ_MASK                 0x015
#define DPRC_CMD_CODE_GET_IRQ_STATUS               0x016
#define DPRC_CMD_CODE_CLEAR_IRQ_STATUS             0x017

#define DPRC_CMD_CODE_CREATE_CONT                  0x151
#define DPRC_CMD_CODE_DESTROY_CONT                 0x152
#define DPRC_CMD_CODE_GET_CONT_ID                  0x830
#define DPRC_CMD_CODE_SET_RES_QUOTA                0x155
#define DPRC_CMD_CODE_GET_RES_QUOTA                0x156
#define DPRC_CMD_CODE_ASSIGN                       0x157
#define DPRC_CMD_CODE_UNASSIGN                     0x158
#define DPRC_CMD_CODE_SET_LOCKED                   0x16B
#define DPRC_CMD_CODE_GET_OBJ_COUNT                0x159
#define DPRC_CMD_CODE_GET_OBJ                      0x15A
#define DPRC_CMD_CODE_GET_RES_COUNT                0x15B
#define DPRC_CMD_CODE_GET_RES_IDS                  0x15C
#define DPRC_CMD_CODE_GET_OBJ_REG                  0x15E
#define DPRC_CMD_CODE_SET_OBJ_IRQ                  0x15F
#define DPRC_CMD_CODE_GET_OBJ_IRQ                  0x160
#define DPRC_CMD_CODE_SET_OBJ_LABEL                0x161
#define DPRC_CMD_CODE_GET_OBJ_DESC                 0x162

#define DPRC_CMD_CODE_CONNECT                      0x167
#define DPRC_CMD_CODE_DISCONNECT                   0x168
#define DPRC_CMD_CODE_GET_POOL                     0x169
#define DPRC_CMD_CODE_GET_POOL_COUNT               0x16A

#define DPRC_CMD_CODE_GET_CONNECTION               0x16C
#define DPRC_CMD_CODE_GET_MEM                      0x16D
#define DPRC_CMD_ERRATA_WRIOP_RESET                0x170

#endif /* _FSL_DPRC_CMD_H */
