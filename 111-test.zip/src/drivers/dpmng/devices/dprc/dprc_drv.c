/*
 * Copyright 2013-2021 NXP
 */

/**************************************************************************//*
 @File          dprc_drv.c

 @Description   driver implementation

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "dpc.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "fsl_sys.h"
#include "kernel/device.h"
#include "fsl_event_pipe.h"
#include "fsl_resman.h"
#include "dplib/fsl_dprc_cmd.h"
#include "fsl_linkman.h"
#include "dtc/dtc.h"
#include "dpl.h"
#include "fsl_platform.h"
#include "drivers/fsl_mc.h"
#include "dpmng.h"
#include "resman.h"
#include "dprc_cmd.h"
#include "legacy_dprc_dplib.h"

#define ASSIGN	1
#define UNASSIGN 0

/* DPRC last supported API version */
#define DPRC_V0_API_VER_MAJOR				5
#define DPRC_V0_API_VER_MINOR				1

int dprc_drv_init(void);


static int str_to_fsl_module(char *str,
	enum fsl_module *linkman_type)
{
	int i;
	struct {
		enum fsl_module linkman_type;
		char *str;

	} map[] = { { FSL_MOD_DPNI, "dpni" }, { FSL_MOD_DPSW,
								"dpsw" },
			{ FSL_MOD_DPDMUX, "dpdmux" }, {
					FSL_MOD_DPMAC, "dpmac" },
			{ FSL_MOD_DPLAG, "dplag" }, {
					FSL_MOD_DPCI, "dpci" } };

	for (i = 0; i < ARRAY_SIZE(map); i++)
		if (!strcmp(str, map[i].str)) {
			*linkman_type = map[i].linkman_type;
			return 0;
		}

	pr_err("invalid link type: %s\n", str);
	return -EINVAL;
}

static int fsl_module_to_str(char *str,
	enum fsl_module linkman_type)
{
	int i;
	struct {
		enum fsl_module linkman_type;
		char *str;

	} map[] = {
	            { FSL_MOD_DPNI, "dpni" }, 
	            { FSL_MOD_DPSW, "dpsw" },
	            { FSL_MOD_DPDMUX, "dpdmux" }, 
	            { FSL_MOD_DPMAC, "dpmac" },
	            { FSL_MOD_DPLAG, "dplag" }, 
	            { FSL_MOD_DPCI, "dpci" } };

	for (i = 0; i < ARRAY_SIZE(map); i++)
		if (map[i].linkman_type == linkman_type) {
			strcpy(str, map[i].str);
			return 0;
		}

	pr_err("invalid link type: %s\n", str);
	return -EINVAL;
}

static uint64_t get_options(void *lo, int node_off)
{
	char *opt_str;
	int total_len;
	int len;
	int i = 0;
	uint64_t options = 0;
	struct {
		char *opt_str;
		uint64_t options;
	} map[] = {

	{ "DPRC_CFG_OPT_SPAWN_ALLOWED", DPRC_CFG_OPT_SPAWN_ALLOWED },
	{ "DPRC_CFG_OPT_ALLOC_ALLOWED", DPRC_CFG_OPT_ALLOC_ALLOWED },
	{ "DPRC_CFG_OPT_OBJ_CREATE_ALLOWED", DPRC_CFG_OPT_OBJ_CREATE_ALLOWED },
	{ "DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED", DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED },
	{ "DPRC_CFG_OPT_AIOP", DPRC_CFG_OPT_AIOP },
	{ "DPRC_CFG_OPT_IRQ_CFG_ALLOWED", DPRC_CFG_OPT_IRQ_CFG_ALLOWED},
	{ "DPRC_CFG_OPT_PL_ALLOWED", DPRC_CFG_OPT_PL_ALLOWED},
	};

	opt_str = (char *)fdt_getprop(lo, node_off, "options", &total_len);
	if (opt_str && (int)(*opt_str) != 0) {
		while (total_len > 0) {
			while (i < ARRAY_SIZE(map)
				&& strcmp(opt_str, map[i].opt_str))
				i++;
			if (i < ARRAY_SIZE(map)
				&& !strcmp(opt_str, map[i].opt_str))
				options |= map[i].options;
			else 
				pr_warn("'%s' option for DPRC is not supported\n", opt_str);
			len = (int)strlen(opt_str) + 1;
			total_len -= len;
			opt_str = PTR_MOVE(opt_str, len );
			i = 0;
		}
	}

	return options;
}

static int get_container_id(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int container_id;
	int err;

	err = resman_get_container_id(portal_id, &container_id);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_CONTAINER_ID(cmd_data, container_id);
	}
	return err;
}

static int create_container_v1(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	struct dprc_cfg dprc_cfg = { 0 };
	struct dprc_cfg *cfg = &dprc_cfg;
	int child_container_id = RESMAN_NO_CONTAINER_ID;
	uint64_t child_portal_offset;
	int err;

	UNUSED(portal_id);

	DPRC_CMD_CREATE_CONTAINER(cmd_data, cfg);

	err = resman_create_container(dprc, cfg, &child_container_id,
					&child_portal_offset, 0);

	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_CREATE_CONTAINER(cmd_data, child_container_id,
		                          child_portal_offset);
	}
	return err;
}

static int create_container_v2(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	struct dprc_cfg dprc_cfg = { 0 };
	struct dprc_cfg *cfg = &dprc_cfg;
	int child_container_id = RESMAN_NO_CONTAINER_ID;
	uint64_t child_portal_offset;
	int err;

	UNUSED(portal_id);

	DPRC_CMD_CREATE_CONTAINER(cmd_data, cfg);

	/* V2 will not longer support DPRC_CFG_OPT_OBJ_CREATE_ALLOWED
	 * dprc_set_locked will include this feature
	 */
	cfg->options |= DPRC_CFG_OPT_OBJ_CREATE_ALLOWED;

	err = resman_create_container(dprc, cfg, &child_container_id,
					&child_portal_offset, 0);

	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_CREATE_CONTAINER(cmd_data, child_container_id,
		                          child_portal_offset);
	}
	return err;
}

static int destroy_container(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int child_container_id;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_DESTROY_CONTAINER(cmd_data, child_container_id);

	return resman_destroy_container(dprc, child_container_id);
}

static int set_quota(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int child_container_id;
	char type[STR_MAX_SIZE] = { 0 };
	uint16_t quota;
	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_SET_RES_QUOTA(cmd_data, child_container_id, type, quota);

	err = resman_set_quota(dprc, child_container_id, type, quota);
	return err;
}

static int get_quota(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int child_container_id;
	char type[STR_MAX_SIZE] = { 0 };
	uint16_t quota;
	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_GET_RES_QUOTA(cmd_data, child_container_id, type);

	err = resman_get_quota(dprc, child_container_id, type, &quota);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_RES_QUOTA(cmd_data, quota);
	}

	return err;
}

static int set_locked(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int child_container_id;
	uint8_t locked;

	/* Read parameters from portal */
	DPRC_CMD_SET_LOCKED(cmd_data, child_container_id, locked);

	return resman_set_locked(dprc, child_container_id, locked, portal_id);
}

static int reset_container_v1(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int child_container_id;

	/* Read parameters from portal */
	DPRC_CMD_RESET_CONTAINER_v1(cmd_data, child_container_id);

	return resman_reset_container(dprc, child_container_id, portal_id, 0);
}

static int reset_container_v2(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int child_container_id;
	uint32_t options = 0;

	/* Read parameters from portal */
	DPRC_CMD_RESET_CONTAINER(cmd_data, child_container_id, options);

	return resman_reset_container(dprc, child_container_id, portal_id, options);
}

static int assign(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int container_id;
	struct resman_res_req req;
	struct resman_res_req *resman_req = &req;
	int err;

	UNUSED(portal_id);

	memset(&req, 0, sizeof(struct resman_res_req));

	DPRC_CMD_ASSIGN(cmd_data, container_id, resman_req);

	err = resman_assign(dprc, container_id, &req, 0);

	return err;
}

static int unassign(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int child_container_id;
	struct resman_res_req req;
	struct resman_res_req *resman_req = &req;
	int err;

	UNUSED(portal_id);

	memset(&req, 0, sizeof(struct resman_res_req));

	/* Read parameters from portal */
	DPRC_CMD_UNASSIGN(cmd_data, child_container_id, resman_req);

	err = resman_unassign(dprc, child_container_id, &req);

	return err;
}

static int get_obj_count(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int obj_count;
	int err;

	UNUSED(portal_id);

	err = resman_get_obj_count(dprc, &obj_count);

	/* Read parameters from portal */
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_OBJ_COUNT(cmd_data, obj_count);
	}
	return err;
}

#ifdef TKT011436
static int errata_wriop_reset(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int err = 0;
	int dpmac_id = 0;
	uint32_t options = 0;

	UNUSED(portal_id);

	DPRC_CMD_WRIOP_RESET(cmd_data, dpmac_id, options);

	if(!options)
		options |= RESMAN_ERRATA_FORCE_WORKAROUND;

	if(dprc->container_id == ROOT_CONTAINER_ID)
		err = resman_errata_workaround(dpmac_id, options);
	else
		pr_warn("Command not allowed for container id = %d differet of root container id = %d\n",
				dprc->container_id, ROOT_CONTAINER_ID);

	return err;
}
#endif /* TKT011436 */

static int get_obj(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int obj_index;
	struct dprc_obj_desc dp_desc = { 0 };
	struct dprc_obj_desc *obj_desc = &dp_desc;
	int err = 0;

	UNUSED(portal_id);

	DPRC_CMD_GET_OBJ(cmd_data, obj_index);

	err = resman_get_obj_desc_by_index(dprc, obj_index, &dp_desc);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_OBJ(cmd_data, obj_desc);
	}

	return err;
}

static int get_obj_desc(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int obj_id;
	char obj_type[STR_MAX_SIZE] = { 0 };
	struct dprc_obj_desc dp_desc = { 0 };
	struct dprc_obj_desc *obj_desc = &dp_desc;
	int err = 0;

	UNUSED(portal_id);

	DPRC_CMD_GET_OBJ_DESC(cmd_data, obj_type, obj_id);

	err = resman_get_obj_desc(dprc, obj_type, obj_id, &dp_desc);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_OBJ_DESC(cmd_data, obj_desc);
	}

	return err;
}

static int get_res_count(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int res_count;
	char type[STR_MAX_SIZE] = { 0 };
	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_GET_RES_COUNT(cmd_data, type);

	err = resman_get_res_count(dprc, type, &res_count);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_RES_COUNT(cmd_data, res_count);
	}
	return err;
}

static int get_attributes_v0(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	struct resman_container_attributes attr = { 0 };
	int err;

	UNUSED(portal_id);

	err = resman_get_attributes(dprc, &attr);
	CHECK_COND_RETVAL(!err, err);

	/* resman_get_attributes returns V1 version of DPRC.
	 * overwrite major and minor with V0 values
	 */
	attr.version.major = DPRC_V0_API_VER_MAJOR;
	attr.version.minor = DPRC_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRC_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	struct resman_container_attributes attr = { 0 };
	int err;

	UNUSED(portal_id);

	err = resman_get_attributes(dprc, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRC_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int get_obj_region_common(struct dprc *dprc, struct mc_cmd_data *cmd_data,
		int portal_id, int version)
{
	char obj_type[STR_MAX_SIZE];
	int obj_id;
	uint8_t region_index;
	struct dprc_region_desc desc = { 0 };
	struct dprc_region_desc *region_desc = &desc;
	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_GET_OBJ_REGION(cmd_data, obj_type, obj_id, region_index);

	err = resman_get_obj_region(dprc, obj_type, obj_id, region_index,
					&desc, (version >= 3) ? 1 : 0);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		if (version < 2)
			DPRC_RSP_GET_OBJ_REGION_V1(cmd_data, region_desc);
		else
			DPRC_RSP_GET_OBJ_REGION(cmd_data, region_desc);
	}
	return err;
}

static int get_obj_region_v1(struct dprc *dprc, struct mc_cmd_data *cmd_data,
		int portal_id)
{
	return get_obj_region_common(dprc, cmd_data, portal_id, 1);
}

static int get_obj_region_v2(struct dprc *dprc, struct mc_cmd_data *cmd_data,
		int portal_id)
{
	return get_obj_region_common(dprc, cmd_data, portal_id, 2);
}

static int get_obj_region_v3(struct dprc *dprc, struct mc_cmd_data *cmd_data,
		int portal_id)
{
	return get_obj_region_common(dprc, cmd_data, portal_id, 3);
}

static int set_irq(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	/* Read parameters from portal */
	DPRC_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	return resman_set_irq(dprc, irq_index, portal_id, irq_cfg);
}

static int get_irq(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_GET_IRQ(cmd_data, irq_index);

	err = resman_get_irq(dprc, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRC_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int set_irq_enable(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	uint8_t irq_index;
	uint8_t en;

	/* Read parameters from portal */
	DPRC_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, en);

	return resman_set_irq_enable(dprc, irq_index, en, portal_id);
}

static int get_irq_enable(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	uint8_t irq_index;
	uint8_t en;
	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = resman_get_irq_enable(dprc, irq_index, &en);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRC_RSP_GET_IRQ_ENABLE(cmd_data, en);

	return 0;
}

static int set_irq_mask(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	uint8_t irq_index;
	uint32_t mask;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return resman_set_irq_mask(dprc, irq_index, mask);
}

static int get_irq_mask(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	uint8_t irq_index;
	uint32_t mask;
	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = resman_get_irq_mask(dprc, irq_index, &mask);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRC_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	uint8_t irq_index;
	uint32_t status;
	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = resman_get_irq_status(dprc, irq_index, &status);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRC_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	uint8_t irq_index;
	uint32_t status;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return resman_clear_irq_status(dprc, irq_index, status);
}

static int get_res_ids(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	char type[STR_MAX_SIZE] = { 0 };
	struct dprc_res_ids_range_desc desc = { 0 };
	struct dprc_res_ids_range_desc *range_desc = &desc;
	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_GET_RES_IDS(cmd_data, range_desc, type);

	err = resman_get_res_ids(dprc, type, &desc);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_RES_IDS(cmd_data, range_desc);
	}

	return err;
}

static int get_pool(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int pool_index;
	char type[STR_MAX_SIZE] = { 0 };
	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_GET_POOL(cmd_data, pool_index);

	err = resman_get_pool(dprc, pool_index, type);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_POOL(cmd_data, type);
	}

	return err;
}

static int get_pool_count(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int pool_count;
	int err;

	UNUSED(portal_id);

	err = resman_get_pool_count(dprc, &pool_count);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_POOL_COUNT(cmd_data, pool_count);
	}
	return err;
}

static int get_api_version(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
    uint32_t major = DPRC_VER_MAJOR;
    uint32_t minor = DPRC_VER_MINOR;

    DPRC_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int set_obj_irq(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	uint8_t irq_index;
	int obj_id;
	char obj_type[STR_MAX_SIZE] = { 0 };
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	/* Read parameters from portal */
	DPRC_CMD_SET_OBJ_IRQ(cmd_data, obj_type, obj_id, irq_index, irq_cfg);

	return resman_set_obj_irq(dprc, obj_type, obj_id, irq_index, portal_id, irq_cfg);
}

static int get_obj_irq(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	uint8_t irq_index;
	int obj_id;
	char obj_type[STR_MAX_SIZE] = { 0 };
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	int err;

	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_GET_OBJ_IRQ(cmd_data, obj_type, obj_id, irq_index);

	err = resman_get_obj_irq(dprc, obj_type, obj_id, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRC_RSP_GET_OBJ_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int set_obj_label(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	char label[STR_MAX_SIZE] = { 0 };
	char obj_type[STR_MAX_SIZE] = { 0 };
	int obj_id;
	UNUSED(portal_id);

	/* Read parameters from portal */
	DPRC_CMD_SET_OBJ_LABEL(cmd_data, obj_type, obj_id, label);

	return resman_set_obj_label(dprc, obj_type, obj_id, label);
}
#if 0 /* linkman */
/* linkman commands */
static int define_to_linkman_type(char *str,
	enum linkman_dev_type *linkman_type)
{
	int i;
	struct {
		enum linkman_dev_type linkman_type;
		char *str;

	} map[] = { { LINKMAN_DEV_TYPE_DPNI, "dpni" }, { LINKMAN_DEV_TYPE_DPSW,
								"dpsw" },
			{ LINKMAN_DEV_TYPE_DPDMUX, "dpdmux" }, {
				LINKMAN_DEV_TYPE_DPMAC, "dpmac" },
			{ LINKMAN_DEV_TYPE_DPLAG, "dplag" }, {
				LINKMAN_DEV_TYPE_DPCI, "dpci" } };

	for (i = 0; i < ARRAY_SIZE(map); i++)
		if (!strcmp(str, map[i].str)) {
			*linkman_type = map[i].linkman_type;
			return 0;
		}

	pr_err("invalid link type: %s\n", str);
	return -EINVAL;
}

static int connect(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	struct dprc_endpoint end1 = { 0 };
	struct dprc_endpoint *endpoint1 = &end1;
	struct dprc_endpoint end2 = { 0 };
	struct dprc_endpoint *endpoint2 = &end2;
	struct linkman_link_cfg dev_cfg, peer_cfg;
	struct linkman *linkman;
	struct dprc *e1_dprc, *e2_dprc;
	struct resman_container_attributes attributes = { 0 };
	struct resman_container_attributes *attr = &attributes;
	int err = 0;

	memset(&dev_cfg, 0, sizeof(struct linkman_link_cfg));
	memset(&peer_cfg, 0, sizeof(struct linkman_link_cfg));

	DPRC_CMD_CONNECT(cmd_data, endpoint1, endpoint2);

	e1_dprc = e2_dprc = dprc;
	resman_get_attributes(dprc, &attributes);
	if (!(attributes.options & DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED)) {
		pr_err("The policy DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED  is not set for the dprc");
		return -EPERM;
	}
	if (attributes.options & DPRC_CFG_OPT_AIOP) {
		if (strcmp(endpoint1->type, "dpci") == 0)
			e1_dprc = NULL;
		if (strcmp(endpoint2->type, "dpci") == 0)
			e2_dprc = NULL;
	}

	if ((resman_find_device_at_descendant(e1_dprc, endpoint1->type,
						endpoint1->id, NULL)
		== NULL)
		|| (resman_find_device_at_descendant(e2_dprc, endpoint2->type,
							endpoint2->id, NULL)
			== NULL)) {
		pr_err("Object doesn't found\n");
		return -EPERM;
	}
	/* Self Connector */
	dev_cfg.dev_id = (uint16_t)endpoint1->id;
	dev_cfg.dev_if_id = (uint16_t)endpoint1->interface_id;
	err = define_to_linkman_type(endpoint1->type, &(dev_cfg.dev_type));
	if (err)
		return err;

	peer_cfg.dev_id = (uint16_t)endpoint2->id;
	peer_cfg.dev_if_id = (uint16_t)endpoint2->interface_id;
	err = define_to_linkman_type(endpoint2->type, &(peer_cfg.dev_type));
	if (err)
		return err;

	/* Start parameters exchange state machine */
	dev_cfg.state = LINKMAN_LINK_PARAM_EXCHANGE;

	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	if (!linkman) {
		pr_err("No linkman found\n");
		return -ENODEV;
	}

	err = linkman_link_change(linkman, /* Link manager handle */
					&dev_cfg, /* self information */
					&peer_cfg); /* Peer information */
	if (err != 0) {
		pr_err("linkman_link_change (exchange param phase) in dprc_connect failed\n");
		return err;
	}

	dev_cfg.state = LINKMAN_LINK_UP;
	dev_cfg.options = 0;
	peer_cfg.options = 0;

	linkman_link_change(linkman, /* Link manager handle */
				&dev_cfg, /* self information */
				&peer_cfg); /* Peer information */

	/* No need to check the return value because there is a possibility
	 * that the linkman will return a failure and it's OK
	 */

	return 0;
}

static int disconnect(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	struct dprc_endpoint end = { 0 };
	struct dprc_endpoint *endpoint = &end;
	struct linkman_link_cfg dev_cfg, peer_cfg;
	struct linkman *linkman;
	int err = 0;

	memset(&dev_cfg, 0, sizeof(struct linkman_link_cfg));
	memset(&peer_cfg, 0, sizeof(struct linkman_link_cfg));

	DPRC_CMD_DISCONNECT(cmd_data, endpoint);

	dev_cfg.dev_id = (uint16_t)endpoint->id;
	dev_cfg.state = LINKMAN_LINK_DOWN;
	dev_cfg.dev_if_id = (uint16_t)endpoint->interface_id;
	err = define_to_linkman_type(endpoint->type, &(dev_cfg.dev_type));
	if (err)
		return err;

	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	if (!linkman) {
		pr_err("No linkman found\n");
		return -ENODEV;
	}

	err = linkman_link_change(linkman, /* Link manager handle */
					&dev_cfg, /* self information */
					&peer_cfg); /* Peer information */
	if (err != 0) {
		pr_err("linkman_link_change (down phase) in dprc_disconnect failed\n");
		return err;
	}

	dev_cfg.state = LINKMAN_LINK_DETACH;
	err = linkman_link_change(linkman, /* Link manager handle */
					&dev_cfg, /* self information */
					&peer_cfg); /* Peer information */
	if (err != 0) {
		pr_err("linkman_link_change (detach phase) in dprc_disconnect failed\n");
		return err;
	}

	return err;
}
#endif /* 0 */

#if 1 /* linkman */
/* linkman commands */
static int define_to_linkman_type(char *str,
	enum fsl_module *type)
{
	int i;
	struct {
		//enum linkman_dev_type linkman_type;
		enum fsl_module	type;
		char *str;

	} map[] = { { FSL_MOD_DPNI, "dpni" }, { FSL_MOD_DPSW,
								"dpsw" },
			{ FSL_MOD_DPDMUX, "dpdmux" }, {
			                                  FSL_MOD_DPMAC, "dpmac" },
			{ FSL_MOD_DPLAG, "dplag" }, {
			                                FSL_MOD_DPCI, "dpci" } };

	for (i = 0; i < ARRAY_SIZE(map); i++)
		if (!strcmp(str, map[i].str)) {
			*type = map[i].type;
			return 0;
		}

	pr_err("invalid link type: %s\n", str);
	return -EINVAL;
}

static int connect(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	struct dprc_endpoint end1 = { 0 };
	struct dprc_endpoint *endpoint1 = &end1;
	struct dprc_endpoint end2 = { 0 };
	struct dprc_endpoint *endpoint2 = &end2;
	struct dprc_connection_cfg connection_cfg = { 0 };
	struct dprc_connection_cfg *cfg = &connection_cfg;
	struct linkman *linkman;
	struct dprc *e1_dprc, *e2_dprc, *contain_dprc;
	int err = 0;
	struct linkman_endpoint dev_ep, peer_ep;
	struct resman_container_attributes attributes = { 0 };
	struct resman *resman;
	struct linkman_control control;
	struct linkman_connection_attr	attr;
	
	UNUSED(portal_id);

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	memset(&dev_ep, 0, sizeof(struct linkman_endpoint));
	memset(&peer_ep, 0, sizeof(struct linkman_endpoint));
	memset(&control, 0, sizeof(struct linkman_control));

	DPRC_CMD_CONNECT(cmd_data, endpoint1, endpoint2, cfg);

	if (!strcmp(endpoint1->type, "dpni") && endpoint1->if_id) {
		pr_warn("Nonzero interface id received for dpni.%d\n", endpoint1->id);
		endpoint1->if_id = 0;
	}
	if (!strcmp(endpoint2->type, "dpni") && endpoint2->if_id) {
		pr_warn("Nonzero interface id received for dpni.%d\n", endpoint2->id);
		endpoint2->if_id = 0;
	}
	
	e1_dprc = e2_dprc = dprc;
	resman_get_attributes(dprc, &attributes);
	if (!(attributes.options & DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED)) {
		pr_err("The policy DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED  is not set for the dprc");
		return -EPERM;
	}
	if (attributes.options & DPRC_CFG_OPT_AIOP) {
		if (strcmp(endpoint1->type, "dpci") == 0)
			e1_dprc = NULL;
		if (strcmp(endpoint2->type, "dpci") == 0)
			e2_dprc = NULL;
	}

	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	if (!linkman) {
		pr_err("No linkman found\n");
		return -ENODEV;
	}

	/* Verify whether or not the objects are linked already */
	dev_ep.id = (uint16_t)endpoint1->id;
	dev_ep.if_id = (uint16_t)endpoint1->if_id;
	err = define_to_linkman_type(endpoint1->type, &(dev_ep.type));
	if (err) {
		pr_err("Unknown Object type: %s\n", endpoint1->type);
		return err;
	}

	err = linkman_get_connection(
		linkman, 		/* Context */
		&dev_ep, 		/* endpoint 1 */
		&peer_ep,       /* endpoint 2 */
		&attr);
	if (err == 0 && attr.state != LINKMAN_STATE_IDLE) {
		char tmp_str[32];
		fsl_module_to_str(tmp_str, dev_ep.type);
		pr_err("Object %s.%d if %d is already connected\n", tmp_str, dev_ep.id, dev_ep.if_id);
		return -EINVAL;
	}

	dev_ep.id = (uint16_t)endpoint2->id;
	dev_ep.if_id = (uint16_t)endpoint2->if_id;
	err = define_to_linkman_type(endpoint2->type, &(dev_ep.type));
	if (err) {
		pr_err("Unknown Object type: %s\n", endpoint2->type);
		return err;
	}
	
	err = linkman_get_connection(
		linkman, 		/* Context */
		&dev_ep, 		/* endpoint 1 */
		&peer_ep,       /* endpoint 2 */
		&attr);
	if (err == 0 && attr.state != LINKMAN_STATE_IDLE) {
		char tmp_str[32];
		fsl_module_to_str(tmp_str, dev_ep.type);
		pr_err("Object %s.%d if %d is already connected\n", tmp_str, dev_ep.id, dev_ep.if_id);
		return -EINVAL;
	}

	/* Self Connector */
	dev_ep.id = (uint16_t)endpoint1->id;
	dev_ep.if_id = (uint16_t)endpoint1->if_id;
	err = define_to_linkman_type(endpoint1->type, &(dev_ep.type));
	if (err)
		return err;

	peer_ep.id = (uint16_t)endpoint2->id;
	peer_ep.if_id = (uint16_t)endpoint2->if_id;
	err = define_to_linkman_type(endpoint2->type, &(peer_ep.type));
	if (err)
		return err;

	if ((resman_find_device_at_descendant(resman, e1_dprc, endpoint1->type,
						endpoint1->id, &contain_dprc)
		== NULL)
		|| (resman_find_device_at_descendant(resman, e2_dprc, endpoint2->type,
							endpoint2->id, &contain_dprc)
			== NULL)) {
		pr_err("Object wasn't found\n");
		return -EPERM;
	}
	/* Update control information */
	control.event = LINKMAN_EVENT_CONNECT;
	control.committed_rate = cfg->committed_rate;
	/* default value */
	if (!cfg->max_rate)
		/* max_rate is only used for virtual connections so should be ok
		 * to use the rate of the recycle port of the platform */
		cfg->max_rate = (uint32_t)soc_db_get_recycle_port_bandwidth();
	control.max_rate = cfg->max_rate;

	err = linkman_set_connection(
		linkman, 
		&control,
		&dev_ep,
		&peer_ep);
	if (err != 0) {
		pr_err("linkman_set_connection (connect event) failed\n");
		return err;
	}

	/* Self Connector */
	dev_ep.id = (uint16_t)endpoint1->id;
	dev_ep.if_id = (uint16_t)endpoint1->if_id;
	err = define_to_linkman_type(endpoint1->type, &(dev_ep.type));
	if (err)
		return err;

	peer_ep.id = (uint16_t)endpoint2->id;
	peer_ep.if_id = (uint16_t)endpoint2->if_id;
	err = define_to_linkman_type(endpoint2->type, &(peer_ep.type));
	if (err)
		return err;

	control.event = LINKMAN_EVENT_LINKUP;
	control.cmd = LINKMAN_CMD_LINKUP_FROM_CONNECT;
	linkman_set_connection(
		linkman,
		&control,
		&dev_ep,
		&peer_ep);

	/* No need to check the return value because there is a possibility
	 * that the linkman will return a failure and it's OK
	 */

	return 0;
}

static int disconnect(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	struct dprc_endpoint end = { 0 };
	struct dprc_endpoint *endpoint = &end;
//	struct linkman_link_cfg dev_cfg, peer_cfg;
//	struct linkman *linkman;
	struct linkman_endpoint dev_ep, peer_ep;
	struct linkman *linkman;
	struct linkman_control control;
	int err = 0;

	UNUSED(portal_id);

	memset(&dev_ep, 0, sizeof(struct linkman_endpoint));
	memset(&peer_ep, 0, sizeof(struct linkman_endpoint));
	memset(&control, 0, sizeof(struct linkman_control));

	DPRC_CMD_DISCONNECT(cmd_data, endpoint);

	control.event = LINKMAN_EVENT_LINKDOWN;
	control.cmd = LINKMAN_CMD_LINKDOWN_FROM_DISCONNECT;

	dev_ep.id = (uint16_t)endpoint->id;
	dev_ep.if_id = (uint16_t)endpoint->if_id;
	err = define_to_linkman_type(endpoint->type, &(dev_ep.type));
	if (err)
		return err;

	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	if (!linkman) {
		pr_err("No linkman found\n");
		return -ENODEV;
	}

	err = linkman_set_connection(linkman, 
	                &control,
			&dev_ep,
			&peer_ep);
	if (err != 0) {
		pr_err("linkman_set_connection (linkdown event) failed\n");
		return err;
	}

	control.event = LINKMAN_EVENT_DISCONNECT;
	err = linkman_set_connection(linkman, 
	                &control,
			&dev_ep,
			&peer_ep);
	if (err != 0) {
		pr_err("linkman_set_connection (disconnect event) failed\n");
		return err;
	}

	return err;
}
#endif /* 1 */

static int get_connection(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	struct dprc_endpoint endpoint1 = { 0 };
	struct dprc_endpoint endpoint2 = { 0 };
	struct linkman_endpoint linkman_ep1 = { 0 };
	struct linkman_endpoint linkman_ep2 = { 0 };
	struct linkman *linkman;
	struct linkman_connection_attr	attr;
	int err, state = -1;

	UNUSED(portal_id);

	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	if (!linkman) {
		pr_err("No linkman found\n");
		return -ENODEV;
	}

	/* Read parameters from portal */
	DPRC_CMD_GET_CONNECTION(cmd_data, (&endpoint1));

	/* Convert parameters to linkman */
	linkman_ep1.id = (uint16_t)endpoint1.id;
	linkman_ep1.if_id = (uint16_t)endpoint1.if_id;
	err = str_to_fsl_module(endpoint1.type, &(linkman_ep1.type));
	if (err)
		return err;

	err = linkman_get_connection(
		linkman, 		/* Context */
		&linkman_ep1, 		/* endpoint 1 */
		&linkman_ep2,           /* endpoint 2 */
		&attr);		
	if (err == 0) {
		if (attr.state != LINKMAN_STATE_IDLE) {
			endpoint2.id = linkman_ep2.id;
			endpoint2.if_id = linkman_ep2.if_id;
			err = fsl_module_to_str(endpoint2.type,
			                           linkman_ep2.type);
			if (err)
				return err;

		}
		else
			memset(&endpoint2, 0x0, sizeof(struct dprc_endpoint));

		switch(attr.state) 
		{
			case LINKMAN_STATE_IDLE:
				state = -1;
				break;
			case LINKMAN_STATE_CANDIDATE:
				state = 0;				
				break;
			case LINKMAN_STATE_CONNECTED:
				state = 0;				
				break;
			case LINKMAN_STATE_NEGOTIATION:
				state = 0;								
				break;
			case LINKMAN_STATE_LINKUP:
				state = 1;				
				break;
			default:		
				break;
		}
		
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_CONNECTION(cmd_data, (&endpoint2), state);
	}
	return err;
}

static int dprc_open_cb(void *obj, int portal_id)
{
	int id = RESMAN_NO_CONTAINER_ID;
	if (obj != 0)
	{
		id = ((struct dprc*)obj)->container_id;
	}
	pr_info("Handling command: dprc_open for DPRC %d on portal id %d\n", id, portal_id);
	return 0;
}

static int dprc_close_cb(void *obj, int portal_id, uint32_t token)
{
	int id = RESMAN_NO_CONTAINER_ID;
	UNUSED(token);
	if (obj != 0)
	{
		id = ((struct dprc*)obj)->container_id;
	}
	pr_info("Handling command: dprc_close for DPRC %d on portal id %d\n", id, portal_id);
	return 0;
}

static int dprc_open_cb_dummy(void *obj, int portal_id)
{
	UNUSED(obj);
	return 0;
}

static int dprc_close_cb_dummy(void *obj, int portal_id, uint32_t token)
{
	UNUSED(obj);
	UNUSED(token);
	return 0;
}

static int get_mem_avail_list(struct dprc *dprc, struct mc_cmd_data *cmd_data, int portal_id)
{
	int err = 0;
	uint16_t page;
	uint8_t partition_id, flags;
	struct dprc_mem mem = {0};
	struct dprc_mem *mem_list = &mem;

	UNUSED(portal_id);

	DPRC_CMD_GET_MEM(cmd_data, partition_id, flags, page);

	err = resman_get_mem_avail_list(page, flags, partition_id, &mem);
	if(!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRC_RSP_GET_MEM(cmd_data, mem_list);
	}

	return err;
}

static int dprc_ctrl_cb(void *obj, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int container_id = RESMAN_NO_CONTAINER_ID;
	int i;
	struct {
		int code;
		int (*function)(struct dprc *dprc,
			struct mc_cmd_data *cmd_data,
			int portal_id);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = { 
			{ DPRC_CMD_CODE_GET_CONT_ID, get_container_id, "dprc_get_container_id", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_CREATE_CONT, create_container_v1, "dprc_create_container", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_DESTROY_CONT, destroy_container, "dprc_destroy_container", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_SET_RES_QUOTA, set_quota, "dprc_set_res_quota", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_RES_QUOTA, get_quota, "dprc_get_res_quota", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_RESET_CONT, reset_container_v1, "dprc_reset_container", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_ASSIGN, assign, "dprc_assign", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_UNASSIGN, unassign, "dprc_unassign", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_OBJ_COUNT, get_obj_count, "dprc_get_obj_count", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_OBJ, get_obj, "dprc_get_obj", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_OBJ_DESC, get_obj_desc, "dprc_get_obj_desc", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_RES_COUNT, get_res_count, "dprc_get_res_count", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_RES_IDS, get_res_ids, "dprc_get_res_ids", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_ATTR, get_attributes_v0, "dprc_get_attributes", DPRC_CMD_V0 },
			{ DPRC_CMD_CODE_GET_OBJ_REG, get_obj_region_v1, "dprc_get_obj_region", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_SET_OBJ_IRQ, set_obj_irq, "dprc_set_obj_irq", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_OBJ_IRQ, get_obj_irq, "dprc_get_obj_irq", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_SET_OBJ_LABEL, set_obj_label, "dprc_set_obj_label", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_SET_IRQ, set_irq, "dprc_set_irq", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_IRQ, get_irq, "dprc_get_irq", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dprc_set_irq_enable", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dprc_get_irq_enable", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dprc_set_irq_mask", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dprc_get_irq_mask", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dprc_get_irq_status", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dprc_clear_irq_status", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_CONNECT, connect, "dprc_connect", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_DISCONNECT, disconnect, "dprc_disconnect", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_CONNECTION, get_connection, "dprc_get_connection", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_POOL, get_pool, "dprc_get_pool", DPRC_CMD_VER_BASE },
			{ DPRC_CMD_CODE_GET_POOL_COUNT, get_pool_count, "dprc_get_pool_count", DPRC_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPRC_CMD_CODE_GET_API_VERSION, get_api_version, "dprc_get_api_version", DPRC_CMD_V1 },
			{ DPRC_CMD_CODE_GET_ATTR, get_attributes_v1, "dprc_get_attributes", DPRC_CMD_V1 },
			{ DPRC_CMD_CODE_GET_OBJ_REG, get_obj_region_v2, "dprc_get_obj_region", DPRC_CMD_V2 },
			{ DPRC_CMD_CODE_SET_LOCKED, set_locked, "dprc_set_locked", DPRC_CMD_V1 },
			{ DPRC_CMD_CODE_CREATE_CONT, create_container_v2, "dprc_create_container", DPRC_CMD_V2 },
			{ DPRC_CMD_CODE_RESET_CONT, reset_container_v2, "dprc_reset_container", DPRC_CMD_V2 },
			{ DPRC_CMD_CODE_GET_OBJ_REG, get_obj_region_v3, "dprc_get_obj_region", DPRC_CMD_V3 },
			{ DPRC_CMD_CODE_GET_MEM, get_mem_avail_list, "dprc_get_peb_info", DPRC_CMD_VER_BASE },
#ifdef TKT011436 
			{ DPRC_CMD_ERRATA_WRIOP_RESET, errata_wriop_reset, "dprc_errata_wriop_reset", DPRC_CMD_VER_BASE },
#endif /* TKT011436 */

		};


	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
			if (cmd == DPRC_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
			{
				if (obj != 0)
					container_id = ((struct dprc *)obj)->container_id;
				pr_info("Handling command: %s for DPRC %d on portal id %d\n", map_commands[i].cmd_str, container_id, portal_id);
			}
			return map_commands[i].function(obj, cmd_data, portal_id);
		}

	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}

static int get_object_preferences(void *lo, int node_off, char *type, int *id)
{
	char tokens[STR_MAX_SIZE] = { 0 };
	char obj_name[STR_MAX_SIZE] = { 0 };
	char *tmp_str;

	tmp_str = (char *)fdt_getprop(lo, node_off, "obj_name", NULL);
	CHECK_COND_RETVAL(tmp_str, -ENAVAIL);

	strncpy(obj_name, tmp_str, sizeof(obj_name) - 1);
	obj_name[strlen(tmp_str)] = '\0';

	tmp_str = strtok(obj_name, "@");
	if (!tmp_str) {
		pr_err("obj_name %s is not defined in the format of <name>@<id>\n", obj_name);
		return -EINVAL;
	}

	*id = atoi(PTR_MOVE(tmp_str,strlen(tmp_str)+1));

	strncpy(tokens, tmp_str, sizeof(tokens) - 1);
	tokens[strlen(tmp_str)] = '\0';
	strncpy(type, tokens, STR_MAX_SIZE - 1);
	type[strlen(tokens)] = '\0';
	return 0;
}

static int get_parent_id(void *lo, int node_off, int *id)
{
	int err = 0;
	char *tokens;
	char *parent;
	char orig[64];

	parent = (char *)fdt_getprop(lo, node_off, "parent", NULL);
	CHECK_COND_RETVAL(parent, -ENAVAIL);

	strncpy(orig, parent, sizeof(orig) - 1);
	orig[strlen(parent)] = '\0';
	if (!strcmp(orig, "none")) {
		*id = -1; //first container - no parent ID
		return 0;
	}

	tokens = strtok(orig, "@");
	if (!tokens)
		return -EINVAL;

	*id = atoi(PTR_MOVE(tokens,strlen(tokens)+1));

	return err;
}

static int lo_unbind_explicit(struct resman_res_req *res_req)
{
	struct device *mc_dev;
	int i;
	int err = 0;

	mc_dev = sys_get_unique_handle(FSL_MOD_MC);
	CHECK_COND_RETVAL(mc_dev, -ENODEV);

	if (res_req->options && DPRC_RES_REQ_OPT_EXPLICIT) {
		for (i = 0; i < res_req->num; i++) {
			err = resman_unbind(
				mc_dev, res_req->type,
				res_req->id_base_align + i);
			if (err)
				return err;
		}
	}
	return err;
}

static uint32_t get_res_options(void *lo, int node_off)
{
	char *opt_str;
	int total_len;
	int len;
	int i = 0;
	uint64_t options = 0;
	struct {
		char *opt_str;
		uint32_t options;
	} map[] = {

	{ "DPRC_RES_REQ_OPT_EXPLICIT", DPRC_RES_REQ_OPT_EXPLICIT },
			{ "DPRC_RES_REQ_OPT_ALIGNED",
					DPRC_RES_REQ_OPT_ALIGNED }};

	//check if user entered number instead of define
	getprop_val(lo, node_off, "options", 0, 0, &options);
	if (options > 3){ //options entered as define
		options = 0;
		opt_str = (char *)fdt_getprop(lo, node_off, "options", &total_len);
		if (opt_str && (int)(*opt_str) != 0) {
			while (total_len > 0) {
				while (i < ARRAY_SIZE(map)
					&& strcmp(opt_str, map[i].opt_str))
					i++;
				if (i < ARRAY_SIZE(map)
					&& !strcmp(opt_str, map[i].opt_str))
					options |= map[i].options;
				len = (int)strlen(opt_str) + 1;
				total_len -= len;
				opt_str = PTR_MOVE(opt_str, len );
				i = 0;
			}
		}
	}
	return (uint32_t)options;
}

static int lo_assign_resources(void *lo,
	int node_off,
	int container_id,
	int assign)
{
	struct dprc *dprc;
	int subnode_off;
	struct resman_res_req res_req;
	char *str;
	int err = 0;
	int resman_err;
	struct resman *resman;
	uint64_t val;

	memset(&res_req, 0, sizeof(struct resman_res_req));

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	subnode_off = fdt_first_subnode(lo, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND) {
		str = (char *)fdt_getprop(lo, subnode_off, "type", NULL);
		if (!str) {
			pr_err("dprc@%d - Resource type to assign is not defined\n", container_id);
			return -EINVAL;
		}
		strncpy(res_req.type, str, sizeof(res_req.type) - 1);
		if (getprop_val(lo, subnode_off, "num", 0, 0, &val)) {
			pr_err("dprc@%d - 'num' is a required field for %s resource request\n", container_id, str);
			return -EINVAL;
		}
		res_req.num = (uint32_t)val;
		getprop_val(lo, subnode_off, "id_base_align", 0, 0, &val);
		res_req.id_base_align = (int)val;
		res_req.options = get_res_options(lo, subnode_off);
		err = lo_unbind_explicit(&res_req);
		if (err)
			return err;

		if (assign) {
			dprc = resman_get_container(resman, container_id);
			if (!dprc){
				pr_err("Did not get container %d\n", container_id);
				return -EINVAL;
			}
			resman_err = resman_assign(dprc, container_id, &res_req, LAYOUT);
			if (resman_err) {
				pr_err("dprc@%d - failed to assign resource type %s\n", container_id, res_req.type);
				return resman_err;
			}
			pr_info("%d resources of type %s assigned to container %d\n", res_req.num, str, container_id);
		} else {
			dprc = resman_get_container(resman, container_id);
			if (!dprc){
				pr_err("Did not get container %d\n", container_id);
				return -EINVAL;
			}
			resman_err = resman_unassign(
				dprc,
				container_id, &res_req);
			CHECK_COND_RETVAL(resman_err==0, resman_err, "Failed to unassign resource");
			pr_info("%d resources of type %s unassigned from container %d\n", res_req.num, str, container_id);
		}
		subnode_off = fdt_next_subnode(lo, subnode_off);
	}

	return err;
}

static int assign_dpmcp(struct resman *resman, int container_id, int obj_id, char *obj_type)
{
	struct dprc *dprc;
	struct resman_res_req res_req;
	int err;

	strcpy(res_req.type, "mcp");
	res_req.id_base_align = obj_id;
	res_req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	res_req.num = 1;
	err = lo_unbind_explicit(&res_req);
	CHECK_COND_RETVAL(!err, err);
	dprc = resman_get_container(resman, container_id);
	CHECK_COND_RETVAL(dprc, -ENODEV);
	err = resman_assign(dprc, container_id, &res_req, LAYOUT);
	if (err)
		return err;
	return 0;
}

static int get_obj_set_preferences(void *lo,
									int node_off,
									char *obj_type,
									int *len) 
{
	char *type;
	
	type = (char *)fdt_getprop(lo, node_off, "type", NULL);
	strncpy(obj_type, type, STR_MAX_SIZE - 1);
	obj_type[strlen(type)] = '\0';
	
	fdt_getprop(lo, node_off, "ids", len);	
	
	return 0;	
}

static int prepare_device_in_container(struct resman *resman, 
		char *obj_type, 
		int obj_id, 
		int container_id,
		int container_portal_id, 
		char *label, 
		int plugged)
{
	struct object *obj;
	struct dprc *dprc;
	struct resman_res_req res_req;
	int err;
	
	obj = resman_open_dev(resman, obj_type,
				(uint16_t)obj_id,
				container_portal_id,
				DPRC_CREATE_DEV_ONLY,
				label);
	if (!obj) {
		pr_err("dprc@%d - Can't create object %s@%d\n",
				container_id, obj_type, obj_id);
		return -ENAVAIL;
	}

	if(plugged) {
		res_req.num = 1;
		res_req.options = DPRC_RES_REQ_OPT_EXPLICIT |
			DPRC_RES_REQ_OPT_PLUGGED;
		strncpy(res_req.type, obj_type,
			sizeof(res_req.type) - 1);
		res_req.id_base_align = obj_id;
		dprc = resman_get_container(resman, container_id);
		CHECK_COND_RETVAL(dprc, -ENODEV);
		err = resman_assign(dprc,
			container_id, &res_req, LAYOUT);
		CHECK_COND_RETVAL(!err, err);
	}

	pr_info("Container %d prepared device for %s[%d] object\n", container_id, obj_type, obj_id);

	return 0;
}

static int lo_assign_objects(void *lo,
	int node_off,
	int container_id,
	int container_portal_id,
	int dtc_portal_req,
	int assign)
{
	int subnode_off;
	struct resman *resman;
	char obj_type[STR_MAX_SIZE] = { 0 };
	char subnode_name[STR_MAX_SIZE] = { 0 };
	int obj_id;
	uint64_t val;
	uint32_t val32;
	char *label;
	int num_ids;
	int plugged;
	int obj_set = 0;
	int i, len, err = 0;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);
	
	subnode_off = fdt_first_subnode(lo, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND) {
        get_node_name(lo, subnode_off, subnode_name);
		if (assign) {
            if ( strcmp(subnode_name, "obj_set")==0 ) {
            	err = get_obj_set_preferences(lo, subnode_off, obj_type, &num_ids);
            	obj_set = 1;
            } else {
				err = get_object_preferences(lo, subnode_off, obj_type, &obj_id);
				num_ids = 1;
				obj_set = 0;
            }
			if (err)
				return err;
			
        	for (i = 0; (4 * i) < num_ids; i++) {
        		if (obj_set) {
					getprop_array(lo, subnode_off, "ids", i, &val32);
					obj_id = (int)val32;
				}
				/* don't allow to create or prepare resman device in container
				if the object was not defined in 'objects' node. */
				if (!dpl_is_obj_defined(obj_type, obj_id)) {
					pr_warn("Object %s@%d not created in dprc@%d: "
						"no object definition found in the 'objects' node\n",
						obj_type, obj_id, container_id);
					continue;
				}

				if (!strcmp(obj_type, "dpseci") && dcfg_is_unavailable(DCFG_DEVDIS_SEC, NULL)) {
					pr_err("The module %s is not enabled for this platform!\n",
							obj_type);
					continue;
				}
				label = (char *)fdt_getprop(lo, subnode_off, "label", &len);
				if (len > STR_MAX_SIZE) {
					pr_err("label is limited to %d characters '%s' is too long\n", STR_MAX_SIZE);
				}
	
				if (strcmp(obj_type, "dpmcp") == 0) {
					err = assign_dpmcp(resman, container_id, obj_id, obj_type);
					if (err)
						return err;
				}
				
				/* assign as plugged (default) unless layout sets plugged = 0*/
				getprop_val(lo, subnode_off, "plugged", 0, 1,
							&val);
				plugged = (int)val;
				
				err = prepare_device_in_container(resman, obj_type, obj_id, container_id, container_portal_id, label, plugged);
				if (err)
					return err;
        	}
		}
		subnode_off = fdt_next_subnode(lo, subnode_off);
	}

	return err;
}

static int pool_probe_cb(void *lo, int node_off)
{
	struct resman *resman;
	int base_icid;
	uint32_t num;
	uint64_t val;

	if (getprop_val(lo, node_off, "num", 0, 0, &val)) {
		pr_err("'num' is a required field for layout icid-pool\n");
		return -EINVAL;
	}
	num = (uint32_t)val;
	if (getprop_val(lo, node_off, "base_icid", 0, 0, &val)) {
		pr_err("'base_icid' is a required field for layout icid-pool\n");
		return -EINVAL;
	}
	base_icid = (int)val;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}

	return resman_create_icid_pool(resman, base_icid, (int)num, 1);
}

static int assign_res_and_obj(void *lo, int node_off, int id, int portal_id)
{
	int subnode_off;
	const char *subnode_name;
	int dtc_portal_req = 1;
	int err = 0;

	if (portal_id == NO_PORTAL_ID)
		dtc_portal_req = 0;

	subnode_off = fdt_first_subnode(lo, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND) {
		subnode_name = fdt_get_name(lo, subnode_off, NULL);
		if (subnode_name && !strcmp(subnode_name, "resources")) {
			err = lo_assign_resources(lo, subnode_off, id, ASSIGN);
			if (err)
				return err;
		} else if (subnode_name && !strcmp(subnode_name, "objects")) {
			err |= lo_assign_objects(lo, subnode_off, id,
							portal_id,
							dtc_portal_req, ASSIGN);
			if (err)
				return err;
		}
		subnode_off = fdt_next_subnode(lo, subnode_off);
	}
	return err;
}

static int save_aiop_container_id(struct dprc_cfg *dprc_cfg, int id)
{
	struct dpmng *dpmng;

	if ((dprc_cfg->options & DPRC_CFG_OPT_AIOP) == DPRC_CFG_OPT_AIOP) {
		dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
		if (!dpmng){
			pr_err("Can't open dpmng for signing aiop_container_id\n");
			return -ENODEV;
		}
		dpmng->aiop_container_id = id;
	}
	return 0;
}

static int dprc_probe_cb(void *lo, int node_off)
{
	struct dprc_cfg dprc_cfg = { 0 };
	int id;
	int parent_id;
	struct dprc *parent_dprc = NULL;
	struct resman *resman;
	uint64_t paddr;
	int err = 0;
	int resman_err;
	uint64_t val;
	struct device *mc_dev;
	char *label_p;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);
	mc_dev = sys_get_unique_handle(FSL_MOD_MC);
	CHECK_COND_RETVAL(mc_dev, -ENODEV);

	/* create attributes from layout */
	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	getprop_val(lo, node_off, "icid", "DPRC_GET_ICID_FROM_POOL",
			DPRC_GET_ICID_FROM_POOL, &val);
	dprc_cfg.icid = (uint16_t)val;
	dprc_cfg.options = (uint64_t)get_options(lo, node_off);

	/* set label */
	label_p = (char *)fdt_getprop(lo, node_off, "label", NULL);
	if (label_p)
		strncpy(dprc_cfg.label, label_p, sizeof(dprc_cfg.label) - 1);

	err = save_aiop_container_id(&dprc_cfg, id);
	if (err)
		return err;

	getprop_val(lo, node_off, "portal_id", "DPRC_GET_PORTAL_ID_FROM_POOL",
			DPRC_GET_PORTAL_ID_FROM_POOL, &val);
	dprc_cfg.portal_id = (int)val;
	if (dprc_cfg.portal_id
		&& (dprc_cfg.portal_id != DPRC_GET_PORTAL_ID_FROM_POOL)) {
		err = resman_unbind(mc_dev, "mcp", dprc_cfg.portal_id);
		if (err)
			return err;
	}
	err = get_parent_id(lo, node_off, &parent_id);
	if (err)
		return err;

	if (parent_id != -1)
		parent_dprc = resman_get_container(resman, parent_id);

	resman_err = resman_create_container(parent_dprc, &dprc_cfg, &id,
						&paddr, LAYOUT);
	if (resman_err) {
		pr_err("failed to create dprc@%d\n", id);
		return resman_err;
	}

	pr_info("container %d created\n", id);

	/* assign objects and resources to container */
	err = assign_res_and_obj(lo, node_off, id, dprc_cfg.portal_id);


	return err;
}

static int dprc_remove_cb(void *lo, int node_off)
{
	int subnode_off;
	const char *subnode_name;
	struct dprc *parent_dprc = NULL;
	struct resman *resman;
	int id, parent_id;
	int portal_id;
	int err = 0;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	portal_id = (int)fdt_getprop(lo, node_off, "portal_id", NULL);
	subnode_off = fdt_first_subnode(lo, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND) {
		subnode_name = fdt_get_name(lo, subnode_off, NULL);
		if (subnode_name && !strcmp(subnode_name, "resources")) {
			err = lo_assign_resources(lo, subnode_off, id,
							UNASSIGN);
			if (err)
				return err;
		} else if (subnode_name && !strcmp(subnode_name, "objects")) {
			err = lo_assign_objects(lo, subnode_off, id, portal_id,
						0, UNASSIGN);
			if (err)
				return err;
		}
		subnode_off = fdt_next_subnode(lo, subnode_off);
	}

	err = get_parent_id(lo, node_off, &parent_id);
	if (err)
		return err;

	if (parent_id != -1)
		parent_dprc = resman_get_container(resman, parent_id);

	if (parent_dprc)
		err = resman_destroy_container(parent_dprc, id);

	return err;
}

static int pool_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	uint64_t base_icid;
	uint64_t num;

	getprop_val(lo, node_off, "num", 0, 0, &num);
	getprop_val(lo, node_off, "base_icid", 0, 0, &base_icid);

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);
	return resman_destroy_icid_pool(resman);
}

static char *dprc_match[] = { "fsl,dprc", "dprc" };
static char *pool_match[] = { "icid-pool", "icid_pool", "fsl,icid-pool" };

int dprc_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };

	pr_info("Executing dprc_drv_init...\n");

	dtc_params.num_compats = ARRAY_SIZE(dprc_match);
	dtc_params.compatibles = dprc_match;
	dtc_params.f_prob_module = dprc_probe_cb;
	dtc_params.f_remove_module = dprc_remove_cb;
	sys_dtc_register_module(&dtc_params);

	dtc_params.num_compats = ARRAY_SIZE(pool_match);
	dtc_params.compatibles = pool_match;
	dtc_params.f_prob_module = pool_probe_cb;
	dtc_params.f_remove_module = pool_remove_cb;
	sys_dtc_register_module(&dtc_params);

	cmdif_ops.open_cb = dprc_open_cb;
	cmdif_ops.close_cb = dprc_close_cb;
	cmdif_ops.ctrl_cb = dprc_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPRC, &cmdif_ops);

	cmdif_ops.open_cb = dprc_open_cb_dummy;
	cmdif_ops.close_cb = dprc_close_cb_dummy;
	cmdif_ops.ctrl_cb = dprc_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module((enum cmdif_module)0x30, &cmdif_ops);

	return 0;
}
