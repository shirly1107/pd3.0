/*
 * Copyright 2013-2020 NXP
 */

#ifndef _LEGACY_DPRC_DPLIB_H
#define _LEGACY_DPRC_DPLIB_H

/* 
 * File used to maintain compatibility with older version of dplib/flib
 * All previous version of dprc commands should be placed here
 */

/**********************************************/
/**********************************************/
/********* V0 version of dprc commands ******/
/**********************************************/
/**********************************************/

/*                cmd, param, offset, width, type, arg_name */
#define DPRC_RSP_GET_ATTRIBUTES_V0(cmd, attr) \
do { \
        MC_RSP_OP(cmd, 0,  0, 32, int,      (attr)->container_id); \
        MC_RSP_OP(cmd, 0, 32, 16, uint16_t, (attr)->icid); \
        MC_RSP_OP(cmd, 1,  0, 32, uint32_t, (attr)->options);\
        MC_RSP_OP(cmd, 1, 32, 32, int,      (attr)->portal_id); \
        MC_RSP_OP(cmd, 2,  0, 16, uint16_t, (attr)->version.major);\
        MC_RSP_OP(cmd, 2, 16, 16, uint16_t, (attr)->version.minor);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPRC_RSP_GET_OBJ_REGION_V1(cmd, region_desc) \
do { \
	MC_RSP_OP(cmd, 1, 0,  32, uint32_t, region_desc->base_offset);\
	MC_RSP_OP(cmd, 2, 0,  32, uint32_t, region_desc->size); \
	MC_RSP_OP(cmd, 2, 32, 4,  enum dprc_region_type, region_desc->type);\
	MC_RSP_OP(cmd, 3, 0,  32, uint32_t, region_desc->flags);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPRC_CMD_RESET_CONTAINER_v1(cmd, child_container_id) \
	MC_CMD_OP(cmd, 0, 0,  32, int,	    child_container_id)

#endif /* _LEGACY_DPRC_DPLIB_H */
