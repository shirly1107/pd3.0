/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPBP_CMD_H
#define _DPBP_CMD_H

/* default version for all dpbp commands */
#define DPPB_CMD_VER_BASE						CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPBP_CMD_V0								CMDHDR_CMD_VERSION(0)
#define DPBP_CMD_V1								CMDHDR_CMD_VERSION(1)
#define DPBP_CMD_V2								CMDHDR_CMD_VERSION(2)

/* Command IDs */
#define DPBP_CMD_CODE_CLOSE                     0x800
#define DPBP_CMD_CODE_OPEN                      0x804
#define DPBP_CMD_CODE_CREATE                    0x904
#define DPBP_CMD_CODE_DESTROY                   0x900
#define DPBP_CMD_CODE_GET_API_VERSION           0xa04

#define DPBP_CMD_CODE_ENABLE                    0x002
#define DPBP_CMD_CODE_DISABLE                   0x003
#define DPBP_CMD_CODE_GET_ATTR                  0x004
#define DPBP_CMD_CODE_RESET                     0x005
#define DPBP_CMD_CODE_IS_ENABLED                0x006

#define DPBP_CMD_CODE_SET_IRQ                   0x010
#define DPBP_CMD_CODE_GET_IRQ                   0x011
#define DPBP_CMD_CODE_SET_IRQ_ENABLE            0x012
#define DPBP_CMD_CODE_GET_IRQ_ENABLE            0x013
#define DPBP_CMD_CODE_SET_IRQ_MASK              0x014
#define DPBP_CMD_CODE_GET_IRQ_MASK              0x015
#define DPBP_CMD_CODE_GET_IRQ_STATUS            0x016
#define DPBP_CMD_CODE_CLEAR_IRQ_STATUS          0x017

#define DPBP_CMD_CODE_SET_NOTIFICATIONS         0x01b0
#define DPBP_CMD_CODE_GET_NOTIFICATIONS         0x01b1
#define DPBP_CMD_CODE_GET_FREE_BUFFERS_NUM      0x01b2

#endif /* _DPBP_CMD_H */
