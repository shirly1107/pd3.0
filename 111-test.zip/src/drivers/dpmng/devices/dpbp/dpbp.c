/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpbp.c

 @Description   library implementation

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_platform.h"
#include "fsl_resman.h"
#include "fsl_dpmac_mc.h"
#include "dpbp.h"

static int check_dpbp_cfg(const struct dpbp *dpbp, const struct dpbp_cfg *cfg)
{
	return 0;
}

static int config_bp_post_auth(struct dpbp *dpbp)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr bpdesc;
	int err, wae, tmp;

	dpmng_get_swportal(dpbp->dpmng, (void**)&sw_portal);
	err = qbman_bp_query(sw_portal, (uint32_t)dpbp->bpid, &bpdesc);
	dpmng_put_swportal(dpbp->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(err == 0, err, "ID[%d]: qbman_bp_query failed\n", dpbp->id);

	qbman_bp_attr_get_bdi(&bpdesc, &tmp, &tmp, &wae);
	qbman_bp_attr_set_bdi(&bpdesc, dpbp->amq.bdi, dpbp->amq.va, wae);
	qbman_bp_attr_set_vbpid(&bpdesc, dpbp->virt_bpid);
	qbman_bp_attr_set_icid(&bpdesc, dpbp->amq.icid, dpbp->amq.pl);

	dpmng_get_swportal(dpbp->dpmng, (void**)&sw_portal);
	err = qbman_bp_configure(sw_portal, (uint32_t)dpbp->bpid, &bpdesc);
	dpmng_put_swportal(dpbp->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(err == 0, err, "ID[%d]: qbman_bp_configure failed\n", dpbp->id);

	return 0;
}

static int resources_authorization(struct dpbp *dpbp)
{
	struct qbman_swp *sw_portal;
	int err;
#ifndef ERR009534
	int i = 0;
#endif /* !ERR009534 */

	CHECK_COND_RETVAL(dpbp, -EINVAL);

	if (dpbp->authorized)
		return 0;

	if (dpbp->amq.bdi)
		dpbp->virt_bpid = (uint32_t)dpbp->bpid;
	else {
#ifdef ERR009534
		/* WRIOP limitation in Rev1 where the VBPID = BPID */
		dpmng_get_swportal(dpbp->dpmng, (void**)&sw_portal);
		CHECK_COND_RETVAL(sw_portal, -ENODEV);
		dpbp->virt_bpid = (uint32_t)dpbp->bpid;
		err = qbman_auth_add(sw_portal, dpbp->amq.icid,
					qbman_auth_type_bpid, dpbp->virt_bpid,
					(uint32_t)dpbp->bpid,
					(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP));
		dpmng_put_swportal(dpbp->dpmng, (void*)sw_portal);
		CHECK_COND_RETVAL(err == 0, err, "qbman_auth_add() failed for BPID\n");
#else
		/* Due to WRIOP limitation where the VBPID[0-5] = BPID, we need to
		 loop till we found specific VBPID */
		dpmng_get_swportal(dpbp->dpmng, (void**)&sw_portal);
		CHECK_COND_RETVAL(sw_portal, -ENODEV);
		do {
			dpbp->virt_bpid = (uint32_t)(dpbp->bpid + 64 * i);
			err = qbman_auth_add(
				sw_portal, dpbp->amq.icid,
				qbman_auth_type_bpid, dpbp->virt_bpid,
				(uint32_t)dpbp->bpid,
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP));
			i++;
			/* we continue as long as we didn't succeeded to add a entry and we
			 * didn't reach the max value of virtual id */
		}while ((err == -EAGAIN)
			&& (dpbp->virt_bpid <= (0xFFFFFFFF - 64)));
		dpmng_put_swportal(dpbp->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("qbman_auth_add() failed for BPID\n");
			return err;
		}
#endif /* ERR009534 */
	}

	dpbp->authorized = 1;

	err = config_bp_post_auth(dpbp);
	CHECK_COND_RETVAL(err == 0, err, "ID[%d]: config_bp_post_auth failed\n", dpbp->id);

	return 0;
}

static int resources_deauthorization(struct dpbp *dpbp)
{
	struct qbman_swp *sw_portal;
	int err;

	CHECK_COND_RETVAL(dpbp, -EINVAL);

	if (!dpbp->authorized)
		return 0;

	dpmng_get_swportal(dpbp->dpmng, (void**)&sw_portal);
	err = resource_deauthorization(sw_portal, dpbp->amq.bdi,
					dpbp->amq.icid, qbman_auth_type_bpid,
					dpbp->virt_bpid,
					(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
					"BPID");
	dpmng_put_swportal(dpbp->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(err == 0, err);

	dpbp->authorized = 0;

	dpbp->amq.icid = (uint16_t)-1;

	return 0;
}

static void dpbp_set_mc_info(struct dpbp *dpbp,
	const struct dpmng_dev_cfg *dev_cfg)
{
	dpbp->id = dev_cfg->id;
	CHECK_COND_RET(dev_cfg->device);
	dpbp->device = dev_cfg->device;
	dpbp->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dpbp->dpmng);
}

int dpbp_init(struct dpbp *dpbp,
	const struct dpbp_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
	int i, err;

	dpbp_set_mc_info(dpbp, dev_cfg);

	if ((err = check_dpbp_cfg(dpbp, cfg)) != 0) {
		pr_err("check_dpbp_cfg failed\n");
		return err;
	}

	/* BPID */
	if ((err = allocate_resource(dpbp->device, "bp", 1, 1, 0, &dpbp->bpid,
					"BPID"))
		!= 0)
		return err;

	qbman_bp_attr_clear(&dpbp->bpdesc);

	dpbp->amq.icid = (uint16_t)-1;

	for (i = 0; i < DPBP_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpbp->irqs[i]), MC_IRQ_TYPE_MSI);

	dpbp_set_dev_ctx(dpbp, &dev_cfg->ctx);

	return 0;
}

struct dpbp * dpbp_allocate(void)
{
	struct dpbp *dpbp;

	dpbp = (struct dpbp *)fsl_xmalloc(sizeof(struct dpbp), 0,
						CORE_CACHELINE_SIZE);
	if (dpbp)
		memset(dpbp, 0, sizeof(struct dpbp));
	return dpbp;
}

void dpbp_deallocate(struct dpbp *dpbp)
{
	fsl_xfree(dpbp);
}

void dpbp_destroy(struct dpbp *dpbp)
{
	int err;

	dpbp_reset(dpbp);
	
	err = resources_deauthorization(dpbp);
	CHECK_COND_RET(err == 0);

	err = resman_unbind_all(dpbp->device);
	CHECK_COND_RET(err == 0);
}

void dpbp_enable(struct dpbp *dpbp)
{
	dpbp->enabled = 1;

}

int dpbp_disable(struct dpbp *dpbp)
{
	dpbp->enabled = 0;

	return 0;
}

int dpbp_is_enabled(struct dpbp *dpbp, int *en)
{
	*en = dpbp->enabled;

	return 0;
}

void dpbp_reset(struct dpbp *dpbp)
{
	struct qbman_swp *swp;
	struct dpbp_notification_cfg cfg = { 0 };
	uint64_t phy_addr;
	int ret;

	dpbp_disable(dpbp);

	/* Reset notification settings */
	dpbp_set_notifications(dpbp, &cfg);

	dpmng_get_swportal(dpbp->dpmng, (void**)&swp);
	CHECK_COND_RET(swp);
	do {
		/* qbman_swp_acquire fails if negative value was returned.
		 * On success it returns number of acquired buffers. */
		ret = qbman_swp_acquire(swp, (uint32_t)dpbp->bpid, &phy_addr,
					1);
	} while ((ret == -EBUSY) || (ret != 0));
	dpmng_put_swportal(dpbp->dpmng, (void*)swp);
}

int dpbp_get_attributes(struct dpbp *dpbp, struct dpbp_attr *attributes)
{
	attributes->id = dpbp->id;
	attributes->bpid = (uint16_t)dpbp->virt_bpid;

	return 0;
}

int dpbp_get_num_free_bufs(struct dpbp *dpbp, uint32_t *num_free_bufs)
{
	struct qbman_swp	*sw_portal;
	struct qbman_attr	bpdesc;
	int			err;

	dpmng_get_swportal(dpbp->dpmng, (void **)&sw_portal);
	err = qbman_bp_query(sw_portal, (uint32_t)dpbp->bpid, &bpdesc);
	if (!err)
		*num_free_bufs = qbman_bp_info_num_free_bufs(&bpdesc);

	return err;
}

int dpbp_set_notifications(struct dpbp *dpbp,
	struct dpbp_notification_cfg *cfg)
{
	struct qbman_swp *sw_portal;
	int err, tmp, bdi, va;

	if ((cfg->depletion_entry || cfg->surplus_entry) &&
	    !cfg->message_iova) {
		pr_err("ID[%d]: scn_iova MUST be given when <x>_entry <> '0'\n",
		       dpbp->id);
		return -EINVAL;
	}

	if (cfg->message_iova && !IS_ALIGNED(cfg->message_iova,16)) {
		pr_err("ID[%d]: scn_iova MUST be aligned to 16\n", dpbp->id);
		return -EINVAL;
	}

	qbman_bp_attr_get_bdi(&dpbp->bpdesc, &bdi, &va, &tmp);
	qbman_bp_attr_set_bdi(
		&dpbp->bpdesc, bdi, va,
		(cfg->options & DPBP_NOTIF_OPT_COHERENT_WRITE) ? 1 : 0);
	if ((cfg->options & DPBP_NOTIF_OPT_AIOP) ||
	    (cfg->options & DPBP_NOTIF_OPT_WRIOP)) {
		uint32_t	hw_targ;

		qbman_bp_attr_set_hwdet(&dpbp->bpdesc, cfg->depletion_entry);
		qbman_bp_attr_set_hwdxt(&dpbp->bpdesc, cfg->depletion_exit);
		hw_targ = 0;
		/* Target of BP depletion SCNs is AIOP DCP1 */
		if (cfg->options & DPBP_NOTIF_OPT_AIOP)
			hw_targ |= 0x2;
		/* Target of BP depletion SCNs is WRIOP DCP0 */
		if (cfg->options & DPBP_NOTIF_OPT_WRIOP)
			hw_targ |= 0x1;
		qbman_bp_attr_set_hw_targ(&dpbp->bpdesc, hw_targ);
	}
	/* Software Depletion detection configure */
	qbman_bp_attr_set_swdet(&dpbp->bpdesc, cfg->depletion_entry);
	qbman_bp_attr_set_swdxt(&dpbp->bpdesc, cfg->depletion_exit);
	qbman_bp_attr_set_swset(&dpbp->bpdesc, cfg->surplus_entry);
	qbman_bp_attr_set_swsxt(&dpbp->bpdesc, cfg->surplus_exit);
	qbman_bp_attr_set_bpscn_addr(&dpbp->bpdesc, cfg->message_iova);
	qbman_bp_attr_set_bpscn_ctx(&dpbp->bpdesc, cfg->message_ctx);

	dpmng_get_swportal(dpbp->dpmng, (void**)&sw_portal);
	err = qbman_bp_configure(sw_portal, (uint32_t)dpbp->bpid,
					&dpbp->bpdesc);
	dpmng_put_swportal(dpbp->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(err == 0, err, "ID[%d]: qbman_bp_configure failed\n", dpbp->id);

	return 0;
}

int dpbp_get_notifications(struct dpbp *dpbp,
	struct dpbp_notification_cfg *cfg)
{
	int		tmp, wae;
	uint32_t	hw_targ;

	qbman_bp_attr_get_bdi(&dpbp->bpdesc, &tmp, &tmp, &wae);
	cfg->options |= (wae) ? DPBP_NOTIF_OPT_COHERENT_WRITE : 0;
	qbman_bp_attr_get_hw_targ(&dpbp->bpdesc, &hw_targ);
	cfg->options |= (hw_targ << 16);
	if ((cfg->options & DPBP_NOTIF_OPT_AIOP) ||
	    (cfg->options & DPBP_NOTIF_OPT_WRIOP)) {
		qbman_bp_attr_get_hwdet(&dpbp->bpdesc, &cfg->depletion_entry);
		qbman_bp_attr_get_hwdxt(&dpbp->bpdesc, &cfg->depletion_exit);
	} else {
		qbman_bp_attr_get_swdet(&dpbp->bpdesc, &cfg->depletion_entry);
		qbman_bp_attr_get_swdxt(&dpbp->bpdesc, &cfg->depletion_exit);
	}
	qbman_bp_attr_get_swset(&dpbp->bpdesc, &cfg->surplus_entry);
	qbman_bp_attr_get_swsxt(&dpbp->bpdesc, &cfg->surplus_exit);
	qbman_bp_attr_get_bpscn_addr(&dpbp->bpdesc, &cfg->message_iova);
	qbman_bp_attr_get_bpscn_ctx(&dpbp->bpdesc, &cfg->message_ctx);
	return 0;
}

int dpbp_set_hw_notifications(struct dpbp *dpbp,
	struct dpbp_hw_notification_cfg *cfg)
{
	struct qbman_swp *sw_portal;
	int err;

	/* Assumes that this is relevant only for WRIOP (DCP#0) */
	if (cfg->depletion_entry)
		qbman_bp_attr_set_hw_targ(&dpbp->bpdesc, 0x1);
	else
		qbman_bp_attr_set_hw_targ(&dpbp->bpdesc, 0);
	qbman_bp_attr_set_hwdet(&dpbp->bpdesc, cfg->depletion_entry);
	qbman_bp_attr_set_hwdxt(&dpbp->bpdesc, cfg->depletion_exit);

	dpmng_get_swportal(dpbp->dpmng, (void**)&sw_portal);
	err = qbman_bp_configure(sw_portal, (uint32_t)dpbp->bpid,
					&dpbp->bpdesc);
	dpmng_put_swportal(dpbp->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(err == 0, err, "ID[%d]: qbman_bp_configure failed\n", dpbp->id);

	return 0;
}

int dpbp_get_hw_notifications(struct dpbp *dpbp,
	struct dpbp_hw_notification_cfg *cfg)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr bpdesc;
	int err;

	dpmng_get_swportal(dpbp->dpmng, (void**)&sw_portal);
	err = qbman_bp_query(sw_portal, (uint32_t)dpbp->bpid,
			&bpdesc);
	dpmng_put_swportal(dpbp->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(err == 0, err, "ID[%d]: dpbp_get_hw_notifications failed\n", dpbp->id);

	qbman_bp_attr_get_hwdet(&bpdesc, &cfg->depletion_entry);
	qbman_bp_attr_get_hwdxt(&bpdesc, &cfg->depletion_exit);

	return 0;
}

void dpbp_register_dpni(struct dpbp *dpbp, int register_dpni)
{
	struct dpbp_hw_notification_cfg hw_cfg = { 0 };

	if (register_dpni)
		dpbp->num_registred_dpnis++;
	else
		dpbp->num_registred_dpnis--;
	CHECK_COND_RET(dpbp->num_registred_dpnis >= 0);

	/* Check if hardware depletion entry/exit was configured */
	dpbp_get_hw_notifications(dpbp, &hw_cfg);
	if (hw_cfg.depletion_entry)
		return;
	if (dpbp->num_registred_dpnis == 1) {
		hw_cfg.depletion_entry = 64;
		hw_cfg.depletion_exit = 128;
		dpbp_set_hw_notifications(dpbp, &hw_cfg);
	}
	if (dpbp->num_registred_dpnis == 0) {
		hw_cfg.depletion_entry = 0;
		hw_cfg.depletion_exit = 0;
		dpbp_set_hw_notifications(dpbp, &hw_cfg);
	}
}

int dpbp_set_dev_ctx(struct dpbp *dpbp, const struct dpmng_dev_ctx *dev_ctx)
{
	int err;

	if (memcmp(&dpbp->amq, &(dev_ctx->amq), sizeof(struct dpmng_amq))
		!= 0) {
		CHECK_COND_RETVAL(!dpbp->enabled, -EINVAL);
		if ((err = resources_deauthorization(dpbp)) != 0) {
			pr_err("ID[%d]: resources_deauthorization failed \n", dpbp->id);
			return err;
		}

		dpbp->amq = dev_ctx->amq;

		dpbp->amq.bdi = (dev_ctx->type == DPMNG_CTX_TYPE_GPP) ? 0 : 1;

		if ((err = resources_authorization(dpbp)) != 0) {
			pr_err("ID[%d]: resources_authorization failed \n", dpbp->id);
			return err;
		}
	}

	return 0;
}

int dpbp_set_irq(struct dpbp *dpbp,
	uint8_t irq_index,
	const struct mc_irq_cfg *irq_cfg)
{
	UNUSED(irq_index);
	UNUSED(irq_cfg);

	pr_err("ID[%d]: IRQs are not supported\n", dpbp->id);
	return -ENOTSUP;
}

int dpbp_get_irq(struct dpbp *dpbp,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg)
{
	UNUSED(irq_index);
	UNUSED(irq_cfg);

	pr_err("ID[%d]: IRQs are not supported\n", dpbp->id);
	return -ENOTSUP;
}

int dpbp_set_irq_enable(struct dpbp *dpbp, uint8_t irq_index, uint8_t en)
{
	UNUSED(irq_index);
	UNUSED(en);

	pr_err("ID[%d]: IRQs are not supported\n", dpbp->id);
	return -ENOTSUP;
}

int dpbp_get_irq_enable(struct dpbp *dpbp, uint8_t irq_index, uint8_t *en)
{
	UNUSED(irq_index);
	UNUSED(en);

	pr_err("ID[%d]: IRQs are not supported\n", dpbp->id);
	return -ENOTSUP;
}

int dpbp_set_irq_mask(struct dpbp *dpbp, uint8_t irq_index, uint32_t mask)
{
	UNUSED(irq_index);
	UNUSED(mask);

	pr_err("ID[%d]: IRQs are not supported\n", dpbp->id);
	return -ENOTSUP;
}

int dpbp_get_irq_mask(struct dpbp *dpbp, uint8_t irq_index, uint32_t *mask)
{
	UNUSED(irq_index);
	UNUSED(mask);

	pr_err("ID[%d]: IRQs are not supported\n", dpbp->id);
	return -ENOTSUP;
}

int dpbp_get_irq_status(struct dpbp *dpbp, uint8_t irq_index, uint32_t *status)
{
	UNUSED(irq_index);
	UNUSED(status);

	pr_err("ID[%d]: IRQs are not supported\n", dpbp->id);
	return -ENOTSUP;
}

int dpbp_clear_irq_status(struct dpbp *dpbp,
	uint8_t irq_index,
	uint32_t status)
{
	UNUSED(irq_index);
	UNUSED(status);

	pr_err("ID[%d]: IRQs are not supported\n", dpbp->id);
	return -ENOTSUP;
}

#define DPBP_BP_CHUNK	7

/*! Allocate memory, release buffers to BMan*/
int dpbp_allocate_buffers(struct dpbp *dpbp,
	enum memory_partition_id partition_id,
	size_t memory_size,
	uint32_t buffer_size)
{
	/**
	 -# Allocate 2MByte Memory in PEB
	 -# Allocate Buffer Pool ID
	 -# Release 256 bytes chunks to BMan
	 */
	int err = 0;
	uint64_t buf[DPBP_BP_CHUNK];
	struct qbman_release_desc release_desc;
	struct qbman_swp *swp;
	unsigned int num_buffers, release_chunk, i, j;

	/* Allocate 2MByte Memory */
	if ((partition_id != MEM_PART_DP_DDR)
		&& (partition_id != MEM_PART_SYSTEM_DDR1)
		&& (partition_id != MEM_PART_PEB))
		return -EINVAL;

	err = fsl_get_mem(memory_size, MEM_PART_PEB, 256,
				&dpbp->buffers_paddr);
	CHECK_COND_RETVAL(err == 0, -ENOMEM);

	/*! Save memory_size and buffer_size */
	dpbp->memory_size = memory_size;
	dpbp->buffer_size = buffer_size;

	/* Get software portal */
	dpmng_get_swportal(dpbp->dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -EINVAL);

	/* Clear the contents of a descriptor to default/starting state. */
	qbman_release_desc_clear(&release_desc);
	/* Set the ID of the buffer pool to release to */
	qbman_release_desc_set_bpid(&release_desc, (uint32_t)(dpbp->bpid));

	/*! get number of buffres */
	num_buffers = memory_size / buffer_size;

	/*! get delta leftover */
	release_chunk = num_buffers % DPBP_BP_CHUNK;
	release_chunk = (release_chunk == 0) ? DPBP_BP_CHUNK : release_chunk;

	for (i = 0; i < num_buffers;) {
		/* Init chunk pointers */
		for (j = 0; j < release_chunk; j++)
			buf[j] = dpbp->buffers_paddr + (buffer_size * (i + j));

		do {
			/* Release buffres to BMan */
			err = qbman_swp_release(swp, /* QMan SW Portal */
						&(release_desc), /* Buffer Pool ID */
						buf, /* Buffer Address */
						release_chunk); /* Number of Buffers */
		} while (err == -EBUSY);
		CHECK_COND_RETVAL(err == 0, err);

		i = i + release_chunk;

		release_chunk = DPBP_BP_CHUNK;
	}

	dpmng_put_swportal(dpbp->dpmng, (void*)swp);

	return err;
}

/*! Acquire buffers from BMan, free PEB memory */
int dpbp_deallocate_buffers(struct dpbp *dpbp, size_t memory_size)
{
	int cnt = 0;
	struct qbman_swp *swp;
	uint64_t buffers[DPBP_BP_CHUNK];
	unsigned int num_buffers, acquire_chunk, i;

	/* Get software portal */
	dpmng_get_swportal(dpbp->dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -EINVAL);

	/*! get number of buffres */
	num_buffers = dpbp->memory_size / dpbp->buffer_size;

	/*! acquire as much as possible at once */
	acquire_chunk = DPBP_BP_CHUNK;
	
	for (i = 0; i < num_buffers;) {
		/*! Acquire chunk of buffers */
		cnt = qbman_swp_acquire(swp, (uint32_t)dpbp->bpid, buffers,
				acquire_chunk);

		if (cnt != acquire_chunk) {

			/* if already switched to one step exit */
			if (acquire_chunk == 1) {
				break;
			}

			/* now walk in steps of one */
			acquire_chunk = 1;
			continue;
		}

		i = i + acquire_chunk;
	}

	if ( i < num_buffers) {
		pr_err("Fail to release %d buffer(s) from bpid %d. \n", (num_buffers - i), (uint32_t)dpbp->bpid);
	}
		
	dpmng_put_swportal(dpbp->dpmng, (void*)swp);

	/*! Free memory */
	fsl_put_mem(dpbp->buffers_paddr);

	return 0;
}

/*! Configure buffer depletion priority */
int dpbp_config_pfc_priority(struct dpmac *dpmac, struct dpbp *dpbp, uint8_t priority_mask, int cmd)
{
	struct eiop_cgp cgp = { 0 };
	cgp.type = EIOP_CGP_BUFFER_DEPLETION;
	cgp.id   = (uint16_t)dpbp->bpid;
	cgp.bits = priority_mask;
	dpmac_set_port_cgp(dpmac, &cgp, cmd);

	return 0;
}

int cong_config_pfc_priority(struct dpmac *dpmac, uint16_t cgid, uint8_t priority_mask, int cmd)
{
	struct eiop_cgp cgp = { 0 };
	cgp.type = EIOP_CGP_CONGESTION_GROUP;
	cgp.id   = cgid;
	cgp.bits = priority_mask;
	dpmac_set_port_cgp(dpmac, &cgp, cmd);

	return 0;
}

/*! Return buffer pool id*/
int dpbp_get_bpid(struct dpbp *dpbp)
{
	return dpbp->bpid;
}
