/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpbp_drv.c

 @Description   driver implementation

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "dplib/fsl_dpbp_cmd.h"
#include "dtc/dtc.h"
#include "fsl_sys.h"
#include "fsl_event_pipe.h"
#include "fsl_dpbp_mc.h"
#include "dpbp_cmd.h"
#include "legacy_dpbp_dplib.h"

/* DPBP last supported API version */
#define DPBP_V0_API_VER_MAJOR				2
#define DPBP_V0_API_VER_MINOR				2

int dpbp_drv_init(void);

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpbp *dpbp;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	return dpbp_set_dev_ctx(dpbp, dev_ctx);
}

static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpbp_cfg dpbp_cfg = { 0 };
	struct dpbp_cfg *cfg = &dpbp_cfg;
	int err;

	dpbp = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpbp) {
		/* NULL */
		dpbp = dpbp_allocate();
		if (!dpbp) {
			pr_err("No memory for dpbp\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpbp_init(dpbp, cfg, &dev_cfg);
		if (err) {
			return err;
		}
		device_set_priv(dev, dpbp);
		sys_add_handle(dpbp, FSL_MOD_DPBP, 1, dev_cfg.id);
	} else
		return -EINVAL;

	return 0;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;

	UNUSED(cmd_data);

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	dpbp_destroy(dpbp);

	sys_remove_handle(FSL_MOD_DPBP, 1, device_get_id(dev));
	dpbp_deallocate(dpbp);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;

	UNUSED(cmd_data);

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	device_set_enable(dev, 1);

	dpbp_enable(dpbp);

	return 0;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	int err;

	UNUSED(cmd_data);

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	err = dpbp_disable(dpbp);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;

	UNUSED(cmd_data);

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	dpbp_reset(dpbp);
	device_set_enable(dev, 0);

	return 0;
}

static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	struct dpbp_attr attr = { 0 };
	int err;

	dpbp = device_get_priv(dev);
	CHECK_COND_RETVAL(dpbp, -ENODEV);

	err = dpbp_get_attributes(dpbp, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.version.major = DPBP_V0_API_VER_MAJOR;
	attr.version.minor = DPBP_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPBP_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	struct dpbp_attr attr = { 0 };
	int err;

	dpbp = device_get_priv(dev);
	CHECK_COND_RETVAL(dpbp, -ENODEV);

	err = dpbp_get_attributes(dpbp, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPBP_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	int en, err;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	err = dpbp_is_enabled(dpbp, &en);

	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPBP_RSP_IS_ENABLED(cmd_data, en);
	}

	return err;
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	DPBP_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dpbp_set_irq(dpbp, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpbp *dpbp;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	return dpbp_set_irq(dpbp, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	/* Read parameters from portal */
	DPBP_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpbp_get_irq(dpbp, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPBP_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpbp *dpbp;
	int err;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	err = dpbp_get_irq(dpbp, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;

	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	uint8_t irq_index;
	uint8_t enable_state;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	/* Read parameters from portal */
	DPBP_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, enable_state);

	return dpbp_set_irq_enable(dpbp, irq_index, enable_state);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	uint8_t irq_index;
	uint8_t enable_state;
	int err;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	/* Read parameters from portal */
	DPBP_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpbp_get_irq_enable(dpbp, irq_index, &enable_state);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPBP_RSP_GET_IRQ_ENABLE(cmd_data, enable_state);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	uint8_t irq_index;
	uint32_t mask;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	/* Read parameters from portal */
	DPBP_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpbp_set_irq_mask(dpbp, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	uint8_t irq_index;
	uint32_t mask;
	int err;
	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;
	/* Read parameters from portal */
	DPBP_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpbp_get_irq_mask(dpbp, irq_index, &mask);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPBP_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	/* Read parameters from portal */
	DPBP_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpbp_get_irq_status(dpbp, irq_index, &status);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPBP_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	uint8_t irq_index;
	uint32_t status;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	/* Read parameters from portal */
	DPBP_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpbp_clear_irq_status(dpbp, irq_index, status);
}

static int set_notifications_v0(struct device *dev,
				struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	struct dpbp_notification_cfg notification_cfg = { 0 };
	struct dpbp_notification_cfg *cfg = &notification_cfg;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	/* Read parameters from portal */
	DPBP_CMD_SET_NOTIFICATIONS_V0(cmd_data, cfg);

	return dpbp_set_notifications(dpbp, cfg);
}

static int set_notifications_v2(struct device *dev,
				struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	struct dpbp_notification_cfg notification_cfg = { 0 };
	struct dpbp_notification_cfg *cfg = &notification_cfg;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	/* Read parameters from portal */
	DPBP_CMD_SET_NOTIFICATIONS_V1(cmd_data, cfg);

	return dpbp_set_notifications(dpbp, cfg);
}

static int get_notifications_v0(struct device *dev,
				struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	struct dpbp_notification_cfg notification_cfg = { 0 };
	struct dpbp_notification_cfg *cfg = &notification_cfg;
	int err;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	err = dpbp_get_notifications(dpbp, cfg);
	if (err)
		return err;

	/* Read parameters from portal */
	DPBP_CMD_GET_NOTIFICATIONS_V0(cmd_data, cfg);

	return 0;
}

static int get_notifications_v2(struct device *dev,
				struct mc_cmd_data *cmd_data)
{
	struct dpbp *dpbp;
	struct dpbp_notification_cfg notification_cfg = { 0 };
	struct dpbp_notification_cfg *cfg = &notification_cfg;
	int err;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	err = dpbp_get_notifications(dpbp, cfg);
	if (err)
		return err;

	/* Read parameters from portal */
	DPBP_CMD_GET_NOTIFICATIONS_V1(cmd_data, cfg);

	return 0;
}

static int get_num_free_bufs(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpbp	*dpbp;
	uint32_t	num_free_bufs;
	int		err;

	dpbp = device_get_priv(dev);
	if (!dpbp)
		return -ENODEV;

	err = dpbp_get_num_free_bufs(dpbp, &num_free_bufs);
	if (err)
		return err;
	/* Read parameters from portal */
	DPBP_RSP_GET_NUM_FREE_BUFS(cmd_data, num_free_bufs);

	return 0;
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPBP_VER_MAJOR;
    uint32_t minor = DPBP_VER_MINOR;

    DPBP_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int dpbp_drv_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpbp_open on DPBP %d\n", device_get_id(dev));
	return 0;
}

static int dpbp_drv_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpbp_close on DPBP %d\n", device_get_id(dev));
	return 0;
}

static int dpbp_drv_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev,
			struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPBP_CMD_CODE_CREATE, init, "dpbp_init", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_DESTROY, destroy, "dpbp_destroy", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_RESET, reset, "dpbp_reset", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_ENABLE, enable, "dpbp_enable", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_DISABLE, disable, "dpbp_disable", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_GET_ATTR, get_attributes_v0, "dpbp_get_attributes", DPBP_CMD_V0 },
			{ DPBP_CMD_CODE_IS_ENABLED, is_enabled, "dpbp_is_enabled", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_SET_IRQ, set_irq, "dpbp_set_irq", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_GET_IRQ, get_irq, "dpbp_get_irq", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpbp_set_irq_enable", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpbp_get_irq_enable", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpbp_set_irq_mask", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpbp_get_irq_mask", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpbp_get_irq_status", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpbp_clear_irq_status", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_SET_NOTIFICATIONS, set_notifications_v0,
				"dpbp_set_notifications", DPPB_CMD_VER_BASE },
			{ DPBP_CMD_CODE_GET_NOTIFICATIONS, get_notifications_v0,
				"dpbp_get_notifications", DPPB_CMD_VER_BASE },
			
			/* New command handlers start here */
			{ DPBP_CMD_CODE_GET_API_VERSION, get_api_version, "dpbp_get_api_version", DPBP_CMD_V1 },
			{ DPBP_CMD_CODE_GET_ATTR, get_attributes_v1, "dpbp_get_attributes", DPBP_CMD_V1 },
			{ DPBP_CMD_CODE_GET_FREE_BUFFERS_NUM, get_num_free_bufs,
				"dpbp_get_num_free_bufs", DPBP_CMD_V1 },
			{ DPBP_CMD_CODE_SET_NOTIFICATIONS, set_notifications_v2,
				"dpbp_set_notifications", DPBP_CMD_V2 },
			{ DPBP_CMD_CODE_GET_NOTIFICATIONS, get_notifications_v2,
				"dpbp_get_notifications", DPBP_CMD_V2 }
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
			if (cmd == DPBP_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPBP %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev,
							cmd_data);
		}

	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}

static int dpbp_drv_probe_cb(void *lo, int node_off)
{
	int err = 0;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	int destroy = 0;
	int id;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(resman, "dpbp", (uint16_t)id, NO_PORTAL_ID,
			DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPBP %.4x\n", id);
	/* create object */
	err = dpbp_drv_ctrl_cb(dev, DPPB_CMD_VER_BASE, DPBP_CMD_CODE_CREATE,
			NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpbp", NO_PORTAL_ID, destroy);

	return err;
}

static int dpbp_drv_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}

	dev = resman_open_dev(resman, "dpbp", (uint16_t)id, NO_PORTAL_ID, 0, NULL);
	if (!dev) {
		pr_err("Can't open DPBP 0x%.4x\n", id);
		return -ENODEV;
	}

        err |= dpbp_drv_ctrl_cb(dev, DPPB_CMD_VER_BASE, DPBP_CMD_CODE_DESTROY, NO_PORTAL_ID, NULL);
        err |= resman_close_dev(resman, dev, "dpbp", NO_PORTAL_ID, 0);

	return err;
}

static char *dpbp_drv_match[] = { "fsl,dpbp", "dpbp" };

int dpbp_drv_init(void)
{
	t_sys_dtc_mod_params lo_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;

	pr_info("Executing dpbp_drv_init...\n");
	
	lo_params.num_compats = ARRAY_SIZE(dpbp_drv_match);
	lo_params.compatibles = dpbp_drv_match;
	lo_params.f_prob_module = dpbp_drv_probe_cb;
	lo_params.f_remove_module = dpbp_drv_remove_cb;
	sys_dtc_register_module(&lo_params);

	cmdif_ops.open_cb = dpbp_drv_open_cb;
	cmdif_ops.close_cb = dpbp_drv_close_cb;
	cmdif_ops.ctrl_cb = dpbp_drv_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPBP, &cmdif_ops);

	strcpy(dev_type_param.device_type, "dpbp");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPBP_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPBP_VER_MAJOR;
	dev_type_param.ver_minor = DPBP_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -EINVAL);

	resman_register_device_operation(resman, "dpbp", &dev_type_param);
	return 0;
}
