/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpbp.h

 @Description   DPBP internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPBP_H
#define __DPBP_H

#include "kernel/fsl_spinlock.h"
#include "fsl_dpbp_mc.h"
#include "fsl_dpmng_mc.h"
#include "fsl_event_pipe.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPBP

struct dpbp {
	uint16_t id;
	int bpid;
	uint32_t virt_bpid;
	struct dpmng *dpmng;
	struct device *device;
	int enabled;
	int authorized;
	struct dpmng_amq amq;
	struct qbman_attr bpdesc;
	int num_registred_dpnis;

	/* Private use */
	phys_addr_t buffers_paddr; /*! memory physical address */
	size_t memory_size; /*! total memory size */
	uint32_t buffer_size; /*! buffer size */

	struct mc_irq irqs[DPBP_MAX_IRQ_NUM];
};

#endif /* __DPBP_H */
