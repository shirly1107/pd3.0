/*
 * Copyright 2017-2019 NXP
 */

#ifndef _DPDBG_CMD_H
#define _DPDBG_CMD_H

/* default version for all dpdbg commands */
#define DPDBG_CMD_VER_BASE								CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)

/* Command IDs */
#define DPDBG_CMD_CODE_CREATE							0x90F
#define DPDBG_CMD_CODE_DESTROY							0x900

#define DPDBG_CMD_CODE_OPEN                             0x80F
#define DPDBG_CMD_CODE_CLOSE                            0x800

#define DPDBG_CMD_CODE_GET_API_VERSION                  0xa0F
#define DPDBG_CMD_CODE_GET_ATTR                         0x004

#define DPDBG_CMD_CODE_DUMP                             0x130
#define DPDBG_CMD_CODE_SET								0x140

#endif /* _DPDBG_CMD_H */
