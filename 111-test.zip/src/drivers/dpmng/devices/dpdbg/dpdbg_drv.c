/*
 * Copyright 2017-2019 NXP
 */

/**************************************************************************//*
 @File          dpdbg_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "dplib/fsl_dpdbg_cmd.h"
#include "dtc/dtc.h"
#include "fsl_sys.h"
#include "fsl_event_pipe.h"
#include "fsl_dpdbg_mc.h"
#include "dpdbg_cmd.h"
#include "legacy_dpdbg_dplib.h"
#include "ctlu.h"
#include "fsl_ctlu.h"
#include "resman.h"
#include "fsl_resman.h"
#include "dpc.h"
#include "log.h"
#include "soc_db.h"
#include "fsl_platform.h"

static char *dpdbg_drv_match[] = { "fsl,dpdbg", "dpdbg" };

int dpdbg_drv_init(void);

static int is_mc_object(char *name)
{
	int i, err = 0;
	
	/* Search device type index */
	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		if (strcmp(device_types[i], name) == 0)
			err = 1;
	}
	
	return err;
}

static struct dprc *get_root_dprc(struct resman *resman, char *type, uint16_t id) 
{
	struct dprc *dprc;
	struct resman_device *device = NULL;
	struct resman_list_item_device *cur_device_item;
	int dev_type_index = -EEXIST;
	int i;
	
	/* Search device type index */
	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		if (strcmp(device_types[i], type) == 0)
			dev_type_index = i;
	}
	
	if (id == RESMAN_NO_DEVICE_ID)
		return NULL;
	
	/* Search for the device in the container
	   Search for the device in resman device pool */
	spin_lock(resman->lock_devices_list[dev_type_index]);
	cur_device_item = resman->devices[dev_type_index];
	while (cur_device_item) {
		if (cur_device_item->device->dev.id == id) {
			spin_unlock(resman->lock_devices_list[dev_type_index]);
			device = cur_device_item->device;
		}
		cur_device_item = cur_device_item->next;
	}

	spin_unlock(resman->lock_devices_list[dev_type_index]);

	if (device == NULL)
		return NULL;
	
	dprc = device->holder;
	
	while (dprc->parent->container_id != 0) {
		dprc = dprc->parent;
	}
		
	return dprc;
}

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpdbg *dpdbg;

	dpdbg = device_get_priv(dev);
	if (!dpdbg)
		return -ENODEV;

	return 0;
}

static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdbg *dpdbg;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpdbg_cfg dpdbg_cfg = { 0 };
	struct dpdbg_cfg *cfg = &dpdbg_cfg;
	int err;
	
	dpdbg = device_get_priv(dev);
	
	/* Get command from portal */
	DPDBG_CMD_CREATE(cmd_data, cfg);
	
	/* should be NULL unless special cases: reset, etc. */
	if (!dpdbg) {
		dpdbg = dpdbg_allocate();
		if (!dpdbg) {
			pr_err("No memory for DPDBG\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpdbg_init(dpdbg, &dev_cfg, cfg);
		if (err)
			return err;
		
		device_set_priv(dev, dpdbg);
		sys_add_handle(dpdbg, FSL_MOD_DPDBG, 1, dev_cfg.id);

		assign(dev, &(dev_cfg.ctx));	
	} else
		return -EINVAL;

	return 0;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdbg *dpdbg = NULL;
	
	UNUSED(cmd_data);
	
	dpdbg = device_get_priv(dev);
	if (!dpdbg)
		return -ENODEV;
	
	dpdbg_destroy(dpdbg);

	sys_remove_handle(FSL_MOD_DPDBG, 1, device_get_id(dev));
	dpdbg_deallocate(dpdbg);
		
	return 0;
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdbg *dpdbg = NULL;
	
	UNUSED(cmd_data);
	
	dpdbg = device_get_priv(dev);
	if (!dpdbg)
		return -ENODEV;
	
	dpdbg_reset(dpdbg);
	
	return 0;
}

static int destroy_by_resman (struct device *dev)
{
	return destroy(dev, NULL);
}

static int reset_by_resman (struct device *dev)
{
	return reset(dev, NULL);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPDBG_VER_MAJOR;
    uint32_t minor = DPDBG_VER_MINOR;

    DPDBG_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int get_attributes(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdbg *dpdbg;
	int err;
	struct dpdbg_attr attr = { 0 };

	dpdbg = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdbg, -ENODEV);

	err = dpdbg_get_attributes(dpdbg, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDBG_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int dump(struct device *dev, struct mc_cmd_data *cmd_data) 
{
	struct dpdbg *dpdbg;
	int obj_id;
	char obj_type[16];
	int err;	
	
	dpdbg = device_get_priv(dev);
	if (!dpdbg)
		return -ENODEV;
	
	/* Get command from portal */
	DPDBG_CMD_DUMP(cmd_data, obj_id, obj_type);
	
	/* Verify if the object that will be dumped 
	 * is in the DPDBG root container or in its children
	 */
	if (is_mc_object(obj_type)) {
		struct resman *resman;
		struct dprc *obj_root_dprc;
		int dpdbg_container_id;
		
		resman = sys_get_unique_handle(FSL_MOD_RESMAN);
		CHECK_COND_RETVAL(resman, -ENODEV);
			
		dpdbg_container_id = dpdbg_get_container_id(dpdbg);
			
		obj_root_dprc = get_root_dprc(resman, obj_type, (uint16_t)obj_id);
		if (obj_root_dprc == NULL)
			return -ENODEV;
			
		if (obj_root_dprc->container_id != dpdbg_container_id)
			return -ENODEV;
	}
	
	if (strncmp(obj_type, "mem", 3) == 0) {
		err = dpdbg_get_mem_info();
		if (err)
			return err;		
	}
	else if (strncmp(obj_type, "dpmcp", 5) == 0) {
		struct dpmcp *dpmcp; 
				
		dpmcp = (struct dpmcp *)sys_get_handle(FSL_MOD_DPMCP, 1, obj_id);
		if (!dpmcp)
			return -ENODEV;
		
		err = dpdbg_get_dpmcp_info(dpdbg, dpmcp);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpio", 4) == 0) {
		struct dpio *dpio; 
						
		dpio = (struct dpio *)sys_get_handle(FSL_MOD_DPIO, 1, obj_id);
		if (!dpio)
			return -ENODEV;
		
		err = dpdbg_get_dpio_info(dpdbg, dpio);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dprc", 4) == 0) {		
		struct dprc *dprc;
		
		dprc = (struct dprc *)sys_get_handle(FSL_MOD_DPRC, 1, obj_id);
		if (!dprc)
			return -ENODEV;

		err = dpdbg_get_dprc_info(dpdbg, dprc);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpbp", 4) == 0) {
		struct dpbp *dpbp;
						
		dpbp = (struct dpbp *)sys_get_handle(FSL_MOD_DPBP, 1, obj_id);
		if (!dpbp)
			return -ENODEV;

		err = dpdbg_get_dpbp_info(dpdbg, dpbp);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpci", 4) == 0) {
		struct dpci *dpci;
						
		dpci = (struct dpci *)sys_get_handle(FSL_MOD_DPCI, 1, obj_id);
		if (!dpci)
			return -ENODEV;

		err = dpdbg_get_dpci_info(dpdbg, dpci);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpmac", 5) == 0) {
		struct dpmac *dpmac;
						
		dpmac = (struct dpmac *)sys_get_handle(FSL_MOD_DPMAC, 1, obj_id);
		if (!dpmac)
			return -ENODEV;
		
		err = dpdbg_get_dpmac_info(dpdbg, dpmac);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpni", 4) == 0) {
		struct dpni *dpni;
						
		dpni = (struct dpni *)sys_get_handle(FSL_MOD_DPNI, 1, obj_id);
		if (!dpni)
			return -ENODEV;

		err = dpdbg_get_dpni_info(dpdbg, dpni);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpsw", 4) == 0) {
		struct dpsw *dpsw;
						
		dpsw = (struct dpsw *)sys_get_handle(FSL_MOD_DPSW, 1, obj_id);
		if (!dpsw)
			return -ENODEV;
		
		err = dpdbg_get_dpsw_info(dpdbg, dpsw);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpdmux", 6) == 0) {
		struct dpdmux *dpdmux;
						
		dpdmux = (struct dpdmux *)sys_get_handle(FSL_MOD_DPDMUX, 1, obj_id);
		if (!dpdmux)
			return -ENODEV;

		err = dpdbg_get_dpdmux_info(dpdbg, dpdmux);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpseci", 6) == 0) {
		struct dpseci *dpseci;
						
		dpseci = (struct dpseci *)sys_get_handle(FSL_MOD_DPSECI, 1, obj_id);
		if (!dpseci)
			return -ENODEV;
		
		err = dpdbg_get_dpseci_info(dpdbg, dpseci);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpcon", 5) == 0) {
		struct dpcon *dpcon;
						
		dpcon = (struct dpcon *)sys_get_handle(FSL_MOD_DPCON, 1, obj_id);
		if (!dpcon)
			return -ENODEV;

		err = dpdbg_get_dpcon_info(dpdbg, dpcon);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpdcei", 6) == 0) {
		struct dpdcei *dpdcei;
						
		dpdcei = (struct dpdcei *)sys_get_handle(FSL_MOD_DPDCEI, 1, obj_id);
		if (!dpdcei)
			return -ENODEV;

		err = dpdbg_get_dpdcei_info(dpdbg, dpdcei);
		if (err)
			return err;
	}
	else if (strncmp(obj_type, "dpdmai", 6) == 0) {
		struct dpdmai *dpdmai;
						
		dpdmai = (struct dpdmai *)sys_get_handle(FSL_MOD_DPDMAI, 1, obj_id);
		if (!dpdmai)
			return -ENODEV;

		err = dpdbg_get_dpdmai_info(dpdbg, dpdmai);
		if (err)
			return err;
	}
	
	return 0;
}

static int set(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdbg *dpdbg;
	int state;
	char module[16];
	int err;
	
	dpdbg = device_get_priv(dev);
	if (!dpdbg)
		return -ENODEV;
	
	DPDBG_CMD_SET(cmd_data, state, module);
	
	if (strcmp(module, "console") == 0) {
		if (state == 0) {
			pr_info("MC UART Console printing OFF \n");
			log_db.console_mode = CONSOLE_MODE_OFF;
			err = 0;
		}
		else if (state == 1) {
			log_db.console_mode = CONSOLE_MODE_ON;
			pr_info("MC UART Console printing ON \n");
			err = 0;
		}
		else {
			pr_err("CONSOLE: ON = 1, OFF = 0 \n");
			err = -EINVAL;
		}
	}
	else if (strcmp(module, "uart_id") == 0) {
		if (state == 0) {
			pr_info("MC UART Console printing OFF \n");
			pltfrm_free_console_cb(sys.platform_ops.h_platform);
			err = 0;
		}
		else if (state > 0 && state <= 4) {
			t_platform *platform = (t_platform *)sys.platform_ops.h_platform;
			
			pltfrm_free_console_cb(sys.platform_ops.h_platform);
			platform->param.console_id = (uint8_t)state - 1;
			pltfrm_init_console_cb(sys.platform_ops.h_platform);
			
			pr_info("MC UART console printing set on UART %d\n", state);
			
			err = 0;
		}
		else {
			pr_err("UART ID: 0(CONSOLE_MODE_OFF), 1, 2, 3 or 4 \n");
			err = -EINVAL;
		}

		return err;
	}
	else if (strcmp(module, "log_level") == 0) {		
		if (state == 0) {
			log_set_global_level(LOG_LEVEL_GLOBAL);
			pr_debug("LOG LEVEL set to GLOBAL \n");
			err = 0;
		}
		else if (state == 1) {
			log_set_global_level(LOG_LEVEL_DEBUG);
			pr_debug("LOG LEVEL set to DEBUG \n");
			err = 0;
		}
		else if (state == 2) {
			log_set_global_level(LOG_LEVEL_INFO);
			pr_info("LOG LEVEL set to INFO \n");
			err = 0;
		}
		else if (state == 3) {
			log_set_global_level(LOG_LEVEL_WARNING);
			pr_warn("LOG LEVEL set to WARNING \n");
			err = 0;
		}
		else if (state == 4) {
			log_set_global_level(LOG_LEVEL_ERROR);
			pr_err("LOG LEVEL set to ERROR \n");
			err = 0;
		}
		else if (state == 5) {
			log_set_global_level(LOG_LEVEL_CRITICAL);
			pr_crit("LOG LEVEL set to CRITICAL \n");
			err = 0;
		}
		else {
			pr_err("LOG LEVEL: 0-GLOBAL, 1-DEBUG, 2-INFO, 3-WARNING, 4-ERROR or 5-CRITICAL \n");
			err = -EINVAL;
		}
	}
	else if (strcmp(module, "log_mode") == 0) {		
		if (state == 0) {
			pr_info("MC DDR printing OFF \n");
			log_set_mode(LOG_MODE_OFF);
			err = 0;
		}
		else if (state == 1) {
			log_set_mode(LOG_MODE_ON);
			pr_info("MC DDR printing ON \n");
			err = 0;
		}
		else {
			pr_err("LOG: ON = 1, OFF = 0 \n");
			err = -EINVAL;
		}
	}
	else if (strcmp(module, "timestamp") == 0) {		
		if (state == 0) {
			log_set_timestamp_mode(LOG_TIMESTAMP_OFF);
			pr_info("Timestamp printing OFF \n");
			err = 0;
		}
		else if (state == 1) {
			log_set_timestamp_mode(LOG_TIMESTAMP_ON);
			pr_info("Timestamp printing ON \n");
			err = 0;
		}
		else {
			pr_err("TIMESTAMP: ON = 1, OFF = 0 \n");
			err = -EINVAL;
		}
	}
	else {
		pr_err("Unavailable module \n");
		err = -EINVAL;
	}
	
	return err;
}

static int dpdbg_drv_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpdbg_open on DPDBG\n");
	return 0;
}

static int dpdbg_drv_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpdbg_close on DPDBG\n");
	return 0;
}

static int dpdbg_drv_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, 	int portal_id, 	uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev,
			struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	} map_commands[] = {
			{ DPDBG_CMD_CODE_CREATE, init, "dpdbg_create", DPDBG_CMD_VER_BASE },
			{ DPDBG_CMD_CODE_DESTROY, destroy, "dpdbg_destroy", DPDBG_CMD_VER_BASE },
			{ DPDBG_CMD_CODE_GET_ATTR, get_attributes, "dpdbg_get_attributes", DPDBG_CMD_VER_BASE },
			{ DPDBG_CMD_CODE_GET_API_VERSION, get_api_version, "dpdbg_get_api_version", DPDBG_CMD_VER_BASE },
			{ DPDBG_CMD_CODE_DUMP, dump, "dpdbg_dump", DPDBG_CMD_VER_BASE },
			{ DPDBG_CMD_CODE_SET, set, "dpdbg_set", DPDBG_CMD_VER_BASE },
		};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) && 
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
			pr_info("Handling command: %s on DPDBG\n", map_commands[i].cmd_str);
			return map_commands[i].function((struct device *)dev,
							cmd_data);
		}

	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}

static int dpdbg_drv_probe_cb (void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	struct dpdbg_cfg dpdbg_cfg = { 0 };
	struct dpdbg_cfg *cfg = &dpdbg_cfg;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	uint64_t val;
	int id;
	int err = 0;
	int destroy = 0;
	
	err = get_node_id(lo, node_off, &id);
	CHECK_COND_RETVAL(err == 0, err);
	
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);
	
	dev = resman_open_dev(resman, "dpdbg", (uint16_t) id, NO_PORTAL_ID, DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPDBG %.4x\n", id);

	getprop_val(lo, node_off, "dpdbg_container_id", 0, 0, &val);
	dpdbg_cfg.dpdbg_container_id = (int)val;
	dpdbg_cfg.dpdbg_id = id;
	
	DPDBG_CMD_CREATE(cmd_data, cfg);

	err = dpdbg_drv_ctrl_cb(dev, DPDBG_CMD_VER_BASE, DPDBG_CMD_CODE_CREATE, NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;
	
	err = resman_close_dev(resman, dev, "dpdbg", NO_PORTAL_ID, destroy);
	if (err) {
		pr_err("Can't create DPDBG\n");
		return err;
	}
	
	pr_info("DPDBG created successfully\n");
	
	return 0;
}

static int dpdbg_drv_remove_cb (void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;
	
	err = get_node_id(lo, node_off, &id);
	CHECK_COND_RETVAL(err == 0, err);

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);
	
	dev = resman_open_dev(resman, "dpdbg", (uint16_t) id, NO_PORTAL_ID, DPRC_OPEN_DEV_ONLY, NULL);
	if (!dev) {
		pr_err("Can't open DPDBG\n");
		return -ENODEV;
	}
	
	err = dpdbg_drv_ctrl_cb(dev, DPDBG_CMD_VER_BASE, DPDBG_CMD_CODE_DESTROY, NO_PORTAL_ID, NULL);
	if (err) {
		pr_err("DPDBG destroy failed\n");
		return err;
	}
	
	err = resman_close_dev(resman, dev, "dpdbg", NO_PORTAL_ID, 0);
	if (err) {
		pr_err("Can't close DPDBG\n");
		return err;
	}
	
	pr_info("DPDBG removed\n");
	
	return 0;
}

int dpdbg_drv_init(void)
{
	t_sys_dtc_mod_params lo_params = { 0 };
	
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;

	pr_info("Executing dpdbg_drv_init...\n");
	
	/* register object */
	lo_params.num_compats = ARRAY_SIZE(dpdbg_drv_match);
	lo_params.compatibles = dpdbg_drv_match;
	lo_params.f_prob_module = dpdbg_drv_probe_cb;
	lo_params.f_remove_module = dpdbg_drv_remove_cb;
	sys_dtc_register_module(&lo_params);
	
	cmdif_ops.open_cb = dpdbg_drv_open_cb;
	cmdif_ops.close_cb = dpdbg_drv_close_cb;
	cmdif_ops.ctrl_cb = dpdbg_drv_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPDBG, &cmdif_ops);

	strcpy(dev_type_param.device_type, "dpdbg");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPDBG_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPDBG_VER_MAJOR;
	dev_type_param.ver_minor = DPDBG_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	resman_register_device_operation(resman, "dpdbg", &dev_type_param);
	
	return 0;
}
