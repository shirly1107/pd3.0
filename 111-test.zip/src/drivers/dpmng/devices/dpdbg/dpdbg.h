/*
 * Copyright 2017-2019 NXP
 */

/******************************************************************************
 @File          dpdbg.h

 @Description   DPDBG internal structures and definitions.
*//***************************************************************************/
#ifndef __DPDBG_H
#define __DPDBG_H

#include "kernel/fsl_spinlock.h"
#include "fsl_dpdbg_mc.h"
#include "fsl_dpmng_mc.h"
#include "fsl_event_pipe.h"
#include "fsl_list.h"
#include "resman.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPDBG


struct dpdbg_handle {
	struct dpkg     	*dpkg_ing;  	/* Ingress Key Generation */
	struct dptbl_mng    	*dptbl_ing; 	/* Ingress Tables */
};

struct dpdbg {
	uint16_t	id;
	uint16_t	container_id;
	struct dpmng    *dpmng;
	struct qbman_block	*qbman;
	struct device	*device;
	int		enabled;
	int		authorized;
	int 		eiop_id;
	struct dpkg *ing_dpkg;
	struct dpmng_amq amq;
   	struct dpdbg_handle	handle;		/*! handlers */
	struct mc_irq irqs[DPDBG_MAX_IRQ_NUM];
};

#endif /* __DPDBG_H */
