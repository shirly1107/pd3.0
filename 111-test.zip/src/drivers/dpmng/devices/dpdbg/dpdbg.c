/*
 * Copyright 2017-2019 NXP
 */

/**************************************************************************//*
 @File          dpdbg.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_mc.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_resman.h"
#include "dpdbg.h"
#include "kernel/device.h"
#include "fsl_dpni_mc.h"
#include "dptbl.h"
#include "fsl_eiop.h"
#include "drivers/fsl_qbman_ctrl.h"
#include "dpni.h"
#include "fsl_system.h"
#include "mem_mng.h"
#include "fsl_slob.h"

#define DPDBG_MAX_MEM_DIGITS 100

int dpdbg_open(struct dpdbg *dpdbg, int dpdbg_id)
{
	return 0;
}

int dpdbg_close(struct dpdbg *dpdbg)
{
	return 0;
}

struct dpdbg *dpdbg_allocate(void)
{
	struct dpdbg *dpdbg;

	dpdbg = (struct dpdbg *)fsl_xmalloc(sizeof(struct dpdbg), 0,
						CORE_CACHELINE_SIZE);
	if (dpdbg)
		memset(dpdbg, 0, sizeof(struct dpdbg));
	return dpdbg;
}

void dpdbg_deallocate(struct dpdbg *dpdbg)
{
	fsl_xfree(dpdbg);
}

int dpdbg_get_container_id(struct dpdbg *dpdbg)
{
	return dpdbg->container_id;
}

int dpdbg_init(struct dpdbg *dpdbg, const struct dpmng_dev_cfg *dev_cfg, struct dpdbg_cfg *cfg)
{
	int i;
	
	dpdbg->id = dev_cfg->id;
	dpdbg->container_id = (uint16_t)cfg->dpdbg_container_id;
	dpdbg->device = dev_cfg->device;
	dpdbg->eiop_id = 0;
	dpdbg->qbman = sys_get_unique_handle(FSL_MOD_QBMAN);
	
	dpdbg->ing_dpkg = sys_get_handle(FSL_MOD_KG, 2, dpdbg->eiop_id, CTLU_EIOP_INGRESS);
	CHECK_COND_RETVAL(dpdbg->ing_dpkg, -ENAVAIL);

	/*! Ingress Key Generation */
	dpdbg->handle.dpkg_ing = sys_get_handle(FSL_MOD_KG, 2, dpdbg->eiop_id, CTLU_EIOP_INGRESS);
	CHECK_COND_RETVAL(dpdbg->handle.dpkg_ing, -ENAVAIL);

	/*! Ingress Tables */
	dpdbg->handle.dptbl_ing = sys_get_handle(FSL_MOD_TABLES_MNG, 2, dpdbg->eiop_id, CTLU_EIOP_INGRESS);
	CHECK_COND_RETVAL(dpdbg->handle.dptbl_ing, -ENAVAIL);
	
	for (i = 0; i < DPDBG_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpdbg->irqs[i]), MC_IRQ_TYPE_MSI);

	return 0;
}

void dpdbg_reset(struct dpdbg *dpdbg)
{
	// do nothing for the moment
}

void dpdbg_destroy(struct dpdbg *dpdbg)
{
	int err;

	dpdbg_reset(dpdbg);
	
	err = resman_unbind_all(dpdbg->device);
	CHECK_COND_RET(err == 0);
}

int dpdbg_get_attributes(struct dpdbg *dpdbg, struct dpdbg_attr *attributes)
{
	attributes->id = dpdbg->id;

	return 0;
}

static void dpdbg_pr_info(char *buf, int size)
{
	char subst_char;
	int i;
	int chunk_size = 256;

	for (i = 0; i < size; i += chunk_size, buf += chunk_size) {
		if (will_log(NO_ID, LOG_LEVEL_INFO)) {
			if (i + chunk_size < size) {
				subst_char = buf[chunk_size];
				buf[chunk_size] = '\0';

				fsl_print(buf);

				buf[chunk_size] = subst_char;
			} else {
				fsl_print(buf);
			}
		}
	}
}

int dpdbg_get_dpmcp_info(struct dpdbg *dpdbg, struct dpmcp *dpmcp)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dpio_info(struct dpdbg *dpdbg, struct dpio *dpio)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dprc_info(struct dpdbg *dpdbg, struct dprc *dprc)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dpbp_info(struct dpdbg *dpdbg, struct dpbp *dpbp)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dpci_info(struct dpdbg *dpdbg, struct dpci *dpci)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dpmac_info(struct dpdbg *dpdbg, struct dpmac *dpmac)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dpni_info(struct dpdbg *dpdbg, struct dpni *dpni)
{
	char *buf;
	int i;
	int count = 0;
	int ceetm_ch_idx;
	uint32_t size = 4 * KILOBYTE;

	buf = (char*)fsl_malloc(size);
	if (!buf)
		return -ENOMEM;

	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\nDPNI %d Info:\n", dpni->id);

	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tType %s\n", (dpni->type == DPNI_TYPE_NI) ? "NI" : (dpni->is_snic) ? "SNIC" : "NIC");
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tMAC ADDR: 0x%x:0x%x:0x%x:0x%x:0x%x:0x%x\n", dpni->mac_addr[0], dpni->mac_addr[1], dpni->mac_addr[2], dpni->mac_addr[3], dpni->mac_addr[4], dpni->mac_addr[5]);
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tOptions 0x%08lx\n", dpni->options);
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tMax Senders %d\n", dpni->max_senders);
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tMax Rx TCs %d:\n", dpni->max_rx_tcs);
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tMax Tx TCs %d:\n", dpni->max_tx_tcs);
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tNum CEETM channels %d:\n", dpni->num_ceetm_ch);
	
	for (i = 0; i < dpni->max_rx_tcs; i++) {
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tRX-TC[%d] :\n", i);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\t\t max-dist-size %d\n", dpni->tc_rx[i].max_dist_size);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\t\t max-fs-entries %d\n", dpni->tc_rx[i].max_fs_entries);
	}
	
	if (dpni->options & DPNI_OPT_SHARED_MAC_TABLE)
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tmax mac filters %d\n", dpni->filters.max_mac_filters);
	else {
		if (dpni->options & DPNI_OPT_UNICAST_FILTER)
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tmax unicast filters %d\n", dpni->filters.max_unicast_filters);
		if (dpni->options & DPNI_OPT_MULTICAST_FILTER)
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tmax multicast filters %d\n", dpni->filters.max_multicast_filters);
	}
	if (dpni->options & DPNI_OPT_VLAN_FILTER)
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tmax vlan filters %d\n", dpni->filters.max_vlan_filters);
	if (dpni->max_rx_tcs > 1)
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tmax qos entries %d\n", dpni->qos.max_qos_entries);

	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tepid %d\n", dpni->epid);
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tspid %d\n", dpni->spid);
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tbackup_spid %d\n", dpni->backup_spid);
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tifpid %d\n", dpni->mem_ifp_info->ifp_desc.ifp_id);
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\trx_qdid %d\n", dpni->rx_qdid);
	for( ceetm_ch_idx  = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\ttx_qdid[%d] %d\n", ceetm_ch_idx, dpni->tx_ch[ceetm_ch_idx].tx_qdid);
	
	if (dpni->options & DPNI_OPT_TX_CONF_DISABLED)
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\ttx-err-fqid %d\n", dpni->tx_conf_err.queue_info.fqid);
	else
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\ttx-conf-err-fqid %d\n", dpni->tx_conf_err.queue_info.fqid);
	
	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\trx-err-fqid %d\n", dpni->rx_err.fqid);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tCEETM_CH[%d] id: %d\n", ceetm_ch_idx, dpni->tx_ch[ceetm_ch_idx].ap.cqchid);
		for (i = 0; i < dpni->max_tx_tcs; i++) {
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\t\tTX-TC[%d] :\n", i);
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\t\tqprid %d\n", dpni->tx_ch[ceetm_ch_idx].tc_tx[i].qprid);
		}
	}

	for( i = 0 ; i < dpni->max_rx_tcs ; i++ ) {
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tRX-TC[%d] :\n", i);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\t\tqprid %d\n", dpni->tc_rx[i].qprid);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\t\tfqid-base %d, dist %d\n", dpni->tc_rx[i].fqid_base, dpni->tc_rx[i].max_dist_size);
	}

	if (dpni->max_policers) {
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tplcrids [");
		for (i = 0; i < dpni->max_policers; i++)
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "%d ", dpni->policer_ids[i]);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "]\n");
	}

	if (dpni->max_congestion_ctrl) {
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\trx-cgids [");
		for (i = 0; i < dpni->max_congestion_ctrl; i++)
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "%d ", dpni->rx_tx_conf_cgids[i].cgid);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "]\n");
	}

	if (!(dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED)) {
		for(ceetm_ch_idx = 0; ceetm_ch_idx < dpni->num_ceetm_ch; ceetm_ch_idx++ )
			for (i = 0; i < dpni->max_senders; i++) {
				SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tTX-SENDER[%d][%d] :\n", ceetm_ch_idx, i);
				SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\t\tconf-fqid %d\n", dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err.queue_info.fqid);
			}
	}

dpni_dump_error:
	dpdbg_pr_info(buf, count);
	pr_info("ID[%d]: dump size is %d bytes / %d bytes\n", dpni->id, count, size);

	fsl_free(buf);

	return 0;
}

int dpdbg_get_dpsw_info(struct dpdbg *dpdbg, struct dpsw *dpsw)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dpdmux_info(struct dpdbg *dpdbg, struct dpdmux *dpdmux)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dpseci_info(struct dpdbg *dpdbg, struct dpseci *dpseci)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dpcon_info(struct dpdbg *dpdbg, struct dpcon *dpcon)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dpdcei_info(struct dpdbg *dpdbg, struct dpdcei *dpdcei)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

int dpdbg_get_dpdmai_info(struct dpdbg *dpdbg, struct dpdmai *dpdmai)
{
	pr_info("Not implemented yet\n");
	
	return -ENOSYS;
}

static void reverse(char *str, int len)
{
	char temp;
	int i = 0;
	int j = len - 1;
	
	while (i<j) { 
		temp = str[i]; 
		str[i] = str[j]; 
		str[j] = temp; 
		i++;
		j--; 
    }
}

static void uint64tostr(uint64_t x, char *str)
{ 
	int i = 0;
	
	if (x == 0) {
		str[i++] = 0 + '0';
	}
	
	while (x) {
		str[i++] = (char)((x%10) + '0');
		x = x/10; 
	} 

	reverse(str, i); 
	str[i] = '\0'; 
} 

static void print_mem_info(uint64_t size_in_bytes, uint64_t usage_in_bytes, uint64_t free_in_bytes, char *mem_name)
{
	char size_str[DPDBG_MAX_MEM_DIGITS];
	char usage_str[DPDBG_MAX_MEM_DIGITS];
	char free_str[DPDBG_MAX_MEM_DIGITS];
	
	uint64tostr(size_in_bytes, size_str);
	uint64tostr(usage_in_bytes, usage_str);
	uint64tostr(free_in_bytes, free_str);
	
	pr_info("%s memory\n", mem_name);
	pr_info("\t Total: %s bytes \n", size_str);
	pr_info("\t Used: %s bytes \n", usage_str);
	pr_info("\t Free: %s bytes \n", free_str);
}

int dpdbg_get_mem_info()
{	
	int i;
	uint64_t size_in_bytes, usage_in_bytes, free_in_bytes;
	
	t_mem_mng *p_mem_mng = (t_mem_mng *)sys.mem_mng;
	
	pr_info("Memory info: \n");
	
	for(i = 0 ; i < ARRAY_SIZE(p_mem_mng->mem_partitions_array); i++ ) {
		if (p_mem_mng->mem_partitions_array[i].was_initialized) {
			size_in_bytes = p_mem_mng->mem_partitions_array[i].info.size;
			usage_in_bytes = p_mem_mng->mem_partitions_array[i].info.current_usage;
			free_in_bytes = size_in_bytes - usage_in_bytes;
			print_mem_info(size_in_bytes, usage_in_bytes, free_in_bytes, p_mem_mng->mem_partitions_array[i].info.name);
		}
	}

	for(i = 0 ; i < ARRAY_SIZE(p_mem_mng->phys_allocation_mem_partitions_array); i++ ) {
		if (p_mem_mng->phys_allocation_mem_partitions_array[i].was_initialized) {
			size_in_bytes = p_mem_mng->phys_allocation_mem_partitions_array[i].info.size;
			usage_in_bytes = p_mem_mng->phys_allocation_mem_partitions_array[i].info.current_usage;
			free_in_bytes = size_in_bytes - usage_in_bytes;			
			print_mem_info(size_in_bytes, usage_in_bytes, free_in_bytes, p_mem_mng->phys_allocation_mem_partitions_array[i].info.name);
		}
	}

	return 0;
}

void get_peb_free_blocks(uint32_t *offset, uint32_t *size, int *used, uint64_t *start_addr)
{
	t_mem_mng *p_mem_mng = (t_mem_mng *)sys.mem_mng;
	t_mem_mng_phys_addr_alloc_partition current_partition;

	current_partition = p_mem_mng->phys_allocation_mem_partitions_array[MEM_PART_PEB];
	*start_addr = current_partition.info.base_paddress;

	slog_get_peb_avail_range(current_partition.h_mem_manager, offset, size, used, *start_addr);
}
