/*
 * Copyright 2017-2019 NXP
 */

#ifndef _LEGACY_DPDBG_DPLIB_H
#define _LEGACY_DPDBG_DPLIB_H

/* 
 * File used to maintain compatibility with older version of dplib/flib
 * All previous version of dpdbg commands should be placed here
 * 
 */

#endif /* _LEGACY_DPDBG_DPLIB_H */
