/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPRTC_CMD_H
#define _DPRTC_CMD_H

/* default version for all dprtc commands */
#define DPRTC_CMD_VER_BASE								CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPRTC_CMD_V0									CMDHDR_CMD_VERSION(0)
#define DPRTC_CMD_V1									CMDHDR_CMD_VERSION(1)
#define DPRTC_CMD_V2									CMDHDR_CMD_VERSION(2)

/* add your new command version number here
 * Ex:
 * #define DPRTC_CMD_CREATE_VER_1                       MC_CMD_HDR_VERSION(DPRTC_CMD_VER_BASE + 1) or
 * #define DPRTC_CMD_CREATE_VER                         MC_CMD_HDR_VERSION(3)
 */

/* Command IDs */
#define DPRTC_CMD_CODE_CLOSE                               0x800
#define DPRTC_CMD_CODE_OPEN                                0x810
#define DPRTC_CMD_CODE_CREATE                              0x910
#define DPRTC_CMD_CODE_DESTROY                             0x900
#define DPRTC_CMD_CODE_GET_API_VERSION                     0xa10

#define DPRTC_CMD_CODE_ENABLE                              0x002
#define DPRTC_CMD_CODE_DISABLE                             0x003
#define DPRTC_CMD_CODE_GET_ATTR                            0x004
#define DPRTC_CMD_CODE_RESET                               0x005
#define DPRTC_CMD_CODE_IS_ENABLED                          0x006

#define DPRTC_CMD_CODE_SET_IRQ                             0x010
#define DPRTC_CMD_CODE_GET_IRQ                             0x011
#define DPRTC_CMD_CODE_SET_IRQ_ENABLE                      0x012
#define DPRTC_CMD_CODE_GET_IRQ_ENABLE                      0x013
#define DPRTC_CMD_CODE_SET_IRQ_MASK                        0x014
#define DPRTC_CMD_CODE_GET_IRQ_MASK                        0x015
#define DPRTC_CMD_CODE_GET_IRQ_STATUS                      0x016
#define DPRTC_CMD_CODE_CLEAR_IRQ_STATUS                    0x017

#define DPRTC_CMD_CODE_SET_CLOCK_OFFSET                    0x1d0
#define DPRTC_CMD_CODE_SET_FREQ_COMPENSATION               0x1d1
#define DPRTC_CMD_CODE_GET_FREQ_COMPENSATION               0x1d2
#define DPRTC_CMD_CODE_GET_TIME                            0x1d3
#define DPRTC_CMD_CODE_SET_TIME                            0x1d4
#define DPRTC_CMD_CODE_SET_ALARM                           0x1d5
#define DPRTC_CMD_CODE_SET_PERIODIC_PULSE                  0x1d6
#define DPRTC_CMD_CODE_CLEAR_PERIODIC_PULSE                0x1d7
#define DPRTC_CMD_CODE_SET_EXT_TRIGGER                     0x1d8
#define DPRTC_CMD_CODE_CLEAR_EXT_TRIGGER                   0x1d9
#define DPRTC_CMD_CODE_GET_EXT_TRIGGER_TIMESTAMP           0x1dA
#define DPRTC_CMD_CODE_SET_FIPER_LOOPBACK                  0x1dB
#define DPRTC_CMD_CODE_GET_CLOCK_OFFSET                    0x1dC

#endif /* _DPRTC_CMD_H */
