/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dprtc.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_platform.h"
#include "fsl_resman.h"
#include "fsl_eiop_rtc.h"
#include "fsl_dprtc_mc.h"
#include "dprtc.h"

static int check_dprtc_cfg(const struct dprtc *dprtc, const struct dprtc_cfg *cfg)
{
	return 0;
}

static void resources_authorization(struct dprtc *dprtc)
{
	CHECK_COND_RET(dprtc);

	if (dprtc->authorized)
		return;

	dprtc->authorized = 1;

	return;
}

static void resources_deauthorization(struct dprtc *dprtc)
{
	CHECK_COND_RET(dprtc);

	if (!dprtc->authorized)
		return;

	dprtc->authorized = 0;

	dprtc->amq.icid = (uint16_t)-1;

	return;
}

static void dprtc_set_mc_info(struct dprtc *dprtc,
	const struct dpmng_dev_cfg *dev_cfg)
{
	dprtc->id = dev_cfg->id;
	CHECK_COND_RET(dev_cfg->device);
	dprtc->device = dev_cfg->device;
	dprtc->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dprtc->dpmng);	
}

static int invoke_inter(void *dprtc, uint8_t index, uint32_t event)
{
	CHECK_COND_RETVAL(dprtc, -EINVAL);

	event_send(&(((struct dprtc *)dprtc)->irqs[index]), event);

	return 0;
}

void *g_dprtc;

int dprtc_init(struct dprtc *dprtc,
	const struct dprtc_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
	dprtc_set_mc_info(dprtc, dev_cfg);
#if 0
	if ((err = check_dprtc_cfg(dprtc, cfg)) != 0) {
		pr_err("check_dprtc_cfg failed\n");
		return err;
	}
#endif
	dprtc->amq.icid = (uint16_t)-1;
/*
	for (i = 0; i < DPRTC_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dprtc->irqs[i]), MC_IRQ_TYPE_MSI);
*/
	dprtc_set_dev_ctx(dprtc, &dev_cfg->ctx);

	dprtc->rtc = sys_get_handle(FSL_MOD_EIOP_RTC,
	               1, 0);
	//TODO - tmp
	g_dprtc = dprtc;
	
	dprtc->period = eiop_rtc_get_timestamp_period(dprtc->rtc);

	CHECK_COND_RETVAL(dprtc->rtc, -ENODEV);

	eiop_rtc_set_isr_params(dprtc->rtc, invoke_inter, dprtc, 0);
	
	return 0;
}

struct dprtc * dprtc_allocate(void)
{
	struct dprtc *dprtc;

	dprtc = (struct dprtc *)fsl_xmalloc(sizeof(struct dprtc), 0,
						CORE_CACHELINE_SIZE);
	if (dprtc)
		memset(dprtc, 0, sizeof(struct dprtc));
	return dprtc;
}

void dprtc_deallocate(struct dprtc *dprtc)
{
	fsl_xfree(dprtc);
}

void dprtc_destroy(struct dprtc *dprtc)
{
	int err;

	dprtc_reset(dprtc);
	
	resources_deauthorization(dprtc);
	
	err = resman_unbind_all(dprtc->device);
	CHECK_COND_RET(err == 0);
}

int dprtc_enable(struct dprtc *dprtc)
{
	dprtc->enabled = 1;

	return 0;
}

int dprtc_disable(struct dprtc *dprtc)
{
	dprtc->enabled = 0;

	return 0;
}

int dprtc_is_enabled(struct dprtc *dprtc, int *en)
{
	*en = dprtc->enabled;

	return 0;
}

void dprtc_reset(struct dprtc *dprtc)
{
}

int dprtc_get_attributes(struct dprtc *dprtc, struct dprtc_attr *attributes)
{
	int err;
	struct eiop_rtc_desc desc;
	
	memset(&desc, 0, sizeof(struct eiop_rtc_desc));
	
	err=sys_get_desc(SOC_MODULE_EIOP_RTC, SOC_DB_RTC_DESC_EIOP_ID, &desc, NULL);
	ASSERT_COND(!err);
		
	attributes->little_endian = desc.little_endian; 
	attributes->addr = (uint32_t)(desc.paddr & 0x0fffffff); 
	attributes->id = dprtc->id;
	attributes->period = dprtc->period;

	return 0;
}

int dprtc_set_dev_ctx(struct dprtc *dprtc, const struct dpmng_dev_ctx *dev_ctx)
{

	if (memcmp(&dprtc->amq, &(dev_ctx->amq), sizeof(struct dpmng_amq))
		!= 0) {
		CHECK_COND_RETVAL(!dprtc->enabled, -EINVAL);

		resources_deauthorization(dprtc);

		dprtc->amq = dev_ctx->amq;

		//TODO - handle this better (update on assign)
		dprtc->amq.bdi = (dev_ctx->type == DPMNG_CTX_TYPE_GPP) ? 0 : 1;

		resources_authorization(dprtc);
	}

	return 0;
}

int dprtc_set_irq(struct dprtc *dprtc,
	uint8_t irq_index,
	const struct mc_irq_cfg *irq_cfg)
{
	if (irq_index >= DPRTC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPRTC_MAX_IRQ_NUM);
		return -EINVAL;
	}

	mc_set_irq(&(dprtc->irqs[irq_index]), irq_cfg);
	return 0;
}

int dprtc_get_irq(struct dprtc *dprtc,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg)
{
	int err;

	if (irq_index >= DPRTC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPRTC_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq(&(dprtc->irqs[irq_index]), irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);
				
	return 0;
}

int dprtc_set_irq_enable(struct dprtc *dprtc, uint8_t irq_index, uint8_t en)
{
	int err;

	if (irq_index >= DPRTC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPRTC_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_set_irq_enable(&(dprtc->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dprtc_get_irq_enable(struct dprtc *dprtc, uint8_t irq_index, uint8_t *en)
{
	int err;

	if (irq_index >= DPRTC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPRTC_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_enable(&(dprtc->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dprtc_set_irq_mask(struct dprtc *dprtc, uint8_t irq_index, uint32_t mask, int version)
{
	int err;
	struct dprtc_ext_trigger_cfg trigger_cfg = { 0 };
	struct dprtc_ext_trigger_cfg *cfg = &trigger_cfg;

	if (irq_index >= DPRTC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPRTC_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_set_irq_mask(&(dprtc->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);
	/* set interrupts on periodic pulse */
	if (mask & DPRTC_EVENT_PERIODIC_PULSE_1)
		eiop_rtc_set_periodic_pulse_intr(dprtc->rtc, 0, 1);
	else
		eiop_rtc_set_periodic_pulse_intr(dprtc->rtc, 0, 0);

	if (version > 1)
	{
		if(mask & DPRTC_EVENT_EXT_TRIGGER_1)
		{
			cfg->ext_trigger_id = 1;
			dprtc_set_ext_trigger(dprtc, cfg);
		} else{
			dprtc_clear_ext_trigger(dprtc, 1);
		}

		if(mask & DPRTC_EVENT_EXT_TRIGGER_2)
		{
			cfg->ext_trigger_id = 2;
			dprtc_set_ext_trigger(dprtc, cfg);
		} else {
			dprtc_clear_ext_trigger(dprtc, 2);
		}

		if (mask & DPRTC_EVENT_PERIODIC_PULSE_2)
			eiop_rtc_set_periodic_pulse_intr(dprtc->rtc, 1, 1);
		else
			eiop_rtc_set_periodic_pulse_intr(dprtc->rtc, 1, 0);
	}
	return 0;
}

int dprtc_get_irq_mask(struct dprtc *dprtc, uint8_t irq_index, uint32_t *mask)
{
	int err;

	if (irq_index >= DPRTC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPRTC_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_mask(&(dprtc->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dprtc_get_irq_status(struct dprtc *dprtc, uint8_t irq_index, uint32_t *status)
{
	int err;

	if (irq_index >= DPRTC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPRTC_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_status(&(dprtc->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dprtc_clear_irq_status(struct dprtc *dprtc,
	uint8_t irq_index,
	uint32_t status)
{
	int err;

	if (irq_index >= DPRTC_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPRTC_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_clear_irq_status(&(dprtc->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);
	
	return 0;
}

int dprtc_set_clock_offset(struct dprtc *dprtc,
	uint64_t offset)
{
	return eiop_rtc_set_clock_offset(dprtc->rtc, offset);
}

int dprtc_get_clock_offset(struct dprtc *dprtc,
	uint64_t *offset)
{
	return eiop_rtc_get_clock_offset(dprtc->rtc, offset);
}

int dprtc_set_freq_compensation(struct dprtc *dprtc,
	uint32_t freq_compensation)
{
	return eiop_rtc_set_freq_compensation(dprtc->rtc, freq_compensation);	
}

int dprtc_get_freq_compensation(struct dprtc *dprtc,
	uint32_t *freq_compensation)
{
	return eiop_rtc_get_freq_compensation(dprtc->rtc, freq_compensation);		
}

int dprtc_get_time(struct dprtc *dprtc,
	uint64_t *time)
{
	return eiop_rtc_get_current_timestamp(dprtc->rtc, time);	
}

int dprtc_set_time(struct dprtc *dprtc,
	uint64_t time)
{
	return eiop_rtc_set_current_timestamp(dprtc->rtc, time);
}

int dprtc_set_alarm(struct dprtc *dprtc,
	struct dprtc_alarm_cfg *dprtc_alarm_cfg)
{
	struct eiop_rtc_event_cfg rtc_event_cfg = {0};
	
	switch(dprtc_alarm_cfg->alarm_id) {
	case (1):
	rtc_event_cfg.event_mask = DPRTC_EVENT_ALARM_1;
	break;		
	case (2):
	rtc_event_cfg.event_mask = DPRTC_EVENT_ALARM_2;
	break;		
	case (3):
	rtc_event_cfg.event_mask = DPRTC_EVENT_ALARM_3;
	break;
	default:
		return -EINVAL;
	}
	/* convert "1" starting index to "0" starting index. */
	rtc_event_cfg.id = dprtc_alarm_cfg->alarm_id - 1;
	rtc_event_cfg.time = dprtc_alarm_cfg->alarm_time;
	
	return eiop_rtc_set_alarm(dprtc->rtc, &rtc_event_cfg);
}
#if 0
int dprtc_set_periodic_pulse(struct dprtc *dprtc,
	struct dprtc_periodic_cfg *dprtc_periodic_cfg)
{
	struct eiop_rtc_event_cfg rtc_event_cfg = {0};
	
	switch(dprtc_periodic_cfg->periodic_pulse_id) {
	case (1):
	rtc_event_cfg.event_mask = DPRTC_EVENT_PERIODIC_PULSE_1;
	break;		
	case (2):
	rtc_event_cfg.event_mask = DPRTC_EVENT_PERIODIC_PULSE_2;
	break;		
	case (3):
	rtc_event_cfg.event_mask = DPRTC_EVENT_PERIODIC_PULSE_3;
	break;
	case (4):
	rtc_event_cfg.event_mask = DPRTC_EVENT_PERIODIC_PULSE_4;
	break;
	default:
		return -EINVAL;
	}
	/* convert "1" starting index to "0" starting index. */
	rtc_event_cfg.id = dprtc_periodic_cfg->periodic_pulse_id - 1;
	rtc_event_cfg.time = dprtc_periodic_cfg->period;
	/* avoid interrupts until user actually registers on them */
	rtc_event_cfg.disable_intr = 1;
	
	return eiop_rtc_set_periodic_pulse(dprtc->rtc, &rtc_event_cfg);
}

int dprtc_clear_periodic_pulse(struct dprtc *dprtc,
	uint8_t id)
{
	/* convert "1" starting index to "0" starting index. */
	id--;
	
	return eiop_rtc_clear_periodic_pulse(dprtc->rtc, id);
}
#endif /* 0 */

int dprtc_set_ext_trigger(struct dprtc *dprtc,
	struct dprtc_ext_trigger_cfg *dprtc_ext_trigger_cfg)
{
	struct eiop_rtc_event_cfg rtc_event_cfg = {0};
	
	switch(dprtc_ext_trigger_cfg->ext_trigger_id) {
	case (1):
	rtc_event_cfg.event_mask = DPRTC_EVENT_EXT_TRIGGER_1;
	break;		
	case (2):
	rtc_event_cfg.event_mask = DPRTC_EVENT_EXT_TRIGGER_2;
	break;		
	case (3):
	rtc_event_cfg.event_mask = DPRTC_EVENT_EXT_TRIGGER_3;
	break;
	case (4):
	rtc_event_cfg.event_mask = DPRTC_EVENT_EXT_TRIGGER_4;
	break;
	default:
		return -EINVAL;
	}
	/* convert "1" starting index to "0" starting index. */
	rtc_event_cfg.id = dprtc_ext_trigger_cfg->ext_trigger_id - 1;
	//rtc_event_cfg.use_pulse_as_input = (int)dprtc_ext_trigger_cfg->use_pulse_as_input;
	//rtc_event_cfg.use_pulse_as_input = 0;

	return eiop_rtc_set_ext_trigger(dprtc->rtc, &rtc_event_cfg);
}

int dprtc_set_fiper_loopback(struct dprtc *dprtc,
	                         struct dprtc_ext_trigger_cfg *dprtc_ext_trigger_cfg)
{
	struct eiop_rtc_event_cfg rtc_event_cfg = {0};

	/* convert "1" starting index to "0" starting index. */
	rtc_event_cfg.id = dprtc_ext_trigger_cfg->ext_trigger_id - 1;
	rtc_event_cfg.use_pulse_as_input = (int)dprtc_ext_trigger_cfg->use_pulse_as_input;

	return eiop_rtc_set_fiper_loopback(dprtc->rtc, &rtc_event_cfg);
}

int dprtc_clear_ext_trigger(struct dprtc *dprtc,
	uint8_t id)
{
	/* convert "1" starting index to "0" starting index. */
	id--;

	return eiop_rtc_clear_ext_trigger(dprtc->rtc, id);
}

int dprtc_get_ext_trigger_timestamp(struct dprtc *dprtc,
	uint8_t id,
	struct dprtc_ext_trigger_status *status)
{
	int err;

	/* convert "1" starting index to "0" starting index. */
	id--;

	err = eiop_rtc_get_ext_trigger_timestamp(dprtc->rtc, id, &status->timestamp);
	err |= eiop_rtc_get_ext_trigger_timestamp_status(dprtc->rtc, id, &status->unread_valid_timestamp);

	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

void dprtc_exceptions(struct dprtc *dprtc)
{
	CHECK_COND_RET(dprtc);

	eiop_rtc_exceptions(dprtc->rtc);
}
