/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dprtc_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "dplib/fsl_dprtc_cmd.h"
#include "dtc/dtc.h"
#include "fsl_sys.h"
#include "fsl_event_pipe.h"
#include "fsl_dprtc_mc.h"
#include "dprtc_cmd.h"
#include "legacy_dprtc_dplib.h"

/* DPRTC last supported API version */
#define DPRTC_V0_API_VER_MAJOR				1
#define DPRTC_V0_API_VER_MINOR				0

int dprtc_drv_init(void);

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dprtc *dprtc;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	return dprtc_set_dev_ctx(dprtc, dev_ctx);
}

static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dprtc_cfg dprtc_cfg = { 0 };
	struct dprtc_cfg *cfg = &dprtc_cfg;
	int err;

	dprtc = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dprtc) {
		/* NULL */
		dprtc = dprtc_allocate();
		if (!dprtc) {
			pr_err("No memory for dprtc\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dprtc_init(dprtc, cfg, &dev_cfg);
		if (err) {
			return err;
		}
		device_set_priv(dev, dprtc);
		sys_add_handle(dprtc, FSL_MOD_DPRTC, 1, dev_cfg.id);
	} else
		return -EINVAL;

	return 0;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;

	UNUSED(cmd_data);

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	dprtc_destroy(dprtc);

	sys_remove_handle(FSL_MOD_DPRTC, 1, device_get_id(dev));
	dprtc_deallocate(dprtc);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;

	UNUSED(cmd_data);

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	device_set_enable(dev, 1);

	dprtc_enable(dprtc);

	return 0;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	int err;

	UNUSED(cmd_data);

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	err = dprtc_disable(dprtc);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;

	UNUSED(cmd_data);

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	dprtc_reset(dprtc);
	device_set_enable(dev, 0);

	return 0;
}

static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	int err;
	struct dprtc_attr attr = { 0 };

	dprtc = device_get_priv(dev);
	CHECK_COND_RETVAL(dprtc, -ENODEV);

	err = dprtc_get_attributes(dprtc, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.version.major = DPRTC_V0_API_VER_MAJOR;
	attr.version.minor = DPRTC_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRTC_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	int err;
	struct dprtc_attr attr = { 0 };

	dprtc = device_get_priv(dev);
	CHECK_COND_RETVAL(dprtc, -ENODEV);

	err = dprtc_get_attributes(dprtc, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRTC_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	int en, err;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	err = dprtc_is_enabled(dprtc, &en);

	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPRTC_RSP_IS_ENABLED(cmd_data, en);
	}

	return err;
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	DPRTC_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dprtc_set_irq(dprtc, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dprtc *dprtc;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	return dprtc_set_irq(dprtc, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_GET_IRQ(cmd_data, irq_index);

	err = dprtc_get_irq(dprtc, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRTC_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dprtc *dprtc;
	int err;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	err = dprtc_get_irq(dprtc, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;

	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t irq_index;
	uint8_t enable_state;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, enable_state);

	return dprtc_set_irq_enable(dprtc, irq_index, enable_state);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t irq_index;
	uint8_t enable_state;
	int err;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dprtc_get_irq_enable(dprtc, irq_index, &enable_state);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRTC_RSP_GET_IRQ_ENABLE(cmd_data, enable_state);

	return 0;
}

static int set_irq_mask_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t irq_index;
	uint32_t mask;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dprtc_set_irq_mask(dprtc, irq_index, mask, 1);
}

static int set_irq_mask_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t irq_index;
	uint32_t mask;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dprtc_set_irq_mask(dprtc, irq_index, mask, 2);
}

static int set_fiper_loopback(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	struct dprtc_ext_trigger_cfg trigger_cfg = { 0 };
	struct dprtc_ext_trigger_cfg *cfg = &trigger_cfg;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_SET_FIPER_LOOPBACK(cmd_data, cfg);

	return dprtc_set_fiper_loopback(dprtc, cfg);

}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t irq_index;
	uint32_t mask;
	int err;
	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;
	/* Read parameters from portal */
	DPRTC_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dprtc_get_irq_mask(dprtc, irq_index, &mask);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRTC_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dprtc_get_irq_status(dprtc, irq_index, &status);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRTC_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t irq_index;
	uint32_t status;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dprtc_clear_irq_status(dprtc, irq_index, status);
}

static int set_clock_offset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint64_t offset;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_SET_CLOCK_OFFSET(cmd_data, offset);

	return dprtc_set_clock_offset(dprtc, offset);
}

static int get_clock_offset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint64_t offset;
	int err;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	err = dprtc_get_clock_offset(dprtc, &offset);
	if (err)
		return err;

	/* Read parameters from portal */
	DPRTC_RSP_GET_CLOCK_OFFSET(cmd_data, (uint64_t)offset);

	return 0;

}

static int set_freq_compensation(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint32_t freq_compensation;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_SET_FREQ_COMPENSATION(cmd_data, freq_compensation);

	return dprtc_set_freq_compensation(dprtc, freq_compensation);
}

static int get_freq_compensation(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint32_t freq_compensation;
	int err;
	
	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	err = dprtc_get_freq_compensation(dprtc, &freq_compensation);
	if (err)
		return err;
	
	DPRTC_RSP_GET_FREQ_COMPENSATION(cmd_data, freq_compensation);
	
	return 0;
}

static int get_time(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint64_t time;
	int err;
	
	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	err = dprtc_get_time(dprtc, &time);
	if (err)
		return err;
	
	DPRTC_RSP_GET_TIME(cmd_data, time);
	
	return 0;
}

static int set_time(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint64_t time;
	
	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_SET_TIME(cmd_data, time);

	return dprtc_set_time(dprtc, time);
}

static int set_alarm(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	struct dprtc_alarm_cfg alarm_cfg = { 0 };
	struct dprtc_alarm_cfg *cfg = &alarm_cfg;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_SET_ALARM(cmd_data, cfg->alarm_time);
	cfg->alarm_id = 2;

	return dprtc_set_alarm(dprtc, cfg);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPRTC_VER_MAJOR;
    uint32_t minor = DPRTC_VER_MINOR;

    DPRTC_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

#if 0
static int set_periodic_pulse(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	struct dprtc_periodic_cfg pulse_cfg = { 0 };
	struct dprtc_periodic_cfg *cfg = &pulse_cfg;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_SET_PERIODIC_PULSE(cmd_data, cfg);

	return dprtc_set_periodic_pulse(dprtc, cfg);
}

static int clear_periodic_pulse(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t id;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_CLEAR_PERIODIC_PULSE(cmd_data, id);

	return dprtc_clear_periodic_pulse(dprtc, id);
}

static int set_ext_trigger(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	struct dprtc_ext_trigger_cfg trigger_cfg = { 0 };
	struct dprtc_ext_trigger_cfg *cfg = &trigger_cfg;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_SET_EXT_TRIGGER(cmd_data, cfg);

	return dprtc_set_ext_trigger(dprtc, cfg);
}

static int clear_ext_trigger(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t id;

	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_CLEAR_EXT_TRIGGER(cmd_data, id);

	return dprtc_clear_ext_trigger(dprtc, id);
}
#endif /* 0 */
static int get_ext_trigger_timestamp(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dprtc *dprtc;
	uint8_t id;
	struct dprtc_ext_trigger_status status = { 0 };
	int err;
	dprtc = device_get_priv(dev);
	if (!dprtc)
		return -ENODEV;

	/* Read parameters from portal */
	DPRTC_CMD_GET_EXT_TRIGGER_TIMESTAMP(cmd_data, id);

	err = dprtc_get_ext_trigger_timestamp(dprtc, id, &status);
	if (err)
		return err;
	
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPRTC_RSP_GET_EXT_TRIGGER_TIMESTAMP(cmd_data, &status);

	return 0;
}


static int dprtc_drv_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dprtc_open on DPRTC %d\n", device_get_id(dev));
	return 0;
}

static int dprtc_drv_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	pr_info("Handling command: dprtc_close on DPRTC %d\n", device_get_id(dev));
	return 0;
}

static int dprtc_drv_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
        struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
        int i;
        struct {
		int code;
		int (*function)(struct device *dev,
			struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPRTC_CMD_CODE_CREATE, init, "dprtc_init", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_DESTROY, destroy, "dprtc_destroy", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_RESET, reset, "dprtc_reset", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_ENABLE, enable, "dprtc_enable", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_DISABLE, disable, "dprtc_disable", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_GET_ATTR, get_attributes_v0, "dprtc_get_attributes", DPRTC_CMD_V0 },
			{ DPRTC_CMD_CODE_IS_ENABLED, is_enabled, "dprtc_is_enabled", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_SET_IRQ, set_irq, "dprtc_set_irq", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_GET_IRQ, get_irq, "dprtc_get_irq", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dprtc_set_irq_enable", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dprtc_get_irq_enable", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_SET_IRQ_MASK, set_irq_mask_v1, "dprtc_set_irq_mask", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dprtc_get_irq_mask", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dprtc_get_irq_status", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dprtc_clear_irq_status", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_SET_CLOCK_OFFSET, set_clock_offset, "dprtc_set_clock_offset", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_SET_FREQ_COMPENSATION, set_freq_compensation, "dprtc_set_freq_compensation", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_GET_FREQ_COMPENSATION, get_freq_compensation, "dprtc_get_freq_compensation", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_GET_TIME, get_time, "dprtc_get_time", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_SET_TIME, set_time, "dprtc_set_time", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_SET_ALARM, set_alarm, "dprtc_set_alarm", DPRTC_CMD_VER_BASE },/*
			{ DPRTC_CMD_CODE_SET_PERIODIC_PULSE, set_periodic_pulse, "dprtc_set_periodic_pulse" , DPRTC_CMD_VER_BASE},
			{ DPRTC_CMD_CODE_CLEAR_PERIODIC_PULSE, clear_periodic_pulse, "dprtc_clear_periodic_pulse", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_SET_EXT_TRIGGER, set_ext_trigger, "dprtc_set_ext_trigger", DPRTC_CMD_VER_BASE },
			{ DPRTC_CMD_CODE_CLEAR_EXT_TRIGGER, clear_ext_trigger, "dprtc_clear_ext_trigger", DPRTC_CMD_VER_BASE },*/
			{ DPRTC_CMD_CODE_GET_EXT_TRIGGER_TIMESTAMP, get_ext_trigger_timestamp, "dprtc_get_ext_trigger_timestamp", DPRTC_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPRTC_CMD_CODE_GET_API_VERSION, get_api_version, "dprtc_get_api_version", DPRTC_CMD_V1 },
			{ DPRTC_CMD_CODE_GET_ATTR, get_attributes_v1, "dprtc_get_attributes", DPRTC_CMD_V1 },
			{ DPRTC_CMD_CODE_SET_IRQ_MASK, set_irq_mask_v2, "dprtc_set_irq_mask", DPRTC_CMD_V2 },
			{ DPRTC_CMD_CODE_SET_FIPER_LOOPBACK, set_fiper_loopback, "dprtc_set_fiper_loopback", DPRTC_CMD_V1 },
			{ DPRTC_CMD_CODE_GET_CLOCK_OFFSET, get_clock_offset, "dprtc_get_clock_offset", DPRTC_CMD_V1 }
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
			if (cmd == DPRTC_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPRTC %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev,
							cmd_data);
		}

	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}

static int dprtc_drv_probe_cb(void *lo, int node_off)
{
	int err = 0;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	int destroy = 0;
	int id;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(resman, "dprtc", (uint16_t)id, NO_PORTAL_ID,
			DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPRTC %.4x\n", id);
	/* create object */
	err = dprtc_drv_ctrl_cb(dev, DPRTC_CMD_VER_BASE, DPRTC_CMD_CODE_CREATE,
	                          NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dprtc", NO_PORTAL_ID, destroy);

	return err;
}

static int dprtc_drv_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}

	dev = resman_open_dev(resman, "dprtc", (uint16_t)id, NO_PORTAL_ID, 0, NULL);
	if (!dev) {
		pr_err("Can't open DPRTC 0x%.4x\n", id);
		return -ENODEV;
	}

	err |= dprtc_drv_ctrl_cb(dev, DPRTC_CMD_VER_BASE, DPRTC_CMD_CODE_DESTROY, NO_PORTAL_ID, NULL);
	err |= resman_close_dev(resman, dev, "dprtc", NO_PORTAL_ID, 0);

	return err;
}

static char *dprtc_drv_match[] = { "fsl,dprtc", "dprtc" };

int dprtc_drv_init(void)
{
	t_sys_dtc_mod_params lo_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;

	pr_info("Executing dprtc_drv_init...\n");
	
	lo_params.num_compats = ARRAY_SIZE(dprtc_drv_match);
	lo_params.compatibles = dprtc_drv_match;
	lo_params.f_prob_module = dprtc_drv_probe_cb;
	lo_params.f_remove_module = dprtc_drv_remove_cb;
	sys_dtc_register_module(&lo_params);

	cmdif_ops.open_cb = dprtc_drv_open_cb;
	cmdif_ops.close_cb = dprtc_drv_close_cb;
	cmdif_ops.ctrl_cb = dprtc_drv_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPRTC, &cmdif_ops);

	strcpy(dev_type_param.device_type, "dprtc");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPRTC_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPRTC_VER_MAJOR;
	dev_type_param.ver_minor = DPRTC_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	resman_register_device_operation(resman, "dprtc", &dev_type_param);

	return 0;
}
