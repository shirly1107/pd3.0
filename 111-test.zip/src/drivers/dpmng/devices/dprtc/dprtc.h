/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dprtc.h

 @Description   DPRTC internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPRTC_H
#define __DPRTC_H

#include "kernel/fsl_spinlock.h"
#include "fsl_dprtc_mc.h"
//#include "fsl_eiop_rtc.h"
#include "fsl_dpmng_mc.h"
#include "fsl_event_pipe.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPRTC

struct dprtc {
	uint16_t id;
	struct dpmng *dpmng;
	struct device *device;
	int enabled;
	int authorized;
	struct dpmng_amq amq;

	struct mc_irq irqs[DPRTC_MAX_IRQ_NUM];
	uint32_t period;
	struct eiop_rtc *rtc;
};

#endif /* __DPRTC_H */
