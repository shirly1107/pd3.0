/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpci.c

 @Description   library implementation

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_event_pipe.h"

#include "fsl_dpmng_mc.h"
//#include "drivers/fsl_aiop.h"
#include "fsl_dpaiop_mc.h"
#include "fsl_dpcon_mc.h"
#include "fsl_dpio_mc.h"
#include "fsl_dpbp_mc.h"
#include "dpci.h"

static int dpci_has_opr(struct dpci *dpci) {
	return dpmng_soc_has_orp() && (dpci->options & DPCI_OPT_HAS_OPR);
}

static int max_index_for_opr(struct dpci *dpci) {
	if (dpci->options & DPCI_OPT_OPR_SHARED) {
		return 1;
	}
	
	return dpci->priorities_num;
}

static struct opr_info* get_opr_info(struct dpci *dpci, uint8_t index) {
	if (dpci->options & DPCI_OPT_OPR_SHARED) {
		return &dpci->rx_queue_info[0].opr;
	}
	
	return &dpci->rx_queue_info[index].opr;
}

static int resources_allocation(struct dpci *dpci)
{
	int tmp[32] = { 0 };
	int err = 0, j;

	if ((err = allocate_resource(dpci->device, "fq", dpci->priorities_num, 1, 0, &(tmp[0]),
					"DPCI-Q"))
		!= 0)
		return err;

	for (j = 0; j < dpci->priorities_num; j++) {
		/* FQIDs */
		dpci->rx_queue_info[j].rx_fqid = (uint32_t)tmp[j];
	}
	
	if (dpci_has_opr(dpci)) {	
		for (j = 0; j < max_index_for_opr(dpci); j++) {
			err = allocate_resource(dpci->device, OPR_RES_TYPE_STR, 1, 1, 0, 
					&(get_opr_info(dpci, (uint8_t)j)->id), OPR_ERR_STR);
			CHECK_COND_RETVAL(err == 0, err, "ID[%d]: OPR resource allocation failed\n", dpci->id);
		}
	}

	return 0;
}

static int resources_deallocation(struct dpci *dpci)
{
	return resman_unbind_all(dpci->device);
}

static int resources_authorization(struct dpci *dpci)
{
	struct qbman_swp *sw_portal = NULL;
	int i, err = 0;
	uint16_t icid;
	int bdi;

	if (!dpci->authorized_rx || !dpci->authorized_tx) {
		if(dpci->ctx_type == DPMNG_CTX_TYPE_AIOP)
		{
			if (!dpci->connected_to_peer)
				return 0;

			icid = dpci->peer_amq.icid;
			bdi = dpci->peer_amq.bdi;
		}
		else
		{
			icid = dpci->amq.icid;
			bdi = dpci->amq.bdi;
		}

		dpmng_get_swportal(dpci->dpmng, (void**)&sw_portal);

		if (!dpci->authorized_rx)
		{	/* RX FQIDs */
			for (i = 0; i < dpci->priorities_num; i++)
				err = resource_authorization(
					sw_portal, bdi, icid,
					qbman_auth_type_fqid,
					&dpci->rx_queue_info[i].rx_virt_fqid,
					dpci->rx_queue_info[i].rx_fqid,
					(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-FQID");
			if (err) {
				dpmng_put_swportal(dpci->dpmng, sw_portal);
				return err;
			}
			
			if (dpci_has_opr(dpci)) {			
				for (i = 0; i < max_index_for_opr(dpci); i++) {
					err = auth_oprid(sw_portal, dpci->amq.bdi, dpci->amq.icid,
							get_opr_info(dpci, (uint8_t)i));
				}
			}
			
			dpci->authorized_rx = 1;
		}

		if (!dpci->connected_to_peer)
		{
			dpmng_put_swportal(dpci->dpmng, sw_portal);
			return 0;
		}

		if (!dpci->authorized_tx)
		{
			/* TX FQIDs */
			for (i = 0; i < dpci->peer_priorities_num; i++)
				err |= resource_authorization(
					sw_portal, bdi, icid,
					qbman_auth_type_fqid, &dpci->tx_virt_fqid[i],
					dpci->tx_fqid[i],
					(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-FQID");
			if (err) {
				dpmng_put_swportal(dpci->dpmng, sw_portal);
				return err;
			}
			dpci->authorized_tx = 1;
		}
		dpmng_put_swportal(dpci->dpmng, sw_portal);
	}
	return 0;
}

static int resources_deauthorization(struct dpci *dpci)
{
	struct qbman_swp *sw_portal = NULL;
	int i, err;
	uint16_t icid;
	int bdi;

	if (!dpci->authorized_rx && !dpci->authorized_tx)
		return 0;

	dpmng_get_swportal(dpci->dpmng, (void**)&sw_portal);
	if(dpci->ctx_type == DPMNG_CTX_TYPE_AIOP)
	{
		icid = dpci->peer_amq.icid;
		bdi = dpci->peer_amq.bdi;
	}
	else
	{
		icid = dpci->amq.icid;
		bdi = dpci->amq.bdi;
	}

	if(dpci->authorized_tx)
	{
		for (i = 0; i < dpci->peer_priorities_num; i++) {
			/* FQIDs */
			if ((err = resource_deauthorization(
				sw_portal, bdi, icid,
				qbman_auth_type_fqid, dpci->tx_virt_fqid[i],
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-FQID"))
				!= 0) {
				dpmng_put_swportal(dpci->dpmng, sw_portal);
				return err;
			}
		}
		dpci->authorized_tx = 0;
	}

	if(dpci->authorized_rx)
	{
		for (i = 0; i < dpci->priorities_num; i++) {
			if ((err = resource_deauthorization(
				sw_portal, bdi, icid,
				qbman_auth_type_fqid,
				dpci->rx_queue_info[i].rx_virt_fqid,
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-FQID"))
				!= 0) {
				dpmng_put_swportal(dpci->dpmng, sw_portal);
				return err;
			}
		}
		
		if (dpci_has_opr(dpci)) {
			for (i = 0; i < max_index_for_opr(dpci); i++) {
				err = deauth_oprid(sw_portal, dpci->amq.bdi, dpci->amq.icid,
						get_opr_info(dpci, (uint8_t)i));
				if (err) {
					dpmng_put_swportal(dpci->dpmng, (void*)sw_portal);
					return err;
				}
			}
		}
		
		dpci->authorized_rx = 0;
	}

	dpmng_put_swportal(dpci->dpmng, sw_portal);
	return 0;
}

/* queues that were already connected to destination, we only want to enable/ disable queues by disable/enable CG*/
static int queues_set_rejection_mode(struct dpci *dpci,
	uint8_t priority,
	int enable)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	uint32_t fqctrl, cgid;
	int err;

	CHECK_COND_RETVAL(dpci, -EINVAL);
	
	cgid = (uint32_t)dpmng_get_cgid(dpci->dpmng);

	dpmng_get_swportal(dpci->dpmng, (void**)&sw_portal);

	qbman_fq_attr_clear(&fqdesc);
	err = qbman_fq_query(sw_portal, dpci->rx_queue_info[priority].rx_fqid,
				&fqdesc);
	if (err != 0) {
		pr_err("queues_set_rejection_mode failed\n");
		dpmng_put_swportal(dpci->dpmng, sw_portal);
		return err;
	}

	qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);

	if (!enable) {
		fqctrl &= ~QBMAN_FQCTRL_CGR;
		cgid = 0;
	} else
		fqctrl |= QBMAN_FQCTRL_CGR;

	qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);
	qbman_fq_attr_set_cgrid(&fqdesc, cgid);

	err = qbman_fq_configure(sw_portal,
					dpci->rx_queue_info[priority].rx_fqid,
					&fqdesc);
	if (err != 0) {
		pr_err("queues_set_rejection_mode failed\n");
		dpmng_put_swportal(dpci->dpmng, sw_portal);
		return err;
	}

	dpmng_put_swportal(dpci->dpmng, sw_portal);
	return 0;
}

static int config_rx_queue(struct dpci *dpci, uint8_t priority)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	uint32_t fqctrl;
	int err, ps = 0;
	struct qbman_attr state;

	CHECK_COND_RETVAL(dpci, -EINVAL);

	dpmng_get_swportal(dpci->dpmng, (void**)&sw_portal);

	err = qbman_fq_query(sw_portal, dpci->rx_queue_info[priority].rx_fqid,
				&fqdesc);
	if (err != 0) {
		pr_err("config_rx_queue failed\n");
		dpmng_put_swportal(dpci->dpmng, sw_portal);
		return err;
	}

	if (dpci->rx_queue_info[priority].order_preservation_en) {
		qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
		fqctrl |= QBMAN_FQCTRL_HOLDACTIVE;
		qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);
	}

	ps = qbman_cacheable_pfdr();
	qbman_fq_attr_set_ctx(
		&fqdesc,
		(uint32_t)(dpci->rx_queue_info[priority].user_ctx >> 32),
		(uint32_t)(dpci->rx_queue_info[priority].user_ctx));
	if (dpci->ctx_type == DPMNG_CTX_TYPE_AIOP)
	{
		qbman_fq_attr_set_icid(&fqdesc, dpci->peer_amq.icid, dpci->peer_amq.pl);
		qbman_fq_attr_set_mctl(&fqdesc, dpci->peer_amq.bdi, 0, dpci->peer_amq.va, ps, 0);
	}
	else
	{
		qbman_fq_attr_set_icid(&fqdesc, dpci->amq.icid, dpci->amq.pl);
		qbman_fq_attr_set_mctl(&fqdesc, dpci->amq.bdi, 0, dpci->amq.va, ps, 0);
	}
	qbman_fq_attr_set_vfqid(&fqdesc, dpci->rx_queue_info[priority].rx_virt_fqid);

	err = qbman_fq_configure(sw_portal,
					dpci->rx_queue_info[priority].rx_fqid,
					&fqdesc);
	if (err != 0) {
		pr_err("qbman_fq_configure failed\n");
		dpmng_put_swportal(dpci->dpmng, sw_portal);
		return err;
	}

	err = qbman_fq_query_state(sw_portal,
					dpci->rx_queue_info[priority].rx_fqid,
					&state);
	if (err != 0) {
		pr_err("DPCI ID[%d]: qbman_fq_query failed\n", dpci->id);
		dpmng_put_swportal(dpci->dpmng, sw_portal);
		return err;
	}

	dpmng_put_swportal(dpci->dpmng, sw_portal);

	if (dpci->ctx_type == DPMNG_CTX_TYPE_AIOP &&
		dpci->rx_queue_info[priority].rx_dest_cfg.dest_type
			== DPCI_DEST_NONE) {
		uint16_t wqid_base;

		wqid_base = dpmng_get_dcp_wqid(dpci->dpmng, QBMAN_DCP_AIOP,
				QBMAN_FIRST_AIOP_DCP_CHID);
		qbman_fq_attr_set_destwq(
			&fqdesc,
			(uint32_t)(wqid_base << 3
					| dpci->rx_queue_info[priority].rx_dest_cfg.priority));

		pr_info("AIOP DPCI: set Rx FQ[%xh] in WQID[%xh]/PRIO:%d\n",
				dpci->rx_queue_info[priority].rx_fqid,
				wqid_base,
				dpci->rx_queue_info[priority].rx_dest_cfg.priority);
		dpmng_get_swportal(dpci->dpmng, (void**)&sw_portal);
		err = qbman_fq_configure(
			sw_portal, dpci->rx_queue_info[priority].rx_fqid,
			&fqdesc);

		if (err != 0) {
			dpmng_put_swportal(dpci->dpmng, sw_portal);
			pr_err( "qbman_fq_configure failed\n");
			return err;
		}

		if (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_parked) {
			err = qbman_swp_fq_schedule(
				sw_portal,
				dpci->rx_queue_info[priority].rx_fqid);
			if (err != 0) {
				pr_err("qbman_swp_fq_schedule failed\n");
				dpmng_put_swportal(dpci->dpmng, sw_portal);
				return err;
			}
		}

		dpmng_put_swportal(dpci->dpmng, sw_portal);

	} else if (dpci->rx_queue_info[priority].rx_dest_cfg.dest_type
			!= DPCI_DEST_NONE) {
		uint16_t destwq;
		if (dpci->rx_queue_info[priority].rx_dest_cfg.dest_type
			== DPCI_DEST_DPIO) {
			struct dpio *dpio =
				sys_get_handle(
					FSL_MOD_DPIO,
					1,
					dpci->rx_queue_info[priority].rx_dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpio, -ENODEV);
			err =
				dpio_get_destwq(
					dpio,
					dpci->rx_queue_info[priority].rx_dest_cfg.priority,
					&destwq);
			CHECK_COND_RETVAL(err == 0, err);
			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			fqctrl |= QBMAN_FQCTRL_FQDAN;
			qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);
		} else { /* DPCI_DEST_DPCON */
			struct dpcon *dpcon =
				sys_get_handle(
					FSL_MOD_DPCON,
					1,
					dpci->rx_queue_info[priority].rx_dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpcon, -ENODEV);
			err =
				dpcon_get_destwq(
					dpcon,
					dpci->rx_queue_info[priority].rx_dest_cfg.priority,
					&destwq);
			CHECK_COND_RETVAL(err == 0, err);
			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			fqctrl &= ~QBMAN_FQCTRL_FQDAN;
			qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);
		}
		qbman_fq_attr_set_destwq(&fqdesc, destwq);

		if (dpci->ctx_type == DPMNG_CTX_TYPE_AIOP) {
			pr_info("AIOP DPCI: set Rx FQ[%xh] in WQID[%xh]\n",
					dpci->rx_queue_info[priority].rx_fqid, destwq);
		}

		dpmng_get_swportal(dpci->dpmng, (void**)&sw_portal);
		err = qbman_fq_configure(
			sw_portal, dpci->rx_queue_info[priority].rx_fqid,
			&fqdesc);
		if (err != 0) {
			dpmng_put_swportal(dpci->dpmng, sw_portal);
			pr_err("qbman_fq_configure failed\n");
			return err;
		}

		if (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_parked) {
			err = qbman_swp_fq_schedule(
				sw_portal,
				dpci->rx_queue_info[priority].rx_fqid);
			if (err != 0) {
				pr_err("qbman_swp_fq_schedule failed\n");
				dpmng_put_swportal(dpci->dpmng, sw_portal);
				return err;
			}
		}

		dpmng_put_swportal(dpci->dpmng, sw_portal);
	}

	return 0;
}

static int invoke_inter(struct dpci *dpci, uint8_t index, uint32_t event)
{
	CHECK_COND_RETVAL(dpci, -EINVAL);

	event_send(&(dpci->irqs[index]), event);

	return 0;
}

static int dpci_config_rx_queues(struct dpci *dpci)
{
	uint8_t priority;
	int err;

	for (priority = 0; priority < dpci->priorities_num; priority++) {
		if ((err = config_rx_queue(dpci, priority)) != 0)
			return err;
	}
	return 0;

}

static int endpoint_integrity(struct dpci *dpci,
	struct linkman_endpoint *endpoint)
{
	if (endpoint->type != FSL_MOD_DPCI)
		return -EINVAL; /*! Invalid argument */
	if (endpoint->id != dpci->id)
		return -EINVAL; /*! Invalid argument */
	return 0;
}

static int event_connect(struct dpci  *dpci,
        const struct linkman_control  *control,
        struct linkman_endpoint 	  *self,
        const struct linkman_endpoint *peer,
        struct linkman_action         *action)
{
	int err = 0;
	struct dpci *dpci_peer;

	/*! Verify self endpoint integrity */
	err = endpoint_integrity(dpci, self);
	CHECK_COND_RETVAL(err == 0, err);


	if (peer->type != FSL_MOD_DPCI)
		return -EINVAL;

	if (peer->id == dpci->id) {
		pr_err("Must connect to a different DPCI\n");
		return -ENOTSUP;
	}

	dpci_peer = sys_get_handle(FSL_MOD_DPCI, 1, peer->id);

	CHECK_COND_RETVAL(dpci_peer, -ENAVAIL, "Must connect to an existing DPCI\n");

	if (dpci->ctx_type == DPMNG_CTX_TYPE_AIOP
		&& dpci_peer->priorities_num != dpci->priorities_num) {
		pr_err("AIOP DPCI Must connect to DPCI with the same number of priorities\n");
		return -ENAVAIL;
	}

	/* require completion notification */
	action->request = LINKMAN_REQUEST_COMPLETE_CB;
	//self->link.state = LINKMAN_STATE_CONNECTED;
	return 0;
}

static int event_linkup(struct dpci  *dpci,
        const struct linkman_control  *control,
        struct linkman_endpoint 	  *self,
        const struct linkman_endpoint *peer,
        struct linkman_action         *action)
{
	int err = 0;
	struct dpci *dpci_peer;

	/* Verify self endpoint integrity */
	err = endpoint_integrity(dpci, self);
	CHECK_COND_RETVAL(err == 0, err);

	CHECK_COND_RETVAL(dpci->enable, -ENAVAIL);

	dpci_peer = sys_get_handle(FSL_MOD_DPCI, 1, dpci->dpci_peer_id);
	CHECK_COND_RETVAL(dpci_peer, -ENAVAIL);

	self->valid_fields = LINKMAN_FIELD_LINK_STATE;
	self->link_state_available = 1;
	action->request = LINKMAN_REQUEST_COMPLETE_CB;


	return 0;
}

static int event_connect_completed(struct dpci  *dpci,
        const struct linkman_control  *control,
        struct linkman_endpoint 	  *self,
        const struct linkman_endpoint *peer,
        struct linkman_action         *action)
{
	int err = 0;
	struct dpci *dpci_peer;
	uint8_t priority;

	dpci_peer = sys_get_handle(FSL_MOD_DPCI, 1, peer->id);
	CHECK_COND_RETVAL(dpci_peer, -ENAVAIL);

	dpci->peer_priorities_num = dpci_peer->priorities_num;
		for (priority = 0; priority < dpci->peer_priorities_num; priority++) {
			dpci->tx_fqid[priority] =
				dpci_peer->rx_queue_info[priority].rx_fqid;
		}

		dpci->dpci_peer_id = (uint8_t)peer->id;

		if (dpci->ctx_type == DPMNG_CTX_TYPE_AIOP)
			memcpy(&dpci->peer_amq, &dpci_peer->amq, sizeof(struct dpmng_amq));

		dpci->connected_to_peer = 1;
		/* the first authorization that works for DPCI tx side also*/
		err = resources_authorization(dpci);
		if (err) {
			dpci->connected_to_peer = 0;
			return err;
		}
		err = dpci_config_rx_queues(dpci);
		CHECK_COND_RETVAL(err == 0, err);

	/*! trigger irq */
	invoke_inter(dpci, DPCI_IRQ_INDEX,
			DPCI_IRQ_EVENT_CONNECTED);

	return 0;

}

static int event_linkup_completed(struct dpci  *dpci,
        const struct linkman_control  *control,
        struct linkman_endpoint 	  *self,
        const struct linkman_endpoint *peer,
        struct linkman_action         *action)
{
	int err = 0;
	struct dpci *dpci_peer;

	dpci_peer = sys_get_handle(FSL_MOD_DPCI, 1, dpci->dpci_peer_id);
	CHECK_COND_RETVAL(dpci_peer, -ENAVAIL);

	if (dpci->ctx_type == DPMNG_CTX_TYPE_AIOP) {
		err = resources_deauthorization(dpci);
		if (err) {
			dpci->connected_to_peer = 0;
			return err;
		}

		memcpy(&dpci->peer_amq, &dpci_peer->amq, sizeof(struct dpmng_amq));

		err = resources_authorization(dpci);
		if (err) {
			dpci->connected_to_peer = 0;
			return err;
		}
	}

	err = dpci_config_rx_queues(dpci);
	CHECK_COND_RETVAL(err == 0, err);

	dpci->link_up = 1;
	self->valid_fields = LINKMAN_FIELD_LINK_STATE;
	self->link_state_available = 1;
	/*! trigger irq */
	invoke_inter(dpci, DPCI_IRQ_INDEX,
			DPCI_IRQ_EVENT_LINK_CHANGED);
	return 0;

}

static int event_linkdown(struct dpci  *dpci,
        const struct linkman_control  *control,
        struct linkman_endpoint 	  *self,
        const struct linkman_endpoint *peer,
        struct linkman_action         *action)
{

	self->link_state_available = 0;
	action->request = LINKMAN_REQUEST_COMPLETE_CB;


	return 0;
}

static int event_linkdown_completed(struct dpci  *dpci,
        const struct linkman_control  *control,
        struct linkman_endpoint 	  *self,
        const struct linkman_endpoint *peer,
        struct linkman_action         *action)
{

	dpci->link_up = 0;

	/*! trigger irq */
	invoke_inter(dpci, DPCI_IRQ_INDEX,
			DPCI_IRQ_EVENT_LINK_CHANGED);
	return 0;
}

static int event_disconnect(struct dpci  *dpci,
        const struct linkman_control  *control,
        struct linkman_endpoint 	  *self,
        const struct linkman_endpoint *peer,
        struct linkman_action         *action)
{
	uint8_t priority;

	resources_deauthorization(dpci);

	for (priority = 0; priority < dpci->peer_priorities_num; priority++) {
		dpci->tx_fqid[priority] = 0;
		dpci->tx_virt_fqid[priority] = 0;
	}
	dpci->link_up = 0;
	dpci->connected_to_peer = 0;
	dpci->peer_priorities_num = 0;
	//Sasha self->link.state = LINKMAN_STATE_IDLE;


	/*! trigger irq */
	invoke_inter(dpci, DPCI_IRQ_INDEX,
			DPCI_IRQ_EVENT_DISCONNECTED);/* might move to disconnect complete */
	return 0;
}

static int link_event(struct dpci *dpci, enum linkman_event event)
{
	int err;
	struct linkman_endpoint self;
	struct linkman_endpoint peer;
	struct linkman_control  control;
    struct linkman_connection_attr	attr;


	memset(&self, 0x0, sizeof(struct linkman_endpoint));
	memset(&peer, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));

	self.type = FSL_MOD_DPCI;
	self.id = (uint16_t)dpci->id;
	control.event = event;

	err = linkman_get_connection(dpci->linkman, &self, &peer, &attr);

	if(event == LINKMAN_EVENT_DISCONNECT && err == 0 && attr.state == LINKMAN_STATE_IDLE)
		return 0;	
	
	err = linkman_set_connection(dpci->linkman, /*! Context */
					&control, /*! Event */
					&self, /*! Self info */
					&peer); /*! dummy param */

	return err;
}

static int clear_fqid(struct dpci *dpci,
	struct dpci_rx_queue_info *rx_queue_info)
{
	CHECK_COND_RETVAL(dpci, -EINVAL);

	if (!rx_queue_info->retire_storage)
		rx_queue_info->retire_storage =
			(struct qbman_result *)fsl_xmalloc(
				sizeof(struct qbman_result), 0, 64);
	CHECK_COND_RETVAL(rx_queue_info->retire_storage, -ENOMEM);

	dpmng_clear_fqid(rx_queue_info->rx_fqid,
				rx_queue_info->retire_storage,
				&rx_queue_info->retire_pending);


	if (rx_queue_info->retire_pending == 1)
		return 0;

	rx_queue_info->user_ctx = 0;
	memset(&rx_queue_info->rx_dest_cfg, 0, sizeof(struct dpci_dest_cfg));

	return 0;
}

static int clear_rx_side(struct dpci *dpci)
{
	struct qbman_swp *sw_portal;
	int i, err = 0;

	CHECK_COND_RETVAL(dpci, -EINVAL);
	
	dpmng_get_swportal(dpci->dpmng, (void**)&sw_portal);
	
	//Retire OPRs
	if (dpci_has_opr(dpci)) {
		for (i = 0; i < max_index_for_opr(dpci); i++) {
			err = retire_opr(sw_portal, get_opr_info(dpci, (uint8_t)i));
			if (err != 0) {
				dpmng_put_swportal(dpci->dpmng, &sw_portal);
				return err;
			}
		}

		dpmng_put_swportal(dpci->dpmng, &sw_portal);
	}

	for (i = 0; i < dpci->priorities_num; i++) {
		/* RX-Q */
		err = clear_fqid(dpci, &dpci->rx_queue_info[i]);
		CHECK_COND_RETVAL(err == 0, err);
	}

	dpmng_put_swportal(dpci->dpmng, (void*)sw_portal);

	return 0;
}

struct dpci *dpci_allocate(void)
{
	struct dpci *dpci;

	dpci = (struct dpci *)fsl_malloc(sizeof(struct dpci));
	if (dpci)
		memset(dpci, 0, sizeof(struct dpci));
	return dpci;
}

void dpci_deallocate(struct dpci *dpci)
{
	fsl_free(dpci);
}

static void dpci_set_mc_info(struct dpci *dpci,
			     const struct dpmng_dev_cfg *dev_cfg)
{
	dpci->id = dev_cfg->id;
	dpci->device = dev_cfg->device;
	dpci->ctx_type = dev_cfg->ctx.type;
}

int dpci_set_dev_ctx(struct dpci *dpci, const struct dpmng_dev_ctx *dev_ctx)
{
	int err;

	if (memcmp(&dpci->amq, &(dev_ctx->amq), sizeof(struct dpmng_amq)) != 0) {
		CHECK_COND_RETVAL(!dpci->enable, -EINVAL);
		if ((err = resources_deauthorization(dpci)) != 0) {
			pr_err("ID[%d]: resources_deauthorization failed \n", dpci->id);
			return err;
		}

		dpci->amq = dev_ctx->amq;
		dpci->ctx_type = dev_ctx->type;

		if ((err = resources_authorization(dpci)) != 0) {
			pr_err("ID[%d]: resources_authorization failed \n", dpci->id);
			return err;
		}

	}

	err = dpci_config_rx_queues(dpci);
	return err;
}

int dpci_init(struct dpci *dpci,
	      const struct dpci_cfg *cfg,
	      const struct dpmng_dev_cfg *dev_cfg)
{
	uint8_t priority;
	int i, err;

	if (!cfg->num_of_priorities) {
		pr_err("Priorities were not configured for DPCI\n");
		return -EINVAL;
	}

	if (cfg->num_of_priorities > DPCI_PRIO_NUM) {
		pr_err("DPCI priorities number can't be bigger than %d \n", DPCI_PRIO_NUM);
		return -EINVAL;
	}

	dpci_set_mc_info(dpci, dev_cfg);

	dpci->priorities_num = cfg->num_of_priorities;
	dpci->options = cfg->options;

	pr_debug("resources_allocation()\n");

	if ((err = resources_allocation(dpci)) != 0) {
		resources_deallocation(dpci);
		pr_err("resources_allocation failed\n");
		return err;
	}

	dpci->linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	CHECK_COND_RETVAL(dpci->linkman, -ENAVAIL);
	dpci->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RETVAL(dpci->dpmng, -ENAVAIL);

	dpci->amq.icid = (uint16_t)-1;
	err = dpci_config_rx_queues(dpci);
	CHECK_COND_RETVAL(err == 0, err);
	for (priority = 0; priority < dpci->priorities_num; priority++) {
		if ((err = queues_set_rejection_mode(dpci, priority, 1)) != 0)
			return err;
		dpci->rx_queue_info[priority].rx_dest_cfg.dest_id =
				QBMAN_FIRST_AIOP_DCP_CHID;
		if (dpci->ctx_type == DPMNG_CTX_TYPE_AIOP) {
			dpci->rx_queue_info[priority].rx_dest_cfg.priority =
					//Ensures that:
					//dpci->priorities_num=1 => priority:0 -> WQID=7
					//dpci->priorities_num=2 => priority:0 -> WQID=0
					//						 => priority:1 -> WQID=7
					((priority == (dpci->priorities_num - 1) ? 1 : priority)
							* (QMAN_CHANNEL_WQ_PRIO_NUM - 1)) %
							QMAN_CHANNEL_WQ_PRIO_NUM;
		} else {
			dpci->rx_queue_info[priority].rx_dest_cfg.priority = 0;
		}
	}
	
	for (i = 0; i < DPCI_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpci->irqs[i]), MC_IRQ_TYPE_MSI);
	
	return 0;
}

void dpci_destroy(struct dpci *dpci)
{
	int err;
	uint8_t priority;

	if (dpci->enable)
		dpci_disable(dpci);

	resources_deauthorization(dpci);
	clear_rx_side(dpci);
	
	if ((err = link_event(dpci, LINKMAN_EVENT_DISCONNECT)) != 0)
		pr_err("Changing DPCI link state to DISCONNECT failed \n");

	resources_deallocation(dpci);

	for (priority = 0; priority < dpci->priorities_num; priority++) {
		memset(&dpci->rx_queue_info[priority].rx_dest_cfg,
				0, sizeof(struct dpci_dest_cfg));
		dpci->rx_queue_info[priority].rx_virt_fqid = 0;
	}

	/* temp till will be moved to structure*/
	for (priority = 0; priority < dpci->priorities_num; priority++)
		if (dpci->rx_queue_info[priority].retire_storage)
			fsl_xfree(dpci->rx_queue_info[priority].retire_storage);
}

int dpci_enable(struct dpci *dpci)
{
	int 	err = 0;
	struct qbman_swp *sw_portal = NULL;
	uint8_t priority;

	dpci->enable = 1;

	/*! trigger link manager state machine */
	err = link_event(dpci, LINKMAN_EVENT_LINKUP);
	if(err)
		pr_info("ID[%d]: currently link cannot be UP\n", dpci->id);

	/* congestion group for queues removed */
	for (priority = 0; priority < dpci->priorities_num; priority++)
		if ((err = queues_set_rejection_mode(dpci, priority, 0)) != 0)
		{
			link_event(dpci, LINKMAN_EVENT_LINKDOWN);
			dpci->enable = 0;
			return err;
		}
	
	//Create opr and set queues
	if (dpci_has_opr(dpci)) {
		dpmng_get_swportal(dpci->dpmng, (void**)&sw_portal);
		//Create OPRs
		for (priority = 0; priority < max_index_for_opr(dpci); priority++) {
			//Create the OPR entries
			err = create_opr(sw_portal,	get_opr_info(dpci, priority), 1); 
			if (err != 0) {
				dpmng_put_swportal(dpci->dpmng, (void*)sw_portal);
				return err;
			}
		}
		
		for (priority = 0; priority < dpci->priorities_num; priority++) {
			/* Adding/remove ORP support for queue */
			err = config_orp_fq(sw_portal, (int)dpci->rx_queue_info[priority].rx_fqid, 
					get_opr_info(dpci, priority));
			if (err != 0) {
				dpmng_put_swportal(dpci->dpmng, (void*)sw_portal);
				return err;
			}
		}
	}

	return 0;
}

int dpci_disable(struct dpci *dpci)
{
	uint8_t priority;
	int err;

	link_event(dpci, LINKMAN_EVENT_LINKDOWN);
	dpci->enable = 0;
	for (priority = 0; priority < dpci->priorities_num; priority++)
		if ((err = queues_set_rejection_mode(dpci, priority, 1)) != 0)
		{
			return err;
		}

	return 0;
}

int dpci_event_cb(void *handle,
                  const struct linkman_control   *control,
                  struct linkman_endpoint        *self,
                  const struct linkman_endpoint  *peer,
                  struct linkman_action          *action)
{
	int err = 0;
	struct dpci *dpci = handle;
	CHECK_COND_RETVAL(handle, -EINVAL);

	switch (control->event) {
	case LINKMAN_EVENT_CONNECT:
		/*! connect */
		err = event_connect(dpci, control, self, peer, action);
		break;
	case LINKMAN_EVENT_DISCONNECT:
		/*! disconnect */
		err = event_disconnect(dpci, control, self, peer, action);
		break;
	case LINKMAN_EVENT_LINKUP:
		/*! link up */
		err = event_linkup(dpci, control, self, peer, action);
		break;
	case LINKMAN_EVENT_LINKDOWN:
		/*! link down */
		err = event_linkdown(dpci, control, self, peer, action);
		break;
	default:
		break;
	}

	return err;
}

int dpci_event_complete_cb(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
		int err = 0;
		struct dpci *dpci = handle;
		CHECK_COND_RETVAL(handle, -EINVAL);

		switch (control->event) {
		case LINKMAN_EVENT_CONNECT:
			/*! connect */
			err = event_connect_completed(dpci, control, self, peer, action);
			break;
		case LINKMAN_EVENT_LINKUP:
			/*! link up */
			err = event_linkup_completed(dpci, control, self, peer, action);
			break;
		case LINKMAN_EVENT_LINKDOWN:
			/*! link up */
			err = event_linkdown_completed(dpci, control, self, peer, action);
			break;

		default:
			break;
		}

		return err;
}
int dpci_set_rx_queue(struct dpci *dpci,
	uint8_t priority,
	const struct dpci_rx_queue_cfg *cfg)
{
	int err;
	uint8_t i, j, k;
	struct dpci_rx_queue_info* qi;

	if (!cfg->options)
		return 0;

	if (priority != DPCI_ALL_QUEUES && priority >= dpci->priorities_num) {
		pr_err("priority not in range\n");
		return -EINVAL;
	}

	if (cfg->options & DPCI_QUEUE_OPT_DEST) {
		if (cfg->dest_cfg.dest_type == DPCI_DEST_DPCON) {
			struct dpcon *dpcon = sys_get_handle(
				FSL_MOD_DPCON, 1, cfg->dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpcon, -EINVAL, "dpcon_id is invalid\n");
			if (!dpcon_is_priority_in_range(
				dpcon, cfg->dest_cfg.priority)) {
				pr_err("dpcon priority not in range\n");
				return -EINVAL;
			}
			/* check that the destination DPCON uses DCP AIOP channels */
			if (dpci->ctx_type == DPMNG_CTX_TYPE_AIOP) {
				CHECK_COND_RETVAL(dpcon_is_aiop_dcp_channel_type(dpcon),
				-EINVAL,
				"Invalid FQ destination: dpcon[%d] not in AIOP container\n",
				cfg->dest_cfg.dest_id);
			}
		}

		if (cfg->dest_cfg.dest_type == DPCI_DEST_DPIO) {
			struct dpio *dpio = sys_get_handle(
				FSL_MOD_DPIO, 1, cfg->dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpio, -EINVAL, "dpio_id is invalid\n");
			if (!dpio_is_priority_in_range(
				dpio, cfg->dest_cfg.priority)) {
				pr_err("priority not in range\n");
				return -EINVAL;
			}
		}

		// In case of AIOP must check the priority even for DPCI_DEST_NONE;
		// no destination means in AIOP context that the destination is the
		// default AIOP DCP channel 0;the WQ id within the channel corresponds
		// with the destination priority not with the FQ priority level - the
		// later is used as default destination priority after dpci_init.
		if (cfg->dest_cfg.dest_type == DPCI_DEST_NONE &&
			dpci->ctx_type == DPMNG_CTX_TYPE_AIOP) {
			CHECK_COND_RETVAL(
			cfg->dest_cfg.priority < QMAN_CHANNEL_WQ_PRIO_NUM,
			-EINVAL,
			"The priority (%d) set explicitly for AIOP must be within 0-%d\n",
			cfg->dest_cfg.priority, QMAN_CHANNEL_WQ_PRIO_NUM - 1);
		}
	}

	if (priority == DPCI_ALL_QUEUES) {
		i = 0;
		j = dpci->priorities_num;
	} else {
		i = priority;
		j = priority + 1;
	}

	k = i;
	for (; k < j; k++) {
		qi = &dpci->rx_queue_info[k];
		if ((cfg->options & DPCI_QUEUE_OPT_DEST)
			&& (cfg->dest_cfg.dest_type == DPCI_DEST_NONE)
			&& (qi->rx_dest_cfg.dest_type != DPCI_DEST_NONE)) {
			// try clear and recover the FQ from the channel
			err = clear_fqid(dpci, qi);
			// clear_fqid should clear the retire pending bit
			if (qi->retire_pending) {
				pr_err("DPCI[%d]: can't retire FQ[%d] from channel\n",
				dpci->id, qi->rx_fqid);
				return -ENOTSUP;
			} else if (err) {
				pr_err("DPCI[%d]: fail to clear FQ[%d]\n",
				dpci->id, qi->rx_fqid);
				return err;
			}
		}
	}

	for (; i < j; i++) {
		if (cfg->options & DPCI_QUEUE_OPT_USER_CTX)
			dpci->rx_queue_info[i].user_ctx = cfg->user_ctx;

		if (cfg->options & DPCI_QUEUE_OPT_DEST)
			memcpy(&dpci->rx_queue_info[i].rx_dest_cfg,
				&(cfg->dest_cfg),
				sizeof(struct dpci_dest_cfg));

		if (cfg->options & DPCI_QUEUE_OPT_HOLD_ACTIVE)
			dpci->rx_queue_info[i].order_preservation_en =
					cfg->order_preservation_en;

		if (dpci->enable) {
			if ((err = config_rx_queue(dpci, i)) != 0)
				return err;
		}
	}

	return 0;
}

int dpci_get_link_state(struct dpci *dpci, int *up)
{
	struct linkman_endpoint ep1, ep2;
    struct linkman_connection_attr	attr;
	int err;

	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	/*! Obtain link */
	ep1.type = FSL_MOD_DPCI;
	ep1.id = (uint16_t)dpci->id;
	err = linkman_get_connection(dpci->linkman, &ep1, &ep2, &attr);

	if (err == 0 && attr.state == LINKMAN_STATE_LINKUP)
		*up = 1;
	else
		*up = 0;

	return 0;
}

int dpci_is_enabled(struct dpci *dpci, int *en)
{

	if (dpci->enable == 1)
		*en = 1;
	else
		*en = 0;

	return 0;
}

int dpci_get_attributes(struct dpci *dpci, struct dpci_attr *attr)
{

	attr->id = (int)dpci->id;
	attr->num_of_priorities = dpci->priorities_num;

	return 0;
}

int dpci_get_peer_attributes(struct dpci *dpci, struct dpci_peer_attr *attr)
{
	struct linkman_endpoint ep1, ep2;
    struct linkman_connection_attr linkman_attr;
	int err;

	attr->num_of_priorities = dpci->priorities_num;

	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	/*! Obtain link */
	ep1.type = FSL_MOD_DPCI;
	ep1.id = (uint16_t)dpci->id;
	err = linkman_get_connection(dpci->linkman, &ep1, &ep2, &linkman_attr);

	if (err == 0 && linkman_attr.state != LINKMAN_STATE_IDLE)
		attr->peer_id = dpci->dpci_peer_id;
	else
		attr->peer_id = -1;

	return 0;
}

int dpci_get_rx_queue(struct dpci *dpci,
	uint8_t priority,
	struct dpci_rx_queue_attr *attr)
{


	if (dpci->authorized_rx)
		attr->fqid = dpci->rx_queue_info[priority].rx_virt_fqid;
	else
		attr->fqid = DPCI_FQID_NOT_VALID;
	if (priority >= dpci->priorities_num)
		attr->fqid = DPCI_FQID_NOT_VALID;

	attr->user_ctx = dpci->rx_queue_info[priority].user_ctx;
	memcpy(&attr->dest_cfg, &dpci->rx_queue_info[priority].rx_dest_cfg,
		sizeof(struct dpci_dest_cfg));

	return 0;
}

int dpci_get_tx_queue(struct dpci *dpci,
	uint8_t priority,
	struct dpci_tx_queue_attr *attr)
{
	struct linkman_endpoint ep1, ep2;
    struct linkman_connection_attr	linkman_attr;
	int err;

	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	//! Obtain link
	ep1.type = FSL_MOD_DPCI;
	ep1.id = (uint16_t)dpci->id;
	err = linkman_get_connection(dpci->linkman, &ep1, &ep2, &linkman_attr);

	if (err == 0 && linkman_attr.state != LINKMAN_STATE_IDLE)
		attr->fqid = dpci->tx_virt_fqid[priority];
	else
		attr->fqid = DPCI_FQID_NOT_VALID;
	if (priority >= dpci->peer_priorities_num)
		attr->fqid = DPCI_FQID_NOT_VALID;

	return err;
}

int dpci_reset(struct dpci *dpci)
{
	int err;
	uint8_t priority;

	if (dpci->enable)
		dpci_disable(dpci);

	err = resources_deauthorization(dpci);
	CHECK_COND_RETVAL(err == 0, err);
	dpci->amq.icid = (uint16_t)-1;

	err = clear_rx_side(dpci);
	CHECK_COND_RETVAL(err == 0, err);

	for (priority = 0; priority < dpci->priorities_num; priority++) {
		dpci->rx_queue_info[priority].rx_dest_cfg.dest_type = DPCI_DEST_NONE;
		dpci->rx_queue_info[priority].rx_dest_cfg.dest_id =
				QBMAN_FIRST_AIOP_DCP_CHID;
		if (dpci->ctx_type == DPMNG_CTX_TYPE_AIOP) {
			dpci->rx_queue_info[priority].rx_dest_cfg.priority =
					//Ensures that:
					//dpci->priorities_num=1 => priority:0 -> WQID=7
					//dpci->priorities_num=2 => priority:0 -> WQID=0
					//						 => priority:1 -> WQID=7
					((priority == (dpci->priorities_num - 1) ? 1 : priority)
							* (QMAN_CHANNEL_WQ_PRIO_NUM - 1)) %
							QMAN_CHANNEL_WQ_PRIO_NUM;
		} else {
			dpci->rx_queue_info[priority].rx_dest_cfg.priority = 0;
		}
		dpci->rx_queue_info[priority].rx_virt_fqid = 0;
	}

	for (priority = 0; priority < dpci->priorities_num; priority++) {
		if ((err = queues_set_rejection_mode(dpci, priority, 1)) != 0)
			return err;
	}

	return 0;
}

int dpci_set_irq(struct dpci *dpci,
		 uint8_t irq_index,
		 const struct mc_irq_cfg *irq_cfg)
{
	if (irq_index >= DPCI_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPCI_MAX_IRQ_NUM);
		return -EINVAL;
	}

	mc_set_irq(&(dpci->irqs[irq_index]), irq_cfg);

	return 0;
}

int dpci_get_irq(struct dpci *dpci,
        	 uint8_t irq_index,
        	 struct mc_irq_cfg *irq_cfg)
{
	int err;
	
	if (irq_index >= DPCI_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPCI_MAX_IRQ_NUM);
		return -EINVAL;
	}

        err = mc_get_irq(&(dpci->irqs[irq_index]), irq_cfg);
        CHECK_COND_RETVAL(err == 0, err);
        
        return 0;
}

int dpci_set_irq_enable(struct dpci *dpci, uint8_t irq_index, uint8_t en)
{
	int err;
	
	if (irq_index >= DPCI_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPCI_MAX_IRQ_NUM);
		return -EINVAL;
	}

        err = mc_set_irq_enable(&(dpci->irqs[irq_index]), en);
        CHECK_COND_RETVAL(err == 0, err);
        
        return 0;
}

int dpci_get_irq_enable(struct dpci *dpci, uint8_t irq_index, uint8_t *en)
{
	int err;
	
	if (irq_index >= DPCI_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPCI_MAX_IRQ_NUM);
		return -EINVAL;
	}

       err = mc_get_irq_enable(&(dpci->irqs[irq_index]), en);
       CHECK_COND_RETVAL(err == 0, err);
       
        return 0;
}

int dpci_set_irq_mask(struct dpci *dpci, uint8_t irq_index, uint32_t mask)
{
	int err;
	
	if (irq_index >= DPCI_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPCI_MAX_IRQ_NUM);
		return -EINVAL;
	}

        err = mc_set_irq_mask(&(dpci->irqs[irq_index]), mask);
        CHECK_COND_RETVAL(err == 0, err);
        
        return 0;
}

int dpci_get_irq_mask(struct dpci *dpci, uint8_t irq_index, uint32_t *mask)
{
	int err;
	
	if (irq_index >= DPCI_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPCI_MAX_IRQ_NUM);
		return -EINVAL;
	}

        err = mc_get_irq_mask(&(dpci->irqs[irq_index]), mask);
        CHECK_COND_RETVAL(err == 0, err);
        
        return 0;
}

int dpci_get_irq_status(struct dpci *dpci,
			 uint8_t irq_index,
			 uint32_t *status)
{
	int err;
	
	if (irq_index >= DPCI_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPCI_MAX_IRQ_NUM);
		return -EINVAL;
	}

        err = mc_get_irq_status(&(dpci->irqs[irq_index]), status);
        CHECK_COND_RETVAL(err == 0, err);
        
        return 0;
}

int dpci_clear_irq_status(struct dpci *dpci,
			  uint8_t irq_index,
			  uint32_t status)
{
	int err;
	
	if (irq_index >= DPCI_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPCI_MAX_IRQ_NUM);
		return -EINVAL;
	}

        err = mc_clear_irq_status(&(dpci->irqs[irq_index]), status);
        CHECK_COND_RETVAL(err == 0, err);
        
        return 0;
}

int dpci_set_opr(struct dpci *dpci, uint8_t index, uint8_t options, struct opr_cfg *cfg) {
	int err = 0;
	int dpci_enabled;
	struct qbman_swp *sw_portal = NULL;
	struct opr_info *info = NULL;

	
	CHECK_COND_RETVAL(dpci_has_opr(dpci), -EINVAL);
		
	dpci_is_enabled(dpci, &dpci_enabled);
	CHECK_COND_RETVAL(dpci_enabled == 0, -EINVAL);
	
	if (!(dpci->options & DPCI_OPT_OPR_SHARED)) {
		CHECK_COND_RETVAL( index < dpci->priorities_num, -EINVAL);
	}
	
	info = get_opr_info(dpci, index);
				
	//Check options
	if (options & OPR_OPT_CREATE) {
		err = configure_opr(cfg, info);
		CHECK_COND_RETVAL(err == 0, err);
	} else if (options & OPR_OPT_RETIRE) {		
		dpmng_get_swportal(dpci->dpmng, (void**)&sw_portal);
		err = retire_opr(sw_portal, info);
		dpmng_put_swportal(dpci->dpmng, (void*)sw_portal);
		CHECK_COND_RETVAL(err == 0, err);
	} else {
		pr_err("ID[%d]: Invalid options for OPR\n", dpci->id);
		return -EINVAL;
	} 
	
	dpmng_put_swportal(dpci->dpmng, (void*)sw_portal);
	return err;
}

int dpci_get_opr(struct dpci *dpci, uint8_t prio, struct opr_cfg *cfg, struct opr_qry *qry) {
	struct qbman_swp *sw_portal = NULL;
	int err = 0;
		
	memset(cfg, 0, sizeof(struct opr_cfg));
	memset(qry, 0, sizeof(struct opr_qry));
	
	if (!(dpci->options & DPCI_OPT_OPR_SHARED)) {
		CHECK_COND_RETVAL( prio < dpci->priorities_num, -EINVAL);
	}
	
	dpmng_get_swportal(dpci->dpmng, (void**)&sw_portal);
		
	err = query_opr(sw_portal, get_opr_info(dpci, prio), cfg, qry);
	dpmng_put_swportal(dpci->dpmng, (void*)sw_portal);
	
	return err;
}
