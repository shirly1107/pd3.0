/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPCI_CMD_H
#define _DPCI_CMD_H

/* default version for all dpci commands */
#define DPCI_CMD_VER_BASE							CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPCI_CMD_V0									CMDHDR_CMD_VERSION(0)
#define DPCI_CMD_V1									CMDHDR_CMD_VERSION(1)
#define DPCI_CMD_V2									CMDHDR_CMD_VERSION(2)

/* Command IDs */
#define DPCI_CMD_CODE_CLOSE                             0x800
#define DPCI_CMD_CODE_OPEN                              0x807
#define DPCI_CMD_CODE_CREATE                            0x907
#define DPCI_CMD_CODE_DESTROY                           0x900
#define DPCI_CMD_CODE_GET_API_VERSION                   0xa07

#define DPCI_CMD_CODE_ENABLE                            0x002
#define DPCI_CMD_CODE_DISABLE                           0x003
#define DPCI_CMD_CODE_GET_ATTR                          0x004
#define DPCI_CMD_CODE_RESET                             0x005
#define DPCI_CMD_CODE_IS_ENABLED                        0x006

#define DPCI_CMD_CODE_SET_IRQ                           0x010
#define DPCI_CMD_CODE_GET_IRQ                           0x011
#define DPCI_CMD_CODE_SET_IRQ_ENABLE                    0x012
#define DPCI_CMD_CODE_GET_IRQ_ENABLE                    0x013
#define DPCI_CMD_CODE_SET_IRQ_MASK                      0x014
#define DPCI_CMD_CODE_GET_IRQ_MASK                      0x015
#define DPCI_CMD_CODE_GET_IRQ_STATUS                    0x016
#define DPCI_CMD_CODE_CLEAR_IRQ_STATUS                  0x017

#define DPCI_CMD_CODE_SET_RX_QUEUE                      0x0e0
#define DPCI_CMD_CODE_GET_LINK_STATE                    0x0e1
#define DPCI_CMD_CODE_GET_PEER_ATTR                     0x0e2
#define DPCI_CMD_CODE_GET_RX_QUEUE                      0x0e3
#define DPCI_CMD_CODE_GET_TX_QUEUE                      0x0e4
#define DPCI_CMD_CODE_SET_OPR                           0x0e5
#define DPCI_CMD_CODE_GET_OPR                           0x0e6

#endif /* _DPCI_CMD_H */
