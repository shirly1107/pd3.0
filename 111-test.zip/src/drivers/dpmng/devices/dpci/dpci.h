/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpci.h

 @Description   DPCI internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPCI_H
#define __DPCI_H

#include "fsl_dpci_mc.h"
#include "kernel/fsl_spinlock.h"
#include "fsl_dptbl.h"
#include "fsl_opr.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPCI

struct dpci_rx_queue_info {
	uint32_t rx_fqid;
	uint32_t rx_virt_fqid;
	uint64_t user_ctx;
	struct dpci_dest_cfg rx_dest_cfg;
	int retire_pending;
	struct qbman_result *retire_storage;
	struct opr_info opr;
	int order_preservation_en;
};

struct dpci {
	/* parameters for run-time (in order to be in cache) */
	uint32_t id;
	int enable;
	int authorized_rx;
	int authorized_tx;
	spinlock_t lock;
	uint32_t options;
	struct device *device;
	struct dpmng_amq amq;
	struct dpmng_amq peer_amq;
	enum dpmng_ctx_type ctx_type;
	struct dpmng *dpmng;
	uint8_t priorities_num;
	uint8_t peer_priorities_num;
	struct dpci_rx_queue_info rx_queue_info[DPCI_PRIO_NUM];

	uint8_t link_up;
	uint8_t connected_to_peer;
	uint8_t dpci_peer_id;
	uint32_t tx_fqid[DPCI_PRIO_NUM];
	uint32_t tx_virt_fqid[DPCI_PRIO_NUM];
	struct linkman *linkman;

	struct mc_irq irqs[DPCI_MAX_IRQ_NUM];
};

#endif /* __DPCI_H */
