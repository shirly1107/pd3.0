/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpci_drv.c

 @Description   driver implementation

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "fsl_sys.h"
#include "dtc/dtc.h"
#include "dplib/fsl_dpci_cmd.h"
#include "fsl_dpmng_mc.h"
#include "fsl_event_pipe.h"
#include "fsl_dpci_mc.h"
#include "fsl_resman.h"
#include "dpci_cmd.h"
#include "legacy_dpci_dplib.h"

/* DPCI last API version */
#define DPCI_V0_API_VER_MAJOR				2
#define DPCI_V0_API_VER_MINOR				3

int dpci_drv_init(void);

/*            cmd, cfg, param, offset, width, type, arg_name */
#define DPCI_LO_CREATE(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  8,  uint8_t,  cfg->num_of_priorities);\
	MC_RSP_OP(cmd, 2, 0,  32, uint32_t, cfg->options);\
} while (0)

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpci *dpci;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	return dpci_set_dev_ctx(dpci, dev_ctx);
}

static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpci_cfg dpci_cfg = { 0 };
	struct dpci_cfg *cfg = &dpci_cfg;
	int err;

	DPCI_CMD_CREATE(cmd_data, cfg);

	dpci = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpci) {
		/* NULL */
		dpci = dpci_allocate();
		if (!dpci) {
			pr_err("No memory for dpci\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpci_init(dpci, cfg, &dev_cfg);
		if (err) {
			return err;
		}

		device_set_priv(dev, dpci);
		sys_add_handle(dpci, FSL_MOD_DPCI, 1, dev_cfg.id);

		assign(dev, &(dev_cfg.ctx));
	} else
		return -EINVAL;

	return 0;
}

static int init_common(struct device *dev, struct dpci_cfg *cfg) {
	struct dpci *dpci;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	int err;

	dpci = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpci) {
		/* NULL */
		dpci = dpci_allocate();
		if (!dpci) {
			pr_err("No memory for dpci\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpci_init(dpci, cfg, &dev_cfg);
		if (err) {
			return err;
		}

		device_set_priv(dev, dpci);
		sys_add_handle(dpci, FSL_MOD_DPCI, 1, dev_cfg.id);

		assign(dev, &(dev_cfg.ctx));
	} else
		return -EINVAL;

	return 0;
}

static int init_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci_cfg dpci_cfg = { 0 };
	struct dpci_cfg *cfg = &dpci_cfg;
	int err = 0;

	DPCI_CMD_CREATE_v1(cmd_data, cfg);
	
	cfg->options = 0;
	
	err = init_common(dev, cfg);

	return err;
}

static int init_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci_cfg dpci_cfg = { 0 };
	struct dpci_cfg *cfg = &dpci_cfg;
	int err = 0;

	DPCI_CMD_CREATE(cmd_data, cfg);
	
	err = init_common(dev, cfg);

	return err;
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	int err;

	UNUSED(cmd_data);

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	device_set_enable(dev, 1);

	err = dpci_enable(dpci);
	if (err)
		device_set_enable(dev, 0);

	return err;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	int err;

	UNUSED(cmd_data);

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	err = dpci_disable(dpci);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;

	UNUSED(cmd_data);

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	dpci_destroy(dpci);
	
	sys_remove_handle(FSL_MOD_DPCI, 1, device_get_id(dev));
	dpci_deallocate(dpci);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	struct dpmng_dev_ctx dev_ctx;
	int err;

	UNUSED(cmd_data);

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	err = dpci_reset(dpci);
	if (!err) {
		resman_get_dev_ctx(dev, &dev_ctx, 1);
		device_set_enable(dev, 0);
		err = assign(dev, &dev_ctx);
	}
	return err;
}

static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}
static int set_rx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	uint8_t priority;
	struct dpci_rx_queue_cfg queue_cfg;
	struct dpci_rx_queue_cfg *cfg = &queue_cfg;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	memset(cfg, 0, sizeof(struct dpci_rx_queue_cfg));

	DPCI_CMD_SET_RX_QUEUE(cmd_data, priority, cfg);

	return dpci_set_rx_queue(dpci, priority, cfg);
}

static int get_link_state(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	int up;
	int err;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	err = dpci_get_link_state(dpci, &up);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPCI_RSP_GET_LINK_STATE(cmd_data, up);
	}
	return err;
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	struct dpci_attr attr = { 0 };
	int err;

	dpci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpci, -ENODEV);

	err = dpci_get_attributes(dpci, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.version.major = DPCI_V0_API_VER_MAJOR;
	attr.version.minor = DPCI_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCI_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	struct dpci_attr attr = { 0 };
	int err;

	dpci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpci, -ENODEV);

	err = dpci_get_attributes(dpci, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCI_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	int en;
	int err;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	err = dpci_is_enabled(dpci, &en);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPCI_RSP_IS_ENABLED(cmd_data, en);
	}
	return err;
}

static int get_peer_attributes(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	int err;
	struct dpci_peer_attr attributes = { 0 };
	struct dpci_peer_attr *attr = &attributes;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	err = dpci_get_peer_attributes(dpci, attr);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPCI_RSP_GET_PEER_ATTR(cmd_data, attr);
	}

	return err;
}

static int get_rx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	int err;
	struct dpci_rx_queue_attr attributes = { 0 };
	struct dpci_rx_queue_attr *attr = &attributes;
	uint8_t priority;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	DPCI_CMD_GET_RX_QUEUE(cmd_data, priority);

	err = dpci_get_rx_queue(dpci, priority, attr);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPCI_RSP_GET_RX_QUEUE(cmd_data, attr);
	}

	return err;
}

static int get_tx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	int err;
	struct dpci_tx_queue_attr attributes = { 0 };
	struct dpci_tx_queue_attr *attr = &attributes;
	uint8_t priority;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	DPCI_CMD_GET_TX_QUEUE(cmd_data, priority);

	err = dpci_get_tx_queue(dpci, priority, attr);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPCI_RSP_GET_TX_QUEUE(cmd_data, attr);
	}

	return err;
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	DPCI_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dpci_set_irq(dpci, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpci *dpci;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	return dpci_set_irq(dpci, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	/* Read parameters from portal */
	DPCI_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpci_get_irq(dpci, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCI_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpci *dpci;
	int err;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	err = dpci_get_irq(dpci, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;
	
	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	uint8_t irq_index;
	uint8_t enable_state;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	/* Read parameters from portal */
	DPCI_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, enable_state);

	return dpci_set_irq_enable(dpci, irq_index, enable_state);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	uint8_t irq_index;
	uint8_t enable_state;
	int err;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	/* Read parameters from portal */
	DPCI_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpci_get_irq_enable(dpci, irq_index, &enable_state);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCI_RSP_GET_IRQ_ENABLE(cmd_data, enable_state);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	uint8_t irq_index;
	uint32_t mask;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	/* Read parameters from portal */
	DPCI_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpci_set_irq_mask(dpci, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	/* Read parameters from portal */
	DPCI_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpci_get_irq_mask(dpci, irq_index, &mask);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCI_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	/* Read parameters from portal */
	DPCI_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpci_get_irq_status(dpci, irq_index, &status);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCI_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	uint8_t irq_index;
	uint32_t status;

	dpci = device_get_priv(dev);
	if (!dpci)
		return -ENODEV;

	/* Read parameters from portal */
	DPCI_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpci_clear_irq_status(dpci, irq_index, status);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPCI_VER_MAJOR;
    uint32_t minor = DPCI_VER_MINOR;

    DPCI_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int set_opr(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	uint8_t options, index;
	struct opr_cfg or_cfg = { 0 };
	struct opr_cfg *cfg = &or_cfg;
	int err;

	dpci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpci, -ENODEV);

	/* Read parameters from portal */
	DPCI_CMD_SET_OPR(cmd_data, index, options, cfg);

	err = dpci_set_opr(dpci, index, options, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int get_opr(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpci *dpci;
	struct opr_cfg or_cfg;
	struct opr_qry or_qry;
	uint8_t index;
	int err;

	dpci = device_get_priv(dev);
	CHECK_COND_RETVAL(dpci, -ENODEV);
	
	/* Read parameters from portal */
	DPCI_CMD_GET_OPR(cmd_data, index);

	err = dpci_get_opr(dpci, index, &or_cfg, &or_qry);
	CHECK_COND_RETVAL(err == 0, err);
	
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPCI_RSP_GET_OPR(cmd_data, &or_cfg, &or_qry);

	return 0;
}

static int dpci_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpci_open on DPCI %d\n", device_get_id(dev));
	return 0;
}

static int dpci_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpci_close on DPCI %d\n", device_get_id(dev));
	return 0;
}

static int dpci_cmd_priority_cb(void *dev, uint16_t cmd)
{
	UNUSED(dev);
	if(cmd == DPCI_CMD_CODE_GET_ATTR)
		return 1;
	else return 0;
	
}

static int dpci_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev,
			struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPCI_CMD_CODE_CREATE, init_v1, "dpci_init", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_DESTROY, destroy, "dpci_destroy", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_ENABLE, enable, "dpci_enable", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_DISABLE, disable, "dpci_disable", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_RESET, reset, "dpci_reset", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_SET_RX_QUEUE, set_rx_queue, "dpci_set_rx_queue", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_GET_LINK_STATE, get_link_state, "dpci_get_link_state", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_GET_ATTR, get_attributes_v0, "dpci_get_attributes", DPCI_CMD_V0 },
			{ DPCI_CMD_CODE_IS_ENABLED, is_enabled, "dpci_is_enabled", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_GET_PEER_ATTR, get_peer_attributes, "dpci_get_peer_attributes", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_GET_RX_QUEUE, get_rx_queue, "dpci_get_rx_queue", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_GET_TX_QUEUE, get_tx_queue, "dpci_get_tx_queue", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_SET_IRQ, set_irq, "dpci_set_irq", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_GET_IRQ, get_irq, "dpci_get_irq", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpci_set_irq_enable", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpci_get_irq_enable", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpci_set_irq_mask", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpci_get_irq_mask", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpci_get_irq_status", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpci_clear_irq_status", DPCI_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPCI_CMD_CODE_GET_API_VERSION, get_api_version, "dpci_get_version", DPCI_CMD_V1 },
			{ DPCI_CMD_CODE_GET_ATTR, get_attributes_v1, "dpci_get_attributes", DPCI_CMD_V1 },
			{ DPCI_CMD_CODE_SET_OPR, set_opr, "dpci_set_opr", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_GET_OPR, get_opr, "dpci_get_opr", DPCI_CMD_VER_BASE },
			{ DPCI_CMD_CODE_CREATE, init_v2, "dpci_init", DPCI_CMD_V2 },
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) && 
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
			if (cmd == DPCI_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPCI %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev,
							cmd_data);
		}

	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}

static uint32_t get_options(void *lo, int node_off)
{
	char *opt_str;
	int total_len;
	int len;
	int i = 0;
	uint32_t options = 0;
	struct {
		char *opt_str;
		uint32_t options;
	} map[] = {
			{ "DPCI_OPT_HAS_OPR", DPCI_OPT_HAS_OPR },
			{ "DPCI_OPT_OPR_SHARED", DPCI_OPT_OPR_SHARED }
	};

	opt_str = (char *)fdt_getprop(lo, node_off, "options", &total_len);

	if (opt_str && (int)(*opt_str) != 0 ) {
		while (total_len > 0){
			while (i < (ARRAY_SIZE(map) - 1) && strcmp(opt_str,map[i].opt_str))
				i++;
			if (!strcmp(opt_str,map[i].opt_str))
				options |= map[i].options;
			len = (int)strlen(opt_str) + 1;
			total_len -= len;
			opt_str = PTR_MOVE(opt_str, len );
			i=0;
		}
	}

	return options;
}

static int dpci_probe_cb(void *lo, int node_off)
{
	int err = 0;
	struct dpci_cfg dpci_cfg = { 0 };
	struct dpci_cfg *cfg = &dpci_cfg;
	int dpci_id;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	uint64_t val;
	int destroy = 0;

	if (getprop_val(lo, node_off, "num_of_priorities", 0, 0, &val)) {
		pr_err("'num_of_priorities' is a required field for layout dpci\n");
		return -EINVAL;
	}
	cfg->num_of_priorities = (uint8_t)val;
	cfg->options = get_options(lo, node_off);
	err = (uint16_t)get_node_id(lo, node_off, &dpci_id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(resman, "dpci", (uint16_t)dpci_id, NO_PORTAL_ID,
			DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPCI %.4x\n", dpci_id);
	DPCI_LO_CREATE(cmd_data, cfg);
	/* create object */
	err = dpci_ctrl_cb(dev, DPCI_CMD_V2, DPCI_CMD_CODE_CREATE,
	    NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpci", NO_PORTAL_ID, destroy);
	return err;
}

static char *dpci_match[] = { "fsl,dpci", "dpci" };

static int dpci_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}

	dev = resman_open_dev(resman, "dpci", (uint16_t)id, NO_PORTAL_ID, 0, NULL);
	if (!dev) {
		pr_err("Can't open DPCI 0x%.4x\n", id);
		return -ENODEV;
	}

        err |= dpci_ctrl_cb(dev, DPCI_CMD_VER_BASE, DPCI_CMD_CODE_DESTROY, NO_PORTAL_ID, NULL);
        err |= resman_close_dev(resman, dev, "dpci", NO_PORTAL_ID, 0);
	return err;
}

int dpci_drv_init(void)
{
	t_sys_dtc_mod_params lo_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	struct linkman *linkman;
	int err;

	pr_info("Executing dpci_drv_init...\n");
	
	lo_params.num_compats = ARRAY_SIZE(dpci_match);
	lo_params.compatibles = dpci_match;
	lo_params.f_prob_module = dpci_probe_cb;
	lo_params.f_remove_module = dpci_remove_cb;
	sys_dtc_register_module(&lo_params);

	cmdif_ops.open_cb = dpci_open_cb;
	cmdif_ops.close_cb = dpci_close_cb;
	cmdif_ops.ctrl_cb = dpci_ctrl_cb;
	cmdif_ops.cmd_priority_cb = dpci_cmd_priority_cb;
	cmdif_register_module(CMDIF_MOD_DPCI, &cmdif_ops);

	strcpy(dev_type_param.device_type, "dpci");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPCI_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPCI_VER_MAJOR;
	dev_type_param.ver_minor = DPCI_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;
	
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	resman_register_device_operation(resman, "dpci",
						&dev_type_param);
	/*! Link manager */
	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	if (!linkman)
		return -ENODEV;
	err = linkman_register_cb(linkman, 
	                          FSL_MOD_DPCI, 
	                          dpci_event_cb,
	                          dpci_event_complete_cb);
	return err;
}
