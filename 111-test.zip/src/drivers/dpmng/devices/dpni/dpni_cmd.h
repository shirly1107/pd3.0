/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPNI_CMD_H
#define _DPNI_CMD_H

/* default version for all dpni commands */
#define DPNI_CMD_VER_BASE                       CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPNI_CMD_V0								CMDHDR_CMD_VERSION(0)
#define DPNI_CMD_V1								CMDHDR_CMD_VERSION(1)
#define DPNI_CMD_V2								CMDHDR_CMD_VERSION(2)
#define DPNI_CMD_V3								CMDHDR_CMD_VERSION(3)
#define DPNI_CMD_V4								CMDHDR_CMD_VERSION(4)
#define DPNI_CMD_V5								CMDHDR_CMD_VERSION(5)
#define DPNI_CMD_V6								CMDHDR_CMD_VERSION(6)

/* Command Codes */
#define DPNI_CMD_CODE_OPEN                                              0x801
#define DPNI_CMD_CODE_CLOSE                                             0x800
#define DPNI_CMD_CODE_CREATE                                            0x901
#define DPNI_CMD_CODE_DESTROY                                           0x900
#define DPNI_CMD_CODE_GET_API_VERSION                                   0xa01

#define DPNI_CMD_CODE_ENABLE                                            0x002
#define DPNI_CMD_CODE_DISABLE                                           0x003
#define DPNI_CMD_CODE_GET_ATTR                                          0x004
#define DPNI_CMD_CODE_RESET                                             0x005
#define DPNI_CMD_CODE_IS_ENABLED                                        0x006

#define DPNI_CMD_CODE_SET_IRQ                                           0x010
#define DPNI_CMD_CODE_GET_IRQ                                           0x011
#define DPNI_CMD_CODE_SET_IRQ_ENABLE                                    0x012
#define DPNI_CMD_CODE_GET_IRQ_ENABLE                                    0x013
#define DPNI_CMD_CODE_SET_IRQ_MASK                                      0x014
#define DPNI_CMD_CODE_GET_IRQ_MASK                                      0x015
#define DPNI_CMD_CODE_GET_IRQ_STATUS                                    0x016
#define DPNI_CMD_CODE_CLEAR_IRQ_STATUS                                  0x017

#define DPNI_CMD_CODE_SET_POOLS                                         0x200
#define DPNI_CMD_CODE_GET_RX_BUFFER_LAYOUT                              0x201
#define DPNI_CMD_CODE_SET_RX_BUFFER_LAYOUT                              0x202
#define DPNI_CMD_CODE_GET_TX_BUFFER_LAYOUT                              0x203
#define DPNI_CMD_CODE_SET_TX_BUFFER_LAYOUT                              0x204
#define DPNI_CMD_CODE_SET_TX_CONF_BUFFER_LAYOUT                         0x205
#define DPNI_CMD_CODE_GET_TX_CONF_BUFFER_LAYOUT                         0x206
#define DPNI_CMD_CODE_SET_L3_CHKSUM_VALIDATION                          0x207
#define DPNI_CMD_CODE_GET_L3_CHKSUM_VALIDATION                          0x208
#define DPNI_CMD_CODE_SET_L4_CHKSUM_VALIDATION                          0x209
#define DPNI_CMD_CODE_GET_L4_CHKSUM_VALIDATION                          0x20A
#define DPNI_CMD_CODE_SET_ERRORS_BEHAVIOR                               0x20B
#define DPNI_CMD_CODE_SET_TX_CONF_REVOKE                                0x20C

#define DPNI_CMD_CODE_GET_QDID                                          0x210
#define DPNI_CMD_CODE_GET_SP_INFO                                       0x211
#define DPNI_CMD_CODE_GET_TX_DATA_OFFSET                                0x212
#define DPNI_CMD_CODE_GET_COUNTER                                       0x213
#define DPNI_CMD_CODE_SET_COUNTER                                       0x214
#define DPNI_CMD_CODE_GET_LINK_STATE                                    0x215
#define DPNI_CMD_CODE_SET_MAX_FRAME_LENGTH                              0x216
#define DPNI_CMD_CODE_GET_MAX_FRAME_LENGTH                              0x217
#define DPNI_CMD_CODE_SET_MTU                                           0x218
#define DPNI_CMD_CODE_GET_MTU                                           0x219
#define DPNI_CMD_CODE_SET_LINK_CFG                                      0x21A
#define DPNI_CMD_CODE_SET_TX_SHAPING                                    0x21B

#define DPNI_CMD_CODE_SET_MCAST_PROMISC                                 0x220
#define DPNI_CMD_CODE_GET_MCAST_PROMISC                                 0x221
#define DPNI_CMD_CODE_SET_UNICAST_PROMISC                               0x222
#define DPNI_CMD_CODE_GET_UNICAST_PROMISC                               0x223
#define DPNI_CMD_CODE_SET_PRIM_MAC                                      0x224
#define DPNI_CMD_CODE_GET_PRIM_MAC                                      0x225
#define DPNI_CMD_CODE_ADD_MAC_ADDR                                      0x226
#define DPNI_CMD_CODE_REMOVE_MAC_ADDR                                   0x227
#define DPNI_CMD_CODE_CLR_MAC_FILTERS                                   0x228

#define DPNI_CMD_CODE_ENABLE_VLAN_FILTER                                0x230
#define DPNI_CMD_CODE_ADD_VLAN_ID                                       0x231
#define DPNI_CMD_CODE_REMOVE_VLAN_ID                                    0x232
#define DPNI_CMD_CODE_CLR_VLAN_FILTERS                                  0x233

#define DPNI_CMD_CODE_SET_RX_TC_DIST                                    0x235
#define DPNI_CMD_CODE_SET_TX_FLOW                                       0x236
#define DPNI_CMD_CODE_GET_TX_FLOW                                       0x237
#define DPNI_CMD_CODE_SET_RX_FLOW                                       0x238
#define DPNI_CMD_CODE_GET_RX_FLOW                                       0x239
#define DPNI_CMD_CODE_SET_RX_ERR_QUEUE                                  0x23A
#define DPNI_CMD_CODE_GET_RX_ERR_QUEUE                                  0x23B

#define DPNI_CMD_CODE_SET_RX_TC_POLICING                                0x23E
#define DPNI_CMD_CODE_SET_RX_TC_EARLY_DROP                              0x23F

#define DPNI_CMD_CODE_SET_QOS_TBL                                       0x240
#define DPNI_CMD_CODE_ADD_QOS_ENT                                       0x241
#define DPNI_CMD_CODE_REMOVE_QOS_ENT                                    0x242
#define DPNI_CMD_CODE_CLR_QOS_TBL                                       0x243
#define DPNI_CMD_CODE_ADD_FS_ENT                                        0x244
#define DPNI_CMD_CODE_REMOVE_FS_ENT                                     0x245
#define DPNI_CMD_CODE_CLR_FS_ENT                                        0x246
#define DPNI_CMD_CODE_SET_VLAN_INSERTION                                0x247
#define DPNI_CMD_CODE_SET_VLAN_REMOVAL                                  0x248
#define DPNI_CMD_CODE_SET_IPR                                           0x249
#define DPNI_CMD_CODE_SET_IPF                                           0x24A
#define DPNI_CMD_CODE_SET_IPSEC                                         0x24B
#define DPNI_CMD_CODE_IPSEC_ADD_SA                                      0x24C
#define DPNI_CMD_CODE_IPSEC_REMOVE_SA                                   0x24D
#define DPNI_CMD_CODE_IPSEC_FLUSH                                       0x24E
#define DPNI_CMD_CODE_IPSEC_SA_GET_STATS                                0x24F

#define DPNI_CMD_CODE_SET_TX_PRIORITIES                                 0x250
#define DPNI_CMD_CODE_GET_RX_TC_POLICING                                0x251
#define DPNI_CMD_CODE_GET_RX_TC_EARLY_DROP                              0x252
#define DPNI_CMD_CODE_SET_RX_TC_CONGESTION_NOTIFICATION                 0x253
#define DPNI_CMD_CODE_GET_RX_TC_CONGESTION_NOTIFICATION                 0x254
#define DPNI_CMD_CODE_SET_TX_TC_CONGESTION_NOTIFICATION                 0x255
#define DPNI_CMD_CODE_GET_TX_TC_CONGESTION_NOTIFICATION                 0x256
#define DPNI_CMD_CODE_SET_TX_CONF                                       0x257
#define DPNI_CMD_CODE_GET_TX_CONF                                       0x258
#define DPNI_CMD_CODE_SET_TX_CONF_CONGESTION_NOTIFICATION               0x259
#define DPNI_CMD_CODE_GET_TX_CONF_CONGESTION_NOTIFICATION               0x25A
#define DPNI_CMD_CODE_SET_TX_TC_EARLY_DROP                              0x25B
#define DPNI_CMD_CODE_GET_TX_TC_EARLY_DROP                              0x25C

#define DPNI_CMD_CODE_GET_STATISTICS                                    0x25D
#define DPNI_CMD_CODE_RESET_STATISTICS                                  0x25E
#define DPNI_CMD_CODE_GET_QUEUE                                         0x25F
#define DPNI_CMD_CODE_SET_QUEUE                                         0x260
#define DPNI_CMD_CODE_GET_TAILDROP                                      0x261
#define DPNI_CMD_CODE_SET_TAILDROP                                      0x262
#define DPNI_CMD_CODE_GET_PORT_MAC_ADDR                                 0x263

#define DPNI_CMD_CODE_GET_BUFFER_LAYOUT                                 0x264
#define DPNI_CMD_CODE_SET_BUFFER_LAYOUT                                 0x265

#define DPNI_CMD_CODE_SET_CONGESTION_NOTIFICATION                       0x267
#define DPNI_CMD_CODE_GET_CONGESTION_NOTIFICATION                       0x268
#define DPNI_CMD_CODE_SET_EARLY_DROP                                    0x269
#define DPNI_CMD_CODE_GET_EARLY_DROP                                    0x26A

#define DPNI_CMD_CODE_GET_OFFLOAD                                       0x26B
#define DPNI_CMD_CODE_SET_OFFLOAD                                       0x26C
#define DPNI_CMD_CODE_SET_TX_CONFIRMATION_MODE                          0x266
#define DPNI_CMD_CODE_GET_TX_CONFIRMATION_MODE                          0x26D

#define DPNI_CMD_CODE_SET_OPR			                            	0x26E
#define DPNI_CMD_CODE_GET_OPR				           					0x26F

#ifndef OBSOLETED_SP_API
#define DPNI_CMD_CODE_LOAD_SW_SEQUENCE			           				0x270
#define DPNI_CMD_CODE_ENABLE_SW_SEQUENCE		           				0x271
#define DPNI_CMD_CODE_GET_SW_SEQUENCE_LAYOUT	           				0x272
#endif	/* OBSOLETED_SP_API */

#define DPNI_CMDID_SET_RX_FS_DIST										0x273
#define DPNI_CMDID_SET_RX_HASH_DIST										0x274
#define DPNI_CMDID_ADD_CUSTOM_TPID										0x275
#define DPNI_CMDID_REMOVE_CUSTOM_TPID									0x276
#define DPNI_CMDID_GET_CUSTOM_TPID										0x277
#define DPNI_CMD_CODE_GET_LINK_CFG										0x278
#define DPNI_CMD_CODE_SET_SINGLE_STEP_CFG								0x279
#define DPNI_CMD_CODE_GET_SINGLE_STEP_CFG								0x27A
#define DPNI_CMD_CODE_SET_PORT_CFG										0x27B
#define DPNI_CMD_CODE_GET_PORT_CFG										0x27C

#define DPNI_CMD_CODE_DUMP_TABLE                           				0x27D

#define DPNI_CMD_CODE_SET_SP_PROFILE			           				0x27E
#define DPNI_CMD_CODE_GET_QDID_EX										0x27F

#endif /* _DPNI_CMD_H */
