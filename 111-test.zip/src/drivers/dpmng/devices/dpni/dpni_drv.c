/*
 * Copyright 2013-2021 NXP
 */

/**************************************************************************//*
 @File          dpni_drv.c

 @Description   driver implementation

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "fsl_malloc.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "kernel/device.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "fsl_sys.h"
#include "dtc/dtc.h"
#include "dplib/fsl_dpni_cmd.h"
#include "drivers/fsl_edma.h"
#include "drivers/fsl_aiop.h"
#include "fsl_dpmng_mc.h"
#include "cmdif_srv.h"
#include "fsl_event_pipe.h"
#include "fsl_resman.h"
#include "fsl_dpni_mc.h"
#include "fsl_opr.h"
#include "dpni_cmd.h"
#include "legacy_dpni_dplib.h"
#include "dpni.h"

/* DPNI last supported API version */
#define DPNI_V0_API_VER_MAJOR				6
#define DPNI_V0_API_VER_MINOR				0

int dpni_drv_init(void);

#define DPNI_CMD_EXTRACT_CFG_PARAMS	8
#define DPNI_DPL_EXT			(uint64_t)(-1)
#define DPNI_CMD_EXTRACT_EXT_PARAMS_OLD	32
#define DPNI_CMD_EXTRACT_EXT_PARAMS	64
#define DPNI_CMD_EARLY_DROP_EXT_PARAMS	13

#ifndef OBSOLETED_SP_API
#define DPNI_CMD_SW_SEQUENCE_LAYOUT_EXT_PARAMS	DPPARSER_MAX_SP
#endif	/* OBSOLETED_SP_API */

#define CIPHER_KEY_OFFSET	60
#define AUTH_KEY_OFFSET		40
#define OUTER_HDR_OFFSET	20
#define IS_SHARED_FS_ENABLED ((attr.options & DPNI_OPT_SHARED_FS) ==  DPNI_OPT_SHARED_FS)

/*            cmd, cfg, param, offset, width, type, arg_name */
#define DPNI_LO_CREATE_V0(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,	8,  uint8_t,  cfg->adv.max_tcs); \
	MC_RSP_OP(cmd, 0, 8,	8,  uint8_t,  cfg->adv.max_senders); \
	MC_RSP_OP(cmd, 0, 16,	8,  uint8_t,  cfg->mac_addr[5]); \
	MC_RSP_OP(cmd, 0, 24,	8,  uint8_t,  cfg->mac_addr[4]); \
	MC_RSP_OP(cmd, 0, 32,	8,  uint8_t,  cfg->mac_addr[3]); \
	MC_RSP_OP(cmd, 0, 40,	8,  uint8_t,  cfg->mac_addr[2]); \
	MC_RSP_OP(cmd, 0, 48,	8,  uint8_t,  cfg->mac_addr[1]); \
	MC_RSP_OP(cmd, 0, 56,	8,  uint8_t,  cfg->mac_addr[0]); \
	MC_RSP_OP(cmd, 1, 0,	32, uint32_t, cfg->adv.options); \
	MC_RSP_OP(cmd, 2, 0,	8,  uint8_t,  cfg->adv.max_unicast_filters); \
	MC_RSP_OP(cmd, 2, 8,	8,  uint8_t,  cfg->adv.max_multicast_filters); \
	MC_RSP_OP(cmd, 2, 16,	8,  uint8_t,  cfg->adv.max_vlan_filters); \
	MC_RSP_OP(cmd, 2, 24,	8,  uint8_t,  cfg->adv.max_qos_entries); \
	MC_RSP_OP(cmd, 2, 32,	8,  uint8_t,  cfg->adv.max_qos_key_size); \
	MC_RSP_OP(cmd, 2, 48,	8,  uint8_t,  cfg->adv.max_dist_key_size); \
	MC_RSP_OP(cmd, 2, 56,	8,  enum net_prot, cfg->adv.start_hdr); \
	MC_RSP_OP(cmd, 4, 48,	8,  uint8_t, cfg->adv.max_policers); \
	MC_RSP_OP(cmd, 4, 56,	8,  uint8_t, cfg->adv.max_congestion_ctrl); \
	MC_RSP_OP(cmd, 5, 0,	64, uint64_t, cfg->adv.ext_cfg_iova); \
} while (0)

/*            cmd, cfg, param, offset, width, type, arg_name */
#define DPNI_LO_CREATE_V1(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, uint32_t,  (cfg)->options); \
	MC_RSP_OP(cmd, 0, 32,  8,  uint8_t,  (cfg)->num_queues); \
	MC_RSP_OP(cmd, 0, 40,  8,  uint8_t,  (cfg)->num_tcs); \
	MC_RSP_OP(cmd, 0, 48,  8,  uint8_t,  (cfg)->mac_filter_entries); \
	MC_RSP_OP(cmd, 1,  0,  8,  uint8_t,  (cfg)->vlan_filter_entries); \
	MC_RSP_OP(cmd, 1, 16,  8,  uint8_t,  (cfg)->qos_entries); \
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t,  (cfg)->fs_entries); \
	MC_RSP_OP(cmd, 1, 48,  8, uint8_t,   (cfg)->num_rx_tcs); \
} while (0)

/*            cmd, cfg, param, offset, width, type, arg_name */
#define DPNI_LO_CREATE_V2(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, uint32_t,  (cfg)->options); \
	MC_RSP_OP(cmd, 0, 32,  8,  uint8_t,  (cfg)->num_queues); \
	MC_RSP_OP(cmd, 0, 40,  8,  uint8_t,  (cfg)->num_tcs); \
	MC_RSP_OP(cmd, 0, 48,  8,  uint8_t,  (cfg)->mac_filter_entries); \
	MC_RSP_OP(cmd, 1,  0,  8,  uint8_t,  (cfg)->vlan_filter_entries); \
	MC_RSP_OP(cmd, 1, 16,  8,  uint8_t,  (cfg)->qos_entries); \
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t,  (cfg)->fs_entries); \
	MC_RSP_OP(cmd, 1, 48,  8, uint8_t,   (cfg)->num_rx_tcs); \
	MC_RSP_OP(cmd, 2,  0,  8,  uint8_t,  (cfg)->num_cgs); \
} while (0)

/*            cmd, cfg, param, offset, width, type, arg_name */
#define DPNI_LO_CREATE_V5(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, uint32_t,  (cfg)->options); \
	MC_RSP_OP(cmd, 0, 32,  8,  uint8_t,  (cfg)->num_queues); \
	MC_RSP_OP(cmd, 0, 40,  8,  uint8_t,  (cfg)->num_tcs); \
	MC_RSP_OP(cmd, 0, 48,  8,  uint8_t,  (cfg)->mac_filter_entries); \
	MC_RSP_OP(cmd, 1,  0,  8,  uint8_t,  (cfg)->vlan_filter_entries); \
	MC_RSP_OP(cmd, 1, 16,  8,  uint8_t,  (cfg)->qos_entries); \
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t,  (cfg)->fs_entries); \
	MC_RSP_OP(cmd, 1, 48,  8,  uint8_t,  (cfg)->num_rx_tcs); \
	MC_RSP_OP(cmd, 2,  0,  8,  uint8_t,  (cfg)->num_cgs); \
	MC_RSP_OP(cmd, 2,  8, 16, uint16_t,  (cfg)->num_opr); \
	MC_RSP_OP(cmd, 2,  24, 8,  uint8_t,  (cfg)->dist_key_size); \
} while (0)

#define DPNI_LO_CREATE_V6(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0,  0, 32, uint32_t,  (cfg)->options); \
	MC_RSP_OP(cmd, 0, 32,  8,  uint8_t,  (cfg)->num_queues); \
	MC_RSP_OP(cmd, 0, 40,  8,  uint8_t,  (cfg)->num_tcs); \
	MC_RSP_OP(cmd, 0, 48,  8,  uint8_t,  (cfg)->mac_filter_entries); \
	MC_RSP_OP(cmd, 0, 56,  8,  uint8_t,  (cfg)->num_ceetm_ch); \
	MC_RSP_OP(cmd, 1,  0,  8,  uint8_t,  (cfg)->vlan_filter_entries); \
	MC_RSP_OP(cmd, 1, 16,  8,  uint8_t,  (cfg)->qos_entries); \
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t,  (cfg)->fs_entries); \
	MC_RSP_OP(cmd, 1, 48,  8,  uint8_t,  (cfg)->num_rx_tcs); \
	MC_RSP_OP(cmd, 2,  0,  8,  uint8_t,  (cfg)->num_cgs); \
	MC_RSP_OP(cmd, 2,  8, 16, uint16_t,  (cfg)->num_opr); \
	MC_RSP_OP(cmd, 2,  24, 8,  uint8_t,  (cfg)->dist_key_size); \
} while (0)

static void read_ipsec_sa_cfg_extention(struct dpni_ipsec_sa_cfg *cfg,
	uint64_t *ext_params)
{
	int i;

	cfg->spi = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0, 0);
	cfg->options = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0, 0);
	cfg->mode = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0, 0);
	cfg->direction = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0, 0);
	cfg->seq_num = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0, 0);
	cfg->seq_num_ext = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0, 0);

	cfg->auth.alg = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0, 0);
	cfg->auth.key_size = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0,
						0);
	cfg->auth.key_paddr = fsl_virt_to_phys(
		&ext_params[0] + AUTH_KEY_OFFSET);

	cfg->cipher.alg = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0, 0);
	for (i = 0; i < 16; i++)
		cfg->cipher.iv[i] = (uint8_t)u64_dec(ext_params[0], 0, 0);
	for (i = 0; i < 4; i++)
		cfg->cipher.nonce_or_salt[i] = (uint8_t)u64_dec(ext_params[0],
								0, 0);
	cfg->cipher.key_size = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0,
						0);
	cfg->cipher.key_paddr = fsl_virt_to_phys(
		&ext_params[0] + CIPHER_KEY_OFFSET);

	cfg->in.anti_replay = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0,
						0);
	for (i = 0; i < 16; i++)
		cfg->in.ip_dst[i] = (uint8_t)u64_dec(ext_params[0], 0, 0);
	for (i = 0; i < 16; i++)
		cfg->in.ip_src[i] = (uint8_t)u64_dec(ext_params[0], 0, 0);

	cfg->out.frag_size = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0,
						0);
	cfg->out.outer_hdr_size = (uint8_t)u64_dec(swap_uint64(ext_params[0]),
							0, 0);
	cfg->out.outer_hdr_paddr = fsl_virt_to_phys(
		&ext_params[0] + OUTER_HDR_OFFSET);

	cfg->lifetime.hard_kb = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0,
							0);
	cfg->lifetime.hard_packet = (uint8_t)u64_dec(
		swap_uint64(ext_params[0]), 0, 0);
	cfg->lifetime.hard_sec = (uint8_t)u64_dec(swap_uint64(ext_params[0]),
							0, 0);
	cfg->lifetime.soft_kb = (uint8_t)u64_dec(swap_uint64(ext_params[0]), 0,
							0);
	cfg->lifetime.soft_packet = (uint8_t)u64_dec(
		swap_uint64(ext_params[0]), 0, 0);
	cfg->lifetime.soft_sec = (uint8_t)u64_dec(swap_uint64(ext_params[0]),
							0, 0);
}

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpni *dpni;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	return dpni_set_dev_ctx(dpni, dev_ctx);
}

struct mc_cmd_data_ext {
	struct mc_cmd_data cmd_data;
	uint64_t ext_params[DPNI_CMD_EXTRACT_CFG_PARAMS];
};

static int init_common(struct device *dev, struct dpni_cfg *cfg)
{
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpni *dpni;
	int err;

	dpni = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpni) {
		/* NULL */
		dpni = dpni_allocate();
		if (!dpni) {
			pr_err("No memory for dpni\n");
			return -ENOMEM;
		}
		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpni_init(dpni, cfg, &dev_cfg);
		if( err ) {
			dpni_deallocate(dpni);
			return err;
		}
		device_set_priv(dev, dpni);
		sys_add_handle(dpni, FSL_MOD_DPNI, 1, dev_cfg.id);
	} else
		return -EINVAL;

	return 0;
}

static int init_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni_cfg dpni_cfg = { 0 };
	struct dpni_cfg *cfg = &dpni_cfg;
	uint64_t ext_params[DPNI_CMD_EXTRACT_CFG_PARAMS] = { 0 };
	struct mc_cmd_data_ext *dpl_cmd;
	int i, err, iter = 0;
	struct qbman_desc qbman_desc;

	DPNI_CMD_CREATE_V0(cmd_data, cfg);
	cfg->adv.single_sender = 0;

	/* Get extended cfg */
	if (cfg->adv.ext_cfg_iova == 0) {
		/* Workaround for backward compatibility */
		MC_CMD_OP(cmd_data, 3, 0, 8, uint8_t,
				cfg->adv.ext_cfg.tc_cfg[0].max_dist);
		MC_CMD_OP(cmd_data, 3, 8, 8, uint8_t,
				cfg->adv.ext_cfg.tc_cfg[1].max_dist);
		MC_CMD_OP(cmd_data, 3, 16, 8, uint8_t,
				cfg->adv.ext_cfg.tc_cfg[2].max_dist);
		MC_CMD_OP(cmd_data, 3, 24, 8, uint8_t,
				cfg->adv.ext_cfg.tc_cfg[3].max_dist);
		MC_CMD_OP(cmd_data, 3, 32, 8, uint8_t,
				cfg->adv.ext_cfg.tc_cfg[4].max_dist);
		MC_CMD_OP(cmd_data, 3, 40, 8, uint8_t,
				cfg->adv.ext_cfg.tc_cfg[5].max_dist);
		MC_CMD_OP(cmd_data, 3, 48, 8, uint8_t,
				cfg->adv.ext_cfg.tc_cfg[6].max_dist);
		MC_CMD_OP(cmd_data, 3, 56, 8, uint8_t,
				cfg->adv.ext_cfg.tc_cfg[7].max_dist);
		MC_CMD_OP(cmd_data, 4, 0, 16, uint16_t,
				cfg->adv.ext_cfg.ipr_cfg.max_reass_frm_size);
		MC_CMD_OP(cmd_data, 4, 16, 16, uint16_t,
				cfg->adv.ext_cfg.ipr_cfg.min_frag_size_ipv4);
		MC_CMD_OP(cmd_data, 4, 32, 16, uint16_t,
				cfg->adv.ext_cfg.ipr_cfg.min_frag_size_ipv6);
		MC_CMD_OP(cmd_data, 5, 0, 16, uint16_t,
				cfg->adv.ext_cfg.ipr_cfg.max_open_frames_ipv4);
		MC_CMD_OP(cmd_data, 5, 16, 16, uint16_t,
				cfg->adv.ext_cfg.ipr_cfg.max_open_frames_ipv6);
		MC_CMD_OP(cmd_data, 5, 32, 8, uint8_t,
				cfg->adv.ext_cfg.ipsec_cfg.sa_selectors);
		MC_CMD_OP(cmd_data, 5, 40, 8, uint8_t,
				cfg->adv.ext_cfg.ipsec_cfg.num_sa_ipv4);
		MC_CMD_OP(cmd_data, 5, 48, 8, uint8_t,
				cfg->adv.ext_cfg.ipsec_cfg.num_sa_ipv6);
	} else if (cfg->adv.ext_cfg_iova == DPNI_DPL_EXT) {
		/* extension from DPL */
		dpl_cmd = (struct mc_cmd_data_ext *)cmd_data;
		DPNI_EXT_EXTENDED_CFG(dpl_cmd->ext_params,
					(&cfg->adv.ext_cfg));
	} else {
		/* command from portal */

		/* Read from DMA */
		err = dpmng_dev_memcpy(dev, ext_params, cfg->adv.ext_cfg_iova,
				DPNI_CMD_EXTRACT_CFG_PARAMS * sizeof(uint64_t),
				1);
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}

		DPNI_EXT_EXTENDED_CFG(ext_params, (&cfg->adv.ext_cfg));
	}

	memset(&qbman_desc, 0, sizeof(struct qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, &iter);

	if (!err)
	{
		// check if max_tcs is greater than the max number of CQS per channel
		if (cfg->adv.max_tcs > qbman_desc.dcp[0].ceetm_instance[0].num_cqs_per_channel)
		{
			pr_err("max_tcs cannot be greater than %d on this platform\n",
					qbman_desc.dcp[0].ceetm_instance[0].num_cqs_per_channel);
			return -EINVAL;
		}
	}

	/* max_dist should not be greater than the maximum distribution size supported
	 * by MC */
	for (i = 0; i < cfg->adv.max_tcs && i < DPNI_MAX_RX_TC; i++)
		CHECK_COND_RETVAL((cfg->adv.ext_cfg.tc_cfg[i].max_dist <= DPNI_MAX_DIST_SIZE),
						-EINVAL,
						"max_dist for traffic class %d cannot be greater than %d\n",
						i + 1, DPNI_MAX_DIST_SIZE);
	cfg->adv.max_rx_tcs = cfg->adv.max_tcs > DPNI_MAX_RX_TC ? DPNI_MAX_RX_TC : cfg->adv.max_tcs;

	return init_common(dev, cfg);
}

static int create_common(struct device *dev, struct dpni_cfg_v1 *cfg_v1, int ver)
{
	struct dpni_cfg dpni_cfg = {0};
	struct dpni_extended_cfg *ext_cfg = &dpni_cfg.adv.ext_cfg;
	int i, iter = 0, err;
	struct qbman_desc qbman_desc;

	memset(&qbman_desc, 0, sizeof(struct qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, &iter);

	if (!err)
	{
		// check if num_tcs is greater than the max number of CQS per channel
		if (cfg_v1->num_tcs > qbman_desc.dcp[0].ceetm_instance[0].num_cqs_per_channel)
		{
			pr_err("num_tcs cannot be greater than %d on this platform\n",
					qbman_desc.dcp[0].ceetm_instance[0].num_cqs_per_channel);
			return -EINVAL;
		}
	}

	if (cfg_v1->options & DPNI_OPT_V1_HAS_OPR)
	{
		if ((cfg_v1->options & DPNI_OPT_V1_OPR_PER_TC) && (cfg_v1->options & DPNI_OPT_V1_CUSTOM_OPR))
		{
			pr_err("option CUSTOM_OPR is incompatible with OPR_PER_TC\n");
			return -EINVAL;
		}
		
		if (cfg_v1->options & DPNI_OPT_V1_CUSTOM_OPR)
		{
			if (cfg_v1->num_opr > DPNI_MAX_OPR)
			{
				cfg_v1->num_opr = DPNI_MAX_OPR;
				pr_warn("num_opr cannot be grater than %d fall back to this value\n", DPNI_MAX_OPR);
			}
		}
	}

	/* set defaults, if needed */
	if (!cfg_v1->num_queues)
		cfg_v1->num_queues = 1;
	if (!cfg_v1->num_tcs)
		cfg_v1->num_tcs = 1;
	if (cfg_v1->options & DPNI_OPT_V1_NO_MAC_FILTER)
		cfg_v1->mac_filter_entries = 0;
	if (cfg_v1->options & DPNI_OPT_V1_NO_FS)
		cfg_v1->fs_entries = 0;
	else if (!cfg_v1->fs_entries)
		cfg_v1->fs_entries = 64;
	if(cfg_v1->options & DPNI_OPT_V1_PFDR_IN_PEB)
		cfg_v1->default_pps = QBMAN_PFDR_POOL_PEB;

	if( ver<2 ) {
		cfg_v1->num_rx_tcs = 0;
		cfg_v1->num_cgs = 0;
	}

	/* convert config to dpni_cfg */
	dpni_cfg.adv.max_vlan_filters = (uint8_t)cfg_v1->vlan_filter_entries;
	dpni_cfg.adv.max_tcs = cfg_v1->num_tcs;
	dpni_cfg.adv.max_rx_tcs = cfg_v1->num_rx_tcs == 0 ? (cfg_v1->num_tcs > DPNI_MAX_RX_TC ? DPNI_MAX_RX_TC : cfg_v1->num_tcs) : cfg_v1->num_rx_tcs;
	dpni_cfg.adv.max_multicast_filters = 0;
	dpni_cfg.adv.max_unicast_filters = cfg_v1->mac_filter_entries;
	if( cfg_v1->options & DPNI_OPT_V1_SINGLE_SENDER ) {
		dpni_cfg.adv.max_senders = 1;
		dpni_cfg.adv.single_sender = 1;
	}
	else {
		dpni_cfg.adv.max_senders = cfg_v1->num_queues;
		dpni_cfg.adv.single_sender = 0;
	}
	dpni_cfg.adv.max_qos_entries = cfg_v1->qos_entries;
	dpni_cfg.adv.default_pps = cfg_v1->default_pps;

	if (!(cfg_v1->options & DPNI_OPT_V5_SHARED_FS)) {
		for (i=0; i<DPNI_MAX_RX_TC; i++) {
			ext_cfg->tc_cfg[i].max_dist = cfg_v1->num_queues;
			ext_cfg->tc_cfg[i].max_fs_entries = cfg_v1->fs_entries;
		}
	} else {
		ext_cfg->tc_cfg[0].max_dist = cfg_v1->num_queues;
		ext_cfg->tc_cfg[0].max_fs_entries = cfg_v1->fs_entries;
	}

	/* We leave FS on even if there is a single queue, just in case FS is
	 * used as ACL
	 */
	dpni_cfg.adv.options |= DPNI_OPT_DIST_HASH |
			DPNI_OPT_SHARED_MAC_TABLE;

	if (cfg_v1->vlan_filter_entries)
		dpni_cfg.adv.options |= DPNI_OPT_VLAN_FILTER;

	if (cfg_v1->options & DPNI_OPT_V1_TX_FRM_RELEASE)
		dpni_cfg.adv.options |= DPNI_OPT_TX_CONF_DISABLED;

	if (!(cfg_v1->options & DPNI_OPT_V1_NO_MAC_FILTER))
		dpni_cfg.adv.options |= DPNI_OPT_UNICAST_FILTER |
				DPNI_OPT_MULTICAST_FILTER;

	if (cfg_v1->options & DPNI_OPT_V1_HAS_POLICING)
		dpni_cfg.adv.max_policers = cfg_v1->num_tcs;

	dpni_cfg.adv.shared_congestion = 0;

	if (cfg_v1->options & DPNI_OPT_V1_CUSTOM_CG) {
		if (cfg_v1->num_cgs < cfg_v1->num_tcs) {
			dpni_cfg.adv.shared_congestion = 1;
			cfg_v1->options |= DPNI_OPT_V1_SHARED_CONGESTION;
		}
		else {
			if (cfg_v1->num_cgs < DPNI_MAX_CG)
				dpni_cfg.adv.max_congestion_ctrl = cfg_v1->num_cgs;
			else
				dpni_cfg.adv.max_congestion_ctrl = DPNI_MAX_CG;
			dpni_cfg.adv.options |= DPNI_OPT_CUSTOM_CG;
		}
	}
	else
		dpni_cfg.adv.max_congestion_ctrl = cfg_v1->num_tcs;

	if (cfg_v1->options & DPNI_OPT_V1_SHARED_CONGESTION) {
		dpni_cfg.adv.max_congestion_ctrl = 1;
		if( cfg_v1->num_tcs==1 )
			pr_warn("dpni: option DPNI_OPT_V1_SHARED_CONGESTION ignored because num_tcs==1\n");
		else
			dpni_cfg.adv.shared_congestion = 1;
	}

	if (cfg_v1->options & DPNI_OPT_V1_HAS_KEY_MASKING)
		dpni_cfg.adv.options |= DPNI_OPT_FS_MASK_SUPPORT |
				DPNI_OPT_QOS_MASK_SUPPORT;

	if (!(cfg_v1->options & DPNI_OPT_V1_NO_FS))
		dpni_cfg.adv.options |= DPNI_OPT_DIST_FS;
	
	if (cfg_v1->options & DPNI_OPT_V1_HAS_OPR)
		dpni_cfg.adv.options |= DPNI_OPT_HAS_OPR;
	
	if (cfg_v1->options & DPNI_OPT_V1_OPR_PER_TC)
		dpni_cfg.adv.options |= DPNI_OPT_OPR_PER_TC;
	
	if (cfg_v1->options & DPNI_OPT_V1_HAS_OPR)
	{
		if (cfg_v1->options & DPNI_OPT_V1_OPR_PER_TC)
			dpni_cfg.adv.max_opr = dpni_cfg.adv.max_rx_tcs;
		else if (cfg_v1->options & DPNI_OPT_V1_CUSTOM_OPR)
		{
			dpni_cfg.adv.options |= DPNI_OPT_CUSTOM_OPR;
			if (cfg_v1->num_opr == 0)
				/* max_rx_tcs*num_queues is most of the time less than DPNI_MAX_OPR
				 * One is how many rx queues are configured in this dpni
				 * The other one is how many rx queues are maximum any dpni on the socket 
				 */
				dpni_cfg.adv.max_opr = (uint16_t)(dpni_cfg.adv.max_rx_tcs * cfg_v1->num_queues);
			else
				dpni_cfg.adv.max_opr = cfg_v1->num_opr;
		}
		else
			dpni_cfg.adv.max_opr = (uint16_t)(dpni_cfg.adv.max_rx_tcs * cfg_v1->num_queues);
	}
	else
		dpni_cfg.adv.max_opr = 0;

	if (ver > 4)
	{
		if (cfg_v1->options & DPNI_OPT_V5_SHARED_HASH_KEY)
				dpni_cfg.adv.options |= DPNI_OPT_SHARED_HASH_KEY;

		if (cfg_v1->options & DPNI_OPT_V5_SHARED_FS) {
				dpni_cfg.adv.options |= DPNI_OPT_SHARED_FS;
				pr_info("DPNI_OPT_SHARED_FS is active for dpni\n");
		}

		if ((cfg_v1->dist_key_size < 1) || (cfg_v1->dist_key_size > 56))
		{
			pr_debug("dist_key_size outside [1,56] interval, falling back to 56\n", cfg_v1->dist_key_size);
			dpni_cfg.adv.max_dist_key_size = 56;
		}
		else
			dpni_cfg.adv.max_dist_key_size = cfg_v1->dist_key_size;
	}
	else
		/* hardcoded, not configurable before version 5 */
		dpni_cfg.adv.max_dist_key_size = 56;

	if( ver < 6 ) {
		cfg_v1->num_ceetm_ch = 0;
	}
	dpni_cfg.adv.num_ceetm_ch = cfg_v1->num_ceetm_ch;
	
	return init_common(dev, &dpni_cfg);
}

static int init_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni_cfg_v1 cfg_v1 = { 0 };
	DPNI_CMD_CREATE(cmd_data, &cfg_v1);

	return create_common(dev, &cfg_v1, 1);
}

static int init_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni_cfg_v1 cfg_v1 = { 0 };
	DPNI_CMD_CREATE(cmd_data, &cfg_v1);

	return create_common(dev, &cfg_v1, 2);
}

static int init_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni_cfg_v1 cfg_v1 = { 0 };
	DPNI_CMD_CREATE_V3(cmd_data, &cfg_v1);

	return create_common(dev, &cfg_v1, 3);
}

static int init_v4(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni_cfg_v1 cfg_v1 = { 0 };
	DPNI_CMD_CREATE_V4(cmd_data, &cfg_v1);

	return create_common(dev, &cfg_v1, 4);
}

static int init_v5(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni_cfg_v1 cfg_v1 = { 0 };
	DPNI_CMD_CREATE_V5(cmd_data, &cfg_v1);

	return create_common(dev, &cfg_v1, 5);
}

static int init_v6(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni_cfg_v1 cfg_v1 = { 0 };
	DPNI_CMD_CREATE_V6(cmd_data, &cfg_v1);

	return create_common(dev, &cfg_v1, 6);
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;

	UNUSED(cmd_data);

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	dpni_destroy(dpni);

	sys_remove_handle(FSL_MOD_DPNI, 1, device_get_id(dev));
	dpni_deallocate(dpni);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int set_pools(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_pools_cfg pools_cfg = { 0 };
	struct dpni_pools_cfg *cfg = &pools_cfg;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_POOLS_VER_BASE(cmd_data, cfg);

	return dpni_set_pools(dpni, cfg);
}

static int set_pools_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_pools_cfg pools_cfg = { 0 };
	struct dpni_pools_cfg *cfg = &pools_cfg;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_POOLS_V2(cmd_data, cfg);

	return dpni_set_pools(dpni, cfg);
}

static int set_pools_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_pools_cfg pools_cfg = { 0 };
	struct dpni_pools_cfg *cfg = &pools_cfg;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_POOLS_V3(cmd_data, cfg);

	return dpni_set_pools(dpni, cfg);
}

static int enable_vlan_filter(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ENABLE_VLAN_FILTER(cmd_data, en);

	return dpni_enable_vlan_filter(dpni, en);
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	device_set_enable(dev, 1);

	err = dpni_enable(dpni);
	if (err)
		device_set_enable(dev, 0);

	return err;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int err;

	UNUSED(cmd_data);

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_disable(dpni);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int err = 0;
	UNUSED(cmd_data);

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_reset(dpni);

	device_set_enable(dev, 0);

	return err;
}

static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}

#ifdef TKT011436 
static int resume_by_resman(struct device *dev)
{
	struct dpni *dpni;
	int err = 0, en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_resume(dpni);

	err = dpni_is_enabled(dpni, &en);
	if(!err && en) {
		device_set_enable(dev, 1);
	}

	return err;
}

static int restore_by_resman(struct device *dev)
{
	struct dpni *dpni;
	int err = 0, en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_restore_after_eiop_reset(dpni);

	err = dpni_is_enabled(dpni, &en);
	if(!err && en) {
		device_set_enable(dev, 1);
	}

	return err;
}

static int empty_check_by_resman(struct device *dev)
{
	struct dpni *dpni;
	int err = 0;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_empty_check(dpni);

	return err;
}

static int graceful_stop_by_resman(struct device *dev)
{
	struct dpni *dpni;
	int err = 0, en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_graceful_stop(dpni);
	
	err = dpni_is_enabled(dpni, &en);
	if(!err && en) {
		device_set_enable(dev, 0);
	}

	return err;
}
#endif /* TKT011436 */

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_attr attr = { 0 };
	uint64_t ext_params[DPNI_CMD_EXTRACT_CFG_PARAMS] = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_ATTRIBUTES_V0(cmd_data, &attr);

	err = dpni_get_attributes(dpni, &attr);
	CHECK_COND_RETVAL(err == 0, err);

	attr.version.major = DPNI_V0_API_VER_MAJOR;
	attr.version.minor = DPNI_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	if (attr.ext_cfg_iova == 0) { //Workaround for backward compatibility
		MC_RSP_OP(cmd_data, 3,  0,  8, uint8_t,  attr.ext_cfg.tc_cfg[0].max_dist);
		MC_RSP_OP(cmd_data, 3,  8,  8, uint8_t,  attr.ext_cfg.tc_cfg[1].max_dist);
		MC_RSP_OP(cmd_data, 3, 16,  8, uint8_t,  attr.ext_cfg.tc_cfg[2].max_dist);
		MC_RSP_OP(cmd_data, 3, 24,  8, uint8_t,  attr.ext_cfg.tc_cfg[3].max_dist);
		MC_RSP_OP(cmd_data, 3, 32,  8, uint8_t,  attr.ext_cfg.tc_cfg[4].max_dist);
		MC_RSP_OP(cmd_data, 3, 40,  8, uint8_t,  attr.ext_cfg.tc_cfg[5].max_dist);
		MC_RSP_OP(cmd_data, 3, 48,  8, uint8_t,  attr.ext_cfg.tc_cfg[6].max_dist);
		MC_RSP_OP(cmd_data, 3, 56,  8, uint8_t,  attr.ext_cfg.tc_cfg[7].max_dist);
		MC_RSP_OP(cmd_data, 4,  0, 16, uint16_t, attr.ext_cfg.ipr_cfg.max_reass_frm_size);
		MC_RSP_OP(cmd_data, 4, 16, 16, uint16_t, attr.ext_cfg.ipr_cfg.min_frag_size_ipv4);
		MC_RSP_OP(cmd_data, 4, 32, 16, uint16_t, attr.ext_cfg.ipr_cfg.min_frag_size_ipv6);

		MC_RSP_OP(cmd_data, 5,  0, 16, uint16_t, attr.ext_cfg.ipr_cfg.max_open_frames_ipv4);
		MC_RSP_OP(cmd_data, 5, 16, 16, uint16_t, attr.ext_cfg.ipr_cfg.max_open_frames_ipv6);
	} else {
		/* prepare extended attr */
		DPNI_PREP_EXTENDED_CFG(ext_params, (&attr.ext_cfg));

		/* Write to DMA */
		err = dpmng_dev_memcpy(dev, ext_params, attr.ext_cfg_iova,
				DPNI_CMD_EXTRACT_CFG_PARAMS * sizeof(uint64_t),
				0);
		if (err) {
			pr_err("Error writing extended DMA parameters");
			return err;
		}
	}

	return 0;
}


static int get_attributes_common(struct device *dev, struct dpni_attr_v1 *attr_v1)
{
	struct dpni *dpni;
	struct dpni_attr attr = { 0 };
	int i, err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_attributes(dpni, &attr);
	CHECK_COND_RETVAL(err == 0, err);

	attr_v1->vlan_filter_entries = attr.max_vlan_filters;
	attr_v1->num_rx_tcs = attr.max_rx_tcs;
	attr_v1->num_tx_tcs = attr.max_tx_tcs;
	attr_v1->qos_entries = attr.max_qos_entries;
	attr_v1->qos_key_size = attr.actual_qos_key_size;
	attr_v1->fs_key_size = attr.max_dist_key_size;

	attr_v1->fs_entries = (uint16_t)-1;
	attr_v1->num_queues = attr.max_senders;
	if (!IS_SHARED_FS_ENABLED) {
		for (i=0; i<attr.max_rx_tcs; i++) {
			attr_v1->fs_entries = MIN(attr_v1->fs_entries,
						attr.ext_cfg.tc_cfg[i].max_fs_entries);
			attr_v1->num_queues = MIN(attr_v1->num_queues,
						(uint8_t)attr.ext_cfg.tc_cfg[i].max_dist);
		}
	} else {
		attr_v1->fs_entries = MIN(attr_v1->fs_entries,
							attr.ext_cfg.tc_cfg[0].max_fs_entries);
		attr_v1->num_queues = MIN(attr_v1->num_queues,
							(uint8_t)attr.ext_cfg.tc_cfg[0].max_dist);
	}

	if (attr.options & DPNI_OPT_SHARED_MAC_TABLE)
		attr_v1->mac_filter_entries = attr.max_unicast_filters;
	else
		attr_v1->mac_filter_entries = MIN(attr.max_unicast_filters,
				attr.max_multicast_filters);

	if (attr.options & DPNI_OPT_TX_CONF_DISABLED)
		attr_v1->options |= DPNI_OPT_V1_TX_FRM_RELEASE;
	if (!(attr.options & DPNI_OPT_UNICAST_FILTER) ||
			!(attr.options & DPNI_OPT_MULTICAST_FILTER))
		attr_v1->options |= DPNI_OPT_V1_NO_MAC_FILTER;
	if (attr.max_policers >= attr.max_rx_tcs)
		attr_v1->options |= DPNI_OPT_V1_HAS_POLICING;
	if (attr.shared_congestion)
		attr_v1->options |= DPNI_OPT_V1_SHARED_CONGESTION;
	else if (attr.options & DPNI_OPT_CUSTOM_CG)
		attr_v1->options |= DPNI_OPT_V1_CUSTOM_CG;
	if (attr.options & DPNI_OPT_FS_MASK_SUPPORT &&
			attr.options & DPNI_OPT_QOS_MASK_SUPPORT)
		attr_v1->options |= DPNI_OPT_V1_HAS_KEY_MASKING;
	if (!(attr.options & DPNI_OPT_DIST_FS))
		attr_v1->options |= DPNI_OPT_V1_NO_FS;
	if (attr.options & DPNI_OPT_HAS_OPR)
		attr_v1->options |= DPNI_OPT_V1_HAS_OPR;
	if (attr.options & DPNI_OPT_OPR_PER_TC)
		attr_v1->options |= DPNI_OPT_V1_OPR_PER_TC;
	if( dpni->single_sender ) {
		attr_v1->options |= DPNI_OPT_V1_SINGLE_SENDER;
	}
	if (attr.options & DPNI_OPT_SHARED_HASH_KEY)
		attr_v1->options |= DPNI_OPT_V5_SHARED_HASH_KEY;

	if (attr.options & DPNI_OPT_SHARED_FS)
			attr_v1->options |= DPNI_OPT_V5_SHARED_FS;

	if (attr.options & DPNI_OPT_CUSTOM_OPR)
			attr_v1->options |= DPNI_OPT_V1_CUSTOM_OPR;

	attr_v1->wriop_version = attr.wriop_version;
	attr_v1->num_cgid = attr.num_cgid;
	attr_v1->num_opr = attr.max_opr;

	attr_v1->num_ceetm_ch = attr.num_ceetm_ch;

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni_attr_v1 attr_v1 = { 0 };

	get_attributes_common(dev, &attr_v1);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	attr_v1.num_ceetm_ch = 0;
	attr_v1.num_opr = 0;
	DPNI_RSP_GET_ATTRIBUTES(cmd_data, &attr_v1);

	return 0;
}

static int get_attributes_v4(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni_attr_v1 attr_v1 = { 0 };

	get_attributes_common(dev, &attr_v1);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	attr_v1.num_opr = 0;
	DPNI_RSP_GET_ATTRIBUTES(cmd_data, &attr_v1);

	return 0;
}

static int get_attributes_v5(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni_attr_v1 attr_v1 = { 0 };

	get_attributes_common(dev, &attr_v1);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_ATTRIBUTES(cmd_data, &attr_v1);

	return 0;
}

static int set_errors_behavior(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_error_cfg error_cfg = { 0 };
	struct dpni_error_cfg *cfg = &error_cfg;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_ERRORS_BEHAVIOR(cmd_data, cfg);

	return dpni_set_errors_behavior(dpni, cfg);
}

static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_is_enabled(dpni, &en);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_IS_ENABLED(cmd_data, en);
	}

	return err;
}

static int get_rx_buffer_layout(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_buffer_layout buffer_layout = { 0 };
	struct dpni_buffer_layout *layout = &buffer_layout;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_rx_buffer_layout(dpni, layout);

	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_RX_BUFFER_LAYOUT(cmd_data, layout);
	}
	return err;
}

static int set_rx_buffer_layout(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_buffer_layout buffer_layout = { 0 };
	struct dpni_buffer_layout *layout = &buffer_layout;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_RX_BUFFER_LAYOUT(cmd_data, layout);

	return dpni_set_rx_buffer_layout(dpni, layout);
}

static int get_tx_buffer_layout(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_buffer_layout buffer_layout = { 0 };
	struct dpni_buffer_layout *layout = &buffer_layout;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_tx_buffer_layout(dpni, layout);

	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_TX_BUFFER_LAYOUT(cmd_data, layout);
	}
	return err;
}

static int set_tx_buffer_layout(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_buffer_layout buffer_layout = { 0 };
	struct dpni_buffer_layout *layout = &buffer_layout;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_TX_BUFFER_LAYOUT(cmd_data, layout);

	return dpni_set_tx_buffer_layout(dpni, layout);
}

static int get_tx_conf_buffer_layout(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_buffer_layout buffer_layout = { 0 };
	struct dpni_buffer_layout *layout = &buffer_layout;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_tx_conf_buffer_layout(dpni, layout);

	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_TX_CONF_BUFFER_LAYOUT(cmd_data, layout);
	}
	return err;
}

static int set_tx_conf_buffer_layout(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_buffer_layout buffer_layout = { 0 };
	struct dpni_buffer_layout *layout = &buffer_layout;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_TX_CONF_BUFFER_LAYOUT(cmd_data, layout);

	return dpni_set_tx_conf_buffer_layout(dpni, layout);
}

static int get_buffer_layout_common(struct device *dev,
	struct mc_cmd_data *cmd_data, int version)
{
	struct dpni *dpni;
	struct dpni_buffer_layout layout = { 0 };
	enum dpni_queue_type qtype;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_BUFFER_LAYOUT(cmd_data, qtype);

	err = dpni_get_buffer_layout(dpni, qtype, &layout);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	if (version < 2)
		DPNI_RSP_GET_BUFFER_LAYOUT_V1(cmd_data, &layout);
	else
		DPNI_RSP_GET_BUFFER_LAYOUT(cmd_data, &layout);

	return 0;
}

static int get_buffer_layout_v1(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	return get_buffer_layout_common (dev, cmd_data, 1);
}

static int get_buffer_layout_v2(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	return get_buffer_layout_common (dev, cmd_data, 2);
}

static int set_buffer_layout_common(struct device *dev,
	struct mc_cmd_data *cmd_data, int version)
{
	struct dpni *dpni;
	struct dpni_buffer_layout layout = { 0 };
	enum dpni_queue_type qtype;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	if (version < 2) {
		DPNI_CMD_SET_BUFFER_LAYOUT_V1(cmd_data, qtype, &layout);
		layout.pass_sw_opaque = 0;
	}
	else
		DPNI_CMD_SET_BUFFER_LAYOUT(cmd_data, qtype, &layout);

	return dpni_set_buffer_layout(dpni, qtype, &layout);
}

static int set_buffer_layout_v1(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	return set_buffer_layout_common(dev, cmd_data, 1);
}

static int set_buffer_layout_v2(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	return set_buffer_layout_common(dev, cmd_data, 2);
}

static int set_l3_chksum_validation(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_L3_CHKSUM_VALIDATION(cmd_data, en);

	return dpni_set_l3_chksum_validation(dpni, en);
}

static int get_l3_chksum_validation(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_l3_chksum_validation(dpni, &en);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_L3_CHKSUM_VALIDATION(cmd_data, en);
	}
	return err;
}

static int set_l4_chksum_validation(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_L4_CHKSUM_VALIDATION(cmd_data, en);

	return dpni_set_l4_chksum_validation(dpni, en);
}

static int get_l4_chksum_validation(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_l4_chksum_validation(dpni, &en);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_L4_CHKSUM_VALIDATION(cmd_data, en);
	}
	return err;
}

static int set_offload_common(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	struct dpni_attr attr = { 0 };
	enum dpni_offload type;
	uint32_t config;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_OFFLOAD(cmd_data, type, config);
	CHECK_COND_RETVAL(!(ver <= 1 && type > DPNI_FLCTYPE_HASH),
					  -EINVAL,
					  "Offload type %d not supported\n", (int)type);

	return dpni_set_offload(dpni, type, config);
}

static int set_offload_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_offload_common(dev, cmd_data, 1);
}

static int set_offload_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_offload_common(dev, cmd_data, 2);
}

static int get_offload_common(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	enum dpni_offload type;
	uint32_t config;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_OFFLOAD(cmd_data, type);
	CHECK_COND_RETVAL(!(ver <= 1 && type > DPNI_FLCTYPE_HASH),
					  -EINVAL,
					  "Offload type %d not supported\n", (int)type);

	err = dpni_get_offload(dpni, type, &config);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_OFFLOAD(cmd_data, config);

	return err;
}

static int get_offload_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_offload_common(dev, cmd_data, 1);
}

static int get_offload_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_offload_common(dev, cmd_data, 2);
}

static int get_qdid_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t qdid;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_qdid(dpni, DPNI_QUEUE_TX, &qdid);

	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_QDID(cmd_data, qdid);
	}

	return err;
}

static int get_qdid_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t qdid;
	enum dpni_queue_type qtype;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_QDID(cmd_data, qtype);

	err = dpni_get_qdid(dpni, qtype, &qdid);

	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_QDID(cmd_data, qdid);
	}

	return err;
}

static int get_qdid_ex_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t qdid[DPMNG_MAX_CEETM_CH];
	enum dpni_queue_type qtype;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_QDID(cmd_data, qtype);

	memset(qdid, 0, sizeof(qdid));
	err = dpni_get_qdid_ex(dpni, qtype, qdid);

	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_QDID_EX(cmd_data, qdid);
	}

	return err;
}

static int get_sp_info(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_sp_info sp_info = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_sp_info(dpni, &sp_info);

	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_SP_INFO(cmd_data, (&sp_info));
	}

	return err;
}

static int get_tx_data_offset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t data_offset;
	int err = 0;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_tx_data_offset(dpni, &data_offset);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_TX_DATA_OFFSET(cmd_data, data_offset);
	}
	return err;
}

static int get_counter(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	enum dpni_counter counter;
	uint64_t value;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_COUNTER(cmd_data, counter);

	err = dpni_get_counter(dpni, counter, &value);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_COUNTER(cmd_data, value);
	}
	return err;
}

static int set_counter(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	enum dpni_counter counter;
	uint64_t value;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_COUNTER(cmd_data, counter, value);

	return dpni_set_counter(dpni, counter, value);
}

static int get_statistics(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t page;
	uint16_t param;
	union dpni_statistics stats = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_STATISTICS(cmd_data, page, param);

	if( page !=4 ) {
		/* Pages that do not use upper part of the param, assure this is zero */
		param = param & 0x00FF;
	}

	err = dpni_get_statistics(dpni, page, &stats, param);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_STATISTICS(cmd_data, &stats);
	return err;
}

static int get_statistics_v4(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t page;
	uint16_t param;
	union dpni_statistics stats = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_STATISTICS(cmd_data, page, param);

	err = dpni_get_statistics(dpni, page, &stats, param);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_STATISTICS(cmd_data, &stats);
	return err;
}

static int reset_statistics(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_reset_statistics(dpni);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	return err;
}

static int set_max_frame_length(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t max_frame_length;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_MAX_FRAME_LENGTH(cmd_data, max_frame_length);

	return dpni_set_max_frame_length(dpni, max_frame_length);
}

static int get_max_frame_length(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t max_frame_length;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_max_frame_length(dpni, &max_frame_length);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_MAX_FRAME_LENGTH(cmd_data, max_frame_length);
	}
	return err;
}

static int set_mtu(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t mtu;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_MTU(cmd_data, mtu);

	return dpni_set_mtu(dpni, mtu);
}

static int get_mtu(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t mtu;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_mtu(dpni, &mtu);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_MTU(cmd_data, mtu);
	}
	return err;
}

static int set_multicast_promisc(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_MULTICAST_PROMISC(cmd_data, en);

	return dpni_set_multicast_promisc(dpni, en);
}

static int get_multicast_promisc(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_multicast_promisc(dpni, &en);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_MULTICAST_PROMISC(cmd_data, en);
	}
	return err;
}

static int set_unicast_promisc(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_UNICAST_PROMISC(cmd_data, en);

	return dpni_set_unicast_promisc(dpni, en);
}

static int get_unicast_promisc(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_unicast_promisc(dpni, &en);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_UNICAST_PROMISC(cmd_data, en);
	}
	return err;
}

static int set_primary_mac_addr(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t mac_addr[6];

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_PRIMARY_MAC_ADDR(cmd_data, mac_addr);

	return dpni_set_primary_mac_addr(dpni, mac_addr);
}

static int get_primary_mac_addr(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int err;
	uint8_t mac_addr[6];

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_primary_mac_addr(dpni, mac_addr);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_PRIMARY_MAC_ADDR(cmd_data, mac_addr);
	}
	return err;
}

static int get_port_mac_addr(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int err;
	uint8_t addr[6];

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_port_mac_addr(dpni, addr);

	DPNI_RSP_GET_PORT_MAC_ADDR(cmd_data, addr);

	return 0;
}

static int add_mac(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t mac_addr[6];

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ADD_MAC_ADDR(cmd_data, mac_addr);

	return dpni_add_mac_addr(dpni, mac_addr);
}

static int add_mac_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t mac_addr[6];
	struct dpni_mac_action_cfg action_cfg;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ADD_MAC_ADDR_V2(cmd_data, mac_addr, action_cfg);
	
	if (action_cfg.flags == DPNI_MAC_SET_QUEUE_ACTION)
		return dpni_add_mac_addr_action(dpni, mac_addr, action_cfg);
	else
		return dpni_add_mac_addr(dpni, mac_addr);
}


static int remove_mac(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t mac_addr[6];

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_REMOVE_MAC_ADDR(cmd_data, mac_addr);

	return dpni_remove_mac_addr(dpni, mac_addr);
}

static int clear_mac_filters(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int unicast;
	int multicast;

	UNUSED(cmd_data);

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_CLEAR_MAC_FILTERS(cmd_data, unicast, multicast);

	return dpni_clear_mac_filters(dpni, unicast, multicast);
}

static int add_vlan_id(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t vlan_id;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ADD_VLAN_ID(cmd_data, vlan_id);

	return dpni_add_vlan_id(dpni, vlan_id);
}

static int add_vlan_id_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t vlan_id;
	uint8_t tc_id, flow_id, flags;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ADD_VLAN_ID_V2(cmd_data, vlan_id, tc_id, flow_id, flags);
	
	if (flags & DPNI_VLAN_SET_QUEUE_ACTION)
	{
		return dpni_add_vlan_id_action(dpni, vlan_id, tc_id, flow_id);
	}
	
	return dpni_add_vlan_id(dpni, vlan_id);
}

static int remove_vlan_id(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t vlan_id;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_REMOVE_VLAN_ID(cmd_data, vlan_id);

	return dpni_remove_vlan_id(dpni, vlan_id);
}

static int clear_vlan_filters(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;

	UNUSED(cmd_data);

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	return dpni_clear_vlan_filters(dpni);
}

static int set_tx_priorities_common(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	struct dpni_tx_priorities prio;
	uint8_t ceetm_ch_idx = 0;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	memset(&prio, 0, sizeof(prio));

	if (ver == 1) {
		DPNI_CMD_SET_TX_PRIORITIES_V1(cmd_data, &prio);
	} else {
		DPNI_CMD_SET_TX_PRIORITIES(cmd_data, &prio, ceetm_ch_idx);
	}

	if( ver<=2 ) {
		ceetm_ch_idx = 0;
	}

	return dpni_set_tx_priorities(dpni, ceetm_ch_idx, &prio);
}

static int set_tx_priorities_v1(struct device *dev, struct mc_cmd_data *cmd_data) 
{
	return set_tx_priorities_common(dev, cmd_data, 1);
}

static int set_tx_priorities_v2(struct device *dev, struct mc_cmd_data *cmd_data) 
{
	return set_tx_priorities_common(dev, cmd_data, 2);
}

static int set_tx_priorities_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_tx_priorities_common(dev, cmd_data, 3);
}

static int set_rx_tc_dist_common(struct device *dev,
		struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	struct dpni_rx_tc_dist_cfg tc_cfg = { 0 };
	struct dpni_rx_tc_dist_cfg *cfg = &tc_cfg;
	struct dpkg_profile_cfg extract_cfg = { 0 };
	uint64_t ext_params[DPNI_CMD_EXTRACT_EXT_PARAMS] = { 0 };
	uint8_t tc_id;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_RX_TC_DIST(cmd_data, tc_id, cfg);

	/* Removed for compatibility with AIOP-SL release.  It uses v1 version
	 * of the command but relies on this bit.
	 * This fix-up should be re-enabled after we sync with AIOP-SL code.
	 */
	//if (ver < 2)
	//	cfg->fs_cfg.keep_hash_key = 0;

	// compatibility with old versions; the field keep_entries is added
	// at command version 3
	if( ver < DPNI_CMD_V3 ) {
		cfg->fs_cfg.keep_entries = 0;
	}

	if (cfg->key_cfg_iova) {
		/* Read from DMA */
		if (ver < 4)
		{
			err = dpmng_dev_memcpy(dev, ext_params, cfg->key_cfg_iova,
				DPNI_CMD_EXTRACT_EXT_PARAMS_OLD * sizeof(uint64_t),
				1);
		}
		else
		{
			err = dpmng_dev_memcpy(dev, ext_params, cfg->key_cfg_iova,
				DPNI_CMD_EXTRACT_EXT_PARAMS * sizeof(uint64_t),
				1);
		}
		
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}
		
		/* Read extention */
		err = dpkg_read_extract_cfg_extention(&extract_cfg, ext_params);
		CHECK_COND_RETVAL(err == 0, err);

		tc_cfg.dist_key_cfg = &extract_cfg;
	}

	return dpni_set_rx_tc_dist(dpni, tc_id, cfg);
}

static int set_rx_tc_dist_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_rx_tc_dist_common(dev, cmd_data, 0);
}

static int set_rx_tc_dist_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_rx_tc_dist_common(dev, cmd_data, 2);
}

static int set_rx_tc_dist_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_rx_tc_dist_common(dev, cmd_data, 3);
}

static int set_rx_tc_dist_v4(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_rx_tc_dist_common(dev, cmd_data, 4);
}

static int set_tx_flow(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_tx_flow_cfg flow_cfg = { 0 };
	struct dpni_tx_flow_cfg *cfg = &flow_cfg;
	uint16_t flow_id;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_TX_FLOW(cmd_data, flow_id, cfg);

	err = dpni_set_tx_flow(dpni, 0, &flow_id, cfg);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_SET_TX_FLOW(cmd_data, flow_id);
	}
	return err;
}

static int get_tx_flow(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_tx_flow_attr flow_attr = { 0 };
	struct dpni_tx_flow_attr *attr = &flow_attr;
	uint16_t flow_id;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_TX_FLOW(cmd_data, flow_id);

	err = dpni_get_tx_flow(dpni, 0, flow_id, attr);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_TX_FLOW(cmd_data, attr);
	}
	return err;
}

static int set_rx_flow(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_queue_cfg queue_cfg = { 0 };
	struct dpni_queue_cfg *cfg = &queue_cfg;
	uint8_t tc_id;
	uint16_t flow_id;
	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_RX_FLOW(cmd_data, tc_id, flow_id, cfg);

	return dpni_set_rx_flow(dpni, tc_id, flow_id, cfg);
}

static int get_rx_flow(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_queue_attr attrib = { 0 };
	struct dpni_queue_attr *attr = &attrib;
	uint8_t tc_id;
	uint16_t flow_id;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_RX_FLOW(cmd_data, tc_id, flow_id);

	err = dpni_get_rx_flow(dpni, tc_id, flow_id, attr);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_RX_FLOW(cmd_data, attr);
	}
	return err;
}

static int set_rx_err_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_queue_cfg queue_cfg = { 0 };
	struct dpni_queue_cfg *cfg = &queue_cfg;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_RX_ERR_QUEUE(cmd_data, cfg);

	return dpni_set_rx_err_queue(dpni, cfg);
}

static int get_rx_err_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_queue_attr attrib = { 0 };
	struct dpni_queue_attr *attr = &attrib;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_rx_err_queue(dpni, attr);
	if (!err) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPNI_RSP_GET_RX_ERR_QUEUE(cmd_data, attr);
	}
	return err;
}

static int set_tx_conf_revoke(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int revoke;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_TX_CONF_REVOKE(cmd_data, revoke);

	return dpni_set_tx_conf_revoke(dpni, 0, revoke);
}

static int get_queue(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	enum dpni_queue_type qtype;
	uint8_t tc;
	uint8_t index;
	uint8_t ceetm_ch_idx;
	int cgid;
	struct dpni_queue queue = { 0 };
	struct dpni_queue_id qid = { 0 };
	struct dpni *dpni;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_QUEUE(cmd_data, qtype, tc, index, ceetm_ch_idx);
	if( ver <= 2 ) {
		/* this field appeared starting with version 3 */
		ceetm_ch_idx = 0;
	}

	err = dpni_get_queue(dpni, ceetm_ch_idx, qtype, tc, index, &queue, &qid, &cgid);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	if (ver == 1) {
		DPNI_RSP_GET_QUEUE(cmd_data, &queue, &qid);
	}
	else {
		if (cgid == DPNI_INVALID_ID)
			DPNI_RSP_GET_QUEUE_V2(cmd_data, &queue, &qid, 0, 0);
		else
			DPNI_RSP_GET_QUEUE_V2(cmd_data, &queue, &qid, 1, (uint8_t)cgid);
	}
	return 0;
}

static int get_queue_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_queue(dev, cmd_data, 1);
}

static int get_queue_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_queue(dev, cmd_data, 2);
}

static int get_queue_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_queue(dev, cmd_data, 3);
}

static int set_queue_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	enum dpni_queue_type qtype;
	uint8_t tc;
	uint8_t index;
	uint8_t options;
	struct dpni_queue queue = { 0 };
	struct dpni *dpni;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_QUEUE(cmd_data, qtype, tc, index, options, &queue);

	return dpni_set_queue(dpni, 0, qtype, tc, index, options, &queue, 0);
}

static int set_queue_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	enum dpni_queue_type qtype;
	uint8_t tc;
	uint8_t index;
	uint8_t options;
	uint8_t cgid;
	struct dpni_queue queue = { 0 };
	struct dpni *dpni;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_QUEUE_V2(cmd_data, qtype, tc, index, options, &queue, cgid);

	return dpni_set_queue(dpni, 0, qtype, tc, index, options, &queue, cgid);
}

static int set_queue_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	enum dpni_queue_type qtype;
	uint8_t tc;
	uint8_t index;
	uint8_t options;
	uint8_t cgid;
	uint8_t ceetm_ch_idx;
	struct dpni_queue queue = { 0 };
	struct dpni *dpni;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_QUEUE_V3(cmd_data, qtype, tc, index, options, &queue, cgid, ceetm_ch_idx);

	return dpni_set_queue(dpni, (int)ceetm_ch_idx, qtype, tc, index, options, &queue, cgid);
}

static int set_qos_table_common(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	struct dpni_qos_tbl_cfg tbl_params = { 0 };
	struct dpni_qos_tbl_cfg *cfg = &tbl_params;
	struct dpkg_profile_cfg extract_cfg = { 0 };
	uint64_t ext_params[DPNI_CMD_EXTRACT_EXT_PARAMS] = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	if( ver<2 ) {
		DPNI_CMD_SET_QOS_TABLE_V1(cmd_data, cfg);
		cfg->keep_entries = 0;
	} else {
		DPNI_CMD_SET_QOS_TABLE(cmd_data, cfg);
	}

	if (cfg->key_cfg_iova) {
		/* Read from DMA */
		err = dpmng_dev_memcpy(dev, ext_params, cfg->key_cfg_iova,
				DPNI_CMD_EXTRACT_EXT_PARAMS * sizeof(uint64_t),
				1);
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}

		/* Read extention */
		err = dpkg_read_extract_cfg_extention(&extract_cfg, ext_params);
		CHECK_COND_RETVAL(err == 0, err);

		tbl_params.qos_key_cfg = &extract_cfg;
	}

	return dpni_set_qos_table(dpni, cfg);
}

static int set_qos_table(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_qos_table_common(dev, cmd_data, 1);
}

static int set_qos_table_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_qos_table_common(dev, cmd_data, 2);
}

struct dpni_rule_cfg_tmp {
	uint64_t key_iova; /*!< IO virtual address to the key */
	uint64_t mask_iova;/*!< IO virtual address to the mask */
	uint8_t key_size; /*!< key/mask size */
};

static int add_qos_entry_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_rule_cfg_tmp key_cfg = { 0 };
	struct dpni_rule_cfg_tmp *cfg = &key_cfg;
	struct dpni_rule_cfg tmp_cfg = { 0 };
	uint8_t tc_id, *scratch_mem;
	int err, offset = 0, scratch_mem_size = 0;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ADD_QOS_ENTRY_V0(cmd_data, cfg, tc_id);

	tmp_cfg.size = cfg->key_size;
	if (tmp_cfg.size == 0) {
		pr_err("key size does not defined\n");
		return -EINVAL;
	}
	
	scratch_mem = (uint8_t*)dpmng_get_scratch(dpni->dpmng);
	
	scratch_mem_size = dpmng_get_scratch_size(dpni->dpmng);

	if (cfg->key_iova) {
		tmp_cfg.key = scratch_mem;
		if (!tmp_cfg.key)
			return -ENOMEM;
		
		if (scratch_mem_size < tmp_cfg.size)
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}
		
		offset = (tmp_cfg.size%32==0 ? 
				tmp_cfg.size : (tmp_cfg.size + (32 - tmp_cfg.size %32)));

		err = dpmng_dev_memcpy(dev, tmp_cfg.key, cfg->key_iova,
				tmp_cfg.size, 1);
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	if (cfg->mask_iova) {
		tmp_cfg.mask = scratch_mem + offset;
		if (!tmp_cfg.mask)
			return -ENOMEM;
		
		if (scratch_mem_size < (offset + tmp_cfg.size))
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}

		err = dpmng_dev_memcpy(dev, tmp_cfg.mask, cfg->mask_iova,
				tmp_cfg.size, 1);
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	err = dpni_add_qos_entry_v0(dpni, &tmp_cfg, tc_id);

	dpmng_put_scratch(dpni->dpmng);

	return err;
}

static int add_qos_entry_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_rule_cfg_tmp key_cfg = { 0 };
	struct dpni_rule_cfg_tmp *cfg = &key_cfg;
	struct dpni_rule_cfg tmp_cfg = { 0 };
	uint8_t tc_id, *scratch_mem;
	uint16_t index;
	int err, offset = 0, scratch_mem_size = 0;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ADD_QOS_ENTRY(cmd_data, cfg, tc_id, index);

	tmp_cfg.size = cfg->key_size;
	if (tmp_cfg.size == 0) {
		pr_err("key size does not defined\n");
		return -EINVAL;
	}
	
	scratch_mem = (uint8_t*)dpmng_get_scratch(dpni->dpmng);
	
	scratch_mem_size = dpmng_get_scratch_size(dpni->dpmng);

	if (cfg->key_iova) {
		tmp_cfg.key = scratch_mem;
		if (!tmp_cfg.key)
			return -ENOMEM;
		
		if (scratch_mem_size < tmp_cfg.size)
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}
		
		offset = (tmp_cfg.size%32==0 ? 
				tmp_cfg.size : (tmp_cfg.size + (32 - tmp_cfg.size %32)));

		err = dpmng_dev_memcpy(dev, tmp_cfg.key, cfg->key_iova,
				tmp_cfg.size, 1);
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	if (cfg->mask_iova) {
		tmp_cfg.mask = scratch_mem + offset;
		if (!tmp_cfg.mask)
			return -ENOMEM;
		
		if (scratch_mem_size < (offset + tmp_cfg.size))
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}

		err = dpmng_dev_memcpy(dev, tmp_cfg.mask, cfg->mask_iova,
				tmp_cfg.size, 1);
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	err = dpni_add_qos_entry_v1(dpni, index, &tmp_cfg, tc_id, DPNI_QOS_OPT_SET_TC_ONLY, 0);

	dpmng_put_scratch(dpni->dpmng);

	return err;
}

static int add_qos_entry_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_rule_cfg_tmp key_cfg = { 0 };
	struct dpni_rule_cfg_tmp *cfg = &key_cfg;
	struct dpni_rule_cfg tmp_cfg = { 0 };
	uint8_t tc_id, flags, flow_id, *scratch_mem;
	uint16_t index;
	int err, offset = 0, scratch_mem_size = 0;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ADD_QOS_ENTRY_V2(cmd_data, cfg, tc_id, index, flags, flow_id);

	tmp_cfg.size = cfg->key_size;
	if (tmp_cfg.size == 0) {
		pr_err("key size does not defined\n");
		return -EINVAL;
	}

	scratch_mem = (uint8_t*)dpmng_get_scratch(dpni->dpmng);
	
	scratch_mem_size = dpmng_get_scratch_size(dpni->dpmng);
	
	if (cfg->key_iova) {
		tmp_cfg.key = scratch_mem;
		if (!tmp_cfg.key)
			return -ENOMEM;
		
		if (scratch_mem_size < tmp_cfg.size)
		{			
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}
		
		offset = (tmp_cfg.size%32==0 ? 
				tmp_cfg.size : (tmp_cfg.size + (32 - tmp_cfg.size %32)));

		err = dpmng_dev_memcpy(dev, tmp_cfg.key, cfg->key_iova,
				tmp_cfg.size, 1);
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	if (cfg->mask_iova) {
		tmp_cfg.mask = scratch_mem + offset;
		if (!tmp_cfg.mask)
			return -ENOMEM;
		
		if (scratch_mem_size < (offset + tmp_cfg.size))
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}

		err = dpmng_dev_memcpy(dev, tmp_cfg.mask, cfg->mask_iova,
				tmp_cfg.size, 1);
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	err = dpni_add_qos_entry_v1(dpni, index, &tmp_cfg, tc_id, flags, flow_id);
	
	dpmng_put_scratch(dpni->dpmng);

	return err;
}

static int remove_qos_entry(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_rule_cfg_tmp key_cfg = { 0 };
	struct dpni_rule_cfg_tmp *cfg = &key_cfg;
	struct dpni_rule_cfg tmp_cfg = { 0 };
	int err, offset = 0, scratch_mem_size = 0;
	uint8_t  *scratch_mem;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_REMOVE_QOS_ENTRY(cmd_data, cfg);

	tmp_cfg.size = cfg->key_size;
	if (tmp_cfg.size == 0) {
		pr_err("key size does not defined\n");
		return -EINVAL;
	}
	
	scratch_mem = (uint8_t*)dpmng_get_scratch(dpni->dpmng);
	
	scratch_mem_size = dpmng_get_scratch_size(dpni->dpmng);

	if (cfg->key_iova) {
		tmp_cfg.key = scratch_mem;
		if (!tmp_cfg.key)
			return -ENOMEM;
		
		if (scratch_mem_size < tmp_cfg.size)
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}
		
		offset = (tmp_cfg.size%32==0 ? 
				tmp_cfg.size : (tmp_cfg.size + (32 - tmp_cfg.size %32)));

		err = dpmng_dev_memcpy(dev, tmp_cfg.key, cfg->key_iova,
				tmp_cfg.size, 1);
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	if (cfg->mask_iova) {
		tmp_cfg.mask = scratch_mem + offset;
		if (!tmp_cfg.mask)
			return -ENOMEM;
		
		if (scratch_mem_size < (offset + tmp_cfg.size))
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}

		err = dpmng_dev_memcpy(dev, tmp_cfg.mask, cfg->mask_iova,
				tmp_cfg.size, 1);
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	err = dpni_remove_qos_entry(dpni, &tmp_cfg);

	dpmng_put_scratch(dpni->dpmng);
	
	return err;
}

static int clear_qos_table(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;

	UNUSED(cmd_data);

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	return dpni_clear_qos_table(dpni);
}

static int add_fs_entry_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	uint16_t flow_id;
	struct dpni_rule_cfg_tmp key_cfg = { 0 };
	struct dpni_rule_cfg_tmp *cfg = &key_cfg;
	struct dpni_rule_cfg tmp_cfg = { 0 };
	int err, offset = 0, scratch_mem_size = 0;
	uint8_t *scratch_mem;
	
	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ADD_FS_ENTRY_V0(cmd_data, tc_id, cfg, flow_id);

	tmp_cfg.size = cfg->key_size;
	if (tmp_cfg.size == 0) {
		pr_err("key size does not defined\n");
		return -EINVAL;
	}
	
	scratch_mem = (uint8_t*)dpmng_get_scratch(dpni->dpmng);
	
	scratch_mem_size = dpmng_get_scratch_size(dpni->dpmng);

	if (cfg->key_iova) {
		tmp_cfg.key = scratch_mem;
		if (!tmp_cfg.key)
			return -ENOMEM;
		
		if (scratch_mem_size < tmp_cfg.size)
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}
		
		offset = (tmp_cfg.size%32==0 ? 
				tmp_cfg.size : (tmp_cfg.size + (32 - tmp_cfg.size %32)));
		
		err = dpmng_dev_memcpy(dev, tmp_cfg.key, cfg->key_iova,
				tmp_cfg.size, 1);
		if (err) {
			fsl_free(tmp_cfg.key);
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	if (cfg->mask_iova) {
		tmp_cfg.mask = (uint8_t*)fsl_malloc(tmp_cfg.size);
		if (!tmp_cfg.mask) {
			if( tmp_cfg.key )
				fsl_free(tmp_cfg.key);
			return -ENOMEM;
		}
		
		if (scratch_mem_size < (offset + tmp_cfg.size))
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}

		err = dpmng_dev_memcpy(dev, tmp_cfg.mask, cfg->mask_iova,
				tmp_cfg.size, 1);
		if (err) {
			fsl_free(tmp_cfg.mask);
			if( tmp_cfg.key )
				fsl_free(tmp_cfg.key);
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	err = dpni_add_fs_entry_v0(dpni, tc_id, &tmp_cfg, flow_id);

	dpmng_put_scratch(dpni->dpmng);

	return err;
}

static int add_fs_entry_check(struct device *dev, int portal_id, struct mc_cmd_data *cmd_data, int cmd_ver)
{
	struct dpni_fs_action_cfg action;
	struct dpni_rule_cfg_tmp cfg = { 0 };
	uint8_t tc_id;
	uint16_t index;
	int err;
	struct cmdif_srv *cmdif;
	struct device *target;

	err = 0;

	if( cmd_ver < 2 )
		/* check not applicable for older versions */
		return err;

	DPNI_CMD_ADD_FS_ENTRY(cmd_data, &cfg, tc_id, index, &action);
	if( !((action.options & DPNI_FS_OPT_REDIRECT_TO_DPNI_RX) | (action.options & DPNI_FS_OPT_REDIRECT_TO_DPNI_TX)) ) {
		/* check not applicable if redirect option is not present */
		return err;
	}

	CHECK_COND_RETVAL( action.redirect_obj_token <= MAX_NUM_OF_INSTANCES, -EINVAL,
			"Invalid token value: %d\n", action.redirect_obj_token);

	cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1, core_get_id());
	CHECK_COND_RETVAL( cmdif != NULL, -ENOENT, "Failed to get handle to cmdif\n");
	portal_id = portal_id - cmdif->portal_base_id;

	CHECK_COND_RETVAL( cmdif->instance_handle[action.redirect_obj_token]!=NULL, -ENOENT,
			"Invalid token %d\n", action.redirect_obj_token);

	CHECK_COND_RETVAL( cmdif->portal_id[action.redirect_obj_token] == portal_id, -EINVAL,
			"Token %d not authorized in this context\n", action.redirect_obj_token);

	target = (struct device *)cmdif->instance_handle[action.redirect_obj_token];
	CHECK_COND_RETVAL( strncmp(dev->type, "dpni", strlen("dpni")) == 0, -EINVAL,
			"Not a valid target");

	return err;
}

static int add_fs_entry_common(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_fs_action_cfg action;
	struct dpni_rule_cfg_tmp cfg = { 0 };
	struct dpni_rule_cfg rule = { 0 };
	uint16_t index;
	int err , offset = 0, scratch_mem_size = 0;
	uint8_t *scratch_mem;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ADD_FS_ENTRY(cmd_data, &cfg, tc_id, index, &action);

	if( ver < 2 ) {
		/* fields available starting with version 2 */
		action.options = action.options & (~DPNI_FS_OPT_REDIRECT_TO_DPNI_RX);
		action.options = action.options & (~DPNI_FS_OPT_REDIRECT_TO_DPNI_TX);
		action.redirect_obj_token = 0;
	}

	rule.size = cfg.key_size;
	if (rule.size == 0) {
		pr_err("key size does not defined\n");
		return -EINVAL;
	}
	
	scratch_mem = (uint8_t*)dpmng_get_scratch(dpni->dpmng);
	
	scratch_mem_size = dpmng_get_scratch_size(dpni->dpmng);
	
	if (cfg.key_iova) {
		rule.key = scratch_mem;
		if (!rule.key)
			return -ENOMEM;
		
		if (scratch_mem_size < rule.size)
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}
		
		offset = (rule.size%32==0 ? 
				rule.size : (rule.size + (32 - rule.size %32)));
		
		err = dpmng_dev_memcpy(dev, rule.key, cfg.key_iova,
				rule.size, 1);
		if (err) {
			fsl_free(rule.key);
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	if (cfg.mask_iova) {
		rule.mask = scratch_mem + offset;
		if (!rule.mask) {
			if( rule.key )
				fsl_free(rule.key);
			return -ENOMEM;
		}
		
		if (scratch_mem_size < (offset + rule.size))
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}

		err = dpmng_dev_memcpy(dev, rule.mask, cfg.mask_iova,
				rule.size, 1);
		if (err) {
			fsl_free(rule.mask);
			if( rule.key )
				fsl_free(rule.key);
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	err = dpni_add_fs_entry_v1(dpni, tc_id, index, &rule, &action);

	dpmng_put_scratch(dpni->dpmng);

	return err;
}

static int add_fs_entry_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return add_fs_entry_common(dev, cmd_data, 1);
}

static int add_fs_entry_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return add_fs_entry_common(dev, cmd_data, 2);
}

static int remove_fs_entry(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_rule_cfg_tmp key_cfg = { 0 };
	struct dpni_rule_cfg_tmp *cfg = &key_cfg;
	struct dpni_rule_cfg tmp_cfg = { 0 };
	int err, scratch_mem_size = 0, offset = 0;
	uint8_t *scratch_mem;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_REMOVE_FS_ENTRY(cmd_data, tc_id, cfg);

	tmp_cfg.size = cfg->key_size;
	if (tmp_cfg.size == 0) {
		pr_err("key size does not defined\n");
		return -EINVAL;
	}
	
	scratch_mem = (uint8_t*)dpmng_get_scratch(dpni->dpmng);
	
	scratch_mem_size = dpmng_get_scratch_size(dpni->dpmng);

	if (cfg->key_iova) {
		tmp_cfg.key = scratch_mem;
		if (!tmp_cfg.key)
			return -ENOMEM;
		
		if (scratch_mem_size < tmp_cfg.size)
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}
		
		offset = (tmp_cfg.size%32==0 ? 
				tmp_cfg.size : (tmp_cfg.size + (32 - tmp_cfg.size %32)));

		err = dpmng_dev_memcpy(dev, tmp_cfg.key, cfg->key_iova,
				tmp_cfg.size, 1);
		if (err) {
			fsl_free(tmp_cfg.key);
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	if (cfg->mask_iova) {
		tmp_cfg.mask = scratch_mem + offset;
		if (!tmp_cfg.mask) {
			if( tmp_cfg.key )
				fsl_free(tmp_cfg.key);
			return -ENOMEM;
		}
		
		if (scratch_mem_size < (offset + tmp_cfg.size))
		{
			pr_err("Scratch memory too small\n");
			return -ENOMEM;
		}

		err = dpmng_dev_memcpy(dev, tmp_cfg.mask, cfg->mask_iova,
				tmp_cfg.size, 1);
		if (err) {
			fsl_free(tmp_cfg.mask);
			if( tmp_cfg.key )
				fsl_free(tmp_cfg.key);
			pr_err("Error reading extended DMA parameters");
			return err;
		}
	}

	err = dpni_remove_fs_entry(dpni, tc_id, &tmp_cfg);
	
	dpmng_put_scratch(dpni->dpmng);

	return err;
}

static int clear_fs_entries(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_CLEAR_FS_ENTRIES(cmd_data, tc_id);

	return dpni_clear_fs_entries(dpni, tc_id);
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dpni_set_irq(dpni, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev,
	struct mc_irq_cfg *irq_cfg,
	int irq_index)
{
	struct dpni *dpni;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	return dpni_set_irq(dpni, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
	uint8_t irq_index;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpni_get_irq(dpni, irq_index, irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev,
	struct mc_irq_cfg *irq_cfg,
	int irq_index)
{
	struct dpni *dpni;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_irq(dpni, (uint8_t)irq_index, irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t irq_index;
	uint8_t en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, en);

	return dpni_set_irq_enable(dpni, irq_index, en);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t irq_index;
	uint8_t en;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpni_get_irq_enable(dpni, irq_index, &en);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_IRQ_ENABLE(cmd_data, en);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t irq_index;
	uint32_t mask;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpni_set_irq_mask(dpni, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpni_get_irq_mask(dpni, irq_index, &mask);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpni_get_irq_status(dpni, irq_index, &status);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t irq_index;
	uint32_t status;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpni_clear_irq_status(dpni, irq_index, status);
}

static int set_ipr_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_SET_IPR(cmd_data, en);

	return dpni_set_ipr(dpni, en);
}

static int set_ipf_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_SET_IPF(cmd_data, en);

	return dpni_set_ipf(dpni, en);
}

static int set_rx_tc_policing(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_rx_tc_policing_cfg policing_cfg = { 0 };
	struct dpni_rx_tc_policing_cfg *cfg = &policing_cfg;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_SET_RX_TC_POLICING(cmd_data, tc_id, cfg);

	return dpni_set_rx_tc_policing(dpni, tc_id, cfg);
}

static int set_rx_tc_early_drop(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_early_drop_cfg early_drop_cfg;
	struct dpni_early_drop_cfg *cfg = &early_drop_cfg;
	uint64_t early_drop_iova;
	uint64_t ext_params[DPNI_CMD_EARLY_DROP_EXT_PARAMS] = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	memset(cfg, 0, sizeof(struct dpni_early_drop_cfg));

	/* Read parameters from portal */
	DPNI_CMD_SET_RX_TC_EARLY_DROP(cmd_data, tc_id, early_drop_iova);

	/* Read from DMA */
	err = dpmng_dev_memcpy(dev, ext_params, early_drop_iova,
			DPNI_CMD_EARLY_DROP_EXT_PARAMS * sizeof(uint64_t),
			1);
	if (err) {
		pr_err("Error reading extended DMA parameters");
		return err;
	}

	/* Read extension */
	DPNI_EXT_EARLY_DROP(ext_params, cfg);

	return dpni_set_rx_tc_early_drop(dpni, tc_id, cfg);
}

static int get_rx_tc_early_drop(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_early_drop_cfg early_drop_cfg;
	struct dpni_early_drop_cfg *cfg = &early_drop_cfg;
	uint64_t early_drop_iova;
	uint64_t ext_params[DPNI_CMD_EARLY_DROP_EXT_PARAMS] = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	memset(cfg, 0, sizeof(struct dpni_early_drop_cfg));

	/* Read parameters from portal */
	DPNI_CMD_GET_RX_TC_EARLY_DROP(cmd_data, tc_id, early_drop_iova);

	err = dpni_get_rx_tc_early_drop(dpni, tc_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* prepare extension before sending it with DMA */
	DPNI_PREP_EARLY_DROP(ext_params, cfg);

	/* Write to DMA */
	err = dpmng_dev_memcpy(dev, ext_params, early_drop_iova,
			DPNI_CMD_EARLY_DROP_EXT_PARAMS * sizeof(uint64_t),
			0);
	if (err) {
		pr_err("Error writing extended DMA parameters");
		return err;
	}

	return 0;
}

static int set_tx_tc_early_drop(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_early_drop_cfg early_drop_cfg;
	struct dpni_early_drop_cfg *cfg = &early_drop_cfg;
	uint64_t early_drop_iova;
	uint64_t ext_params[DPNI_CMD_EARLY_DROP_EXT_PARAMS] = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	memset(cfg, 0, sizeof(struct dpni_early_drop_cfg));

	/* Read parameters from portal */
	DPNI_CMD_SET_TX_TC_EARLY_DROP(cmd_data, tc_id, early_drop_iova);

	/* Read from DMA */
	err = dpmng_dev_memcpy(dev, ext_params, early_drop_iova,
			DPNI_CMD_EARLY_DROP_EXT_PARAMS * sizeof(uint64_t),
			1);
	if (err) {
		pr_err("Error reading extended DMA parameters");
		return err;
	}

	/* Read extension */
	DPNI_EXT_EARLY_DROP(ext_params, cfg);

	return dpni_set_tx_tc_early_drop(dpni, 0, tc_id, cfg);
}

static int get_tx_tc_early_drop(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_early_drop_cfg early_drop_cfg;
	struct dpni_early_drop_cfg *cfg = &early_drop_cfg;
	uint64_t early_drop_iova;
	uint64_t ext_params[DPNI_CMD_EARLY_DROP_EXT_PARAMS] = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	memset(cfg, 0, sizeof(struct dpni_early_drop_cfg));

	/* Read parameters from portal */
	DPNI_CMD_GET_TX_TC_EARLY_DROP(cmd_data, tc_id, early_drop_iova);

	err = dpni_get_tx_tc_early_drop(dpni, 0, tc_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* prepare extension before sending it with DMA */
	DPNI_PREP_EARLY_DROP(ext_params, cfg);

	/* Write to DMA */
	err = dpmng_dev_memcpy(dev, ext_params, early_drop_iova,
			DPNI_CMD_EARLY_DROP_EXT_PARAMS * sizeof(uint64_t),
			0);
	if (err) {
		pr_err("Error writing extended DMA parameters");
		return err;
	}

	return 0;
}

static int get_rx_tc_policing(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_rx_tc_policing_cfg policing_cfg = { 0 };
	struct dpni_rx_tc_policing_cfg *cfg = &policing_cfg;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_RX_TC_POLICING(cmd_data, tc_id);

	err = dpni_get_rx_tc_policing(dpni, tc_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* read response */
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_RX_TC_POLICING(cmd_data, cfg);

	return 0;
}

static int set_rx_tc_congestion_notification(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_congestion_notification_cfg cg_cfg;
	struct dpni_congestion_notification_cfg *cfg = &cg_cfg;

	memset(cfg, 0, sizeof(struct dpni_congestion_notification_cfg));

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_SET_RX_TC_CONGESTION_NOTIFICATION(cmd_data, tc_id, cfg);

	return dpni_set_rx_tc_congestion_notification(dpni, tc_id, cfg);
}

static int get_rx_tc_congestion_notification(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_congestion_notification_cfg cg_cfg;
	struct dpni_congestion_notification_cfg *cfg = &cg_cfg;
	int err;

	memset(cfg, 0, sizeof(struct dpni_congestion_notification_cfg));

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_RX_TC_CONGESTION_NOTIFICATION(cmd_data, tc_id);

	err = dpni_get_rx_tc_congestion_notification(dpni, tc_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* read response */
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_RX_TC_CONGESTION_NOTIFICATION(cmd_data, cfg);

	return 0;
}

static int set_tx_tc_congestion_notification(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_congestion_notification_cfg cg_cfg;
	struct dpni_congestion_notification_cfg *cfg = &cg_cfg;

	memset(cfg, 0, sizeof(struct dpni_congestion_notification_cfg));

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_SET_TX_TC_CONGESTION_NOTIFICATION(cmd_data, tc_id, cfg);

	return dpni_set_tx_tc_congestion_notification(dpni, 0, tc_id, cfg);
}

static int get_tx_tc_congestion_notification(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id;
	struct dpni_congestion_notification_cfg cg_cfg;
	struct dpni_congestion_notification_cfg *cfg = &cg_cfg;
	int err;

	memset(cfg, 0, sizeof(struct dpni_congestion_notification_cfg));

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_TX_TC_CONGESTION_NOTIFICATION(cmd_data, tc_id);

	err = dpni_get_tx_tc_congestion_notification(dpni, 0, tc_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* read response */
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_TX_TC_CONGESTION_NOTIFICATION(cmd_data, cfg);

	return 0;
}

static int set_tx_conf(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t flow_id;
	struct dpni_tx_conf_cfg conf_cfg = { 0 };
	struct dpni_tx_conf_cfg *cfg = &conf_cfg;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_SET_TX_CONF(cmd_data, flow_id, cfg);

	return dpni_set_tx_conf(dpni, 0, flow_id, cfg);
}

static int get_tx_conf(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t flow_id;
	struct dpni_tx_conf_attr conf_attr = { 0 };
	struct dpni_tx_conf_attr *attr = &conf_attr;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_TX_CONF(cmd_data, flow_id);

	err = dpni_get_tx_conf(dpni, 0, flow_id, attr);
	CHECK_COND_RETVAL(err == 0, err);

	/* read response */
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_TX_CONF(cmd_data, attr);

	return 0;
}

static int set_tx_conf_congestion_notification(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t flow_id;
	struct dpni_congestion_notification_cfg cg_cfg;
	struct dpni_congestion_notification_cfg *cfg = &cg_cfg;

	memset(cfg, 0, sizeof(struct dpni_congestion_notification_cfg));

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_SET_TX_CONF_CONGESTION_NOTIFICATION(cmd_data, flow_id, cfg);

	return dpni_set_tx_conf_congestion_notification(dpni, 0, flow_id, cfg);
}

static int get_tx_conf_congestion_notification(struct device *dev,
	struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t flow_id;
	struct dpni_congestion_notification_cfg cg_cfg;
	struct dpni_congestion_notification_cfg *cfg = &cg_cfg;
	int err;

	memset(cfg, 0, sizeof(struct dpni_congestion_notification_cfg));

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_TX_CONF_CONGESTION_NOTIFICATION(cmd_data, flow_id);

	err = dpni_get_tx_conf_congestion_notification(dpni, 0, flow_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* read response */
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_TX_CONF_CONGESTION_NOTIFICATION(cmd_data, cfg);

	return 0;
}

static int set_ipsec_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_SET_IPSEC(cmd_data, en);

	return dpni_set_ipsec(dpni, en);
}

static int ipsec_add_sa(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_ipsec_sa_cfg sa_cfg = { 0 };
	struct dpni_ipsec_sa_cfg *cfg = &sa_cfg;
	int err = 0;
	uint64_t extension_iova;
	uint16_t extension_buf_size = 0;
	uint64_t *ext_params;
	uint8_t sa_id;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_IPSEC_ADD_SA(cmd_data, extension_iova, extension_buf_size);

	err = dpni_get_sa_tmp_buffer(dpni, extension_buf_size,
					(void **)&ext_params, &sa_id);
	CHECK_COND_RETVAL(err == 0, err);

	/* Read from DMA */
	err = dpmng_dev_memcpy(dev, ext_params, extension_iova,
			extension_buf_size, 1);
	if (err) {
		pr_err("Error reading extended DMA parameters");
		return err;
	}
	
	read_ipsec_sa_cfg_extention(cfg, ext_params);

	err = dpni_ipsec_add_sa(dpni, cfg, sa_id);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));

	DPNI_RSP_IPSEC_ADD_SA(cmd_data, sa_id);

	return 0;

}

static int ipsec_remove_sa(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t sa_id;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_IPSEC_REMOVE_SA(cmd_data, sa_id);

	return dpni_ipsec_remove_sa(dpni, sa_id);
}

static int ipsec_flush(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	return dpni_ipsec_flush(dpni);
}

static int ipsec_sa_get_stats(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint64_t kbytes, packets;
	uint32_t sec;
	int err;
	uint8_t sa_id;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_IPSEC_SA_GET_STATS(cmd_data, sa_id);

	err = dpni_ipsec_sa_get_stats(dpni, sa_id, &kbytes, &packets, &sec);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));

	DPNI_RSP_IPSEC_SA_GET_STATS(cmd_data, kbytes, packets, sec);

	return 0;
}

static int set_vlan_insertion(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_SET_VLAN_INSERTION(cmd_data, en);

	return dpni_set_vlan_insertion(dpni, en);
}

static int set_vlan_removal(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	int en;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_SET_VLAN_REMOVAL(cmd_data, en);

	return dpni_set_vlan_removal(dpni, en);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPNI_VER_MAJOR;
    uint32_t minor = DPNI_VER_MINOR;

    DPNI_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int set_link_cfg(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	struct dpni_link_cfg link_cfg = { 0 };
	struct dpni_link_cfg *cfg = &link_cfg;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	if (ver < 2)
	{
		DPNI_CMD_SET_LINK_CFG_V1(cmd_data, cfg);
		cfg->advertising = 0;
	}
	else
		DPNI_CMD_SET_LINK_CFG(cmd_data, cfg);

	return dpni_set_link_cfg(dpni, cfg);
}

static int set_link_cfg_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_link_cfg(dev, cmd_data, 1);
}

static int set_link_cfg_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_link_cfg(dev, cmd_data, 2);
}

static int get_link_cfg(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_link_cfg link_cfg = { 0 };
	struct dpni_link_cfg *cfg = &link_cfg;
	int err = 0;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_link_cfg(dpni, cfg);
	CHECK_COND_RETVAL(err == 0, err, "dpni_set_link_cfg() return error");

	DPNI_RSP_GET_LINK_CFG(cmd_data, cfg);

	return 0;
}

static int get_link_state(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	struct dpni_link_state link_state = { 0 };
	struct dpni_link_state *state = &link_state;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_link_state(dpni, state);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	
	if (ver < 2)
		DPNI_RSP_GET_LINK_STATE_V1(cmd_data, state);
	else
		DPNI_RSP_GET_LINK_STATE(cmd_data, state);

	return 0;
}

static int get_link_state_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_link_state(dev, cmd_data, 1);
}

static int get_link_state_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_link_state(dev, cmd_data, 2);
}


static int set_tx_shaping_common(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	struct dpni_tx_shaping_cfg cr_shaper = { 0 };
	struct dpni_tx_shaping_cfg *tx_cr_shaper = &cr_shaper;
	
	struct dpni_tx_shaping_cfg er_shaper = { 0 };
	struct dpni_tx_shaping_cfg *tx_er_shaper = &er_shaper;
	
	int coupled = 0;
	int lni_shaping = 0;
	uint8_t ceetm_ch_idx = 0;
	uint16_t oal;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_TX_SHAPING(cmd_data, tx_cr_shaper, tx_er_shaper, coupled, lni_shaping, ceetm_ch_idx, oal);

	if (ver < 2) {
		tx_er_shaper->max_burst_size = 0;
		tx_er_shaper->rate_limit = 0;
		coupled = 0;
	}

	if( ver < 3 ) {
		lni_shaping = 0;
		ceetm_ch_idx = 0;
		oal = 0;
	}

	return dpni_set_tx_shaping(dpni, (int)ceetm_ch_idx, tx_cr_shaper, tx_er_shaper, coupled, lni_shaping, oal);
}

static int set_tx_shaping_v0(struct device *dev, struct mc_cmd_data *cmd_data) {
	return set_tx_shaping_common(dev, cmd_data, 0);
}

static int set_tx_shaping_v2(struct device *dev, struct mc_cmd_data *cmd_data) {
	return set_tx_shaping_common(dev, cmd_data, 2);
}

static int set_tx_shaping_v3(struct device *dev, struct mc_cmd_data *cmd_data) {
	return set_tx_shaping_common(dev, cmd_data, 3);
}

static int get_taildrop_common(struct device *dev,
		struct mc_cmd_data *cmd_data, int ver) {
	struct dpni *dpni;
	struct dpni_taildrop taildrop = { 0 };
	uint8_t tc, q_index;
	enum dpni_congestion_point cp;
	enum dpni_queue_type q_type;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_TAILDROP(cmd_data, cp, q_type, tc, q_index);

	err = dpni_get_taildrop(dpni, 0, cp, q_type, tc, q_index, &taildrop);
	CHECK_COND_RETVAL(err == 0, err);
	
	if (ver == 1) {
		taildrop.oal = 0;
	}

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_TAILDROP(cmd_data, &taildrop);

	return 0;
}

static int get_taildrop_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_taildrop_common(dev, cmd_data, 1);
}

static int get_taildrop_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return get_taildrop_common(dev, cmd_data, 2);
}

static int set_taildrop_common(struct device *dev,
		struct mc_cmd_data *cmd_data, int ver)
{
		struct dpni *dpni;
		struct dpni_taildrop taildrop = { 0 };
		uint8_t tc, q_index;
		enum dpni_congestion_point cp;
		enum dpni_queue_type q_type;
		uint8_t ceetm_ch_idx;

		dpni = device_get_priv(dev);
		CHECK_COND_RETVAL(dpni, -ENODEV);

		DPNI_CMD_SET_TAILDROP(cmd_data, cp, q_type, tc, q_index, &taildrop, ceetm_ch_idx);
		
		if( ver <= 1 )
			taildrop.oal = 0;

		if( ver <= 2 )
			ceetm_ch_idx = 0;

		return dpni_set_taildrop(dpni, (int)ceetm_ch_idx, cp, q_type, tc, q_index, &taildrop);
}

static int set_taildrop_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_taildrop_common(dev, cmd_data, 1);
}

static int set_taildrop_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_taildrop_common(dev, cmd_data, 2);
}

static int set_taildrop_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_taildrop_common(dev, cmd_data, 3);
}

static int set_tx_confirmation_mode(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	enum dpni_confirmation_mode mode;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_TX_CONFIRMATION_MODE(cmd_data, mode);

	return dpni_set_tx_confirmation_mode(dpni, 0, mode);
}

static int get_tx_confirmation_mode(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	enum dpni_confirmation_mode mode;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_tx_confirmation_mode(dpni, &mode);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_TX_CONFIRMATION_MODE(cmd_data, mode);

	return 0;
}

static int set_congestion_notification_common(struct device *dev,
		struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	enum dpni_queue_type qtype;
	uint8_t tc;
	int cgid = 0;
	enum dpni_congestion_point cp;
	struct dpni_congestion_notification_cfg cfg = { DPNI_CONGESTION_UNIT_BYTES };
	uint8_t ceetm_ch_idx;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_CONGESTION_NOTIFICATION(cmd_data, qtype, tc, &cfg,	cp, cgid, ceetm_ch_idx);
	if (ver <= 1){
		cp = DPNI_CP_QUEUE;
		cgid = DPNI_INVALID_ID;
	}

	return dpni_set_congestion_notification(dpni, ceetm_ch_idx, qtype, tc, &cfg, cp, cgid);
}

static int set_congestion_notification_v1(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return set_congestion_notification_common(dev, cmd_data, 1);
}
static int set_congestion_notification_v2(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return set_congestion_notification_common(dev, cmd_data, 2);
}

static int set_congestion_notification_v3(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return set_congestion_notification_common(dev, cmd_data, 3);
}

static int get_congestion_notification_common(struct device *dev,
		struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	enum dpni_queue_type qtype;
	uint8_t tc;
	int cgid = 0;
	enum dpni_congestion_point cp;
	struct dpni_congestion_notification_cfg cfg = { DPNI_CONGESTION_UNIT_BYTES };
	uint8_t ceetm_ch_idx;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_CONGESTION_NOTIFICATION(cmd_data, qtype, tc, cp, cgid, ceetm_ch_idx);

	if (ver <= 1)
	{
		cgid = DPNI_INVALID_ID;
		cp = DPNI_CP_QUEUE;
	}

	if( ver <= 2 ) {
		ceetm_ch_idx = 0;
	}

	err = dpni_get_congestion_notification(dpni, (int)ceetm_ch_idx, qtype, tc, &cfg, cp, cgid);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_CONGESTION_NOTIFICATION(cmd_data, &cfg);

	return 0;
}

static int get_congestion_notification_v1(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return get_congestion_notification_common(dev, cmd_data, 1);
}

static int get_congestion_notification_v2(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return get_congestion_notification_common(dev, cmd_data, 2);
}

static int get_congestion_notification_v3(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return get_congestion_notification_common(dev, cmd_data, 3);
}

static int set_early_drop_common(struct device *dev,
		struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	enum dpni_queue_type qtype;
	uint8_t tc, channel_idx;
	uint64_t iova;
	uint64_t ext_params[DPNI_CMD_EARLY_DROP_EXT_PARAMS] = { 0 };
	struct dpni_early_drop_cfg cfg = { DPNI_CONGESTION_UNIT_BYTES };
	enum dpni_early_drop_mode mode;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_EARLY_DROP(cmd_data, qtype, tc, channel_idx, iova);

	/* Read from DMA */
	err = dpmng_dev_memcpy(dev, ext_params, iova,
			DPNI_CMD_EARLY_DROP_EXT_PARAMS * sizeof(uint64_t), 1);
	if (err) {
		pr_err("Error reading extended DMA parameters");
		return err;
	}

	if( ver <=2 ) {
		/* this field is added starting with V3 */
		channel_idx = 0;
	}

	if (ver == 1) {
		/* Read extension */
		DPNI_EXT_EARLY_DROP_V1(ext_params, &cfg, mode);
		
		cfg.dpni_wred_enable = 0;
		cfg.dpni_tail_drop_enable = 0;
		if (mode == DPNI_EARLY_DROP_MODE_WRED) {
			cfg.dpni_wred_enable = 1;
		} else if (mode == DPNI_EARLY_DROP_MODE_TAIL) {
			cfg.dpni_tail_drop_enable = 1;
		}
	} else {
		DPNI_EXT_EARLY_DROP(ext_params, &cfg);
	}

	return dpni_set_early_drop(dpni, channel_idx, qtype, tc, &cfg);
}

static int set_early_drop_v1(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return set_early_drop_common(dev, cmd_data, 1); 
}

static int set_early_drop_v2(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return set_early_drop_common(dev, cmd_data, 2); 
}

static int set_early_drop_v3(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return set_early_drop_common(dev, cmd_data, 3);
}

static int get_early_drop_common(struct device *dev,
		struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	enum dpni_queue_type qtype;
	uint8_t tc, channel_idx;
	uint64_t iova;
	uint64_t ext_params[DPNI_CMD_EARLY_DROP_EXT_PARAMS] = { 0 };
	struct dpni_early_drop_cfg cfg = { DPNI_CONGESTION_UNIT_BYTES };
	enum dpni_early_drop_mode mode = DPNI_EARLY_DROP_MODE_NONE;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_GET_EARLY_DROP(cmd_data, qtype, tc, channel_idx, iova);

	if( ver <= 2 ) {
		/* this field is added starting with V3 */
		channel_idx = 0;
	}

	err = dpni_get_early_drop(dpni, 0, qtype, tc, &cfg);
	CHECK_COND_RETVAL(err == 0, err);

	if (ver == 1) {
		if (cfg.dpni_wred_enable) {
			mode = DPNI_EARLY_DROP_MODE_WRED;
		} else if (cfg.dpni_tail_drop_enable){
			mode = DPNI_EARLY_DROP_MODE_TAIL;
		}
		
		DPNI_PREP_EARLY_DROP_V1(ext_params, &cfg, mode);
	} else {
		DPNI_PREP_EARLY_DROP(ext_params, &cfg);
	}

	/* prepare extension before sending it with DMA */
	DPNI_PREP_EARLY_DROP(ext_params, &cfg);

	/* Write to DMA */
	err = dpmng_dev_memcpy(dev, ext_params, iova,
			DPNI_CMD_EARLY_DROP_EXT_PARAMS * sizeof(uint64_t), 0);
	if (err) {
		pr_err("Error writing extended DMA parameters");
		return err;
	}

	return 0;
}

static int get_early_drop_v1(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return get_early_drop_common(dev, cmd_data, 1); 
}

static int get_early_drop_v2(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return get_early_drop_common(dev, cmd_data, 2); 
}

static int get_early_drop_v3(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return get_early_drop_common(dev, cmd_data, 3);
}

static int set_opr(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id, options, index;
	struct opr_cfg or_cfg = { 0 };
	struct opr_cfg *cfg = &or_cfg;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_SET_OPR(cmd_data, tc_id, index, options, cfg);

	err = dpni_set_opr(dpni, tc_id, index, options, cfg, 0);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int set_opr_v2(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id, options, index, opr_id;
	struct opr_cfg or_cfg = { 0 };
	struct opr_cfg *cfg = &or_cfg;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_SET_OPR_V2(cmd_data, tc_id, index, options, cfg, opr_id);

	err = dpni_set_opr(dpni, tc_id, index, options, cfg, opr_id);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int get_opr(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id, index;
	struct opr_cfg or_cfg;
	struct opr_qry or_qry;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_OPR(cmd_data, tc_id, index);

	err = dpni_get_opr(dpni, tc_id, index, &or_cfg, &or_qry, 0, 0);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_OPR(cmd_data, &or_cfg, &or_qry);

	return 0;
}

static int get_opr_v2(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint8_t tc_id, index, flags, opr_id;
	struct opr_cfg or_cfg;
	struct opr_qry or_qry;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	/* Read parameters from portal */
	DPNI_CMD_GET_OPR_V2(cmd_data, tc_id, index, flags, opr_id);

	err = dpni_get_opr(dpni, tc_id, index, &or_cfg, &or_qry, flags, opr_id);
	CHECK_COND_RETVAL(err == 0, err);
	
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPNI_RSP_GET_OPR(cmd_data, &or_cfg, &or_qry);

	return 0;
}

static int set_single_step_cfg(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_single_step_cfg cfg = {0};

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_SINGLE_STEP_CFG(cmd_data, cfg);

	return dpni_set_single_step_cfg(dpni, &cfg);
}

static int get_single_step_cfg(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_single_step_cfg cfg = {0};
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_single_step_cfg(dpni, &cfg);
	CHECK_COND_RETVAL(err==0, err, "dpni_get_ptp_cfg() return error");

	DPNI_RSP_GET_SINGLE_STEP_CFG(cmd_data, cfg);

	return 0;
}

#ifndef OBSOLETED_SP_API
/******************************************************************************/
/* Contains load parameters as they are passed by GPP in MCP */
struct dpparser_load_gpp_ss_cfg {
	enum dpni_soft_sequence_dest	dest;
	uint16_t			ss_offset;
	uint16_t			ss_size;
	uint64_t			ss_iova;
};

/* Contains load parameters as they are passed by GPP in MCP */
struct dpparser_enable_gpp_ss_cfg {
	enum dpni_soft_sequence_dest	dest;
	uint16_t			hxs;
	uint8_t				set_start;
	uint16_t			ss_offset;
	uint8_t				param_offset;
	uint8_t				param_size;
	uint64_t			param_iova;
};

/******************************************************************************/
static int load_sw_sequence(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni				*dpni;
	struct dpni_load_ss_cfg			load_cfg;
	struct dpparser_load_gpp_ss_cfg		gpp_load_cfg;
	int					err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_LOAD_SW_SEQUENCE(cmd_data, &gpp_load_cfg);
	load_cfg.dest = gpp_load_cfg.dest;
	load_cfg.ss_offset = gpp_load_cfg.ss_offset;
	load_cfg.ss_size = gpp_load_cfg.ss_size;
	/* Allocate */
	load_cfg.ss_iova = fsl_malloc(load_cfg.ss_size);
	err = dpmng_dev_memcpy(dev, load_cfg.ss_iova, gpp_load_cfg.ss_iova,
			       load_cfg.ss_size, 1);
	if (err) {
		fsl_free(load_cfg.ss_iova);
		pr_err("Error reading extended DMA parameters");
		return err;
	}
	err = dpni_load_sw_sequence(dpni, &load_cfg);
	if (load_cfg.ss_iova)
		fsl_free(load_cfg.ss_iova);
	CHECK_COND_RETVAL(err == 0, err);
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	return 0;
}

/******************************************************************************/
static int get_sw_sequence_layout(struct device *dev,
				  struct mc_cmd_data *cmd_data)
{
	struct dpni			*dpni;
	uint64_t			ss_layout_iova;
	enum dpni_soft_sequence_dest	src;
	int				err, i;
	uint64_t			*p_param;
	uint64_t ext_params[DPNI_SW_SEQUENCE_LAYOUT_SIZE] = { 0 };
	struct dpni_sw_sequence_layout_entry
			layout[DPNI_SW_SEQUENCE_LAYOUT_SIZE];

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	DPNI_CMD_GET_SW_SEQUENCE_LAYOUT(cmd_data, src, ss_layout_iova);
	err = dpni_get_sw_sequence_layout(dpni, src, layout);
	CHECK_COND_RETVAL(err == 0, err);
	/* Prepare extension before sending it with DMA */
	for (i = 0; i < DPNI_SW_SEQUENCE_LAYOUT_SIZE; i++) {
		p_param = &(ext_params[i]);
		DPNI_PREP_SW_SEQUENCE_LAYOUT(p_param, layout[i]);
	}
	/* Write to DMA */
	err = dpmng_dev_memcpy(dev, ext_params, ss_layout_iova,
			       DPNI_SW_SEQUENCE_LAYOUT_SIZE * sizeof(uint64_t),
			       0);
	if (err) {
		pr_err("Error writing extended DMA parameters");
		return err;
	}
	return 0;
}

/******************************************************************************/
static int enable_sw_sequence(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni				*dpni;
	struct dpni_enable_ss_cfg		enable_cfg;
	struct dpparser_enable_gpp_ss_cfg	gpp_enable_cfg;
	int					err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	/* Read parameters from portal */
	DPNI_CMD_ENABLE_SW_SEQUENCE(cmd_data, &gpp_enable_cfg);
	enable_cfg.set_start = gpp_enable_cfg.set_start;
	enable_cfg.ss_offset = gpp_enable_cfg.ss_offset;
	enable_cfg.dest = gpp_enable_cfg.dest;
	enable_cfg.hxs = gpp_enable_cfg.hxs;
	enable_cfg.param_offset = gpp_enable_cfg.param_offset;
	enable_cfg.param_size = gpp_enable_cfg.param_size;
	/* Allocate */
	enable_cfg.param_iova = fsl_malloc(enable_cfg.param_size);
	err = dpmng_dev_memcpy(dev, enable_cfg.param_iova,
			       gpp_enable_cfg.param_iova,
			       enable_cfg.param_size, 1);
	if (err) {
		fsl_free(enable_cfg.param_iova);
		pr_err("Error reading extended DMA parameters");
		return err;
	}
	err = dpni_enable_sw_sequence(dpni, &enable_cfg,
				      gpp_enable_cfg.set_start);
	if (enable_cfg.param_iova)
		fsl_free(enable_cfg.param_iova);
	CHECK_COND_RETVAL(err == 0, err);
	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	return 0;
}
#endif /* OBSOLETED_SP_API */

/******************************************************************************/
static int set_sp_profile(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni		*dpni;
	uint8_t 		sp_profile[MAX_SP_PROFILE_ID_SIZE];
	uint8_t 		type;
	int				err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);
	
	/* Read parameters from portal */
	DPNI_CMD_SET_SP_PROFILE(cmd_data, sp_profile, type);

	err = dpni_set_sp_profile(dpni, sp_profile, type);
	CHECK_COND_RETVAL(err == 0, err);
	return 0;
}

static int set_rx_fs_dist_common(struct device *dev,
		struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	struct dpni_rx_dist_cfg cfg = {0};
	uint64_t ext_params[DPNI_CMD_EXTRACT_EXT_PARAMS] = { 0 };
	struct dpkg_profile_cfg extract_cfg = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_RX_FS_DIST(cmd_data, &cfg);

	if ( cfg.enable && cfg.key_cfg_iova ) {
		/* Read from DMA */
		if (ver < 2)
		{
			err = dpmng_dev_memcpy(dev, ext_params, cfg.key_cfg_iova,
				DPNI_CMD_EXTRACT_EXT_PARAMS_OLD * sizeof(uint64_t),
				1);
		}
		else
		{
			err = dpmng_dev_memcpy(dev, ext_params, cfg.key_cfg_iova,
				DPNI_CMD_EXTRACT_EXT_PARAMS * sizeof(uint64_t),
				1);
		}
		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}

		/* Read extention */
		err = dpkg_read_extract_cfg_extention(&extract_cfg, ext_params);
		CHECK_COND_RETVAL(err == 0, err);

		cfg.key_changed = 1;
	}

	cfg.dist_key_cfg = &extract_cfg;

	return dpni_set_rx_fs_dist(dpni, cfg.tc_id, &cfg);
}

static int set_rx_fs_dist_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_rx_fs_dist_common(dev, cmd_data, 1);
}
static int set_rx_fs_dist_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_rx_fs_dist_common(dev, cmd_data, 2);
}

static int set_rx_hash_dist_common(struct device *dev,
		struct mc_cmd_data *cmd_data, int ver)
{
	struct dpni *dpni;
	struct dpni_rx_dist_cfg cfg = {0};
	uint64_t ext_params[DPNI_CMD_EXTRACT_EXT_PARAMS] = { 0 };
	struct dpkg_profile_cfg extract_cfg = { 0 };
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_RX_HASH_DIST(cmd_data, &cfg);

	if ( cfg.enable && cfg.key_cfg_iova ) {
		/* Read from DMA */
		if (ver < 2)
		{
			err = dpmng_dev_memcpy(dev, ext_params, cfg.key_cfg_iova,
				DPNI_CMD_EXTRACT_EXT_PARAMS_OLD * sizeof(uint64_t),
				1);
		}
		else
		{
			err = dpmng_dev_memcpy(dev, ext_params, cfg.key_cfg_iova,
				DPNI_CMD_EXTRACT_EXT_PARAMS * sizeof(uint64_t),
				1);
		}

		if (err) {
			pr_err("Error reading extended DMA parameters");
			return err;
		}

		/* Read extention */
		err = dpkg_read_extract_cfg_extention(&extract_cfg, ext_params);
		CHECK_COND_RETVAL(err == 0, err, "dpkg_read_extract_cfg_extention() return error");

		cfg.key_changed = 1;
	}

	cfg.dist_key_cfg = &extract_cfg;

	return dpni_set_rx_hash_dist(dpni, cfg.tc_id, &cfg);
}

static int set_rx_hash_dist_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return set_rx_hash_dist_common(dev, cmd_data, 1);
}

static int set_rx_hash_dist_v2(struct device *dev,	struct mc_cmd_data *cmd_data)
{
	return set_rx_hash_dist_common(dev, cmd_data, 2);
}

static int add_custom_tpid(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t tpid;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_ADD_CUSTOM_TPID(cmd_data, tpid);

	return dpni_add_custom_tpid(dpni, tpid);
}

static int remove_custom_tpid(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	uint16_t tpid;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_REMOVE_CUSTOM_TPID(cmd_data, tpid);

	return dpni_remove_custom_tpid(dpni, tpid);
}

static int get_custom_tpid(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_custom_tpid tpid;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	err = dpni_get_custom_tpid(dpni, &tpid);
	CHECK_COND_RETVAL( err == 0, err, "dpni_get_custom_tpid() failed");

	DPNI_RSP_GET_TPID(cmd_data, &tpid);

	return 0;
}

static int set_port_cfg(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni	*dpni;
	uint32_t	flags;
	struct dpni_port_cfg port_cfg = { 0 };

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	DPNI_CMD_SET_PORT_CFG(cmd_data, flags, (&port_cfg));

	return dpni_set_port_cfg(dpni, flags, &port_cfg);
}

static int get_port_cfg(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpni *dpni;
	struct dpni_port_cfg port_cfg;
	int err;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	memset(&port_cfg, 0, sizeof(struct dpni_port_cfg));
	err = dpni_get_port_cfg(dpni, &port_cfg);
	CHECK_COND_RETVAL(err==0, err);

	DPNI_RSP_GET_PORT_CFG(cmd_data, (&port_cfg));

	return 0;
}

static int dpni_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpni_open on DPNI %d\n", device_get_id(dev));

	return 0;
}

static int dpni_close_cb(void *dev, int portal_id, uint32_t token)
{
	struct dpni *dpni;

	UNUSED(portal_id);

	pr_info("Handling command: dpni_close on DPNI %d\n", device_get_id(dev));

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL( dpni !=NULL , 0, "No dpni associated with device");

	return dpni_close(dpni, (uint16_t)token);
}

static int dump_table(struct device *dev, struct mc_cmd_data *cmd_data)
{
	uint16_t table_type;
	uint16_t table_index;
	uint64_t snapshot_iova;
	uint32_t iova_size;
	uint16_t table_size;
	int err;

	DPNI_CMD_DUMP_TABLE(cmd_data, table_type, table_index, snapshot_iova, iova_size);

	err = dpni_dump_table(dev, table_type, table_index, snapshot_iova, (int)iova_size, &table_size);
	CHECK_COND_RETVAL(err==0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));	
	DPNI_RSP_DUMP_TABLE(cmd_data, table_size);

	return 0;
}

static int dpni_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	int i;
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int err;
	struct {
		int code;
		int (*function)(struct device *dev,
			struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPNI_CMD_CODE_CREATE, init_v0, "dpni_create", DPNI_CMD_V0 },
			{ DPNI_CMD_CODE_DESTROY, destroy, "dpni_destroy", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_ENABLE_VLAN_FILTER, enable_vlan_filter, "dpni_enable_vlan_filter", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_ENABLE, enable, "dpni_enable", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_DISABLE, disable, "dpni_disable", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_RESET, reset, "dpni_reset", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_IS_ENABLED, is_enabled, "dpni_is_enabled", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_PRIORITIES, set_tx_priorities_v1, "dpni_set_tx_priorities", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_RX_TC_DIST, set_rx_tc_dist_v0, "dpni_set_rx_tc_dist", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_RX_TC_EARLY_DROP, set_rx_tc_early_drop, "dpni_set_rx_tc_early_drop", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_RX_TC_POLICING, set_rx_tc_policing, "dpni_set_rx_tc_policing", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_FLOW, set_tx_flow, "dpni_set_tx_flow", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_TX_FLOW, get_tx_flow, "dpni_get_tx_flow", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_RX_FLOW, set_rx_flow, "dpni_set_rx_flow", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_RX_FLOW, get_rx_flow, "dpni_get_rx_flow", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_RX_ERR_QUEUE, set_rx_err_queue, "dpni_set_rx_err_queue", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_RX_ERR_QUEUE, get_rx_err_queue, "dpni_get_rx_err_queue", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_CONF_REVOKE, set_tx_conf_revoke, "dpni_set_tx_conf_revoke", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_ATTR, get_attributes_v0, "dpni_get_attributes", DPNI_CMD_V0 },
			{ DPNI_CMD_CODE_SET_ERRORS_BEHAVIOR, set_errors_behavior, "dpni_set_errors_behavior", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_QDID, get_qdid_v0, "dpni_get_qdid", DPNI_CMD_V0 },
			{ DPNI_CMD_CODE_GET_SP_INFO, get_sp_info, "dpni_get_sp_info", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_RX_BUFFER_LAYOUT, get_rx_buffer_layout, "dpni_get_rx_buffer_layout", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_RX_BUFFER_LAYOUT, set_rx_buffer_layout, "dpni_set_rx_buffer_layout", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_TX_BUFFER_LAYOUT, get_tx_buffer_layout, "dpni_get_tx_buffer_layout", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_BUFFER_LAYOUT, set_tx_buffer_layout, "dpni_set_tx_buffer_layout", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_TX_CONF_BUFFER_LAYOUT, get_tx_conf_buffer_layout, "dpni_get_tx_conf_buffer_layout", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_CONF_BUFFER_LAYOUT, set_tx_conf_buffer_layout, "dpni_set_tx_conf_buffer_layout", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_L3_CHKSUM_VALIDATION, get_l3_chksum_validation, "dpni_get_l3_chksum_validation", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_L3_CHKSUM_VALIDATION, set_l3_chksum_validation, "dpni_set_l3_chksum_validation", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_L4_CHKSUM_VALIDATION, get_l4_chksum_validation, "dpni_get_l4_chksum_validation", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_L4_CHKSUM_VALIDATION, set_l4_chksum_validation, "dpni_set_l4_chksum_validation", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_COUNTER, get_counter, "dpni_get_counter", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_COUNTER, set_counter, "dpni_set_counter", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_LINK_STATE, get_link_state_v1, "dpni_get_link_state", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_LINK_CFG, set_link_cfg_v1, "dpni_set_link_cfg", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_SHAPING, set_tx_shaping_v0, "dpni_set_tx_shaping", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_MAX_FRAME_LENGTH, set_max_frame_length, "dpni_set_max_frame_length", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_MAX_FRAME_LENGTH, get_max_frame_length, "dpni_get_max_frame_length", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_MTU, set_mtu, "dpni_set_mtu", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_MTU, get_mtu, "dpni_get_mtu", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_MCAST_PROMISC, set_multicast_promisc, "dpni_set_multicast_promisc", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_MCAST_PROMISC, get_multicast_promisc, "dpni_get_multicast_promisc", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_UNICAST_PROMISC, set_unicast_promisc, "dpni_set_unicast_promisc", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_UNICAST_PROMISC, get_unicast_promisc, "dpni_get_unicast_promisc", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_PRIM_MAC, set_primary_mac_addr, "dpni_set_primary_mac_addr", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_ADD_MAC_ADDR, add_mac, "dpni_add_mac_addr", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_REMOVE_MAC_ADDR, remove_mac, "dpni_remove_mac_addr", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_CLR_MAC_FILTERS, clear_mac_filters, "dpni_clear_mac_filters", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_ADD_VLAN_ID, add_vlan_id, "dpni_add_vlan_id", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_REMOVE_VLAN_ID, remove_vlan_id, "dpni_remove_vlan_id", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_CLR_VLAN_FILTERS, clear_vlan_filters, "dpni_clear_vlan_filters", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_QOS_TBL, set_qos_table, "dpni_set_qos_table", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_ADD_QOS_ENT, add_qos_entry_v0, "dpni_add_qos_entry", DPNI_CMD_V0 },
			{ DPNI_CMD_CODE_REMOVE_QOS_ENT, remove_qos_entry, "dpni_remove_qos_entry", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_CLR_QOS_TBL, clear_qos_table, "dpni_clear_qos_table", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_ADD_FS_ENT, add_fs_entry_v0, "dpni_add_fs_entry", DPNI_CMD_V0 },
			{ DPNI_CMD_CODE_REMOVE_FS_ENT, remove_fs_entry, "dpni_remove_fs_entry", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_CLR_FS_ENT, clear_fs_entries, "dpni_clear_fs_entries", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_TX_DATA_OFFSET, get_tx_data_offset, "dpni_get_tx_data_offset", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_PRIM_MAC, get_primary_mac_addr, "dpni_get_primary_mac_addr", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_CLR_MAC_FILTERS, clear_mac_filters, "dpni_clear_mac_filters", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_IRQ, set_irq, "dpni_set_irq", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_IRQ, get_irq, "dpni_get_irq", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpni_set_irq_enable", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpni_get_irq_enable", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpni_set_irq_mask", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpni_get_irq_mask", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpni_get_irq_status", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpni_clear_irq_status", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_POOLS, set_pools, "dpni_set_pools", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_IPR, set_ipr_enable, "dpni_set_ipr_enable", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_IPF, set_ipf_enable, "dpni_set_ipf_enable", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_RX_TC_POLICING, get_rx_tc_policing, "dpni_get_rx_tc_policing", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_RX_TC_EARLY_DROP, get_rx_tc_early_drop, "dpni_get_rx_tc_early_drop", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_TC_EARLY_DROP, set_tx_tc_early_drop, "dpni_set_tx_tc_early_drop", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_TX_TC_EARLY_DROP, get_tx_tc_early_drop, "dpni_get_tx_tc_early_drop", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_RX_TC_CONGESTION_NOTIFICATION, set_rx_tc_congestion_notification, "dpni_set_rx_tc_congestion_notification", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_RX_TC_CONGESTION_NOTIFICATION, get_rx_tc_congestion_notification, "dpni_get_rx_tc_congestion_notification", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_TC_CONGESTION_NOTIFICATION, set_tx_tc_congestion_notification, "dpni_set_tx_tc_congestion_notification", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_TX_TC_CONGESTION_NOTIFICATION, get_tx_tc_congestion_notification, "dpni_get_tx_tc_congestion_notification", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_CONF, set_tx_conf, "dpni_set_tx_conf", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_TX_CONF, get_tx_conf, "dpni_get_tx_conf", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_CONF_CONGESTION_NOTIFICATION, set_tx_conf_congestion_notification, "dpni_set_tx_conf_congestion_notification", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_TX_CONF_CONGESTION_NOTIFICATION, get_tx_conf_congestion_notification, "dpni_get_tx_conf_congestion_notification", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_IPSEC, set_ipsec_enable, "dpni_set_ipsec", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_IPSEC_ADD_SA, ipsec_add_sa, "dpni_ipsec_add_sa", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_IPSEC_REMOVE_SA, ipsec_remove_sa, "dpni_ipsec_remove_sa", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_IPSEC_FLUSH, ipsec_flush, "dpni_ipsec_flush", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_IPSEC_SA_GET_STATS, ipsec_sa_get_stats, "dpni_ipsec_sa_get_stats", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_VLAN_INSERTION, set_vlan_insertion, "dpni_set_vlan_insertion", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_VLAN_REMOVAL, set_vlan_removal, "dpni_set_vlan_removal", DPNI_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPNI_CMD_CODE_GET_API_VERSION, get_api_version, "dpni_get_api_version", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_CREATE, init_v1, "dpni_create", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_GET_ATTR, get_attributes_v1, "dpni_get_attributes", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_GET_ATTR, get_attributes_v1, "dpni_get_attributes", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_ATTR, get_attributes_v1, "dpni_get_attributes", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_GET_STATISTICS, get_statistics, "dpni_get_statistics", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_STATISTICS, get_statistics, "dpni_get_statistics", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_STATISTICS, get_statistics, "dpni_get_statistics", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_RESET_STATISTICS, reset_statistics, "dpni_reset_statistics", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_ADD_QOS_ENT, add_qos_entry_v1, "dpni_add_qos_entry", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_ADD_QOS_ENT, add_qos_entry_v2, "dpni_add_qos_entry", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_ADD_FS_ENT, add_fs_entry_v1, "dpni_add_fs_entry", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_GET_QUEUE, get_queue_v1, "dpni_get_queue", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_GET_QUEUE, get_queue_v2, "dpni_get_queue", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_SET_QUEUE, set_queue_v1, "dpni_set_queue", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_SET_QUEUE, set_queue_v2, "dpni_set_queue", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_TAILDROP, get_taildrop_v1, "dpni_get_taildrop", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_GET_TAILDROP, get_taildrop_v2, "dpni_get_taildrop", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_SET_TAILDROP, set_taildrop_v1, "dpni_set_taildrop", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_SET_TAILDROP, set_taildrop_v2, "dpni_set_taildrop", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_PORT_MAC_ADDR, get_port_mac_addr, "dpni_get_port_mac_addr", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_BUFFER_LAYOUT, set_buffer_layout_v1, "dpni_set_buffer_layout", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_BUFFER_LAYOUT, set_buffer_layout_v2, "dpni_set_buffer_layout", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_BUFFER_LAYOUT, get_buffer_layout_v1, "dpni_get_buffer_layout", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_BUFFER_LAYOUT, get_buffer_layout_v2, "dpni_get_buffer_layout", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_QDID, get_qdid_v1, "dpni_get_qdid", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_SET_CONGESTION_NOTIFICATION, set_congestion_notification_v1, "dpni_set_congestion_notification", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_CONGESTION_NOTIFICATION, set_congestion_notification_v2, "dpni_set_congestion_notification", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_CONGESTION_NOTIFICATION, get_congestion_notification_v1, "dpni_get_congestion_notification", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_CONGESTION_NOTIFICATION, get_congestion_notification_v2, "dpni_get_congestion_notification", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_SET_EARLY_DROP, set_early_drop_v1, "dpni_set_early_drop", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_EARLY_DROP, get_early_drop_v1, "dpni_get_early_drop", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_EARLY_DROP, set_early_drop_v2, "dpni_set_early_drop", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_EARLY_DROP, get_early_drop_v2, "dpni_get_early_drop", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_OFFLOAD, get_offload_v1, "dpni_get_offload", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_OFFLOAD, set_offload_v1, "dpni_set_offload", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_TX_CONFIRMATION_MODE, set_tx_confirmation_mode, "dpni_set_tx_confirmation_mode", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_TX_CONFIRMATION_MODE, get_tx_confirmation_mode, "dpni_get_tx_confirmation_mode", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_OPR, set_opr, "dpni_set_opr", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_OPR, get_opr, "dpni_get_opr", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_RX_TC_DIST, set_rx_tc_dist_v2, "dpni_set_rx_tc_dist", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_SET_TX_SHAPING, set_tx_shaping_v2, "dpni_set_tx_shaping", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_SET_POOLS, set_pools_v2, "dpni_set_pools", DPNI_CMD_V2 },
#ifndef OBSOLETED_SP_API
			{ DPNI_CMD_CODE_LOAD_SW_SEQUENCE, load_sw_sequence,
			  "dpni_load_sw_sequence", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_ENABLE_SW_SEQUENCE, enable_sw_sequence,
			  "dpni_enable_sw_sequence", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_SW_SEQUENCE_LAYOUT,
			  get_sw_sequence_layout, "dpni_get_sw_sequence_layout",
			  DPNI_CMD_VER_BASE },
#endif	/* OBSOLETED_SP_API */
			{ DPNI_CMD_CODE_SET_TX_PRIORITIES, set_tx_priorities_v2, "dpni_set_tx_priorities", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_SET_RX_TC_DIST, set_rx_tc_dist_v3, "dpni_set_rx_tc_dist", DPNI_CMD_V3 },
			{ DPNI_CMDID_SET_RX_FS_DIST, set_rx_fs_dist_v1, "dpni_set_rx_fs_dist", DPNI_CMD_VER_BASE },
			{ DPNI_CMDID_SET_RX_HASH_DIST, set_rx_hash_dist_v1, "dpni_set_rx_hash_dist", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_SET_QOS_TBL, set_qos_table_v2, "dpni_set_qos_table", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_CREATE, init_v2, "dpni_create", DPNI_CMD_V2 },
			{ DPNI_CMDID_ADD_CUSTOM_TPID, add_custom_tpid, "dpni_add_custom_tpid", DPNI_CMD_VER_BASE},
			{ DPNI_CMDID_REMOVE_CUSTOM_TPID, remove_custom_tpid, "dpni_remove_custom_tpid", DPNI_CMD_VER_BASE},
			{ DPNI_CMDID_GET_CUSTOM_TPID, get_custom_tpid, "dpni_get_custom_tpid", DPNI_CMD_VER_BASE},
			{ DPNI_CMD_CODE_GET_LINK_STATE, get_link_state_v2, "dpni_get_link_state", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_SET_LINK_CFG, set_link_cfg_v2, "dpni_set_link_cfg", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_CREATE, init_v3, "dpni_create", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_SET_POOLS, set_pools_v3, "dpni_set_pools", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_ADD_VLAN_ID, add_vlan_id_v2, "dpni_add_vlan_id", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_LINK_CFG, get_link_cfg, "dpni_get_link_cfg", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_ADD_MAC_ADDR, add_mac_v2, "dpni_add_mac_addr", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_SET_RX_TC_DIST, set_rx_tc_dist_v4, "dpni_set_rx_tc_dist", DPNI_CMD_V4 },
			{ DPNI_CMDID_SET_RX_HASH_DIST, set_rx_hash_dist_v2, "dpni_set_rx_hash_dist", DPNI_CMD_V2 },
			{ DPNI_CMDID_SET_RX_FS_DIST, set_rx_fs_dist_v2, "dpni_set_rx_fs_dist", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_CREATE, init_v4, "dpni_create", DPNI_CMD_V4 },
			{ DPNI_CMD_CODE_SET_OPR, set_opr_v2, "dpni_set_opr", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_OPR, get_opr_v2, "dpni_get_opr", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_SET_PORT_CFG, set_port_cfg, "dpni_set_port_cfg", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_GET_PORT_CFG, get_port_cfg, "dpni_get_port_cfg", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_SET_SINGLE_STEP_CFG, set_single_step_cfg, "dpni_set_ptp_cfg", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_SINGLE_STEP_CFG, get_single_step_cfg, "dpni_get_ptp_cfg", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_CREATE, init_v5, "dpni_create", DPNI_CMD_V5 },
			{ DPNI_CMD_CODE_DUMP_TABLE, dump_table, "dpni_dump_table", DPNI_CMD_V1 },
			{ DPNI_CMD_CODE_ADD_FS_ENT, add_fs_entry_v2, "dpni_add_fs_entry", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_SET_SP_PROFILE, set_sp_profile, "dpni_set_sp_profile", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_CREATE, init_v6, "dpni_create", DPNI_CMD_V6 },
			{ DPNI_CMD_CODE_GET_ATTR, get_attributes_v4, "dpni_get_attributes", DPNI_CMD_V4 },
			{ DPNI_CMD_CODE_GET_QDID_EX, get_qdid_ex_v1, "dpni_get_qdid_ex", DPNI_CMD_VER_BASE },
			{ DPNI_CMD_CODE_GET_QUEUE, get_queue_v3, "dpni_get_queue", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_GET_STATISTICS, get_statistics_v4, "dpni_get_statistics", DPNI_CMD_V4 },
			{ DPNI_CMD_CODE_SET_TX_SHAPING, set_tx_shaping_v3, "dpni_set_tx_shaping", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_SET_CONGESTION_NOTIFICATION, set_congestion_notification_v3, "dpni_set_congestion_notification", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_GET_CONGESTION_NOTIFICATION, get_congestion_notification_v3, "dpni_get_congestion_notification", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_SET_QUEUE, set_queue_v3, "dpni_set_queue", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_SET_TAILDROP, set_taildrop_v3, "dpni_set_taildrop", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_SET_TX_PRIORITIES, set_tx_priorities_v3, "dpni_set_tx_priorities", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_SET_EARLY_DROP, set_early_drop_v3, "dpni_set_early_drop", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_GET_EARLY_DROP, get_early_drop_v3, "dpni_get_early_drop", DPNI_CMD_V3 },
			{ DPNI_CMD_CODE_SET_OFFLOAD, set_offload_v2, "dpni_set_offload", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_OFFLOAD, get_offload_v2, "dpni_get_offload", DPNI_CMD_V2 },
			{ DPNI_CMD_CODE_GET_ATTR, get_attributes_v5, "dpni_get_attributes", DPNI_CMD_V5 },
		};

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
			if (cmd == DPNI_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else {
				pr_info("Handling command: %s on DPNI %d\n", map_commands[i].cmd_str, device_get_id(dev));
				/* special checks for various commands */
				if (cmd == DPNI_CMD_CODE_ADD_FS_ENT ) {
					err = add_fs_entry_check((struct device *)dev, portal_id, cmd_data, cmd_ver);
					CHECK_COND_RETVAL( err == 0, -EINVAL, "Failed to check parameters for dpni_add_fs_entry\n");
				}
			}
			return map_commands[i].function((struct device *)dev,
							cmd_data);
		}

	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}

struct dpni_option_map {
	char *opt_str;
	uint32_t options;
};

struct dpni_option_map dpni_option_map_v0[] = {
	{ "DPNI_OPT_ALLOW_DIST_KEY_PER_TC", DPNI_OPT_ALLOW_DIST_KEY_PER_TC },
	{ "DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED",
			DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED },
	{ "DPNI_OPT_TX_CONF_DISABLED", DPNI_OPT_TX_CONF_DISABLED },
	{ "DPNI_OPT_DIST_HASH", DPNI_OPT_DIST_HASH },
	{ "DPNI_OPT_DIST_FS", DPNI_OPT_DIST_FS },
	{ "DPNI_OPT_UNICAST_FILTER", DPNI_OPT_UNICAST_FILTER },
	{ "DPNI_OPT_MULTICAST_FILTER", DPNI_OPT_MULTICAST_FILTER },
	{ "DPNI_OPT_VLAN_FILTER", DPNI_OPT_VLAN_FILTER },
	{ "DPNI_OPT_IPR", DPNI_OPT_IPR },
	{ "DPNI_OPT_IPF", DPNI_OPT_IPF },
	{ "DPNI_OPT_VLAN_MANIPULATION", DPNI_OPT_VLAN_MANIPULATION },
	{ "DPNI_OPT_QOS_MASK_SUPPORT", DPNI_OPT_QOS_MASK_SUPPORT },
	{ "DPNI_OPT_FS_MASK_SUPPORT", DPNI_OPT_FS_MASK_SUPPORT },
};

struct dpni_option_map dpni_option_map_v1[] = {
	{ "DPNI_OPT_TX_FRM_RELEASE", DPNI_OPT_V1_TX_FRM_RELEASE },
	{ "DPNI_OPT_NO_MAC_FILTER", DPNI_OPT_V1_NO_MAC_FILTER },
	{ "DPNI_OPT_HAS_POLICING", DPNI_OPT_V1_HAS_POLICING },
	{ "DPNI_OPT_SHARED_CONGESTION", DPNI_OPT_V1_SHARED_CONGESTION },
	{ "DPNI_OPT_HAS_KEY_MASKING", DPNI_OPT_V1_HAS_KEY_MASKING },
	{ "DPNI_OPT_NO_FS", DPNI_OPT_V1_NO_FS },
	{ "DPNI_OPT_HAS_OPR", DPNI_OPT_V1_HAS_OPR },
	{ "DPNI_OPT_OPR_PER_TC", DPNI_OPT_V1_OPR_PER_TC },
	{ "DPNI_OPT_SINGLE_SENDER", DPNI_OPT_V1_SINGLE_SENDER },
	{ "DPNI_OPT_PFDR_IN_PEB", DPNI_OPT_V1_PFDR_IN_PEB},
	{ "DPNI_OPT_CUSTOM_CG", DPNI_OPT_V1_CUSTOM_CG},
	{ "DPNI_OPT_CUSTOM_OPR", DPNI_OPT_V1_CUSTOM_OPR},
	{ "DPNI_OPT_SHARED_HASH_KEY", DPNI_OPT_V5_SHARED_HASH_KEY},
	{ "DPNI_OPT_SHARED_FS", DPNI_OPT_V5_SHARED_FS},
};

static uint32_t get_options(void *lo, int node_off, struct dpni_option_map *map,
		int map_count)
{
	char *opt_str;
	int total_len;
	int len;
	int i = 0;
	uint32_t options = 0;

	opt_str = (char *)fdt_getprop(lo, node_off, "options", &total_len);
	if (opt_str && (int)(*opt_str) != 0) {
		while (total_len > 0) {
			while (i < (map_count - 1) && strcmp(opt_str, map[i].opt_str))
				i++;
			if (!strcmp(opt_str, map[i].opt_str))
				options |= map[i].options;
			else
				pr_warn("Ignored DPNI CREATE option \"%s\"\n", opt_str);
			len = (int)strlen(opt_str) + 1;
			total_len -= len;
			opt_str = PTR_MOVE(opt_str, len);
			i = 0;
		}
	}

	return options;
}

static enum net_prot get_net_prot(void *lo, int node_off, char *str)
{
	int i;
	struct {
		char *net_str;
		enum net_prot net_prot;
	} map[] =
		{ { "NET_PROT_NONE", NET_PROT_NONE },
			{ "NET_PROT_PAYLOAD", NET_PROT_PAYLOAD },
			{ "NET_PROT_ETH", NET_PROT_ETH },
			{ "NET_PROT_VLAN", NET_PROT_VLAN },
			{ "NET_PROT_IPV4", NET_PROT_IPV4 },
			{ "NET_PROT_IPV6", NET_PROT_IPV6 },
			{ "NET_PROT_IP", NET_PROT_IP },
			{ "NET_PROT_TCP", NET_PROT_TCP },
			{ "NET_PROT_UDP", NET_PROT_UDP },
			{ "NET_PROT_UDP_LITE", NET_PROT_UDP_LITE },
			{ "NET_PROT_IPHC", NET_PROT_IPHC },
			{ "NET_PROT_SCTP", NET_PROT_SCTP },
			{ "NET_PROT_SCTP_CHUNK_DATA", NET_PROT_SCTP_CHUNK_DATA },
			{ "NET_PROT_PPPOE", NET_PROT_PPPOE },
			{ "NET_PROT_PPP", NET_PROT_PPP },
			{ "NET_PROT_PPPMUX", NET_PROT_PPPMUX },
			{ "NET_PROT_PPPMUX_SUBFRM", NET_PROT_PPPMUX_SUBFRM },
			{ "NET_PROT_L2TPV2", NET_PROT_L2TPV2 },
			{ "NET_PROT_L2TPV3_CTRL", NET_PROT_L2TPV3_CTRL },
			{ "NET_PROT_L2TPV3_SESS", NET_PROT_L2TPV3_SESS },
			{ "NET_PROT_LLC", NET_PROT_LLC },
			{ "NET_PROT_LLC_SNAP", NET_PROT_LLC_SNAP },
			{ "NET_PROT_NLPID", NET_PROT_NLPID },
			{ "NET_PROT_SNAP", NET_PROT_SNAP },
			{ "NET_PROT_MPLS", NET_PROT_MPLS },
			{ "NET_PROT_IPSEC_AH", NET_PROT_IPSEC_AH },
			{ "NET_PROT_IPSEC_ESP", NET_PROT_IPSEC_ESP },
			{ "NET_PROT_UDP_ENC_ESP", NET_PROT_UDP_ENC_ESP },
			{ "NET_PROT_MACSEC", NET_PROT_MACSEC },
			{ "NET_PROT_GRE", NET_PROT_GRE },
			{ "NET_PROT_MINENCAP", NET_PROT_MINENCAP },
			{ "NET_PROT_DCCP", NET_PROT_DCCP },
			{ "NET_PROT_ICMP", NET_PROT_ICMP },
			{ "NET_PROT_IGMP", NET_PROT_IGMP },
			{ "NET_PROT_ARP", NET_PROT_ARP },
			{ "NET_PROT_CAPWAP_DATA", NET_PROT_CAPWAP_DATA },
			{ "NET_PROT_CAPWAP_CTRL", NET_PROT_CAPWAP_CTRL },
			{ "NET_PROT_RFC2684", NET_PROT_RFC2684 },
			{ "NET_PROT_ICMPV6", NET_PROT_ICMPV6 },
			{ "NET_PROT_FCOE", NET_PROT_FCOE },
			{ "NET_PROT_FIP", NET_PROT_FIP },
			{ "NET_PROT_ISCSI", NET_PROT_ISCSI },
			{ "NET_PROT_GTP", NET_PROT_GTP },
			{ "NET_PROT_USER_DEFINED_L2", NET_PROT_USER_DEFINED_L2 },
			{ "NET_PROT_USER_DEFINED_L3", NET_PROT_USER_DEFINED_L3 },
			{ "NET_PROT_USER_DEFINED_L4", NET_PROT_USER_DEFINED_L4 },
			{ "NET_PROT_USER_DEFINED_L5", NET_PROT_USER_DEFINED_L5 },
			{ "NET_PROT_USER_DEFINED_SHIM1",
				NET_PROT_USER_DEFINED_SHIM1 },
			{ "NET_PROT_USER_DEFINED_SHIM2",
				NET_PROT_USER_DEFINED_SHIM2 } };
	if (!str)
		return NET_PROT_NONE;
	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (!strcmp(str, map[i].net_str))
			return map[i].net_prot;
	}pr_err("Invalid net_prot '%s' setting to default 'NET_PROT_NONE'\n");
	return NET_PROT_NONE;
}

static int dpni_probe_cb_v0(void *lo, int node_off)
{
	int err = 0;
	int i;
	struct mc_cmd_data 	*cmd_data;
	struct mc_cmd_data_ext cmd_tmp;
	struct mc_cmd_data_ext *cmd = &cmd_tmp;
	struct device *dev;
	struct resman *resman;
	struct dpni_cfg dpni_cfg;
	struct dpni_cfg *cfg = &dpni_cfg;
	struct dpni_extended_cfg *ext_cfg = &cfg->adv.ext_cfg;
	int id;
	uint64_t val;
	uint32_t val32;
	char *tmp_str;
	int destroy = 0;

	memset(cmd, 0, sizeof(struct mc_cmd_data_ext));
	memset(cfg, 0, sizeof(struct dpni_cfg));

	cmd_data = &cmd->cmd_data;
	
	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	for (i = 0; i < 6; i++) {
		getprop_array(lo, node_off, "mac_addr", i, &val32);
		dpni_cfg.mac_addr[i] = (uint8_t)val32;
	}
	getprop_val(lo, node_off, "max_senders", 0, 0, &val);
	dpni_cfg.adv.max_senders = (uint8_t)val;
	dpni_cfg.adv.options = get_options(lo, node_off, dpni_option_map_v0,
			ARRAY_SIZE(dpni_option_map_v0));

	tmp_str = (char *)fdt_getprop(lo, node_off, "start_hdr", NULL);
	dpni_cfg.adv.start_hdr = get_net_prot(lo, node_off, tmp_str);

	getprop_val(lo, node_off, "max_tcs", 0, 0, &val);
	dpni_cfg.adv.max_tcs = (uint8_t)val;

	getprop_val(lo, node_off, "max_unicast_filters", 0, 0, &val);
	dpni_cfg.adv.max_unicast_filters = (uint8_t)val;
	getprop_val(lo, node_off, "max_multicast_filters", 0, 0, &val);
	dpni_cfg.adv.max_multicast_filters = (uint8_t)val;
	getprop_val(lo, node_off, "max_vlan_filters", 0, 0, &val);
	dpni_cfg.adv.max_vlan_filters = (uint8_t)val;
	getprop_val(lo, node_off, "max_qos_entries", 0, 0, &val);
	dpni_cfg.adv.max_qos_entries = (uint8_t)val;
	getprop_val(lo, node_off, "max_qos_key_size", 0, 0, &val);
	dpni_cfg.adv.max_qos_key_size = (uint8_t)val;
	getprop_val(lo, node_off, "max_dist_key_size", 0, 0, &val);
	dpni_cfg.adv.max_dist_key_size = (uint8_t)val;
	getprop_val(lo, node_off, "max_policers", 0, 0, &val);
	dpni_cfg.adv.max_policers = (uint8_t)val;
	getprop_val(lo, node_off, "max_congestion_ctrl", 0, 0, &val);
	dpni_cfg.adv.max_congestion_ctrl = (uint8_t)val;
	/* ext_cfg parameters */
	for (i = 0; i < dpni_cfg.adv.max_tcs && i < DPNI_MAX_RX_TC; i++) {
		getprop_array(lo, node_off, "max_dist_per_tc", i, &val32);
		ext_cfg->tc_cfg[i].max_dist = (uint16_t)val32;
		getprop_array(lo, node_off, "max_fs_entries_per_tc", i,
				&val32);
		ext_cfg->tc_cfg[i].max_fs_entries =
			(uint16_t)val32;
	}
	getprop_val(lo, node_off, "max_open_frames_ipv4", 0, 0, &val);
	ext_cfg->ipr_cfg.max_open_frames_ipv4 = (uint16_t)val;
	getprop_val(lo, node_off, "max_open_frames_ipv6", 0, 0, &val);
	ext_cfg->ipr_cfg.max_open_frames_ipv6 = (uint16_t)val;
	getprop_val(lo, node_off, "max_reass_frm_size", 0, 0, &val);
	ext_cfg->ipr_cfg.max_reass_frm_size = (uint16_t)val;
	getprop_val(lo, node_off, "min_frag_size_ipv4", 0, 0, &val);
	ext_cfg->ipr_cfg.min_frag_size_ipv4 = (uint16_t)val;
	getprop_val(lo, node_off, "min_frag_size_ipv6", 0, 0, &val);
	ext_cfg->ipr_cfg.min_frag_size_ipv6 = (uint16_t)val;

	/* mark extension from DPL */
	dpni_cfg.adv.ext_cfg_iova = DPNI_DPL_EXT;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(resman, "dpni", (uint16_t)id, NO_PORTAL_ID,
			DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPNI %.4x\n", id);
	DPNI_LO_CREATE_V0(cmd_data, cfg);
	DPNI_PREP_EXTENDED_CFG(cmd->ext_params, ext_cfg);
	/* create object */
	err = dpni_ctrl_cb(dev, DPNI_CMD_V0, DPNI_CMD_CODE_CREATE, NO_PORTAL_ID,
				(uint8_t*)cmd);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpni", NO_PORTAL_ID, destroy);

	return err;
}

static int dpni_probe_cb_v1(void *lo, int node_off)
{
	struct dpni_cfg_v1 cfg;
	struct mc_cmd_data_ext cmd = { 0 };

	int err = 0;
	struct device *dev;
	struct resman *resman;
	int id;
	uint64_t val;
	int destroy = 0;

	memset(&cfg, 0, sizeof(struct dpni_cfg_v1));

	err = get_node_id(lo, node_off, &id);
	CHECK_COND_RETVAL(err == 0, err);

	cfg.options = get_options(lo, node_off, dpni_option_map_v1,
			ARRAY_SIZE(dpni_option_map_v1));

	getprop_val(lo, node_off, "fs_entries", 0, 0, &val);
	cfg.fs_entries = (uint16_t) val;

	getprop_val(lo, node_off, "vlan_filter_entries", 0, 0, &val);
	cfg.vlan_filter_entries = (uint8_t) val;

	getprop_val(lo, node_off, "mac_filter_entries", 0, 0, &val);
	cfg.mac_filter_entries = (uint8_t) val;

	getprop_val(lo, node_off, "num_rx_tcs", 0, 0, &val);
	cfg.num_rx_tcs = (uint8_t) val;

	getprop_val(lo, node_off, "num_queues", 0, 0, &val);
	cfg.num_queues = (uint8_t) val;

	getprop_val(lo, node_off, "num_tcs", 0, 0, &val);
	cfg.num_tcs = (uint8_t) val;

	getprop_val(lo, node_off, "qos_entries", 0, 0, &val);
	cfg.qos_entries = (uint8_t) val;

	getprop_val(lo, node_off, "num_cgs", 0, 0, &val);
	cfg.num_cgs = (uint8_t) val;

	getprop_val(lo, node_off, "num_opr", 0, 0, &val);
	cfg.num_opr = (uint16_t) val;

	getprop_val(lo, node_off, "dist_key_size", 0, 0, &val);
	cfg.dist_key_size = (uint8_t) val;

	getprop_val(lo, node_off, "num_channels", 0, 0, &val);
	cfg.num_ceetm_ch = (uint8_t) val;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(resman, "dpni", (uint16_t) id, NO_PORTAL_ID,
			DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPNI %.4x\n", id);
	DPNI_LO_CREATE_V6(&cmd.cmd_data, &cfg);
	/* create object */
	err = dpni_ctrl_cb(dev, DPNI_CMD_V6, DPNI_CMD_CODE_CREATE, NO_PORTAL_ID,
			(uint8_t*) &cmd);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpni", NO_PORTAL_ID, destroy);

	return err;
}

static int dpni_probe_cb(void *lo, int node_off)
{
	unsigned long long ver;

	getprop_val(lo, 0, "dpl-version", NULL, 8, &ver);
	if (ver >= 10)
		return dpni_probe_cb_v1(lo, node_off);

	return dpni_probe_cb_v0(lo, node_off);
}

static int dpni_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	err = get_node_id(lo, node_off, &id);
	CHECK_COND_RETVAL(err == 0, err);
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman) {
		pr_err("Can't find resman");
		return -ENODEV;
	}

	dev = resman_open_dev(resman, "dpni", (uint16_t)id, NO_PORTAL_ID, 0,
				NULL);
	if (!dev) {
		pr_err("Can't open DPNI 0x%.4x\n", id);
		return -ENODEV;
	}

	err |= dpni_ctrl_cb(dev, DPNI_CMD_V0, DPNI_CMD_CODE_DESTROY,
	                      NO_PORTAL_ID, NULL);

	err |= resman_close_dev(resman, dev, "dpni", NO_PORTAL_ID, 0);

	return err;
}

static char *dpni_match[] = { "fsl,dpni", "dpni" };

int dpni_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	struct linkman *linkman;

	pr_info("Executing dpni_drv_init...\n");
	
	dtc_params.num_compats = ARRAY_SIZE(dpni_match);
	dtc_params.compatibles = dpni_match;
	dtc_params.f_prob_module = dpni_probe_cb;
	dtc_params.f_remove_module = dpni_remove_cb;
	sys_dtc_register_module(&dtc_params);

	cmdif_ops.open_cb = dpni_open_cb;
	cmdif_ops.close_cb = dpni_close_cb;
	cmdif_ops.ctrl_cb = dpni_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPNI, &cmdif_ops);

	strcpy(dev_type_param.device_type, "dpni");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPNI_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPNI_VER_MAJOR;
	dev_type_param.ver_minor = DPNI_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;
#ifdef TKT011436	
	dev_type_param.f_graceful_stop = graceful_stop_by_resman;
	dev_type_param.f_empty_check = empty_check_by_resman;
	dev_type_param.f_restore_after_eiop_reset = restore_by_resman;
	dev_type_param.f_resume = resume_by_resman;
#endif /* TKT011436 */

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	ASSERT_COND(resman);
	resman_register_device_operation(resman, "dpni", &dev_type_param);

	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	ASSERT_COND(linkman);
	linkman_register_cb(linkman, FSL_MOD_DPNI, dpni_linkman_event_cb,
				dpni_linkman_event_complete_cb);

	return 0;
}
