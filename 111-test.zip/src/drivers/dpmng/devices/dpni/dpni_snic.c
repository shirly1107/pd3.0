/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpni_snic.c

 @Description   library implementation

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_malloc.h"
#include "drivers/fsl_aiop.h"
#include "fsl_event_pipe.h"

#include "fsl_dpmng_mc.h"
#include "fsl_dpcon_mc.h"
#include "fsl_dpio_mc.h"
#include "fsl_dpbp_mc.h"
#include "fsl_aiop.h"

#include "dpni.h"
#include "fsl_snic_cmd.h"
#include "fsl_qbman.h"

#define CMD_PREP(_param, _offset, _width, _type, _arg) \
	(cmd_data.params[_param] |= u64_enc((_offset), (_width), (_arg)))

#define RSP_READ(_param, _offset, _width, _type, _arg) \
	(*(_arg) = (_type)u64_dec(cmd_data.params[_param], (_offset), (_width)))

#define CMD_PREP_BYTE_ARRAY(_param, _offset, _width, _type, _arg) \
{\
		int i, u_param = _param, u_offset = _offset, _array_size = _width/8;\
	 	 for (i = 0; i < _array_size; i++) {\
	 		 u_offset = (_offset + (i * 8)) % 64;\
	 		 if (u_offset == 0)\
	 		 	 u_param += 1;\
	 		 	 (cmd_data.params[u_param] |= u64_enc((u_offset), (8), (*(_arg + i))));\
	 	 }\
	}

static int snic_allocate_and_fill_bp(struct dpni *dpni)
{
	struct qbman_release_desc release_desc;
	struct qbman_swp *sw_portal;
	uint64_t addr[1];
	uint32_t res_count = 0;
	int err = 0, i, res_arr[10];
	const struct memory_partition_list snic_ddr_mem_partitions = {
			.mem_part_ids = {
				MEM_PART_DP_DDR, MEM_PART_SYSTEM_DDR2, MEM_PART_SYSTEM_DDR1,
				MEM_PART_LAST /* mark end of list*/ } };
	/* Allocate DPNI_SNIC_PEB_NUM_OF_BUFFERS PEB Buffers of
	 * DPNI_SNIC_PEB_BUFFER_SIZE */
	err = fsl_get_mem(
		DPNI_SNIC_PEB_NUM_OF_BUFFERS * DPNI_SNIC_PEB_BUFFER_SIZE,
		MEM_PART_PEB, DPNI_SNIC_BUFFER_ALIGN, &dpni->snic.peb_mem_paddr);
	if (err) {
		pr_err("ID[%d]: no memory for PEB buffers\n", dpni->id);
		return -ENOMEM;
	}

	/* Allocate DPNI_SNIC_DDR_NUM_OF_BUFFERS (DPDDR or system-DDR)
	 * Buffers of DPNI_SNIC_DDR_BUFFER_SIZE */
	err = fsl_get_mem_mp(
		DPNI_SNIC_DDR_NUM_OF_BUFFERS * DPNI_SNIC_DDR_BUFFER_SIZE,
		&snic_ddr_mem_partitions, DPNI_SNIC_BUFFER_ALIGN,
		&dpni->snic.ddr_mem_paddr);
	if (err) {
		pr_err("ID[%d]: no memory for DDR buffers\n", dpni->id);
		return -ENOMEM;
	}

	res_count = 2;
	if ((err = allocate_resource(dpni->device, "bp", res_count, 1, 0,
					res_arr, "BPIDs"))
		!= 0) {
		fsl_put_mem(dpni->snic.peb_mem_paddr);
		fsl_put_mem(dpni->snic.ddr_mem_paddr);
		return err;
	}

	dpni->snic.peb_bpid = res_arr[0];
	dpni->snic.ddr_bpid = res_arr[1];

	/* Clear the contents of a descriptor to default/starting state. */
	qbman_release_desc_clear(&release_desc);

	/* Set the ID of the buffer pool to release to */
	qbman_release_desc_set_bpid(&release_desc,
					(uint32_t)dpni->snic.peb_bpid);

	/* Get software portal */
	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	for (i = 0; i < DPNI_SNIC_PEB_NUM_OF_BUFFERS; i++) {
		addr[0] = (uint64_t)(
			dpni->snic.peb_mem_paddr
			+ i * DPNI_SNIC_PEB_BUFFER_SIZE);

		/* Release buffres to BMan */
		err = qbman_swp_release(sw_portal, /* QMan SW Portal */
					&release_desc, /* Buffer Pool ID */
					addr, /* Buffer Address */
					1 /* Number of Buffers */
					);
		if (err != 0)
			break;
	}

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	/* Clear the contents of a descriptor to default/starting state. */
	qbman_release_desc_clear(&release_desc);

	/* Set the ID of the buffer pool to release to */
	qbman_release_desc_set_bpid(&release_desc,
					(uint32_t)dpni->snic.ddr_bpid);

	/* Get software portal */
	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	for (i = 0; i < DPNI_SNIC_DDR_NUM_OF_BUFFERS; i++) {
		addr[0] = (uint64_t)(
			dpni->snic.ddr_mem_paddr
			+ i * DPNI_SNIC_DDR_BUFFER_SIZE);

		/* Release buffres to BMan */
		err = qbman_swp_release(sw_portal, /* QMan SW Portal */
					&release_desc, /* Buffer Pool ID */
					addr, /* Buffer Address */
					1 /* Number of Buffers */
					);
		if (err != 0)
			break;
	}

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return err;
}

static void snic_deallocate_and_drain_bp(struct dpni *dpni)
{
	struct qbman_swp *sw_portal;
	uint64_t addr[1];
	int ret = 0;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	do {
		ret = qbman_swp_acquire(sw_portal,
					(uint32_t)dpni->snic.peb_bpid, addr,
					1);
	} while (ret > 0);ASSERT_COND(ret == 0);

	do {
		ret = qbman_swp_acquire(sw_portal,
					(uint32_t)dpni->snic.ddr_bpid, addr,
					1);
	} while (ret > 0);ASSERT_COND(ret == 0);

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	fsl_put_mem(dpni->snic.peb_mem_paddr);
	fsl_put_mem(dpni->snic.ddr_mem_paddr);
}

static int snic_cmdif_open(struct dpni *dpni)
{
	int err = 0;

	dpni->snic.cidesc.regs = sys_get_unique_handle(FSL_MOD_CMDIF_CL_REGS);
	if (!dpni->snic.cidesc.regs)
		return -ENAVAIL;
	err = cmdif_open(&dpni->snic.cidesc, "sNIC", 0,
				dpni->snic.command_buffer, 64);

	return err;
}

static void snic_cmdif_close(struct dpni *dpni)
{
	int err;

	err = cmdif_close(&dpni->snic.cidesc);
	ASSERT_COND(err == 0);
}

static int snic_register(struct dpni *dpni,
	uint32_t *snic_ep_pc,
	uint16_t *snic_id)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;

	err = cmdif_send(&dpni->snic.cidesc, (uint16_t)SNIC_REGISTER, /*cmd_id*/
				SNIC_CMDSZ_REGISTER, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);

	SNIC_REGISTER_CMD(RSP_READ);

	return err;
}

static void snic_unregister(struct dpni *dpni, uint16_t snic_id)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;

	SNIC_UNREGISTER_CMD(CMD_PREP);

	err = cmdif_send(&dpni->snic.cidesc, (uint16_t)SNIC_UNREGISTER, /*cmd_id*/
				SNIC_CMDSZ_UNREGISTER, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);
}

static void snic_set_qdid(struct dpni *dpni, uint16_t snic_id, uint32_t qdid)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;

	SNIC_SET_QDID_CMD(CMD_PREP);

	err = cmdif_send(&dpni->snic.cidesc, (uint16_t)SNIC_SET_QDID, /*cmd_id*/
				SNIC_CMDSZ_SET_QDID, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);
}

static void snic_set_spid(struct dpni *dpni, uint16_t snic_id, uint32_t spid)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;

	SNIC_SET_SPID_CMD(CMD_PREP);

	err = cmdif_send(&dpni->snic.cidesc, (uint16_t)SNIC_SET_SPID, /*cmd_id*/
				SNIC_CMDSZ_SET_SPID, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);
}

static void snic_set_enable_flags(struct dpni *dpni,
	uint16_t snic_id,
	int vlan_insert,
	int vlan_remove,
	int ipr,
	int ipf,
	int ipsec)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	uint16_t snic_flags = 0;
	int err;

	snic_flags |= (vlan_insert ? SNIC_VLAN_ADD_EN : 0);
	snic_flags |= (vlan_remove ? SNIC_VLAN_REMOVE_EN : 0);
	snic_flags |= (ipr ? SNIC_IPR_EN : 0);
	snic_flags |= (ipf ? SNIC_IPF_EN : 0);
	snic_flags |= (ipsec ? SNIC_IPSEC_EN : 0);
	SNIC_ENABLE_FLAGS_CMD(CMD_PREP);

	err = cmdif_send(&dpni->snic.cidesc, (uint16_t)SNIC_ENABLE_FLAGS, /*cmd_id*/
				SNIC_CMDSZ_ENABLE_FLAGS, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);
}

static void snic_set_mtu(struct dpni *dpni, uint16_t snic_id, uint16_t ipf_mtu)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;

	SNIC_CMD_MTU(CMD_PREP);

	err = cmdif_send(&dpni->snic.cidesc, (uint16_t)SNIC_SET_MTU, /*cmd_id*/
				SNIC_CMDSZ_SET_MTU, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);
}

static void snic_ipr_create_instance(struct dpni *dpni,
	uint16_t snic_id,
	struct dpni_ipr_cfg *cfg)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;

	SNIC_IPR_CREATE_INSTANCE_CMD(CMD_PREP);

	err = cmdif_send(&dpni->snic.cidesc,
				(uint16_t)SNIC_IPR_CREATE_INSTANCE, /*cmd_id*/
				SNIC_CMDSZ_IPR_CREATE_INSTANCE, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);
}

static void snic_ipr_delete_instance(struct dpni *dpni, uint16_t snic_id)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;

	SNIC_IPR_DELETE_INSTANCE_CMD(CMD_PREP);

	err = cmdif_send(&dpni->snic.cidesc,
				(uint16_t)SNIC_IPR_DELETE_INSTANCE, /*cmd_id*/
				SNIC_CMDSZ_IPR_DELETE_INSTANCE, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);
}

static int map_mc_to_aiop_snic_params(struct dpni_ipsec_cfg *ipsec_cfg)
{
	int i = 0;
	uint8_t tmp = 0;

	const struct map_mc_to_aiop map_sa_selectors[] = {
		{ DPNI_IPSEC_INCLUDE_IP_SRC_IN_SA_SELECT,
			SNIC_IPSEC_INCLUDE_IP_SRC_IN_SA_SELECT },
		{ DPNI_IPSEC_INCLUDE_IP_DST_IN_SA_SELECT,
			SNIC_IPSEC_INCLUDE_IP_DST_IN_SA_SELECT } };

	for (i = 0; i < ARRAY_SIZE(map_sa_selectors); i++)
		if (ipsec_cfg->sa_selectors & map_sa_selectors[i].mc)
			tmp |= map_sa_selectors[i].aiop;
	ipsec_cfg->sa_selectors = (uint8_t)tmp;

	return 0;
}

static int snic_ipsec_create_instance(struct dpni *dpni,
	uint16_t snic_id,
	struct dpni_ipsec_cfg *cfg)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;

	err = map_mc_to_aiop_snic_params(cfg);
	if (err)
		return err;

	SNIC_IPSEC_CREATE_INSTANCE_CMD(CMD_PREP);

	err = cmdif_send(&dpni->snic.cidesc,
				(uint16_t)SNIC_IPSEC_CREATE_INSTANCE, /*cmd_id*/
				SNIC_CMDSZ_IPSEC_CREATE_INSTANCE, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);

	/* initialize general parameters */
	dpni->snic.ipsec_info.options = cfg->sa_selectors;

	return 0;
}

static void snic_ipsec_delete_instance(struct dpni *dpni, uint16_t snic_id)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;

	SNIC_IPSEC_DELETE_INSTANCE_CMD(CMD_PREP);

	err = cmdif_send(&dpni->snic.cidesc, (uint16_t)SNIC_IPSEC_DEL_INSTANCE, /*cmd_id*/
				SNIC_CMDSZ_IPSEC_DELETE_INSTANCE, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);
}

static int snic_config_fqid(struct dpni *dpni,
	struct dpni_snic_fqid_info *rx_queue)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	struct qbman_attr state;
	uint16_t wqid_base;
	int err, ps = 0;

	ps = qbman_cacheable_pfdr();
	
	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_icid(&fqdesc, dpni->snic.mc_amq.icid,
				dpni->snic.mc_amq.pl);
	qbman_fq_attr_set_mctl(&fqdesc, dpni->snic.mc_amq.bdi, 1,
				dpni->snic.mc_amq.va, ps, 0);
	qbman_fq_attr_set_ctx(&fqdesc, (uint32_t)(rx_queue->ctx >> 32),
				(uint32_t)(rx_queue->ctx));
	qbman_fq_attr_set_vfqid(&fqdesc, rx_queue->virt_fqid);
	err = qbman_fq_configure(sw_portal, (uint32_t)rx_queue->fqid, &fqdesc);
	if (err != 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		pr_err("ID[%d]: qbman_fq_configure failed\n", dpni->id);
		return err;
	}

	wqid_base = dpmng_get_dcp_wqid(dpni->dpmng, QBMAN_DCP_AIOP, 0);
	qbman_fq_attr_set_destwq(&fqdesc, (uint32_t)(wqid_base << 3));

	err = qbman_fq_configure(sw_portal, (uint32_t)rx_queue->fqid, &fqdesc);
	if (err != 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		pr_err( "qbman_fq_configure failed\n", dpni->id);
		return err;
	}

	err = qbman_fq_query_state(sw_portal, (uint32_t)rx_queue->fqid,
					&state);
	if (err != 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		pr_err("ID[%d]: qbman_fq_query failed\n", dpni->id);
		return err;
	}

	if (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_parked) {
		err = qbman_swp_fq_schedule(sw_portal,
						(uint32_t)rx_queue->fqid);
		if (err != 0) {
			pr_err("ID[%d]: qbman_swp_fq_schedule failed\n", dpni->id);
			return err;
		}
	}
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return 0;
}

static int snic_config_rx_qbman(struct dpni *dpni)
{
	struct qbman_swp *sw_portal;
	int err;

	if (dpni->ap_valid) {
		/* Post AIOP */
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_dct_configure(
			sw_portal,
			dpni->ceetmid,
			(uint16_t)dpni->snic.ing_post_aiop.dctidx,
			dpni->snic.mc_amq.bdi,
			dpni->snic.mc_amq.va,
			dpni->snic.mc_amq.icid,
			dpni->snic.mc_amq.pl,
			((uint64_t)dpni->snic.ing_post_aiop.fcead.command1
				<< 32)
			| (uint64_t)dpni->snic.ing_post_aiop.fcead.command2);
		if (err != 0) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			pr_err( "qbman_dct_configure failed\n", dpni->id);
			return err;
		}

		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	}

	/* Pre AIOP */
	err = snic_config_fqid(dpni, &dpni->snic.ing_pre_aiop);
	if (err != 0)
		return err;

	return 0;
}

static int snic_config_tx_qbman(struct dpni *dpni)
{
	struct qbman_swp *sw_portal;
	int err, i;

	if (dpni->ap_valid) {
		/* Post AIOP */
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		for (i = 0; i < dpni->max_tx_tcs; i++) {
			err =
				qbman_dct_configure(
					sw_portal,
					dpni->ceetmid,
					(uint16_t)dpni->snic.egr_post_aiop[i].dctidx,
					dpni->snic.mc_amq.bdi,
					dpni->snic.mc_amq.va,
					dpni->snic.mc_amq.icid,
					dpni->snic.mc_amq.pl,
					((uint64_t)dpni->snic.egr_post_aiop[i].fcead.command1
						<< 32)
					| (uint64_t)dpni->snic.egr_post_aiop[i].fcead.command2);
			if (err != 0) {
				dpmng_put_swportal(dpni->dpmng,
							(void*)sw_portal);
				pr_err( "qbman_dct_configure failed\n", dpni->id);
				return err;
			}

		}
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	}

	for (i = 0; i < dpni->max_tx_tcs; i++) {
		err = snic_config_fqid(dpni, &dpni->snic.egr_pre_aiop[i]);
		if (err != 0)
			return err;
	}

	return 0;
}

static void snic_clear_fqid(struct dpni *dpni,
	struct dpni_snic_fqid_info *rx_queue)
{
	if (!rx_queue->retire_storage)
		rx_queue->retire_storage = (struct qbman_result *)fsl_xmalloc(
			sizeof(struct qbman_result), 0, 64);
	ASSERT_COND(rx_queue->retire_storage);

	dpmng_clear_fqid((uint32_t)rx_queue->fqid, rx_queue->retire_storage,
				&rx_queue->retire_pending);

	if (rx_queue->retire_pending == 1)
		return;
}

static int snic_clear_tx_side(struct dpni *dpni)
{
	int i;

	for (i = 0; i < dpni->max_tx_tcs; i++)
		snic_clear_fqid(dpni, &dpni->snic.egr_pre_aiop[i]);

	return 0;
}

static int snic_clear_rx_side(struct dpni *dpni)
{
	/* Pre AIOP */
	snic_clear_fqid(dpni, &dpni->snic.ing_pre_aiop);

	return 0;
}

static int snic_config_spid(struct dpni *dpni)
{
	struct aiop_sp_cfg sp_cfg;
	int err;

	memset(&sp_cfg, 0, sizeof(struct aiop_sp_cfg));
	sp_cfg.bdi = dpni->snic.mc_amq.bdi;
	sp_cfg.pl = dpni->snic.mc_amq.pl;
	sp_cfg.icid = dpni->snic.mc_amq.icid;
	sp_cfg.virt_addr = dpni->snic.mc_amq.va;
	sp_cfg.frame_format = SP_FF_SINGLE_BUF_OR_SG;
	sp_cfg.pass_thru_ann_room =
		dpni->snic.egress_ifp_info->init.defcfg.rx_buf_layout.priv_data_size;
	eiop_ifp_get_hw_annotation_room(&dpni->snic.egress_ifp_info->ifp_desc,
					&sp_cfg.accel_specific_ann_room);
	sp_cfg.data_head_room =
		dpni->snic.egress_ifp_info->init.defcfg.rx_buf_layout.data_headroom;
	sp_cfg.num_pools = 2;
	sp_cfg.bp_cfg[0].bmt = dpni->snic.mc_amq.bmt;
	sp_cfg.bp_cfg[0].bpid = (uint16_t)dpni->snic.peb_virt_bpid;
	sp_cfg.bp_cfg[0].bp_size = DPNI_SNIC_PEB_BUFFER_SIZE;
	sp_cfg.bp_cfg[1].bmt = dpni->snic.mc_amq.bmt;
	sp_cfg.bp_cfg[1].bpid = (uint16_t)dpni->snic.ddr_virt_bpid;
	sp_cfg.bp_cfg[1].bp_size = DPNI_SNIC_DDR_BUFFER_SIZE;
	sp_cfg.bp_cfg[1].backup_pool = 1;

	err = aiop_tile_set_storage_profile(dpni->aiop_tile,
						(uint32_t)dpni->snic.spid,
						&sp_cfg);

	return err;
}

static int snic_initial_configuration_pre_aiop(struct dpni *dpni)
{
	struct qbman_swp *sw_portal;
	uint16_t qprid[DPNI_MAX_RX_TC + DPNI_MAX_TX_TC];
	int err, i;

	for (i = 0; i < dpni->max_tx_tcs; i++) {
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_qpr_configure(
			sw_portal, (uint16_t)dpni->snic.egr_pre_aiop[i].qprid,
			(uint32_t)dpni->snic.egr_pre_aiop[i].fqid, (uint16_t)1,
			(uint32_t)0);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_qpr_configure failed\n", dpni->id);
			return err;
		}
	}

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_qpr_configure(
		sw_portal, (uint16_t)dpni->snic.ing_pre_aiop.qprid,
		(uint32_t)dpni->snic.ing_pre_aiop.fqid, (uint16_t)1,
		(uint32_t)0);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d]: qbman_qpr_configure failed\n", dpni->id);
		return err;
	}

	/* Config QPR array */
	for (i = 0; i < DPNI_MAX_RX_TC + DPNI_MAX_TX_TC; i++)
		qprid[i] = (uint16_t)(
			(i < DPNI_MAX_TX_TC) ?
				dpni->snic.egr_pre_aiop[i].qprid :
				dpni->snic.ing_pre_aiop.qprid);

	/* Config QDR */
	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_qd_configure(sw_portal, (uint16_t)dpni->snic.pre_aiop_qdid,
					qprid);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d]: qbman_qd_configure failed\n", dpni->id);
		return err;
	}

	return 0;
}

static int snic_initial_configuration_post_aiop(struct dpni *dpni)
{
	struct qbman_swp *sw_portal;
	uint16_t qprid[DPNI_MAX_TX_TC + DPNI_MAX_RX_TC];
	int err, i;

	memset(&dpni->snic.ing_post_aiop.fcead, 0, sizeof(struct eiop_fcead));
	EIOP_FCEAD_SET_IFPID( &dpni->snic.ing_post_aiop.fcead,
				dpni->mem_ifp_info->ifp_desc.ifp_id);

	for (i = 0; i < dpni->max_tx_tcs; i++) {
		memset(&dpni->snic.egr_post_aiop[i].fcead, 0,
			sizeof(struct eiop_fcead));
		EIOP_FCEAD_SET_IFPID(
			&dpni->snic.egr_post_aiop[i].fcead,
			dpni->snic.ingress_ifp_info->ifp_desc.ifp_id);
	}

	/* Config QPR array */
	for (i = 0; i < DPNI_MAX_TX_TC + DPNI_MAX_RX_TC; i++)
		qprid[i] = (uint16_t)(
			(i < DPNI_MAX_TX_TC) ?
				dpni->snic.egr_post_aiop[i].qprid :
				dpni->snic.ing_post_aiop.qprid);

	/* Config QDR */
	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_qd_configure(sw_portal,
					(uint16_t)dpni->snic.post_aiop_qdid,
					qprid);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d]: qbman_qd_configure failed\n", dpni->id);
		return err;
	}

	return 0;
}

static int map_mc_to_aiop_sa_params(struct dpni_ipsec_sa_cfg *ipsec_cfg)
{
	int i;
	uint32_t tmp;

	const struct map_mc_to_aiop map_dir[] = {
		{ DPNI_IPSEC_SA_IN, SNIC_IPSEC_SA_IN }, {
			DPNI_IPSEC_SA_OUT, SNIC_IPSEC_SA_OUT } };

	const struct map_mc_to_aiop map_options[] =
		{ { DPNI_IPSEC_SA_OPT_EXT_SEQ_NUM,
			SNIC_IPSEC_SA_OPT_EXT_SEQ_NUM },
			{ DPNI_IPSEC_SA_OPT_IPV6, SNIC_IPSEC_SA_OPT_IPV6 }, {
				DPNI_IPSEC_SA_OPT_RND_GEN_IV,
				SNIC_IPSEC_SA_OPT_RND_GEN_IV } };

#define DPNI_IPSEC_SA_OPT_EXT_SEQ_NUM		0x00000001
#define DPNI_IPSEC_SA_OPT_RND_GEN_IV		0x00000002
#define DPNI_IPSEC_SA_OPT_IPV6				0x00000004
#define DPNI_IPSEC_SA_COPY_INNER_DF			0x00000008
#define DPNI_IPSEC_SA_CFG_DSCP 				0x00000010

	const struct map_mc_to_aiop map_anti_replay[] = {
		{ DPNI_IPSEC_SA_ANTI_REPLAY_NONE,
			SNIC_IPSEC_SA_ANTI_REPLAY_NONE },
		{ DPNI_IPSEC_SA_ANTI_REPLAY_WS_32,
			SNIC_IPSEC_SA_ANTI_REPLAY_WS_32 },
		{ DPNI_IPSEC_SA_ANTI_REPLAY_WS_64,
			SNIC_IPSEC_SA_ANTI_REPLAY_WS_64 },
		{ DPNI_IPSEC_SA_ANTI_REPLAY_WS_128,
			SNIC_IPSEC_SA_ANTI_REPLAY_WS_128 } };

	const struct map_mc_to_aiop map_cipher_alg[] = {
		{ DPNI_IPSEC_CIPHER_DES_IV64, SNIC_IPSEC_CIPHER_DES_IV64 }, {
			DPNI_IPSEC_CIPHER_DES, SNIC_IPSEC_CIPHER_DES },
		{ DPNI_IPSEC_CIPHER_3DES, SNIC_IPSEC_CIPHER_3DES }, {
			DPNI_IPSEC_CIPHER_NULL, SNIC_IPSEC_CIPHER_NULL },
		{ DPNI_IPSEC_CIPHER_AES_CBC, SNIC_IPSEC_CIPHER_AES_CBC }, {
			DPNI_IPSEC_CIPHER_AES_CTR, SNIC_IPSEC_CIPHER_AES_CTR },
		{ DPNI_IPSEC_CIPHER_AES_CCM8, SNIC_IPSEC_CIPHER_AES_CCM8 }, {
			DPNI_IPSEC_CIPHER_AES_CCM12,
			SNIC_IPSEC_CIPHER_AES_CCM12 },
		{ DPNI_IPSEC_CIPHER_AES_CCM16, SNIC_IPSEC_CIPHER_AES_CCM16 },
		{ DPNI_IPSEC_CIPHER_AES_GCM8, SNIC_IPSEC_CIPHER_AES_GCM8 }, {
			DPNI_IPSEC_CIPHER_AES_GCM12,
			SNIC_IPSEC_CIPHER_AES_GCM12 },
		{ DPNI_IPSEC_CIPHER_AES_GCM16, SNIC_IPSEC_CIPHER_AES_GCM16 }, {
			DPNI_IPSEC_CIPHER_AES_NULL_WITH_GMAC,
			SNIC_IPSEC_CIPHER_AES_NULL_WITH_GMAC } };

	const struct map_mc_to_aiop map_auth_alg[] =
		{ { DPNI_IPSEC_AUTH_NULL, SNIC_IPSEC_AUTH_NULL }, {
			DPNI_IPSEC_AUTH_HMAC_MD5_96,
			SNIC_IPSEC_AUTH_HMAC_MD5_96 },
			{ DPNI_IPSEC_AUTH_HMAC_SHA1_96,
				SNIC_IPSEC_AUTH_HMAC_SHA1_96 },
			{ DPNI_IPSEC_AUTH_AES_XCBC_MAC_96,
				SNIC_IPSEC_AUTH_AES_XCBC_MAC_96 },
			{ DPNI_IPSEC_AUTH_HMAC_MD5_128,
				SNIC_IPSEC_AUTH_HMAC_MD5_128 },
			{ DPNI_IPSEC_AUTH_HMAC_SHA1_160,
				SNIC_IPSEC_AUTH_HMAC_SHA1_160 },
			{ DPNI_IPSEC_AUTH_AES_CMAC_96,
				SNIC_IPSEC_AUTH_AES_CMAC_96 },
			{ DPNI_IPSEC_AUTH_HMAC_SHA2_256_128,
				SNIC_IPSEC_AUTH_HMAC_SHA2_256_128 },
			{ DPNI_IPSEC_AUTH_HMAC_SHA2_384_192,
				SNIC_IPSEC_AUTH_HMAC_SHA2_384_192 },
			{ DPNI_IPSEC_AUTH_HMAC_SHA2_512_256,
				SNIC_IPSEC_AUTH_HMAC_SHA2_512_256 } };

	i = 0;
	while ((i < ARRAY_SIZE(map_dir))
		&& ((uint8_t)map_dir[i].mc != ipsec_cfg->direction))
		i++;
	if (i == ARRAY_SIZE(map_dir)) {
		pr_err("Invalid direction\n");
		return -EINVAL;
	}
	ipsec_cfg->direction = (uint8_t)map_dir[i].aiop;

	i = 0;
	while ((i < ARRAY_SIZE(map_anti_replay))
		&& ((uint8_t)map_anti_replay[i].mc != ipsec_cfg->in.anti_replay))
		i++;
	if (i == ARRAY_SIZE(map_anti_replay)) {
		pr_err("Invalid anti_replay value\n");
		return -EINVAL;
	}
	ipsec_cfg->in.anti_replay = (uint8_t)map_anti_replay[i].aiop;

	i = 0;
	while ((i < ARRAY_SIZE(map_cipher_alg))
		&& ((uint8_t)map_cipher_alg[i].mc != ipsec_cfg->cipher.alg))
		i++;
	if (i == ARRAY_SIZE(map_cipher_alg)) {
		pr_err("Invalid cipher alg value\n");
		return -EINVAL;
	}
	ipsec_cfg->cipher.alg = (uint8_t)map_cipher_alg[i].aiop;

	i = 0;
	while ((i < ARRAY_SIZE(map_auth_alg))
		&& ((uint8_t)map_auth_alg[i].mc != ipsec_cfg->auth.alg))
		i++;
	if (i == ARRAY_SIZE(map_auth_alg)) {
		pr_err("Invalid auth alg value\n");
		return -EINVAL;
	}
	ipsec_cfg->auth.alg = (uint8_t)map_auth_alg[i].aiop;

	tmp = 0;
	for (i = 0; i < ARRAY_SIZE(map_options); i++)
		if (ipsec_cfg->options & map_options[i].mc)
			tmp |= map_options[i].aiop;
	ipsec_cfg->options = tmp;

	return 0;
}

static int snic_ipsec_get_sa(struct dpni *dpni, uint8_t *return_sa_id)
{
	uint8_t sa_id = 0;

	/* search for a free SA */
	while ((sa_id < DPNI_MAX_SAS)
		&& dpni->snic.ipsec_info.sa_array[sa_id].registered)
		sa_id++;
	if (sa_id == DPNI_MAX_SAS)
		return -ENOSPC;

	/* mark SA as registered and return selected SA */
	dpni->snic.ipsec_info.sa_array[sa_id].registered = 1;
	*return_sa_id = sa_id;

	return 0;
}

static int snic_ipsec_config_sa(struct dpni *dpni,
	struct dpni_ipsec_sa_cfg *ipsec_cfg,
	uint8_t sa_id)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;

	/* check validity of parameters and map to AIOP coding */
	err = map_mc_to_aiop_sa_params(ipsec_cfg);
	if (err)
		return err;

	dpni->snic.ipsec_info.sa_array[sa_id].cfg = *ipsec_cfg;

	return 0;
}

static int snic_ipsec_add_sa(struct dpni *dpni, uint8_t sa_id)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err = 0;
	int snic_id = dpni->snic.dpni_index;
	struct dpni_ipsec_sa_cfg *cfg;
	uint32_t nic_options;

	cfg = &dpni->snic.ipsec_info.sa_array[sa_id].cfg;

	/* Copy NIC options */
	nic_options = dpni->snic.ipsec_info.options;
	/* add SA internal options (include key flags) */
	//cfg->options |= 0;
	SNIC_IPSEC_ADD_SA_CMD(CMD_PREP, CMD_PREP_BYTE_ARRAY);
	err = cmdif_send(&dpni->snic.cidesc, (uint16_t)SNIC_IPSEC_ADD_SA, /*cmd_id*/
				SNIC_CMDSZ_IPSEC_ADD_SA, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);

	/* mark SA as registered and return selected SA */
	dpni->snic.ipsec_info.sa_array[sa_id].added = 1;
	if (dpni->snic.ipsec_info.sa_array[sa_id].tmp_buf)
		fsl_free(dpni->snic.ipsec_info.sa_array[sa_id].tmp_buf);

	return 0;
}

static int snic_ipsec_rmv_sa(struct dpni *dpni, uint8_t sa_id)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;
	int snic_id = dpni->snic.dpni_index;
	struct sa_info *sa_info = &dpni->snic.ipsec_info.sa_array[sa_id];
	uint32_t nic_options;
	struct dpni_ipsec_sa_cfg *cfg =
		&dpni->snic.ipsec_info.sa_array[sa_id].cfg;

	/* Nothing to remove */
	if (!sa_info->registered)
		return 0;

	/* Copy NIC options */
	nic_options = dpni->snic.ipsec_info.options;

	/* if SA was actually added (i.e. snic configured) - remove it.
	 * otherwise, it is only in the MC data base (registered) */
	if (sa_info->added) {
		SNIC_IPSEC_DEL_SA_CMD(CMD_PREP, CMD_PREP_BYTE_ARRAY);
		err = cmdif_send(&dpni->snic.cidesc,
					(uint16_t)SNIC_IPSEC_DEL_SA, /*cmd_id*/
					SNIC_CMDSZ_IPSEC_DEL_SA, /*size*/
					CMDIF_PRI_HIGH, /*priority*/
					(uint64_t)(&cmd_data), /*data*/
					NULL, NULL);
		ASSERT_COND(err == 0);

		/* mark SA as removed (redundant action) */
		sa_info->added = 0;
	}
	/* mark SA as unregistered */
	sa_info->registered = 0;

	return 0;
}

static int snic_ipsec_sa_get_stats(struct dpni *dpni,
	int sa_id,
	uint64_t *kbytes,
	uint64_t *packets,
	uint32_t *secs)
{
	struct snic_cmd_data cmd_data = { { 0 } };
	int err;
	int snic_id = dpni->snic.dpni_index;
	struct sa_info *sa_info = &dpni->snic.ipsec_info.sa_array[sa_id];

	/* Nothing to read */
	if (!sa_info->added)
		return 0;

	SNIC_IPSEC_SA_GET_STATS_CMD(CMD_PREP);
	err = cmdif_send(&dpni->snic.cidesc, (uint16_t)SNIC_IPSEC_SA_GET_STATS, /*cmd_id*/
				SNIC_CMDSZ_IPSEC_SA_GET_STATS_MAX, /*size*/
				CMDIF_PRI_HIGH, /*priority*/
				(uint64_t)(&cmd_data), /*data*/
				NULL, NULL);
	ASSERT_COND(err == 0);

	SNIC_IPSEC_SA_GET_STATS_RSP_CMD(RSP_READ);

	return 0;
}

static int init_ipsec(struct dpni *dpni)
{
	int err;
	uint8_t i;

	err = snic_ipsec_create_instance(dpni, dpni->snic.dpni_index,
						&dpni->snic.ipsec_info.cfg);
	ASSERT_COND(err == 0);

	for (i = 0; i < DPNI_MAX_SAS; i++)
		if (dpni->snic.ipsec_info.sa_array[i].registered)
			snic_ipsec_add_sa(dpni, i);
	/*dpni->snic.ipsec_info.sa_array[i].cfg.sa_id*/

	return 0;
}

/* Inter-module API */
void snic_set_defaults(struct dpni *dpni, int reset)
{
	dpni->snic.mtu = DPNI_DEFAULT_MAX_TRANSMIT_UNIT;
	dpni->snic.ipf = 0;
	dpni->snic.ipr = 0;
	dpni->snic.ipsec = 0;
	dpni->snic.vlan_insert = 0;
	dpni->snic.vlan_remove = 0;
	dpni->snic.pass_fas = 0;
}

int snic_ceetm_configuration(struct dpni *dpni)
{
	struct qbman_swp *sw_portal;
	uint32_t lfqid;
	int err, ps = 0;
	uint8_t i;

	ps = qbman_cacheable_pfdr();

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_cq_configure(
		sw_portal, dpni->ceetmid,
		(uint16_t)dpni->snic.ing_post_aiop.cqid,
		(uint8_t)dpni->snic.ing_post_aiop.ccgid,
		ps,
		/* PFDR Pool 0 */0);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err( "qbman_cq_configure failed\n", dpni->id);
		return err;
	}

	lfqid = qbman_lfqid_compose_ex(
		dpni->ceetmid, (uint16_t)dpni->snic.ing_post_aiop.lfqidx);

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_lfq_configure(
		sw_portal, lfqid, (uint16_t)dpni->snic.ing_post_aiop.cqid,
		(uint16_t)dpni->snic.ing_post_aiop.dctidx, 0);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err( "qbman_lfq_configure failed\n", dpni->id);
		return err;
	}

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_qpr_configure(
		sw_portal, (uint16_t)dpni->snic.ing_post_aiop.qprid, lfqid, 1,
		(uint32_t)dpni->snic.ing_post_aiop.ccgid);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err( "qbman_qpr_configure failed\n", dpni->id);
		return err;
	}

	for (i = 0; i < dpni->max_tx_tcs; i++) {
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_cq_configure(
			sw_portal, dpni->ceetmid,
			(uint16_t)dpni->snic.egr_post_aiop[i].cqid,
			(uint8_t)dpni->snic.egr_post_aiop[i].ccgid,
			ps,
			/* PFDR Pool 0 */0);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err( "qbman_cq_configure failed\n", dpni->id);
			return err;
		}

		lfqid = qbman_lfqid_compose_ex(
			dpni->ceetmid,
			(uint16_t)dpni->snic.egr_post_aiop[i].lfqidx);

		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_lfq_configure(
			sw_portal, lfqid,
			(uint16_t)dpni->snic.egr_post_aiop[i].cqid,
			(uint16_t)dpni->snic.egr_post_aiop[i].dctidx, 0);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err( "qbman_lfq_configure failed\n", dpni->id);
			return err;
		}

		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_qpr_configure(
			sw_portal, (uint16_t)dpni->snic.egr_post_aiop[i].qprid,
			lfqid, 1, (uint32_t)dpni->snic.egr_post_aiop[i].ccgid);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err( "qbman_qpr_configure failed\n", dpni->id);
			return err;
		}
	}

	err = snic_config_tx_qbman(dpni);
	if (err != 0) {
		pr_err("ID[%d]: snic_config_tx_qbman failed\n", dpni->id);
		return err;
	}

	err = snic_config_rx_qbman(dpni);
	if (err != 0) {
		pr_err("ID[%d]: snic_config_rx_qbman failed\n", dpni->id);
		return err;
	}

	return 0;
}

int snic_configuration(struct dpni *dpni)
{
	struct aiop_ep_entry_cfg ep_cfg = { 0 };
	int i, err;

	err = snic_cmdif_open(dpni);
	if (err != 0) {
		pr_err("ID[%d]: AIOP communication failed\n", dpni->id);
		return err;
	}

	err = snic_register(dpni, &ep_cfg.pc, &dpni->snic.dpni_index);
	if (err != 0) {
		snic_cmdif_close(dpni);
		pr_err("ID[%d]: Exceeded HF-NICs limit\n", dpni->id);
		return err;
	}

	snic_set_qdid(dpni, dpni->snic.dpni_index,
			dpni->snic.post_aiop_virt_qdid);
	snic_set_spid(dpni, dpni->snic.dpni_index, (uint32_t)dpni->snic.spid);
	if (dpni->options & DPNI_OPT_IPR)
		snic_ipr_create_instance(dpni, dpni->snic.dpni_index,
						&dpni->snic.ipr_cfg);
	if (dpni->options & DPNI_OPT_IPF)
		snic_set_mtu(dpni, dpni->snic.dpni_index, dpni->snic.mtu);
	if (dpni->options & DPNI_OPT_IPSEC)
		init_ipsec(dpni);

	snic_set_enable_flags(dpni, dpni->snic.dpni_index,
				dpni->snic.vlan_insert, dpni->snic.vlan_remove,
				dpni->snic.ipr, dpni->snic.ipf,
				dpni->snic.ipsec);

	err = aiop_tile_ws_set_ep_entry(dpni->aiop_tile,
					(uint32_t)dpni->snic.epid, &ep_cfg);
	ASSERT_COND(err == 0);

	dpni->snic.ing_pre_aiop.ctx = (DPNI_SNIC_INGRESS << 31)
					| dpni->snic.dpni_index;
	err = snic_config_fqid(dpni, &dpni->snic.ing_pre_aiop);
	if (err != 0)
		return err;

	for (i = 0; i < dpni->max_tx_tcs; i++) {
		dpni->snic.egr_pre_aiop[i].ctx =
			(DPNI_SNIC_EGRESS << 31) | dpni->snic.dpni_index;
		err = snic_config_fqid(dpni, &dpni->snic.egr_pre_aiop[i]);
		if (err != 0)
			return err;
	}

	err = snic_config_spid(dpni);
	if (err != 0) {
		pr_err("ID[%d]: snic_config_spid failed\n", dpni->id);
		return err;
	}

	dpni->snic.configured = 1;

	return 0;
}

int snic_initial_configuration(struct dpni *dpni)
{
	int err;

	dpmng_get_amq(&dpni->snic.mc_amq);

	err = snic_initial_configuration_pre_aiop(dpni);
	if (err)
		return err;

	err = snic_initial_configuration_post_aiop(dpni);
	if (err)
		return err;

	return 0;
}

int snic_ceetm_resources_allocation(struct dpni *dpni)
{
	int err, i;
	char type[16];
	struct dpmng_accesspoint ap = { 0 };
	int dcp_id, ceetm_id;

	dcp_id = dpni->tx_ch[0].ap.dcp_id;
	ceetm_id = dpni->tx_ch[0].ap.ceetm_id;

	snprintf(type, sizeof(type), "cqch.ctm%d.ins%d", dcp_id, ceetm_id);
	if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
					&dpni->snic.ceetm_chid, "CQ-Channel"))
		!= 0)
		return err;

	ap.ceetm_id = ceetm_id;
	ap.dcp_id = dcp_id;
	ap.iop_id = dpni->eiop_id;
	ap.cqchid = dpni->snic.ceetm_chid;
	err = dpmng_connection_virt_lniid(dpni->dpmng, &ap);
	ASSERT_COND(err == 0);

	set_accesspoint_to_lni(dpni, &ap, 0);

	for (i = 0; i < dpni->max_tx_tcs + 1; i++) {
		struct dpni_snic_lfqid_info *lfqid_info;

		if (i < dpni->max_tx_tcs) {
			lfqid_info = &dpni->snic.egr_post_aiop[i];
			lfqid_info->ccgid = i; /* CCG are mapped to 0-7 */
		} else {
			lfqid_info = &dpni->snic.ing_post_aiop;
			lfqid_info->ccgid = 0;
		}

		/* LFQID_INFO */
		snprintf(type, sizeof(type), "lfqmt.ctm%d.ins%d",
				dcp_id, ceetm_id);
		if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
						&lfqid_info->lfqidx, "LFQID"))
			!= 0)
			return err;

		snprintf(type, sizeof(type), "dct.ctm%d.ins%d",
				dcp_id, ceetm_id);
		if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
						&lfqid_info->dctidx, "DCTIDX"))
			!= 0)
			return err;
	}

	return 0;
}

int snic_ceetm_resources_deallocation(struct dpni *dpni)
{
	int err, i;
	char type[16];
	int dcp_id, ceetm_id;

	dcp_id = dpni->tx_ch[0].ap.dcp_id;
	ceetm_id = dpni->tx_ch[0].ap.ceetm_id;

	snprintf(type, sizeof(type), "cqch.ctm%d.ins%d", dcp_id, ceetm_id);
	if ((err = deallocate_resource(dpni->device, type,
					dpni->snic.ceetm_chid, "CQ-Channel"))
		!= 0)
		return err;

	for (i = 0; i < dpni->max_tx_tcs + 1; i++) {
		struct dpni_snic_lfqid_info *lfqid_info;

		if (i < dpni->max_tx_tcs)
			lfqid_info = &dpni->snic.egr_post_aiop[i];
		else
			lfqid_info = &dpni->snic.ing_post_aiop;

		/* LFQID_INFO */
		snprintf(type, sizeof(type), "lfqmt.ctm%d.ins%d", dcp_id, ceetm_id);
		if ((err = deallocate_resource(dpni->device, type,
						lfqid_info->lfqidx, "LFQID"))
			!= 0)
			return err;

		snprintf(type, sizeof(type), "dct.ctm%d.ins%d", dcp_id, ceetm_id);
		if ((err = deallocate_resource(dpni->device, type,
						lfqid_info->dctidx, "DCTIDX"))
			!= 0)
			return err;
	}

	return 0;
}

int snic_resources_allocation(struct dpni *dpni)
{
	int err, i, res_arr[100];
	char type[16];

	if ((err = snic_allocate_and_fill_bp(dpni)) != 0)
		return err;

	snprintf(type, sizeof(type), "ifp.wr%d", dpni->eiop_id);
	if ((err = allocate_resource(dpni->device, type, 2, 1, 0, res_arr,
					"IFP"))
		!= 0)
		return err;
	dpni->snic.ingress_ifp_info->ifp_desc.ifp_id = res_arr[0];
	dpni->snic.egress_ifp_info->ifp_desc.ifp_id = res_arr[1];

	dpni->snic.ingress_ifp_info->ifp_desc.eiop_id = dpni->eiop_id;
	dpni->snic.ingress_ifp_info->next_ifpid =
		dpni->snic.ingress_ifp_info->ifp_desc.ifp_id;
	err = sys_get_desc(SOC_MODULE_EIOP_IFP,
				(SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID),
				&dpni->snic.ingress_ifp_info->ifp_desc, NULL);
	ASSERT_COND(err == 0);

	dpni->snic.egress_ifp_info->ifp_desc.eiop_id = dpni->eiop_id;
	dpni->snic.egress_ifp_info->next_ifpid =
		dpni->snic.egress_ifp_info->ifp_desc.ifp_id;
	err = sys_get_desc(SOC_MODULE_EIOP_IFP,
				(SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID),
				&dpni->snic.egress_ifp_info->ifp_desc, NULL);
	ASSERT_COND(err == 0);

	/* Hash KID */
	snprintf(type, sizeof(type), "kp.wr%d.ctlui", dpni->eiop_id);
	if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
					&dpni->snic.hash_kid, "KIDs"))
		!= 0)
		return err;

	/* QDID */
	if ((err = allocate_resource(dpni->device, "qd", 2, 1, 0, res_arr,
					"QDID"))
		!= 0)
		return err;
	dpni->snic.pre_aiop_qdid = res_arr[0];
	dpni->snic.post_aiop_qdid = res_arr[1];

	/* QPR */
	if ((err = allocate_resource(dpni->device, "qpr",
					(uint32_t)(2 * (dpni->max_tx_tcs + 1)), 1,
					0, res_arr, "QPRs"))
		!= 0)
		return err;

	ASSERT_COND(dpni->max_tx_tcs <= DPNI_MAX_TX_TC);
	for (i = 0; i < dpni->max_tx_tcs + 1; i++) {
		struct dpni_snic_fqid_info *fqid_info;
		struct dpni_snic_lfqid_info *lfqid_info;

		if (i < dpni->max_tx_tcs) {
			fqid_info = &dpni->snic.egr_pre_aiop[i];
			lfqid_info = &dpni->snic.egr_post_aiop[i];
		} else {
			fqid_info = &dpni->snic.ing_pre_aiop;
			lfqid_info = &dpni->snic.ing_post_aiop;
		}

		fqid_info->qprid = res_arr[i];
		lfqid_info->qprid = res_arr[i + (dpni->max_tx_tcs + 1)];
	}

	/* FQIDs */
	if ((err = allocate_resource(dpni->device, "fq",
					(uint32_t)(dpni->max_tx_tcs + 1), 1, 0,
					res_arr, "FQIDs"))
		!= 0)
		return err;

	for (i = 0; i < dpni->max_tx_tcs + 1; i++) {
		struct dpni_snic_fqid_info *fqid_info;

		if (i < dpni->max_tx_tcs)
			fqid_info = &dpni->snic.egr_pre_aiop[i];
		else
			fqid_info = &dpni->snic.ing_pre_aiop;

		fqid_info->fqid = res_arr[i];
	}

	snprintf(type, sizeof(type), "ep.aiop%d", 0);
	if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
					&dpni->snic.epid, "EPID"))
		!= 0)
		return err;

	snprintf(type, sizeof(type), "sp.aiop%d", 0);
	if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
					&dpni->snic.spid, "SPID"))
		!= 0)
		return err;

	return 0;
}

int snic_resources_deallocation(struct dpni *dpni)
{
	int err = 0;

	snic_deallocate_and_drain_bp(dpni);

	return err;
}

int snic_resources_authorization(struct dpni *dpni)
{
	struct qbman_swp *sw_portal = NULL;
	int i, err;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	/* QDID */
	if ((err = resource_authorization(
		sw_portal, dpni->snic.mc_amq.bdi, dpni->snic.mc_amq.icid,
		qbman_auth_type_qdid, &dpni->snic.post_aiop_virt_qdid,
		(uint32_t)dpni->snic.post_aiop_qdid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "SNIC-POST-QDID"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	if ((err = resource_authorization(
		sw_portal, dpni->snic.mc_amq.bdi, dpni->snic.mc_amq.icid,
		qbman_auth_type_qdid, &dpni->snic.pre_aiop_virt_qdid,
		(uint32_t)dpni->snic.pre_aiop_qdid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "SNIC-PRE-QDID"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	for (i = 0; i < dpni->max_tx_tcs; i++)
		if ((err = resource_authorization(
			sw_portal, dpni->snic.mc_amq.bdi,
			dpni->snic.mc_amq.icid, qbman_auth_type_fqid,
			&dpni->snic.egr_pre_aiop[i].virt_fqid,
			(uint32_t)dpni->snic.egr_pre_aiop[i].fqid,
			(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
			"SNIC-EGR-PRE-AIOP-Q"))
			!= 0) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			return err;
		}

	if ((err = resource_authorization(
		sw_portal, dpni->snic.mc_amq.bdi, dpni->snic.mc_amq.icid,
		qbman_auth_type_fqid, &dpni->snic.ing_pre_aiop.virt_fqid,
		(uint32_t)dpni->snic.ing_pre_aiop.fqid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "SNIC-ING-PRE-AIOP-Q"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	if ((err = resource_authorization(
		sw_portal, dpni->snic.mc_amq.bdi, dpni->snic.mc_amq.icid,
		qbman_auth_type_bpid, &dpni->snic.peb_virt_bpid,
		(uint32_t)dpni->snic.peb_bpid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "SNIC-BPID"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	if ((err = resource_authorization(
		sw_portal, dpni->snic.mc_amq.bdi, dpni->snic.mc_amq.icid,
		qbman_auth_type_bpid, &dpni->snic.ddr_virt_bpid,
		(uint32_t)dpni->snic.ddr_bpid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "SNIC-BPID"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return 0;
}

int snic_resources_deauthorization(struct dpni *dpni)
{
	struct qbman_swp *sw_portal = NULL;
	int i, err;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	/* QDID */
	if ((err = resource_deauthorization(
		sw_portal, dpni->snic.mc_amq.bdi, dpni->snic.mc_amq.icid,
		qbman_auth_type_qdid, dpni->snic.post_aiop_virt_qdid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "SNIC-POST-QDID"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	if ((err = resource_deauthorization(
		sw_portal, dpni->snic.mc_amq.bdi, dpni->snic.mc_amq.icid,
		qbman_auth_type_qdid, dpni->snic.pre_aiop_virt_qdid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "SNIC-PRE-QDID"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	for (i = 0; i < dpni->max_tx_tcs; i++)
		if ((err = resource_deauthorization(
			sw_portal, dpni->snic.mc_amq.bdi,
			dpni->snic.mc_amq.icid, qbman_auth_type_fqid,
			dpni->snic.egr_pre_aiop[i].virt_fqid,
			(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
			"SNIC-EGR-PRE-AIOP-Q"))
			!= 0) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			return err;
		}

	if ((err = resource_deauthorization(
		sw_portal, dpni->snic.mc_amq.bdi, dpni->snic.mc_amq.icid,
		qbman_auth_type_fqid, dpni->snic.ing_pre_aiop.virt_fqid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "SNIC-ING-PRE-AIOP-Q"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	if ((err = resource_deauthorization(
		sw_portal, dpni->snic.mc_amq.bdi, dpni->snic.mc_amq.icid,
		qbman_auth_type_bpid, dpni->snic.peb_virt_bpid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "SNIC-BPID"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	if ((err = resource_deauthorization(
		sw_portal, dpni->snic.mc_amq.bdi, dpni->snic.mc_amq.icid,
		qbman_auth_type_bpid, dpni->snic.ddr_virt_bpid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "SNIC-BPID"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return 0;
}

int snic_config_qbman(struct dpni *dpni)
{
	int err;

	err = snic_config_tx_qbman(dpni);
	if (err != 0) {
		pr_err("ID[%d]: snic_config_tx_qbman failed\n", dpni->id);
		return err;
	}

	err = snic_config_rx_qbman(dpni);
	if (err != 0) {
		pr_err("ID[%d]: snic_config_rx_qbman failed\n", dpni->id);
		return err;
	}

	return 0;
}

void snic_reset(struct dpni *dpni)
{
	/* If not configured nothing to do right now */
	if (!dpni->snic.configured)
		return;

	if (dpni->options & DPNI_OPT_IPF)
		snic_set_mtu(dpni, dpni->snic.dpni_index, dpni->snic.mtu);

	if (dpni->options & DPNI_OPT_IPSEC)
		dpni_ipsec_flush(dpni);

	snic_set_enable_flags(dpni, dpni->snic.dpni_index,
				dpni->snic.vlan_insert, dpni->snic.vlan_remove,
				dpni->snic.ipr, dpni->snic.ipf,
				dpni->snic.ipsec);

}

void snic_destroy(struct dpni *dpni)
{
	snic_clear_tx_side(dpni);

	snic_clear_rx_side(dpni);

	if (!dpni->snic.configured)
		return;

	if (dpni->options & DPNI_OPT_IPR)
		snic_ipr_delete_instance(dpni, dpni->snic.dpni_index);

	if (dpni->options & DPNI_OPT_IPSEC) {
		dpni_ipsec_flush(dpni);
		snic_ipsec_delete_instance(dpni, dpni->snic.dpni_index);
	}

	snic_unregister(dpni, dpni->snic.dpni_index);

	snic_cmdif_close(dpni);
}

/* External-API */
int dpni_set_mtu(struct dpni *dpni, uint16_t mtu)
{
	if (!(dpni->options & DPNI_OPT_IPF)) {
		pr_err("IPF wasn't chosen as "
		"part of the general options mask\n");
		return -EACCES;
	}

	dpni->snic.mtu = mtu;
	if (dpni->snic.configured)
		snic_set_mtu(dpni, dpni->snic.dpni_index, dpni->snic.mtu);

	return 0;
}

int dpni_get_mtu(struct dpni *dpni, uint16_t *mtu)
{
	*mtu = dpni->snic.mtu;

	return 0;
}

int dpni_set_vlan_insertion(struct dpni *dpni, int en)
{
	if (!(dpni->options & DPNI_OPT_VLAN_MANIPULATION)) {
		pr_err("VLAN_MANIPULATION wasn't chosen as "
		"part of the general options mask\n");
		return -EACCES;
	}

	dpni->snic.vlan_insert = en;
	if (dpni->snic.configured)
		snic_set_enable_flags(dpni, dpni->snic.dpni_index,
					dpni->snic.vlan_insert,
					dpni->snic.vlan_remove, dpni->snic.ipr,
					dpni->snic.ipf, dpni->snic.ipsec);

	return 0;
}

int dpni_set_vlan_removal(struct dpni *dpni, int en)
{
	if (!(dpni->options & DPNI_OPT_VLAN_MANIPULATION)) {
		pr_err("VLAN_MANIPULATION wasn't chosen as "
		"part of the general options mask\n");
		return -EACCES;
	}

	dpni->snic.vlan_remove = en;
	if (dpni->snic.configured)
		snic_set_enable_flags(dpni, dpni->snic.dpni_index,
					dpni->snic.vlan_insert,
					dpni->snic.vlan_remove, dpni->snic.ipr,
					dpni->snic.ipf, dpni->snic.ipsec);

	return 0;
}

int dpni_set_ipr(struct dpni *dpni, int en)
{
	if (!(dpni->options & DPNI_OPT_IPR)) {
		pr_err("IPR wasn't chosen as "
		"part of the general options mask\n");
		return -EACCES;
	}

	if (en) {
		if (!dpni->l3_chksum_valid) {
			pr_err("ID[%d]: cannot enabled IPR if L3 checksum "
			"validation is disabled\n", dpni->id);
			return -EINVAL;
		}
		if (!dpni->l4_chksum_valid) {
			pr_err("ID[%d]: cannot enabled IPR if L4 checksum "
			"validation is disabled\n", dpni->id);
			return -EINVAL;
		}
	}

	dpni->snic.ipr = en;
	if (dpni->snic.configured)
		snic_set_enable_flags(dpni, dpni->snic.dpni_index,
					dpni->snic.vlan_insert,
					dpni->snic.vlan_remove, dpni->snic.ipr,
					dpni->snic.ipf, dpni->snic.ipsec);

	return 0;
}

int dpni_set_ipf(struct dpni *dpni, int en)
{
	if (!(dpni->options & DPNI_OPT_IPF)) {
		pr_err("IPF wasn't chosen as "
		"part of the general options mask\n");
		return -EACCES;
	}

	dpni->snic.ipf = en;
	if (dpni->snic.configured)
		snic_set_enable_flags(dpni, dpni->snic.dpni_index,
					dpni->snic.vlan_insert,
					dpni->snic.vlan_remove, dpni->snic.ipr,
					dpni->snic.ipf, dpni->snic.ipsec);

	return 0;
}

int dpni_set_ipsec(struct dpni *dpni, int en)
{
	if (!(dpni->options & DPNI_OPT_IPSEC)) {
		pr_err("IPSEC wasn't chosen as "
		"part of the general options mask\n");
		return -EACCES;
	}

	if (en) {
		if (!dpni->l3_chksum_valid) {
			pr_err("ID[%d]: cannot enabled IPSEC if L3 checksum "
			"validation is disabled\n", dpni->id);
			return -EINVAL;
		}
		if (!dpni->l4_chksum_valid) {
			pr_err("ID[%d]: cannot enabled IPSEC if L4 checksum "
			"validation is disabled\n", dpni->id);
			return -EINVAL;
		}
	}

	dpni->snic.ipsec = en;
	if (dpni->snic.configured)
		snic_set_enable_flags(dpni, dpni->snic.dpni_index,
					dpni->snic.vlan_insert,
					dpni->snic.vlan_remove, dpni->snic.ipr,
					dpni->snic.ipf, dpni->snic.ipsec);

	return 0;
}

/* used by dpni_drv only */
int dpni_get_sa_tmp_buffer(struct dpni *dpni,
	uint32_t tmp_buff_size,
	void **buf,
	uint8_t *sa_id)
{
	int err;

	err = snic_ipsec_get_sa(dpni, sa_id);
	if (err)
		return err;

	if (tmp_buff_size) {
		dpni->snic.ipsec_info.sa_array[*sa_id].tmp_buf = fsl_malloc(
			tmp_buff_size);

		if (dpni->snic.ipsec_info.sa_array[*sa_id].tmp_buf == NULL) {
			pr_err("No memory for dpni\n");
			return -ENOMEM;
		}
		*buf = dpni->snic.ipsec_info.sa_array[*sa_id].tmp_buf;
	}

	return 0;
}

int dpni_ipsec_add_sa(struct dpni *dpni,
	struct dpni_ipsec_sa_cfg *cfg,
	uint8_t sa_id)
{
	int err;

	if (!(dpni->options & DPNI_OPT_IPSEC)) {
		pr_err("DPNI_OPT_IPSEC wasn't chosen as "
		"part of the general options mask\n");
		return -EACCES;
	}

	err = snic_ipsec_config_sa(dpni, cfg, sa_id);
	if (err)
		return err;

	if (dpni->snic.configured)
		snic_ipsec_add_sa(dpni, sa_id);

	return 0;
}

int dpni_ipsec_remove_sa(struct dpni *dpni, uint8_t sa_id)
{
	int err;

	if (!(dpni->options & DPNI_OPT_IPSEC)) {
		pr_err("DPNI_OPT_IPSEC wasn't chosen as "
		"part of the general options mask\n");
		return -EACCES;
	}

	err = snic_ipsec_rmv_sa(dpni, sa_id);
	ASSERT_COND(err == 0);

	return 0;
}

int dpni_ipsec_flush(struct dpni *dpni)
{
	struct sa_info *sa_info;
	uint8_t i;
	int err;

	if (!(dpni->options & DPNI_OPT_IPSEC)) {
		pr_err("DPNI_OPT_IPSEC wasn't chosen as "
		"part of the general options mask\n");
		return -EACCES;
	}

	for (i = 0; i < DPNI_MAX_SAS; i++) {
		sa_info = &dpni->snic.ipsec_info.sa_array[i];

		if ((sa_info->registered) && (sa_info->added)) {
			err = snic_ipsec_rmv_sa(dpni, i);
			if (err)
				return err;
		} else {
			sa_info->registered = 0;
			sa_info->added = 0;
		}
	}

	return 0;
}

int dpni_ipsec_sa_get_stats(struct dpni *dpni,
	uint8_t sa_id,
	uint64_t *kbytes,
	uint64_t *packets,
	uint32_t *sec)
{
	int err;

	if (!(dpni->options & DPNI_OPT_IPSEC)) {
		pr_err("DPNI_OPT_IPSEC wasn't chosen as "
		"part of the general options mask\n");
		return -EACCES;
	}

	err = snic_ipsec_sa_get_stats(dpni, sa_id, kbytes, packets, sec);
	ASSERT_COND(err == 0);

	return 0;
}
