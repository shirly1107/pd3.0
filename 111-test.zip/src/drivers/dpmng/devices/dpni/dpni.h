/*
 * Copyright 2013-2021 NXP
 */

/******************************************************************************
 @File          dpni.h

 @Description   DPNI internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPNI_H
#define __DPNI_H

#include "kernel/fsl_spinlock.h"
#include "fsl_cmdif_client.h"
#include "fsl_eiop_ifp.h"
#include "fsl_eiop.h"
#include "fsl_dpni_mc.h"
#include "fsl_dpparser.h"
#include "fsl_dpkg.h"
#include "fsl_dptbl.h"
#include "fsl_dppolicy.h"
#include "fsl_dpdmux_mc.h"
#include "fsl_event_pipe.h"
#include "fsl_dpaiop_mc.h"
#include "fsl_opr.h"
#include "dpparser.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPNI

/* Defaults */
#define DPNI_DEFAULT_KEY_SIZE		24
#define DPNI_DEFAULT_MAX_FRAME_LENGTH	1536
#define DPNI_DEFAULT_MAX_TRANSMIT_UNIT	1500
#define DPNI_DEFAULT_WBFS_GROUP_PRIO 7
#define DPNI_DEFAULT_WBFS_GROUP_SIZE 4
#define DPNI_DEFAULT_SCHED_WEIGHT	100

/* Max values */
#define DPNI_MAX_SENDERS		2 * SOC_NUM_OF_CORES
/**< Maximum number of senders */
#define DPNI_MAX_DIST_SIZE		DPNI_MAX_SENDERS
/* Maximum number of CG per DPNI */
#define DPNI_MAX_CG				SOC_NUM_OF_CORES * DPNI_MAX_RX_TC
/**< Maximum dist size */
#define DPNI_MAX_FS_ENTRIES		1024
/**< Maximum dist entries */
#define DPNI_MAX_KEY_SIZE		56
/**< Maximum key size for the QoS and distribution */

#define DPNI_MAX_UNICAST_FILTERS		16
/*!< Maximum number of unicast filters */
#define DPNI_MAX_MULTICAST_FILTERS		64
/*!< Maximum number of multicast filters */

#define DPNI_MAX_MAC_FILTERS			(DPNI_MAX_UNICAST_FILTERS + DPNI_MAX_MULTICAST_FILTERS)

#define DPNI_MAX_VLAN_FILTERS			16
/*!< Maximum number of VLAN filters */
#define DPNI_MAX_QOS_ENTRIES			64
/*!< Maximum number of QoS entries */
#define DPNI_MAX_SAS				32

/*!< Maximum number of OPR(order point record) */
#define DPNI_MAX_OPR		SOC_NUM_OF_CORES * DPNI_MAX_RX_TC

#define DPNI_OPT_RSC				0x00002000
/*!< RSC support */
#define DPNI_OPT_GSO				0x00004000
/*!< GSO support */
#define DPNI_OPT_MACSEC				0x00008000
/*!< MACSEC support */

#define DPNI_MAX_FS_REDIRECT_ENTRIES	64

#define DPNI_POLICY_PRI_BROADCAST	0
#define DPNI_POLICY_PRI_MULTICAST	1
#define DPNI_POLICY_PRI_UNICAST		2
#define DPNI_POLICY_NUM_RULES		3

#define DPNI_MAX_TD_THRESHOLD		0xE0000000
#define DPNI_MAX_WRED_THRESHOLD 	(1ULL << 39)

/* POLICING */
#define DPNI_POLICING_GREEN_IDX		0
#define DPNI_POLICING_YELLOW_IDX	1
#define DPNI_POLICING_RED_IDX		2

/* SNIC */
#define DPNI_SNIC_EGRESS		0x0
#define DPNI_SNIC_INGRESS		0x1
#define DPNI_SNIC_PEB_NUM_OF_BUFFERS	100
#define DPNI_SNIC_PEB_BUFFER_SIZE	256
#define DPNI_SNIC_BUFFER_ALIGN	256
#define DPNI_SNIC_DDR_NUM_OF_BUFFERS	100
#define DPNI_SNIC_DDR_BUFFER_SIZE	2048
#define DPNI_SNIC_MAX_MFL		IFP_MAX_FRAME_LENGTH

#define DPNI_RX_BASE_QPRI		8
#define DPNI_TX_BASE_CQ			8

#define DPNI_ID_IN_USE			0x80000000

#define DPNI_INVALID_ID			(-1)

#define QDID_INVALID_ID			((uint32_t)-1)

#define DPNI_OPTIONS_NOT_SUPPORTED \
	( \
		DPNI_OPT_MACSEC | \
		DPNI_OPT_RSC | \
		DPNI_OPT_GSO \
		)

#define DPNI_SNIC_OPTIONS_SUPPORTED \
	( \
		DPNI_OPT_VLAN_MANIPULATION | \
		DPNI_OPT_IPR | \
		DPNI_OPT_IPF |\
		DPNI_OPT_IPSEC \
		)

#define DPNI_ERRORS_TO_DISCARD		(EIOP_IFP_ERR_KS | 		\
					EIOP_IFP_ERR_MNL | 		\
					EIOP_IFP_ERR_TID | 		\
					EIOP_IFP_ERR_PIE | 		\
					EIOP_IFP_ERR_PARSER_CL| 	\
					EIOP_IFP_ERR_PARSER_ISF | 	\
					EIOP_IFP_ERR_PARSER_BL)

#define EIOP_ASSERT_COND(err) \
{ \
	ASSERT_COND(!err || (err == -ETIMEDOUT)); \
	err = 0; \
} while (0)

enum dpni_type {
	DPNI_TYPE_NI = 1, /*!< DPNI of type NI */
	DPNI_TYPE_NIC
/*!< DPNI of type NIC */
};

typedef void (rx_tc_dist_cb)(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *tc_cfg);

struct dpni_fs_redirect_table_entry {
	int			valid;
	uint16_t	token;
	int 		obj_id;
	uint16_t	flow_id;
	uint16_t	options;
};

/* The FS rule is redirecting the frame to another dpni object */
struct dpni_fs_redirect {
	int valid;			/* entry is valid - this rule redirects to another dpni */
	uint16_t token;		/* token used to redirect */
	int obj_id;			/* object id to redirect */
	struct dpni_fs_redirect_table_entry *remote_entry;	/* data entry located into
					dpni target. Stored here to be updated when this dpni operates
					on the rule. Targer dpni will use this information to update
					the rule if it is closed or reset*/
};

struct dpni_table_rule {
	char in_use;
	char is_last;
	char custom_flc;
	char flow_id_rule;
	union {
		uint8_t mac_addr[6];
		uint8_t vlan_key[3]; /* [0] - vlan exist, [1-2] - vlan-id */
		struct {
			int maskable;
			uint8_t key[DPNI_MAX_KEY_SIZE];
			uint8_t mask[DPNI_MAX_KEY_SIZE];
			uint16_t priority;
			uint8_t size;
			int qos_priority;
		} key_cfg;
	} rule;
	struct dpni_rule_cfg key_params;
	struct dptbl_action action;
	struct dpni_fs_redirect redirect;
};

typedef int (rule_match_cb)(void *user_rule,
	struct dpni_table_rule *table_rule);
typedef void (dptbl_rule_create_cb)(struct dpni_table_rule *table_rule,
	struct dptbl_rule *rule);
typedef void (remove_mac_vlan_dpdmux_cb)(struct dpni *dpni,
	struct dpni_table_rule *table_rule);
typedef void (post_remove_cb)(struct dpni *dpni,
	struct dpni_table_rule *table_rule);

typedef void (cgr_fill_cb)(void *cfg, struct qbman_attr *cgr_desc, int clear);

typedef void (cgr_reset_counters_cb)(struct qbman_swp *swp,
	int cgid,
	int is_ccgid,
	uint32_t ceetmid,
	uint8_t cchannelid);

struct dpni_cgr_cfg {
	int cgid;
	int *cgid_index;
	int is_ccgid;
	int free_cgid;
	uint32_t ceetmid;
	uint8_t cchannelid;
	void *cfg;
	cgr_fill_cb *fill_cb;
	cgr_reset_counters_cb *reset_cb;
	int16_t oal;
};

struct dpni_pools_int_cfg {
	uint8_t num_dpbp;
	uint8_t pool_as;
	struct {
		struct dpbp *dpbp;
		uint16_t buffer_size;
		uint8_t priority;
	} pools[DPNI_MAX_DPBP];
};

struct dpni_rx_queue_info {
	int fqid;
	uint32_t virt_fqid;
	uint64_t user_ctx;
	struct dpni_dest_cfg dest_cfg;
	enum dpni_flc_type flc_type;
	uint64_t flc_opaque;
	int cgid_en;
	int cgid_index;
	int order_preservation_en;
	uint32_t tail_drop_threshold;
	int16_t oal;
	int opr_id;

	int retire_pending;
	struct qbman_result *retire_storage;
	int always_stash;
};

struct dpni_tx_conf_info {
	int only_error_frames;
	struct dpni_rx_queue_info queue_info;

	int notification_enable;
	struct dpni_congestion_notification_cfg cg_notify;
};

struct retire_storage_data {
	int retire_pending;
	uint8_t *data;
};

struct dpni_sender_info {
	int valid;
	int private_tx_conf_err_queue;
	struct dpni_tx_conf_info tx_conf_err;
	int l3_chksum_gen;
	int l4_chksum_gen;
	struct eiop_fcead fcead; /* conf-fqid should be written here*/
	int dctidx;
};

struct dpni_tc_tx_info {
	int qprid;
	int cqid;
	uint8_t cq_index;
	int ccgid;
	uint32_t virtual_cgid;
	int lfqidx_base;

	int early_drop_enable;
	int notification_enable;
	struct dpni_congestion_notification_cfg cg_notify;
	struct dpni_early_drop_cfg cg_early_drop;
	uint32_t virtual_lfq[DPNI_MAX_DIST_SIZE];
};


#define DPNI_FS_DROP		((uint16_t)-1)
struct dpni_rx_dist_config {
	int fs_enable;			// flow steering enabled
	struct dpkg_profile_cfg fs_dist_key;
	uint16_t fs_dist_size;
	int fs_key_available;

	int hash_enable;		// hash enabled
	struct dpkg_profile_cfg hash_dist_key;
	uint16_t hash_dist_size;
	int hash_key_available;

	uint16_t default_queue;	// default queue used in flow steering if hash is disabled
};

struct dpni_tc_rx_info {
	int valid;
	int virt_dist;
	uint8_t qos_owners;
	uint16_t max_dist_size;
	uint16_t dist_size;
	uint16_t num_fs_entries;
	uint16_t max_fs_entries;
	uint16_t max_dist_key_size;
	enum dpni_dist_mode dist_mode;
	uint8_t kid_hash;
	uint8_t kid_fs;
	struct dpkg_profile_cfg dist_extract_cfg;
	struct dptbl_action default_action;
	struct dpni_table_rule keys[DPNI_MAX_FS_ENTRIES];
	struct dptbl *fs_tbl;
	struct dptbl_action miss_action;
	struct dptbl_action action;
	int fs_tbl_is_valid;

	int qprid;
	int fqid_base;
	int cgid_index;
	int plcrid;
	int policer_enable;
	struct dppolicer_profile_cfg policer;

	struct dpni_rx_queue_info rx_queues[DPNI_MAX_DIST_SIZE];

	struct dpni_rx_dist_config dist_cfg;
	struct dpni_fs_tbl_cfg fs_cfg;

};

struct dpni_qos {
	int valid;
	uint8_t max_qos_entries;
	uint8_t num_qos_entries;
	uint16_t max_qos_key_size;
	uint16_t actual_qos_key_size;
	struct dpni_table_rule keys[DPNI_MAX_QOS_ENTRIES];
	int kid;
	struct dptbl *tbl;
	struct dptbl_action default_action;
	struct dptbl_action miss_action;
	uint8_t default_tc;
	struct dpkg_profile_cfg qos_key_cfg;
	/*!< Used in case of no-match and 'discard_on_miss'= 0 */
	uint8_t tbl_default_tc;
};

struct dpni_filters {
	uint8_t max_vlan_filters;
	uint8_t num_vlan_filters;
	int vlan_enable;
	int mac_kid;
	int vlan_kid;
	struct dptbl *mac_tbl;
	struct dptbl *fc_multicast_tbl;	// flow control multicast table
	union {
		struct {
			uint8_t max_unicast_filters;
			uint8_t num_unicast_filters;
			uint8_t max_multicast_filters;
			uint8_t num_multicast_filters;
		};
		struct {
			uint8_t max_mac_filters;
			uint8_t num_mac_filters;
		};
	};
	/* single MAC address table for both u-cast and m-cast.  If entries are
	 * reserved for one or the other, first entries are u-cast.
	 */
	struct dpni_table_rule mac_addrs[DPNI_MAX_MAC_FILTERS];

	struct dptbl *vlan_tbl;
	struct dpni_table_rule vlans[DPNI_MAX_VLAN_FILTERS];

	struct dptbl_action mac_allow_action;
	struct dptbl_action multicast_allow_action;	// used in multicast filter table to allow frames to pass
	struct dptbl_action tbl_deny_action;		// store action settings used for discard
	struct dptbl_action vlan_allow_action;
	struct dptbl_action vlan_disallow_action;
};

struct dpni_ifp_info {
	int next_ifpid;
	struct eiop_ifp_desc ifp_desc;
	struct eiop_ifp_cfg init;
};

struct dpni_snic_lfqid_info {
	int qprid;
	int dctidx;
	int cqid;
	uint8_t cq_index;
	int ccgid;
	int lfqidx;
	struct eiop_fcead fcead; /* IFPID should be written here*/
};

struct dpni_snic_fqid_info {
	int qprid;
	int fqid;
	uint32_t virt_fqid;
	uint64_t ctx;
	int retire_pending;
	struct qbman_result *retire_storage;
};

struct sa_info {
	uint8_t registered;
	uint8_t added;
	struct dpni_ipsec_sa_cfg cfg;
	void *tmp_buf;
};

struct ipsec_info {
	struct dpni_ipsec_cfg cfg;
	uint16_t options;
	struct sa_info sa_array[DPNI_MAX_SAS];
};

struct dpni_snic {
	int epid;
	int spid;
	uint16_t dpni_index;
	struct dpni_ifp_info *ingress_ifp_info; /* SNIC ingress direction to AIOP */
	struct dpni_ifp_info *egress_ifp_info; /* SNIC egress direction to AIOP */
	// int start_kid;
	int peb_bpid;
	uint32_t peb_virt_bpid;
	phys_addr_t peb_mem_paddr;
	int ddr_bpid;
	uint32_t ddr_virt_bpid;
	phys_addr_t ddr_mem_paddr;
	int ceetm_chid;
	uint8_t cq_slider;
	int pre_aiop_qdid;
	uint32_t pre_aiop_virt_qdid;
	int post_aiop_qdid;
	uint32_t post_aiop_virt_qdid;
	int hash_kid;
	struct dpmng_amq mc_amq;
	struct dpni_snic_fqid_info ing_pre_aiop;
	struct dpni_snic_lfqid_info ing_post_aiop;
	struct dpni_snic_fqid_info egr_pre_aiop[DPNI_MAX_TX_TC];
	struct dpni_snic_lfqid_info egr_post_aiop[DPNI_MAX_TX_TC];
	struct dpni_ipr_cfg ipr_cfg;
	struct ipsec_info ipsec_info;
	int pass_fas;
	uint16_t mtu;
	int vlan_insert;
	int vlan_remove;
	int ipr;
	int ipf;
	int ipsec;

	int configured;

	/* CMDIF */
	void *command_buffer;
	struct cmdif_desc cidesc;
};

struct dpni_congestion_group
{
	int cgid;
	uint32_t virtual_cgid;
	int in_use;
	int early_drop_enable;
	int notification_enable;
	uint32_t tail_drop_threshold;
	int16_t oal;
	struct dpni_congestion_notification_cfg cg_notify;
	struct dpni_early_drop_cfg cg_early_drop;
};

struct dpni_opr_info
{
	uint16_t opr_id;
	struct opr_info opr;
};

struct dpni_restore_info
{
	int en;
	int init_done;
	int ingress_ifp_en;
	int mac_in_loopback;
};

#define DPNI_LINKRES_CONNECTION_ALLOCATED	0x00000001ul
#define DPNI_LINKRES_AP_CONNECTED			0x00000002ul
#define DPNI_LINKRES_ALLOC_BW				0x00000004ul
#define DPNI_LINKRES_CHANNEL_ALLOCATED		0x00000008ul
#define DPNI_LINKRES_LFQ_ALLOCATED			0x00000010ul

#define DPNI_LINKRES_CONNECTED				0x80000000ul

struct dpni_tx_channel_data {
	struct dpmng_accesspoint ap;
	int lfq_authorized;

	int tx_qdid;
	uint32_t tx_virt_qdid;

	struct dpni_tx_shaping_cfg tx_cr_shaper;
	struct dpni_tx_shaping_cfg tx_er_shaper;
	int shaper_coupling;

	struct dpni_tx_priorities tx_selection;

	struct dpni_sender_info sender_info[DPNI_MAX_SENDERS];
	struct dpni_tc_tx_info tc_tx[DPNI_MAX_TX_TC];
};

struct dpni {
	/* parameters for run-time (in order to be in cache) */
	int id;
	enum dpni_type type;
	struct dpmng_dev_ctx dev_ctx;
	/* State machine flags */
	int enabled;
	int self_link_down_finished;
	int authorized;

	/* Tx channel data - dpni allocates one structure for each channel */
	struct dpni_tx_channel_data *tx_ch;

	spinlock_t lock;
	uint32_t options;
	uint8_t mac_addr[6];
	uint8_t max_senders;
	uint8_t max_rx_tcs;
	uint8_t max_tx_tcs;
	uint8_t max_policers;
	int policer_ids[DPNI_MAX_RX_TC];
	uint8_t max_congestion_ctrl;
	uint16_t max_opr;
	uint8_t shared_congestion;
	struct dpni_opr_info opr[DPNI_MAX_OPR];
	struct dpni_congestion_group rx_tx_conf_cgids[DPNI_MAX_CG + 1];
	struct dpni_tc_rx_info tc_rx[DPNI_MAX_RX_TC];
	struct dpni_qos qos;
	struct dpni_filters filters;
	struct dpni_pools_int_cfg pools_cfg;
	struct dpni_pools_int_cfg backup_pools_cfg;
	struct dpni_restore_info restore;
	int rx_qdid;
	uint32_t rx_virt_qdid;
	int void_qprid;
	struct dpni_rx_queue_info rx_err;
	struct dpni_tx_conf_info tx_conf_err;
	/* In case of no-tx-conf this is only tx-err; otherwise, and also no
	 * private tx-conf, this is used for both tx-conf and tx-err */
	int tx_conf_disable;
	struct dpni_ifp_info *mem_ifp_info;
	char l3_chksum_valid;
	char l4_chksum_valid;
	char l3_chksum_gen;
	char l4_chksum_gen;
	int multicast_promisc_en;
	int unicast_promisc_en;
	uint16_t mfl;

	int conn_id;
	int ap_valid;
	struct dpni_link_cfg link_cfg;

	struct dpni_tx_shaping_cfg tx_lni_cr_shaper;
	struct dpni_tx_shaping_cfg tx_lni_er_shaper;
	int lni_shaper_oal;
	int lni_shaper_coupling;
	int lni_configured;

	int eiop_id;
	uint32_t ceetmid;
	uint8_t cq_slider;

	int policy_id;
	struct dppolicy *policy;
	int ing_parser_id;
	uint8_t ing_sp_prof[MAX_SP_PROFILE_ID_SIZE];
	int is_ing_parser_id_allocated;
	int egr_parser_id;
	uint8_t egr_sp_prof[MAX_SP_PROFILE_ID_SIZE];
	int is_egr_parser_id_allocated;
	uint16_t ing_start_hxs;
	uint16_t egr_start_hxs;
	struct dptbl_action dummy_action;
	struct dptbl_rule dummy_rule;
	uint8_t dummy_key;

	int is_snic;
	struct dpni_snic snic;

	struct mc_irq irqs[DPNI_MAX_IRQ_NUM];

	/* AIOP Only */
	int epid;
	int spid;
	int backup_spid;

	struct device *device;
	struct dpkg *ing_dpkg;
	struct dpparser *ing_dpparser;
	struct dpparser *egr_dpparser;
	struct dppolicer *ing_dppolicer;
	struct dptbl_mng *ing_dptbl;
	struct dppolicy_mng *ing_dppolicy;
	struct linkman *linkman;
	struct dpmng *dpmng;
	struct dpmac *dpmac;
	struct dpni *dpni; // connected dpni object
	struct aiop_tile *aiop_tile;
	struct dpdmux *dpdmux;
	uint16_t dpdmux_if_id;
	enum dpdmux_method dpdmux_method;

	/* buffers used for queue retire */
	struct retire_storage_data queue_retire_data;

	int is_fs_backward_comp;

	/* default PFDR Pool Select */
	int default_pps;

	/* cscn priority mask written on eiop */
	uint8_t congestion_pfc_mask[DPNI_MAX_RX_TC];
	int flow_control_enabled;
	uint8_t single_sender;

	int fc_idx;

	uint32_t link_res_flags; /* keep track of the resources allocated during
								connection procedure. Used to deallocate
								resources when an error appeared while connecting */

	struct dpni_single_step_cfg single_step_cfg;

	/* keep track of the dpni objects that redirect frames here */
	struct dpni_fs_redirect_table_entry fs_redirect_table[DPNI_MAX_FS_REDIRECT_ENTRIES];

	int num_ceetm_ch;	/* number of CEETM channels */

	int en_header_stashing;
	int en_payload_stashing;
};

struct map_mc_to_aiop {
	uint32_t mc;
	uint32_t aiop;
};

/* Inter-module API */
void snic_set_defaults(struct dpni *dpni, int reset);
int snic_resources_allocation(struct dpni *dpni);
int snic_ceetm_resources_allocation(struct dpni *dpni);
int snic_ceetm_resources_deallocation(struct dpni *dpni);
int snic_resources_deallocation(struct dpni *dpni);
int snic_configuration(struct dpni *dpni);
int snic_ceetm_configuration(struct dpni *dpni);
int snic_initial_configuration(struct dpni *dpni);
int snic_resources_authorization(struct dpni *dpni);
int snic_resources_deauthorization(struct dpni *dpni);
int snic_config_qbman(struct dpni *dpni);
void snic_reset(struct dpni *dpni);
void snic_destroy(struct dpni *dpni);

void set_accesspoint_to_lni(struct dpni *dpni,
	struct dpmng_accesspoint *ap,
	int shaped);

int dpni_reset_statistics(struct dpni *dpni);

#endif /* __DPNI_H */
