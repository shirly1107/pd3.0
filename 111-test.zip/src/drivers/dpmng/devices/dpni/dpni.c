/*
 * Copyright 2013-2021 NXP
 */

/**************************************************************************//*
 @File          dpni.c

 @Description   library implementation

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "drivers/fsl_aiop.h"
#include "fsl_qbman.h"
#include "fsl_event_pipe.h"
#include "fsl_aiop_common.h"

#include "fsl_dpmng_mc.h"
#include "cmdif_srv.h"
#include "fsl_dpcon_mc.h"
#include "fsl_dpio_mc.h"
#include "fsl_dpbp_mc.h"
#include "fsl_dpmac_mc.h"
#include "fsl_dpsw_mc.h"
#include "fsl_ceetm_if.h"
#include "fsl_dpdmux_mc.h"
#include "fsl_timer.h"
#include "eiop_ifp.h"
#include "flow_control.h"

#include "dpni.h"
#include "device.h"

//#define DPNI_DUMP_STRUCTURE

#define DPNI_DUMP_SETTINGS		0x01
#define DPNI_DUMP_RESOURCES		0x02

// local flags used in flow control configuration
#define DPNI_ENABLE_FC_SENDING		0x01
#define DPNI_ENABLE_FC_RESPONSE		0x02
#define DPNI_ENABLE_PFC_SENDING		0x04
#define DPNI_ENABLE_PFC_RESPONSE	0x08
#define IS_SHARED_FS_ENABLED ((dpni->options & DPNI_OPT_SHARED_FS) ==  DPNI_OPT_SHARED_FS)
#define SELECT_TC_SHARED_FS(tc_id) (IS_SHARED_FS_ENABLED ? 0 : tc_id)


static void dpni_update_pfc_settings(struct dpni *dpni, uint32_t flags);

static void dpni_dump(struct dpni *dpni, uint8_t flag)
{
	char *buf;
	uint32_t size = 4 * KILOBYTE;
	int count = 0, i;
	int ceetm_ch_idx;

	if (!(((log_levels[LOG_MODULE] != LOG_LEVEL_GLOBAL)
		&& (log_levels[LOG_MODULE] <= LOG_LEVEL_DEBUG))
		|| ((log_levels[LOG_MODULE] == LOG_LEVEL_GLOBAL)
			&& (log_global_level <= LOG_LEVEL_DEBUG))))
		return;

	buf = (char*)fsl_malloc(size);
	if (!buf)
		return;

	SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\nDPNI %d Info:\n", dpni->id);
	if (flag & DPNI_DUMP_SETTINGS) {
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\tType %s\n",
			(dpni->type == DPNI_TYPE_NI) ? "NI" :
			(dpni->is_snic) ? "SNIC" : "NIC");
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\tMAC ADDR: 0x%x:0x%x:0x%x:0x%x:0x%x:0x%x\n",
			dpni->mac_addr[0], dpni->mac_addr[1],
			dpni->mac_addr[2], dpni->mac_addr[3],
			dpni->mac_addr[4], dpni->mac_addr[5]);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\tOptions 0x%08lx\n",
			dpni->options);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\tMax Senders %d\n",
			dpni->max_senders);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\tMax Rx TCs %d:\n",
			dpni->max_rx_tcs);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\tMax Tx TCs %d:\n",
			dpni->max_tx_tcs);
		for (i = 0; i < dpni->max_rx_tcs; i++) {
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\tRX-TC[%d] :\n", i);
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\t\t max-dist-size %d\n",
				dpni->tc_rx[i].max_dist_size);
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\t\t max-fs-entries %d\n",
				dpni->tc_rx[i].max_fs_entries);
			//		dpni->tc_rx[i].max_dist_key_size = cfg->max_dist_key_size;
			//		dpni->tc_rx[i].private_dist_key = cfg->dist_key_variety;
		}
		if (dpni->options & DPNI_OPT_SHARED_MAC_TABLE)
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\tmax mac filters %d\n",
				dpni->filters.max_mac_filters);
		else {
			if (dpni->options & DPNI_OPT_UNICAST_FILTER)
				SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"\tmax unicast filters %d\n",
					dpni->filters.max_unicast_filters);
			if (dpni->options & DPNI_OPT_MULTICAST_FILTER)
				SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"\tmax multicast filters %d\n",
					dpni->filters.max_multicast_filters);
		}
		if (dpni->options & DPNI_OPT_VLAN_FILTER)
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\tmax vlan filters %d\n",
				dpni->filters.max_vlan_filters);
		if (dpni->max_rx_tcs > 1)
		{
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\tmax qos entries %d\n",
				dpni->qos.max_qos_entries);
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"\tmax qos key size %d\n",
					dpni->qos.actual_qos_key_size);
		}
		//	dpni->qos.max_qos_key_size = cfg->max_qos_key_size;
	}

	if (flag & DPNI_DUMP_RESOURCES) {
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"RESOURCES:\n",
			dpni->id);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\tepid %d\n",
			dpni->epid);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\tspid %d\n",
			dpni->spid);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\tbackup_spid %d\n",
			dpni->backup_spid);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\tifpid %d\n",
			dpni->mem_ifp_info->ifp_desc.ifp_id);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\trx_qdid %d\n",
				dpni->rx_qdid);
		for( ceetm_ch_idx  = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"\ttx_qdid[%d] %d\n", ceetm_ch_idx, dpni->tx_ch[ceetm_ch_idx].tx_qdid);
		if (dpni->options & DPNI_OPT_TX_CONF_DISABLED)
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\ttx-err-fqid %d\n",
				dpni->tx_conf_err.queue_info.fqid);
		else
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\ttx-conf-err-fqid %d\n",

		dpni->tx_conf_err.queue_info.fqid);
		SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
			"\trx-err-fqid %d\n",
			dpni->rx_err.fqid);

		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "\tChanel %d\n", ceetm_ch_idx);
			for (i = 0; i < dpni->max_tx_tcs; i++) {
				SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"\t\tTX-TC[%d] :\n", i);
				SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"\t\t\tqprid %d\n", dpni->tx_ch[ceetm_ch_idx].tc_tx[i].qprid);
			}
		}

		for (i = 0; i < dpni->max_rx_tcs; i++) {
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"\tRX-TC[%d] :\n", i);
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"\t\tqprid %d\n",

			dpni->tc_rx[i].qprid);
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"\t\tfqid-base %d, dist %d\n",
					dpni->tc_rx[i].fqid_base,
					dpni->tc_rx[i].max_dist_size);
		}

		if (dpni->max_policers) {
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\tplcrids [");
			for (i = 0; i < dpni->max_policers; i++) {
				SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"%d ",
					dpni->policer_ids[i]);
			}
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "]\n");
		}

		if (dpni->max_congestion_ctrl) {
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
				"\trx-cgids [");
			for (i = 0; i < dpni->max_congestion_ctrl; i++)
				SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
					"%d ",
					dpni->rx_tx_conf_cgids[i].cgid);
			SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error, "]\n");
		}

		if (!(dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED)) {
			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				for (i = 0; i < dpni->max_senders; i++) {
					SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
							"\tTX-SENDER[%d] channel %d:\n",
							i, ceetm_ch_idx);
					SNPRINTF_OR_EXIT(buf, size, count, dpni_dump_error,
							"\t\tconf-fqid %d\n",
							dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err.queue_info.fqid);
				}
			}
		}
	}

dpni_dump_error:
	pr_debug(buf);
	pr_debug("ID[%d]: dump size is %d\n", dpni->id, count);

	fsl_free(buf);
}

static int is_dist_size_supported(uint16_t dist_size)
{
	uint16_t supported_dist[] = { 1, 2, 3, 4, 6, 7, 8, 12, 14, 16, 24, 28,
					32, 48, 56, 64, 96, 112, 128, 192, 224,
					256, 384, 448, 512, 768, 896, 1024 };
	int i, count = ARRAY_SIZE(supported_dist);

	for (i = 0; i < count; i++)
		if (dist_size == supported_dist[i])
			return 1;
	return 0;
}

static int dpni_get_rx_base_qpri(struct dpni *dpni)
{
#ifdef MC_CLI
    if(dpni->options & DPNI_OPT_RX_TX_HW_ECHO)
        return 0;
#endif
    return DPNI_RX_BASE_QPRI;
}

static int dpni_has_opr(struct dpni *dpni) {
	return dpmng_soc_has_orp() && (dpni->options & DPNI_OPT_HAS_OPR);
}

static uint16_t get_valid_dist_size(uint16_t dist_size)
{
	uint16_t supported_dist[] = { 1, 2, 3, 4, 6, 7, 8, 12, 14, 16, 24, 28,
					32, 48, 56, 64, 96, 112, 128, 192, 224,
					256, 384, 448, 512, 768, 896, 1024 };
	int i, count = ARRAY_SIZE(supported_dist);

	if (dist_size == 0)
		return 1;

	for (i = count - 1; i >= 0; i--)
		if (dist_size >= supported_dist[i])
			return supported_dist[i];

	ASSERT_COND(0);

	return 0;
}

static struct opr_info* get_opr_info(struct dpni *dpni, uint8_t tc_id, uint8_t dist) {
	int opr_id = 0;

	opr_id = dpni->tc_rx[tc_id].rx_queues[dist].opr_id;
	if (opr_id == DPNI_INVALID_ID)
		return NULL;
	else
		return &dpni->opr[opr_id].opr;
}

static int assign_opr(struct dpni *dpni, uint8_t tc_id, uint8_t index, uint8_t opr_id) {

	dpni->tc_rx[tc_id].rx_queues[index].opr_id = opr_id;

	return 0;
}

static int remove_opr(struct dpni *dpni, uint8_t opr_id) {
	int tc_id, index;

	for (tc_id = 0; tc_id < dpni->max_rx_tcs; tc_id++)
		for (index = 0; index < dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size; index++)
			if (dpni->tc_rx[tc_id].rx_queues[index].opr_id == opr_id)
				dpni->tc_rx[tc_id].rx_queues[index].opr_id = DPNI_INVALID_ID;

	return 0;
}


static int map_opr(struct dpni *dpni) {
	int i,j;

	for (i = 0; i < dpni->max_rx_tcs; i++)
	{
		for (j = 0; j < dpni->tc_rx[SELECT_TC_SHARED_FS(i)].max_dist_size; j++)
		{
			if (dpni->options & DPNI_OPT_CUSTOM_OPR)
				dpni->tc_rx[i].rx_queues[j].opr_id = DPNI_INVALID_ID;
			else if (dpni->options & DPNI_OPT_OPR_PER_TC)
				dpni->tc_rx[i].rx_queues[j].opr_id = i;
			else
				dpni->tc_rx[i].rx_queues[j].opr_id = i*dpni->tc_rx[SELECT_TC_SHARED_FS(i)].max_dist_size + j;
		}
	}
	return 0;
}


/*
 Distribution Width: 3 (n=0)
 dest:  0	QDBin: 0x0000
 dest:  1	QDBin: 0x0100
 dest:  2	QDBin: 0x0200

 Distribution Width: 6 (n=1)
 dest:  0	QDBin: 0x0000
 dest:  1	QDBin: 0x0001
 dest:  2	QDBin: 0x0100
 dest:  3	QDBin: 0x0101
 dest:  4	QDBin: 0x0200
 dest:  5	QDBin: 0x0201

 Distribution Width: 12 (n=2)
 dest:  0	QDBin: 0x0000
 dest:  1	QDBin: 0x0001
 dest:  2	QDBin: 0x0002
 dest:  3	QDBin: 0x0003
 dest:  4	QDBin: 0x0100
 dest:  5	QDBin: 0x0101
 dest:  6	QDBin: 0x0102
 dest:  7	QDBin: 0x0103
 dest:  8	QDBin: 0x0200
 dest:  9	QDBin: 0x0201
 dest:  10	QDBin: 0x0202
 dest:  11	QDBin: 0x0203

 Distribution Width: 7 (n=0)
 dest:  0	QDBin: 0x0000
 dest:  1	QDBin: 0x0080
 dest:  2	QDBin: 0x0100
 dest:  3	QDBin: 0x0180
 dest:  4	QDBin: 0x0200
 dest:  5	QDBin: 0x0280
 dest:  6	QDBin: 0x0300

 Distribution Width: 14 (n=1)
 dest:  0	QDBin: 0x0000
 dest:  1	QDBin: 0x0001
 dest:  2	QDBin: 0x0080
 dest:  3	QDBin: 0x0081
 dest:  4	QDBin: 0x0100
 dest:  5	QDBin: 0x0101
 dest:  6	QDBin: 0x0180
 dest:  7	QDBin: 0x0181
 dest:  8	QDBin: 0x0200
 dest:  9	QDBin: 0x0201
 dest:  10	QDBin: 0x0280
 dest:  11	QDBin: 0x0281
 dest:  12	QDBin: 0x0300
 dest:  13	QDBin: 0x0301
 *
 */
static int get_qdbin_from_flowid(uint16_t dist_size, uint16_t flow_id)
{
	int qdbin, mod;

	ASSERT_COND(flow_id<dist_size);
	switch (dist_size) {
	case 3:
	case 6:
	case 12:
		mod = (dist_size / 3);
		qdbin = ((flow_id / mod) << 8) | (flow_id % mod);
		break;
	case 7:
	case 14:
		mod = (dist_size / 7);
		qdbin = ((flow_id / mod) << 7) | (flow_id % mod);
		break;
	default: /* this must be power of 2 */
		ASSERT_COND(is_power_of_2(dist_size));
		qdbin = (int)flow_id;
		break;
	}

	return qdbin;
}

static int get_flowid_from_qdbin(uint16_t dist_size, int qdbin)
{
	int flow_id, mod;

	switch (dist_size) {
	case 3:
	case 6:
	case 12:
		mod = (dist_size / 3);
		flow_id = ((qdbin >> 8) * mod) + (qdbin & 0xff);
		break;
	case 7:
	case 14:
		mod = (dist_size / 7);
		flow_id = ((qdbin >> 7) * mod) + (qdbin & 0x7f);
		break;
	default: /* this must be power of 2 */
		ASSERT_COND(is_power_of_2(dist_size));
		flow_id = qdbin;
		break;
	}

	return flow_id;
}

static int mac_rule_match_cb(void *user_rule,
	struct dpni_table_rule *table_rule)
{
	return memcmp(user_rule, table_rule->rule.mac_addr, 6);
}

static int vlan_rule_match_cb(void *user_rule,
	struct dpni_table_rule *table_rule)
{
	return memcmp(user_rule, table_rule->rule.vlan_key, 3);
}

static int qos_fs_rule_match_cb(void *user_rule,
	struct dpni_table_rule *table_rule)
{
	struct dpni_rule_cfg *user_key = user_rule;
	int ret = 0;

	ret |= memcmp(user_key->key, &table_rule->rule.key_cfg.key,
			user_key->size);
	if (table_rule->rule.key_cfg.maskable) {
		ASSERT_COND(user_key->mask);
		ret |= memcmp(user_key->mask, &table_rule->rule.key_cfg.mask,
				user_key->size);
	}

	return ret;
}

static void qos_post_rule_remove_cb(struct dpni *dpni,
	struct dpni_table_rule *table_rule)
{
	dpni->tc_rx[table_rule->action.qpri - dpni_get_rx_base_qpri(dpni)].qos_owners--;
}

static void mac_dptbl_rule_create_cb(struct dpni_table_rule *table_rule,
	struct dptbl_rule *rule)
{
	rule->rule_cfg.exact.key = table_rule->rule.mac_addr;
	rule->rule_cfg.exact.size = 6;
}

static int is_mac_table_custom_rule(struct dpni_table_rule *table_rule)
{
	return table_rule->action.in_use;
}

static void vlan_dptbl_rule_create_cb(struct dpni_table_rule *table_rule,
	struct dptbl_rule *rule)
{
	rule->rule_cfg.exact.key = table_rule->rule.vlan_key;
	rule->rule_cfg.exact.size = 3;
}

static void qos_fs_dptbl_rule_create_cb(struct dpni_table_rule *table_rule,
	struct dptbl_rule *rule)
{
	if (table_rule->rule.key_cfg.maskable) {
		rule->rule_cfg.masked.key =
			(uint8_t*)&table_rule->rule.key_cfg.key;
		rule->rule_cfg.masked.mask =
			(uint8_t*)&table_rule->rule.key_cfg.mask;
		rule->rule_cfg.masked.priority =
			table_rule->rule.key_cfg.priority;
		rule->rule_cfg.masked.size = table_rule->rule.key_cfg.size;
	} else {
		rule->rule_cfg.exact.key =
			(uint8_t*)&table_rule->rule.key_cfg.key;
		rule->rule_cfg.exact.size = table_rule->rule.key_cfg.size;
	}
}

static void update_action_with_flc(struct dpni *dpni,
			struct dpni_rx_queue_info *info,
			struct dptbl_action *action)
{
	/* stash control and opaque are only applicable to GPP */
	if (dpni->dev_ctx.type != DPMNG_CTX_TYPE_GPP) {
		return;
	}

	if( !( action->options & DPTBL_ACTION_SET_QDBIN ) )
		/* when DPTBL_ACTION_SET_QDBIN is set user wants to enqueue frame
		 * on a specific queue and do not use hashing */
		if (dpni->options & DPNI_OPT_FLCTYPE_HASH) {
			action->options |= DPTBL_ACTION_SET_FLC_FOR_AIOP;
		}
	if (info->flc_type == DPNI_FLC_STASH)
		action->options |= DPTBL_ACTION_SET_STASHING_CNTRL;
	else
		action->options &= ~DPTBL_ACTION_SET_STASHING_CNTRL;
	action->options |= DPTBL_ACTION_SET_OPAQUE;
	action->opaque = info->flc_opaque;
}

static inline uint8_t get_kid_fs(struct dpni *dpni, uint8_t tc)
{
	if (dpni->options & DPNI_OPT_ALLOW_DIST_KEY_PER_TC)
		return dpni->tc_rx[tc].kid_fs;
	return dpni->tc_rx[0].kid_fs;
}

static inline uint8_t get_kid_hash(struct dpni *dpni, uint8_t tc)
{
	if (dpni->options & DPNI_OPT_ALLOW_DIST_KEY_PER_TC)
		return dpni->tc_rx[tc].kid_hash;
	return dpni->tc_rx[0].kid_hash;
}

static void fill_qos_entry(struct dpni *dpni,
	uint8_t tc_id,
	struct dptbl_action *action,
	uint8_t flags,
	uint8_t flow_id)
{
	uint8_t rx_queue = 0;
	
	memset(action, 0, sizeof(struct dptbl_action));
	action->options = DPTBL_ACTION_SET_QPRI;
	action->qpri = dpni_get_rx_base_qpri(dpni) + tc_id;
	action->next_action = DPTBL_ACTION_DONE;

	if (dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode == DPNI_DIST_MODE_FS) {
		action->next_action = DPTBL_ACTION_LOOKUP;
		action->lookup_params.dpkg_profile_id = get_kid_fs(dpni, SELECT_TC_SHARED_FS(tc_id));
		dptbl_get_id(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl,
				&action->lookup_params.dptbl_id);

	} else if ((dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode == DPNI_DIST_MODE_HASH) &&
			!(flags & DPNI_QOS_OPT_SET_FLOW_ID)) {
		action->options |= DPTBL_ACTION_SET_HASH_KID;
		action->hash_dpkg_profile_id = get_kid_hash(dpni, SELECT_TC_SHARED_FS(tc_id));
	}

	if (flags & DPNI_QOS_OPT_SET_FLOW_ID)
	{
			action->next_action = DPTBL_ACTION_DONE;
			action->options |= DPTBL_ACTION_SET_QDBIN;
			action->qd_bin = get_qdbin_from_flowid(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size, flow_id);
	}

	if (dpni->tc_rx[tc_id].policer_enable) {
		action->options |= DPTBL_ACTION_SET_POLICER_ID;
		action->dppolicer_profile_id = dpni->tc_rx[tc_id].plcrid;
	}

	update_action_with_flc(dpni, &dpni->tc_rx[tc_id].rx_queues[flow_id], action);
}

static void copy_dptbl_to_dppolicy(struct dptbl_action *tbl_action,
	struct dppolicy_action *policy_action)
{
	policy_action->dppolicer_profile_id = tbl_action->dppolicer_profile_id;
	policy_action->hash_dpkg_profile_id = tbl_action->hash_dpkg_profile_id;
	policy_action->ifp_id = tbl_action->ifp_id;
	policy_action->lookup_params.dpkg_profile_id =
		tbl_action->lookup_params.dpkg_profile_id;
	policy_action->lookup_params.dptbl_id =
		tbl_action->lookup_params.dptbl_id;
	policy_action->next_action =
		(enum dppolicy_next_action)tbl_action->next_action;
	policy_action->opaque = tbl_action->opaque;
	policy_action->options = tbl_action->options;
	policy_action->qd_bin = tbl_action->qd_bin;
	policy_action->qd_id = tbl_action->qd_id;
	policy_action->qos_map_method =
		(enum dppolicy_qos_map_method)tbl_action->qos_map_method;
	policy_action->qpri = tbl_action->qpri;
	policy_action->replic_id = tbl_action->replic_id;
}

static void modify_ctlu_policy_action(struct dpni *dpni,
	int priority,
	struct dppolicy_action *action)
{
	struct dppolicy_rule rule; /* Policy rule */
	int err;

	memset(&rule, 0, sizeof(struct dppolicy_rule));
	rule.num_of_identifiers = 1;
	rule.identifiers[0].exclude = 0;
	rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT_OPT;
	rule.identifiers[0].prot = NET_PROT_ETH;
	switch (priority) {
	case DPNI_POLICY_PRI_BROADCAST:
		rule.priority = DPNI_POLICY_PRI_BROADCAST;
		rule.identifiers[0].opt = NH_OPT_ETH_BROADCAST;
		break;
	case DPNI_POLICY_PRI_MULTICAST:
		rule.priority = DPNI_POLICY_PRI_MULTICAST;
		rule.identifiers[0].opt = NH_OPT_ETH_MULTICAST;
		break;
	case DPNI_POLICY_PRI_UNICAST:
		rule.priority = DPNI_POLICY_PRI_UNICAST;
		rule.identifiers[0].opt = NH_OPT_ETH_UNICAST;
		break;
	default:
		ASSERT_COND(0);
	}

	err = dppolicy_modify_rule(dpni->policy, &rule, action);
	ASSERT_COND(!err || (err == -ETIMEDOUT));
}

static void fill_dpdmux_kid_tid(struct dpni *dpni,
	uint16_t *tid,
	uint16_t *kid)
{
	struct dppolicy_action action;
	int table_id;

	memset(&action, 0, sizeof(struct dppolicy_action));
	switch (dpni->dpdmux_method) {
	case DPDMUX_METHOD_C_VLAN_MAC:
		if (!(dpni->options & DPNI_OPT_VLAN_FILTER)) {
			pr_info("ID[%d]: dpni wasn't configured with vlan "
			"filtering but dpdmux is working in vlan-mac method.\n", dpni->id);
			return;
		}

		if (dpni->is_snic) {
			/* No need to provide kid/tid, need to finish the flow */
			*tid = (uint16_t)-1;
			*kid = (uint16_t)-1;
		} else {
			/* will skip both MAC and VLAN tables. provide QoS table info */
			dptbl_get_id(dpni->qos.tbl, &table_id);
			*tid = (uint16_t)table_id;
			*kid = (uint16_t)dpni->qos.kid;
		}

		if (dpni->filters.vlan_tbl)
			copy_dptbl_to_dppolicy(
				&dpni->filters.vlan_allow_action, &action);
		else
			copy_dptbl_to_dppolicy(&dpni->filters.mac_allow_action,
						&action);
		modify_ctlu_policy_action(dpni, DPNI_POLICY_PRI_BROADCAST,
						&action);
		modify_ctlu_policy_action(dpni, DPNI_POLICY_PRI_MULTICAST,
						&action);
		modify_ctlu_policy_action(dpni, DPNI_POLICY_PRI_UNICAST,
						&action);
		break;
	case DPDMUX_METHOD_MAC:
		/* Need to provide either VLAN or QoS table info */
		if (dpni->filters.vlan_tbl) {
			dptbl_get_id(dpni->filters.vlan_tbl, &table_id);
			*tid = (uint16_t)table_id;
			*kid = (uint16_t)dpni->filters.vlan_kid;
		} else {
			dptbl_get_id(dpni->qos.tbl, &table_id);
			*tid = (uint16_t)table_id;
			*kid = (uint16_t)dpni->qos.kid;
		}
		copy_dptbl_to_dppolicy(&dpni->filters.mac_allow_action,
					&action);
		modify_ctlu_policy_action(dpni, DPNI_POLICY_PRI_BROADCAST,
						&action);
		modify_ctlu_policy_action(dpni, DPNI_POLICY_PRI_MULTICAST,
						&action);
		modify_ctlu_policy_action(dpni, DPNI_POLICY_PRI_UNICAST,
						&action);
		break;
	case DPDMUX_METHOD_C_VLAN:
		if (!(dpni->options & DPNI_OPT_VLAN_FILTER)) {
			pr_info("ID[%d]: dpni wasn't configured with vlan "
			"filtering but dpdmux is working in vlan-mac method.\n", dpni->id);
			return;
		}
		/* Need to provide MAC table info */
		dptbl_get_id(dpni->filters.mac_tbl, &table_id);
		*tid = (uint16_t)table_id;
		*kid = (uint16_t)dpni->filters.mac_kid;
		break;
	case DPDMUX_METHOD_CUSTOM:
		/* don't care about DPNI connecting to DPDMUX, DPDMUX has
		 * custom rules.
		 */
		break;
	default:
		ASSERT_COND(0);
	}
}

static int update_dpdmux_address(struct dpni *dpni,
	uint8_t mac[6],
	uint16_t vlan_id,
	int remove)
{
	struct dpdmux_l2_rule l2_rule;

	/* We MUST ignore errors from the dpdmux functions. There is no other choice */
	memcpy(&(l2_rule.mac_addr), mac, 6);
	l2_rule.vlan_id = vlan_id;

	if (remove)
		dpdmux_if_remove_l2_rule(dpni->dpdmux, dpni->dpdmux_if_id,
						&l2_rule, DPDMUX_OWNER_NIC);
	else
		dpdmux_if_add_l2_rule(dpni->dpdmux, dpni->dpdmux_if_id,
					&l2_rule, DPDMUX_OWNER_NIC);
	return 0;
}

static int update_dpdmux_mac_vlan_by_mac(struct dpni *dpni,
	uint8_t addr[6],
	int remove)
{
	int i;

	for (i = 0; i < dpni->filters.max_vlan_filters; i++) {
		if (dpni->filters.vlans[i].in_use)
			update_dpdmux_address(
				dpni,
				addr,
				*(uint16_t*)&dpni->filters.vlans[i].rule.vlan_key[1],
				remove);
	}

	return 0;
}

static int update_dpdmux_mac_vlan_by_vlan(struct dpni *dpni,
	uint16_t vlan_id,
	int remove)
{
	int j;

	/* Add {vlan_id,primary mac address} */
	update_dpdmux_address(dpni, dpni->mac_addr, vlan_id, remove);

	for (j=0; j<DPNI_MAX_MAC_FILTERS; j++)
		if (dpni->filters.mac_addrs[j].in_use)
			update_dpdmux_address(dpni,
					dpni->filters.mac_addrs[j].rule.mac_addr,
					vlan_id, remove);
	return 0;
}

static void update_dpdmux_unicast_promisc(struct dpni *dpni)
{
	int i;

	if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC) {
		for (i = 0; i < dpni->filters.max_vlan_filters; i++) {
			if (dpni->filters.vlans[i].in_use)
				dpdmux_if_set_unicast_promisc(
					dpni->dpdmux,
					dpni->dpdmux_if_id,
					*(uint16_t*)&dpni->filters.vlans[i].rule.vlan_key[1],
					dpni->unicast_promisc_en);
		}
	} else if (dpni->dpdmux_method == DPDMUX_METHOD_MAC) {
		dpdmux_if_set_unicast_promisc(dpni->dpdmux, dpni->dpdmux_if_id,
						0/* no vlan */,
						dpni->unicast_promisc_en);
	}
}

static void update_dpdmux_multicast_promisc(struct dpni *dpni)
{
	int i;

	if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC) {
		for (i = 0; i < dpni->filters.max_vlan_filters; i++) {
			if (dpni->filters.vlans[i].in_use)
				dpdmux_if_set_multicast_promisc(
					dpni->dpdmux,
					dpni->dpdmux_if_id,
					*(uint16_t*)&dpni->filters.vlans[i].rule.vlan_key[1],
					dpni->multicast_promisc_en);
		}
	} else if (dpni->dpdmux_method == DPDMUX_METHOD_MAC) {
		dpdmux_if_set_multicast_promisc(dpni->dpdmux,
						dpni->dpdmux_if_id,
						0/* no vlan */,
						dpni->multicast_promisc_en);
	}
}

static int populate_tables_to_dpdmux(struct dpni *dpni, int remove)
{
	int i;
	int err;

	switch (dpni->dpdmux_method) {
	case DPDMUX_METHOD_C_VLAN_MAC:
		for (i = 0; i < dpni->filters.max_vlan_filters; i++)
			if (dpni->filters.vlans[i].in_use) {
				update_dpdmux_mac_vlan_by_vlan(
					dpni,
					*(uint16_t*)&dpni->filters.vlans[i].rule.vlan_key[1],
					remove);
				if (dpni->unicast_promisc_en) {
					err =
						dpdmux_if_set_unicast_promisc(
							dpni->dpdmux,
							dpni->dpdmux_if_id,
							*(uint16_t*)&dpni->filters.vlans[i].rule.vlan_key[1],
							(remove ? 0 : 1)/*en*/);
					CHECK_COND_RETVAL(err == 0, err);
				}

				if (dpni->multicast_promisc_en) {
					err =
						dpdmux_if_set_multicast_promisc(
							dpni->dpdmux,
							dpni->dpdmux_if_id,
							*(uint16_t*)&dpni->filters.vlans[i].rule.vlan_key[1],
							(remove ? 0 : 1)/*en*/);
					CHECK_COND_RETVAL(err == 0, err);
				}
			}
		break;
	case DPDMUX_METHOD_MAC:
		/* Add primary mac address */
		update_dpdmux_address(dpni, dpni->mac_addr, 0,
					remove /* add */);

		/* Add mac address */
		for (i = 0; i < DPNI_MAX_MAC_FILTERS; i++)
			if (dpni->filters.mac_addrs[i].in_use)
				update_dpdmux_address(
					dpni,
					dpni->filters.mac_addrs[i].rule.mac_addr,
					0 /* vlan-id */, remove);

		if (dpni->unicast_promisc_en) {
			err = dpdmux_if_set_unicast_promisc(
				dpni->dpdmux, dpni->dpdmux_if_id, 0,/*vlan*/
				(remove ? 0 : 1)/*en*/);
			CHECK_COND_RETVAL(err == 0, err);
		}

		if (dpni->multicast_promisc_en) {
			err = dpdmux_if_set_multicast_promisc(
				dpni->dpdmux, dpni->dpdmux_if_id, 0,/*vlan*/
				(remove ? 0 : 1)/*en*/);
			CHECK_COND_RETVAL(err == 0, err);
		}
		break;
	case DPDMUX_METHOD_C_VLAN:
		for (i = 0; i < dpni->filters.max_vlan_filters; i++)
			if (dpni->filters.vlans[i].in_use)
				update_dpdmux_address(
					dpni,
					0 /* mac-addr */,
					*(uint16_t*)&dpni->filters.vlans[i].rule.vlan_key[1],
					remove);
		break;
	case DPDMUX_METHOD_CUSTOM:
		/* don't care about DPNI connecting to DPDMUX, DPDMUX has
		 * custom rules.
		 */
		break;
	default:
		ASSERT_COND(0);
	}

	return 0;
}

static int check_flc(struct dpni *dpni, const struct dpni_flc_cfg *flc_cfg)
{
	switch (flc_cfg->flc_type) {
	case DPNI_FLC_USER_DEFINED:
		break;
	case DPNI_FLC_STASH:
		if (flc_cfg->flow_context_size != DPNI_STASH_SIZE_0B) {
			if (!flc_cfg->flow_context)
				pr_err( "ID[%d]: Flow context address must be given\n", dpni->id);
			if (!IS_ALIGNED(flc_cfg->flow_context, 64))
				pr_err( "ID[%d]: Flow context address must be aligned to %d\n", dpni->id, 64);
		}
		break;
	}
	return 0;
}

static void build_flc(struct dpni_rx_queue_info *info,
	struct dpni_flc_cfg *flc_cfg,
	int build_external)
{
	if (!build_external) {
		info->flc_opaque = 0;
		info->flc_type = flc_cfg->flc_type;
		switch (flc_cfg->flc_type) {
		case DPNI_FLC_USER_DEFINED:
			info->flc_opaque = flc_cfg->flow_context;
			break;
		case DPNI_FLC_STASH:
			if (flc_cfg->flow_context_size != DPNI_STASH_SIZE_0B) {
				info->flc_opaque |= flc_cfg->flow_context;
				info->flc_opaque |= flc_cfg->flow_context_size;
			}
			if (flc_cfg->options & DPNI_FLC_STASH_FRAME_ANNOTATION)
				info->flc_opaque |= DPNI_STASH_SIZE_192B << 2;
			info->flc_opaque |= flc_cfg->frame_data_size << 4;
			break;
		}
	} else {
		flc_cfg->flc_type = info->flc_type;
		switch (info->flc_type) {
		case DPNI_FLC_USER_DEFINED:
			flc_cfg->flow_context = info->flc_opaque;
			break;
		case DPNI_FLC_STASH:
			flc_cfg->flow_context = (info->flc_opaque & ~0x3fLL);
			flc_cfg->flow_context_size =
				(enum dpni_stash_size)((info->flc_opaque)
							& 0x3LL);
			if ((info->flc_opaque >> 2) & 0x3LL)
				flc_cfg->options |=
					DPNI_FLC_STASH_FRAME_ANNOTATION;
			flc_cfg->frame_data_size =
				(enum dpni_stash_size)((info->flc_opaque >> 4)
							& 0x3LL);
			break;
		}
	}
}

static void vlan_update_miss_flc(struct dpni *dpni)
{
	struct dpni_rx_queue_info *info = NULL;
	int err;

	if (!dpni->filters.vlan_tbl || !dpni->filters.vlan_enable || dpni->restore.en)
		return;

	info = &dpni->rx_err;
	ASSERT_COND(info);

	update_action_with_flc(dpni, info, &dpni->filters.vlan_disallow_action);
	err = dptbl_modify_miss_action(dpni->filters.vlan_tbl,
					&dpni->filters.vlan_disallow_action);
	ASSERT_COND(!err || (err == -ETIMEDOUT));
}

static void qos_update_miss_flc(struct dpni *dpni)
{
	struct dpni_rx_queue_info *info = NULL;
	int err;

	if (!dpni->qos.valid)
		return;

	/* if miss is discard we take rx-err's FLC */
	if (dpni->qos.miss_action.options & DPTBL_ACTION_SET_DISCARD_FLAG)
		info = &dpni->rx_err;

	/* if miss is explicit TC we take flow#0's FLC */
	if (dpni->qos.miss_action.options & DPTBL_ACTION_SET_QPRI)
		info = &dpni->tc_rx[dpni->qos.miss_action.qpri
					- dpni_get_rx_base_qpri(dpni)].rx_queues[0];

	CHECK_COND_RET( info != NULL, "ID[%d] qos_update_miss_flc error\n", dpni->id);

	update_action_with_flc(dpni, info, &dpni->qos.miss_action);
	err = dptbl_modify_miss_action(dpni->qos.tbl, &dpni->qos.miss_action);
	ASSERT_COND(!err || (err == -ETIMEDOUT));
}

static void fs_update_miss_flc(struct dpni *dpni, uint8_t tc_id)
{
	struct dpni_rx_queue_info *info = NULL;
	int err;

	if (!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid)
		return;

	/* if miss is discard we take rx-err's FLC */
	if (dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].miss_action.options
		& DPTBL_ACTION_SET_DISCARD_FLAG)
		info = &dpni->rx_err;

	/* if miss is explicit flow-id we take flow's FLC */
	if (dpni->tc_rx[tc_id].miss_action.options & DPTBL_ACTION_SET_QDBIN)
		info = &dpni->tc_rx[tc_id].rx_queues[get_flowid_from_qdbin(
			dpni->tc_rx[SELECT_TC_SHARED_FS(SELECT_TC_SHARED_FS(tc_id))].dist_size,
			dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].miss_action.qd_bin)];

	/* if miss is hash we take flow#0's FLC */
	if (dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].miss_action.options & DPTBL_ACTION_SET_HASH_KID)
		info = &dpni->tc_rx[tc_id].rx_queues[0];


	CHECK_COND_RET(info, "Looking for a miss action but none found!");

	update_action_with_flc(dpni, info, &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].miss_action);
	err = dptbl_modify_miss_action(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl,
					&dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].miss_action);
	ASSERT_COND(!err || (err == -ETIMEDOUT));
}

static void update_pass_through_qos(struct dpni *dpni)
{
	struct dptbl_action action;
	uint32_t options = dpni->qos.default_action.options;
	int err = 0;

	/* If the QoS is 'dummy' or not yet defined by the user we must
	 * assure TC#0 will work */
	if (!((dpni->max_rx_tcs == 1) || (!dpni->qos.valid)) && !dpni->restore.en)
		return;

	/* Only TC#0 can explicit active distribution */
	if (options & DPTBL_ACTION_SET_QDBIN)
		fill_qos_entry(dpni, 0, &action, DPNI_QOS_OPT_SET_FLOW_ID, 0);
	else
		fill_qos_entry(dpni, 0, &action, DPNI_QOS_OPT_SET_TC_ONLY, 0);
	if (!(dpni->max_rx_tcs > 1))
		err = dptbl_modify_rule(dpni->qos.tbl, &dpni->dummy_rule,
					&action);
	else if (!dpni->qos.valid || dpni->restore.en)
		err = dptbl_modify_miss_action(dpni->qos.tbl, &action);

	ASSERT_COND(!err || (err == -ETIMEDOUT));
}

static void update_qos_entries_flc(struct dpni *dpni)
{
	struct dptbl_rule rule;
	int i;

	if (!dpni->qos.valid)
		return;

	i = 0;
	do {
		if (dpni->qos.keys[i].in_use) {
			memset(&rule, 0, sizeof(struct dptbl_rule));
			qos_fs_dptbl_rule_create_cb(&dpni->qos.keys[i], &rule);
			update_action_with_flc(dpni,
				&dpni->tc_rx[dpni->qos.keys[i].action.qpri
						- dpni_get_rx_base_qpri(dpni)].rx_queues[0],
				&dpni->qos.keys[i].action);
			dptbl_modify_rule(dpni->qos.tbl, &rule,
						&dpni->qos.keys[i].action);
		}
	} while (!dpni->qos.keys[i++].is_last);

	qos_update_miss_flc(dpni);
}

static void update_fs_entries_flc(struct dpni *dpni, uint8_t tc_id)
{
	struct dptbl_rule rule;
	int i, flow_id;

	if (!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid)
		return;

	i = 0;
	do {
		if (dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[i].in_use &&
				!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[i].custom_flc) {
			memset(&rule, 0, sizeof(struct dptbl_rule));
			qos_fs_dptbl_rule_create_cb(
				&dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[i], &rule);
			flow_id = get_flowid_from_qdbin(
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size,
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[i].action.qd_bin);

			update_action_with_flc(dpni,
				&dpni->tc_rx[tc_id].rx_queues[flow_id],/*for shared fs table we keep the tc_id as is when we are extracting queue info */
				&dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[i].action);
			dptbl_modify_rule(
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl, &rule,
				&dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[i].action);
		}
	} while (!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[i++].is_last);

	fs_update_miss_flc(dpni, tc_id);
}

static void remove_mac_dpdmux_cb(struct dpni *dpni,
	struct dpni_table_rule *table_rule)
{
	if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC)
		update_dpdmux_mac_vlan_by_mac(dpni, table_rule->rule.mac_addr,
						1 /* remove */);
	else if (dpni->dpdmux_method == DPDMUX_METHOD_MAC)
		update_dpdmux_address(dpni, table_rule->rule.mac_addr,
					0 /*vlan-id*/, 1 /* remove */);
}

static void remove_vlan_dpdmux_cb(struct dpni *dpni,
	struct dpni_table_rule *table_rule)
{
	if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC)
		update_dpdmux_mac_vlan_by_vlan(
			dpni, *(uint16_t*)&table_rule->rule.vlan_key[1],
			1 /* remove */);
	else if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN)
		update_dpdmux_address(
			dpni, 0 /* mac */,
			*(uint16_t*)&table_rule->rule.vlan_key[1],
			1 /* remove */);
}

static void reset_rule(struct dpni_table_rule *rule)
{
	char is_last;
	uint16_t priority;

	is_last = rule->is_last;
	priority = rule->rule.key_cfg.priority;
	memset(rule, 0, sizeof(struct dpni_table_rule));
	rule->rule.key_cfg.priority = priority;
	rule->is_last = is_last;
}

static struct dpni_table_rule* find_free_rule(struct dpni_table_rule *array)
{
	int i;

	i = 0;
	do {
		if (!array[i].in_use) {
			reset_rule(&array[i]);
			array[i].in_use = 1;
			return &array[i];
		}
	} while (!array[i++].is_last);

	return NULL;
}

static struct dpni_table_rule* find_rule_by_priority(struct dpni_table_rule *array, int priority)
{
	int i;

	i = 0;
	do {
		if (array[i].rule.key_cfg.priority==priority) {
			reset_rule(&array[i]);
			array[i].in_use = 1;
			return &array[i];
		}
	} while (!array[i++].is_last);

	return NULL;
}

static void remove_rule(struct dpni *dpni,
	struct dpni_table_rule *array,
	void *rule,
	rule_match_cb match_cb,
	post_remove_cb post_remove_cb)
{
	int i;

	/* if !match_cb than assumes 'array' is
	 * explicit rule and remove it without searching */
	if (!match_cb) {
		if (post_remove_cb)
			post_remove_cb(dpni, array);
		array->in_use = 0;
		return;
	}

	i = 0;
	do {
		if (array[i].in_use && (match_cb(rule, &array[i]) == 0)) {
			if (post_remove_cb)
				post_remove_cb(dpni, &array[i]);
			array[i].in_use = 0;
			return;
		}
	} while (!array[i++].is_last);

	ASSERT_COND(0);
}

static struct dpni_table_rule* get_rule(struct dpni *dpni,
	struct dpni_table_rule *array,
	void *rule,
	rule_match_cb match_cb)
{
	int i;

	i = 0;
	do {
		if (array[i].in_use && (match_cb(rule, &array[i]) == 0))
			return &array[i];
	} while (!array[i++].is_last);

	return NULL;
}

static void clear_table(struct dpni *dpni,
	struct dptbl *tbl,
	struct dpni_table_rule *array,
	dptbl_rule_create_cb rule_create_cb,
	post_remove_cb post_remove_cb,
	remove_mac_vlan_dpdmux_cb dpdmux_remove_cb)
{
	struct dptbl_rule rule;
	int i, err;

	i = 0;
	do {
		if (array[i].in_use) {
			memset(&rule, 0, sizeof(struct dptbl_rule));
			rule_create_cb(&array[i], &rule);
			err = dptbl_remove_rule(tbl, &rule);
			ASSERT_COND(!err || (err == -ETIMEDOUT));
			if (dpdmux_remove_cb)
				dpdmux_remove_cb(dpni, &array[i]);
			if (post_remove_cb)
				post_remove_cb(dpni, &array[i]);

			if( array[i].redirect.valid ) {
				array[i].redirect.remote_entry->valid = 0;
				array[i].redirect.remote_entry = NULL;
				array[i].redirect.token = 0;
				array[i].redirect.valid = 0;
			}

			array[i].in_use = 0;
		}
	} while (!array[i++].is_last);
}

static void clear_all_tables(struct dpni *dpni)
{
	struct dpni_rx_tc_dist_cfg tc_cfg;
	int i;

	dpni_clear_mac_filters(dpni, 1, 1);
	if (dpni->options & DPNI_OPT_VLAN_FILTER)
		dpni_clear_vlan_filters(dpni);

	if (dpni->qos.valid) {
		dpni_clear_qos_table(dpni);
		if (dpni->qos.default_tc != -1)
			dpni->tc_rx[dpni->qos.default_tc].qos_owners--;
		dpni->qos.valid = 0;
	}

	memset(&tc_cfg, 0, sizeof(struct dpni_rx_tc_dist_cfg));
	tc_cfg.dist_mode = DPNI_DIST_MODE_NONE;

	if (!IS_SHARED_FS_ENABLED) {
		for (i = 0; i < dpni->max_rx_tcs; i++)
			if (dpni->tc_rx[i].valid)
				dpni_set_rx_tc_dist(dpni, (uint8_t)i, &tc_cfg);
	} else {
		if (dpni->tc_rx[0].valid)
			dpni_set_rx_tc_dist(dpni, (uint8_t)0, &tc_cfg);
	}

}

static int invoke_inter(struct dpni *dpni, uint8_t index, uint32_t event)
{
	event_send(&(dpni->irqs[index]), event);

	return 0;
}

static int get_free_sender_id(struct dpni *dpni, int ceetm_ch_idx, uint16_t *id)
{
	int err = 0;
	uint16_t i;

	for (i = 0; i < dpni->max_senders; i++) {
		if (dpni->tx_ch[ceetm_ch_idx].sender_info[i].valid == 0)
			break;
	}

	if (i == dpni->max_senders)
		err = -ENAVAIL;
	else {
		*id = i;
		dpni->tx_ch[ceetm_ch_idx].sender_info[i].valid = 1;
	}

	return err;
}

static inline void get_dest_wq(const struct dpni_dest_cfg *cfg,
	uint16_t *dest_wqid)
{
	struct dpcon *dpcon;
	struct dpio *dpio;
	int err;

	if (cfg->dest_type == DPNI_DEST_DPIO) {
		dpio = sys_get_handle(FSL_MOD_DPIO, 1, cfg->dest_id);
		ASSERT_COND(dpio);
		err = dpio_get_destwq(dpio, cfg->priority, dest_wqid);
		ASSERT_COND(err == 0);
	} else { /* DPNI_DEST_DPCON */
		dpcon = sys_get_handle(FSL_MOD_DPCON, 1, cfg->dest_id);
		ASSERT_COND(dpcon);
		err = dpcon_get_destwq(dpcon, cfg->priority, dest_wqid);
		ASSERT_COND(err == 0);
	}
}

static void early_drop_reset(struct qbman_swp *swp,
	int cgid,
	int is_ccgid,
	uint32_t ceetmid,
	uint8_t cchannelid)
{
	/* reset statistics */
	if (is_ccgid)
		qbman_ceetm_statistics_query(
			swp, ceetmid, (uint16_t)(cchannelid << 4 | cgid),
			query_and_clear_reject_statistics, NULL, NULL);
	else
		qbman_cgr_statistics_query(swp, (uint32_t)cgid, 1, NULL, NULL);
}

static void early_drop_fill(void *opaque,
	struct qbman_attr *cgr_desc,
	int reset)
{
	struct dpni_early_drop_cfg *cfg = (struct dpni_early_drop_cfg *)opaque;
	uint32_t wred_dp;

	/* clear early-drop settings */
	qbman_cgr_attr_set_td_ctrl(cgr_desc, 0);
	qbman_cgr_attr_wred_set_edp(cgr_desc, DPNI_POLICING_GREEN_IDX, 0);
	qbman_cgr_attr_wred_set_edp(cgr_desc, DPNI_POLICING_YELLOW_IDX, 0);
	qbman_cgr_attr_wred_set_edp(cgr_desc, DPNI_POLICING_RED_IDX, 0);
	if (reset)
		return;

	qbman_cgr_attr_set_mode(cgr_desc, cfg->units, 0);
	if (cfg->dpni_tail_drop_enable) {
		qbman_cgr_attr_set_td_ctrl(cgr_desc, 1);
		qbman_cgr_attr_set_td_thres(cgr_desc,
						cfg->tail_drop_threshold);
	} 
	
	if (cfg->dpni_wred_enable) {
		qbman_cgr_attr_wred_set_edp(cgr_desc, DPNI_POLICING_GREEN_IDX,
						1);
		wred_dp = qbman_cgr_attr_wred_dp_compose(
			cfg->green.min_threshold, cfg->green.max_threshold,
			cfg->green.drop_probability);
		qbman_cgr_attr_wred_set_parm_dp(cgr_desc,
						DPNI_POLICING_GREEN_IDX,
						wred_dp);
		qbman_cgr_attr_wred_set_edp(cgr_desc, DPNI_POLICING_YELLOW_IDX,
						1);
		wred_dp = qbman_cgr_attr_wred_dp_compose(
			cfg->yellow.min_threshold, cfg->yellow.max_threshold,
			cfg->yellow.drop_probability);
		qbman_cgr_attr_wred_set_parm_dp(cgr_desc,
						DPNI_POLICING_YELLOW_IDX,
						wred_dp);
		qbman_cgr_attr_wred_set_edp(cgr_desc, DPNI_POLICING_RED_IDX,
						1);
		wred_dp = qbman_cgr_attr_wred_dp_compose(
			cfg->red.min_threshold, cfg->red.max_threshold,
			cfg->red.drop_probability);
		qbman_cgr_attr_wred_set_parm_dp(cgr_desc,
						DPNI_POLICING_RED_IDX,
						wred_dp);
	}
}

/******************************************************************************/
static void dcp_congestion_notification_fill(void *opaque,
					     struct qbman_attr *cgr_desc,
					     int reset)
{
	struct dpni_congestion_notification_cfg		*cfg;

	cfg = (struct dpni_congestion_notification_cfg *)opaque;
	/* Must clear old settings */
	qbman_cgr_attr_clear(cgr_desc);
	if (reset)
		return;
	qbman_cgr_attr_set_mode(cgr_desc, cfg->units, 0);
	qbman_cgr_attr_set_cs_thres(cgr_desc, cfg->threshold_entry);
	qbman_cgr_attr_set_cs_thres_x(cgr_desc, cfg->threshold_exit);
	/* Set :
	 *	- CG_WR_ADDR iova address
	 *	- CSCN_WR_EN entry, exit and coherent bits in CTL2 */
	qbman_cgr_attr_set_cscn_in_memory(cgr_desc,
					  (cfg->notification_mode &
					   DPNI_CGN_MODE_WRITE_MEM_ON_ENTER) ?
							   1 : 0,
					  (cfg->notification_mode &
					   DPNI_CGN_MODE_WRITE_MEM_ON_EXIT) ?
							   1 : 0,
					  cfg->message_iova,
					  (cfg->notification_mode &
					   DPNI_CGN_MODE_COHERENT_WRITE) ?
							   1 : 0);
	/* Message CTX */
	qbman_cgr_attr_set_cscn_ctx(cgr_desc, cfg->message_ctx);
	/* WRIOP DCP */
	if (cfg->notification_mode & DPNI_CGN_NOTIFY_WRIOP_DCP)
		qbman_cgr_attr_set_cscn_tdcp(cgr_desc, 0x0, 1);
	/* AIOP DCP */
	if (cfg->notification_mode & DPNI_CGN_NOTIFY_AIOP_DCP)
		qbman_cgr_attr_set_cscn_tdcp(cgr_desc, 0x1, 1);
	/* BDI field is included in CSCN that are sent from this congestion
	 * group to a DCP portal */
	qbman_cgr_attr_set_cscn_bdi(cgr_desc, 1);
	/* Congestion Group (CG) Write Privilege Level
	 * The value of this bit will be supplied as both the PL and BMT value
	 * to the IOMMU, therefore if this bit is
	 *	- 0, the write will be authorized and translated by the IOMMU,
	 *	- 1 then IOMMU translation is bypassed and the address in
	 *	CG_WR_ADDR must be a real physical address. */
	qbman_cgr_attr_set_cscn_pl(cgr_desc, 1);
}

static void congestion_notification_fill(void *opaque,
	struct qbman_attr *cgr_desc,
	int reset)
{
	struct dpni_congestion_notification_cfg *cfg =
		(struct dpni_congestion_notification_cfg *)opaque;
	uint16_t destwq;

	/* Check if DCP notification was configured */
	if ((cfg->notification_mode & DPNI_CGN_NOTIFY_AIOP_DCP) ||
	    (cfg->notification_mode & DPNI_CGN_NOTIFY_WRIOP_DCP)) {
		dcp_congestion_notification_fill(opaque, cgr_desc, reset);
		return;
	}
	/* clear old settings */
	qbman_cgr_attr_set_cs_thres(cgr_desc, 0);
	qbman_cgr_attr_set_cs_thres_x(cgr_desc, 0);
	qbman_cgr_attr_set_cscn_wq_ctrl(cgr_desc, 0, 0, 0);
	qbman_cgr_attr_set_cscn_wqid(cgr_desc, 0);
	qbman_cgr_attr_set_cscn_in_memory(cgr_desc, 0, 0, 0, 0);
	qbman_cgr_attr_set_cscn_ctx(cgr_desc, 0);
	if (reset)
		return;
	qbman_cgr_attr_set_mode(cgr_desc, cfg->units, 0);
	qbman_cgr_attr_set_cs_thres(cgr_desc, cfg->threshold_entry);
	qbman_cgr_attr_set_cs_thres_x(cgr_desc, cfg->threshold_exit);
	if (cfg->dest_cfg.dest_type != DPNI_DEST_NONE) {
		qbman_cgr_attr_set_cscn_wq_ctrl(
			cgr_desc,
			(cfg->notification_mode & DPNI_CGN_MODE_NOTIFY_DEST_ON_ENTER) ?
				1 : 0,
			(cfg->notification_mode & DPNI_CGN_MODE_NOTIFY_DEST_ON_EXIT) ?
				1 : 0,
			(cfg->notification_mode & DPNI_CGN_MODE_INTR_COALESCING_DISABLED) ?
				1 : 0);
		get_dest_wq(&cfg->dest_cfg, &destwq);
		qbman_cgr_attr_set_cscn_wqid(cgr_desc, (uint32_t)destwq);
	}

	qbman_cgr_attr_set_cscn_in_memory(
		cgr_desc,
		(cfg->notification_mode & DPNI_CGN_MODE_WRITE_MEM_ON_ENTER) ? 1 : 0,
		(cfg->notification_mode & DPNI_CGN_MODE_WRITE_MEM_ON_EXIT) ? 1 : 0,
		cfg->message_iova,
		(cfg->notification_mode & DPNI_CGN_MODE_COHERENT_WRITE) ? 1 : 0);
	qbman_cgr_attr_set_cscn_ctx(cgr_desc, cfg->message_ctx);
}

static inline int is_snic(struct dpni *dpni, const struct dpni_cfg *cfg)
{
	if ((dpni->type == DPNI_TYPE_NIC)
		&& (cfg->adv.options & DPNI_SNIC_OPTIONS_SUPPORTED))
		return 1;
	return 0;
}

static inline int check_dest_cfg(struct dpni *dpni,
	const struct dpni_dest_cfg *cfg)
{
	struct dpcon *dpcon;
	struct dpio *dpio;

	if (cfg->dest_type == DPNI_DEST_DPCON) {
		dpcon = sys_get_handle(FSL_MOD_DPCON, 1, cfg->dest_id);
		if (!dpcon) {
			pr_err("ID[%d]: dpcon_id is invalid\n", dpni->id);
			return -EINVAL;
		}
		if (!dpcon_is_priority_in_range(dpcon, cfg->priority)) {
			pr_err("ID[%d]: priority not in range\n", dpni->id);
			return -EINVAL;
		}
		/* check that the destination DPCON uses DCP AIOP channels */
		if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
			CHECK_COND_RETVAL(dpcon_is_aiop_dcp_channel_type(dpcon),
			-EINVAL,
			"Invalid FQ destination: dpcon[%d] not in AIOP container\n",
			cfg->dest_id);
		}
	}

	if (cfg->dest_type == DPNI_DEST_DPIO) {
		dpio = sys_get_handle(FSL_MOD_DPIO, 1, cfg->dest_id);
		if (!dpio) {
			pr_err("ID[%d]: dpio_id is invalid\n", dpni->id);
			return -EINVAL;
		}
		if (!dpio_is_priority_in_range(dpio, cfg->priority)) {
			pr_err("ID[%d]: priority not in range\n", dpni->id);
			return -EINVAL;
		}
	}

	/* In case of AIOP must check the priority even for DPNI_DEST_NONE also;
	it means that the destination is the default AIOP DCP channel 0.*/
	if (cfg->dest_type == DPNI_DEST_NONE &&
		dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
		CHECK_COND_RETVAL(cfg->priority < QMAN_CHANNEL_WQ_PRIO_NUM,
		-EINVAL,
		"The priority (%d) set explicitly for AIOP must be within 0-%d\n",
		cfg->priority, QMAN_CHANNEL_WQ_PRIO_NUM - 1);
	}

	return 0;
}

static int config_ctlu_policy(struct dpni *dpni, int reset)
{
	struct dppolicy_cfg policy_cfg; /* Policy */
	struct dppolicy_rule rule; /* Policy rule */
	struct dppolicy_action action; /* Policy Action */
	int err;

	if (!dpni->restore.en) {
		memset(&policy_cfg, 0x0, sizeof(struct dppolicy_cfg));
		policy_cfg.max_num_of_rules = DPNI_POLICY_NUM_RULES;
		if (!reset) {
			dpni->policy = dppolicy_init(dpni->ing_dppolicy, /* Policy handle */
			dpni->policy_id, /* Policy ID */
			&policy_cfg); /* Policy configuration */
			if (!dpni->policy) {
				pr_err("ID[%d]: creating policy failed\n", dpni->id);
				return -ENAVAIL;
			}
		}
	}

	/* BROADCAST - skip MAC filter and go to next hop */
	memset(&rule, 0, sizeof(struct dppolicy_rule));
	memset(&action, 0, sizeof(struct dppolicy_action));
	rule.priority = DPNI_POLICY_PRI_BROADCAST;
	rule.num_of_identifiers = 1;
	rule.identifiers[0].exclude = 0;
	rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT_OPT;
	rule.identifiers[0].prot = NET_PROT_ETH;
	rule.identifiers[0].opt = NH_OPT_ETH_BROADCAST;
	copy_dptbl_to_dppolicy(&dpni->filters.mac_allow_action, &action);
	if (reset)
		err = dppolicy_modify_rule(dpni->policy, &rule, &action);
	else
		err = dppolicy_add_rule(dpni->policy, &rule, &action, dpni->restore.en);
	CHECK_COND_RETVAL( !err||(err == -ETIMEDOUT), err, "Cannot modify/add policy rule\n");

	/* MULTICAST - by default pass all multicast frames */
	memset(&rule, 0, sizeof(struct dppolicy_rule));
	memset(&action, 0, sizeof(struct dppolicy_action));
	rule.priority = DPNI_POLICY_PRI_MULTICAST;
	rule.num_of_identifiers = 1;
	rule.identifiers[0].exclude = 0;
	rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT_OPT;
	rule.identifiers[0].prot = NET_PROT_ETH;
	rule.identifiers[0].opt = NH_OPT_ETH_MULTICAST;
#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		copy_dptbl_to_dppolicy(&dpni->filters.multicast_allow_action, &action);
	}
	else {
		copy_dptbl_to_dppolicy(&dpni->filters.mac_allow_action, &action);
	}
#else
	copy_dptbl_to_dppolicy(&dpni->filters.mac_allow_action, &action);
#endif
	if (reset)
		err = dppolicy_modify_rule(dpni->policy, &rule, &action);
	else
		err = dppolicy_add_rule(dpni->policy, &rule, &action, dpni->restore.en);
	CHECK_COND_RETVAL( !err||(err == -ETIMEDOUT), err, "Cannot modify/add policy rule\n");

	/* UNICAST - go to unicast table */
	memset(&rule, 0, sizeof(struct dppolicy_rule));
	memset(&action, 0, sizeof(struct dppolicy_action));
	rule.priority = DPNI_POLICY_PRI_UNICAST;
	rule.num_of_identifiers = 1;
	rule.identifiers[0].exclude = 0;
	rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT_OPT;
	rule.identifiers[0].prot = NET_PROT_ETH;
	rule.identifiers[0].opt = NH_OPT_ETH_UNICAST;
	action.next_action = DPPOLICY_ACTION_LOOKUP;
	action.lookup_params.dpkg_profile_id = dpni->filters.mac_kid;
	dptbl_get_id(dpni->filters.mac_tbl, &action.lookup_params.dptbl_id);
	if (reset)
		err = dppolicy_modify_rule(dpni->policy, &rule, &action);
	else
		err = dppolicy_add_rule(dpni->policy, &rule, &action, dpni->restore.en);
	CHECK_COND_RETVAL( !err||(err == -ETIMEDOUT), err, "Cannot modify/add policy rule\n");

	return err;
}

static int max_tcs_for_lookps(struct dpni *dpni)
{
	if (dpni->options & DPNI_OPT_ALLOW_DIST_KEY_PER_TC)
		return dpni->max_rx_tcs;
	return 1;
}

static int config_ctlu(struct dpni *dpni, int reset)
{
	struct dpkg_profile_cfg kg_cfg;
	struct dptbl_cfg tbl_cfg;
	struct dptbl_rule rule;
	struct dptbl_action action, next_action;
#ifdef TKT508412
	struct dptbl_cfg multicast_tbl_cfg;
#endif
	uint8_t no_vlan_key[] = { 0, 0, 0 };
	int err, i;

	/* FLOW: 'start'->MAC_Filters->VLAN_Filters->QoS (->FS->hash)
	 * create the flow in reverse order */

	/* this is used to set up a default entry in classification tables
	 * until the user sets up key composition rules, entries.
	 */
	dpni->dummy_key = 0;
	dpni->dummy_rule.rule_cfg.exact.key = &dpni->dummy_key;
	dpni->dummy_rule.rule_cfg.exact.size = 1;

	memset(&next_action, 0, sizeof(struct dptbl_action));
	next_action.options = 0;
	next_action.next_action = DPTBL_ACTION_DONE;

	/* set up a dummy 1 byte key for now, can be replaced by the
	 * user.  This is used both for FS and hash */
	memset(&kg_cfg, 0, sizeof(struct dpkg_profile_cfg));
	kg_cfg.num_extracts = 1;
	kg_cfg.extracts[0].type = DPKG_EXTRACT_CONSTANT;
	kg_cfg.extracts[0].extract.constant.constant = 0;
	kg_cfg.extracts[0].extract.constant.num_of_repeats = 1;

	/* Set up hash KEY ID, a miss in FS should direct here */
	if (dpni->options & DPNI_OPT_DIST_HASH) {
		if (!IS_SHARED_FS_ENABLED) {
			for (i = 0; i < max_tcs_for_lookps(dpni); i++) {
				if (reset)
					err = dpkg_profile_modify(
						dpni->ing_dpkg,
						dpni->tc_rx[i].kid_hash,
						&kg_cfg);
				else
					err = dpkg_profile_create(
						dpni->ing_dpkg,
						dpni->tc_rx[i].kid_hash,
						&kg_cfg);

				CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
			}
		} else {
			if (reset)
				err = dpkg_profile_modify(
					dpni->ing_dpkg,
					dpni->tc_rx[0].kid_hash,
					&kg_cfg);
			else
				err = dpkg_profile_create(
					dpni->ing_dpkg,
					dpni->tc_rx[0].kid_hash,
					&kg_cfg);

			CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		}

		next_action.options |= DPTBL_ACTION_SET_HASH_KID;
	}

	if (!IS_SHARED_FS_ENABLED) {
		for (i = 0; i < dpni->max_rx_tcs; i++) {
			/* skip TCs that have 0 entries of size 0, DPTBL doesn't like
			 * them
			 */
			if (!dpni->tc_rx[i].max_fs_entries)
				continue;

			/* deal with key composition first */
			if (reset)
				err = dpkg_profile_modify(
					dpni->ing_dpkg,
					dpni->tc_rx[i].kid_fs,
					&kg_cfg);
			else
				err = dpkg_profile_create(
					dpni->ing_dpkg,
					dpni->tc_rx[i].kid_fs,
					&kg_cfg);

			CHECK_COND_RETVAL( err==0, err, "ID[%d] failed o %s dpkg profile",
					dpni->id, reset?"modify at reset":"create");

			/* per-TC we may have different KEY IDs to go on with, this is
			 * used if we miss in FS table
			 * normally we could save us the trouble and set HKID in IFP,
			 * but for now we still support different key composition rules
			 * per TC */
			next_action.hash_dpkg_profile_id = get_kid_hash(dpni,
					(uint8_t)i);

			memset(&tbl_cfg, 0, sizeof(struct dptbl_cfg));
			tbl_cfg.max_key_size =
					(uint8_t)dpni->tc_rx[i].max_dist_key_size;
			tbl_cfg.max_rules = dpni->tc_rx[i].max_fs_entries;
			if (dpni->options & DPNI_OPT_FS_MASK_SUPPORT)
				tbl_cfg.type = DPTBL_TYPE_TCAM_ACL;
			else
				tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
			tbl_cfg.action_on_miss = &next_action;
			tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
			if (reset) {
				/* Just modify miss-action */
				err = dptbl_modify_miss_action(
					dpni->tc_rx[i].fs_tbl,
					tbl_cfg.action_on_miss);
				CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
			} else {
				dpni->tc_rx[i].fs_tbl = dptbl_init(
					dpni->ing_dptbl,
					&tbl_cfg);
				CHECK_COND_RETVAL(dpni->tc_rx[i].fs_tbl, -ENAVAIL,
						"ID[%d]: creating FS table failed\n",
						dpni->id);
			}
			memcpy(&dpni->tc_rx[i].default_action, &next_action,
				sizeof(struct dptbl_action));
		}
	} else {
		if (dpni->tc_rx[0].max_fs_entries) {
			/* deal with key composition first */
			if (reset)
				err = dpkg_profile_modify(
					dpni->ing_dpkg,
					dpni->tc_rx[0].kid_fs,
					&kg_cfg);
			else
				err = dpkg_profile_create(
					dpni->ing_dpkg,
					dpni->tc_rx[0].kid_fs,
					&kg_cfg);

			CHECK_COND_RETVAL( err==0, err, "ID[%d] failed o %s dpkg profile",
					dpni->id, reset?"modify at reset":"create");
			/* per-TC we may have different KEY IDs to go on with, this is
			 * used if we miss in FS table
			 * normally we could save us the trouble and set HKID in IFP,
			 * but for now we still support different key composition rules
			 * per TC */
			next_action.hash_dpkg_profile_id = get_kid_hash(dpni,
					(uint8_t)0);

			memset(&tbl_cfg, 0, sizeof(struct dptbl_cfg));
			tbl_cfg.max_key_size =
					(uint8_t)dpni->tc_rx[0].max_dist_key_size;
			tbl_cfg.max_rules = dpni->tc_rx[0].max_fs_entries;
			if (dpni->options & DPNI_OPT_FS_MASK_SUPPORT)
				tbl_cfg.type = DPTBL_TYPE_TCAM_ACL;
			else
				tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
			tbl_cfg.action_on_miss = &next_action;
			tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
			if (reset) {
				/* Just modify miss-action */
				err = dptbl_modify_miss_action(
					dpni->tc_rx[0].fs_tbl,
					tbl_cfg.action_on_miss);
				CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
			} else {
				dpni->tc_rx[0].fs_tbl = dptbl_init(
					dpni->ing_dptbl,
					&tbl_cfg);
				CHECK_COND_RETVAL(dpni->tc_rx[0].fs_tbl, -ENAVAIL,
						"ID[%d]: creating FS table failed\n",
						dpni->id);
			}

			memcpy(&dpni->tc_rx[0].default_action, &next_action,
					sizeof(struct dptbl_action));
		}
	}

	/* used if we miss in QoS table, go to lowest prio TC by default
	 *
	 * These settings are temporary at best, notice next_action = DONE.
	 * At this time we don't follow up with FS look-ups or hashing, even
	 * if they are set-up with defaults.  The real magic is in
	 * rx_tc_dist_sequence, a matrix of operations to do when changing from
	 * one distribution mode to another (no distr -> hash or whatever).
	 * All this is unnecessarily complicated, but it's not trivial to
	 * replace everything in one go.
	 */
	memset(&next_action, 0, sizeof(struct dptbl_action));
	next_action.options = DPTBL_ACTION_SET_QPRI | DPTBL_ACTION_SET_QDBIN;
	next_action.qpri = dpni_get_rx_base_qpri(dpni);
	next_action.qd_bin = get_qdbin_from_flowid(
			dpni->tc_rx[SELECT_TC_SHARED_FS(0)].max_dist_size,
			0);
	next_action.next_action = DPTBL_ACTION_DONE;

	memset(&tbl_cfg, 0, sizeof(struct dptbl_cfg));
	if (dpni->max_rx_tcs > 1) {
		tbl_cfg.max_key_size = (uint8_t)dpni->qos.max_qos_key_size;
		tbl_cfg.max_rules = dpni->qos.max_qos_entries;
		if (dpni->options & DPNI_OPT_QOS_MASK_SUPPORT)
			tbl_cfg.type = DPTBL_TYPE_TCAM_ACL;
		else
			tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
		tbl_cfg.action_on_miss = &next_action;
		tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
		if (reset) {
			/* Just modify miss-action */
			err = dptbl_modify_miss_action(
				dpni->qos.tbl, tbl_cfg.action_on_miss);
			CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		} else {
			dpni->qos.tbl = dptbl_init(dpni->ing_dptbl, &tbl_cfg);
			if (!dpni->qos.tbl) {
				pr_err("ID[%d]: creating QoS table failed\n", dpni->id);
				return -ENAVAIL;
			}
			dpni->qos.valid = 0;
		}
	} else if (!reset) {
		/* Skip it in 'reset' mode as it shouldn't change.
		 * Create dummy QoS table */
		tbl_cfg.max_key_size = 1;
		tbl_cfg.max_rules = 1;
		tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
		tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
		dpni->qos.tbl = dptbl_init(dpni->ing_dptbl, &tbl_cfg);
		if (!dpni->qos.tbl) {
			pr_err("ID[%d]: creating QoS table failed\n", dpni->id);
			return -ENAVAIL;
		}
		err = dptbl_add_rule(dpni->qos.tbl, &dpni->dummy_rule,
					&next_action, 0);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	}
	update_pass_through_qos(dpni);

	memset(&kg_cfg, 0, sizeof(struct dpkg_profile_cfg));
	kg_cfg.num_extracts = 1;
	kg_cfg.extracts[0].type = DPKG_EXTRACT_CONSTANT;
	kg_cfg.extracts[0].extract.constant.constant = 0;
	kg_cfg.extracts[0].extract.constant.num_of_repeats = 1;
	if (reset) {
		err = dpkg_profile_modify(dpni->ing_dpkg, dpni->qos.kid,
						&kg_cfg);
	} else {
		err = dpkg_profile_create(dpni->ing_dpkg, dpni->qos.kid,
						&kg_cfg);
	}

	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);

	memcpy(&dpni->qos.default_action, &next_action,
		sizeof(struct dptbl_action));
	memset(&next_action, 0, sizeof(struct dptbl_action));
	if (dpni->is_snic) {
		struct dpkg_profile_cfg kg_cfg = { 0 };

		next_action.options = DPTBL_ACTION_SET_QPRI;
		next_action.qpri = 8;			//DPNI_RX_BASE_QPRI;
		next_action.options |= DPTBL_ACTION_SET_OPAQUE;
		next_action.opaque = 0;
		next_action.next_action = DPTBL_ACTION_DONE;

		/* 3-Tuple for hashing */
		kg_cfg.num_extracts = 3;
		kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[0].extract.from_hdr.prot = NET_PROT_IP;
		kg_cfg.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[0].extract.from_hdr.field = NH_FLD_IP_SRC;
		kg_cfg.extracts[1].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[1].extract.from_hdr.prot = NET_PROT_IP;
		kg_cfg.extracts[1].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[1].extract.from_hdr.field = NH_FLD_IP_DST;
		kg_cfg.extracts[2].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[2].extract.from_hdr.prot = NET_PROT_IP;
		kg_cfg.extracts[2].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[2].extract.from_hdr.field = NH_FLD_IP_PROTO;

		if (!reset) {
			err = dpkg_profile_create(dpni->ing_dpkg,
							dpni->snic.hash_kid,
							&kg_cfg);
			CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		}
	} else {
		next_action.next_action = DPTBL_ACTION_LOOKUP;
		dptbl_get_id(dpni->qos.tbl,
				&next_action.lookup_params.dptbl_id);
		next_action.lookup_params.dpkg_profile_id = dpni->qos.kid;
	}

	if (dpni->options & DPNI_OPT_VLAN_FILTER) {
		memset(&kg_cfg, 0, sizeof(struct dpkg_profile_cfg));
		kg_cfg.num_extracts = 2;
		/* catch if VALN exist */
		kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_CONTEXT;
		kg_cfg.extracts[0].extract.from_context.src =
			DPKG_FROM_PARSE_RESULT_SPECIFIC_PROTOCOL;
		kg_cfg.extracts[0].extract.from_context.size = 1;
		kg_cfg.extracts[0].extract.from_context.offset = 4 + 2;
		kg_cfg.extracts[0].num_of_byte_masks = 1;
		kg_cfg.extracts[0].masks[0].mask = 0x04;
		/* extract VLAN TCI */
		kg_cfg.extracts[1].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[1].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[1].extract.from_hdr.prot = NET_PROT_VLAN;
		kg_cfg.extracts[1].extract.from_hdr.field = NH_FLD_VLAN_TCI;
		kg_cfg.extracts[1].num_of_byte_masks = 1;
		kg_cfg.extracts[1].masks[0].mask = 0x0f;
		if (!reset) {
			err = dpkg_profile_create(dpni->ing_dpkg,
							dpni->filters.vlan_kid,
							&kg_cfg);
			CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		}

		memset(&tbl_cfg, 0, sizeof(struct dptbl_cfg));
		tbl_cfg.max_key_size = 3; /* VLAN exist + VLAN TCI size */
		tbl_cfg.max_rules =
			(uint32_t)(dpni->filters.max_vlan_filters + 1) /* for the non-vlan key */;
		tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
		tbl_cfg.action_on_miss = &next_action;
		tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
		memcpy(&dpni->filters.vlan_allow_action, &next_action,
			sizeof(struct dptbl_action));
		memset(&dpni->filters.vlan_disallow_action, 0,
			sizeof(struct dptbl_action));
		dpni->filters.vlan_disallow_action.next_action =
			DPTBL_ACTION_DONE;
		dpni->filters.vlan_disallow_action.options =
			DPTBL_ACTION_SET_DISCARD_FLAG;

		if (reset) {
			/* Just modify miss-action */
			err = dptbl_modify_miss_action(
				dpni->filters.vlan_tbl,
				tbl_cfg.action_on_miss);
			CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		} else {
			dpni->filters.vlan_tbl = dptbl_init(dpni->ing_dptbl,
								&tbl_cfg);
			if (!dpni->filters.vlan_tbl) {
				pr_err("ID[%d]: creating VLAN table failed\n", dpni->id);
				return -ENAVAIL;
			}

			/* Add RULE to catch non VLAN frames to skip the filter */
			memset(&rule, 0, sizeof(struct dptbl_rule));
			rule.rule_cfg.exact.key = no_vlan_key;
			rule.rule_cfg.exact.size = 3;
			err = dptbl_add_rule(
				dpni->filters.vlan_tbl, &rule,
				&dpni->filters.vlan_allow_action, 0);
			CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		}
		memset(&next_action, 0, sizeof(struct dptbl_action));
		next_action.next_action = DPTBL_ACTION_LOOKUP;
		dptbl_get_id(dpni->filters.vlan_tbl,
				&next_action.lookup_params.dptbl_id);
		next_action.lookup_params.dpkg_profile_id =
			dpni->filters.vlan_kid;
	}

	/* UNICAST Filters */
	memset(&tbl_cfg, 0, sizeof(struct dptbl_cfg));
	tbl_cfg.max_key_size = 6; /* MAC ADDR size */
	tbl_cfg.max_rules = 2; /* Need at least 2 for the primary
	 and for the option to modify it */
	if (dpni->options & DPNI_OPT_UNICAST_FILTER)
		tbl_cfg.max_rules += dpni->filters.max_unicast_filters;
	if (dpni->options & DPNI_OPT_MULTICAST_FILTER)
		tbl_cfg.max_rules += dpni->filters.max_multicast_filters;
	tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
	tbl_cfg.options = DPTBL_OPTIONS_OPTIMIZIED_DISCARD;
	tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
	memset(&action, 0, sizeof(struct dptbl_action));
	action.next_action = DPTBL_ACTION_DONE;
	tbl_cfg.action_on_miss = &action;
	if (!reset) {
		dpni->filters.mac_tbl = dptbl_init(dpni->ing_dptbl, &tbl_cfg);
		if (!dpni->filters.mac_tbl) {
			pr_err("ID[%d]: creating UNICAST table failed\n", dpni->id);
			return -ENAVAIL;
		}
	}

#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		memset(&multicast_tbl_cfg, 0, sizeof(multicast_tbl_cfg));
		multicast_tbl_cfg.max_key_size = 6; /* MAC ADDR size */
		multicast_tbl_cfg.max_rules = 2;
		multicast_tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
		multicast_tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
		multicast_tbl_cfg.action_on_miss = &next_action;

		if( !reset ) {
			dpni->filters.fc_multicast_tbl = dptbl_init(dpni->ing_dptbl, &multicast_tbl_cfg);
			CHECK_COND_RETVAL( dpni->filters.fc_multicast_tbl!=NULL, -ENAVAIL,
					"ID[%d]: creating MULTICAST table failed\n", dpni->id);
		}
	}
#endif

	/* MAC (both unicast&multicast) Filters */
	memset(&kg_cfg, 0, sizeof(struct dpkg_profile_cfg));
	kg_cfg.num_extracts = 1;
	kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[0].extract.from_hdr.prot = NET_PROT_ETH;
	kg_cfg.extracts[0].extract.from_hdr.field = NH_FLD_ETH_DA;
	if (!reset) {
		err = dpkg_profile_create(dpni->ing_dpkg,
						dpni->filters.mac_kid,
						&kg_cfg);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	}

	memcpy(&dpni->filters.mac_allow_action, &next_action,
		sizeof(struct dptbl_action));

#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		memset(&next_action, 0, sizeof(struct dptbl_action));
		next_action.next_action = DPTBL_ACTION_LOOKUP;
		dptbl_get_id(dpni->filters.fc_multicast_tbl,
				&next_action.lookup_params.dptbl_id);
		next_action.lookup_params.dpkg_profile_id =
			dpni->filters.mac_kid;
		memcpy(&dpni->filters.multicast_allow_action, &next_action,
				sizeof(struct dptbl_action));
	}
#endif

	/* Add Primary mac address to the filter table */
	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = dpni->mac_addr;
	rule.rule_cfg.exact.size = 6;
	if (!reset) {
		err = dptbl_add_rule(dpni->filters.mac_tbl, &rule,
					&dpni->filters.mac_allow_action, 0);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	}

	if (dpni->is_ing_parser_id_allocated) {
		err = dpparser_init_profile(dpni->ing_dpparser,
						dpni->ing_parser_id, NULL,
						NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		/* Attach ingress soft parser */
		err = dpparser_attach_soft_parser(dpni->ing_dpparser, dpni->ing_sp_prof,
							dpni->ing_parser_id,
							&dpni->ing_start_hxs,
							0, NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		if (dpni->ing_start_hxs)
			pr_info("WRIOP INGRESS start HXS set to 0x%x\n",
				dpni->ing_start_hxs);
	}

	if (dpni->is_egr_parser_id_allocated) {
		err = dpparser_init_profile(dpni->egr_dpparser,
						dpni->egr_parser_id, NULL,
						NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		/* Attach egress soft parser */
		err = dpparser_attach_soft_parser(dpni->egr_dpparser, dpni->egr_sp_prof,
							dpni->egr_parser_id,
							&dpni->egr_start_hxs,
							1, NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		if (dpni->egr_start_hxs)
			pr_info("WRIOP EGRESS start HXS set to 0x%x\n",
				dpni->egr_start_hxs);
	}

	err = config_ctlu_policy(dpni, reset);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);

	return 0;
}

static void delete_ctlu(struct dpni *dpni)
{
	int i;

	if (dpni->options & DPNI_OPT_DIST_HASH) {
		if (!IS_SHARED_FS_ENABLED) {
			for (i=0; i<max_tcs_for_lookps(dpni); i++)
				dpkg_profile_delete(dpni->ing_dpkg,
					dpni->tc_rx[i].kid_hash);
		} else
			dpkg_profile_delete(dpni->ing_dpkg,
					    dpni->tc_rx[0].kid_hash);
	}
	if (dpni->options & DPNI_OPT_DIST_FS) {
		if (!IS_SHARED_FS_ENABLED) {
			for (i=0; i<dpni->max_rx_tcs; i++)
				dpkg_profile_delete(dpni->ing_dpkg,
					dpni->tc_rx[i].kid_fs);
		} else
			dpkg_profile_delete(dpni->ing_dpkg,
						dpni->tc_rx[0].kid_fs);
	}

	for (i = 0; i < dpni->max_rx_tcs; i++)
		if (dpni->tc_rx[i].fs_tbl)
			dptbl_delete(dpni->tc_rx[i].fs_tbl);


	if (dpni->qos.tbl) {
		dpkg_profile_delete(dpni->ing_dpkg, dpni->qos.kid);
		dptbl_delete(dpni->qos.tbl);
	}

	if (dpni->filters.vlan_tbl) {
		dpkg_profile_delete(dpni->ing_dpkg, dpni->filters.vlan_kid);
		dptbl_delete(dpni->filters.vlan_tbl);
	}

	if (dpni->filters.mac_tbl) {
		dpkg_profile_delete(dpni->ing_dpkg, dpni->filters.mac_kid);
		dptbl_delete(dpni->filters.mac_tbl);
	}

#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		if (dpni->filters.fc_multicast_tbl) {
				dptbl_delete(dpni->filters.fc_multicast_tbl);
			}
	}
#endif

	if (dpni->is_ing_parser_id_allocated)
		dpparser_delete_profile(dpni->ing_dpparser,
					dpni->ing_parser_id, NULL);

	if (dpni->is_egr_parser_id_allocated)
		dpparser_delete_profile(dpni->egr_dpparser,
					dpni->egr_parser_id, NULL);

	if (dpni->policy)
		dppolicy_done(dpni->policy);


}

static void config_eiop_ifps_pools(struct dpni *dpni)
{
	struct eiop_ifp_tx_pcd_cfg tx_params;
	struct eiop_ifp_rx_pcd_cfg rx_params;
	struct dpbp_attr attr;
	uint32_t lfqid;
	int err, i;

#ifdef MC_CLI
    if(dpni->options & DPNI_OPT_RX_TX_HW_ECHO)
        dpni->mem_ifp_info->init.default_cfg.qd_id = (int)dpni->tx_virt_qdid;
    else
        dpni->mem_ifp_info->init.default_cfg.qd_id = (int)dpni->rx_virt_qdid;
#else
    dpni->mem_ifp_info->init.default_cfg.qd_id = (int)dpni->rx_virt_qdid;
#endif

	dpni->mem_ifp_info->init.default_cfg.options =
		EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_OPAQUE;
	dpni->mem_ifp_info->init.default_cfg.opaque = dpni->rx_err.flc_opaque;
	if (dpni->rx_err.flc_type == DPNI_FLC_STASH)
		dpni->mem_ifp_info->init.default_cfg.options |=
			EIOP_IFP_DEFAULT_CFG_OPT_SET_STASHING_CNTRL;
	if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
		dpni->mem_ifp_info->init.default_cfg.options |=
			EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_FOR_AIOP;
		/* SET EPID, APPID = 0 */
		dpni->mem_ifp_info->init.default_cfg.opaque = dpni->epid;
	}

	if (dpni->en_header_stashing)
		dpni->mem_ifp_info->init.defcfg.options |= EIOP_IFP_DEFCFG_OPT_SET_HEADER_STASHING;
	else
		dpni->mem_ifp_info->init.defcfg.options &= ~EIOP_IFP_DEFCFG_OPT_SET_HEADER_STASHING;
	if (dpni->en_payload_stashing)
		dpni->mem_ifp_info->init.defcfg.options |= EIOP_IFP_DEFCFG_OPT_SET_PAYLOAD_STASHING;
	else
		dpni->mem_ifp_info->init.defcfg.options &= ~EIOP_IFP_DEFCFG_OPT_SET_PAYLOAD_STASHING;

	dpni->mem_ifp_info->init.rx_err_fqid = (int)dpni->rx_err.virt_fqid;
	dpni->mem_ifp_info->init.tx_err_fqid =
		(int)dpni->tx_conf_err.queue_info.virt_fqid;

	if (dpni->dev_ctx.amq.bdi)
		dpni->mem_ifp_info->init.defcfg.options |=
			EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION;
	if (dpni->dev_ctx.amq.pl)
		dpni->mem_ifp_info->init.defcfg.options |=
			EIOP_IFP_DEFCFG_OPT_SET_PRIVIL_LEVEL;
	if (dpni->dev_ctx.amq.va)
		dpni->mem_ifp_info->init.defcfg.options |=
			EIOP_IFP_DEFCFG_OPT_SET_VIRT_ADDR;
	
	dpni->mem_ifp_info->init.defcfg.icid = dpni->dev_ctx.amq.icid;
	dpni->mem_ifp_info->init.max_frame_length = dpni->mfl;

	memset(&attr, 0, sizeof(struct dpbp_attr));
	/* Main pools */
	if (dpni->pools_cfg.pool_as)
		dpni->mem_ifp_info->init.defcfg.options |=
					EIOP_IFP_DEFCFG_OPT_SET_BUFFER_POOL_ON_QDBIN;
	dpni->mem_ifp_info->init.num_of_pools_used = dpni->pools_cfg.num_dpbp;
	for (i = 0; i < dpni->pools_cfg.num_dpbp; i++) {
		dpbp_get_attributes(dpni->pools_cfg.pools[i].dpbp, &attr);
		dpni->mem_ifp_info->init.pools_cfg[i].id = attr.bpid;
		dpni->mem_ifp_info->init.pools_cfg[i].size =
			dpni->pools_cfg.pools[i].buffer_size;
		dpni->mem_ifp_info->init.pools_cfg[i].priority_mask = dpni->pools_cfg.pools[i].priority;
		if (dpni->dev_ctx.amq.bmt)
			dpni->mem_ifp_info->init.pools_cfg[i].options |=
				EIOP_IFP_BUF_POOL_OPT_BMT;
	}

	/* Backup pools */
	if (dpni->backup_pools_cfg.pool_as)
		dpni->mem_ifp_info->init.defcfg.options |=
					EIOP_IFP_DEFCFG_OPT_SET_BUFFER_POOL_ON_QDBIN;
	dpni->mem_ifp_info->init.defcfg.num_of_backup_pools_used =
		dpni->backup_pools_cfg.num_dpbp;
	for (i = 0; i < dpni->backup_pools_cfg.num_dpbp; i++) {
		dpbp_get_attributes(dpni->backup_pools_cfg.pools[i].dpbp,
					&attr);
		dpni->mem_ifp_info->init.defcfg.backup_pool_cfg[i].id =
			attr.bpid;
		dpni->mem_ifp_info->init.defcfg.backup_pool_cfg[i].size =
			dpni->backup_pools_cfg.pools[i].buffer_size;
		if (dpni->dev_ctx.amq.bmt)
			dpni->mem_ifp_info->init.defcfg.backup_pool_cfg[i].options |=
				EIOP_IFP_BUF_POOL_OPT_BMT;
	}

	/* S-NIC adaption */
	if (dpni->is_snic) {
		dpni->mem_ifp_info->init.max_frame_length = DPNI_SNIC_MAX_MFL;

		dpni->snic.ingress_ifp_info->init.default_cfg.options |=
			EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_OPAQUE;
		dpni->snic.ingress_ifp_info->init.default_cfg.options |=
			EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_FOR_AIOP;
		dpni->snic.ingress_ifp_info->init.default_cfg.opaque =
			dpni->snic.epid;
		/* Fragments will use backup pool */
		dpni->snic.ingress_ifp_info->init.default_cfg.options |=
			EIOP_IFP_DEFAULT_CFG_OPT_SET_IPRE;

		dpni->snic.ingress_ifp_info->init.default_cfg.qd_id =
			(int)dpni->snic.pre_aiop_virt_qdid;
		lfqid = qbman_lfqid_compose_ex(
			dpni->ceetmid,
			(uint16_t)dpni->snic.ing_post_aiop.lfqidx);
		dpni->snic.ingress_ifp_info->init.rx_err_fqid = (int)lfqid;
		dpni->snic.ingress_ifp_info->init.tx_err_fqid =
			(int)dpni->tx_conf_err.queue_info.virt_fqid;
		if (dpni->snic.mc_amq.bdi)
			dpni->snic.ingress_ifp_info->init.defcfg.options |=
				EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION;
		if (dpni->snic.mc_amq.pl)
			dpni->snic.ingress_ifp_info->init.defcfg.options |=
				EIOP_IFP_DEFCFG_OPT_SET_PRIVIL_LEVEL;
		if (dpni->snic.mc_amq.va)
			dpni->snic.ingress_ifp_info->init.defcfg.options |=
				EIOP_IFP_DEFCFG_OPT_SET_VIRT_ADDR;
		dpni->snic.ingress_ifp_info->init.defcfg.icid =
			dpni->snic.mc_amq.icid;
		dpni->snic.ingress_ifp_info->init.max_frame_length = dpni->mfl;

		dpni->snic.ingress_ifp_info->init.num_of_pools_used = 1;
		/* main pool PEB */
		dpni->snic.ingress_ifp_info->init.pools_cfg[0].id =
			(int)dpni->snic.peb_virt_bpid;
		dpni->snic.ingress_ifp_info->init.pools_cfg[0].size =
			DPNI_SNIC_PEB_BUFFER_SIZE;
		if (dpni->snic.mc_amq.bmt)
			dpni->snic.ingress_ifp_info->init.pools_cfg[0].options |=
				EIOP_IFP_BUF_POOL_OPT_BMT;
		dpni->snic.ingress_ifp_info->init.defcfg.num_of_backup_pools_used =
			1;
		/* Backup pool DDR:
		 * 1. will always be used by fragments
		 * 2. will be used when main memory depleted */
		dpni->snic.ingress_ifp_info->init.defcfg.backup_pool_cfg[0].id =
			(int)dpni->snic.ddr_virt_bpid;
		dpni->snic.ingress_ifp_info->init.defcfg.backup_pool_cfg[0].size =
			DPNI_SNIC_DDR_BUFFER_SIZE;
		if (dpni->snic.mc_amq.bmt)
			dpni->snic.ingress_ifp_info->init.defcfg.backup_pool_cfg[0].options |=
				EIOP_IFP_BUF_POOL_OPT_BMT;
#ifdef ERR009354
		dpni->snic.ingress_ifp_info->init.defcfg.rx_buf_layout.data_align =
			256;
#endif /* ERR009354 */

		dpni->snic.ingress_ifp_info->init.defcfg.rx_buf_layout.pass_fas =
			dpni->snic.pass_fas;
		dpni->mem_ifp_info->init.defcfg.tx_buf_layout.pass_fas =
			dpni->snic.pass_fas;

		err = eiop_ifp_init_pools(&dpni->snic.ingress_ifp_info->ifp_desc,
					&dpni->snic.ingress_ifp_info->init);
		ASSERT_COND(!err || (err == -ETIMEDOUT));

		dpni->snic.egress_ifp_info->init.default_cfg.options |=
			EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_OPAQUE;
		dpni->snic.egress_ifp_info->init.default_cfg.options |=
			EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_FOR_AIOP;
		dpni->snic.egress_ifp_info->init.default_cfg.opaque =
			dpni->snic.epid;

		dpni->snic.egress_ifp_info->init.default_cfg.qd_id =
			(int)dpni->snic.pre_aiop_virt_qdid;
		dpni->snic.egress_ifp_info->init.rx_err_fqid =
			dpni->snic.egress_ifp_info->init.tx_err_fqid =
				(int)dpni->tx_conf_err.queue_info.virt_fqid;
		if (dpni->snic.mc_amq.bdi)
			dpni->snic.egress_ifp_info->init.defcfg.options |=
				EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION;
		if (dpni->snic.mc_amq.pl)
			dpni->snic.egress_ifp_info->init.defcfg.options |=
				EIOP_IFP_DEFCFG_OPT_SET_PRIVIL_LEVEL;
		if (dpni->snic.mc_amq.va)
			dpni->snic.egress_ifp_info->init.defcfg.options |=
				EIOP_IFP_DEFCFG_OPT_SET_VIRT_ADDR;
		dpni->snic.egress_ifp_info->init.defcfg.icid =
			dpni->snic.mc_amq.icid;
		dpni->snic.egress_ifp_info->init.max_frame_length =
			DPNI_SNIC_MAX_MFL;

		/* main pool PEB */
		dpni->snic.egress_ifp_info->init.num_of_pools_used = 1;
		dpni->snic.egress_ifp_info->init.pools_cfg[0].id =
			(int)dpni->snic.peb_virt_bpid;
		dpni->snic.egress_ifp_info->init.pools_cfg[0].size =
			DPNI_SNIC_PEB_BUFFER_SIZE;
		if (dpni->snic.mc_amq.bmt)
			dpni->snic.egress_ifp_info->init.pools_cfg[0].options |=
				EIOP_IFP_BUF_POOL_OPT_BMT;

		/* Backup pool DDR:
		 * will be used when main memory depleted */
		dpni->snic.egress_ifp_info->init.defcfg.backup_pool_cfg[0].id =
			(int)dpni->snic.ddr_virt_bpid;
		dpni->snic.egress_ifp_info->init.defcfg.backup_pool_cfg[0].size =
			DPNI_SNIC_DDR_BUFFER_SIZE;
		if (dpni->snic.mc_amq.bmt)
			dpni->snic.egress_ifp_info->init.defcfg.backup_pool_cfg[0].options |=
				EIOP_IFP_BUF_POOL_OPT_BMT;

		if ((dpni->options & DPNI_OPT_VLAN_MANIPULATION)
			|| (dpni->options & DPNI_OPT_IPSEC)) {
			/* Instruct the IFP to copy the 8B to AIOP */
			dpni->snic.egress_ifp_info->init.defcfg.tx_buf_layout.pass_sw_opaque =
				1;
			dpni->snic.egress_ifp_info->init.defcfg.rx_buf_layout.pass_sw_opaque =
				1;
			/* At least 4B to hold the VLAN header to avoid S/G */
			dpni->snic.egress_ifp_info->init.defcfg.rx_buf_layout.data_headroom =
				4;
		}
	}
#ifdef ERR009354
		dpni->snic.egress_ifp_info->init.defcfg.rx_buf_layout.data_align =
			256;
#endif /* ERR009354 */

		err = eiop_ifp_init_pools(&dpni->snic.egress_ifp_info->ifp_desc,
					&dpni->snic.egress_ifp_info->init);
		ASSERT_COND(!err || (err == -ETIMEDOUT));

	//Check if data align is 64 aligned
	if (dpni->mem_ifp_info->init.defcfg.rx_buf_layout.data_align % 64 ||
			dpni->mem_ifp_info->init.defcfg.rx_buf_layout.data_align == 0) {
		dpni->mem_ifp_info->init.defcfg.options &= ~EIOP_IFP_DEFCFG_OPT_SET_WRITE_OPTIMIZE;
		pr_warn("ID[%d]: data_align %d is not a multiple of 64. Write optimize will not be set \n", dpni->id,
            dpni->mem_ifp_info->init.defcfg.rx_buf_layout.data_align);
	} else {
		dpni->mem_ifp_info->init.defcfg.options |= EIOP_IFP_DEFCFG_OPT_SET_WRITE_OPTIMIZE;
	}

	err = eiop_ifp_init_pools(&dpni->mem_ifp_info->ifp_desc,
				&dpni->mem_ifp_info->init);
	ASSERT_COND(!err || (err == -ETIMEDOUT));
	
	/* Setup Egress flow */
	memset(&tx_params, 0, sizeof(struct eiop_ifp_tx_pcd_cfg));
	tx_params.activate_modules = EIOP_IFP_ACTIVATE_MODULE_PARSER;
	tx_params.parser.start_hxs = dpni->egr_start_hxs;
	tx_params.parser.profile_id = dpni->egr_parser_id;
	err = eiop_ifp_tx_pcd_set(&dpni->mem_ifp_info->ifp_desc, &tx_params);
	ASSERT_COND(!err || (err == -ETIMEDOUT));

	/* S-NIC adaption */
	if (dpni->is_snic) {
		memset(&tx_params, 0, sizeof(struct eiop_ifp_tx_pcd_cfg));
		tx_params.activate_modules = EIOP_IFP_ACTIVATE_MODULE_PARSER;
		tx_params.parser.start_hxs = dpni->egr_start_hxs;
		tx_params.parser.profile_id = dpni->egr_parser_id;
		err = eiop_ifp_tx_pcd_set(
			&dpni->snic.egress_ifp_info->ifp_desc, &tx_params);
		ASSERT_COND(!err || (err == -ETIMEDOUT));

		err = eiop_ifp_tx_pcd_set(
			&dpni->snic.ingress_ifp_info->ifp_desc, &tx_params);
		ASSERT_COND(!err || (err == -ETIMEDOUT));

		/* Activate HASH in HFNIC */
		memset(&rx_params, 0, sizeof(struct eiop_ifp_rx_pcd_cfg));
		rx_params.activate_modules =
			EIOP_IFP_ACTIVATE_MODULE_PARSER
			| EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION;
		rx_params.parser.start_hxs = dpni->ing_start_hxs;
		rx_params.parser.profile_id = dpni->ing_parser_id;
		rx_params.default_hash_generation.profile_id =
			dpni->snic.hash_kid;
		err = eiop_ifp_rx_pcd_set(
			&dpni->snic.egress_ifp_info->ifp_desc, &rx_params);
		ASSERT_COND(!err || (err == -ETIMEDOUT));
	}
	
	/* Setup Ingress flow */
	memset(&rx_params, 0, sizeof(struct eiop_ifp_rx_pcd_cfg));
	rx_params.activate_modules = (EIOP_IFP_ACTIVATE_MODULE_PARSER
					| EIOP_IFP_ACTIVATE_MODULE_POLICY
					| EIOP_IFP_ACTIVATE_MODULE_LOOKUP);
	rx_params.parser.start_hxs = dpni->ing_start_hxs;
	rx_params.parser.profile_id = dpni->ing_parser_id;
	rx_params.policy.profile_id = dpni->policy_id;
	rx_params.default_lookup.dpkg_profile_id = dpni->filters.mac_kid;
	dptbl_get_id(dpni->filters.mac_tbl,
			&rx_params.default_lookup.dptbl_id);

	if (dpni->l3_chksum_valid)
		rx_params.parser.rx_options |=
			EIOP_IFP_PARSER_RX_OPT_L3_CHECKSUM_VALIDATE;
	if (dpni->l4_chksum_valid)
		rx_params.parser.rx_options |=
			EIOP_IFP_PARSER_RX_OPT_L4_CHECKSUM_VALIDATE;

	if (!dpni->is_snic) {
		if (dpni->options & DPNI_OPT_DIST_HASH) {
			rx_params.activate_modules |=
				EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION;
			rx_params.default_hash_generation.profile_id =
				dpni->tc_rx[0].kid_hash;
		}
		if (dpni->max_policers) {
			rx_params.activate_modules |=
				EIOP_IFP_ACTIVATE_MODULE_POLICER;
			/* set "dummy" policer-id */
			rx_params.default_policer.profile_id =
				dpmng_get_plcrid(dpni->dpmng);
		}
	} else {
		/* Activate HASH in HFNIC */
		rx_params.activate_modules |=
			EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION;
		rx_params.default_hash_generation.profile_id =
			dpni->snic.hash_kid;
	}

	err = eiop_ifp_rx_pcd_set(&dpni->snic.ingress_ifp_info->ifp_desc,
					&rx_params);
	ASSERT_COND(!err || (err == -ETIMEDOUT));

	/* S-NIC adaption */
	if (dpni->is_snic) {
		memset(&rx_params, 0, sizeof(struct eiop_ifp_rx_pcd_cfg));
		rx_params.activate_modules =
			EIOP_IFP_ACTIVATE_MODULE_PARSER
			| EIOP_IFP_ACTIVATE_MODULE_LOOKUP;
		rx_params.parser.start_hxs = dpni->ing_start_hxs;
		rx_params.parser.profile_id = dpni->ing_parser_id;
		if (dpni->l3_chksum_valid)
			rx_params.parser.rx_options |=
				EIOP_IFP_PARSER_RX_OPT_L3_CHECKSUM_VALIDATE;
		if (dpni->l4_chksum_valid)
			rx_params.parser.rx_options |=
				EIOP_IFP_PARSER_RX_OPT_L4_CHECKSUM_VALIDATE;

		rx_params.default_lookup.dpkg_profile_id = dpni->qos.kid;
		dptbl_get_id(dpni->qos.tbl,
				&rx_params.default_lookup.dptbl_id);

		if (dpni->options & DPNI_OPT_DIST_HASH) {
			rx_params.activate_modules |=
				EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION;
			rx_params.default_hash_generation.profile_id =
				dpni->tc_rx[0].kid_hash;
		}

		if (dpni->max_policers) {
			rx_params.activate_modules |=
				EIOP_IFP_ACTIVATE_MODULE_POLICER;
			/* set "dummy" policer-id */
			rx_params.default_policer.profile_id =
				dpmng_get_plcrid(dpni->dpmng);
		}

		err = eiop_ifp_rx_pcd_set(&dpni->mem_ifp_info->ifp_desc,
						&rx_params);
		ASSERT_COND(!err || (err == -ETIMEDOUT));
	}
}

static void config_eiop_ifp_egress(struct dpni *dpni)
{
	int err;

	dpni->mem_ifp_info->init.tx_err_fqid =
		(int)dpni->tx_conf_err.queue_info.virt_fqid;


	/* S-NIC adaption */
	if (dpni->is_snic) {
		dpni->snic.ingress_ifp_info->init.tx_err_fqid =
			(int)dpni->tx_conf_err.queue_info.virt_fqid;

		dpni->mem_ifp_info->init.defcfg.tx_buf_layout.pass_fas =
			dpni->snic.pass_fas;

		err = eiop_ifp_init_egress(&dpni->snic.ingress_ifp_info->ifp_desc,
					&dpni->snic.ingress_ifp_info->init);
		ASSERT_COND(!err || (err == -ETIMEDOUT));

		err = eiop_ifp_set_enqueue_ifp(
			&dpni->snic.ingress_ifp_info->ifp_desc,
			dpni->snic.ingress_ifp_info->next_ifpid);
		ASSERT_COND(!err || (err == -ETIMEDOUT));

		dpni->snic.egress_ifp_info->init.rx_err_fqid =
			dpni->snic.egress_ifp_info->init.tx_err_fqid =
				(int)dpni->tx_conf_err.queue_info.virt_fqid;

		if ((dpni->options & DPNI_OPT_VLAN_MANIPULATION)
			|| (dpni->options & DPNI_OPT_IPSEC)) {
			/* Instruct the IFP to copy the 8B to AIOP */
			dpni->snic.egress_ifp_info->init.defcfg.tx_buf_layout.pass_sw_opaque =
				1;
			dpni->snic.egress_ifp_info->init.defcfg.rx_buf_layout.pass_sw_opaque =
				1;
			/* At least 4B to hold the VLAN header to avoid S/G */
			dpni->snic.egress_ifp_info->init.defcfg.rx_buf_layout.data_headroom =
				4;
		}

		err = eiop_ifp_init_egress(&dpni->snic.egress_ifp_info->ifp_desc,
					&dpni->snic.egress_ifp_info->init);
		ASSERT_COND(!err || (err == -ETIMEDOUT));

		err = eiop_ifp_set_enqueue_ifp(
			&dpni->snic.egress_ifp_info->ifp_desc,
			dpni->snic.egress_ifp_info->next_ifpid);
		ASSERT_COND(!err || (err == -ETIMEDOUT));
	}
	
	err = eiop_ifp_init_egress(&dpni->mem_ifp_info->ifp_desc,
				&dpni->mem_ifp_info->init);
	ASSERT_COND(!err || (err == -ETIMEDOUT));
}

static int config_aiop_spids(struct dpni *dpni)
{
	struct dpbp_attr attr;
	struct aiop_sp_cfg sp_cfg;
	int err, i;

	memset(&sp_cfg, 0, sizeof(struct aiop_sp_cfg));
	sp_cfg.bdi = dpni->dev_ctx.amq.bdi;
	sp_cfg.pl = dpni->dev_ctx.amq.pl;
	sp_cfg.icid = dpni->dev_ctx.amq.icid;
	sp_cfg.virt_addr = dpni->dev_ctx.amq.va;
	sp_cfg.frame_format = SP_FF_SINGLE_BUF_OR_SG;
	sp_cfg.pass_thru_ann_room =
		dpni->mem_ifp_info->init.defcfg.rx_buf_layout.priv_data_size;
	eiop_ifp_get_hw_annotation_room(&dpni->mem_ifp_info->ifp_desc,
					&sp_cfg.accel_specific_ann_room);
	sp_cfg.data_head_room =
		dpni->mem_ifp_info->init.defcfg.rx_buf_layout.data_headroom;
	sp_cfg.data_length =
		dpni->mem_ifp_info->init.defcfg.rx_buf_layout.data_tailroom;

	/* Main SP */
	sp_cfg.num_pools = dpni->pools_cfg.num_dpbp;
	for (i = 0; i < sp_cfg.num_pools; i++) {
		dpbp_get_attributes(dpni->pools_cfg.pools[i].dpbp, &attr);
		sp_cfg.bp_cfg[i].bmt = dpni->dev_ctx.amq.bmt;
		sp_cfg.bp_cfg[i].bpid = attr.bpid;
		sp_cfg.bp_cfg[i].bp_size =
			dpni->pools_cfg.pools[i].buffer_size;
	}

	err = aiop_tile_set_storage_profile(dpni->aiop_tile,
						(uint32_t)dpni->spid, &sp_cfg);
	if (err) {
		pr_err("ID[%d]: aiop_tile_set_storage_profile failed\n", dpni->id);
		return err;
	}

	/* Backup SP */
	if (dpni->backup_pools_cfg.num_dpbp) {
		sp_cfg.num_pools = dpni->backup_pools_cfg.num_dpbp;
		for (i = 0; i < sp_cfg.num_pools; i++) {
			dpbp_get_attributes(
				dpni->backup_pools_cfg.pools[i].dpbp, &attr);
			sp_cfg.bp_cfg[i].bmt = dpni->dev_ctx.amq.bmt;
			sp_cfg.bp_cfg[i].bpid = attr.bpid;
			sp_cfg.bp_cfg[i].bp_size =
				dpni->backup_pools_cfg.pools[i].buffer_size;
		}

		err = aiop_tile_set_storage_profile(
			dpni->aiop_tile, (uint32_t)dpni->backup_spid, &sp_cfg);
		if (err) {
			pr_err("ID[%d]: aiop_tile_set_storage_profile failed\n", dpni->id);
			return err;
		}
	}

	return 0;
}

/* Computes the internal priority or WQ id within a DCP channel for a
traffic class based on the current max number of traffic classes
configured for the dpni. The function uses a static mapping of TCs to WQs,
respecting the 4 strict priority levels from recognized by Qman
WQ class scheduler: high (WQ[0..1]), med (WQ[2..5]) and low (WQ[6..7]). */
static uint8_t get_dcp_channel_wq_priority(struct dpni *dpni, uint8_t tc) {
//How to read the matrix:
//- DPNI TC number = row number + 1 (must be [0..7])
//- User priority or traffic class = column number (must be [0..7])
//- Each cell represent a WQ id
	static uint8_t tc_to_wqid[DPNI_MAX_RX_TC][DPNI_MAX_RX_TC] = {
	{7,   7, 7, 7, 7, 7, 7, 7},
	{0, 7,   7, 7, 7, 7, 7, 7},
	{0, 1, 7,   7, 7, 7, 7, 7},
	{0, 1, 2, 7,   7, 7, 7, 7},
	{0, 1, 2, 4, 7,   7, 7, 7},
	{0, 1, 2, 4, 6, 7,   7, 7},
	{0, 1, 2, 4, 5, 6, 7,   7},
	{0, 1, 2, 3, 4, 5, 6, 7  }};
	CHECK_COND_RETVAL(dpni->max_rx_tcs > tc, DPNI_DEFAULT_DCP_WQID,
	"tc value %d exceeds max configured TC value %d;"
	"use default value (%d) instead\n",
	tc, dpni->max_rx_tcs, DPNI_DEFAULT_DCP_WQID);
	return tc_to_wqid[dpni->max_rx_tcs - 1][tc];
}

static int config_fqid(struct dpni *dpni, struct dpni_rx_queue_info *rx_queue)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	struct qbman_attr state;
	uint16_t destwq;
	uint32_t fqctrl;
	int err;
	int pps = QBMAN_PFDR_POOL_BASE;	// PFDR pool select
	struct qbman_desc qbman_desc;
	int iter = 0, ps = 0;
	uint32_t fqstate = 0;

	memset(&qbman_desc, 0, sizeof(qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, &iter);
	if (err) {
		pr_err("Could not obtain QBMAN descriptor\n");
		return err;
	}

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_fq_query_state(sw_portal, (uint32_t)rx_queue->fqid,
					&state);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d]: qbman_fq_query failed\n", dpni->id);
		return err;
	}
	fqstate = qbman_fq_state_schedstate(&state);
	if (fqstate == qbman_fq_schedstate_oos)
		/* new FQID, clear descriptor */
		qbman_fq_attr_clear(&fqdesc);
	else
	/* Avoid F2h error after Initialize FQ command due to invalid FQ state.
	This occurs if one or more of the FQ specified in the command are in
	the Retired state or have their retirement pending (R) bit asserted.*/
	if (fqstate == qbman_fq_schedstate_retired) {
		CHECK_COND_RETVAL(0, -EINVAL,
				"Fail to configure retired FQ[%d] due to invalid state\n");
	} else if (qbman_fq_state_retirement_pending(&state)) {
		CHECK_COND_RETVAL(0, -EINVAL,
				"Fail to configure FQ[%d]: retirement pending\n");
	} else {
		/* working FQID, fill the descriptor with its current values */
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_fq_query(sw_portal, (uint32_t)rx_queue->fqid,
					&fqdesc);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_fq_query failed\n", dpni->id);
			return err;
		}
	}
	qbman_fq_attr_set_ctx(&fqdesc, (uint32_t)(rx_queue->user_ctx >> 32),
				(uint32_t)rx_queue->user_ctx);
	qbman_fq_attr_set_icid(&fqdesc, dpni->dev_ctx.amq.icid,
				dpni->dev_ctx.amq.pl);
	if( qbman_desc.multiple_pfdr_support && (dpni->dev_ctx.type==DPMNG_CTX_TYPE_AIOP || dpni->default_pps==QBMAN_PFDR_POOL_PEB) ) {
		pps = QBMAN_PFDR_POOL_PEB;
		ps = !pps;
	} else
		ps = qbman_cacheable_pfdr();

	qbman_fq_attr_set_mctl(&fqdesc, dpni->dev_ctx.amq.bdi, 0,
				dpni->dev_ctx.amq.va, ps, pps);
	qbman_fq_attr_set_vfqid(&fqdesc, rx_queue->virt_fqid);
	qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
	if (rx_queue->always_stash)
		fqctrl |= QBMAN_FQCTRL_STASH;

	if (rx_queue->order_preservation_en)
		fqctrl |= QBMAN_FQCTRL_HOLDACTIVE;

	fqctrl &= ~QBMAN_FQCTRL_TAILDROP;
	if (rx_queue->tail_drop_threshold) {
		fqctrl |= QBMAN_FQCTRL_TAILDROP;
		qbman_fq_attr_set_tdthresh(&fqdesc,
						rx_queue->tail_drop_threshold);
		
		qbman_fq_attr_set_oa(&fqdesc, 0, 0, (int32_t)rx_queue->oal); 
	}
	
	if (rx_queue->cgid_en) {
		fqctrl |= QBMAN_FQCTRL_CGR;
		qbman_fq_attr_set_cgrid(&fqdesc, (uint32_t)dpni->rx_tx_conf_cgids[rx_queue->cgid_index].cgid);
		qbman_fq_attr_set_oa(&fqdesc, 0, 1, (int32_t)dpni->rx_tx_conf_cgids[rx_queue->cgid_index].oal);
	}

	qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_fq_configure(sw_portal, (uint32_t)rx_queue->fqid, &fqdesc);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d]: qbman_fq_configure failed\n", dpni->id);
		return err;
	}

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_fq_query_state(sw_portal, (uint32_t)rx_queue->fqid,
					&state);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d]: qbman_fq_query failed\n", dpni->id);
		return err;
	}

	if (rx_queue->dest_cfg.dest_type != DPNI_DEST_NONE) {
		get_dest_wq(&rx_queue->dest_cfg, &destwq);
		if (rx_queue->dest_cfg.dest_type == DPNI_DEST_DPIO) {
			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			qbman_fq_attr_set_fqctrl(
				&fqdesc, fqctrl | QBMAN_FQCTRL_FQDAN);
		} else { /* DPNI_DEST_DPCON */
			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			qbman_fq_attr_set_fqctrl(
				&fqdesc, fqctrl & ~QBMAN_FQCTRL_FQDAN);
		}
		qbman_fq_attr_set_destwq(&fqdesc, (uint32_t)destwq);

		if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
			pr_info("AIOP DPNI: set Rx FQ[%xh] in WQID[%xh]\n",
					rx_queue->fqid, destwq);
		}
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_fq_configure(sw_portal, (uint32_t)rx_queue->fqid,
						&fqdesc);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_fq_configure failed\n", dpni->id);
			return err;
		}

		if (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_parked) {
			dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
			err = qbman_swp_fq_schedule(
				sw_portal, (uint32_t)rx_queue->fqid);
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			if (err != 0) {
				pr_err("ID[%d]: qbman_swp_fq_schedule failed\n", dpni->id);
				return err;
			}
		}
	} else if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
		uint32_t wqid_base;
		wqid_base = dpmng_get_dcp_wqid(dpni->dpmng, QBMAN_DCP_AIOP,
				QBMAN_FIRST_AIOP_DCP_CHID);
		qbman_fq_attr_set_destwq(&fqdesc,
				(uint32_t)((wqid_base << 3) | rx_queue->dest_cfg.priority));
		pr_info("AIOP DPNI: set Rx FQ[%xh] in WQID[%xh]/PRIO:%d\n",
				rx_queue->fqid, wqid_base, rx_queue->dest_cfg.priority);
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_fq_configure(sw_portal, (uint32_t)rx_queue->fqid,
						&fqdesc);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err( "qbman_fq_configure failed\n", dpni->id);
			return err;
		}

		if (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_parked) {
			dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
			err = qbman_swp_fq_schedule(
				sw_portal, (uint32_t)rx_queue->fqid);
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			if (err != 0) {
				pr_err("ID[%d]: qbman_swp_fq_schedule failed\n", dpni->id);
				return err;
			}
		}
	}

	return 0;
}

static int csum_gen_l3(struct dpni *dpni, struct dpni_sender_info *info)
{
	return dpni->l3_chksum_gen | info->l3_chksum_gen;
}

static int csum_gen_l4(struct dpni *dpni, struct dpni_sender_info *info)
{
	return dpni->l4_chksum_gen | info->l4_chksum_gen;
}

static int config_sender_info(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t sender_id,
	struct dpni_sender_info *info)
{
	struct qbman_swp *sw_portal;
	struct dpni_tx_conf_info *tx_conf_err;
	struct eiop_desc desc = {0};
	uint32_t lfqid;
	int i, err;

	if (!dpni->ap_valid)
		return 0;

	CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
			dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

	soc_db_get_desc(SOC_MODULE_EIOP,
			SOC_DB_NO_MATCH_FIELDS,
			&desc, NULL);

	EIOP_FCEAD_SET_IFPID(&info->fcead,
				dpni->snic.egress_ifp_info->ifp_desc.ifp_id);
	EIOP_FCEAD_SET_L3CSG(&info->fcead, csum_gen_l3(dpni, info));
	EIOP_FCEAD_SET_L4CSG(&info->fcead, csum_gen_l4(dpni, info));
	EIOP_FCEAD_SET_FQID(&info->fcead, 0);
	EIOP_FCEAD_SET_EBDD(&info->fcead, 0);
	EIOP_FCEAD_SET_UPD(&info->fcead, 0);
	if (!dpni->tx_conf_disable) {
		tx_conf_err =
			(info->private_tx_conf_err_queue) ?
				&info->tx_conf_err : &dpni->tx_conf_err;
		EIOP_FCEAD_SET_FQID(&info->fcead,
					tx_conf_err->queue_info.virt_fqid);
		EIOP_FCEAD_SET_FQIDT(&info->fcead,
					tx_conf_err->only_error_frames);
		EIOP_FCEAD_SET_EBDD(&info->fcead,
					!tx_conf_err->only_error_frames);
		EIOP_FCEAD_SET_UPD(&info->fcead, !!dpni->mem_ifp_info->init.defcfg.tx_buf_layout.pass_ts);
	}

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	for (i = 0; i < dpni->max_tx_tcs; i++) {
		lfqid = qbman_lfqid_compose_ex(
			dpni->ceetmid, (uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].lfqidx_base);

		err = qbman_lfq_configure(
			sw_portal,
			lfqid + sender_id,
			(uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid,
			(uint16_t)info->dctidx,
			(uint32_t)(
				(info->private_tx_conf_err_queue) ?
					info->tx_conf_err.queue_info.fqid :
					dpni->tx_conf_err.queue_info.fqid));
		if (err != 0) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			pr_err( "ID[%d] qbman_lfq_configure failed; channel: %d, tc: %d\n", dpni->id, ceetm_ch_idx, i);
			return err;
		}
	}

	err = qbman_dct_configure(
		sw_portal,
		dpni->ceetmid,
		(uint16_t)info->dctidx,
		dpni->dev_ctx.amq.bdi,
		dpni->dev_ctx.amq.va,
		dpni->dev_ctx.amq.icid,
		dpni->dev_ctx.amq.pl,
		((uint64_t)info->fcead.command1 << 32)
		| (uint64_t)info->fcead.command2);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d] qbman_dct_configure failed\n", dpni->id);
		return err;
	}

	return 0;
}

static int get_free_cgid(struct dpni *dpni, int *cgid_index)
{
	int i;

	if (*cgid_index != DPNI_INVALID_ID)
		return 0;

	/* Find free cg-id */
	for (i = 0; i < dpni->max_congestion_ctrl; i++)
		if (!(dpni->rx_tx_conf_cgids[i].in_use))
			break;
	if (i == dpni->max_congestion_ctrl) {
		pr_err("ID[%d]: all early-drops are used \n", dpni->id);
		return -ENAVAIL;
	}

	*cgid_index = i;
	if( !dpni->shared_congestion ) {
		dpni->rx_tx_conf_cgids[i].in_use = 1;
	}

	return 0;
}

static void return_cgid(struct dpni *dpni, int *cgid_index)
{
	ASSERT_COND(*cgid_index != dpni->max_congestion_ctrl);
	dpni->rx_tx_conf_cgids[*cgid_index].in_use = 0;
	*cgid_index = DPNI_INVALID_ID;
}

static int set_cgr_enable(struct dpni *dpni, struct dpni_cgr_cfg *cgr_cfg)
{
	struct qbman_attr cgr_desc;
	struct qbman_swp *sw_portal;
	int err;

 
	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	if (cgr_cfg->is_ccgid)
		err = qbman_ccgr_query(sw_portal, cgr_cfg->ceetmid,
					cgr_cfg->cchannelid,
					(uint8_t)cgr_cfg->cgid, &cgr_desc);
	else
	{
		err = get_free_cgid(dpni, cgr_cfg->cgid_index);
		if (err)
		{
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			return err;
		}
		
		cgr_cfg->cgid = dpni->rx_tx_conf_cgids[*cgr_cfg->cgid_index].cgid;
		err = qbman_cgr_query(sw_portal, (uint32_t)cgr_cfg->cgid,
					&cgr_desc);
	}
	if (err) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}
	ASSERT_COND(cgr_cfg->fill_cb);
	
	cgr_cfg->fill_cb(cgr_cfg->cfg, &cgr_desc, 0);
	if (cgr_cfg->is_ccgid) {
		qbman_ccgr_attr_set_oal(&cgr_desc, (uint32_t)cgr_cfg->oal);
		err = qbman_ccgr_configure(sw_portal, cgr_cfg->ceetmid,
						cgr_cfg->cchannelid,
						(uint8_t)cgr_cfg->cgid,
						&cgr_desc);
	}
	else
		err = qbman_cgr_configure(sw_portal, (uint32_t)cgr_cfg->cgid,
						&cgr_desc);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err)
		return err;

	return 0;
}

static int set_cgr_disable(struct dpni *dpni, struct dpni_cgr_cfg *cgr_cfg)
{
	struct qbman_attr cgr_desc;
	struct qbman_swp *sw_portal;
	int err;

	CHECK_COND_RETVAL(cgr_cfg->cgid != DPNI_INVALID_ID, -EINVAL);
	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	if (cgr_cfg->is_ccgid)
		err = qbman_ccgr_query(sw_portal, cgr_cfg->ceetmid,
					cgr_cfg->cchannelid,
					(uint8_t)cgr_cfg->cgid, &cgr_desc);
	else
		err = qbman_cgr_query(sw_portal, (uint32_t)cgr_cfg->cgid,
					&cgr_desc);
	if (err) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}
	CHECK_COND_RETVAL(cgr_cfg->fill_cb, -EINVAL);
	cgr_cfg->fill_cb(cgr_cfg->cfg, &cgr_desc, 1);
	if (cgr_cfg->reset_cb)
		cgr_cfg->reset_cb(sw_portal, cgr_cfg->cgid, cgr_cfg->is_ccgid,
					cgr_cfg->ceetmid, cgr_cfg->cchannelid);
	if (cgr_cfg->is_ccgid)
		err = qbman_ccgr_configure(sw_portal, cgr_cfg->ceetmid,
						cgr_cfg->cchannelid,
						(uint8_t)cgr_cfg->cgid,
						&cgr_desc);
	else
		err = qbman_cgr_configure(sw_portal, (uint32_t)cgr_cfg->cgid,
						&cgr_desc);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(err == 0, err);
	if (cgr_cfg->free_cgid)
		return_cgid(dpni, cgr_cfg->cgid_index);

	return 0;
}

static int config_tx_tc_ccg(struct dpni *dpni, int ceetm_ch_idx, uint16_t tc_id)
{
	struct dpni_cgr_cfg cgr_cfg = { 0 };
	int err;

	if (!dpni->ap_valid)
		return 0;

	CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
			dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

	cgr_cfg.cgid = dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].ccgid;
	cgr_cfg.is_ccgid = 1;
	cgr_cfg.ceetmid = dpni->ceetmid;
	cgr_cfg.cchannelid = (uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid;
	cgr_cfg.oal = dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cg_early_drop.oal;

	/* Configure congestion notification */
	cgr_cfg.cfg = (void *)&dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cg_notify;
	cgr_cfg.fill_cb = congestion_notification_fill;
	cgr_cfg.reset_cb = NULL;
	if (dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cg_notify.threshold_entry != 0) {
		err = set_cgr_enable(dpni, &cgr_cfg);
		CHECK_COND_RETVAL(err == 0, err);
		dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].notification_enable = 1;
	} else if (dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].notification_enable) {
		dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].notification_enable = 0;
		err = set_cgr_disable(dpni, &cgr_cfg);
		CHECK_COND_RETVAL(err == 0, err);
	}

	/* Configure early-drop */
	cgr_cfg.cfg = (void *)&dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cg_early_drop;
	cgr_cfg.fill_cb = early_drop_fill;
	cgr_cfg.reset_cb = early_drop_reset;
	if (dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cg_early_drop.dpni_tail_drop_enable ||
			dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cg_early_drop.dpni_wred_enable) {
		err = set_cgr_enable(dpni, &cgr_cfg);
		CHECK_COND_RETVAL(err == 0, err);
		dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].early_drop_enable = 1;
	} else if (dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].early_drop_enable) {
		dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].early_drop_enable = 0;
		err = set_cgr_disable(dpni, &cgr_cfg);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return 0;
}

static int cgid_authorization_n_configuration(struct dpni *dpni,
	int cgid,
	uint32_t *virtual_cgid,
	int is_ccgid,
	uint32_t ceetmid,
	uint8_t cchannelid)
{
	struct qbman_swp *sw_portal = NULL;
	struct qbman_attr attr;
	uint8_t dcpid, instanceid;
	uint32_t rrid_cgid;
	int err;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	rrid_cgid = (uint32_t)cgid;
	if (is_ccgid) {
		qbman_ceetmid_decompose(ceetmid, &dcpid, &instanceid);
		rrid_cgid = qbman_auth_rrid_ccgid_compose(dcpid, instanceid,
								cchannelid,
								(uint8_t)cgid);
	}

	err = resource_authorization(sw_portal, dpni->dev_ctx.amq.bdi,
					dpni->dev_ctx.amq.icid,
					qbman_auth_type_cgid, virtual_cgid,
					rrid_cgid, QBMAN_AUTH_SWP, "CGID");
	if (err) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}
	if( !is_ccgid && *virtual_cgid >= MAX_CGID_VIRT_ID ) {
		pr_warn("ID[%d]: Virtual congestion group id is above 256, the flow control feature will not work\n",
				dpni->id);
	}

	if (is_ccgid)
		err = qbman_ccgr_query(sw_portal, ceetmid, cchannelid,
					(uint8_t)cgid, &attr);
	else
		err = qbman_cgr_query(sw_portal, (uint32_t)cgid, &attr);
	if (err) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}
	qbman_cgr_attr_set_cscn_vcgid(&attr, *virtual_cgid,
					dpni->dev_ctx.amq.bdi);
	qbman_cgr_attr_set_cg_icid(&attr, dpni->dev_ctx.amq.icid,
					dpni->dev_ctx.amq.pl,
					dpni->dev_ctx.amq.va);
	if (is_ccgid)
		err = qbman_ccgr_configure(sw_portal, ceetmid, cchannelid,
						(uint8_t)cgid, &attr);
	else
		err = qbman_cgr_configure(sw_portal, (uint32_t)cgid, &attr);

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int config_retire_storage_data(struct dpni *dpni)
{
	struct retire_storage_data *retire_storage;

	retire_storage = &dpni->queue_retire_data;

	if( retire_storage->data ) {
		return 0;
	}
	retire_storage->data = fsl_xmalloc(sizeof(struct dpni_rx_queue_info), 0, 64);
	CHECK_COND_RETVAL(retire_storage->data!=NULL, -ENOMEM, "Failed to configure queue retire storage data\n");

	retire_storage->retire_pending = 0;

	return 0;
}

static void clear_retire_storage_data(struct dpni *dpni)
{
	struct retire_storage_data *retire_storage;

	retire_storage = &dpni->queue_retire_data;
	if( retire_storage->data!=NULL ) {
		if( retire_storage->retire_pending ) {
			pr_err("clear_retire_storage_data() - Previous retire call is in pending; leave a memory leak behind\n");
			retire_storage->retire_pending = 0;
		} else {
			fsl_xfree(retire_storage->data);
		}
	}
}

static void mark_retire_storage_pending(struct dpni *dpni)
{
	dpni->queue_retire_data.retire_pending = 1;
}

static void *get_retire_storage_buffer(struct dpni *dpni)
{
	struct retire_storage_data *retire_storage;

	retire_storage = &dpni->queue_retire_data;
	if( retire_storage->retire_pending ) {
		pr_err("get_retire_storage_buffer() - Previous retire call is in pending; leave a memory leak behind\n");
		retire_storage->data = fsl_xmalloc(sizeof(struct dpni_rx_queue_info), 0, 64);
		retire_storage->retire_pending = 0;
	}
	return retire_storage->data;
}

static int config_tx_qbman(struct dpni *dpni)
{
	int err, i;
	int ceetm_ch_idx;

	/* TX-ERR-Q */
	err = config_fqid(dpni, &dpni->tx_conf_err.queue_info);
	CHECK_COND_RETVAL(err == 0, err);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		for (i = 0; i < dpni->max_senders; i++) {
			if (dpni->tx_ch[ceetm_ch_idx].sender_info[i].private_tx_conf_err_queue) {
				err = config_fqid(
						dpni,
						&dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err.queue_info);
				CHECK_COND_RETVAL(err == 0, err, "ID[%d] config_fqid error\n", dpni->id);
			}
			err = config_sender_info(dpni, ceetm_ch_idx, (uint16_t)i,
					&dpni->tx_ch[ceetm_ch_idx].sender_info[i]);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}

	if (dpni->ap_valid)
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
			for (i = 0; i < dpni->max_tx_tcs; i++) {
				if( dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_cgid==QBMAN_INVALID_VRID ) {
					err = cgid_authorization_n_configuration(
							dpni, dpni->tx_ch[ceetm_ch_idx].tc_tx[i].ccgid,
							&dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_cgid, 1, dpni->ceetmid,
							(uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid);
					CHECK_COND_RETVAL(err == 0, err);
				}
			}

	return 0;
}

static int config_rx_qbman(struct dpni *dpni)
{
	int err, i, j;

	/* RX-ERR-Q */
	dpni->rx_err.always_stash = 0; /* No stash for rx-err FQID */
	err = config_fqid(dpni, &dpni->rx_err);
	CHECK_COND_RETVAL(err == 0, err);

	for (i = 0; i < dpni->max_rx_tcs; i++) {
		for (j = 0; j < dpni->tc_rx[SELECT_TC_SHARED_FS(i)].max_dist_size; j++) {
			/* RX-Q */
#ifdef MC_CLI
            dpni->tc_rx[i].rx_queues[j].always_stash = 1;
#endif
			err = config_fqid(dpni, &dpni->tc_rx[i].rx_queues[j]);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}

	return 0;
}

static int config_qbman(struct dpni *dpni)
{
	int err;

	if ((dpni->is_snic) && ((err = snic_config_qbman(dpni)) != 0))
		return err;

	err = config_tx_qbman(dpni);
	if (err != 0) {
		pr_err("ID[%d]: config_tx_qbman failed\n", dpni->id);
		return err;
	}

	err = config_rx_qbman(dpni);
	if (err != 0) {
		pr_err("ID[%d]: config_rx_qbman failed\n", dpni->id);
		return err;
	}

	return 0;
}

static int configuration(struct dpni *dpni)
{
	int err;
	uint8_t tc, dist;
	struct qbman_swp *sw_portal;

	if (dpni->is_snic && !dpni->snic.configured) {
		err = snic_configuration(dpni);
		if (err != 0) {
			pr_err("ID[%d]: snic_configuration failed\n", dpni->id);
			return err;
		}
	}

	if (dpni_has_opr(dpni)) {
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

		for (dist = 0; dist < dpni->max_opr; dist++) {
			//Create the OPR entries
			err = create_opr(sw_portal,	&dpni->opr[dist].opr, 1);
			if (err != 0) {
				dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
				return err;
			}
		}
		for (tc = 0; tc < dpni->max_rx_tcs; tc++) {
			for (dist = 0; dist < dpni->tc_rx[SELECT_TC_SHARED_FS(tc)].max_dist_size; dist++) {
				/* Adding/remove ORP support for queue */
				if (dpni->tc_rx[tc].rx_queues[dist].opr_id != DPNI_INVALID_ID)
				{
					err = config_orp_fq(sw_portal, dpni->tc_rx[tc].rx_queues[dist].fqid,
						get_opr_info(dpni, tc, dist));
					if (err != 0) {
						dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
						return err;
					}
				}
			}
		}
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	}
	return 0;
}

static int set_tx_rejection_mode(struct dpni *dpni, int reject)
{
	struct qbman_swp *sw_portal = NULL;
	struct qbman_attr fqdesc;
	uint32_t fqctrl, lfqid, cgid = (uint32_t)dpmng_get_cgid(dpni->dpmng);
	int err, i;
	int ceetm_ch_idx;

	if (reject) {
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		/* Set CGID and set TX-ERR-Q as the rejected fqid in RX-ERR-Q */
		err = qbman_fq_query(sw_portal, (uint32_t)dpni->rx_err.fqid,
					&fqdesc);
		if (err != 0) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			pr_err("ID[%d]: qbman_fq_query failed\n", dpni->id);
			return err;
		}
		qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
		qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl | QBMAN_FQCTRL_CGR);
		qbman_fq_attr_set_cgrid(&fqdesc, cgid);
		qbman_fq_attr_set_erfqid(
			&fqdesc, (uint32_t)dpni->tx_conf_err.queue_info.fqid);
		err = qbman_fq_configure(sw_portal,
						(uint32_t)dpni->rx_err.fqid,
						&fqdesc);
		if (err != 0) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			pr_err("ID[%d]: qbman_fq_configure failed\n", dpni->id);
			return err;
		}

		/* Set all Tx QPRIs to point to the RX-ERR-Q */
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
			for (i = 0; i < dpni->max_tx_tcs; i++) {
				err = qbman_qpr_configure(
						sw_portal, (uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].qprid,
						(uint32_t)dpni->rx_err.fqid, 1, cgid);
				if (err != 0) {
					dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
					pr_err( "qbman_qpr_configure failed\n", dpni->id);
					return err;
				}
			}
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	} else {
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		/* Restore all Tx QPRIs */
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
			for (i = 0; i < dpni->max_tx_tcs; i++) {
				lfqid = qbman_lfqid_compose_ex(
						dpni->ceetmid,
						(uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].lfqidx_base);

				err = qbman_qpr_configure(
						sw_portal, (uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].qprid,
						lfqid, dpni->max_senders,
						(uint32_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].ccgid);
				if (err != 0) {
					dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
					pr_err( "qbman_qpr_configure failed\n", dpni->id);
					return err;
				}
			}

		/* Restore RX-ERR-Q settings */
		err = qbman_fq_query(sw_portal, (uint32_t)dpni->rx_err.fqid,
					&fqdesc);
		if (err != 0) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			pr_err("ID[%d]: qbman_fq_query failed\n", dpni->id);
			return err;
		}
		qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
		qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl & ~QBMAN_FQCTRL_CGR);
		err = qbman_fq_configure(sw_portal,
						(uint32_t)dpni->rx_err.fqid,
						&fqdesc);
		if (err != 0) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			pr_err("ID[%d]: qbman_fq_configure failed\n", dpni->id);
			return err;
		}
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	}

	return 0;
}

static int initial_configuration(struct dpni *dpni)
{
	struct qbman_swp *sw_portal;
	uint16_t qprid[DPNI_MAX_RX_TC + DPNI_MAX_TX_TC];
	int err, i;
	int fqid;
	int ceetm_ch_idx;

	err = config_ctlu(dpni, 0 /* init-stage */);
	if (err != 0) {
		pr_err("ID[%d]: config_ctlu failed\n", dpni->id);
		return err;
	}

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	for (i = 0; i < dpni->max_rx_tcs; i++) {
		err = qbman_qpr_configure(
			sw_portal, (uint16_t)dpni->tc_rx[i].qprid,
			(uint32_t)dpni->tc_rx[i].fqid_base,
			(uint16_t)dpni->tc_rx[SELECT_TC_SHARED_FS(i)].dist_size,
			(uint32_t)dpni->rx_tx_conf_cgids[i].cgid);
		if (err != 0) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			pr_err( "ID[%d]: qbman_qpr_configure failed for rx-qprid\n", dpni->id);
			return err;
		}
	}

	if( dpni->tx_conf_disable == 0 ) {
		fqid = dpni->tx_ch[0].sender_info[0].tx_conf_err.queue_info.fqid;
	}
	else {
		fqid = dpni->tx_conf_err.queue_info.fqid;
	}
	err = qbman_qpr_configure(sw_portal,
			(uint16_t)dpni->void_qprid, (uint32_t)fqid,
			1, (uint32_t)dpmng_get_cgid(dpni->dpmng));

	/* Config QDR */
	memset(qprid, 0, sizeof(qprid));
	qprid[0] = (uint16_t)dpni->tc_rx[0].qprid;
	for (i = 0; i < DPNI_MAX_RX_TC; i++) {
		qprid[i+dpni_get_rx_base_qpri(dpni)] = (uint16_t)dpni->tc_rx[i].qprid;
	}
	err = qbman_qd_configure(sw_portal, (uint16_t)dpni->rx_qdid, qprid);
	if (err != 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		pr_err("ID[%d]: qbman_qd_configure failed\n", dpni->id);
		return err;
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		memset(qprid, 0, sizeof(qprid));
		for (i = 0; i < dpni->max_tx_tcs; i++) {
			qprid[i] = (uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].qprid;
		}
		if( i==0 ) i++;
		for( ; i < DPNI_MAX_TX_TC ; i++ ) {
			qprid[i] = (uint16_t)dpni->void_qprid;
		}
		err = qbman_qd_configure(sw_portal, (uint16_t)dpni->tx_ch[ceetm_ch_idx].tx_qdid, qprid);
		if (err != 0) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			pr_err("ID[%d]: qbman_qd_configure failed\n", dpni->id);
			return err;
		}
	}

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	if (dpni->is_snic) {
		err = snic_initial_configuration(dpni);
		if (err != 0) {
			pr_err("ID[%d]: snic_initial_configuration failed\n", dpni->id);
			return err;
		}
	}

	return 0;
}

static void clear_fqid(struct dpni *dpni, struct dpni_rx_queue_info *rx_queue)
{
	if (!rx_queue->retire_storage)
		rx_queue->retire_storage = get_retire_storage_buffer(dpni);
	ASSERT_COND(rx_queue->retire_storage);

	dpmng_clear_fqid((uint32_t)rx_queue->fqid, rx_queue->retire_storage,
				&rx_queue->retire_pending);

	if (rx_queue->retire_pending == 1) {
		mark_retire_storage_pending(dpni);
		return;
	}

	rx_queue->user_ctx = 0;
	rx_queue->flc_type = DPNI_FLC_USER_DEFINED;
	rx_queue->flc_opaque = 0;
	rx_queue->always_stash = 1;
	rx_queue->order_preservation_en = 0;
	rx_queue->tail_drop_threshold = 0;
	rx_queue->oal = 0;
	memset(&rx_queue->dest_cfg, 0, sizeof(struct dpni_dest_cfg));
}

static int clear_tx_side(struct dpni *dpni)
{
	int ceetm_ch_idx;
	int i;

	/* TX-ERR-Q */
	clear_fqid(dpni, &dpni->tx_conf_err.queue_info);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
		for (i = 0; i < dpni->max_senders; i++) {
			if (!(dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED)) {
				/* TX-CONF-Q */
				clear_fqid(
						dpni,
						&dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err.queue_info);
				dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err.only_error_frames = 0;
				dpni->tx_ch[ceetm_ch_idx].sender_info[i].private_tx_conf_err_queue = 1;
			}
			memset(&dpni->tx_ch[ceetm_ch_idx].sender_info[i].fcead, 0,
					sizeof(struct eiop_fcead));
			dpni->tx_ch[ceetm_ch_idx].sender_info[i].l3_chksum_gen = 0;
			dpni->tx_ch[ceetm_ch_idx].sender_info[i].l4_chksum_gen = 0;
			dpni->tx_ch[ceetm_ch_idx].sender_info[i].valid = 0;
	}

	return 0;
}

static int clear_rx_side(struct dpni *dpni)
{
	int i, j, err = 0;
	struct qbman_swp *sw_portal;

	/* RX-ERR-Q */
	clear_fqid(dpni, &dpni->rx_err);

	for (i = 0; i < dpni->max_rx_tcs; i++) {
		for (j = 0; j < dpni->tc_rx[SELECT_TC_SHARED_FS(i)].max_dist_size; j++)
			/* RX-Q */
			clear_fqid(dpni, &dpni->tc_rx[i].rx_queues[j]);
		memset(&dpni->tc_rx[i].dist_extract_cfg, 0,
			sizeof(struct dpkg_profile_cfg));
		dpni->tc_rx[i].dist_size = 1;
		dpni->tc_rx[i].dist_cfg.fs_dist_size = dpni->tc_rx[i].dist_size;
		dpni->tc_rx[i].valid = 0;

		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_qpr_configure(sw_portal,
					(uint16_t)dpni->tc_rx[i].qprid,
					(uint32_t)dpni->tc_rx[i].fqid_base,
					(uint16_t)dpni->tc_rx[i].dist_size,
					(uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[i].cgid_index].cgid);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_qpr_configure failed for qprid\n", dpni->id);
			return err;
		}
	}
	
	//Retire OPRs
	if (dpni_has_opr(dpni)) {
		err = dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		for (i = 0; i < dpni->max_opr; i++) {
			err = retire_opr(sw_portal, &dpni->opr[i].opr);
			if (err != 0) {
				dpmng_put_swportal(dpni->dpmng, &sw_portal);
				return err;
			}
		}
		
		err = dpmng_put_swportal(dpni->dpmng, &sw_portal);
	}
	return 0;
}

static int reset_counters(struct dpni *dpni)
{
	dpni_set_counter(dpni, DPNI_CNT_ING_FRAME, 0);
	dpni_set_counter(dpni, DPNI_CNT_ING_BYTE, 0);
	dpni_set_counter(dpni, DPNI_CNT_ING_FRAME_DROP, 0);
	dpni_set_counter(dpni, DPNI_CNT_ING_FRAME_DISCARD, 0);
	dpni_set_counter(dpni, DPNI_CNT_ING_MCAST_FRAME, 0);
	dpni_set_counter(dpni, DPNI_CNT_ING_MCAST_BYTE, 0);
	dpni_set_counter(dpni, DPNI_CNT_ING_BCAST_FRAME, 0);
	dpni_set_counter(dpni, DPNI_CNT_ING_BCAST_BYTES, 0);
	dpni_set_counter(dpni, DPNI_CNT_EGR_FRAME, 0);
	dpni_set_counter(dpni, DPNI_CNT_EGR_BYTE, 0);
	dpni_set_counter(dpni, DPNI_CNT_EGR_FRAME_DISCARD, 0);
	dpni_set_counter(dpni, DPNI_CNT_ING_NO_BUFFER_DISCARD, 0);
	dpni_set_counter(dpni, DPNI_CNT_EGR_FRAME_CONFIRMED, 0);
	dpni_set_counter(dpni, DPNI_CNT_EGR_MCAST_FRAME, 0);
	dpni_set_counter(dpni, DPNI_CNT_EGR_MCAST_BYTE, 0);
	dpni_set_counter(dpni, DPNI_CNT_EGR_BCAST_FRAME, 0);
	dpni_set_counter(dpni, DPNI_CNT_EGR_BCAST_BYTES, 0);

	return 0;
}

static void clear_dpbps(struct dpni *dpni)
{
	int i;

	/* Unregister DPNI from those DPBPs */
	for (i = 0; i < dpni->pools_cfg.num_dpbp; i++)
		dpbp_register_dpni(dpni->pools_cfg.pools[i].dpbp, 0);

	for (i = 0; i < dpni->backup_pools_cfg.num_dpbp; i++)
		dpbp_register_dpni(dpni->backup_pools_cfg.pools[i].dpbp, 0);

	memset(&dpni->pools_cfg, 0, sizeof(struct dpni_pools_int_cfg));
	memset(&dpni->backup_pools_cfg, 0, sizeof(struct dpni_pools_int_cfg));
}

#ifdef TKT011436
static int restore_extraction_hash(struct dpni *dpni, uint8_t tc_id)
{
	struct dpkg_profile_cfg *new;
	int kid, err;

	kid = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].kid_hash;
	new = &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_dist_key;
	
	err = dpkg_profile_modify(dpni->ing_dpkg, kid, new);
	CHECK_COND_RETVAL(err == 0, err, "dpkg_profile_modify Failed\n");
	
	return 0;
}
#endif /* TKT011436 */

static void modify_extraction_hash(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *tc_cfg)
{
	struct dpkg_profile_cfg *old, *new;
	int kid, err;

	kid = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].kid_hash;
	old = &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_extract_cfg;
	new = tc_cfg->dist_key_cfg;

	err = dpkg_profile_modify(dpni->ing_dpkg, kid, new);
	ASSERT_COND(!err || (err == -ETIMEDOUT));
	memcpy(old, new, sizeof(struct dpkg_profile_cfg));
}

#ifdef TKT011436
static int restore_extraction_fs(struct dpni *dpni, uint8_t tc_id)
{
	struct dpkg_profile_cfg *new;
	int kid, err;

	kid = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].kid_fs;
	new = &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_key;
	
	err = dpkg_profile_modify(dpni->ing_dpkg, kid, new);
	CHECK_COND_RETVAL(err == 0, err, "dpkg_profile_modify Failed\n");
	
	return 0;
}
#endif /* TKT011436 */

static void modify_extraction_fs(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *tc_cfg)
{
	struct dpkg_profile_cfg *old, *new;
	int kid, err;

	kid = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].kid_fs;
	old = &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_extract_cfg;

	new = tc_cfg->dist_key_cfg;

	err = dpkg_profile_modify(dpni->ing_dpkg, kid, new);
	ASSERT_COND(!err || (err == -ETIMEDOUT));
	memcpy(old, new, sizeof(struct dpkg_profile_cfg));

}

#ifdef TKT011436
static int restore_fs_table(struct dpni *dpni, uint8_t tc_id)
{
	int err;

	if(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_enable && dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid)
	{
		/* start by changing the key composition rule */
		err = restore_extraction_fs(dpni, tc_id);
		if(dpni->tc_rx[tc_id].fs_cfg.miss_action == DPNI_FS_MISS_HASH) {
			err = restore_extraction_hash(dpni, tc_id);
			CHECK_COND_RETVAL(err == 0, err, "restore_extraction_hash Failed\n");
		}
		CHECK_COND_RETVAL(err == 0, err, "restore_extraction_fs Failed\n");
		fs_update_miss_flc(dpni, tc_id);
		update_pass_through_qos(dpni);
	}
	return 0;
}
#endif /* TKT011436 */

static void set_fs_table(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *tc_cfg)
{
	const struct dpni_fs_tbl_cfg *params;
	struct dptbl_action *action = &dpni->tc_rx[tc_id].miss_action;

	dpni->tc_rx[tc_id].dist_cfg.fs_enable = 1;

	/* start by changing the key composition rule */
	modify_extraction_fs(dpni, tc_id, tc_cfg);

	params = &tc_cfg->fs_cfg;
	memset(action, 0, sizeof(struct dptbl_action));
	action->next_action = DPTBL_ACTION_DONE;
	if (params->miss_action == DPNI_FS_MISS_DROP) {
		action->next_action = DPTBL_ACTION_DONE;
		action->options = DPTBL_ACTION_SET_DISCARD_FLAG;
	} else if (params->miss_action == DPNI_FS_MISS_EXPLICIT_FLOWID) {
		action->options |= DPTBL_ACTION_SET_QDBIN;
		action->qd_bin = get_qdbin_from_flowid(
			dpni->tc_rx[tc_id].dist_size, params->default_flow_id);
	} else {
		/* default to hash.. */
		if (!params->keep_hash_key)
			/* update hash key, for backward compatibility */
			modify_extraction_hash(dpni, tc_id, tc_cfg);
		action->options |= DPTBL_ACTION_SET_HASH_KID;
		action->hash_dpkg_profile_id = get_kid_hash(dpni, tc_id);
	}

	dpni->tc_rx[tc_id].fs_tbl_is_valid = 1;

	fs_update_miss_flc(dpni, tc_id);

	update_pass_through_qos(dpni);
}

static void delete_fs_table(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *tc_cfg)
{
	int err;

	err = dpni_clear_fs_entries(dpni, tc_id);
	ASSERT_COND(err == 0);

	err = dptbl_modify_miss_action(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl,
					&dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].default_action);
	EIOP_ASSERT_COND(err);

	/* If the QoS is 'dummy' or not yet defined by the user we must
	 * assure TC#0 will work */
	if (tc_id == 0) {
		if (!(dpni->max_rx_tcs > 1))
			err = dptbl_modify_rule(dpni->qos.tbl,
						&dpni->dummy_rule,
						&dpni->qos.default_action);
		else if (!dpni->qos.valid)
			err = dptbl_modify_miss_action(
				dpni->qos.tbl, &dpni->qos.default_action);
		ASSERT_COND(!err || (err == -ETIMEDOUT));
	}

	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_enable = 0;

	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid = 0;
}

static void modify_qos_entries(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *tc_cfg)
{
	struct dptbl_rule rule;
	int i;
	uint8_t flow_id;

	UNUSED(tc_cfg);

	if (dpni->tc_rx[tc_id].qos_owners == 0)
		return;

	/* Find all entries that point to this tc_id and change their action */
	i = 0;
	do {
		if ((dpni->qos.keys[i].in_use)
			&& (dpni->qos.keys[i].action.qpri
				== (dpni_get_rx_base_qpri(dpni) + tc_id))) {
			memset(&rule, 0, sizeof(struct dptbl_rule));
			qos_fs_dptbl_rule_create_cb(&dpni->qos.keys[i], &rule);
			if (dpni->qos.keys[i].flow_id_rule ||
				(!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_enable &&
				 !dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_enable))
			{
				flow_id = (uint8_t)get_flowid_from_qdbin(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size ,dpni->qos.keys[i].action.qd_bin);
				fill_qos_entry(dpni, tc_id, &dpni->qos.keys[i].action, DPNI_QOS_OPT_SET_FLOW_ID, flow_id);
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size;
			}
			else
			{	
				fill_qos_entry(dpni, tc_id, &dpni->qos.keys[i].action, DPNI_QOS_OPT_SET_TC_ONLY, 0);
			}
			dptbl_modify_rule(dpni->qos.tbl, &rule,
						&dpni->qos.keys[i].action);
		}
	} while (!dpni->qos.keys[i++].is_last);

	/* Modify miss-action if required */
	if (dpni->qos.default_tc == tc_id) {
		fill_qos_entry(dpni, tc_id, &dpni->qos.miss_action, DPNI_QOS_OPT_SET_FLOW_ID, 0);
		dptbl_modify_miss_action(dpni->qos.tbl,
						&dpni->qos.miss_action);
	}
}

#ifdef TKT011436
static int restore_rx_fs_hash_dist(struct dpni *dpni, uint8_t tc_id) 
{
	int fs_en, hash_en, err = 0;
	enum dpni_dist_mode current_dist_mode;
	current_dist_mode = dpni->tc_rx[tc_id].dist_mode;

	hash_en = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_enable;
	fs_en = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_enable;

	if (fs_en && hash_en)
		CHECK_COND_RETVAL(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode == DPNI_DIST_MODE_FS,
				-EINVAL, "Wrong DIST MODE\n");

	if (hash_en){
		err = restore_extraction_hash(dpni, SELECT_TC_SHARED_FS(tc_id));
		CHECK_COND_RETVAL(err == 0, err, "restore_extraction_hash Failed\n");
	}

	if (fs_en){
		err = restore_fs_table(dpni, SELECT_TC_SHARED_FS(tc_id));
		CHECK_COND_RETVAL(err == 0, err, "restore_fs_table Failed\n");
	}

	if (hash_en || fs_en) {
		pr_debug("modify_qos_entries\n");
		modify_qos_entries(dpni, tc_id, NULL);
	}

	return 0;
}
#endif /* TKT011436 */

/* This table is central to the way classification works in the DPNI.
 * The flow of traffic through DPNI classification stages is not fixed as one
 * would expect, based on DPNI CREATE configuration.
 * It changes depending on user settings.  A DPNI with QoS, hash and FS starts
 * up doing a QoS look-up but no hash or FS.  If the user sets up FS or hash,
 * the flow changes to take that configuration in.
 * The table contains the operation that need to be done to
 * switch between one mode (like only QoS) to another (like QoS and hash).
 */
static rx_tc_dist_cb *rx_tc_dist_sequence[][3][3] = { {
		/* None -> None: ignore */
		{ NULL,                   NULL,                   NULL },
		/* None -> HASH: modify hash key, modify QoS entries */
		{ modify_extraction_hash, modify_qos_entries,     NULL },
		/* None -> FS:'set-new'table', modify entries */
		{ set_fs_table,           modify_qos_entries,     NULL },
		}, {
		/* HASH -> None: modify QoS entries */
		{ modify_qos_entries,     NULL,                   NULL },
		/* HASH -> HASH: modify hash key */
		{ modify_extraction_hash, NULL,                   NULL },
		/* HASH -> FS: 'set-new-table', modify QoS entries */
		{ set_fs_table,           modify_qos_entries,     NULL },
		}, {
		/* FS -> None: modify the entries, unset FS table */
		{ modify_qos_entries,     delete_fs_table,        NULL },
		/* FS -> HASH: unset FS table,  modify QoS entries */
		{ delete_fs_table,        modify_qos_entries,     NULL },
		/* FS -> FS: unset (inc. clear) FS table, 'set-new-table' */
		{ delete_fs_table,        set_fs_table,           NULL },
}, };

void set_accesspoint_to_lni(struct dpni *dpni,
	struct dpmng_accesspoint *ap,
	int shaped)
{
	int err;
	uint32_t ceetmid;
	void *swp;

	/*! Compose CEETM */
	ceetmid = qbman_ceetmid_compose((uint8_t)ap->dcp_id,
					(uint8_t)ap->ceetm_id);

	/* Get software portal */
	err = dpmng_get_swportal(dpni->dpmng, &swp);
	ASSERT_COND(err == 0);

	err = qbman_cchannel_configure(swp, /* SW Portal */
					ceetmid, /* Composed CEETM ID */
					(uint8_t)ap->cqchid, /* Channel ID */
					(uint8_t)ap->lniid, /* LNI ID */
					shaped); /* shaped/un-shaped */
	ASSERT_COND(err == 0);

	err = dpmng_put_swportal(dpni->dpmng, &swp);
	ASSERT_COND(err == 0);
}

static void map_ceetm_cqs(struct dpni *dpni)
{
	struct qbman_desc desc;
	struct dpni_snic_lfqid_info *lfqid_info;
	uint8_t num_cqs_per_cqch, cq_index, weight_count_a = 0, weight_count_b = 0,  strict_count = 0;
	int err, cqchid;
	int ceetm_ch_idx;
	uint8_t i;


#define GET_BASE_CQID(cqch) (cqch << 4)

	memset(&desc, 0x0, sizeof(struct qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				0, /* match options*/
				&desc, /* descriptor */
				NULL); /* iterator */
	ASSERT_COND(err == 0);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		strict_count = 0;
		weight_count_a = 0;
		weight_count_b = 0;
		num_cqs_per_cqch = desc.dcp[dpni->tx_ch[ceetm_ch_idx].ap.dcp_id].ceetm_instance[dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id].num_cqs_per_channel;

		cqchid = (dpni->is_snic) ? dpni->snic.ceetm_chid : dpni->tx_ch[ceetm_ch_idx].ap.cqchid;
		for (i = 0; i < dpni->max_tx_tcs; i++) {
			/* Numerically lower traffic class has higher priority */

			if (dpni->max_tx_tcs == 16 && num_cqs_per_cqch == 16) {
				/* If the number of TCS is 16 we have every available CQ assigned to a channel.
				 * We will have first 8 (0-7) strict and the last 8 as weighted group A and group B*/
				cq_index = i;
			} else {
				if (dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].mode == DPNI_TX_SCHED_STRICT_PRIORITY)
					cq_index = strict_count++;
				else {
					if (dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].mode == DPNI_TX_SCHED_WEIGHTED_A) {
						cq_index = (uint8_t)(desc.ceetm_weight_pri_q_base + weight_count_a++);
					}
					else {
						cq_index = (uint8_t)(desc.ceetm_weight_pri_q_base + QBMAN_MAX_CEETM_GRP_SIZE + weight_count_b++);
					}
				}
			}

			dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cq_index = cq_index;

			/* SNIC */
			lfqid_info = &dpni->snic.egr_post_aiop[i];
			if (num_cqs_per_cqch == 8)
				lfqid_info->cqid = (int)(GET_BASE_CQID(dpni->tx_ch[ceetm_ch_idx].ap.cqchid) + i);
			else
				lfqid_info->cqid = (int)(GET_BASE_CQID(dpni->tx_ch[ceetm_ch_idx].ap.cqchid) + (i + desc.ceetm_weight_pri_q_base));
		}

		if (num_cqs_per_cqch == 8) {
			if (weight_count_b == 0) {
				dpni->cq_slider = weight_count_a;
			}
			else {
				dpni->cq_slider = QBMAN_MAX_CEETM_GRP_SIZE + weight_count_b;
			}
			dpni->snic.cq_slider = 8; /* All CQs are weighted CQs */
		} else {
			dpni->cq_slider = 0;
			dpni->snic.cq_slider = 0;
		}

		for (i = 0; i < dpni->max_tx_tcs; i++) {
			dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid = GET_BASE_CQID(cqchid);
			if (num_cqs_per_cqch == 8) {
				if (dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].mode != DPNI_TX_SCHED_STRICT_PRIORITY) {
					dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid += dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cq_index - dpni->cq_slider;
				} else {
					dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid += dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cq_index;
				}
			} else {
				dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid += dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cq_index;
			}
		}
	}
	/* SNIC */
	lfqid_info = &dpni->snic.ing_post_aiop;
	lfqid_info->cqid = GET_BASE_CQID(dpni->snic.ceetm_chid);
}

static void config_cq_channel_scheduling(struct dpni *dpni)
{
	struct qbman_attr channel_attr;
	struct qbman_swp *sw_portal;
	struct qbman_desc qbman_desc;
	int err, i, cqchid;
	uint8_t cqslider;
	int csms;
	uint32_t num_strict_pri_q = 0;
	uint32_t prio_A = DPNI_DEFAULT_WBFS_GROUP_PRIO, prio_B = DPNI_DEFAULT_WBFS_GROUP_PRIO;
	int ceetm_ch_idx;

	err = dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	ASSERT_COND(err == 0);

	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				0, /* match options*/
				&qbman_desc, /* descriptor */
				NULL); /* iterator */
	ASSERT_COND(err == 0);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		memset(&channel_attr, 0, sizeof(channel_attr));
		cqchid = (dpni->is_snic) ? dpni->snic.ceetm_chid : dpni->tx_ch[ceetm_ch_idx].ap.cqchid;
		qbman_cscheduler_query(sw_portal, dpni->ceetmid, (uint8_t)cqchid, 1, &channel_attr);

		num_strict_pri_q = qbman_desc.ceetm_num_strict_pri_q;

		/* combine/divide both groups A & B */
		if (!dpni->tx_ch[ceetm_ch_idx].tx_selection.separate_groups)
			qbman_cscheduler_set_group_b(&channel_attr, 1);
		else
			qbman_cscheduler_set_group_b(&channel_attr, 0);

		cqslider = (dpni->is_snic) ? dpni->snic.cq_slider : dpni->cq_slider;

		if (dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_A == 0 || dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_A > num_strict_pri_q)
			prio_A = num_strict_pri_q - 1;
		else if (dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_B == 0 ||
			dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_B >= dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_A ||
			dpni->max_tx_tcs == DPNI_MAX_TX_TC)
			prio_A = (uint32_t)(dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_A - 1 + cqslider);
		else
			prio_A = (uint32_t)(dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_A - 2 + cqslider);

		if (dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_B == 0 || dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_B > num_strict_pri_q)
			prio_B = num_strict_pri_q - 1;
		else if (dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_A == 0
				|| dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_A >= dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_B
				|| dpni->max_tx_tcs == DPNI_MAX_TX_TC)
			prio_B = (uint32_t)(dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_B - 1 + cqslider);
		else
			prio_B = (uint32_t)(dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_B - 2 + cqslider);

		qbman_cscheduler_set_prio_a(&channel_attr, prio_A);
		qbman_cscheduler_set_prio_b(&channel_attr, prio_B);

		qbman_cscheduler_get_csms(&channel_attr, &csms);

		for (i = 0; i < dpni->max_tx_tcs; i++) {
			if (dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].mode != DPNI_TX_SCHED_STRICT_PRIORITY)
				qbman_cscheduler_set_cq_weight(
						&channel_attr,
						dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cq_index,
						dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].delta_bandwidth,
						csms);
		}

		//Set slider
		qbman_cscheduler_set_cqps(&channel_attr, cqslider);

		qbman_cscheduler_configure(sw_portal, dpni->ceetmid,
					(uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid,
					&channel_attr);
	}

	err = dpmng_put_swportal(dpni->dpmng, &sw_portal);
	ASSERT_COND(err == 0);

}

static int config_tx_selection(struct dpni *dpni)
{
	struct qbman_swp *sw_portal;
	uint32_t lfqid, fqider;
	uint16_t cqid, dctidx;
	uint8_t ccgid;
	int i, j, err;
	struct qbman_desc qbman_desc;
	int iter = 0, ps = 0;
	int pps = QBMAN_PFDR_POOL_BASE;
	int ceetm_ch_idx;

	if (!dpni->ap_valid)
		return 0;

	memset(&qbman_desc, 0, sizeof(qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, &iter);
	if (err) {
		pr_err("Could not obtain QBMAN descriptor\n");
		return err;
	}

	map_ceetm_cqs(dpni);

	if( qbman_desc.multiple_pfdr_support && (dpni->dev_ctx.type==DPMNG_CTX_TYPE_AIOP || dpni->default_pps==QBMAN_PFDR_POOL_PEB) ) {
		pps = QBMAN_PFDR_POOL_PEB;
		ps = !pps;
	} else
		ps = qbman_cacheable_pfdr();

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		if(!dpni->restore.en)
			for (i = 0; i < dpni->max_tx_tcs; i++) {
				err = qbman_cq_configure(sw_portal, dpni->ceetmid,
						(uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid,
						(uint8_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].ccgid,
						/* PFDR stashing */ps,
						/* PFDR Pool 0 */(uint8_t)pps);
				CHECK_COND_RETVAL(err == 0, err);
			}

		/* Update the LFQs of the senders */
		for (j = 0; j < dpni->max_senders; j++)
			for (i = 0; i < dpni->max_tx_tcs; i++) {
				lfqid = qbman_lfqid_compose_ex(
						dpni->ceetmid,
						(uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].lfqidx_base);

				err = qbman_lfq_query(sw_portal, lfqid + j, &cqid,
						&dctidx, &fqider, &ccgid);
				if (err != 0) {
					dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
					pr_err( "qbman_lfq_query failed\n", dpni->id);
					return err;
				}

				cqid = (uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid;
				err = qbman_lfq_configure(sw_portal, lfqid + j, cqid,
						dctidx, fqider);
				if (err != 0) {
					dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
					pr_err( "qbman_lfq_configure failed\n", dpni->id);
					return err;
				}
			}
	}

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	config_cq_channel_scheduling(dpni);

	return 0;
}

static inline uint8_t get_tx_pause_status(struct dpni *dpni)
{
	uint64_t options = dpni->link_cfg.options;
	struct dpmac_link_cfg cfg;
	int err;

	/* Get the pause frame settings as actually configured on the DPMAC.
	 * This ensures the fact that we work with what actually is configured
	 * on the DPMAC object and not what was requested by the DPNI. This
	 * difference between the two states appears when the DPMAC is in
	 * TYPE_PHY, the DPNI requested the pause frame settings to be enabled
	 * by PHY auto-negotiation reached another verdict.
	 */
	if (dpni->dpmac) {
		err = dpmac_get_link_cfg(dpni->dpmac, &cfg);
		if (!err)
			options = cfg.options;
	}

	return (uint8_t) ((!!(options & DPNI_LINK_OPT_PAUSE)) ^ (!!(options & DPNI_LINK_OPT_ASYM_PAUSE)));
}

static inline uint8_t get_pfc_status(struct dpni *dpni)
{
	return !!(dpni->link_cfg.options&DPNI_LINK_OPT_PFC_PAUSE);
}

static void config_tc_class_flow_cotrol(struct dpni *dpni, int ceetm_ch_idx, int enable)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr tcfc_attr = {0};
	uint8_t tc_id;
	uint32_t ceetmid;
	int channel_idx = 0;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	ceetmid = qbman_ceetmid_compose(
		(uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.dcp_id,
		(uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id);

	qbman_ceetm_tcfc_query(sw_portal, ceetmid, (uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.lniid, &tcfc_attr);

	if( dpni->dpmac ) {
		for( tc_id=0 ; tc_id<dpni->max_tx_tcs ; tc_id++ ) {
			qbman_ceetm_tcfc_set_lnitcfcc(&tcfc_attr, 0, dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cq_index, (uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid, tc_id, enable);
		}
	} else {
		if( !enable ) {
			channel_idx = 0;
		} else {
			CHECK_COND_RET(dpni->fc_idx >= 0 , "ID[%d] Cannot configure lnitcfcc, channel index value is invalid\n", dpni->id);
			channel_idx = dpni->fc_idx;
		}
		qbman_ceetm_tcfc_set_lnitcfcc(&tcfc_attr, 1, 0, (uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid, (uint8_t)channel_idx, enable);
	}

	qbman_ceetm_tcfc_configure(sw_portal, ceetmid, (uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.lniid, &tcfc_attr);

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
}

static int dpni_ceetm_extra_resources_allocation(struct dpni *dpni)
{
	char type[16];
	int ceetm_ch_idx;
	int err = 0;
	
	CHECK_COND_RETVAL(dpni->max_tx_tcs * dpni->max_senders <= DPMNG_MAX_LFQMTIDX_ALLOC, -EINVAL);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		snprintf(type, sizeof(type), "lfqmt.ctm%d.ins%d", dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id);
		err = allocate_resource(dpni->device, /*Resource manager handle */
				type, /* Resource type */
				(uint32_t)((dpni->max_tx_tcs * dpni->max_senders) - DPMNG_DEFAULT_LFQMTIDX_ALLOC), /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				&(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[DPMNG_DEFAULT_LFQMTIDX_ALLOC]), /* Address */
				"LFQMTIDX"); /* Error string */
	}

	return err;
}

static int lfq_resources_authorization(struct dpni *dpni, int ceetm_ch_idx)
{
	struct qbman_swp *sw_portal = NULL;
	int i, j;
	uint32_t lfqid;
	int err = 0, err1 = 0;

	if( dpni->tx_ch[ceetm_ch_idx].lfq_authorized ) {
		return err;
	}

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	for (i=0; i < dpni->max_tx_tcs; i++) {
		for(j = 0; j < dpni->max_senders; j++) {
			lfqid = qbman_lfqid_compose_ex(dpni->ceetmid, (uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].lfqidx_base);

			err = resource_authorization(
								sw_portal, dpni->dev_ctx.amq.bdi,
								dpni->dev_ctx.amq.icid, qbman_auth_type_fqid,
								&dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_lfq[j],
								lfqid + j,
								QBMAN_AUTH_SWP | QBMAN_AUTH_DCP, "TX-Q");
			if ( err ) {
				pr_err("ID[%d] LDQ authorization failed tc_id: %d, lfq_idx: %d, lfq_id: %08x\n",
						dpni->id, i, j, lfqid);
				err1 = err;
				break;
			}
		}

		if( j != dpni->max_senders )
			break;
	}

	if( i != dpni->max_tx_tcs ) {
		/* authorization failed, cannot continue and must remove authorization already made*/
		j--;
		for( ; j >= 0 ; j-- ) {
			err = resource_deauthorization(
				sw_portal, dpni->dev_ctx.amq.bdi,
				dpni->dev_ctx.amq.icid, qbman_auth_type_fqid,
				dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_lfq[j],
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-Q");
			if( err ) {
				lfqid = qbman_lfqid_compose_ex(dpni->ceetmid, (uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].lfqidx_base);
				pr_err("ID[%d] LFQ authorization remove failed for tx_id:%d, lfq_idx: %d, virtual_id: %d, lfq_id: %08x",
						dpni->id, i, j, dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_lfq[j], lfqid);
			}
		}

		i--;
		for( ; i >= 0 ; i-- ) {
			for( j = 0 ; j < dpni->max_senders ; j++ ) {
				err = resource_deauthorization(
					sw_portal, dpni->dev_ctx.amq.bdi,
					dpni->dev_ctx.amq.icid, qbman_auth_type_fqid,
					dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_lfq[j],
					(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-Q");
				if( err ) {
					lfqid = qbman_lfqid_compose_ex(dpni->ceetmid, (uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].lfqidx_base);
					pr_err("ID[%d] LFQ authorization remove failed for tx_id:%d, lfq_idx: %d, virtual_id: %d, lfq_id: %08x",
							dpni->id, i, j, dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_lfq[j], lfqid);
				}
			}
		}

		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

		return err1;
	}

	dpni->tx_ch[ceetm_ch_idx].lfq_authorized = 1;

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return err;
}

static int lfq_resources_deauthorization(struct dpni *dpni, int ceetm_ch_idx)
{
	struct qbman_swp *sw_portal = NULL;
	int i, j;
	int err = 0, err1 = 0;

	if( !dpni->tx_ch[ceetm_ch_idx].lfq_authorized )
		return 0;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	for (i = 0; i < dpni->max_tx_tcs; i++)
		for (j = 0; j < dpni->max_senders; j++) {
			err = resource_deauthorization(
				sw_portal, dpni->dev_ctx.amq.bdi,
				dpni->dev_ctx.amq.icid, qbman_auth_type_fqid,
				dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_lfq[j],
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-Q");
			if (err) {
				pr_err("ID[%d] Failed to remove authorization for virtual lfq %d\n", dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_lfq[j]);
				err1 = err;
			}
		}

	dpni->tx_ch[ceetm_ch_idx].lfq_authorized = 0;

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return err1;
}

static int ceetm_configure(struct dpni *dpni)
{
	struct qbman_swp *sw_portal;
	uint32_t lfqid;
	int ceetm_ch_idx;
	int i, err = 0;
	int lfq_idx, tmp;

	if (dpni->is_snic) {
		err = snic_ceetm_resources_allocation(dpni);
		CHECK_COND_RETVAL(err == 0, err);
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		for (i = 0; i < dpni->max_tx_tcs; i++) {
			dpni->tx_ch[ceetm_ch_idx].tc_tx[i].ccgid = i; /* CCG are mapped to 0-7 */
		}
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		lfq_idx = 0;
		tmp = 0;
		for( i = 0 ; i < dpni->max_tx_tcs ; i++ ) {
			if( tmp + dpni->max_senders > DPNI_MAX_SENDERS ) {
				tmp = 0;
				lfq_idx += DPNI_MAX_SENDERS;
			}
			dpni->tx_ch[ceetm_ch_idx].tc_tx[i].lfqidx_base = dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx + tmp];
			tmp += dpni->max_senders;
		}
	}

	if(!dpni->restore.en){
		/* ceetm_id and dcp_id are the same for all access points */
		for( ceetm_ch_idx = 1 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			err = (dpni->tx_ch[ceetm_ch_idx-1].ap.ceetm_id != dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id) || (dpni->tx_ch[ceetm_ch_idx-1].ap.dcp_id != dpni->tx_ch[ceetm_ch_idx].ap.dcp_id) -EPERM? : 0;
			CHECK_COND_RETVAL(err, err, "TD[%d] ceetm_id and dcp_id must be the same for all access points"
					"ap_idx: %d and %d, channel %d and %d, cfp_id %d and %d\n",
					dpni->id, ceetm_ch_idx-1, ceetm_ch_idx,
					dpni->tx_ch[ceetm_ch_idx-1].ap.ceetm_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id,
					dpni->tx_ch[ceetm_ch_idx-1].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.dcp_id);
		}

		dpni->ceetmid = qbman_ceetmid_compose((uint8_t)dpni->tx_ch[0].ap.dcp_id, (uint8_t)dpni->tx_ch[0].ap.ceetm_id);

		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			err = lfq_resources_authorization(dpni, ceetm_ch_idx);
			if( err ) {
				pr_err("ID[%d] LFQ authorization error\n", dpni->id);
				break;
			}
		}
		if( ceetm_ch_idx != dpni->num_ceetm_ch ) {
			for( ; ceetm_ch_idx >= 0 ; ceetm_ch_idx-- ) {
				err = lfq_resources_deauthorization(dpni, ceetm_ch_idx);
				CHECK_COND_RETVAL( err==0, err, "ID[%d] LFQ deauthorization error\n", dpni->id);
			}
		}

		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
			for (i = 0; i < dpni->max_tx_tcs; i++) {
				lfqid = qbman_lfqid_compose_ex(dpni->ceetmid, (uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].lfqidx_base);
				err = qbman_qpr_configure(
						sw_portal, (uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].qprid, lfqid,
						dpni->max_senders, (uint32_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].ccgid);
				if( err ) {
					pr_err("ID[%d] QPR configuration failed for channel %d, tc: %d\n", dpni->id, ceetm_ch_idx, i);
				}
		}
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		}
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		for (i = 0; i < dpni->max_senders; i++) {
			dpni->tx_ch[ceetm_ch_idx].sender_info[i].dctidx = dpni->tx_ch[ceetm_ch_idx].ap.dctidx[i];
			err = config_sender_info(dpni, ceetm_ch_idx, (uint16_t)i, &dpni->tx_ch[ceetm_ch_idx].sender_info[i]);
			CHECK_COND_RETVAL(err == 0, err, "ID[%d] config sender info failed for channel: %d sender: %d\n",
					dpni->id, ceetm_ch_idx, i);
		}
	}

	if(!dpni->restore.en){
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			for (i = 0; i < dpni->max_tx_tcs; i++) {
				if( dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_cgid==QBMAN_INVALID_VRID ) {
					err = cgid_authorization_n_configuration(
							dpni, dpni->tx_ch[ceetm_ch_idx].tc_tx[i].ccgid,
							&dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_cgid, 1, dpni->ceetmid,
							(uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid);
					if (err)
						return err;
				}
				err = config_tx_tc_ccg(dpni, ceetm_ch_idx, (uint16_t)i);
				CHECK_COND_RETVAL(err == 0, err);
			}
		}
	}

	err = config_tx_selection(dpni);
	if (err)
		return err;

	if (dpni->is_snic) {
		err = snic_ceetm_configuration(dpni);
		CHECK_COND_RETVAL(err == 0, err);
		config_eiop_ifps_pools(dpni);
		config_eiop_ifp_egress(dpni);
	}

	return err;
}

static void config_cq_channel_shaper(struct dpni *dpni,
	int ceetm_ch_idx,
	uint64_t cr_bps,
	uint64_t er_bps,
	uint32_t cr_burst_size,
	uint32_t er_burst_size,
	int coupled)
{
	struct qbman_desc desc;
	struct qbman_attr shaper_attr, channel_attr;
	struct qbman_swp *sw_portal;
	uint8_t i;
	int err;

	memset(&desc, 0x0, sizeof(struct qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				0, /* match options*/
				&desc, /* descriptor */
				NULL); /* iterator */
	ASSERT_COND(err == 0);

	err = dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	ASSERT_COND(err == 0);
	qbman_cchannel_shaper_query(sw_portal, dpni->ceetmid,
					(uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid,
					&shaper_attr);

	qbman_cscheduler_query(sw_portal, dpni->ceetmid, (uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid, 1,
			&channel_attr);

	err = dpmng_put_swportal(dpni->dpmng, &sw_portal);
	ASSERT_COND(err == 0);

	qbman_shaper_set_commit_rate(&shaper_attr, cr_bps);
	cr_burst_size = qbman_fix_burst_size(cr_burst_size, cr_bps);
	qbman_shaper_set_crtbl(&shaper_attr, cr_burst_size);
	qbman_shaper_set_excess_rate(&shaper_attr, er_bps);
	er_burst_size = qbman_fix_burst_size(er_burst_size, er_bps);
	qbman_shaper_set_ertbl(&shaper_attr, er_burst_size);
	
	qbman_shaper_set_coupling(&shaper_attr, (coupled) ? 1 : 0);

	qbman_cscheduler_set_crem_group_a(&channel_attr, (cr_bps) ? 1 : 0);
	qbman_cscheduler_set_erem_group_a(&channel_attr, (er_bps) ? 1 : 0);
	qbman_cscheduler_set_crem_group_b(&channel_attr, (cr_bps) ? 1 : 0);
	qbman_cscheduler_set_erem_group_b(&channel_attr, (er_bps) ? 1 : 0);
	for (i = 0; i < desc.ceetm_num_strict_pri_q; i++) {
		qbman_cscheduler_set_crem_cq(&channel_attr, i,
						(cr_bps) ? 1 : 0);
		qbman_cscheduler_set_erem_cq(&channel_attr, i,
						(er_bps) ? 1 : 0);
	}

	err = dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	ASSERT_COND(err == 0);
	qbman_cchannel_shaper_configure(sw_portal, dpni->ceetmid,
					(uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid,
					&shaper_attr);

	qbman_cscheduler_configure(sw_portal, dpni->ceetmid,
					(uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid,
					&channel_attr);

	err = dpmng_put_swportal(dpni->dpmng, &sw_portal);
	ASSERT_COND(err == 0);

	/* enable/disable shaped option in the channel */
	set_accesspoint_to_lni(dpni, &dpni->tx_ch[ceetm_ch_idx].ap, (cr_bps==0 && er_bps==0) ? 0 : 1);
}

static int config_lni_shaper(struct dpni *dpni,
	uint64_t cr_bps,
	uint64_t er_bps,
	uint32_t cr_burst_size,
	uint32_t er_burst_size,
	int coupled)
{
	struct qbman_swp *sw_portal;
	struct dpmac_ifg_cfg cfg;
	struct qbman_attr shaper_attr;
	uint32_t oal;
	int err = 0;

	CHECK_COND_RETVAL(dpni->ap_valid==1, -ENODEV, "ID[%d] Attempt to perform lni shaping for an unconnected object\n", dpni->id);

	if( dpni->dpmac ) {
		dpmac_get_ifg_mode(dpni->dpmac, &cfg);
	}
	else {
		pr_warn("ID[%d] Attempt to perform LNI shaping over non-mac connection\n", dpni->id);
		cfg.ipg_length = 12;
	}

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	if( cr_bps == 0 && er_bps == 0 ) {
		oal = (uint32_t)cfg.ipg_length + 12;
		if( dpni->lni_configured ) {
			if( dpni->lni_shaper_oal ) {
				oal = (uint32_t)dpni->lni_shaper_oal;
			}
		}
		err = qbman_lni_shaper_disable(sw_portal, (uint32_t)dpni->ceetmid, (uint32_t)dpni->tx_ch[0].ap.lniid, oal);
	} else {
		memset(&shaper_attr, 0, sizeof(shaper_attr));
		qbman_lni_shaper_query(sw_portal, dpni->ceetmid, (uint32_t)dpni->tx_ch[0].ap.lniid, &shaper_attr);

		oal = (uint32_t)cfg.ipg_length + 12;
		if( dpni->lni_shaper_oal ) {
			oal = (uint32_t)dpni->lni_shaper_oal;
		}

		qbman_shaper_set_oal(&shaper_attr, oal);

		qbman_shaper_set_commit_rate(&shaper_attr, cr_bps);
		cr_burst_size = qbman_fix_burst_size(cr_burst_size, cr_bps);
		qbman_shaper_set_crtbl(&shaper_attr, cr_burst_size);
		qbman_shaper_set_excess_rate(&shaper_attr, er_bps);
		er_burst_size = qbman_fix_burst_size(er_burst_size, er_bps);
		qbman_shaper_set_ertbl(&shaper_attr, er_burst_size);

		qbman_shaper_set_coupling(&shaper_attr, (coupled) ? 1 : 0);

		err = qbman_lni_shaper_configure(sw_portal, (uint32_t)dpni->ceetmid, (uint32_t)dpni->tx_ch[0].ap.lniid, &shaper_attr);
	}

	if( err ) {
		pr_err("ID[%d]: Failed to configure LNI shaper (ceetm_id: %d, lni_id: %d\n",
				dpni->id, dpni->tx_ch[0].ap.ceetm_id, dpni->tx_ch[0].ap.lniid);
	}

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return err;
}

static void disable_lni_shaping(struct dpni *dpni )
{
	struct qbman_swp *sw_portal;
	struct dpmac_ifg_cfg cfg;
	int err;

	CHECK_COND_RET(dpni->ap_valid==1, -ENODEV, "ID[%d] Attempt to perform shaping for an unconnected object\n", dpni->id);

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	if( dpni->dpmac ) {
		dpmac_get_ifg_mode(dpni->dpmac, &cfg);
	}
	else {
		cfg.ipg_length = 12;
	}

	err = qbman_lni_shaper_disable(sw_portal, (uint32_t)dpni->ceetmid, (uint32_t)dpni->tx_ch[0].ap.lniid, (uint32_t)cfg.ipg_length + 12);
	CHECK_COND_RET(err==0, err, "ID[%d] Fail to disable LNI shaping\n", dpni->id);
}


static void update_mac_single_step_config(struct dpni *dpni, struct dpni_single_step_cfg *ptp_cfg)
{
	struct dpmac_ptp_cfg cfg = {0};

	if( dpni->dpmac == NULL ) {
		if( ptp_cfg->enable )
			pr_warn("ID[%d] - dpni not connected to MAC object, IEEE 1588 single step configuration ignored\n");
		return;
	}

	cfg.enable = ptp_cfg->enable;
	cfg.offset = (uint8_t)ptp_cfg->offset;
	cfg.options = ptp_cfg->ch_update ? DPMAC_PTP_OPT_CHECKSUM_CORRECTION : 0;
	cfg.peer_delay = ptp_cfg->peer_delay;
	dpmac_set_ptp(dpni->dpmac, &cfg);
}

static void update_tx_shaping(struct dpni *dpni)
{
	struct linkman_endpoint endpoint1, endpoint2;
	struct linkman_connection_attr attr;
	uint64_t cr_bps = 0, er_bps = 0;
	uint32_t cr_burst_size = 0;
	uint32_t er_burst_size = 0;
	int err;
	int ceetm_ch_idx;

	memset(&endpoint1, 0x0, sizeof(struct linkman_endpoint));
	memset(&endpoint2, 0x0, sizeof(struct linkman_endpoint));
	memset(&attr, 0x0, sizeof(struct linkman_connection_attr));
	endpoint1.type = FSL_MOD_DPNI;
	endpoint1.id = (uint16_t)dpni->id;

	err = linkman_get_connection(dpni->linkman, &endpoint1, &endpoint2,
					&attr);

	/* only update the shaping if link is up and we have valid rate */
	if (err || (attr.state != LINKMAN_STATE_LINKUP))
		return;

	if( attr.rate > attr.max_rate )
		attr.rate = attr.max_rate;

	/* update channel shaper */
	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		cr_burst_size = dpni->tx_ch[ceetm_ch_idx].tx_cr_shaper.max_burst_size;
		er_burst_size = dpni->tx_ch[ceetm_ch_idx].tx_er_shaper.max_burst_size;
		cr_bps = 0;
		er_bps = 0;
		if (attr.rate) {
			if (dpni->tx_ch[ceetm_ch_idx].tx_cr_shaper.rate_limit > attr.rate) {
				cr_bps = attr.rate;
				er_bps = 0;
			} else if (dpni->tx_ch[ceetm_ch_idx].tx_cr_shaper.rate_limit || dpni->tx_ch[ceetm_ch_idx].tx_er_shaper.rate_limit){
				cr_bps = dpni->tx_ch[ceetm_ch_idx].tx_cr_shaper.rate_limit;
				er_bps = dpni->tx_ch[ceetm_ch_idx].tx_er_shaper.rate_limit;
				if ((dpni->tx_ch[ceetm_ch_idx].tx_cr_shaper.rate_limit + dpni->tx_ch[ceetm_ch_idx].tx_er_shaper.rate_limit) > attr.rate) {
					er_bps = attr.rate - dpni->tx_ch[ceetm_ch_idx].tx_cr_shaper.rate_limit;
				} else {
					er_bps = dpni->tx_ch[ceetm_ch_idx].tx_er_shaper.rate_limit;
				}
			} else if (endpoint2.type != FSL_MOD_DPMAC){
				cr_bps = attr.rate;
				er_bps = attr.max_rate - cr_bps;
				cr_burst_size = ceetm_if_get_max_tbl();
				er_burst_size = ceetm_if_get_max_tbl();
			}
		} else {
			cr_bps = dpni->tx_ch[ceetm_ch_idx].tx_cr_shaper.rate_limit;
			er_bps = dpni->tx_ch[ceetm_ch_idx].tx_er_shaper.rate_limit;
		}
	
		cr_bps *= 1000000;
		er_bps *= 1000000;
	
		config_cq_channel_shaper(dpni, ceetm_ch_idx, cr_bps, er_bps, cr_burst_size, er_burst_size, dpni->tx_ch[ceetm_ch_idx].shaper_coupling);
	}

	/* update LNI shaper */
	cr_burst_size = dpni->tx_lni_cr_shaper.max_burst_size;
	er_burst_size = dpni->tx_lni_er_shaper.max_burst_size;
	cr_bps = 0;
	er_bps = 0;
	if( attr.rate ) {
		if( dpni->tx_lni_cr_shaper.rate_limit > attr.rate ) {
			cr_bps = attr.rate;
			er_bps = 0;
		} else if (dpni->tx_lni_cr_shaper.rate_limit || dpni->tx_lni_er_shaper.rate_limit){
			cr_bps = dpni->tx_lni_cr_shaper.rate_limit;
			er_bps = dpni->tx_lni_er_shaper.rate_limit;
			if ((dpni->tx_lni_cr_shaper.rate_limit + dpni->tx_lni_er_shaper.rate_limit) > attr.rate) {
				er_bps = attr.rate - dpni->tx_lni_cr_shaper.rate_limit;
			} else {
				er_bps = dpni->tx_lni_er_shaper.rate_limit;
			}
		} else if (endpoint2.type != FSL_MOD_DPMAC){
			cr_bps = dpni->tx_lni_cr_shaper.rate_limit;
			er_bps = dpni->tx_lni_er_shaper.rate_limit;
			cr_burst_size = ceetm_if_get_max_tbl();
			er_burst_size = ceetm_if_get_max_tbl();
		}

		cr_bps *= 1000000;
		er_bps *= 1000000;
	}
	else {
		cr_bps = dpni->tx_lni_cr_shaper.rate_limit;
		er_bps = dpni->tx_lni_er_shaper.rate_limit;
	}

	if( dpni->lni_configured )
		config_lni_shaper(dpni, cr_bps, er_bps, cr_burst_size, er_burst_size, dpni->lni_shaper_coupling);
}

static int endpoint_integrity(struct dpni *dpni,
	const struct linkman_endpoint *peer)
{
	struct dpni *dpni_peer;

	if (peer->type == FSL_MOD_DPLAG) {
		pr_err("ID[%d]: peer type\n", dpni->id);
		return -ENOTSUP;
	}

	if (dpni->type == DPNI_TYPE_NI) {
		if (peer->type != FSL_MOD_DPNI) {
			pr_err("ID[%d]: No support for NI <=> !DPNI\n", dpni->id);
			return -ENOTSUP;
		}
		dpni_peer = sys_get_handle(FSL_MOD_DPNI, 1, peer->id);
		ASSERT_COND(dpni_peer);
		if (dpni_peer->type != DPNI_TYPE_NI) {
			pr_err("ID[%d]: No support for NI <=> !NI\n", dpni->id);
			return -ENOTSUP;
		}
	}

	if ((dpni->type == DPNI_TYPE_NIC) && (peer->type == FSL_MOD_DPNI)) {
		dpni_peer = sys_get_handle(FSL_MOD_DPNI, 1, peer->id);
		ASSERT_COND(dpni_peer);
		if (dpni_peer->type != DPNI_TYPE_NIC) {
			pr_err("ID[%d]: No support for NIC <=> !NIC\n", dpni->id);
			return -ENOTSUP;
		}
	}

	return 0;
}

static int link_state_common_denominator(const struct linkman_endpoint *ep1,
	const struct linkman_endpoint *ep2,
	uint32_t committed_rate,
	uint32_t *rate)
{
	int err = 0;

	/* 1 - negotiation, 2 - negotiation */
	if (((ep1->options & LINKMAN_LINK_OPT_AUTONEG) != 0)
		&& ((ep2->options & LINKMAN_LINK_OPT_AUTONEG) != 0)) {
		*rate = committed_rate;
	}
	/* 1 - negotiation, 2 - fixed */
	else if (((ep1->options & LINKMAN_LINK_OPT_AUTONEG) != 0)
			&& ((ep2->options & LINKMAN_LINK_OPT_AUTONEG) == 0)) {
		if (committed_rate < ep2->rate)
			return -ENOTSUP;
		*rate = ep2->rate;
	}
	/* 1 - fixed, 2 - negotiation */
	else if (((ep1->options & LINKMAN_LINK_OPT_AUTONEG) == 0)
			&& ((ep2->options & LINKMAN_LINK_OPT_AUTONEG) != 0)) {
		if (committed_rate < ep1->rate)
			return -ENOTSUP;
		*rate = ep1->rate;
	}
	/* 1 - fixed, 2 - fixed */
	else if (((ep1->options & LINKMAN_LINK_OPT_AUTONEG) == 0)
			&& ((ep2->options & LINKMAN_LINK_OPT_AUTONEG) == 0)) {
		if (ep1->rate != ep2->rate)
			return -ENOTSUP;
		*rate = ep1->rate;
	}
	return err;
}

static int dpni_empty_all_frames(struct dpni *dpni)
{
	struct 		dpni_link_state state;
	struct 		qbman_swp *sw_portal;
	struct 		qbman_attr cq_attr;
	int 		timeout;
	uint32_t 	sum;
	int 		i, tmp;
	int 		ceetm_ch_idx;
	int 		err = 0;

	err = dpni_get_link_state(dpni, &state);
	CHECK_COND_RETVAL(err == 0, err, "ID[%d]: Could not obtain link state", dpni->id);
	err = !!state.up;
	CHECK_COND_RETVAL(err == 0, -EINVAL, "ID[%d]: Link state up, cannot empty it\n", dpni->id);

	if( dpni->dpmac == NULL )
		return 0;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	sum = 0;
	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		for ( i = 0; i < dpni->max_tx_tcs; i++) {
			err = qbman_cq_query(sw_portal, dpni->ceetmid,
					(uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid,
					(uint8_t*)&tmp, &tmp,
					&cq_attr, NULL);
			if( err ) {
				pr_err("ID[%d] Failed qbman query for Tx queue; channel %d, tc: %d\n", dpni->id, ceetm_ch_idx, i);
			}
			sum += qbman_cq_num_of_frames(&cq_attr);
		}
	}
	if( !sum ) {
		/* no frames in Tx queues */
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return 0;
	}
	pr_info("ID[%d]: dpni_empty_all_frames() - Tx queues contain %d frames\n", dpni->id, sum);

	/* Steps needed to flush the frames that still exist in TX queue need to be executed
	 * in this order:
	 * 	1. disable shaping to consume frames at full speed
	 * 	2. set mac in loopback mode
	 * 	3. enable dpmac
	 * 	4. enable interface profiles
	 * 	5. enable subportal
	 */
	disable_lni_shaping(dpni);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		set_accesspoint_to_lni(dpni, &dpni->tx_ch[ceetm_ch_idx].ap, 0);
	}

	dpmac_set_loopback(dpni->dpmac, 1);

	timeout = 400;
	do {
		for( sum = 0, ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			for ( i = 0; i < dpni->max_tx_tcs; i++) {
				err = qbman_cq_query(sw_portal, dpni->ceetmid,
						(uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid,
						(uint8_t*)&tmp, &tmp,
						&cq_attr, NULL);
				if( err ) {
					pr_err("ID[%d] Failed qbman query for Tx queue; channel %d, tc: %d\n", dpni->id, ceetm_ch_idx, i);
				}
				sum += qbman_cq_num_of_frames(&cq_attr);
			}
		}
		if( sum ) {
			pr_debug("ID[%d]: dpni_empty_all_frames() - Tx queues contain %d frames\n", dpni->id, sum);
			timer_sleep(5);
		}
	} while (sum && --timeout);

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if( sum && timeout==0 ) {
		pr_err("ID[%d] empty all frames timeout, %d frames available in Tx\n", sum);
		dpmac_set_loopback(dpni->dpmac, 0);
		return -ETIMEDOUT;
	}

	/* Undo above steps */
	dpmac_set_loopback(dpni->dpmac, 0);

	return err;
}

static int event_negotiation_ok(struct dpni *dpni,
	uint32_t rate,
	uint64_t options,
	struct linkman_action *action)
{
	int err = 0;

	if (dpni->is_snic) {
		eiop_ifp_rx_enable(&dpni->snic.egress_ifp_info->ifp_desc);
		eiop_ifp_tx_enable(&dpni->snic.egress_ifp_info->ifp_desc);
	}

	if (dpni->is_snic) {
		eiop_ifp_rx_enable(&dpni->mem_ifp_info->ifp_desc);
		eiop_ifp_tx_enable(&dpni->mem_ifp_info->ifp_desc);
	}
	
	eiop_ifp_rx_enable(&dpni->snic.ingress_ifp_info->ifp_desc);

	/* Indicate to link manager to save link state */
	action->state.rate = rate;
	action->state.options = options;

	/* Require completion notification */
	action->request = LINKMAN_REQUEST_COMPLETE_CB;

	return err;
}

static int calculate_lfq_cnt(struct dpni *dpni)
{
	int tc_id;
	int cnt;
	int tmp;

	tmp = 0;
	cnt = 0;
	for( tc_id = 0 ; tc_id < dpni->max_tx_tcs ; tc_id++ ) {
		if( tmp + dpni->max_senders > DPNI_MAX_SENDERS ) {
			tmp = dpni->max_senders;
			cnt += DPNI_MAX_SENDERS;
		}
		else {
			tmp = tmp + dpni->max_senders;
		}
	}

	if( tmp )
		tmp = DPNI_MAX_SENDERS;
	cnt += tmp;

	return cnt;
}

static int event_connect_dpmac(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	int ret = 0, err1 = 0;
	int channel_ids[DPMNG_MAX_CEETM_CH];
	int ceetm_ch_idx, lfq_idx;
	int lfq_cnt;

	self->valid_fields |= LINKMAN_FIELD_IFPID;
	self->ifpid = dpni->snic.ingress_ifp_info->ifp_desc.ifp_id;

	/* get connection id */
	ret = dpmng_connection_phys_allocate(dpni->dpmng, /* dpmng context */
						peer->id, /* mac id */
						&dpni->conn_id); /* connection id */
	ASSERT_COND(!ret);
	dpni->link_res_flags |= DPNI_LINKRES_CONNECTION_ALLOCATED;

	ret = dpmng_connection_get_accesspoint(dpni->dpmng, /* dpmng context */
						dpni->conn_id, /* connection id */
						0, /* not used */
						0, /* not used */
						&dpni->tx_ch[0].ap);
	CHECK_COND_RETVAL( ret==0, ret, "ID[%d] Failed to get AP for connection\n");

	for( ceetm_ch_idx = 1 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		memcpy(&dpni->tx_ch[ceetm_ch_idx].ap, &dpni->tx_ch[0].ap, sizeof(dpni->tx_ch[0].ap));
	}

	memset(channel_ids, 0, sizeof(channel_ids));
	ret = dpmng_connection_alloc_ceetm_channel(dpni->dpmng,
			channel_ids, dpni->tx_ch[0].ap.dcp_id, dpni->tx_ch[0].ap.ceetm_id,
			dpni->num_ceetm_ch);
	CHECK_COND_RETVAL( ret == 0, ret, "ID[%d] Failed to allocate %d ceetm channels\n", dpni->id, dpni->num_ceetm_ch);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		dpni->tx_ch[ceetm_ch_idx].ap.cqchid = channel_ids[ceetm_ch_idx];
	}
	dpni->link_res_flags |= DPNI_LINKRES_CHANNEL_ALLOCATED;

	lfq_cnt = calculate_lfq_cnt(dpni);
	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));

		for( lfq_idx = 0 ; lfq_idx < lfq_cnt ; lfq_idx += DPNI_MAX_SENDERS ) {
			/* will allocate DPNI_MAX_SENDERS lfq resource at once  */
			ret = dpmng_connection_alloc_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
					dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
			if( ret ) {
				pr_err("ID[%d] Failed to allocate %d LFQID resources for channel indes %d\n",
						dpni->id, lfq_cnt, ceetm_ch_idx);
				err1 = ret;
				break;
			}
		}

		if( lfq_idx != lfq_cnt ) {
			lfq_idx -= DPNI_MAX_SENDERS;
			for( ; lfq_idx >= 0 ; lfq_idx -= DPNI_MAX_SENDERS ) {
				dpmng_connection_free_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
						dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
			}
			memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
			break;
		}
	}

	if( ceetm_ch_idx != dpni->num_ceetm_ch ) {
		ceetm_ch_idx--;
		for( ; ceetm_ch_idx >= 0 ; ceetm_ch_idx-- ) {
			for( lfq_idx = 0 ; lfq_idx < lfq_cnt ; lfq_idx += DPNI_MAX_SENDERS ) {
				/* will allocate DPNI_MAX_SENDERS lfq resource at once  */
				dpmng_connection_free_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
						dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
			}
			memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
		}
	}
	CHECK_COND_RETVAL( err1 == 0, err1, "ID[%d] LFQ allocation error\n", dpni->id);

	dpni->link_res_flags |= DPNI_LINKRES_LFQ_ALLOCATED;

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		dpni->tx_ch[ceetm_ch_idx].ap.lfq_cnt = lfq_cnt;
	}

	dpni->ap_valid = 1;

	/* Add access-point to physical port */
	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		set_accesspoint_to_lni(dpni, &dpni->tx_ch[ceetm_ch_idx].ap, 0);
	}

	ret = ceetm_configure(dpni);
	CHECK_COND_RETVAL(ret == 0, ret, "ID[%d] event_connect_dpmac ceetm configure failed", dpni->id);

	dpni->dpmac = sys_get_handle(FSL_MOD_DPMAC, 1, peer->id);
	ASSERT_COND(dpni->dpmac);
	
	if ((ret = set_tx_rejection_mode(dpni, 0)) != 0) {
			pr_err("ID[%d]: set_tx_rejection_mode failed\n", dpni->id);
			return ret;
	}
	
	config_eiop_ifp_egress(dpni);
	
	update_mac_single_step_config(dpni, &dpni->single_step_cfg);

	eiop_ifp_tx_enable(&dpni->snic.ingress_ifp_info->ifp_desc);

	dpni->link_res_flags |= DPNI_LINKRES_CONNECTED;

	return ret;
}

static int event_disconnect_dpmac(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	int ret = 0;
	uint8_t j;
	struct dpni_early_drop_cfg ed_cfg;
	struct dpni_congestion_notification_cfg notify_cfg;
	static const uint8_t zero_mac[6];
	struct dpni_single_step_cfg ptp_cfg;
	int ceetm_ch_idx;

	if( !dpni->ap_valid ) {
		/* skip over clearing frames */
		self->valid_fields |= LINKMAN_FIELD_CLEAR_TX_FRAMES;
	}
	
	if (!(self->valid_fields & LINKMAN_FIELD_CLEAR_TX_FRAMES))
	{
		if (!dpni->restore.en){
			if ((ret = set_tx_rejection_mode(dpni, 1)) != 0) {
					pr_err("ID[%d]: set_tx_rejection_mode failed\n", dpni->id);
					return ret;
			}

			/*Clear TX congestion policies*/
			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				for (j = 0; j < dpni->max_tx_tcs; j++) {
					/* store a copy of current settings */
					memcpy(&ed_cfg, &dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_early_drop,
							sizeof(struct dpni_early_drop_cfg));
					memcpy(&notify_cfg, &dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_notify,
							sizeof(struct dpni_congestion_notification_cfg));

					/* TX - reset both early-drop and congestion notification */
					memset(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_early_drop, 0, sizeof(struct dpni_early_drop_cfg));
					memset(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_notify, 0, sizeof(struct dpni_congestion_notification_cfg));
					config_tx_tc_ccg(dpni, ceetm_ch_idx, j);

					/* restore settings to be used when link will be up again */
					memcpy(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_early_drop, &ed_cfg,
							sizeof(struct dpni_early_drop_cfg));
					memcpy(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_notify, &notify_cfg,
							sizeof(struct dpni_congestion_notification_cfg));
				}
			}
		}

		dpni_update_pfc_settings(dpni, 0);

		/* In context of restore, the subportal is disabled */
		/* Do not empty frames from QMAN in this case */
		if(!dpni->restore.en) {
			dpni_empty_all_frames(dpni);
		
			dpmac_set_loopback(dpni->dpmac, 1);

			/*firstly disable tx ifp to stop enqueueing */
			if ((ret = eiop_ifp_tx_graceful_stop(
					&dpni->snic.ingress_ifp_info->ifp_desc))
					!= 0) {
				pr_err("ID[%d]: IFP egress disable failed\n", dpni->id);
				return ret;
			}

			dpmac_set_loopback(dpni->dpmac, 0);
		}

		self->valid_fields |= LINKMAN_FIELD_CLEAR_TX_FRAMES;
	}
	
	if (dpni->is_snic)
		snic_ceetm_resources_deallocation(dpni);

	if (dpni->dpmac) {
		/* Final clear for mac loopback bit - just in case this setting was changed */
		dpmac_set_loopback(dpni->dpmac, 0);

		/* clear IEE 1588 single step settings from MAC */
		memset(&ptp_cfg, 0, sizeof(ptp_cfg));
		update_mac_single_step_config(dpni, &ptp_cfg);

		/* Leave subportal enabled and ready to be used for other connections */
		dpni->dpmac = NULL;
	}

	if (((self->valid_fields & LINKMAN_FIELD_FREE_CONN_ID) == 0)) {
		if( dpni->ap_valid ) {
			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				ret = dpmng_connection_free_ceetm_channel(dpni->dpmng,
						&dpni->tx_ch[ceetm_ch_idx].ap.cqchid, dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, 1);
				if( ret ) {
					pr_err("Failed to free ceerm channel resource\n");
				}
			}
		}

		/*! free connection */
		if( dpni->link_res_flags & DPNI_LINKRES_CONNECTION_ALLOCATED ) {
			ret = dpmng_connection_free(dpni->dpmng, dpni->conn_id);
			CHECK_COND_RETVAL(ret == 0, ret, "dpmng_connection_free()\n");
			dpni->link_res_flags &= (~DPNI_LINKRES_CONNECTION_ALLOCATED);
		}

		/*! indicate virtual connection field in valid fields */
		self->valid_fields |= LINKMAN_FIELD_FREE_CONN_ID;
	}

	if( !dpni->restore.en ) {
		/* be sure LNI does not remain shaped for future connections */
		if( dpni->ap_valid )
			disable_lni_shaping(dpni);
	}
	dpni->ap_valid = 0;

	if(!dpni->restore.en){
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			ret = lfq_resources_deauthorization(dpni, ceetm_ch_idx);
			if( ret ) {
				pr_err("ID[%d] Failed to remove LFQ authorization\n", dpni->id);
			}
		}

		if( dpni->link_res_flags & DPNI_LINKRES_LFQ_ALLOCATED ) {
			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				dpmng_connection_free_lfqmtidx(dpni->dpmng, dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx,
						dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, dpni->tx_ch[ceetm_ch_idx].ap.lfq_cnt);
				memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
			}
			dpni->link_res_flags &= (~DPNI_LINKRES_LFQ_ALLOCATED);
		}

		if( dpni->link_res_flags & DPNI_LINKRES_CHANNEL_ALLOCATED ) {
			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				dpmng_connection_free_ceetm_channel(dpni->dpmng,
					&dpni->tx_ch[ceetm_ch_idx].ap.cqchid, dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, 1);
			}
			dpni->link_res_flags &= (~DPNI_LINKRES_CHANNEL_ALLOCATED);
		}

		/* set DPNI's mac address to ZERO when disconnecting the DPMAC,
		 * allowing the linux ethernet driver to randomly assign a new 
		 * mac address
		 */
		dpni_set_primary_mac_addr(dpni, zero_mac);
	}

	dpni->link_res_flags &= (~DPNI_LINKRES_CONNECTED);

	return ret;
}

static int event_linkup_dpmac(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	int ret = 0;
	uint64_t options;
	uint32_t pfc_flags;
	int tmp;

	/* Verify device state is valid */
	if (dpni->enabled == 0)
		return -EACCES;

	if (dpni->link_cfg.options & DPNI_LINK_OPT_HALF_DUPLEX)
		self->options |= LINKMAN_LINK_OPT_HALF_DUPLEX;
	if (dpni->link_cfg.options & DPNI_LINK_OPT_AUTONEG)
		self->options |= LINKMAN_LINK_OPT_AUTONEG;
	if (dpni->link_cfg.options & DPNI_LINK_OPT_PAUSE)
		self->options |= LINKMAN_LINK_OPT_PAUSE;
	if (dpni->link_cfg.options & DPNI_LINK_OPT_ASYM_PAUSE)
		self->options |= LINKMAN_LINK_OPT_ASYM_PAUSE;
	if( dpni->link_cfg.options & DPNI_LINK_OPT_PFC_PAUSE )
		self->options |= LINKMAN_LINK_OPT_PFC_PAUSE;

	self->rate = dpni->link_cfg.rate;
	self->advertising = dpni->link_cfg.advertising;
	self->valid_fields = LINKMAN_FIELD_LINK_CFG;

	self->ep_enabled = dpni->enabled;
	self->valid_fields |= LINKMAN_FIELD_LINK_STATE;

	if ((peer->valid_fields & LINKMAN_FIELD_LINK_STATE) == 0)
		return LINKMAN_ECONT;

	if (peer->link_state_available == 0)
		return 0;

	options = self->options & peer->options;

	pfc_flags = 0;
	tmp = (!!(options & LINKMAN_LINK_OPT_PAUSE)) ^ (!!(options & LINKMAN_LINK_OPT_ASYM_PAUSE));
	if( tmp ) pfc_flags |= DPNI_ENABLE_FC_SENDING;
	tmp = !!(options & LINKMAN_LINK_OPT_PAUSE);
	if( tmp ) pfc_flags |= DPNI_ENABLE_FC_RESPONSE;
	tmp = (!!(options & LINKMAN_LINK_OPT_PFC_PAUSE)) & (!!(pfc_flags & DPNI_ENABLE_FC_SENDING));
	if( tmp ) pfc_flags |= DPNI_ENABLE_PFC_SENDING;
	tmp = (!!(options & LINKMAN_LINK_OPT_PAUSE)) & (!!(options & LINKMAN_LINK_OPT_PFC_PAUSE));
	if( tmp ) pfc_flags |= DPNI_ENABLE_PFC_RESPONSE;

	dpni_update_pfc_settings(dpni, pfc_flags);

	ret = event_negotiation_ok(dpni, peer->rate, options, action);

	return ret;
}

static int event_connect_dpni(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	const struct linkman_control *control,
	struct linkman_action *action)
{
	int channel_ids[DPMNG_MAX_CEETM_CH];
	int ceetm_ch_idx, lfq_idx, lfq_cnt;
	int ret = LINKMAN_ECONT, err1 = 0;

	self->num_channels = dpni->num_ceetm_ch;	/* pass number of ceetm channels to remote object */
	self->valid_fields |= LINKMAN_FIELD_INIT;

	if( (peer->valid_fields & LINKMAN_FIELD_INIT) == 0 ) {
		return LINKMAN_ECONT;
	}

	if (((self->valid_fields & LINKMAN_FIELD_CONN_ID) == 0) && !dpni->restore.en) {
		/*! Check if virtual connection has been allocated */
		if ((peer->valid_fields & LINKMAN_FIELD_CONN_ID) == 0) {
			/*! allocate virtual connection */
			ret = dpmng_connection_virt_allocate(
				dpni->dpmng, &dpni->conn_id);
			CHECK_COND_RETVAL(ret == 0, ret, "dpmng_connection_virt_allocate() return error");
			dpni->link_res_flags |= DPNI_LINKRES_CONNECTION_ALLOCATED;

			/* Get mine accesspoint */
			ret = dpmng_connection_get_accesspoint(dpni->dpmng, /* dpmng context */
								dpni->conn_id, /* connection id */
								0, /* ap index */
								control->committed_rate,
								&dpni->tx_ch[0].ap);
			CHECK_COND_RETVAL( ret == 0, ret, "dpmng_connection_get_accesspoint() return error");

			memset(channel_ids, 0, sizeof(channel_ids));
			ret = dpmng_connection_alloc_ceetm_channel(dpni->dpmng,
					channel_ids, dpni->tx_ch[0].ap.dcp_id, dpni->tx_ch[0].ap.ceetm_id,
					dpni->num_ceetm_ch);
			CHECK_COND_RETVAL( ret==0, ret, "ID[%d] Failed to allocate ceetm channel\n", dpni->id);

			dpni->tx_ch[0].ap.cqchid = channel_ids[0];
			for( ceetm_ch_idx = 1 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				memcpy(&dpni->tx_ch[ceetm_ch_idx].ap, &dpni->tx_ch[0].ap, sizeof(struct dpmng_accesspoint));
				dpni->tx_ch[ceetm_ch_idx].ap.cqchid = channel_ids[ceetm_ch_idx];
			}
			dpni->link_res_flags |= DPNI_LINKRES_CHANNEL_ALLOCATED;

			lfq_cnt = calculate_lfq_cnt(dpni);

			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));

				for( lfq_idx = 0 ; lfq_idx < lfq_cnt ; lfq_idx += DPNI_MAX_SENDERS ) {
					/* will allocate DPNI_MAX_SENDERS lfq resource at once */
					ret = dpmng_connection_alloc_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
							dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
					if( ret ) {
						pr_err("ID[%d] Failed to allocate %d LFQID resources for channel index %d\n",
								dpni->id, lfq_cnt, ceetm_ch_idx);
						err1 = ret;
						break;
					}
				}

				if( lfq_idx != lfq_cnt ) {
					lfq_idx -= DPNI_MAX_SENDERS;
					for( ; lfq_idx >= 0 ; lfq_idx -= DPNI_MAX_SENDERS ) {
						dpmng_connection_free_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
								dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
					}
					memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
					break;
				}
			}

			if( ceetm_ch_idx != dpni->num_ceetm_ch ) {
				ceetm_ch_idx -= 1;
				for( ; ceetm_ch_idx >= 0 ; ceetm_ch_idx-- ) {
					for( lfq_idx = 0 ; lfq_idx < lfq_cnt ; lfq_idx += DPNI_MAX_SENDERS ) {
						dpmng_connection_free_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
								dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
					}
					memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
				}
			}

			CHECK_COND_RETVAL( err1 == 0, err1, "ID[%d] LFQ allocation error\n", dpni->id);

			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				dpni->tx_ch[ceetm_ch_idx].ap.lfq_cnt = lfq_cnt;
			}

			dpni->link_res_flags |= DPNI_LINKRES_LFQ_ALLOCATED;

			if( self->id!=peer->id ) {
				/* Get peer accesspoint */
				ret = dpmng_connection_get_accesspoint(dpni->dpmng, /* dpmng context */
						dpni->conn_id, /* connection id */
						1, /* ap index */
						control->committed_rate,
						&self->ap[0]);
				CHECK_COND_RETVAL( ret == 0, ret, "dpmng_connection_get_accesspoint() return error");

				memset(channel_ids, 0, sizeof(channel_ids));
				ret = dpmng_connection_alloc_ceetm_channel(dpni->dpmng,
						channel_ids, self->ap[0].dcp_id, self->ap[0].ceetm_id,
						peer->num_channels);
				CHECK_COND_RETVAL( ret == 0, ret, "ID[%d] Failed to allocate %d ceetm channels", dpni->id, peer->num_channels);

				self->ap[0].cqchid = channel_ids[0];
				for( ceetm_ch_idx = 1 ; ceetm_ch_idx < peer->num_channels ; ceetm_ch_idx++ ) {
					memcpy(&self->ap[ceetm_ch_idx], &self->ap[0], sizeof(struct dpmng_accesspoint));
					self->ap[ceetm_ch_idx].cqchid = channel_ids[ceetm_ch_idx];
				}
			}

			/* Allocate bandwidth */
			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				ret = dpmng_connection_allocate_bandwidth(
						dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap,
						control->committed_rate);
				if( ret ) {
					pr_err("ID[%d] Failed to allocate bandwidth (channel: %d)\n", dpni->id, ceetm_ch_idx);
					break;
				}
			}
			if( ret ) {
				err1 = ret;
				ceetm_ch_idx--;
				for( ; ceetm_ch_idx >= 0 ; ceetm_ch_idx-- ) {
					ret = dpmng_connection_free_bandwidth(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap);
					if( ret ) {
						pr_err("ID[%d] Cannot free bandwidth to recover after allocation error\n", dpni->id);
					}
				}
				return err1;
			}

			dpni->link_res_flags |= DPNI_LINKRES_ALLOC_BW;

			self->conn_id = dpni->conn_id;
		} else if (self->id != peer->id) {

			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
				memcpy(&dpni->tx_ch[ceetm_ch_idx].ap, &peer->ap[ceetm_ch_idx], sizeof(struct dpmng_accesspoint));
			self->conn_id = peer->conn_id;

			dpni->link_res_flags |= DPNI_LINKRES_CHANNEL_ALLOCATED;

			lfq_cnt = calculate_lfq_cnt(dpni);

			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));

				for( lfq_idx = 0 ; lfq_idx < lfq_cnt ; lfq_idx += DPNI_MAX_SENDERS ) {
					/* will allocate DPNI_MAX_SENDERS lfq resource at once */
					ret = dpmng_connection_alloc_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
							dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
					if( ret ) {
						pr_err("ID[%d] Failed to allocate %d LFQID resources for channel index %d\n",
								dpni->id, lfq_cnt, ceetm_ch_idx);
						err1 = ret;
						break;
					}
				}

				if( lfq_idx != lfq_cnt ) {
					lfq_idx -= DPNI_MAX_SENDERS;
					for( ; lfq_idx >= 0 ; lfq_idx -= DPNI_MAX_SENDERS ) {
						dpmng_connection_free_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
								dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
					}
					memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
					break;
				}
			}

			if( ceetm_ch_idx != dpni->num_ceetm_ch ) {
				ceetm_ch_idx -= 1;
				for( ; ceetm_ch_idx >= 0 ; ceetm_ch_idx-- ) {
					for( lfq_idx = 0 ; lfq_idx < lfq_cnt ; lfq_idx += DPNI_MAX_SENDERS ) {
						dpmng_connection_free_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
								dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
					}
					memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
				}
			}

			CHECK_COND_RETVAL( err1 == 0, err1, "ID[%d] LFQ allocation error\n", dpni->id);

			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				dpni->tx_ch[ceetm_ch_idx].ap.lfq_cnt = lfq_cnt;
			}

			dpni->link_res_flags |= DPNI_LINKRES_LFQ_ALLOCATED;

			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				ret = dpmng_connection_allocate_bandwidth(
						dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap,
						control->committed_rate);
				if( ret ) {
					pr_err("ID[%d] Failed to allocate bandwidth (channel: %d)\n", dpni->id, ceetm_ch_idx);
					break;
				}
			}
			if( ret ) {
				err1 = ret;
				ceetm_ch_idx--;
				for( ; ceetm_ch_idx >= 0 ; ceetm_ch_idx-- ) {
					ret = dpmng_connection_free_bandwidth(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap);
					if( ret ) {
						pr_err("ID[%d] Cannot free bandwidth to recover after allocation error\n", dpni->id);
					}
				}
				return err1;
			}

			dpni->link_res_flags |= DPNI_LINKRES_ALLOC_BW;
		} else {
			self->conn_id = peer->conn_id;
		}

		/*! indicate virtual connection field in valid fields */
		self->valid_fields |= LINKMAN_FIELD_CONN_ID;
		/*! update virtual connection id */
		dpni->conn_id = self->conn_id;
	}else{
		self->valid_fields |= LINKMAN_FIELD_CONN_ID;
	}

	if (!(peer->valid_fields & LINKMAN_FIELD_IFPID))
		return LINKMAN_ECONT;
	
	if (!(self->valid_fields & LINKMAN_FIELD_IFP_ENABLE))
	{

		dpni->snic.ingress_ifp_info->next_ifpid = peer->ifpid;
		ret = eiop_ifp_set_enqueue_ifp(
				&dpni->snic.ingress_ifp_info->ifp_desc,
				dpni->snic.ingress_ifp_info->next_ifpid);
		ASSERT_COND(!ret || (ret == -ETIMEDOUT));

		dpni->ap_valid = 1;

		set_accesspoint_to_lni(dpni, &dpni->tx_ch[0].ap, 0);

		ret = ceetm_configure(dpni);
		if (ret != 0)
			return ret;
	
		if ((ret = set_tx_rejection_mode(dpni, 0)) != 0) {
			pr_err("ID[%d]: set_tx_rejection_mode failed\n", dpni->id);
			return ret;
		}
			
		config_eiop_ifp_egress(dpni);
	
		self->valid_fields |= LINKMAN_FIELD_IFP_ENABLE;
	}
	
	if (!(peer->valid_fields & LINKMAN_FIELD_IFP_ENABLE))
			return LINKMAN_ECONT;
		
	eiop_ifp_tx_enable(&dpni->snic.ingress_ifp_info->ifp_desc);

	dpni->dpni = sys_get_handle(FSL_MOD_DPNI, 1, peer->id);

	dpni->link_res_flags |= DPNI_LINKRES_CONNECTED;
	ret = 0; /* Done */

	return ret;
}

static int event_disconnect_dpni(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	int err = 0;
	uint8_t j;
	struct dpni_early_drop_cfg ed_cfg;
	struct dpni_congestion_notification_cfg notify_cfg;
	int ceetm_ch_idx;

	if (dpni->is_snic)
		snic_ceetm_resources_deallocation(dpni);
	if(!dpni->restore.en)
		if ((err = set_tx_rejection_mode(dpni, 1)) != 0) {
			pr_err("ID[%d]: set_tx_rejection_mode failed\n", dpni->id);
			return err;
		}

	if( (dpni->link_res_flags & DPNI_LINKRES_CONNECTED) == 0 ) {
		/* connect failed for some reason, skip over flow control cleanup */
		self->options |= LINKMAN_FIELD_CLEANUP_PFC;
	}

	if( !(self->options & LINKMAN_FIELD_CLEANUP_PFC) ) {
		dpni_update_pfc_settings(dpni, 0);
		self->options |= LINKMAN_FIELD_CLEANUP_PFC;
	}
	if( !(peer->options & LINKMAN_FIELD_CLEANUP_PFC) ) {
		return LINKMAN_ECONT;
	}

	if( dpni->fc_idx != FLOW_CONTROL_INVALID_INDEX ) {
		if( !peer->fc_disabled )
			fc_release_channel_idx(dpni->fc_idx);
		dpni->fc_idx = FLOW_CONTROL_INVALID_INDEX;
		self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
		self->fc_disabled = 1;
	}
	else {
		self->fc_disabled = 1;
	}

	if( !peer->fc_disabled ) {
		return LINKMAN_ECONT;
	}

	if(!dpni->restore.en){
		/*Clear TX congestion policies*/
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			for (j = 0; j < dpni->max_tx_tcs; j++) {
				/* store a copy of current settings */
				memcpy(&ed_cfg, &dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_early_drop,
						sizeof(struct dpni_early_drop_cfg));
				memcpy(&notify_cfg, &dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_notify,
						sizeof(struct dpni_congestion_notification_cfg));

				/* TX - reset both early-drop and congestion notification */
				memset(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_early_drop, 0, sizeof(struct dpni_early_drop_cfg));
				memset(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_notify, 0, sizeof(struct dpni_congestion_notification_cfg));
				config_tx_tc_ccg(dpni, ceetm_ch_idx, j);

				/* restore settings to be used when link will be up again */
				memcpy(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_early_drop, &ed_cfg,
						sizeof(struct dpni_early_drop_cfg));
				memcpy(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_notify, &notify_cfg,
						sizeof(struct dpni_congestion_notification_cfg));
			}
		}
	}

	if ((err = eiop_ifp_tx_graceful_stop(
		&dpni->snic.ingress_ifp_info->ifp_desc))
		!= 0) {
		pr_err("ID[%d]: IFP egress disable failed\n", dpni->id);
		return err;
	}

	if (((self->valid_fields & LINKMAN_FIELD_FREE_CONN_ID) == 0) && !dpni->restore.en) {
		if ((peer->valid_fields & LINKMAN_FIELD_FREE_CONN_ID) == 0) {
			/*! free connection */
			err = dpmng_connection_free(dpni->dpmng,
							dpni->conn_id);
			if (err != 0)
				return err;
		}

		/*! indicate virtual connection field in valid fields */
		self->valid_fields |= LINKMAN_FIELD_FREE_CONN_ID;

		if( self->id == peer->id ) {
			/* connection on the same dpni */
			if( peer->valid_fields & LINKMAN_FIELD_ALLOCATE_CR ) {
				/* Commiterd rate deallocated by peer */
				self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
			}
			else if( (self->valid_fields & LINKMAN_FIELD_ALLOCATE_CR) == 0) {
				if( dpni->link_res_flags & DPNI_LINKRES_ALLOC_BW )
					for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
						err = dpmng_connection_free_bandwidth(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap);
						if (err != 0) {
							pr_err("ID[%d] Failed to free connection bandwidth for channel %d\n", dpni->id, ceetm_ch_idx);
						}
					}
				self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
			}
			dpni->link_res_flags &= (~DPNI_LINKRES_ALLOC_BW);

			if( (peer->valid_fields & LINKMAN_FIELD_ALLOCATE_CR) == 0 )
				return LINKMAN_ECONT;
		}
		else {
			if( (self->valid_fields & LINKMAN_FIELD_ALLOCATE_CR) == 0 ) {
				if( dpni->link_res_flags & DPNI_LINKRES_ALLOC_BW )
					for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
						err = dpmng_connection_free_bandwidth(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap);
						if (err != 0) {
							pr_err("ID[%d] Failed to free connection bandwidth for channel %d\n", dpni->id, ceetm_ch_idx);
						}
					}
				dpni->link_res_flags &= (~DPNI_LINKRES_ALLOC_BW);
				self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
			}

			if( (peer->valid_fields & LINKMAN_FIELD_ALLOCATE_CR) == 0 )
				return LINKMAN_ECONT;
		}
	}

	if(!dpni->restore.en) {
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			err = lfq_resources_deauthorization(dpni, ceetm_ch_idx);
			if( err ) {
				pr_err("ID[%d] Failed to remove LFQ authorization for channel %d\n", dpni->id, ceetm_ch_idx);
			}
		}

		if( dpni->link_res_flags & DPNI_LINKRES_LFQ_ALLOCATED ) {
			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				dpmng_connection_free_lfqmtidx(dpni->dpmng, dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx,
						dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, dpni->tx_ch[ceetm_ch_idx].ap.lfq_cnt);
				memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
			}
			dpni->link_res_flags &= (~DPNI_LINKRES_LFQ_ALLOCATED);
		}

		if( dpni->link_res_flags & DPNI_LINKRES_CHANNEL_ALLOCATED ) {
			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				dpmng_connection_free_ceetm_channel(dpni->dpmng,
					&dpni->tx_ch[ceetm_ch_idx].ap.cqchid, dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, 1);
			}
			dpni->link_res_flags &= (~DPNI_LINKRES_CHANNEL_ALLOCATED);
		}

		/* be sure LNI does not remain shaped for future connections */
		if( dpni->ap_valid )
			disable_lni_shaping(dpni);
	}

	dpni->link_res_flags &= (~DPNI_LINKRES_CONNECTED);
	dpni->ap_valid = 0;
	dpni->dpni = NULL;

	return err;
}

static int event_connect_master_dp_object(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	const struct linkman_control *control,
	struct linkman_action *action)
{
	uint32_t dpdmux_phase1, dpdmux_phase2;
	int ceetm_ch_idx;
	int ret = LINKMAN_ECONT, err1 = 0;
	int lfq_cnt = 0, lfq_idx = 0;

	self->num_channels = dpni->num_ceetm_ch;	/* pass number of ceetm channels to remote object */
	self->valid_fields |= LINKMAN_FIELD_INIT;

	if( (peer->valid_fields & LINKMAN_FIELD_INIT) == 0 ) {
		return LINKMAN_ECONT;
	}

	if ((ret = set_tx_rejection_mode(dpni, 0)) != 0) {
		pr_err("ID[%d]: set_tx_rejection_mode failed\n", dpni->id);
		return ret;
	}

	dpdmux_phase1 = (LINKMAN_FIELD_IFPID | LINKMAN_FIELD_DPDMUX_METHOD);
	dpdmux_phase2 = dpdmux_phase1
			| (LINKMAN_FIELD_TID | LINKMAN_FIELD_KID);

	if (peer->type == FSL_MOD_DPDMUX) {
		if ((peer->valid_fields & dpdmux_phase2) == dpdmux_phase2) {
			/* second time after visit in DPDMUX.
			 * now can update filters tables in dpdmux */
			populate_tables_to_dpdmux(dpni, 0); /* remove tables */
		} else {
			if (peer->valid_fields & LINKMAN_FIELD_DPDMUX_METHOD)
				dpni->dpdmux_method =
					(enum dpdmux_method)peer->dpdmux_method;
			else
				return LINKMAN_ECONT;

			/* first time after visit in DPDMUX.
			 * get handle and provide kid&tid */
			dpni->dpdmux = sys_get_handle(FSL_MOD_DPDMUX, 1,
							peer->id);
			ASSERT_COND(dpni->dpdmux);
			dpni->dpdmux_if_id = peer->if_id;

			fill_dpdmux_kid_tid(dpni, &self->tid, &self->kid);
			self->valid_fields |= LINKMAN_FIELD_KID
						| LINKMAN_FIELD_TID;

			return LINKMAN_ECONT;
		}
	}

	if (peer->valid_fields & LINKMAN_FIELD_AP_AVAILABLE) {
		if (peer->ap_available == 0)
			return 0; /* Done */

		/* Copy  NIC's accesspoint */
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			memcpy(&dpni->tx_ch[ceetm_ch_idx].ap, &peer->ap[ceetm_ch_idx], sizeof(struct dpmng_accesspoint));
		}
		dpni->link_res_flags |= DPNI_LINKRES_CHANNEL_ALLOCATED;

		lfq_cnt = calculate_lfq_cnt(dpni);

		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));

			for( lfq_idx = 0 ; lfq_idx < lfq_cnt ; lfq_idx += DPNI_MAX_SENDERS ) {
				/* will allocate DPNI_MAX_SENDERS lfq resource at once */
				ret = dpmng_connection_alloc_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
						dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
				if( ret ) {
					pr_err("ID[%d] Failed to allocate %d LFQID resources for channel index %d\n",
							dpni->id, lfq_cnt, ceetm_ch_idx);
					err1 = ret;
					break;
				}
			}

			if( lfq_idx != lfq_cnt ) {
				lfq_idx -= DPNI_MAX_SENDERS;
				for( ; lfq_idx >= 0 ; lfq_idx -= DPNI_MAX_SENDERS ) {
					dpmng_connection_free_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
							dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
				}
				memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
				break;
			}
		}

		if( ceetm_ch_idx != dpni->num_ceetm_ch ) {
			ceetm_ch_idx -= 1;
			for( ; ceetm_ch_idx >= 0 ; ceetm_ch_idx-- ) {
				for( lfq_idx = 0 ; lfq_idx < lfq_cnt ; lfq_idx += DPNI_MAX_SENDERS ) {
					dpmng_connection_free_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
							dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
				}
				memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
			}
		}

		CHECK_COND_RETVAL( err1 == 0, err1, "ID[%d] LFQ allocation error\n", dpni->id);

		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			dpni->tx_ch[ceetm_ch_idx].ap.lfq_cnt = lfq_cnt;
		}

		dpni->link_res_flags |= DPNI_LINKRES_LFQ_ALLOCATED;

		dpni->ap_valid = 1;

		/* Add access-point to physical port */
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			set_accesspoint_to_lni(dpni, &dpni->tx_ch[ceetm_ch_idx].ap, 0);
		}

		ret = ceetm_configure(dpni);
		CHECK_COND_RETVAL( ret==0, ret, "ID[%d] CEETM configure failed\n", dpni->id);
	} else
		return LINKMAN_ECONT;

	if (peer->valid_fields & LINKMAN_FIELD_IFPID) {
		dpni->snic.ingress_ifp_info->next_ifpid = peer->ifpid;
		ret = eiop_ifp_set_enqueue_ifp(
			&dpni->snic.ingress_ifp_info->ifp_desc,
			dpni->snic.ingress_ifp_info->next_ifpid);
		EIOP_ASSERT_COND(ret);

		eiop_ifp_tx_enable(&dpni->snic.ingress_ifp_info->ifp_desc);

	} else
		return LINKMAN_ECONT;

	if (peer->valid_fields & LINKMAN_FIELD_ALLOCATE_CR) {

		if (peer->allocate_cr == 0)
			return 0; /* Done */

		if ((self->valid_fields & LINKMAN_FIELD_ALLOCATE_CR) == 0) {
			/* Allocate bandwidth */
			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
				ret = dpmng_connection_allocate_bandwidth(
						dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap,
						control->committed_rate);
				if( ret ) {
					pr_err("ID[%d] Fail to allocate bandwidth for channel %d\n", dpni->id, ceetm_ch_idx);
					err1 = ret;
					break;
				}
			}
			if( ceetm_ch_idx != dpni->num_ceetm_ch ) {
				for( ; ceetm_ch_idx >=0 ; ceetm_ch_idx-- ) {
					ret = dpmng_connection_free_bandwidth(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap);
					if( ret )
						pr_err("ID[%d] Faled to release bandwidth\n", dpni->id);
				}
			}
			CHECK_COND_RETVAL(err1 == 0, err1, "dpmng_connection_allocate_bandwidth() return error\n");
			dpni->link_res_flags |= DPNI_LINKRES_ALLOC_BW;

			self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
		}
	} else
		return LINKMAN_ECONT;

	dpni->link_res_flags |= DPNI_LINKRES_CONNECTED;

	return ret;

}

static int event_disconnect_master_dp_object(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	int err = LINKMAN_ECONT;
	uint8_t j;
	struct dpni_early_drop_cfg ed_cfg;
	struct dpni_congestion_notification_cfg notify_cfg;
	uint32_t pfc_flags;
	int ceetm_ch_idx;

	if( !( self->valid_fields & LINKMAN_FIELD_LINK_CFG ) ) {
		/* copy data about link configuration in self and peer structures */
		self->fc_channel_idx = dpni->fc_idx;
		self->valid_fields |= LINKMAN_FIELD_LINK_CFG;
		return LINKMAN_ECONT;
	}

	if( !( self->valid_fields & LINKMAN_FIELD_PFC_CONFIG ) ) {
		/* check flow control configuration */
		if( ( self->fc_channel_idx==FLOW_CONTROL_INVALID_INDEX && peer->fc_channel_idx!=FLOW_CONTROL_INVALID_INDEX ) ||
			( self->fc_channel_idx!=FLOW_CONTROL_INVALID_INDEX && peer->fc_channel_idx==FLOW_CONTROL_INVALID_INDEX ) )
		{
			pr_err(	"[ID%d] Invalid flow control configuration; self(%d) peer(%d); MC will set some default values to continue... "
					"Future flow control configuration may fail\n", dpni->id, self->fc_channel_idx, peer->fc_channel_idx);
			self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
			dpni->fc_idx = FLOW_CONTROL_INVALID_INDEX;
		}
		self->valid_fields |= LINKMAN_FIELD_PFC_CONFIG;
		return LINKMAN_ECONT;
	}

	if( self->fc_channel_idx == FLOW_CONTROL_INVALID_INDEX ) {
		/* Flow control not enabled, perform flag exchange*/
		if( !self->fc_disabled ) {
			self->fc_disabled = 1;
		}
		if( !peer->fc_disabled ) {
			return LINKMAN_ECONT;
		}
	} else if( dpni->fc_idx != FLOW_CONTROL_INVALID_INDEX ) {
		/* flow control is enabled */
		if( !self->fc_disabled ) {
			/* disable flow control settings */
			pfc_flags = 0;
			dpni_update_pfc_settings(dpni, pfc_flags);
			self->fc_disabled = 1;
		}

		if( !peer->fc_disabled ) {
			/* wait for peer to disable flow control settings */
			return LINKMAN_ECONT;
		}

		if( peer->fc_channel_idx != FLOW_CONTROL_INVALID_INDEX ) {
			/* flow control channel index not released by peer */
			if( self->fc_channel_idx != FLOW_CONTROL_INVALID_INDEX ) {
				/* release flow control */
				fc_release_channel_idx(dpni->fc_idx);
				dpni->fc_idx = FLOW_CONTROL_INVALID_INDEX;
				self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
				return LINKMAN_ECONT;
			}
		} else {
			/* flow control channel index released by peer */
			dpni->fc_idx = FLOW_CONTROL_INVALID_INDEX;
			self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
		}
	}

	if ( (peer->valid_fields & LINKMAN_FIELD_ALLOCATE_CR)==0 )
		return LINKMAN_ECONT;

	if (dpni->is_snic)
		snic_ceetm_resources_deallocation(dpni);
	
	if ((err = set_tx_rejection_mode(dpni, 1)) != 0) {
		pr_err("ID[%d]: set_tx_rejection_mode failed\n", dpni->id);
		return err;
	}
	
	/*Clear TX congestion policies*/
	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		for (j = 0; j < dpni->max_tx_tcs; j++) {
			/* store a copy of current settings */
			memcpy(&ed_cfg, &dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_early_drop,
					sizeof(struct dpni_early_drop_cfg));
			memcpy(&notify_cfg, &dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_notify,
					sizeof(struct dpni_congestion_notification_cfg));

			/* TX - reset both early-drop and congestion notification */
			memset(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_early_drop, 0, sizeof(struct dpni_early_drop_cfg));
			memset(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_notify, 0, sizeof(struct dpni_congestion_notification_cfg));
			config_tx_tc_ccg(dpni, ceetm_ch_idx, j);

			/* restore settings to be used when link will be up again */
			memcpy(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_early_drop, &ed_cfg,
				sizeof(struct dpni_early_drop_cfg));
			memcpy(&dpni->tx_ch[ceetm_ch_idx].tc_tx[j].cg_notify, &notify_cfg,
				sizeof(struct dpni_congestion_notification_cfg));
		}
	}
	
	if ((err = eiop_ifp_tx_graceful_stop(
		&dpni->snic.ingress_ifp_info->ifp_desc))
		!= 0) {
		pr_err("ID[%d]: IFP egress disable failed\n", dpni->id);
		return err;
	}
	
	if (dpni->dpdmux) {
		populate_tables_to_dpdmux(dpni, 1); /* remove tables */

		dpni->dpdmux = NULL;
		/* need to reset the FALU */
		config_ctlu_policy(dpni, 1);
	}

	if (peer->valid_fields & LINKMAN_FIELD_ALLOCATE_CR) {
		if ((self->valid_fields & LINKMAN_FIELD_ALLOCATE_CR) == 0) {
			if (peer->allocate_cr) {
				/* Deallocate bandwidth */
				if( dpni->link_res_flags & DPNI_LINKRES_ALLOC_BW) {
					for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
						err = dpmng_connection_free_bandwidth(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap);
						if( err ) {
							pr_err("ID[%d] Failed to free connection bandwidth\n", dpni->id);
						}
					}
					dpni->link_res_flags &= (~DPNI_LINKRES_ALLOC_BW);
				}
			}
			self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
		}
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		err = lfq_resources_deauthorization(dpni, ceetm_ch_idx);
		if( err ) {
			pr_err("ID[%d] Failed to remove LFQ authorization for channel %d\n", dpni->id, ceetm_ch_idx);
		}
	}

	if( dpni->link_res_flags & DPNI_LINKRES_LFQ_ALLOCATED ) {
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			dpmng_connection_free_lfqmtidx(dpni->dpmng, dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx,
					dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, dpni->tx_ch[ceetm_ch_idx].ap.lfq_cnt);
			memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
		}
		dpni->link_res_flags &= (~DPNI_LINKRES_LFQ_ALLOCATED);
	}

	if( !dpni->restore.en ) {
		/* be sure LNI does not remain shaped for future connections */
		if( dpni->ap_valid )
			disable_lni_shaping(dpni);
	}

	if( dpni->link_res_flags & DPNI_LINKRES_CHANNEL_ALLOCATED ) {
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			dpmng_connection_free_ceetm_channel(dpni->dpmng,
				&dpni->tx_ch[ceetm_ch_idx].ap.cqchid, dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, 1);
		}
		dpni->link_res_flags &= (~DPNI_LINKRES_CHANNEL_ALLOCATED);
	}

	dpni->link_res_flags &= (~DPNI_LINKRES_CONNECTED);
	dpni->ap_valid = 0;

	return 0;
}

int dpni_get_ap_ppid(struct dpni *dpni, int *ppid)
{
	if( dpni->ap_valid )
		*ppid = dpni->tx_ch[0].ap.ppid;
	else
		return -ENOTSUP;

	return 0;
}

static int dpni_get_remote_ppid(struct dpni *dpni, int *ppid)
{
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr link_attr;
	void *object;
	int err;

	*ppid = -1;

	if( dpni->dpmac ) {
		*ppid = dpmac_get_ppid(dpni->dpmac);
	} else {
		memset(&endpoint1, 0, sizeof(endpoint1));
		memset(&endpoint2, 0, sizeof(endpoint2));
		memset(&link_attr, 0, sizeof(link_attr));

		endpoint1.type = FSL_MOD_DPNI;
		endpoint1.id = (uint16_t)dpni->id;
		err = linkman_get_connection(dpni->linkman, &endpoint1, &endpoint2, &link_attr);
		CHECK_COND_RETVAL(err==0, err, "Could not get connected object to dpni.%d\n", dpni->id);

		object = sys_get_handle(endpoint2.type, 1, endpoint2.id);
		CHECK_COND_RETVAL(object, -ENODEV, "[ID: %d] Could not get connected object\n", dpni->id);
		switch( endpoint2.type ) {
		case FSL_MOD_DPNI:
			err = dpni_get_ap_ppid((struct dpni *)object, ppid);
			CHECK_COND_RETVAL(err==0, err, "dpni_get_ap_ppid() return error\n");
			break;
		case FSL_MOD_DPSW:
			err = dpsw_get_ap_ppid((struct dpsw *)object, endpoint2.if_id, ppid);
			CHECK_COND_RETVAL(err==0, err, "dpsw_get_ap_ppid() return error\n");
			break;
		case FSL_MOD_DPDMUX:
			err = dpdmux_get_ap_ppid((struct dpdmux *)object, endpoint2.if_id, ppid);
			CHECK_COND_RETVAL(err==0, err, "dpdmux_get_ap_ppid() return error\n");
			break;
		}
	}

	return 0;
}

static int dpni_config_ppid_priority(struct dpni *dpni, uint16_t cgid, char type, uint8_t prio_mask, int cmd)
{
	int ppid = -1;
	struct eiop_cgp cgp = { 0 };
	struct eiop_port_desc eiop_port_desc = {0};
	int err = 0;

	err = !(type==EIOP_CGP_CONGESTION_GROUP || type==EIOP_CGP_BUFFER_DEPLETION);
	CHECK_COND_RETVAL(err==0, -EINVAL, "Invalid congestion group type: %d\n", type);

	err = dpni_get_remote_ppid(dpni, &ppid);
	CHECK_COND_RETVAL(err==0, err, "Could not get ppid; flow control feature will not work\n");
	eiop_port_desc.port_id = ppid;
	err = sys_get_desc(SOC_MODULE_EIOP_PORT, SOC_DB_PORT_DESC_ID, &eiop_port_desc, NULL);
	CHECK_COND_RETVAL(err==0, err, "Could not get eiop port descriptor; flow control feature will not work\n");

	cgp.type = type;
	cgp.id   = cgid;
	cgp.bits = prio_mask;
	eiop_port_set_cgp(&eiop_port_desc, &cgp, cmd);

	return 0;
}

static int set_buffer_depletion_priority(struct dpni *dpni, int enable_tx, int enable_pfc, int dpni_enable)
{
	int num_pools;
	int i;
	uint8_t prio_mask;
	int cmd = 0;
	int bpid;
	int err;

	num_pools = dpni->pools_cfg.num_dpbp;
	for( i=0 ; i<num_pools ; i++ ) {
		if( dpni->dpmac ) {
			// this case can use priority flow control
			prio_mask = dpni->pools_cfg.pools[i].priority;
			prio_mask = enable_tx?(enable_pfc?prio_mask:0xff):0x00;
			prio_mask = dpni_enable?prio_mask:0x00;
			cmd = 2;
		}
		else {
			// this case will use simple flow control
			prio_mask = dpni->fc_idx != FLOW_CONTROL_INVALID_INDEX ? 0x01 << dpni->fc_idx : 0x00;
			cmd = !!(enable_tx && dpni_enable);
		}

		bpid = dpbp_get_bpid(dpni->pools_cfg.pools[i].dpbp);
		err = dpni_config_ppid_priority(dpni, (uint16_t)bpid, EIOP_CGP_BUFFER_DEPLETION, prio_mask, cmd);
		CHECK_COND_RETVAL(err==0, err, "Could not update buffer pool trigger to enable flow control");
	}

	return 0;
}

static int update_buffer_depletion_priority(struct dpni *dpni, uint32_t flags)
{
	int enable_tx;
	int enable_pfc;
	int err;

	enable_tx = !!(flags & DPNI_ENABLE_FC_SENDING);		// send flow control frames
	enable_pfc = !!(flags & DPNI_ENABLE_PFC_SENDING);	// send priority flow control frames

	err = set_buffer_depletion_priority(dpni, enable_tx, enable_pfc, !!flags);
	CHECK_COND_RETVAL(err==0, err);

	return 0;
}

static int event_linkup_virt(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	const struct linkman_control *control,
	struct linkman_action *action)
{
	uint32_t rate;
	int ret = LINKMAN_ECONT;
	uint64_t options;
	int ch_idx;
	uint32_t pfc_flags;
	int tmp;

	/* Verify device state is valid */
	if (dpni->enabled == 0)
		return -EACCES;

	/* Advertise capabilities */
	if( !(self->valid_fields & LINKMAN_FIELD_LINK_CFG) ) {
		self->valid_fields |= LINKMAN_FIELD_LINK_CFG;

		self->rate = dpni->link_cfg.rate;
		if (dpni->link_cfg.options & DPNI_LINK_OPT_HALF_DUPLEX)
			self->options |= LINKMAN_LINK_OPT_HALF_DUPLEX;
		if (dpni->link_cfg.options & DPNI_LINK_OPT_AUTONEG)
			self->options |= LINKMAN_LINK_OPT_AUTONEG;
		if (dpni->link_cfg.options & DPNI_LINK_OPT_PAUSE)
			self->options |= LINKMAN_LINK_OPT_PAUSE;
		if (dpni->link_cfg.options & DPNI_LINK_OPT_ASYM_PAUSE)
			self->options |= LINKMAN_LINK_OPT_ASYM_PAUSE;
		if( dpni->link_cfg.options & DPNI_LINK_OPT_PFC_PAUSE )
			self->options |= LINKMAN_LINK_OPT_PFC_PAUSE;
	}

	if( self->options & LINKMAN_LINK_OPT_ASYM_PAUSE ) {
		/* LINK_OPT_ASYM_PAUSE pause not supported at all, so it must be cleared */
		self->options &= ~(LINKMAN_LINK_OPT_PAUSE | LINKMAN_LINK_OPT_ASYM_PAUSE);
		return LINKMAN_ECONT;
	}

	if ( !(peer->valid_fields & LINKMAN_FIELD_LINK_CFG) ) {
		return LINKMAN_ECONT;
	}

	ret = link_state_common_denominator(
		self, peer, control->committed_rate, &rate);
	CHECK_COND_RETVAL(ret == 0, ret, "link_state_common_denominator() failed" );

	if( peer->type == FSL_MOD_DPNI || peer->type == FSL_MOD_DPSW || peer->type == FSL_MOD_DPDMUX ) {
		// check options with remote dpni
		options = self->options & peer->options;
		if( self->options != options ) {
			pr_warn("ID[%d]: Not all options set are supported on remote end\n", dpni->id);
			if( (self->options & LINKMAN_LINK_OPT_PAUSE) && !(options & LINKMAN_LINK_OPT_PAUSE) )
				pr_warn("ID[%d]: DPNI_LINK_OPT_PAUSE not supported on remote, disabled\n", dpni->id);
			if( (self->options & LINKMAN_LINK_OPT_ASYM_PAUSE) && !(options & LINKMAN_LINK_OPT_ASYM_PAUSE) )
				pr_warn("ID[%d]: DPNI_LINK_OPT_ASYM_PAUSE not supported on remote, disabled\n", dpni->id);
			if( (self->options & DPNI_LINK_OPT_PFC_PAUSE) && !(options & LINKMAN_LINK_OPT_PFC_PAUSE) )
				pr_warn("ID[%d]: LINKMAN_LINK_OPT_PFC_PAUSE not supported on remote, disabled\n", dpni->id);
		}

		/* Do not remove AUTONEG flag if peer is not configured with AUTONEG capability */
		self->options = options | (self->options & LINKMAN_LINK_OPT_AUTONEG);

		if( self->options & LINKMAN_LINK_OPT_PAUSE ) {
			if( dpni->fc_idx != FLOW_CONTROL_INVALID_INDEX && !peer->fc_available ) {
				self->fc_channel_idx = dpni->fc_idx;
				self->fc_available = 1;
				return LINKMAN_ECONT;
			}

			if( peer->fc_available ) {
				dpni->fc_idx = peer->fc_channel_idx;
				self->fc_channel_idx = peer->fc_channel_idx;
				self->fc_available = 1;
			} else {
				ch_idx = fc_get_next_channel_idx();
				if( ch_idx < 0 ) {
					self->options &= ~LINKMAN_LINK_OPT_PAUSE;
					pr_err("[ID%d] No channels available to implement flow control on linkup; clear PAUSE flag\n", dpni->id);
					return LINKMAN_ECONT;	/* execute again for peer */
				} else {
					self->fc_channel_idx = ch_idx;
					self->fc_available = 1;
					dpni->fc_idx = self->fc_channel_idx;
					return LINKMAN_ECONT;	/* execute again to pass same setting to peer */
				}
			}

			pfc_flags = 0;
			tmp = !!(self->options & LINKMAN_LINK_OPT_PAUSE);
			if( tmp ) pfc_flags |= (DPNI_ENABLE_FC_SENDING | DPNI_ENABLE_FC_RESPONSE);
			dpni_update_pfc_settings(dpni, pfc_flags);
		} else {
			/* pause not enabled */
			if( dpni->fc_idx != FLOW_CONTROL_INVALID_INDEX ) {
				/* pause was previously enabled 
				 * disable current settings and free flow control resource */
				if( !self->fc_available ) {
					pfc_flags = 0;
					dpni_update_pfc_settings(dpni, pfc_flags);
					self->fc_available = 1;
				}

				/* wait for peer to disable FC*/
				if( !peer->fc_available )
					return LINKMAN_ECONT;

				/* if peer does not free the resources */
				if( peer->fc_channel_idx != FLOW_CONTROL_INVALID_INDEX ) {
					fc_release_channel_idx(dpni->fc_idx);
				}

				/* clear data */
				dpni->fc_idx = FLOW_CONTROL_INVALID_INDEX;
				self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
			}
		}
	}

	ret = event_negotiation_ok(dpni, rate, self->options, action);

	return ret;
}

static int event_linkdown(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr cq_attr;
	uint32_t sum, timeout = 1;
	int tmp, i;
	int ret = 0; /* Done */
	int ceetm_ch_idx;
	
	if ((dpni->dpmac)
		&& !(peer->valid_fields & LINKMAN_FIELD_DPMAC_RX_DIS))
		return LINKMAN_ECONT;
	
	if ((ret = eiop_ifp_rx_graceful_stop(
		&dpni->snic.ingress_ifp_info->ifp_desc))
		!= 0) {
		pr_err("ID[%d]: IFP ingress disable failed\n", dpni->id);
		return ret;
	}

	if (dpni->is_snic) {
		if ((ret = eiop_ifp_tx_graceful_stop(
			&dpni->mem_ifp_info->ifp_desc))
			!= 0) {
			pr_err("ID[%d]: IFP egress enable failed\n", dpni->id);
			return ret;
		}

		if ((ret = eiop_ifp_rx_graceful_stop(
			&dpni->mem_ifp_info->ifp_desc))
			!= 0) {
			pr_err("ID[%d]: IFP ingress enable failed\n", dpni->id);
			return ret;
		}
	}
#if 0
	/* 2. wait till frame-counter equal '0' on all rx-queues and
	 * all tasks finished */
	do {
		for (sum = 0, i = 0; i < dpni->max_tcs; i++) {
			/* sum += read_frame_cnt of dpni->tc_rx[i].class_qid */
		}
	}while (sum && --timeout);
	if (!timeout) {
		pr_err("ID[%d]: empty ingress queues failed\n", dpni->id);
		self->state = LINKMAN_LINK_FAILURE;
		return;
	}
#endif

	/* disable subportal to stop dequeues from TX queues */
	if( !dpni->dpmac && !dpni->restore.en) {
		/* Recycle ports: Disable shaping and wait till frame-counter
		 * equal '0' for all tx-queues. */
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
			set_accesspoint_to_lni(dpni, &dpni->tx_ch[ceetm_ch_idx].ap, 0);
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		timeout = 1000;
		do {
			for( sum = 0, ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
				for ( i = 0; i < dpni->max_tx_tcs; i++) {
					ret = qbman_cq_query(sw_portal, dpni->ceetmid,
							(uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid,
							(uint8_t*)&tmp, &tmp,
							&cq_attr, NULL);
					if( ret == 0)
						sum += qbman_cq_num_of_frames(&cq_attr);
					else
						pr_err("ID[%d] Fail to query frames for channel %d tc %d\n", dpni->id, ceetm_ch_idx, i);
				}
		} while (sum && --timeout);
	}
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (!timeout) {
		pr_err("ID[%d]: empty egress queues failed\n", dpni->id);
		return -ETIMEDOUT;
	}

	if (dpni->is_snic) {
		if ((ret = eiop_ifp_tx_graceful_stop(
			&dpni->snic.egress_ifp_info->ifp_desc))
			!= 0) {
			pr_err("ID[%d]: IFP egress enable failed\n", dpni->id);
			return ret;
		}

		if ((ret = eiop_ifp_rx_graceful_stop(
			&dpni->snic.egress_ifp_info->ifp_desc))
			!= 0) {
			pr_err("ID[%d]: IFP ingress enable failed\n", dpni->id);
			return ret;
		}
	}

	dpni->self_link_down_finished = 1;

	/* Require completion notification */
	action->request = LINKMAN_REQUEST_COMPLETE_CB;

	dpni_update_pfc_settings(dpni, 0);

	return ret;
}

static int event_phys(struct dpni *dpni,
	const struct linkman_control *control,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	int err = 0;

	switch (control->event) {
	case LINKMAN_EVENT_CONNECT:
		err = event_connect_dpmac(dpni, self, peer, action);
		break;
	case LINKMAN_EVENT_DISCONNECT:
		err = event_disconnect_dpmac(dpni, self, peer, action);
		break;
	case LINKMAN_EVENT_LINKUP:
		err = event_linkup_dpmac(dpni, self, peer, action);
		break;
	case LINKMAN_EVENT_LINKDOWN:
		err = event_linkdown(dpni, self, peer, action);
		break;
	case LINKMAN_EVENT_NEGOTIATION_OK:
		err = event_negotiation_ok(dpni, peer->rate, peer->options,
						action);
		break;
	case LINKMAN_EVENT_NEGOTIATION_FAIL:
		// err = event_negotiation_fail(dpni, self, peer, action);
		break;
	default:
		err = -ENOTSUP; /* Operation not supported */
		break;
	}
	return err;
}

static int event_deassociate_virt(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	int ceetm_ch_idx;

	if( dpni->link_res_flags & DPNI_LINKRES_CHANNEL_ALLOCATED ) {
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			dpmng_connection_free_ceetm_channel(dpni->dpmng,
					&dpni->tx_ch[ceetm_ch_idx].ap.cqchid, dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, 1);
		}
		dpni->link_res_flags &= (~DPNI_LINKRES_CHANNEL_ALLOCATED);
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		lfq_resources_deauthorization(dpni, ceetm_ch_idx);
	}

	return 0;
}

static int event_associate_virt(struct dpni *dpni,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	int ret = LINKMAN_ECONT, err1 = 0;
	int ceetm_ch_idx;
	int lfq_idx, lfq_cnt;

	self->num_channels = dpni->num_ceetm_ch;	/* pass number of ceetm channels to remote object */
	self->valid_fields |= LINKMAN_FIELD_INIT;

	if( (peer->valid_fields & LINKMAN_FIELD_INIT) == 0 ) {
		return LINKMAN_ECONT;
	}

	if (peer->valid_fields & LINKMAN_FIELD_AP_AVAILABLE) {
		/* no possibility of a case if (peer->ap_available == 0) */

		/* Copy  NIC's accesspoint */
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			memcpy(&dpni->tx_ch[ceetm_ch_idx].ap, &peer->ap[ceetm_ch_idx], sizeof(struct dpmng_accesspoint));
		}
		dpni->link_res_flags |= DPNI_LINKRES_CHANNEL_ALLOCATED;

		lfq_cnt = calculate_lfq_cnt(dpni);

		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));

			for( lfq_idx = 0 ; lfq_idx < lfq_cnt ; lfq_idx += DPNI_MAX_SENDERS ) {
				/* will allocate DPNI_MAX_SENDERS lfq resource at once */
				ret = dpmng_connection_alloc_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
						dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
				if( ret ) {
					pr_err("ID[%d] Failed to allocate %d LFQID resources for channel index %d\n",
							dpni->id, lfq_cnt, ceetm_ch_idx);
					err1 = ret;
					break;
				}
			}

			if( lfq_idx != lfq_cnt ) {
				lfq_idx -= DPNI_MAX_SENDERS;
				for( ; lfq_idx >= 0 ; lfq_idx -= DPNI_MAX_SENDERS ) {
					dpmng_connection_free_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
							dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
				}
				memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
				break;
			}
		}

		if( ceetm_ch_idx != dpni->num_ceetm_ch ) {
			ceetm_ch_idx -= 1;
			for( ; ceetm_ch_idx >= 0 ; ceetm_ch_idx-- ) {
				for( lfq_idx = 0 ; lfq_idx < lfq_cnt ; lfq_idx += DPNI_MAX_SENDERS ) {
					dpmng_connection_free_lfqmtidx(dpni->dpmng, &dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx[lfq_idx],
							dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id, DPNI_MAX_SENDERS);
				}
				memset(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx, 0, sizeof(dpni->tx_ch[ceetm_ch_idx].ap.lfqmtidx));
			}
		}

		CHECK_COND_RETVAL( err1 == 0, err1, "ID[%d] LFQ allocation error\n", dpni->id);

		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			dpni->tx_ch[ceetm_ch_idx].ap.lfq_cnt = lfq_cnt;
		}

		dpni->link_res_flags |= DPNI_LINKRES_LFQ_ALLOCATED;

		dpni->ap_valid = 1;

		/* Add access-point to physical port */
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
			set_accesspoint_to_lni(dpni, &dpni->tx_ch[ceetm_ch_idx].ap, 0);

		ret = ceetm_configure(dpni);
		if (ret != 0)
			return ret;

	} else
		return LINKMAN_ECONT;

	dpni->snic.ingress_ifp_info->next_ifpid = peer->ifpid;
	ret = eiop_ifp_set_enqueue_ifp(
		&dpni->snic.ingress_ifp_info->ifp_desc,
		dpni->snic.ingress_ifp_info->next_ifpid);
	ASSERT_COND(!ret || (ret == -ETIMEDOUT));

	eiop_ifp_tx_enable(&dpni->snic.ingress_ifp_info->ifp_desc);

	ret = 0; /* Done */

	return ret;
}

static int event_virt(struct dpni *dpni,
	const struct linkman_control *control,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	uint64_t bps;
	int err = 0;

	switch (control->event) {
	case LINKMAN_EVENT_CONNECT:
		bps = (uint64_t)control->committed_rate * 1000000;
		if (!dpmng_is_rate_allowed(dpni->dpmng, bps)) {
			pr_err("ID[%d]: committed_rate isn't allowed\n", dpni->id);
			return -EINVAL;
		}
		bps = (uint64_t)control->max_rate * 1000000;
		if (!dpmng_is_rate_allowed(dpni->dpmng, bps)) {
			pr_err("ID[%d]: max_rate isn't allowed\n", dpni->id);
			return -EINVAL;
		}

		/* check max rate bigger than committed */
		if (control->max_rate < control->committed_rate) {
			pr_err("ID[%d]: max_rate must be bigger than comitted_rate\n", dpni->id);
			return -EINVAL;
		}

		self->valid_fields |= LINKMAN_FIELD_IFPID;
		self->ifpid = dpni->snic.ingress_ifp_info->ifp_desc.ifp_id;

		if (peer->type == FSL_MOD_DPNI)
			err = event_connect_dpni(dpni, self, peer, control,
							action);
		else
			err = event_connect_master_dp_object(dpni, self, peer,
								control,
								action);
		break;
	case LINKMAN_EVENT_DISCONNECT:
		if (peer->type == FSL_MOD_DPNI)
			err = event_disconnect_dpni(dpni, self, peer, action);
		else
			err = event_disconnect_master_dp_object(dpni, self,
								peer, action);
		break;
	case LINKMAN_EVENT_LINKUP:
		/* link up */
		err = event_linkup_virt(dpni, self, peer, control, action);
		break;
	case LINKMAN_EVENT_LINKDOWN:
		/* link down */
		err = event_linkdown(dpni, self, peer, action);
		break;
	case LINKMAN_EVENT_ASSOCIATE:
		err = event_associate_virt(dpni, self, peer, action);
		break;
	case LINKMAN_EVENT_DEASSOCIATE:
		err = event_deassociate_virt(dpni, self, peer, action);
		break;
	default:
		err = -ENOTSUP; /* Operation not supported */
		break;
	}

	return err;
}

static int alloc_internal_resources(struct dpni *dpni)
{
	int i, j;

	dpni->lock = spin_lock_create();
	if (!dpni->lock) {
		pr_err("ID[%d]: no memory for spinlock\n", dpni->id);
		return -EIO;
	}

	dpni->mem_ifp_info = (struct dpni_ifp_info *)fsl_malloc(
		sizeof(struct dpni_ifp_info));
	if (!dpni->mem_ifp_info) {
		pr_err("ID[%d]: no memory for mem_ifp_info\n", dpni->id);
		return -EIO;
	}
	memset(dpni->mem_ifp_info, 0, sizeof(struct dpni_ifp_info));

	if (!dpni->is_snic) {
		dpni->snic.ingress_ifp_info = dpni->mem_ifp_info;
		dpni->snic.egress_ifp_info = dpni->mem_ifp_info;
	} else {
		dpni->snic.ingress_ifp_info =
			(struct dpni_ifp_info *)fsl_malloc(
				sizeof(struct dpni_ifp_info));
		if (!dpni->snic.ingress_ifp_info) {
			pr_err("ID[%d]: no memory for snic.ingress_ifp_info\n", dpni->id);
			return -EIO;
		}
		memset(dpni->snic.ingress_ifp_info, 0,
			sizeof(struct dpni_ifp_info));
		dpni->snic.egress_ifp_info =
			(struct dpni_ifp_info *)fsl_malloc(
				sizeof(struct dpni_ifp_info));
		if (!dpni->snic.egress_ifp_info) {
			pr_err("ID[%d]: no memory for snic.egress_ifp_info\n", dpni->id);
			return -EIO;
		}
		memset(dpni->snic.egress_ifp_info, 0,
			sizeof(struct dpni_ifp_info));

		dpni->snic.command_buffer = fsl_malloc(64);
		if (!dpni->snic.command_buffer) {
			pr_err("ID[%d]: No memory for snic-cmdif\n", dpni->id);
			return -EIO;
		}
	}

	if (!(dpni->options & DPNI_OPT_SHARED_MAC_TABLE))
		dpni->filters.mac_addrs[DPNI_MAX_UNICAST_FILTERS - 1].is_last = 1;
	dpni->filters.mac_addrs[DPNI_MAX_MAC_FILTERS - 1].is_last = 1;
	dpni->filters.vlans[DPNI_MAX_VLAN_FILTERS - 1].is_last = 1;

	dpni->qos.keys[DPNI_MAX_QOS_ENTRIES - 1].is_last = 1;
	for (i = 0; i < DPNI_MAX_QOS_ENTRIES; i++)
		dpni->qos.keys[i].rule.key_cfg.priority = (uint16_t)i;

	for (i = 0; i < dpni->max_rx_tcs; i++) {
		dpni->tc_rx[i].keys[DPNI_MAX_FS_ENTRIES - 1].is_last = 1;
		for (j = 0; j < DPNI_MAX_FS_ENTRIES; j++)
			dpni->tc_rx[i].keys[j].rule.key_cfg.priority =
				(uint16_t)j;
	}

	return 0;
}

static void free_internal_resources(struct dpni *dpni)
{
	if (dpni->mem_ifp_info)
		fsl_free(dpni->mem_ifp_info);

	clear_retire_storage_data(dpni);

	if (dpni->is_snic) {
		if (dpni->snic.ingress_ifp_info)
			fsl_free(dpni->snic.ingress_ifp_info);
		if (dpni->snic.egress_ifp_info)
			fsl_free(dpni->snic.egress_ifp_info);
		if (dpni->snic.command_buffer)
			fsl_free(dpni->snic.command_buffer);
	}

	if (dpni->lock)
		spin_lock_free(dpni->lock);
}

static void set_defaults(struct dpni *dpni, int reset)
{
	int i,j, err = 0;
	int ceetm_ch_idx;
	struct qbman_desc desc;

	reset_counters(dpni);

	memset(&dpni->mem_ifp_info->init, 0, sizeof(struct eiop_ifp_cfg));
	memset(&dpni->snic.ingress_ifp_info->init, 0,
		sizeof(struct eiop_ifp_cfg));
	memset(&dpni->snic.egress_ifp_info->init, 0,
		sizeof(struct eiop_ifp_cfg));
	dpni->tx_conf_disable = 0;
	if (dpni->options & DPNI_OPT_TX_CONF_DISABLED)
		dpni->tx_conf_disable = 1;
	dpni->l3_chksum_valid = 1;
	dpni->l4_chksum_valid = 1;
	dpni->l3_chksum_gen = 0;
	dpni->l4_chksum_gen = 0;
	dpni->multicast_promisc_en = 1;
	dpni->unicast_promisc_en = 0;
	dpni->mfl = DPNI_DEFAULT_MAX_FRAME_LENGTH;
	if (dpni->options & DPNI_OPT_IPF)
		dpni->snic.mtu = DPNI_DEFAULT_MAX_FRAME_LENGTH;
	dpni->link_cfg.options = DPNI_LINK_OPT_AUTONEG | DPNI_LINK_OPT_PAUSE | DPNI_LINK_OPT_ASYM_PAUSE;
	dpni->link_cfg.rate = 0;

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		dpni->tx_ch[ceetm_ch_idx].tx_cr_shaper.rate_limit = 0;
		dpni->tx_ch[ceetm_ch_idx].tx_cr_shaper.max_burst_size = (uint32_t)ceetm_if_get_max_tbl();
		dpni->tx_ch[ceetm_ch_idx].tx_er_shaper.rate_limit = 0;
		dpni->tx_ch[ceetm_ch_idx].tx_er_shaper.max_burst_size = (uint32_t)ceetm_if_get_max_tbl();

		dpni->tx_ch[ceetm_ch_idx].shaper_coupling = 0;
	}

	dpni->tx_lni_cr_shaper.rate_limit = 0;
	dpni->tx_lni_cr_shaper.max_burst_size = 0;
	dpni->tx_lni_er_shaper.rate_limit = 0;
	dpni->tx_lni_er_shaper.max_burst_size = 0;

	dpni->lni_shaper_coupling = 0;

	for (i = 0; i < dpni->max_rx_tcs; i++) {
		dpni->tc_rx[i].cgid_index = DPNI_INVALID_ID;
		
		for (j = 0; j < dpni->tc_rx[SELECT_TC_SHARED_FS(i)].max_dist_size; j++)
			dpni->tc_rx[i].rx_queues[j].cgid_index = DPNI_INVALID_ID ;
		
		// AIOP: default FQ WQ destination or priority
		if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
			for (j = 0; j > dpni->tc_rx[SELECT_TC_SHARED_FS(i)].max_dist_size; j++)
				dpni->tc_rx[i].rx_queues[j].dest_cfg.dest_id =
						QBMAN_FIRST_AIOP_DCP_CHID;
			dpni->tc_rx[i].rx_queues[j].dest_cfg.dest_type =  DPNI_DEST_NONE;
			dpni->tc_rx[i].rx_queues[j].dest_cfg.priority =
					get_dcp_channel_wq_priority(dpni, (uint8_t)i);
		}
	}
	
	map_opr(dpni);
	
	memset(&desc, 0x0, sizeof(struct qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				0, /* match options*/
				&desc, /* descriptor */
				NULL); /* iterator */
	ASSERT_COND(err == 0);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		for (i = 0; i < dpni->max_tx_tcs; i++) {
			if (i < desc.ceetm_weight_pri_q_base)
				dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].mode = DPNI_TX_SCHED_STRICT_PRIORITY;
			else {
				if (i < (desc.ceetm_weight_pri_q_base + DPNI_DEFAULT_WBFS_GROUP_SIZE))
					dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].mode = DPNI_TX_SCHED_WEIGHTED_A;
				else
					dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].mode = DPNI_TX_SCHED_WEIGHTED_B;

				dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].delta_bandwidth = DPNI_DEFAULT_SCHED_WEIGHT;
			}
		}

		/* Set priority for groupA and groupB just below last priority
		 * Use separate groups in default configuration. This setting will emulate
		 * 10 strict TCS for dpni with more than 8 TC. The priorities will be used
		 * in next order: TC0-7 (first 8 prio), TC8 (prio 9), TC12 (prio 10) */
		dpni->tx_ch[ceetm_ch_idx].tx_selection.separate_groups = 1;
		dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_A = DPNI_DEFAULT_WBFS_GROUP_PRIO+1;
		dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_B = DPNI_DEFAULT_WBFS_GROUP_PRIO+1;

		for (i = 0; i < dpni->max_senders; i++) {
			dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err.queue_info.cgid_index = DPNI_INVALID_ID;
		}
	}

	if (!reset) {
		dpni->dev_ctx.amq.icid = (uint16_t)-1;
		dpni->ap_valid = 0;
	}
	if (dpni->is_snic)
		snic_set_defaults(dpni, reset);

	dpni->fc_idx = FLOW_CONTROL_INVALID_INDEX;
	
	memset(&dpni->restore, 0, sizeof(dpni->restore));
	dpni->restore.init_done = 1;

	memset(&dpni->single_step_cfg, 0, sizeof(dpni->single_step_cfg));
}

static void set_default_cfg(struct dpni *dpni, struct dpni_cfg *cfg)
{
	int i;

	dpni->type = DPNI_TYPE_NI;
	if ((cfg->adv.start_hdr == NET_PROT_NONE)
		|| (cfg->adv.start_hdr == NET_PROT_ETH)) {
		cfg->adv.start_hdr = NET_PROT_ETH;
		dpni->type = DPNI_TYPE_NIC;
	}

	cfg->adv.max_senders =
		(cfg->adv.max_senders) ? cfg->adv.max_senders : 1;

	cfg->adv.max_tcs = (cfg->adv.max_tcs) ? cfg->adv.max_tcs : DPNI_DEFAULT_RX_TC;
	if (cfg->adv.max_rx_tcs > 1) {
		cfg->adv.max_qos_entries =
			(cfg->adv.max_qos_entries) ?
				cfg->adv.max_qos_entries : DPNI_MAX_QOS_ENTRIES;

		cfg->adv.max_qos_key_size =
			(cfg->adv.max_qos_key_size) ?
				cfg->adv.max_qos_key_size :
				DPNI_DEFAULT_KEY_SIZE;
	} else {
		cfg->adv.max_qos_entries = 0;
		cfg->adv.max_qos_key_size = 0;
	}

	/* for backward compatibility - need to check if all
	 * 'new max_fs_entries' is '0' and 'DPNI_OPT_DIST_FS' is selected then
	 * set them to 'max_dist'*/
	for (i = 0; i < cfg->adv.max_tcs && i < DPNI_MAX_RX_TC; i++)
		if (cfg->adv.ext_cfg.tc_cfg[i].max_fs_entries != 0)
			break;
	if ((i == cfg->adv.max_tcs) || (i == DPNI_MAX_RX_TC)) {
		if (cfg->adv.options & DPNI_OPT_DIST_FS)
			dpni->is_fs_backward_comp = 1;
	} else
		/* one of the TCs has max_fs_entries > 0 */
		cfg->adv.options |= DPNI_OPT_DIST_FS;

	if ((cfg->adv.options & DPNI_OPT_DIST_HASH)
		|| (cfg->adv.options & DPNI_OPT_DIST_FS)) {
		cfg->adv.max_dist_key_size =
			(cfg->adv.max_dist_key_size) ?
				cfg->adv.max_dist_key_size :
				DPNI_DEFAULT_KEY_SIZE;
	} else {
		for (i = 0; i < cfg->adv.max_tcs && i < DPNI_MAX_RX_TC; i++) {
			cfg->adv.ext_cfg.tc_cfg[i].max_dist = 0;
			cfg->adv.ext_cfg.tc_cfg[i].max_fs_entries = 0;
		}
		cfg->adv.max_dist_key_size = 0;
	}

	if (cfg->adv.options & DPNI_OPT_UNICAST_FILTER)
		cfg->adv.max_unicast_filters =
			(cfg->adv.max_unicast_filters) ?
				cfg->adv.max_unicast_filters :
				DPNI_MAX_UNICAST_FILTERS;
	else
		cfg->adv.max_unicast_filters = 0;

	if (cfg->adv.options & DPNI_OPT_MULTICAST_FILTER)
		cfg->adv.max_multicast_filters =
			(cfg->adv.max_multicast_filters) ?
				cfg->adv.max_multicast_filters :
				DPNI_MAX_MULTICAST_FILTERS;
	else
		cfg->adv.max_multicast_filters = 0;

	if (cfg->adv.options & DPNI_OPT_VLAN_FILTER)
		cfg->adv.max_vlan_filters =
			(cfg->adv.max_vlan_filters) ?
				cfg->adv.max_vlan_filters :
				DPNI_MAX_VLAN_FILTERS;
	else
		cfg->adv.max_vlan_filters = 0;

	if (cfg->adv.options & DPNI_OPT_TX_CONF_DISABLED)
		cfg->adv.options |= DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED;

	if (!(cfg->adv.options & DPNI_OPT_SHARED_HASH_KEY))
		cfg->adv.options |= DPNI_OPT_ALLOW_DIST_KEY_PER_TC;

	if( cfg->adv.num_ceetm_ch == 0 ) {
		dpni->num_ceetm_ch = 1;
	}
	else {
		dpni->num_ceetm_ch = cfg->adv.num_ceetm_ch;
	}

	dpni->en_header_stashing = 0;
	dpni->en_payload_stashing = 0;
}

static int check_dpni_cfg(const struct dpni *dpni, const struct dpni_cfg *cfg)
{
	struct aiop_tile_desc aiop_tile_desc;
	int i;

	if (dpni->type == DPNI_TYPE_NI) {
		pr_err("ID[%d]: DPNI of type NI not-supported\n", dpni->id);
		return -ENOTSUP;
	}

	if (cfg->adv.options & DPNI_OPTIONS_NOT_SUPPORTED) {
		uint64_t tmp = cfg->adv.options & DPNI_OPTIONS_NOT_SUPPORTED;
		pr_err( "ID[%d]: options 0x%08x%08x not supported\n", dpni->id, (uint32_t)(tmp>>32), (uint32_t)tmp);
		return -ENOTSUP;
	}

	memset(&aiop_tile_desc, 0, sizeof(aiop_tile_desc));
	if (dpni->is_snic
		&& (sys_get_desc(SOC_MODULE_AIOP, 0, &aiop_tile_desc, NULL)
			!= 0)) {
		uint64_t tmp = cfg->adv.options & DPNI_SNIC_OPTIONS_SUPPORTED;
		pr_err("ID[%d]: options 0x%08x%08x are not supported on this chip\n", dpni->id, (uint32_t)(tmp>>32), (uint32_t)tmp);
		return -ENOTSUP;
	}

	if ((cfg->adv.options & DPNI_OPT_QOS_MASK_SUPPORT)
		|| (cfg->adv.options & DPNI_OPT_FS_MASK_SUPPORT)) {

		if (!dpmng_soc_has_tcam(dpni->eiop_id)) {
			pr_err("ID[%d]: MASK cannot be supported as there is no TCAM in this chip\n", dpni->id);
			return -EINVAL;
		}
	}
	if ((dpni->type == DPNI_TYPE_NI)
		&& ((cfg->adv.options & DPNI_OPT_UNICAST_FILTER)
			|| (cfg->adv.options & DPNI_OPT_MULTICAST_FILTER)
			|| (cfg->adv.options & DPNI_OPT_VLAN_FILTER))) {
		pr_err( "ID[%d]: type NI cannot be used with the given option mask\n", dpni->id);
		return -EINVAL;
	}

	if (NH_ETH_IS_MULTICAST_ADDR(cfg->mac_addr)) {
		pr_err("ID[%d]: mac address cannot be a multicast address\n", dpni->id);
		return -EINVAL;
	}

	if (!cfg->adv.max_senders
		|| (cfg->adv.max_senders > DPNI_MAX_SENDERS)) {
		pr_err( "ID[%d]: max_senders (%d) valid range (1-%d)\n", dpni->id, cfg->adv.max_senders, DPNI_MAX_SENDERS);
		return -EINVAL;
	}

	if (cfg->adv.options & DPNI_OPT_SHARED_MAC_TABLE) {
		if (cfg->adv.options & DPNI_OPT_UNICAST_FILTER &&
				cfg->adv.max_unicast_filters > DPNI_MAX_MAC_FILTERS) {
			pr_err( "ID[%d]: MAC filter entries (%d) exceeds supported limit (%d)\n",
					dpni->id, cfg->adv.max_unicast_filters,
					DPNI_MAX_MAC_FILTERS);
			return -EINVAL;
		}
	} else {
		if ((cfg->adv.options & DPNI_OPT_UNICAST_FILTER)
			&& (cfg->adv.max_unicast_filters > DPNI_MAX_UNICAST_FILTERS)) {
			pr_err( "ID[%d]: max_unicast_filters (%d) valid range (1-%d)\n", dpni->id, cfg->adv.max_unicast_filters, DPNI_MAX_UNICAST_FILTERS);
			return -EINVAL;
		}

		if ((cfg->adv.options & DPNI_OPT_MULTICAST_FILTER)
			&& (cfg->adv.max_multicast_filters > DPNI_MAX_MULTICAST_FILTERS)) {
			pr_err( "ID[%d]: max_multicast_filters (%d) valid range (1-%d)\n", dpni->id, cfg->adv.max_multicast_filters, DPNI_MAX_MULTICAST_FILTERS);
			return -EINVAL;
		}
	}

	if ((cfg->adv.options & DPNI_OPT_VLAN_FILTER)
		&& (cfg->adv.max_vlan_filters > DPNI_MAX_VLAN_FILTERS)) {
		pr_err( "ID[%d]: max_vlan_filters (%d) valid range (1-%d)\n", dpni->id, cfg->adv.max_vlan_filters, DPNI_MAX_VLAN_FILTERS);
		return -EINVAL;
	}
	
	if (cfg->adv.max_tcs > 1) {
		if (cfg->adv.max_tcs > DPNI_MAX_TX_TC) {
			pr_err( "ID[%d]: max_tcs (%d) valid range (1-%d)\n", dpni->id, cfg->adv.max_tcs, DPNI_MAX_TX_TC);
			return -EINVAL;
		}

		if (cfg->adv.max_qos_entries > DPNI_MAX_QOS_ENTRIES) {
			pr_err( "ID[%d]: max_qos_entries (%d) valid range (1-%d)\n", dpni->id, cfg->adv.max_qos_entries, DPNI_MAX_QOS_ENTRIES);
			return -EINVAL;
		}
		if (cfg->adv.max_qos_key_size > DPNI_MAX_KEY_SIZE) {
			pr_err( "ID[%d]: max_qos_key_size (%d) valid range (1-%d)\n", dpni->id, cfg->adv.max_qos_key_size, DPNI_MAX_KEY_SIZE);
			return -EINVAL;
		}
	}

	CHECK_COND_RETVAL( cfg->adv.max_rx_tcs <= 8, -EINVAL, "ID[%d]: max_rx_tcs (%d) valid range (0-%d)", dpni->id, cfg->adv.max_rx_tcs, 8);

	if ((cfg->adv.options & DPNI_OPT_DIST_HASH)
		|| (cfg->adv.options & DPNI_OPT_DIST_FS))
		if (cfg->adv.max_dist_key_size > DPNI_MAX_KEY_SIZE) {
			pr_err( "ID[%d]: max_dist_key_size (%d) valid range (1-%d)\n", dpni->id, cfg->adv.max_dist_key_size, DPNI_MAX_KEY_SIZE);
			return -EINVAL;
		}

	if (!IS_SHARED_FS_ENABLED) {
		if ((cfg->adv.options & DPNI_OPT_DIST_FS)
				&& (!dpni->is_fs_backward_comp))
			for (i = 0; i < cfg->adv.max_tcs && i < DPNI_MAX_RX_TC; i++)
				if (cfg->adv.ext_cfg.tc_cfg[i].max_fs_entries
						> DPNI_MAX_FS_ENTRIES) {
					pr_err( "ID[%d]: TC[%d] - max_fs_entries (%d) valid range (0-%d)\n", dpni->id, i, cfg->adv.ext_cfg.tc_cfg[i].max_fs_entries, DPNI_MAX_FS_ENTRIES);
				return -EINVAL;
				}
	} else {
		if (cfg->adv.ext_cfg.tc_cfg[0].max_fs_entries > DPNI_MAX_FS_ENTRIES) {
			pr_err( "ID[%d]: TC[%d] - max_fs_entries (%d) valid range (0-%d)\n", dpni->id, 0, cfg->adv.ext_cfg.tc_cfg[0].max_fs_entries, DPNI_MAX_FS_ENTRIES);
			return -EINVAL;
		}
	}

	if (dpni->max_policers > cfg->adv.max_tcs) {
		pr_err( "ID[%d]: max_policers (%d) valid range (0-%d)\n", dpni->id, cfg->adv.max_policers, cfg->adv.max_tcs);
		return -EINVAL;
	}

	if (dpni->max_congestion_ctrl
		> (cfg->adv.max_tcs + dpni->max_senders)) {
		pr_err( "ID[%d]: max_congestion_ctrl (%d) valid range (0-%d)\n", dpni->id, cfg->adv.max_congestion_ctrl, (cfg->adv.max_tcs + dpni->max_senders));
		return -EINVAL;
	}

	if (cfg->adv.options & DPNI_OPT_IPR) {
		if (!cfg->adv.ext_cfg.ipr_cfg.max_open_frames_ipv4
			&& !cfg->adv.ext_cfg.ipr_cfg.max_open_frames_ipv6) {
			pr_err( "ID[%d]: either max_open_frames_ipv4 or max_open_frames_ipv6 should be non zero\n", dpni->id);
			return -EINVAL;
		}
		if (!cfg->adv.ext_cfg.ipr_cfg.max_reass_frm_size) {
			pr_err("ID[%d]: max_reass_frm_size should be non zero\n", dpni->id);
			return -EINVAL;
		}
	}

	CHECK_COND_RETVAL(cfg->adv.num_ceetm_ch < DPMNG_MAX_CEETM_CH, -EINVAL, "ID[%d] Number of channels greater than %d (provided value is: %d)\n",
			DPMNG_MAX_CEETM_CH, cfg->adv.num_ceetm_ch);

	return 0;
}

static int resources_allocation(struct dpni *dpni)
{
#define RES_ARR_SIZE		1024
	int err, i, j, res_arr[RES_ARR_SIZE];
	uint32_t res_count = 0;
	struct aiop_tile_desc aiop_tile_desc;
	char type[16];
	int qdid[2];
	uint32_t ceetm_ch_idx;

	CHECK_COND_RETVAL(dpni->max_senders <= DPNI_MAX_SENDERS, -EINVAL);
	CHECK_COND_RETVAL(dpni->max_rx_tcs <= DPNI_MAX_RX_TC, -EINVAL);
	CHECK_COND_RETVAL(dpni->max_tx_tcs <= DPNI_MAX_TX_TC, -EINVAL);

	/* POLICY */
	snprintf(type, sizeof(type), "plcy.wr%d.ctlui", dpni->eiop_id);
	if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
					&dpni->policy_id, "POLICY-ID"))
		!= 0)
		return err;

	/* KID */
	res_count = 2;
	if (dpni->options & DPNI_OPT_VLAN_FILTER)
		res_count += 1;
	if (dpni->options & DPNI_OPT_DIST_HASH)
		res_count += max_tcs_for_lookps(dpni);
	 if (dpni->options & DPNI_OPT_DIST_FS)
		 res_count += dpni->max_rx_tcs;

	CHECK_COND_RETVAL(res_count <= ARRAY_SIZE(res_arr), -EINVAL);
	snprintf(type, sizeof(type), "kp.wr%d.ctlui", dpni->eiop_id);
	if ((err = allocate_resource(dpni->device, type, res_count, 1, 0,
					res_arr, "KIDs"))
		!= 0)
		return err;

	dpni->filters.mac_kid = res_arr[--res_count];
	dpni->qos.kid = res_arr[--res_count];
	if (dpni->options & DPNI_OPT_VLAN_FILTER)
		dpni->filters.vlan_kid = res_arr[--res_count];

	if (dpni->options & DPNI_OPT_DIST_HASH) {
		if (!IS_SHARED_FS_ENABLED) {
			for (i = 0; i < max_tcs_for_lookps(dpni); i++)
				dpni->tc_rx[i].kid_hash = (uint8_t)res_arr[--res_count];
		} else
			dpni->tc_rx[0].kid_hash = (uint8_t)res_arr[--res_count];
	}
	if (dpni->options & DPNI_OPT_DIST_FS) {
		if (!IS_SHARED_FS_ENABLED) {
			for (i = 0; i < dpni->max_rx_tcs; i++)
				dpni->tc_rx[i].kid_fs = (uint8_t)res_arr[--res_count];
		} else
			dpni->tc_rx[0].kid_fs = (uint8_t)res_arr[--res_count];
	}

	/* Ingress PARSER-ID */
	err = dpparser_find_profile(dpni->ing_dpparser, NULL, NULL, 0,
					&dpni->ing_parser_id);
	if (err != 0) {
		dpparser_get_resource_str(dpni->ing_dpparser, type);
		if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
						&dpni->ing_parser_id,
						"PARSER-ID"))
			!= 0)
			return err;
	}
	dpni->is_ing_parser_id_allocated = 1;

	/* Egress PARSER-ID */
	err = dpparser_find_profile(dpni->egr_dpparser, NULL, NULL, 0,
					&dpni->egr_parser_id);
	if (err != 0) {
		dpparser_get_resource_str(dpni->egr_dpparser, type);
		if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
						&dpni->egr_parser_id,
						"PARSER-ID"))
			!= 0)
			return err;
	}
	dpni->is_egr_parser_id_allocated = 1;

	/* IFP */
	snprintf(type, sizeof(type), "ifp.wr%d", dpni->eiop_id);
	if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
					&dpni->mem_ifp_info->ifp_desc.ifp_id,
					"IFP"))
		!= 0)
		return err;
	dpni->mem_ifp_info->ifp_desc.eiop_id = dpni->eiop_id;

	dpni->mem_ifp_info->next_ifpid = dpni->mem_ifp_info->ifp_desc.ifp_id;
	err = sys_get_desc(SOC_MODULE_EIOP_IFP,
				(SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID),
				&dpni->mem_ifp_info->ifp_desc, NULL);
	CHECK_COND_RETVAL(err == 0, err);

	/* QDID */
	if ((err = allocate_resource(dpni->device, "qd", (uint32_t)(1+dpni->num_ceetm_ch), 1, 0, qdid,
					"QDID"))
		!= 0)
		return err;
	dpni->rx_qdid = qdid[0];
	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		dpni->tx_ch[ceetm_ch_idx].tx_qdid = qdid[1+ceetm_ch_idx];
	}

	/* QPRs */
	if ((err = allocate_resource(dpni->device, "qpr",
					(uint32_t)(dpni->num_ceetm_ch * dpni->max_tx_tcs + dpni->max_rx_tcs + 1), 1, 0,
					res_arr, "QPRs"))
		!= 0)
		return err;

	j = 0;
	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		for (i = 0; i < dpni->max_tx_tcs; i++) {
			dpni->tx_ch[ceetm_ch_idx].tc_tx[i].qprid = res_arr[j];
			j++;
		}
	}
	
	for (i = 0; i < dpni->max_rx_tcs; i++) {
		dpni->tc_rx[i].qprid = res_arr[j];
		j++;
	}

	dpni->void_qprid = res_arr[j];

	/* FQIDs */
	res_count = 2;
	if (!(dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED))
		res_count += (dpni->max_senders * dpni->num_ceetm_ch);

	CHECK_COND_RETVAL(res_count <= ARRAY_SIZE(res_arr), -EINVAL);
	if ((err = allocate_resource(dpni->device, "fq", res_count, 1, 0,
					res_arr, "FQs"))
		!= 0)
		return err;

	dpni->tx_conf_err.queue_info.fqid = res_arr[--res_count];
	dpni->rx_err.fqid = res_arr[--res_count];

	if (!(dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED))
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
			for (i = 0; i < dpni->max_senders; i++) {
				dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err.queue_info.fqid = res_arr[--res_count];
				dpni->tx_ch[ceetm_ch_idx].sender_info[i].private_tx_conf_err_queue = 1;
			}
		}

	for (i = 0; i < dpni->max_rx_tcs; i++) {
		res_count = dpni->tc_rx[SELECT_TC_SHARED_FS(i)].max_dist_size;
		ASSERT_COND(res_count <= ARRAY_SIZE(res_arr));
		if ((err = allocate_resource(dpni->device, "fq", res_count, 1,
						0, res_arr, "RX-Q"))
			!= 0)
			return err;
		dpni->tc_rx[i].fqid_base = res_arr[0];

		for (j = 0; j < dpni->tc_rx[SELECT_TC_SHARED_FS(i)].max_dist_size; j++)
			dpni->tc_rx[i].rx_queues[j].fqid =
				dpni->tc_rx[i].fqid_base + j;
	}
	
	//OPR
	if (dpni_has_opr(dpni)) {
		for (i = 0; i < dpni->max_opr; i++) {
			err = allocate_resource(dpni->device, OPR_RES_TYPE_STR, 1, 1, 0,
					&dpni->opr[i].opr.id,OPR_ERR_STR);
				CHECK_COND_RETVAL(err == 0, err, "ID[%d]: OPR resource allocation failed\n", dpni->id);
		}
	}


	/* Policer-Profiles and CGs */
	if (dpni->max_policers) {
		snprintf(type, sizeof(type), "plcr.wr%d.ctlui", dpni->eiop_id);
		if ((err = allocate_resource(dpni->device, type,
						dpni->max_policers, 1, 0,
						dpni->policer_ids, "RX-PLCRID"))
			!= 0)
			return err;
	}

	/* allocate one more CG for the common tx-conf flow */
	res_count = (uint32_t)(dpni->max_congestion_ctrl + 1);
	if ((err = allocate_resource(dpni->device, "cg", res_count, 1, 0,
					res_arr, "CGID"))
		!= 0)
		return err;

	for (i = 0; i <= dpni->max_congestion_ctrl; i++) {
		dpni->rx_tx_conf_cgids[i].cgid = res_arr[i];
		dpni->rx_tx_conf_cgids[i].virtual_cgid = QBMAN_INVALID_VRID;
	}

	dpni->tx_conf_err.queue_info.cgid_index = i;

	memset(&aiop_tile_desc, 0, sizeof(aiop_tile_desc));
	if (sys_get_desc(SOC_MODULE_AIOP, 0, &aiop_tile_desc, NULL) == 0) {
		snprintf(type, sizeof(type), "ep.aiop%d", 0);
		if ((err = allocate_resource(dpni->device, type, 1, 1, 0,
						&dpni->epid, "EPID"))
			!= 0)
			return err;

		res_count = 2;
		snprintf(type, sizeof(type), "sp.aiop%d", 0);
		if ((err = allocate_resource(dpni->device, type, res_count, 1,
						0, res_arr, "SPID"))
			!= 0)
			return err;
		dpni->spid = res_arr[0];
		dpni->backup_spid = res_arr[1];
	}

	if ((dpni->is_snic) && ((err = snic_resources_allocation(dpni)) != 0))
		return err;

	return 0;
}

static int resources_deallocation(struct dpni *dpni)
{
	int err = 0;

	if ((dpni->is_snic)
		&& ((err = snic_resources_deallocation(dpni)) != 0))
		return err;

	if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
		struct aiop_ep_entry_cfg ep_cfg;

		ep_cfg.pc = 0;
		ep_cfg.parameter = (uint32_t)-1;

		err = aiop_tile_ws_set_ep_entry(dpni->aiop_tile,
						(uint32_t)dpni->epid, &ep_cfg);
		if (err) {
			pr_err("ID[%d]: aiop_tile_ws_set_ep_entry failed\n", dpni->id);
			return err;
		}
	}

	if ((err = resman_unbind_all(dpni->device)) != 0)
		return err;

	return err;
}

static int resources_authorization(struct dpni *dpni)
{
	struct qbman_swp *sw_portal = NULL;
	int i, j, err = 0, err1 = 0;
	int ceetm_ch_idx;

	if (dpni->authorized)
		return 0;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	/* QDID */
	if ((err = resource_authorization(
		sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
		qbman_auth_type_qdid, &dpni->rx_virt_qdid, (uint32_t)dpni->rx_qdid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "QDID"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		dpni->tx_ch[ceetm_ch_idx].tx_virt_qdid = QDID_INVALID_ID;
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		err = resource_authorization(
				sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
				qbman_auth_type_qdid, &dpni->tx_ch[ceetm_ch_idx].tx_virt_qdid, (uint32_t)dpni->tx_ch[ceetm_ch_idx].tx_qdid,
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "QDID");
		if( err ) {
			err1 = err;
			dpni->tx_ch[ceetm_ch_idx].tx_virt_qdid = QDID_INVALID_ID;
			pr_err("ID[%d] Failed to authorize qdid: %d\n", dpni->tx_ch[ceetm_ch_idx].tx_qdid);
			break;
		}
	}
	if( ceetm_ch_idx != dpni->num_ceetm_ch ) {
		/* could not authorize all qdid values for Tx path
		 * remove authorization for valid ones and set them to invalid value to be skipped into resources_deauthorization*/
		ceetm_ch_idx--;
		for( ; ceetm_ch_idx > 0 ; ceetm_ch_idx-- ) {
			err = resource_deauthorization(
					sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
					qbman_auth_type_qdid, dpni->tx_ch[ceetm_ch_idx].tx_virt_qdid,
					(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "QDID");
			if( err ) {
				pr_err("ID[%d] Failed to remove authorization for virtual qdid %d\n", dpni->id, dpni->tx_ch[ceetm_ch_idx].tx_virt_qdid);
				continue;
			}
			else
				dpni->tx_ch[ceetm_ch_idx].tx_virt_qdid = QDID_INVALID_ID;
		}
		return err1;
	}

	/* FQIDs */
	if ((err = resource_authorization(
		sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
		qbman_auth_type_fqid, &dpni->tx_conf_err.queue_info.virt_fqid,
		(uint32_t)dpni->tx_conf_err.queue_info.fqid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-ERR-Q"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	if ((err = resource_authorization(
		sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
		qbman_auth_type_fqid, &dpni->rx_err.virt_fqid,
		(uint32_t)dpni->rx_err.fqid, (QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
		"RX-ERR-Q"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	if (!(dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED))
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
			for (i = 0; i < dpni->max_senders; i++)
				if ((err =
						resource_authorization(
								sw_portal,
								dpni->dev_ctx.amq.bdi,
								dpni->dev_ctx.amq.icid,
								qbman_auth_type_fqid,
								&dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err.queue_info.virt_fqid,
								(uint32_t)dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err.queue_info.fqid,
								(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
								"TX-CONF-Q"))
								!= 0) {
					dpmng_put_swportal(dpni->dpmng,
							(void*)sw_portal);
					return err;
				}

	for (i = 0; i < dpni->max_rx_tcs; i++)
		for (j = 0; j < dpni->tc_rx[SELECT_TC_SHARED_FS(i)].max_dist_size; j++)
			if ((err = resource_authorization(
				sw_portal, dpni->dev_ctx.amq.bdi,
				dpni->dev_ctx.amq.icid, qbman_auth_type_fqid,
				&dpni->tc_rx[i].rx_queues[j].virt_fqid,
				(uint32_t)dpni->tc_rx[i].rx_queues[j].fqid,
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-Q"))
				!= 0) {
				dpmng_put_swportal(dpni->dpmng,
							(void*)sw_portal);
				return err;
			}

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	for (i = 0; i <= dpni->max_congestion_ctrl; i++) {
		err = cgid_authorization_n_configuration(
			dpni, dpni->rx_tx_conf_cgids[i].cgid,
			&dpni->rx_tx_conf_cgids[i].virtual_cgid, 0, 0, 0);
		CHECK_COND_RETVAL(err == 0, err);
	}
	
	//OPR
	if (dpni_has_opr(dpni)) {
		for (i = 0; i < dpni->max_opr; i++) {
			err = auth_oprid(sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
					&dpni->opr[i].opr);
		}
	}
	
	if ((dpni->is_snic)
		&& ((err = snic_resources_authorization(dpni)) != 0))
		return err;

	dpni->authorized = 1;

	if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
		struct aiop_ep_entry_cfg ep_cfg = { 0 };

		ep_cfg.pc = 0;
		ep_cfg.parameter =
			(uint32_t)(dpni->id | AIOP_EPID_SET_BY_DPNI);

		err = aiop_tile_ws_set_ep_entry(dpni->aiop_tile,
						(uint32_t)dpni->epid, &ep_cfg);
		if (err) {
			pr_err("ID[%d]: aiop_tile_ws_set_ep_entry failed\n", dpni->id);
			return err;
		}
	}

	err = config_qbman(dpni);
	if (err != 0) {
		pr_err("ID[%d]: config_qbman failed\n", dpni->id);
		return err;
	}

	return 0;
}

static int resources_deauthorization(struct dpni *dpni)
{
	struct qbman_swp *sw_portal = NULL;
	int i, j, err;
	int ceetm_ch_idx;

	if (!dpni->authorized)
		return 0;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	/* QDID */
	if ((err = resource_deauthorization(
		sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
		qbman_auth_type_qdid, dpni->rx_virt_qdid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "QDID"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		if( dpni->tx_ch[ceetm_ch_idx].tx_virt_qdid == QDID_INVALID_ID )
			break;
		err = resource_deauthorization(
				sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
				qbman_auth_type_qdid, dpni->tx_ch[ceetm_ch_idx].tx_virt_qdid,
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "QDID");
		if( err ) {
			pr_err("ID[%d] Failed to remove authorization for virtual qdid %d\n", dpni->id, dpni->tx_ch[ceetm_ch_idx].tx_virt_qdid);
		}
	}

	/* FQIDs */
	if ((err = resource_deauthorization(
		sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
		qbman_auth_type_fqid, dpni->tx_conf_err.queue_info.virt_fqid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-ERR-Q"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	if ((err = resource_deauthorization(
		sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
		qbman_auth_type_fqid, dpni->rx_err.virt_fqid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-ERR-Q"))
		!= 0) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}

	if (!(dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED))
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
			for (i = 0; i < dpni->max_senders; i++)
				if ((err =
						resource_deauthorization(
								sw_portal,
								dpni->dev_ctx.amq.bdi,
								dpni->dev_ctx.amq.icid,
								qbman_auth_type_fqid,
								dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err.queue_info.virt_fqid,
								(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP),
								"TX-CONF-Q"))
								!= 0) {
					dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
				return err;
			}

	for (i = 0; i < dpni->max_rx_tcs; i++) {
		for (j = 0; j < dpni->tc_rx[SELECT_TC_SHARED_FS(i)].max_dist_size; j++) {
			err = resource_deauthorization(
				sw_portal, dpni->dev_ctx.amq.bdi,
				dpni->dev_ctx.amq.icid, qbman_auth_type_fqid,
				dpni->tc_rx[i].rx_queues[j].virt_fqid,
				(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-Q");
			if (err) {
				dpmng_put_swportal(dpni->dpmng,
							(void*)sw_portal);
				return err;
			}
		}
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
		for (i = 0; i < dpni->max_tx_tcs; i++) {
			if( dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_cgid!=QBMAN_INVALID_VRID ) {
				err = resource_deauthorization(
						sw_portal, dpni->dev_ctx.amq.bdi,
						dpni->dev_ctx.amq.icid, qbman_auth_type_cgid,
						dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_cgid,
						QBMAN_AUTH_SWP, "CGID");
				if (err) {
					pr_err("ID[%d] Failed to remove auhoizartion for CCG (virt_id: %d, channel: %d, tc: %d).. continue",
							dpni->id, ceetm_ch_idx, i);
					dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
					return err;
				}
				dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_cgid = QBMAN_INVALID_VRID;
			}
		}

	/* CGs */
	for (i = 0; i <= dpni->max_congestion_ctrl; i++) {
		err = resource_deauthorization(
			sw_portal, dpni->dev_ctx.amq.bdi,
			dpni->dev_ctx.amq.icid, qbman_auth_type_cgid,
			dpni->rx_tx_conf_cgids[i].virtual_cgid, QBMAN_AUTH_SWP,
			"CGID");
		if (err) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			return err;
		}
	}

	//OPR
	if (dpni_has_opr(dpni)) {
		for (i = 0; i < dpni->max_opr; i++) {
			err = deauth_oprid(sw_portal, dpni->dev_ctx.amq.bdi, dpni->dev_ctx.amq.icid,
									&dpni->opr[i].opr);
		}
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
		lfq_resources_deauthorization(dpni, ceetm_ch_idx);

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	if ((dpni->is_snic)
		&& ((err = snic_resources_deauthorization(dpni)) != 0))
		return err;

	dpni->authorized = 0;
	dpni->dev_ctx.amq.icid = (uint16_t)-1;

	return 0;
}

static int check_rx_tc_dist_fs(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *tc_cfg)
{
	if (tc_cfg->dist_mode == DPNI_DIST_MODE_FS) {
		if (dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_fs_entries == 0) {
			pr_err("ID[%d]: can't create FS table for tc %d as"
			" max_fs_entries == 0\n", dpni->id, SELECT_TC_SHARED_FS(tc_id));
			return -EACCES;
		}

		if ((tc_cfg->fs_cfg.miss_action == DPNI_FS_MISS_HASH)
			&& !(dpni->options & DPNI_OPT_DIST_HASH)) {
			pr_err("ID[%d]: HASH wasn't chosen as part of the general options mask\n", dpni->id);
			return -EACCES;
		}

		if ((tc_cfg->fs_cfg.miss_action == DPNI_FS_MISS_EXPLICIT_FLOWID)
			&& (tc_cfg->fs_cfg.default_flow_id >= tc_cfg->dist_size)) {
			pr_err("ID[%d]: default_flow_id (%d) valid range (0-%d)\n", dpni->id, tc_cfg->fs_cfg.default_flow_id, tc_cfg->dist_size-1);
			return -EINVAL;
		}
	}

	return 0;
}

static int check_rx_tc_dist_hash_fs(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *tc_cfg)
{
	int i, err;

	if (tc_cfg->dist_size > dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size) {
		pr_err( "ID[%d]: dist_size (%d) valid range (1-%d)\n", dpni->id, tc_cfg->dist_size, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size);
		return -EINVAL;
	}

	if (!is_dist_size_supported(tc_cfg->dist_size)) {
		pr_err( "ID[%d]: dist_size (%d) isn't supported\n", dpni->id, tc_cfg->dist_size);
		return -EINVAL;
	}

	if (!tc_cfg->dist_key_cfg) {
		pr_err("ID[%d]: extract_cfg cannot be NULL\n", dpni->id);
		return -ENAVAIL;
	}

	if ((err = dpkg_profile_check_cfg(dpni->ing_dpkg, tc_cfg->dist_key_cfg))
		!= 0) {
		pr_err("ID[%d]: extraction key is wrong\n", dpni->id);
		return err;
	}

	if ((tc_cfg->dist_mode == DPNI_DIST_MODE_HASH)
		&& !(dpni->options & DPNI_OPT_DIST_HASH)) {
		pr_err("ID[%d]: HASH distribution wasn't chosen as part of the"
		" general options mask\n", dpni->id);
		return -EACCES;
	}

	if ((err = check_rx_tc_dist_fs(dpni, tc_id, tc_cfg)) != 0)
		return err;

	if (!(dpni->options & DPNI_OPT_ALLOW_DIST_KEY_PER_TC)) {
		if (!IS_SHARED_FS_ENABLED) {
			for (i = 0; i < dpni->max_rx_tcs; i++) {
				if ((i == tc_id) || (!dpni->tc_rx[i].valid)
					|| (dpni->tc_rx[i].dist_mode
						== DPNI_DIST_MODE_NONE))
					continue;
				if ((tc_cfg->dist_key_cfg->num_extracts
					!= dpni->tc_rx[i].dist_extract_cfg.num_extracts)
					|| (memcmp(
						tc_cfg->dist_key_cfg,
						&dpni->tc_rx[i].dist_extract_cfg,
						tc_cfg->dist_key_cfg->num_extracts
						* sizeof(struct dpkg_extract))
						!= 0)) {
					pr_err( "ID[%d]: Key extraction must be the same for all TCs\n", dpni->id);
					return -EINVAL;
				}
			}
		}
	}

	return 0;
}

static int check_rx_tc_dist(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *tc_cfg)
{
	int err;

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err("ID[%d]: tc_id (%d) must be smaller than %d\n", dpni->id, tc_id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	if (!((tc_cfg->dist_mode == DPNI_DIST_MODE_NONE)
		|| (tc_cfg->dist_mode == DPNI_DIST_MODE_HASH)
		|| (tc_cfg->dist_mode == DPNI_DIST_MODE_FS))) {
		pr_err("ID[%d]: invalid dist_mode\n", dpni->id);
		return -EINVAL;
	}

	if (tc_cfg->dist_mode != DPNI_DIST_MODE_NONE) {
		err = check_rx_tc_dist_hash_fs(dpni, tc_id, tc_cfg);
		if (err)
			return err;
	}

	if (((dpni->tc_rx[tc_id].dist_mode == DPNI_DIST_MODE_FS)
		&& (tc_cfg->dist_mode == DPNI_DIST_MODE_HASH))
		|| ((dpni->tc_rx[tc_id].dist_mode == DPNI_DIST_MODE_HASH)
			&& (tc_cfg->dist_mode == DPNI_DIST_MODE_FS))) {
		if (dpni->tc_rx[tc_id].qos_owners && dpni->enabled) {
			pr_err( "ID[%d]: tc_id (%d) can't be changed, either delete QoS mappings or disable the DPNI\n", tc_id, dpni->id);
			return -EACCES;
		}
	}

	return 0;
}

static int check_congestion_notification(struct dpni *dpni,
	int early_drop_enable,
	enum dpni_congestion_unit early_drop_units,
	const struct dpni_congestion_notification_cfg *cfg)
{
	int err;

	if (early_drop_enable && (cfg->units != early_drop_units)) {
		pr_err("ID[%d]: notification units %d must match the early-drop units %d\n", dpni->id, cfg->units, early_drop_units);
		return -EINVAL;
	}

	if ((cfg->notification_mode & DPNI_CGN_MODE_NOTIFY_DEST_ON_ENTER)
		|| (cfg->notification_mode & DPNI_CGN_MODE_NOTIFY_DEST_ON_EXIT)) {
		err = check_dest_cfg(dpni, &cfg->dest_cfg);
		if (err != 0)
			return err;
	}

	if (((cfg->notification_mode & DPNI_CGN_MODE_WRITE_MEM_ON_ENTER)
		|| (cfg->notification_mode & DPNI_CGN_MODE_WRITE_MEM_ON_EXIT))
		&& !IS_ALIGNED(cfg->message_iova, 16)) {
		pr_err("ID[%d]: message_iova must be 16B aligned\n", dpni->id);
		return -EINVAL;
	}

	return 0;
}

static int check_tx_conf(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	const struct dpni_tx_conf_cfg *cfg)
{
	struct dpni_tx_conf_info *info;
	int err;

	if ((flow_id != DPNI_COMMON_TX_CONF)
		&& (dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED)) {
		pr_err("ID[%d]: 'private' TX-confirmation isn't supported\n", dpni->id);
		return -ENOTSUP;
	}

	if ((flow_id == DPNI_COMMON_TX_CONF)
		&& (dpni->options & DPNI_OPT_TX_CONF_DISABLED)
		&& (!cfg->errors_only)) {
		pr_err("ID[%d]: 'errors_only' must be '1' as TX-confirmation"
		" isn't supported\n", dpni->id);
		return -ENOTSUP;
	}

	if (cfg->queue_cfg.options & DPNI_QUEUE_OPT_FLC) {
		pr_err( "ID[%d]: 'DPNI_QUEUE_OPT_FLC' cann't be used for TX-Conf-Err\n", dpni->id);
		return -EINVAL;
	}

	if (flow_id == DPNI_COMMON_TX_CONF)
		info = &dpni->tx_conf_err;
	else {
		if (flow_id >= dpni->max_senders) {
			pr_err( "ID[%d]: flow_id must be smaller than %d\n", dpni->id, dpni->max_senders);
			return -EINVAL;
		}

		if (!dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id].valid) {
			pr_err("ID[%d]: flow_id isn't valid\n", dpni->id);
			return -EACCES;
		}

		info = &dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id].tx_conf_err;
	}

	if (cfg->queue_cfg.options & DPNI_QUEUE_OPT_DEST) {
		err = check_dest_cfg(dpni, &cfg->queue_cfg.dest_cfg);
		if (err != 0)
			return err;

		if ((cfg->queue_cfg.dest_cfg.dest_type == DPNI_DEST_NONE)
			&& (info->queue_info.dest_cfg.dest_type
				!= DPNI_DEST_NONE)) {
			pr_err("ID[%d]: Cannot change back to parked mode\n", dpni->id);
			return -ENOTSUP;
		}
	}

	if ((cfg->queue_cfg.options & DPNI_QUEUE_OPT_TAILDROP_THRESHOLD)
		&& (cfg->queue_cfg.tail_drop_threshold > DPNI_MAX_TD_THRESHOLD)) {
		pr_err( "ID[%d]: tail_drop_threshold must not exceed %d\n", dpni->id, DPNI_MAX_TD_THRESHOLD);
		return -EINVAL;
	}

	return 0;
}

static void fill_policer(const struct dpni_rx_tc_policing_cfg *cfg,
	struct dppolicer_profile_cfg *policer)
{
	memset(policer, 0, sizeof(struct dppolicer_profile_cfg));
	if (!(cfg->options & DPNI_POLICER_OPT_COLOR_AWARE))
		policer->options |= DPPOLICER_OPT_COLOR_BLIND;
	if (cfg->options & DPNI_POLICER_OPT_DISCARD_RED)
		policer->options |= DPPOLICER_OPT_DISCARD_RED;
	if (cfg->default_color == DPNI_POLICER_COLOR_GREEN)
		policer->default_color = DPPPLICER_GREEN;
	if (cfg->default_color == DPNI_POLICER_COLOR_YELLOW)
		policer->default_color = DPPPLICER_YELLOW;
	if (cfg->default_color == DPNI_POLICER_COLOR_RED)
		policer->default_color = DPPPLICER_RED;
	if (cfg->mode == DPNI_POLICER_MODE_PASS_THROUGH)
		policer->alg = DPPPLICER_PASS_THROUGH;
	if (cfg->mode == DPNI_POLICER_MODE_RFC_2698)
		policer->alg = DPPPLICER_RFC_2698;
	if (cfg->mode == DPNI_POLICER_MODE_RFC_4115)
		policer->alg = DPPPLICER_RFC_4115;
	if (cfg->units == DPNI_POLICER_UNIT_BYTES) {
		policer->non_passthrough_cfg.rate_mode =
			DPPPLICER_BYTE_RATE_MODE;
		/* count only IP header and payload */
		policer->non_passthrough_cfg.byte_rate_cfg.frame_len_select =
			DPPPLICER_L3_FRM_LEN;
	}
	if (cfg->units == DPNI_POLICER_UNIT_PACKETS)
		policer->non_passthrough_cfg.rate_mode =
			DPPPLICER_PACKET_RATE_MODE;

	policer->non_passthrough_cfg.committed_info_rate = cfg->cir;
	policer->non_passthrough_cfg.committed_burst_size = cfg->cbs;
	policer->non_passthrough_cfg.peak_or_excessive_info_rate = cfg->eir;
	policer->non_passthrough_cfg.peak_or_excessive_burst_size = cfg->ebs;

	policer->green_drop_pri = DPNI_POLICING_GREEN_IDX;
	policer->yellow_drop_pri = DPNI_POLICING_YELLOW_IDX;
	policer->red_drop_pri = DPNI_POLICING_RED_IDX;
}

static int set_rx_tc_policer(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_policing_cfg *cfg)
{
	int i, err;

	if (cfg->mode != DPNI_POLICER_MODE_NONE) {
		/* if already set, we can skip as it was done before */
		if (!dpni->tc_rx[tc_id].policer_enable) {
			/* Find free plcr-id */
			for (i = 0; i < dpni->max_policers; i++)
				if (!(dpni->policer_ids[i] & DPNI_ID_IN_USE))
					break;
			if (i == dpni->max_policers) {
				pr_err("ID[%d]: all policers are used \n", dpni->id);
				return -ENAVAIL;
			}
			dpni->tc_rx[tc_id].plcrid = dpni->policer_ids[i];
			dpni->policer_ids[i] |= DPNI_ID_IN_USE;
		}

		fill_policer(cfg, &dpni->tc_rx[tc_id].policer);
		err = dppolicer_init_profile(dpni->ing_dppolicer,
						dpni->tc_rx[tc_id].plcrid,
						NULL,
						&dpni->tc_rx[tc_id].policer);
		if (err) {
			if (!dpni->tc_rx[tc_id].policer_enable)
				dpni->policer_ids[i] &= ~DPNI_ID_IN_USE;
			return err;
		}
		/* if already set, we can skip as it was done before */
		if (!dpni->tc_rx[tc_id].policer_enable) {
			dpni->tc_rx[tc_id].policer_enable = 1;
			modify_qos_entries(dpni, tc_id, NULL);
			update_pass_through_qos(dpni);
		}
	}
	if ((cfg->mode == DPNI_POLICER_MODE_NONE)
		&& (dpni->tc_rx[tc_id].policer_enable)) {
		dpni->tc_rx[tc_id].policer_enable = 0;
		modify_qos_entries(dpni, tc_id, NULL);
		update_pass_through_qos(dpni);
		dppolicer_delete_profile(dpni->ing_dppolicer,
						dpni->tc_rx[tc_id].plcrid,
						NULL);
		/* mark unused plcr-id */
		for (i = 0; i < dpni->max_policers; i++)
			if ((dpni->policer_ids[i] & ~DPNI_ID_IN_USE)
				== dpni->tc_rx[tc_id].plcrid)
				break;

		CHECK_COND_RETVAL(i != dpni->max_policers, -EINVAL);
		dpni->policer_ids[i] &= ~DPNI_ID_IN_USE;
	}

	return 0;
}

static int set_rx_tc_early_drop(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_early_drop_cfg *cfg)
{
	struct dpni_cgr_cfg cgr_cfg = { 0 };
	int i, err;

	cgr_cfg.cgid_index = &dpni->tc_rx[tc_id].cgid_index;
	
	if (*cgr_cfg.cgid_index != DPNI_INVALID_ID)
		cgr_cfg.cgid = dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].cgid;
	
	cgr_cfg.cfg = (void *)cfg;
	cgr_cfg.fill_cb = early_drop_fill;
	cgr_cfg.reset_cb = early_drop_reset;
	if (cfg->dpni_tail_drop_enable || cfg->dpni_wred_enable) {
		if ( (*cgr_cfg.cgid_index != DPNI_INVALID_ID) && 
				dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].notification_enable
			&& (cfg->units != dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].cg_notify.units)) {
			pr_err( "ID[%d]: tc_id (%d), early drop units %d must match the notification units %d\n",
					dpni->id, tc_id, cfg->units, dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].cg_notify.units);
			return -EINVAL;
		}
		err = set_cgr_enable(dpni, &cgr_cfg);
		if (err)
			return err;
		dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].early_drop_enable = 1;
		dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].oal = cfg->oal;

		/* Set the CGR on relevant FQIDs */
		if (!dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].notification_enable) {
			for (i = 0; i < dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size; i++) {
				dpni->tc_rx[tc_id].rx_queues[i].cgid_en = 1;
				dpni->tc_rx[tc_id].rx_queues[i].cgid_index = *cgr_cfg.cgid_index;
				config_fqid(
					dpni,
					&dpni->tc_rx[tc_id].rx_queues[i]); /*To update*/
			}
		}
		
		memcpy(&dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].cg_early_drop, cfg,
			sizeof(struct dpni_early_drop_cfg));
		
	} else if (*cgr_cfg.cgid_index != DPNI_INVALID_ID && dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].early_drop_enable) {
		/* Unset the CGR from relevant FQIDs */
		if (!dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].notification_enable) {
			for (i = 0; i < dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size; i++) {
				dpni->tc_rx[tc_id].rx_queues[i].cgid_en = 0;				
				config_fqid(
					dpni,
					&dpni->tc_rx[tc_id].rx_queues[i]);
			}
		}

		dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].early_drop_enable = 0;
		cgr_cfg.free_cgid = !dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].notification_enable;
		
		memcpy(&dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].cg_early_drop, cfg,
			sizeof(struct dpni_early_drop_cfg));
		
		err = set_cgr_disable(dpni, &cgr_cfg);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return 0;
}

static int set_cgid_early_drop(struct dpni *dpni,
	int cgid_index,
	const struct dpni_early_drop_cfg *cfg)
{
	struct dpni_cgr_cfg cgr_cfg = { 0 };
	int err;
	struct qbman_attr cgr_desc;
	struct qbman_swp *sw_portal; 


	if (cgid_index > DPNI_INVALID_ID)
		cgr_cfg.cgid = dpni->rx_tx_conf_cgids[cgid_index].cgid;
	else
		return -EINVAL;
	
	cgr_cfg.cfg = (void *)cfg;
	
	memcpy(&dpni->rx_tx_conf_cgids[cgid_index].cg_early_drop, cfg,
		sizeof(struct dpni_early_drop_cfg));
	
	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	
	err = qbman_cgr_query(sw_portal, (uint32_t)cgr_cfg.cgid,
					&cgr_desc);
	if (err) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}
	
	if (cfg->dpni_tail_drop_enable || cfg->dpni_wred_enable) {
		if ((cgid_index != DPNI_INVALID_ID) && dpni->rx_tx_conf_cgids[cgid_index].notification_enable
			&& (cfg->units != dpni->rx_tx_conf_cgids[cgid_index].cg_notify.units)) {
			pr_err( "ID[%d]:, early drop units %d must match the notification units %d\n", dpni->id, cfg->units,
					dpni->rx_tx_conf_cgids[cgid_index].cg_notify.units);
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			return -EINVAL;
		}
		
		early_drop_fill(cgr_cfg.cfg, &cgr_desc, 0);
		err = qbman_cgr_configure(sw_portal, (uint32_t)cgr_cfg.cgid,
							&cgr_desc);
		if (err){
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			return err;
		}
		
		dpni->rx_tx_conf_cgids[cgid_index].early_drop_enable = 1;
		dpni->rx_tx_conf_cgids[cgid_index].oal = cfg->oal;
		
		memcpy(&dpni->rx_tx_conf_cgids[cgid_index].cg_early_drop, cfg,
			sizeof(struct dpni_early_drop_cfg));
		
	} else if (dpni->rx_tx_conf_cgids[cgid_index].early_drop_enable) {
		
		dpni->rx_tx_conf_cgids[cgid_index].early_drop_enable = 0;

		early_drop_fill(cgr_cfg.cfg, &cgr_desc, 1);
		early_drop_reset(sw_portal, cgr_cfg.cgid, cgr_cfg.is_ccgid,
						cgr_cfg.ceetmid, cgr_cfg.cchannelid);
		
		err = qbman_cgr_configure(sw_portal, (uint32_t)cgr_cfg.cgid,
							&cgr_desc);
		
		CHECK_COND_RETVAL(err == 0, err);
	}
	
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return 0;
}

static int set_congestion_notification_dcp(struct dpni * dpni, uint32_t cgid, uint32_t dcpid, int enable)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr cgr_desc = {0};
	int err;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	err = qbman_cgr_query(sw_portal, cgid, &cgr_desc);
	if( err ) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}
	qbman_cgr_attr_set_cscn_tdcp(&cgr_desc, dcpid, enable);
	err = qbman_cgr_configure(sw_portal, cgid,&cgr_desc);

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return err;
}

static int dpni_get_cscn_notification_en(struct dpni *dpni, int tc_id)
{
	int retval = 0;
	
	if (dpni->tc_rx[tc_id].cgid_index == DPNI_INVALID_ID)
		return retval; 

	if( dpni->shared_congestion ) {
		// shared congestion, if a single TC has flow control enabled, return true
		for( tc_id=0 ; tc_id<dpni->max_rx_tcs; tc_id++ ) {
			if( dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cg_notify.notification_mode & DPNI_CGN_MODE_FLOW_CONTROL ) {
				retval = 1;
				break;
			}
		}
	} else {
		// each TC has unique congestion point, return only flag value
		retval = !!(dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cg_notify.notification_mode & DPNI_CGN_MODE_FLOW_CONTROL);
	}

	return retval;
}

static int update_eiop_cscn_priority(struct dpni *dpni, int ceetm_ch_idx, int tc_id, uint32_t flags)
{
	int enable_tx = 0;
	int enable_pfc = 0;
	uint8_t prio_mask = 0x00;
	int notification_pfc_en = 0;
	int cmd = 0;

	int err = 0;

	if( dpni->dpni==NULL && dpni->dpmac==NULL ) {
		//connection type not supported
		return 0;
	}
	
	if (dpni->tc_rx[tc_id].cgid_index == DPNI_INVALID_ID)
		return 0;

	if( dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].notification_enable ) {
		notification_pfc_en = dpni_get_cscn_notification_en(dpni, tc_id);

		enable_tx = !!(flags & DPNI_ENABLE_FC_SENDING);
		enable_pfc = !!(flags & DPNI_ENABLE_PFC_SENDING);

		if( dpni->dpmac!=NULL ) {
			prio_mask = 0x01<<tc_id;
			prio_mask = dpni->shared_congestion?0xff:prio_mask;
			prio_mask = (dpni->dpmac!=NULL)?prio_mask:0xff; // priority flow control works only with mac
			prio_mask = enable_tx?(enable_pfc?prio_mask:0xff):0x00;
			prio_mask = (notification_pfc_en)?prio_mask:0x00;
			cmd = 2;
		}
		else if( dpni->dpni != NULL && dpni->fc_idx != FLOW_CONTROL_INVALID_INDEX ){
			prio_mask = 0x01 << dpni->fc_idx;
			cmd = enable_tx;
		} else {
			return 0;
		}

		if( dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].virtual_cgid < MAX_CGID_VIRT_ID ) {
			err = dpni_config_ppid_priority(dpni, (uint16_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].virtual_cgid, EIOP_CGP_CONGESTION_GROUP, prio_mask, cmd);
			CHECK_COND_RETVAL(err==0, err, "Could not set congestion priority mask for ppid\n");
		}
		else
			pr_err("ID[%d]: TC[%d] cannot be configured to generate PFC frames (virtual cgid %d)\n",
					dpni->id, tc_id, dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].virtual_cgid);

		if( dpni->dpmac==NULL ) {
			err = set_congestion_notification_dcp(dpni, (uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid, (uint32_t)dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, enable_tx);
			CHECK_COND_RETVAL(err==0, err, "Could not set notification dcp; flow control feature will not work");
		}
	}

	return 0;
}

static int update_cscn_dcp(struct dpni *dpni, int ceetm_ch_idx, int tc_id, uint32_t flags)
{
	int enable_tx;
	int enable;
	int dcp_en;
	int dcpid;
	int err;
	int notification_pfc_en = 0;

	notification_pfc_en = dpni_get_cscn_notification_en(dpni, tc_id);

	enable = !!flags;
	enable_tx = !!(flags & DPNI_ENABLE_FC_SENDING);
	dcp_en = enable?enable_tx:0;
	dcp_en = (notification_pfc_en)?dcp_en:0;
	dcpid = dpni->tx_ch[ceetm_ch_idx].ap.dcp_id;
	err = set_congestion_notification_dcp(dpni, (uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid, (uint32_t)dcpid, dcp_en);
	CHECK_COND_RETVAL( err==0, err, "Could not %s cscn dcp (tc: %d, cgid: %d); cscn based flow control may not work\n",
				dcp_en?"update":"clear", tc_id, dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid);

	return 0;
}

static int config_cscn_tx_pfc(struct dpni *dpni, int ceetm_ch_idx, int tc_id, uint32_t flags)
{
	if( dpni->dpni==NULL && dpni->dpmac==NULL ) {
		// connection not supported
		return 0;
	}

	if (dpni->tc_rx[tc_id].cgid_index == DPNI_INVALID_ID)
		return 0;
	
	if( dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].notification_enable ) {
		update_eiop_cscn_priority(dpni, ceetm_ch_idx, tc_id, flags);
		/* Update the notified DCPs only if they weren't already set */
		if (!(dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cg_notify.notification_mode &
		      DPNI_CGN_NOTIFY_AIOP_DCP) &&
		    !(dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cg_notify.notification_mode &
		      DPNI_CGN_NOTIFY_WRIOP_DCP))
			update_cscn_dcp(dpni, ceetm_ch_idx, tc_id, flags);
	}

	return 0;
}

static int set_rx_tc_congestion_notification(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_congestion_notification_cfg *cfg)
{
	struct dpni_cgr_cfg cgr_cfg = { 0 };
	int i, err;
	int configure_pfc = 0;
	int early_drop_enable;
	enum dpni_congestion_unit early_drop_units = DPNI_CONGESTION_UNIT_BYTES;
	int tmp;
	uint32_t pfc_flags;
	struct dpni_link_state link_state;
	uint64_t options;

	cgr_cfg.cgid_index = &dpni->tc_rx[tc_id].cgid_index;
	
	if (*cgr_cfg.cgid_index != DPNI_INVALID_ID)
		cgr_cfg.cgid = dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].cgid;
	
	cgr_cfg.cfg = (void *)cfg;
	cgr_cfg.fill_cb = congestion_notification_fill;
	cgr_cfg.reset_cb = NULL;
	if (cfg->threshold_entry != 0) {
		early_drop_enable = *cgr_cfg.cgid_index <= DPNI_INVALID_ID ? 0 : dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].early_drop_enable;
		early_drop_units = *cgr_cfg.cgid_index <= DPNI_INVALID_ID ? DPNI_CONGESTION_UNIT_BYTES : dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].cg_early_drop.units;
		err = check_congestion_notification(
			dpni, early_drop_enable,
			early_drop_units, cfg);
		if (err) {
			pr_err("ID[%d]: tc_id (%d) - configuration check failed\n", dpni->id, tc_id);
			return err;
		}

		err = set_cgr_enable(dpni, &cgr_cfg);
		CHECK_COND_RETVAL(err == 0, err);
		dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].notification_enable = 1;
		if( dpni->enabled ) {
			// configure PFC later
			// cannot configure here because dpni structure not yet updated
			configure_pfc = 1;
		}
		/* Set the CGR on relevant FQIDs */
		if (!dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].early_drop_enable) {
			for (i = 0; i < dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size; i++) {
				dpni->tc_rx[tc_id].rx_queues[i].cgid_en = 1;
				dpni->tc_rx[tc_id].rx_queues[i].cgid_index = *cgr_cfg.cgid_index;
				config_fqid(
					dpni,
					&dpni->tc_rx[tc_id].rx_queues[i]);
			}
		}
		
		memcpy(&dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].cg_notify, cfg,
			sizeof(struct dpni_congestion_notification_cfg));

		
	} else if (*cgr_cfg.cgid_index != DPNI_INVALID_ID && dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].notification_enable) {
		/* Unset the CGR from relevant FQIDs */
		if (!dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].early_drop_enable) {
			for (i = 0; i < dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size; i++) {
				dpni->tc_rx[tc_id].rx_queues[i].cgid_en = 0;
				config_fqid(
					dpni,
					&dpni->tc_rx[tc_id].rx_queues[i]);
			}
		}
		if( dpni->enabled ) {
			config_cscn_tx_pfc(dpni, 0, tc_id, 0);
		}
		dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].notification_enable = 0;
		cgr_cfg.free_cgid = !dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].early_drop_enable;
		
		memcpy(&dpni->rx_tx_conf_cgids[*cgr_cfg.cgid_index].cg_notify, cfg,
			sizeof(struct dpni_congestion_notification_cfg));		
		
		err = set_cgr_disable(dpni, &cgr_cfg);
		if (err)
			return err;
	}

	if( configure_pfc && (dpni->dpmac != NULL || dpni->dpni != NULL) ) {
		// configure pfc if connected to dpmac or other dpni
		pfc_flags = 0;
		err = dpni_get_link_state(dpni, &link_state);
		if( link_state.up ) {
			options = link_state.options;
			tmp = (!!(options & LINKMAN_LINK_OPT_PAUSE)) ^ (!!(options & LINKMAN_LINK_OPT_ASYM_PAUSE));
			if( tmp ) pfc_flags |= DPNI_ENABLE_FC_SENDING;
			tmp = !!(options & LINKMAN_LINK_OPT_PAUSE);
			if( tmp ) pfc_flags |= DPNI_ENABLE_FC_RESPONSE;
			tmp = (!!(options & LINKMAN_LINK_OPT_PFC_PAUSE)) & (!!(pfc_flags & DPNI_ENABLE_FC_SENDING));
			if( tmp ) pfc_flags |= DPNI_ENABLE_PFC_SENDING;
			tmp = (!!(options & LINKMAN_LINK_OPT_PAUSE)) & (!!(options & LINKMAN_LINK_OPT_PFC_PAUSE));
			if( tmp ) pfc_flags |= DPNI_ENABLE_PFC_RESPONSE;
			if( dpni->dpni!=NULL ) {
				// dpni-dpni connection supports only simple flow control
				pfc_flags = pfc_flags & (~(DPNI_ENABLE_PFC_SENDING | DPNI_ENABLE_PFC_RESPONSE) );
			}
		}
		else
			pfc_flags = 0;
		config_cscn_tx_pfc(dpni, 0, tc_id, pfc_flags);
	}

	return 0;
}

static int set_rx_cgid_congestion_notification(struct dpni *dpni,
	int cgid_index,
	const struct dpni_congestion_notification_cfg *cfg)
{
	struct dpni_cgr_cfg cgr_cfg = { 0 };
	int err;
	int configure_pfc = 0;
	struct qbman_attr cgr_desc;
	struct qbman_swp *sw_portal; 
	
	if (cgid_index > DPNI_INVALID_ID)
		cgr_cfg.cgid = dpni->rx_tx_conf_cgids[cgid_index].cgid;
	else
		return -EINVAL;

	cgr_cfg.cfg = (void *)cfg;

	memcpy(&dpni->rx_tx_conf_cgids[cgid_index].cg_notify, cfg,
		sizeof(struct dpni_congestion_notification_cfg));
	
	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	
	err = qbman_cgr_query(sw_portal, (uint32_t)cgr_cfg.cgid,
					&cgr_desc);
	if (err) {
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		return err;
	}
	
	if (cfg->threshold_entry != 0) {
		err = check_congestion_notification(
			dpni, dpni->rx_tx_conf_cgids[cgid_index].early_drop_enable,
			dpni->rx_tx_conf_cgids[cgid_index].cg_early_drop.units, cfg);
		if (err) {
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			pr_err("ID[%d]: cgid (%d) - configuration check failed\n", dpni->id, cgid_index);
			return err;
		}
		
		congestion_notification_fill(cgr_cfg.cfg, &cgr_desc, 0);

		err = qbman_cgr_configure(sw_portal, (uint32_t)cgr_cfg.cgid,
							&cgr_desc);
		if (err){
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			return err;
		}

		dpni->rx_tx_conf_cgids[cgid_index].notification_enable = 1;
		
		memcpy(&dpni->rx_tx_conf_cgids[cgid_index].cg_notify, cfg,
			sizeof(struct dpni_congestion_notification_cfg));

		
	} else if (dpni->rx_tx_conf_cgids[cgid_index].notification_enable) {

		dpni->rx_tx_conf_cgids[cgid_index].notification_enable = 0;
		
		congestion_notification_fill(cgr_cfg.cfg, &cgr_desc, 1);		
		
		err = qbman_cgr_configure(sw_portal, (uint32_t)cgr_cfg.cgid,
							&cgr_desc);
		
		CHECK_COND_RETVAL(err == 0, err);
	}

	return 0;
}


static int set_tx_conf_congestion_notification(struct dpni *dpni,
	uint16_t flow_id,
	struct dpni_tx_conf_info *info,
	const struct dpni_congestion_notification_cfg *cfg)
{
	struct dpni_cgr_cfg cgr_cfg = { 0 };
	int err;

	cgr_cfg.cgid = dpni->rx_tx_conf_cgids[info->queue_info.cgid_index].cgid;
	cgr_cfg.cgid_index = &info->queue_info.cgid_index;
	cgr_cfg.cfg = (void *)cfg;
	cgr_cfg.fill_cb = congestion_notification_fill;
	cgr_cfg.reset_cb = NULL;
	if (cfg->threshold_entry != 0) {
		err = check_congestion_notification(
			dpni, 0, (enum dpni_congestion_unit)0, cfg);
		if (err) {
			pr_err("ID[%d]: flow_id (%d) - configuration check failed\n", dpni->id, flow_id);
			return err;
		}

		err = set_cgr_enable(dpni, &cgr_cfg);
		CHECK_COND_RETVAL(err == 0, err);
		info->notification_enable = 1;
		/* Set the CGR on relevant FQID */
		info->queue_info.cgid_en = 1;
		config_fqid(dpni, &info->queue_info);
	} else if (info->notification_enable) {
		/* Unset the CGR from relevant FQID */
		info->queue_info.cgid_en = 0;
		config_fqid(dpni, &info->queue_info);

		info->notification_enable = 0;
		cgr_cfg.free_cgid = (flow_id == DPNI_COMMON_TX_CONF) ? 0 : 1;
		err = set_cgr_disable(dpni, &cgr_cfg);
		CHECK_COND_RETVAL(err == 0, err);
	}

	memcpy(&info->cg_notify, cfg,
		sizeof(struct dpni_congestion_notification_cfg));

	return 0;
}

static void clear_all_policers_n_cgs(struct dpni *dpni)
{
	struct dpni_rx_tc_policing_cfg plcr_cfg;
	struct dpni_early_drop_cfg ed_cfg;
	struct dpni_congestion_notification_cfg notify_cfg;
	uint8_t i,j;
	int ceetm_ch_idx;

	memset(&plcr_cfg, 0, sizeof(struct dpni_rx_tc_policing_cfg));
	memset(&ed_cfg, 0, sizeof(struct dpni_early_drop_cfg));
	memset(&notify_cfg, 0,
		sizeof(struct dpni_congestion_notification_cfg));
	
	for (i = 0; i < dpni->max_rx_tcs; i++) {
		/* RX - reset early-drop, congestion notification and policers */
		if (dpni->tc_rx[i].policer_enable)
			set_rx_tc_policer(dpni, i, &plcr_cfg);
		if (dpni->tc_rx[i].cgid_index != DPNI_INVALID_ID)
		{
			if (dpni->rx_tx_conf_cgids[dpni->tc_rx[i].cgid_index].early_drop_enable)
				set_rx_tc_early_drop(dpni, i, &ed_cfg);
			if (dpni->rx_tx_conf_cgids[dpni->tc_rx[i].cgid_index].notification_enable)
				set_rx_tc_congestion_notification(dpni, i,
								&notify_cfg);
		}
		for (j =0; j < dpni->tc_rx[SELECT_TC_SHARED_FS(i)].dist_size; j++)
		{
			if (dpni->tc_rx[i].rx_queues[j].cgid_index != DPNI_INVALID_ID)
			{
				if (dpni->rx_tx_conf_cgids[dpni->tc_rx[i].rx_queues[j].cgid_index].early_drop_enable)
					set_cgid_early_drop(dpni, dpni->tc_rx[i].rx_queues[j].cgid_index, &ed_cfg);
				if (dpni->rx_tx_conf_cgids[dpni->tc_rx[i].rx_queues[j].cgid_index].notification_enable)
					set_rx_tc_congestion_notification(dpni, i,
									&notify_cfg);
			}
		}
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		for (i = 0; i < dpni->max_tx_tcs; i++) {
			/* TX - reset both early-drop and congestion notification */
			memcpy(&dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cg_early_drop, &ed_cfg,
					sizeof(struct dpni_early_drop_cfg));
			memcpy(&dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cg_notify, &notify_cfg,
					sizeof(struct dpni_congestion_notification_cfg));
			config_tx_tc_ccg(dpni, ceetm_ch_idx, i);
		}
	}

	/* TX-Conf - reset common tx-conf congestion notification */
	set_tx_conf_congestion_notification(dpni, DPNI_COMMON_TX_CONF,
						&dpni->tx_conf_err,
						&notify_cfg);
	
	pr_debug("clear_all_policers_n_cgs clear max_senders \n");

	/* TX-Conf - reset congestion notification */
	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		for (i = 0; i < dpni->max_senders; i++)
			if (dpni->tx_ch[ceetm_ch_idx].sender_info[i].valid)
				set_tx_conf_congestion_notification(
						dpni, 0, &dpni->tx_ch[ceetm_ch_idx].sender_info[i].tx_conf_err,
						&notify_cfg);
	}
}

static void dpni_set_mc_info(struct dpni *dpni,
	const struct dpmng_dev_cfg *dev_cfg)
{
	struct aiop_tile_desc aiop_tile_desc = { 0 };

	ASSERT_COND(dev_cfg->device);

	dpni->id = dev_cfg->id;
	dpni->device = dev_cfg->device;
	dpni->dev_ctx.type = dev_cfg->ctx.type;
	dpni->eiop_id = 0;

	dpni->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	ASSERT_COND(dpni->dpmng);
	dpni->linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	ASSERT_COND(dpni->linkman);
	dpni->ing_dpkg = sys_get_handle(FSL_MOD_KG, 2, dpni->eiop_id,
					CTLU_EIOP_INGRESS);
	ASSERT_COND(dpni->ing_dpkg);
	dpni->ing_dptbl = sys_get_handle(FSL_MOD_TABLES_MNG, 2, dpni->eiop_id,
						CTLU_EIOP_INGRESS);
	ASSERT_COND(dpni->ing_dptbl);
	dpni->ing_dpparser = sys_get_handle(FSL_MOD_PARSER, 2, dpni->eiop_id,
						CTLU_EIOP_INGRESS);
	ASSERT_COND(dpni->ing_dpparser);
	dpni->egr_dpparser = sys_get_handle(FSL_MOD_PARSER, 2, dpni->eiop_id,
						CTLU_EIOP_EGRESS);
	ASSERT_COND(dpni->egr_dpparser);

	dpni->ing_dppolicer = sys_get_handle(FSL_MOD_POLICER, 2, dpni->eiop_id,
						CTLU_EIOP_INGRESS);
	ASSERT_COND(dpni->ing_dppolicer);

	dpni->ing_dppolicy = sys_get_handle(FSL_MOD_POLICIES_MNG, 2,
						dpni->eiop_id,
						CTLU_EIOP_INGRESS);
	ASSERT_COND(dpni->ing_dppolicy);

	if (sys_get_desc(SOC_MODULE_AIOP, 0, &aiop_tile_desc, NULL) == 0) {
		dpni->aiop_tile = sys_get_handle(FSL_MOD_AIOP_TILE, 1, 0);
		ASSERT_COND(dpni->aiop_tile);
	}
}

static int clear_buffer_depletion_priority(struct dpni *dpni)
{
	return set_buffer_depletion_priority(dpni, 1, 0, 0);
}

static int check_pfc_compatibility(struct dpni *dpni, const struct dpni_link_cfg *cfg)
{
	int enable_tx;
	uint8_t tc_id = 0;
	uint16_t flow_id = 0;
	uint32_t rate;
	int err;

	enable_tx = get_tx_pause_status(dpni) && !get_pfc_status(dpni);

	// tail drop compatibility check
	for (tc_id = 0; tc_id < dpni->max_rx_tcs; tc_id++) {
		for (flow_id = 0; flow_id < dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size; flow_id++) {
			if( enable_tx && dpni->tc_rx[tc_id].rx_queues[flow_id].tail_drop_threshold ) {
				// just print a warning
				pr_warn("ID[%d]: tail drop enabled; flow control may not work as expected\n", dpni->id);
				break;
			}
		}
		if( flow_id!=dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size ) {
			break;
		}
	}

	// mac compatibility check
	if( dpni->enabled && dpni->dpmac ) {
		// check desired configuration against current dpmac configuration
		if( (cfg->options & DPNI_LINK_OPT_AUTONEG)==0 ) {
			// fixed link - dpmac and dpni must have same rate
			err = dpmac_get_rate(dpni->dpmac, &rate);
			CHECK_COND_RETVAL(err==0, err, "Could not obtain dpmac link rate");
		}
	}

	return 0;
}

static int check_taildrop_compatibility(struct dpni *dpni)
{
	int enable_tx;

	enable_tx = get_tx_pause_status(dpni) && !get_pfc_status(dpni);
	if( enable_tx ) {
		pr_warn("ID[%d]: tail drop enabled may have conflicts with flow control settings\n", dpni->id);
	}
	return 0;
}


static void dpni_update_pfc_settings(struct dpni *dpni, uint32_t flags)
{
	int tc_id;

	// configure flow control based on congestion notification
	for( tc_id=0 ; tc_id<dpni->max_rx_tcs ; tc_id++ )
		config_cscn_tx_pfc(dpni, 0, tc_id, flags);

	update_buffer_depletion_priority(dpni, flags);
	dpni->flow_control_enabled=1;

	// configure response to Priority Flow Control frames
	config_tc_class_flow_cotrol(dpni, 0, !!(flags & DPNI_ENABLE_FC_RESPONSE));
}

static int dpni_apply_link_cfg(struct dpni *dpni)
{
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr attr;
	struct linkman_control control;
	struct dpni_link_state;
	int err = 0;

	// flip the link to update latest changes into link manager
	memset(&endpoint1, 0x0, sizeof(struct linkman_endpoint));
	memset(&endpoint2, 0x0, sizeof(struct linkman_endpoint));
	memset(&attr, 0x0, sizeof(struct linkman_connection_attr));
	memset(&control, 0x0, sizeof(struct linkman_control));
	endpoint1.type = FSL_MOD_DPNI;
	endpoint1.id = (uint16_t)dpni->id;

	err = linkman_get_connection(dpni->linkman, &endpoint1, &endpoint2, &attr);
	if ((!err) && (attr.state != LINKMAN_STATE_IDLE) && (attr.state != LINKMAN_STATE_CONNECTED)) {
		if(attr.state == LINKMAN_STATE_NEGOTIATION) {
			control.event = LINKMAN_EVENT_NEGOTIATION_FAIL;
			err = linkman_set_connection(dpni->linkman, &control, &endpoint1, &endpoint2);
			CHECK_COND_RETVAL(err==0, err, "ID[%d]: linkman_set_connection (LINKMAN_EVENT_NEGOTIATION_FAIL) failed\n", dpni->id);
		} else {
			control.event = LINKMAN_EVENT_LINKDOWN;
			err = linkman_set_connection(dpni->linkman, &control, &endpoint1, &endpoint2);
			CHECK_COND_RETVAL(err==0, err, "ID[%d]: linkman_set_connection (LINKMAN_EVENT_LINKDOWN) failed\n", dpni->id);
		}

		control.event = LINKMAN_EVENT_LINKUP;
		control.cmd = LINKMAN_CMD_SET_LINK_CFG;
		err = linkman_set_connection(dpni->linkman, &control, &endpoint1, &endpoint2);
		CHECK_COND_RETVAL(err==0, err, "ID[%d]: linkman_set_connection (LINKMAN_EVENT_LINKUP) failed\n", dpni->id);
	}
	return 0;
}

struct dpni *dpni_allocate(void)
{
	struct dpni *dpni;

	dpni = (struct dpni *)fsl_xmalloc(sizeof(struct dpni), 0,
						CORE_CACHELINE_SIZE);
	if (dpni)
		memset(dpni, 0, sizeof(struct dpni));
	return dpni;
}

void dpni_deallocate(struct dpni *dpni)
{
	if( dpni->tx_ch != NULL )
		fsl_xfree(dpni->tx_ch);
	fsl_xfree(dpni);
}

int dpni_set_dev_ctx(struct dpni *dpni, const struct dpmng_dev_ctx *dev_ctx)
{
	int err;

	if (memcmp(&dpni->dev_ctx, dev_ctx, sizeof(struct dpmng_dev_ctx))
		!= 0) {
		if ((err = resources_deauthorization(dpni)) != 0) {
			pr_err("ID[%d]: resources_deauthorization failed \n", dpni->id);
			return err;
		}

		memcpy(&dpni->dev_ctx, dev_ctx, sizeof(struct dpmng_dev_ctx));
		dpni->dev_ctx.amq.bdi =
			(dev_ctx->type == DPMNG_CTX_TYPE_GPP) ? 0 : 1;

		if ((err = resources_authorization(dpni)) != 0) {
			pr_err("ID[%d]: resources_authorization failed \n", dpni->id);
			return err;
		}
	}

	return 0;
}

static int dpni_filter_flow_control_multicast(struct dpni *dpni)
{
	struct dptbl_rule rule;
	int err;
	uint8_t multicast_mac[] = {0x01, 0x80, 0xc2, 0x00, 0x00, 0x01};

	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = (uint8_t *)multicast_mac;
	rule.rule_cfg.exact.size = 6;

	memset(&dpni->filters.tbl_deny_action, 0, sizeof(struct dptbl_action));
	dpni->filters.tbl_deny_action.next_action = DPTBL_ACTION_DONE;
	dpni->filters.tbl_deny_action.options = DPTBL_ACTION_SET_DISCARD_FLAG;
	err = dptbl_add_rule(dpni->filters.fc_multicast_tbl, &rule,
				&dpni->filters.tbl_deny_action, 0);
	CHECK_COND_RETVAL( err==0, err, "ID[%d]: Failed to add flow control multicast in filter table\n", dpni->id);

	return 0;
}

static int dpni_clear_flow_control_multicast(struct dpni *dpni)
{
	struct dptbl_rule rule;
	int err;
	uint8_t multicast_mac[] = {0x01, 0x80, 0xc2, 0x00, 0x00, 0x01};

	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = multicast_mac;
	rule.rule_cfg.exact.size = 6;
	err = dptbl_remove_rule(dpni->filters.mac_tbl, &rule);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);

	return 0;
}

int dpni_init(struct dpni *dpni,
	struct dpni_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
	int ceetm_ch_idx;
	int i, err;

	err = config_retire_storage_data(dpni); // when init fails mc will execute destroy() and will need this data
	CHECK_COND_RETVAL(err==0, err, "Failed to configure queue retire storage data\n");

	dpni_set_mc_info(dpni, dev_cfg);

	set_default_cfg(dpni, cfg);

	dpni->tx_ch = fsl_xmalloc( sizeof(struct dpni_tx_channel_data) * dpni->num_ceetm_ch, 0, CORE_CACHELINE_SIZE);
	CHECK_COND_RETVAL( dpni->tx_ch != NULL, -ENOMEM, "ID[%d] Fail to allocate extra memory\n", dpni->id);

	memset(dpni->tx_ch, 0, sizeof(struct dpni_tx_channel_data) * dpni->num_ceetm_ch);

	dpni->is_snic = is_snic(dpni, cfg);

	if ((err = check_dpni_cfg(dpni, cfg)) != 0) {
		pr_err("ID[%d]: check_dpni_cfg() failed\n", dpni->id);
		return err;
	}

	memcpy(dpni->mac_addr, cfg->mac_addr, 6);
	err = dpparser_get_hdr_code(cfg->adv.start_hdr, &dpni->ing_start_hxs);
	err = dpparser_get_hdr_code(cfg->adv.start_hdr, &dpni->egr_start_hxs);
	CHECK_COND_RETVAL(err == 0, err);

	NEXT_POWER_OF_2(cfg->adv.max_senders, dpni->max_senders);
	dpni->options = cfg->adv.options;
	dpni->single_sender = cfg->adv.single_sender;
	if( cfg->adv.max_rx_tcs == 0 ) {
		dpni->max_rx_tcs = cfg->adv.max_tcs > DPNI_MAX_RX_TC ? DPNI_MAX_RX_TC : cfg->adv.max_tcs;
		dpni->max_tx_tcs = cfg->adv.max_tcs;
	}
	else {
		dpni->max_rx_tcs = cfg->adv.max_rx_tcs;
		dpni->max_tx_tcs = cfg->adv.max_tcs;
	}

	dpni->default_pps = cfg->adv.default_pps;

	if (!IS_SHARED_FS_ENABLED) {
		for (i = 0; i < dpni->max_rx_tcs; i++) {
			dpni->tc_rx[i].max_dist_size = get_valid_dist_size(
				cfg->adv.ext_cfg.tc_cfg[i].max_dist);
			dpni->tc_rx[i].dist_size = 1;
			dpni->tc_rx[i].max_dist_key_size = cfg->adv.max_dist_key_size;
			dpni->tc_rx[i].max_fs_entries =
				cfg->adv.ext_cfg.tc_cfg[i].max_fs_entries;
			if (dpni->is_fs_backward_comp)
				dpni->tc_rx[i].max_fs_entries =
					dpni->tc_rx[i].max_dist_size;
		}
	} else {
		dpni->tc_rx[0].max_dist_size = get_valid_dist_size(
						cfg->adv.ext_cfg.tc_cfg[0].max_dist);
		dpni->tc_rx[0].dist_size = 1;
		dpni->tc_rx[0].max_dist_key_size = cfg->adv.max_dist_key_size;
		dpni->tc_rx[0].max_fs_entries =
			cfg->adv.ext_cfg.tc_cfg[0].max_fs_entries;
		if (dpni->is_fs_backward_comp)
			dpni->tc_rx[0].max_fs_entries =
				dpni->tc_rx[0].max_dist_size;
	}

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		for(i = 0; i < dpni->max_tx_tcs; i++ ) {
			dpni->tx_ch[ceetm_ch_idx].tc_tx[i].virtual_cgid = QBMAN_INVALID_VRID;
		}
	}

	if (dpni->options & DPNI_OPT_SHARED_MAC_TABLE) {
		dpni->filters.max_mac_filters = cfg->adv.max_unicast_filters;
		dpni->filters.max_multicast_filters = 0;
	} else {
		dpni->filters.max_unicast_filters = cfg->adv.max_unicast_filters;
		dpni->filters.max_multicast_filters = cfg->adv.max_multicast_filters;
	}
	dpni->filters.max_vlan_filters = cfg->adv.max_vlan_filters;
	dpni->qos.max_qos_entries = cfg->adv.max_qos_entries;
	dpni->qos.max_qos_key_size = cfg->adv.max_qos_key_size;
	dpni->qos.actual_qos_key_size = cfg->adv.max_qos_key_size;
	dpni->max_policers = cfg->adv.max_policers;
	dpni->max_congestion_ctrl = cfg->adv.max_congestion_ctrl;
	dpni->shared_congestion = cfg->adv.shared_congestion;
	dpni->max_opr = cfg->adv.max_opr;
	if (dpni->options & DPNI_OPT_IPR)
		memcpy(&dpni->snic.ipr_cfg, &cfg->adv.ext_cfg.ipr_cfg,
			sizeof(struct dpni_ipr_cfg));
	if (dpni->options & DPNI_OPT_IPSEC)
		memcpy(&dpni->snic.ipsec_info.cfg, &cfg->adv.ext_cfg.ipsec_cfg,
			sizeof(struct dpni_ipsec_cfg));
	
	for (i = 0; i< dpni->max_congestion_ctrl; i++) {
		memset(&dpni->rx_tx_conf_cgids[i], 0, sizeof(struct dpni_congestion_group));
	}

	dpni_dump(dpni, DPNI_DUMP_SETTINGS);

	pr_debug( "ID[%d]: alloc_internal_resources()\n", dpni->id);
	if ((err = alloc_internal_resources(dpni)) != 0) {
		pr_err("ID[%d]: alloc_internal_resources failed\n", dpni->id);
		dpni_destroy(dpni);
		return err;
	}

	pr_debug("ID[%d]: resources_allocation()\n", dpni->id);
	if ((err = resources_allocation(dpni)) != 0) {
		pr_err("ID[%d]: resources_allocation failed\n", dpni->id);
		dpni_destroy(dpni);
		return err;
	}

	dpni_dump(dpni, DPNI_DUMP_RESOURCES);

	set_defaults(dpni, 0);

	err = initial_configuration(dpni);
	if (err != 0) {
		pr_err("ID[%d]: initial_configuration failed\n", dpni->id);
		dpni_destroy(dpni);
		return err;
	}

	if ((err = set_tx_rejection_mode(dpni, 1)) != 0) {
		pr_err("ID[%d]: set_tx_rejection_mode failed\n", dpni->id);
		return err;
	}

#ifdef DPNI_DUMP_STRUCTURE
	mem_disp((uint8_t*)dpni, sizeof(struct dpni));
#endif /* DPNI_DUMP_STRUCTURE */

	for (i = 0; i < DPNI_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpni->irqs[i]), MC_IRQ_TYPE_MSI);

	dpni_set_dev_ctx(dpni, &dev_cfg->ctx);

#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		dpni_filter_flow_control_multicast(dpni);
	}
#endif

	return 0;
}

static int dpni_clean_redirect_rules(struct dpni *dpni, int param, int val)
{
	struct dpni_table_rule *tbl_rule = NULL;
	struct dptbl_rule rule = { 0 };
	struct dptbl_action action;
	int rule_idx, tc_idx;
	int max_tc_loop;
	int err;
	uint16_t token = 0;
	int dpni_id = -1;

	if( param == 0 )
		token = (uint16_t)val;
	else
		dpni_id = val;

	if( IS_SHARED_FS_ENABLED )
		max_tc_loop = 1;
	else
		max_tc_loop = dpni->max_rx_tcs;

	for( tc_idx = 0 ; tc_idx < max_tc_loop ; tc_idx++ ) {
		rule_idx = 0;
		do {
			tbl_rule = &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_idx)].keys[rule_idx];

			if( !tbl_rule->in_use ) {
				rule_idx++;
				continue;
			}

			if( !tbl_rule->redirect.valid ) {
				rule_idx++;
				continue;
			}

			if( param == 0) {
				if( tbl_rule->redirect.token != token ){
					rule_idx++;
					continue;
				}
			}
			else {
				if( tbl_rule->redirect.obj_id != dpni_id ) {
					rule_idx++;
					continue;
				}
			}

			if( tbl_rule->rule.key_cfg.maskable ) {
				rule.rule_cfg.masked.key		= tbl_rule->rule.key_cfg.key;
				rule.rule_cfg.masked.mask		= tbl_rule->rule.key_cfg.mask;
				rule.rule_cfg.masked.size		= tbl_rule->rule.key_cfg.size;
				rule.rule_cfg.masked.priority	= tbl_rule->rule.key_cfg.priority;
			}
			else {
				rule.rule_cfg.masked.key		= tbl_rule->rule.key_cfg.key;
				rule.rule_cfg.masked.size		= tbl_rule->rule.key_cfg.size;
			}

			memset(&action, 0, sizeof(action));
			if( tbl_rule->redirect.remote_entry->options & DPNI_FS_OPT_DISCARD ) {
				action.options = DPTBL_ACTION_SET_DISCARD_FLAG;
			}
			else {
				action.options = DPTBL_ACTION_SET_QDBIN | DPTBL_ACTION_SET_OPAQUE;
				action.qd_bin = get_qdbin_from_flowid(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_idx)].dist_size,
						tbl_rule->redirect.remote_entry->flow_id);
			}
			action.next_action = DPTBL_ACTION_DONE;

			err = dptbl_modify_rule(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_idx)].fs_tbl, &rule, &action);
			if( err ) {
				if( param == 0 )
					pr_err("dpni.%d: fail to modify redirect rule for token %d... continue\n", dpni->id, token);
				else
					pr_err("dpni.%d: fail to modify redirect rule to dpni.%d (destroy)\n", dpni->id, dpni_id);
			}
			else {
				if( param == 0 )
					pr_warn("Token %d closed, redirect rule for dpni.%d modified\n", token, dpni->id);
				else
					pr_warn("dpni.%d is destroyed, redirect rule for dpni.%d modified\n", dpni_id, dpni->id);
			}

			memcpy(&tbl_rule->action, &action, sizeof(action));
			tbl_rule->redirect.valid = 0;
			tbl_rule->redirect.remote_entry->valid = 0;

			rule_idx++;
		} while( !tbl_rule->is_last );
	}

	return 0;
}

void dpni_destroy(struct dpni *dpni)
{
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr attr;
	struct linkman_control control;
	int err;

	struct dpni_fs_redirect_table_entry *redirect_entry;
	struct dpni *src_dpni;
	int rule_idx;

	for( rule_idx = 0 ; rule_idx < DPNI_MAX_FS_REDIRECT_ENTRIES ; rule_idx++ ) {
		redirect_entry = &dpni->fs_redirect_table[rule_idx];

		if( !redirect_entry->valid )
			continue;

		src_dpni = sys_get_handle(FSL_MOD_DPNI, 1, redirect_entry->obj_id);
		if( src_dpni == NULL )
			continue;

		dpni_clean_redirect_rules(src_dpni, 1, dpni->id);
	}

	if (dpni->enabled)
		dpni_disable(dpni);

	memset(&endpoint1, 0x0, sizeof(struct linkman_endpoint));
	memset(&endpoint2, 0x0, sizeof(struct linkman_endpoint));
	memset(&attr, 0x0, sizeof(struct linkman_connection_attr));
	memset(&control, 0x0, sizeof(struct linkman_control));
	endpoint1.type = FSL_MOD_DPNI;
	endpoint1.id = (uint16_t)dpni->id;
	err = linkman_get_connection(dpni->linkman, &endpoint1, &endpoint2, &attr);
	if ((!err) && (attr.state != LINKMAN_STATE_IDLE)) {
		control.event = LINKMAN_EVENT_DISCONNECT;
		if (linkman_set_connection(dpni->linkman, &control, &endpoint1,
						&endpoint2)
			!= 0)
			pr_warn( "ID[%d]: linkman_set_connection (DISCONNECT) failed\n", dpni->id);
	}
	
	err = resources_deauthorization(dpni);
	ASSERT_COND(!err);

	clear_tx_side(dpni);

	clear_rx_side(dpni);

	delete_ctlu(dpni);

	if (dpni->is_snic)
		snic_destroy(dpni);

	err = resources_deallocation(dpni);
	ASSERT_COND(!err);

	free_internal_resources(dpni);
}

int dpni_clean_flow_control_config(struct dpni *dpni)
{
	dpni_update_pfc_settings(dpni, 0);
	dpni->fc_idx = FLOW_CONTROL_INVALID_INDEX;

	return 0;
}

static int dpni_reset_flow_control(struct dpni *dpni)
{
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr link_attr;
	void *object;
	int err;

	dpni_update_pfc_settings(dpni, 0);

	if( dpni->fc_idx == FLOW_CONTROL_INVALID_INDEX ) {
		return 0;
	}

	memset(&endpoint1, 0, sizeof(endpoint1));
	memset(&endpoint2, 0, sizeof(endpoint2));
	memset(&link_attr, 0, sizeof(link_attr));

	endpoint1.type = FSL_MOD_DPNI;
	endpoint1.id = (uint16_t)dpni->id;
	err = linkman_get_connection(dpni->linkman, &endpoint1, &endpoint2, &link_attr);
	CHECK_COND_RETVAL(err==0, err, "Could not get connected object to dpni.%d\n", dpni->id);

	object = sys_get_handle(endpoint2.type, 1, endpoint2.id);
	CHECK_COND_RETVAL(object, -ENODEV, "[ID: %d] Could not get connected object\n", dpni->id);

	switch( endpoint2.type ) {
	case FSL_MOD_DPNI:
		CHECK_COND_RETVAL(dpni->ap_valid, -EINVAL, "Connected dpni object do not have a valid ap\n");
		err = dpni_clean_flow_control_config((struct dpni *)object);
		CHECK_COND_RETVAL(err==0, err, "dpni_clean_flow_control_config() return error\n");
		break;
	case FSL_MOD_DPSW:
		err = dpsw_clean_flow_control_config((struct dpsw *)object, endpoint2.if_id);
		CHECK_COND_RETVAL(err==0, err, "dpni_clean_flow_control_config() return error\n");
		break;
	case FSL_MOD_DPDMUX:
		err = dpdmux_clean_flow_control_config((struct dpdmux *)object, endpoint2.if_id);
		CHECK_COND_RETVAL(err==0, err, "dpdmux_clean_flow_control_config() return error\n");
		break;
	case FSL_MOD_DPMAC:
		/* nothing here */
		break;
	default:
		CHECK_COND_RETVAL( 0 , -EPERM, "Operation permitted only peer connecion type: %d\n", endpoint2.type);
	}

	fc_release_channel_idx(dpni->fc_idx);
	dpni->fc_idx = FLOW_CONTROL_INVALID_INDEX;

	return 0;
}

int dpni_reset(struct dpni *dpni)
{
	int err = 0;

	pr_info("start dpni[%d] reset...\n", dpni->id);
	if (dpni->enabled)
		err |= dpni_disable(dpni);

	err |= dpni_reset_flow_control(dpni);
	CHECK_COND_RETVAL(err==0, err, "dpni_reset_flow_control() return error\n");
	
	/* In context of restore, the subportal is disabled */
	/* Do not empty frames from QMAN in this case */
	if(!dpni->restore.en)
		dpni_empty_all_frames(dpni);

	clear_all_tables(dpni);

	clear_all_policers_n_cgs(dpni);

	err |= clear_tx_side(dpni);

	err |= clear_rx_side(dpni);

	clear_dpbps(dpni);

	set_defaults(dpni, 1 /* reset-stage */);
	
	/* To populate it to DPDMUX */
	if (dpni->dpdmux) {
		update_dpdmux_unicast_promisc(dpni);
		update_dpdmux_multicast_promisc(dpni);
	}
	
	err |= config_ctlu(dpni, 1 /* reset-stage */);

	err |= config_tx_selection(dpni);

	if (dpni->is_snic)
		snic_reset(dpni);

	if (!dpni->ap_valid)
	{
		err |= set_tx_rejection_mode(dpni, 1);
	}

	err |= config_qbman(dpni);

	update_mac_single_step_config(dpni, &dpni->single_step_cfg);

	if( dpni->dpdmux ) {
		dpdmux_if_update_max_frame_len(dpni->dpdmux, 0, dpni->mfl);
		dpdmux_if_update_max_frame_len(dpni->dpdmux, dpni->dpdmux_if_id, dpni->mfl);
	}

	dpni->en_header_stashing = 0;
	dpni->en_payload_stashing = 0;

#ifdef DPNI_DUMP_STRUCTURE
	mem_disp((uint8_t*)dpni, sizeof(struct dpni));
#endif /* DPNI_DUMP_STRUCTURE */
	return err;
}

int dpni_enable(struct dpni *dpni)
{
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_control control;
	int err;

	if (dpni->enabled)
		return 0;

	if (!dpni->pools_cfg.num_dpbp) {
		pr_err("ID[%d]: Must set pools prior enabling\n", dpni->id);
		return -EACCES;
	}

#if 0
	err = eiop_ifp_init(&dpni->mem_ifp_info->ifp_desc,
		&dpni->mem_ifp_info->init);
	ASSERT_COND(err == 0);
#endif
	
	config_eiop_ifps_pools(dpni);
	
	/* configure the egress interface profile if it is enabled through connection*/
	if (dpni->ap_valid) {
		config_eiop_ifp_egress(dpni);

		if(!eiop_ifp_tx_is_enable(&dpni->snic.ingress_ifp_info->ifp_desc))
			eiop_ifp_tx_enable(&dpni->snic.ingress_ifp_info->ifp_desc);
	}

	if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
		err = config_aiop_spids(dpni);
		ASSERT_COND(err == 0);
	}

	dpni->enabled = 1;

	if ((err = configuration(dpni)) != 0) {
		dpni->enabled = 0;
		return err;
	}

	memset(&endpoint1, 0x0, sizeof(struct linkman_endpoint));
	memset(&endpoint2, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));
	endpoint1.type = FSL_MOD_DPNI;
	endpoint1.id = (uint16_t)dpni->id;
	control.event = LINKMAN_EVENT_LINKUP;
	if(!dpni->restore.en)
		control.cmd = LINKMAN_CMD_ENABLE;
	else
		control.cmd = LINKMAN_CMD_SILENTLY;
	if (linkman_set_connection(dpni->linkman, &control, &endpoint1,
					&endpoint2)
		!= 0)
		pr_info("ID[%d]: currently link cannot be UP\n", dpni->id);


	return err;
}

int dpni_disable(struct dpni *dpni)
{
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr attr;
	struct linkman_control control;
	int err;

	if (!dpni->enabled)
		return 0;

	memset(&endpoint1, 0x0, sizeof(struct linkman_endpoint));
	memset(&endpoint2, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));
	memset(&attr, 0x0, sizeof(struct linkman_connection_attr));
	endpoint1.type = FSL_MOD_DPNI;
	endpoint1.id = (uint16_t)dpni->id;

	err = linkman_get_connection(dpni->linkman, &endpoint1, &endpoint2,
					&attr);
	if (!err && (attr.state == LINKMAN_STATE_LINKUP)) {
		dpni->self_link_down_finished = 0;

		control.event = LINKMAN_EVENT_LINKDOWN;
		if(!dpni->restore.en)
			control.cmd = LINKMAN_CMD_DISABLE;
		else
			control.cmd = LINKMAN_CMD_SILENTLY;
		err = linkman_set_connection(dpni->linkman, &control,
						&endpoint1, &endpoint2);

		/* In context of restore, the subportal is disabled */
		/* Do not empty frames from QMAN in this case */
		if(!dpni->restore.en)
			dpni_empty_all_frames(dpni);

		if ((err = eiop_ifp_tx_graceful_stop(
						&dpni->snic.ingress_ifp_info->ifp_desc))
						!= 0) {
					pr_err("ID[%d]: IFP egress disable failed\n", dpni->id);
					return err;
		}
		
		dpni->enabled = (dpni->self_link_down_finished ? 0 : 1);
		if (dpni->enabled) {
			pr_err("ID[%d]: dpni_disable failed\n", dpni->id);
			return err;
		}
	} else if (!err && attr.state == LINKMAN_STATE_NEGOTIATION) {
		control.event = LINKMAN_EVENT_NEGOTIATION_FAIL;
		if(!dpni->restore.en)
			control.cmd = LINKMAN_CMD_DISABLE;
		else
			control.cmd = LINKMAN_CMD_SILENTLY;
		err = linkman_set_connection(dpni->linkman, &control,
						&endpoint1, &endpoint2);
		dpni->enabled = 0;
		return err;
	} else
		dpni->enabled = 0;

	return 0;
}

int dpni_is_enabled(struct dpni *dpni, int *en)
{
	*en = dpni->enabled;

	return 0;
}

int dpni_set_pools(struct dpni *dpni, struct dpni_pools_cfg *cfg)
{
	int i;
	uint8_t bp_mask;
	struct eiop_desc desc = {0};

	if (dpni->enabled) {
		pr_err("ID[%d]: DPNI must be disabled\n", dpni->id);
		return -EACCES;
	}

	if (!cfg->num_dpbp) {
		pr_err("ID[%d]: must have at least one pool\n", dpni->id);
		return -EINVAL;
	}

	if (cfg->num_dpbp > DPNI_MAX_DPBP) {
		pr_err( "ID[%d]: num of pools must be smaller than %d\n", dpni->id, (DPNI_MAX_DPBP+1));
		return -EINVAL;
	}
	
	soc_db_get_desc(SOC_MODULE_EIOP, SOC_DB_NO_MATCH_FIELDS, &desc, NULL);
	
	if ((cfg->pool_options) && (desc.wriop_version < WRIOP_VERSION(3, 0, 0)))
	{
		pr_err("ID[%d]: Could not configure buffer pool per queue on this platform\n");
		return -ENOSYS;
	}
	
	bp_mask = 0x00;
	for( i=0 ; i<cfg->num_dpbp ; i++ ) {
		cfg->pools[i].priority = (cfg->pools[i].priority==0)?0xff:cfg->pools[i].priority;
		bp_mask = bp_mask | cfg->pools[i].priority;
	}
	if( bp_mask!=0xff ) {
		pr_warn("ID[%d] Some traffic classes do not have associated a buffer pool. Associated TC mask %02x\n", 
				dpni->id, bp_mask);
	}

	clear_dpbps(dpni);

	for (i = 0; i < cfg->num_dpbp; i++) {
		struct dpbp *dpbp;

		dpbp = sys_get_handle(FSL_MOD_DPBP, 1, cfg->pools[i].dpbp_id);
		if (!dpbp) {
			pr_err( "ID[%d]: dpbp_id %d not found\n", dpni->id, cfg->pools[i].dpbp_id);
			return -EINVAL;
		}

		if (!cfg->pools[i].buffer_size) {
			pr_err( "ID[%d]: pool[%d]: buffer-size can't be '0'\n", dpni->id, i, cfg->pools[i].buffer_size);
			return -EINVAL;
		}

		if ((cfg->pools[i].buffer_size % 64) != 0) {
			pr_err( "ID[%d]: pool[%d]: buffer-size is not multiple of 64\n", dpni->id, i);
			return -EINVAL;
		}

		if (cfg->pools[i].buffer_size > 65472) {
			pr_err( "ID[%d]: pool[%d]: buffer-size must be up to 65472\n", dpni->id, i);
			return -EINVAL;
		}
#ifdef ERR009354
		if ((cfg->pools[i].buffer_size % 256) != 0) {
			pr_err( "ID[%d]: pool[%d]: ERR009354 requires that buffer-size is a multiple of 256\n", dpni->id, i);
			return -EINVAL;
		}
#endif /* ERR009354 */
		if (cfg->pools[i].backup_pool) {
			dpni->backup_pools_cfg.pools[dpni->backup_pools_cfg.num_dpbp].dpbp = dpbp;
			dpni->backup_pools_cfg.pools[dpni->backup_pools_cfg.num_dpbp].buffer_size = cfg->pools[i].buffer_size;
			dpni->pools_cfg.pools[dpni->pools_cfg.num_dpbp].priority = cfg->pools[i].priority;
			dpni->backup_pools_cfg.num_dpbp++;
		} else {
			dpni->pools_cfg.pools[dpni->pools_cfg.num_dpbp].dpbp = dpbp;
			dpni->pools_cfg.pools[dpni->pools_cfg.num_dpbp].buffer_size = cfg->pools[i].buffer_size;
			dpni->pools_cfg.pools[dpni->pools_cfg.num_dpbp].priority = cfg->pools[i].priority;
			dpni->pools_cfg.num_dpbp++;
		}
		/* Register the DPNI with the DPBP */
		dpbp_register_dpni(dpbp, 1);
	}

	if (!dpni->pools_cfg.num_dpbp) {
		pr_err("ID[%d]: must have at least one regular pool\n", dpni->id);
		return -EINVAL;
	}
	
	dpni->pools_cfg.pool_as = cfg->pool_options;
	dpni->backup_pools_cfg.pool_as = cfg->pool_options;

	if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
		if (dpni->pools_cfg.num_dpbp > 2) {
			pr_err( "ID[%d]: num of pools must be smaller than %d\n", dpni->id, 3);
			return -EINVAL;
		}
		if (dpni->backup_pools_cfg.num_dpbp > 2) {
			pr_err( "ID[%d]: num of backup-pools must be smaller than %d\n", dpni->id, 3);
			return -EINVAL;
		}
	}

	return 0;
}

int dpni_set_l3_chksum_validation(struct dpni *dpni, int en)
{
	if (!en) {
		if (dpni->snic.ipr) {
			pr_err("ID[%d]: cannot disable L3 checksum validation when IPR "
			"is enabled\n", dpni->id);
			return -EINVAL;
		}
		if (dpni->snic.ipsec) {
			pr_err("ID[%d]: cannot disable L3 checksum validation when IPSEC "
			"is enabled\n", dpni->id);
			return -EINVAL;
		}
	}

	eiop_ifp_set_l3csv(&dpni->snic.ingress_ifp_info->ifp_desc, en);
	eiop_ifp_set_l3csv(&dpni->mem_ifp_info->ifp_desc, en);

	dpni->l3_chksum_valid = !!en;

	return 0;
}

int dpni_get_l3_chksum_validation(struct dpni *dpni, int *en)
{
	*en = dpni->l3_chksum_valid;

	return 0;
}

int dpni_set_l4_chksum_validation(struct dpni *dpni, int en)
{
	if (!en) {
		if (dpni->snic.ipr) {
			pr_err("ID[%d]: cannot disable L4 checksum validation when IPR "
			"is enabled\n", dpni->id);
			return -EINVAL;
		}
		if (dpni->snic.ipsec) {
			pr_err("ID[%d]: cannot disable L4 checksum validation when IPSEC "
			"is enabled\n", dpni->id);
			return -EINVAL;
		}
	}

	eiop_ifp_set_l4csv(&dpni->snic.ingress_ifp_info->ifp_desc, en);
	eiop_ifp_set_l4csv(&dpni->mem_ifp_info->ifp_desc, en);

	dpni->l4_chksum_valid = !!en;

	return 0;
}

int dpni_get_l4_chksum_validation(struct dpni *dpni, int *en)
{
	*en = dpni->l4_chksum_valid;

	return 0;
}

int dpni_set_offload(struct dpni *dpni, enum dpni_offload type,
		uint32_t config)
{
	struct dpni_attr attr = { 0 };
	int err;
	uint16_t i;

	switch (type) {
	case DPNI_OFF_RX_L3_CSUM:
		return dpni_set_l3_chksum_validation(dpni, !!config);
	case DPNI_OFF_RX_L4_CSUM:
		return dpni_set_l4_chksum_validation(dpni, !!config);
	case DPNI_OFF_TX_L3_CSUM:
		dpni->l3_chksum_gen = !!config;
		for (i=0; i<dpni->max_senders; i++) {
			err = config_sender_info(dpni, 0, i,
					&dpni->tx_ch[0].sender_info[i]);
			CHECK_COND_RETVAL(err == 0, err);
		}
		break;
	case DPNI_OFF_TX_L4_CSUM:
		dpni->l4_chksum_gen = !!config;
		for (i=0; i<dpni->max_senders; i++) {
			err = config_sender_info(dpni, 0, i,
					&dpni->tx_ch[0].sender_info[i]);
			CHECK_COND_RETVAL(err == 0, err);
		}
		break;
	case DPNI_FLCTYPE_HASH:
		if (!dpni->enabled)
			if (config)
				dpni->options |= DPNI_OPT_FLCTYPE_HASH;
			else
				dpni->options &= ~DPNI_OPT_FLCTYPE_HASH;
		else
			pr_warn("ID[%d]: DPNI has to be disabled in order to change the FLC style\n", dpni->id);
		break;
	case DPNI_HEADER_STASHING:
		CHECK_COND_RETVAL(dpni->enabled == 0,
						  -EINVAL,
						  "ID[%d]: DPNI_HEADER_STASHING can be changed only when"
						  " the dpni is disabled\n", dpni->id);
		dpni->en_header_stashing = (int) config;
		break;
	case DPNI_PAYLOAD_STASHING:
		CHECK_COND_RETVAL(dpni->enabled == 0,
						  -EINVAL,
						  "ID[%d]: DPNI_PAYLOAD_STASHING can be changed only when"
						  " the dpni is disabled\n", dpni->id);

		err = dpni_get_attributes(dpni, &attr);
		CHECK_COND_RETVAL(!err, err, "dpni_get_attributes() returned error %d\n", err);
		CHECK_COND_RETVAL(!(attr.wriop_version <= WRIOP_VERSION(1,0,0)),
						  -EINVAL,
						  "DPNI_PAYLOAD_STASHING not supported on WRIOP Rev1.0\n");

		dpni->en_payload_stashing = (int) config;
		break;
	default:
		pr_err("ID[%d]: offload type not supported, expected <= %d\n",
				dpni->id, DPNI_PAYLOAD_STASHING);
		return -ENOTSUP;
	}

	return 0;
}

int dpni_get_offload(struct dpni *dpni, enum dpni_offload type,
		uint32_t *config)
{
	struct dpni_attr attr = { 0 };
	int err;

	switch (type) {
	case DPNI_OFF_RX_L3_CSUM:
		*config = !!dpni->l3_chksum_valid;
		break;
	case DPNI_OFF_RX_L4_CSUM:
		*config = !!dpni->l4_chksum_valid;
		break;
	case DPNI_OFF_TX_L3_CSUM:
		*config = !!dpni->l3_chksum_gen;
		break;
	case DPNI_OFF_TX_L4_CSUM:
		*config = !!dpni->l4_chksum_gen;
		break;
	case DPNI_HEADER_STASHING:
		*config = (uint32_t) dpni->en_header_stashing;
		break;
	case DPNI_PAYLOAD_STASHING:
		err = dpni_get_attributes(dpni, &attr);
		CHECK_COND_RETVAL(!err, err, "dpni_get_attributes() returned error %d\n", err);
		CHECK_COND_RETVAL(!(attr.wriop_version <= WRIOP_VERSION(1,0,0)),
						  -EINVAL,
						  "DPNI_PAYLOAD_STASHING not supported on WRIOP Rev1.0\n");

		*config = (uint32_t) dpni->en_payload_stashing;
		break;
	default:
		pr_err("ID[%d]: offload type not supported, expected <= %d\n",
				dpni->id, DPNI_PAYLOAD_STASHING);
		return -ENOTSUP;
	}

	return 0;
}


int dpni_get_qdid(struct dpni *dpni, enum dpni_queue_type qtype,
		uint16_t *qdid)
{
#ifdef MC_CLI
    switch(qtype) {
        case DPNI_REAL_QUEUE_RX:
            *qdid = (uint16_t)dpni->rx_qdid;
            break;
        case DPNI_REAL_QUEUE_TX:
            *qdid = (uint16_t)dpni->tx_qdid[0];
            break;
        default:
            *qdid = (uint16_t)dpni->tx_virt_qdid[0];
            break;
    }
#else

	/* qtype is ignored for now, all queues use the same QDID */
	*qdid = (uint16_t)dpni->tx_ch[0].tx_virt_qdid;
#endif

	return 0;
}

int dpni_get_qdid_ex(struct dpni *dpni, enum dpni_queue_type qtype,
		uint16_t *qdid)
{
	int i;

#ifdef MC_CLI
	switch(qtype) {
	case DPNI_REAL_QUEUE_RX:
		qdid[0] = (uint16_t)dpni->rx_qdid;
		break;
	case DPNI_REAL_QUEUE_TX:
		for( i = 0 ; i < dpni->num_ceetm_ch ; i++ ) {
			qdid[i] = (uint16_t)dpni->tx_qdid[i];
		}
		break;
	default:
		qdid[0] = (uint16_t)dpni->tx_virt_qdid[0];
		break;
	}
#else

	for( i = 0 ; i < dpni->num_ceetm_ch ; i++ ) {
		/* qtype is ignored for now, all queues use the same QDID */
		qdid[i] = (uint16_t)dpni->tx_ch[i].tx_virt_qdid;
	}
#endif

	return 0;
}

int dpni_get_sp_info(struct dpni *dpni, struct dpni_sp_info *sp_info)
{
	sp_info->spids[0] = (uint16_t)dpni->spid;
	sp_info->spids[1] = (uint16_t)dpni->backup_spid;

	return 0;
}

int dpni_get_tx_data_offset(struct dpni *dpni, uint16_t *data_offset)
{
	uint32_t tx_data_off, tx_conf_data_off;

	eiop_ifp_get_data_offset(
		&dpni->snic.egress_ifp_info->init.defcfg.tx_buf_layout,
		&tx_data_off, 0);
	eiop_ifp_get_data_offset(
		&dpni->snic.egress_ifp_info->init.defcfg.txconf_buf_layout,
		&tx_conf_data_off, 0);
	*data_offset = (uint16_t)MAX(tx_data_off, tx_conf_data_off);

	return 0;
}

int dpni_get_attributes(struct dpni *dpni, struct dpni_attr *attr)
{
	int i, err = 0;
	struct eiop_desc desc = {0};
	enum net_prot hdr;
	uint16_t max_queues;

	soc_db_get_desc(SOC_MODULE_EIOP, SOC_DB_NO_MATCH_FIELDS, &desc, NULL);

	attr->id = dpni->id;
	err = dpparser_get_hdr_prot(dpni->ing_start_hxs, &hdr);
	CHECK_COND_RETVAL(err == 0, err);
	attr->start_hdr = hdr;
	attr->options = dpni->options;
	attr->max_rx_tcs = dpni->max_rx_tcs;
	attr->max_tx_tcs = dpni->max_tx_tcs;
	if (!IS_SHARED_FS_ENABLED) {
		for (i = 0; i < dpni->max_rx_tcs; i++) {
			attr->ext_cfg.tc_cfg[i].max_dist =
				dpni->tc_rx[i].max_dist_size;
			attr->ext_cfg.tc_cfg[i].max_fs_entries =
				dpni->tc_rx[i].max_fs_entries;
		}
	} else {
		attr->ext_cfg.tc_cfg[0].max_dist =
					dpni->tc_rx[0].max_dist_size;
		attr->ext_cfg.tc_cfg[0].max_fs_entries =
					dpni->tc_rx[0].max_fs_entries;
		for (i = 1; i < dpni->max_rx_tcs; i++) {
			attr->ext_cfg.tc_cfg[i].max_dist =
					dpni->tc_rx[0].max_dist_size;;
			attr->ext_cfg.tc_cfg[i].max_fs_entries =
					dpni->tc_rx[0].max_fs_entries;;
		}
	}

	if( dpni->single_sender ) {
		// single sender: max_senders is always 1; function will provide number of queues for Rx.
		max_queues = dpni->tc_rx[0].max_dist_size;
		if (!IS_SHARED_FS_ENABLED) {
			for ( i = 1 ; i < dpni->max_rx_tcs ; i++)
				if( max_queues<dpni->tc_rx[i].max_dist_size )
					max_queues = dpni->tc_rx[i].max_dist_size;
		}
		if( max_queues>256 )
			pr_warn("Number of Rx queues (%d) exceed field size\n", max_queues);
		attr->max_senders = (uint8_t)max_queues;
	}
	else {
		attr->max_senders = dpni->max_senders;
	}

	if (dpni->options & DPNI_OPT_SHARED_MAC_TABLE) {
		attr->max_unicast_filters = dpni->filters.max_mac_filters;
		attr->max_multicast_filters = 0;
	} else {
		attr->max_unicast_filters = dpni->filters.max_unicast_filters;
		attr->max_multicast_filters = dpni->filters.max_multicast_filters;
	}
	attr->max_vlan_filters = dpni->filters.max_vlan_filters;
	attr->max_qos_entries = dpni->qos.max_qos_entries;
	attr->max_qos_key_size = (uint8_t)dpni->qos.max_qos_key_size;
	attr->actual_qos_key_size = (uint8_t)dpni->qos.actual_qos_key_size;
	attr->max_dist_key_size = (uint8_t)dpni->tc_rx[0].max_dist_key_size;
	attr->max_policers = dpni->max_policers;
	attr->max_congestion_ctrl = dpni->max_congestion_ctrl;
	memcpy(&attr->ext_cfg.ipr_cfg, &dpni->snic.ipr_cfg,
		sizeof(struct dpni_ipr_cfg));

	attr->wriop_version = desc.wriop_version;

	attr->shared_congestion = dpni->shared_congestion;
	attr->num_cgid = dpni->max_congestion_ctrl;

	attr->num_ceetm_ch = (uint8_t)dpni->num_ceetm_ch;
	attr->max_opr = dpni->max_opr;

	return 0;
}

int dpni_get_counter(struct dpni *dpni,
	enum dpni_counter counter,
	uint64_t *value)
{
	switch (counter) {
	case DPNI_CNT_ING_FRAME:
		*value = eiop_ifp_get_counter(
			&dpni->snic.ingress_ifp_info->ifp_desc, E_INGRESS_FC);
		break;
	case DPNI_CNT_ING_BYTE:
		*value = eiop_ifp_get_counter(
			&dpni->snic.ingress_ifp_info->ifp_desc, E_INGRESS_BC);
		break;
	case DPNI_CNT_ING_FRAME_DROP:
		*value = eiop_ifp_get_counter(
			&dpni->snic.ingress_ifp_info->ifp_desc, E_INGRESS_FFC);
		break;
	case DPNI_CNT_ING_FRAME_DISCARD:
		*value = eiop_ifp_get_counter(
			&dpni->snic.ingress_ifp_info->ifp_desc, E_INGRESS_FDC);
		break;
	case DPNI_CNT_ING_MCAST_FRAME:
		*value = eiop_ifp_get_counter(
			&dpni->snic.ingress_ifp_info->ifp_desc, E_INGRESS_MFC);
		break;
	case DPNI_CNT_ING_MCAST_BYTE:
		*value = eiop_ifp_get_counter(
			&dpni->snic.ingress_ifp_info->ifp_desc, E_INGRESS_MBC);
		break;
	case DPNI_CNT_ING_BCAST_FRAME:
		*value = eiop_ifp_get_counter(
			&dpni->snic.ingress_ifp_info->ifp_desc, E_INGRESS_BFC);
		break;
	case DPNI_CNT_ING_BCAST_BYTES:
		*value = eiop_ifp_get_counter(
			&dpni->snic.ingress_ifp_info->ifp_desc, E_INGRESS_BBC);
		break;
	case DPNI_CNT_EGR_FRAME:
		*value = eiop_ifp_get_counter(
			&dpni->snic.egress_ifp_info->ifp_desc, E_EGRESS_FC);
		break;
	case DPNI_CNT_EGR_BYTE:
		*value = eiop_ifp_get_counter(
			&dpni->snic.egress_ifp_info->ifp_desc, E_EGRESS_BC);
		break;
	case DPNI_CNT_EGR_FRAME_DISCARD:
		*value = eiop_ifp_get_counter(
			&dpni->snic.egress_ifp_info->ifp_desc, E_EGRESS_FDC);
		break;
	case DPNI_CNT_ING_NO_BUFFER_DISCARD:
		*value = eiop_ifp_get_counter(
			&dpni->snic.ingress_ifp_info->ifp_desc, E_INGRESS_OODC);
		break;
	case DPNI_CNT_EGR_FRAME_CONFIRMED:
		*value = eiop_ifp_get_counter(
			&dpni->snic.egress_ifp_info->ifp_desc, E_EGRESS_CFC);
		break;
	case DPNI_CNT_EGR_MCAST_FRAME:
		*value = eiop_ifp_get_counter(
			&dpni->snic.egress_ifp_info->ifp_desc, E_EGRESS_MFC);
		break;
	case DPNI_CNT_EGR_MCAST_BYTE:
		*value = eiop_ifp_get_counter(
			&dpni->snic.egress_ifp_info->ifp_desc, E_EGRESS_MBC);
		break;
	case DPNI_CNT_EGR_BCAST_FRAME:
		*value = eiop_ifp_get_counter(
			&dpni->snic.egress_ifp_info->ifp_desc, E_EGRESS_BFC);
		break;
	case DPNI_CNT_EGR_BCAST_BYTES:
		*value = eiop_ifp_get_counter(
			&dpni->snic.egress_ifp_info->ifp_desc, E_EGRESS_BBC);
		break;
	default:
		pr_err("ID[%d]: counter not supported\n", dpni->id);
		return -ENOTSUP;
	}

	return 0;
}

int dpni_set_counter(struct dpni *dpni,
	enum dpni_counter counter,
	uint64_t value)
{
	switch (counter) {
	case DPNI_CNT_ING_FRAME:
		eiop_ifp_set_counter(&dpni->snic.ingress_ifp_info->ifp_desc,
					E_INGRESS_FC, value);
		break;
	case DPNI_CNT_ING_BYTE:
		eiop_ifp_set_counter(&dpni->snic.ingress_ifp_info->ifp_desc,
					E_INGRESS_BC, value);
		break;
	case DPNI_CNT_ING_FRAME_DROP:
		eiop_ifp_set_counter(&dpni->snic.ingress_ifp_info->ifp_desc,
					E_INGRESS_FFC, value);
		break;
	case DPNI_CNT_ING_FRAME_DISCARD:
		eiop_ifp_set_counter(&dpni->snic.ingress_ifp_info->ifp_desc,
					E_INGRESS_FDC, value);
		break;
	case DPNI_CNT_ING_MCAST_FRAME:
		eiop_ifp_set_counter(&dpni->snic.ingress_ifp_info->ifp_desc,
					E_INGRESS_MFC, value);
		break;
	case DPNI_CNT_ING_MCAST_BYTE:
		eiop_ifp_set_counter(&dpni->snic.ingress_ifp_info->ifp_desc,
					E_INGRESS_MBC, value);
		break;
	case DPNI_CNT_ING_BCAST_FRAME:
		eiop_ifp_set_counter(&dpni->snic.ingress_ifp_info->ifp_desc,
					E_INGRESS_BFC, value);
		break;
	case DPNI_CNT_ING_BCAST_BYTES:
		eiop_ifp_set_counter(&dpni->snic.ingress_ifp_info->ifp_desc,
					E_INGRESS_BBC, value);
		break;
	case DPNI_CNT_EGR_FRAME:
		eiop_ifp_set_counter(&dpni->snic.egress_ifp_info->ifp_desc,
					E_EGRESS_FC, value);
		break;
	case DPNI_CNT_EGR_BYTE:
		eiop_ifp_set_counter(&dpni->snic.egress_ifp_info->ifp_desc,
					E_EGRESS_BC, value);
		break;
	case DPNI_CNT_EGR_FRAME_DISCARD:
		eiop_ifp_set_counter(&dpni->snic.egress_ifp_info->ifp_desc,
					E_EGRESS_FDC, value);
		break;
	case DPNI_CNT_ING_NO_BUFFER_DISCARD:
		eiop_ifp_set_counter(&dpni->snic.ingress_ifp_info->ifp_desc,
					E_INGRESS_OODC, value);
		break;
	case DPNI_CNT_EGR_FRAME_CONFIRMED:
		eiop_ifp_set_counter(&dpni->snic.egress_ifp_info->ifp_desc,
					E_EGRESS_CFC, value);
		break;
	case DPNI_CNT_EGR_MCAST_FRAME:
		eiop_ifp_set_counter(&dpni->snic.egress_ifp_info->ifp_desc,
					E_EGRESS_MFC, value);
		break;
	case DPNI_CNT_EGR_MCAST_BYTE:
		eiop_ifp_set_counter(&dpni->snic.egress_ifp_info->ifp_desc,
					E_EGRESS_MBC, value);
		break;
	case DPNI_CNT_EGR_BCAST_FRAME:
		eiop_ifp_set_counter(&dpni->snic.egress_ifp_info->ifp_desc,
					E_EGRESS_BFC, value);
		break;
	case DPNI_CNT_EGR_BCAST_BYTES:
		eiop_ifp_set_counter(&dpni->snic.egress_ifp_info->ifp_desc,
					E_EGRESS_BBC, value);
		break;
	default:
		pr_err("ID[%d]: counter not supported\n", dpni->id);
		return -ENOTSUP;
	}

	return 0;
}

static uint64_t dpni_get_tx_pending_cnt(struct dpni *dpni)
{
	int tc_id;
	uint64_t pending_frames;
	struct qbman_attr cq_attr;
	struct qbman_swp *sw_portal;
	int ceetm_ch_idx;
	int err;

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	pending_frames = 0;

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ )
		for (tc_id = 0; tc_id < dpni->max_tx_tcs; tc_id++) {
			memset(&cq_attr, 0, sizeof(cq_attr));
			err = qbman_cq_query(sw_portal, dpni->ceetmid,
					(uint16_t)dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cqid,
					NULL, NULL,
					&cq_attr, NULL);
			if( err ) {
				pr_warn("Fail to get Tx pending frames count for dpni.%d TC%d\n", dpni->id, tc_id);
				continue;
			}
			pending_frames += qbman_cq_num_of_frames(&cq_attr);
		}

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return pending_frames;
}

int dpni_get_statistics(struct dpni *dpni, uint8_t page,
		union dpni_statistics *stats, uint16_t param)
{
	struct eiop_ifp_desc *ifp_desc = &dpni->snic.egress_ifp_info->ifp_desc;
	struct qbman_swp *sw_portal;
	int err = 0;
	uint32_t ceetmid;
	int cgid_index = DPNI_INVALID_ID;
	struct dppolicer_counters policer_counters;
	int tc_id, queue_id;
	int ceetm_ch_idx = 0;

	switch (page) {
	case 0:
		stats->page_0.ingress_all_frames =
				eiop_ifp_get_counter(ifp_desc, E_INGRESS_FC);
		stats->page_0.ingress_all_bytes =
				eiop_ifp_get_counter(ifp_desc, E_INGRESS_BC);
		stats->page_0.ingress_multicast_frames =
				eiop_ifp_get_counter(ifp_desc, E_INGRESS_MFC);
		stats->page_0.ingress_multicast_bytes =
				eiop_ifp_get_counter(ifp_desc, E_INGRESS_MBC);
		stats->page_0.ingress_broadcast_frames =
				eiop_ifp_get_counter(ifp_desc, E_INGRESS_BFC);
		stats->page_0.ingress_broadcast_bytes =
				eiop_ifp_get_counter(ifp_desc, E_INGRESS_BBC);
		break;
	case 1:
		stats->page_1.egress_all_frames =
				eiop_ifp_get_counter(ifp_desc, E_EGRESS_FC);
		stats->page_1.egress_all_bytes =
				eiop_ifp_get_counter(ifp_desc, E_EGRESS_BC);
		stats->page_1.egress_multicast_frames =
				eiop_ifp_get_counter(ifp_desc, E_EGRESS_MFC);
		stats->page_1.egress_multicast_bytes =
				eiop_ifp_get_counter(ifp_desc, E_EGRESS_MBC);
		stats->page_1.egress_broadcast_frames =
				eiop_ifp_get_counter(ifp_desc, E_EGRESS_BFC);
		stats->page_1.egress_broadcast_bytes =
				eiop_ifp_get_counter(ifp_desc, E_EGRESS_BBC);
		break;
	case 2:
		stats->page_2.ingress_filtered_frames =
				eiop_ifp_get_counter(ifp_desc, E_INGRESS_FFC);
		stats->page_2.ingress_discarded_frames =
				eiop_ifp_get_counter(ifp_desc, E_INGRESS_FDC);
		stats->page_2.ingress_nobuffer_discards =
				eiop_ifp_get_counter(ifp_desc, E_INGRESS_OODC);
		stats->page_2.egress_discarded_frames =
				eiop_ifp_get_counter(ifp_desc, E_EGRESS_FDC);
		stats->page_2.egress_confirmed_frames =
				eiop_ifp_get_counter(ifp_desc, E_EGRESS_CFC);
		break;
	case 3:
		tc_id = (int)(param & 0xff);
		ceetm_ch_idx = (int)((param >> 8) & 0xff);

		CHECK_COND_RETVAL( tc_id < dpni->max_tx_tcs, -EINVAL,
				"ID[%d]: (param & 0xff) value (%d) must be smaller than %d (max Tx TCs)\n", dpni->id, tc_id, dpni->max_tx_tcs);

		CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL,
				"ID[%d]: ((param >> 8) & 0xff) value (%d) must be smaller than %d (max Tx TCs)\n", dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

		ceetmid = qbman_ceetmid_compose( (uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, (uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id);

		err = qbman_ceetm_statistics_query(sw_portal, ceetmid,
			(uint16_t)(((uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid << 4) | dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cqid),
			query_dq_statistics,
			&stats->page_3.ceetm_dequeue_frames, &stats->page_3.ceetm_dequeue_bytes);

		if (err != 0) {
			pr_err("ID[%d] Failed dequeueu statistics query for channel %d tc %d\n",
					dpni->id, ceetm_ch_idx, tc_id);
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			return err;
		}
		
		err = qbman_ceetm_statistics_query(sw_portal, ceetmid,
			(uint16_t)(((uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid << 4) | dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].ccgid),
			query_reject_statistics,
			&stats->page_3.ceetm_reject_frames, &stats->page_3.ceetm_reject_bytes);
		
		if (err != 0) {
			pr_err("ID[%d] Failed reject statistics query for channel %d tc %d\n",
					dpni->id, ceetm_ch_idx, tc_id);
			dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
			return err;
		}

		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		break;
	case 4:
		if (dpni->options & DPNI_OPT_CUSTOM_CG)
		{
			tc_id = (int)(param & 0xff);
			queue_id = (int)((param >> 8) & 0xff);

			CHECK_COND_RETVAL(tc_id < dpni->max_rx_tcs, -EINVAL,
					"ID[%d]: param (%d) must be smaller than %d (max Rx TCs)\n", dpni->id, tc_id, dpni->max_rx_tcs);

			CHECK_COND_RETVAL(queue_id < dpni->max_senders, -EINVAL,
					"ID[%d]: param (%d) must be smaller than %d (max senders)\n", dpni->id, queue_id, dpni->max_senders);

			cgid_index = dpni->tc_rx[tc_id].rx_queues[queue_id].cgid_index;

			CHECK_COND_RETVAL(cgid_index != DPNI_INVALID_ID, -EINVAL, "No congestion point enabled for TC%d Queue %d\n", tc_id, queue_id);
		}
		else
		{
			CHECK_COND_RETVAL(param < dpni->max_rx_tcs, -EINVAL,
					"ID[%d]: param (%d) must be smaller than %d (max Rx TCs)\n", dpni->id, param, dpni->max_rx_tcs);
			tc_id = (int)(param & 0xff);
			cgid_index = dpni->tc_rx[tc_id].cgid_index;

			CHECK_COND_RETVAL(cgid_index != DPNI_INVALID_ID, -EINVAL, "No congestion point enabled for TC%d\n", tc_id);
		}

		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

		err = qbman_cgr_statistics_query(sw_portal, (uint32_t)dpni->rx_tx_conf_cgids[cgid_index].cgid, 0,
				&stats->page_4.cgr_reject_frames,
				&stats->page_4.cgr_reject_bytes);

		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		break;
	case 5:
		CHECK_COND_RETVAL(param < dpni->max_rx_tcs, -EINVAL,
				"ID[%d]: param (%d) must be smaller than %d (max Rx TCs)\n", dpni->id, param, dpni->max_rx_tcs);
		CHECK_COND_RETVAL(dpni->tc_rx[param].policer_enable!=0, -EINVAL,
				"ID[%d]: Policer not enabled for TC%d\n", dpni->id, param);
		err = dppolicer_get_profile_counters(dpni->ing_dppolicer,
				dpni->tc_rx[param].plcrid,
				NULL,
				&policer_counters);

		stats->page_5.policer_cnt_red = policer_counters.cnt_red;
		stats->page_5.policer_cnt_yellow = policer_counters.cnt_yellow;
		stats->page_5.policer_cnt_green = policer_counters.cnt_green;
		stats->page_5.policer_cnt_re_red = policer_counters.cnt_re_red;
		stats->page_5.policer_cnt_re_yellow = policer_counters.cnt_re_yellow;
		break;
	case 6:
		stats->page_6.tx_pending_frames_cnt = dpni_get_tx_pending_cnt(dpni);
		break;
	default:
		pr_err("ID[%d] dpni_get_statistics(): page %d not implemented\n", dpni->id, page);
		err = -EINVAL;
		break;
	}

	return err;
}

int dpni_reset_statistics(struct dpni *dpni)
{
	struct eiop_ifp_desc *ifp_desc = &dpni->snic.egress_ifp_info->ifp_desc;
	struct qbman_swp *sw_portal;
	int i, j, err = 0;
	uint32_t ceetmid;
	int ceetm_ch_idx;

	eiop_ifp_set_counter(ifp_desc, E_INGRESS_FC, 0);
	eiop_ifp_set_counter(ifp_desc, E_INGRESS_BC, 0);
	eiop_ifp_set_counter(ifp_desc, E_INGRESS_MFC, 0);
	eiop_ifp_set_counter(ifp_desc, E_INGRESS_MBC, 0);
	eiop_ifp_set_counter(ifp_desc, E_INGRESS_BFC, 0);
	eiop_ifp_set_counter(ifp_desc, E_INGRESS_BBC, 0);

	eiop_ifp_set_counter(ifp_desc, E_EGRESS_FC, 0);
	eiop_ifp_set_counter(ifp_desc, E_EGRESS_BC, 0);
	eiop_ifp_set_counter(ifp_desc, E_EGRESS_MFC, 0);
	eiop_ifp_set_counter(ifp_desc, E_EGRESS_MBC, 0);
	eiop_ifp_set_counter(ifp_desc, E_EGRESS_BFC, 0);
	eiop_ifp_set_counter(ifp_desc, E_EGRESS_BBC, 0);

	eiop_ifp_set_counter(ifp_desc, E_INGRESS_FFC, 0);
	eiop_ifp_set_counter(ifp_desc, E_INGRESS_FDC, 0);
	eiop_ifp_set_counter(ifp_desc, E_INGRESS_OODC, 0);
	eiop_ifp_set_counter(ifp_desc, E_EGRESS_FDC, 0);
	eiop_ifp_set_counter(ifp_desc, E_EGRESS_CFC, 0);

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);

	for( ceetm_ch_idx = 0 ; ceetm_ch_idx < dpni->num_ceetm_ch ; ceetm_ch_idx++ ) {
		ceetmid = qbman_ceetmid_compose( (uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.dcp_id, (uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id);
		for (i = 0; i < dpni->max_tx_tcs; i++) {
			err = qbman_ceetm_statistics_query(sw_portal, ceetmid,
				(uint16_t)(((uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid << 4) | dpni->tx_ch[ceetm_ch_idx].tc_tx[i].cqid),
				query_and_clear_dq_statistics, NULL, NULL);

			if (err != 0) {
				dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
				continue;
			}

			err = qbman_ceetm_statistics_query(sw_portal, ceetmid,
				(uint16_t)(((uint8_t)dpni->tx_ch[ceetm_ch_idx].ap.cqchid << 4) | dpni->tx_ch[ceetm_ch_idx].tc_tx[i].ccgid),
				query_and_clear_reject_statistics, NULL, NULL);

			if (err != 0) {
				dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
				continue;
			}
		}
	}

	for( i = 0 ; i < dpni->max_rx_tcs ; i++ ) {
		if( dpni->tc_rx[i].cgid_index != DPNI_INVALID_ID ) {
			err = qbman_cgr_statistics_query(sw_portal, (uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[i].cgid_index].cgid, 1,
					NULL, NULL);
		}
		for (j = 0; j < dpni->tc_rx[SELECT_TC_SHARED_FS(i)].dist_size; j++)
		{
			if (dpni->tc_rx[i].rx_queues[j].cgid_index != DPNI_INVALID_ID)
				err = qbman_cgr_statistics_query(sw_portal, (uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[i].rx_queues[j].cgid_index].cgid, 1,
									NULL, NULL);
		}

		if( dpni->tc_rx[i].policer_enable ) {
			dppolicer_reset_profile_counters(dpni->ing_dppolicer,
					dpni->tc_rx[i].plcrid, NULL);
		}
	}

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return err;
}

int dpni_set_link_cfg(struct dpni *dpni, const struct dpni_link_cfg *cfg)
{
	int err, tmp_err;
	struct dpni_link_cfg safe_cfg;

	// check new configuration compatibility
	err = check_pfc_compatibility(dpni, cfg);
	CHECK_COND_RETVAL(err==0, err, "Configuration provided not compatible\n");
	
	if (cfg->advertising & ~DPNI_ADVERTISED_MASK)
	{
		pr_err("ID[%d]: Illegal advertised speed\n", dpni->id);
		return -EINVAL;
	}
	
	if( !dpni->enabled ) {
		memcpy(&dpni->link_cfg, cfg, sizeof(struct dpni_link_cfg));
	}
	else {
		if( dpni->link_cfg.rate!=cfg->rate || dpni->link_cfg.options!=cfg->options ||
			dpni->link_cfg.advertising!=cfg->advertising ) {
			//store current working config for the case when something is going really bad
			safe_cfg.rate = dpni->link_cfg.rate;
			safe_cfg.options = dpni->link_cfg.options;
			safe_cfg.advertising = dpni->link_cfg.advertising;

			// apply configuration
			dpni->link_cfg.rate = cfg->rate;
			dpni->link_cfg.options = cfg->options;
			dpni->link_cfg.advertising = cfg->advertising;

			err = dpni_apply_link_cfg(dpni);
			if( err ) {
				// this should never happen because the configuration is already checked...
				pr_err("Could not apply link configuration. Try to restore last configuration\n");
				dpni->link_cfg.rate = safe_cfg.rate;
				dpni->link_cfg.options = safe_cfg.options;
				dpni->link_cfg.advertising = safe_cfg.advertising;
				tmp_err = dpni_apply_link_cfg(dpni);
				if( tmp_err ) {
					pr_err("Could not restore the configuration; link remain disabled\n");
					dpni_disable(dpni);
					return tmp_err;
				}
				return err;
			}
		}
	}

	return 0;
}

int dpni_get_link_cfg(struct dpni *dpni, struct dpni_link_cfg *cfg)
{
	cfg->advertising	= dpni->link_cfg.advertising;
	cfg->options		= dpni->link_cfg.options;
	cfg->rate			= dpni->link_cfg.rate;

	return 0;
}

int dpni_get_link_state(struct dpni *dpni, struct dpni_link_state *state)
{
	struct linkman_endpoint endpoint1, endpoint2;
	struct linkman_connection_attr attr;
	int err;

	memset(&endpoint1, 0x0, sizeof(struct linkman_endpoint));
	memset(&endpoint2, 0x0, sizeof(struct linkman_endpoint));
	memset(&attr, 0x0, sizeof(struct linkman_connection_attr));
	endpoint1.type = FSL_MOD_DPNI;
	endpoint1.id = (uint16_t)dpni->id;

	err = linkman_get_connection(dpni->linkman, &endpoint1, &endpoint2,
					&attr);
	if (err || (attr.state != LINKMAN_STATE_LINKUP))
		state->up = 0;
	else
		state->up = 1;
	state->rate = attr.rate;
	state->options = attr.options;
	state->supported = attr.supported;
	state->advertising = attr.advertising;
	state->state_valid = 1;

	return 0;
}

int dpni_set_tx_shaping(struct dpni *dpni, const int ceetm_ch_idx,
		const struct dpni_tx_shaping_cfg *tx_cr_shaper,
		const struct dpni_tx_shaping_cfg *tx_er_shaper,
		const int shaper_coupling, const int lni_shaping, const uint16_t oal)
{
	uint64_t cr_bps, er_bps;

	CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
				dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

	cr_bps = (uint64_t)tx_cr_shaper->rate_limit * 1000000;
	if (!dpmng_is_rate_allowed(dpni->dpmng, cr_bps)) {
		pr_err("ID[%d]: Committed rate is too big\n", dpni->id);
		return -EINVAL;
	}
	
	er_bps = (uint64_t)tx_er_shaper->rate_limit * 1000000;
	if (!dpmng_is_rate_allowed(dpni->dpmng, er_bps)) {
		pr_err("ID[%d]: Excess rate is too big\n", dpni->id);
		return -EINVAL;
	}
	
	CHECK_COND_RETVAL(tx_cr_shaper->max_burst_size <= ceetm_if_get_max_tbl(),
			-EINVAL,
			"ID[%d]: CR Max Burst Size must be smaller than: %d\n",
			dpni->id, (int)ceetm_if_get_max_tbl());
	
	CHECK_COND_RETVAL(tx_er_shaper->max_burst_size <= ceetm_if_get_max_tbl(),
			-EINVAL,
			"ID[%d]: ER Max Burst Size must be smaller than: %d\n",
			dpni->id, (int)ceetm_if_get_max_tbl());

	if( lni_shaping ) {
		memcpy(&dpni->tx_lni_cr_shaper, tx_cr_shaper, sizeof(struct dpni_tx_shaping_cfg));
		memcpy(&dpni->tx_lni_er_shaper, tx_er_shaper, sizeof(struct dpni_tx_shaping_cfg));
		dpni->lni_shaper_coupling = shaper_coupling;
		dpni->lni_shaper_oal = oal;
		dpni->lni_configured = 1;
	}
	else {
		memcpy(&dpni->tx_ch[ceetm_ch_idx].tx_cr_shaper, tx_cr_shaper, sizeof(struct dpni_tx_shaping_cfg));
		memcpy(&dpni->tx_ch[ceetm_ch_idx].tx_er_shaper, tx_er_shaper, sizeof(struct dpni_tx_shaping_cfg));
		dpni->tx_ch[ceetm_ch_idx].shaper_coupling = shaper_coupling;
	}

	update_tx_shaping(dpni);

	return 0;
}

int dpni_set_max_frame_length(struct dpni *dpni, uint16_t max_frame_length)
{
	int err;

	err = eiop_ifp_set_max_frame_length(
		&dpni->snic.ingress_ifp_info->ifp_desc, max_frame_length);
	if (err) {
		pr_err("ID[%d]: setting MFL failed\n", dpni->id);
		return err;
	}

	dpni->mfl = max_frame_length;

	if( dpni->dpdmux ) {
		/* dpni endpoint is dpdmux
		 * update max frame length for dpdmux interface 0 to allow receiving
		 * update max frame length for dpni interface to allow sending */
		err = dpdmux_if_update_max_frame_len(dpni->dpdmux, 0, max_frame_length);
		if( err ) pr_warn("dpni.%d: Failed to update max frame length for mux connection (if 0)\n");
		err = dpdmux_if_update_max_frame_len(dpni->dpdmux, dpni->dpdmux_if_id, max_frame_length);
		if( err ) pr_warn("dpni.%d: Failed to update max frame length for mux connection (if %d)\n", dpni->dpdmux_if_id);
	}

	return 0;
}

int dpni_get_max_frame_length(struct dpni *dpni, uint16_t *max_frame_length)
{
	*max_frame_length = dpni->mfl;

	return 0;
}

int dpni_set_multicast_promisc(struct dpni *dpni, int en)
{
	struct dppolicy_rule rule;
	struct dppolicy_action action;
	int err;

	if (dpni->multicast_promisc_en != en) {
		memset(&rule, 0, sizeof(struct dppolicy_rule));
		memset(&action, 0, sizeof(struct dppolicy_action));
		rule.priority = DPNI_POLICY_PRI_MULTICAST;
		rule.num_of_identifiers = 1;
		rule.identifiers[0].exclude = 0;
		rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT_OPT;
		rule.identifiers[0].prot = NET_PROT_ETH;
		rule.identifiers[0].opt = NH_OPT_ETH_MULTICAST;
		if (en) {
#ifdef TKT508412
			if( eiop_wriop_apply_TKT508412_fix() ) {
				copy_dptbl_to_dppolicy(&dpni->filters.multicast_allow_action,
						&action);
			}
			else {
				copy_dptbl_to_dppolicy(&dpni->filters.mac_allow_action,
						&action);
			}
#else
			copy_dptbl_to_dppolicy(&dpni->filters.mac_allow_action,
					&action);
#endif
		} else {
			if (dpni->options & DPNI_OPT_MULTICAST_FILTER) {
				action.next_action = DPPOLICY_ACTION_LOOKUP;
				action.lookup_params.dpkg_profile_id =
					dpni->filters.mac_kid;
				dptbl_get_id(
					dpni->filters.mac_tbl,
					&action.lookup_params.dptbl_id);
			} else {
				action.next_action = DPPOLICY_ACTION_DONE;
				action.options =
					DPPOLICY_ACTION_SET_DISCARD_FLAG;
			}
		}
		err = dppolicy_modify_rule(dpni->policy, &rule, &action);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);

		dpni->multicast_promisc_en = en;

		if (dpni->dpdmux)
			update_dpdmux_multicast_promisc(dpni);
	}

	return 0;
}

int dpni_set_unicast_promisc(struct dpni *dpni, int en)
{
	struct dppolicy_rule rule;
	struct dppolicy_action action;
	int err;

	if (dpni->unicast_promisc_en != en) {
		memset(&rule, 0, sizeof(struct dppolicy_rule));
		memset(&action, 0, sizeof(struct dppolicy_action));
		rule.priority = DPNI_POLICY_PRI_UNICAST;
		rule.num_of_identifiers = 1;
		rule.identifiers[0].exclude = 0;
		rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT_OPT;
		rule.identifiers[0].prot = NET_PROT_ETH;
		rule.identifiers[0].opt = NH_OPT_ETH_UNICAST;
		if (en) {
			copy_dptbl_to_dppolicy(&dpni->filters.mac_allow_action,
						&action);
		} else {
			CHECK_COND_RETVAL(dpni->filters.mac_tbl, -ENAVAIL);
			action.next_action = DPPOLICY_ACTION_LOOKUP;
			action.lookup_params.dpkg_profile_id =
				dpni->filters.mac_kid;
			dptbl_get_id(dpni->filters.mac_tbl,
					&action.lookup_params.dptbl_id);
		}

		err = dppolicy_modify_rule(dpni->policy, &rule, &action);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);

		dpni->unicast_promisc_en = en;

		if (dpni->dpdmux)
			update_dpdmux_unicast_promisc(dpni);
	}

	return 0;
}

int dpni_get_multicast_promisc(struct dpni *dpni, int *en)
{
	*en = dpni->multicast_promisc_en;

	return 0;
}

int dpni_get_unicast_promisc(struct dpni *dpni, int *en)
{
	*en = dpni->unicast_promisc_en;

	return 0;
}

int dpni_set_primary_mac_addr(struct dpni *dpni, const uint8_t new_addr[6])
{
	struct dptbl_rule rule;
	int err;

	if (NH_ETH_IS_MULTICAST_ADDR(new_addr)) {
		pr_err("ID[%d]: mac address cannot be a multicast address\n", dpni->id);
		return -EINVAL;
	}

	if (memcmp(dpni->mac_addr, new_addr, 6) == 0)
		return 0;

	CHECK_COND_RETVAL(dpni->filters.mac_tbl, -ENAVAIL);

	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = (uint8_t *)new_addr;
	rule.rule_cfg.exact.size = 6;
	err = dptbl_add_rule(dpni->filters.mac_tbl, &rule,
				&dpni->filters.mac_allow_action, 0);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = dpni->mac_addr;
	rule.rule_cfg.exact.size = 6;
	err = dptbl_remove_rule(dpni->filters.mac_tbl, &rule);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);

	if (dpni->dpdmux) {
		if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC) {
			/* The right flow is the opposite but to optimized the
			 * use of entries i reversed it taking the chance some
			 * frames will be lost */
			update_dpdmux_mac_vlan_by_mac(dpni, dpni->mac_addr,
							1 /* remove */);
			update_dpdmux_mac_vlan_by_mac(dpni,
							(uint8_t *)new_addr,
							0 /* add */);
		} else if (dpni->dpdmux_method == DPDMUX_METHOD_MAC) {
			update_dpdmux_address(dpni, (uint8_t *)new_addr,
						0 /*vlan_id*/, 0 /* add */);
			update_dpdmux_address(dpni, dpni->mac_addr,
						0 /*vlan_id*/, 1 /* remove */);
		}
	}

	memcpy(dpni->mac_addr, new_addr, 6);

	return 0;
}

int dpni_get_primary_mac_addr(struct dpni *dpni, uint8_t addr[6])
{
	memcpy(addr, dpni->mac_addr, 6);

	return 0;
}

int dpni_get_port_mac_addr(struct dpni *dpni, uint8_t addr[6])
{
	memset(addr, 0, 6);
	if (dpni->dpmac)
		dpmac_get_port_mac_addr(dpni->dpmac, addr);
	return 0;
}

int dpni_add_mac_addr(struct dpni *dpni, const uint8_t addr[6])
{
	struct dpni_table_rule *tbl_rule, *table_rules;
	struct dptbl_rule rule;
	uint8_t *num_filters, max_filters;
	int err, is_mcast = NH_ETH_IS_MULTICAST_ADDR(addr);

	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = (uint8_t *)addr;
	rule.rule_cfg.exact.size = 6;

	if (is_mcast && !(dpni->options & DPNI_OPT_MULTICAST_FILTER)) {
		pr_err("ID[%d]: multicast address filtering wasn't chosen as "
				"part of the general options mask\n", dpni->id);
		return -EACCES;
	} else if (!is_mcast && !(dpni->options & DPNI_OPT_UNICAST_FILTER)) {
		pr_err("ID[%d]: unicast address filtering wasn't chosen as "
				"part of the general options mask\n", dpni->id);
		return -EACCES;
	}
	if (!is_mcast && !memcmp(dpni->mac_addr, addr, 6)) {
		pr_err("ID[%d]: address equal to primary address, "
				"cannot be added\n", dpni->id);
		return -ENAVAIL;
	}

	if (dpni->options & DPNI_OPT_SHARED_MAC_TABLE) {
		num_filters = &dpni->filters.num_mac_filters;
		max_filters = dpni->filters.max_mac_filters;
		table_rules = dpni->filters.mac_addrs;
	} else if (is_mcast) {
		num_filters = &dpni->filters.num_multicast_filters;
		max_filters = dpni->filters.max_multicast_filters;
		table_rules = &dpni->filters.mac_addrs[DPNI_MAX_UNICAST_FILTERS];
	} else {
		num_filters = &dpni->filters.num_unicast_filters;
		max_filters = dpni->filters.max_unicast_filters;
		table_rules = dpni->filters.mac_addrs;
	}
	if (*num_filters >=  max_filters) {
		pr_err("ID[%d]: address filtering table is full\n", dpni->id);
		return -ENOSPC;
	}
	err = dptbl_add_rule(dpni->filters.mac_tbl, &rule,
				&dpni->filters.mac_allow_action, 0);
	if (err) {
		pr_err("ID[%d]: Failed to add address\n", dpni->id);
		return err;
	}
	tbl_rule = find_free_rule(table_rules);
	CHECK_COND_RETVAL(tbl_rule, -ENAVAIL);

	*num_filters += 1;
	memcpy(&tbl_rule->rule.mac_addr, (uint8_t *)addr, 6);

	if (dpni->dpdmux) {
		if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC)
			update_dpdmux_mac_vlan_by_mac(dpni, (uint8_t *)addr,
							0 /* add */);
		else if (dpni->dpdmux_method == DPDMUX_METHOD_MAC)
			update_dpdmux_address(dpni, (uint8_t *)addr,
						0 /*vlan_id*/, 0 /* add */);
	}

	return 0;
}

int dpni_add_mac_addr_action(struct dpni *dpni, const uint8_t addr[6], struct dpni_mac_action_cfg action_cfg)
{
	struct dpni_table_rule *tbl_rule, *table_rules;
	struct dptbl_rule rule;
	uint8_t *num_filters, max_filters;
	int err, is_mcast = NH_ETH_IS_MULTICAST_ADDR(addr);
	struct dptbl_action next_action;
	struct qbman_swp *sw_portal;

	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = (uint8_t *)addr;
	rule.rule_cfg.exact.size = 6;

	if (is_mcast && !(dpni->options & DPNI_OPT_MULTICAST_FILTER)) {
		pr_err("ID[%d]: multicast address filtering wasn't chosen as "
				"part of the general options mask\n", dpni->id);
		return -EACCES;
	} else if (!is_mcast && !(dpni->options & DPNI_OPT_UNICAST_FILTER)) {
		pr_err("ID[%d]: unicast address filtering wasn't chosen as "
				"part of the general options mask\n", dpni->id);
		return -EACCES;
	}
	if (!is_mcast && !memcmp(dpni->mac_addr, addr, 6)) {
		pr_err("ID[%d]: address equal to primary address, "
				"cannot be added\n", dpni->id);
		return -ENAVAIL;
	}
	
	if (action_cfg.fq_id > dpni->tc_rx[action_cfg.tc_id].max_dist_size) {
		pr_err( "ID[%d]: tc_id %d flow_id must be smaller than %d\n", dpni->id, action_cfg.tc_id, 
				dpni->tc_rx[action_cfg.tc_id].max_dist_size);
		return -EINVAL;
	}
	
	if (dpni->tc_rx[action_cfg.tc_id].dist_mode == DPNI_DIST_MODE_HASH)
	{
		pr_err( "ID[%d]: HASH distribution enable on tc %d\n", dpni->id, action_cfg.tc_id);
		return -EINVAL;
	}

	if (dpni->options & DPNI_OPT_SHARED_MAC_TABLE) {
		num_filters = &dpni->filters.num_mac_filters;
		max_filters = dpni->filters.max_mac_filters;
		table_rules = dpni->filters.mac_addrs;
	} else if (is_mcast) {
		num_filters = &dpni->filters.num_multicast_filters;
		max_filters = dpni->filters.max_multicast_filters;
		table_rules = &dpni->filters.mac_addrs[DPNI_MAX_UNICAST_FILTERS];
	} else {
		num_filters = &dpni->filters.num_unicast_filters;
		max_filters = dpni->filters.max_unicast_filters;
		table_rules = dpni->filters.mac_addrs;
	}
	if (*num_filters >=  max_filters) {
		pr_err("ID[%d]: address filtering table is full\n", dpni->id);
		return -ENOSPC;
	}
	
	memset(&next_action, 0, sizeof(struct dptbl_action));
	next_action.options = DPTBL_ACTION_SET_QPRI | DPTBL_ACTION_SET_QDBIN | DPTBL_ACTION_SET_OPAQUE;
	next_action.qpri = dpni_get_rx_base_qpri(dpni) + action_cfg.tc_id;
	next_action.qd_bin = get_qdbin_from_flowid(dpni->tc_rx[action_cfg.tc_id].max_dist_size, action_cfg.fq_id);
	next_action.next_action = DPTBL_ACTION_DONE;
	next_action.in_use = 1;
	
	err = dptbl_add_rule(dpni->filters.mac_tbl, &rule, &next_action, 0);
	if (err) {
		pr_err("ID[%d]: Failed to add address\n", dpni->id);
		return err;
	}
	tbl_rule = find_free_rule(table_rules);
	CHECK_COND_RETVAL(tbl_rule, -ENAVAIL);

	*num_filters += 1;
	memcpy(&tbl_rule->rule.mac_addr, (uint8_t *)addr, 6);
	memcpy(&tbl_rule->action, &next_action, sizeof(struct dptbl_action));
		
	if ((!dpni->tc_rx[action_cfg.tc_id].dist_cfg.fs_enable) && !(dpni->tc_rx[action_cfg.tc_id].fs_tbl_is_valid))
	{
		dpni->tc_rx[action_cfg.tc_id].dist_size = dpni->tc_rx[action_cfg.tc_id].max_dist_size;
		dpni->tc_rx[action_cfg.tc_id].dist_cfg.fs_dist_size = dpni->tc_rx[action_cfg.tc_id].dist_size;
		dpni->tc_rx[action_cfg.tc_id].virt_dist = 1;
				
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_qpr_configure(sw_portal,
				(uint16_t)dpni->tc_rx[action_cfg.tc_id].qprid,
				(uint32_t)dpni->tc_rx[action_cfg.tc_id].fqid_base,
				(uint16_t)dpni->tc_rx[action_cfg.tc_id].dist_size,
				(uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[action_cfg.tc_id].cgid_index].cgid);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_qpr_configure failed for qprid\n", dpni->id);
			return err;
		}
	}

	if (dpni->dpdmux) {
		if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC)
			update_dpdmux_mac_vlan_by_mac(dpni, (uint8_t *)addr,
							0 /* add */);
		else if (dpni->dpdmux_method == DPDMUX_METHOD_MAC)
			update_dpdmux_address(dpni, (uint8_t *)addr,
						0 /*vlan_id*/, 0 /* add */);
	}

	return 0;
}

int dpni_remove_mac_addr(struct dpni *dpni, const uint8_t addr[6])
{
	struct dptbl_rule rule;
	uint8_t *num_filters;
	struct dpni_table_rule *table_rules, *tbl_rule;
	int err, is_mcast = NH_ETH_IS_MULTICAST_ADDR(addr);
	int tc_id;
	struct qbman_swp *sw_portal;

	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = (uint8_t *)addr;
	rule.rule_cfg.exact.size = 6;

	if (is_mcast && !(dpni->options & DPNI_OPT_MULTICAST_FILTER)) {
		pr_err("ID[%d]: multicast address filtering wasn't chosen as "
				"part of the general options mask\n", dpni->id);
		return -EACCES;
	} else if (!is_mcast && !(dpni->options & DPNI_OPT_UNICAST_FILTER)) {
		pr_err("ID[%d]: unicast address filtering wasn't chosen as "
				"part of the general options mask\n", dpni->id);
		return -EACCES;
	}
	if (!is_mcast && !memcmp(dpni->mac_addr, addr, 6)) {
		pr_err("ID[%d]: address equal to primary address, "
				"cannot be removed\n", dpni->id);
		return -ENAVAIL;
	}

	if (dpni->options & DPNI_OPT_SHARED_MAC_TABLE) {
		num_filters = &dpni->filters.num_mac_filters;
		table_rules = dpni->filters.mac_addrs;
	} else if (is_mcast) {
		num_filters = &dpni->filters.num_multicast_filters;
		table_rules = &dpni->filters.mac_addrs[DPNI_MAX_UNICAST_FILTERS];
	} else {
		num_filters = &dpni->filters.num_unicast_filters;
		table_rules = dpni->filters.mac_addrs;
	}
	
	tbl_rule = get_rule(dpni, table_rules, (void*)addr,
			mac_rule_match_cb);
	if (!tbl_rule) {
		pr_err("ID[%d]: entry doesn't exist\n", dpni->id);
		return -ENAVAIL;
	}

	tc_id = tbl_rule->action.qpri - dpni_get_rx_base_qpri(dpni);

	err = dptbl_remove_rule(dpni->filters.mac_tbl, &rule);
	if (err) {
		pr_err("ID[%d]: Failed to remove address\n", dpni->id);
		return err;
	}

	if (dpni->dpdmux) {
		if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC)
			update_dpdmux_mac_vlan_by_mac(dpni, (uint8_t *)addr,
							1 /* remove */);
		else if (dpni->dpdmux_method == DPDMUX_METHOD_MAC)
			update_dpdmux_address(dpni, (uint8_t *)addr,
						0 /*vlan-id*/, 1 /* remove */);
	}

	remove_rule(dpni, table_rules, (void*)addr, mac_rule_match_cb, NULL);

	*num_filters -= 1;
	
	if ((*num_filters == 0) && !(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid))
	{
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = 1;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_size =1;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].virt_dist = 0;
				
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_qpr_configure(sw_portal,
					(uint16_t)dpni->tc_rx[tc_id].qprid,
					(uint32_t)dpni->tc_rx[tc_id].fqid_base,
					(uint16_t)dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size,
					(uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_qpr_configure failed for qprid\n", dpni->id);
			return err;
		}
	}

	return 0;
}

int dpni_clear_mac_filters(struct dpni *dpni, int unicast, int multicast)
{
	struct dpni_table_rule *table_rules = dpni->filters.mac_addrs;
	struct dptbl_rule rule;
	int i = 0, is_mcast, err;

	for (i=0; i<DPNI_MAX_MAC_FILTERS; i++) {
		if (!table_rules[i].in_use)
			continue;
		is_mcast = NH_ETH_IS_MULTICAST_ADDR(table_rules[i].rule.mac_addr);
		if ((is_mcast && !multicast) || (!is_mcast && !unicast))
			continue;

		memset(&rule, 0, sizeof(struct dptbl_rule));
		mac_dptbl_rule_create_cb(&table_rules[i], &rule);
		err = dptbl_remove_rule(dpni->filters.mac_tbl, &rule);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		if (dpni->dpdmux)
			remove_mac_dpdmux_cb(dpni, &table_rules[i]);

		/* no post-remove callback for MAC */
		table_rules[i].in_use = 0;

		if (dpni->options & DPNI_OPT_SHARED_MAC_TABLE)
			dpni->filters.num_mac_filters -= 1;
		else if (is_mcast)
			dpni->filters.num_multicast_filters -= 1;
		else
			dpni->filters.num_unicast_filters -= 1;
	}
	
	return 0;
}

int dpni_enable_vlan_filter(struct dpni *dpni, int en)
{
	int err;

	if (!(dpni->options & DPNI_OPT_VLAN_FILTER)) {
		pr_err("ID[%d]: VLAN filtering wasn't chosen as "
		"part of the general options mask\n", dpni->id);
		return -EACCES;
	}

	if (en) {
		/* Filters active, modify miss action to drop frames */
		vlan_update_miss_flc(dpni);
		err = dptbl_modify_miss_action(
			dpni->filters.vlan_tbl,
			&dpni->filters.vlan_disallow_action);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	} else {
		/* Filters inactive, modify miss action to pass frames */
		err = dptbl_modify_miss_action(
			dpni->filters.vlan_tbl,
			&dpni->filters.vlan_allow_action);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
	}

	dpni->filters.vlan_enable = en;

	return 0;
}

int dpni_add_vlan_id(struct dpni *dpni, uint16_t vlan_id)
{
	struct dpni_table_rule *tbl_rule;
	struct dptbl_rule rule;
	uint8_t vlan_key[3];
	int err;

	if (!(dpni->options & DPNI_OPT_VLAN_FILTER)) {
		pr_err("ID[%d]: VLAN filtering wasn't chosen as "
		"part of the general options mask\n", dpni->id);
		return -EACCES;
	}

	if (dpni->filters.num_vlan_filters == dpni->filters.max_vlan_filters) {
		pr_err("ID[%d]: VLAN filtering is full\n", dpni->id);
		return -ENOSPC;
	}

	/* Verify VLAN is 12 bits long */
	CHECK_COND_RETVAL((vlan_id & 0xF000) == 0, -EINVAL);

	vlan_key[0] = 0x4; /* VLAN present */
	*((uint16_t*)&vlan_key[1]) = vlan_id;
	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = vlan_key;
	rule.rule_cfg.exact.size = 3;
	err = dptbl_add_rule(dpni->filters.vlan_tbl, &rule,
				&dpni->filters.vlan_allow_action, 0);
	if (err) {
		pr_err("ID[%d]: Failed to add vlan-id\n", dpni->id);
		return err;
	}
	dpni->filters.num_vlan_filters += 1;

	tbl_rule = find_free_rule(dpni->filters.vlans);
	CHECK_COND_RETVAL(tbl_rule, -ENAVAIL);
	memcpy(tbl_rule->rule.vlan_key, vlan_key, 3);
	memcpy(&tbl_rule->action, &dpni->filters.vlan_allow_action, sizeof(struct dptbl_action));
	tbl_rule->rule.key_cfg.size = 3;

	if (dpni->dpdmux) {
		if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC)
			update_dpdmux_mac_vlan_by_vlan(dpni, vlan_id,
							0 /* add */);
		else if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN)
			update_dpdmux_address(dpni, 0 /* mac */, vlan_id,
						0 /* add */);

		if (dpni->dpdmux) {
			if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC) {
				if (dpni->unicast_promisc_en) {
					err = dpdmux_if_set_unicast_promisc(
						dpni->dpdmux,
						dpni->dpdmux_if_id, vlan_id,
						1/*en*/);
					CHECK_COND_RETVAL(err == 0, err);
				}

				if (dpni->multicast_promisc_en) {
					err = dpdmux_if_set_multicast_promisc(
						dpni->dpdmux,
						dpni->dpdmux_if_id, vlan_id,
						1/*en*/);
					CHECK_COND_RETVAL(err == 0, err);
				}
			}
		}
	}

	return 0;
}

int dpni_add_vlan_id_action(struct dpni *dpni, uint16_t vlan_id, uint8_t tc_id, uint8_t flow_id)
{
	struct dpni_table_rule *tbl_rule;
	struct dptbl_rule rule;
	uint8_t vlan_key[3];
	int err;
	struct dptbl_action next_action;
	struct qbman_swp *sw_portal;

	if (!(dpni->options & DPNI_OPT_VLAN_FILTER)) {
		pr_err("ID[%d]: VLAN filtering wasn't chosen as "
		"part of the general options mask\n", dpni->id);
		return -EACCES;
	}

	if (dpni->filters.num_vlan_filters == dpni->filters.max_vlan_filters) {
		pr_err("ID[%d]: VLAN filtering is full\n", dpni->id);
		return -ENOSPC;
	}

	if (flow_id > dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size) {
		pr_err( "ID[%d]: tc_id %d flow_id must be smaller than %d\n", dpni->id, tc_id, 
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size);
		return -EINVAL;
	}

	if (dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode == DPNI_DIST_MODE_HASH)
	{
		pr_err( "ID[%d]: HASH distribution enable on tc %d\n", dpni->id, tc_id);
		return -EINVAL;
	}

	/* Verify VLAN is 12 bits long */
	CHECK_COND_RETVAL((vlan_id & 0xF000) == 0, -EINVAL);

	vlan_key[0] = 0x4; /* VLAN present */
	*((uint16_t*)&vlan_key[1]) = vlan_id;
	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = vlan_key;
	rule.rule_cfg.exact.size = 3;
	
	memset(&next_action, 0, sizeof(struct dptbl_action));
	next_action.options = DPTBL_ACTION_SET_QPRI | DPTBL_ACTION_SET_QDBIN | DPTBL_ACTION_SET_OPAQUE;
	next_action.qpri = dpni_get_rx_base_qpri(dpni) + tc_id;
	next_action.qd_bin = get_qdbin_from_flowid(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size, flow_id);
	next_action.next_action = DPTBL_ACTION_DONE;
	
	err = dptbl_add_rule(dpni->filters.vlan_tbl, &rule,
				&next_action, 0);
	if (err) {
		pr_err("ID[%d]: Failed to add vlan-id\n", dpni->id);
		return err;
	}
	dpni->filters.num_vlan_filters += 1;

	tbl_rule = find_free_rule(dpni->filters.vlans);
	CHECK_COND_RETVAL(tbl_rule, -ENAVAIL);
	memcpy(tbl_rule->rule.vlan_key, vlan_key, 3);
	memcpy(&tbl_rule->action, &next_action, sizeof(struct dptbl_action));
	tbl_rule->rule.key_cfg.size = 3;
	
	if ((!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_enable) && !(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid))
	{
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].virt_dist = 1;
			
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_qpr_configure(sw_portal,
				(uint16_t)dpni->tc_rx[tc_id].qprid,
				(uint32_t)dpni->tc_rx[tc_id].fqid_base,
				(uint16_t)dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size,
				(uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_qpr_configure failed for qprid\n", dpni->id);
			return err;
		}
	}
	
	if (dpni->dpdmux) {
		if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC)
			update_dpdmux_mac_vlan_by_vlan(dpni, vlan_id,
							0 /* add */);
		else if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN)
			update_dpdmux_address(dpni, 0 /* mac */, vlan_id,
						0 /* add */);

		if (dpni->dpdmux) {
			if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC) {
				if (dpni->unicast_promisc_en) {
					err = dpdmux_if_set_unicast_promisc(
						dpni->dpdmux,
						dpni->dpdmux_if_id, vlan_id,
						1/*en*/);
					CHECK_COND_RETVAL(err == 0, err);
				}

				if (dpni->multicast_promisc_en) {
					err = dpdmux_if_set_multicast_promisc(
						dpni->dpdmux,
						dpni->dpdmux_if_id, vlan_id,
						1/*en*/);
					CHECK_COND_RETVAL(err == 0, err);
				}
			}
		}
	}

	return 0;
}

int dpni_remove_vlan_id(struct dpni *dpni, uint16_t vlan_id)
{
	struct dptbl_rule rule;
	uint8_t vlan_key[3];
	int err;
	int tc_id;
	struct qbman_swp *sw_portal;
	struct dpni_table_rule *tbl_rule;

	if (!(dpni->options & DPNI_OPT_VLAN_FILTER)) {
		pr_err("ID[%d]: VLAN filtering wasn't chosen as "
		"part of the general options mask\n", dpni->id);
		return -EACCES;
	}

	if (dpni->filters.num_vlan_filters == 0) {
		pr_err("ID[%d]: VLAN filtering is empty\n", dpni->id);
		return -ENAVAIL;
	}

	/* Verify VLAN is 12 bits long */
	CHECK_COND_RETVAL((vlan_id & 0xF000) == 0, -EINVAL);

	vlan_key[0] = 0x4; /* VLAN present */
	*((uint16_t*)&vlan_key[1]) = vlan_id;

	tbl_rule = get_rule(dpni, dpni->filters.vlans, (void*)&vlan_key,
			vlan_rule_match_cb);
	if (!tbl_rule) {
		pr_err("ID[%d]: entry doesn't exist\n", dpni->id);
		return -ENAVAIL;
	}
	
	tc_id = tbl_rule->action.qpri - dpni_get_rx_base_qpri(dpni);

	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = vlan_key;
	rule.rule_cfg.exact.size = 3;
	err = dptbl_remove_rule(dpni->filters.vlan_tbl, &rule);
	if (err) {
		pr_err("ID[%d]: Failed to remove vlan-id\n", dpni->id);
		return err;
	}

	dpni->filters.num_vlan_filters -= 1;
	
	if (dpni->dpdmux) {
		if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC)
			update_dpdmux_mac_vlan_by_vlan(dpni, vlan_id,
							1 /* remove */);
		else if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN)
			update_dpdmux_address(dpni, 0 /* mac */, vlan_id,
						1 /* remove */);

		if (dpni->dpdmux) {
			if (dpni->dpdmux_method == DPDMUX_METHOD_C_VLAN_MAC) {
				if (dpni->unicast_promisc_en) {
					err = dpdmux_if_set_unicast_promisc(
						dpni->dpdmux,
						dpni->dpdmux_if_id, vlan_id,
						0/*en*/);
					CHECK_COND_RETVAL(err == 0, err);
				}

				if (dpni->multicast_promisc_en) {
					err = dpdmux_if_set_multicast_promisc(
						dpni->dpdmux,
						dpni->dpdmux_if_id, vlan_id,
						0/*en*/);
					CHECK_COND_RETVAL(err == 0, err);
				}
			}
		}
	}

	remove_rule(dpni, dpni->filters.vlans, &vlan_key, vlan_rule_match_cb,
			NULL);
	
	if ((dpni->filters.num_vlan_filters == 0) && !(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid))
	{
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = 1;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_size =1;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].virt_dist = 0;
			
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_qpr_configure(sw_portal,
					(uint16_t)dpni->tc_rx[tc_id].qprid,
					(uint32_t)dpni->tc_rx[tc_id].fqid_base,
					(uint16_t)dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size,
					(uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_qpr_configure failed for qprid\n", dpni->id);
			return err;
		}
	}

	return 0;
}

int dpni_clear_vlan_filters(struct dpni *dpni)
{
	if (!(dpni->options & DPNI_OPT_VLAN_FILTER)) {
		pr_err("ID[%d]: VLAN filtering wasn't chosen as "
		"part of the general options mask\n", dpni->id);
		return -EACCES;
	}

	if (dpni->filters.num_vlan_filters == 0)
		return 0;

	clear_table(dpni, dpni->filters.vlan_tbl, dpni->filters.vlans,
			vlan_dptbl_rule_create_cb, NULL,
			((dpni->dpdmux) ? remove_vlan_dpdmux_cb : NULL));

	dpni->filters.num_vlan_filters = 0;

	return 0;
}

int dpni_set_rx_tc_dist(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *tc_cfg)
{
	struct qbman_swp *sw_portal;
	enum dpni_dist_mode current_dist_mode;
	rx_tc_dist_cb *func;
	int err, i;
	int dist_changed = 0;

	if (IS_SHARED_FS_ENABLED && tc_id) {
		pr_debug("dpni_set_rx_tc_dist setting only the qpr for tc [%d]\n", tc_id);
		goto init_tc_dist_qpr;
	}

	err = check_rx_tc_dist(dpni, tc_id, tc_cfg);
	CHECK_COND_RETVAL(err == 0, err);
	current_dist_mode = dpni->tc_rx[tc_id].dist_mode;
	dpni->tc_rx[tc_id].dist_mode = tc_cfg->dist_mode;
	if (tc_cfg->dist_mode != DPNI_DIST_MODE_NONE)
		dpni->tc_rx[tc_id].dist_size = tc_cfg->dist_size;
	else
		if (!dpni->tc_rx[tc_id].virt_dist)
			dpni->tc_rx[tc_id].dist_size = 1;

	// store data into dist configuration structure
	switch( tc_cfg->dist_mode ) {
	case DPNI_DIST_MODE_NONE:
		dpni->tc_rx[tc_id].dist_cfg.hash_enable = 0;
		dpni->tc_rx[tc_id].dist_cfg.fs_enable = 0;

		/* Enable SET_QDBIN flag for default QoS rule */
		dpni->qos.default_action.options |= DPTBL_ACTION_SET_QDBIN;
		update_pass_through_qos(dpni);

		break;
	case DPNI_DIST_MODE_FS:
		switch( tc_cfg->fs_cfg.miss_action ) {
		case DPNI_FS_MISS_DROP:
			dpni->tc_rx[tc_id].dist_cfg.default_queue = DPNI_FS_DROP;
			dpni->tc_rx[tc_id].dist_cfg.hash_enable = 0;
			break;
		case DPNI_FS_MISS_EXPLICIT_FLOWID:
			dpni->tc_rx[tc_id].dist_cfg.hash_enable = 0;
			dpni->tc_rx[tc_id].dist_cfg.default_queue = tc_cfg->fs_cfg.default_flow_id;
			break;
		case DPNI_FS_MISS_HASH:
			if( !tc_cfg->fs_cfg.keep_hash_key ) {
				memcpy(&dpni->tc_rx[tc_id].fs_cfg, &tc_cfg->fs_cfg, sizeof(struct dpni_fs_tbl_cfg));
				memcpy(&dpni->tc_rx[tc_id].dist_cfg.hash_dist_key, tc_cfg->dist_key_cfg, sizeof(struct dpkg_profile_cfg));
				dpni->tc_rx[tc_id].dist_cfg.hash_dist_size = dpni->tc_rx[tc_id].dist_size;
			}
			dpni->tc_rx[tc_id].dist_cfg.hash_enable = 1;
			break;
		}
		memcpy(&dpni->tc_rx[tc_id].dist_cfg.fs_dist_key, tc_cfg->dist_key_cfg, sizeof(struct dpkg_profile_cfg));
		dpni->tc_rx[tc_id].dist_cfg.fs_dist_size = dpni->tc_rx[tc_id].dist_size;

		/* Disable SET_QDBIN flag for QoS default rule */
		dpni->qos.default_action.options &= ~DPTBL_ACTION_SET_QDBIN;
		update_pass_through_qos(dpni);

		break;
	case DPNI_DIST_MODE_HASH:
		memcpy(&dpni->tc_rx[tc_id].dist_cfg.hash_dist_key, tc_cfg->dist_key_cfg, sizeof(struct dpkg_profile_cfg));
		dpni->tc_rx[tc_id].dist_cfg.hash_dist_size = dpni->tc_rx[tc_id].dist_size;
		dpni->tc_rx[tc_id].dist_cfg.hash_enable = 1;

		/* Disable SET_QDBIN flag for QoS default rule */
		dpni->qos.default_action.options &= ~DPTBL_ACTION_SET_QDBIN;
		update_pass_through_qos(dpni);

		break;
	}

	// some transition are processed using custom code
	switch( current_dist_mode ) {
	case DPNI_DIST_MODE_FS:
		switch( tc_cfg->dist_mode ) {
		// MODE_FS -> MODE_FS transition
		// based on user flag table entries may be leaved in place and only distribution rule is changed
		case DPNI_DIST_MODE_FS:
			if( !tc_cfg->fs_cfg.keep_entries ) {
				delete_fs_table(dpni, tc_id, tc_cfg);
			}
			set_fs_table(dpni, tc_id, tc_cfg);
			dist_changed = 1;
			break;
		}
		break;
	default:
		break;
	}

	// if no custom transition execute default code
	for (i = 0; !dist_changed && i < 3; i++) {
		func =
			rx_tc_dist_sequence[current_dist_mode][tc_cfg->dist_mode][i];
		if (!func)
			break;
		func(dpni, tc_id, tc_cfg);
	}

init_tc_dist_qpr:

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_qpr_configure(sw_portal,
					(uint16_t)dpni->tc_rx[tc_id].qprid,
					(uint32_t)dpni->tc_rx[tc_id].fqid_base,
					(uint16_t)dpni->tc_rx[tc_id].dist_size,
					(uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid);

	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	if (err != 0) {
		pr_err("ID[%d]: qbman_qpr_configure failed for qprid\n", dpni->id);
		return err;
	}

	if (IS_SHARED_FS_ENABLED && (tc_id == 0)) {
		dpni->tc_rx[tc_id].valid = 1;
		pr_debug("DPNI_OPT_SHARED_FS is set. Only tc[0] is valid for dpni_set_rx_tc_dist");
	} else if (!IS_SHARED_FS_ENABLED){
		dpni->tc_rx[tc_id].valid = 1;
	}

	return 0;
}

int dpni_set_tx_priorities(struct dpni *dpni, int ceetm_ch_idx,
	const struct dpni_tx_priorities *cfg)
{
	int i, err;
	uint8_t count_a = 0, count_b = 0, count_strict = 0, num_cqs_per_cqch;
	struct qbman_desc desc;
	int loop_end;

	CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index must be smaller than %d\n",
			dpni->id, dpni->num_ceetm_ch);

	memset(&desc, 0x0, sizeof(struct qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				0, /* match options*/
				&desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);

	CHECK_COND_RETVAL(cfg->prio_group_A<(desc.ceetm_num_strict_pri_q+2), -EINVAL, "ID[%d]: prio_group_A=%d is invalid (expect 0-9)\n", dpni->id, cfg->prio_group_A);
	CHECK_COND_RETVAL(cfg->prio_group_B<(desc.ceetm_num_strict_pri_q+2), -EINVAL, "ID[%d]: prio_group_B=%d is invalid (expect 0-9)\n", dpni->id, cfg->prio_group_B);

	num_cqs_per_cqch =
		desc.dcp[dpni->tx_ch[ceetm_ch_idx].ap.dcp_id].ceetm_instance[dpni->tx_ch[ceetm_ch_idx].ap.ceetm_id].num_cqs_per_channel;

	loop_end = dpni->max_tx_tcs>8 ? 8 : dpni->max_tx_tcs;
	for (i = 0; i < loop_end; i++) {
		if ((cfg->tc_sched[i].mode != DPNI_TX_SCHED_STRICT_PRIORITY)
			&&	cfg->tc_sched[i].delta_bandwidth != 0
			&& ((cfg->tc_sched[i].delta_bandwidth < 100)
				|| (cfg->tc_sched[i].delta_bandwidth > 24800))) {
			pr_err( "ID[%d]: tc_sched[%d], valid range: (%d-%d)\n", dpni->id, i, 100, 24800);
			return -EINVAL;
		}
		
		if( dpni->max_tx_tcs>8 )
			count_strict++;	// ignore groupA/B if more than 8 TCs
		else if (cfg->tc_sched[i].mode == DPNI_TX_SCHED_WEIGHTED_A)
			count_a++;
		else if (cfg->tc_sched[i].mode == DPNI_TX_SCHED_WEIGHTED_B)
			count_b++;
		else
			count_strict++;
	}

	if ( cfg->separate_groups && (count_a > QBMAN_MAX_CEETM_GRP_SIZE || count_b > QBMAN_MAX_CEETM_GRP_SIZE) ) {
		pr_err( "ID[%d]: Weighted group size of is greater than the maximum allowed value of %d\n", dpni->id, QBMAN_MAX_CEETM_GRP_SIZE);
		return -EINVAL;
	}

	if( !cfg->separate_groups && count_b!=0 ) {
		pr_err( "ID[%d]: DPNI_TX_SCHED_WEIGHTED_B cannot be used when separate_goupus==0\n", dpni->id);
		return -EINVAL;
	}

	// check if internal structure has enough space to store data
	if( ((sizeof(dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched)/sizeof(struct dpni_tx_schedule_cfg))) < (dpni->max_tx_tcs+desc.ceetm_weight_pri_q_base) ) {
		pr_err("Internal structure to small to store the configuration\n");
		return -EINVAL;
	}

	if (num_cqs_per_cqch == 8 && count_b > 0) {
		if (count_a < QBMAN_MAX_CEETM_GRP_SIZE)
			pr_warn( "ID[%d]: Assigning a TC to group B will allocate all %d CQ from group A and less strict priority TCs will be available. %d\n", 
					dpni->id, QBMAN_MAX_CEETM_GRP_SIZE);
	}

	loop_end = dpni->max_tx_tcs>8 ? 8 : dpni->max_tx_tcs;
	for (i = 0; i < loop_end; i++) {
		if (dpni->max_tx_tcs <= 8 || num_cqs_per_cqch == 8) {
			dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].mode = cfg->tc_sched[i].mode;
			if (cfg->tc_sched[i].delta_bandwidth == 0)
				dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].delta_bandwidth = DPNI_DEFAULT_SCHED_WEIGHT;
			else
				dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i].delta_bandwidth = cfg->tc_sched[i].delta_bandwidth;
		} else {
			if (i < desc.ceetm_weight_pri_q_base) {
				if (cfg->tc_sched[i].delta_bandwidth == 0)
					dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i + desc.ceetm_weight_pri_q_base].delta_bandwidth = DPNI_DEFAULT_SCHED_WEIGHT;
				else
					dpni->tx_ch[ceetm_ch_idx].tx_selection.tc_sched[i + desc.ceetm_weight_pri_q_base].delta_bandwidth = cfg->tc_sched[i].delta_bandwidth;
			}
		}
	}

	dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_A = cfg->prio_group_A;
	dpni->tx_ch[ceetm_ch_idx].tx_selection.prio_group_B = cfg->prio_group_B;
	dpni->tx_ch[ceetm_ch_idx].tx_selection.separate_groups = cfg->separate_groups;

	err = config_tx_selection(dpni);

	return err;
}

int dpni_set_rx_tc_policing(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_policing_cfg *cfg)
{
	int err;

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err("ID[%d]: tc_id (%d) must be smaller than %d\n", dpni->id, tc_id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	err = set_rx_tc_policer(dpni, tc_id, cfg);
	if (err)
		return err;

	return 0;
}

int dpni_get_rx_tc_policing(struct dpni *dpni,
	uint8_t tc_id,
	struct dpni_rx_tc_policing_cfg *cfg)
{
	struct dppolicer_profile_cfg *policer;

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id (%d), valid range: (0-%d)\n", dpni->id, tc_id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	memset(cfg, 0, sizeof(struct dpni_rx_tc_policing_cfg));
	if (!dpni->tc_rx[tc_id].policer_enable)
		return 0;

	policer = &dpni->tc_rx[tc_id].policer;
	if (!(policer->options & DPPOLICER_OPT_COLOR_BLIND))
		cfg->options |= DPNI_POLICER_OPT_COLOR_AWARE;
	if (policer->options & DPPOLICER_OPT_DISCARD_RED)
		cfg->options |= DPNI_POLICER_OPT_DISCARD_RED;
	if (policer->default_color == DPPPLICER_GREEN)
		cfg->default_color = DPNI_POLICER_COLOR_GREEN;
	if (policer->default_color == DPPPLICER_YELLOW)
		cfg->default_color = DPNI_POLICER_COLOR_YELLOW;
	if (policer->default_color == DPPPLICER_RED)
		cfg->default_color = DPNI_POLICER_COLOR_RED;
	if (policer->alg == DPPPLICER_PASS_THROUGH)
		cfg->mode = DPNI_POLICER_MODE_PASS_THROUGH;
	if (policer->alg == DPPPLICER_RFC_2698)
		cfg->mode = DPNI_POLICER_MODE_RFC_2698;
	if (policer->alg == DPPPLICER_RFC_4115)
		cfg->mode = DPNI_POLICER_MODE_RFC_4115;
	if (policer->alg == DPPPLICER_RFC_4115)
		cfg->mode = DPNI_POLICER_MODE_RFC_4115;
	if (policer->non_passthrough_cfg.rate_mode == DPPPLICER_BYTE_RATE_MODE)
		cfg->units = DPNI_POLICER_UNIT_BYTES;
	if (policer->non_passthrough_cfg.rate_mode
		== DPPPLICER_PACKET_RATE_MODE)
		cfg->units = DPNI_POLICER_UNIT_PACKETS;

	cfg->cir = policer->non_passthrough_cfg.committed_info_rate;
	cfg->cbs = policer->non_passthrough_cfg.committed_burst_size;
	cfg->eir = policer->non_passthrough_cfg.peak_or_excessive_info_rate;
	cfg->ebs = policer->non_passthrough_cfg.peak_or_excessive_burst_size;

	return 0;
}

#ifdef MC_CLI
int dpni_get_metering(struct dpni *dpni, 
        uint8_t tc_id,
        struct dpni_metering_counters *counters)    
{
       int err = 0;
       /* get red counter */
	   err = dppolicer_get_profile_counter(dpni->ing_dppolicer,
			   	   	   	dpni->tc_rx[tc_id].plcrid,
						NULL,
						DPPOLICER_CNT_RED,
						&counters->red);
       /* get yellow counter */
	   err = dppolicer_get_profile_counter(dpni->ing_dppolicer,
			   	   	   	dpni->tc_rx[tc_id].plcrid,
						NULL,
						DPPOLICER_CNT_YELLOW,
						&counters->yellow);
       /* get green counter */
	   err = dppolicer_get_profile_counter(dpni->ing_dppolicer,
			   	   	   	dpni->tc_rx[tc_id].plcrid,
						NULL,
						DPPOLICER_CNT_GREEN,
						&counters->green);
       if (err != 0)
            return err;
       return err;
} 
#endif

int dpni_set_rx_tc_early_drop(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_early_drop_cfg *cfg)
{
	int err;

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id (%d), valid range: (0-%d)\n", dpni->id, tc_id, dpni->max_rx_tcs);
		return -EINVAL;
	}
	
	if (cfg->green.max_threshold >= DPNI_MAX_WRED_THRESHOLD ||
			cfg->yellow.max_threshold >= DPNI_MAX_WRED_THRESHOLD ||
			cfg->red.max_threshold >= DPNI_MAX_WRED_THRESHOLD) {
		pr_err("ID[%d]: Max threshold must be less then 2^39\n", dpni->id);
		return -EINVAL;
	}

	err = set_rx_tc_early_drop(dpni, tc_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_get_rx_tc_early_drop(struct dpni *dpni,
	uint8_t tc_id,
	struct dpni_early_drop_cfg *cfg)
{
	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id (%d), valid range: (0-%d)\n", dpni->id, tc_id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	memcpy(cfg, &dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cg_early_drop,
		sizeof(struct dpni_early_drop_cfg));

	return 0;
}

int dpni_set_tx_tc_early_drop(struct dpni *dpni, int ceetm_ch_idx,
	uint8_t tc_id,
	const struct dpni_early_drop_cfg *cfg)
{
	int err;

	CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
			dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

	if (tc_id >= dpni->max_tx_tcs) {
		pr_err("ID[%d]: tc_id (%d) must be smaller than %d\n", dpni->id, tc_id, dpni->max_tx_tcs);
		return -EINVAL;
	}

	if (cfg->dpni_wred_enable &&
			(cfg->green.max_threshold >= DPNI_MAX_WRED_THRESHOLD ||
			cfg->yellow.max_threshold >= DPNI_MAX_WRED_THRESHOLD ||
			cfg->red.max_threshold >= DPNI_MAX_WRED_THRESHOLD)) {
		pr_err("ID[%d]: Max threshold must be less then 2^39\n", dpni->id);
		return -EINVAL;
	}

	memcpy(&dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cg_early_drop, cfg,
		sizeof(struct dpni_early_drop_cfg));

	err = config_tx_tc_ccg(dpni, ceetm_ch_idx, tc_id);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_get_tx_tc_early_drop(struct dpni *dpni, int ceem_ch_idx,
	uint8_t tc_id,
	struct dpni_early_drop_cfg *cfg)
{
	if (tc_id >= dpni->max_tx_tcs) {
		pr_err("ID[%d]: tc_id (%d), valid range: (0-%d)\n", dpni->id, tc_id, dpni->max_tx_tcs);
		return -EINVAL;
	}

	memcpy(cfg, &dpni->tx_ch[ceem_ch_idx].tc_tx[tc_id].cg_early_drop,
		sizeof(struct dpni_early_drop_cfg));

	return 0;
}

int dpni_set_early_drop(struct dpni *dpni, int ceetm_ch_idx, enum dpni_queue_type qtype,
		uint8_t tc, const struct dpni_early_drop_cfg *cfg)
{
	switch (qtype) {
	case DPNI_QUEUE_RX:
		return dpni_set_rx_tc_early_drop(dpni, tc, cfg);
	case DPNI_QUEUE_TX:
		return dpni_set_tx_tc_early_drop(dpni, ceetm_ch_idx, tc, cfg);
	}

	pr_err("Unexpected QUEUE_TYPE, expected <= %d\n",
			(int)DPNI_QUEUE_TX);
	return -EINVAL;
}

int dpni_get_early_drop(struct dpni *dpni, int ceem_ch_idx, enum dpni_queue_type qtype,
		uint8_t tc, struct dpni_early_drop_cfg *cfg)
{
	switch (qtype) {
	case DPNI_QUEUE_RX:
		return dpni_get_rx_tc_early_drop(dpni, tc, cfg);
	case DPNI_QUEUE_TX:
		return dpni_get_tx_tc_early_drop(dpni, ceem_ch_idx, tc, cfg);
	}

	pr_err("Unexpected QUEUE_TYPE, expected <= %d\n",
			(int)DPNI_QUEUE_TX);
	return -EINVAL;
}

int dpni_set_rx_tc_congestion_notification(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_congestion_notification_cfg *cfg)
{
	int err;

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err("ID[%d]: tc_id (%d), valid range: (0-%d)\n", dpni->id, tc_id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	err = set_rx_tc_congestion_notification(dpni, tc_id, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_get_rx_tc_congestion_notification(struct dpni *dpni,
	uint8_t tc_id,
	struct dpni_congestion_notification_cfg *cfg)
{
	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id (%d), valid range: (0-%d)\n", dpni->id, tc_id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	memcpy(cfg, &dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cg_notify,
		sizeof(struct dpni_congestion_notification_cfg));

	return 0;
}

int dpni_get_rx_cgid_congestion_notification(struct dpni *dpni,
	int cgid_index,
	struct dpni_congestion_notification_cfg *cfg)
{
	if (cgid_index == DPNI_INVALID_ID) {
		pr_err( "ID[%d]: cgid (%d), valid range: (0-%d)\n", dpni->id, cgid_index, dpni->max_congestion_ctrl);
		return -EINVAL;
	}

	memcpy(cfg, &dpni->rx_tx_conf_cgids[cgid_index].cg_notify,
		sizeof(struct dpni_congestion_notification_cfg));

	return 0;
}

int dpni_set_tx_tc_congestion_notification(struct dpni *dpni, int ceetm_ch_idx,
	uint8_t tc_id,
	const struct dpni_congestion_notification_cfg *cfg)
{
	int err;

	if (tc_id >= dpni->max_tx_tcs) {
		pr_err( "ID[%d]: tc_id (%d), valid range: (0-%d)\n", dpni->id, tc_id, dpni->max_tx_tcs);
		return -EINVAL;
	}

	if (cfg->threshold_entry != 0) {
		err = check_congestion_notification(
			dpni, dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].early_drop_enable,
			dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cg_early_drop.units, cfg);
		if (err) {
			pr_err("ID[%d]: tc_id (%d) - configuration check failed\n", dpni->id, tc_id);
			return err;
		}
	}

	memcpy(&dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cg_notify, cfg,
		sizeof(struct dpni_congestion_notification_cfg));

	err = config_tx_tc_ccg(dpni, ceetm_ch_idx, tc_id);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_get_tx_tc_congestion_notification(struct dpni *dpni, int ceetm_ch_idx,
	uint8_t tc_id,
	struct dpni_congestion_notification_cfg *cfg)
{
	CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
				dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

	if (tc_id >= dpni->max_tx_tcs) {
		pr_err( "ID[%d]: tc_id (%d), valid range: (0-%d)\n", dpni->id, tc_id, dpni->max_tx_tcs);
		return -EINVAL;
	}

	memcpy(cfg, &dpni->tx_ch[ceetm_ch_idx].tc_tx[tc_id].cg_notify,
		sizeof(struct dpni_congestion_notification_cfg));

	return 0;
}

int dpni_set_congestion_notification(struct dpni *dpni, int ceetm_ch_idx,
		enum dpni_queue_type qtype, uint8_t tc,
		const struct dpni_congestion_notification_cfg *cfg,
		enum dpni_congestion_point cp, int cgid)
{
	switch (cp)	{
	case DPNI_CP_QUEUE:
		switch (qtype) {
		case DPNI_QUEUE_RX:
			return dpni_set_rx_tc_congestion_notification(dpni, tc, cfg);
		case DPNI_QUEUE_TX:
			return dpni_set_tx_tc_congestion_notification(dpni, ceetm_ch_idx, tc, cfg);
		case DPNI_QUEUE_TX_CONFIRM:
			return dpni_set_tx_conf_congestion_notification(dpni, 0, tc, cfg);
		}
		break;
	case DPNI_CP_CONGESTION_GROUP:
		if (! (dpni->options & DPNI_OPT_CUSTOM_CG))
		{
			pr_err("Congestion Group only available with dpni custom cg\n");
			return -EINVAL;
		}
		return set_rx_cgid_congestion_notification(dpni, cgid, cfg);
		break;
	}
	pr_err("Unexpected QUEUE_TYPE, expected <= %d\n",
			(int)DPNI_QUEUE_TX_CONFIRM);
	return -EINVAL;
}

int dpni_get_congestion_notification(struct dpni *dpni, int ceetm_ch_idx,
		enum dpni_queue_type qtype, uint8_t tc,
		struct dpni_congestion_notification_cfg *cfg,
		enum dpni_congestion_point cp, int cgid)
{
	switch (cp)	{
	case DPNI_CP_QUEUE:
		switch (qtype) {
		case DPNI_QUEUE_RX:
			return dpni_get_rx_tc_congestion_notification(dpni, tc, cfg);
		case DPNI_QUEUE_TX:
			return dpni_get_tx_tc_congestion_notification(dpni, ceetm_ch_idx, tc, cfg);
		case DPNI_QUEUE_TX_CONFIRM:
			return dpni_get_tx_conf_congestion_notification(dpni, 0, tc, cfg);
		}
		break;
	case DPNI_CP_CONGESTION_GROUP :
		if (! (dpni->options & DPNI_OPT_CUSTOM_CG))
		{
			pr_err("Congestion Group only available with dpni custom cg\n");
			return -EINVAL;
		}
		return dpni_get_rx_cgid_congestion_notification(dpni, cgid, cfg);
		break;
	}

	pr_err("Unexpected QUEUE_TYPE, expected <= %d\n",
			(int)DPNI_QUEUE_TX_CONFIRM);
	return -EINVAL;
}

int dpni_set_tx_flow(struct dpni *dpni,
	int ceetm_ch_idx, uint16_t *flow_id,
	const struct dpni_tx_flow_cfg *params)
{
	struct dpni_sender_info *info;
	int err;

	if (*flow_id == DPNI_NEW_FLOW_ID) {
		err = get_free_sender_id(dpni, ceetm_ch_idx, flow_id);
		if (err) {
			pr_err("ID[%d]: No free flow-id\n", dpni->id);
			return err;
		}
	}

	if (*flow_id >= dpni->max_senders) {
		pr_err( "ID[%d]: flow_id must be smaller than %d\n", dpni->id, dpni->max_senders);
		return -EINVAL;
	}

	info = &dpni->tx_ch[ceetm_ch_idx].sender_info[*flow_id];

	if (!info->valid) {
		pr_err("ID[%d]: flow_id isn't valid\n", dpni->id);
		return -EACCES;
	}

	if (!params->options)
		return 0;

	if ((dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED)
		&& (params->options & DPNI_TX_FLOW_OPT_TX_CONF_ERROR)) {
		uint64_t tmp = params->options & DPNI_TX_FLOW_OPT_TX_CONF_ERROR;
		pr_err("ID[%d]: As no private tx-conf, options 0x%08x%08x is not "
		"supported\n", dpni->id, (uint32_t)(tmp>>32), (uint32_t)tmp);
		return -ENOTSUP;
	}

	if (params->options & DPNI_TX_FLOW_OPT_L3_CHKSUM_GEN)
		info->l3_chksum_gen = params->l3_chksum_gen;

	if (params->options & DPNI_TX_FLOW_OPT_L4_CHKSUM_GEN)
		info->l4_chksum_gen = params->l4_chksum_gen;

	if (params->options & DPNI_TX_FLOW_OPT_TX_CONF_ERROR)
		info->private_tx_conf_err_queue =
			!params->use_common_tx_conf_queue;

	err = config_sender_info(dpni, ceetm_ch_idx, *flow_id, info);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_get_tx_flow(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	struct dpni_tx_flow_attr *attr)
{
	struct dpni_sender_info *info;

	if (flow_id >= dpni->max_senders) {
		pr_err( "ID[%d]: flow_id must be smaller than %d\n", dpni->id, dpni->max_senders);
		return -EINVAL;
	}

	info = &dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id];

	if (!info->valid) {
		pr_err("ID[%d]: flow_id isn't valid\n", dpni->id);
		return -EACCES;
	}

	attr->l3_chksum_gen = info->l3_chksum_gen;
	attr->l4_chksum_gen = info->l4_chksum_gen;
	attr->use_common_tx_conf_queue = !info->private_tx_conf_err_queue;

	return 0;
}

int dpni_set_rx_flow(struct dpni *dpni,
	uint8_t tc_id,
	uint16_t flow_id,
	const struct dpni_queue_cfg *params)
{
	struct dpni_rx_queue_info *info;
	uint8_t tc_end, orig_tc = tc_id;
	uint16_t flow_end;
	int err;
	uint16_t old_dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size;

	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size;
	if ((tc_id != DPNI_ALL_TCS) && (tc_id >= dpni->max_rx_tcs)) {
		pr_err( "ID[%d]: tc_id must be smaller than %d\n", dpni->id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	if ((tc_id != DPNI_ALL_TCS) && (flow_id != DPNI_ALL_TC_FLOWS)
		&& (flow_id >= dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size)) {
		pr_err( "ID[%d]: flow_id must be smaller than %d\n", dpni->id, dpni->tc_rx[tc_id].dist_size);
		return -EINVAL;
	}

	if (IS_SHARED_FS_ENABLED) {
		pr_debug( "ID[%d]: DPNI_OPT_SHARED_FS is set. Setting flow  for tc_id[%d].\n", dpni->id, tc_id);
	}

	if (!params->options)
		return 0;

	if (params->options & DPNI_QUEUE_OPT_DEST) {
		err = check_dest_cfg(dpni, &params->dest_cfg);
		CHECK_COND_RETVAL(err == 0, err);
	}

	if (params->options & DPNI_QUEUE_OPT_FLC) {
		err = check_flc(dpni, &params->flc_cfg);
		CHECK_COND_RETVAL(err == 0, err);
	}

	if ((params->options & DPNI_QUEUE_OPT_TAILDROP_THRESHOLD)
		&& (params->tail_drop_threshold > DPNI_MAX_TD_THRESHOLD)) {
		pr_err( "ID[%d]: tail_drop_threshold must not exceed %d\n", dpni->id, DPNI_MAX_TD_THRESHOLD);
		return -EINVAL;
	}

	if (params->tail_drop_threshold) {
		check_taildrop_compatibility(dpni);
	}
	
	if (params->options & DPNI_QUEUE_OPT_SET_CGID) {
		if (params->cgid_index > DPNI_MAX_CG || params->cgid_index > dpni->max_congestion_ctrl) {
			pr_err( "ID[%d]: cgid must not exceed %d\n", dpni->id, dpni->max_congestion_ctrl);
			return -EINVAL;
		}
	}

	tc_end = tc_id;
	flow_end = flow_id;
	if (tc_id == DPNI_ALL_TCS) {
		tc_id = 0;
		flow_id = 0;
		tc_end = dpni->max_rx_tcs - 1;
		flow_end = DPNI_ALL_TC_FLOWS;
	} else if (flow_id == DPNI_ALL_TC_FLOWS)
		flow_id = 0;

	if (params->options & DPNI_QUEUE_OPT_DEST) {
		uint8_t tmp_tc_id = tc_id;
		uint16_t tmp_flow_id = flow_id;

		for (; tc_id <= tc_end; tc_id++)
			for (;
				flow_id
				<= ((flow_end == DPNI_ALL_TC_FLOWS) ?
					dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size - 1 :
					flow_end); flow_id++) {
				info = &dpni->tc_rx[tc_id].rx_queues[flow_id];
				ASSERT_COND(info);

				if ((params->dest_cfg.dest_type
					== DPNI_DEST_NONE)
					&& (info->dest_cfg.dest_type
						!= DPNI_DEST_NONE)) {
					pr_err( "ID[%d]: Cannot change back to parked mode\n", dpni->id);
					return -ENOTSUP;
				}

			}
		tc_id = tmp_tc_id;
		flow_id = tmp_flow_id;
	}

	for (; tc_id <= tc_end; tc_id++) {
		uint16_t tmp_flow_id = flow_id;
		for (;
			flow_id
			<= ((flow_end == DPNI_ALL_TC_FLOWS) ?
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size - 1 : flow_end);
			flow_id++) {

			info = &dpni->tc_rx[tc_id].rx_queues[flow_id];
			CHECK_COND_RETVAL(info, -EINVAL);

			if (params->options & DPNI_QUEUE_OPT_USER_CTX)
				info->user_ctx = params->user_ctx;

			if (params->options & DPNI_QUEUE_OPT_DEST)
				memcpy(&info->dest_cfg, &params->dest_cfg,
					sizeof(struct dpni_dest_cfg));

			if (params->options & DPNI_QUEUE_OPT_FLC)
				build_flc(
					info,
					(struct dpni_flc_cfg *)&params->flc_cfg,
					0);

			if (params->options & DPNI_QUEUE_OPT_ORDER_PRESERVATION)
				info->order_preservation_en =
					params->order_preservation_en;

			if (params->options & DPNI_QUEUE_OPT_TAILDROP_THRESHOLD)
				info->tail_drop_threshold =
					params->tail_drop_threshold;
			
			if (params->options & DPNI_QUEUE_OPT_TAILDROP_OAL)
					info->oal = params->oal;
			
			if (params->options & DPNI_QUEUE_OPT_SET_CGID)
			{
				info->cgid_index = params->cgid_index;
				info->cgid_en = 1;
				dpni->rx_tx_conf_cgids[params->cgid_index].in_use = 1;
			}	
			if (params->options & DPNI_QUEUE_OPT_CLEAR_CGID)
			{
				info->cgid_index = DPNI_INVALID_ID;
				info->cgid_en = 0;
				dpni->rx_tx_conf_cgids[params->cgid_index].in_use = 0;
			}
			
			if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
				pr_info(
				"AIOP DPNI: configure Rx FQ[%xh] from TC[%xh]/flow=%d\n",
				info->fqid, tc_id, flow_id);
			}

			err = config_fqid(dpni, info);
			CHECK_COND_RETVAL(err == 0, err);
		}
		flow_id = tmp_flow_id;
    }

	/* Update QoS/FSs entries with new FLC */
	if (params->options & DPNI_QUEUE_OPT_FLC) {
		update_qos_entries_flc(dpni);
		update_pass_through_qos(dpni);

		tc_id = tc_end = orig_tc;
		if (tc_id == DPNI_ALL_TCS) {
			tc_id = 0;
			tc_end = dpni->max_rx_tcs - 1;
		}
		for (; tc_id <= tc_end; tc_id++)
			update_fs_entries_flc(dpni, tc_id);
	}
	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = old_dist_size;

	return 0;
}

int dpni_get_rx_flow(struct dpni *dpni,
	uint8_t tc_id,
	uint16_t flow_id,
	struct dpni_queue_attr *attr)
{
	struct dpni_rx_queue_info *info;

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id must be smaller than %d\n", dpni->id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	if (flow_id >= dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size) {
		pr_err( "ID[%d]: flow_id must be smaller than %d\n", dpni->id, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size);
		return -EINVAL;
	}

	info = &dpni->tc_rx[tc_id].rx_queues[flow_id];
	CHECK_COND_RETVAL(info, -EINVAL);
	attr->user_ctx = info->user_ctx;
	memcpy(&attr->dest_cfg, &info->dest_cfg, sizeof(struct dpni_dest_cfg));
	build_flc(info, &attr->flc_cfg, 1);
	attr->order_preservation_en = info->order_preservation_en;
	attr->tail_drop_threshold = info->tail_drop_threshold;
	attr->fqid = info->virt_fqid;
	attr->oal = info->oal;
	
	attr->cgid_index = info->cgid_index;

	return 0;
}

int dpni_set_rx_err_queue(struct dpni *dpni, const struct dpni_queue_cfg *cfg)
{
	struct dpni_rx_queue_info *info;
	int err;

	if (!cfg->options)
		return 0;

	info = &dpni->rx_err;

	if (cfg->options & DPNI_QUEUE_OPT_DEST) {
		err = check_dest_cfg(dpni, &cfg->dest_cfg);
		CHECK_COND_RETVAL(err == 0, err);

		if ((cfg->dest_cfg.dest_type == DPNI_DEST_NONE)
			&& (info->dest_cfg.dest_type != DPNI_DEST_NONE)) {
			pr_err("ID[%d]: Cannot change back to parked mode\n", dpni->id);
			return -ENOTSUP;
		}
	}

	if (cfg->options & DPNI_QUEUE_OPT_FLC) {
		pr_err("ID[%d]: 'DPNI_QUEUE_OPT_FLC' isn't supported\n", dpni->id);
		return -ENOTSUP;
	}

	if ((cfg->options & DPNI_QUEUE_OPT_TAILDROP_THRESHOLD)
		&& (cfg->tail_drop_threshold > DPNI_MAX_TD_THRESHOLD)) {
		pr_err( "ID[%d]: tail_drop_threshold must not exceed %d\n", dpni->id, DPNI_MAX_TD_THRESHOLD);
		return -EINVAL;
	}

	if (cfg->options & DPNI_QUEUE_OPT_USER_CTX)
		info->user_ctx = cfg->user_ctx;

	if (cfg->options & DPNI_QUEUE_OPT_DEST)
		memcpy(&info->dest_cfg, &cfg->dest_cfg,
			sizeof(struct dpni_dest_cfg));

	if (cfg->options & DPNI_QUEUE_OPT_ORDER_PRESERVATION)
		info->order_preservation_en = cfg->order_preservation_en;

	if (cfg->options & DPNI_QUEUE_OPT_TAILDROP_THRESHOLD)
		info->tail_drop_threshold = cfg->tail_drop_threshold;

	err = config_fqid(dpni, info);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_get_rx_err_queue(struct dpni *dpni, struct dpni_queue_attr *attr)
{
	struct dpni_rx_queue_info *info;

	info = &dpni->rx_err;

	attr->user_ctx = info->user_ctx;
	memcpy(&attr->dest_cfg, &info->dest_cfg, sizeof(struct dpni_dest_cfg));
	build_flc(info, &attr->flc_cfg, 1);
	attr->order_preservation_en = info->order_preservation_en;
	attr->tail_drop_threshold = info->tail_drop_threshold;
	attr->fqid = info->virt_fqid;

	return 0;
}

int dpni_set_tx_conf(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	const struct dpni_tx_conf_cfg *cfg)
{
	struct dpni_tx_conf_info *info;
	int i, err;

	err = check_tx_conf(dpni, ceetm_ch_idx, flow_id, cfg);
	if (err) {
		pr_err("ID[%d]: flow_id (%d) - configuration check failed\n", dpni->id, flow_id);
		return err;
	}

	if (flow_id == DPNI_COMMON_TX_CONF)
		info = &dpni->tx_conf_err;
	else
		info = &dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id].tx_conf_err;

	if (cfg->queue_cfg.options & DPNI_QUEUE_OPT_USER_CTX)
		info->queue_info.user_ctx = cfg->queue_cfg.user_ctx;

	if (cfg->queue_cfg.options & DPNI_QUEUE_OPT_DEST)
		memcpy(&info->queue_info.dest_cfg, &cfg->queue_cfg.dest_cfg,
			sizeof(struct dpni_dest_cfg));

	if (cfg->queue_cfg.options & DPNI_QUEUE_OPT_ORDER_PRESERVATION)
		info->queue_info.order_preservation_en =
			cfg->queue_cfg.order_preservation_en;

	if (cfg->queue_cfg.options & DPNI_QUEUE_OPT_TAILDROP_THRESHOLD)
		info->queue_info.tail_drop_threshold =
			cfg->queue_cfg.tail_drop_threshold;

	info->only_error_frames = cfg->errors_only;

	err = config_fqid(dpni, &info->queue_info);
	CHECK_COND_RETVAL(err == 0, err);

	/* Need to update the tx-error behavior */
	if (flow_id == DPNI_COMMON_TX_CONF) {
		/* Need to go over all senders */
		for (i = 0; i < dpni->max_senders; i++) {
			err = config_sender_info(dpni, ceetm_ch_idx, (uint16_t)i,
							&dpni->tx_ch[ceetm_ch_idx].sender_info[i]);
			if (err != 0)
				return err;
		}
	} else {
		CHECK_COND_RETVAL(flow_id < DPNI_MAX_SENDERS, -EINVAL);
		err = config_sender_info(dpni, ceetm_ch_idx, flow_id,
						&dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id]);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return 0;
}

int dpni_get_tx_conf(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	struct dpni_tx_conf_attr *attr)
{
	struct dpni_tx_conf_info *info;
	enum dpni_confirmation_mode cmode;

	if ((flow_id != DPNI_COMMON_TX_CONF)
		&& (dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED)) {
		pr_err("ID[%d]: 'private' TX-confirmation isn't supported\n", dpni->id);
		return -ENOTSUP;
	}

	dpni_get_tx_confirmation_mode(dpni, &cmode);
	/* If confirmation mode == DPNI_CONF_SINGLE then return common confirmation
	 * frame queue - ignore 'index' field in dpni_get_queue command
	 */
	if ((cmode == DPNI_CONF_SINGLE) || (flow_id == DPNI_COMMON_TX_CONF))
		info = &dpni->tx_conf_err;
	else {
		if (flow_id >= dpni->max_senders) {
			pr_err( "ID[%d]: flow_id must be smaller than %d\n", dpni->id, dpni->max_senders);
			return -EINVAL;
		}

		if (!dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id].valid) {
			pr_err("ID[%d]: flow_id isn't valid\n", dpni->id);
			return -EACCES;
		}

		info = &dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id].tx_conf_err;
	}

	attr->errors_only = info->only_error_frames;
	attr->queue_attr.user_ctx = info->queue_info.user_ctx;
	memcpy(&attr->queue_attr.dest_cfg, &info->queue_info.dest_cfg,
		sizeof(struct dpni_dest_cfg));
	attr->queue_attr.order_preservation_en =
		info->queue_info.order_preservation_en;
	attr->queue_attr.tail_drop_threshold =
		info->queue_info.tail_drop_threshold;
	attr->queue_attr.fqid = info->queue_info.virt_fqid;

	return 0;
}

int dpni_set_tx_conf_congestion_notification(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	const struct dpni_congestion_notification_cfg *cfg)
{
	struct dpni_tx_conf_info *info;
	int err;

	CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
			dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

	if ((flow_id != DPNI_COMMON_TX_CONF)
		&& (dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED)) {
		pr_err("ID[%d]: 'private' TX-confirmation isn't supported\n", dpni->id);
		return -ENOTSUP;
	}

	if (flow_id == DPNI_COMMON_TX_CONF)
		info = &dpni->tx_conf_err;
	else {
		if (flow_id >= dpni->max_senders) {
			pr_err( "ID[%d]: flow_id must be smaller than %d\n", dpni->id, dpni->max_senders);
			return -EINVAL;
		}

		if (!dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id].valid) {
			pr_err("ID[%d]: flow_id isn't valid\n", dpni->id);
			return -EACCES;
		}

		info = &dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id].tx_conf_err;
	}

	err = set_tx_conf_congestion_notification(dpni, flow_id, info, cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_get_tx_conf_congestion_notification(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	struct dpni_congestion_notification_cfg *cfg)
{
	struct dpni_tx_conf_info *info;

	CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
			dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

	if ((flow_id != DPNI_COMMON_TX_CONF)
		&& (dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED)) {
		pr_err("ID[%d]: 'private' TX-confirmation isn't supported\n", dpni->id);
		return -ENOTSUP;
	}

	if (flow_id == DPNI_COMMON_TX_CONF)
		info = &dpni->tx_conf_err;
	else {
		if (flow_id >= dpni->max_senders) {
			pr_err( "ID[%d]: flow_id must be smaller than %d\n", dpni->id, dpni->max_senders);
			return -EINVAL;
		}

		if (!dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id].valid) {
			pr_err("ID[%d]: flow_id isn't valid\n", dpni->id);
			return -EACCES;
		}

		info = &dpni->tx_ch[ceetm_ch_idx].sender_info[flow_id].tx_conf_err;
	}

	memcpy(cfg, &info->cg_notify,
		sizeof(struct dpni_congestion_notification_cfg));

	return 0;
}

int dpni_set_tx_conf_revoke(struct dpni *dpni, int ceetm_ch_idx, int revoke)
{
	int i, err;

	if (dpni->options & DPNI_OPT_TX_CONF_DISABLED) {
		if (!revoke) {
			pr_err( "ID[%d]: can't enable tx-conf when 'DPNI_OPT_TX_CONF_DISABLED' was set\n", dpni->id);
			return -EINVAL;
		} else
			/* as tx-conf already was disabled in the configuration
			 * phase, no need to do anything */
			return 0;
	}

	dpni->tx_conf_disable = revoke;

	for (i = 0; i < dpni->max_senders; i++) {
		err = config_sender_info(dpni, ceetm_ch_idx, (uint16_t)i,
						&dpni->tx_ch[ceetm_ch_idx].sender_info[i]);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return 0;
}

static void dpni_attr2queue(struct dpni_queue_attr *attr, struct dpni_queue *queue)
{
	queue->destination.id = (uint32_t)attr->dest_cfg.dest_id;
	queue->destination.priority = attr->dest_cfg.priority;
	queue->destination.type = attr->dest_cfg.dest_type;
	queue->destination.hold_active = !!attr->order_preservation_en;
	queue->flc.stash_control = (attr->flc_cfg.flc_type == DPNI_FLC_STASH);
	queue->flc.value = attr->flc_cfg.flow_context;
	queue->user_context = attr->user_ctx;
}

int dpni_get_queue(struct dpni *dpni, int ceetm_ch_idx, enum dpni_queue_type qtype, uint8_t tc,
		uint8_t index, struct dpni_queue *queue,
		struct dpni_queue_id *qid, int *cgid)
{
	int err;
	uint16_t index16;

	CHECK_COND_RETVAL(IN_RANGE(DPNI_QUEUE_RX, qtype, DPNI_QUEUE_RX_ERR),
			-EINVAL,
			"unexpected QUEUE_TYPE value %d, expected <= %d\n",
			(int)DPNI_QUEUE_RX_ERR);

	if (qtype == DPNI_QUEUE_RX) {
		struct dpni_queue_attr attr = { 0 };
		
		CHECK_COND_RETVAL( tc <= dpni->max_rx_tcs - 1,
			-EINVAL,
			"unexpected TC value %d, expected 0..%d\n",
			tc, dpni->max_rx_tcs - 1);

		err = dpni_get_rx_flow(dpni, tc, index, &attr);
		CHECK_COND_RETVAL(err == 0, err);

		dpni_attr2queue(&attr, queue);
		qid->fqid = attr.fqid;
		*cgid = attr.cgid_index;
		/* QDBIN is not populated */
	} else if (qtype == DPNI_QUEUE_TX) {
		CHECK_COND_RETVAL(IN_RANGE(0, tc, dpni->max_tx_tcs - 1),
				-EINVAL,
				"unexpected TC value %d, expected 0..%d\n",
				tc, dpni->max_tx_tcs - 1);

		CHECK_COND_RETVAL(IN_RANGE(0, index, dpni->max_senders -1),
				-EINVAL,
				"unexpected INDEX value %d, expected 0..%d\n",
				index, dpni->max_senders - 1);

		CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
				dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

		/* for now the dpni_get_tx_flow information isn't useful */
		/*
		 * struct dpni_tx_flow_attr attr = { 0 };
		 *
		 * dpni->sender_info[index].valid = 1;
		 * err = dpni_get_tx_flow(dpni, index, &attr);
		 * if (err)
		 * 	return err;
		 */

		/* destination is not relevant for Tx, ignore */
		/* user context also not relevant to the user */
		qid->qdbin = (uint16_t)get_qdbin_from_flowid(dpni->max_senders,
				index);
		qid->fqid = dpni->tx_ch[ceetm_ch_idx].tc_tx[tc].virtual_lfq[index];
	} else if (qtype == DPNI_QUEUE_TX_CONFIRM) {
		struct dpni_tx_conf_attr attr = { 0 };

		index16 = index;
		if (index == (uint8_t)DPNI_COMMON_TX_CONF) {
			index16 = DPNI_COMMON_TX_CONF;
		} else if (index >= 0 && index < dpni->max_senders) {
			dpni->tx_ch[ceetm_ch_idx].sender_info[index].valid = 1;
		}

		err = dpni_get_tx_conf(dpni, ceetm_ch_idx, index16, &attr);
		CHECK_COND_RETVAL(err == 0, err);

		dpni_attr2queue(&attr.queue_attr, queue);
		qid->fqid = attr.queue_attr.fqid;
		/* QDBIN is not populated */
		queue->user_context = attr.queue_attr.user_ctx;
	} else if (qtype == DPNI_QUEUE_RX_ERR) {
		struct dpni_queue_attr attr = { 0 };

		err = dpni_get_rx_err_queue(dpni, &attr);
		CHECK_COND_RETVAL(err == 0, err);

		dpni_attr2queue(&attr, queue);
		qid->fqid = attr.fqid;
		/* QDBIN is not populated */
		queue->user_context = attr.user_ctx;
	}

	return 0;
}

static void dpni_queue2cfg(struct dpni_queue *queue, struct dpni_queue_cfg *cfg)
{
	cfg->dest_cfg.dest_id = queue->destination.id;
	cfg->dest_cfg.priority = queue->destination.priority;
	cfg->dest_cfg.dest_type = queue->destination.type;
	cfg->flc_cfg.flc_type = (queue->flc.stash_control) ? DPNI_FLC_STASH :
			DPNI_FLC_USER_DEFINED;
	cfg->order_preservation_en = !!queue->destination.hold_active;
	cfg->flc_cfg.frame_data_size =
			(enum dpni_stash_size)(queue->flc.value >> 4 & 0x3);
	cfg->flc_cfg.options = (queue->flc.value >> 2 & 0x3) ?
			DPNI_FLC_STASH_FRAME_ANNOTATION : 0;
	cfg->flc_cfg.flow_context_size =
			(enum dpni_stash_size)(queue->flc.value & 0x3);
	cfg->flc_cfg.flow_context = queue->flc.value & ~0x3fULL;
	cfg->user_ctx = queue->user_context;
}

int dpni_set_queue(struct dpni *dpni, int ceetm_ch_idx, enum dpni_queue_type qtype, uint8_t tc,
		uint8_t index, uint8_t options, struct dpni_queue *queue, uint8_t cgid)
{
	int err;
	uint16_t index16;

	CHECK_COND_RETVAL(IN_RANGE(DPNI_QUEUE_RX, qtype, DPNI_QUEUE_RX_ERR),
			-EINVAL,
			"unexpected QUEUE_TYPE value %d, expected <= %d\n",
			(int)DPNI_QUEUE_RX_ERR);

	if (qtype == DPNI_QUEUE_RX) {
		struct dpni_queue_cfg cfg = { 0 };
		
		CHECK_COND_RETVAL(tc <= dpni->max_rx_tcs - 1 || tc == DPNI_ALL_TCS,
					-EINVAL,
					"unexpected TC value %d, expected 0..%d\n",
					tc, dpni->max_rx_tcs - 1);

		if (IS_SHARED_FS_ENABLED) {
			pr_debug( "ID[%d]: DPNI_OPT_SHARED_FS is set. Setting rx queue for tc_id[%d]\n", dpni->id, tc);
		}

		dpni_queue2cfg(queue, &cfg);
		cfg.options = options;
		cfg.cgid_index = cgid;

		index16 = index;
		if (index == (uint8_t)DPNI_ALL_TC_FLOWS)
			index16 = DPNI_ALL_TC_FLOWS;

		err = dpni_set_rx_flow(dpni, tc, index16, &cfg);
		CHECK_COND_RETVAL(err == 0, err);
	} else if (qtype == DPNI_QUEUE_TX) {
		struct dpni_tx_flow_cfg cfg = { 0 };
		uint16_t flow_id = index;

		CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
					dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

		CHECK_COND_RETVAL(IN_RANGE(0, tc, dpni->max_tx_tcs - 1),
				-EINVAL,
				"unexpected TC value %d, expected 0..%d\n",
				tc, dpni->max_tx_tcs - 1);

		CHECK_COND_RETVAL(IN_RANGE(0, index, dpni->max_senders -1),
				-EINVAL,
				"unexpected INDEX value %d, expected 0..%d\n",
				index, dpni->max_senders - 1);

		dpni->tx_ch[ceetm_ch_idx].sender_info[index].valid = 1;

		err = dpni_set_tx_flow(dpni, ceetm_ch_idx, &flow_id, &cfg);
		CHECK_COND_RETVAL(err == 0, err);
	} else if (qtype == DPNI_QUEUE_TX_CONFIRM) {
		struct dpni_tx_conf_cfg cfg = { 0 };

		index16 = index;
		if (index == (uint8_t)DPNI_COMMON_TX_CONF)
			index16 = DPNI_COMMON_TX_CONF;

		dpni_queue2cfg(queue, &cfg.queue_cfg);
		cfg.queue_cfg.options = options;

		err = dpni_set_tx_conf(dpni, ceetm_ch_idx, index16, &cfg);
		CHECK_COND_RETVAL(err == 0, err);
	} else if (qtype == DPNI_QUEUE_RX_ERR) {
		struct dpni_queue_cfg cfg = { 0 };

		dpni_queue2cfg(queue, &cfg);
		cfg.options = options;

		err = dpni_set_rx_err_queue(dpni, &cfg);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return 0;
}

#ifdef TKT011436 
static int dpni_restore_qos_table(struct dpni *dpni)
{
	int err;
	uint8_t tc_id;
	
	if (!dpni->qos.valid)
		return 0;

	pr_debug("dpni_restore_qos_table\n");

	tc_id = dpni->qos.tbl_default_tc;

	err = dpkg_profile_modify(dpni->ing_dpkg, dpni->qos.kid,
				&dpni->qos.qos_key_cfg);
	CHECK_COND_RETVAL(err == 0, err, "Failed to restore the QoS entry\n");

	if (dpni->qos.miss_action.options != DPTBL_ACTION_SET_DISCARD_FLAG)
	{
		if (!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid)
			if( dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode == DPNI_DIST_MODE_HASH)
				fill_qos_entry(dpni, tc_id,
						&dpni->qos.miss_action, DPNI_QOS_OPT_SET_TC_ONLY, 0);
			else
				fill_qos_entry(dpni, tc_id,
						&dpni->qos.miss_action, DPNI_QOS_OPT_SET_FLOW_ID, 0);
		else
			fill_qos_entry(dpni, tc_id,
					&dpni->qos.miss_action, DPNI_QOS_OPT_SET_TC_ONLY, 0);
	}

	qos_update_miss_flc(dpni);

	return 0;
}
#endif /* TKT011436 */

int dpni_set_qos_table(struct dpni *dpni,
	const struct dpni_qos_tbl_cfg *params)
{
	int err;
	struct dpkg_profile_cfg *new_key;

	if (dpni->max_rx_tcs == 1) {
		pr_err( "ID[%d]: As max-tcs equal to 1 QoS table cannot be set\n", dpni->id);
		return -EACCES;
	}

	if (!params->qos_key_cfg) {
		pr_err("ID[%d]: extract_cfg cannot be NULL\n", dpni->id);
		return -ENAVAIL;
	}

	if ((!params->discard_on_miss)
		&& (params->default_tc >= dpni->max_rx_tcs)) {
		pr_err( "ID[%d]: default_tc must be smaller than %d\n", dpni->id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	if (dpni->qos.valid & !params->keep_entries) {
		/* table already exist, need to clear and 'delete' it */
		dpni_clear_qos_table(dpni);
		if (dpni->qos.default_tc != -1)
			dpni->tc_rx[dpni->qos.default_tc].qos_owners--;
	}

	err = dpkg_profile_check_cfg(dpni->ing_dpkg, params->qos_key_cfg);
	if (err) {
		pr_err("ID[%d]: extraction key is wrong\n", dpni->id);
		return err;
	}

	err = dpkg_profile_modify(dpni->ing_dpkg, dpni->qos.kid,
					params->qos_key_cfg);
	if (err) {
		pr_err("ID[%d]: failed to create the extraction key\n", dpni->id);
		return err;
	}

	dpni->qos.valid = 1;

	memset(&dpni->qos.miss_action, 0, sizeof(struct dptbl_action));
	dpni->qos.miss_action.next_action = DPTBL_ACTION_DONE;
	if (params->discard_on_miss) {
		dpni->qos.miss_action.options = DPTBL_ACTION_SET_DISCARD_FLAG;
	} else {
		if (!dpni->tc_rx[params->default_tc].fs_tbl_is_valid)
			if( dpni->tc_rx[params->default_tc].dist_mode == DPNI_DIST_MODE_HASH)
				fill_qos_entry(dpni, params->default_tc,
						&dpni->qos.miss_action, DPNI_QOS_OPT_SET_TC_ONLY, 0);
			else
				fill_qos_entry(dpni, params->default_tc,
						&dpni->qos.miss_action, DPNI_QOS_OPT_SET_FLOW_ID, 0);
		else
			fill_qos_entry(dpni, params->default_tc,
					&dpni->qos.miss_action, DPNI_QOS_OPT_SET_TC_ONLY, 0);
	}

	qos_update_miss_flc(dpni);

	/* Used at restore */
	new_key = params->qos_key_cfg;
	memcpy(&dpni->qos.qos_key_cfg, new_key, sizeof(struct dpkg_profile_cfg));
	/* Used in case of no-match and 'discard_on_miss'= 0 */
	dpni->qos.tbl_default_tc = params->default_tc;

	dpni->qos.default_tc = (uint8_t)-1;
	if (!params->discard_on_miss) {
		dpni->qos.default_tc = params->default_tc;
		dpni->tc_rx[dpni->qos.default_tc].qos_owners++;
	}

	return 0;
}

int dpni_add_qos_entry_v0(struct dpni *dpni,
	const struct dpni_rule_cfg *user_key_params,
	uint8_t tc_id)
{
	struct dptbl_rule rule;
	struct dptbl_action action;
	struct dpni_table_rule *tbl_rule;
	struct dpni_rule_cfg key_params;
	int err;

	if (!dpni->qos.valid) {
		pr_err( "ID[%d]: QoS table wasn't set. call dpni_set_qos_table\n", dpni->id);
		return -EACCES;
	}

	if (dpni->qos.num_qos_entries == dpni->qos.max_qos_entries) {
		pr_err("ID[%d]: QoS table is full\n", dpni->id);
		return -ENOSPC;
	}

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id must be smaller than %d\n", dpni->id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	memcpy(&key_params, user_key_params, sizeof(struct dpni_rule_cfg));
	if (!key_params.key) {
		pr_err("ID[%d]: key cannot be NULL\n", dpni->id);
		return -ENAVAIL;
	}

	if ((!(dpni->options & DPNI_OPT_QOS_MASK_SUPPORT))
		&& key_params.mask) {
		pr_err( "ID[%d]: QoS mask support wasn't set, so mask must be NULL\n", dpni->id);
		return -ENOTSUP;
	}

	if ((dpni->options & DPNI_OPT_QOS_MASK_SUPPORT) && !key_params.mask)
		key_params.mask = key_params.key;

	/* Check if rule already exist in SW DB */
	tbl_rule = get_rule(dpni, dpni->qos.keys, (void*)&key_params,
				qos_fs_rule_match_cb);
	if (tbl_rule) {
		pr_err("ID[%d]: entry already exist\n", dpni->id);
		return -ENAVAIL;
	}

	/* find free entry, Don't move it as priority is taken from it */
	tbl_rule = find_free_rule(dpni->qos.keys);
	CHECK_COND_RETVAL(tbl_rule, -ENAVAIL);

	memset(&rule, 0, sizeof(struct dptbl_rule));

	if (dpni->options & DPNI_OPT_QOS_MASK_SUPPORT) {
		rule.rule_cfg.masked.key = key_params.key;
		rule.rule_cfg.masked.mask = key_params.mask;
		rule.rule_cfg.masked.size = key_params.size;
		rule.rule_cfg.masked.priority =
			tbl_rule->rule.key_cfg.priority;
	} else {
		rule.rule_cfg.exact.key = key_params.key;
		rule.rule_cfg.exact.size = key_params.size;
	}

	fill_qos_entry(dpni, tc_id, &action, DPNI_QOS_OPT_SET_TC_ONLY, 0);
	err = dptbl_add_rule(dpni->qos.tbl, &rule, &action, 0);
	if (err) {
		remove_rule(dpni, tbl_rule, NULL, NULL, NULL);
		pr_err("ID[%d]: Failed to add entry\n", dpni->id);
		return err;
	}

	memcpy(&tbl_rule->action, &action, sizeof(struct dptbl_action));
	tbl_rule->rule.key_cfg.size = key_params.size;
	memcpy(&tbl_rule->rule.key_cfg.key, key_params.key, key_params.size);
	if (key_params.mask) {
		tbl_rule->rule.key_cfg.qos_priority = rule.rule_cfg.masked.priority;
		memcpy(&tbl_rule->rule.key_cfg.mask, key_params.mask,
			key_params.size);
		tbl_rule->rule.key_cfg.maskable = 1;
	}
	
	dpni->qos.num_qos_entries++;
	dpni->tc_rx[tc_id].qos_owners++;

	return 0;
}

int dpni_add_qos_entry_v1(struct dpni *dpni,
	uint16_t entry_index,
	const struct dpni_rule_cfg *user_key_params,
	uint8_t tc_id, uint8_t flags, uint8_t flow_id)
{
	struct dptbl_rule rule;
	struct dptbl_action action;
	struct dpni_table_rule *tbl_rule;
	struct dpni_rule_cfg key_params;
	int err;
	struct qbman_swp *sw_portal = NULL;
	char flow_id_rule = 0;

	if (!dpni->qos.valid) {
		pr_err( "ID[%d]: QoS table wasn't set. call dpni_set_qos_table\n", dpni->id);
		return -EACCES;
	}

	if (dpni->qos.num_qos_entries == dpni->qos.max_qos_entries) {
		pr_err("ID[%d]: QoS table is full\n", dpni->id);
		return -ENOSPC;
	}

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id must be smaller than %d\n", dpni->id, dpni->max_rx_tcs);
		return -EINVAL;
	}
	
	if (IS_SHARED_FS_ENABLED) {
		pr_debug( "ID[%d]: DPNI_OPT_SHARED_FS is set. The qos entry for tc_id[%d] will be added.\n", dpni->id, tc_id);
	}

	if (flags & DPNI_QOS_OPT_SET_FLOW_ID) {
		if (flow_id > dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size) {
			pr_err( "ID[%d]: tc_id %d flow_id must be smaller than %d\n", dpni->id, tc_id, dpni->tc_rx[tc_id].max_dist_size);
			return -EINVAL;
		}
		flow_id_rule = 1;
	}
	else
	{
		flow_id = 0;
	
		if (!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid &&
			!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_enable)
			flags = DPNI_QOS_OPT_SET_FLOW_ID;
	}

	memcpy(&key_params, user_key_params, sizeof(struct dpni_rule_cfg));
	if (!key_params.key) {
		pr_err("ID[%d]: key cannot be NULL\n", dpni->id);
		return -ENAVAIL;
	}

	if ((!(dpni->options & DPNI_OPT_QOS_MASK_SUPPORT))
		&& key_params.mask) {
		pr_err( "ID[%d]: QoS mask support wasn't set, so mask must be NULL\n", dpni->id);
		return -ENOTSUP;
	}

	if ((dpni->options & DPNI_OPT_QOS_MASK_SUPPORT) && !key_params.mask)
		key_params.mask = key_params.key;

	/* Check if rule already exist in SW DB */
	tbl_rule = get_rule(dpni, dpni->qos.keys, (void*)&key_params,
				qos_fs_rule_match_cb);
	if (tbl_rule) {
		pr_err("ID[%d]: entry already exist\n", dpni->id);
		return -ENAVAIL;
	}

	memset(&rule, 0, sizeof(struct dptbl_rule));

	if (dpni->options & DPNI_OPT_QOS_MASK_SUPPORT) {
		tbl_rule = find_rule_by_priority(dpni->qos.keys, entry_index);
		CHECK_COND_RETVAL(tbl_rule, -ENAVAIL);

		rule.rule_cfg.masked.priority = entry_index;
		rule.rule_cfg.masked.key = key_params.key;
		rule.rule_cfg.masked.mask = key_params.mask;
		rule.rule_cfg.masked.size = key_params.size;
	} else {
		/* find free entry, Don't move it as priority is taken from it */
		tbl_rule = find_free_rule(dpni->qos.keys);
		CHECK_COND_RETVAL(tbl_rule, -ENAVAIL);
		rule.rule_cfg.masked.priority =
			tbl_rule->rule.key_cfg.priority;

		rule.rule_cfg.exact.key = key_params.key;
		rule.rule_cfg.exact.size = key_params.size;
	}
	

	fill_qos_entry(dpni, tc_id, &action, flags, flow_id);
	
	err = dptbl_add_rule(dpni->qos.tbl, &rule, &action, 0);
	if (err) {
		remove_rule(dpni, tbl_rule, NULL, NULL, NULL);
		pr_err("ID[%d]: Failed to add entry\n", dpni->id);
		return err;
	}

	memcpy(&tbl_rule->action, &action, sizeof(struct dptbl_action));
	tbl_rule->rule.key_cfg.size = key_params.size;
	memcpy(&tbl_rule->rule.key_cfg.key, key_params.key, key_params.size);
	tbl_rule->flow_id_rule = flow_id_rule;
	tbl_rule->rule.key_cfg.qos_priority = rule.rule_cfg.masked.priority;
	if (key_params.mask) {
		memcpy(&tbl_rule->rule.key_cfg.mask, key_params.mask,
			key_params.size);
		tbl_rule->rule.key_cfg.maskable = 1;
	}
	
	dpni->qos.actual_qos_key_size = key_params.size;

	dpni->qos.num_qos_entries++;
	dpni->tc_rx[tc_id].qos_owners++;
	
	if ((flags & DPNI_QOS_OPT_SET_FLOW_ID) && (!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_enable)
		&& !(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid))
	{
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].virt_dist = 1;
				
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_qpr_configure(sw_portal,
					(uint16_t)dpni->tc_rx[tc_id].qprid,
					(uint32_t)dpni->tc_rx[tc_id].fqid_base,
					(uint16_t)dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size,
					(uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_qpr_configure failed for qprid\n", dpni->id);
			return err;
		}
	}

	return 0;
}

int dpni_remove_qos_entry(struct dpni *dpni,
	const struct dpni_rule_cfg *user_key_params)
{
	struct dptbl_rule rule;
	struct dpni_rule_cfg key_params;
	struct dpni_table_rule *tbl_rule;
	int err;
	int tc_id;
	struct qbman_swp *sw_portal = NULL;

	if (!dpni->qos.valid) {
		pr_err( "ID[%d]: QoS table wasn't set. call dpni_set_qos_table\n", dpni->id);
		return -EACCES;
	}

	if (dpni->qos.num_qos_entries == 0) {
		pr_err("ID[%d]: QoS table is empty\n", dpni->id);
		return -ENAVAIL;
	}

	memcpy(&key_params, user_key_params, sizeof(struct dpni_rule_cfg));
	if (!key_params.key) {
		pr_err("ID[%d]: key cannot be NULL\n", dpni->id);
		return -ENAVAIL;
	}

	if ((!(dpni->options & DPNI_OPT_QOS_MASK_SUPPORT))
		&& key_params.mask) {
		pr_err( "ID[%d]: QoS mask support wasn't set, so mask must be NULL\n", dpni->id);
		return -ENOTSUP;
	}

	if ((dpni->options & DPNI_OPT_QOS_MASK_SUPPORT) && !key_params.mask)
		key_params.mask = key_params.key;

	tbl_rule = get_rule(dpni, dpni->qos.keys, (void*)&key_params,
				qos_fs_rule_match_cb);
	if (!tbl_rule) {
		pr_err("ID[%d]: entry doesn't exist\n", dpni->id);
		return -ENAVAIL;
	}

	memset(&rule, 0, sizeof(struct dptbl_rule));
	if (dpni->options & DPNI_OPT_QOS_MASK_SUPPORT) {
		rule.rule_cfg.masked.key = key_params.key;
		rule.rule_cfg.masked.mask = key_params.mask;
		rule.rule_cfg.masked.size = key_params.size;
		rule.rule_cfg.masked.priority =
			tbl_rule->rule.key_cfg.priority;
	} else {
		rule.rule_cfg.exact.key = key_params.key;
		rule.rule_cfg.exact.size = key_params.size;
	}
	err = dptbl_remove_rule(dpni->qos.tbl, &rule);
	if (err) {
		pr_err("ID[%d]: Failed to remove entry\n", dpni->id);
		return err;
	}

	remove_rule(dpni, tbl_rule, NULL, NULL, qos_post_rule_remove_cb);

	dpni->qos.num_qos_entries--;
	
	tc_id = tbl_rule->action.qpri - dpni_get_rx_base_qpri(dpni);

	if (IS_SHARED_FS_ENABLED) {
		pr_debug( "ID[%d]: DPNI_OPT_SHARED_FS is set. The qos for tc_id[%d] will be removed.\n", dpni->id, tc_id);
	}

	if ((dpni->qos.num_qos_entries == 0) && !(dpni->tc_rx[tc_id].fs_tbl_is_valid))
	{
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = 1;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_size =1;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].virt_dist = 0;
		
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = qbman_qpr_configure(sw_portal,
					(uint16_t)dpni->tc_rx[tc_id].qprid,
					(uint32_t)dpni->tc_rx[tc_id].fqid_base,
					(uint16_t)dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size,
					(uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		if (err != 0) {
			pr_err("ID[%d]: qbman_qpr_configure failed for qprid\n", dpni->id);
			return err;
		}
	}

	return 0;
}

int dpni_clear_qos_table(struct dpni *dpni)
{
	if (!dpni->qos.valid) {
		pr_err( "ID[%d]: QoS table wasn't set. call dpni_set_qos_table\n", dpni->id);
		return -EACCES;
	}

	if (dpni->qos.num_qos_entries == 0)
		return 0;

	clear_table(dpni, dpni->qos.tbl, dpni->qos.keys,
			qos_fs_dptbl_rule_create_cb, qos_post_rule_remove_cb,
			NULL);

	dpni->qos.num_qos_entries = 0;

	return 0;
}

int dpni_add_fs_entry_v0(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rule_cfg *user_key_params,
	uint16_t flow_id)
{
	struct dptbl_rule rule;
	struct dptbl_action action;
	struct dpni_table_rule *tbl_rule;
	struct dpni_rule_cfg key_params;
	int err;
	int idx;
	uint8_t *tmp_mask = NULL;

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id must be smaller than %d\n", dpni->id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	if (!dpni->tc_rx[tc_id].valid) {
		pr_err( "ID[%d]: tc_id wasn't set. call dpni_set_rx_tc_dist\n", dpni->id);
		return -EACCES;
	}

	if (!dpni->tc_rx[tc_id].fs_tbl_is_valid) {
		pr_err( "ID[%d]: FS table wasn't set. call dpni_set_rx_tc_dist with FS mode\n", dpni->id);
		return -EACCES;
	}

	if (dpni->tc_rx[tc_id].num_fs_entries
		== dpni->tc_rx[tc_id].max_fs_entries) {
		pr_err("ID[%d]: FS table is full\n", dpni->id);
		return -ENOSPC;
	}

	if (flow_id >= dpni->tc_rx[tc_id].dist_size) {
		pr_err("ID[%d]: flow_id must be smaller "
		"than %d\n", dpni->id, dpni->tc_rx[tc_id].dist_size);
		return -EINVAL;
	}

	memcpy(&key_params, user_key_params, sizeof(struct dpni_rule_cfg));
	if (!key_params.key) {
		pr_err("ID[%d]: key cannot be NULL\n", dpni->id);
		return -ENAVAIL;
	}

	if ((!(dpni->options & DPNI_OPT_FS_MASK_SUPPORT)) && key_params.mask) {
		pr_err( "ID[%d]: FS mask support wasn't set, so mask must be NULL\n", dpni->id);
		return -ENOTSUP;
	}

	if ((dpni->options & DPNI_OPT_FS_MASK_SUPPORT) && !key_params.mask) {
		tmp_mask = fsl_malloc(key_params.size);
		CHECK_COND_RETVAL(tmp_mask!=NULL, -ENOMEM, "ID[%d]: Could not allocate memory for temp mask\n", dpni->id);
		memset(tmp_mask, 0xFF, key_params.size);
		key_params.mask = tmp_mask;
	}

	if( dpni->options & DPNI_OPT_FS_MASK_SUPPORT ) {
		for( idx = 0; idx<key_params.size ; idx++ ) {
			key_params.key[idx] = key_params.key[idx] & key_params.mask[idx];
		}
	}

	/* Check if rule already exist in SW DB */
	tbl_rule = get_rule(dpni, dpni->tc_rx[tc_id].keys, (void*)&key_params,
				qos_fs_rule_match_cb);
	if (tbl_rule) {
		if( tmp_mask )
			fsl_free(tmp_mask);
		if( dpni->options & DPNI_OPT_FS_MASK_SUPPORT )
			pr_err("ID[%d]: an entry and mask that will produce same result already exist\n", dpni->id);
		else
			pr_err("ID[%d]: entry already exists\n", dpni->id);
		return -ENAVAIL;
	}

	/* find free entry, Don't move it as priority is taken from it */
	tbl_rule = find_free_rule(dpni->tc_rx[tc_id].keys);
	CHECK_COND_RETVAL(tbl_rule, -ENAVAIL);

	memset(&rule, 0, sizeof(struct dptbl_rule));
	memset(&action, 0, sizeof(struct dptbl_action));

	if (dpni->options & DPNI_OPT_FS_MASK_SUPPORT) {
		rule.rule_cfg.masked.key = key_params.key;
		rule.rule_cfg.masked.mask = key_params.mask;
		rule.rule_cfg.masked.size = key_params.size;
		rule.rule_cfg.masked.priority =
			tbl_rule->rule.key_cfg.priority;
	} else {
		rule.rule_cfg.exact.key = key_params.key;
		rule.rule_cfg.exact.size = key_params.size;
	}
	action.options = DPTBL_ACTION_SET_QDBIN;
	action.qd_bin = get_qdbin_from_flowid(dpni->tc_rx[tc_id].dist_size,
						flow_id);
	action.next_action = DPTBL_ACTION_DONE;
	update_action_with_flc(dpni, &dpni->tc_rx[tc_id].rx_queues[flow_id],
				&action);
	err = dptbl_add_rule(dpni->tc_rx[tc_id].fs_tbl, &rule, &action, 0);
	if (err) {
		remove_rule(dpni, tbl_rule, NULL, NULL, NULL);
		if( tmp_mask )
			fsl_free(tmp_mask);
		pr_err("ID[%d]: Failed to add entry\n", dpni->id);
		return err;
	}

	//memcpy(dpni->tc_rx[tc_id].keys[entry_index].key_params, &key_params, sizeof(struct dpni_rule_cfg));
	memcpy(&tbl_rule->action, &action, sizeof(struct dptbl_action));
	tbl_rule->rule.key_cfg.size = key_params.size;
	memcpy(&tbl_rule->rule.key_cfg.key, key_params.key, key_params.size);
	if ( dpni->options & DPNI_OPT_FS_MASK_SUPPORT ) {
		memcpy(&tbl_rule->rule.key_cfg.mask, key_params.mask,
			key_params.size);
		tbl_rule->rule.key_cfg.maskable = 1;
	}

	dpni->tc_rx[tc_id].num_fs_entries++;

	if( tmp_mask )
		fsl_free(tmp_mask);

	return 0;
}

static struct dpni* dpni_get_dpni_by_token(uint16_t token)
{
	struct cmdif_srv *cmdif;
	struct device *dev;
	struct dpni *dpni;

	cmdif = sys_get_handle(FSL_MOD_CMDIF_SRV, 1, core_get_id());
	CHECK_COND_RETVAL( cmdif != NULL, NULL, "Failed to get handle to cmdif\n");

	dev = (struct device *)cmdif->instance_handle[token];
	CHECK_COND_RETVAL( cmdif!=NULL, NULL, "Invalid handle for token %d\n", token);

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL( dpni!=0, NULL, "Failed to get dpni object");

	return dpni;
}

static struct dpni_fs_redirect_table_entry *dpni_get_first_redirect_entry(struct dpni *dpni)
{
	struct dpni_fs_redirect_table_entry *entry = NULL;
	int i;

	for( i = 0 ; i < DPNI_MAX_FS_REDIRECT_ENTRIES ; i++ ) {
		if( !dpni->fs_redirect_table[i].valid ) {
			entry = &dpni->fs_redirect_table[i];
			break;
		}
	}

	return entry;
}

int dpni_add_fs_entry_v1(struct dpni *dpni,
	uint8_t tc_id,
	uint16_t entry_index,
	const struct dpni_rule_cfg *user_key_params,
	const struct dpni_fs_action_cfg *user_action)
{
	struct dptbl_rule rule;
	struct dptbl_action action;
	struct dpni_table_rule *tbl_rule;
	struct dpni_rule_cfg key_params;
	struct dpni_rx_queue_info info;
	struct dpni_rx_queue_info *pinfo;
	int err;
	int idx;
	uint8_t *tmp_mask = NULL;
	struct dpni *target_dpni = NULL;
	struct dpni_fs_redirect_table_entry *redirect_entry = NULL;

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id must be smaller than %d\n", dpni->id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	if (!IS_SHARED_FS_ENABLED) {
		if (!dpni->tc_rx[tc_id].valid) {
			pr_err( "ID[%d]: tc_id wasn't set. call dpni_set_rx_tc_dist\n", dpni->id);
			return -EACCES;
		}
	} else {
		if (!dpni->tc_rx[tc_id].valid) {
			pr_err( "ID[%d]: DPNI_OPT_SHARED_FS is set. Cannot add fs entry for tc(%d) \n", dpni->id, tc_id);
			return -EACCES;
		}
	}

	if (!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid) {
		pr_err( "ID[%d]: FS table wasn't set. call dpni_set_rx_tc_dist with FS mode\n", dpni->id);
		return -EACCES;
	}

	if (dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].num_fs_entries
		== dpni->tc_rx[tc_id].max_fs_entries) {
		pr_err("ID[%d]: FS table is full\n", dpni->id);
		return -ENOSPC;
	}


	if (IS_SHARED_FS_ENABLED) {
		pr_debug("ID[%d]: DPNI_OPT_SHARED_FS is set. The entry for tc_id[%d] will be added in the shared fs table.\n", dpni->id, tc_id);
	}

	if (user_action->flow_id >= dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size) {
		pr_err("ID[%d]: flow_id must be smaller "
		"than %d\n", dpni->id, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size);
		return -EINVAL;
	}

	memcpy(&key_params, user_key_params, sizeof(struct dpni_rule_cfg));
	if (!key_params.key) {
		pr_err("ID[%d]: key cannot be NULL\n", dpni->id);
		return -ENAVAIL;
	}

	if ((!(dpni->options & DPNI_OPT_FS_MASK_SUPPORT)) && key_params.mask) {
		pr_err( "ID[%d]: FS mask support wasn't set, so mask must be NULL\n", dpni->id);
		return -ENOTSUP;
	}

	if ((dpni->options & DPNI_OPT_FS_MASK_SUPPORT) &&
			(entry_index >= dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_fs_entries)) {
		pr_err("ID[%d]: entry_index must be smaller than %d\n",
				dpni->id,
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_fs_entries);
		return -EINVAL;
	}

	if( (user_action->options & (DPNI_FS_OPT_REDIRECT_TO_DPNI_RX | DPNI_FS_OPT_REDIRECT_TO_DPNI_TX)) == 
			(DPNI_FS_OPT_REDIRECT_TO_DPNI_RX | DPNI_FS_OPT_REDIRECT_TO_DPNI_TX) ) {
		pr_err("ID[%d] flags DPNI_FS_OPT_REDIRECT_TO_DPNI_RX and DPNI_FS_OPT_REDIRECT_TO_DPNI_TX are exclusive\n", dpni->id);
		return -EINVAL;
	}

	if ((dpni->options & DPNI_OPT_FS_MASK_SUPPORT) && !key_params.mask) {
		tmp_mask = fsl_malloc(key_params.size);
		CHECK_COND_RETVAL(tmp_mask!=NULL, -ENOMEM, "ID[%d]: Could not allocate memory for temp mask\n", dpni->id);
		memset(tmp_mask, 0xFF, key_params.size);
		key_params.mask = tmp_mask;
	}

	if( dpni->options & DPNI_OPT_FS_MASK_SUPPORT ) {
		for( idx = 0; idx<key_params.size ; idx++ ) {
			key_params.key[idx] = key_params.key[idx] & key_params.mask[idx];
		}
	}

	/*
	 * Check if rule already exist in SW DB 
	 */
	/* all the rules will be added in the same fs table if shared fs option is active.
	 * It means that all the rules will be taken from tc 0 which defines the shared table
	 */
	tbl_rule = get_rule(dpni, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys, (void*)&key_params,
				qos_fs_rule_match_cb);
	if (tbl_rule) {
		if( tmp_mask )
			fsl_free(tmp_mask);
		if( dpni->options & DPNI_OPT_FS_MASK_SUPPORT )
			pr_err("ID[%d]: an entry and mask that will produce same result already exist\n", dpni->id);
		else
			pr_err("ID[%d]: entry already exists\n", dpni->id);
		return -ENAVAIL;
	}

	memset(&rule, 0, sizeof(struct dptbl_rule));
	memset(&action, 0, sizeof(struct dptbl_action));

	if (dpni->options & DPNI_OPT_FS_MASK_SUPPORT) {
		tbl_rule = &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[entry_index];
		if (tbl_rule->in_use) {
			if( tmp_mask )
				fsl_free(tmp_mask);
			pr_err("ID[%d]: classification entry index in use\n", dpni->id);
			return -ENAVAIL;
		}

		reset_rule(tbl_rule);
		tbl_rule->in_use = 1;
		rule.rule_cfg.masked.priority = tbl_rule->rule.key_cfg.priority;
		rule.rule_cfg.masked.key = key_params.key;
		rule.rule_cfg.masked.mask = key_params.mask;
		rule.rule_cfg.masked.size = key_params.size;

	} else {
		/* find free entry, Don't move it as priority is taken from it */
		tbl_rule = find_free_rule(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys);
		CHECK_COND_RETVAL(tbl_rule, -ENAVAIL);
		rule.rule_cfg.masked.priority = tbl_rule->rule.key_cfg.priority;

		rule.rule_cfg.exact.key = key_params.key;
		rule.rule_cfg.exact.size = key_params.size;
	}

	pinfo = &dpni->tc_rx[tc_id].rx_queues[user_action->flow_id];

	action.next_action = DPTBL_ACTION_DONE;

	tbl_rule->redirect.valid = 0;

	if ( user_action->options & DPNI_FS_OPT_REDIRECT_TO_DPNI_RX ) {
		target_dpni = dpni_get_dpni_by_token( user_action->redirect_obj_token );
		CHECK_COND_RETVAL( target_dpni != NULL, -EINVAL, "Failed to get target dpni\n");

		action.options = DPTBL_ACTION_SET_IFP_ID;
		action.ifp_id = target_dpni->snic.ingress_ifp_info->ifp_desc.ifp_id;

		action.next_action = DPTBL_ACTION_LOOKUP;
		dptbl_get_id(target_dpni->qos.tbl, &action.lookup_params.dptbl_id);
		action.lookup_params.dpkg_profile_id = target_dpni->qos.kid;

		redirect_entry = dpni_get_first_redirect_entry(target_dpni);
		CHECK_COND_RETVAL( redirect_entry!=NULL, -E2BIG,
				"dpni.%d can be used as FS target for max %d rules", DPNI_MAX_FS_REDIRECT_ENTRIES);

		tbl_rule->redirect.valid = 1;
		tbl_rule->redirect.token = user_action->redirect_obj_token;
		tbl_rule->redirect.obj_id = target_dpni->id;
		tbl_rule->redirect.remote_entry	= redirect_entry;
	} else if ( user_action->options & DPNI_FS_OPT_REDIRECT_TO_DPNI_TX ) {
		target_dpni = dpni_get_dpni_by_token( user_action->redirect_obj_token );
		CHECK_COND_RETVAL( target_dpni != NULL, -EINVAL, "Failed to get target dpni\n");

		action.options = DPTBL_ACTION_SET_QDID;
		action.qd_id = (int)target_dpni->tx_ch[0].tx_virt_qdid;

		action.options |= DPTBL_ACTION_SET_QPRI;
		action.qpri = 0;

		redirect_entry = dpni_get_first_redirect_entry(target_dpni);
		CHECK_COND_RETVAL( redirect_entry!=NULL, -E2BIG,
				"dpni.%d can be used as FS target for max %d rules", DPNI_MAX_FS_REDIRECT_ENTRIES);

		tbl_rule->redirect.valid = 1;
		tbl_rule->redirect.token = user_action->redirect_obj_token;
		tbl_rule->redirect.obj_id = target_dpni->id;
		tbl_rule->redirect.remote_entry	= redirect_entry;
	}
	else if (user_action->options & DPNI_FS_OPT_DISCARD) {
		action.options = DPTBL_ACTION_SET_DISCARD_FLAG;
	}
	else {
		action.options = DPTBL_ACTION_SET_QDBIN;
		action.qd_bin = get_qdbin_from_flowid(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size,
							user_action->flow_id);
		if (user_action->options & DPNI_FS_OPT_SET_FLC) {
			info.flc_opaque = user_action->flc;
			info.flc_type = (user_action->options & DPNI_FS_OPT_SET_STASH_CONTROL) ?
					DPNI_FLC_STASH : DPNI_FLC_USER_DEFINED;
			pinfo = &info;
			tbl_rule->custom_flc = 1;
		}
	}
	if (dpni->dev_ctx.type == DPMNG_CTX_TYPE_AIOP &&
			user_action->options & DPNI_FS_OPT_SET_FLC) {
		action.options &= ~(DPTBL_ACTION_SET_QDBIN |
				DPTBL_ACTION_SET_STASHING_CNTRL);
		action.options |= DPTBL_ACTION_SET_OPAQUE |
				DPTBL_ACTION_SET_FLC_FOR_AIOP;
		action.opaque = user_action->flc;
	} else {
		update_action_with_flc(dpni, pinfo, &action);
	}

	err = dptbl_add_rule(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl, &rule, &action, 0);
	if (err) {
		remove_rule(dpni, tbl_rule, NULL, NULL, NULL);
		if( tmp_mask )
			fsl_free(tmp_mask);
		pr_err("ID[%d]: Failed to add entry\n", dpni->id);
		return err;
	}
	/* copy key_params used to find tbl_rule at restore */
	//memcpy(dpni->tc_rx[tc_id].keys[entry_index].key_params, &key_params, sizeof(struct dpni_rule_cfg));
	memcpy(&tbl_rule->action, &action, sizeof(struct dptbl_action));
	tbl_rule->rule.key_cfg.size = key_params.size;
	memcpy(&tbl_rule->rule.key_cfg.key, key_params.key, key_params.size);
	if ( dpni->options & DPNI_OPT_FS_MASK_SUPPORT ) {
		memcpy(&tbl_rule->rule.key_cfg.mask, key_params.mask,
			key_params.size);
		tbl_rule->rule.key_cfg.maskable = 1;
	}

	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].num_fs_entries++;

	if( redirect_entry!=NULL ) {
		redirect_entry->valid	= 1;
		redirect_entry->token	= user_action->redirect_obj_token;
		redirect_entry->flow_id = user_action->flow_id;
		redirect_entry->obj_id	= dpni->id;
		redirect_entry->options = user_action->options;
	}

	if( tmp_mask )
		fsl_free(tmp_mask);

	return 0;
}

int dpni_remove_fs_entry(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rule_cfg *user_key_params)
{
	struct dptbl_rule rule;
	struct dpni_rule_cfg key_params;
	struct dpni_table_rule *tbl_rule;
	int err;
	int idx;
	uint8_t *tmp_mask = NULL;

	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id must be smaller than %d\n", dpni->id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	if (!IS_SHARED_FS_ENABLED) {
		if (!dpni->tc_rx[tc_id].valid) {
			pr_err( "ID[%d]: tc_id wasn't set. call dpni_set_rx_tc_dist\n", dpni->id);
			return -EACCES;
		}
	} else {
		if (!dpni->tc_rx[tc_id].valid) {
			pr_err( "ID[%d]: DPNI_OPT_SHARED_FS is set. Cannot remove fs entry for tc(%d) \n", dpni->id, tc_id);
			return -EACCES;
		}
	}

	if (!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid) {
		pr_err( "ID[%d]: FS table wasn't set. call dpni_set_rx_tc_dist with FS mode\n", dpni->id);
		return -EACCES;
	}

	if (dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].num_fs_entries == 0) {
		pr_err("ID[%d]: FS table is empty\n", dpni->id);
		return -ENAVAIL;
	}

	if (IS_SHARED_FS_ENABLED) {
		pr_debug( "ID[%d]: DPNI_OPT_SHARED_FS is set. The entry for tc_id[%d] will be removed from the shared fs table.\n", dpni->id, tc_id);
	}

	memcpy(&key_params, user_key_params, sizeof(struct dpni_rule_cfg));
	if (!key_params.key) {
		pr_err("ID[%d]: key cannot be NULL\n", dpni->id);
		return -ENAVAIL;
	}

	if ((!(dpni->options & DPNI_OPT_FS_MASK_SUPPORT)) && key_params.mask) {
		pr_err( "ID[%d]: FS mask support wasn't set, so mask must be NULL\n", dpni->id);
		return -ENOTSUP;
	}

	if ((dpni->options & DPNI_OPT_FS_MASK_SUPPORT) && !key_params.mask) {
		tmp_mask = fsl_malloc(key_params.size);
		CHECK_COND_RETVAL(tmp_mask!=NULL, -ENOMEM, "ID[%d]: Could not allocate memory for temp mask\n", dpni->id);
		memset(tmp_mask, 0xFF, key_params.size);
		key_params.mask = tmp_mask;
	}

	if( dpni->options & DPNI_OPT_FS_MASK_SUPPORT ) {
		for( idx = 0; idx<key_params.size ; idx++ ) {
			key_params.key[idx] = key_params.key[idx] & key_params.mask[idx];
		}
	}

	tbl_rule = get_rule(dpni, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys, (void*)&key_params,
				qos_fs_rule_match_cb);
	if (!tbl_rule) {
		if( tmp_mask )
			fsl_free(tmp_mask);
		pr_err("ID[%d]: entry doesn't exist\n", dpni->id);
		return -ENAVAIL;
	}

	memset(&rule, 0, sizeof(struct dptbl_rule));
	if (dpni->options & DPNI_OPT_FS_MASK_SUPPORT) {
		rule.rule_cfg.masked.key = key_params.key;
		rule.rule_cfg.masked.mask = key_params.mask;
		rule.rule_cfg.masked.size = key_params.size;
		rule.rule_cfg.masked.priority =
			tbl_rule->rule.key_cfg.priority;
	} else {
		rule.rule_cfg.exact.key = key_params.key;
		rule.rule_cfg.exact.size = key_params.size;
	}
	err = dptbl_remove_rule(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl, &rule);
	if (err) {
		if( tmp_mask )
			fsl_free(tmp_mask);
		pr_err("ID[%d]: Failed to remove entry\n", dpni->id);
		return err;
	}

	if( tbl_rule->redirect.valid ) {
		/* if rule was redirecting to another dpni clear the target data */
		tbl_rule->redirect.remote_entry->valid = 0;
		tbl_rule->redirect.valid = 0;
	}

	remove_rule(dpni, tbl_rule, NULL, NULL, NULL);

	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].num_fs_entries--;

	if( tmp_mask )
		fsl_free(tmp_mask);

	return 0;
}

int dpni_clear_fs_entries(struct dpni *dpni, uint8_t tc_id)
{
	if (tc_id >= dpni->max_rx_tcs) {
		pr_err( "ID[%d]: tc_id must be smaller than %d\n", dpni->id, dpni->max_rx_tcs);
		return -EINVAL;
	}

	if (!IS_SHARED_FS_ENABLED) {
		if (!dpni->tc_rx[tc_id].valid) {
			pr_err( "ID[%d]: tc_id wasn't set. call dpni_set_rx_tc_dist\n", dpni->id);
			return -EACCES;
		}
	} else {
		if (!dpni->tc_rx[tc_id].valid) {
			pr_err( "ID[%d]: DPNI_OPT_SHARED_FS is set. Cannot clear all fs entries for tc(%d) \n", dpni->id, tc_id);
			return -EACCES;
		}
	}

	if (!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl_is_valid) {
		pr_err( "ID[%d]: FS table wasn't set. call dpni_set_rx_tc_dist with FS mode\n", dpni->id);
		return -EACCES;
	}

	if (dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].num_fs_entries == 0)
		return 0;


	if (IS_SHARED_FS_ENABLED) {
		pr_debug( "ID[%d]: DPNI_OPT_SHARED_FS is set. All entries for tc_id[%d] will be removed from shared fs. \n", dpni->id, tc_id);
	}

	clear_table(dpni, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys,
			qos_fs_dptbl_rule_create_cb, NULL, NULL);

	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].num_fs_entries = 0;

	return 0;
}

int dpni_set_irq(struct dpni *dpni,
	uint8_t irq_index,
	const struct mc_irq_cfg *irq_cfg)
{
	if (irq_index >= DPNI_MAX_IRQ_NUM) {
		pr_err( "IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPNI_MAX_IRQ_NUM);
		return -EINVAL;
	}

	mc_set_irq(&(dpni->irqs[irq_index]), irq_cfg);
	return 0;
}

int dpni_get_irq(struct dpni *dpni,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg)
{
	int err;

	if (irq_index >= DPNI_MAX_IRQ_NUM) {
		pr_err( "IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPNI_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq(&(dpni->irqs[irq_index]), irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_set_irq_enable(struct dpni *dpni, uint8_t irq_index, uint8_t en)
{
	int err;

	if (irq_index >= DPNI_MAX_IRQ_NUM) {
		pr_err( "IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPNI_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_set_irq_enable(&(dpni->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_get_irq_enable(struct dpni *dpni, uint8_t irq_index, uint8_t *en)
{
	int err;

	if (irq_index >= DPNI_MAX_IRQ_NUM) {
		pr_err( "IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPNI_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_enable(&(dpni->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_set_irq_mask(struct dpni *dpni, uint8_t irq_index, uint32_t mask)
{
	int err;

	if (irq_index >= DPNI_MAX_IRQ_NUM) {
		pr_err( "IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPNI_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_set_irq_mask(&(dpni->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_get_irq_mask(struct dpni *dpni, uint8_t irq_index, uint32_t *mask)
{
	int err;

	if (irq_index >= DPNI_MAX_IRQ_NUM) {
		pr_err( "IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPNI_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_mask(&(dpni->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_get_irq_status(struct dpni *dpni, uint8_t irq_index, uint32_t *status)
{
	int err;

	if (irq_index >= DPNI_MAX_IRQ_NUM) {
		pr_err( "IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPNI_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_status(&(dpni->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_clear_irq_status(struct dpni *dpni,
	uint8_t irq_index,
	uint32_t status)
{
	int err;

	if (irq_index >= DPNI_MAX_IRQ_NUM) {
		pr_err( "IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPNI_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_clear_irq_status(&(dpni->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpni_set_errors_behavior(struct dpni *dpni, struct dpni_error_cfg *cfg)
{
	struct eiop_ifp_err_cfg mem_err_cfg, snic_ing_err_cfg;
	uint32_t errors;

	errors = cfg->errors;
	if (dpni->is_snic
		&& ((errors & DPNI_ERROR_FLE) || (errors & DPNI_ERROR_PHE))
		&& (cfg->error_action != DPNI_ERROR_ACTION_DISCARD)
		&& dpni->enabled) {
		pr_err( "ID[%d]: Must be disabled to change the errors behavior for FLE/PHE\n", dpni->id);
		return -EINVAL;
	}

	if (dpni->is_snic
		&& ((errors & DPNI_ERROR_FLE) || (errors & DPNI_ERROR_PHE)))
		dpni->snic.pass_fas =
			(cfg->error_action != DPNI_ERROR_ACTION_DISCARD) ?
				1 : 0;

	memset(&mem_err_cfg, 0, sizeof(struct eiop_ifp_err_cfg));
	memset(&snic_ing_err_cfg, 0, sizeof(struct eiop_ifp_err_cfg));
	if (cfg->error_action == DPNI_ERROR_ACTION_DISCARD) {
		/* Discard is the same behavior in both cases */
		snic_ing_err_cfg.action = mem_err_cfg.action =
			EIOP_IFP_ERR_DROP;
		errors |= DPNI_ERRORS_TO_DISCARD;
	} else {
		/* For non-discard case, all errors will be
		 * directed to rx-err before AIOP */
		snic_ing_err_cfg.action = EIOP_IFP_ERR_ENQ_TO_ERR_Q;
		if (dpni->snic.pass_fas)
			snic_ing_err_cfg.options =
				EIOP_IFP_ERR_CFG_OPT_SET_FD_STATUS;

		mem_err_cfg.action =
			(cfg->error_action == DPNI_ERROR_ACTION_CONTINUE) ?
				EIOP_IFP_ERR_ENQ : EIOP_IFP_ERR_ENQ_TO_ERR_Q;

		if (cfg->set_frame_annotation)
			mem_err_cfg.options =
				(EIOP_IFP_ERR_CFG_OPT_SET_FD_STATUS
					| EIOP_IFP_ERR_CFG_OPT_SET_FD_ERR);
	}

	eiop_ifp_set_err_behavior(&dpni->snic.ingress_ifp_info->ifp_desc,
					errors, &snic_ing_err_cfg);
	dpni->snic.ingress_ifp_info->init.errors_settings = EIOP_IFP_CFG_OPT_ERROR_SKIP_CFG;

	eiop_ifp_set_err_behavior(&dpni->mem_ifp_info->ifp_desc, errors,
					&mem_err_cfg);
	dpni->mem_ifp_info->init.errors_settings = EIOP_IFP_CFG_OPT_ERROR_SKIP_CFG;

	return 0;
}

int dpni_get_rx_buffer_layout(struct dpni *dpni,
	struct dpni_buffer_layout *layout)
{
	struct buf_layout *ifp_layout;

	ifp_layout = &dpni->mem_ifp_info->init.defcfg.rx_buf_layout;
	layout->data_align = ifp_layout->data_align;
	layout->pass_frame_status = ifp_layout->pass_fas;
	layout->pass_parser_result = ifp_layout->pass_pr;
	layout->pass_timestamp = ifp_layout->pass_ts;
	layout->pass_sw_opaque = ifp_layout->pass_sw_opaque;
	layout->private_data_size = ifp_layout->priv_data_size;
	layout->data_head_room = ifp_layout->data_headroom;
	layout->data_tail_room = ifp_layout->data_tailroom;

	return 0;
}

int dpni_get_tx_buffer_layout(struct dpni *dpni,
	struct dpni_buffer_layout *layout)
{
	struct buf_layout *ifp_layout;

	ifp_layout = &dpni->snic.egress_ifp_info->init.defcfg.tx_buf_layout;
	layout->data_align = ifp_layout->data_align;
	layout->pass_frame_status = ifp_layout->pass_fas;
	layout->pass_timestamp = ifp_layout->pass_ts;
	layout->pass_sw_opaque = ifp_layout->pass_sw_opaque;
	layout->private_data_size = ifp_layout->priv_data_size;

	return 0;
}

int dpni_get_tx_conf_buffer_layout(struct dpni *dpni,
	struct dpni_buffer_layout *layout)
{
	struct buf_layout *ifp_layout;

	ifp_layout =
		&dpni->snic.egress_ifp_info->init.defcfg.txconf_buf_layout;
	layout->pass_frame_status = ifp_layout->pass_fas;
	layout->pass_timestamp = ifp_layout->pass_ts;

	return 0;
}

int dpni_set_rx_buffer_layout(struct dpni *dpni,
	const struct dpni_buffer_layout *layout)
{
	struct buf_layout ifp_layout;
	struct dpni_ifp_info *ifp_info;
	int err;

	if (!layout->options)
		return 0;

	if (dpni->enabled) {
		pr_err("ID[%d]: DPNI must be disabled\n", dpni->id);
		return -EACCES;
	}

	ifp_info = dpni->mem_ifp_info;
	/* structure copy is deliberate */
	ifp_layout = ifp_info->init.defcfg.rx_buf_layout;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_DATA_ALIGN)
		ifp_layout.data_align = layout->data_align;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_FRAME_STATUS)
		ifp_layout.pass_fas = layout->pass_frame_status;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_PARSER_RESULT)
		ifp_layout.pass_pr = layout->pass_parser_result;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_PRIVATE_DATA_SIZE)
		ifp_layout.priv_data_size =
			ROUND_UP(layout->private_data_size, 64);

	if (layout->options & DPNI_BUF_LAYOUT_OPT_TIMESTAMP)
		ifp_layout.pass_ts = layout->pass_timestamp;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_DATA_HEAD_ROOM)
		ifp_layout.data_headroom = layout->data_head_room;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_DATA_TAIL_ROOM)
		ifp_layout.data_tailroom = layout->data_tail_room;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_SW_OPAQUE)
		ifp_layout.pass_sw_opaque = layout->pass_sw_opaque;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_NO_SG)
		ifp_layout.no_sg = 1;

	err = eiop_ifp_check_buffer_layout(&ifp_info->init.defcfg, &ifp_layout,
						1);
	if (err) {
		pr_err("ID[%d]: Incorrect buffer layout settings\n", dpni->id);
		return err;
	}
	/* structure copy is deliberate */
	ifp_info->init.defcfg.rx_buf_layout = ifp_layout;

	return 0;
}

int dpni_set_tx_buffer_layout(struct dpni *dpni,
	const struct dpni_buffer_layout *layout)
{
	struct buf_layout ifp_layout;
	struct dpni_ifp_info *ifp_info;
	int err;

	if (!layout->options)
		return 0;

	if (dpni->enabled) {
		pr_err("ID[%d]: DPNI must be disabled\n", dpni->id);
		return -EACCES;
	}

	if (layout->options & DPNI_BUF_LAYOUT_OPT_PARSER_RESULT) {
		pr_err( "ID[%d]: 'DPNI_BUF_LAYOUT_OPT_PARSER_RESULT' cann't be used for TX\n", dpni->id);
		return -EINVAL;
	}

	if (layout->options & DPNI_BUF_LAYOUT_OPT_DATA_HEAD_ROOM) {
		pr_err( "ID[%d]: 'DPNI_BUF_LAYOUT_OPT_DATA_HEAD_ROOM' cann't be used for TX\n", dpni->id);
		return -EINVAL;
	}

	if (layout->options & DPNI_BUF_LAYOUT_OPT_DATA_TAIL_ROOM) {
		pr_err( "ID[%d]: 'DPNI_BUF_LAYOUT_OPT_DATA_TAIL_ROOM' cann't be used for TX\n", dpni->id);
		return -EINVAL;
	}

	ifp_info = dpni->snic.egress_ifp_info;
	/* structure copy is deliberate */
	ifp_layout = ifp_info->init.defcfg.tx_buf_layout;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_DATA_ALIGN)
		ifp_layout.data_align = layout->data_align;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_FRAME_STATUS)
		ifp_layout.pass_fas = layout->pass_frame_status;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_PRIVATE_DATA_SIZE)
		ifp_layout.priv_data_size =
			ROUND_UP(layout->private_data_size, 64);

	if (layout->options & DPNI_BUF_LAYOUT_OPT_TIMESTAMP) {
		ifp_layout.pass_ts = layout->pass_timestamp;
		ifp_layout.pass_egr_ad = layout->pass_timestamp;
	}

	if (layout->options & DPNI_BUF_LAYOUT_OPT_SW_OPAQUE)
		ifp_layout.pass_sw_opaque = layout->pass_sw_opaque;

	err = eiop_ifp_check_buffer_layout(&ifp_info->init.defcfg, &ifp_layout,
						0);
	if (err) {
		pr_err("ID[%d]: Incorrect buffer layout settings\n", dpni->id);
		return err;
	}
	/* structure copy is deliberate */
	ifp_info->init.defcfg.tx_buf_layout = ifp_layout;

	return 0;
}

int dpni_set_tx_conf_buffer_layout(struct dpni *dpni,
	const struct dpni_buffer_layout *layout)
{
	struct buf_layout ifp_layout;
	struct dpni_ifp_info *ifp_info;
	int err;

	if (!layout->options)
		return 0;

	if (dpni->enabled) {
		pr_err("ID[%d]: DPNI must be disabled\n", dpni->id);
		return -EACCES;
	}

	if (layout->options & DPNI_BUF_LAYOUT_OPT_PARSER_RESULT) {
		pr_err( "ID[%d]: 'DPNI_BUF_LAYOUT_OPT_PARSER_RESULT' cann't be used for TX-Conf\n", dpni->id);
		return -EINVAL;
	}

	if (layout->options & DPNI_BUF_LAYOUT_OPT_DATA_ALIGN) {
		pr_err( "ID[%d]: 'DPNI_BUF_LAYOUT_OPT_DATA_ALIGN' cann't be used for TX-Conf\n", dpni->id);
		return -EINVAL;
	}

	if (layout->options & DPNI_BUF_LAYOUT_OPT_PRIVATE_DATA_SIZE) {
		pr_err( "ID[%d]: 'DPNI_BUF_LAYOUT_OPT_PRIVATE_DATA_SIZE' cann't be used for TX-Conf\n", dpni->id);
		return -EINVAL;
	}

	if (layout->options & DPNI_BUF_LAYOUT_OPT_DATA_HEAD_ROOM) {
		pr_err( "ID[%d]: 'DPNI_BUF_LAYOUT_OPT_DATA_HEAD_ROOM' cann't be used for TX-Conf\n", dpni->id);
		return -EINVAL;
	}

	if (layout->options & DPNI_BUF_LAYOUT_OPT_DATA_TAIL_ROOM) {
		pr_err( "ID[%d]: 'DPNI_BUF_LAYOUT_OPT_DATA_TAIL_ROOM' cann't be used for TX-Conf\n", dpni->id);
		return -EINVAL;
	}

	ifp_info = dpni->snic.egress_ifp_info;
	/* structure copy is deliberate */
	ifp_layout = ifp_info->init.defcfg.txconf_buf_layout;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_FRAME_STATUS)
		ifp_layout.pass_fas = layout->pass_frame_status;

	if (layout->options & DPNI_BUF_LAYOUT_OPT_TIMESTAMP)
		ifp_layout.pass_ts = layout->pass_timestamp;

	err = eiop_ifp_check_buffer_layout(&ifp_info->init.defcfg, &ifp_layout,
						0);
	if (err) {
		pr_err("ID[%d]: Incorrect buffer layout settings\n", dpni->id);
		return err;
	}

	/* structure copy is deliberate */
	ifp_info->init.defcfg.txconf_buf_layout = ifp_layout;

	return 0;
}

int dpni_set_buffer_layout(struct dpni *dpni, enum dpni_queue_type qtype,
		const struct dpni_buffer_layout *layout)
{
	switch (qtype) {
	case DPNI_QUEUE_RX:
		return dpni_set_rx_buffer_layout(dpni, layout);
	case DPNI_QUEUE_TX:
		return dpni_set_tx_buffer_layout(dpni, layout);
	case DPNI_QUEUE_TX_CONFIRM:
		return dpni_set_tx_conf_buffer_layout(dpni, layout);
	}

	pr_err("Unexpected QUEUE_TYPE, expected <= %d\n",
			(int)DPNI_QUEUE_TX_CONFIRM);
	return -EINVAL;
}

int dpni_get_buffer_layout(struct dpni *dpni, enum dpni_queue_type qtype,
		struct dpni_buffer_layout *layout)
{
	switch (qtype) {
	case DPNI_QUEUE_RX:
		return dpni_get_rx_buffer_layout(dpni, layout);
	case DPNI_QUEUE_TX:
		return dpni_get_tx_buffer_layout(dpni, layout);
	case DPNI_QUEUE_TX_CONFIRM:
		return dpni_get_tx_conf_buffer_layout(dpni, layout);
	}

	pr_err("Unexpected QUEUE_TYPE, expected <= %d\n",
			(int)DPNI_QUEUE_TX_CONFIRM);
	return -EINVAL;
}

int dpni_get_taildrop(struct dpni *dpni, int ceetm_ch_idx, enum dpni_congestion_point cg_point,
		enum dpni_queue_type q_type, uint8_t tc, uint8_t queue_index,
		struct dpni_taildrop *taildrop)
{
	struct dpni_queue_attr q_cfg = { 0 };
	struct dpni_early_drop_cfg *g_cfg;
	int err;

	if( q_type == DPNI_QUEUE_TX )
		CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
					dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

	taildrop->units = DPNI_CONGESTION_UNIT_BYTES;
	taildrop->enable = 0;
	taildrop->threshold = 0;

	switch (cg_point) {
	case DPNI_CP_QUEUE:
		CHECK_COND_RETVAL(q_type == DPNI_QUEUE_RX, -EINVAL,
				"only QUEUE_TYPE 0 (Rx queue) is supported in combination with CONGESTION_POINT 0 (queue)\n");
		err = dpni_get_rx_flow(dpni, tc, queue_index, &q_cfg);
		CHECK_COND_RETVAL(err == 0, err);

		taildrop->threshold = q_cfg.tail_drop_threshold;
		taildrop->oal = q_cfg.oal;
		if (taildrop->threshold)
			taildrop->enable = 1;
		break;

	case DPNI_CP_GROUP:
		if (q_type == DPNI_QUEUE_RX) {
			if (tc >= dpni->max_rx_tcs) {
				pr_err("invalid TC %d, expected < %d\n", tc, dpni->max_rx_tcs);
				return -EINVAL;
			}
			
			g_cfg = &dpni->rx_tx_conf_cgids[dpni->tc_rx[tc].cgid_index].cg_early_drop;
		} else {
			if (tc >= dpni->max_tx_tcs) {
				pr_err("invalid TC %d, expected < %d\n", tc, dpni->max_tx_tcs);
				return -EINVAL;
			}
			
			g_cfg = &dpni->tx_ch[ceetm_ch_idx].tc_tx[tc].cg_early_drop;
		}
	
		if (g_cfg->dpni_tail_drop_enable &&
				g_cfg->tail_drop_threshold) {
			taildrop->enable = 1;
			taildrop->units = g_cfg->units;
			taildrop->threshold = g_cfg->tail_drop_threshold;
			taildrop->oal = g_cfg->oal;
		}
		
		break;
		
	case DPNI_CP_CONGESTION_GROUP:
		if (queue_index >= dpni->max_congestion_ctrl) {
			pr_err("invalid congestion index %d, expected < %d\n", tc, dpni->max_congestion_ctrl);
			return -EINVAL;
		}
					
		g_cfg = &dpni->rx_tx_conf_cgids[queue_index].cg_early_drop;
			
		if (g_cfg->dpni_tail_drop_enable &&
				g_cfg->tail_drop_threshold) {
				taildrop->enable = 1;
				taildrop->units = g_cfg->units;
				taildrop->threshold = g_cfg->tail_drop_threshold;
				taildrop->oal = g_cfg->oal;
		}				
		break;

	default:
		pr_err("unexpected CONGESTON_POINT value %d\n", (int)cg_point);
		return -EINVAL;
	}
	return 0;
}

int dpni_set_taildrop(struct dpni *dpni, int ceetm_ch_idx, enum dpni_congestion_point cg_point,
		enum dpni_queue_type q_type, uint8_t tc, uint8_t queue_index,
		struct dpni_taildrop *taildrop)
{
	struct dpni_queue_cfg q_cfg = { 0 };
	struct dpni_early_drop_cfg g_cfg = { DPNI_CONGESTION_UNIT_BYTES };

	CHECK_COND_RETVAL(q_type == DPNI_QUEUE_RX || q_type == DPNI_QUEUE_TX,
			-EINVAL,
			"Unexpected QUEUE_TYPE value (%d), expected %d or %d\n",
			q_type, DPNI_QUEUE_RX, DPNI_QUEUE_TX);

	if( q_type == DPNI_QUEUE_TX )
		CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
				dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

	switch (cg_point) {
	case DPNI_CP_QUEUE:
		CHECK_COND_RETVAL(q_type == DPNI_QUEUE_RX, -EINVAL,
				"only QUEUE_TYPE 0 (Rx queue) is supported in combination with CONGESTION_POINT 0 (queue)\n");
		q_cfg.tail_drop_threshold = taildrop->threshold;
		q_cfg.oal = taildrop->oal;
		q_cfg.options = DPNI_QUEUE_OPT_TAILDROP_THRESHOLD | DPNI_QUEUE_OPT_TAILDROP_OAL;

		if (!taildrop->enable) {
			q_cfg.tail_drop_threshold = 0;
			q_cfg.oal = 0;
		}
		
		return dpni_set_rx_flow(dpni, tc, queue_index, &q_cfg);
	case DPNI_CP_GROUP:
		g_cfg.dpni_tail_drop_enable = 1;
		g_cfg.units = taildrop->units;
		g_cfg.tail_drop_threshold = taildrop->threshold;
		g_cfg.oal = taildrop->oal;

		if (!taildrop->enable) {
			g_cfg.dpni_tail_drop_enable = 0;
			g_cfg.tail_drop_threshold = 0;
			g_cfg.oal = 0;
		}

		if (q_type == DPNI_QUEUE_RX)
			return set_rx_tc_early_drop(dpni, tc, &g_cfg);
		else
			return dpni_set_tx_tc_early_drop(dpni, ceetm_ch_idx, tc, &g_cfg);
		
		case DPNI_CP_CONGESTION_GROUP:
			
			CHECK_COND_RETVAL(q_type == DPNI_QUEUE_RX, -EINVAL,
							"only QUEUE_TYPE 0 (Rx queue) is supported in combination with CONGESTION_POINT 2 (Congestion Group)\n");
			g_cfg.dpni_tail_drop_enable = 1;
			g_cfg.units = taildrop->units;
			g_cfg.tail_drop_threshold = taildrop->threshold;
			g_cfg.oal = taildrop->oal;
			
			if (!taildrop->enable) {
				g_cfg.dpni_tail_drop_enable = 0;
				g_cfg.tail_drop_threshold = 0;
				g_cfg.oal = 0;
			}
			return set_cgid_early_drop(dpni, queue_index, &g_cfg);
	default:
		pr_err("unexpected CONGESTON_POINT value %d, expected %d or %d\n",
				(int)cg_point, DPNI_CP_QUEUE, DPNI_CP_GROUP);
		return -EINVAL;
	}
	return 0;
}

int dpni_set_tx_confirmation_mode(struct dpni *dpni, int ceetm_ch_idx,
		enum dpni_confirmation_mode cmode)
{
	int i, err;

	if (dpni->enabled) {
		pr_err("DPNI%d: must be disabled to change confirmation mode\n",
				dpni->id);
		return -EACCES;
	}

	CHECK_COND_RETVAL( ceetm_ch_idx < dpni->num_ceetm_ch, -EINVAL, "ID[%d] Channel index %d must be smaller than %d\n",
			dpni->id, ceetm_ch_idx, dpni->num_ceetm_ch);

	switch (cmode) {
	case DPNI_CONF_AFFINE:
		if (dpni->options & DPNI_OPT_TX_CONF_DISABLED) {
			pr_err("ID[%d]: The DPNI does not support confirmation queues\n",
					dpni->id);
			return -ENOTSUP;
		}
		if (dpni->options & DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED) {
			pr_err("ID[%d]: The DPNI does not support affine confirmation queues\n",
					dpni->id);
			return -ENOTSUP;
		}
		dpni->tx_conf_disable = 0;
		for (i = 0; i < dpni->max_senders; i++) {
			dpni->tx_ch[ceetm_ch_idx].sender_info[i].private_tx_conf_err_queue = 1;
			dpni->tx_ch[ceetm_ch_idx].sender_info[i].valid = 1;
		}
		break;
	case DPNI_CONF_SINGLE:
		if (dpni->options & DPNI_OPT_TX_CONF_DISABLED) {
			pr_err("ID[%d]: The DPNI does not support confirmation queues\n",
					dpni->id);
			return -ENOTSUP;
		}
		dpni->tx_conf_disable = 0;
		for (i = 0; i < dpni->max_senders; i++)
			dpni->tx_ch[ceetm_ch_idx].sender_info[i].private_tx_conf_err_queue = 0;
		break;
	case DPNI_CONF_DISABLE:
		dpni->tx_conf_disable = 1;
		for (i = 0; i < dpni->max_senders; i++)
			dpni->tx_ch[ceetm_ch_idx].sender_info[i].private_tx_conf_err_queue = 0;
		break;
	default:
		pr_err("ID[%d]: DPNI confirmation mode is not supported, expected <= %d\n",
				dpni->id, DPNI_CONF_DISABLE);
		return -ENOTSUP;
	}

	for (i = 0; i < dpni->max_senders; i++) {
		err = config_sender_info(dpni, ceetm_ch_idx, (uint16_t)i,
				&dpni->tx_ch[ceetm_ch_idx].sender_info[i]);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return 0;
}


int dpni_get_tx_confirmation_mode(struct dpni *dpni,
		enum dpni_confirmation_mode *cmode)
{
	if (dpni->tx_conf_disable)
		*cmode = DPNI_CONF_DISABLE;
	else if (dpni->tx_ch[0].sender_info[0].private_tx_conf_err_queue)
		/* we don't handle mixes, where one queue uses private cnfq,
		 * while others share
		 */
		*cmode = DPNI_CONF_AFFINE;
	else
		*cmode = DPNI_CONF_SINGLE;

	return 0;
}

int dpni_set_opr(struct dpni *dpni, uint8_t tc_id, uint8_t index, uint8_t options, struct opr_cfg *cfg, uint8_t opr_id) {
	int err = 0;
	int dpni_enabled;
	struct qbman_swp *sw_portal = NULL;
	struct opr_info *info = NULL;
	
	if (!(dpni_has_opr(dpni))) {
		return -EINVAL;
	}
		
	dpni_is_enabled(dpni, &dpni_enabled);
	CHECK_COND_RETVAL(dpni_enabled == 0, -EINVAL);
	
	CHECK_COND_RETVAL( tc_id < dpni->max_rx_tcs, -EINVAL);
		
	if (!(dpni->options & DPNI_OPT_OPR_PER_TC)) {
		CHECK_COND_RETVAL( index < dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size, -EINVAL);
	}
	
	if ((dpni->options & DPNI_OPT_CUSTOM_OPR) &&
		!(options & OPR_OPT_ASSIGN)	&&
		(get_opr_info(dpni, tc_id, index) == NULL))
	{
		pr_err("ID[%d]: Assign the OPR before creation\n", dpni->id);
		return -EINVAL;
	}

	if ((options & OPR_OPT_ASSIGN) && (dpni->options & DPNI_OPT_CUSTOM_OPR)) {
		err = assign_opr(dpni, tc_id, index, opr_id);
		CHECK_COND_RETVAL(err == 0, err);
	}

	info = get_opr_info(dpni, tc_id, index);
	CHECK_COND_RETVAL(info != NULL, -EINVAL, "ID[%d]: No OPR assigned for TC %d queue %d\n",dpni->id, tc_id, index);

	//Check options
	if (options & OPR_OPT_CREATE) {
		err = configure_opr(cfg, info);
		CHECK_COND_RETVAL(err == 0, err);
	} else if (options & OPR_OPT_RETIRE) {
		dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
		err = retire_opr(sw_portal, info);
		if ( dpni->options & DPNI_OPT_CUSTOM_OPR )
			err = remove_opr(dpni, opr_id);
		dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
		CHECK_COND_RETVAL(err == 0, err);
	} else if (options & OPR_OPT_ASSIGN) {
		CHECK_COND_RETVAL(info->state == OPR_SET, -EINVAL, "ASSIGN called before CREATE\n");
	} else {
		pr_err("ID[%d]: Invalid options for OPR\n", dpni->id);
		return -EINVAL;
	}

	if (info->state != OPR_SET) {
		pr_err("ID[%d]: OPR for TC%d, queue %d not configured\n", dpni->id, tc_id, index);
	}

	return err;
}

int dpni_get_opr(struct dpni *dpni, uint8_t tc_id, uint8_t index,
		struct opr_cfg *cfg, struct opr_qry *qry, uint8_t flags, uint8_t opr_id) {
	struct qbman_swp *sw_portal = NULL;
	int err = 0;
	struct opr_info* opr = NULL;
	

	memset(cfg, 0, sizeof(struct opr_cfg));
	memset(qry, 0, sizeof(struct opr_qry));

	if (!flags)
	{
		CHECK_COND_RETVAL( tc_id < dpni->max_rx_tcs, -EINVAL);
	
		if (!(dpni->options & DPNI_OPT_OPR_PER_TC)) {
			CHECK_COND_RETVAL( index < dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size, -EINVAL);
		}
		opr = get_opr_info(dpni, tc_id, index);
	}
	else
	{
		CHECK_COND_RETVAL( opr_id < dpni->max_opr, -EINVAL);
		opr = &dpni->opr[opr_id].opr;
	}

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	
	err = query_opr(sw_portal, opr, cfg, qry);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);

	return err;
}

#ifndef OBSOLETED_SP_API
int dpni_load_sw_sequence(struct dpni *dpni, struct dpni_load_ss_cfg *cfg)
{
	int				err = 0;
	struct dpparser_sw_seq_info	ss_info;
	struct dpparser			*ss_parser;
	
	switch (cfg->dest) {
		case DPNI_SS_INGRESS:
			ss_parser = dpni->ing_dpparser;
			break;
		case DPNI_SS_EGRESS:
			ss_parser = dpni->egr_dpparser;
			break;
		default:
			break;
	}
	/* Built the SS info */
	ss_info.pc = cfg->ss_offset;
	ss_info.size = cfg->ss_size;
	ss_info.byte_code = (uint8_t*)cfg->ss_iova;
	err = dpparser_load_sw_seq(ss_parser, &ss_info);
	return err;
}

int dpni_enable_sw_sequence(struct dpni *dpni, struct dpni_enable_ss_cfg *cfg,
			    int set_start)
{
	int					err = 0;
	struct dpparser_sw_seq_profile_info	sp_info;
	struct dpparser				*sp_parser;
	int					sp_id = -1;
	
	switch (cfg->dest) {
		case DPNI_SS_INGRESS:
			sp_parser = dpni->ing_dpparser;
			if (dpni->is_ing_parser_id_allocated)
				sp_id = dpni->ing_parser_id;
			break;
		case DPNI_SS_EGRESS:
			sp_parser = dpni->egr_dpparser;
			if (dpni->is_ing_parser_id_allocated)
				sp_id = dpni->egr_parser_id;
			break;
		default:
			break;
	}
	CHECK_COND_RETVAL(sp_id >= 0, -EINVAL);
	if (!set_start && cfg->hxs != HXS_NULL) {
		/* Built the SS info */
		sp_info.hxs = (enum hxs_code)cfg->hxs;
		sp_info.start_pc = cfg->ss_offset;
		sp_info.param_array = (uint8_t*)cfg->param_iova;
		sp_info.param_offset = cfg->param_offset;
		sp_info.param_size = cfg->param_size;
		err = dpparser_enable_sw_seq(sp_parser, sp_id, NULL, &sp_info);
	}
	if (set_start) {
		err = dpparser_check_hxs(cfg->ss_offset);
		CHECK_COND_RETVAL(err == 0, err);
		/* Set the starting HXS to a soft sequence stating PC */
		if (cfg->ss_offset < sp_parser->min_pc ||
		    cfg->ss_offset > sp_parser->max_pc) {
			pr_err("ID[%d]: Starting HXS not in [0x%x, 0x%x]\n",
			       dpni->id, sp_parser->min_pc, sp_parser->max_pc);
			return -EINVAL;
		}
		switch (cfg->dest) {
			case DPNI_SS_INGRESS:
				dpni->ing_start_hxs = cfg->ss_offset;
				break;
			case DPNI_SS_EGRESS:
				dpni->egr_start_hxs = cfg->ss_offset;
				break;
			default:
				break;
		}
		if (cfg->param_size > 0) {
			/* Copy parameters */
			sp_info.hxs = HXS_NULL;
			sp_info.param_array = (uint8_t*)cfg->param_iova;
			sp_info.param_offset = cfg->param_offset;
			sp_info.param_size = cfg->param_size;
			err = dpparser_enable_sw_seq(sp_parser, sp_id, NULL,
						     &sp_info);
		}
	}
	return err;
}

int dpni_get_sw_sequence_layout(struct dpni *dpni,
				enum dpni_soft_sequence_dest src,
				struct dpni_sw_sequence_layout_entry *layout)
{
	int			err = 0, i;
	struct dpparser	*sp_parser;

	switch (src) {
		case DPNI_SS_INGRESS:
			sp_parser = dpni->ing_dpparser;
			break;
		case DPNI_SS_EGRESS:
			sp_parser = dpni->egr_dpparser;
			break;
		default:
			break;
	}
	for (i = 0; i < DPNI_SW_SEQUENCE_LAYOUT_SIZE; i ++) {
		layout[i].ss_offset =
				sp_parser->ss_layout->ss_entry[i].ss_offset;
		layout[i].ss_size = sp_parser->ss_layout->ss_entry[i].ss_size;
		layout[i].param_offset =
				sp_parser->ss_layout->ss_entry[i].param_offset;
		layout[i].param_size =
				sp_parser->ss_layout->ss_entry[i].param_size;
	}
	return err;
}
#endif	/* OBSOLETED_SP_API */

int dpni_set_sp_profile(struct dpni *dpni, uint8_t sp_profile[], uint8_t type)
{
	int err = 0;

	if (type & DPNI_SET_SP_PROFILE_INGRESS) {
		err = dpparser_is_valid_sp_profile_id(dpni->ing_dpparser, sp_profile);
		if (err != 0) {
			pr_err("Invalid SP Profile (not registered on ingress parser)\n");
			return -EINVAL;
		}
		if (!dpni->is_ing_parser_id_allocated) {
			pr_err("Setting SP Profile on DPNI cannot be done before DPNI initialization\n");
			return -EINVAL;
		}

		err = dpparser_init_profile(dpni->ing_dpparser,
						dpni->ing_parser_id, NULL,
						NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		
		/* Attach ingress soft parser */
		err = dpparser_attach_soft_parser(dpni->ing_dpparser, sp_profile, dpni->ing_parser_id,
							&dpni->ing_start_hxs, 0, NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		if (dpni->ing_start_hxs)
			pr_info("WRIOP INGRESS start HXS set to 0x%x\n", dpni->ing_start_hxs);

		memcpy(dpni->ing_sp_prof, sp_profile, MAX_SP_PROFILE_ID_SIZE);
		
		pr_info("BLOB: Soft Parser Profile: %s successfully attached on WRIOP Ingress dpni: %d \n", sp_profile, dpni->id);
	}
	if (type & DPNI_SET_SP_PROFILE_EGRESS) {
		err = dpparser_is_valid_sp_profile_id(dpni->egr_dpparser, sp_profile);
		if (err != 0) {
			pr_err("Invalid SP Profile (not registered on egress parser)\n");
			return -EINVAL;
		}
		if (!dpni->is_egr_parser_id_allocated) {
			pr_err("Setting SP Profile on DPNI cannot be done before DPNI initialization\n");
			return -EINVAL;
		}

		err = dpparser_init_profile(dpni->egr_dpparser,
						dpni->egr_parser_id, NULL,
						NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		
		/* Attach egress soft parser */
		err = dpparser_attach_soft_parser(dpni->egr_dpparser, sp_profile, dpni->egr_parser_id,
							&dpni->egr_start_hxs, 0, NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		if (dpni->egr_start_hxs)
			pr_info("WRIOP EGRESS start HXS set to 0x%x\n", dpni->egr_start_hxs);
		
		memcpy(dpni->egr_sp_prof, sp_profile, MAX_SP_PROFILE_ID_SIZE);

		pr_info("BLOB: Soft Parser Profile: %s successfully attached on WRIOP Egress dpni: %d \n", sp_profile, dpni->id);
	}
		
	return 0;
}

int dpni_linkman_event_cb(void *dev,
	const struct linkman_control *control,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	struct dpni *dpni;
	int err = 0;

	dpni = (struct dpni *)dev;

	err = endpoint_integrity(dpni, peer);
	CHECK_COND_RETVAL(err == 0, err);

	switch (peer->type) {
	case FSL_MOD_DPMAC:
		err = event_phys(dpni, control, self, peer, action);
		break;
	default:
		err = event_virt(dpni, control, self, peer, action);
		break;
	}

	/* Require completion notification */
	if (control->event == LINKMAN_EVENT_CONNECT ||
	    control->event == LINKMAN_EVENT_DISCONNECT)
		action->request = LINKMAN_REQUEST_COMPLETE_CB;

	return err;
}

int dpni_linkman_event_complete_cb(void *dev,
	const struct linkman_control *control,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action)
{
	struct dpni *dpni;
	int err = 0;

	dpni = (struct dpni *)dev;

	switch (control->event) {
	case LINKMAN_EVENT_NEGOTIATION_OK:
	case LINKMAN_EVENT_LINKUP:
		update_tx_shaping(dpni);
	case LINKMAN_EVENT_LINKDOWN:
		if(!dpni->restore.en)
		invoke_inter(dpni, DPNI_IRQ_INDEX,
				DPNI_IRQ_EVENT_LINK_CHANGED);
		break;
	case LINKMAN_EVENT_CONNECT:
		if( dpni->dpdmux ) {
			/* dpni endpoint is dpdmux
			 * update max frame length for dpdmux interface 0 to allow receiving
			 * update max frame length for dpni interface to allow sending */
			err = dpdmux_if_update_max_frame_len(dpni->dpdmux, 0, dpni->mfl);
			if( err ) pr_warn("dpni.%d: Failed to update max frame length for mux connection (if 0)\n");
			err = dpdmux_if_update_max_frame_len(dpni->dpdmux, dpni->dpdmux_if_id, dpni->mfl);
			if( err ) pr_warn("dpni.%d: Failed to update max frame length for mux connection (if %d)\n", dpni->dpdmux_if_id);
		}
	case LINKMAN_EVENT_DISCONNECT:
		if(!dpni->restore.en)
		invoke_inter(dpni, DPNI_IRQ_INDEX,
			     DPNI_IRQ_EVENT_ENDPOINT_CHANGED);
		break;
	default:
		break;
	}

	return err;
}

int dpni_set_rx_fs_dist(struct dpni *dpni, uint8_t tc_id, struct dpni_rx_dist_cfg *cfg)
{
	int fs_prev_status, hash_enable;
	struct dpni_rx_tc_dist_cfg tc_cfg = {0};
	struct qbman_swp *sw_portal;
	int err = 0;

	CHECK_COND_RETVAL(cfg->tc_id <= dpni->max_rx_tcs, -EINVAL,
			"ID[%d]: tc_id max value is %d", dpni->id, dpni->max_rx_tcs );

	err = cfg->enable && !is_dist_size_supported(cfg->dist_size);
	CHECK_COND_RETVAL(err == 0, -EINVAL,
			"ID[%d]: dist_size (%d) isn't supported\n", dpni->id, cfg->dist_size);

	CHECK_COND_RETVAL(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_fs_entries>0, -EINVAL,
			"ID[%d]: can't create FS table for tc %d as max_fs_entries == 0\n", dpni->id, tc_id );

	err = cfg->enable && cfg->dist_size==0;
	CHECK_COND_RETVAL(err == 0, -EINVAL,
			"ID[%d]: When FS is enabled dist_size must be greater than zero", dpni->id);

	err = cfg->dist_size > dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size;
	CHECK_COND_RETVAL(err == 0, -EINVAL,
			"ID[%d]: dist_size for FS distribution must be smaller than %d", dpni->id, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size);

	if (IS_SHARED_FS_ENABLED) {
		pr_debug( "ID[%d]: DPNI_OPT_SHARED_FS is set. rx_fs_dist configuration for tc[%d] will not overwrite the shared fs table config.\n",
			dpni->id, tc_id);
	}

	/* If shared fs is used, then each time this function is invoked with a different tc than 0,
	 * the tc[0] existing configuration will be overwritten with the one that corresponds to the tc given as an argument.
	 * This needs to be done in case the qos table is initialized before the fs table.  Although the tc will have rx queues associated with it,
	 * it is not considered valid from shared fs perspective. The consequence of this is that no entries that belong to a different tc than 0 can be added
	 * in the fs table. The condition that prevents the adding of fs entires, is  rx_tc[i].valid has a value of 0 for i > 0.
	 * It means that all the functions that try to update the shared fs and use a tc different than 0, will return with an error
	 * if tc is not valid.
	 * A tc has the possibility to become valid  in one of the functions: dpni_set_rx_hash_dist,dpni_set_rx_fs_dist,dpni_set_rx_tc_dist.
	 * To summarize :for the shared fs the followed code path in the afforementioned functions will trigger the validation of tc=0 only.
	 */
	if (IS_SHARED_FS_ENABLED && tc_id) {
		pr_debug("dpni_set_rx_fs_dist setting only the qpr for tc [%d]\n", tc_id);
	}

	err = (cfg->flow_id != DPNI_FS_DROP) && (cfg->flow_id > dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size);
	CHECK_COND_RETVAL(err == 0, -EINVAL,
			"ID[%d]: flow_id for FS distribution must be smaller than %d", dpni->id, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size);

	if( cfg->key_changed ) {
		memcpy(&dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_key, cfg->dist_key_cfg, sizeof(struct dpkg_profile_cfg));
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_key_available = 1;
	}

	err = cfg->enable && !dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_key_available;
	CHECK_COND_RETVAL(err == 0, -EINVAL,
			"ID[%d]: FS key not set. On first call dpni_set_rx_fs_dist() with enable set to 1 must provide a FS key", dpni->id);

	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.default_queue = cfg->flow_id;

	fs_prev_status = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_enable;
	hash_enable = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_enable;

	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_enable = cfg->enable;
	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_size = cfg->dist_size;

	if( fs_prev_status ) {
		if( !cfg->enable ) {
			if( hash_enable ) {
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode = DPNI_DIST_MODE_HASH;
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_dist_size;

				tc_cfg.dist_mode = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode;
				tc_cfg.dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size;
				delete_fs_table(dpni, (uint8_t)SELECT_TC_SHARED_FS(tc_id), &tc_cfg);
				/* validate only tc 0 for shared fs case */
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].valid = 0;
				modify_qos_entries(dpni, tc_id, &tc_cfg);
			} else {
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode = DPNI_DIST_MODE_NONE;
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = 1;//cfg->dist_size;

				tc_cfg.dist_mode = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode;
				tc_cfg.dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size;
				modify_qos_entries(dpni, tc_id, &tc_cfg);

				delete_fs_table(dpni, SELECT_TC_SHARED_FS(tc_id), &tc_cfg);
				/* validate only tc 0 for shared fs case */
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].valid = 0;

				/* Enable SET_QDBIN flag for default QoS rule */
				dpni->qos.default_action.options |= DPTBL_ACTION_SET_QDBIN;
				update_pass_through_qos(dpni);
			}
		}
	}

	if( cfg->enable ) {
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode = DPNI_DIST_MODE_FS;
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = cfg->dist_size;

		tc_cfg.dist_mode = DPNI_DIST_MODE_FS;
		tc_cfg.dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size;
		tc_cfg.fs_cfg.keep_entries = 1;
		if( hash_enable ) {
			tc_cfg.fs_cfg.miss_action = DPNI_FS_MISS_HASH;
			tc_cfg.fs_cfg.keep_hash_key = 1;
			tc_cfg.dist_key_cfg = &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_dist_key;
			modify_extraction_hash(dpni, tc_id, &tc_cfg);
		} else if( dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.default_queue == DPNI_FS_DROP ) {
			tc_cfg.fs_cfg.miss_action = DPNI_FS_MISS_DROP;
		} else {
			tc_cfg.fs_cfg.miss_action = DPNI_FS_MISS_EXPLICIT_FLOWID;
			tc_cfg.fs_cfg.default_flow_id = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.default_queue;
		}
		tc_cfg.dist_key_cfg = cfg->dist_key_cfg;
		set_fs_table(dpni, SELECT_TC_SHARED_FS(tc_id), &tc_cfg);
		modify_qos_entries(dpni, tc_id, &tc_cfg);
		/* validate only tc 0 for shared fs case */
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].valid = 1;

		/* Disable SET_QDBIN flag for QoS default rule */
		dpni->qos.default_action.options &= ~DPTBL_ACTION_SET_QDBIN;
		update_pass_through_qos(dpni);
	}

	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_qpr_configure(sw_portal,
				(uint16_t)dpni->tc_rx[tc_id].qprid,
				(uint32_t)dpni->tc_rx[tc_id].fqid_base,
				(uint16_t)dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size,
				(uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d]: qbman_qpr_configure failed for qprid\n", dpni->id);
		return err;
	}

	return 0;
}

int dpni_set_rx_hash_dist(struct dpni *dpni, uint8_t tc_id, struct dpni_rx_dist_cfg *cfg)
{
	int hash_prev_status, fs_enable;
	struct dpni_rx_tc_dist_cfg tc_cfg = {0};
	struct qbman_swp *sw_portal;
	int err = 0;

	CHECK_COND_RETVAL(cfg->tc_id <= dpni->max_rx_tcs, -EINVAL,
			"ID[%d]: tc_id max value is %d", dpni->id, dpni->max_rx_tcs );

	err = cfg->enable && !is_dist_size_supported(cfg->dist_size);
	CHECK_COND_RETVAL(err == 0, -EINVAL,
			"ID[%d]: dist_size (%d) isn't supported\n", dpni->id, cfg->dist_size);

	err = cfg->enable && cfg->dist_size==0;
	CHECK_COND_RETVAL(err == 0, -EINVAL,
			"ID[%d]: When HASH is enabled dist_size must be greater than zero", dpni->id);

	if (IS_SHARED_FS_ENABLED) {
		pr_debug( "ID[%d]: DPNI_OPT_SHARED_FS is set. rx_hash_dist configuration for tc[%d] will not overwrite the shared fs table config.\n",
			dpni->id, tc_id);
	}

	/* If shared fs is used, then each time this function is invoked with a different tc than 0,
	 * the tc[0] existing configuration will be overwritten with the one that corresponds to the tc given as an argument.
	 * This needs to be done in case the qos table is initialized before the fs table.  Although the tc will have rx queues associated with it,
	 * it is not considered valid from shared fs perspective. The consequence of this is that no entries that belong to a different tc than 0 can be added
	 * in the fs table. The condition that prevents the adding of fs entires, is  rx_tc[i].valid has a value of 0 for i > 0.
	 * It means that all the functions that try to update the shared fs and use a tc different than 0, will return with an error
	 * if tc is not valid.
	 * A tc has the possibility to become valid  in one of the functions: dpni_set_rx_hash_dist,dpni_set_rx_fs_dist,dpni_set_rx_tc_dist.
	 * To summarize :for the shared fs the followed code path in the afforementioned functions will trigger the validation of tc=0 only.
	 */
	if (IS_SHARED_FS_ENABLED && tc_id) {
		pr_debug("dpni_set_rx_hash_dist setting only the qpr for tc[%d]\n", tc_id);
	}

	err = cfg->dist_size > dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size;
	CHECK_COND_RETVAL(err == 0, -EINVAL,
			"ID[%d]: dist_size for FS distribution must be smaller than %d", dpni->id, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].max_dist_size);

	if( cfg->key_changed ) {
		memcpy(&dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_dist_key, cfg->dist_key_cfg, sizeof(struct dpkg_profile_cfg));
		dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_key_available = 1;
	}

	err = cfg->enable && !dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_key_available;
	CHECK_COND_RETVAL(err == 0, -EINVAL,
			"ID[%d]: Hash key not set. On first call call dpni_set_rx_hash_dist() with enable set to 1 must provide a HASH key", dpni->id);

	hash_prev_status = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_enable;
	fs_enable = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_enable;

	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_enable = cfg->enable;
	dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.hash_dist_size = cfg->dist_size;

	if( hash_prev_status ) {
		if( !cfg->enable ) {
			if( fs_enable ) {
				// DPNI_DIST_MODE_FS
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode = DPNI_DIST_MODE_FS;
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_size;

				tc_cfg.dist_mode = DPNI_DIST_MODE_FS;
				tc_cfg.dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size;
				if( dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.default_queue==DPNI_FS_DROP ) {
					tc_cfg.fs_cfg.miss_action = DPNI_FS_MISS_DROP;
				} else {
					tc_cfg.fs_cfg.miss_action = DPNI_FS_MISS_EXPLICIT_FLOWID;
					tc_cfg.fs_cfg.default_flow_id = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.default_queue;
				}
				tc_cfg.dist_key_cfg = &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_key;
				set_fs_table(dpni, SELECT_TC_SHARED_FS(tc_id), &tc_cfg);
				modify_qos_entries(dpni, tc_id, &tc_cfg);
				/* validate only tc 0 for shared fs case */
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].valid = 1;
			} else {
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode = DPNI_DIST_MODE_NONE;
				dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = 1;

				modify_qos_entries(dpni, tc_id, NULL);

				/* Enable SET_QDBIN flag for default QoS rule */
				dpni->qos.default_action.options |= DPTBL_ACTION_SET_QDBIN;
				update_pass_through_qos(dpni);
			}
		}
	}

	if( cfg->enable ) {
		if( fs_enable ) {
			// DPNI_DIST_MODE_FS and DPNI_FS_MISS_HASH
			dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode = DPNI_DIST_MODE_FS;
			dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = cfg->dist_size;

			tc_cfg.dist_mode = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode;
			tc_cfg.dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size;
			tc_cfg.dist_key_cfg = cfg->dist_key_cfg;
			modify_extraction_hash(dpni, tc_id, &tc_cfg);

			tc_cfg.fs_cfg.miss_action = DPNI_FS_MISS_HASH;
			tc_cfg.fs_cfg.keep_hash_key = 1;
			tc_cfg.dist_key_cfg = &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_cfg.fs_dist_key;
			set_fs_table(dpni, SELECT_TC_SHARED_FS(tc_id), &tc_cfg);
			modify_qos_entries(dpni, tc_id, &tc_cfg);
			/* validate only tc 0 for shared fs case */
			dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].valid = 1;
		} else {
			// DPNI_DIST_MODE_HASH
			dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode = DPNI_DIST_MODE_HASH;
			dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size = cfg->dist_size;

			tc_cfg.dist_mode = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_mode;
			tc_cfg.dist_size = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size;
			tc_cfg.dist_key_cfg = cfg->dist_key_cfg;
			if( hash_prev_status ) {
				modify_extraction_hash(dpni, SELECT_TC_SHARED_FS(tc_id), &tc_cfg);
			} else {
				modify_extraction_hash(dpni, SELECT_TC_SHARED_FS(tc_id), &tc_cfg);
				modify_qos_entries(dpni, tc_id, &tc_cfg);
			}
			dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].valid = 1;

			/* Disable SET_QDBIN flag for QoS default rule */
			dpni->qos.default_action.options &= ~DPTBL_ACTION_SET_QDBIN;
			update_pass_through_qos(dpni);
		}
	}


	dpmng_get_swportal(dpni->dpmng, (void**)&sw_portal);
	err = qbman_qpr_configure(sw_portal,
				(uint16_t)dpni->tc_rx[tc_id].qprid,
				(uint32_t)dpni->tc_rx[tc_id].fqid_base,
				(uint16_t)dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].dist_size,
				(uint32_t)dpni->rx_tx_conf_cgids[dpni->tc_rx[tc_id].cgid_index].cgid);
	dpmng_put_swportal(dpni->dpmng, (void*)sw_portal);
	if (err != 0) {
		pr_err("ID[%d]: qbman_qpr_configure failed for qprid\n", dpni->id);
		return err;
	}

	return 0;
}


int dpni_add_custom_tpid(struct dpni *dpni, uint16_t tpid)
{
	int err = 0;

	err = !dpni->is_egr_parser_id_allocated;
	CHECK_COND_RETVAL( err == 0 , -EACCES, "Could not set tpid %04x for ingress\n", tpid);

	/* Ingress */
	err = dpparser_add_tpid(dpni->ing_dpparser,
				dpni->ing_parser_id,
				NULL, tpid);
	CHECK_COND_RETVAL(err == 0, err, "Could not set tpid %04x for ingress\n", tpid);

	/* Egress */
	err = dpparser_add_tpid(dpni->egr_dpparser,
				dpni->egr_parser_id,
				NULL, tpid);
	CHECK_COND_RETVAL(err == 0, err, "Could not set tpid %04x for egress\n", tpid);

	return err;
}


int dpni_remove_custom_tpid(struct dpni *dpni, uint16_t tpid)
{
	int err = 0;

	/* Ingress */
	err = dpparser_remove_tpid(dpni->ing_dpparser,
				dpni->ing_parser_id,
				NULL, tpid);
	CHECK_COND_RETVAL(err == 0, err, "Could not remove tpid %04x for ingress\n", tpid);

	/* Egress */
	err = dpparser_remove_tpid(dpni->egr_dpparser,
				dpni->egr_parser_id,
				NULL, tpid);
	CHECK_COND_RETVAL(err == 0, err, "Could not remove tpid %04x for egress\n", tpid);

	return err;
}


int dpni_get_custom_tpid(struct dpni *dpni, struct dpni_custom_tpid *tpid)
{
	int err = 0;

	dpparser_get_tpid(dpni->ing_dpparser,
			dpni->ing_parser_id,
			&tpid->tpid1, &tpid->tpid2);

	return err;
}

int dpni_set_port_cfg(struct dpni *dpni, uint32_t flags, struct dpni_port_cfg *port_cfg)
{
	CHECK_COND_RETVAL(dpni->dpmac!=NULL, -ENODEV,
			"ID[%d]: dpni_set_port_cfg() works only if dpni is connected to a dpmac object\n");

	if( flags & DPNI_PORT_CFG_LOOPBACK ) {
		dpmac_set_loopback(dpni->dpmac, port_cfg->loopback_en);
	}

	return 0;
}

int dpni_get_port_cfg(struct dpni *dpni, struct dpni_port_cfg *port_cfg)
{
	int err;

	CHECK_COND_RETVAL(dpni->dpmac!=NULL, -ENODEV,
			"ID[%d]: dpni_set_port_cfg() works only if dpni is connected to a dpmac object\n");

	err = dpmac_get_loopback(dpni->dpmac, &port_cfg->loopback_en);
	CHECK_COND_RETVAL(err==0, err, "ID[%d]: dpmac_get_loopback() return error\n");

	return 0;
}

int dpni_set_single_step_cfg(struct dpni *dpni, struct dpni_single_step_cfg *ptp_cfg)
{
	CHECK_COND_RETVAL(ptp_cfg->enable && ptp_cfg->offset!=0, -EINVAL,
			"ID[%d] offset cannot be zero if PTP_v2 is enabled\n", dpni->id);

	memcpy(&dpni->single_step_cfg, ptp_cfg, sizeof(struct dpni_single_step_cfg));

	update_mac_single_step_config(dpni, ptp_cfg);

	return 0;
}
	
int dpni_get_single_step_cfg(struct dpni *dpni, struct dpni_single_step_cfg *ptp_cfg)
{
	memcpy(ptp_cfg, &dpni->single_step_cfg, sizeof(struct dpni_single_step_cfg));

	return 0;
}

static int get_action_result(struct dpni *dpni, struct dptbl_action action, uint16_t table_type, uint16_t *result) {
	int err = 0, t;
	int tid;

	if (table_type == DPNI_FS_TABLE) {
		result[0] = 0;
		result[1] = (uint16_t)action.qd_bin;
		result[2] = 0;
	}
	else if (table_type == DPNI_MAC_TABLE) {
		dptbl_get_tbl_id(dpni->filters.mac_tbl, &tid);
		if(action.lookup_params.dptbl_id == tid) {
			result[0] = DPNI_MAC_TABLE;
			result[1] = 0;
			result[2] = 0;
		}

		dptbl_get_tbl_id(dpni->filters.vlan_tbl, &tid);
		if(action.lookup_params.dptbl_id == tid) {
			result[0] = DPNI_VLAN_TABLE;
			result[1] = 0;
			result[2] = 0;
		}

		dptbl_get_tbl_id(dpni->qos.tbl, &tid);
		if(action.lookup_params.dptbl_id == tid) {
			result[0] = DPNI_QOS_TABLE;
			result[1] = 0;
			result[2] = 0;
		}

		if (IS_SHARED_FS_ENABLED) {
			result[0] = DPNI_FS_TABLE;
			result[1] = 0;
			result[2] = 1;
		}
		else {
			for (t = 0; t < DPNI_MAX_RX_TC; t++) {
				dptbl_get_tbl_id(dpni->tc_rx[t].fs_tbl, &tid);
				if (action.lookup_params.dptbl_id == tid) {
					result[0] = DPNI_FS_TABLE;
					result[1] = (uint16_t)t;
					result[2] = 0;
					break;
				}
			}
		}
	}
	else if (table_type == DPNI_QOS_TABLE) {
		if (action.next_action == DPTBL_ACTION_LOOKUP) {
			if (IS_SHARED_FS_ENABLED) {
				result[0] = DPNI_FS_TABLE;
				result[1] = 0;
				result[2] = 1;
			}
			else {
				for (t = 0; t < DPNI_MAX_RX_TC; t++) {
					dptbl_get_tbl_id(dpni->tc_rx[t].fs_tbl, &tid);
					if (action.lookup_params.dptbl_id == tid) {
						result[0] = DPNI_FS_TABLE;
						result[1] = (uint16_t)t;
						result[2] = 0;
						break;
					}
				}
			}
		}
		else {
			result[0] = 0;
			result[1] = (uint16_t)action.qd_bin;
			result[2] = (uint16_t)action.qpri;
		}
	}
	else if (table_type == DPNI_VLAN_TABLE) {
		result[0] = DPNI_QOS_TABLE;
		result[1] = 0;
		result[2] = 0;
	}
	else {
		pr_err("Invalid table type\n");
		err = -EINVAL;
	}

	return err;
}

int dpni_dump_table(struct device *dev, uint16_t table_type, uint16_t table_index, uint64_t iova_addr, int iova_size, uint16_t *table_size)
{
	int err = 0, i;
	int table_num_entries;
	int table_max_entries;
	int real_key_size;
	int match_type;
	int remaining_bytes;
	uint32_t header_size;
	uint32_t entry_size;
	uint32_t max_entries;
	struct dpni *dpni;
	struct dump_table_header header;
	struct dump_table_entry *entries;
	struct dptbl *tbl;
	struct dptbl_action action;
	struct dptbl_rule rule;

	*table_size = 0;

	dpni = device_get_priv(dev);
	CHECK_COND_RETVAL(dpni, -ENODEV);

	header_size = sizeof(struct dump_table_header);
	entry_size = sizeof(struct dump_table_entry);

	remaining_bytes = iova_size;
	CHECK_COND_RETVAL( remaining_bytes>=header_size, -EINVAL, "[ID%d] Not enough space to store header\n", dpni->id);

	max_entries = (remaining_bytes - header_size) / entry_size;

	if (table_type == DPNI_FS_TABLE) {
		if( IS_SHARED_FS_ENABLED && (table_index != SELECT_TC_SHARED_FS(table_index)) ) {
			pr_warn("DPNI.%d has a shared FS table, set table_index to default\n");
			table_index = SELECT_TC_SHARED_FS(table_index);
		}

		if (!dpni->tc_rx[table_index].fs_tbl_is_valid) {
			pr_err("The FS table from DPNI %d is not enabled for TC %d\n", dpni->id, table_index);
			return -EINVAL;
		}

		tbl = dpni->tc_rx[table_index].fs_tbl;
	}
	else if (table_type == DPNI_QOS_TABLE) {
		if (!dpni->qos.valid) {
			pr_err("The QOS table from DPNI %d is not enabled\n", dpni->id);
			return -EINVAL;
		}

		tbl = dpni->qos.tbl;
	}
	else if (table_type == DPNI_MAC_TABLE) {
		tbl = dpni->filters.mac_tbl;
	}
	else if (table_type == DPNI_VLAN_TABLE) {
		if (!dpni->filters.vlan_enable) {
			pr_err("The VLAN table from DPNI %d is not enabled\n", dpni->id, table_index);
			return -EINVAL;
		}

		tbl = dpni->filters.vlan_tbl;
	}
	else {
		pr_err("Invalid table type\n");
		return -EINVAL;
	}

	dptbl_get_num_of_used_rules(tbl, &table_num_entries);
	dptbl_get_num_of_max_rules(tbl, &table_max_entries);
	dptbl_get_tbl_type(tbl, &match_type);
	// get default action

	memset(&header, 0, header_size);
	header.table_type = table_type;
	header.match_type = (uint8_t)match_type;
	header.table_num_entries = (uint16_t)table_num_entries;
	header.table_max_entries = (uint16_t)table_max_entries;
	// set default action in header

	err = dpmng_dev_memcpy(dev, &header, iova_addr, header_size, 0);
	if (err) {
		pr_err("Error writing extended DMA parameters\n");
		return err;
	}

	remaining_bytes -= header_size;
	iova_addr += header_size;
	*table_size = 0;

	entries = (struct dump_table_entry *)fsl_malloc(max_entries * entry_size);
	CHECK_COND_RETVAL(entries, -ENOMEM);
	memset(entries, 0, max_entries * entry_size);

	err = dptbl_query(tbl, entries, (int)max_entries, table_size);
	if (err) {
		pr_err("Error in dptbl_query for dpdmux@%d\n", dpni->id);
		fsl_free(entries);
		return err;
	}

	for (i = 0; i < *table_size; i++) {
		memset(&rule, 0, sizeof(struct dptbl_rule));

		if ((table_type == DPNI_FS_TABLE && (dpni->options & DPNI_OPT_FS_MASK_SUPPORT)) ||
				(table_type == DPNI_QOS_TABLE && (dpni->options & DPNI_OPT_QOS_MASK_SUPPORT))){
			rule.rule_cfg.masked.key = entries[i].key;
			rule.rule_cfg.masked.mask = entries[i].mask;
			rule.rule_cfg.masked.priority = entries[i].rule_index;
			dptbl_get_real_key_size(tbl, &real_key_size);
			rule.rule_cfg.masked.size = (uint32_t)real_key_size;
		}
		else {
			rule.rule_cfg.exact.key = entries[i].key;
			dptbl_get_real_key_size(tbl, &real_key_size);
			rule.rule_cfg.exact.size = (uint32_t)real_key_size;
		}

		memset(&action, 0x0, sizeof(struct dptbl_action));
		err = dptbl_get_action(tbl, &rule, &action);
		if(err) {
			pr_err("Error getting key action\n");
			continue;
		}

		entries[i].key_action = action.next_action;

		err = get_action_result(dpni, action, table_type, entries[i].result);
		if (err) {
			pr_err("Error getting action result\n");
			continue;
		}

		err = dpmng_dev_memcpy(dev, &entries[i], iova_addr, entry_size, 0);
		if (err) {
			pr_err("Error writing extended DMA parameters\n");
			fsl_free(entries);
			return err;
		}

		iova_addr += entry_size;
	}

	fsl_free(entries);
	return err;
}

#ifdef TKT011436 
static int dpni_restore_promisc(struct dpni *dpni)
{
	struct dppolicy_rule rule;
	struct dppolicy_action action;
	int err;

	/* By default, unicast promsic is disabled and dpni->multicast_promisc_en = 1 to be used
	 * at add VLAN -> DPDMUX
	 */

	if (!dpni->multicast_promisc_en) {
		pr_debug("Disable multicast promisc, by default is enabled, this is a configuration from runtime\n");
		memset(&rule, 0, sizeof(struct dppolicy_rule));
		memset(&action, 0, sizeof(struct dppolicy_action));
		rule.priority = DPNI_POLICY_PRI_MULTICAST;
		rule.num_of_identifiers = 1;
		rule.identifiers[0].exclude = 0;
		rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT_OPT;
		rule.identifiers[0].prot = NET_PROT_ETH;
		rule.identifiers[0].opt = NH_OPT_ETH_MULTICAST;

		if (dpni->options & DPNI_OPT_MULTICAST_FILTER) {
			action.next_action = DPPOLICY_ACTION_LOOKUP;
			action.lookup_params.dpkg_profile_id =
				dpni->filters.mac_kid;
			dptbl_get_id(
				dpni->filters.mac_tbl,
				&action.lookup_params.dptbl_id);
		} else {
			action.next_action = DPPOLICY_ACTION_DONE;
			action.options =
				DPPOLICY_ACTION_SET_DISCARD_FLAG;
		}

		err = dppolicy_modify_rule(dpni->policy, &rule, &action);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err, "dppolicy_modify_rule Failed\n");

/*
		if (dpni->dpdmux)
			update_dpdmux_multicast_promisc(dpni);
*/
	}
	
	if (dpni->unicast_promisc_en) {
		pr_debug("Enable unciast promisc, by default is disabled, this is a configuration from runtime\n");
		memset(&rule, 0, sizeof(struct dppolicy_rule));
		memset(&action, 0, sizeof(struct dppolicy_action));
		rule.priority = DPNI_POLICY_PRI_MULTICAST;
		rule.num_of_identifiers = 1;
		rule.identifiers[0].exclude = 0;
		rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT_OPT;
		rule.identifiers[0].prot = NET_PROT_ETH;
		rule.identifiers[0].opt = NH_OPT_ETH_UNICAST;

		copy_dptbl_to_dppolicy(&dpni->filters.mac_allow_action,
					&action);

		err = dppolicy_modify_rule(dpni->policy, &rule, &action);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err, "dppolicy_modify_rule Failed\n");
/*
		if (dpni->dpdmux)
			update_dpdmux_unicast_promisc(dpni);
*/
	}

	return 0;
}

static int restore_runtime_config(struct dpni *dpni)
{
	
	struct dpni_table_rule *mac_table_rules = dpni->filters.mac_addrs;
	struct dpni_table_rule *tbl_rule;
	struct dptbl_rule rule;
	struct dptbl_action next_action;
	int i = 0, index_key = 0, err, iter = 0, nr_rules = 0;
	uint8_t tc_id = 0;
	
	pr_info("ID[%d] Restore runtime configuration\n", dpni->id);
	/************** MAC table ****************/
	pr_debug("ID[%d]Restore MAC table rules\n", dpni->id);
	if (dpni->options & DPNI_OPT_SHARED_MAC_TABLE)
		nr_rules = dpni->filters.num_mac_filters;
	else
		nr_rules = dpni->filters.num_unicast_filters +
					dpni->filters.num_multicast_filters;
	if(nr_rules){
		for (i = 0; ((i < DPNI_MAX_MAC_FILTERS) && (iter < nr_rules)); i++) {
			if (!mac_table_rules[i].in_use)
				continue;
			iter++;
			memset(&next_action, 0, sizeof(struct dptbl_action));
			/* get action */
			if(is_mac_table_custom_rule(&mac_table_rules[i]))
				memcpy(&next_action, &mac_table_rules[i].action, sizeof(struct dptbl_action));
			else 
				memcpy(&next_action, &dpni->filters.mac_allow_action, sizeof(struct dptbl_action));

			/* get rule */
			memset(&rule, 0, sizeof(struct dptbl_rule));
			mac_dptbl_rule_create_cb(&mac_table_rules[i], &rule);
			
			/* add rule */
			err = dptbl_add_rule(dpni->filters.mac_tbl, &rule,
						&next_action, dpni->restore.en);
			CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err, "dptbl_add_rule Failed\n");

		}
	}
	/**************Unicast + Multicast Promisc ******************************/
	err = dpni_restore_promisc(dpni);
	CHECK_COND_RETVAL(err == 0, err, "dpni_restore_promisc Failed\n");
	
	memset(&rule, 0, sizeof(struct dptbl_rule));
	memset(&next_action, 0, sizeof(struct dptbl_action));
	iter = 0;
	pr_debug("ID[%d]Restore FS table rules\n", dpni->id);
	/*********************** FS table *************************************/
	for (tc_id = 0; tc_id < DPNI_MAX_RX_TC; tc_id++)
	{
		err = restore_rx_fs_hash_dist(dpni, tc_id);
		CHECK_COND_RETVAL(err == 0, err, "restore_rx_fs_hash_dist Failed\n");
		nr_rules = dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].num_fs_entries;
		if(nr_rules){
			iter = 0;
			for (index_key = 0; ((index_key < DPNI_MAX_FS_ENTRIES) && (iter < nr_rules)); index_key++) {
				/*tbl_rule = get_rule(dpni, dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys, 
							(void*)&dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[index_key].key_params,
							qos_fs_rule_match_cb);
				*/
				/* restore all rules that were in use before WRIOP reset */
				if(!dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[index_key].in_use)
					continue;
				iter++;
				tbl_rule = &dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].keys[index_key];

				/* build the rule */                                                                                                                                                                                                              
				memset(&rule, 0, sizeof(struct dptbl_rule));
				if((dpni->options & DPNI_OPT_FS_MASK_SUPPORT) && tbl_rule->rule.key_cfg.maskable){
					rule.rule_cfg.masked.key = tbl_rule->rule.key_cfg.key;
					rule.rule_cfg.masked.mask = tbl_rule->rule.key_cfg.mask;
					rule.rule_cfg.masked.size = tbl_rule->rule.key_cfg.size;
				} else {
					rule.rule_cfg.exact.key = tbl_rule->rule.key_cfg.key;
					rule.rule_cfg.exact.size = tbl_rule->rule.key_cfg.size;
				}
				rule.rule_cfg.masked.priority = tbl_rule->rule.key_cfg.priority;
				/* get action */
				memset(&next_action, 0, sizeof(struct dptbl_action));
				memcpy(&next_action, &tbl_rule->action, sizeof(struct dptbl_action));

				/* restore the rule in hardware */
				err = dptbl_add_rule(dpni->tc_rx[SELECT_TC_SHARED_FS(tc_id)].fs_tbl, &rule, &next_action, dpni->restore.en);
				if (err) {
					remove_rule(dpni, tbl_rule, NULL, NULL, NULL);
					pr_err("ID[%d]: Failed to restore FS entry\n", dpni->id);
					return err;
				}
			}
		}
	}
	
	memset(&rule, 0, sizeof(struct dptbl_rule));
	memset(&next_action, 0, sizeof(struct dptbl_action));
	iter = 0;
	pr_debug("ID[%d]Restore QOS table rules\n", dpni->id);

	/************************ QoS table **********************************/
	err = dpni_restore_qos_table(dpni);
	CHECK_COND_RETVAL(err == 0, err, "dpni_restore_qos_table Failed\n");

	nr_rules = dpni->qos.num_qos_entries;
	if(nr_rules){
		iter = 0;
		for (index_key = 0; ((index_key < DPNI_MAX_QOS_ENTRIES) && (iter < nr_rules)); index_key++) {
			//tbl_rule = get_rule(dpni, dpni->tc_rx[tc_id].keys, (void*)&dpni->tc_rx[tc_id].keys[index_key].key_params,
			//			qos_fs_rule_match_cb);
			/* restore all rules that were in use before WRIOP reset */
			if(!dpni->qos.keys[index_key].in_use)
				continue;
			iter++;
			tbl_rule = &dpni->qos.keys[index_key];
			/* build the rule */
			memset(&rule, 0, sizeof(struct dptbl_rule));
			if((dpni->options & DPNI_OPT_QOS_MASK_SUPPORT) && tbl_rule->rule.key_cfg.maskable){
				rule.rule_cfg.masked.key = tbl_rule->rule.key_cfg.key;
				rule.rule_cfg.masked.mask = tbl_rule->rule.key_cfg.mask;
				rule.rule_cfg.masked.size = tbl_rule->rule.key_cfg.size;
			} else {
				rule.rule_cfg.exact.key = tbl_rule->rule.key_cfg.key;
				rule.rule_cfg.exact.size = tbl_rule->rule.key_cfg.size;
			}
			rule.rule_cfg.masked.priority = tbl_rule->rule.key_cfg.qos_priority;
			/* get action */
			memset(&next_action, 0, sizeof(struct dptbl_action));
			memcpy(&next_action, &tbl_rule->action, sizeof(struct dptbl_action));

			/* restore the rule in hardware */
			err = dptbl_add_rule(dpni->qos.tbl, &rule, &next_action, dpni->restore.en);
			if (err) {
				remove_rule(dpni, tbl_rule, NULL, NULL, NULL);
				pr_err("ID[%d]: Failed to restore QoS entry\n", dpni->id);
				return err;
			}		
		}
	}

	memset(&rule, 0, sizeof(struct dptbl_rule));
	memset(&next_action, 0, sizeof(struct dptbl_action));
	iter = 0;
	pr_debug("ID[%d]Restore VLAN table rules\n", dpni->id);
	/************************ VLAN rules ************************************/
	nr_rules = dpni->filters.num_vlan_filters;
	if(nr_rules){
		iter = 0;
		for (index_key = 0; ((index_key < DPNI_MAX_VLAN_FILTERS) && (iter < nr_rules)); index_key++) {
			//tbl_rule = get_rule(dpni, dpni->tc_rx[tc_id].keys, (void*)&dpni->tc_rx[tc_id].keys[index_key].key_params,
			//			qos_fs_rule_match_cb);
			/* restore all rules that were in use before WRIOP reset */
			if(!dpni->filters.vlans[index_key].in_use)
				continue;
			iter++;
			tbl_rule = &dpni->filters.vlans[index_key];
			/* build the rule */
			memset(&rule, 0, sizeof(struct dptbl_rule));
			rule.rule_cfg.exact.key = tbl_rule->rule.vlan_key;
			rule.rule_cfg.exact.size = tbl_rule->rule.key_cfg.size;
			/* get action */
			memset(&next_action, 0, sizeof(struct dptbl_action));
			memcpy(&next_action, &tbl_rule->action, sizeof(struct dptbl_action));

			/* restore the rule in hardware */
			err = dptbl_add_rule(dpni->filters.vlan_tbl, &rule, &next_action, dpni->restore.en);
			if (err) {
				remove_rule(dpni, tbl_rule, NULL, NULL, NULL);
				pr_err("ID[%d]: Failed to restore VLAN entry\n", dpni->id);
				return err;
			}		
		}
	}
	/*************** Enable Vlan if was enabled ************************************/
	if(dpni->filters.vlan_enable)
		dpni_enable_vlan_filter(dpni, dpni->filters.vlan_enable);

	return err;
}

static int dpni_restore_ctlu( struct dpni *dpni)
{
	struct dpkg_profile_cfg kg_cfg;
	struct dptbl_cfg tbl_cfg;
	struct dptbl_rule rule;
	struct dptbl_action action, next_action;
#ifdef TKT508412
	struct dptbl_cfg multicast_tbl_cfg;
#endif
	uint8_t no_vlan_key[] = { 0, 0, 0 };
	int err, i;

	/* FLOW: 'start'->MAC_Filters->VLAN_Filters->QoS (->FS->hash)
	 * create the flow in reverse order */

	/* this is used to set up a default entry in classification tables
	 * until the user sets up key composition rules, entries.
	 */
	
	pr_debug("DPNI[%d] restore CTLU\n", dpni->id);

	/* set up a dummy 1 byte key for now, can be replaced by the
	 * user.  This is used both for FS and hash */
	memset(&kg_cfg, 0, sizeof(struct dpkg_profile_cfg));
	kg_cfg.num_extracts = 1;
	kg_cfg.extracts[0].type = DPKG_EXTRACT_CONSTANT;
	kg_cfg.extracts[0].extract.constant.constant = 0;
	kg_cfg.extracts[0].extract.constant.num_of_repeats = 1;

	/* Set up hash KEY ID, a miss in FS should direct here */
	if (dpni->options & DPNI_OPT_DIST_HASH) {
		if (!IS_SHARED_FS_ENABLED) {
			for (i = 0; i < max_tcs_for_lookps(dpni); i++) {
				/*TODO: we could avoid setting up hash for 1 queue, but
				 * this needs more changes, like different next_action
				 * structures per-TC, as the flow would be different */
				err = dpkg_profile_create(
					dpni->ing_dpkg,
					dpni->tc_rx[i].kid_hash,
					&kg_cfg);
		
				CHECK_COND_RETVAL(!err , err, 
						"ID[%d] Failed to create DPKG profile at restore\n", dpni->id);
			}
		} else {
			/*TODO: we could avoid setting up hash for 1 queue, but
			 * this needs more changes, like different next_action
			 * structures per-TC, as the flow would be different */
			err = dpkg_profile_create(
				dpni->ing_dpkg,
				dpni->tc_rx[0].kid_hash,
				&kg_cfg);
	
			CHECK_COND_RETVAL(!err , err, 
					"ID[%d] Failed to create DPKG profile at restore\n", dpni->id);
		}

//		next_action.options |= DPTBL_ACTION_SET_HASH_KID;
	}

	if (!IS_SHARED_FS_ENABLED) {
		for (i = 0; i < dpni->max_rx_tcs; i++) {
			/* skip TCs that have 0 entries of size 0, DPTBL doesn't like
			 * them
			 */
			if (!dpni->tc_rx[i].max_fs_entries)
				continue;

			/* deal with key composition first */
			err = dpkg_profile_create(dpni->ing_dpkg, dpni->tc_rx[i].kid_fs,
					&kg_cfg);
	
			CHECK_COND_RETVAL(!err, err,
					"ID[%d] Failed to create DPKG profile at restore\n", dpni->id);
	
			/* per-TC we may have different KEY IDs to go on with, this is
			 * used if we miss in FS table
			 * normally we could save us the trouble and set HKID in IFP,
			 * but for now we still support different key composition rules
			 * per TC */
	//		next_action.hash_dpkg_profile_id = get_kid_hash(dpni,
	//				(uint8_t)i);
			memset(&tbl_cfg, 0, sizeof(struct dptbl_cfg));
			tbl_cfg.max_key_size = (uint8_t) dpni->tc_rx[i].max_dist_key_size;
			tbl_cfg.max_rules = dpni->tc_rx[i].max_fs_entries;
			if (dpni->options & DPNI_OPT_FS_MASK_SUPPORT)
				tbl_cfg.type = DPTBL_TYPE_TCAM_ACL;
			else
				tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
			tbl_cfg.action_on_miss = &dpni->tc_rx[i].default_action;
			tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
			if (dpni->tc_rx[i].fs_tbl != NULL) {
				err = dptbl_restore(dpni->tc_rx[i].fs_tbl, dpni->ing_dptbl,
						&tbl_cfg);
				CHECK_COND_RETVAL(err == 0, -ENAVAIL,
						"ID[%d]: RESTORING FS table failed\n", dpni->id);
			} else {
				pr_err("FS table = NULL\n");
				return -EINVAL;
			}
		}
	} else {
		if (dpni->tc_rx[0].max_fs_entries) {
			/* deal with key composition first */
			err = dpkg_profile_create(dpni->ing_dpkg, dpni->tc_rx[0].kid_fs,
					&kg_cfg);
	
			CHECK_COND_RETVAL(!err, err,
					"ID[%d] Failed to create DPKG profile at restore\n", dpni->id);
	
			/* per-TC we may have different KEY IDs to go on with, this is
			 * used if we miss in FS table
			 * normally we could save us the trouble and set HKID in IFP,
			 * but for now we still support different key composition rules
			 * per TC */
	//		next_action.hash_dpkg_profile_id = get_kid_hash(dpni,
	//				(uint8_t)0);
			memset(&tbl_cfg, 0, sizeof(struct dptbl_cfg));
			tbl_cfg.max_key_size = (uint8_t) dpni->tc_rx[0].max_dist_key_size;
			tbl_cfg.max_rules = dpni->tc_rx[0].max_fs_entries;
			if (dpni->options & DPNI_OPT_FS_MASK_SUPPORT)
				tbl_cfg.type = DPTBL_TYPE_TCAM_ACL;
			else
				tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
			tbl_cfg.action_on_miss = &dpni->tc_rx[0].default_action;
			tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
			if (dpni->tc_rx[0].fs_tbl != NULL) {
				err = dptbl_restore(dpni->tc_rx[0].fs_tbl, dpni->ing_dptbl,
						&tbl_cfg);
				CHECK_COND_RETVAL(err == 0, -ENAVAIL,
						"ID[%d]: RESTORING FS table failed\n", dpni->id);
			} else {
				pr_err("FS table = NULL\n");
				return -EINVAL;
			}
		}
	}

	/* used if we miss in QoS table, go to lowest prio TC by default
	 *
	 * These settings are temporary at best, notice next_action = DONE.
	 * At this time we don't follow up with FS look-ups or hashing, even
	 * if they are set-up with defaults.  The real magic is in
	 * rx_tc_dist_sequence, a matrix of operations to do when changing from
	 * one distribution mode to another (no distr -> hash or whatever).
	 * All this is unnecessarily complicated, but it's not trivial to
	 * replace everything in one go.
	 */
	/*
	memset(&next_action, 0, sizeof(struct dptbl_action));
	next_action.options = DPTBL_ACTION_SET_QPRI;
	next_action.qpri = dpni_get_rx_base_qpri(dpni);
	next_action.next_action = DPTBL_ACTION_DONE;*/

	memset(&tbl_cfg, 0, sizeof(struct dptbl_cfg));
	if (dpni->max_rx_tcs > 1) {

		tbl_cfg.max_key_size = (uint8_t)dpni->qos.max_qos_key_size;
		tbl_cfg.max_rules = dpni->qos.max_qos_entries;
		if (dpni->options & DPNI_OPT_QOS_MASK_SUPPORT)
			tbl_cfg.type = DPTBL_TYPE_TCAM_ACL;
		else
			tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
		tbl_cfg.action_on_miss = &dpni->qos.default_action;
		tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;

		if (dpni->qos.tbl != NULL) {
			err = dptbl_restore(dpni->qos.tbl, dpni->ing_dptbl, &tbl_cfg);
			if (err) {
				pr_err("ID[%d]: restoring QoS table failed\n", dpni->id);
				return err;
			}

		} else {
			pr_err("ID[%d]: QoS table = NULL\n", dpni->id);
			return -EINVAL;
		}
	} else {
		/* Skip it in 'reset' mode as it shouldn't change.
		 * Create dummy QoS table */
		tbl_cfg.max_key_size = 1;
		tbl_cfg.max_rules = 1;
		tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
		tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
		if (dpni->qos.tbl != NULL){
			err = dptbl_restore(dpni->qos.tbl, dpni->ing_dptbl, &tbl_cfg);
			if (err) {
				pr_err("ID[%d]: restoring QoS table failed\n", dpni->id);
				return -ENAVAIL;
			}
			err = dptbl_add_rule(dpni->qos.tbl, &dpni->dummy_rule,
						&dpni->qos.default_action, dpni->restore.en);
			CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		} else {
			pr_err("ID[%d]: dpni->qos.tbl is NULL\n", dpni->id);
			return -EINVAL;
		}
	}

	update_pass_through_qos(dpni);

	memset(&kg_cfg, 0, sizeof(struct dpkg_profile_cfg));
	kg_cfg.num_extracts = 1;
	kg_cfg.extracts[0].type = DPKG_EXTRACT_CONSTANT;
	kg_cfg.extracts[0].extract.constant.constant = 0;
	kg_cfg.extracts[0].extract.constant.num_of_repeats = 1;
	err = dpkg_profile_create(dpni->ing_dpkg, dpni->qos.kid,
					&kg_cfg);

	CHECK_COND_RETVAL(!err, err,
					"ID[%d] Failed to create DPKG profile at restore\n", dpni->id);

	memset(&next_action, 0, sizeof(struct dptbl_action));
	if (dpni->is_snic) {
		struct dpkg_profile_cfg kg_cfg = { 0 };

		next_action.options = DPTBL_ACTION_SET_QPRI;
		next_action.qpri = 8;			//DPNI_RX_BASE_QPRI;
		next_action.options |= DPTBL_ACTION_SET_OPAQUE;
		next_action.opaque = 0;
		next_action.next_action = DPTBL_ACTION_DONE;

		/* 3-Tuple for hashing */
		kg_cfg.num_extracts = 3;
		kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[0].extract.from_hdr.prot = NET_PROT_IP;
		kg_cfg.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[0].extract.from_hdr.field = NH_FLD_IP_SRC;
		kg_cfg.extracts[1].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[1].extract.from_hdr.prot = NET_PROT_IP;
		kg_cfg.extracts[1].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[1].extract.from_hdr.field = NH_FLD_IP_DST;
		kg_cfg.extracts[2].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[2].extract.from_hdr.prot = NET_PROT_IP;
		kg_cfg.extracts[2].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[2].extract.from_hdr.field = NH_FLD_IP_PROTO;


		err = dpkg_profile_create(dpni->ing_dpkg,
						dpni->snic.hash_kid,
						&kg_cfg);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);

	} else {
		/* At resotre, table's ids will not be the same */
		next_action.next_action = DPTBL_ACTION_LOOKUP;
		dptbl_get_id(dpni->qos.tbl,
				&next_action.lookup_params.dptbl_id);
		next_action.lookup_params.dpkg_profile_id = dpni->qos.kid;
	}

	if (dpni->options & DPNI_OPT_VLAN_FILTER) {
		memset(&kg_cfg, 0, sizeof(struct dpkg_profile_cfg));
		kg_cfg.num_extracts = 2;
		/* catch if VALN exist */
		kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_CONTEXT;
		kg_cfg.extracts[0].extract.from_context.src =
			DPKG_FROM_PARSE_RESULT_SPECIFIC_PROTOCOL;
		kg_cfg.extracts[0].extract.from_context.size = 1;
		kg_cfg.extracts[0].extract.from_context.offset = 4 + 2;
		kg_cfg.extracts[0].num_of_byte_masks = 1;
		kg_cfg.extracts[0].masks[0].mask = 0x04;
		/* extract VLAN TCI */
		kg_cfg.extracts[1].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[1].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[1].extract.from_hdr.prot = NET_PROT_VLAN;
		kg_cfg.extracts[1].extract.from_hdr.field = NH_FLD_VLAN_TCI;
		kg_cfg.extracts[1].num_of_byte_masks = 1;
		kg_cfg.extracts[1].masks[0].mask = 0x0f;


		err = dpkg_profile_create(dpni->ing_dpkg,
						dpni->filters.vlan_kid,
						&kg_cfg);
		CHECK_COND_RETVAL(!err, err,
						"ID[%d] Failed to create DPKG profile at restore\n", dpni->id);

		memset(&tbl_cfg, 0, sizeof(struct dptbl_cfg));
		tbl_cfg.max_key_size = 3; /* VLAN exist + VLAN TCI size */
		tbl_cfg.max_rules =
			(uint32_t)(dpni->filters.max_vlan_filters + 1) /* for the non-vlan key */;
		tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
		//tbl_cfg.action_on_miss = &dpni->filters.vlan_allow_action;
		tbl_cfg.action_on_miss = &next_action;
		tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
		memcpy(&dpni->filters.vlan_allow_action, &next_action,
			sizeof(struct dptbl_action));
		memset(&dpni->filters.vlan_disallow_action, 0,
			sizeof(struct dptbl_action));
		dpni->filters.vlan_disallow_action.next_action =
			DPTBL_ACTION_DONE;
		dpni->filters.vlan_disallow_action.options =
			DPTBL_ACTION_SET_DISCARD_FLAG;


		if (dpni->filters.vlan_tbl != NULL) {
			err = dptbl_restore(dpni->filters.vlan_tbl, dpni->ing_dptbl,
							&tbl_cfg);
			if (err) {
				pr_err("ID[%d]: creating VLAN table failed\n", dpni->id);
				return err;
			}
		} else {
			pr_err("Vlan table = NULL\n");
			return -EINVAL;
		}
			
		/* Add RULE to catch non VLAN frames to skip the filter */
		memset(&rule, 0, sizeof(struct dptbl_rule));
		rule.rule_cfg.exact.key = no_vlan_key;
		rule.rule_cfg.exact.size = 3;
		err = dptbl_add_rule(
			dpni->filters.vlan_tbl, &rule,
			&dpni->filters.vlan_allow_action, dpni->restore.en);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);

		/* At restore the tbl's ID is different because of different order */
		memset(&next_action, 0, sizeof(struct dptbl_action));
		next_action.next_action = DPTBL_ACTION_LOOKUP;
		dptbl_get_id(dpni->filters.vlan_tbl,
				&next_action.lookup_params.dptbl_id);
		next_action.lookup_params.dpkg_profile_id =
			dpni->filters.vlan_kid;
	}

	/* UNICAST Filters */
	memset(&tbl_cfg, 0, sizeof(struct dptbl_cfg));
	tbl_cfg.max_key_size = 6; /* MAC ADDR size */
	tbl_cfg.max_rules = 2; /* Need at least 2 for the primary
	 and for the option to modify it */
	if (dpni->options & DPNI_OPT_UNICAST_FILTER)
		tbl_cfg.max_rules += dpni->filters.max_unicast_filters;
	if (dpni->options & DPNI_OPT_MULTICAST_FILTER)
		tbl_cfg.max_rules += dpni->filters.max_multicast_filters;
	tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
	tbl_cfg.options = DPTBL_OPTIONS_OPTIMIZIED_DISCARD;
	tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
	memset(&action, 0, sizeof(struct dptbl_action));
	action.next_action = DPTBL_ACTION_DONE;
	tbl_cfg.action_on_miss = &action;
	if(dpni->filters.mac_tbl != NULL){
		err = dptbl_restore(dpni->filters.mac_tbl, 
							dpni->ing_dptbl, 
							&tbl_cfg);
		if (err) {
			pr_err("ID[%d]: creating UNICAST table failed\n", dpni->id);
			return err;
	}
	} else {
		pr_err("ID[%d]: dpni->filters.mac_tbl = NULL\n", dpni->id);
		return -EINVAL;
	}

	/* MAC (both unicast&multicast) Filters */
	memset(&kg_cfg, 0, sizeof(struct dpkg_profile_cfg));
	kg_cfg.num_extracts = 1;
	kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
	kg_cfg.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
	kg_cfg.extracts[0].extract.from_hdr.prot = NET_PROT_ETH;
	kg_cfg.extracts[0].extract.from_hdr.field = NH_FLD_ETH_DA;

	err = dpkg_profile_create(dpni->ing_dpkg,
					dpni->filters.mac_kid,
					&kg_cfg);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);

	/* we change it because TBL id is changed at retore */
	memcpy(&dpni->filters.mac_allow_action, &next_action,
		sizeof(struct dptbl_action));

	/* Add Primary mac address to the filter table */
	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = dpni->mac_addr;
	rule.rule_cfg.exact.size = 6;

	pr_debug("Add Primary mac address to the filter table\n");
	err = dptbl_add_rule(dpni->filters.mac_tbl, &rule,
				&dpni->filters.mac_allow_action, dpni->restore.en);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);

	if (dpni->is_ing_parser_id_allocated) {
		err = dpparser_init_profile(dpni->ing_dpparser,
						dpni->ing_parser_id, NULL,
						NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		/* Attach ingress soft parser */
		err = dpparser_attach_soft_parser(dpni->ing_dpparser, dpni->ing_sp_prof,
							dpni->ing_parser_id,
							&dpni->ing_start_hxs,
							0, NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		if (dpni->ing_start_hxs)
			pr_info("WRIOP INGRESS start HXS set to 0x%x\n",
				dpni->ing_start_hxs);
	}

	if (dpni->is_egr_parser_id_allocated) {
		err = dpparser_init_profile(dpni->egr_dpparser,
						dpni->egr_parser_id, NULL,
						NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		/* Attach egress soft parser */
		err = dpparser_attach_soft_parser(dpni->egr_dpparser, dpni->egr_sp_prof,
							dpni->egr_parser_id,
							&dpni->egr_start_hxs,
							1, NULL);
		CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err);
		if (dpni->egr_start_hxs)
			pr_info("WRIOP EGRESS start HXS set to 0x%x\n",
				dpni->egr_start_hxs);
	}

	err = config_ctlu_policy(dpni, 0);
	CHECK_COND_RETVAL(!err || (err == -ETIMEDOUT), err, "restore_ctlu_policy Failed\n");

	return 0;
}

static int dpni_restore_init_config( struct dpni *dpni)
{
	int err;

	err = dpni_restore_ctlu(dpni);
	CHECK_COND_RETVAL(err==0, err, "dpni_restore_ctlu FAILED\n");

	return 0;
}

int dpni_restore_after_eiop_reset(struct dpni *dpni)
{
	int err, is_en, is_en_peer;
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_control control;
	struct linkman_connection_attr linkman_attr;
	struct dpmac *dpmac = NULL;
	struct dpni *peer_dpni = NULL;
	struct linkman *linkman;

	pr_info("DPNI[%d] Init after WRIOP reset\n", dpni->id);

	err = dpni_restore_init_config(dpni);
	if (err != 0) {
		pr_err("ID[%d]: initial_configuration failed\n", dpni->id);
		dpni_destroy(dpni);
		return err;
	}

	/* Used for DPNI <-> DPNI connection */
	dpni->restore.init_done = 1;

	if (!dpni->ap_valid)
	{
		err = set_tx_rejection_mode(dpni, 1);
		CHECK_COND_RETVAL(err==0, err, "DPNI[%d] set_tx_rejection_mode FAILED\n", dpni->id);
		
    	err = restore_runtime_config(dpni);
    	CHECK_COND_RETVAL(err==0, err, "restore_runtime_config FAILED\n");
    	dpni->restore.en = 0;

	} else if (dpni->dpmac) {

		dpni_is_enabled(dpni, &is_en);

		/* If EN , disable it to be able to perform DISCONENCT */
		if(is_en){
			err = dpni_disable(dpni);
			CHECK_COND_RETVAL(err==0, err, "dpni_disable FAILED\n");
		}

		dpmac = dpmac_get_handle(dpni->dpmac);
		CHECK_COND_RETVAL(dpmac, -EINVAL, "sys_get_handle Failed\n");

        linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
        CHECK_COND_RETVAL(linkman, -EINVAL, "sys_get_unique_handle Failed \n");

        memset(&endpoint1, 0x0, sizeof(struct linkman_endpoint));
        memset(&endpoint2, 0x0, sizeof(struct linkman_endpoint));
        memset(&control, 0x0, sizeof(struct linkman_control));
        memset(&linkman_attr, 0x0, sizeof(struct linkman_connection_attr));
        
        endpoint1.type = FSL_MOD_DPMAC;
        endpoint1.id = (uint16_t)dpmac_get_id(dpmac);
        endpoint2.type = FSL_MOD_DPNI;
        endpoint2.id = (uint16_t)dpni->id;

        err = linkman_get_connection(linkman, &endpoint1, &endpoint2, &linkman_attr);
        CHECK_COND_RETVAL(err == 0, err, "linkman_get_connection Failed \n");

        control.event = LINKMAN_EVENT_DISCONNECT;
        err = linkman_set_connection(linkman, &control,
                &endpoint1, &endpoint2);
        CHECK_COND_RETVAL(err == 0, err, "DPNI <-> DPMAC DISCONNECT Failed\n");

        control.event = LINKMAN_EVENT_CONNECT;
        control.committed_rate = linkman_attr.committed_rate;
        control.max_rate = linkman_attr.max_rate;
        control.supported = linkman_attr.supported;

        /* Start parameters exchange state machine */
        err = linkman_set_connection(linkman, &control,
                &endpoint1, &endpoint2);
        CHECK_COND_RETVAL(err == 0, -EINVAL, "DPNI <-> DPMAC CONNECT Failed\n");
        enum dpmac_link_type link_type = dpmac_get_link_type(dpni->dpmac);
        
        /* Force Link-up from PHY in case of TYPE_PHY connection */
		if(link_type == DPMAC_LINK_TYPE_PHY || link_type == DPMAC_LINK_TYPE_BACKPLANE)
			dpmac_set_linkup_from_phy(1, dpmac);

    	/* Enable back if it was enabled */
    	if(is_en) {
    		err = dpni_enable(dpni);
    		CHECK_COND_RETVAL(err==0, err, "dpni_enable FAILED\n");
    	}

		dpmac_set_linkup_from_phy(0, dpmac);

    	err = restore_runtime_config(dpni);
    	CHECK_COND_RETVAL(err==0, err, "restore_runtime_config FAILED\n");
    	dpni->restore.en = 0;

	} else if (dpni->dpni){

		peer_dpni = sys_get_handle(FSL_MOD_DPNI, 1, dpni->dpni->id);
		CHECK_COND_RETVAL(dpni, -EINVAL, "sys_get_handle Failed\n");
		
		/* Wait for both DPNIs to be restored */
		if (dpni->restore.init_done && peer_dpni->restore.init_done)
		{
			/* If EN, disable it to be able to perform DISCONENCT */
			dpni_is_enabled(dpni, &is_en);
			if(is_en){
				err = dpni_disable(dpni);
				CHECK_COND_RETVAL(err==0, err, "dpni_disable FAILED\n");
			}
			
			dpni_is_enabled(peer_dpni, &is_en_peer);
			if(is_en_peer){
				err = dpni_disable(peer_dpni);
				CHECK_COND_RETVAL(err==0, err, "dpni_disable FAILED\n");
			}

			memset(&endpoint1, 0x0, sizeof(struct linkman_endpoint));
			memset(&endpoint2, 0x0, sizeof(struct linkman_endpoint));
			memset(&control, 0x0, sizeof(struct linkman_control));
			endpoint1.type = FSL_MOD_DPNI;
			endpoint1.id = (uint16_t)dpni->id;
			endpoint2.type = FSL_MOD_DPNI;
			endpoint2.id = (uint16_t)peer_dpni->id;
			control.event = LINKMAN_EVENT_DISCONNECT;
			control.committed_rate = 0;
			control.max_rate = 0;
			/* Start parameters exchange state machine */
			linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
			CHECK_COND_RETVAL(linkman, -EINVAL, "sys_get_unique_handle Failed \n");

			err = linkman_set_connection(linkman, &control,
					&endpoint1, &endpoint2);
			CHECK_COND_RETVAL(err == 0, -EINVAL, "Dpni <-> Dpni DISCONNECT Failed\n");
			
			control.event = LINKMAN_EVENT_CONNECT;
			err = linkman_set_connection(linkman, &control,
					&endpoint1, &endpoint2);
			CHECK_COND_RETVAL(err == 0, -EINVAL, "Dpni <-> Dpni CONNECT Failed\n");

			/* Enable them back if was enabled */
	    	if(is_en) {
	    		err = dpni_enable(dpni);
	    		CHECK_COND_RETVAL(err == 0, err, "dpni_enable FAILED\n");
	    	}
	    	
	    	if(is_en_peer) {
	    		err = dpni_enable(peer_dpni);
	    		CHECK_COND_RETVAL(err == 0, err, "dpni_enable FAILED\n");
	    	}
	    	
	    	/* Restore Runtime config */
	    	err = restore_runtime_config(peer_dpni);
	    	CHECK_COND_RETVAL(err == 0, err, "restore_runtime_config FAILED\n");
	    	err = restore_runtime_config(dpni);
	    	CHECK_COND_RETVAL(err == 0, err, "restore_runtime_config FAILED\n");
	    	dpni->restore.en = 0;
	    	peer_dpni->restore.en = 0;
		}

	}

	return 0;
}

int dpni_empty_check(struct dpni *dpni)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)dpni->snic.ingress_ifp_info->ifp_desc.vaddr;
	struct dpmac *dpmac;
	struct eiop_port_desc eiop_port_desc = {0};
	int tries = 10, err = 0;
	uint32_t tmp;
	
	if(dpni->restore.en)
		return 0;
	pr_info("DPNI[%d] dpni_empty_check\n", dpni->id);

	do {
		tmp = ioread32(&regs->ifebsy) & EIOP_IFP_EGGR_BSY;
	} while ((tmp == EIOP_IFP_EGGR_BSY) && --tries);
	if ((tmp == EIOP_IFP_EGGR_BSY) && tries == 0) {
		tmp = ioread32(&regs->ifebsy);
		pr_warn("There are still pending tasks on IFP egress way\n");
		/* Do not return because this is a sign of errata occurrence */
	}

	tries = 10;
	do {
		tmp = ioread32(&regs->ifibsy) & EIOP_IFP_INGR_BSY;
	} while ((tmp == EIOP_IFP_INGR_BSY) && --tries);
	if ((tmp == EIOP_IFP_INGR_BSY) && tries == 0) {
		tmp = ioread32(&regs->ifibsy);
		pr_err("There are still %d pending tasks on IFP ingres way\n",
				(tmp & EIOP_IFP_INGR_EBC));
		return -EINVAL;
	}

	dpni->restore.en = 1;
	dpni->restore.init_done = 0;
	/* From here just for physical ports */
	if(!dpni->dpmac)
		return 0;

	dpmac = dpmac_get_handle(dpni->dpmac);
	CHECK_COND_RETVAL(dpmac != NULL, -EINVAL, "DPMAC get handle failed\n");

	int ret_val = dpmac_check_empty(dpmac, tries, tmp);

	return ret_val;
}

int dpni_graceful_stop(struct dpni *dpni)
{
	struct dpmac *dpmac;
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)dpni->snic.ingress_ifp_info->ifp_desc.vaddr;
	uint32_t tmp;
	int tries = 10;
	int loopback_en;
	
	if(dpni->restore.en)
		return 0;
	pr_info("DPNI[%d] dpni_graceful_stop\n", dpni->id);
	
	if(dpni->dpmac){
		dpmac = dpmac_get_handle(dpni->dpmac);
		CHECK_COND_RETVAL(dpmac != NULL, -EINVAL, "DPMAC get handle failed\n");
	}

	/*The Sub-portal was disabled previously */
	/* Disable IFP ingress */
	if(eiop_ifp_rx_is_enable(&dpni->snic.ingress_ifp_info->ifp_desc))
	{

		dpni->restore.ingress_ifp_en = 1;

		eiop_ifp_rx_disable(dpni->snic.ingress_ifp_info->ifp_desc.vaddr);

		/*be sure valid bit is cleared*/
		do {
			tmp = ioread32(&regs->ifpv) & EIOP_IFP_INGR_EN;
		} while ((tmp == EIOP_IFP_INGR_EN) && --tries);
	
		if ((tmp == EIOP_IFP_INGR_EN) && tries == 0) {
			pr_err("Ingress ifp cannot be disabled. "
			"Graceful stop can not be executed"
			"Can not clear valid bit.\n");
			return -EINVAL;
		}
	}

	/* for Physical ports set MAC in loopback */
	if (dpni->dpmac) {
//		err = eiop_port_tx_set_flush(&(dpmac->port_desc));
//		CHECK_COND_RETVAL(err==0, err, "eiop_port_tx_set_flush FAILED\n");
		dpmac_get_loopback(dpni->dpmac, &loopback_en);
		if(!loopback_en)
			dpmac_set_loopback(dpni->dpmac, 1);
		else
			dpni->restore.mac_in_loopback = 1;
	}
	return 0;
}

int dpni_resume(struct dpni *dpni)
{
	struct dpmac *dpmac;
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)dpni->snic.ingress_ifp_info->ifp_desc.vaddr;
	uint32_t tmp;
	int tries = 10;

	pr_info("DPNI[%d] dpni_resume\n", dpni->id);

	/* Enable IFP ingress if was en */
	if(dpni->restore.ingress_ifp_en)
	{
		eiop_ifp_rx_enable(&dpni->snic.ingress_ifp_info->ifp_desc);

		/*be sure valid bit is set*/
		do {
			tmp = ioread32(&regs->ifpv) & EIOP_IFP_INGR_EN;
		} while ((tmp != EIOP_IFP_INGR_EN) && --tries);
	
		if ((tmp != EIOP_IFP_INGR_EN) && tries == 0) {
			pr_err("Ingress ifp cannot be enabled. "
			"Can not set valid bit.\n");
			return -EINVAL;
		}
		
		dpni->restore.ingress_ifp_en = 0;
	}

	/* for Physical ports remove MAC loopback if wasn't set*/
	if(dpni->dpmac){
		dpmac = dpmac_get_handle(dpni->dpmac);
		CHECK_COND_RETVAL(dpmac != NULL, -EINVAL, "DPMAC get handle failed\n");
	
		/*		err = eiop_port_tx_set_flush(&(dpmac->port_desc));
			CHECK_COND_RETVAL(err==0, err, "eiop_port_tx_set_flush FAILED\n");*/
		if(!dpni->restore.mac_in_loopback)
			dpmac_set_loopback(dpni->dpmac, 0);
		else
			dpni->restore.mac_in_loopback = 0;
	}

	return 0;
}

int dpni_errata_check(struct dpni *dpni, uint32_t depleton_wait_us)
{
	int err = 0, iter = 5, ret = 0;

	if(!dpni || dpni->restore.en)
		return 0;
	pr_info("DPNI[%d] dpni_errata_check\n", dpni->id);

	/* Start to drain al frames from WRIOP */
	err = dpni_graceful_stop(dpni);
	CHECK_COND_RETVAL(!err, err, "Fail to start the drain of DPNI[%d]\n", dpni->id);

	/* Verify if WRIOP is drained or errata occured */
	do{
		timer_udelay(depleton_wait_us);
		ret = dpni_empty_check(dpni);
	}while(ret && (ret != -ETIMEDOUT) && --iter);

	/* resume if errata not occured */
	if(ret != -ETIMEDOUT)
		if (dpni_resume(dpni))
			ret = -ETIMEDOUT; /* Force workaround if dpni cannot be recovered */

	if(ret != -ETIMEDOUT){
		dpni->restore.en = 0;
		dpni->restore.init_done = 1;
	}

	return ret;
}
#endif /* TKT011436 */

int dpni_close(struct dpni *dpni, uint16_t token)
{
	struct dpni_fs_redirect_table_entry *redirect_entry;
	struct dpni *src_dpni;
	int rule_idx;

	for( rule_idx = 0 ; rule_idx < DPNI_MAX_FS_REDIRECT_ENTRIES ; rule_idx++ ) {
		redirect_entry = &dpni->fs_redirect_table[rule_idx];

		if( !redirect_entry->valid )
			continue;

		if( redirect_entry->token != token )
			continue;

		src_dpni = sys_get_handle(FSL_MOD_DPNI, 1, redirect_entry->obj_id);
		if( src_dpni == NULL )
			continue;

		dpni_clean_redirect_rules(src_dpni, 0, token);
	}

	return 0;
}
