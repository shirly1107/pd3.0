/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpdcei_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "fsl_sys.h"
#include "dtc/dtc.h"
#include "dplib/fsl_dpdcei_cmd.h"
#include "fsl_dpmng_mc.h"
#include "fsl_event_pipe.h"
#include "fsl_dpdcei_mc.h"
#include "fsl_resman.h"
#include "dpdcei_drv.h"

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	UNUSED(dev);
	UNUSED(dev_ctx);

	pr_err("DPDCEI is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int destroy_by_resman(struct device *dev)
{
	return 0;
}

static int reset_by_resman(struct device *dev)
{
	return 0;
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	UNUSED(dev);
	UNUSED(irq_cfg);
	UNUSED(irq_index);

	pr_err("DPDCEI is not supported in this SOC!\n");
	return -ENOTSUP;
}


static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	UNUSED(dev);
	UNUSED(irq_cfg);
	UNUSED(irq_index);

	pr_err("DPDCEI is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpdcei_open_cb(void *dev, int portal_id)
{
	UNUSED(dev);
	UNUSED(portal_id);
	
	pr_err("DPDCEI is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpdcei_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(dev);
	UNUSED(portal_id);

	pr_err("DPDCEI is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpdcei_ctrl_cb(void *dev,
                        uint8_t cmd_ver,
                        uint16_t cmd,
                        int portal_id,
                        uint8_t *data)
{
	UNUSED(dev);
	UNUSED(cmd_ver);
	UNUSED(cmd);
	UNUSED(portal_id);
	UNUSED(data);
	
	pr_err("DPDCEI is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpdcei_probe_cb(void *lo, int node_off)
{
	UNUSED(lo);
	UNUSED(node_off);

	pr_warn("DPDCEI defined in DPL - Not supported in this SOC!\n");
	return 0;
}

static char *dpdcei_match[] = { "fsl,dpdcei", "dpdcei" };

static int dpdcei_remove_cb(void *lo, int node_off)
{
	UNUSED(lo);
	UNUSED(node_off);
	
	return 0;
}

int dpdcei_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	int err;

	dtc_params.num_compats = ARRAY_SIZE(dpdcei_match);
	dtc_params.compatibles = dpdcei_match;
	dtc_params.f_prob_module = dpdcei_probe_cb;
	dtc_params.f_remove_module = dpdcei_remove_cb;
	sys_dtc_register_module(&dtc_params);

	cmdif_ops.open_cb = dpdcei_open_cb;
	cmdif_ops.close_cb = dpdcei_close_cb;
	cmdif_ops.ctrl_cb = dpdcei_ctrl_cb;
	cmdif_register_module(CMDIF_MOD_DPDCEI, &cmdif_ops);
	strcpy(dev_type_param.device_type, "dpdcei");
	dev_type_param.irq_count = DPDCEI_MAX_IRQ_NUM; /*TODO - how many irqs?*/
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPDCEI_VER_MAJOR;
	dev_type_param.ver_minor = DPDCEI_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	ASSERT_COND(resman);

	err = resman_register_device_operation(resman, "dpdcei",
	                                       &dev_type_param);
	return err;
}
