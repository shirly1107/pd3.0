/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpdcei_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "fsl_sys.h"
#include "dtc/dtc.h"
#include "dplib/fsl_dpdcei_cmd.h"
#include "fsl_dpmng_mc.h"
#include "fsl_event_pipe.h"
#include "fsl_dpdcei_mc.h"
#include "fsl_resman.h"
#include "dpdcei_drv.h"
#include "dpdcei_cmd.h"
#include "legacy_dpdcei_dplib.h"

/* DPDCEI last supported api version */
#define DPDCEI_V0_API_VER_MAJOR				1
#define DPDCEI_V0_API_VER_MINOR				2

/*            cmd,  cfg, param, offset, width,  type,  	arg_name */
#define DPDCEI_LO_CREATE(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 8,  8,  enum dpdcei_engine,  cfg->engine);\
	MC_RSP_OP(cmd, 0, 16, 8,  uint8_t,  cfg->priority);\
} while (0)

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpdcei *dpdcei;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	return dpdcei_set_dev_ctx(dpdcei, dev_ctx);
}

static int init(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpdcei_cfg dpdcei_cfg;
	struct dpdcei_cfg *cfg = &dpdcei_cfg;
	int err;

	memset(&dpdcei_cfg, 0, sizeof(struct dpdcei_cfg));

	DPDCEI_CMD_CREATE(cmd_data, cfg);

	dpdcei = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpdcei) {
		/* NULL */
		dpdcei = dpdcei_allocate();
		if (!dpdcei) {
			pr_err("No memory for dpdcei\n");
			return -ENOMEM;
		}
		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpdcei_init(dpdcei, cfg, &dev_cfg);
		if (err) {
			return err;
		}
		device_set_priv(dev, dpdcei);
		sys_add_handle(dpdcei, FSL_MOD_DPDCEI, 1, dev_cfg.id);

		assign(dev, &(dev_cfg.ctx));
	}
	else
		return -EINVAL;

	return 0;
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	int err;


	UNUSED(cmd_data);

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	device_set_enable(dev, 1);

	err = dpdcei_enable(dpdcei);
		if (err)
			device_set_enable(dev, 0);

	return err;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	int err;

	UNUSED(cmd_data);

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	err = dpdcei_disable(dpdcei);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	int err;

	UNUSED(cmd_data);

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	err = dpdcei_destroy(dpdcei);
	if (err){
		pr_err("failed to destroy DPDCEI\n");
		return err;
	}

	sys_remove_handle(FSL_MOD_DPDCEI, 1, device_get_id(dev));
	dpdcei_deallocate(dpdcei);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	struct dpmng_dev_ctx dev_ctx;
	int err;

	UNUSED(cmd_data);

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	err = dpdcei_reset(dpdcei);
	if (!err) {
		resman_get_dev_ctx(dev, &dev_ctx, 1);
		device_set_enable(dev, 0);
		err = assign(dev, &dev_ctx);
	}
	return err;
}

static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}

static int set_rx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	struct dpdcei_rx_queue_cfg queue_cfg;
	struct dpdcei_rx_queue_cfg *cfg = &queue_cfg;

	dpdcei = device_get_priv(dev);
    	if (!dpdcei)
    		return -ENODEV;

   	memset(cfg, 0, sizeof(struct dpdcei_rx_queue_cfg));

    DPDCEI_CMD_SET_RX_QUEUE(cmd_data, cfg);

    return dpdcei_set_rx_queue(dpdcei, cfg);
}


static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	struct dpdcei_attr attr = { 0 };
	int err;

	dpdcei = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdcei, -ENODEV);

	err = dpdcei_get_attributes(dpdcei, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.version.major = DPDCEI_V0_API_VER_MAJOR;
	attr.version.minor = DPDCEI_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDCEI_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	struct dpdcei_attr attr = { 0 };
	int err;

	dpdcei = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdcei, -ENODEV);

	err = dpdcei_get_attributes(dpdcei, &attr);
	CHECK_COND_RETVAL(!err, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDCEI_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	int en;
	int err;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	err = dpdcei_is_enabled(dpdcei, &en);
	if(!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDCEI_RSP_IS_ENABLED(cmd_data, en);
	}

	return err;
}

static int get_rx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	int err;
	struct dpdcei_rx_queue_attr attributes = { 0 };
	struct dpdcei_rx_queue_attr *attr = &attributes;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	err = dpdcei_get_rx_queue(dpdcei, attr);
	if(!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDCEI_RSP_GET_RX_QUEUE(cmd_data, attr);
	}

	return err;
}

static int get_tx_queue(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	int err;
	struct dpdcei_tx_queue_attr attributes = { 0 };
	struct dpdcei_tx_queue_attr *attr = &attributes;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	err = dpdcei_get_tx_queue(dpdcei, attr);
	if(!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDCEI_RSP_GET_TX_QUEUE(cmd_data, attr);
	}

	return err;
}


static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
        uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

    	dpdcei = device_get_priv(dev);
    	if (!dpdcei)
    		return -ENODEV;

    	DPDCEI_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

    	if (resman_is_irq_cfg_allowed(dev) == 0)
    		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

        return dpdcei_set_irq(dpdcei, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpdcei *dpdcei;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	return dpdcei_set_irq(dpdcei, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
        struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	/* Read parameters from portal */
	DPDCEI_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpdcei_get_irq(dpdcei, irq_index, irq_cfg);
	if (err)
		return err;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDCEI_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpdcei *dpdcei;
	int err;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	err = dpdcei_get_irq(dpdcei, (uint8_t)irq_index, irq_cfg);
	if (err)
		return err;

	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	uint8_t irq_index;
	uint8_t enable_state;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	/* Read parameters from portal */
	DPDCEI_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, enable_state);

	return dpdcei_set_irq_enable(dpdcei, irq_index, enable_state);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	uint8_t irq_index;
	uint8_t enable_state;
	int err;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	/* Read parameters from portal */
	DPDCEI_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpdcei_get_irq_enable(dpdcei, irq_index, &enable_state);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDCEI_RSP_GET_IRQ_ENABLE(cmd_data, enable_state);
	}
	return err;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	uint8_t irq_index;
	uint32_t mask;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	/* Read parameters from portal */
	DPDCEI_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpdcei_set_irq_mask(dpdcei, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	/* Read parameters from portal */
	DPDCEI_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpdcei_get_irq_mask(dpdcei, irq_index, &mask);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDCEI_RSP_GET_IRQ_MASK(cmd_data, mask);
	}
	return err;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	/* Read parameters from portal */
	DPDCEI_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpdcei_get_irq_status(dpdcei, irq_index, &status);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDCEI_RSP_GET_IRQ_STATUS(cmd_data, status);
	}
	return err;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdcei *dpdcei;
	uint8_t irq_index;
	uint32_t status;

	dpdcei = device_get_priv(dev);
	if (!dpdcei)
		return -ENODEV;

	/* Read parameters from portal */
	DPDCEI_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpdcei_clear_irq_status(dpdcei, irq_index, status);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPDCEI_VER_MAJOR;
    uint32_t minor = DPDCEI_VER_MINOR;

    DPDCEI_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

static int dpdcei_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpdcei_open on DPDCEI %d\n", device_get_id(dev));
	return 0;
}

static int dpdcei_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpdcei_close on DPDCEI %d\n", device_get_id(dev));
	return 0;
}

static int dpdcei_ctrl_cb(void *dev,
			  uint8_t cmd_ver,
			  uint16_t cmd,
			  int portal_id,
			  uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev, struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPDCEI_CMD_CODE_CREATE, init, "dpdcei_init", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_ENABLE, enable, "dpdcei_enable", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_DISABLE, disable, "dpdcei_disable", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_DESTROY, destroy, "dpdcei_destroy", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_RESET, reset, "dpdcei_reset", DPDCEI_CMD_VER_BASE},
			{ DPDCEI_CMD_CODE_GET_ATTR, get_attributes_v0, "dpdcei_get_attributes", DPDCEI_CMD_V0 },
			{ DPDCEI_CMD_CODE_IS_ENABLED, is_enabled, "dpdcei_is_enabled", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_SET_RX_QUEUE, set_rx_queue, "dpdcei_set_rx_queue", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_GET_RX_QUEUE, get_rx_queue, "dpdcei_get_rx_queue", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_GET_TX_QUEUE, get_tx_queue, "dpdcei_get_tx_queue", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_SET_IRQ, set_irq, "dpdcei_set_irq", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_GET_IRQ, get_irq, "dpdcei_get_irq", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpdcei_set_irq_enable", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpdcei_get_irq_enable", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpdcei_set_irq_mask", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpdcei_get_irq_mask", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpdcei_get_irq_status", DPDCEI_CMD_VER_BASE },
			{ DPDCEI_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpdcei_clear_irq_status", DPDCEI_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPDCEI_CMD_CODE_GET_API_VERSION, get_api_version, "dpdcei_get_api_version", DPDCEI_CMD_V1 },
			{ DPDCEI_CMD_CODE_GET_ATTR, get_attributes_v1, "dpdcei_get_attributes", DPDCEI_CMD_V1 },
			{ DPDCEI_CMD_CODE_GET_ATTR, get_attributes_v1, "dpdcei_get_attributes", DPDCEI_CMD_V2 },
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))){
			if (cmd == DPDCEI_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPDCEI %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev, cmd_data);
		}

	pr_err("Invalid command %d\n",cmd);
	return -ENOTSUP;
}

static int get_engine(void *lo, int node_off, enum dpdcei_engine *engine)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		enum dpdcei_engine engine;
	} map[] = {
			{ "DPDCEI_ENGINE_COMPRESSION", DPDCEI_ENGINE_COMPRESSION },
			{ "DPDCEI_ENGINE_DECOMPRESSION", DPDCEI_ENGINE_DECOMPRESSION }
	};

	str = (char *)fdt_getprop(lo, node_off, "engine", NULL);
	if (!str) {
		pr_err("'engine' is a required field in DPDCEI node\n");
		*engine = DPDCEI_ENGINE_COMPRESSION;
		return -EINVAL;
	}
	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (!strcmp(str, map[i].str)) {
			*engine = map[i].engine;
			return 0;
		}
	}
	pr_err("Did not defined engine in DPL - setting to default DPDCEI_ENGINE_COMPRESSION\n");
	*engine = DPDCEI_ENGINE_COMPRESSION;
	return -EINVAL;
}

static int dpdcei_probe_cb(void *lo, int node_off)
{
	int err = 0;
	struct dpdcei_cfg dpdcei_cfg;
	struct dpdcei_cfg *cfg = &dpdcei_cfg;
	int dpdcei_id;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	int destroy = 0;
	uint64_t val;

	memset(&dpdcei_cfg, 0, sizeof(struct dpdcei_cfg));

	err = (uint16_t)get_node_id(lo, node_off, &dpdcei_id);
	if (err)
		return err;

	err = get_engine(lo, node_off, &dpdcei_cfg.engine);
	if (err)
		return err;

	getprop_val(lo, node_off, "priority", 0, 0, &val);
	dpdcei_cfg.priority = (uint8_t)val;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman){
		pr_err("Can't find resman");
		return -ENODEV;
	}
	/* create & open resman device */
	dev = resman_open_dev(
			resman, "dpdcei",
			(uint16_t)dpdcei_id,
			NO_PORTAL_ID, DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPDCEI %.4x\n", dpdcei_id);
	DPDCEI_LO_CREATE(cmd_data, cfg);
	/* create object */
	err = dpdcei_ctrl_cb(dev, DPDCEI_CMD_VER_BASE, DPDCEI_CMD_CODE_CREATE,
			NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpdcei",
		                       NO_PORTAL_ID, destroy);

	return err;
}

static char *dpdcei_match[] = { "fsl,dpdcei", "dpdcei" };

static int dpdcei_remove_cb(void *lo, int node_off)
{
	struct resman *resman;
	struct device *dev;
	int id;
	int err = 0;

	err = get_node_id(lo, node_off, &id);
	if (err)
		return err;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	if (!resman){
		pr_err("Can't find resman");
		return -ENODEV;
	}

	dev = resman_open_dev(
	        resman, "dpdcei",
	        (uint16_t)id,
	        NO_PORTAL_ID, 0, NULL);
	if (!dev){
		pr_err("Can't open DPDCEI 0x%.4x\n", id);
		return -ENODEV;
	}

        err |= dpdcei_ctrl_cb(dev, DPDCEI_CMD_VER_BASE, DPDCEI_CMD_CODE_DESTROY, NO_PORTAL_ID, NULL);
        err |= resman_close_dev(resman, dev, "dpdcei",
			                       NO_PORTAL_ID, 0);
	return err;
}

int dpdcei_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	int err;

	pr_info("Executing dpdcei_drv_init...\n");

	dtc_params.num_compats = ARRAY_SIZE(dpdcei_match);
	dtc_params.compatibles = dpdcei_match;
	dtc_params.f_prob_module = dpdcei_probe_cb;
	dtc_params.f_remove_module = dpdcei_remove_cb;
	sys_dtc_register_module(&dtc_params);

	cmdif_ops.open_cb = dpdcei_open_cb;
	cmdif_ops.close_cb = dpdcei_close_cb;
	cmdif_ops.ctrl_cb = dpdcei_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module(CMDIF_MOD_DPDCEI, &cmdif_ops);
	strcpy(dev_type_param.device_type, "dpdcei");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPDCEI_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPDCEI_VER_MAJOR;
	dev_type_param.ver_minor = DPDCEI_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset =   reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV);

	err = resman_register_device_operation(resman, "dpdcei",
	                                       &dev_type_param);
	return err;
}
