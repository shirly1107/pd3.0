/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpdcei.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_event_pipe.h"

#include "fsl_dpmng_mc.h"
#include "fsl_dpcon_mc.h"
#include "fsl_dpio_mc.h"
#include "fsl_dpbp_mc.h"
#include "dpdcei.h"

static int resources_allocation(struct dpdcei *dpdcei)
{
	int tmp = 0;
	int err;

	/* FQIDs */
	tmp = 0;
	if ((err = allocate_resource(dpdcei->device, "fq", 1, 1, 0,
			&tmp, "DPDCEI-Q"))
		!= 0)
			return err;
	dpdcei->tx_queue_info.tx_fqid = (uint32_t)tmp;

	tmp = 0;
	if ((err = allocate_resource(dpdcei->device, "fq", 1, 0, 0,
		&tmp, "DPDCEI-Q"))
		!= 0)
			return err;
	dpdcei->rx_queue_info.rx_fqid = (uint32_t)tmp;

	return 0;
}

static int resources_deallocation(struct dpdcei *dpdcei)
{
	int err;

	/* FQID */
	if ((err = deallocate_resource(
		dpdcei->device, "fq",
		(int)dpdcei->tx_queue_info.tx_fqid, "DPDCEI-Q"))
		!= 0)
			return err;
	if ((err = deallocate_resource(
		dpdcei->device, "fq",
		(int)dpdcei->rx_queue_info.rx_fqid, "DPDCEI-Q"))
		!= 0)
			return err;

	return 0;
}

static int resources_authorization(struct dpdcei *dpdcei)
{
	struct qbman_swp *sw_portal = NULL;
	int		 err;

	if (dpdcei->authorized)
		return 0;

	dpmng_get_swportal(dpdcei->dpmng, (void**)&sw_portal);

	/* FQIDs */
	if ((err = resource_authorization(
		sw_portal, dpdcei->amq.bdi, dpdcei->amq.icid,
		qbman_auth_type_fqid,
		&dpdcei->tx_queue_info.tx_virt_fqid,
		dpdcei->tx_queue_info.tx_fqid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-FQID"))
		!= 0)
	{
		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
		return err;
	}

	if ((err = resource_authorization(
		sw_portal, dpdcei->amq.bdi, dpdcei->amq.icid,
		qbman_auth_type_fqid,
		&dpdcei->rx_queue_info.rx_virt_fqid,
		dpdcei->rx_queue_info.rx_fqid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-FQID"))
		!= 0)
	{
		resource_deauthorization(
			sw_portal, dpdcei->amq.bdi, dpdcei->amq.icid,
			qbman_auth_type_fqid,
			dpdcei->tx_queue_info.tx_virt_fqid,
			(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-FQID");

		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
		return err;
	}

	dpdcei->authorized = 1;
	dpmng_put_swportal(dpdcei->dpmng, sw_portal);

	return 0;
}

static int resources_deauthorization(struct dpdcei *dpdcei)
{
	struct qbman_swp *sw_portal = NULL;
	int err;

	CHECK_COND_RETVAL(dpdcei, -EINVAL);

	if (!dpdcei->authorized)
		return 0;

	dpmng_get_swportal(dpdcei->dpmng, (void**)&sw_portal);

	/* FQIDs */
	if ((err = resource_deauthorization(
		sw_portal, dpdcei->amq.bdi, dpdcei->amq.icid,
		qbman_auth_type_fqid,
		dpdcei->tx_queue_info.tx_virt_fqid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "TX-FQID"))
		!= 0) {
		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
		return err;
	}

	if ((err = resource_deauthorization(
		sw_portal, dpdcei->amq.bdi, dpdcei->amq.icid,
		qbman_auth_type_fqid,
		dpdcei->rx_queue_info.rx_virt_fqid,
		(QBMAN_AUTH_SWP | QBMAN_AUTH_DCP), "RX-FQID"))
		!= 0) {
		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
		return err;
	}

	dpmng_put_swportal(dpdcei->dpmng, sw_portal);
	dpdcei->authorized = 0;
	dpdcei->amq.icid = (uint16_t)-1;

	return 0;
}

/*
 * Queues that were already connected to destination, we only want to
 * enable/disable queues by disable/enable CG
 */
static int queues_set_rejection_mode(struct dpdcei *dpdcei,
	int en)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	uint32_t fqctrl, cgid;
	int err;

	CHECK_COND_RETVAL(dpdcei, -EINVAL);

	cgid = (uint32_t)dpmng_get_cgid(dpdcei->dpmng);

	dpmng_get_swportal(dpdcei->dpmng, (void**)&sw_portal);

	/* TX-FQID*/
	qbman_fq_attr_clear(&fqdesc);
	err = qbman_fq_query(sw_portal,
				dpdcei->tx_queue_info.tx_fqid,
				&fqdesc);
	if (err != 0) {
		pr_err("queues_set_rejection_mode failed\n");
		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
		return err;
	}

	qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
	if (!en) {
		fqctrl &= ~QBMAN_FQCTRL_CGR;
		cgid = 0;
	} else
		fqctrl |= QBMAN_FQCTRL_CGR;

	qbman_fq_attr_set_fqctrl(&fqdesc, fqctrl);
	qbman_fq_attr_set_cgrid(&fqdesc, cgid);

	err = qbman_fq_configure(
		sw_portal, dpdcei->tx_queue_info.tx_fqid, &fqdesc);
	if (err != 0) {
		pr_err("queues_set_rejection_mode failed\n");
		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
		return err;
	}

	dpmng_put_swportal(dpdcei->dpmng, sw_portal);
	return 0;
}

static int config_tx_queue(struct dpdcei *dpdcei)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	int err, ps = 0;
	struct qbman_attr state;
    uint32_t decompression_offset=0;
    CHECK_COND_RETVAL(dpdcei, -EINVAL);

	ps = qbman_cacheable_pfdr();
	dpmng_get_swportal(dpdcei->dpmng, (void**)&sw_portal);

	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_ctx(
		&fqdesc, 0,
		(uint32_t)dpdcei->rx_queue_info.rx_virt_fqid);
	qbman_fq_attr_set_erfqid(
		&fqdesc, dpdcei->rx_queue_info.rx_fqid);
	qbman_fq_attr_set_icid(&fqdesc, dpdcei->amq.icid, dpdcei->amq.pl);
	qbman_fq_attr_set_mctl(&fqdesc, dpdcei->amq.bdi, 0, dpdcei->amq.va, ps, 0);
	qbman_fq_attr_set_vfqid(&fqdesc,
				dpdcei->tx_queue_info.tx_virt_fqid);
	err = qbman_fq_configure(
		sw_portal, dpdcei->tx_queue_info.tx_fqid, &fqdesc);
	if (err != 0) {
		pr_err("qbman_fq_configure failed\n");
		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
		return err;
	}

	if(dpdcei->engine == DPDCEI_ENGINE_DECOMPRESSION)
		decompression_offset=1;
	qbman_fq_attr_set_destwq(
		&fqdesc,
		(uint32_t)((0xE30 + decompression_offset) << 3
				| dpdcei->tx_queue_info.tx_priority
					- 1));

	err = qbman_fq_configure(
		sw_portal, dpdcei->tx_queue_info.tx_fqid, &fqdesc);

	if (err != 0) {
		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
		pr_err( "qbman_fq_configure failed\n");
		return err;
	}

	err = qbman_fq_query_state(
		sw_portal, dpdcei->tx_queue_info.tx_fqid, &state);
	if (err != 0) {
		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
		pr_err("DPDCEI ID[%d]: qbman_fq_query failed\n", dpdcei->id);
		return err;
	}

	if (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_parked) {
		err = qbman_swp_fq_schedule(
			sw_portal, dpdcei->tx_queue_info.tx_fqid);
		if (err != 0) {
			pr_err("qbman_swp_fq_schedule failed\n");
			dpmng_put_swportal(dpdcei->dpmng, sw_portal);
			return err;
		}
	}

	dpmng_put_swportal(dpdcei->dpmng, sw_portal);
	return 0;
}

static int config_rx_queue(struct dpdcei *dpdcei)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	struct qbman_attr state;
	uint32_t fqctrl;
	int err, ps = 0;

	CHECK_COND_RETVAL(dpdcei, -EINVAL);

	ps = qbman_cacheable_pfdr();
	dpmng_get_swportal(dpdcei->dpmng, (void**)&sw_portal);

	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_ctx(
		&fqdesc,
		(uint32_t)(dpdcei->rx_queue_info.user_ctx >> 32),
		(uint32_t)(dpdcei->rx_queue_info.user_ctx));
	qbman_fq_attr_set_icid(&fqdesc, dpdcei->amq.icid, dpdcei->amq.pl);
	qbman_fq_attr_set_mctl(&fqdesc, dpdcei->amq.bdi, 0, dpdcei->amq.va, ps, 0);
	qbman_fq_attr_set_vfqid(&fqdesc,
				dpdcei->rx_queue_info.rx_virt_fqid);
	err = qbman_fq_configure(
		sw_portal, dpdcei->rx_queue_info.rx_fqid, &fqdesc);
	if (err != 0) {
		pr_err("qbman_fq_configure failed\n");
		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
		return err;
	}

	dpmng_put_swportal(dpdcei->dpmng, sw_portal);

	if (dpdcei->rx_queue_info.rx_dest_cfg.dest_type
		!= DPDCEI_DEST_NONE) {
		uint16_t destwq;
		if (dpdcei->rx_queue_info.rx_dest_cfg.dest_type
			== DPDCEI_DEST_DPIO) {
			struct dpio *dpio =
				sys_get_handle(
					FSL_MOD_DPIO,
					1,
					dpdcei->rx_queue_info.rx_dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpio, -ENAVAIL);
			err =
				dpio_get_destwq(
					dpio,
					dpdcei->rx_queue_info.rx_dest_cfg.priority,
					&destwq);
			CHECK_COND_RETVAL(err == 0, err);
			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			qbman_fq_attr_set_fqctrl(
				&fqdesc, fqctrl | QBMAN_FQCTRL_FQDAN);
		} else { /*DPDCEI_DPCON */
			struct dpcon *dpcon =
				sys_get_handle(
					FSL_MOD_DPCON,
					1,
					dpdcei->rx_queue_info.rx_dest_cfg.dest_id);
			CHECK_COND_RETVAL(dpcon, -ENAVAIL);
			err =
				dpcon_get_destwq(
					dpcon,
					dpdcei->rx_queue_info.rx_dest_cfg.priority,
					&destwq);
			CHECK_COND_RETVAL(err == 0, err);
			qbman_fq_attr_get_fqctrl(&fqdesc, &fqctrl);
			qbman_fq_attr_set_fqctrl(
				&fqdesc, fqctrl & ~QBMAN_FQCTRL_FQDAN);
		}
		qbman_fq_attr_set_destwq(&fqdesc, destwq);

		dpmng_get_swportal(dpdcei->dpmng, (void**)&sw_portal);
		err = qbman_fq_configure(
			sw_portal, dpdcei->rx_queue_info.rx_fqid,
			&fqdesc);
		if (err != 0) {
			dpmng_put_swportal(dpdcei->dpmng, sw_portal);
			pr_err("qbman_fq_configure failed\n");
			return err;
		}

		err = qbman_fq_query_state(
			sw_portal, dpdcei->rx_queue_info.rx_fqid,
			&state);
		if (err != 0) {
			dpmng_put_swportal(dpdcei->dpmng, sw_portal);
			pr_err("DPDCEI ID[%d]: qbman_fq_query failed\n", dpdcei->id);
			return err;
		}

		if (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_parked) {
			err = qbman_swp_fq_schedule(
				sw_portal,
				dpdcei->rx_queue_info.rx_fqid);
			if (err != 0) {
				pr_err("qbman_swp_fq_schedule failed\n");
				dpmng_put_swportal(dpdcei->dpmng, sw_portal);
				return err;
			}
		}

		dpmng_put_swportal(dpdcei->dpmng, sw_portal);
	}

	return 0;
}

static int queues_configuration(struct dpdcei *dpdcei)
{
	int err;

	if ((err = config_tx_queue(dpdcei)) != 0) {
		return err;
	}
	if ((err = config_rx_queue(dpdcei)) != 0) {
		return err;
	}
	return 0;
}

static int clear_rx_fqid(struct dpdcei *dpdcei,
	struct dpdcei_rx_queue_info *rx_queue_info)
{
	CHECK_COND_RETVAL(dpdcei, -EINVAL);

	if (!rx_queue_info->retire_storage)
		rx_queue_info->retire_storage =
			(struct qbman_result *)fsl_xmalloc(
				sizeof(struct qbman_result), 0, 64);
	CHECK_COND_RETVAL(rx_queue_info->retire_storage, -ENOMEM);

	dpmng_clear_fqid(rx_queue_info->rx_fqid,
				rx_queue_info->retire_storage,
				&rx_queue_info->retire_pending);

	if (rx_queue_info->retire_pending == 1)
		return 0;

	rx_queue_info->user_ctx = 0;
	memset(&rx_queue_info->rx_dest_cfg, 0, sizeof(struct dpdcei_dest_cfg));

	return 0;
}

static int clear_tx_fqid(struct dpdcei *dpdcei,
	struct dpdcei_tx_queue_info *tx_queue_info)
{

	CHECK_COND_RETVAL(dpdcei, -EINVAL);

	if (!tx_queue_info->retire_storage)
		tx_queue_info->retire_storage =
			(struct qbman_result *)fsl_xmalloc(
				sizeof(struct qbman_result), 0, 64);
	CHECK_COND_RETVAL(tx_queue_info->retire_storage, -ENOMEM);

	dpmng_clear_fqid(tx_queue_info->tx_fqid,
				tx_queue_info->retire_storage,
				&tx_queue_info->retire_pending);


	if (tx_queue_info->retire_pending == 1)
		return 0;

	return 0;
}

static int clear_queues(struct dpdcei *dpdcei)
{
	struct qbman_swp *sw_portal;

	CHECK_COND_RETVAL(dpdcei, -EINVAL);

	dpmng_get_swportal(dpdcei->dpmng, (void**)&sw_portal);
	clear_tx_fqid(dpdcei, &dpdcei->tx_queue_info);
	clear_rx_fqid(dpdcei, &dpdcei->rx_queue_info);
	dpmng_put_swportal(dpdcei->dpmng, (void*)sw_portal);

	return 0;
}

static int drain_queue(struct dpdcei *dpdcei, uint32_t fqid)
{
	struct qbman_swp *swp;
	struct qbman_pull_desc pulldesc;
	const struct qbman_result *dq_storage = NULL;
	int err, timeout = DPDCEI_RESET_TIMEOUT, found = 0;
	struct qbman_fd fd_dq;
	const struct qbman_fd *__fd;
	struct qbman_attr state;

	CHECK_COND_RETVAL(dpdcei, -EINVAL);

	dpmng_get_swportal(dpdcei->dpmng, (void **)&swp);
	err = qbman_fq_query_state(swp, fqid, &state);
	dpmng_put_swportal(dpdcei->dpmng, (void *)swp);
	if (err) {
		pr_err("DPDCEI ID[%d]: qbman_fq_query failed\n", dpdcei->id);
		return err;
	}
	if (qbman_fq_state_schedstate(&state) == qbman_fq_schedstate_oos) {
		pr_warn("DPDCEI ID[%d]: queue can't be emptied\n", dpdcei->id);
		return 0;
	}

	/* Drain FQ */
	dpmng_get_swportal(dpdcei->dpmng, (void **)&swp);
	do {
		qbman_pull_desc_clear(&pulldesc);
		qbman_pull_desc_set_storage(&pulldesc, NULL, 0, 0);
		qbman_pull_desc_set_numframes(&pulldesc, 1);
		qbman_pull_desc_set_token(&pulldesc, 0xab);
		qbman_pull_desc_set_fq(&pulldesc, fqid);
		err = qbman_swp_pull(swp, &pulldesc);
		if (err) {
			dpmng_put_swportal(dpdcei->dpmng, swp);
			return err;
		}

		dq_storage = qbman_swp_dqrr_next(swp);
		if (!dq_storage)
			break;

		if (!qbman_result_is_DQ(dq_storage)) {
			dpmng_put_swportal(dpdcei->dpmng, swp);
			pr_err("DPDCEI ID[%d]: QBMAN dequeue result not valid %d\n",
					dpdcei->id);
			return -EFAULT;
		}

		/* check response FD for flush command on RX queue */
		if (!found && (qbman_result_DQ_flags(dq_storage)
			 & QBMAN_DQ_STAT_VALIDFRAME)) {
			__fd = qbman_result_DQ_fd(dq_storage);
			memcpy((uint8_t *)&fd_dq, (uint8_t *)__fd,
				sizeof(struct qbman_fd));
			if (fd_dq.simple.frc == DPDCEI_FRC_FQID_FLUSH) {
				found = 1;
				qbman_swp_dqrr_consume(swp, dq_storage);
				break;
			}
			timeout = DPDCEI_RESET_TIMEOUT;
		}
		qbman_swp_dqrr_consume(swp, dq_storage);
	} while (!(qbman_result_DQ_flags(dq_storage) & QBMAN_DQ_STAT_FQEMPTY)
			&& --timeout);

	dpmng_put_swportal(dpdcei->dpmng, (void *)swp);

	if (!timeout) {
		pr_warn("DPDCEI ID[%d]: Timeout when emptying queue %d\n",
			dpdcei->id, fqid);
	}

	if (!found) {
		pr_warn("DPDCEI ID[%d]: Flush on queue %d not confirmed\n",
				dpdcei->id, fqid);
	}

	return 0;
}

static int flush_dce_queue(struct dpdcei *dpdcei, uint32_t fqid)
{
	struct qbman_swp *swp = NULL;
	struct qbman_fd fd_eq;
	struct qbman_eq_desc eqdesc;
	struct qbman_attr state;
	int err = 0;

	CHECK_COND_RETVAL(dpdcei, -EINVAL);

	dpmng_get_swportal(dpdcei->dpmng, (void **)&swp);
	err = qbman_fq_query_state(swp, fqid, &state);
	if (err) {
		dpmng_put_swportal(dpdcei->dpmng, swp);
		pr_err("DPDCEI ID[%d]: qbman_fq_query failed\n", dpdcei->id);
		return err;
	}

	if ((qbman_fq_state_retirement_pending(&state))
		|| (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_retired)
		|| (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_oos)) {
		dpmng_put_swportal(dpdcei->dpmng, swp);
		pr_err("DPDCEI ID[%d]: TX queue not in valid state\n",
			dpdcei->id);
		return -EFAULT;
	}

	memset(&fd_eq, 0, sizeof(struct qbman_fd));
	fd_eq.simple.ctrl |= DPDCEI_RESET_FD_CTRL;
	fd_eq.simple.frc |= DPDCEI_FRC_FQID_FLUSH;
	qbman_eq_desc_clear(&eqdesc);
	qbman_eq_desc_set_no_orp(&eqdesc, 0);
	qbman_eq_desc_set_fq(&eqdesc, fqid);
	err = qbman_swp_enqueue(swp, &eqdesc, &fd_eq);
	if (err)
		pr_warn("DPDCEI ID[%d]: Enqueue of FQID scope flush command on TX queue failed\n",
			dpdcei->id);
	dpmng_put_swportal(dpdcei->dpmng, swp);
	return err;
}

static int flush_dce(struct dpdcei *dpdcei)
{
	struct qbman_swp *swp = NULL;
	struct qbman_attr state;
	int err;
	uint32_t fqid;

	CHECK_COND_RETVAL(dpdcei, -EINVAL);

	/* prepare RX queue before sending flush FD */
	fqid = dpdcei->rx_queue_info.rx_fqid;
	dpmng_get_swportal(dpdcei->dpmng, (void **)&swp);
	err = qbman_fq_query_state(swp, fqid, &state);
	if (err) {
		dpmng_put_swportal(dpdcei->dpmng, swp);
		pr_err("DPDCEI ID[%d]: qbman_fq_query_state failed\n",
				dpdcei->id);
		return err;
	}
	if ((qbman_fq_state_retirement_pending(&state))
		|| (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_retired)
		|| (qbman_fq_state_schedstate(&state)
			== qbman_fq_schedstate_oos)) {
		dpmng_put_swportal(dpdcei->dpmng, swp);
		pr_warn("DPDCEI ID[%d]: RX queue not in valid state\n",
			dpdcei->id);
		return 0;
	}

	/* send FD for flush operation */
	err = flush_dce_queue(dpdcei, dpdcei->tx_queue_info.tx_fqid);
	if (!err) {
		/* empty Rx queues */
		err = drain_queue(dpdcei, dpdcei->rx_queue_info.rx_fqid);
		CHECK_COND_RETVAL(err == 0, err);
	} else {
		pr_warn("DPDCEI ID[%d]: Could not flush DCE\n", dpdcei->id);
		return 0;
	}

	return 0;
}

struct dpdcei *dpdcei_allocate(void)
{
	struct dpdcei *dpdcei;

	dpdcei = (struct dpdcei *)fsl_malloc(sizeof(struct dpdcei));
	if (dpdcei)
		memset(dpdcei, 0, sizeof(struct dpdcei));
	return dpdcei;
}

void dpdcei_deallocate(struct dpdcei *dpdcei)
{
	fsl_free(dpdcei);
}

static void dpdcei_set_mc_info(struct dpdcei *dpdcei,
		const struct dpmng_dev_cfg *dev_cfg)
{
	dpdcei->dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dpdcei->dpmng);

	dpdcei->id = dev_cfg->id;
	dpdcei->device = dev_cfg->device;
}


int dpdcei_set_dev_ctx(struct dpdcei *dpdcei,
		       const struct dpmng_dev_ctx *dev_ctx)
{
	int err;

	if (memcmp(&dpdcei->amq, &(dev_ctx->amq), sizeof(struct dpmng_amq)) != 0) {
		CHECK_COND_RETVAL(!dpdcei->en, -EINVAL);
		if ((err = resources_deauthorization(dpdcei)) != 0) {
			pr_err("ID[%d]: resources_deauthorization failed \n", dpdcei->id);
			return err;
		}

		dpdcei->amq = dev_ctx->amq;
		dpdcei->amq.bdi =
			(dev_ctx->type == DPMNG_CTX_TYPE_AIOP) ? 1 : 0;

		if ((err = resources_authorization(dpdcei)) != 0) {
			pr_err("ID[%d]: resources_authorization failed \n", dpdcei->id);
			return err;
		}
	}

	if ((err = queues_configuration(dpdcei)) != 0) {
		pr_err("ID[%d]:  initial_configuration after authorization failed \n", dpdcei->id);
		return err;
	}
	return 0;
}

#include "fsl_dce_ctrl.h"
static int workaround_decomp_dpdcei_created;

int dpdcei_init(struct dpdcei *dpdcei,
		const struct dpdcei_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg)
{
	int  i, err;

	if (!IN_RANGE(1, cfg->priority, 8)) {
		pr_err("Priority (%d) not in valid range (1-8)\n", cfg->priority);
		return -EINVAL;
	}

	dpdcei_set_mc_info(dpdcei, dev_cfg);

	dpdcei->tx_queue_info.tx_priority = cfg->priority;
	dpdcei->engine = cfg->engine;

	if (dpdcei->engine == DPDCEI_ENGINE_DECOMPRESSION
			&& dce_block_get_version() <= ERR010843_DCE_REV) {
		/* This logic assumes a single MC context. This does not protect
		 * against a multithreaded MC */
		if (!workaround_decomp_dpdcei_created) {
			workaround_decomp_dpdcei_created = 1;
		} else {
			pr_err("Only 1 decompression dpdcei allowed in system due to errata ERR010843\n");
			return -ENAVAIL;
		}
	}

	pr_debug("resources_allocation()\n");

	if ((err = resources_allocation(dpdcei)) != 0) {
		resources_deallocation(dpdcei);
		pr_err("resources_allocation failed\n");
		return err;
	}

	dpdcei->amq.icid = (uint16_t)-1;

	err = queues_configuration(dpdcei);
	if (err != 0) {
		pr_err("ID[%d]: queues_configuration failed\n", dpdcei->id);
		dpdcei_destroy(dpdcei);
		return err;
	}

	/* CG enabled for queues*/
	if ((err = queues_set_rejection_mode(dpdcei, 1))
		!= 0)
		return err;

	for (i = 0; i < DPDCEI_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpdcei->irqs[i]), MC_IRQ_TYPE_MSI);

	return 0;
}

int dpdcei_destroy(struct dpdcei *dpdcei)
{
	int err;

	if (dpdcei->en) {
		if ((err = dpdcei_disable(dpdcei)) != 0) {
			pr_err("dpdcei_disable failed\n");
			return err;
		}
	}

	err = resources_deauthorization(dpdcei);
	CHECK_COND_RETVAL(err == 0, err);
	err = clear_queues(dpdcei);
	CHECK_COND_RETVAL(err == 0, err);
	memset(&dpdcei->rx_queue_info.rx_dest_cfg,
			0, sizeof(struct dpdcei_dest_cfg));
	dpdcei->rx_queue_info.rx_virt_fqid = 0;
	dpdcei->tx_queue_info.tx_virt_fqid = 0;

	err = resources_deallocation(dpdcei);
	CHECK_COND_RETVAL(err == 0, err);

	if (dpdcei->engine == DPDCEI_ENGINE_DECOMPRESSION
			&& dce_block_get_version() <= ERR010843_DCE_REV) {
		/* This logic assumes a single MC context. This does not protect
		 * against a multithreaded MC */
		if (workaround_decomp_dpdcei_created) {
			workaround_decomp_dpdcei_created = 0;
		} else {
			pr_err("Unexpected condition. Decompression dpdcei is successfully destroyed, but workaround flag was not set\n");
			return -ENAVAIL;
		}
	}

	return 0;
}

int dpdcei_enable(struct dpdcei *dpdcei)
{
	int err;

	/* CG disabled for queues*/
	if ((err = queues_set_rejection_mode(dpdcei, 0))
		!= 0)
		return err;

	dpdcei->en = 1;

	return 0;
}

int dpdcei_disable(struct dpdcei *dpdcei)
{
	int err;

	/* CG enabled for queues*/
	if ((err = queues_set_rejection_mode(dpdcei, 1))
		!= 0)
		return err;
	dpdcei->en = 0;

	return 0;
}

int dpdcei_is_enabled(struct dpdcei *dpdcei, int *en)
{
	if (dpdcei->en == 1)
		*en = 1;
	else
		*en = 0;

	return 0;
}

int dpdcei_get_rx_queue(struct dpdcei *dpdcei,
	struct dpdcei_rx_queue_attr *attr)
{
	attr->fqid = dpdcei->rx_queue_info.rx_virt_fqid;
	attr->user_ctx = dpdcei->rx_queue_info.user_ctx;
	memcpy(&attr->dest_cfg, &dpdcei->rx_queue_info.rx_dest_cfg,
		sizeof(struct dpdcei_dest_cfg));

	return 0;
}

int dpdcei_get_tx_queue(struct dpdcei *dpdcei,
	struct dpdcei_tx_queue_attr *attr)
{

	attr->fqid = dpdcei->tx_queue_info.tx_virt_fqid;

	return 0;
}


int dpdcei_set_rx_queue(struct dpdcei *dpdcei,
	const struct dpdcei_rx_queue_cfg *cfg)
{
	int err;

	if (!cfg->options)
		return 0;

	if (cfg->options & DPDCEI_QUEUE_OPT_DEST) {
		if (cfg->dest_cfg.dest_type == DPDCEI_DEST_DPCON) {
			struct dpcon *dpcon = sys_get_handle(
				FSL_MOD_DPCON, 1, cfg->dest_cfg.dest_id);
			if (!dpcon) {
				pr_err("dpcon_id is invalid\n");
				return -EINVAL;
			}
			if (!dpcon_is_priority_in_range(
				dpcon, cfg->dest_cfg.priority)) {
				pr_err("dpcon priority not in range\n");
				return -EINVAL;
			}
		}

		if (cfg->dest_cfg.dest_type == DPDCEI_DEST_DPIO) {
			struct dpio *dpio = sys_get_handle(
				FSL_MOD_DPIO, 1, cfg->dest_cfg.dest_id);
			if (!dpio) {
				pr_err("dpio_id is invalid\n");
				return -EINVAL;
			}
			if (!dpio_is_priority_in_range(
				dpio, cfg->dest_cfg.priority)) {
				pr_err("priority not in range\n");
				return -EINVAL;
			}
		}
	}

	if ((cfg->options & DPDCEI_QUEUE_OPT_DEST)
		&& (cfg->dest_cfg.dest_type == DPDCEI_DEST_NONE)
		&& (dpdcei->rx_queue_info.rx_dest_cfg.dest_type
		!= DPDCEI_DEST_NONE)) {
			pr_err( "ID[%d]: Cannot change back to parked mode\n", dpdcei->id);
			return -ENOTSUP;
	}

	if (cfg->options & DPDCEI_QUEUE_OPT_USER_CTX)
		dpdcei->rx_queue_info.user_ctx = cfg->user_ctx;

	if (cfg->options & DPDCEI_QUEUE_OPT_DEST)
		memcpy(&dpdcei->rx_queue_info.rx_dest_cfg,
			   &(cfg->dest_cfg),
			   sizeof(struct dpdcei_dest_cfg));

	err = config_rx_queue(dpdcei);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

#include "fsl_dce_ctrl.h"

int dpdcei_get_attributes(struct dpdcei *dpdcei, struct dpdcei_attr *attr)
{

	attr->id = (int)dpdcei->id;
	attr->engine = dpdcei->engine;
	attr->dce_version = dce_block_get_version();

	return 0;
}

int dpdcei_reset(struct dpdcei *dpdcei)
{
	int err;

	CHECK_COND_RETVAL(dpdcei, -EINVAL);

	/* Clear any DCE cache related to this FQID */
	err = flush_dce(dpdcei);
	CHECK_COND_RETVAL(err == 0, err);

	err = resources_deauthorization(dpdcei);
	CHECK_COND_RETVAL(err == 0, err);

	if (dpdcei->en) {
		if ((err = dpdcei_disable(dpdcei)) != 0) {
			pr_err("dpdcei_disable failed\n");
			return err;
		}
	}

	err = clear_queues(dpdcei);
	CHECK_COND_RETVAL(err == 0, err);

	memset(&dpdcei->rx_queue_info.rx_dest_cfg,
			0, sizeof(struct dpdcei_dest_cfg));
	dpdcei->rx_queue_info.rx_virt_fqid = 0;
	dpdcei->tx_queue_info.tx_virt_fqid = 0;

	if ((err = queues_set_rejection_mode(dpdcei, 1))
		!= 0)
		return err;

	return 0;
}

int dpdcei_set_irq(struct dpdcei *dpdcei,
		  uint8_t irq_index,
		  const struct mc_irq_cfg *irq_cfg)
{
	UNUSED(irq_index);
	UNUSED(irq_cfg);

	pr_err("ID[%d]: IRQs are not supported\n", dpdcei->id);
	return -ENOTSUP;
}

int dpdcei_get_irq(struct dpdcei *dpdcei,
		  uint8_t irq_index,
		  struct mc_irq_cfg *irq_cfg)
{
	UNUSED(irq_index);
	UNUSED(irq_cfg);

	pr_err("ID[%d]: IRQs are not supported\n", dpdcei->id);
	return -ENOTSUP;
}

int dpdcei_set_irq_enable(struct dpdcei *dpdcei, uint8_t irq_index, uint8_t en)
{
	UNUSED(irq_index);
	UNUSED(en);

	pr_err("ID[%d]: IRQs are not supported\n", dpdcei->id);
	return -ENOTSUP;
}

int dpdcei_get_irq_enable(struct dpdcei *dpdcei, uint8_t irq_index, uint8_t *en)
{
	UNUSED(irq_index);
	UNUSED(en);

	pr_err("ID[%d]: IRQs are not supported\n", dpdcei->id);
	return -ENOTSUP;
}

int dpdcei_set_irq_mask(struct dpdcei *dpdcei,
			uint8_t irq_index,
			uint32_t mask)
{
	UNUSED(irq_index);
	UNUSED(mask);

	pr_err("ID[%d]: IRQs are not supported\n", dpdcei->id);
	return -ENOTSUP;
}

int dpdcei_get_irq_mask(struct dpdcei *dpdcei,
			uint8_t irq_index,
			uint32_t *mask)
{
	UNUSED(irq_index);
	UNUSED(mask);

	pr_err("ID[%d]: IRQs are not supported\n", dpdcei->id);
	return -ENOTSUP;
}

int dpdcei_get_irq_status(struct dpdcei *dpdcei,
			  uint8_t irq_index,
			  uint32_t *status)
{
	UNUSED(irq_index);
	UNUSED(status);

	pr_err("ID[%d]: IRQs are not supported\n", dpdcei->id);
	return -ENOTSUP;
}

int dpdcei_clear_irq_status(struct dpdcei *dpdcei,
			    uint8_t irq_index,
			    uint32_t status)
{
	UNUSED(irq_index);
	UNUSED(status);

	pr_err("ID[%d]: IRQs are not supported\n", dpdcei->id);
	return -ENOTSUP;
}
