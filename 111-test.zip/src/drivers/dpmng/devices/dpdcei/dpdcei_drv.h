/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpdcei_drv.h

 @Description   DPDCEI internal structures and definitions.
*//***************************************************************************/
#ifndef __DPDCEI_DRV_H
#define __DPDCEI_DRV_H

#include "fsl_types.h"


int dpdcei_drv_init(void);


#endif /* __DPDCEI_DRV_H */
