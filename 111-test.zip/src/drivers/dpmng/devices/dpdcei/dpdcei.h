/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpdcei.h

 @Description   DPDCEI internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPDCEI_H
#define __DPDCEI_H

#include "fsl_dpdcei_mc.h"
#include "kernel/fsl_spinlock.h"
#include "fsl_dptbl.h"
#include "fsl_types.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPDCEI

#define DPDCEI_RESET_TIMEOUT 100000

#define DPDCEI_RESET_FD_CTRL (9201 << 14)
#define DPDCEI_FRC_FQID_FLUSH 0x60000000
#define DPDCEI_FRC_NOP 0xE0000000

struct dpdcei_rx_queue_info {
	uint32_t rx_fqid;
	uint32_t rx_virt_fqid;
	struct dpdcei_dest_cfg rx_dest_cfg;
	uint64_t user_ctx;

	int retire_pending;
	struct qbman_result *retire_storage;
};

struct dpdcei_tx_queue_info {
	uint8_t tx_priority;
	uint32_t tx_fqid;
	uint32_t tx_virt_fqid;

	int retire_pending;
	struct qbman_result *retire_storage;
};

struct dpdcei {
	/* parameters for run-time (in order to be in cache) */
	uint32_t 			id;
	enum dpdcei_engine 	engine;
	int 				en;
	int 				authorized;
	spinlock_t 			lock;
	struct device 		*device;
	struct dpmng_amq 	amq;
	struct dpmng 		*dpmng;
	struct dpdcei_rx_queue_info rx_queue_info;
	struct dpdcei_tx_queue_info tx_queue_info;

	uint8_t irq_count;
	struct mc_irq irqs[DPDCEI_MAX_IRQ_NUM];
};

#endif /* __DPDCEI_H */
