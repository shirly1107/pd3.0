/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File	  dpdmux.c

 @Description   Library implementation

 @Cautions      None.
 *//***************************************************************************/
#include "dpdmux.h"
#include "hmap.h"
#include "fsl_timer.h"
#include "fsl_dpni_mc.h"
#include "eiop_ifp.h"
#include "flow_control.h"

/* local flags used in flow control configuration */
#define DPDMUX_ENABLE_FC_SENDING		0x0001
#define DPDMUX_ENABLE_FC_RESPONSE		0x0002
#define DPDMUX_UPDATE_FC				0x8000

#include "device.h"


/**
 * @brief	Function declaration
 */
static void irq_if_trigger(struct dpdmux *dpdmux,
	uint16_t if_id, uint16_t event);
static uint32_t irq_if_compose_message(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t event);
static int irq_get_pending_if(struct dpdmux *dpdmux, uint16_t *if_id);
static uint16_t irq_if_restore_event(struct dpdmux *dpdmux, uint16_t if_id);
static void irq_if_save_event(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t event);

static int init_default(struct dpdmux *dpdmux);

static int if_associate_with_lni(struct dpdmux *dpdmux,
	uint16_t if_id, int shaped);
static int virt_link_rates(
        const struct linkman_endpoint   *ep1,
        const struct linkman_endpoint   *ep2,
        const struct linkman_control   *control,
        struct linkman_link_state       *link_state,
        uint32_t *max_rate);
static int if_get_counter_vepa(struct dpdmux *dpdmux,
	uint16_t if_id,
	enum dpdmux_counter_type type,
	uint64_t *counter);
static int multicast_management_rules_params_integrity(
	struct dpdmux *dpdmux,
        int table_id,
        int hmap_id);

static int link_event(struct dpdmux *dpdmux,
	enum linkman_event event,
	uint16_t if_id);

/* CEETM Interface APIs */
static int init_ceetm_if(struct dpdmux  *dpdmux, uint16_t if_id);
static int init_deafult_ceetm_if(struct dpdmux  *dpdmux);
static int init_default_ceetm_if_tx_selection(struct dpdmux  *dpdmux);
static int init_default_ceetm_if_early_drop(struct dpdmux  *dpdmux);
static int if_set_tx_selection_params_integrity(
	struct dpdmux  *dpdmux,
	uint16_t if_id,
        const struct dpdmux_tx_selection_cfg *ts);

static int if_set_tx_selection_params_save(
	struct dpdmux  *dpdmux,
	uint16_t if_id,
        const struct dpdmux_tx_selection_cfg *ts);

static int if_set_tx_selection_ccqs(
	struct dpdmux  *dpdmux,
	uint16_t if_id);

/* called from connect and dpdmux_if_set_tx_selection */
static int if_set_tx_selection_qos_mapping(
	struct dpdmux  *dpdmux,
	uint16_t if_id,
	enum fsl_module type);

static int get_connection(
	struct dpdmux  *dpdmux,
	uint16_t if_id,
	struct linkman_endpoint *ep,
	struct linkman_connection_attr *attr);

static int if_set_early_drop_params_integrity(struct dpdmux *dpdmux,
                        uint16_t if_id,
                        uint8_t tc_id,
                        const struct dpdmux_early_drop_cfg *drop_cfg);

static int if_set_early_drop(struct dpdmux *dpdmux,
                        uint16_t if_id,
                        uint8_t tc_id,
                        const struct dpdmux_early_drop_cfg *drop_cfg);

static enum ceetm_if_ccg_unit get_early_drop_unit(
	enum dpdmux_early_drop_unit unit);

static enum ceetm_if_ccg_mode get_early_drop_mode(
	enum dpdmux_early_drop_mode mode);

static enum ceetm_if_sched_mode get_schedule_mode(
	enum dpdmux_schedule_mode mode);

static int init_if_eiop_qos(struct dpdmux *dpdmux, uint16_t id);

static int if_set_zero_taildrop(struct dpdmux  *dpdmux, int if_id);
static int if_restore_taildrop(struct dpdmux  *dpdmux, int if_id);
static int if_get_early_drop(
		struct dpdmux *dpdmux,
        uint16_t if_id,
        struct dpdmux_early_drop_cfg *drop);


/**************************************************************************//**
 @Collection    DMux Implementation

 @{
 *//***************************************************************************/

#ifdef TKT508412
static int dpdmux_filter_flow_control_multicast(struct dpdmux *dpdmux)
{
	struct dptbl_rule rule;
	struct dptbl_action tbl_deny_action;
	int err;
	uint8_t multicast_mac[] = {0x01, 0x80, 0xc2, 0x00, 0x00, 0x01};

	memset(&rule, 0, sizeof(struct dptbl_rule));
	rule.rule_cfg.exact.key = (uint8_t *)multicast_mac;
	rule.rule_cfg.exact.size = 6;

	memset(&tbl_deny_action, 0, sizeof(struct dptbl_action));
	tbl_deny_action.next_action = DPTBL_ACTION_DONE;
	tbl_deny_action.options = DPTBL_ACTION_SET_DISCARD_FLAG;
	err = dptbl_add_rule(dpdmux->fc_filtering_tbl.handle, &rule, &tbl_deny_action, 0);
	CHECK_COND_RETVAL( err==0, err, "ID[%d]: Failed to add flow control multicast in filter table\n", dpdmux->id);

	return 0;
}
#endif

static void init_handles(struct dpdmux *dpdmux)
{
	/*! Ingress Parser */
	dpdmux->hndl.dpparser_ing = sys_get_handle(FSL_MOD_PARSER, 2, /*! number of params */
							0, /*! iop_id */
							CTLU_EIOP_INGRESS); /*! Ingress */
	CHECK_COND_RET(dpdmux->hndl.dpparser_ing);

	/*! Egress Parser */
	dpdmux->hndl.dpparser_egr = sys_get_handle(FSL_MOD_PARSER, 2, /*! number of params */
							0, /*! iop_id */
							CTLU_EIOP_EGRESS); /*! Egress */
	CHECK_COND_RET(dpdmux->hndl.dpparser_egr);

	/*! Ingress FALU */
	dpdmux->hndl.dppolicy_ing = sys_get_handle(FSL_MOD_POLICIES_MNG, 2, /*! number of params */
							0, /*! iop_id */
							CTLU_EIOP_INGRESS); /*! Ingress */
	CHECK_COND_RET(dpdmux->hndl.dppolicy_ing);

	/*! Ingress Key Generation */
	dpdmux->hndl.dpkg_ing = sys_get_handle(FSL_MOD_KG, 2, /*! number of params */
						0, /*! iop_id */
						CTLU_EIOP_INGRESS); /*! Ingress */
	CHECK_COND_RET(dpdmux->hndl.dpkg_ing);

	dpdmux->hndl.dpkg_egr = sys_get_handle(FSL_MOD_KG, 2, /*! number of params */
						0, /*! iop_id */
						CTLU_EIOP_EGRESS); /*! egress */
	CHECK_COND_RET(dpdmux->hndl.dpkg_egr);

	/*! Ingress Tables */
	dpdmux->hndl.dptbl_ing = sys_get_handle(FSL_MOD_TABLES_MNG, 2, /*! number of params */
						0, /*! iop_id */
						CTLU_EIOP_INGRESS); /*! Ingress */
	CHECK_COND_RET(dpdmux->hndl.dptbl_ing);

	/*! Link manager 2.0 */
	dpdmux->hndl.linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	CHECK_COND_RET(dpdmux->hndl.linkman);

	/*! General manager */
	dpdmux->hndl.dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RET(dpdmux->hndl.dpmng);

	/*! Ingress QoS */
	dpdmux->hndl.dpqos_ing = sys_get_handle(
		FSL_MOD_QoS_MNG, 	/* handle type */
		2, 			/* number of params */
		0, 			/* iop_id */
		CTLU_EIOP_INGRESS); 	/* Ingress */
	CHECK_COND_RET(dpdmux->hndl.dpqos_ing);

}

static int get_key_size(struct dpdmux *dpdmux)
{
	switch (dpdmux->method) {
	case DPDMUX_METHOD_C_VLAN_MAC:
		return 8;
	case DPDMUX_METHOD_MAC:
		return 6;
	case DPDMUX_METHOD_C_VLAN:
	case DPDMUX_METHOD_S_VLAN:
		return 2;
	case DPDMUX_METHOD_CUSTOM:
		return dpdmux->custom_cls_rule_size;
	case DPDMUX_METHOD_NONE:
	default:
		return 0;
	}
	return 0;
}

static int init_ctlu_prp(struct dpdmux *dpdmux,
	enum ctlu_type ctlu_type,
	struct dpdmux_id *prp)
{
	/**
	 -# PRP  Parser Profile
	 */
	int err;
	char type[16];
	struct dpparser *dpparser;

	switch (ctlu_type) {
	case (CTLU_EIOP_EGRESS):
		/* Egress Parser Profile */
		dpparser = dpdmux->hndl.dpparser_egr;
		break;
	case (CTLU_EIOP_INGRESS):
		/* Ingress Parser Profile */
		dpparser = dpdmux->hndl.dpparser_ing;
		break;
	default:
		err = -EINVAL;
		return err;

	}
	dpparser_get_resource_str(dpparser, type);
	err = allocate_resource(dpdmux->hndl.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(prp->id), /* Address to store */
				"PRPID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err, "allocate_resource : %d\n", err);

	err = dpparser_init_profile(dpparser, prp->id, NULL, NULL);
	CHECK_COND_RETVAL(err == 0, err, "dpparser_init_profile : %d\n", err );

	prp->inuse = 1;

	return 0;
}

static int init_bman_bp(struct dpdmux *dpdmux)
{
	/*
	 * Allocate dpbp
	 * Initialize dpbp
	 * dpbp_allocate_buffers
	 */
	int err = 0;
	struct dpbp_cfg dpbp_cfg = { 0 };
	struct dpmng_dev_cfg dev_cfg = { 0 };
	struct dpbp_hw_notification_cfg bp_notification_cfg;

	/*! Allocate DPBP */
	dpdmux->dpbp = dpbp_allocate();
	CHECK_COND_RETVAL(dpdmux->dpbp, -ENAVAIL);

	/*! Init dpbp */
	dev_cfg.device = dpdmux->hndl.dprc;

	err = dpbp_init(dpdmux->dpbp, &dpbp_cfg, &dev_cfg);
	CHECK_COND_RETVAL(err == 0, err, "dpbp_init : %d\n", err);

	/*! Set dpbp AMQ */
	dpmng_get_amq(&(dev_cfg.ctx.amq));

	err = dpbp_set_dev_ctx(dpdmux->dpbp, &(dev_cfg.ctx));
	CHECK_COND_RETVAL(err == 0, err, "dpbp_set_amq : %d\n", err);

	/*! *Enable */
	dpbp_enable(dpdmux->dpbp);

	/*! Allocate buffers */
	err = dpbp_allocate_buffers(dpdmux->dpbp, /*! Context */
					MEM_PART_PEB, /*! PEB memory */
					/* if mem_size property has been specified, use it instead of default value
					 * mem_size represents the number of 256byte buffers.
					 */
					dpdmux->mem_size ? ((uint32_t)dpdmux->mem_size * DPDMUX_BP_BUFFER_SIZE) : DPDMUX_BP_MEMORY_SIZE, /*! Memory size */
					DPDMUX_BP_BUFFER_SIZE); /*! Buffer size */
	CHECK_COND_RETVAL(err == 0, err, "ID[%d] - dpbp_allocate_buffers(), failed to allocate dpbp buffers\n", dpdmux->id);

	/* Configure depletion thresholds */
	memset(&bp_notification_cfg, 0, sizeof(bp_notification_cfg));
	/* Set the hysteresis windows */
	bp_notification_cfg.depletion_entry = 120;
	bp_notification_cfg.depletion_exit = 184;
	err = dpbp_set_hw_notifications(dpdmux->dpbp, &bp_notification_cfg);
	CHECK_COND_RETVAL(err == 0, err, "ID[%d] - dpbp_set_hw_notifications() return error\n", dpdmux->id);

	return err;
}

static int init_err_fq(struct dpdmux *dpdmux)
{
	/**
	 -# Allocate FQID
	 -# Get software portal
	 -# Configure FQID
	 */

	int err;
	struct qbman_attr fqdesc;
	struct qbman_swp *swp;
	struct dpmng_amq amq;

	/* Allocate FQID */
	/* Get software portal */
	dpmng_get_swportal(dpdmux->hndl.dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -ENAVAIL);

	err = allocate_resource(dpdmux->hndl.dprc, /*Resource manager handle */
				"fq", /* Resource type */
				1, /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				&(dpdmux->err_fqid), /* Address */
				"FQID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err, "allocate_resource (FQID) : %d\n", err);

	/* Get ICID */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	/* Configure FQID */
	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_fqctrl(&fqdesc, QBMAN_FQCTRL_HOLDACTIVE);
	qbman_fq_attr_set_icid(&fqdesc, amq.icid, amq.pl);

	qbman_fq_attr_set_tdthresh(&fqdesc, 0);
	err = qbman_fq_configure(swp, (uint32_t)dpdmux->err_fqid, &fqdesc);

	return err;
}

static int replicator_init_fq(struct dpdmux *dpdmux)
{
	/**
	 -# Allocate FQID
	 -# Get software portal
	 -# Configure FQID
	 */

	int err;
	struct qbman_attr fqdesc;
	struct qbman_swp *swp;
	struct dpmng_amq amq;
	/* Allocate FQID */
	enum qbman_fq_schedstate_e ss;
	struct qbman_attr state;

	/* Get software portal */
	dpmng_get_swportal(dpdmux->hndl.dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -ENAVAIL);

	/*! Allocate FQID */
	err = allocate_resource(dpdmux->hndl.dprc, /*Resource manager handle */
				"fq", /* Resource type */
				1, /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				&(dpdmux->replicator.fqid), /* Address */
				"FQID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err, "allocate_resource (replicator FQID) : %d\n", err);

	/* Get AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	/* Configure FQID */
	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_fqctrl(&fqdesc, QBMAN_FQCTRL_HOLDACTIVE);
	qbman_fq_attr_set_icid(&fqdesc, amq.icid, amq.pl);
	qbman_fq_attr_set_mctl(&fqdesc, amq.bdi, 0, amq.va, 0, 0);

	/* dest_wq = 0xFF0 << 3 = 0x7F80 */
	qbman_fq_attr_set_destwq(&fqdesc, DPDMUX_CHID << 3);
	err = qbman_fq_configure(swp, (uint32_t)(dpdmux->replicator.fqid),
					&fqdesc);
	CHECK_COND_RETVAL(err == 0, err);
	
	err = qbman_fq_query_state(swp, (uint32_t)dpdmux->replicator.fqid,
					&state);
	CHECK_COND_RETVAL(err == 0, err);

	ss = (enum qbman_fq_schedstate_e)qbman_fq_state_schedstate(&state);
	if (ss == qbman_fq_schedstate_parked) {
		/*! Override parked mode - frames can be dequeued by WRIOP */
		err = qbman_swp_fq_schedule(
			swp, /* Software portal */
			(uint32_t)dpdmux->replicator.fqid);/* Frame queue */
	}

	return err;
}

static int replicator_init_qpri(struct dpdmux *dpdmux, int max_pri)
{
	int err = 0, i;
	struct qbman_swp *swp;

	dpmng_get_swportal(dpdmux->hndl.dpmng, (void **)&(swp));
	//ASSERT_COND(swp);

	for (i = 0; i < max_pri; i++) {
		/* QPRI		Priority Record */
		/* Allocate Queuing priority record */

		err = allocate_resource(dpdmux->hndl.dprc, /*Resource manager handle */
					"qpr", /* Resource type */
					1, /* Number of resources*/
					1, /* Base align */
					0, /* Options */
					&(dpdmux->replicator.qprid), /* Address */
					"QPR"); /* Error string */
		CHECK_COND_RETVAL(err == 0, err, "allocate_resource (replicator qpri) : %d\n", err);

		/* map QPri->FQID*/
		err = qbman_qpr_configure(
			swp, /* Software portal */
			(uint16_t)(dpdmux->replicator.qprid), /* QPRIID*/
			(uint32_t)(dpdmux->replicator.fqid), /* FQID base */
			1, /* distribution */
			0); /* CGID */
		if (err != 0)
			break;
	}
	err = dpmng_put_swportal(dpdmux->hndl.dpmng, &swp);
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}

static int replicator_init_qdr(struct dpdmux *dpdmux, int max_pri)
{
	int err, i;
	uint16_t qprid[16];
	struct qbman_swp *swp;
	struct dpmng_amq amq;

	dpmng_get_swportal(dpdmux->hndl.dpmng, (void **)&(swp));
	CHECK_COND_RETVAL(swp, -EINVAL);

	/* Allocate QDID */
	err = allocate_resource(dpdmux->hndl.dprc, /*Resource manager handle */
				"qd", /* Resource type */
				1, /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				&(dpdmux->replicator.qdid), /* Address */
				"QDID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err, "allocate_resource (replicator qdid) : %d\n", err);

	/*! Resource authorization */
	/* Obtain AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	for (i = 0; i < 16; i++) {
		qprid[i] = (uint16_t)dpdmux->replicator.qprid;
	}
	/* (QDR) Queuing Destination Record Configure */
	err = qbman_qd_configure(swp, /* Software portal */
					(uint16_t)(dpdmux->replicator.qdid),/* QDID */
					&(qprid[0])); /* Array of QPRID's */
	CHECK_COND_RETVAL(err == 0, err, "qbman_qd_configure : %d\n", err);

	dpdmux->replicator.qprid = qprid[0];

	err = dpmng_put_swportal(dpdmux->hndl.dpmng, &swp);
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}

static int init_ctlu_kg(struct dpdmux *dpdmux)
{
	int err = 0;
	struct dpkg_profile_cfg kg_profile;
	uint16_t pool_attr[RESMAN_MAX_POOL_ATTR_NUM];
	char type[16];

	memset(&kg_profile, 0x0, sizeof(kg_profile));
	memset(pool_attr, 0x0, sizeof(pool_attr));

	snprintf(type, sizeof(type), "kp.wr%d.%s", 0 /*eiop_id*/,
			"ctlui"/* CTLU_EIOP_INGRESS */);
	err = allocate_resource(dpdmux->hndl.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(dpdmux->kg[DPDMUX_KG_DMAT_IDX].id), /* Address */
				"KID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err, "allocate_resource (DMAT kg): %d\n", err);

	switch (dpdmux->method) {
	case (DPDMUX_METHOD_C_VLAN_MAC):
		/* VLAN and MAC Extraction*/
		kg_profile.num_extracts = 2;

		/* MAC Extraction */
		kg_profile.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
		kg_profile.extracts[0].extract.from_hdr.prot = NET_PROT_ETH;
		kg_profile.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_profile.extracts[0].extract.from_hdr.field = NH_FLD_ETH_DA;

		/* VLAN Extraction */
		kg_profile.extracts[1].type = DPKG_EXTRACT_FROM_HDR;
		kg_profile.extracts[1].extract.from_hdr.prot = NET_PROT_VLAN;
		kg_profile.extracts[1].extract.from_hdr.hdr_index = 0;
		kg_profile.extracts[1].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_profile.extracts[1].extract.from_hdr.field = NH_FLD_VLAN_TCI;
		/* Mask VLAN over TCI (its last 12 out of 16 bits) */
		kg_profile.extracts[1].num_of_byte_masks = 2;
		kg_profile.extracts[1].masks[0].mask = 0x0f;
		kg_profile.extracts[1].masks[0].offset = 0;
		kg_profile.extracts[1].masks[1].mask = 0xff;
		kg_profile.extracts[1].masks[1].offset = 1;

		break;

	case (DPDMUX_METHOD_MAC):
		/* MAC Extraction */
		kg_profile.num_extracts = 1;
		kg_profile.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
		kg_profile.extracts[0].extract.from_hdr.hdr_index = 0;
		kg_profile.extracts[0].extract.from_hdr.prot = NET_PROT_ETH;
		kg_profile.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_profile.extracts[0].extract.from_hdr.field = NH_FLD_ETH_DA;
		kg_profile.extracts[0].extract.from_hdr.size = 6;
		kg_profile.extracts[0].extract.from_hdr.offset = 0;
		break;

	case (DPDMUX_METHOD_C_VLAN):
		/* VLAN Extraction */
		kg_profile.num_extracts = 1;
		kg_profile.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
		kg_profile.extracts[0].extract.from_hdr.hdr_index = 0;
		kg_profile.extracts[0].extract.from_hdr.prot = NET_PROT_VLAN;
		kg_profile.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_profile.extracts[0].extract.from_hdr.field = NH_FLD_VLAN_TCI;
		/* Mask VLAN over TCI (its last 12 out of 16 bits) */
		kg_profile.extracts[0].num_of_byte_masks = 2;
		kg_profile.extracts[0].masks[0].mask = 0x0f;
		kg_profile.extracts[0].masks[0].offset = 0;
		kg_profile.extracts[0].masks[1].mask = 0xff;
		kg_profile.extracts[0].masks[1].offset = 1;

		break;

#if 0
		case (DPDMUX_METHOD_S_VLAN):
		break;
#endif 

	case (DPDMUX_METHOD_CUSTOM):
		/* use a dummy key composition rule, will change at run-time */
		kg_profile.num_extracts = 1;
		kg_profile.extracts[0].type = DPKG_EXTRACT_CONSTANT;
		kg_profile.extracts[0].extract.constant.constant = 0;
		kg_profile.extracts[0].extract.constant.num_of_repeats = 1;

		break;

	default:
		return -EINVAL;
	}

	err = dpkg_profile_create(dpdmux->hndl.dpkg_ing,
					dpdmux->kg[DPDMUX_KG_DMAT_IDX].id,
					&kg_profile);
	CHECK_COND_RETVAL(err == 0, err, "dpkg_profile_create: %d\n", err);

	dpdmux->kg[DPDMUX_KG_DMAT_IDX].inuse = 1;

#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		snprintf(type, sizeof(type), "kp.wr%d.%s", 0, "ctlui");
		err = allocate_resource(dpdmux->hndl.dprc,
					type,
					1,
					1,
					0,
					&(dpdmux->fc_filtering_kid.id),
					"KID"); /* Error string */
		CHECK_COND_RETVAL(err == 0, err, "allocate_resource (fc filtering kg): %d\n", err);

		memset(&kg_profile, 0, sizeof(kg_profile));
		kg_profile.num_extracts = 1;
		kg_profile.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
		kg_profile.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_profile.extracts[0].extract.from_hdr.prot = NET_PROT_ETH;
		kg_profile.extracts[0].extract.from_hdr.field = NH_FLD_ETH_DA;

		err = dpkg_profile_create(dpdmux->hndl.dpkg_ing,
				dpdmux->fc_filtering_kid.id,
				&kg_profile);
		CHECK_COND_RETVAL(err == 0, err, "dpkg_profile_create: %d\n", err);

		dpdmux->fc_filtering_kid.inuse = 1;
	}
#endif

	return err;
}

static int init_ctlu_prune_kg(struct dpdmux *dpdmux)
{
	/**
	 -# KG format
	 00-15	IFP
	 */
	int err = 0;
	struct dpkg_profile_cfg kg_cfg; /* KID conf */
	char type[16];

	snprintf(type, sizeof(type), "kp.wr%d.%s", 0 /*eiop_id*/,
			"ctlui"/* CTLU_EIOP_INGRESS */);
	err = allocate_resource(dpdmux->hndl.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(dpdmux->kg[DPDMUX_KG_PRUNE_IDX].id), /* Address */
				"KID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err, "allocate_resource (prune kg): %d\n", err);

	/* Clear Configuration Parameters */
	memset(&kg_cfg, 0x0, sizeof(struct dpkg_profile_cfg));

	kg_cfg.num_extracts = 1; /* IFP or source MAC */
	if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN) { /* IFP */
		kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_CONTEXT;
		kg_cfg.extracts[0].extract.from_context.src = DPKG_FROM_IFP;
		kg_cfg.extracts[0].num_of_byte_masks = 2;
		kg_cfg.extracts[0].masks[0].mask = 0x0F;
		kg_cfg.extracts[0].masks[0].offset = 0;
		kg_cfg.extracts[0].masks[1].mask = 0xFF;
		kg_cfg.extracts[0].masks[1].offset = 1;
	}
	else { /* source MAC address */
		kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[0].extract.from_hdr.prot = NET_PROT_ETH;
		kg_cfg.extracts[0].extract.from_hdr.hdr_index = 0;
		kg_cfg.extracts[0].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[0].extract.from_hdr.field = NH_FLD_ETH_SA;
		kg_cfg.extracts[0].extract.from_hdr.size = 6;
		kg_cfg.extracts[0].extract.from_hdr.offset = 0;

	}
	err = dpkg_profile_create(dpdmux->hndl.dpkg_ing,
	                          dpdmux->kg[DPDMUX_KG_PRUNE_IDX].id, &kg_cfg);
	CHECK_COND_RETVAL(err == 0, err, "dpkg_profile_create: %d\n", err);

	dpdmux->kg[DPDMUX_KG_PRUNE_IDX].inuse = 1;

	return err;
}

static int init_ctlu_miss_kg(struct dpdmux *dpdmux)
{
	/**
	 -# KG format
	 00-15	IFP
	 */
	int err = 0;
	struct dpkg_profile_cfg kg_cfg; /* KID conf */
	char type[16];

	snprintf(type, sizeof(type), "kp.wr%d.%s", 0 /*eiop_id*/,
			"ctlui"/* CTLU_EIOP_INGRESS */);
	err = allocate_resource(dpdmux->hndl.dprc, /*Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(dpdmux->kg[DPDMUX_KG_MISS_IDX].id), /* Address */
				"KID"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err, "allocate_resource (miss kg): %d\n", err);

	/* Clear Configuration Parameters */
	memset(&kg_cfg, 0x0, sizeof(struct dpkg_profile_cfg));

	kg_cfg.num_extracts = 1;

	/* multicast ethernet frame bit extraction */
	kg_cfg.extracts[0].type = DPKG_EXTRACT_FROM_CONTEXT;
	kg_cfg.extracts[0].extract.from_context.src =
		DPKG_FROM_PARSE_RESULT_SPECIFIC_PROTOCOL;
	kg_cfg.extracts[0].extract.from_context.size = 1;
	/* 1 means the second byte in FAF */
	kg_cfg.extracts[0].extract.from_context.offset = 4 + 1;
	kg_cfg.extracts[0].num_of_byte_masks = 1;
	/* 0x08 means the multicast bit in FAF */
	kg_cfg.extracts[0].masks[0].mask = 0x08;

	if (dpdmux->method == DPDMUX_METHOD_C_VLAN_MAC) {
		kg_cfg.num_extracts = 2;
		/* VLAN Extraction */
		kg_cfg.extracts[1].type = DPKG_EXTRACT_FROM_HDR;
		kg_cfg.extracts[1].extract.from_hdr.prot = NET_PROT_VLAN;
		kg_cfg.extracts[1].extract.from_hdr.hdr_index = 0;
		kg_cfg.extracts[1].extract.from_hdr.type = DPKG_FULL_FIELD;
		kg_cfg.extracts[1].extract.from_hdr.field = NH_FLD_VLAN_TCI;
		kg_cfg.extracts[1].num_of_byte_masks = 2;
		kg_cfg.extracts[1].masks[0].mask = 0x0F;
		kg_cfg.extracts[1].masks[0].offset = 0;
		kg_cfg.extracts[1].masks[1].mask = 0xFF;
		kg_cfg.extracts[1].masks[1].offset = 1;
	}
	err = dpkg_profile_create(dpdmux->hndl.dpkg_ing,
					dpdmux->kg[DPDMUX_KG_MISS_IDX].id,
					&kg_cfg);
	CHECK_COND_RETVAL(err == 0, err, "dpkg_profile_create: %d\n", err);

	dpdmux->kg[DPDMUX_KG_MISS_IDX].inuse = 1;

	return err;
}

static int if_eiop_ifp_rx_enable(struct dpdmux *dpdmux, uint16_t id)
{
	int err = 0;
	struct dpdmux_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	/*! Obtain Interface */
	iface = &(dpdmux->iface[id]);

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	/* IFP */
	eiop_ifp_rx_enable(&eiop_ifp_desc);

	return err;
}

static int if_eiop_ifp_tx_enable(struct dpdmux *dpdmux, uint16_t id)
{
	int err = 0;
	struct dpdmux_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	/*! Obtain Interface */
	iface = &(dpdmux->iface[id]);

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	/* IFP */
	eiop_ifp_tx_enable(&eiop_ifp_desc);

	return err;
}

static int if_eiop_ifp_disable(struct dpdmux *dpdmux, uint16_t id)
{
	int err;
	struct dpdmux_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	if (id >= dpdmux->num_ifs)
		return -EINVAL;

	/*! Obtain interface */
	iface = &(dpdmux->iface[id]);

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* WRIOP ID */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	/* TX IFP valid disable */
	err = eiop_ifp_tx_graceful_stop(&eiop_ifp_desc);
	CHECK_COND_RETVAL(err == 0, err, "eiop_ifp_tx_graceful_stop: %d\n", err);

	/* RX IFP valid disable */
	err = eiop_ifp_rx_graceful_stop(&eiop_ifp_desc);

	return err;
}

static int if_eiop_ifp_next(struct dpdmux *dpdmux, uint16_t id, int ifpid)
{
	int err;
	struct dpdmux_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	iface = &(dpdmux->iface[id]);

	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* WRIOP ID */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	/*! Set next IFP */
	err = eiop_ifp_set_enqueue_ifp(&eiop_ifp_desc, ifpid);

	return err;
}

static int dpdmux_get_remote_ppid(struct dpdmux *dpdmux, int if_id, int *ppid)
{
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr link_attr;
	void *object;
	int err;

	*ppid = -1;
	if(if_id == DPDMUX_UL_INDEX)
		return -ENOSYS;

	memset(&endpoint1, 0, sizeof(endpoint1));
	memset(&endpoint2, 0, sizeof(endpoint2));
	memset(&link_attr, 0, sizeof(link_attr));

	endpoint1.type = FSL_MOD_DPDMUX;
	endpoint1.id = (uint16_t)dpdmux->id;
	endpoint1.if_id = (uint16_t)if_id;
	err = linkman_get_connection(dpdmux->hndl.linkman, &endpoint1, &endpoint2, &link_attr);
	CHECK_COND_RETVAL(err==0, err, "Could not get connected object to dpdmux.%d [%d]\n", dpdmux->id, if_id);

	object = sys_get_handle(endpoint2.type, 1, endpoint2.id);
	CHECK_COND_RETVAL(object, -ENODEV, "[ID: %d] Could not get connected object\n", dpdmux->id);
	switch( endpoint2.type ) {
	case FSL_MOD_DPNI:
		err = dpni_get_ap_ppid((struct dpni *)object, ppid);
		CHECK_COND_RETVAL(err==0, err, "dpni_get_ap_ppid() return error\n");
		break;
	default:
		pr_err("Invalid connection peer object\n");
		err = -EINVAL;
		break;
	}

	return err;
}

static int dpdmux_get_ppid(struct dpdmux *dpdmux, int if_id, int *ppid)
{
	struct dpdmux_if *iface;
	int err;

	*ppid = -1;

	iface = &(dpdmux->iface[if_id]);
	if((if_id == DPDMUX_UL_INDEX) && (dpdmux->dpmac != NULL)) {
		/* uplink */
		*ppid = dpmac_get_ppid(dpdmux->dpmac);
		err = 0;
	} else {
		err = dpdmux_get_remote_ppid(dpdmux, if_id, ppid);
	}

	return err;
}

static int dpdmux_config_ppid_priority(struct dpdmux *dpdmux, int if_id,
		uint16_t cgid, char type, uint8_t prio_mask, int cmd)
{
	int ppid = -1;
	struct eiop_cgp cgp = { 0 };
	struct eiop_port_desc eiop_port_desc = {0};
	int err = 0;

	err = !(type==EIOP_CGP_CONGESTION_GROUP || type==EIOP_CGP_BUFFER_DEPLETION);
	CHECK_COND_RETVAL(err==0, -EINVAL, "Invalid congestion group type: %d\n", type);

	err = dpdmux_get_ppid(dpdmux, if_id, &ppid);
	CHECK_COND_RETVAL(err==0, err, "Could not get ppid; flow control feature will not work\n");

	eiop_port_desc.port_id = ppid;
	err = sys_get_desc(SOC_MODULE_EIOP_PORT, SOC_DB_PORT_DESC_ID, &eiop_port_desc, NULL);
	CHECK_COND_RETVAL(err==0, err, "Could not get eiop port descriptor; flow control feature will not work\n");

	cgp.type = type;
	cgp.id   = cgid;
	cgp.bits = prio_mask;
	eiop_port_set_cgp(&eiop_port_desc, &cgp, cmd);

	return 0;
}

static int dpdmux_if_update_bp_config(struct dpdmux *dpdmux, int if_id, uint32_t flags)
{
	struct dpbp_attr dpbp_attr;
	struct dpbp	*dpbp;
	int err = 0;
	struct dpdmux_if  *iface;
	int cmd = 0;
	uint8_t prio_mask = 0;

	/* return if no FC*/
	if( !(flags & DPDMUX_UPDATE_FC) )
		return 0;

	dpbp = dpdmux->dpbp;

	err = dpbp_get_attributes(dpbp, &dpbp_attr);
	CHECK_COND_RETVAL( err==0, err, "DPDMUX.%d[%d]: dpbp_get_attributes() call failed\n", dpdmux->id, if_id);

	/* the BP will be configured only on uplink */
	/* there is only one buffer on DPDMUX */
	iface = &dpdmux->iface[if_id];

	if (if_id == DPDMUX_UL_INDEX) {
		cmd = 2; /* write whole field */
		if( flags & DPDMUX_ENABLE_FC_SENDING )
			prio_mask = 0xff;
		else 
			prio_mask = 0x00;
	}
	else
	{
		if( flags & DPDMUX_ENABLE_FC_SENDING )
			cmd = 1;
		else
			cmd = 0;
		
		prio_mask = 0x01 << iface->fc_idx;
	}
	
	err = dpdmux_config_ppid_priority(dpdmux, if_id,
					dpbp_attr.bpid, EIOP_CGP_BUFFER_DEPLETION,
					prio_mask, cmd);
	CHECK_COND_RETVAL( err==0, err, "DPDMUX.%d[%d]: dpdmux_config_ppid_priority() failed\n", dpdmux->id, if_id);

	return err;
}

static int dpdmux_if_update_channel_fc(struct dpdmux *dpdmux, int if_id, uint32_t flags)
{
/*
 * 	- Go over all accesspoints
 * 	- configure committed and excess rates
 * */
	int err = 0;
	struct dpmng_accesspoint  *ap;
	uint32_t ceetmid;
	struct dpdmux_if  *iface;
	struct qbman_attr tcfc_attr = {0};
	struct qbman_swp *sw_portal;
	int enable;

	if( !(flags & DPDMUX_UPDATE_FC) )
		return 0;

	dpmng_get_swportal(dpdmux->hndl.dpmng, (void **)&(sw_portal));

	iface = &dpdmux->iface[if_id];
	if( iface->fc_idx == FLOW_CONTROL_INVALID_INDEX )
		return 0;

	ap = &iface->ap;

	ceetmid = qbman_ceetmid_compose(
			(uint8_t)ap->dcp_id,
			(uint8_t)ap->ceetm_id);
	qbman_ceetm_tcfc_query(sw_portal, ceetmid, (uint8_t)ap->lniid, &tcfc_attr);

	enable = 0;
	if( flags & DPDMUX_ENABLE_FC_RESPONSE ) {
		enable = 1;
	}

	qbman_ceetm_tcfc_set_lnitcfcc(&tcfc_attr, 1, 0, (uint8_t)ap->cqchid, (uint8_t)iface->fc_idx, enable);

	qbman_ceetm_tcfc_configure(sw_portal, ceetmid, (uint8_t)ap->lniid, &tcfc_attr);

	dpmng_put_swportal(dpdmux->hndl.dpmng, (void*)sw_portal);

	return err;
}

static void save_init_params(struct dpdmux *dpdmux,
	const struct dpdmux_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
	/* Save DMux configuration */
	dpdmux->options = cfg->adv.options;

	dpdmux->num_ifs = cfg->num_ifs;
	/* num_ifs internally - include already the uplink */

	dpdmux->default_create_if = cfg->default_if;
	/* default_create_if internally - it is used at reset */

	dpdmux->default_if = cfg->default_if;
	/* default_if internally - it is used for actual default interface */

	dpdmux->method = cfg->method;
	dpdmux->manip = cfg->manip;
	dpdmux->max_dmat_entries = cfg->adv.max_dmat_entries;
	dpdmux->max_mc_groups = cfg->adv.max_mc_groups;
	dpdmux->max_vlan_ids = cfg->adv.max_vlan_ids;
	dpdmux->mem_size = cfg->adv.mem_size;

	/*! Save MC information */
	dpdmux->hndl.dprc = dev_cfg->device;
	dpdmux->id = dev_cfg->id;

}

static int init_allocate_iface(struct dpdmux *dpdmux,
	const struct dpdmux_cfg *cfg)
{
	/*! Allocate Interface dataBase */
	dpdmux->iface = (struct dpdmux_if *)fsl_malloc(
		sizeof(struct dpdmux_if) * /*!< Interface dateBase size */
		cfg->num_ifs); /*!< Number of Interfaces */
	if (dpdmux->iface == NULL)
		return -ENOMEM; /*!< Out of memory */

	/*! Reset dataBase*/
	memset(dpdmux->iface, 0x0, sizeof(struct dpdmux_if) * cfg->num_ifs);

	return 0;
}

static int init_allocate(struct dpdmux *dpdmux, const struct dpdmux_cfg *cfg)
{
	/**
	 -# Interface
	 -# DMAT
	 -# memset
	 */
	int err;

	/*! Interface dataBase */
	err = init_allocate_iface(dpdmux, cfg);
	CHECK_COND_RETVAL(err == 0, err, "init_allocate_iface: %d\n", err);

	memset(&dpdmux->table, 0x0, sizeof(struct dpdmux_table) * DPDMUX_MAX_TBL);

	return err;
}

static int verify_params_integrity(const struct dpdmux_cfg *src_cfg,
	struct dpdmux_cfg *dst_cfg)
{
	memcpy(dst_cfg, src_cfg, sizeof(struct dpdmux_cfg));

	/* verify classification method is valid */
	switch (dst_cfg->method) {
		case DPDMUX_METHOD_NONE:
		case DPDMUX_METHOD_C_VLAN_MAC:
		case DPDMUX_METHOD_MAC:
		case DPDMUX_METHOD_C_VLAN:
		case DPDMUX_METHOD_S_VLAN:
		case DPDMUX_METHOD_CUSTOM:
			break;
		default:
			pr_err("dmux method %d\n", dst_cfg->method);
			return -EINVAL;
	}

	switch (dst_cfg->manip) {
		case DPDMUX_MANIP_NONE:
		case DPDMUX_MANIP_ADD_REMOVE_S_VLAN:
			break;
		default:
			pr_err("dmux manip %d\n", dst_cfg->manip);
			return -EINVAL;

	}
	
	if (dst_cfg->method == DPDMUX_METHOD_NONE) {
		pr_err("dmux method was not configured\n");
		return -EINVAL;
	}

	/* Range */
	if ((dst_cfg->num_ifs < 1) || (dst_cfg->num_ifs > DPDMUX_MAX_IF)) {
		pr_err("num_ifs (%d, valid range: (1-%d\n", dst_cfg->num_ifs, DPDMUX_MAX_IF);
		return -EINVAL; /* Invalid argument */
	}

	/* Default interface */
	if (dst_cfg->default_if)
		if (dst_cfg->default_if > dst_cfg->num_ifs) {
			pr_err("default_if = %d, bigger than num_ifs = %d\n", dst_cfg->default_if, dst_cfg->num_ifs);
			return -EINVAL;
		}else if (dst_cfg->method != DPDMUX_METHOD_CUSTOM) {
			pr_err("default_if is available only for DPDMUX_METHOD_CUSTOM, "
					"not available for method = %d\n", dst_cfg->method );
			return -EINVAL;
		}

	if (dst_cfg->method == DPDMUX_METHOD_S_VLAN) {
		pr_err("currently there is no support of S-Vlan\n");
		return -ENOTSUP;
	}

	if ((dst_cfg->method != DPDMUX_METHOD_S_VLAN)
		&& (dst_cfg->manip == DPDMUX_MANIP_ADD_REMOVE_S_VLAN)) {
		pr_err("ID[%d]: currently there is no support of Add/Remove Vlan without method of S-Vlan\n");
		return -EINVAL;
	}
	
	if (dst_cfg->adv.max_dmat_entries > DPDMUX_MAX_NUM_DMAT_ENTRIES) {
			pr_err("Max number of DMAT entries must be smaller or equal to: %d\n", DPDMUX_MAX_NUM_DMAT_ENTRIES);
			return -EINVAL;
	}
	
	/* Integrity */
	dst_cfg->adv.max_dmat_entries =
		(dst_cfg->adv.max_dmat_entries == 0) ?
			DPDMUX_MAX_NUM_DMAT_ENTRIES :
			dst_cfg->adv.max_dmat_entries;

	if (!(dst_cfg->adv.options & DPDMUX_OPT_REPLICATION_DIS)) {
		if (dst_cfg->adv.max_mc_groups > DPDMUX_MAX_DMAT_MC_GROUPS) {
			pr_err("Max number of MC groups must be smaller or equal to: %d\n", DPDMUX_MAX_DMAT_MC_GROUPS);
			return -EINVAL;
		}
		
		dst_cfg->adv.max_mc_groups =
			(dst_cfg->adv.max_mc_groups == 0) ?
				DPDMUX_MAX_DMAT_MC_GROUPS :
				dst_cfg->adv.max_mc_groups;

#if 0
		if (dst_cfg->adv.max_dmat_entries < dst_cfg->adv.max_mc_groups)
		pr_err("ID[%d]: multicast groups number(%d) is bigger than the DMAT entries(%d)\n", dst_cfg->adv.max_mc_groups, dst_cfg->adv.max_dmat_entries);
		return -EINVAL;
#endif
	}

	/* number of vlan ids is relevant in case of mac+vlan in the miss table
	 * allocation */
	if (dst_cfg->method == DPDMUX_METHOD_C_VLAN_MAC) {
		if (dst_cfg->adv.max_vlan_ids > DPDMUX_MAX_VLAN_IDS) {
			pr_err("Max number of VLAN ids must be smaller or equal to: %d\n", DPDMUX_MAX_VLAN_IDS);
			return -EINVAL;
		}
		
		dst_cfg->adv.max_vlan_ids =
			(dst_cfg->adv.max_vlan_ids == 0) ?
				DPDMUX_MAX_VLAN_IDS :
				dst_cfg->adv.max_vlan_ids;
	}
	/*
	 * when METHOD_C_VLAN or METHOD_S_VLAN configured in
	 * OPT_BRIDGE_EN (VEB)
	 * return -ENOTSUP (ENGR00362551)
	 * */
	if (dst_cfg->adv.options & DPDMUX_OPT_BRIDGE_EN) {
		if ((dst_cfg->method == DPDMUX_METHOD_C_VLAN) ||
			(dst_cfg->method == DPDMUX_METHOD_S_VLAN) ||
			(dst_cfg->method == DPDMUX_METHOD_CUSTOM)) {
				pr_err("Method %d is not supported in VEB mode: %d\n",
						dst_cfg->method);
				return -ENOTSUP;
		}
	}

	/*
	 * Check classification mask support option
	 */
	if (dst_cfg->adv.options & DPDMUX_OPT_CLS_MASK_SUPPORT) {
		/* Hardcoded EIOP_ID to 0, it is safe for now as there is only one WRIOP
		 * instance but this should come from SocDB
		 */
		if (!dpmng_soc_has_tcam(0)) {
			pr_err("Option %d not supported as there is no TCAM in this chip\n",
					DPDMUX_OPT_CLS_MASK_SUPPORT);
			return -EINVAL;
		}

		if( dst_cfg->method != DPDMUX_METHOD_CUSTOM ) {
			pr_err("Option DPDMUX_OPT_CLS_MASK_SUPPORT set using other method than DPDMUX_METHOD_CUSTOM. "
					"This configuration will consume lot of resources without using them properly. "
					"Continue anyway\n");
		}
	}

	/* add 1 to include the uplink port */
	dst_cfg->num_ifs++;

	return 0;
}

static void init_internal_database(struct dpdmux *dpdmux, int init_phase)
{
	int i = 0;
	struct dpdmux_if *iface;

	/*! L2 switch dataBase */
	if (!(dpdmux->skip_reset_flags & DPDMUX_SKIP_DEFAULT_INTERFACE))
		dpdmux->default_if = dpdmux->default_create_if; /*! default mirroring interface */

	dpdmux->ceetm_id = 0;

	if (!(dpdmux->skip_reset_flags & DPDMUX_SKIP_UNICAST_RULES))
		dpdmux->custom_cls_rule_size = DPDMUX_CUSTOM_KEY_SIZE;

	/* Save interfaces cfg */
	for (i = 0; i < dpdmux->num_ifs; i++) {
		iface = &(dpdmux->iface[i]); /*! Get interface */
		if (init_phase) {
			memset(iface, 0, sizeof(struct dpdmux_if));

			iface->ap.dcp_id = 0;
			iface->ap.ceetm_id = 0;
		}

		iface->policy_id = DPDMUX_POLICY_ALL; /*! admit all policy */

		iface->link_cfg.options = 0;
		iface->link_cfg.options |= DPDMUX_LINK_OPT_AUTONEG;

		iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;

		iface->mfl = DPDMUX_MAX_FRAME_LENGTH;
	}

	/*! Handles */
	init_handles(dpdmux);
}


static int if_set_counter(struct dpdmux *dpdmux,
	uint16_t if_id,
	enum dpdmux_counter_type type,
	uint64_t counter)
{
	struct dpdmux_if *iface;
	int err = 0;
	struct eiop_ifp_desc eiop_ifp_desc;

	iface = &(dpdmux->iface[if_id]);

	/* Obtain IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	switch (type) {
	case DPDMUX_CNT_ING_FRAME:
		eiop_ifp_set_counter(&eiop_ifp_desc, /*! IFP descriptor */
					E_INGRESS_FC, /*! Counter Type */
					counter); /*! Value */
		break;
	case DPDMUX_CNT_ING_BYTE:
		eiop_ifp_set_counter(&eiop_ifp_desc, /*! IFP descriptor */
					E_INGRESS_BC, /*! Counter Type */
					counter); /*! Value */
		break;
	case DPDMUX_CNT_ING_FLTR_FRAME: /*! Ingress filtered frame */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_FFC, counter);
		break;
	case DPDMUX_CNT_ING_FRAME_DISCARD: /*! Ingress frame discard */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_FDC, counter);
		break;
	case DPDMUX_CNT_ING_MCAST_FRAME: /*! Ingress multicast frame */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_MFC, counter);
		break;
	case DPDMUX_CNT_ING_MCAST_BYTE: /*! Ingress multicast byte */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_MBC, counter);
		break;
	case DPDMUX_CNT_ING_BCAST_FRAME: /*! Ingress broadcast frame */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_BFC, counter);
		break;
	case DPDMUX_CNT_ING_BCAST_BYTES: /*! Ingress broadcast byte */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_BBC, counter);
		break;
	case DPDMUX_CNT_EGR_FRAME: /*! Egress frame count */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_EGRESS_FC, counter);
		break;
	case DPDMUX_CNT_EGR_BYTE: /*! Egress byte count */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_EGRESS_BC, counter);
		break;
	case DPDMUX_CNT_EGR_FRAME_DISCARD: /**< Egress frame drop count */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_EGRESS_FDC, counter);
		break;
	case DPDMUX_CNT_ING_NO_BUFFER_DISCARD: /**< Ingress frame no buffer drop count */
		eiop_ifp_set_counter(&eiop_ifp_desc, E_INGRESS_OODC, counter);
		break;
	default:
		err = -ENOTSUP; /*!< Operation not supported */
		break;
	}

	return err;
}

static int if_get_counter_vepa(struct dpdmux *dpdmux,
	uint16_t if_id,
	enum dpdmux_counter_type type,
	uint64_t *counter)
{
	int err = 0;
	struct eiop_ifp_desc 	ifp_desc, next_ifp_desc;
	struct dpdmux_if	*iface;

	/* Obtain DMux interface */
	iface = &(dpdmux->iface[if_id]);

	/* Obtain IFP descriptor */
	ifp_desc.ifp_id = iface->ap.ifpid;		/* ifp */
	ifp_desc.eiop_id = iface->ap.iop_id;		/* wriop id */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, 	/* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID,
				&ifp_desc, 		/* descriptor */
				NULL); 			/* iterator */
	CHECK_COND_RETVAL(err == 0, err);

	/* Obtain next IFP descriptor */
	next_ifp_desc.ifp_id = iface->next_ifpid;		/* next ifp */
	next_ifp_desc.eiop_id = iface->ap.iop_id;		/* wriop id */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, 	/* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID,
				&next_ifp_desc, 	/* descriptor */
				NULL); 			/* iterator */
	CHECK_COND_RETVAL(err == 0, err);

	switch (type) {
		case DPDMUX_CNT_ING_FRAME:
			*counter = eiop_ifp_get_counter(
				&next_ifp_desc,
				E_EGRESS_FC ); /* Egress Frame Counter */
			break;
		case DPDMUX_CNT_ING_BYTE:
			*counter = eiop_ifp_get_counter(
				&next_ifp_desc,
				E_EGRESS_BC); /* Egress byte counter */
			break;
		case DPDMUX_CNT_ING_FLTR_FRAME:
			/*
			 * there is no meaning in case of VEPA
			 * to filter frames then return 0
			 */
			*counter = 0;
			break;
		case DPDMUX_CNT_ING_FRAME_DISCARD:
			*counter = eiop_ifp_get_counter(
				&next_ifp_desc,
				E_EGRESS_FDC); /* Egress Frame Discard */
			break;
		case DPDMUX_CNT_ING_MCAST_FRAME:
			*counter = eiop_ifp_get_counter(
				&next_ifp_desc,
				E_EGRESS_MFC); /* Egress multicast frame */
			break;
		case DPDMUX_CNT_ING_MCAST_BYTE:
			*counter = eiop_ifp_get_counter(
				&next_ifp_desc,
				E_EGRESS_MBC); /* egress multicast byte */
			break;
		case DPDMUX_CNT_ING_BCAST_FRAME:
			*counter = eiop_ifp_get_counter(
				&next_ifp_desc,
				E_EGRESS_BFC); /* Egress broadcast frame */
			break;
		case DPDMUX_CNT_ING_BCAST_BYTES:
			*counter = eiop_ifp_get_counter(
				&next_ifp_desc,
				E_EGRESS_BBC); /* Egress broadcast byte */
			break;
		case DPDMUX_CNT_EGR_FRAME:
			*counter = eiop_ifp_get_counter(
				&ifp_desc,
				E_EGRESS_FC); /* Egress frame count */
			break;
		case DPDMUX_CNT_EGR_BYTE:
			*counter = eiop_ifp_get_counter(
				&ifp_desc,
				E_EGRESS_BC); /* Egress byte count */
			break;
		case DPDMUX_CNT_EGR_FRAME_DISCARD:
			*counter = eiop_ifp_get_counter(
				&ifp_desc,
				E_EGRESS_FDC); /* Egress frame drop count */
			break;
		case DPDMUX_CNT_ING_NO_BUFFER_DISCARD:
			*counter = eiop_ifp_get_counter(
				&ifp_desc, E_INGRESS_OODC); /**< Ingress frame no buffer drop count */
			break;
		default:
			err = -ENOTSUP; /* Operation not supported */
			break;
	}
	return err;
}

static int if_get_counter(struct dpdmux *dpdmux,
	int ifpid,
	int iop_id,
	enum dpdmux_counter_type type,
	uint64_t *counter)
{
	int err = 0;
	struct eiop_ifp_desc eiop_ifp_desc;

	/* Obtain IFP descriptor */
	eiop_ifp_desc.ifp_id = ifpid;
	eiop_ifp_desc.eiop_id = iop_id; /* TBD */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	switch (type) {
	case DPDMUX_CNT_ING_FRAME:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc,E_INGRESS_FC); /**< Ingress frame */
		break;
	case DPDMUX_CNT_ING_BYTE:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc, E_INGRESS_BC); /**< Ingress byte count */
		break;
	case DPDMUX_CNT_ING_FLTR_FRAME:
		/* there is no meaning in case of VEPA to filter frames then I
		 * return 0 */
		*counter = eiop_ifp_get_counter(&eiop_ifp_desc,	E_INGRESS_FFC); /**< Ingress filtered frame */
		break;
	case DPDMUX_CNT_ING_FRAME_DISCARD:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc, E_INGRESS_FDC); /**< Ingress frame discard */
		break;
	case DPDMUX_CNT_ING_MCAST_FRAME:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc, E_INGRESS_MFC); /**< Ingress multicast frame */
		break;
	case DPDMUX_CNT_ING_MCAST_BYTE:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc, E_INGRESS_MBC); /**< Ingress multicast byte */
		break;
	case DPDMUX_CNT_ING_BCAST_FRAME:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc, E_INGRESS_BFC); /**< Ingress broadcast frame */
		break;
	case DPDMUX_CNT_ING_BCAST_BYTES:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc, E_INGRESS_BBC); /**< Ingress broadcast byte */
		break;
	case DPDMUX_CNT_EGR_FRAME:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc, E_EGRESS_FC); /**< Egress frame count */
		break;
	case DPDMUX_CNT_EGR_BYTE:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc, E_EGRESS_BC); /**< Egress byte count */
		break;
	case DPDMUX_CNT_EGR_FRAME_DISCARD:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc, E_EGRESS_FDC); /**< Egress frame drop count */
		break;
	case DPDMUX_CNT_ING_NO_BUFFER_DISCARD:
		*counter = eiop_ifp_get_counter(
			&eiop_ifp_desc, E_INGRESS_OODC); /**< Ingress frame no buffer drop count */
		break;
	default:
		err = -ENOTSUP; /*!< Operation not supported */
		break;
	}

	return err;
}

static int get_appropriate_counter(struct dpdmux *dpdmux,
                           	uint16_t if_id,
                           	enum dpdmux_counter_type counter_type,
                           	uint64_t *counter)
{
	struct dpdmux_if *iface;
	struct dpmac_counters dpmac_stats;
	int tmp_ifp;
	int opposite = 0;
	int err = 0;

	/*! Obtain interface */
	iface = &(dpdmux->iface[if_id]); /* Get interface */
	tmp_ifp = iface->ap.ifpid;

	/* handle uplink case:
	 * if uplink is physical call to the mac get counter routine to get the
	 * egress counters
	 * if uplink is virtual(cascading) call to the ifp get counter routine
	 */
	if (if_id == DPDMUX_UL_INDEX) {
		if (dpdmux->method != DPDMUX_METHOD_S_VLAN) {
			if (dpdmux->dpmac == NULL) {
				pr_warn(
					"dpmac is not connected to the dpdmux\n");
				*counter = 0;
				return 0;
			}

			/* get DPMAC counters */
			err = dpmac_get_statistics(dpdmux->dpmac,
							&dpmac_stats);
			CHECK_COND_RETVAL(err == 0, err);
			switch (counter_type) {
			case (DPDMUX_CNT_EGR_FRAME):
				*counter = dpmac_stats.if_out_pkts;
				return err;
			case (DPDMUX_CNT_EGR_BYTE):
				*counter = dpmac_stats.if_out_octets;
				return err;
			case (DPDMUX_CNT_EGR_FRAME_DISCARD):
				*counter = dpmac_stats.if_out_discards;
				return err;
			}
		}
	} else {
		/* handle virtual interfaces case:
		 * if VEPA -
		 * use the dpni ifp when calling the ifp get counter routine
		 * if VEB -
		 * use the dpdmux ifp when calling the ifp get counter routine
		 */
		if (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN)) {
			tmp_ifp = iface->next_ifpid;
			/* in case of VEPA,there is a need to
			 read the opposite counters because they are read from NIC */
			opposite = 1;
		}
	}
	if (opposite)
		err = if_get_counter_vepa(
			dpdmux,			/* context */
			if_id,			/* interface id */
			counter_type,		/* counter type */
			counter);		/* counter */
	else
		err = if_get_counter(dpdmux, tmp_ifp, iface->ap.iop_id,
					counter_type, counter);

	return err;
}

static void if_handle_internal_counter(struct dpdmux *dpdmux,
	uint16_t if_id,
	enum dpdmux_counter_type counter_type,
	uint64_t counter,
	enum dpdmux_counter_operation operation)
{
	struct dpdmux_if *iface;

	/*! Obtain interface */
	iface = &(dpdmux->iface[if_id]); /* Get interface */

	switch (operation) {
	case (DPDMUX_CNT_OPERATION_SET):
		iface->counters[counter_type] = counter;
		break;
#if 0 /* for code coverage */
	case (DPDMUX_CNT_OPERATION_ADD):
			iface->counters[counter_type] += counter;
			break;


		case (DPDMUX_CNT_OPERATION_SUB):
			iface->counters[counter_type] =
				(counter - iface->counters[counter_type]);
			break;
#endif /* for code coverage */
	}
}



static int clear_ifp_counters(struct dpdmux *dpdmux, uint16_t if_id, int reset)
{
	int err = 0;
	enum dpdmux_counter_type counter_type;
	uint64_t counter;

	for (counter_type = DPDMUX_CNT_ING_FRAME;
		counter_type <= DPDMUX_CNT_EGR_FRAME_DISCARD; counter_type++) {
		/* zero the counters */
		err = if_set_counter(dpdmux, /*! Context */
					if_id, /*! Interface id */
					counter_type, /*! Counter type */
					0); /*! Counter value */
		CHECK_COND_RETVAL(err == 0, err);

		if (reset) {
			/* in case of reset operation - save the current
			 * counters
			 */
			err = get_appropriate_counter(dpdmux,
							if_id,
							counter_type,
							&counter);
			if (err)
				return err;

			/* update the internal counter to reflect the current situation */
			if_handle_internal_counter(dpdmux, if_id, counter_type, counter,
					  DPDMUX_CNT_OPERATION_SET/* operation */);
		}
	}
	return err;
}

static int init_if_eiop_qos(struct dpdmux *dpdmux, uint16_t if_id)
{
	int err = 0;
	struct dpdmux_if *iface;

	/*! Obtain interface */
	iface = &(dpdmux->iface[if_id]);

	/*! Allocate dpqos object */
	iface->dpqos = dpqos_init(dpdmux->hndl.dpqos_ing, iface->ap.ifpid);
	if (iface->dpqos == NULL)
		return -EFAULT;

	return err;
}

static int init_if_eiop_ifp(struct dpdmux *dpdmux, uint16_t id)
{
	/**
	 -# Conventional IFP
	 -# Extension ingress IFP
	 -# Extension egress IFP
	 */
	int err = 0;
	struct eiop_ifp_cfg ifp_params; /**< IFP */
	struct eiop_ifp_tx_pcd_cfg ifpext_egr_params; /**< Ext IFP */
	struct eiop_ifp_rx_pcd_cfg ifpext_ing_params; /**< Ext IFP */
	struct dpdmux_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct dpmng_amq amq;
	struct dpbp_attr 	dpbp_attr;
	struct ceetm_if_attr  	ceetm_if_attr;

	/* Interface context */
	iface = &(dpdmux->iface[id]); /* Get interface */

	/* Obtain buffer pool attributes */
	err = dpbp_get_attributes(dpdmux->dpbp, &dpbp_attr);
	CHECK_COND_RETVAL(err == 0, err);

	/* obtain ceetm interface attributes */
        ceetm_if_get_attributes(iface->ceetm_if, &ceetm_if_attr);

	/*! Obtain AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	memset(&ifp_params, 0x00, sizeof(struct eiop_ifp_cfg));
	ifp_params.default_cfg.qd_id = ceetm_if_attr.qdid;
#if 0
	ifp_params.default_cfg.replic_list_id =
	dpdmux->iface[id].rpl_pool.rpl_head.id0;
#endif

	ifp_params.num_of_pools_used = 1;
	ifp_params.pools_cfg[0].id = dpbp_attr.bpid;
	ifp_params.pools_cfg[0].size = DPDMUX_BP_BUFFER_SIZE;

	ifp_params.pools_cfg[0].options =
		(amq.bmt == 1) ? EIOP_IFP_BUF_POOL_OPT_BMT | EIOP_IFP_BUF_POOL_OPT_SCARCE_RESOURCE 
				: EIOP_IFP_BUF_POOL_OPT_SCARCE_RESOURCE;
	ifp_params.max_frame_length =
		dpdmux->max_frame_length = DPDMUX_MAX_FRAME_LENGTH;
	ifp_params.mng_cmd_ring_paddr = 0x0;
	ifp_params.mng_cmd_icid = amq.icid;
#if 0
	ifp_params.default_cfg.options =
	EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_REPLIC_ID;
	| /* FLCTYPE=0*/
	EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_OPAQUE; /* ACL */

	ifp_params.default_cfg.opaque = ((uint64_t)acl_tid << 48) |
	((uint64_t)dpdmux->acl_kg.id << 40);
#endif
	ifp_params.default_cfg.opaque = (uint64_t)ceetm_if_attr.qdid;
	ifp_params.rx_err_fqid = dpdmux->err_fqid; /**< err FQID */
	ifp_params.tx_err_fqid = dpdmux->err_fqid; /**< err FQID */
	/*! AMQ configuration */
	ifp_params.defcfg.options |=
		(amq.bdi == 1) ?
			EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION : 0;
	ifp_params.defcfg.options |=
		(amq.pl == 1) ? EIOP_IFP_DEFCFG_OPT_SET_PRIVIL_LEVEL : 0;
	ifp_params.defcfg.options |=
		(amq.va == 1) ? EIOP_IFP_DEFCFG_OPT_SET_VIRT_ADDR : 0;
	ifp_params.defcfg.icid = amq.icid;

	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	/* Enable annotations and timestamp on ingress and egress
	 * This is needed to pass MAC timestamp over recycle port for 1588 frames
	 * If not enabled the frame will receive the timestamp when transmitted over
	 * recycle port with a new time read from rtc. The MAC timestamp will be lost.
	 * Not supported on LS2080/2085 SoC
	 */
	if (!soc_db_use_recycle_port_timestamp()) {
		ifp_params.defcfg.rx_buf_layout.pass_ts		= 1;
		ifp_params.defcfg.rx_buf_layout.pass_fas	= 1;
		ifp_params.defcfg.rx_buf_layout.pass_ing_ad = 1;

		ifp_params.defcfg.tx_buf_layout.pass_ts		= 1;
		ifp_params.defcfg.tx_buf_layout.pass_fas	= 1;
	}
	ifp_params.defcfg.tx_buf_layout.pass_egr_ad = 1;	// IFERA_FAEADV = 1

	ifp_params.errors_settings = EIOP_IFP_CFG_OPT_ERROR_LIMIT_DROP;

	/*! Init IFP */
	err = eiop_ifp_init(&eiop_ifp_desc, /*reg base */
				&ifp_params); /* params */
	CHECK_COND_RETVAL(err == 0, err, "eiop_ifp_init: %d\n", err);

	/* Extension ingress IFP */
	/* Clear Configuration Parameters */
	memset(&ifpext_ing_params, 0x00, sizeof(struct eiop_ifp_rx_pcd_cfg));
	/* Turn ON CTLU modules */
	ifpext_ing_params.activate_modules =
		EIOP_IFP_ACTIVATE_MODULE_PARSER
		| EIOP_IFP_ACTIVATE_MODULE_POLICY
		| EIOP_IFP_ACTIVATE_MODULE_QoS_MAPPING
		| EIOP_IFP_ACTIVATE_MODULE_LOOKUP;

	ifpext_ing_params.parser.profile_id = dpdmux->prp_ing.id;
	err = dpparser_get_hdr_code(NET_PROT_ETH, &ifpext_ing_params.parser.start_hxs);
	CHECK_COND_RETVAL(err == 0, err);
	ifpext_ing_params.policy.profile_id =
		dpdmux->policy[iface->policy_id].id;
#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		ifpext_ing_params.default_lookup.dptbl_id = (uint16_t)(dpdmux->fc_filtering_tbl.id);
		ifpext_ing_params.default_lookup.dpkg_profile_id = (uint8_t)(dpdmux->fc_filtering_kid.id);
	}
	else {
		ifpext_ing_params.default_lookup.dptbl_id = (uint16_t)(dpdmux->table[DPDMUX_DMAT_IDX].id);
		ifpext_ing_params.default_lookup.dpkg_profile_id = (uint8_t)(dpdmux->kg[DPDMUX_KG_DMAT_IDX].id);
	}
#else
	ifpext_ing_params.default_lookup.dptbl_id =
		(uint16_t)(dpdmux->table[DPDMUX_DMAT_IDX].id);
	ifpext_ing_params.default_lookup.dpkg_profile_id =
		(uint8_t)(dpdmux->kg[DPDMUX_KG_DMAT_IDX].id);
#endif

	err = eiop_ifp_rx_pcd_set(&eiop_ifp_desc, /* registers base */
					&ifpext_ing_params); /* ingress parameters */
	CHECK_COND_RETVAL(err == 0, err, "eiop_ifp_rx_pcd_set: %d\n", err);

	/* Extension IFP egress */
	/* Clear Configuration Parameters */
	memset(&ifpext_egr_params, 0x00, sizeof(struct eiop_ifp_tx_pcd_cfg));
	/* Turn OFF CTLU modules */
	ifpext_egr_params.activate_modules = EIOP_IFP_ACTIVATE_MODULE_PARSER /*|
	 EIOP_IFP_ACTIVATE_MODULE_LOOKUP*/;

	ifpext_egr_params.parser.profile_id = dpdmux->prp_egr.id;
	err = dpparser_get_hdr_code(NET_PROT_ETH, &ifpext_egr_params.parser.start_hxs);
	CHECK_COND_RETVAL(err == 0, err);
#if 0
	ifpext_egr_params.default_lookup.dptbl_id = (uint16_t)(vlan_tid);
	ifpext_egr_params.default_lookup.dpkg_profile_id =
	(uint8_t)(dpdmux->vlan_kg.id);
#endif
	err = eiop_ifp_tx_pcd_set(&eiop_ifp_desc, /* registers base */
					&ifpext_egr_params); /* egress parameters */
	CHECK_COND_RETVAL(err == 0, err, "eiop_ifp_tx_pcd_set: %d\n", err);

	/*! Clear all IFP counters */
	err = clear_ifp_counters(dpdmux, id, 0/* no reset */);
	if (err != 0) {
		pr_err("clear_ifp_counters: %d\n", err);
		return err;
	}
	return err;
}

static int replic_get_ifs(struct dpdmux *dpdmux, hmap_data replic)
{
       int err = 0, id, rrid;
       uint16_t cnt = 0;
       struct replic_element_info rr;

       /*! Get replic head rrid */
       err = replic_get_element_head(replic, &id);
       if (err == 0)
             replic_get_element_rrid(replic, id, &rrid);
       else
             rrid = 0;

       pr_info("replic_get_ifs\n");
      /*! go over link list to obtain interfaces */
       while (rrid != 0) {
             /*! Get Replication record */
             err = replic_query_element_rrid(rrid, &rr);
             if (err != 0)
                    return err;

             pr_info("QDID:%d\n", rr.qdid);

             /*! go to the next element */
             rrid = rr.next_rrid;

             /*! Update counter */
             cnt++;
       }

       return 0;
}


static int add_if_to_replication_list(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint8_t *addr,
	struct hmap *hmap,
	enum dpdmux_owner owner,
	int *head_rrid,
	int *new_group)
{
	int err;
	struct dpmng_amq amq;
	hmap_data replic;
	struct replic_element_info element_info;
	int element_head_id;
        struct ceetm_if_attr    ceetm_if_attr;
        struct ceetm_if		*ceetm_if;

	/* obtain ceetm interface */
	ceetm_if = dpdmux->iface[if_id].ceetm_if;

        /* obtain ceetm interface attributes */
        ceetm_if_get_attributes(ceetm_if, &ceetm_if_attr);

	err = hmap_lookup(hmap, addr, &replic);
	if (err == -ENAVAIL)/* no entry*/
	{
		err = hmap_add_key(hmap, addr);
		CHECK_COND_RETVAL(err == 0, err, "hmap_add_key failed\n");
		*new_group = 1;

		err = hmap_lookup(hmap, addr, &replic);
		CHECK_COND_RETVAL(err == 0, err, "hmap_lookup failed\n");
	}

	/* Add new element to the group */
	memset(&element_info, 0x0, sizeof(struct replic_element_info));

	/* prepare element */
	element_info.qdid = ceetm_if_attr.qdid;
//	element_info.fqid = dpdmux->replicator.fqid;
	element_info.fqid = dpmng_get_rtn_fqid(dpdmux->hndl.dpmng);
	/* Get ICID */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	element_info.icid = amq.icid;

	err = replic_add_element(replic, (int)if_id, &element_info);

	if (err) {
		/* check if the entry already exists */
		if (err != -EEXIST) {
			pr_err("replic_add_element failed\n");
		}
		return err;
	}

	err = replic_get_element_head(replic, &element_head_id);
	CHECK_COND_RETVAL(err == 0, err, "replic_get_element_head failed\n");

	err = replic_get_element_rrid(replic, element_head_id, head_rrid);
	CHECK_COND_RETVAL(err == 0, err, "replic_get_element_rrid failed\n");

	err = replic_set_element_opaque(replic, if_id, (int)owner/* opaque */);
	CHECK_COND_RETVAL(err == 0, err, "replic_set_element_opaque failed\n");

	err = replic_get_ifs(dpdmux, replic);
	CHECK_COND_RETVAL(err == 0, err, "replic_get_ifs failed\n");

	return 0;

}

static int add_rule_with_replication_to_table(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint8_t *addr,
	struct hmap *hmap,
	enum dpdmux_owner owner,
	uint32_t key_size,
	int table_index,
	int miss_entry)
{
	int err;
	struct dptbl_rule rule;
	struct dptbl_action action;
	int head_rrid;
	int new_group = 0;

	err = add_if_to_replication_list(dpdmux, if_id, addr, hmap, owner,
						&head_rrid, &new_group);
	CHECK_COND_RETVAL(err == 0, err, "add_if_to_replication_list failed\n");

	memset(&rule, 0, sizeof(struct dptbl_rule));
	memset(&action, 0, sizeof(struct dptbl_action));

	rule.rule_cfg.exact.key = (uint8_t*)addr;
	rule.rule_cfg.exact.size = key_size;

	action.next_action = DPTBL_ACTION_LOOKUP;
	action.options = DPTBL_ACTION_SET_QDID | DPTBL_ACTION_SET_REPLIC_ID;
	action.qd_id = dpdmux->replicator.qdid;
	action.replic_id = head_rrid;
	action.dppolicer_profile_id = owner;

	/* set tid and kid for pruning table */
	action.lookup_params.dptbl_id = dpdmux->table[DPDMUX_PRUNE_TBL_IDX].id;
	action.lookup_params.dpkg_profile_id = dpdmux->kg[DPDMUX_KG_PRUNE_IDX].id;

	err =
		(miss_entry == 1) ? /* check if handle the miss entry */
		dptbl_modify_miss_action(dpdmux->table[table_index].handle,
						&action) :
		((new_group == 1) ? /* check if it's a new group or one that already exists */
		dptbl_add_rule(dpdmux->table[table_index].handle, &rule,
				&action, 0) :
		dptbl_modify_rule(dpdmux->table[table_index].handle, &rule,
					&action));
	CHECK_COND_RETVAL(err == 0, err, "dptbl_add/modify_rule failed\n");

	return 0;

}

static int add_rule_to_table(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint8_t *addr,
	uint8_t *mask_ptr,
	uint32_t key_size,
	uint16_t priority, // used for TCAM tables
	int hmap_index,//struct hmap *hmap,
	int table_id,
	enum dpdmux_owner owner,
	int allow_modify)
{
	int err, err1;
	struct dptbl_rule rule;
	struct dptbl_action action;
	hmap_data data;
	struct ceetm_if *ceetm_if;
	struct ceetm_if_attr ceetm_if_attr;
	int count = 0, i;
	char buf[1024];
	uint8_t mask[DPDMUX_CUSTOM_KEY_SIZE];
	uint8_t map_key[2*DPDMUX_CUSTOM_KEY_SIZE];

	memset(&rule, 0, sizeof(struct dptbl_rule));

	/* obtain ceetm interface */
	ceetm_if = dpdmux->iface[if_id].ceetm_if;

	/* obtain ceetm interface attributes */
	ceetm_if_get_attributes(ceetm_if, &ceetm_if_attr);

	memset(map_key, 0, sizeof(map_key));
	memcpy(map_key, addr, key_size);
	if( dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT ) {
		if( mask_ptr ) {
			memcpy(&map_key[key_size], mask_ptr, key_size);
		}
		else {
			memset(&map_key[key_size], 0, key_size);
		}
	}

	err = hmap_lookup(dpdmux->hmap[hmap_index], (hmap_key)map_key, (hmap_data*)(&data));

	if ((allow_modify == 0)
		&& (err != -ENAVAIL))/* exist entry and it's not allowed*/{
		pr_err("Table already contains this rule\n");
		return -EEXIST;
	}

	if( err == 0 && dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT ) {
		if( priority != ((struct dpdmux_hmap_data *)data)->priority ) {
			pr_err("ID[%D] Same table entry exist with different priority\n", dpdmux->id);
			return -EINVAL;
		}
	}

	/* the entry doesn't exist */
	err1 = hmap_add_key(dpdmux->hmap[hmap_index], (hmap_key)map_key);
	if (err1) {
		if (!((allow_modify == 1) && (err1 == -EEXIST)))
		{
			pr_err("hmap_add_key failed (allow_modify: %d, err: %d)\n",
					allow_modify, err1);
			return err1;
		}
	}

	err = hmap_lookup(dpdmux->hmap[hmap_index], (hmap_key)map_key, &data);
	CHECK_COND_RETVAL(err == 0, err, "hmap_lookup failed\n");

	if (dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT) {
		if (!mask_ptr) {
			memset(mask, 0xff, key_size);
			pr_info("key mask is NULL defaulting to 0xFF\n");
		}
		else
			memcpy(mask, mask_ptr, key_size);

		rule.rule_cfg.masked.key = (uint8_t*)addr;
		rule.rule_cfg.masked.mask = (uint8_t*)mask;
		rule.rule_cfg.masked.size = key_size;
		rule.rule_cfg.masked.priority = priority;
	}
	else {
		rule.rule_cfg.exact.key = (uint8_t*)addr;
		rule.rule_cfg.exact.size = key_size;
	}

	memset(&action, 0, sizeof(struct dptbl_action));

	if (table_id == DPDMUX_PRUNE_TBL_IDX) {
		action.next_action = DPTBL_ACTION_DONE;
		action.options = DPTBL_ACTION_SET_OPAQUE | DPTBL_ACTION_SET_REPLIC_ID;
		/* indicates that there is no intention for replication in this entry */
		action.replic_id = 0;
		action.opaque = ceetm_if_attr.qdid;
	}
	else {
		action.next_action = DPTBL_ACTION_DONE;
		action.options = DPTBL_ACTION_SET_QDID;
		action.qd_id = ceetm_if_attr.qdid;
		action.dppolicer_profile_id = owner;
	}

	err = dptbl_add_rule(dpdmux->table[table_id].handle, &rule,
				&action, 0);

	/* check if the entry already exists */
	if ((allow_modify == 1) && (err == -EEXIST)) {
		err = dptbl_modify_rule(dpdmux->table[table_id].handle, /* Table handle */
					&rule, /* Rule */
					&action /* Action */
					);
		CHECK_COND_RETVAL(err == 0, err, "dptbl_modify_rule failed\n");
	} else if( err ) {
		pr_err("ID[%d] failed to add rule", dpdmux->id);

		err1 = hmap_remove_key(dpdmux->hmap[hmap_index], (hmap_key) map_key);
		CHECK_COND_RETVAL(err1 == 0, err1, "hmap_remove_key failed\n");

		return err;
	}

	/* save the owner */
	((struct dpdmux_hmap_data *)data)->owner = owner;

	/* save the priority if applicable */
	if (dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT) {
		((struct dpdmux_hmap_data *)data)->priority = priority;
		memcpy(((struct dpdmux_hmap_data *)data)->mask, mask, key_size);
	}

	if (!(((log_levels[LOG_MODULE] != LOG_LEVEL_GLOBAL)
			&& (log_levels[LOG_MODULE] <= LOG_LEVEL_DEBUG))
			|| ((log_levels[LOG_MODULE] == LOG_LEVEL_GLOBAL)
			&& (log_global_level <= LOG_LEVEL_DEBUG))))
			return 0;

	memset(buf, 0, sizeof(buf));
	count += sprintf((char *)&buf[count], "key:");

	if( (dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT) && (hmap_index == DPDMUX_HMAP_UNICAST_IDX) ) {
		key_size = key_size * 2;
	}

	for (i = 0; i < key_size; i++) {
		count += sprintf((char *)&buf[count], " %x", map_key[i]);
	}
	
	count += sprintf((char *)&buf[count], " , hmap: %d, table: %d, owner: %d\n", hmap_index, table_id, owner);
	
	pr_debug(buf);
	
	return err;
}

static int remove_rule_from_table(struct dpdmux *dpdmux,
	uint8_t *addr,
	uint8_t *mask_ptr,
	uint32_t key_size,
	int hmap_index,
	int table_id,
	enum dpdmux_owner owner,
	int remove_data)
{
	int err;
	struct dptbl_rule rule;
	struct dptbl_action action;
	hmap_data data;
	enum dpdmux_owner stored_owner;
	int remove_allowed = 0;
	int count = 0, i;
	char buf[1024];
	uint8_t mask[DPDMUX_CUSTOM_KEY_SIZE];
	uint8_t map_key[2*DPDMUX_CUSTOM_KEY_SIZE];

	memset(&rule, 0, sizeof(struct dptbl_rule));

	memset(map_key, 0, sizeof(map_key));
	memcpy(map_key, addr, key_size);
	if( dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT ) {
		if( mask_ptr ) {
			memcpy(&map_key[key_size], mask_ptr, key_size);
		}
		else {
			memset(&map_key[key_size], 0xff, key_size);
		}
	}

	err = hmap_lookup(dpdmux->hmap[hmap_index], (hmap_key)map_key, (hmap_data*)(&data));

	CHECK_COND_RETVAL( err == 0 , err,  "ID[%d] Rule does not exist\n", dpdmux->id);

	if (dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT) {
		if (!mask_ptr) {
			memset(mask, 0xff, key_size);
			pr_info("key mask is NULL defaulting to 0xFF\n");
		}
		else
			memcpy(mask, mask_ptr, key_size);

		rule.rule_cfg.masked.key = (uint8_t*)addr;
		rule.rule_cfg.masked.mask = (uint8_t*)mask;
		rule.rule_cfg.masked.size = key_size;
		rule.rule_cfg.masked.priority = ((struct dpdmux_hmap_data *)data)->priority;
	}
	else {
		rule.rule_cfg.exact.key = (uint8_t*)addr;
		rule.rule_cfg.exact.size = key_size;
	}

	memset(&action, 0x0, sizeof(struct dptbl_action));
	err = dptbl_get_action(
		dpdmux->table[table_id].handle, &rule,
		&action);
	CHECK_COND_RETVAL(err == 0, err, "dptbl_get_action()");
	
	/* Can't remove the rule from the table in case that the rule's owner
	 * is management and the entity that ask to remove the rule is not
	 * management
	 */
	stored_owner = ((struct dpdmux_hmap_data *)data)->owner;
	if (owner == stored_owner)
		remove_allowed = 1;
	else
		if ((owner == DPDMUX_OWNER_MANAGEMENT ) && (stored_owner == (uint64_t)DPDMUX_OWNER_NIC))
			remove_allowed = 1;

	if (remove_allowed == 0)
	{
		pr_err("owner of rule is different  - can't remove the address\n");
		return -EINVAL;
	}

	err = dptbl_remove_rule(
		dpdmux->table[table_id].handle, &rule);

	CHECK_COND_RETVAL(err == 0, err, "dptbl_remove_rule()\n");

	/* the entry already exists */
	err = hmap_remove_key(dpdmux->hmap[hmap_index], (hmap_key)map_key);
	CHECK_COND_RETVAL(err == 0, err);

	if (!(((log_levels[LOG_MODULE] != LOG_LEVEL_GLOBAL)
		&& (log_levels[LOG_MODULE] <= LOG_LEVEL_DEBUG))
		|| ((log_levels[LOG_MODULE] == LOG_LEVEL_GLOBAL)
		&& (log_global_level <= LOG_LEVEL_DEBUG))))
		return 0;

	memset(buf, 0, sizeof(buf));
	count += sprintf((char *)&buf[count], "key:");

	if( (dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT) && (hmap_index == DPDMUX_HMAP_UNICAST_IDX) ) {
		key_size = key_size * 2;
	}

	for (i = 0; i < key_size; i++) {
		count += sprintf((char *)&buf[count], " %x", map_key[i]);
	}

	count += sprintf((char *)&buf[count], " , hmap: %d, table: %d, owner: %d\n", hmap_index, table_id, owner);

	pr_debug(buf);

	return 0;
}

static int remove_if_from_replication_list(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint8_t *addr,
	struct hmap *hmap,
	enum dpdmux_owner owner,
	int *head_rrid,
	int *is_empty)
{
	int err;
	hmap_data replic;
	int head_id;
	uint64_t opaque;
	int remove_allowed = 0;

	CHECK_COND_RETVAL(dpdmux, -EINVAL);
	err = hmap_lookup(hmap, (hmap_key)addr, &replic);
	if (err == -ENAVAIL) {
		pr_err("hmap_lookup failed - no existing entry\n");
		return err;
	}

	/* check that the owner of the rule is the one that ask to remove it */
	/*	if (action.dppolicer_profile_id != owner) {
	 pr_err("owner of rule is different  - can't remove the address\n");
	 return -EINVAL;
	 } */

	/* check rule owner */
	err = replic_get_element_opaque(replic, if_id, &opaque);
	CHECK_COND_RETVAL(err == 0, err, "replic_get_element_opaque : %d\n", err);

	if (owner == opaque)
		remove_allowed = 1;
	else
		if ((owner == DPDMUX_OWNER_MANAGEMENT ) && (opaque == (uint64_t)DPDMUX_OWNER_NIC))
			remove_allowed = 1;

	if (remove_allowed == 0)
	{
		pr_err("owner of rule is different  - can't remove the address\n");
		return -EINVAL;
	}

	err = replic_remove_element(replic, if_id);
	CHECK_COND_RETVAL(err == 0, err, "replic_remove_element : %d\n", err);

	*is_empty = replic_is_empty(replic);

	if (*is_empty == 1) {
		/* search the address in the hash table */
		err = hmap_lookup(hmap, addr, &replic);
		if (err == -ENAVAIL)/* no entry*/{
			pr_err("hmap_lookup failed\n");
			return err;
		}
		/* remove the address from the hash table */
		err = hmap_remove_key(hmap, addr);
		CHECK_COND_RETVAL(err == 0, err, "hmap_remove_key failed\n");
	} else {
		/* get the head element */
		err = replic_get_element_head(replic, &head_id);
		CHECK_COND_RETVAL(err == 0, err, "replic_get_element_head failed \n");

		err = replic_get_element_rrid(replic, head_id, head_rrid);
		CHECK_COND_RETVAL(err == 0, err, "replic_get_element_rrid failed \n");
	}

	return 0;
}

static int remove_rule_with_replication_from_table(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint8_t *addr,
	struct hmap *hmap,
	enum dpdmux_owner owner,
	uint32_t key_size,
	int table_index,
	int miss_entry)
{
	struct dptbl_rule rule;
	struct dptbl_action action;
	int err;
	hmap_data replic;
	int is_empty = 0;
	int head_rrid;

	CHECK_COND_RETVAL(dpdmux, -EINVAL);
	err = hmap_lookup(hmap, (hmap_key)addr, &replic);
	if (err == -ENAVAIL) {
		pr_err("hmap_lookup failed - no existing entry\n");
		return err;
	}

	/* check that the owner of the rule is the one that ask to remove it */
	memset(&rule, 0, sizeof(struct dptbl_rule));
	memset(&action, 0, sizeof(struct dptbl_action));

	err = remove_if_from_replication_list(dpdmux, if_id, addr, hmap, owner,
						&head_rrid, &is_empty);
	CHECK_COND_RETVAL(err == 0, err, "remove_if_from_replication_list : %d\n", err);

	rule.rule_cfg.exact.key = (uint8_t*)addr;
	rule.rule_cfg.exact.size = key_size;

	if (is_empty == 1) {
		err = dptbl_get_action(
			dpdmux->table[table_index].handle,
			&rule, &action);
		CHECK_COND_RETVAL(err == 0, err);

		/* remove the rule from the DMAT */
		err = dptbl_remove_rule(
			dpdmux->table[table_index].handle,
			&rule);
	} else {
		/* prepare the action for modify operation */
		action.next_action = DPTBL_ACTION_DONE;
		action.options = DPTBL_ACTION_SET_QDID
					| DPTBL_ACTION_SET_REPLIC_ID;
		action.qd_id = dpdmux->replicator.qdid;
		action.replic_id = head_rrid;

		err = ((miss_entry == 1) ? /* check if modify regular entry or modify the miss entry */
		dptbl_modify_miss_action(dpdmux->table[table_index].handle,
						&action) :
		dptbl_modify_rule(
			dpdmux->table[table_index].handle,
			&rule, &action));

	}
	
	CHECK_COND_RETVAL(err == 0, err, "dptbl_modify/remove_rule failed \n");

	return 0;
}

static int build_miss_key(struct dpdmux *dpdmux,
	uint16_t vlan_id,
	int multicast,
	uint8_t *key)
{
	switch (dpdmux->method) {
	case DPDMUX_METHOD_C_VLAN_MAC:
		/* check if to set multicast bit in FAF */
		if (multicast)
			key[0] = 0x08; /* multicast bit in FAF is set */
		else
			key[0] = 0;/* multicast bit in FAF is not set */

		key[1] = (uint8_t)((vlan_id & 0x0f00) >> 8);
		key[2] = (uint8_t)(vlan_id & 0x00ff);
		break;
	case DPDMUX_METHOD_MAC:
		if (multicast)
			key[0] = 0x08; /* multicast bit in FAF is set */
		else
			key[0] = 0;/* multicast bit in FAF is not set */
		break;
	case DPDMUX_METHOD_C_VLAN:
		key[0] = (uint8_t)((vlan_id & 0x0f00) >> 8);
		key[1] = (uint8_t)(vlan_id & 0x00ff);
		break;
	case DPDMUX_METHOD_S_VLAN:
	case DPDMUX_METHOD_CUSTOM:
		return -ENOTSUP;
	}
	return 0;
}

static void get_miss_info_by_method(struct dpdmux *dpdmux,
	int *num_entries,
	int *key_size)
{
	switch (dpdmux->method) {
	case DPDMUX_METHOD_C_VLAN_MAC:
		/* 2 means one for unicast and one for multicast
		 * +1 for the case of vlan = 0 */
		*num_entries = 2 * (dpdmux->max_vlan_ids + 1);
		*key_size = 3;
		break;
	case DPDMUX_METHOD_MAC:
		*num_entries = 2;
		*key_size = 1;
		break;
	case DPDMUX_METHOD_C_VLAN:
		/* only one entry for miss handling - no extra table
		 * is required
		 */
		*num_entries = 0;
		*key_size = 2;
		break;
	case DPDMUX_METHOD_S_VLAN:
	case DPDMUX_METHOD_CUSTOM:
		*num_entries = 0;
		*key_size = 0;
		break;
	}

	return;
}

static int get_multicast_max_num(struct dpdmux *dpdmux)
{
	int multicast_max_num = 0;
	
	switch (dpdmux->method) {
		case DPDMUX_METHOD_C_VLAN_MAC:
			multicast_max_num = 
				dpdmux->max_mc_groups + /* number of mc entries */
				dpdmux->max_vlan_ids + 	/* number of bc entries */
				1;			/* bc with vlan 0 */
			break;
		case DPDMUX_METHOD_MAC:
			multicast_max_num = 
				dpdmux->max_mc_groups + /* number of mc entries */
				1;			/* bc with vlan 0 */
			break;
		case DPDMUX_METHOD_C_VLAN:
			multicast_max_num = 1;
			break;
		case DPDMUX_METHOD_S_VLAN:
		case DPDMUX_METHOD_CUSTOM:
		default:
			multicast_max_num = 0;
			break;
	}
	
	return multicast_max_num;
}

static int update_miss_entry_in_dmat(struct dpdmux *dpdmux,
	uint16_t if_id,
	enum dpdmux_owner owner,
	int add)
{
	int err = 0;
	uint8_t miss_key[DPDMUX_VLAN_KEY_SIZE];
	uint32_t key_size = DPDMUX_VLAN_KEY_SIZE;
	struct dptbl_action action;
        struct ceetm_if_attr    ceetm_if_attr;
        struct ceetm_if         *ceetm_if;


	/* the routine updates the miss entry in the dmat table in case of
	 * vlan only method
	 * this routine is required for updating
	 *  	1.the default interface
	 *  	2.the uplink interface - in case of bridging
	 */
        /* obtain ceetm interface */
        ceetm_if = dpdmux->iface[if_id].ceetm_if;

        /* obtain ceetm interface attributes */
        ceetm_if_get_attributes(ceetm_if, &ceetm_if_attr);

	memset(miss_key, 0xFF, (sizeof(uint8_t) * DPDMUX_VLAN_KEY_SIZE));

	if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN) {
		/* add new interface to the miss entry */
		if (add)
			err = add_rule_with_replication_to_table(
				dpdmux, (uint16_t)if_id, miss_key,
				dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX],
				owner, key_size,
				(int)DPDMUX_DMAT_IDX, 1/* miss_entry */);
		else
			/* remove an interface from the miss entry */
			err = remove_rule_with_replication_from_table(
				dpdmux, (uint16_t)if_id, miss_key,
				dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX],
				owner, key_size,
				(int)DPDMUX_DMAT_IDX, 1/* miss_entry */);
		}
	else /* VEPA handling - only add/remove the default interface */
	{
		memset(&action, 0, sizeof(struct dptbl_action));

		if (add) {
			/* prepare the action for modify operation -
			 * add the default interface to miss action
			 * */
			action.next_action = DPTBL_ACTION_DONE;
			action.options = DPTBL_ACTION_SET_QDID;
			action.qd_id = ceetm_if_attr.qdid;
		}
		else {
			/* remove the default interface from the miss action
		 	 * which means discard operation
		 	 * */
			action.next_action = DPTBL_ACTION_DONE;
			action.options = DPTBL_ACTION_SET_DISCARD_FLAG;
		}
		err = dptbl_modify_miss_action(dpdmux->table[DPDMUX_DMAT_IDX].handle,
						&action);
	}
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}

static int update_entry_in_miss_table_with_key(struct dpdmux *dpdmux,
	uint16_t if_id,
	enum dpdmux_owner owner,
	uint8_t *miss_key,
	uint32_t miss_key_size,
	int add)
{

	int err = 0;

	/* the routine updates an entry in the miss table in case of
	 * MAC & vlan method or MAC only method
	 * this routine is required for updating
	 *  	1.the default interface
	 *  	2.the uplink interface - in case of bridging
	 *  	3. multicast/unicast promiscuous interface
	 */

	/* add or remove the interface from the miss table */
	if (add)
		err = add_rule_with_replication_to_table(
			dpdmux, (uint16_t)if_id, miss_key, dpdmux->hmap[DPDMUX_HMAP_MISS_IDX],
			owner,
			miss_key_size, (int)DPDMUX_MISS_TBL_IDX,
			0/* miss_entry */);
	else
		err = remove_rule_with_replication_from_table(
			dpdmux, (uint16_t)if_id, miss_key, dpdmux->hmap[DPDMUX_HMAP_MISS_IDX],
			owner,
			miss_key_size, (int)DPDMUX_MISS_TBL_IDX,
			0/* miss_entry */);

	return err;
}

static int update_entry_in_miss_table(struct dpdmux *dpdmux,
	uint16_t if_id,
	enum dpdmux_owner owner,
	uint16_t vlan_id,
	int multicast,
	int add)
{

	int err = 0;
	uint8_t miss_key[DPDMUX_MAX_MISS_KEY_SIZE];
	int num_entries = 0;
	uint32_t miss_key_size = 0;

	/* the routine updates an entry in the miss table in case of
	 * MAC & vlan method or MAC only method
	 * this routine is required for updating
	 *  	1.the default interface
	 *  	2.the uplink interface - in case of bridging
	 *  	3. multicast/unicast promiscuous interface
	 */

	memset(miss_key, 0, (sizeof(uint8_t) * DPDMUX_MAX_MISS_KEY_SIZE));

	get_miss_info_by_method(dpdmux, &num_entries, &miss_key_size);

	err = build_miss_key(dpdmux, vlan_id, multicast, miss_key);
	CHECK_COND_RETVAL(err == 0, err);

	err = update_entry_in_miss_table_with_key(dpdmux, if_id, owner, miss_key,
							miss_key_size, add);

	return err;
}

static int init_ctlu_dmat(struct dpdmux *dpdmux)
{
	struct dptbl_cfg tbl_cfg;
	struct dptbl_action action_on_miss;

	memset(&tbl_cfg, 0x0, sizeof(struct dptbl_cfg));
	memset(&action_on_miss, 0x0, sizeof(struct dptbl_action));

	tbl_cfg.mem_type = DPTBL_INT_MEMORY;
	tbl_cfg.aging_threshold = 0;

	if (dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT)
		tbl_cfg.type = DPTBL_TYPE_TCAM_ACL;
	else
		tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;

	tbl_cfg.action_on_miss = &action_on_miss;
	tbl_cfg.options = DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;

	switch (dpdmux->method) {
	case (DPDMUX_METHOD_C_VLAN_MAC):
		tbl_cfg.max_rules = (uint32_t)(dpdmux->max_dmat_entries +
			dpdmux->max_mc_groups +
			dpdmux->max_vlan_ids + /* entry of broadcast per vlan */
		        1 + /* one for broadcast with vlan 0 */
		        1);/*for miss */
		tbl_cfg.max_key_size = DPDMUX_VLAN_MAC_KEY_SIZE;

		/* initialize the miss entry to go to the miss table */
		action_on_miss.next_action = DPTBL_ACTION_LOOKUP;
		action_on_miss.lookup_params.dptbl_id =
			dpdmux->table[DPDMUX_MISS_TBL_IDX].id;
		action_on_miss.lookup_params.dpkg_profile_id =
			dpdmux->kg[DPDMUX_KG_MISS_IDX].id;

		break;
	case (DPDMUX_METHOD_C_VLAN):
		tbl_cfg.max_rules = (uint32_t)(dpdmux->max_dmat_entries +
			1 + /* one for broadcast with vlan 0 */
			1);/*for miss */
		tbl_cfg.max_key_size = DPDMUX_VLAN_KEY_SIZE;

		/* initialize the miss entry to go to the prune table -
		 * relevant only in case of rev1 and only in case of VEB
		 * in case of VEPA, there is no prunning */
		if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN) {
			action_on_miss.next_action = DPTBL_ACTION_LOOKUP;
			action_on_miss.lookup_params.dptbl_id =
				dpdmux->table[DPDMUX_PRUNE_TBL_IDX].id;
			action_on_miss.lookup_params.dpkg_profile_id =
				dpdmux->kg[DPDMUX_KG_PRUNE_IDX].id;
		}
		else {
			action_on_miss.next_action = DPTBL_ACTION_DONE;
			action_on_miss.options = DPTBL_ACTION_SET_DISCARD_FLAG;
		}
		break;
	case (DPDMUX_METHOD_MAC):
		tbl_cfg.max_rules = (uint32_t)(dpdmux->max_dmat_entries +
			dpdmux->max_mc_groups +
			1 + /* one for broadcast with vlan 0 */
			1);/*for miss */
		tbl_cfg.max_key_size = DPDMUX_MAC_KEY_SIZE;

		/* initialize the miss entry to go to the miss table */
		action_on_miss.next_action = DPTBL_ACTION_LOOKUP;
		action_on_miss.lookup_params.dptbl_id =
			dpdmux->table[DPDMUX_MISS_TBL_IDX].id;
		action_on_miss.lookup_params.dpkg_profile_id =
			dpdmux->kg[DPDMUX_KG_MISS_IDX].id;
		break;
	case (DPDMUX_METHOD_CUSTOM):
		tbl_cfg.max_rules = (uint32_t)(dpdmux->max_dmat_entries);
		tbl_cfg.max_key_size = DPDMUX_CUSTOM_KEY_SIZE;

		/* should discard on miss, no other default action for now */
		action_on_miss.next_action = DPTBL_ACTION_DONE;
		action_on_miss.options = DPTBL_ACTION_SET_DISCARD_FLAG;
		break;
	default:
		return -ENOTSUP;
	}

	dpdmux->table[DPDMUX_DMAT_IDX].handle = dptbl_init(
		dpdmux->hndl.dptbl_ing, &tbl_cfg); /* params structure */

	if (dpdmux->table[DPDMUX_DMAT_IDX].handle == NULL)
		return -ENAVAIL;

	dptbl_get_id(dpdmux->table[DPDMUX_DMAT_IDX].handle, /*DMAT Handle */
			&dpdmux->table[DPDMUX_DMAT_IDX].id /* Table ID */);

	dpdmux->table[DPDMUX_DMAT_IDX].key_size = tbl_cfg.max_key_size;

#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		memset(&action_on_miss, 0, sizeof(action_on_miss));
		memset(&tbl_cfg, 0, sizeof(tbl_cfg));
		tbl_cfg.max_key_size = 6; /* MAC ADDR size */
		tbl_cfg.max_rules = 2;
		tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
		tbl_cfg.options |= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
		tbl_cfg.action_on_miss = &action_on_miss;

		action_on_miss.next_action = DPTBL_ACTION_LOOKUP;
		action_on_miss.lookup_params.dptbl_id = dpdmux->table[DPDMUX_DMAT_IDX].id;
		action_on_miss.lookup_params.dpkg_profile_id = dpdmux->kg[DPDMUX_KG_DMAT_IDX].id;

		dpdmux->fc_filtering_tbl.handle = dptbl_init(dpdmux->hndl.dptbl_ing, &tbl_cfg);
		CHECK_COND_RETVAL( dpdmux->fc_filtering_tbl.handle!=NULL, -ENAVAIL, "ID[%d]: Error creating flow control filtering table\n", dpdmux->id);

		dptbl_get_id(dpdmux->fc_filtering_tbl.handle, &dpdmux->fc_filtering_tbl.id);

		dpdmux_filter_flow_control_multicast(dpdmux);
	}
#endif

	return 0;
}

static void add_if_to_ifp_prune_table(struct dpdmux *dpdmux, int id)
{
	struct dptbl_rule rule;
	struct dptbl_action action;
	int err;
	uint32_t key;
        struct ceetm_if_attr    ceetm_if_attr;
        struct ceetm_if         *ceetm_if;

        /* obtain ceetm interface */
        ceetm_if = dpdmux->iface[id].ceetm_if;

        /* obtain ceetm interface attributes */
        ceetm_if_get_attributes(ceetm_if, &ceetm_if_attr);

	memset(&rule, 0, sizeof(struct dptbl_rule));
	memset(&action, 0, sizeof(struct dptbl_action));

	key = ((uint32_t)(dpdmux->iface[id].ap.ifpid) << 16);

	rule.rule_cfg.exact.key = (uint8_t*)&key;
	rule.rule_cfg.exact.size = DPDMUX_IFP_PRUNE_TBL_KEY_SIZE;

	action.next_action = DPTBL_ACTION_DONE;
	action.options = DPTBL_ACTION_SET_OPAQUE | DPTBL_ACTION_SET_REPLIC_ID;
	/* indicates that there is no intention for replication in this entry */
	action.replic_id = 0;
	action.opaque = ceetm_if_attr.qdid;

	err = dptbl_add_rule(dpdmux->table[DPDMUX_PRUNE_TBL_IDX].handle, &rule, &action, 0);
	CHECK_COND_RET(err == 0);

#ifdef DPDMUX_DEBUG
	err = add_rule_to_table(dpdmux,
			(uint16_t)id,
			(uint8_t*)&key,
			NULL,
			DPDMUX_IFP_PRUNE_TBL_KEY_SIZE,/*key_size*/
			DPDMUX_HMAP_PRUNE_IDX,/*hmap_index*/
			DPDMUX_PRUNE_TBL_IDX,/*table_id*/
			DPDMUX_OWNER_INTERNAL,/*owner,*/
			0/*allow_modify*/);
	CHECK_COND_RET(err == 0);
#endif
	return;
}

static void remove_if_from_ifp_prune_table(struct dpdmux *dpdmux, int id)
{
	struct dptbl_rule rule;
	int err = 0;
	uint32_t key;

	memset(&rule, 0, sizeof(struct dptbl_rule));

	key = ((uint32_t)(dpdmux->iface[id].ap.ifpid) << 16);

	rule.rule_cfg.exact.key = (uint8_t*)&key;
	rule.rule_cfg.exact.size = DPDMUX_IFP_PRUNE_TBL_KEY_SIZE;

	err = dptbl_remove_rule(dpdmux->table[DPDMUX_PRUNE_TBL_IDX].handle, &rule);
	CHECK_COND_RET(err == 0);
#ifdef DPDMUX_DEBUG
	err = remove_rule_from_table(dpdmux,
			(uint8_t*)&key,
			NULL,
			DPDMUX_IFP_PRUNE_TBL_KEY_SIZE,
			DPDMUX_HMAP_PRUNE_IDX,/*hmap_index*/
			DPDMUX_PRUNE_TBL_IDX,/*table_id*/
			DPDMUX_OWNER_INTERNAL,/*owner,*/
			1/*remove data*/);
	CHECK_COND_RET(err == 0);
#endif
	return;
}

static int init_ctlu_prune_table(struct dpdmux *dpdmux)
{
	struct dptbl_cfg tbl_cfg;
	struct dptbl_action action_on_miss;

	memset(&tbl_cfg, 0x0, sizeof(struct dptbl_cfg));
	memset(&action_on_miss, 0x0, sizeof(struct dptbl_action));

	/* mode | key     | table size
	 * -----------------------------------
	 * VEB  | IFP     | #interfaces
	 * -----------------------------------
	 * VEPA | src MAC | #dmat_entries
	 * -----------------------------------
	 */
	if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN) {
		tbl_cfg.max_rules = dpdmux->num_ifs;
		tbl_cfg.max_key_size = DPDMUX_IFP_PRUNE_TBL_KEY_SIZE;
	}
	else {
		tbl_cfg.max_rules = dpdmux->max_dmat_entries;
		tbl_cfg.max_key_size = DPDMUX_SRC_MAC_PRUNE_TBL_KEY_SIZE;
	}

	tbl_cfg.mem_type = DPTBL_INT_MEMORY;
	tbl_cfg.aging_threshold = 0;
	tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
	tbl_cfg.options = DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
	tbl_cfg.action_on_miss = NULL;

	dpdmux->table[DPDMUX_PRUNE_TBL_IDX].handle = dptbl_init(dpdmux->hndl.dptbl_ing,
							&tbl_cfg); /* params structure */

	if (dpdmux->table[DPDMUX_PRUNE_TBL_IDX].handle == NULL)
		return -ENAVAIL;

	dptbl_get_id(dpdmux->table[DPDMUX_PRUNE_TBL_IDX].handle, /*DMAT Handle */
			&dpdmux->table[DPDMUX_PRUNE_TBL_IDX].id); /* Table ID */

	dpdmux->table[DPDMUX_PRUNE_TBL_IDX].key_size = tbl_cfg.max_key_size;

	return 0;
}

static int init_ctlu_miss_table(struct dpdmux *dpdmux)
{
	struct dptbl_cfg tbl_cfg;
	struct dptbl_action miss_action;
	int num_entries = 0, key_size = 0;

	memset(&tbl_cfg, 0x0, sizeof(struct dptbl_cfg));
	memset(&miss_action, 0x0, sizeof(struct dptbl_action));

	get_miss_info_by_method(dpdmux, &num_entries, &key_size);

	tbl_cfg.max_rules = (uint32_t)num_entries;

	tbl_cfg.mem_type = DPTBL_INT_MEMORY;
	tbl_cfg.aging_threshold = 0;
	tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
	tbl_cfg.options = DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION
				| DPTBL_OPTIONS_OPTIMIZIED_DISCARD;

	/* Miss Action */
	miss_action.next_action = DPTBL_ACTION_DONE;
	tbl_cfg.action_on_miss = &miss_action;
	tbl_cfg.max_key_size = (uint8_t)key_size;

	dpdmux->table[DPDMUX_MISS_TBL_IDX].handle = dptbl_init(
		dpdmux->hndl.dptbl_ing, &tbl_cfg); /* params structure */

	if (dpdmux->table[DPDMUX_MISS_TBL_IDX].handle == NULL)
		return -ENAVAIL;

	dptbl_get_id(dpdmux->table[DPDMUX_MISS_TBL_IDX].handle, /*DMAT Handle */
			&dpdmux->table[DPDMUX_MISS_TBL_IDX].id /* Table ID */
			);

	dpdmux->table[DPDMUX_MISS_TBL_IDX].key_size = tbl_cfg.max_key_size;

	return 0;
}

static int policy_add_rule_parse_error(struct dpdmux_policy *policy)
{
	int err;
	struct dppolicy_rule rule; /* Policy rule */
	struct dppolicy_action action; /* Policy Action */

	memset(&rule, 0, sizeof(struct dppolicy_rule));
	memset(&action, 0, sizeof(struct dppolicy_action));

	/* Defining rule and action for parsing error */

	rule.num_of_identifiers = 1; /* Parsing error */
	rule.priority = DPDMUX_POLICY_PRI_ERR; /* Priority */
	rule.identifiers[0].exclude = 0; /* include */
	rule.identifiers[0].type = DPPOLICY_IDENTIFIER_GEN_PRS_ERR;

	action.next_action = DPPOLICY_ACTION_DONE; /* Discard */
	action.options = DPPOLICY_ACTION_SET_DISCARD_FLAG;
	/* Adding the rule */
	err = dppolicy_add_rule(policy->handle, /* Policy handle */
				&rule, /* Rule */
				&action, /* Action */
				0);

	return err;
}

static int policy_allocate_and_init(struct dpdmux *dpdmux,
	int policy_index,
	int max_rules)
{
	int err;
	struct dpdmux_policy *policy = &(dpdmux->policy[policy_index]);
	uint16_t pool_attr[RESMAN_MAX_POOL_ATTR_NUM];
	struct dppolicy_cfg policy_cfg;
	char type[16];

	memset(pool_attr, 0x0, sizeof(pool_attr));

	snprintf(type, sizeof(type), "plcy.wr%d.%s", 0 /*eiop_id*/,
			"ctlui"/* CTLU_EIOP_INGRESS */);
	err = allocate_resource(dpdmux->hndl.dprc, /* Resource manager handle */
				type, /* Resource type */
				1, /* Number of resources */
				1, /* Base align */
				0, /* Options */
				&(policy->id), /* Address */
				"POLICY"); /* Error string */
	CHECK_COND_RETVAL(err == 0, err, "allocate_resource (policy): %d\n", err);

	/* Initialize policy */

	/* Clear Configuration Parameters */
	memset(&policy_cfg, 0x0, sizeof(struct dppolicy_cfg));

	policy_cfg.max_num_of_rules = (uint16_t)max_rules;

	policy->handle = dppolicy_init(dpdmux->hndl.dppolicy_ing,/*Policy hndl*/
					policy->id, /* Policy ID */
					&policy_cfg); /* Policy configuration */

	if (policy->handle == NULL) {
		pr_err("ID[%d]: dppolicy_init failed\n", dpdmux->id);
		return -ENAVAIL;
	}

	return 0;
}

static int init_ctlu_policy_all(struct dpdmux *dpdmux)
{
	int err;
	struct dppolicy_rule rule; /* Policy rule */
	struct dppolicy_action action; /* Policy Action */

	/* policy allocation and initialization */
	err =
		policy_allocate_and_init(
			dpdmux,
			DPDMUX_POLICY_ALL,
			DPDMUX_MAX_POLICY_RULES);
	CHECK_COND_RETVAL(err == 0, err, "policy_allocate_and_init (policy all): %d\n", err);

	/* START OF RULES ADDITIONS */

	/* RULES:
	 * 	Parsing error
	 *	1-Vlan
	 *  N- Vlan
	 *  BPDU and other control frames
	 *	Miss
	 */

	/* Adding parsing error rule */
	err = policy_add_rule_parse_error(
		&(dpdmux->policy[DPDMUX_POLICY_ALL]));
	CHECK_COND_RETVAL(err == 0, err, "policy_add_rule_parse_error (policy all): %d\n", err);
#if 0
	/* Adding "1-Vlan" rule */
	memset(&rule, 0x00, sizeof(struct dppolicy_rule));
	memset(&action, 0x00, sizeof(struct dppolicy_action));

	rule.priority = DPDMUX_MAX_POLICY_RULES - 2; /* ?? */
	rule.num_of_identifiers = 1;
	rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT;
	rule.identifiers[0].prot = NET_PROT_VLAN;
	rule.identifiers[0].hdr_index = 0;

	action.next_action = DPPOLICY_ACTION_LOOKUP; /* lookup */
	action.lookup_params.dpkg_profile_id =
	dpdmux->kg[DPDMUX_KG_DMAT_IDX].id;/* KID */
	action.lookup_params.dptbl_id = dpdmux->dmat/*[DPDMUX_DMAT_IDX]*/.id; /* TID */

	err = dppolicy_add_rule(policy->handle, &rule, &action, 0);
	if (err != 0)
	return -err;

	/* Adding rule for "N-Vlan" */
	memset(&rule, 0x00, sizeof(struct dprule));
	memset(&action, 0x00, sizeof(struct dpaction));

	rule.priority = (DPDMUX_MAX_POLICY_RULES - 5); /* ?? */
	rule.num_of_identifiers = 1;
	rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT;
	rule.identifiers[0].prot = NET_PROT_VLAN;
	rule.identifiers[0].hdr_index = (uint8_t)LAST_HDR_INDEX;

	action.next_action = DPPOLICY_ACTION_DISCARD;

	err = dppolicy_add_rule(dpdmux->policy[DPDMUX_POLICY_ALL].handle,
		&rule, &action, 0);
	if (err != 0)
	return -err;

	/* Adding rule for "BPDU" */
	memset(&rule, 0x00, sizeof(struct dprule));
	memset(&action, 0x00, sizeof(struct dpaction));

	rule.priority = DPDMUX_MAX_POLICY_RULES - 3; /* ?? */
	rule.num_of_identifiers = 1;

	rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT_OPT;
	rule.identifiers[0].prot = NET_PROT_ETH;
	rule.identifiers[0].opt = NET_HDR_OPT_ETH_BPDU;
	rule.identifiers[0].hdr_index = 0;

	action.next_action = DPPOLICY_ACTION_DISCARD;

	err = dppolicy_add_rule(dpdmux->policy[DPDMUX_POLICY_ALL].handle,
		&rule, &action, 0);
	if (err != 0)
	return -err;
#endif
#ifdef BROADCAST
	/* Adding broadcast rule - only in case the dmux is configured to work
	 * in MAC method, otherwise- the broadcast entry will be added for each of the
	 * configured vlans */
	if (dpdmux->method == DPDMUX_METHOD_MAC) {
		/* fulfill the broadcast address */
		memset(broadcast_addr, 0xFF, DPDMUX_BROADCAST_ADDR_SIZE);

		/* add all the interfaces to the replication list of the broadcast */
		for (i=0; i < dpdmux->num_ifs; i++) {
			err = add_if_to_replication_list(dpdmux,
				(uint16_t)i,
				broadcast_addr,
				dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX],
				&head_rrid,
				&new_group);
			if (err) {
				pr_err("add_if_to_replication_list failed (if_id %d\n", i);
				return err;
			}
		}

		/* Adding rule for "broadcast" */
		if (!(dpdmux->options & DPDMUX_OPT_REPLICATION_DIS)) {
			memset(&rule, 0x00, sizeof(struct dppolicy_rule));
			memset(&action, 0x00, sizeof(struct dppolicy_action));

			rule.priority = DPDMUX_MAX_POLICY_RULES - 2; /* ?? */
			rule.num_of_identifiers = 1;

			rule.identifiers[0].type = DPPOLICY_IDENTIFIER_PROT_OPT;
			rule.identifiers[0].prot = NET_PROT_ETH;
			rule.identifiers[0].opt = NH_OPT_ETH_BROADCAST;
			rule.identifiers[0].hdr_index = 0;

			action.next_action = DPPOLICY_ACTION_LOOKUP;
			action.options = DPPOLICY_ACTION_SET_QDID |
			DPPOLICY_ACTION_SET_REPLIC_ID;
			action.qd_id = dpdmux->replicator.qdid;
			action.replic_id = head_rrid;
			action.dppolicer_profile_id = DPDMUX_OWNER_MANAGEMENT;
			/* set tid and kid for pruning table */
			action.lookup_params.dptbl_id = dpdmux->prune_tbl.id;
			action.lookup_params.dpkg_profile_id =
			dpdmux->kg[DPDMUX_KG_PRUNE_IDX].id;

			err = dppolicy_add_rule(dpdmux->policy[DPDMUX_POLICY_ALL].handle,
				&rule, &action, 0);
			if (err) {
				pr_err("dppolicy_add_rule failed (broadcast rule)\n");
				return err;
			}
		}
	}
#endif /* BROADCAST */
	/* Adding "Miss" rule */
	memset(&rule, 0x00, sizeof(struct dppolicy_rule));
	memset(&action, 0x00, sizeof(struct dppolicy_action));

	rule.priority = DPDMUX_MAX_POLICY_RULES - 1;
	rule.num_of_identifiers = 0;

#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		action.next_action = DPPOLICY_ACTION_LOOKUP;
		action.lookup_params.dpkg_profile_id = dpdmux->fc_filtering_kid.id;
		action.lookup_params.dptbl_id = dpdmux->fc_filtering_tbl.id;
	}
	else {
		/* go to the DMux address table for lookup */
		action.next_action = DPPOLICY_ACTION_LOOKUP;
		action.lookup_params.dpkg_profile_id =
			dpdmux->kg[DPDMUX_KG_DMAT_IDX].id;
		action.lookup_params.dptbl_id = dpdmux->table[DPDMUX_DMAT_IDX].id;
	}
#else
	/* go to the DMux address table for lookup */
	action.next_action = DPPOLICY_ACTION_LOOKUP;
	action.lookup_params.dpkg_profile_id =
		dpdmux->kg[DPDMUX_KG_DMAT_IDX].id;
	action.lookup_params.dptbl_id = dpdmux->table[DPDMUX_DMAT_IDX].id;
#endif

	err = dppolicy_add_rule(dpdmux->policy[DPDMUX_POLICY_ALL].handle,
				&rule, &action, 0);

	/* END OF RULES ADDITIONS */

	return err;

}

static int init_ctlu_policy(struct dpdmux *dpdmux)
{
	int err;

	err = init_ctlu_policy_all(dpdmux);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_policy_all: %d\n", err);
#if 0
	err = init_ctlu_policy_tagonly(dpdmux);
	if (err != 0)
	return err;
	err = init_ctlu_policy_untagonly(dpdmux);
	if (err != 0)
	return err;
#endif
	return 0;

}

static int init_ctlu(struct dpdmux *dpdmux)
{
	int err;
	enum ctlu_type ctlu_type;

	if (!(dpdmux->options & DPDMUX_OPT_REPLICATION_DIS)) {
		/* Key Generation */
		err = init_ctlu_prune_kg(dpdmux);
		CHECK_COND_RETVAL(err == 0, err, "init_ctlu_prune_kg : %d\n", err);

		err = init_ctlu_prune_table(dpdmux);
		CHECK_COND_RETVAL(err == 0, err, "init_ctlu_prune_table : %d\n", err);

		/* miss table allocation -
		 * relevant only in case of MAC&VLAN method or MAC method */
		if ((dpdmux->method == DPDMUX_METHOD_C_VLAN_MAC)
			|| (dpdmux->method == DPDMUX_METHOD_MAC)) {
			/* allocate key for the miss table - multicast bit in FAF */
			err = init_ctlu_miss_kg(dpdmux);
			CHECK_COND_RETVAL(err == 0, err, "init_ctlu_miss_kg : %d\n", err);

			/* allocate miss table */
			err = init_ctlu_miss_table(dpdmux);
			CHECK_COND_RETVAL(err == 0, err, "init_ctlu_miss_table : %d\n", err);
		}
	}
	/* Key Generation */
	err = init_ctlu_kg(dpdmux);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_kg : %d\n", err);
	
	/* CTLU DMAT */
	err = init_ctlu_dmat(dpdmux);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_dmat failed : %d\n", err);

	/* Policy */
	err = init_ctlu_policy(dpdmux);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_policy : %d\n", err);

	/* Parser */
	ctlu_type = CTLU_EIOP_INGRESS;
	err = init_ctlu_prp(dpdmux, ctlu_type, &(dpdmux->prp_ing));
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_prp (ingress) : %d\n", err);

	ctlu_type = CTLU_EIOP_EGRESS;
	err = init_ctlu_prp(dpdmux, ctlu_type, &(dpdmux->prp_egr));
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu_prp (egress) : %d\n", err);

	return err;
}

static int init_replicator_miss(struct dpdmux *dpdmux)
{
	int err = 0, i;
	int key_size;
	hmap_data data;
	struct replic_cfg replic_cfg;
	int num_hash_entries = 0;

	get_miss_info_by_method(dpdmux, &num_hash_entries, &key_size);

	/* no need of hash allocation in case the number of hash entries is 0 */
	if (num_hash_entries == 0)
		return 0;

	/* build hash and replication records for miss handling */
	dpdmux->hmap[DPDMUX_HMAP_MISS_IDX] = hmap_create(num_hash_entries,/*hmap_size*/
					(size_t)key_size);
	if (dpdmux->hmap[DPDMUX_HMAP_MISS_IDX] == NULL)
		return -ENOMEM;

	replic_cfg.num_elements = dpdmux->num_ifs;
	replic_cfg.dprc = dpdmux->hndl.dprc;

	for (i = 0; i < num_hash_entries; i++) {
		data = replic_create(&replic_cfg);
		CHECK_COND_RETVAL(data, -ENOMEM);

		err = hmap_set_data(dpdmux->hmap[DPDMUX_HMAP_MISS_IDX], i, data);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return err;
}

static int init_replicator_multicast(struct dpdmux *dpdmux)
{
	int err = 0, i;
	int key_size;
	hmap_data data;
	struct replic_cfg replic_cfg;
	int num_hash_entries = 0;

	key_size = get_key_size(dpdmux);
	CHECK_COND_RETVAL(key_size, -EINVAL);

	num_hash_entries = get_multicast_max_num(dpdmux);

	if (!num_hash_entries)
		return 0;

	/* multicast groups */
	dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX] = hmap_create(
		num_hash_entries,
		(size_t)key_size);
	if (dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX] == NULL)
		return -ENOMEM;

	replic_cfg.num_elements = dpdmux->num_ifs;
	replic_cfg.dprc = dpdmux->hndl.dprc;

	for (i = 0; i < num_hash_entries; i++) {
		data = replic_create(&replic_cfg);
		CHECK_COND_RETVAL(data, -ENOMEM);

		err = hmap_set_data(dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX], i, data);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return err;
}

static int init_hmap(struct dpdmux *dpdmux,
                     int num_hash_entries,
                     int key_size,
                     int index)
{
	int err = 0, i;
	struct dpdmux_hmap_data *data;

	dpdmux->hmap[index] = hmap_create(
		num_hash_entries,/*hmap_size*/
		(size_t)key_size);
	CHECK_COND_RETVAL(dpdmux->hmap[index], -ENOMEM);

	for (i = 0; i < num_hash_entries; i++) {
		data = (struct dpdmux_hmap_data *)fsl_malloc(sizeof(struct dpdmux_hmap_data));
		CHECK_COND_RETVAL(data, -ENOMEM);

		memset(data, 0, sizeof(struct dpdmux_hmap_data));
		data->owner = DPDMUX_OWNER_NONE;

		err = hmap_set_data(dpdmux->hmap[index], i, data);
		CHECK_COND_RETVAL(err == 0, err);
	}

	return err;
}

static int init_replicator(struct dpdmux *dpdmux)
{
	int err;

	err = init_replicator_multicast(dpdmux);
	CHECK_COND_RETVAL(err == 0, err);

	err = init_replicator_miss(dpdmux);
	CHECK_COND_RETVAL(err == 0, err);

	dpdmux->replicator.max_pri = DPDMUX_MAX_PRI;

	/* Replication Frame Queue */
	err = replicator_init_fq(dpdmux);
	CHECK_COND_RETVAL(err == 0, err);

	/* Replication Queue Priority */
	err = replicator_init_qpri(dpdmux, DPDMUX_MAX_PRI);
	CHECK_COND_RETVAL(err == 0, err);

	/* Replication Queue (QDID) */
	err = replicator_init_qdr(dpdmux, DPDMUX_MAX_PRI);

	return err;
}

static int handle_ifp_prune_table(struct dpdmux *dpdmux, int add)
{
	uint16_t i; /**< Interface iterator */
	int first_if = 0;

	/* check if prune table already exists */
	CHECK_COND_RETVAL(dpdmux->table[DPDMUX_PRUNE_TBL_IDX].handle, -EINVAL);
	
	for (i = (uint16_t)first_if; i < dpdmux->num_ifs; i++) {
		if (add)
			add_if_to_ifp_prune_table(dpdmux, i);
		else
			/* remove */
			remove_if_from_ifp_prune_table(dpdmux, i);
	}
	return 0;
}

static int handle_broadcast_address(struct dpdmux *dpdmux, int add)
{
	struct dpdmux_l2_rule l2_rule;
	uint16_t first_if = (uint16_t)DPDMUX_FIRST_VIRT_IF;
	uint16_t i;
	int err = 0;

	if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN)
		first_if = 0;

	/* add all the interfaces to a rule of broadcast with vlan = 0 */
	if ((dpdmux->method == DPDMUX_METHOD_MAC)
		|| (dpdmux->method == DPDMUX_METHOD_C_VLAN_MAC)) {

		memset(&(l2_rule.mac_addr[0]), 0xFF, DPDMUX_MAC_KEY_SIZE);
		memset(&(l2_rule.vlan_id), 0x0, DPDMUX_VLAN_KEY_SIZE);

		for (i = first_if; i < dpdmux->num_ifs; i++) {
			if (add)
				err = dpdmux_if_add_l2_rule(
					dpdmux, i, &l2_rule,
					DPDMUX_OWNER_INTERNAL);
			else
				err = dpdmux_if_remove_l2_rule(
					dpdmux, i, &l2_rule,
					DPDMUX_OWNER_INTERNAL);

		}
	}
	/* indication for cleaning the entry */
	dpdmux->added_broadcast_address = add;

	return err;
}

static int update_miss_table_entries(struct dpdmux *dpdmux,
	uint16_t if_id,
	enum dpdmux_owner owner,
	uint16_t vlan_id,
	int add)
{
	int err = 0;

	err = update_entry_in_miss_table(dpdmux, if_id, owner, vlan_id, 0/* unicast*/,
						add);
	CHECK_COND_RETVAL(err == 0, err);

	err = update_entry_in_miss_table(dpdmux, if_id, owner, vlan_id,
						1/* multicast*/, add);
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}

static int handle_ul_in_miss(struct dpdmux *dpdmux,
                             uint16_t vlan_id,
                             enum dpdmux_owner owner,
                             int add)
{
	int err = 0;

	if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN) {
		/* add/remove the uplink to/from the miss entry in the dmat */
		switch (dpdmux->method) {
		case (DPDMUX_METHOD_C_VLAN):
		case (DPDMUX_METHOD_CUSTOM):
			err = update_miss_entry_in_dmat(dpdmux,
							DPDMUX_UL_INDEX,
							owner,
							add);
			break;
		case (DPDMUX_METHOD_MAC):
		case (DPDMUX_METHOD_C_VLAN_MAC):
			err = update_miss_table_entries(dpdmux,
							DPDMUX_UL_INDEX,
							owner,
							vlan_id, add);
			break;
		case (DPDMUX_METHOD_S_VLAN):
		default:
			return -ENOTSUP;
		}
		CHECK_COND_RETVAL(err == 0, err);

	}
	/* indication for cleaning the entry */
	dpdmux->added_ul_in_miss = add;

	return err;
}

static int init_interfaces_and_resource_allocation(struct dpdmux *dpdmux)
{
	int err = 0;
	int ifp[DPDMUX_MAX_IF];
	uint16_t i;
	struct dpdmux_if *iface;
	char type[16];


	snprintf(type, sizeof(type), "ifp.wr%d", 0/* wriop_id*/);
	err = allocate_resource(
		dpdmux->hndl.dprc, 	/* Resource manager handle */
		type, 			/* Resource type */
		dpdmux->num_ifs, 	/* Number of resources*/
		1, 			/* Base align */
		0, 			/* Options */
		ifp, 			/* Address to store */
		"IFPID"); 		/* Error string */
	CHECK_COND_RETVAL(err == 0, err, "allocate IFP resources : %d\n", err);

	/* Interface */
	for (i = 0; i < dpdmux->num_ifs; i++) {
		/* Get interface */
		iface = &(dpdmux->iface[i]);

		/* set ifp per interface */
		iface->ap.ifpid = ifp[i];

		/* CEETM interface */
		err = init_ceetm_if(dpdmux, i);
		CHECK_COND_RETVAL(err == 0, err, "init_ceetm_if : %d\n", err);

		/* IFP Init */
		err = init_if_eiop_ifp(dpdmux, i);
		CHECK_COND_RETVAL(err == 0, err, "init_if_eiop_ifp : %d\n", err);

		/* QoS mapping */
		err = init_if_eiop_qos(dpdmux, i);
		CHECK_COND_RETVAL(err == 0, err, "init_if_eiop_qos : %d\n", err);
	}

	return err;
}


static int init_infrastructure(struct dpdmux *dpdmux)
{
	/*
	 *	BMan/Buffer Pool
	 *	QMan/CEETM
	 *	CTLU/FALU/VLAN/FDB
	 *	EIOP/MAC/IFP
	 *	replication
	 */
	int map_key_size;
	int err = 0;
#ifdef DPDMUX_DEBUG
	int prune_table_entries;
	int prune_key_size;
#endif

	err = init_bman_bp(dpdmux);
	CHECK_COND_RETVAL(err == 0, err, "swlib_init_bman_bp : %d\n", err);

	/* Error queue */
	err = init_err_fq(dpdmux);
	CHECK_COND_RETVAL(err == 0, err, "init_err_fq : %d\n", err);

	/* CTLU */
	err = init_ctlu(dpdmux);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu : %d\n", err);

	/* initialize the interfaces and allocate the following for all the
	 * interfaces:
	 * IFPs
	 * QDIDs
	 * QPRIs
	 */
	err = init_interfaces_and_resource_allocation(dpdmux);
	CHECK_COND_RETVAL(err == 0, err, "init_ctlu : %d\n", err);

	if (!(dpdmux->options & DPDMUX_OPT_REPLICATION_DIS)) {
		/* Replication */
		err = init_replicator(dpdmux);
		CHECK_COND_RETVAL(err == 0, err, "init_replicator : %d\n", err);
	}

	map_key_size = get_key_size(dpdmux);
	if( dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT ) {
		/* hmap key will store the key and the mask*/
		map_key_size = map_key_size * 2;
	}

	err = init_hmap(
		dpdmux,				/* dmux context */
	        dpdmux->max_dmat_entries,	/* number of unicast entries */
	        map_key_size,				/* hash key size */
	        DPDMUX_HMAP_UNICAST_IDX);	/* hash table index */
	CHECK_COND_RETVAL(err == 0, err, "init_hmap : %d\n", err);

#ifdef DPDMUX_DEBUG
	if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN) {
		prune_table_entries = dpdmux->num_ifs;
		prune_key_size = 2;/* IFP size */
	}
	else {
		/* allocate hmap_pruning for the prune table based on src mac as a key
		 * in the prune table in case of VEPA */
		prune_table_entries = dpdmux->max_dmat_entries;
		prune_key_size = 6;/* key_size is src MAC */
	}

	err = init_hmap(dpdmux,
	                prune_table_entries, /*num_hash_entries*/
	                prune_key_size,
			DPDMUX_HMAP_PRUNE_IDX/*index*/);
	CHECK_COND_RETVAL(err == 0, err, "init_hmap_prune : %d\n", err);
#endif
	/* allocate hmap_pruning for the prune table based on src mac as a key
	 * this prune table is relevant only in case of VEPA */
	if (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN)) {
		err = init_hmap(dpdmux,
				dpdmux->max_dmat_entries, /*num_hash_entries*/
				6, /* key_size is src MAC */
				DPDMUX_HMAP_PRUNE_IDX/*index*/);
		CHECK_COND_RETVAL(err == 0, err, "init_hmap_prune : %d\n", err);
	}
	if (!(dpdmux->options & DPDMUX_OPT_REPLICATION_DIS)) {

		/* prune table based on IFP is relevant only in case of VEB */
		if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN) {
			err = handle_ifp_prune_table(dpdmux, 1/* add */);
			CHECK_COND_RETVAL(err == 0, err);
		}
		err = handle_broadcast_address(dpdmux, 1/*add */);
		CHECK_COND_RETVAL(err == 0, err, "handle_broadcast_address failed : %d\n", err);

		if (dpdmux->method != DPDMUX_METHOD_C_VLAN_MAC)
			err = handle_ul_in_miss(dpdmux,
						0/* vlan_id */,
						DPDMUX_OWNER_INTERNAL,
						1/*add */);
		CHECK_COND_RETVAL(err == 0, err, "handle_ul_in_miss failed : %d\n", err);
	}

	return 0;
}

static int destroy_bman_bp(struct dpdmux *dpdmux)
{
	/*
	 * Release buffer pool
	 * free PEB memory
	 */
	int err;
	struct dpbp_hw_notification_cfg bp_notification_cfg;

	/* Configure depletion thresholds */
	memset(&bp_notification_cfg, 0, sizeof(bp_notification_cfg));

	if (dpdmux->dpbp != NULL) {
		/* delete the hysteresis window */
		bp_notification_cfg.depletion_entry = 0;
		bp_notification_cfg.depletion_exit = 0;
		err = dpbp_set_hw_notifications(dpdmux->dpbp, &bp_notification_cfg);
		CHECK_COND_RETVAL(err == 0, err, "ID[%d] - dpbp_set_hw_notifications() return error\n", dpdmux->id);

		/*! Deallocate buffres */
		dpbp_deallocate_buffers(dpdmux->dpbp, dpdmux->mem_size ?
									((uint32_t)dpdmux->mem_size * DPDMUX_BP_BUFFER_SIZE) :
									DPDMUX_BP_MEMORY_SIZE);

		/*! Destroy DPBP */
		dpbp_destroy(dpdmux->dpbp);
		/*! Dealocate DPBP) */
		fsl_free(dpdmux->dpbp);
		dpdmux->dpbp = NULL;
	}

	return 0;
}

static int destroy_deallocate_iface(struct dpdmux *dpdmux)
{
	int err = 0, i;
	struct dpdmux_if *iface;

	if(dpdmux->iface == NULL)
		return err;

	for (i = 0; i < dpdmux->num_ifs; i++) {
		iface = &(dpdmux->iface[i]);

		if (iface->ceetm_if != NULL)
			ceetm_if_destroy(iface->ceetm_if);

		if (iface->dpqos != NULL)
			dpqos_done(iface->dpqos);
	}

	/* deallocate Interface dataBase */
	if (dpdmux->iface != NULL)
		fsl_free(dpdmux->iface);

	return 0;
}

static int destroy_deallocate(struct dpdmux *dpdmux)
{
	/*
	 * -# free all memories having pointer different than zero
	 * */

	/*! Pool and PEB */
	destroy_bman_bp(dpdmux);

	/*! Intrface dataBase */
	destroy_deallocate_iface(dpdmux);

	return 0;
}

int dpdmux_if_enable(struct dpdmux *dpdmux, uint16_t id)
{
	int err = 0;
	struct dpdmux_if *iface;

	if (id >= dpdmux->num_ifs)
		return -EINVAL;

	/*! Obtain Interface */
	iface = &(dpdmux->iface[id]);

	/*! Enable Interface */
	iface->enable = 1;

	/*! trigger link manager state machine */
	err = link_event(dpdmux, LINKMAN_EVENT_LINKUP, id);
	if (err) {
		pr_warn("ID[%d]: link_event (UP) failed\n", dpdmux->id);
	}

	return 0;
}

int dpdmux_if_disable(struct dpdmux *dpdmux, uint16_t id)
{
	int err = 0;
	struct dpdmux_if *iface;
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr attr;
	enum linkman_event event;

	if (id >= dpdmux->num_ifs)
		return -EINVAL;

	iface = &(dpdmux->iface[id]);

	iface->enable = 0;

	memset(&endpoint1, 0x0, sizeof(struct linkman_endpoint));
	memset(&endpoint2, 0x0, sizeof(struct linkman_endpoint));
	memset(&attr, 0x0, sizeof(struct linkman_connection_attr));
	endpoint1.type = FSL_MOD_DPDMUX;
	endpoint1.id = (uint16_t)dpdmux->id;
	endpoint1.if_id = id;

	event = LINKMAN_EVENT_LINKDOWN;
	err = linkman_get_connection(dpdmux->hndl.linkman, &endpoint1, &endpoint2, &attr);
	if( !err && attr.state == LINKMAN_STATE_NEGOTIATION )
		event = LINKMAN_EVENT_NEGOTIATION_FAIL;
	else if( !err && attr.state==LINKMAN_STATE_IDLE )
		return 0;

	/*! Trigger link manager state machine */
	err = link_event(dpdmux, event, id);
	if (err) {
		pr_warn("ID[%d]: link_event (DOWN) failed when disabling interface %d\n", dpdmux->id, id);
	}

	return 0;
}

static int destroy_resources(struct dpdmux *dpdmux)
{
	/*
	 * deallocate all resources
	 * */

	if (dpdmux->hndl.dprc)
		resman_unbind_all(dpdmux->hndl.dprc);

	return 0;
}

static void destroy_keys_and_tables(struct dpdmux *dpdmux)
{
	/*! Remove miss KG */
	if (dpdmux->kg[DPDMUX_KG_MISS_IDX].inuse == 1) {
		dpkg_profile_delete(dpdmux->hndl.dpkg_ing,
					dpdmux->kg[DPDMUX_KG_MISS_IDX].id);
		dpdmux->kg[DPDMUX_KG_MISS_IDX].inuse = 0;
	}

	/* free miss table */
	if (dpdmux->table[DPDMUX_MISS_TBL_IDX].handle) {
		dptbl_delete(dpdmux->table[DPDMUX_MISS_TBL_IDX].handle);
		dpdmux->table[DPDMUX_MISS_TBL_IDX].handle = NULL;
	}

	/*! Remove DMAT KG */
	if (dpdmux->kg[DPDMUX_KG_DMAT_IDX].inuse == 1) {
		dpkg_profile_delete(dpdmux->hndl.dpkg_ing,
					dpdmux->kg[DPDMUX_KG_DMAT_IDX].id);
		dpdmux->kg[DPDMUX_KG_DMAT_IDX].inuse = 0;
	}

#ifdef TKT508412
	if( eiop_wriop_apply_TKT508412_fix() ) {
		if( dpdmux->fc_filtering_tbl.handle != NULL ) {
			dptbl_delete(dpdmux->fc_filtering_tbl.handle);
			dpdmux->fc_filtering_tbl.handle = NULL;
		}

		if( dpdmux->fc_filtering_kid.inuse ) {
			dpkg_profile_delete(dpdmux->hndl.dpkg_ing, dpdmux->fc_filtering_kid.id);
			dpdmux->fc_filtering_kid.inuse = 0;
		}
	}
#endif

	if (dpdmux->table[DPDMUX_PRUNE_TBL_IDX].handle) {
		dptbl_delete(dpdmux->table[DPDMUX_PRUNE_TBL_IDX].handle);
		dpdmux->table[DPDMUX_PRUNE_TBL_IDX].handle = NULL;
	}

	if (dpdmux->kg[DPDMUX_KG_PRUNE_IDX].inuse == 1) {
		dpkg_profile_delete(dpdmux->hndl.dpkg_ing,
			dpdmux->kg[DPDMUX_KG_PRUNE_IDX].id);
		dpdmux->kg[DPDMUX_KG_PRUNE_IDX].inuse = 0;
	}

	/* free DMAT */
	if (dpdmux->table[DPDMUX_DMAT_IDX].handle) {
		dptbl_delete(dpdmux->table[DPDMUX_DMAT_IDX].handle);
		dpdmux->table[DPDMUX_DMAT_IDX].handle = NULL;
	}

}

static void destroy_ctlu(struct dpdmux *dpdmux)
{
	int err = 0;

	/*! Remove Parser Profile */
	if (dpdmux->prp_ing.inuse == 1)
		dpparser_delete_profile(dpdmux->hndl.dpparser_ing,
					dpdmux->prp_ing.id, NULL);

	if (dpdmux->prp_egr.inuse == 1)
		dpparser_delete_profile(dpdmux->hndl.dpparser_egr,
					dpdmux->prp_egr.id, NULL);

	/*! Remove FALU entries (Admit all Policy) */
	if (dpdmux->policy[DPDMUX_POLICY_ALL].handle != NULL)
		dppolicy_done(dpdmux->policy[DPDMUX_POLICY_ALL].handle);

	/*! Remove FALU entries (Tag only Policy) */
	if (dpdmux->policy[DPDMUX_POLICY_TAG_ONLY].handle != NULL)
		dppolicy_done(dpdmux->policy[DPDMUX_POLICY_TAG_ONLY].handle);

	/*! Remove FALU entries (Un-Tag only Policy) */
	if (dpdmux->policy[DPDMUX_POLICY_UN_TAG_ONLY].handle != NULL)
		dppolicy_done(
			dpdmux->policy[DPDMUX_POLICY_UN_TAG_ONLY].handle);

	if (!(dpdmux->options & DPDMUX_OPT_REPLICATION_DIS)) {
		/* remove the uplink from the miss entry in the dmat or from the entries
		 * with vlan = 0 formt he miss table
		 */
		if (dpdmux->added_ul_in_miss) {
			err = handle_ul_in_miss(dpdmux,
						0/* vlan_id */,
						/*DPDMUX_OWNER_MANAGEMENT,*/DPDMUX_OWNER_INTERNAL,
						0 /*remove */);
			if (err != 0) {
				pr_err("handle_ul_in_miss failed : %d\n", err);
//				return err;
			}
		}
		/* remove broadcast address from the dmat table */
		if (dpdmux->added_broadcast_address) {
			err = handle_broadcast_address(dpdmux, 0 /*remove */);
			if (err != 0) {
				pr_err("handle_broadcast_address failed : %d\n", err);
//				return err;
			}
		}

		if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN) {
			err = handle_ifp_prune_table(dpdmux, 0/* remove */);
			CHECK_COND_RET(err == 0);
		}
	}
	destroy_keys_and_tables(dpdmux);
}

static int free_replicator_unicast(struct dpdmux *dpdmux)
{
	int i;
	hmap_data data;
	int err = 0;

	if (dpdmux->hmap[DPDMUX_HMAP_UNICAST_IDX]) {
		for( i=0 ; i<dpdmux->max_dmat_entries ; i++ ) {
			err = hmap_get_data(dpdmux->hmap[DPDMUX_HMAP_UNICAST_IDX], i, &data);
			CHECK_COND_RETVAL(err==0, err, "error\n");
			if( data )
				fsl_free(data);
		}
		hmap_destroy(dpdmux->hmap[DPDMUX_HMAP_UNICAST_IDX]);
		dpdmux->hmap[DPDMUX_HMAP_UNICAST_IDX] = NULL;
	}

	return err;
}

static int free_replicator_prune(struct dpdmux *dpdmux)
{
	int i;
	hmap_data data;
	int err = 0;

	if (dpdmux->hmap[DPDMUX_HMAP_PRUNE_IDX]) {
		for( i=0 ; i<dpdmux->max_dmat_entries ; i++ ) {
			err = hmap_get_data(dpdmux->hmap[DPDMUX_HMAP_PRUNE_IDX], i, &data);
			CHECK_COND_RETVAL(err==0, err, "error\n");
			if( data )
				fsl_free(data);
		}
		hmap_destroy(dpdmux->hmap[DPDMUX_HMAP_PRUNE_IDX]);
		dpdmux->hmap[DPDMUX_HMAP_PRUNE_IDX] = NULL;
	}

	return err;
}

static int free_replicator_multicast(struct dpdmux *dpdmux)
{
	int err = 0, i;
	hmap_data data;
	int num_hash_entries;

	if (dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX]) {
		num_hash_entries = get_multicast_max_num(dpdmux);
		for (i = 0; i < num_hash_entries; i++) {
			err = hmap_get_data(dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX], i, &data);
			CHECK_COND_RETVAL(err == 0, err);
			if (data)
				replic_destroy(data);
		}

		hmap_destroy(dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX]);
		dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX] = NULL;
	}

	return err;
}

static int free_replicator_miss(struct dpdmux *dpdmux)
{
	int err = 0, i;
	hmap_data data;
	int num_hash_entries = 0, key_size = 0;

	get_miss_info_by_method(dpdmux, &num_hash_entries, &key_size);


	if (dpdmux->hmap[DPDMUX_HMAP_MISS_IDX]) {
		for (i = 0; i < num_hash_entries; i++) {
			err = hmap_get_data(dpdmux->hmap[DPDMUX_HMAP_MISS_IDX], i, &data);
			CHECK_COND_RETVAL(err == 0, err);
			if(data)
				replic_destroy(data);
		}

		hmap_destroy(dpdmux->hmap[DPDMUX_HMAP_MISS_IDX]);
		dpdmux->hmap[DPDMUX_HMAP_MISS_IDX] = NULL;
	}

	return err;
}

static int destroy_disconnect(struct dpdmux *dpdmux)
{
	/*
	 * 	disable all interfaces
	 * 	disconnect all interfaces
	 */
	int err;
	uint16_t i;
	/*! disable all interfaces */
	err = dpdmux_disable(dpdmux);

	/*! disconnect all interfaces */
	for (i = 0; i < dpdmux->num_ifs; i++) {
		/*! trigger link manager state machine */
		link_event(dpdmux, LINKMAN_EVENT_DISCONNECT, i);
	}
	return err;
}

static int is_if_eiop_ifp_rx_enable(struct dpdmux *dpdmux, uint16_t id)
{
	int err;
	struct dpdmux_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;

	/*! Obtain Interface */
	iface = &(dpdmux->iface[id]);

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	return eiop_ifp_rx_is_enable(&eiop_ifp_desc);
}

static int event_completed_uplink(struct dpdmux *dpdmux,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	enum linkman_event event)
{
	int err = 0, i; /*! Operation not supported */
	struct linkman_endpoint ep1, ep2;
	struct linkman_control control;

	/* the routine is relevant only in case of VEPA
	 * in case of VEB - return from the function */
//	if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN)
//		return 0;

	/* the routine is relevant only in case there is a link
	 * between the dmux uplink and the mac
	 */
	if (peer->type != FSL_MOD_DPMAC)
		return 0;

	for (i = DPDMUX_FIRST_VIRT_IF; i < dpdmux->num_ifs; i++) {
		memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
		memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
		memset(&control, 0x0, sizeof(struct linkman_control));

		ep1.type = FSL_MOD_DPDMUX;
		ep1.id = (uint16_t)dpdmux->id;
		ep1.if_id = (uint16_t)i;

		control.event = event;
		err = linkman_set_connection(dpdmux->hndl.linkman, &control,
						&ep1, &ep2);

		/* don't check here return err - it's OK */
	}

	return err;
}

static int endpoint_integrity(struct dpdmux *dpdmux,
	struct linkman_endpoint *endpoint)
{
	if (endpoint->type != FSL_MOD_DPDMUX)
		return -EINVAL; /*! Invalid argument */
	if (endpoint->id != dpdmux->id)
		return -EINVAL; /*! Invalid argument */
	if (endpoint->if_id >= dpdmux->num_ifs)
		return -EINVAL; /*! Invalid argument */
	return 0;
}

static int link_event(struct dpdmux *dpdmux,
	enum linkman_event event,
	uint16_t if_id)
{
	int err;
	struct linkman_endpoint self;
	struct linkman_endpoint peer;
	struct linkman_control 	control;

	memset(&self, 0x0, sizeof(struct linkman_endpoint));
	memset(&peer, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));

	self.type = FSL_MOD_DPDMUX;
	self.id = (uint16_t)dpdmux->id;
	self.if_id = if_id;

	if( if_id==DPDMUX_UL_INDEX && dpdmux->dpmac!=NULL ) {
		switch( event ) {
		case LINKMAN_EVENT_LINKUP:
			control.cmd = LINKMAN_CMD_ENABLE;
			break;
		case LINKMAN_EVENT_LINKDOWN:
		case LINKMAN_EVENT_NEGOTIATION_FAIL:
			control.cmd = LINKMAN_CMD_DISABLE;
			break;
		}
	}

	control.event = event;
	err = linkman_set_connection(
		dpdmux->hndl.linkman, 	/* Context */
		&control, 		/* Event */
		&self, 			/* Self info */
		&peer); 		/* dummy param */

	return err;
}

#ifdef DPDMUX_DEBUG//debug only
static int dump_unicast_hmap(struct dpdmux *dpdmux,
                                           int table_id,
                                           int hmap_id)
{
	int err = 0;
	hmap_data data;
	enum dpdmux_owner owner;
	int iter_status, iter;
	uint8_t key[2*DPDMUX_VLAN_MAC_KEY_SIZE];

	/*! Remove management unicast rules from dmat */
	iter_status = hmap_get_start_iterator(dpdmux->hmap[hmap_id/*DPDMUX_HMAP_UNICAST_IDX*/], &iter);

	pr_info("dump_unicast_hmap:table_id %d hmap_id %d\n",table_id, hmap_id);
	while (iter_status == 0) {
		iter_status = hmap_iterate(dpdmux->hmap[hmap_id/*DPDMUX_HMAP_UNICAST_IDX*/], &iter, key,
						(hmap_data *)&data);

		owner = *((enum dpdmux_owner*)data);
		pr_info("\t key %x %x %x %x %x %x %x %x owner %x\n",key[0], key[1], key[2], key[3], key[4], key[5], key[6], key[7], owner);
		if (owner == DPDMUX_OWNER_MANAGEMENT)
		{
			err = remove_rule_from_table(dpdmux,
				key,
				NULL,
				get_key_size(dpdmux),
				hmap_id/*DPDMUX_HMAP_UNICAST_IDX*/,
				table_id/*DPDMUX_DMAT_IDX*/,
				DPDMUX_OWNER_MANAGEMENT,
				1/*remove_data*/);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}
	return err;
}

static int dump_multicast_hmap(struct dpdmux *dpdmux,
                                             int table_id,
                                             int hmap_id)
{
	int err = 0, i;
	hmap_data data;
	int iter_status, iter;
	uint8_t key[DPDMUX_VLAN_MAC_KEY_SIZE];
	int inuse, rrid;
	uint64_t opaque;
	int key_size = 0;

	/*! Remove management unicast rules from dmat */
	iter_status = hmap_get_start_iterator(dpdmux->hmap[hmap_id],
	                                      &iter);

	key_size = dpdmux->table[table_id].key_size;
	pr_info("dump_multicast_hmap:table_id %d hmap_id %d\n",table_id, hmap_id);
	while (iter_status == 0) {
		iter_status = hmap_iterate(dpdmux->hmap[hmap_id],
		                           &iter,
		                           key,
					   (hmap_data *)&data);

		pr_info("\t key %x %x %x %x %x %x %x %x \n",key[0], key[1], key[2], key[3], key[4], key[5], key[6], key[7]);
		for (i = 0; i < dpdmux->num_ifs; i++) {
			err = replic_get_element_by_id((struct replic *)data,
			                              i,
			                              &inuse,
			                              &rrid,
			                              &opaque);
			CHECK_COND_RETVAL(err == 0, err);
			pr_info("\t \t inuse %d rrid %d opaque %x %x\n",inuse, rrid, opaque, (opaque >> 32));
		}
	}
	return err;
}
#endif

static void dpdmux_dump(struct dpdmux *dpdmux)
{
	int i;
	struct dpdmux_if *iface;
	char *buf;
	uint32_t size = 8 * KILOBYTE;
	int count = 0;
	int rtn_fqid;
        struct ceetm_if_attr    ceetm_if_attr;

	rtn_fqid = dpmng_get_rtn_fqid(dpdmux->hndl.dpmng);

	buf = (char*)fsl_malloc(size);
	CHECK_COND_RET(buf);

	count += sprintf((char *)&buf[count], "\nDPDMUX 0x%x:\n", dpdmux->id);
	count += sprintf((char *)&buf[count], "\t options:\t %lx %lx\n", ((uint32_t)(dpdmux->options & 0x00000000FFFFFFFF)), (uint32_t)(dpdmux->options >>32));
	count += sprintf((char *)&buf[count], "\t max_dmat_entries:\t 0x%x \n", dpdmux->max_dmat_entries);
	count += sprintf((char *)&buf[count], "\t max_frame_length:\t 0x%x \n", dpdmux->max_frame_length);
	count += sprintf((char *)&buf[count], "\t default_if:\t 0x%x \n", dpdmux->default_if);
	count += sprintf((char *)&buf[count],
	                 "\t method : %s\n", dpdmux->method == DPDMUX_METHOD_NONE ? "DPDMUX_METHOD_NONE" : dpdmux->method == DPDMUX_METHOD_C_VLAN_MAC ? "DPDMUX_METHOD_C_VLAN_MAC" : dpdmux->method == DPDMUX_METHOD_MAC ? "DPDMUX_METHOD_MAC" : dpdmux->method == DPDMUX_METHOD_C_VLAN ? "DPDMUX_METHOD_C_VLAN" : dpdmux->method == DPDMUX_METHOD_S_VLAN ? "DPDMUX_METHOD_S_VLAN" : dpdmux->method == DPDMUX_METHOD_CUSTOM ? "DPDMUX_METHOD_CUSTOM" : "ERROR!");
	count += sprintf((char *)&buf[count], "\t manip :\t %s\n", dpdmux->manip == DPDMUX_MANIP_NONE ? "DPDMUX_MANIP_NONE" : dpdmux->manip == DPDMUX_MANIP_ADD_REMOVE_S_VLAN ? "DPDMUX_MANIP_ADD_REMOVE_S_VLAN" : "ERROR!");
	count += sprintf((char *)&buf[count], "\t ingress parser:\t 0x%xd\n", dpdmux->prp_ing.id);
	count += sprintf((char *)&buf[count], "\t egress parser:\t 0x%x\n", dpdmux->prp_egr.id);
	count += sprintf((char *)&buf[count], "\t qdid (replic):\t 0x%x\n", dpdmux->replicator.qdid);
	count += sprintf((char *)&buf[count], "\t qprid (replic):\t 0x%x\n", dpdmux->replicator.qprid);
	count += sprintf((char *)&buf[count], "\t fqid (replic):\t 0x%x\n", dpdmux->replicator.fqid);
	count += sprintf((char *)&buf[count], "\t rtn fqid (replic):\t 0x%x\n", rtn_fqid);
	//count += sprintf((char *)&buf[count], "cgid (replic): %d\n", dpdmux->replicator.cgid);
	//count += sprintf((char *)&buf[count], "max_pri (replic): %d\n", dpdmux->replicator.max_pri);
	count += sprintf((char *)&buf[count], "\t dmat id:\t 0x%x\n", dpdmux->table[DPDMUX_DMAT_IDX].id);
	count += sprintf((char *)&buf[count], "\t dmat kid:\t 0x%x\n", dpdmux->kg[DPDMUX_KG_DMAT_IDX].id);
	count += sprintf((char *)&buf[count], "\t miss table id:\t 0x%x\n", dpdmux->table[DPDMUX_MISS_TBL_IDX].id);
	count += sprintf((char *)&buf[count], "\t miss kid:\t 0x%x\n", dpdmux->kg[DPDMUX_KG_MISS_IDX].id);
	count += sprintf((char *)&buf[count], "\t prune tid:\t 0x%x\n", dpdmux->table[DPDMUX_PRUNE_TBL_IDX].id);
	count += sprintf((char *)&buf[count], "\t prune kid:\t 0x%x\n", dpdmux->kg[DPDMUX_KG_PRUNE_IDX].id);
	for (i = 0; i < dpdmux->num_ifs; i++) {
		iface = &(dpdmux->iface[i]);

	        /* obtain ceetm interface attributes */
	        ceetm_if_get_attributes(iface->ceetm_if, &ceetm_if_attr);

		count += sprintf((char *)&buf[count], "  Interface: %d\n", i);
		count += sprintf((char *)&buf[count], "\t ifpid:\t 0x%x\n", iface->ap.ifpid);
		count += sprintf((char *)&buf[count], "\t dcpid:\t 0x%x\n", iface->ap.dcp_id);
		count += sprintf((char *)&buf[count], "\t instance_id:\t 0x%x\n", iface->ap.ceetm_id);
		count += sprintf((char *)&buf[count], "\t dctidx[0]:\t 0x%x\n", iface->ap.dctidx[0]);
		count += sprintf((char *)&buf[count], "\t qdid:\t 0x%x\n", ceetm_if_attr.qdid);
		count += sprintf((char *)&buf[count], "\t qpri:\t 0x%x\n", ceetm_if_attr.qpri[0].id);
		count += sprintf((char *)&buf[count], "\t cqchid:\t 0x%x\n", iface->ap.cqchid);
		count += sprintf((char *)&buf[count], "\t lfqmtidx[0]:\t 0x%x\n", iface->ap.lfqmtidx[0]);
	}

	CHECK_COND_GOTO(count < size, clean_up);
	
	pr_info(buf);

#ifdef DPDMUX_DEBUG//debug only
	err = dump_unicast_hmap(dpdmux, DPDMUX_DMAT_IDX, DPDMUX_HMAP_UNICAST_IDX);
	err = dump_multicast_hmap(dpdmux, DPDMUX_DMAT_IDX, DPDMUX_HMAP_MULTICAST_IDX);
	err = dump_multicast_hmap(dpdmux, DPDMUX_MISS_TBL_IDX, DPDMUX_HMAP_MISS_IDX);
	err = dump_unicast_hmap(dpdmux, DPDMUX_PRUNE_TBL_IDX, DPDMUX_HMAP_PRUNE_IDX);
#endif
	
clean_up:
	fsl_free(buf);
}

/******************************************************************/
/* API */
/******************************************************************/

struct dpdmux *dpdmux_allocate()
{
	struct dpdmux *dpdmux = NULL;

	dpdmux = (struct dpdmux *)fsl_malloc(sizeof(struct dpdmux));

	if (dpdmux)
		memset(dpdmux, 0, sizeof(struct dpdmux));
	return dpdmux;
}

void dpdmux_deallocate(struct dpdmux *dpdmux)
{
	if (dpdmux != NULL)
		fsl_free(dpdmux);
}

int dpdmux_set_dev_ctx(struct dpdmux *dpdmux, const struct dpmng_dev_ctx *dev_ctx)
{
	return 0;
}

int dpdmux_init(struct dpdmux *dpdmux,
	const struct dpdmux_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg)
{
	int i, err;
	struct dpdmux_cfg dst_cfg;

	/* Verify parameters integrity */
	err = verify_params_integrity(cfg, &dst_cfg);
	if (err != 0) {
		pr_err("verify_params_integrity : %d\n", err);
		dpdmux_destroy(dpdmux);
		return err;
	}

	/* Allocate DMux Memory */
	err = init_allocate(dpdmux, &dst_cfg);
	if (err != 0) {
		pr_err("init_allocate : %d\n", err);
		dpdmux_destroy(dpdmux);
		return err;
	}

	/* Initialize data base */
	save_init_params(dpdmux, &dst_cfg, dev_cfg);

	/* Internal Dmux data structure(include handles) */
	init_internal_database(dpdmux, 1/*init_phase*/);

	err = init_infrastructure(dpdmux);
	if (err != 0) {
		pr_err("init_infrastructure : %d\n", err);
		dpdmux_destroy(dpdmux);
		return err;
	}

	/* Init default configuration */
	err = init_default(dpdmux);
	if (err != 0) {
		pr_err("init_default : %d\n", err);
		dpdmux_destroy(dpdmux);
		return err;
	}

	/* Set default interface */
	if ((dpdmux->method == DPDMUX_METHOD_CUSTOM) && (dpdmux->default_create_if > 0)) {
		err = dpdmux_set_default_if(dpdmux, dpdmux->default_create_if, 0);
		CHECK_COND_RETVAL(err == 0, err);
	}

	/* Enable DMux */
	err = dpdmux_enable(dpdmux);
	if (err != 0) {
		pr_err("dpdmux_enable : %d\n", err);
		dpdmux_destroy(dpdmux);
		return err;
	}

	/* Debugging */
	dpdmux_dump(dpdmux); /* DMUX database */

	dpmng_dump(dpdmux->hndl.dpmng); /* DPMNG database */

	for (i = 0; i < DPDMUX_MAX_IRQ_NUM; i++)
		mc_init_irq(&(dpdmux->irqs[i]), MC_IRQ_TYPE_MSI);

	/* Set the dpdmux resetable by default */
	dpdmux->skip_reset_flags = 0;

	return err;
}

void dpdmux_destroy(struct dpdmux *dpdmux)
{
	/*
	 -# disable all interfaces
	 -# Release all manually added ctlu entries
	 -# Release all ctlu tables
	 -# Release all Resource manager resources
	 -# unregister external modules
	 -# de-allocate memory
	 */

	/* Disable all interfaces */
	destroy_disconnect(dpdmux);

	/* Release all CTLU tables  */
	destroy_ctlu(dpdmux);

	free_replicator_unicast(dpdmux);

	free_replicator_prune(dpdmux);

	free_replicator_multicast(dpdmux);

	free_replicator_miss(dpdmux);

	/* unbind LDPAA resources */
	destroy_resources(dpdmux);

	/* free memory */
	destroy_deallocate(dpdmux);
}

static int search_key_in_hash(struct dpdmux *dpdmux,
	struct hmap *hmap,
	int hmap_offset,
	uint8_t *required_key,
	int required_key_size,
	int offset)
{
	int iter_status, iter;
	hmap_data data;
	uint8_t key[8] = { 0 };
	int found_key = -1;

	if (!hmap_offset)
		iter_status = hmap_get_start_iterator(hmap, &iter);
	else
		iter_status =
				(iter = hmap_next_iterator(hmap, hmap_offset)) < hmap->size ? 0 : -ENODEV;

	while (iter_status == 0) {
		iter_status = hmap_iterate(hmap, &iter, (hmap_key)key,
						(void**)&data);

		if (memcmp(required_key, &(key[offset]),
				(size_t)required_key_size)
			== 0) {
			found_key = iter;
			return found_key;
		}
	}
	return found_key;
}

static int copy_address_by_method(struct dpdmux *dpdmux,
	const struct dpdmux_l2_rule *l2_rule,
	uint8_t *addr,
	int *key_size)
{
	int err = 0;

	/* initialize the required address */
	memset(addr, 0, (DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE));
	switch (dpdmux->method) {
	case (DPDMUX_METHOD_C_VLAN_MAC):
		memcpy(addr, l2_rule->mac_addr, DPDMUX_MAC_KEY_SIZE);
		addr[DPDMUX_MAC_KEY_SIZE] = (uint8_t)((l2_rule->vlan_id
							& 0x0f00)
							>> 8);
		addr[DPDMUX_MAC_KEY_SIZE + 1] = (uint8_t)(l2_rule->vlan_id
								& 0x00ff);
		*key_size = (DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE);
		break;
	case (DPDMUX_METHOD_C_VLAN):
		addr[0] = (uint8_t)((l2_rule->vlan_id & 0x0f00) >> 8);
		addr[1] = (uint8_t)(l2_rule->vlan_id & 0x00ff);
		*key_size = DPDMUX_VLAN_KEY_SIZE;
		break;
	case (DPDMUX_METHOD_MAC):
		memcpy(addr, l2_rule->mac_addr, DPDMUX_MAC_KEY_SIZE);
		*key_size = DPDMUX_MAC_KEY_SIZE;
		break;
	default:
		return -EINVAL;
	}
	return err;
}

static int if_set_promisc(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t vlan_id,
	int unicast_promisc,
	int multicast_promisc,
	int en,
	enum dpdmux_owner owner)
{
	int err = 0;
	uint8_t miss_key[DPDMUX_MAX_MISS_KEY_SIZE];
	int num_entries = 0;
	uint32_t key_size = 0;

	switch (dpdmux->method) {
	case DPDMUX_METHOD_C_VLAN:
		memset(miss_key, 0,
			(sizeof(uint8_t) * DPDMUX_MAX_MISS_KEY_SIZE));

		get_miss_info_by_method(dpdmux, &num_entries, &key_size);

		/* unicast_promisc and multicast_promisc parameters are not
		 * relevant in case of vlan method */
		err = build_miss_key(dpdmux, vlan_id, 0, /* multicast */
					miss_key);
		CHECK_COND_RETVAL(err == 0, err);

		/* add this interface to the vlan table */
		if (en)
			err = add_rule_to_table(dpdmux, if_id, miss_key, NULL,
			                        key_size, 0,
			                        DPDMUX_HMAP_UNICAST_IDX,
						DPDMUX_DMAT_IDX,
						owner,
						0/* allow_modify */);
		else
			/* remove this interface from the vlan table */
			err = remove_rule_from_table(dpdmux, miss_key, NULL,
										DPDMUX_MAX_MISS_KEY_SIZE,
										DPDMUX_HMAP_UNICAST_IDX,
										DPDMUX_DMAT_IDX, owner,
										0/* remove_data*/);

		CHECK_COND_RETVAL(err == 0, err);

		break;
	case DPDMUX_METHOD_C_VLAN_MAC:
	case DPDMUX_METHOD_MAC:
		if (unicast_promisc) {
			err = update_entry_in_miss_table(
				dpdmux, if_id, owner, vlan_id, 0/*multicast*/,
				en/*add or remove*/);
			CHECK_COND_RETVAL(err == 0, err, "update_entry_in_miss_table(unicast promisc.) : %d\n", err);
		}

		if (multicast_promisc) {
			err = update_entry_in_miss_table(
				dpdmux, if_id, owner, vlan_id, 1/*multicast*/,
				en/*add or remove*/);
			CHECK_COND_RETVAL(err == 0, err, "update_entry_in_miss_table(multicast promisc.) : %d\n", err);
		}
		break;
	case DPDMUX_METHOD_NONE:
	case DPDMUX_METHOD_S_VLAN:
	default:
		return -ENOTSUP;
	}

	return 0;
}

static int handle_ul_def_promisc_in_miss_table(struct dpdmux *dpdmux,
              	const struct dpdmux_l2_rule *l2_rule,
              	enum dpdmux_owner owner,
              	int add)
{
	/*
	 * add this vlan to the miss table and populate with default
	 * and uplink port(in case of VEB) and with all the current
	 * unicast/multicast promis. interfaces
	 */
	uint16_t i = 0;
	struct dpdmux_if *iface;
	int err = 0;

	if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN) {

		/* add/remove uplink to/from the miss table */
		err = handle_ul_in_miss(dpdmux,
		                        l2_rule->vlan_id,
		                        owner,/*DPDMUX_OWNER_INTERNAL,*/
		                        add);
		CHECK_COND_RETVAL(err == 0, err, "handle_ul_in_miss failed : %d\n", err);
	}
	/*
	 * add/remove the new vlan to the miss table and populate with
	 * the default interface
	 */
	if (dpdmux->default_if) {
		err = update_miss_table_entries(dpdmux,
						dpdmux->default_if,
						owner,
						l2_rule->vlan_id,
						add);
		CHECK_COND_RETVAL(err == 0, err);
	}

	/* relevant only in remove !!
	 * remove all the unicast and multicast promisc. ports
	 * from the rule in the miss table
	 * */
	if (add == 0) {
		for (i = 0; i < dpdmux->num_ifs; i++) {
			iface = &(dpdmux->iface[i]);

			err = if_set_promisc(dpdmux,
					     i,
					     (l2_rule->vlan_id),
					     (int)(iface->unicast_promisc),/* unicast_promisc */
					     (int)(iface->multicast_promisc),/* multicast_promisc */
					     add,
					     owner);
			if (err != 0) {
				pr_err("if_set_promisc failed : %d\n", err);
				err = 0;
//				return err;
			}
		}
	}
	return err;
}

static int check_existence_rule_vlan(struct dpdmux *dpdmux,
		uint8_t addr[DPDMUX_VLAN_MAC_KEY_SIZE])
{
	int key_in_unicast = 0, key_in_multicast = 0;
	int hits_in_unicast = 0, hits_in_multicast = 0;

	do {
		key_in_unicast = search_key_in_hash(
				dpdmux, dpdmux->hmap[DPDMUX_HMAP_UNICAST_IDX],
				key_in_unicast,
				&(addr[DPDMUX_MAC_KEY_SIZE])/*vlan_id*/,
				DPDMUX_VLAN_KEY_SIZE/*key_size*/,
				DPDMUX_MAC_KEY_SIZE/*offset*/);
		if (key_in_unicast >= 0)
			hits_in_unicast++, key_in_unicast++;
	} while (key_in_unicast >= 0);

	do {
		key_in_multicast = search_key_in_hash(
			dpdmux, dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX],
			key_in_multicast,
			&(addr[DPDMUX_MAC_KEY_SIZE])/*vlan_id*/,
			DPDMUX_VLAN_KEY_SIZE/*key_size*/,
			DPDMUX_MAC_KEY_SIZE/*offset*/);
		if (key_in_multicast >= 0)
			hits_in_multicast++, key_in_multicast++;
	} while (key_in_multicast >= 0);

	return ((hits_in_unicast == 1) && (hits_in_multicast <= 1)) ||
			((hits_in_unicast == 0) && (hits_in_multicast <= 2)) ? 0 : 1;
}

static void handle_broadcast_rule(struct dpdmux *dpdmux,
	uint16_t if_id,
	int add,
	const struct dpdmux_l2_rule *l2_rule,
	enum dpdmux_owner owner)
{
	int err = 0;
	uint8_t addr[DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE];

	/* add broadcast address only in case of C_VLAN_MAC method */
	if (dpdmux->method != DPDMUX_METHOD_C_VLAN_MAC)
		return;

	memset(&addr, 0x00, DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE);
	memset(&addr, 0xFF, DPDMUX_MAC_KEY_SIZE);

	addr[DPDMUX_MAC_KEY_SIZE] = (uint8_t)((l2_rule->vlan_id
						& 0x0f00)
						>> 8);
	addr[DPDMUX_MAC_KEY_SIZE + 1] = (uint8_t)(l2_rule->vlan_id
							& 0x00ff);

	if (add) {
		/* add entry with broadcast address + the vlan id value */
		err = add_rule_with_replication_to_table(
			dpdmux, if_id, (uint8_t*)addr, dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX],
			owner,
			(DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE),/* key_size*/
			DPDMUX_DMAT_IDX, 0/* miss_entry */);
		if (err) {
			pr_debug(
				"add broadcast address (with vlan %d failed\n", l2_rule->vlan_id);
		}
	}
	else /* rmeove */
	{
		/* remove only if there is no other unicast/multicast rule with that VLAN */
		if (check_existence_rule_vlan(dpdmux, addr)) {
			pr_debug(
					"Due to existing rules with that VLAN,"
					"remove broadcast address (with vlan %d failed\n", l2_rule->vlan_id);
			return;
		}

		err = remove_rule_with_replication_from_table(
			dpdmux, if_id, (uint8_t*)addr, dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX],
			owner,
			(DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE),/* key_size*/
			DPDMUX_DMAT_IDX, 0/*miss entry */);
		if (err) {
			pr_debug(
				"remove broadcast address (with vlan %d failed\n", l2_rule->vlan_id);
		}
	}
	return;
}

static int handle_l2_rule(struct dpdmux *dpdmux,
	uint16_t if_id,
	int add,
	const struct dpdmux_l2_rule *l2_rule,
	const uint8_t *addr,
	uint32_t key_size,
	enum dpdmux_owner owner)
{
	int err = 0;

	if (add) {
		if ((l2_rule->mac_addr)
			&& (NH_ETH_IS_MULTICAST_ADDR(l2_rule->mac_addr)))
			err = add_rule_with_replication_to_table(
				dpdmux, if_id, (uint8_t*)addr, dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX],
				owner, key_size, DPDMUX_DMAT_IDX, 0/* miss_entry */);
		else
			err = add_rule_to_table(dpdmux, if_id, (uint8_t*)addr, NULL,
						key_size, 0,
						DPDMUX_HMAP_UNICAST_IDX, DPDMUX_DMAT_IDX,
						owner,
						0/* allow_modify*/);

		CHECK_COND_RETVAL(err == 0, err, "add rule to table failed : %d\n", err);
	}
	else /*remove */ {
		if ((l2_rule->mac_addr)
			&& (NH_ETH_IS_MULTICAST_ADDR(l2_rule->mac_addr)))
			err = remove_rule_with_replication_from_table(
				dpdmux, if_id, (uint8_t*)addr, dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX],
				owner, key_size, DPDMUX_DMAT_IDX, 0/*miss entry */);
		else
			err = remove_rule_from_table(dpdmux, (uint8_t*)addr, NULL, key_size,
							DPDMUX_HMAP_UNICAST_IDX,
							DPDMUX_DMAT_IDX, owner,
							0/* remove_data*/);

		if (err) {
			pr_debug(
			"remove rule from table failed (%d)\n", err);
			return err;
		}
	}
	return err;
}

int dpdmux_if_add_l2_rule(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_l2_rule *l2_rule,
	enum dpdmux_owner owner)
{
	int err;
	uint8_t addr[DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE];
	uint32_t key_size = 0;

	CHECK_COND_RETVAL(dpdmux, -EINVAL);
	CHECK_COND_RETVAL(dpdmux->table[DPDMUX_DMAT_IDX].handle, -EINVAL);

	/* Validations */
	if (if_id >= dpdmux->num_ifs) {
		pr_err("if_id:%d out of range\n", if_id);
		return -EINVAL;
	}

	/* check that the vlan value doesn't exceed 12 bits only in the relevant
	 * methods */
	if (((dpdmux->method == DPDMUX_METHOD_C_VLAN_MAC) ||
		(dpdmux->method == DPDMUX_METHOD_C_VLAN)) &&
		((l2_rule->vlan_id & 0xf000) != 0)) {
		pr_err("vlan %x exceed the allowed value\n", l2_rule->vlan_id);
		return -EINVAL;
	}

	memset(&addr, 0x00, DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE);
	/*
	 * In case of MAC_VLAN, add a broadcast address for the actual vlan id
	 * only when l2_rule mac address is unicast.
	 */
	if (!(NH_ETH_IS_BROADCAST_ADDR(l2_rule->mac_addr)))
		handle_broadcast_rule(dpdmux, if_id, 1/*add*/, l2_rule, owner);

	err = copy_address_by_method(dpdmux, l2_rule, addr, &key_size);
	CHECK_COND_RETVAL(err == 0, err);

	err = handle_l2_rule(dpdmux,
		if_id,
		1/*add*/,
		l2_rule,
		addr,
		key_size,
		owner);
	CHECK_COND_RETVAL(err == 0, err);

	/* in case of VEPA and it's not vlan method and not a multicast/broadcast
	 * address - add this address to the pruning table
	 */
	if ((dpdmux->method != DPDMUX_METHOD_C_VLAN)
		&& (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN)) &&
		! (NH_ETH_IS_MULTICAST_ADDR(l2_rule->mac_addr))) {
		err = add_rule_to_table(dpdmux, if_id, (uint8_t*)addr, NULL,
					DPDMUX_SRC_MAC_PRUNE_TBL_KEY_SIZE, 0,
					DPDMUX_HMAP_PRUNE_IDX,
					DPDMUX_PRUNE_TBL_IDX,
					owner,
					0/* allow_modify*/);

		CHECK_COND_RETVAL(err == 0, err, "add rule to prune table failed : %d\n", err);
	}

	/*
	 * add this vlan to the miss table and populate with
	 * default port
	 * uplink port(in case of VEB)
	 * all the current unicast/multicast promis. interfaces
	 */
	if (dpdmux->method == DPDMUX_METHOD_C_VLAN_MAC) {
		err = handle_ul_def_promisc_in_miss_table(dpdmux,
				l2_rule,
				owner,
				1/* add*/);
		if (err != 0 && err != -EEXIST) {
			pr_err("handle_ul_def_promisc_in_miss_table : %d\n", err);
			return err;
		}
	}

	return 0;
}

static int remove_duo_rule_from_miss_table(struct dpdmux *dpdmux,
	const struct dpdmux_l2_rule *l2_rule,
	enum dpdmux_owner owner)
{
	int err = 0;
	uint8_t addr[DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE];
	int key_in_unicast = 0, key_in_multicast = 0;

	/* decide if to remove the vlan from the miss table
	 * if the vlan doesn't exist in the dmat(check in the hmap_unicast and
	 * hmap_multicast) then I remove this vlan from the miss table  */
	memcpy(&addr, l2_rule->mac_addr, DPDMUX_MAC_KEY_SIZE);
	addr[DPDMUX_MAC_KEY_SIZE] = (uint8_t)((l2_rule->vlan_id
						& 0x0f00)
						>> 8);
	addr[DPDMUX_MAC_KEY_SIZE + 1] = (uint8_t)(l2_rule->vlan_id
							& 0x00ff);

	key_in_unicast = search_key_in_hash(
			dpdmux, dpdmux->hmap[DPDMUX_HMAP_UNICAST_IDX],
			0,/* from the start of hmap */
			&(addr[DPDMUX_MAC_KEY_SIZE])/*vlan_id*/,
			DPDMUX_VLAN_KEY_SIZE/*key_size*/,
			DPDMUX_MAC_KEY_SIZE/*offset*/);

	key_in_multicast = search_key_in_hash(
		dpdmux, dpdmux->hmap[DPDMUX_HMAP_MULTICAST_IDX],
		0,/* from the start of hmap */
		&(addr[DPDMUX_MAC_KEY_SIZE])/*vlan_id*/,
		DPDMUX_VLAN_KEY_SIZE/*key_size*/,
		DPDMUX_MAC_KEY_SIZE/*offset*/);

	if ((key_in_unicast == -1) && (key_in_multicast == -1)) {
		/*
		 * remove the following ports from the specific entry
		 * default port
		 * uplink port(in case of VEB)
		 * all the current unicast/multicast promis. interfaces
		 * consequently the unicasr and multicast rule in the miss table
		 * will be removed from the miss table
		 * */
		err = handle_ul_def_promisc_in_miss_table(dpdmux,
		              	l2_rule,
		              	owner,
		              	0/* add*/);
		CHECK_COND_RETVAL(err == 0, err, "handle_ul_def_promisc_in_miss_table : %d\n", err);
	}
	return err;
}

int dpdmux_if_remove_l2_rule(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_l2_rule *l2_rule,
	enum dpdmux_owner owner)
{
	int err;
	uint8_t addr[DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE];
	uint32_t key_size = 0;

	CHECK_COND_RETVAL(dpdmux, -EINVAL);
	CHECK_COND_RETVAL(dpdmux->table[DPDMUX_DMAT_IDX].handle, -EINVAL);

        if (if_id >= dpdmux->num_ifs) {
                pr_err("if_id:%d out of range\n", if_id);
                return -EINVAL;
        }

	/* check that the vlan value doesn't exceed 12 bits only in the relevant
	 * methods */
	if (((dpdmux->method == DPDMUX_METHOD_C_VLAN_MAC) ||
		(dpdmux->method == DPDMUX_METHOD_C_VLAN)) &&
		((l2_rule->vlan_id & 0xf000) != 0)) {
		pr_err("vlan %x exceed the allowed value\n", l2_rule->vlan_id);
		return -EINVAL;
	}

	memset(&addr, 0x00, DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE);

	/*
	 * In case of MAC_VLAN, remove the broadcast address for the actual vlan id
	 * only when l2_rule mac address is not a broadcast address.
	 */
	if (!(NH_ETH_IS_BROADCAST_ADDR(l2_rule->mac_addr)))
		handle_broadcast_rule(dpdmux, if_id, 0/*remove*/, l2_rule, owner);

	err = copy_address_by_method(dpdmux, l2_rule, addr, &key_size);
	CHECK_COND_RETVAL(err == 0, err);

	err = handle_l2_rule(dpdmux,
		if_id,
		0/*remove*/,
		l2_rule,
		addr,
		key_size,
		owner);
	CHECK_COND_RETVAL(err == 0, err);

	/* in case of VEPA and it's not vlan method - remove this address
	 * from the pruning table
	 */
	if ((dpdmux->method != DPDMUX_METHOD_C_VLAN)
		&& (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN)) &&
			! (NH_ETH_IS_MULTICAST_ADDR(l2_rule->mac_addr))) {
		err = remove_rule_from_table(dpdmux, (uint8_t*)addr, NULL,
					DPDMUX_SRC_MAC_PRUNE_TBL_KEY_SIZE,
					DPDMUX_HMAP_PRUNE_IDX,
					DPDMUX_PRUNE_TBL_IDX,
					owner,
					0/* allow_modify*/);

		CHECK_COND_RETVAL(err == 0, err, "add rule to prune table failed : %d\n", err);
	}
	/* check if there is a need to clean the couple of rules
	 * (unicast and multicast) from the miss table
	 */
	if (dpdmux->method == DPDMUX_METHOD_C_VLAN_MAC) {
		err = remove_duo_rule_from_miss_table(dpdmux,
		                                l2_rule, owner);
		if (err) {
			pr_debug(
			"remove_duo_rule_from_miss_table failed (%d)\n", err);
//			err = 0;
		}
	}

	return 0;
}

int dpdmux_if_set_unicast_promisc(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t vlan_id,
	int en)
{
	int err = 0;
	enum dpdmux_owner owner = DPDMUX_OWNER_NIC;
	struct dpdmux_if *iface;

	/* in case of remove  - there is a need to check that I don't
	 * remove the default port
	 */
	if ((en == 0) && (if_id == dpdmux->default_if))
		return err;

	err = if_set_promisc(dpdmux, if_id, vlan_id, 1,/* unicast_promisc */
				0,/* multicast_promisc */
				en, owner);

	iface = &(dpdmux->iface[if_id]);

	iface->unicast_promisc = en;

	return err;
}

int dpdmux_if_set_multicast_promisc(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t vlan_id,
	int en)
{
	int err = 0;
	enum dpdmux_owner owner = DPDMUX_OWNER_NIC;
	struct dpdmux_if *iface;

	/* in case of remove  - there is a need to check that I don't
	 * remove the default port
	 */
	if ((en == 0) && (if_id == dpdmux->default_if))
		return err;

	err = if_set_promisc(dpdmux, if_id, vlan_id, 0,/* unicast_promisc */
				1,/* multicast_promisc */
				en, owner);

	iface = &(dpdmux->iface[if_id]);

	iface->multicast_promisc = en;

	return err;
}

#if 0 /* for code coverage */
int dpdmux_if_set_transmit_rate(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_transmit_rate *cfg)
{
	ASSERT_COND(dpdmux);
	UNUSED(dpdmux);
	UNUSED(if_id);
	UNUSED(cfg);

	return 0;
}
#endif /* for code coverage */
int dpdmux_get_attributes(struct dpdmux *dpdmux, struct dpdmux_attr *attr)
{
#ifdef DPDMUX_DEBUG//debug only
	int err;
#endif /* DPDMUX_DEBUG */

	attr->id = dpdmux->id;
	attr->options = dpdmux->options;
	attr->method = dpdmux->method;
	attr->manip = dpdmux->manip;
	/* mem_size field was updated (multiplied by 256) when resources were allocated */
	attr->mem_size = (uint16_t) (dpdmux->mem_size ? dpdmux->mem_size : (DPDMUX_BP_MEMORY_SIZE/DPDMUX_BP_BUFFER_SIZE));
	attr->num_ifs = dpdmux->num_ifs - 1;
	/* return num_ifs without the uplink - only the virtual interfaces */
	attr->default_if = dpdmux->default_if;
	/* return default_if which represents the actual default interface
	 * It can be different from default_create_if if it was changed after create
	 */
	attr->max_dmat_entries = dpdmux->max_dmat_entries;
	attr->max_mc_groups = dpdmux->max_mc_groups;
	attr->max_vlan_ids = dpdmux->max_vlan_ids;

#ifdef DPDMUX_DEBUG//debug only
	err = dump_unicast_hmap(dpdmux, DPDMUX_DMAT_IDX, DPDMUX_HMAP_UNICAST_IDX);
	err = dump_multicast_hmap(dpdmux, DPDMUX_DMAT_IDX, DPDMUX_HMAP_MULTICAST_IDX);
	err = dump_multicast_hmap(dpdmux, DPDMUX_MISS_TBL_IDX, DPDMUX_HMAP_MISS_IDX);
	err = dump_unicast_hmap(dpdmux, DPDMUX_PRUNE_TBL_IDX, DPDMUX_HMAP_PRUNE_IDX);
#endif /* DPDMUX_DEBUG */
	return 0;
}

int dpdmux_enable(struct dpdmux *dpdmux)
{
	int err = 0;
	uint16_t i;

	/* Enable all interfaces */
	for (i = 0; i < dpdmux->num_ifs; i++) {
		err = dpdmux_if_enable(dpdmux, i);
		if (err != 0)
			break;
	}
	return err;
}

int dpdmux_disable(struct dpdmux *dpdmux)
{
	int err = 0;
	uint16_t i;

	/* Disable all interfaces */
	for (i = 0; i < dpdmux->num_ifs; i++) {
		err = dpdmux_if_disable(dpdmux, i);
		if (err != 0)
			break;
	}
	return err;
}

static int remove_unicast_rules(struct dpdmux *dpdmux,
                                int table_id,
                                int hmap_id,
                                enum dpdmux_owner owner)
{
	int err = 0;
	hmap_data data;
	enum dpdmux_owner stored_owner;
	int priority = 0;
	int iter_status, iter;
	uint8_t key[2*DPDMUX_CUSTOM_KEY_SIZE];
	uint32_t key_size;
	uint8_t *mask_ptr = NULL;

	/*! Remove management unicast rules from dmat */
	iter_status = hmap_get_start_iterator(dpdmux->hmap[hmap_id/*DPDMUX_HMAP_UNICAST_IDX*/], &iter);

	while (iter_status == 0) {
		iter_status = hmap_iterate(dpdmux->hmap[hmap_id/*DPDMUX_HMAP_UNICAST_IDX*/], &iter, key,
						(hmap_data *)&data);

		stored_owner = ((struct dpdmux_hmap_data *)data)->owner;
		if( dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT ) {
			priority = ((struct dpdmux_hmap_data *)data)->priority;
			mask_ptr = ((struct dpdmux_hmap_data *)data)->mask;
		}
		if (stored_owner == owner)
		{
			/* if method is MAC_VLAN and remove is made on prunning table then
			 * key size is 6 (see dpdmux_if_add_l2_rule) */
			if ((dpdmux->method == DPDMUX_METHOD_C_VLAN_MAC) &&
					(table_id == DPDMUX_PRUNE_TBL_IDX))
				key_size = DPDMUX_SRC_MAC_PRUNE_TBL_KEY_SIZE;
			else
				key_size = (uint32_t)get_key_size(dpdmux);

			err = remove_rule_from_table(dpdmux,
				key,
				mask_ptr,
				key_size,
				hmap_id/*DPDMUX_HMAP_UNICAST_IDX*/,
				table_id/*DPDMUX_DMAT_IDX*/,
				owner,
				1/*remove_data*/);
			CHECK_COND_RETVAL(err == 0, err, "remove_rule_from_table()\n");
		}
	}
	return err;
}

static int remove_multicast_management_rules(struct dpdmux *dpdmux,
                                             int table_id,
                                             int hmap_id)
{
	int err = 0, i;
	hmap_data data;
	int iter_status, iter;
	uint8_t key[DPDMUX_VLAN_MAC_KEY_SIZE];
	uint64_t opaque;
	uint32_t key_size = 0;

	err = multicast_management_rules_params_integrity(
		dpdmux,
	        table_id,
	        hmap_id);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Remove management unicast rules from dmat */
	iter_status = hmap_get_start_iterator(dpdmux->hmap[hmap_id],
	                                      &iter);

	key_size = dpdmux->table[table_id].key_size;

	while (iter_status == 0) {
		iter_status = hmap_iterate(dpdmux->hmap[hmap_id],
		                           &iter,
		                           key,
					   (hmap_data *)&data);

		for (i = 0; i < dpdmux->num_ifs; i++) {
			err = replic_get_element_opaque((struct replic *)data,
			                              i,
			                              &opaque);
			if (opaque == (uint64_t)DPDMUX_OWNER_MANAGEMENT) {
				err = remove_rule_with_replication_from_table(
					dpdmux,
					(uint16_t)i/*if_id*/,
					key,
					dpdmux->hmap[hmap_id/*DPDMUX_HMAP_MULTICAST_IDX*/],
					DPDMUX_OWNER_MANAGEMENT,
					key_size,
					table_id,
					0/* miss_entry*/);
				CHECK_COND_RETVAL(err == 0, err);
			}
		}
	}
	return err;
}

static int multicast_management_rules_params_integrity(
	struct dpdmux *dpdmux,
        int table_id,
        int hmap_id)
{
	int err = 0;

	CHECK_COND_RETVAL(dpdmux, -EINVAL);

	CHECK_COND_RETVAL(dpdmux->hmap[hmap_id], -ENAVAIL);
	
	CHECK_COND_RETVAL(dpdmux->table[table_id].handle, -ENAVAIL);

	return err;
}

int dpdmux_clean_flow_control_config(struct dpdmux *dpdmux, int if_id)
{
	struct dpdmux_if	*iface;
	uint32_t	pfc_flags;
	int err = 0;

	iface = &(dpdmux->iface[if_id]);
	if( iface->fc_idx == FLOW_CONTROL_INVALID_INDEX )
		return 0;

	pfc_flags = DPDMUX_UPDATE_FC;
	
	err = dpdmux_if_update_bp_config(dpdmux, if_id, pfc_flags);
	CHECK_COND_RETVAL( err==0, err, "DPDMUX.%d[%d]: dpdmux_if_update_bp_config() call failed\n", dpdmux->id, if_id);
	
	dpdmux_if_update_channel_fc(dpdmux, if_id, pfc_flags);

	iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;

	return 0;
}

static int dpdmux_reset_flow_control(struct dpdmux *dpdmux, int if_id)
{
	struct linkman_endpoint endpoint1;
	struct linkman_endpoint endpoint2;
	struct linkman_connection_attr link_attr;
	struct dpdmux_if *iface;
	void *object;
	int err;

	iface = &(dpdmux->iface[if_id]);
	if( iface->fc_idx == FLOW_CONTROL_INVALID_INDEX ) {
		return 0;
	}

	memset(&endpoint1, 0, sizeof(endpoint1));
	memset(&endpoint2, 0, sizeof(endpoint2));
	memset(&link_attr, 0, sizeof(link_attr));

	endpoint1.type = FSL_MOD_DPDMUX;
	endpoint1.id = (uint16_t)dpdmux->id;
	endpoint1.if_id = (uint16_t)if_id;
	err = linkman_get_connection(dpdmux->hndl.linkman, &endpoint1, &endpoint2, &link_attr);
	CHECK_COND_RETVAL(err==0, err, "Could not get connected object to dpdmux.%d [%d]\n", dpdmux->id, if_id);

	object = sys_get_handle(endpoint2.type, 1, endpoint2.id);
	CHECK_COND_RETVAL(object, -ENODEV, " Could not get connected object\n");

	switch( endpoint2.type ) {
	case FSL_MOD_DPNI:
		err = dpni_clean_flow_control_config((struct dpni *)object);
		CHECK_COND_RETVAL(err==0, err, "dpni_clean_flow_control_config() return error\n");
		break;
	default:
		pr_err("ID[%d] - invalid flow control configuration on interface %d, continue\n", if_id);
		break;
	}

	fc_release_channel_idx(iface->fc_idx);
	err = dpdmux_clean_flow_control_config(dpdmux, if_id);
	CHECK_COND_RETVAL(err==0, err, "dpdmux_clean_flow_control_config() return error\n");

	return 0;
}

static int dpdmux_update_uplink_max_frame_len(struct dpdmux *dpdmux)
{
	struct dpdmux_if *iface;
	struct linkman_endpoint ep;
	struct linkman_connection_attr connection_attr;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct dpni *dpni;
	uint16_t max_frame_length, tmp_frame_len;
	uint16_t i;
	int err;

	/* update only if the flag is set */
	if( !(dpdmux->options & DPDMUX_OPT_AUTO_MAX_FRAME_LEN) )
		return 0;

	max_frame_length = 0;
	for (i = 0; i < dpdmux->num_ifs; i++) {
		memset(&ep, 0, sizeof(ep));
		get_connection(dpdmux, i, &ep, &connection_attr);

		if( ep.type == FSL_MOD_DPNI ) {
			dpni = (struct dpni *)sys_get_handle(FSL_MOD_DPNI, 1, ep.id);
			dpni_get_max_frame_length(dpni, &tmp_frame_len);
			if( tmp_frame_len > max_frame_length )
				max_frame_length = tmp_frame_len;
		}
	}

	if( max_frame_length == 0 ) {
		max_frame_length = DPDMUX_MAX_FRAME_LENGTH;
	}

	iface = &(dpdmux->iface[DPDMUX_UL_INDEX]);

	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id;
	err = sys_get_desc(SOC_MODULE_EIOP_IFP,
					SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID,
					&eiop_ifp_desc,	NULL);
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	err = eiop_ifp_set_max_frame_length(&eiop_ifp_desc, max_frame_length);
	CHECK_COND_RETVAL(err == 0, err);

	iface->mfl = max_frame_length;

	return 0;
}

int dpdmux_reset(struct dpdmux *dpdmux)
{
	int err = 0;
	uint16_t if_id = 0;

	CHECK_COND_RETVAL(dpdmux, -EINVAL);

	UNUSED(dpdmux);

	/*! Disable all interfaces */
	err = dpdmux_disable(dpdmux);
	CHECK_COND_RETVAL(err == 0, err);

	/*! Clear all IFP counters */
	for (if_id = 0; if_id < dpdmux->num_ifs; if_id++) {
		err = clear_ifp_counters(dpdmux, if_id, 1/*reset */);
		CHECK_COND_RETVAL(err == 0, err);

		/* reset the Flow Control on interface and peer */
		err = dpdmux_reset_flow_control(dpdmux, if_id);
		CHECK_COND_RETVAL(err==0, err, "dpdmux_reset_flow_control() return error\n");

		/* restore IFP defaults */
		err = init_if_eiop_ifp(dpdmux, if_id);
		CHECK_COND_RETVAL(err == 0, err, "init_if_eiop_ifp : %d\n", err);
	}
	/* set no_default_if if dpdmux->default_if is 0, the function will do nothing
	 * set the same default interface as the last one set if dpdmux->default_if is different from 0
	 */
	if(!(dpdmux->skip_reset_flags & DPDMUX_SKIP_DEFAULT_INTERFACE))
		if (dpdmux->method == DPDMUX_METHOD_CUSTOM) {
			err = dpdmux_set_default_if(dpdmux, dpdmux->default_create_if, (dpdmux->default_create_if > 0) ? 0 : 1 );
			CHECK_COND_RETVAL(err == 0, err);
		}

	if(!(dpdmux->skip_reset_flags & DPDMUX_SKIP_UNICAST_RULES))
	{
		/* remove management unicast rules from the dmat */
		err = remove_unicast_rules(dpdmux, DPDMUX_DMAT_IDX,
				DPDMUX_HMAP_UNICAST_IDX, DPDMUX_OWNER_MANAGEMENT);
		CHECK_COND_RETVAL(err == 0, err);

		/* remove management unicast rules from the prune table in case of VEPA */
		if (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN)) {
			err = remove_unicast_rules(dpdmux, DPDMUX_PRUNE_TBL_IDX,
					DPDMUX_HMAP_PRUNE_IDX, DPDMUX_OWNER_MANAGEMENT);
			CHECK_COND_RETVAL(err == 0, err);
		}
	}

	if(!(dpdmux->skip_reset_flags & DPDMUX_SKIP_MULTICAST_RULES))
	{
		/* remove management multicast rules from the dmat */
		err = remove_multicast_management_rules(dpdmux, DPDMUX_DMAT_IDX, DPDMUX_HMAP_MULTICAST_IDX);
		if ((err != 0) && (err != -ENAVAIL))
			return err;

		/* remove management multicast rules from the miss table */
		err = remove_multicast_management_rules(dpdmux, DPDMUX_MISS_TBL_IDX, DPDMUX_HMAP_MISS_IDX);
		if ((err != 0) && (err != -ENAVAIL))
			return err;
	}
	/* set defaults */
	init_internal_database(dpdmux, 0/* NOT init_phase */);

	err = dpdmux_update_uplink_max_frame_len(dpdmux);
	if( err ) pr_warn("dpdmux_update_uplink_max_frame_len return error\n");

	/* enable all interfaces */
	err = dpdmux_enable(dpdmux);

	return err;
}

#if 0 /* for code coverage */
int dpdmux_set_scheduling(struct dpdmux *dpdmux,
	const struct dpdmux_rate_cfg *cfg)
{

	ASSERT_COND(dpdmux);
	UNUSED(dpdmux);
	UNUSED(cfg);
	return 0;
}
#endif /* for code coverage */

#if 0
int dpdmux_register_ctrl_protocol(struct dpdmux *dpdmux,
	struct dpdmux_ctrl_protocol *cfg)
{
	ASSERT_COND(dpdmux);
	UNUSED(dpdmux);
	UNUSED(cfg);
	return 0;
}

int dpdmux_unregister_ctrl_protocol(struct dpdmux *dpdmux,
	struct dpdmux_ctrl_protocol *cfg)
{
	ASSERT_COND(dpdmux);
	UNUSED(dpdmux);
	UNUSED(cfg);
	return 0;
}
#endif


int dpdmux_if_get_counter(struct dpdmux *dpdmux,
	uint16_t if_id,
	enum dpdmux_counter_type counter_type,
	uint64_t *counter)
{
	int err = 0;
	struct dpdmux_if *iface;


        if (if_id >= dpdmux->num_ifs) {
                pr_err("if_id:%d out of range\n", if_id);
                return -EINVAL;
        }

	iface = &(dpdmux->iface[if_id]);
	CHECK_COND_RETVAL(dpdmux, -EINVAL);

	err = get_appropriate_counter(dpdmux,
	                           	if_id,
	                           	counter_type,
	                           	counter);
	CHECK_COND_RETVAL(err == 0, err);

	*counter = (*counter - iface->counters[counter_type]);

	return err;
}

int dpdmux_ul_reset_counters(struct dpdmux *dpdmux)
{
	int err, i;

	CHECK_COND_RETVAL(dpdmux, -EINVAL);

	if (dpdmux->dpmac == NULL) {
		pr_debug("dpmac is not connected to the dmux\n");
		return -ENAVAIL;
	}

	/* if uplink is physical need to reset the mac counters */
	if (dpdmux->method != DPDMUX_METHOD_S_VLAN) {
		/*! reset DPMAC counters */
		err = dpmac_reset_counters(dpdmux->dpmac);
		CHECK_COND_RETVAL(err == 0, err);
	}
	else /* S-Vlan support - need to reset the ifp counters */
	{
		err = if_set_counter(dpdmux,
		               DPDMUX_UL_INDEX,
		               DPDMUX_CNT_EGR_FRAME,
		               0);
		CHECK_COND_RETVAL(err == 0, err);

		err = if_set_counter(dpdmux,
		               DPDMUX_UL_INDEX,
		               DPDMUX_CNT_EGR_BYTE,
		               0);
		CHECK_COND_RETVAL(err == 0, err);

		err = if_set_counter(dpdmux,
		               DPDMUX_UL_INDEX,
		               DPDMUX_CNT_EGR_FRAME_DISCARD,
		               0);
		CHECK_COND_RETVAL(err == 0, err);

	}
	err = clear_ifp_counters(dpdmux, DPDMUX_UL_INDEX, 0/* no reset */);
	CHECK_COND_RETVAL(err == 0, err);
	/* set to 0 the internal counter to reflect the
	 * reset of mac/interface 0 counters  */
	for (i = DPDMUX_CNT_ING_FRAME; i < DPDMUX_MAX_CNT; i++ ) {
		if_handle_internal_counter(dpdmux, DPDMUX_UL_INDEX,
			  (enum dpdmux_counter_type)i,
			  0,/*counter value */
			  DPDMUX_CNT_OPERATION_SET/* operation */);
	}

	return 0;
}

/**
 * Update the maximum frame length on all dmux interfaces.
 */
int dpdmux_set_max_frame_length(struct dpdmux *dpdmux,
	const uint16_t max_frame_length)
{
	int err;
	uint16_t i, mfl = max_frame_length;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct dpdmux_if *iface;

	CHECK_COND_RETVAL(dpdmux, -EINVAL);

	/* update only if the flag is set */
	if( !(dpdmux->options & DPDMUX_OPT_AUTO_MAX_FRAME_LEN) ) {
		pr_warn("dpdmux.%d dpdmux_set_max_frame_length(): "
				"flag DPDMUX_OPT_AUTO_MAX_FRAME_LEN is set, the max frame length value will be overwritten",
				dpdmux->id);
	}

	/* In case of VEPA, the maximum frame length on all dmux interfaces
	 * will be updated with the minimum value of the mfls of the connected
	 * dpnis and the actual value of dmux mfl.
	*/
	if (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN))
	{
		for (i = 0; i < dpdmux->num_ifs; i++) {
			struct linkman_connection_attr attr;
			struct linkman_endpoint ep;
			struct dpni *ni;

			get_connection(dpdmux, i, &ep, &attr);
			if (ep.type == FSL_MOD_DPNI)
			{
				uint16_t tmp_mfl;

				ni = (struct dpni *)sys_get_handle(FSL_MOD_DPNI, 1, ep.id);
				dpni_get_max_frame_length(ni, &tmp_mfl);
				if (tmp_mfl < mfl)
					mfl = tmp_mfl;
			}
		}
	}

	if (dpdmux->dpmac == NULL) {
		pr_debug("dpmac is not connected to the dmux\n");
		return -ENAVAIL;
	}

	/*! Go over all interfaces and update the maximum frame length */
	for (i = 0; i < dpdmux->num_ifs; i++) {
		/*! Obtain interface */
		iface = &(dpdmux->iface[i]); /* Get interface */

		/*! Get IFP descriptor */
		eiop_ifp_desc.ifp_id = iface->ap.ifpid;
		eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* TBD */
		err = sys_get_desc(SOC_MODULE_EIOP_IFP,/* module */
					/* match options*/
					SOC_DB_IFP_DESC_ID |
					SOC_DB_IFP_DESC_EIOP_ID,
					&eiop_ifp_desc, /* descriptor */
					NULL); /* iterator */
		CHECK_COND_RETVAL(err == 0, err);
		CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

		/*! Set frame length */
		err = eiop_ifp_set_max_frame_length(&eiop_ifp_desc,
						    mfl);
		CHECK_COND_RETVAL(err == 0, err, "ID[%d] Filed to change max frame len for interface %d\n", dpdmux->id, i);

		iface->mfl = mfl;
	}

	dpdmux->max_frame_length = mfl;

	return 0;
}

int dpdmux_get_max_frame_length(struct dpdmux *dpdmux, uint16_t if_id,
		uint16_t *max_frame_length)
{
	struct dpdmux_if *iface;

	CHECK_COND_RETVAL(if_id < dpdmux->num_ifs, -EINVAL, "Interface ID must be smaller than %d\n", dpdmux->num_ifs);

	if( !(dpdmux->options & DPDMUX_OPT_AUTO_MAX_FRAME_LEN) ) {
		*max_frame_length = dpdmux->max_frame_length;
	}
	else {
		if( dpdmux->options & DPDMUX_OPT_BRIDGE_EN )
			iface = &(dpdmux->iface[if_id]);
		else
			iface = &(dpdmux->iface[0]);

		*max_frame_length = iface->mfl;
	}

	return 0;
}

static int update_default_if_in_miss_table_rules(struct dpdmux *dpdmux,
						uint16_t if_id,
						enum dpdmux_owner owner,
						int no_default_if,
						uint8_t *miss_key,
						uint32_t key_size)
{
	int err = 0;
	int iter_status, iter;
	hmap_data data;

	if (no_default_if == 1)
		if ((dpdmux->iface[dpdmux->default_if].unicast_promisc) ||
			(dpdmux->iface[dpdmux->default_if].multicast_promisc))
		return err;

	/* go over all the entries in the miss table and updates the
	 * entries with the default port
	 */
	iter_status = hmap_get_start_iterator(dpdmux->hmap[DPDMUX_HMAP_MISS_IDX],
						&iter);

	while (iter_status == 0) {
		/* Retrieve the key in the miss table at iterator and updates iterator */
		iter_status = hmap_iterate(dpdmux->hmap[DPDMUX_HMAP_MISS_IDX], &iter,
						miss_key,
						(void**)&data);

		/* remove the if_id in case the user asked to remove
		 * the current default interface or asked to update
		 * the current one
		 */
		if ((dpdmux->default_if != 0) &&
			((no_default_if) || (dpdmux->default_if != if_id)))
		{
			err = update_entry_in_miss_table_with_key(
				dpdmux, dpdmux->default_if, owner, miss_key,
				key_size, 0/*remove */);
			CHECK_COND_RETVAL(err == 0, err);
		}

		/* set new default interface */
		if (!no_default_if)
			err = update_entry_in_miss_table_with_key(
				dpdmux, if_id, owner, miss_key, key_size,
				1/*add */);

		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int update_default_if_in_dmat_rules(struct dpdmux *dpdmux,
					uint16_t if_id,
					enum dpdmux_owner owner,
					int no_default_if)
{
	int err = 0;

	uint8_t addr[DPDMUX_VLAN_KEY_SIZE];

	if ((no_default_if)
		|| (dpdmux->default_if != if_id)
			&& (dpdmux->default_if != 0)) {
		err = update_miss_entry_in_dmat(dpdmux,
						dpdmux->default_if,
						owner,
						0/*remove */);
		CHECK_COND_RETVAL(err == 0, err);
		/* handle the entry of vlan=0 */
		if ((dpdmux->method != DPDMUX_METHOD_CUSTOM) && dpdmux->default_if) {
			memset(&addr, 0, DPDMUX_VLAN_KEY_SIZE);
			err = remove_rule_from_table(
				dpdmux, (uint8_t*)addr, NULL,
				(uint32_t)get_key_size(dpdmux),
				DPDMUX_HMAP_UNICAST_IDX,
				DPDMUX_DMAT_IDX,
				owner,
				0 /* remove_data */);
			CHECK_COND_RETVAL(err == 0, err);
		}

	}
	/* set new default interface */
	if (!no_default_if) {
		err = update_miss_entry_in_dmat(dpdmux, if_id, owner,
						1/*add */);
		CHECK_COND_RETVAL(err == 0, err);

		/* handle the entry of vlan=0 */
		if (dpdmux->method != DPDMUX_METHOD_CUSTOM) {
			memset(&addr, 0, DPDMUX_VLAN_KEY_SIZE);
			err = add_rule_to_table(dpdmux, if_id, (uint8_t*)addr, NULL,
									DPDMUX_VLAN_KEY_SIZE, 0,
									DPDMUX_HMAP_UNICAST_IDX,
						DPDMUX_DMAT_IDX,
						owner,
						0/* allow_modify */);
		}
	}
	return err;
}

int dpdmux_if_get_link_state(struct dpdmux *dpdmux, uint16_t if_id,
	struct dpdmux_link_state *state)
{
	int err = 0;
	struct linkman_endpoint ep1, ep2;
	struct linkman_connection_attr	connection_attr;

	/*! Check parameters */
	if (if_id >= dpdmux->num_ifs)
		return -EINVAL;

	/*! init endpoints */
	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));

	/*! Endpoint information */
	ep1.type = FSL_MOD_DPDMUX;
	ep1.id = (uint16_t)dpdmux->id;
	ep1.if_id = if_id;

	/*! Obtain connection */
	err = linkman_get_connection(
		dpdmux->hndl.linkman,
		&ep1,
	        &ep2,
	        &connection_attr);
	CHECK_COND_RETVAL(err == 0, err);

	/* copy state to user */
	state->options = connection_attr.options;
	state->rate = connection_attr.rate;
	state->up = (connection_attr.state == LINKMAN_STATE_LINKUP) ? 1 : 0;

	return err;
}

int dpdmux_if_set_link_cfg(struct dpdmux *dpdmux, uint16_t if_id,
	struct dpdmux_link_cfg *cfg)
{
	struct dpdmux_if	*iface;
	uint64_t opt_chk;

	/*! Check parameters */
        if (if_id >= dpdmux->num_ifs)
                return -EINVAL;

        /* Obtain interface */
        iface = &(dpdmux->iface[if_id]);

	if (iface->enable) {
		pr_err("ID[%d] IF[%d]: interface must be disabled\n",
		       dpdmux->id, if_id);
		return -EACCES;
	}
	
	opt_chk = DPDMUX_LINK_OPT_AUTONEG |
			DPDMUX_LINK_OPT_HALF_DUPLEX	|
			DPDMUX_LINK_OPT_PAUSE |
			DPDMUX_LINK_OPT_ASYM_PAUSE;
	
	if (cfg->options & (~opt_chk)) {
		pr_err("ID[%d] IF[%d]: invalid link options (0x%x) %\n",
				       dpdmux->id, if_id, cfg->options);
		return -EINVAL;
	}
		
	/* Save link configuration */
	memcpy(&(iface->link_cfg), cfg, sizeof(struct dpdmux_link_cfg));

	return 0;
}

int dpdmux_set_default_if(struct dpdmux *dpdmux,
	uint16_t if_id,
	int no_default_if)
{
	int err = 0;
	uint8_t miss_key[DPDMUX_MAX_MISS_KEY_SIZE];
	int num_entries = 0;
	uint32_t key_size = 0;
	enum dpdmux_owner owner = DPDMUX_OWNER_MANAGEMENT;

	pr_debug("ID[%d] IF[%d]: start \n", dpdmux->id, if_id);

	/* default interface has only been tested with method = CUSTOM
	 * put an error message that the rest of the methods are not supported */
	if (dpdmux->method != DPDMUX_METHOD_CUSTOM) {
		pr_err("default interface configuration not supported for method %d\n",
				dpdmux->method);
		return -EINVAL;
	}

	if (if_id >= dpdmux->num_ifs) {
		pr_err("if_id:%d out of range\n", if_id);
		return -EINVAL;
	}

	/* default interface can\t be zero - the user should set no_default_if
	 * to delete the default interface
	 */
	if ((if_id == 0) && (no_default_if == 0)) {
		pr_err("default interface can't be zero\n");
		return -ENAVAIL;
	}
	/* check if there is a request to remove the default interface and
	 * currently there is no default interface
	 */
	if ((dpdmux->default_if == 0) && (no_default_if == 1))
		return 0;

	memset(miss_key, 0, (sizeof(uint8_t) * DPDMUX_MAX_MISS_KEY_SIZE));

	get_miss_info_by_method(dpdmux, &num_entries, &key_size);

	switch (dpdmux->method) {
	case DPDMUX_METHOD_C_VLAN:
	case DPDMUX_METHOD_CUSTOM:
		err = update_default_if_in_dmat_rules(dpdmux,
		                                      if_id,
		                                      owner,
		                                      no_default_if);
		CHECK_COND_RETVAL(err == 0, err);
		break;
	case DPDMUX_METHOD_MAC:
	case DPDMUX_METHOD_C_VLAN_MAC:
		/* handling default interface which is different than zero
		 * add the entries with vlan = 0 to the miss table
		 */
		/* if the new default interface is different than 0, than I
		 * add an entry with vlan=0 only in case it is VEPA.
		 * mac+vlan method - add two entries to the miss table with vlan = 0
		 * (one for multicast and one for unicast)
		 * in VEB, the entry already exists in the miss table populated
		 * by the uplink.it will be updated by the loop on the hash
		 * table
		 *
		 */
		if ((dpdmux->default_if == 0) && (if_id != 0)
			&& (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN))) {
			/* add unicast + vlan = 0 entry to the miss table */
			/* add multicast + vlan = 0 entry to the miss table */
			err = update_miss_table_entries(dpdmux, if_id, owner, 0,/*vlan_id*/
							1/*add*/);
			CHECK_COND_RETVAL(err == 0, err);
		}

		err = update_default_if_in_miss_table_rules(dpdmux,
		                                        if_id,
		                                        owner,
		                                        no_default_if,
		                                        miss_key,
		                                        key_size);
		CHECK_COND_RETVAL(err == 0, err);
		break;
	case DPDMUX_METHOD_NONE:
	case DPDMUX_METHOD_S_VLAN:
	default:
		return -ENOTSUP;
	}

	/* remove the default interface from the table */
	if (no_default_if)
		dpdmux->default_if = 0;
	else
		/* set the if_id as the default interface */
		dpdmux->default_if = if_id;

	return err;
}

int dpdmux_get_default_if(struct dpdmux *dpdmux, uint16_t *if_id)
{
	*if_id = dpdmux->default_if;

	return 0;
}

int dpdmux_set_resetable(struct dpdmux *dpdmux, uint8_t skip_reset_flags)
{
	dpdmux->skip_reset_flags = skip_reset_flags;

	return 0;

}

int dpdmux_get_resetable(struct dpdmux *dpdmux, uint8_t *skip_reset_flags)
{
	*skip_reset_flags = dpdmux->skip_reset_flags;

	return 0;

}

#if 0 /* for code coverage */
int dpdmux_if_get_transmit_rate(struct dpdmux *dpdmux,
	uint16_t if_id,
	struct dpdmux_transmit_rate *cfg)
{
	/*struct dpdmux_if *iface;*/

	ASSERT_COND(dpdmux);

	if (if_id >= dpdmux->num_ifs)
		return -EINVAL;
#if 0
	iface = &(dpdmux->iface[if_id]);

	switch (iface->rate) {
		case FSL_ENET_SPEED_10: /**< 10 Mbps */
		cfg->rate = 10 * MBIT_PER_SECOND;
		break;
		case FSL_ENET_SPEED_100: /**< 100 Mbps */
		cfg->rate = 100 * MBIT_PER_SECOND;
		break;
		case FSL_ENET_SPEED_1000: /**< 1000 Mbps = 1 Gbps */
		cfg->rate = 1 * GBIT_PER_SECOND;
		break;
		case FSL_ENET_SPEED_10000: /**< 10000 Mbps = 10 Gbps */
		cfg->rate = 10 * GBIT_PER_SECOND;
		break;
		default:
		cfg->rate = 0;
		break;
	}
#endif
	return -ENOTSUP;
}

int dpdmux_if_set_tci(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_tci_val *cfg)
{
	struct dpdmux_if *iface;

	CHECK_COND_RETVAL(dpdmux, -EINVAL);

	if (if_id >= dpdmux->num_ifs)
		return -EINVAL;
	iface = &(dpdmux->iface[if_id]);

	memcpy(&(iface->tci), cfg, sizeof(struct dpdmux_tci_val));
	return -ENOTSUP;
}

int dpdmux_if_set_accepted_frames(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_accepted_frames *cfg)
{
	struct dpdmux_if *iface;

	CHECK_COND_RETVAL(dpdmux, -EINVAL);

	if (if_id >= dpdmux->num_ifs)
		return -EINVAL;
	iface = &(dpdmux->iface[if_id]);

	memcpy(&(iface->accept_frame_types), cfg,
		sizeof(struct dpdmux_accepted_frames));

	return -ENOTSUP;
}

#endif /* for code coverage */

int dpdmux_if_get_attributes(struct dpdmux *dpdmux,
	uint16_t if_id,
	struct dpdmux_if_attr *attr)
{
	struct dpdmux_if *iface;
	struct linkman_endpoint 	ep1, ep2;
	struct linkman_connection_attr	connection_attr;
	int err;

	if (if_id >= dpdmux->num_ifs)
		return -EINVAL;

	memset(attr, 0, sizeof(struct dpdmux_if_attr));	
	iface = &(dpdmux->iface[if_id]);

	attr->is_default = (if_id == dpdmux->default_if);
	attr->accept_frame_type = iface->accept_frame_types.type;

	attr->enabled = iface->enable; /*! Enabled/disabled */
	attr->tci = iface->tci;

	/* Obtain link */
	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	memset(&connection_attr, 0x0, sizeof(struct linkman_connection_attr));
	ep1.type = FSL_MOD_DPDMUX;
	ep1.id = (uint16_t)dpdmux->id;
	ep1.if_id = if_id;
	err = linkman_get_connection(dpdmux->hndl.linkman,
	                             &ep1,
	                             &ep2,
	                             &connection_attr);

	if (!err)
		attr->rate = (int)connection_attr.rate;

	return 0;
}

int dpdmux_set_irq(struct dpdmux *dpdmux,
	uint8_t irq_index,
	const struct mc_irq_cfg *irq_cfg)
{
	if (irq_index >= DPDMUX_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPDMUX_MAX_IRQ_NUM);
		return -EINVAL;
	}

	mc_set_irq(&(dpdmux->irqs[irq_index]), irq_cfg);
	return 0;
}

int dpdmux_get_irq(struct dpdmux *dpdmux,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg)
{
	int err;

	if (irq_index >= DPDMUX_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPDMUX_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq(&(dpdmux->irqs[irq_index]), irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpdmux_set_irq_enable(struct dpdmux *dpdmux, uint8_t irq_index, uint8_t en)
{
	int err;

	if (irq_index >= DPDMUX_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPDMUX_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_set_irq_enable(&(dpdmux->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpdmux_get_irq_enable(struct dpdmux *dpdmux,
	uint8_t irq_index,
	uint8_t *en)
{
	int err;

	if (irq_index >= DPDMUX_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPDMUX_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_enable(&(dpdmux->irqs[irq_index]), en);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpdmux_set_irq_mask(struct dpdmux *dpdmux,
	uint8_t irq_index,
	uint32_t mask)
{
	int err;

	if (irq_index >= DPDMUX_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPDMUX_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_set_irq_mask(&(dpdmux->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpdmux_get_irq_mask(struct dpdmux *dpdmux,
	uint8_t irq_index,
	uint32_t *mask)
{
	int err;

	if (irq_index >= DPDMUX_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPDMUX_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_mask(&(dpdmux->irqs[irq_index]), mask);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpdmux_get_irq_status(struct dpdmux *dpdmux,
	uint8_t irq_index,
	uint32_t *status)
{
	int err;

	if (irq_index >= DPDMUX_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n", irq_index, DPDMUX_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_get_irq_status(&(dpdmux->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpdmux_clear_irq_status(struct dpdmux *dpdmux,
	uint8_t irq_index,
	uint32_t status)
{
	int err, pending;
	uint16_t if_id, event;

	if (irq_index >= DPDMUX_MAX_IRQ_NUM) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPDMUX_MAX_IRQ_NUM);
		return -EINVAL;
	}

	err = mc_clear_irq_status(&(dpdmux->irqs[irq_index]), status);
	CHECK_COND_RETVAL(err == 0, err);

	/* Is any pending messages? */
	pending = irq_get_pending_if(dpdmux, &if_id);
	if (pending == 1) {
		/* get event and clear pending */
		event = irq_if_restore_event(dpdmux, if_id);

		/* trigger an interrupt */
		irq_if_trigger(dpdmux, if_id, event);
	}

	return 0;
}

static int event_negotiation_fail(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	return 0;
}

static int event_negotiation_ok(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0;

    /* enable ifp */
    err = if_eiop_ifp_rx_enable(dpdmux, self->if_id);

    /* Indicate to lnik manager to save link state */
    action->state.rate = peer->rate;
    action->state.options = peer->options;

    /* Require completion notification */
    action->request = LINKMAN_REQUEST_COMPLETE_CB;

	return err;
}


static int event_linkdown_phys(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
/*
 *      -Verify parameters
 *      -Check MAC disabled RX
 *      -RX graceful stop
 *      -check link is external
 *              -set loopback
 *
 *      -eiop_ifp_tx_graceful_stop
 *
 *
 *      -remove loopback
 * */

	int err = -ENOTSUP; /* Operation not supported */
	struct dpdmux_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct dpmac *dpmac;

	/* Check MAC disabled RX */
	if (!(peer->valid_fields & LINKMAN_FIELD_DPMAC_RX_DIS))
		return LINKMAN_ECONT;

	/* Obtain ifp descriptor */
	iface = &(dpdmux->iface[self->if_id]);

	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* WRIOP ID */

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	CHECK_COND_RETVAL(err == 0, err);

	/* RX graceful stop */
	err = eiop_ifp_rx_graceful_stop(&eiop_ifp_desc);
	CHECK_COND_RETVAL(err == 0, err);

	dpmac = sys_get_handle(FSL_MOD_DPMAC, 1, peer->id);
	CHECK_COND_RETVAL(dpmac, -ENAVAIL);

	/* require completion notification */
	action->request = LINKMAN_REQUEST_COMPLETE_CB;

	return err;
}

static int event_linkup_phys(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0;
    struct dpdmux_if *iface;
    uint32_t pfc_flags;

	iface = &(dpdmux->iface[self->if_id]);

	/* Is end-point enabled? */
	CHECK_COND_RETVAL(iface->enable, -EACCES);

	if( !(self->valid_fields & LINKMAN_FIELD_LINK_CFG) ) {
		/* tell to the peer that cfg has been made */
		self->valid_fields = LINKMAN_FIELD_LINK_CFG;

		/* Provide Line configuration */
		if( iface->link_cfg.options & DPDMUX_LINK_OPT_AUTONEG )
			self->options |= LINKMAN_LINK_OPT_AUTONEG;
		if( iface->link_cfg.options & DPDMUX_LINK_OPT_PAUSE )
			self->options |= LINKMAN_LINK_OPT_PAUSE;
		if( iface->link_cfg.options & DPDMUX_LINK_OPT_ASYM_PAUSE )
			self->options |= LINKMAN_LINK_OPT_ASYM_PAUSE;

		self->rate = iface->link_cfg.rate;
		return LINKMAN_ECONT;
	}

	if( self->options & LINKMAN_LINK_OPT_PAUSE ) {
		pfc_flags = DPDMUX_UPDATE_FC | DPDMUX_ENABLE_FC_SENDING | DPDMUX_ENABLE_FC_RESPONSE;
		err = dpdmux_if_update_bp_config(dpdmux, self->if_id, pfc_flags);
		CHECK_COND_RETVAL( err==0, err, "DPDMUX.%d[%d]: dpdmux_if_update_bp_config() call failed\n", dpdmux->id, self->if_id);
	}
	else {
		pfc_flags = DPDMUX_UPDATE_FC;
		err = dpdmux_if_update_bp_config(dpdmux, self->if_id, pfc_flags);
		CHECK_COND_RETVAL( err==0, err, "DPDMUX.%d[%d]: dpdmux_if_update_bp_config() call failed\n", dpdmux->id, self->if_id);
	}
	self->ep_enabled = iface->enable;
	self->valid_fields |= LINKMAN_FIELD_LINK_STATE;

	/* Link state valid? */
	if ((peer->valid_fields & LINKMAN_FIELD_LINK_STATE) == 0)
		return LINKMAN_ECONT;

	/* Link state available */
	if (peer->link_state_available == 0)
		return 0;

	err = event_negotiation_ok(dpdmux, self, peer, action);

	return err;
}

static int dpdmux_empty_all_frames(const struct linkman_endpoint  *peer)
{
	int en, err=0, tries = 50;
	struct dpmac *dpmac;
	uint64_t counter = 0, counter_new = 0;
	
	dpmac = sys_get_handle(FSL_MOD_DPMAC, 1, peer->id);
	ASSERT_COND(dpmac);
	
	dpmac_is_enabled(dpmac, &en);
	if (!en)
		dpmac_enable(dpmac);
	
	err = dpmac_set_loopback(dpmac, 1);
	
	do{
		counter = counter_new;
		timer_udelay(1);
		dpmac_get_counter (dpmac, DPMAC_CNT_EGR_GOOD_FRAME, &counter_new);
		
	} while ((counter != counter_new) && --tries);
	
	if (!tries )
	{
		pr_err("DPDMUX failed to clear all frames from tx\n");
	}
		
	err = dpmac_set_loopback(dpmac, 0);
	
	if (!en)
		err = dpmac_disable(dpmac);
	
	return err;
}

static int event_disconnect_phys(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
        int err = 0;
        struct dpdmux_if *iface;
        struct eiop_ifp_desc eiop_ifp_desc;
        
        /* Obtain interface */
        iface = &(dpdmux->iface[self->if_id]);
        
        eiop_ifp_desc.ifp_id = iface->ap.ifpid;
        eiop_ifp_desc.eiop_id = iface->ap.iop_id; /* WRIOP ID */
        
    	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
    				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID, /* match options*/
    				&eiop_ifp_desc, /* descriptor */
    				NULL); /* iterator */
    	CHECK_COND_RETVAL(err == 0, err);

    	dpdmux_empty_all_frames(peer);
    	
    	/* Stop TX*/
    	err = eiop_ifp_tx_graceful_stop(&eiop_ifp_desc);
    	CHECK_COND_RETVAL(err == 0, err);
        
        self->valid_fields |= LINKMAN_FIELD_CLEAR_TX_FRAMES;

        if (((self->valid_fields & LINKMAN_FIELD_FREE_CONN_ID) == 0)) {

            /* disconnect accesspoint */
			if( iface->link_res_flags & DPDMUX_LINKRES_AP_CONNECTED) {
                err = ceetm_if_disconnect_accesspoint(
                	iface->ceetm_if,
                	&(iface->ap));
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags &= (~DPDMUX_LINKRES_AP_CONNECTED);
			}

			if( iface->link_res_flags & DPDMUX_LINKRES_CHANNEL_ALLOCATED ) {
				err = dpmng_connection_free_ceetm_channel(dpdmux->hndl.dpmng,
						&iface->ap.cqchid, iface->ap.dcp_id, iface->ap.ceetm_id, 1);
				iface->link_res_flags &= (~DPDMUX_LINKRES_CHANNEL_ALLOCATED);
				if( err ) {
					pr_err("IF[%d] Failed to free ceetm channel resource for interface %d\n",
							dpdmux->id, self->if_id);
				}
			}

			if( iface->link_res_flags & DPDMUX_LINKRES_CONNECTION_ALLOCATED) {
                /* free virtual connection */
                err = dpmng_connection_free(
                	dpdmux->hndl.dpmng, 	/* Context */
                        iface->conn_id); 	/* connection id */
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags &= (~DPDMUX_LINKRES_CONNECTION_ALLOCATED);
			}

			if( iface->link_res_flags & DPDMUX_LINKRES_LFQ_ALLOCATED ) {
				err = dpmng_connection_free_lfqmtidx(dpdmux->hndl.dpmng, iface->ap.lfqmtidx,
						iface->ap.dcp_id, iface->ap.ceetm_id, iface->num_lfq);
				iface->link_res_flags &= (~DPDMUX_LINKRES_LFQ_ALLOCATED);
				if( err ) {
					pr_err("ID[%d] Failed to free %d LFQ resources disconnecting interface %d",
							dpdmux->id, iface->num_lfq, self->if_id);
				}
			}

			/* indicate virtual connection field in valid fields */
			self->valid_fields |= LINKMAN_FIELD_FREE_CONN_ID;
        }
        
        dpdmux->dpmac = NULL;

        return err;
}

/* physical events */
static int event_connect_phys(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
        int err = 0;
        struct dpdmux_if *iface;
        struct dpmng_amq  amq;

        /* Obtain interface */
        iface = &(dpdmux->iface[self->if_id]);

        /* get connection id */
        err = dpmng_connection_phys_allocate(
        	dpdmux->hndl.dpmng, 		/* dpmng context */
                peer->id, 			/* mac id */
                &(iface->conn_id)); 		/* connection id */
        CHECK_COND_RETVAL(err == 0, err);
        iface->link_res_flags |= DPDMUX_LINKRES_CONNECTION_ALLOCATED;

        /* Get access-point from dpmng */
        self->ifpid = iface->ap.ifpid;
        memset(&(iface->ap), 0x0, sizeof(struct dpmng_accesspoint));
        err = dpmng_connection_get_accesspoint(
        	dpdmux->hndl.dpmng, 		/* dpmng context */
                iface->conn_id, 		/* connection id */
                0, 				/* not used */
                0, 				/* not used */
                &(iface->ap));
        CHECK_COND_RETVAL(err == 0, err);

		err = dpmng_connection_alloc_ceetm_channel(
				dpdmux->hndl.dpmng,
				&iface->ap.cqchid, iface->ap.dcp_id, iface->ap.ceetm_id,
				1);
		CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate ceetm channel\n", dpdmux->id);
		iface->link_res_flags |= DPDMUX_LINKRES_CHANNEL_ALLOCATED;

		iface->num_lfq = 64;
		err = dpmng_connection_alloc_lfqmtidx(dpdmux->hndl.dpmng,
				iface->ap.lfqmtidx, iface->ap.dcp_id, iface->ap.ceetm_id, iface->num_lfq);
		CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate LFQ resources\n", dpdmux->id);
		iface->link_res_flags |= DPDMUX_LINKRES_LFQ_ALLOCATED;

        /* restore ifp */
        iface->ap.ifpid = self->ifpid;

        /* Obtain AMQ */
        memset(&amq, 0x0, sizeof(struct dpmng_amq));
        dpmng_get_amq(&amq);

        /* connect accesspoint */
        err = ceetm_if_connect_accesspoint(
            iface->ceetm_if,        /* ceetm interface */
            &(iface->ap),           /* accesspoint */
            &amq);              /* security */
        CHECK_COND_RETVAL(err == 0, err);
        iface->link_res_flags |= DPDMUX_LINKRES_AP_CONNECTED;

        /* associate accesspoint with lni */
        err = if_associate_with_lni(dpdmux, self->if_id, 0);
        CHECK_COND_RETVAL(err == 0, err);

        /* update qos mapping */
        err = if_set_tx_selection_qos_mapping(
                dpdmux,                         /* context */
                self->if_id,                    /* interface id */
                peer->type);                    /* peer type */
        CHECK_COND_RETVAL(err == 0, err);

        /* Indicate to peer IFP */
        self->ifpid = iface->ap.ifpid;
        self->valid_fields |= LINKMAN_FIELD_IFPID;
        
        /* enable ifp */
        err = if_eiop_ifp_tx_enable(dpdmux, self->if_id);
        CHECK_COND_RETVAL(err == 0, err);

	/* require completion notification */
       	action->request = LINKMAN_REQUEST_COMPLETE_CB;

       	dpdmux->dpmac = sys_get_handle(FSL_MOD_DPMAC, 1, peer->id);
       	CHECK_COND_RETVAL(dpdmux->dpmac, -ENAVAIL);

        return err;
}


static int event_phys(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0;

	switch (control->event) {
		case LINKMAN_EVENT_CONNECT:
			err = event_connect_phys(
				handle, self, peer, action);
			break;
		case LINKMAN_EVENT_DISCONNECT:
			err = event_disconnect_phys(
				handle, self, peer, action);
			break;
		case LINKMAN_EVENT_LINKUP:
			/* link up */
			err = event_linkup_phys(handle, self, peer, action);
			break;
		case LINKMAN_EVENT_LINKDOWN:
			/* link down */
			err = event_linkdown_phys(handle, self, peer, action);
			break;
		case LINKMAN_EVENT_NEGOTIATION_OK:
			/* link down */
			err = event_negotiation_ok(handle, self, peer, action);
			break;
		case LINKMAN_EVENT_NEGOTIATION_FAIL:
			/* link down */
			err = event_negotiation_fail(handle, self, peer, action);
			break;
		default:
			err = -ENOTSUP; /* Operation not supported */
			break;
        }
        return err;
}

static int link_state_common_denominator(
	const struct linkman_endpoint	*ep1,
	const struct linkman_endpoint 	*ep2,
	uint32_t committed_rate,
	struct linkman_link_state *link_state)
{
	int err = 0;

	/* 1 - negotiation, 2 - negotiation */
	if ( ((ep1->options & LINKMAN_LINK_OPT_AUTONEG) != 0) &&
		((ep2->options & LINKMAN_LINK_OPT_AUTONEG) != 0)) {
		link_state->rate = committed_rate;
	}
	/* 1 - negotiation, 2 - fixed */
	else if ( ((ep1->options & LINKMAN_LINK_OPT_AUTONEG) != 0) &&
		((ep2->options & LINKMAN_LINK_OPT_AUTONEG) == 0)) {
		if (committed_rate < ep2->rate)
			return -ENOTSUP;
		link_state->rate = ep2->rate;
	}
	/* 1 - fixed, 2 - negotiation */
	else if ( ((ep1->options & LINKMAN_LINK_OPT_AUTONEG) == 0) &&
		((ep2->options & LINKMAN_LINK_OPT_AUTONEG) != 0)) {
		if (committed_rate < ep1->rate)
			return -ENOTSUP;
		link_state->rate = ep1->rate;
	}
	/* 1 - fixed, 2 - fixed */
	else if ( ((ep1->options & LINKMAN_LINK_OPT_AUTONEG) == 0) &&
		((ep2->options & LINKMAN_LINK_OPT_AUTONEG) == 0)) {
		if (ep1->rate != ep2->rate)
			return -ENOTSUP;
		link_state->rate = ep1->rate;
	}
	return err;
}

static int event_deassociate_virt(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        	*self,
        	const struct linkman_endpoint  	*peer,
        	const struct linkman_control   	*control,
        	struct linkman_action          	*action)
{
        int err = 0;

        return err;
}

static int is_virt_connection_shaped(
                const struct linkman_control   *control)
{
	return !((control->committed_rate == 0) && (control->max_rate == 0));
}

static int event_linkup_virt(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	const struct linkman_control   *control,
        	struct linkman_action          *action)
{
	int err = LINKMAN_ECONT;
	struct linkman_link_state 	link_state = {0};
	struct dpdmux_if *iface;
	uint32_t max_rate;
	struct dpdmux_link_state if_link_state = {0};
	int ch_idx;
	uint64_t options;
	uint32_t pfc_flags;

	memset(&link_state, 0, sizeof(struct linkman_link_state));
	if( !(dpdmux->options & DPDMUX_OPT_BRIDGE_EN) ) {
		// VEPA mode: do not perform link up unless uplink port is UP
		err = dpdmux_if_get_link_state(dpdmux, DPDMUX_UL_INDEX, &if_link_state);
		if( err || (!err && !if_link_state.up) ){
			return -EAGAIN;
		}	
	}

	/* Obtain interface */
	iface = &(dpdmux->iface[self->if_id]);

	/* Verify device state is valid */
	CHECK_COND_RETVAL(iface->enable, -EACCES); /* invalid device state */

	/* Advertise capabilities */
	self->rate = iface->link_cfg.rate;
	if( !(self->valid_fields & LINKMAN_FIELD_LINK_CFG) ) {
		self->valid_fields |= LINKMAN_FIELD_LINK_CFG;

		if( iface->link_cfg.options & DPDMUX_LINK_OPT_AUTONEG )
			self->options |= LINKMAN_LINK_OPT_AUTONEG;
		if( iface->link_cfg.options & DPDMUX_LINK_OPT_PAUSE )
			self->options |= LINKMAN_LINK_OPT_PAUSE;
		if( iface->link_cfg.options & DPDMUX_LINK_OPT_ASYM_PAUSE )
			self->options |= LINKMAN_LINK_OPT_ASYM_PAUSE;
	}

	/* LINK_OPT_ASYM_PAUSE pause not supported at all, so it must be cleared */
	if( self->options & LINKMAN_LINK_OPT_ASYM_PAUSE ) {
		self->options &= ~(LINKMAN_LINK_OPT_PAUSE | LINKMAN_LINK_OPT_ASYM_PAUSE);
		pr_warn("ID[%d]: LINK_OPT_ASYM_PAUSE combinations not supported for virtual connections... clear and continue", dpdmux->id);
		return LINKMAN_ECONT;
	}

	/* wait capabilities from peer */
	if ( !(peer->valid_fields & LINKMAN_FIELD_LINK_CFG) ) {
		return LINKMAN_ECONT;
	}

	/*  check options with remote object */
	options = self->options & peer->options;
	if( options != self->options ) {
		if( !(options & LINKMAN_LINK_OPT_PAUSE) && (self->options & LINKMAN_LINK_OPT_PAUSE) ) {
			pr_warn("ID[%d] dpdmux: LINKMAN_LINK_OPT_PAUSE not supported on remote, Flow Control will not be enabled\n", dpdmux->id);
		}
	}

	/* Do not remove AUTONEG flag if peer is not configured with AUTONEG capability */
	self->options = options | (self->options & LINKMAN_LINK_OPT_AUTONEG);

	if( self->options & LINKMAN_LINK_OPT_PAUSE ) {
		if( peer->fc_available ) {
			/* channel index allocated by peer, copy and enable FC */
			iface->fc_idx = peer->fc_channel_idx;
			self->fc_channel_idx = peer->fc_channel_idx;
			self->fc_available = 1;
		} else if(iface->fc_idx == FLOW_CONTROL_INVALID_INDEX) {
			/* first time here, alloc channel index */
			ch_idx = fc_get_next_channel_idx();
			if( ch_idx < 0 ) {
				/* no channel index available, disable FC */
				self->options &= ~LINKMAN_LINK_OPT_PAUSE;
				pr_err("[ID%d] No channels available to implement flow control for if %d; clear PAUSE flag\n", dpdmux->id, self->if_id);
				return LINKMAN_ECONT;	// execute again for peer to disable FC
			} else {
				self->fc_channel_idx = ch_idx;
				self->fc_available = 1;
				iface->fc_idx = self->fc_channel_idx;
				return LINKMAN_ECONT;	// execute again to pass same setting to peer
			}
		} else {
				/* channel index allocated on a previous call */
				self->fc_channel_idx = iface->fc_idx;
				self->fc_available = 1;
				return LINKMAN_ECONT;
		}

		pfc_flags = DPDMUX_UPDATE_FC | DPDMUX_ENABLE_FC_SENDING | DPDMUX_ENABLE_FC_RESPONSE;
		dpdmux_if_update_channel_fc(dpdmux, self->if_id, pfc_flags);
		
		if( dpdmux->options & DPDMUX_OPT_BRIDGE_EN ) {
			/*Veb mode send Xoff to dpni */
			err = dpdmux_if_update_bp_config(dpdmux, self->if_id, pfc_flags);
			CHECK_COND_RETVAL( err==0, err, "DPDMUX.%d[%d]: dpdmux_if_update_bp_config() call failed\n", dpdmux->id, self->if_id);
		}

	} else {
		/* pause not enabled */
		if( iface->fc_idx != FLOW_CONTROL_INVALID_INDEX ) {
			/* pause was previously enabled 
			 * disable current settings and free flow control resource */
			if( !self->fc_available ) {
				pfc_flags = DPDMUX_UPDATE_FC;
				dpdmux_if_update_channel_fc(dpdmux, self->if_id, pfc_flags);
				
				if( dpdmux->options & DPDMUX_OPT_BRIDGE_EN ) {
					/*Veb mode remove Xoff to DPNI*/
					err = dpdmux_if_update_bp_config(dpdmux, self->if_id, pfc_flags);
					CHECK_COND_RETVAL( err==0, err, "DPDMUX.%d[%d]: dpdmux_if_update_bp_config() call failed\n", dpdmux->id, self->if_id);
				}
				self->fc_available = 1;
			}

			/* wait for peer to disable FC*/
			if( !peer->fc_available ) {
				return LINKMAN_ECONT;
			}

			/* if peer does not free the resources */
			if( peer->fc_channel_idx != FLOW_CONTROL_INVALID_INDEX ) {
				fc_release_channel_idx(iface->fc_idx);
			}

			/* clear data */
			iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
			self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
		}
	}

	/* Is peer capabilities available? */
	if ((peer->valid_fields & LINKMAN_FIELD_LINK_CFG) != 0) {

			/* Obtain committed and maximum rates */
			err = virt_link_rates(
					self,
					peer,
					control,
					&link_state,
					&max_rate);
			CHECK_COND_RETVAL(err == 0, err, "virt_link_rates() failed" );

			/* Configure rates */
			err = ceetm_if_set_transmit_rate(
				iface->ceetm_if, 	/* ceetm context */
				link_state.rate,	/* committed rate */
				max_rate);		/* maximum rate */
			CHECK_COND_RETVAL(err == 0, err, "ceetm_if_set_transmit_rate() failed" );

			/* enable ifp */
			err = if_eiop_ifp_rx_enable(dpdmux, self->if_id);
			CHECK_COND_RETVAL(err == 0, err, "if_eiop_ifp_rx_enable() failed" );
			err = if_eiop_ifp_tx_enable(dpdmux, self->if_id);
			CHECK_COND_RETVAL(err == 0, err, "if_eiop_ifp_tx_enable() failed" );

			/* Indicate to link manager to save link state */
			link_state.options = self->options;
			memcpy(&(action->state), &link_state, sizeof(struct linkman_link_state));

			/* Request for completion notification */
			action->request = LINKMAN_REQUEST_COMPLETE_CB;
	}

    /* restore taildrop for this interface while down */
   if_restore_taildrop(dpdmux, self->if_id);

	return err;
}

static int event_linkdown_virt(struct dpdmux 	*dpdmux,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	const struct linkman_control   	*control,
        	struct linkman_action          *action)
{
	int err;

        /* Disable IFP */
        err = if_eiop_ifp_disable(dpdmux, self->if_id);

        /* set zero taildrop for this interface when down */
        if_set_zero_taildrop(dpdmux, self->if_id);

        /* Request for completion notification */
        action->request = LINKMAN_REQUEST_COMPLETE_CB;

	return err;
}

static int veb_event_disconnect_virt(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0;
	struct dpdmux_if *iface;
	uint32_t pfc_flags;

	err = if_eiop_ifp_disable(dpdmux, self->if_id);
	
	/*! Obtain interface */
	iface = &(dpdmux->iface[self->if_id]);

	if( !(self->valid_fields & LINKMAN_FIELD_LINK_CFG )) {
		/* copy data about link configuration in self and peer structures */
		self->fc_channel_idx = iface->fc_idx;
		self->valid_fields |= LINKMAN_FIELD_LINK_CFG;
		return LINKMAN_ECONT;
	}

	if( !( self->valid_fields & LINKMAN_FIELD_PFC_CONFIG ) ) {
		/* check flow control configuration */
		if( ( self->fc_channel_idx==FLOW_CONTROL_INVALID_INDEX && peer->fc_channel_idx!=FLOW_CONTROL_INVALID_INDEX ) ||
			( self->fc_channel_idx!=FLOW_CONTROL_INVALID_INDEX && peer->fc_channel_idx==FLOW_CONTROL_INVALID_INDEX ) )
		{
			pr_err(	"[ID%d] if%d Invalid flow control configuration ; self(%d) peer(%d); \n"
					"MC will set some default values to continue... \n"
					"Future flow control configuration may fail\n", dpdmux->id, self->if_id, self->fc_channel_idx, peer->fc_channel_idx);
			self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
			iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
		}
		self->valid_fields |= LINKMAN_FIELD_PFC_CONFIG;
		return LINKMAN_ECONT;
	}

	if( self->fc_channel_idx == FLOW_CONTROL_INVALID_INDEX ) {
		/* Flow control not enabled, perform flag exchange*/
		if( !self->fc_disabled ) {
			self->fc_disabled = 1;
		}
		if( !peer->fc_disabled ) {
			return LINKMAN_ECONT;
		}
	}
	else if( iface->fc_idx != FLOW_CONTROL_INVALID_INDEX ) {
		/* flow control is enabled */
		if( !self->fc_disabled ) {
			/* disable flow control settings */
			pfc_flags = DPDMUX_UPDATE_FC;
			dpdmux_if_update_channel_fc(dpdmux, self->if_id, pfc_flags);
			
			err = dpdmux_if_update_bp_config(dpdmux, self->if_id, pfc_flags);
			CHECK_COND_RETVAL( err==0, err, "DPDMUX.%d[%d]: dpdmux_if_update_bp_config() call failed\n", dpdmux->id, self->if_id);
			
			self->fc_disabled = 1;
		}

		if( !peer->fc_disabled ) {
			/* wait for peer to disable flow control */
			return LINKMAN_ECONT;
		}

		/* if peer does not free the resources */
		if( peer->fc_channel_idx != FLOW_CONTROL_INVALID_INDEX ) {
			/* flow control channel index not released by peer */
			if( self->fc_channel_idx != FLOW_CONTROL_INVALID_INDEX ) {
				/* release flow control */
				fc_release_channel_idx(iface->fc_idx);
				iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
				self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
				return LINKMAN_ECONT;
			}
		} else {
			/* flow control channel index released by peer */
			iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
			self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
		}
	}

	if (((self->valid_fields & LINKMAN_FIELD_FREE_CONN_ID) == 0)) {

			/* disconnect accesspoint */
		if( iface->link_res_flags & DPDMUX_LINKRES_AP_CONNECTED ) {
			err = ceetm_if_disconnect_accesspoint(
					iface->ceetm_if,
					&(iface->ap));
			CHECK_COND_RETVAL(err == 0, err);
			iface->link_res_flags &= (~DPDMUX_LINKRES_AP_CONNECTED);
		}

		if( iface->link_res_flags & DPDMUX_LINKRES_ALLOC_BW ) {
			err = dpmng_connection_free_bandwidth(
				dpdmux->hndl.dpmng,             /* Context */
					&(iface->ap)                    /* access point */
					);
			CHECK_COND_RETVAL(err == 0, err);
			iface->link_res_flags &= (~DPDMUX_LINKRES_ALLOC_BW);
		}

		if( iface->link_res_flags & DPDMUX_LINKRES_CHANNEL_ALLOCATED ) {
			err = dpmng_connection_free_ceetm_channel(dpdmux->hndl.dpmng,
					&iface->ap.cqchid, iface->ap.dcp_id, iface->ap.ceetm_id, 1);
			iface->link_res_flags &= (~DPDMUX_LINKRES_CHANNEL_ALLOCATED);
			if( err ) {
				pr_err("Failed to free ceetm channel resource\n");
			}
		}

		if( iface->link_res_flags & DPDMUX_LINKRES_LFQ_ALLOCATED ) {
			err = dpmng_connection_free_lfqmtidx(dpdmux->hndl.dpmng, iface->ap.lfqmtidx,
					iface->ap.dcp_id, iface->ap.ceetm_id, iface->num_lfq);
			iface->link_res_flags &= (~DPDMUX_LINKRES_LFQ_ALLOCATED);
			if( err ) {
				pr_err("ID[%d] Failed to free %d LFQ resources disconnecting interface %d",
						dpdmux->id, iface->num_lfq, self->if_id);
			}
		}

		if( iface->link_res_flags & DPDMUX_LINKRES_CONNECTION_ALLOCATED ) {
			/*! free virtual connection */
			err = dpmng_connection_free(dpdmux->hndl.dpmng, /*! Context */
											iface->conn_id); /*! connection id */
			CHECK_COND_RETVAL(err == 0, err);
			iface->link_res_flags &= (~DPDMUX_LINKRES_CONNECTION_ALLOCATED);
		}

			/*! indicate virtual connection field in valid fields */
			self->valid_fields |= LINKMAN_FIELD_FREE_CONN_ID;
	}

	self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
	self->allocate_cr = 1;

	/* require completion notification */
	action->request = LINKMAN_REQUEST_COMPLETE_CB;

	return err;
}

static int disconnect_virt_from_linkup_uplink(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0;
	struct dpdmux_if *iface;

	err = if_eiop_ifp_disable(dpdmux, self->if_id);

	if (((self->valid_fields & LINKMAN_FIELD_FREE_CONN_ID) == 0)) {

		/*! Obtain interface */
		iface = &(dpdmux->iface[self->if_id]);

		if( iface->link_res_flags & DPDMUX_LINKRES_AP_CONNECTED ) {
			/* disconnect accesspoint */
			err = ceetm_if_disconnect_accesspoint(
					iface->ceetm_if,
					&(iface->ap));
			CHECK_COND_RETVAL(err == 0, err);
			iface->link_res_flags &= (~DPDMUX_LINKRES_AP_CONNECTED);
		}

		if( iface->link_res_flags & DPDMUX_LINKRES_ALLOC_BW ) {
			err = dpmng_connection_free_bandwidth(
				dpdmux->hndl.dpmng,             /* Context */
					&(iface->ap)                    /* access point */
					);
			CHECK_COND_RETVAL(err == 0, err);
			iface->link_res_flags &= (~DPDMUX_LINKRES_ALLOC_BW);
		}

		if( iface->link_res_flags & DPDMUX_LINKRES_CHANNEL_ALLOCATED ) {
			err = dpmng_connection_free_ceetm_channel(dpdmux->hndl.dpmng,
					&iface->ap.cqchid, iface->ap.dcp_id, iface->ap.ceetm_id, 1);
			iface->link_res_flags &= (~DPDMUX_LINKRES_CHANNEL_ALLOCATED);
			if( err ) {
				pr_err("Failed to free ceetm channel resource\n");
			}
		}

		if( iface->link_res_flags & DPDMUX_LINKRES_LFQ_ALLOCATED ) {
			err = dpmng_connection_free_lfqmtidx(dpdmux->hndl.dpmng, iface->ap.lfqmtidx,
					iface->ap.dcp_id, iface->ap.ceetm_id, iface->num_lfq);
			iface->link_res_flags &= (~DPDMUX_LINKRES_LFQ_ALLOCATED);
			if( err ) {
				pr_err("ID[%d] Failed to free %d LFQ resources disconnecting interface %d",
						dpdmux->id, iface->num_lfq, self->if_id);
			}
		}

		if( iface->link_res_flags & DPDMUX_LINKRES_CONNECTION_ALLOCATED ) {
			/*! free virtual connection */
			err = dpmng_connection_free(dpdmux->hndl.dpmng, /*! Context */
										iface->conn_id); /*! connection id */
			CHECK_COND_RETVAL(err == 0, err);
			iface->link_res_flags &= (~DPDMUX_LINKRES_CONNECTION_ALLOCATED);
		}

		/*! indicate virtual connection field in valid fields */
		self->valid_fields |= LINKMAN_FIELD_FREE_CONN_ID;
	}

	/* Indicate to peer */
	self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
	self->allocate_cr = 0;

	/* Indicate to peer */
	self->valid_fields |= LINKMAN_FIELD_AP_AVAILABLE;
	self->ap_available = 1;

	return err;
}

static int disconnect_virt_from_connected_or_idle_uplink(
	struct dpdmux 	*dpdmux,
        struct linkman_endpoint        *self,
        const struct linkman_endpoint  *peer,
        struct linkman_action          *action)
{
        int err = 0;
        struct dpdmux_if *iface;
        
        err = if_eiop_ifp_disable(dpdmux, self->if_id);

        if (((self->valid_fields & LINKMAN_FIELD_FREE_CONN_ID) == 0)) {

                /*! Obtain interface */
                iface = &(dpdmux->iface[self->if_id]);

                /* disconnect accesspoint */
            if( iface->link_res_flags & DPDMUX_LINKRES_AP_CONNECTED ) {
                err = ceetm_if_disconnect_accesspoint(
                        iface->ceetm_if,
                        &(iface->ap));
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags &= (~DPDMUX_LINKRES_AP_CONNECTED);
            }

            if( iface->link_res_flags & DPDMUX_LINKRES_ALLOC_BW ) {
                err = dpmng_connection_free_bandwidth(
						dpdmux->hndl.dpmng,             /* Context */
                        &(iface->ap)                    /* access point */
                        );
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags &= (~DPDMUX_LINKRES_ALLOC_BW);
            }

			if( iface->link_res_flags & DPDMUX_LINKRES_CHANNEL_ALLOCATED ) {
				err = dpmng_connection_free_ceetm_channel(dpdmux->hndl.dpmng,
						&iface->ap.cqchid, iface->ap.dcp_id, iface->ap.ceetm_id, 1);
				iface->link_res_flags &= (~DPDMUX_LINKRES_CHANNEL_ALLOCATED);
				if( err ) {
					pr_err("Failed to free ceetm channel resource\n");
				}
			}

			if( iface->link_res_flags & DPDMUX_LINKRES_LFQ_ALLOCATED ) {
				err = dpmng_connection_free_lfqmtidx(dpdmux->hndl.dpmng, iface->ap.lfqmtidx,
						iface->ap.dcp_id, iface->ap.ceetm_id, iface->num_lfq);
				iface->link_res_flags &= (~DPDMUX_LINKRES_LFQ_ALLOCATED);
				if( err ) {
					pr_err("ID[%d] Failed to free %d LFQ resources disconnecting interface %d",
							dpdmux->id, iface->num_lfq, self->if_id);
				}
			}

            /*! free virtual connection */
            if( iface->link_res_flags & DPDMUX_LINKRES_CONNECTION_ALLOCATED ) {
				err = dpmng_connection_free_ceetm_channel(dpdmux->hndl.dpmng,
						&iface->ap.cqchid, iface->ap.dcp_id, iface->ap.ceetm_id, 1);
				if( err ) {
					pr_err("Failed to free ceerm channel resource\n");
				}
                err = dpmng_connection_free(dpdmux->hndl.dpmng, /*! Context */
                                                iface->conn_id); /*! connection id */
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags &= (~DPDMUX_LINKRES_CONNECTION_ALLOCATED);

                /*! indicate virtual connection field in valid fields */
                self->valid_fields |= LINKMAN_FIELD_FREE_CONN_ID;
            }
        }

	/* Indicate to peer */
	self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
	self->allocate_cr = 0;

	/* Indicate to peer */
	self->valid_fields |= LINKMAN_FIELD_AP_AVAILABLE;
	self->ap_available = 1;

	return err;
}

static int vepa_event_disconnect_virt(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        	*self,
        	const struct linkman_endpoint  	*peer,
        	const struct linkman_control   	*control,
        	struct linkman_action          	*action)
{
	int err = LINKMAN_ECONT;
	struct linkman_endpoint ep1, ep2;
	struct linkman_connection_attr	connection_attr;
	struct dpdmux_if *iface;
	uint32_t pfc_flags;

	/*! Obtain interface */
	iface = &(dpdmux->iface[self->if_id]);

	if( !(self->valid_fields & LINKMAN_FIELD_LINK_CFG )) {
		/* copy data about link configuration in self and peer structures */
		self->fc_channel_idx = iface->fc_idx;
		self->valid_fields |= LINKMAN_FIELD_LINK_CFG;
		return LINKMAN_ECONT;
	}

	if( !( self->valid_fields & LINKMAN_FIELD_PFC_CONFIG ) ) {
		/* check flow control configuration */
		if( ( self->fc_channel_idx==FLOW_CONTROL_INVALID_INDEX && peer->fc_channel_idx!=FLOW_CONTROL_INVALID_INDEX ) ||
			( self->fc_channel_idx!=FLOW_CONTROL_INVALID_INDEX && peer->fc_channel_idx==FLOW_CONTROL_INVALID_INDEX ) )
		{
			pr_err(	"[ID%d] if%d Invalid flow control configuration ; self(%d) peer(%d); MC will set some default values to continue... "
					"Future flow control configuration may fail\n", dpdmux->id, self->if_id, self->fc_channel_idx, peer->fc_channel_idx);
			self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
			iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
		}
		self->valid_fields |= LINKMAN_FIELD_PFC_CONFIG;
		return LINKMAN_ECONT;
	}

	if( self->fc_channel_idx == FLOW_CONTROL_INVALID_INDEX ) {
		/* Flow control not enabled, perform flag exchange*/
		if( !self->fc_disabled ) {
			self->fc_disabled = 1;
		}
		if( !peer->fc_disabled ) {
			return LINKMAN_ECONT;
		}
	}
	else if( iface->fc_idx != FLOW_CONTROL_INVALID_INDEX ) {
		/* flow control is enabled */
		if( !self->fc_disabled ) {
			/* disable flow control settings */
			pfc_flags = DPDMUX_UPDATE_FC;
			dpdmux_if_update_channel_fc(dpdmux, self->if_id, pfc_flags);
			self->fc_disabled = 1;;
		}

		if( !peer->fc_disabled ) {
			/* wait for peer to disable flow control */
			return LINKMAN_ECONT;
		}

		/* if peer does not free the resources */
		if( peer->fc_channel_idx != FLOW_CONTROL_INVALID_INDEX ) {
			/* flow control channel index not released by peer */
			if( self->fc_channel_idx != FLOW_CONTROL_INVALID_INDEX ) {
				/* release flow control */
				fc_release_channel_idx(iface->fc_idx);
				iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
				self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
				return LINKMAN_ECONT;
			}
		} else {
			/* flow control channel index released by peer */
			iface->fc_idx = FLOW_CONTROL_INVALID_INDEX;
			self->fc_channel_idx = FLOW_CONTROL_INVALID_INDEX;
		}
	}

 	/*! init endpoints */
 	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
 	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));

 	/*! Endpoint information */
 	ep1.type = FSL_MOD_DPDMUX;
 	ep1.id = (uint16_t)dpdmux->id;
 	ep1.if_id = DPDMUX_UL_INDEX;

 	/*! get uplink state */
 	err = linkman_get_connection(
 		dpdmux->hndl.linkman,
 		&ep1,
 	        &ep2,
 	        &connection_attr);
 	CHECK_COND_RETVAL(err == 0, err);

 	/* check the following states that are invalid in case of uplink */
 	switch (connection_attr.state) {
 		case LINKMAN_STATE_IDLE:
 		case LINKMAN_STATE_CONNECTED:
 		case LINKMAN_STATE_NEGOTIATION:
 			err = disconnect_virt_from_connected_or_idle_uplink(dpdmux,
 				                            self,
 				                            peer,
 				                            action);
 			break;
 		case LINKMAN_STATE_LINKUP:
 			err = disconnect_virt_from_linkup_uplink(dpdmux,
 				                            self,
 				                            peer,
 				                            action);
 			break;
 		case LINKMAN_STATE_CANDIDATE:
 		case LINKMAN_STATE_INVALID:
 		default:
 		        return -EACCES;
 	}

    /* Require completion notification */
    action->request = LINKMAN_REQUEST_COMPLETE_CB;

 	return err;
}

static int veb_event_connect_virt(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        	*self,
        	struct linkman_endpoint        	*peer,
        	const struct linkman_control   	*control,
        	struct linkman_action          	*action)
{
        int err, idx, ifpid;
        struct dpdmux_if *iface;
        struct dpmng_accesspoint ap[2];
        struct dpmng_amq  amq;
        int channel_ids[DPMNG_MAX_CEETM_CH];
        int ceetm_ch_idx;

        /* Obtain interface */
        iface = &(dpdmux->iface[self->if_id]);

        /* nothing to pass from mux side */
        self->valid_fields |= LINKMAN_FIELD_INIT;

        /* waiting for data to be passed from dpni side */
		if( (peer->valid_fields & LINKMAN_FIELD_INIT) == 0 ) {
			return LINKMAN_ECONT;
		}

        if ((self->valid_fields & LINKMAN_FIELD_CONN_ID) == 0) {

                /* Obtain virtual connection */
                err = dpmng_connection_virt_allocate(dpdmux->hndl.dpmng,
                                                        &(iface->conn_id));
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags |= DPDMUX_LINKRES_CONNECTION_ALLOCATED;

                /* indicate connection has been taken */
                self->valid_fields |= LINKMAN_FIELD_CONN_ID;
        }

        if (!(self->valid_fields & LINKMAN_FIELD_AP_AVAILABLE)) {
                /* get accesspoint #1 */
                memset(&(ap[0]), 0x0, sizeof(struct dpmng_accesspoint));
                err = dpmng_connection_get_accesspoint(
                	dpdmux->hndl.dpmng, 	/* dpmng context */
                        iface->conn_id, 	/* connection id */
                        0, 			/* ap index */
                        control->committed_rate,
                        &(ap[0]));		/* ap #0 */
                CHECK_COND_RETVAL(err == 0, err);

                /* get accesspoint #2 */
                memset(&(ap[1]), 0x0, sizeof(struct dpmng_accesspoint));
                err = dpmng_connection_get_accesspoint(
                	dpdmux->hndl.dpmng, 	/* dpmng context */
                        iface->conn_id, 	/* connection id */
                        1, 			/* ap index */
                        control->committed_rate,
                        &(ap[1]));		/* ap #1 */
                CHECK_COND_RETVAL(err == 0, err);

                /* decide distribute ap's */
                /* in case of VEB - all the DMUX ap's belong to the same
                 * ceetm_id
                 * */
                idx = (dpdmux->ceetm_id == ap[0].ceetm_id) ? 0 : 1;

                /* allocate ceetm channels for mux interface */
				err = dpmng_connection_alloc_ceetm_channel(
						dpdmux->hndl.dpmng,
						&ap[idx].cqchid, ap[idx].dcp_id, ap[idx].ceetm_id,
						1);
				CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate ceetm channel\n", dpdmux->id);

                /* Copy dpdmux accesspoint */
                ifpid = iface->ap.ifpid; /* save temp */
                memcpy(&(iface->ap), &(ap[idx]),
                        sizeof(struct dpmng_accesspoint));
                iface->ap.ifpid = ifpid; /* restore ifp */
                iface->link_res_flags |= DPDMUX_LINKRES_CHANNEL_ALLOCATED;

                iface->num_lfq = 64;
				err = dpmng_connection_alloc_lfqmtidx(dpdmux->hndl.dpmng,
						iface->ap.lfqmtidx, iface->ap.dcp_id, iface->ap.ceetm_id, iface->num_lfq);
				iface->link_res_flags |= DPDMUX_LINKRES_LFQ_ALLOCATED;

                /* Allocate bandwidth for interface AP*/
               err = dpmng_connection_allocate_bandwidth(
                       dpdmux->hndl.dpmng,             /* Context */
                       &(iface->ap),                   /* Access point */
                       control->committed_rate);       /* Bandwidth */
               CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to allocate connection bandwidth %d\n", dpdmux->id, control->committed_rate);
               iface->link_res_flags |= DPDMUX_LINKRES_ALLOC_BW;

                /* Obtain AMQ */
                memset(&amq, 0x0, sizeof(struct dpmng_amq));
                dpmng_get_amq(&amq);

                /* connect accesspoint */
                err = ceetm_if_connect_accesspoint(
                	iface->ceetm_if,		/* ceetm interface */
                	&(iface->ap), 			/* accesspoint */
                	&amq);				/* security */
                CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to connect accespoint\n", dpdmux->id);
                iface->link_res_flags |= DPDMUX_LINKRES_AP_CONNECTED;

                /* associate accesspoint with lni */
                err = if_associate_with_lni(dpdmux, self->if_id, 0);
                CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to associate LNI\n", dpdmux->id);

                /* update qos mapping */
                err = if_set_tx_selection_qos_mapping(
                	dpdmux, 			/* context */
                	self->if_id, 			/* interface id */
                	peer->type);			/* peer type */
                CHECK_COND_RETVAL(err == 0, err, "ID[%d] Update qos mapping\n", dpdmux->id);

			/* allocate ceetm channels for dpni interface*/
			memset(channel_ids, 0, sizeof(channel_ids));
			err = dpmng_connection_alloc_ceetm_channel(dpdmux->hndl.dpmng,
					channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id,
					peer->num_channels);
			CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate %d ceetm channels", dpdmux->id, peer->num_channels);

			/* Copy  NIC's accesspoint */
			for( ceetm_ch_idx = 0 ; ceetm_ch_idx < peer->num_channels ; ceetm_ch_idx++ ) {
				memcpy(&(self->ap[ceetm_ch_idx]), &(ap[!idx]), sizeof(struct dpmng_accesspoint));
				self->ap[ceetm_ch_idx].cqchid = channel_ids[ceetm_ch_idx];
			}

                /* Indicate to peer */
				self->valid_fields |= LINKMAN_FIELD_AP_AVAILABLE;
				self->ap_available = 1;
        }

	/* Indicate to peer */
	self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
    self->allocate_cr = 1;		/* remote must allocate own lni bandwidth */
    peer->allocate_cr = 0;

        /* Indicate to peer IFP and dpdmux method */
	self->ifpid = iface->ap.ifpid;
	self->dpdmux_method = dpdmux->method; /* method */
	self->valid_fields |= LINKMAN_FIELD_IFPID
				| LINKMAN_FIELD_DPDMUX_METHOD;

	/*! save peer information */
	if ((peer->valid_fields & LINKMAN_FIELD_TID)
		&& (peer->valid_fields & LINKMAN_FIELD_KID)) {
		iface->kid = peer->kid;
		iface->tid = peer->tid;
		self->valid_fields |= LINKMAN_FIELD_TID | LINKMAN_FIELD_KID;
	} else
		return LINKMAN_ECONT;

	/* set next ifp */
	if ((peer->valid_fields & LINKMAN_FIELD_IFPID) != 0) {
		err = if_eiop_ifp_next(dpdmux, self->if_id, peer->ifpid);
		iface->next_ifpid = peer->ifpid;
	} else
		return LINKMAN_ECONT;

	/* enable ifp */
    err = if_eiop_ifp_tx_enable(dpdmux, self->if_id);
    CHECK_COND_RETVAL(err == 0, err);

    /* set zero taildrop for this interface when down */
	if_set_zero_taildrop(dpdmux, self->if_id);

    return err;
}

static int event_associate_virt(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        	*self,
        	const struct linkman_endpoint  	*peer,
        	const struct linkman_control   	*control,
        	struct linkman_action          	*action)
{

        int err = 0, idx, ifpid, lniid;
        struct dpdmux_if *iface, *ul_iface;;
        struct dpmng_accesspoint ap[2];
        struct dpmng_amq  amq;
		int channel_ids[DPMNG_MAX_CEETM_CH];
		int ceetm_ch_idx;
		int num_channels;

	/* Cet interface */
	iface = &(dpdmux->iface[self->if_id]);

	/* nothing to pass from mux side */
	self->valid_fields |= LINKMAN_FIELD_INIT;

	/* waiting for data to be passed from dpni side */
	if( (peer->valid_fields & LINKMAN_FIELD_INIT) == 0 ) {
		return LINKMAN_ECONT;
	}

	if( peer->num_channels==0 ) {
		pr_warn("ID[%d] Peer dpni did not iset number of channels, defaulting to 1\n", dpdmux->id);
		num_channels = 1;
	}
	else
		num_channels = peer->num_channels;

	if (!(self->valid_fields & LINKMAN_FIELD_AP_AVAILABLE)) {

		/* get accesspoint #1 */
		memset(&(ap[0]), 0x0, sizeof(struct dpmng_accesspoint));
		err = dpmng_connection_get_accesspoint(dpdmux->hndl.dpmng, /* dpmng context */
							iface->conn_id, /* connection id */
							0, /* ap index */
							control->committed_rate,
							&(ap[0]));
		CHECK_COND_RETVAL( err == 0, err, "ID[%d]\n Failed to get first accesspoint\n", dpdmux->id);

		/* get accesspoint #2 */
		memset(&(ap[1]), 0x0, sizeof(struct dpmng_accesspoint));
		err = dpmng_connection_get_accesspoint(dpdmux->hndl.dpmng, /* dpmng context */
							iface->conn_id, /* connection id */
							1, /* ap index */
							control->committed_rate,
							&(ap[1]));
		CHECK_COND_RETVAL( err == 0, err, "ID[%d]\n Failed to get second accesspoint\n", dpdmux->id);

		ul_iface = &(dpdmux->iface[DPDMUX_UL_INDEX]);

		/* in case of VEPA - all the NIC ap's belong to the same
		 * ceetm_id as the uplink
		 */
		idx = (ul_iface->ap.ceetm_id == ap[0].ceetm_id) ? 1 : 0;

		err = dpmng_connection_alloc_ceetm_channel(
						dpdmux->hndl.dpmng,
						&ap[idx].cqchid, ap[idx].dcp_id, ap[idx].ceetm_id,
						1);
		CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate ceetm channel\n", dpdmux->id);

		memset(channel_ids, 0, sizeof(channel_ids));
		err = dpmng_connection_alloc_ceetm_channel(
				dpdmux->hndl.dpmng,
				channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id,
				num_channels);
		if( err ) {
			dpmng_connection_free_ceetm_channel(dpdmux->hndl.dpmng,
					&ap[idx].cqchid, ap[idx].dcp_id, ap[idx].ceetm_id, 1);
		}
		CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate %d ceetm channels\n", dpdmux->id, num_channels);

		/* override the lniid with the uplink lniide */
		lniid = ul_iface->ap.lniid;

		/* Copy dmux accesspoint */
		ifpid = iface->ap.ifpid; /* save temp */
		memcpy(&(iface->ap), &(ap[idx]),
			sizeof(struct dpmng_accesspoint));
		iface->ap.ifpid = ifpid; /* restore ifp */
		iface->link_res_flags |= DPDMUX_LINKRES_CHANNEL_ALLOCATED;

		iface->num_lfq = 64;
		err = dpmng_connection_alloc_lfqmtidx(dpdmux->hndl.dpmng,
				iface->ap.lfqmtidx, iface->ap.dcp_id, iface->ap.ceetm_id, iface->num_lfq);
		iface->link_res_flags |= DPDMUX_LINKRES_LFQ_ALLOCATED;

		/* Allocate bandwidth for interface AP*/
		err = dpmng_connection_allocate_bandwidth(
				dpdmux->hndl.dpmng,             /* Context */
				&(iface->ap),                   /* Access point */
				control->committed_rate);       /* Bandwidth */
		if( err ) {
			dpmng_connection_free_ceetm_channel(dpdmux->hndl.dpmng,
					channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id, num_channels);
		}
		CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to allocate connection bandwidth %d\n", dpdmux->id, control->committed_rate);
		iface->link_res_flags |= DPDMUX_LINKRES_ALLOC_BW;

		/* Copy  NIC's accesspoint */
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < num_channels ; ceetm_ch_idx++ ) {
			memcpy(&(self->ap[ceetm_ch_idx]), &(ap[!idx]), sizeof(struct dpmng_accesspoint));
			self->ap[ceetm_ch_idx].cqchid = channel_ids[ceetm_ch_idx];
			/* copy the lniid to the NIC's ap -
			 * override the lniid value in case of VEPA*/
			self->ap[ceetm_ch_idx].lniid = lniid;
		}

	        /* Obtain AMQ */
	        memset(&amq, 0x0, sizeof(struct dpmng_amq));
	        dpmng_get_amq(&amq);

	        /* connect accesspoint */
	        err = ceetm_if_connect_accesspoint(
	            iface->ceetm_if,        /* ceetm interface */
	            &(iface->ap),           /* accesspoint */
	            &amq);              /* security */
			if( err ) {
				dpmng_connection_free_ceetm_channel(dpdmux->hndl.dpmng,
						channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id, num_channels);
			}
			CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to connect accespoint\n", dpdmux->id);
			iface->link_res_flags |= DPDMUX_LINKRES_AP_CONNECTED;

			/* associate accesspoint with lni */
	        err = if_associate_with_lni(dpdmux, self->if_id, 0);
	        if( err ) {
				dpmng_connection_free_ceetm_channel(dpdmux->hndl.dpmng,
						channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id, num_channels);
	        }
	        CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to associate LNI\n", dpdmux->id);

	        /* update qos mapping */
	        err = if_set_tx_selection_qos_mapping(
	                dpdmux,                         /* context */
	                self->if_id,                    /* interface id */
	                peer->type);                    /* peer type */
			if( err ) {
				dpmng_connection_free_ceetm_channel(dpdmux->hndl.dpmng,
						channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id, peer->num_channels);
            }
            CHECK_COND_RETVAL(err == 0, err, "ID[%d] Update qos mapping\n", dpdmux->id);

		/* Indicate to peer */
		self->valid_fields |= LINKMAN_FIELD_AP_AVAILABLE;
		self->ap_available = 1;

	}

	/* set zero taildrop for this interface when down */
	if_set_zero_taildrop(dpdmux, self->if_id);

	return err;
}

static int connect_virt_to_idle_uplink(struct dpdmux 		*dpdmux,
                                 	struct linkman_endpoint        	*self,
                                 	const struct linkman_endpoint  	*peer,
                                 	const struct linkman_control   	*control,
                                 	struct linkman_action          	*action)
{
        int err = LINKMAN_ECONT;
        struct dpdmux_if *iface;

	/* Obtain interface */
	iface = &(dpdmux->iface[self->if_id]);

    /* nothing to pass from mux side */
    self->valid_fields |= LINKMAN_FIELD_INIT;

    /* waiting for data to be passed from dpni side */
	if( (peer->valid_fields & LINKMAN_FIELD_INIT) == 0 ) {
		return LINKMAN_ECONT;
	}

        if ((self->valid_fields & LINKMAN_FIELD_CONN_ID) == 0) {

                /* Obtain virtual connection */
                err = dpmng_connection_virt_allocate(
                	dpdmux->hndl.dpmng,
                        &(iface->conn_id));
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags |= DPDMUX_LINKRES_CONNECTION_ALLOCATED;

                /* indicate connection has been taken */
                self->valid_fields |= LINKMAN_FIELD_CONN_ID;
        }

	/* Indicate to peer if to allocate committed rate only in case
	 * of VEB */
	self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
	self->allocate_cr = 0;

	/* Indicate to peer */
	self->valid_fields |= LINKMAN_FIELD_AP_AVAILABLE;
	self->ap_available = 0;

        /* Indicate to peer IFP and dpdmux method */
	self->ifpid = iface->ap.ifpid;
	self->dpdmux_method = dpdmux->method; /* method */
	self->valid_fields |= LINKMAN_FIELD_IFPID
				| LINKMAN_FIELD_DPDMUX_METHOD;

	/*! save peer information */
	if ((peer->valid_fields & LINKMAN_FIELD_TID)
		&& (peer->valid_fields & LINKMAN_FIELD_KID)) {
		iface->kid = peer->kid;
		iface->tid = peer->tid;
		self->valid_fields |= LINKMAN_FIELD_TID | LINKMAN_FIELD_KID;
	} else
		return LINKMAN_ECONT;

	/* set next ifp */
	if ((peer->valid_fields & LINKMAN_FIELD_IFPID) != 0) {
		err = if_eiop_ifp_next(dpdmux, self->if_id, peer->ifpid);
		iface->next_ifpid = peer->ifpid;
	} else
		return LINKMAN_ECONT;

	action->request = LINKMAN_REQUEST_CANDIDATE;

	/* set zero taildrop for this interface when down */
    if_set_zero_taildrop(dpdmux, self->if_id);

	return err;
}


static int connect_virt_to_linkup_uplink(
	struct dpdmux 		*dpdmux,
        struct linkman_endpoint        	*self,
        const struct linkman_endpoint  	*peer,
        const struct linkman_control   	*control,
        struct linkman_action          	*action)
{
        int err = 0, idx, ifpid, lniid;
        struct dpdmux_if *iface, *ul_iface;
        struct dpmng_accesspoint ap[2];
        struct dpmng_amq  	amq;
        int channel_ids[DPMNG_MAX_CEETM_CH];
        int ceetm_ch_idx;

	/* Get the interface */
	iface = &(dpdmux->iface[self->if_id]);

	/* nothing to pass from mux side */
	self->valid_fields |= LINKMAN_FIELD_INIT;

	/* waiting for data to be passed from dpni side */
	if( (peer->valid_fields & LINKMAN_FIELD_INIT) == 0 ) {
		return LINKMAN_ECONT;
	}

	CHECK_COND_RETVAL( peer->num_channels != 0, -EINVAL, "ID[%d] Peer dpni did not set number of channels\n");

        if ((self->valid_fields & LINKMAN_FIELD_CONN_ID) == 0) {

                /* Obtain virtual connection */
                err = dpmng_connection_virt_allocate(
                	dpdmux->hndl.dpmng,
                        &(iface->conn_id));
                CHECK_COND_RETVAL(err == 0, err);
                iface->link_res_flags |= DPDMUX_LINKRES_CONNECTION_ALLOCATED;

                /* indicate connection has been taken */
                self->valid_fields |= LINKMAN_FIELD_CONN_ID;
        }

	if (!(self->valid_fields & LINKMAN_FIELD_AP_AVAILABLE)) {

		/* get accesspoint #1 */
		memset(&(ap[0]), 0x0, sizeof(struct dpmng_accesspoint));
		err = dpmng_connection_get_accesspoint(dpdmux->hndl.dpmng, /* dpmng context */
							iface->conn_id, /* connection id */
							0, /* ap index */
							control->committed_rate,
							&(ap[0]));
		CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to get first accesspoint\n", dpdmux->id);

		/* get accesspoint #2 */
		memset(&(ap[1]), 0x0, sizeof(struct dpmng_accesspoint));
		err = dpmng_connection_get_accesspoint(dpdmux->hndl.dpmng, /* dpmng context */
							iface->conn_id, /* connection id */
							1, /* ap index */
							control->committed_rate,
							&(ap[1]));
		CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to get second accesspoint\n");

		ul_iface = &(dpdmux->iface[DPDMUX_UL_INDEX]);

		/* in case of VEPA - all the NIC ap's belong to the same
		 * ceetm_id as the uplink
		 */
		idx = (ul_iface->ap.ceetm_id == ap[0].ceetm_id) ? 1 : 0;

		err = dpmng_connection_alloc_ceetm_channel(
				dpdmux->hndl.dpmng,
				&ap[idx].cqchid, ap[idx].dcp_id, ap[idx].ceetm_id,
				1);
		CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate ceetm channel\n", dpdmux->id);

		/* override the lniid with the uplink lniide */
		lniid = ul_iface->ap.lniid;

		/* Copy dmux accesspoint */
		ifpid = iface->ap.ifpid; /* save temp */
		memcpy(&(iface->ap), &(ap[idx]),
			sizeof(struct dpmng_accesspoint));
		iface->ap.ifpid = ifpid; /* restore ifp */
		iface->link_res_flags |= DPDMUX_LINKRES_CHANNEL_ALLOCATED;

		iface->num_lfq = 64;
		err = dpmng_connection_alloc_lfqmtidx(dpdmux->hndl.dpmng,
				iface->ap.lfqmtidx, iface->ap.dcp_id, iface->ap.ceetm_id, iface->num_lfq);
		iface->link_res_flags |= DPDMUX_LINKRES_LFQ_ALLOCATED;

                /* Allocate bandwidth */
                err = dpmng_connection_allocate_bandwidth(
                        dpdmux->hndl.dpmng,             /* Context */
                        &(iface->ap),                   /* Access point */
                        control->committed_rate);       /* Bandwidth */
                CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to allocate connection bandwidth %d\n", dpdmux->id, control->committed_rate);
                iface->link_res_flags |= DPDMUX_LINKRES_ALLOC_BW;

                /* Obtain AMQ */
                memset(&amq, 0x0, sizeof(struct dpmng_amq));
                dpmng_get_amq(&amq);

                /* connect accesspoint */
                err = ceetm_if_connect_accesspoint(
                    iface->ceetm_if,        /* ceetm interface */
                    &(iface->ap),           /* accesspoint */
                    &amq);              /* security */
				CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to connect accespoint\n", dpdmux->id);
				iface->link_res_flags |= DPDMUX_LINKRES_AP_CONNECTED;

                /* associate accesspoint with lni */
                err = if_associate_with_lni(dpdmux, self->if_id, 0);
				CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to associate LNI\n", dpdmux->id);

                /* update qos mapping */
                err = if_set_tx_selection_qos_mapping(
                        dpdmux,                         /* context */
                        self->if_id,                    /* interface id */
                        peer->type);                    /* peer type */
                CHECK_COND_RETVAL(err == 0, err, "ID[%d] Update qos mapping\n", dpdmux->id);

		memset(channel_ids, 0, sizeof(channel_ids));
		err = dpmng_connection_alloc_ceetm_channel(dpdmux->hndl.dpmng,
				channel_ids, ap[!idx].dcp_id, ap[!idx].ceetm_id,
				peer->num_channels);
		CHECK_COND_RETVAL( err == 0, err, "ID[%d] Failed to allocate %d ceetm channels", dpdmux->id, peer->num_channels);

		/* Copy  NIC's accesspoint */
		for( ceetm_ch_idx = 0 ; ceetm_ch_idx < peer->num_channels ; ceetm_ch_idx++ ) {
			memcpy(&(self->ap[ceetm_ch_idx]), &(ap[!idx]), sizeof(struct dpmng_accesspoint));
			self->ap[ceetm_ch_idx].cqchid = channel_ids[ceetm_ch_idx];
			/* copy the lniid to the NIC's ap -
			 * override the lniid value in case of VEPA*/
			self->ap[ceetm_ch_idx].lniid = lniid;
		}

		/* Indicate to peer */
		self->valid_fields |= LINKMAN_FIELD_AP_AVAILABLE;
		self->ap_available = 1;
	}

	/* Indicate to peer if to allocate committed rate only in case
	 * of VEB */
	self->valid_fields |= LINKMAN_FIELD_ALLOCATE_CR;
	self->allocate_cr = 0;

        /* Indicate to peer IFP and dpdmux method */
	self->ifpid = iface->ap.ifpid;
	self->dpdmux_method = dpdmux->method; /* method */
	self->valid_fields |= LINKMAN_FIELD_IFPID
				| LINKMAN_FIELD_DPDMUX_METHOD;

	/*! save peer information */
	if ((peer->valid_fields & LINKMAN_FIELD_TID)
		&& (peer->valid_fields & LINKMAN_FIELD_KID)) {
		iface->kid = peer->kid;
		iface->tid = peer->tid;
		self->valid_fields |= LINKMAN_FIELD_TID | LINKMAN_FIELD_KID;
	} else
		return LINKMAN_ECONT;

	/* set next ifp */
	if ((peer->valid_fields & LINKMAN_FIELD_IFPID) != 0) {
		err = if_eiop_ifp_next(dpdmux, self->if_id, peer->ifpid);
		iface->next_ifpid = peer->ifpid;
	} else
		return LINKMAN_ECONT;
	
	/* enable ifp */
    err = if_eiop_ifp_tx_enable(dpdmux, self->if_id);
    CHECK_COND_RETVAL(err == 0, err);

    /* set zero taildrop for this interface when down */
	if_set_zero_taildrop(dpdmux, self->if_id);

    return err;
}

static int vepa_event_connect_virt(struct dpdmux 		*dpdmux,
        	struct linkman_endpoint        	*self,
        	const struct linkman_endpoint  	*peer,
        	const struct linkman_control   	*control,
        	struct linkman_action          	*action)
{
        int err = LINKMAN_ECONT;
	struct linkman_endpoint ep1, ep2;
	struct linkman_connection_attr	connection_attr;

	/*! init endpoints */
	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));

	/*! Endpoint information */
	ep1.type = FSL_MOD_DPDMUX;
	ep1.id = (uint16_t)dpdmux->id;
	ep1.if_id = DPDMUX_UL_INDEX;

	/*! get uplink state */
	err = linkman_get_connection(
		dpdmux->hndl.linkman,
		&ep1,
		&ep2,
		&connection_attr);
	CHECK_COND_RETVAL(err == 0, err, "ID[%d] Failed to get connection\n");

	/* check the following states that are valid in case of uplink */
	switch (connection_attr.state) {
		case LINKMAN_STATE_IDLE:
			err = connect_virt_to_idle_uplink(dpdmux,
			                            self,
			                            peer,
			                            control,
			                            action);
			break;
		case LINKMAN_STATE_CONNECTED:
		case LINKMAN_STATE_NEGOTIATION:
		case LINKMAN_STATE_LINKUP:
			err = connect_virt_to_linkup_uplink(dpdmux,
				                            self,
				                            peer,
				                            control,
				                            action);
			break;
		case LINKMAN_STATE_CANDIDATE:
		case LINKMAN_STATE_INVALID:
		default:
		        return -EACCES;
	}

	/* set zero taildrop for this interface when down */
    if_set_zero_taildrop(dpdmux, self->if_id);

	return err;
}

static int event_virt(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = LINKMAN_ECONT;
	struct dpdmux 		*dpdmux;

	dpdmux = (struct dpdmux *)handle;

	switch (control->event) {
		case LINKMAN_EVENT_CONNECT:
			if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN)
				err = veb_event_connect_virt(
					handle, self, peer, control, action);
			else
				err = vepa_event_connect_virt(
					handle, self, peer, control, action);
			break;
		case LINKMAN_EVENT_DISCONNECT:
			if (dpdmux->options & DPDMUX_OPT_BRIDGE_EN)
				err = veb_event_disconnect_virt(
					handle, self, peer, action);
			else
				err = vepa_event_disconnect_virt(
					handle, self, peer, control, action);
			break;
		case LINKMAN_EVENT_LINKUP:
			/* link up */
				err = event_linkup_virt(
					handle, self, peer, control, action);
			break;
		case LINKMAN_EVENT_LINKDOWN:
			/* link down */
				err = event_linkdown_virt(
					handle, self, peer, control, action);
			break;
		case LINKMAN_EVENT_ASSOCIATE:
			if (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN))
				err = event_associate_virt(
					handle, self, peer, control, action);
			break;
		case LINKMAN_EVENT_DEASSOCIATE:
			if (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN))
				err = event_deassociate_virt(
					handle, self, peer, control, action);
			break;
		default:
			err = -ENOTSUP; /* Operation not supported */
			break;
        }
        return err;
}


/* NEW LINKMAN */
int dpdmux_event_cb(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
        int err;

        /* Verify end-point integrity */
        err = endpoint_integrity(handle, self);
        CHECK_COND_RETVAL(err == 0, err);

        switch (peer->type) {
        	case FSL_MOD_DPMAC:
        		err = event_phys(handle, control, self, peer, action);
        		break;
        	case FSL_MOD_DPNI:
        		err = event_virt(handle, control, self, peer, action);
        		break;
        	default:
        		err = -ENOTSUP; /* Operation not supported */
        		break;
        }
        return err;
}

int dpdmux_event_complete_cb(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action)
{
	int err = 0;
	struct dpdmux 		*dpdmux;
	uint16_t event = 0;

	dpdmux = (struct dpdmux *)handle;

        /* Verify self end point integrity */
        err = endpoint_integrity(handle, self);
        CHECK_COND_RETVAL(err == 0, err);

	switch(control->event) {
		case LINKMAN_EVENT_CONNECT:
		        if (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN))
				err = event_completed_uplink(handle, self, peer,
								LINKMAN_EVENT_ASSOCIATE);
			event |= DPDMUX_IRQ_EVENT_LINK_CHANGED | DPDMUX_IRQ_EVENT_ENDPOINT_CHANGED;
			break;
		case LINKMAN_EVENT_DISCONNECT:
		    if (!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN))
				err = event_completed_uplink(handle, self, peer,
							LINKMAN_EVENT_DEASSOCIATE);
			event |= DPDMUX_IRQ_EVENT_LINK_CHANGED | DPDMUX_IRQ_EVENT_ENDPOINT_CHANGED;

			/* update maximum frame length according to remaining connected dpni and allow function to return SUCCESS */
			err = dpdmux_update_uplink_max_frame_len(dpdmux);
			CHECK_COND_RETVAL(err==0, 0, "dpdmux_update_uplink_max_frame_len() return error");
			break;
		case LINKMAN_EVENT_NEGOTIATION_OK:
		case LINKMAN_EVENT_LINKUP:
		        if ((self->if_id == DPDMUX_UL_INDEX) &&
		        	(!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN))) {

		        	err = event_completed_uplink(handle, self, peer,
		        				LINKMAN_EVENT_LINKUP);
		        }
			event |= DPDMUX_IRQ_EVENT_LINK_CHANGED;
			break;
		case LINKMAN_EVENT_LINKDOWN:
		        if ((self->if_id == DPDMUX_UL_INDEX) &&
		        	(!(dpdmux->options & DPDMUX_OPT_BRIDGE_EN))) {
		        	err = event_completed_uplink(handle, self, peer,
							LINKMAN_EVENT_LINKDOWN);
		        }
			event |= DPDMUX_IRQ_EVENT_LINK_CHANGED;
			break;
		case LINKMAN_EVENT_NEGOTIATION_FAIL:
		case LINKMAN_EVENT_NEGOTIATION:
		case LINKMAN_EVENT_ASSOCIATE:
		case LINKMAN_EVENT_DEASSOCIATE:
		default:
			event |= DPDMUX_IRQ_EVENT_LINK_CHANGED;
		        break;
	}

	/* trigger irq */
	irq_if_trigger(handle, self->if_id, event);

	return err;
}



static void irq_if_trigger(struct dpdmux *dpdmux,
	uint16_t if_id, uint16_t event)
{
	uint32_t message, status = 0;
	struct mc_irq *irq;

	/* Get IRQ */
	irq = &(dpdmux->irqs[DPDMUX_IRQ_INDEX_IF]);

	/* Check IRQ status */
	mc_get_irq_status(irq, &status);

	if (status == 0) {
		/* Compose message */
		message = irq_if_compose_message(dpdmux, if_id, event);

		/* Send event */
		event_send(irq, message);
	} else
		irq_if_save_event(dpdmux, if_id, event);
}

static uint32_t irq_if_compose_message(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t event)
{
        return ((((uint32_t)if_id) << 16) | ((uint32_t)event));
}

static int irq_get_pending_if(struct dpdmux *dpdmux, uint16_t *if_id)
{
	uint16_t i;
	int pending = 0;

	for (i = 0; i < dpdmux->num_ifs; i++) {
		if (dpdmux->iface[i].irq.pending == 1) {
			*if_id = i;
			pending = 1;
			break;
		}
	}
	return pending;
}

static uint16_t irq_if_restore_event(struct dpdmux *dpdmux, uint16_t if_id)
{
	struct dpdmux_irq *irq;

	/* Obtain interface */
	irq = &(dpdmux->iface[if_id].irq);

	/* Clear pending */
	irq->pending = 0;

	return irq->event;
}

static void irq_if_save_event(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t event)
{
	struct dpdmux_irq *irq;

	/* Obtain interface */
	irq = &(dpdmux->iface[if_id].irq);

	/* Clear pending */
	irq->pending = 1;

	/* Save */
	irq->event = event;
}

static int init_default(struct dpdmux *dpdmux)
{
	int err = 0;

	err = init_deafult_ceetm_if(dpdmux);

	return err;
}

static int if_associate_with_lni(struct dpdmux *dpdmux,
	uint16_t if_id, int shaped)
{
	int err;
	uint32_t ceetmid;
	void *swp;
	struct dpmng_accesspoint *ap;

	ap = &(dpdmux->iface[if_id].ap);

	/*! Compose CEETM */
	ceetmid = qbman_ceetmid_compose((uint8_t)ap->dcp_id,
					(uint8_t)ap->ceetm_id);

	/* Get software portal */
	err = dpmng_get_swportal(dpdmux->hndl.dpmng, &(swp));
	CHECK_COND_RETVAL(err == 0, err);

	err = qbman_cchannel_configure(swp, /* SW Portal */
					ceetmid, /* Composed CEETM ID */
					(uint8_t)ap->cqchid, /* Channel ID */
					(uint8_t)ap->lniid, /* LNI ID */
					shaped); /* shaped/un-shaped */

	return err;
}

static int virt_link_rates(
        const struct linkman_endpoint   *ep1,
        const struct linkman_endpoint   *ep2,
        const struct linkman_control   *control,
        struct linkman_link_state       *link_state,
        uint32_t *max_rate)
{
        int err = 0;
        int shaped;

        shaped = is_virt_connection_shaped(control);
        if (shaped == 1) {
                /* Calculate link state */
                err = link_state_common_denominator(
                        ep1, ep2,
                        control->committed_rate,
                        link_state);
                CHECK_COND_RETVAL(err == 0, err, "link_state_common_denominator() failed");

                *max_rate = (link_state->options & LINKMAN_LINK_OPT_AUTONEG) ?
                        control->max_rate : link_state->rate;
        }
        else {
                link_state->rate = 0;
                link_state->options = 0;
                *max_rate = (uint32_t)soc_db_get_recycle_port_bandwidth();
        }

        return err;
}

static int init_ceetm_if(struct dpdmux  *dpdmux, uint16_t if_id)
{
	int 			err = 0, i;
	struct dpdmux_if	*iface;
	struct ceetm_if_cfg 	ceetm_cfg;
	struct dpmng_dev_cfg 	dev_cfg;

	/* obtain ceetm interface */
	iface = &(dpdmux->iface[if_id]);

	/* init device configuration */
	memset(&dev_cfg, 0x0, sizeof(struct dpmng_dev_cfg));
	dev_cfg.device = dpdmux->hndl.dprc;
	dev_cfg.id = (uint16_t)dpdmux->id;

	/* init ceetm configuration */
	memset(&ceetm_cfg, 0x0, sizeof(struct ceetm_if_cfg));
	ceetm_cfg.num_qdbin = 1;
	ceetm_cfg.num_qpri = DPDMUX_MAX_PRI + 1;	/* priority + ctrl */
	ceetm_cfg.lfqid = dpmng_get_rtn_fqid(dpdmux->hndl.dpmng);

	for (i = 0; i < DPDMUX_MAX_PRI; i++) {
		ceetm_cfg.qpri[i].in_use = 1;		/* priority in use */
	}

	/* create ceetm interface */
	iface->ceetm_if = ceetm_if_create(&ceetm_cfg, &dev_cfg);
	CHECK_COND_RETVAL(iface->ceetm_if, -ENOMEM);

	return err;
}

static int init_deafult_ceetm_if(struct dpdmux  *dpdmux)
{
	int err = 0;

	err = init_default_ceetm_if_tx_selection(dpdmux);
	CHECK_COND_RETVAL(err == 0, err);

	err = init_default_ceetm_if_early_drop(dpdmux);

	return err;
}

static int init_default_ceetm_if_tx_selection(struct dpdmux  *dpdmux)
{
	int err = 0;
	uint16_t i;
	struct dpdmux_tx_selection_cfg  trans_select;

	/* reset configuration parameters */
	memset(&trans_select, 0x0, sizeof(struct dpdmux_tx_selection_cfg));

	/* Strict priority method */
	trans_select.tc_sched[0].mode = DPDMUX_SCHED_STRICT_PRIORITY;
	trans_select.tc_sched[1].mode = DPDMUX_SCHED_STRICT_PRIORITY;
	trans_select.tc_sched[2].mode = DPDMUX_SCHED_STRICT_PRIORITY;
	trans_select.tc_sched[3].mode = DPDMUX_SCHED_STRICT_PRIORITY;

	/* All priorities mapped to traffic class 7 (highest) */
	trans_select.tc_id[0] = 0x0;
	trans_select.tc_id[1] = 0x0;
	trans_select.tc_id[2] = 0x1;
	trans_select.tc_id[3] = 0x1;
	trans_select.tc_id[4] = 0x2;
	trans_select.tc_id[5] = 0x2;
	trans_select.tc_id[6] = 0x3;
	trans_select.tc_id[7] = 0x3;

	for (i = 0; i < dpdmux->num_ifs; i++) {
		err = dpdmux_if_set_tx_selection(dpdmux, i, &trans_select);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int init_default_ceetm_if_early_drop(struct dpdmux  *dpdmux)
{
	int err = 0;
	struct dpdmux_early_drop_cfg 	drop;
	struct dpdmux_if	*iface;
	uint16_t i;

	memset(&drop, 0x0, sizeof(struct dpdmux_early_drop_cfg));

	/* configure lossy traffic */
	drop.drop_mode = DPDMUX_EARLY_DROP_MODE_NONE;
	drop.units = DPDMUX_EARLY_DROP_UNIT_BUFFERS;
	drop.tail_drop_threshold = DPDMUX_TAIL_DROP_THRESHOLD;

	for (i = 0; i < dpdmux->num_ifs; i++) {
		err = dpdmux_if_tc_set_early_drop(
			dpdmux,
			i,
			DPDMUX_TAIL_DROP_CCGIDX,
			&drop);
		CHECK_COND_RETVAL(err == 0, err);
	}

	/* Configure lossless traffic */
	drop.drop_mode = DPDMUX_EARLY_DROP_MODE_NONE;

	for (i = 0; i < dpdmux->num_ifs; i++) {
		err = dpdmux_if_tc_set_early_drop(
			dpdmux,
			i,
			DPDMUX_BUFFER_DEPLETION_CCGIDX,
			&drop);
		CHECK_COND_RETVAL(err == 0, err);
	}

	/* store internal drop configuration */
	for (i = 0; i < dpdmux->num_ifs; i++) {
		iface = &(dpdmux->iface[i]);
		iface->drop_cfg.drop_mode = drop.drop_mode;
		iface->drop_cfg.units = drop.units;
		iface->drop_cfg.tail_drop_threshold = drop.tail_drop_threshold;
	}

	return err;
}

static int if_set_zero_taildrop(struct dpdmux  *dpdmux, int if_id)
{
	int err = 0;
	struct dpdmux_early_drop_cfg 	drop;
	struct dpdmux_if	*iface;

	if( if_id == DPDMUX_UL_INDEX ) /* for now do not perform this for UL interface */
		return 0;

	iface = &(dpdmux->iface[if_id]);

	memset(&drop, 0x0, sizeof(struct dpdmux_early_drop_cfg));

	/* configure lossy traffic */
	drop.drop_mode = DPDMUX_EARLY_DROP_MODE_TAIL;
	drop.units = DPDMUX_EARLY_DROP_UNIT_BUFFERS;
	drop.tail_drop_threshold = 0;

	err = dpdmux_if_tc_set_early_drop(
			dpdmux,
			(uint16_t)if_id,
			DPDMUX_TAIL_DROP_CCGIDX,
			&drop);
		CHECK_COND_RETVAL(err == 0, err);

	/* Configure lossless traffic */
	drop.drop_mode = DPDMUX_EARLY_DROP_MODE_TAIL;

	err = dpdmux_if_tc_set_early_drop(
			dpdmux,
			(uint16_t)if_id,
			DPDMUX_BUFFER_DEPLETION_CCGIDX,
			&drop);
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}


static int if_restore_taildrop(struct dpdmux  *dpdmux, int if_id)
{
	int err = 0;
	struct dpdmux_early_drop_cfg 	drop;
	struct dpdmux_if	*iface;

	if( if_id == DPDMUX_UL_INDEX ) /* for now do not perform this for UL interface */
		return 0;

	iface = &(dpdmux->iface[if_id]);

	memset(&drop, 0x0, sizeof(struct dpdmux_early_drop_cfg));

	/* configure lossy traffic */
	err = dpdmux_if_tc_set_early_drop(
			dpdmux,
			(uint16_t)if_id,
			DPDMUX_TAIL_DROP_CCGIDX,
			&iface->drop_cfg);
		CHECK_COND_RETVAL(err == 0, err);

	/* Configure lossless traffic */
	drop.drop_mode = DPDMUX_EARLY_DROP_MODE_NONE;
	drop.units = DPDMUX_EARLY_DROP_UNIT_BUFFERS;
	drop.tail_drop_threshold = DPDMUX_TAIL_DROP_THRESHOLD;

	err = dpdmux_if_tc_set_early_drop(
			dpdmux,
			(uint16_t)if_id,
			DPDMUX_BUFFER_DEPLETION_CCGIDX,
			&drop);
	CHECK_COND_RETVAL(err == 0, err);

	return err;
}


int dpdmux_if_set_tx_selection(struct dpdmux *dpdmux, uint16_t if_id,
	const struct dpdmux_tx_selection_cfg *ts)
{
	int err = 0;
	struct linkman_endpoint ep;
	struct linkman_connection_attr attr;

	/* verify parameters validity */
	err = if_set_tx_selection_params_integrity(dpdmux, if_id, ts);
	CHECK_COND_RETVAL(err == 0, err);

	/* Save configuration */
	err = if_set_tx_selection_params_save(dpdmux, if_id, ts);
	CHECK_COND_RETVAL(err == 0, err);

	/* configure ceetm interface */
	err = if_set_tx_selection_ccqs(dpdmux, if_id);
	CHECK_COND_RETVAL(err == 0, err);

	/* Obtain connection */
	err = get_connection(dpdmux, if_id, &ep, &attr);
	CHECK_COND_RETVAL(err == 0, err);

	/* Is interface connected? */
	if ((attr.state != LINKMAN_STATE_IDLE) &&
		(attr.state != LINKMAN_STATE_CANDIDATE)) {
		/* Qos Mapping */
		err = if_set_tx_selection_qos_mapping(dpdmux, if_id, ep.type);
		CHECK_COND_RETVAL(err == 0, err);
	}
	return err;
}

static int if_set_tx_selection_params_integrity(
	struct dpdmux  *dpdmux,
	uint16_t if_id,
        const struct dpdmux_tx_selection_cfg *ts)
{
        int err = 0, i;
        uint8_t	tc_id;

        if (if_id >= dpdmux->num_ifs)
                return -EINVAL;

        for (i = 0; i < DPDMUX_MAX_PRI; i++) {
        	/* obtain traffic class */
        	tc_id = ts->tc_id[i];

        	/* traffic class is in range */
                if (tc_id >= DPDMUX_MAX_TC)
                        return -EINVAL;

                if (ts->tc_sched[tc_id].mode == DPDMUX_SCHED_STRICT_PRIORITY)
                	continue;

                /* Check lower bound */
		if (ts->tc_sched[tc_id].delta_bandwidth < SCHED_LOWER_BOUND)
			return -EINVAL;

		/* check upper bound */
		if (ts->tc_sched[tc_id].delta_bandwidth > SCHED_UPPER_BOUND)
			return -EINVAL;
        }
	return err;
}

static int if_set_tx_selection_params_save(
	struct dpdmux  *dpdmux,
	uint16_t if_id,
        const struct dpdmux_tx_selection_cfg *ts)
{
	int err = 0;
	struct dpdmux_tx_selection_cfg *tx_sel;

	/* Obtain transmission selection configuration */
	tx_sel = &(dpdmux->iface[if_id].tx_sel);

	/* Copy transmission selection configuration */
	memcpy(tx_sel, ts, sizeof(struct dpdmux_tx_selection_cfg));

	return err;
}

static int if_set_tx_selection_ccqs(
	struct dpdmux  *dpdmux,
	uint16_t if_id)
{
/*
 * 	- create a local map of an existing traffic classes
 * 	- init priority to class fixed queue mapping
 * 	- go over all traffic classes (0-3) for physical
 * 	- go over all traffic classes (0-3) for virtual
 * */

	int 				err = 0, i, ccqidx, tcidx;
	struct ceetm_if 		*ceetm_if;
	struct ceetm_if_ccqs_cfg 	ccqs;
	struct dpdmux_tx_selection_cfg	*tx_sel;
	uint8_t pps = QBMAN_PFDR_POOL_BASE;	// PFDR pool select
	struct qbman_desc qbman_desc;
	int iter = 0, ps = 0;

	memset(&qbman_desc, 0, sizeof(qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, &iter);
	if (err) {
		pr_err("Could not obtain QBMAN descriptor\n");
		return err;
	}
	if( qbman_desc.multiple_pfdr_support ) {
		pps = QBMAN_PFDR_POOL_PEB;
		ps = !pps;
	} else
		ps = qbman_cacheable_pfdr();

	/* obtain ceetm interface */
	ceetm_if = dpdmux->iface[if_id].ceetm_if;

	/* obtain transmission selection configuration */
	tx_sel = &(dpdmux->iface[if_id].tx_sel);

	/* reset ceetm configuration */
	memset(&ccqs, 0x0, sizeof(struct ceetm_if_ccqs_cfg));

	for (i = 0, tcidx = 0; i < DPDMUX_MAX_PRI/2; i++, tcidx++) {
		ccqidx = ccqs.ccqidx[i] = (uint8_t) (i * 2);

		ccqs.ccq[ccqidx].ccgidx = DPDMUX_TAIL_DROP_CCGIDX;
		ccqs.ccq[ccqidx].delta_bandwidth =
			tx_sel->tc_sched[tcidx].delta_bandwidth;
		ccqs.ccq[ccqidx].pps = pps;
		ccqs.ccq[ccqidx].ps = ps;
		ccqs.ccq[ccqidx].mode =
			get_schedule_mode(tx_sel->tc_sched[tcidx].mode);
	}

	for (i = DPDMUX_MAX_PRI/2, tcidx = 0;
		i < DPDMUX_MAX_PRI; i++, tcidx++) {
		ccqidx = ccqs.ccqidx[i] = (uint8_t)((i - DPDMUX_MAX_TC) * 2 + 1);

		ccqs.ccq[ccqidx].ccgidx = DPDMUX_TAIL_DROP_CCGIDX;
		ccqs.ccq[ccqidx].delta_bandwidth =
			tx_sel->tc_sched[tcidx].delta_bandwidth;
		ccqs.ccq[ccqidx].pps = pps;
		ccqs.ccq[ccqidx].ps = ps;
		ccqs.ccq[ccqidx].mode =
			get_schedule_mode(tx_sel->tc_sched[tcidx].mode);
	}

	/* configure ceetm interface */
	err = ceetm_if_ccqs_configure(ceetm_if, &ccqs);

	return err;
}

static enum ceetm_if_sched_mode get_schedule_mode(
	enum dpdmux_schedule_mode mode)
{
	enum ceetm_if_sched_mode ceetm_if_mode = CEETM_IF_SCHED_STRICT_PRIORITY;

	/* translate scheduling mode */
	switch (mode) {
		case DPDMUX_SCHED_STRICT_PRIORITY:
			ceetm_if_mode = CEETM_IF_SCHED_STRICT_PRIORITY;
			break;
		case DPDMUX_SCHED_WEIGHTED:
			ceetm_if_mode = CEETM_IF_SCHED_WEIGHTED;
			break;
		default:
			break;
	}
	return ceetm_if_mode;
}

/* called from connect and dpdmux_if_set_tx_selection */
static int if_set_tx_selection_qos_mapping(
	struct dpdmux  *dpdmux,
	uint16_t if_id,
	enum fsl_module type)
{
	int err = 0, i;
	struct dpdmux_tx_selection_cfg *tx_sel;
	struct dpqos_rule 		rule;
	struct dpqos_action 		action;
	struct dpqos			*dpqos;	/* QoS Mapping handler */

	/* Obtain transmission selection */
	tx_sel = &(dpdmux->iface[if_id].tx_sel);

	/* Obtain QoS mapping handler */
	dpqos = dpdmux->iface[if_id].dpqos;

	/* Reset database */
	memset(&rule, 0x0, sizeof(struct dpqos_rule));
	memset(&action, 0x0, sizeof(struct dpqos_action));

	/* VPRI QoS mapping */
	rule.method = DPQOS_METHOD_BASED_ON_VLAN;
	action.options = DPQOS_ACTION_SET_QPRI;
	action.next_action = DPQOS_ACTION_DONE;

	for (i = 0; i < DPDMUX_MAX_PRI; i++) {
		/* Set QoS mapping */
		rule.priority = i;
		action.qpri = (type == FSL_MOD_DPMAC) ?
			tx_sel->tc_id[i] :
			(tx_sel->tc_id[i] + DPDMUX_MAX_PRI/2);

		/* add an entry */
		err = dpqos_add_rule(dpqos, &rule, &action);
		if (err == -EEXIST) {
			err = dpqos_modify_rule(dpqos, &rule, &action);
		}
		if (err != 0)
			break;
	}
	return err;
}

static int get_connection(
	struct dpdmux  *dpdmux,
	uint16_t if_id,
	struct linkman_endpoint *ep,
	struct linkman_connection_attr *attr)
{
	int 				err;
	struct linkman_endpoint 	dmux_ep;

	/* Init DMux endpoint */
	memset(&dmux_ep, 0x0, sizeof(struct linkman_endpoint));
	dmux_ep.type = FSL_MOD_DPDMUX;
	dmux_ep.id = (uint16_t)dpdmux->id;
	dmux_ep.if_id = if_id;

	/* Obtain connection */
	err = linkman_get_connection(
		dpdmux->hndl.linkman,	/* context */
	        &dmux_ep,		/* DMux endpoint */
	        ep,			/* remote endpoint */
	        attr);			/* link attributes */

	return err;
}

int dpdmux_if_tc_set_early_drop(struct dpdmux *dpdmux,
                        uint16_t if_id,
                        uint8_t ccgidx,
                        const struct dpdmux_early_drop_cfg *drop_cfg)
{
	/*
	*       - Verify parameters integrity
	*       - set_early_drop -> int ceetm_if_ccgs_configure()
	*/
	int err = 0;

	err = if_set_early_drop_params_integrity(dpdmux, if_id, ccgidx, drop_cfg);
	CHECK_COND_RETVAL(err == 0, err);

        /* update ceetm if */
        err = if_set_early_drop(dpdmux, if_id, ccgidx, drop_cfg);

        return err;
}

static int if_set_early_drop_params_integrity(struct dpdmux *dpdmux,
                        uint16_t if_id,
                        uint8_t ccgidx,
                        const struct dpdmux_early_drop_cfg *drop_cfg)
{
	int err = 0;

	if (if_id >= dpdmux->num_ifs)
                return -EINVAL;

	/* traffic class is in range */
	if (ccgidx >= DPDMUX_MAX_TC)
		return -EINVAL;

	return err;
}

static int if_set_early_drop(struct dpdmux *dpdmux,
                        uint16_t if_id,
                        uint8_t ccgidx,
                        const struct dpdmux_early_drop_cfg *drop)
{
	int 			err = 0;
	struct ceetm_if 	*ceetm_if;
	struct ceetm_if_ccg_cfg ccg;

	/* Obtain interface */
	ceetm_if = dpdmux->iface[if_id].ceetm_if;

	/* build configuration */
	memset(&ccg, 0x0, sizeof(struct ceetm_if_ccg_cfg));
	ccg.units = get_early_drop_unit(drop->units);
	ccg.mode = get_early_drop_mode(drop->drop_mode);
	
	if (drop->units == DPDMUX_EARLY_DROP_UNIT_BUFFERS)
	{
		/*Buffers unit are transformed to memory footprint in Qman
		 * MEM footprint is indicated in 64byte units
		 * and dpdmux buffer size is 254 then the vale
		 * should be multiplied by 4
		 */
		ccg.tail_drop_threshold = drop->tail_drop_threshold * 
								(DPDMUX_BP_BUFFER_SIZE/64);
	}
	else
	{
		/* tail drop */
		ccg.tail_drop_threshold = drop->tail_drop_threshold;
	}

	/* wred green */
	ccg.green.drop_probability = drop->green.drop_probability;
	ccg.green.max_threshold = drop->green.max_threshold;
	ccg.green.min_threshold = drop->green.min_threshold;

	/* wred yellow */
	ccg.yellow.drop_probability = drop->yellow.drop_probability;
	ccg.yellow.max_threshold = drop->yellow.max_threshold;
	ccg.yellow.min_threshold = drop->yellow.min_threshold;

	/* configure ceetm interface */
	err = ceetm_if_ccg_configure(ceetm_if, ccgidx, &ccg);

	return err;
}

static enum ceetm_if_ccg_unit get_early_drop_unit(
	enum dpdmux_early_drop_unit unit)
{
	enum ceetm_if_ccg_unit ceetm_if_unit = CEETM_IF_CCG_UNIT_BYTES;

	switch (unit) {
		case DPDMUX_EARLY_DROP_UNIT_BYTES:
			ceetm_if_unit = CEETM_IF_CCG_UNIT_BYTES;
			break;
		case DPDMUX_EARLY_DROP_UNIT_PACKETS:
			ceetm_if_unit = CEETM_IF_CCG_UNIT_PACKETS;
			break;
		case DPDMUX_EARLY_DROP_UNIT_BUFFERS:
			ceetm_if_unit = CEETM_IF_CCG_UNIT_BUFFERS;
			break;
		default:
			break;
	}
	return ceetm_if_unit;
}

static enum ceetm_if_ccg_mode get_early_drop_mode(
	enum dpdmux_early_drop_mode mode)
{
	enum ceetm_if_ccg_mode ceetm_if_mode = CEETM_IF_CCG_MODE_NONE;

	switch (mode) {
		case DPDMUX_EARLY_DROP_MODE_NONE:
			ceetm_if_mode = CEETM_IF_CCG_MODE_NONE;
			break;
		case DPDMUX_EARLY_DROP_MODE_TAIL:
			ceetm_if_mode = CEETM_IF_CCG_MODE_TAIL;
			break;
		case DPDMUX_EARLY_DROP_MODE_WRED:
			ceetm_if_mode = CEETM_IF_CCG_MODE_WRED;
			break;
		default:
			break;
	}
	return ceetm_if_mode;
}

int dpdmux_set_custom_key(struct dpdmux *dpdmux,
		struct dpkg_profile_cfg *extract_cfg)
{
	int err;

	CHECK_COND_RETVAL(dpdmux->method == DPDMUX_METHOD_CUSTOM, -ENOTSUP,
			"ID[%d] only DPDMUX instances using DPDMUX_METHOD_CUSTOM can set custom keys\n");

	err = dpkg_profile_modify(dpdmux->hndl.dpkg_ing,
			dpdmux->kg[DPDMUX_KG_DMAT_IDX].id,
			extract_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	/* if the key was changed, wipe out all current rules */
	err = remove_unicast_rules(dpdmux, DPDMUX_DMAT_IDX, DPDMUX_HMAP_UNICAST_IDX,
			DPDMUX_OWNER_MANAGEMENT);
	CHECK_COND_RETVAL(err == 0, err,
			"ID[%d] clearing of classification table failed, obsolete rules may still be present\n");

	// restore default rule size - this will be changed in add_custom_cls_entry()
	dpdmux->custom_cls_rule_size = DPDMUX_CUSTOM_KEY_SIZE;

	return 0;
}

int dpdmux_add_custom_cls_entry(struct dpdmux *dpdmux,
		struct dpdmux_rule_cfg *rule,
		uint16_t index,
		struct dpdmux_cls_action *action)
{
	int err;
	uint16_t unsupp_opt = action->options & ~DPDMUX_FS_OPT_DISCARD;

	CHECK_COND_RETVAL(dpdmux->method == DPDMUX_METHOD_CUSTOM, -EINVAL,
			"API only available for CUSTOM DMUX method\n");

	CHECK_COND_RETVAL(!(action->options & DPDMUX_FS_OPT_DISCARD) &&
			(action->dest_if < dpdmux->num_ifs),
			-EINVAL, "DEST_IF (%d) must be < than NUM_IFS (%d)\n",
			(int)action->dest_if, (int)dpdmux->num_ifs);

	if (unsupp_opt)
		/* a good place to flag a warning to pass with the return
		 * code */
		pr_warn("ID[%d] unsupported flags (%04x) ignored in OPTIONS field\n",
				unsupp_opt);

	err = add_rule_to_table(dpdmux, action->dest_if, rule->key, rule->mask,
				rule->size, index,
				DPDMUX_HMAP_UNICAST_IDX, DPDMUX_DMAT_IDX,
				DPDMUX_OWNER_MANAGEMENT, 1/* allow_modify*/);
	CHECK_COND_RETVAL(err == 0, err,
			"ID[%d] Failed to add rule into table\n", dpdmux->id);

	if( dpdmux->custom_cls_rule_size == DPDMUX_CUSTOM_KEY_SIZE )
		// set the new custom rule size
		dpdmux->custom_cls_rule_size = rule->size;

	return 0;
}

int dpdmux_remove_custom_cls_entry(struct dpdmux *dpdmux,
		struct dpdmux_rule_cfg *rule)
{
	int err;

	CHECK_COND_RETVAL(dpdmux->method == DPDMUX_METHOD_CUSTOM, -EINVAL,
			"API only available for CUSTOM DMUX method\n");

	err = remove_rule_from_table(dpdmux, rule->key, rule->mask, rule->size,
			DPDMUX_HMAP_UNICAST_IDX, DPDMUX_DMAT_IDX,
			DPDMUX_OWNER_MANAGEMENT, 1);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

int dpdmux_if_set_taildrop(struct dpdmux *dpdmux, uint16_t if_id, 
		struct dpdmux_taildrop_cfg *cfg)
{
	struct dpdmux_if *iface = &(dpdmux->iface[if_id]);
	struct dpdmux_early_drop_cfg 	drop;
	int err = 0;

	memset(&drop, 0x0, sizeof(struct dpdmux_early_drop_cfg));
	drop.drop_mode = DPDMUX_EARLY_DROP_MODE_TAIL;
	drop.units = cfg->units;
	drop.tail_drop_threshold = cfg->threshold;
	if( cfg->enable )
		drop.drop_mode = DPDMUX_EARLY_DROP_MODE_TAIL;
	else
		drop.drop_mode = DPDMUX_EARLY_DROP_MODE_NONE;

	/* store drop configuration to be restored after link up procedure */
	iface->drop_cfg.drop_mode = drop.drop_mode;
	iface->drop_cfg.units = drop.units;
	iface->drop_cfg.tail_drop_threshold = drop.tail_drop_threshold;

	err = dpdmux_if_tc_set_early_drop(dpdmux, if_id, DPDMUX_TAIL_DROP_CCGIDX, &drop);
	CHECK_COND_RETVAL(err == 0, err, "dpdmux_if_tc_set_early_drop() failed\n");

	return err;
}

static int if_get_early_drop(
	struct dpdmux *dpdmux,
        uint16_t if_id,
        struct dpdmux_early_drop_cfg *drop)
{
	struct ceetm_if_ccg_cfg ccg;
	struct dpdmux_if 		*iface;

	iface = &(dpdmux->iface[if_id]);
	ceetm_if_ccg_get_config(iface->ceetm_if, DPDMUX_TAIL_DROP_CCGIDX, &ccg);

	memset(drop, 0, sizeof(struct dpdmux_early_drop_cfg) );
	switch( ccg.units ) {
	case CEETM_IF_CCG_UNIT_BYTES:
		drop->units = DPDMUX_EARLY_DROP_UNIT_BYTES;
		break;
	case CEETM_IF_CCG_UNIT_PACKETS:
		drop->units = DPDMUX_EARLY_DROP_UNIT_PACKETS;
		break;
	case CEETM_IF_CCG_UNIT_BUFFERS:
		drop->units = DPDMUX_EARLY_DROP_UNIT_BUFFERS;
		break;
	default:
		pr_err("Unknown unit type: %d\n", ccg.units);
		return -EINVAL;
	}

	switch( ccg.mode ) {
	case CEETM_IF_CCG_MODE_NONE:
		drop->drop_mode = DPDMUX_EARLY_DROP_MODE_NONE;
		break;
	case CEETM_IF_CCG_MODE_TAIL:
		drop->drop_mode = DPDMUX_EARLY_DROP_MODE_TAIL;
		break;
	case CEETM_IF_CCG_MODE_WRED:
		drop->drop_mode = DPDMUX_EARLY_DROP_MODE_WRED;
		break;
	default:
		pr_err("Unknown mode type: %d\n", ccg.mode);
		return -EINVAL;
	}

	if (drop->units == DPDMUX_EARLY_DROP_UNIT_BUFFERS)
	{
		drop->tail_drop_threshold = ccg.tail_drop_threshold /
									(DPDMUX_BP_BUFFER_SIZE/64);
	}
	else
	{
		/* tail drop */
		drop->tail_drop_threshold = ccg.tail_drop_threshold;
	}

	/* wred green */
	drop->green.drop_probability = ccg.green.drop_probability;
	drop->green.max_threshold = ccg.green.max_threshold;
	drop->green.min_threshold = ccg.green.min_threshold;

	/* wred yellow */
	drop->yellow.drop_probability = ccg.yellow.drop_probability;
	drop->yellow.max_threshold = ccg.yellow.max_threshold;
	drop->yellow.min_threshold = ccg.yellow.min_threshold;

	return 0;
}

int dpdmux_if_get_taildrop(struct dpdmux *dpdmux, uint16_t if_id,
		struct dpdmux_taildrop_cfg *cfg)
{
	struct dpdmux_early_drop_cfg 	drop_cfg;
	int err = 0;

	err = if_get_early_drop(dpdmux, if_id, &drop_cfg);
	CHECK_COND_RETVAL( err==0, err, "if_get_early_drop() return error");

	if( drop_cfg.drop_mode == DPDMUX_EARLY_DROP_MODE_TAIL )
		cfg->enable = 1;
	else
		cfg->enable = 0;

	cfg->units = drop_cfg.units;
	cfg->threshold = drop_cfg.tail_drop_threshold;

	return err;
}

int dpdmux_get_ap_ppid(struct dpdmux *dpdmux, int if_id, int *ppid)
{
	struct dpdmux_if *iface;

	iface = &(dpdmux->iface[if_id]);
	if( iface->link_res_flags & DPDMUX_LINKRES_AP_CONNECTED) /* access point valid */
		*ppid = iface->ap.ppid;
	else
		return -ENOTSUP;

	return 0;
}

static int get_action_result(struct dpdmux *dpdmux, struct dptbl_action action, uint16_t *result) {
	result[0] = (uint16_t)(action.options >> 16);
	result[1] = (uint16_t)action.options;
	result[2] = (uint16_t)action.replic_id;

	return 0;
}

int dpdmux_dump_table(struct device *dev, uint16_t table_type, uint16_t table_index, uint64_t iova_addr, int iova_size, uint16_t *table_size)
{
	int err = 0, i;
	int table_num_entries;
	int table_max_entries;
	int remaining_bytes;
	int real_key_size;
	int match_type;
	int tbl_index;
	uint32_t header_size;
	uint32_t entry_size;
	uint32_t max_entries;
	struct dpdmux *dpdmux;
	struct dump_table_header header;
	struct dump_table_entry *entries;
	struct dptbl *tbl;
	struct dptbl_action action;
	struct dptbl_rule rule;

	*table_size = 0;

	if (table_type == DPDMUX_DMAT_TABLE){
		tbl_index = DPDMUX_DMAT_IDX;
	}
	else if (table_type == DPDMUX_MISS_TABLE) {
		tbl_index = DPDMUX_MISS_TBL_IDX;
	}
	else if (table_type == DPDMUX_PRUNE_TABLE) {
		tbl_index = DPDMUX_PRUNE_TBL_IDX;
	}
	else {
		pr_err("Invalid table index\n");
		return -EINVAL;
	}

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	header_size = sizeof(struct dump_table_header);
	entry_size = sizeof(struct dump_table_entry);

	remaining_bytes = iova_size;
	CHECK_COND_RETVAL(remaining_bytes>=header_size, -EINVAL, "[ID%d] Not enough room to store header\n", dpdmux->id);

	max_entries = (remaining_bytes - header_size) / entry_size;

	tbl = dpdmux->table[tbl_index].handle;

	dptbl_get_num_of_used_rules(tbl, &table_num_entries);
	dptbl_get_num_of_max_rules(tbl, &table_max_entries);
	dptbl_get_tbl_type(tbl, &match_type);
	// get default action

	memset(&header, 0, header_size);
	header.table_type = table_type;
	header.match_type = (uint8_t)match_type;
	header.table_num_entries = (uint16_t)table_num_entries;
	header.table_max_entries = (uint16_t)table_max_entries;
	// set default action in header

	err = dpmng_dev_memcpy(dev, &header, iova_addr, (uint32_t)header_size, 0);
	if (err) {
		pr_err("Error writing extended DMA parameters\n");
		return err;
	}

	remaining_bytes -= header_size;
	iova_addr += header_size;
	*table_size = 0;

	entries = (struct dump_table_entry *)fsl_malloc(max_entries * entry_size);
	CHECK_COND_RETVAL(entries, -ENOMEM);
	memset(entries, 0, max_entries * entry_size);

	err = dptbl_query(tbl, (void *)entries, (int)max_entries, table_size);
	if (err) {
		pr_err("Error in dptbl_query for dpdmux@%d\n", dpdmux->id);
		fsl_free(entries);
		return err;
	}

	for (i = 0; i < *table_size; i++) {
		memset(&rule, 0, sizeof(struct dptbl_rule));

		if (dpdmux->options & DPDMUX_OPT_CLS_MASK_SUPPORT) {
			rule.rule_cfg.masked.key = entries[i].key;
			rule.rule_cfg.masked.mask = entries[i].mask;
			dptbl_get_real_key_size(tbl, &real_key_size);
			rule.rule_cfg.masked.size = (uint32_t)real_key_size;
		} else {
			rule.rule_cfg.exact.key = entries[i].key;
			dptbl_get_real_key_size(tbl, &real_key_size);
			rule.rule_cfg.exact.size = (uint32_t)real_key_size;
		}

		memset(&action, 0x0, sizeof(struct dptbl_action));
		err = dptbl_get_action(tbl, &rule, &action);
		if(err) {
			pr_err("Error getting key action\n");
			continue;
		}

		entries[i].key_action = action.next_action;

		err = get_action_result(dpdmux, action, entries[i].result);
		if (err) {
			pr_err("Error getting action result\n");
			continue;
		}

		err = dpmng_dev_memcpy(dev, &entries[i], iova_addr, entry_size, 0);
		if (err) {
			pr_err("Error writing extended DMA parameters\n");
			fsl_free(entries);
			return err;
		}

		iova_addr += entry_size;
	}

	fsl_free(entries);
	return err;
}

int dpdmux_set_errors_behavior(struct dpdmux *dpdmux, uint16_t if_id, struct dpdmux_error_cfg *cfg)
{
	struct dpdmux_if *iface;
	struct eiop_ifp_err_cfg ifp_err_cfg;
	struct eiop_ifp_desc eiop_ifp_desc;
	int err;

	CHECK_COND_RETVAL( if_id < dpdmux->num_ifs, -EINVAL, "dpdmux.%d: if_id value %d invalid, must be smaller than %d\n",
			dpdmux->id, if_id, dpdmux->num_ifs);

	err = !(dpdmux->options & DPDMUX_OPT_BRIDGE_EN) && (if_id != 0);
	CHECK_COND_RETVAL(err==0, -EINVAL, "In VEPA mode error behavior can be configured only for interface zero\n");

	memset(&ifp_err_cfg, 0, sizeof(ifp_err_cfg));
	if( cfg->error_action == DPDMUX_ERROR_ACTION_DISCARD ) {
		ifp_err_cfg.action = EIOP_IFP_ERR_DROP;
	}
	else if( cfg->error_action == DPDMUX_ERROR_ACTION_CONTINUE ) {
		ifp_err_cfg.action = EIOP_IFP_ERR_ENQ;
	} else {
		err = 1;
		CHECK_COND_RETVAL(err = 0, -EINVAL, "Invalid error action: %d\n", cfg->error_action);
	}

	iface = &(dpdmux->iface[if_id]);

	/* Obtain IFP descriptor */
	memset(&eiop_ifp_desc, 0, sizeof(eiop_ifp_desc));
	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id;

	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID,
				&eiop_ifp_desc, NULL);
	CHECK_COND_RETVAL(err == 0, err, "Failed for IFP descriptor\n");

	eiop_ifp_set_err_behavior(&eiop_ifp_desc, cfg->errors, &ifp_err_cfg);

	return 0;
}

int dpdmux_if_update_max_frame_len(struct dpdmux *dpdmux, uint16_t if_id, uint16_t max_frame_len)
{
	struct dpdmux_if *iface;
	struct eiop_ifp_desc eiop_ifp_desc;
	struct linkman_connection_attr attr;
	struct linkman_endpoint ep;
	struct dpni *dpni;
	uint16_t tmp_mfl;
	int err = 0;
	uint16_t i;

	if( dpdmux==NULL )
		return -EINVAL;

	/* update only if the flag is set */
	if( !(dpdmux->options & DPDMUX_OPT_AUTO_MAX_FRAME_LEN) )
		return 0;

	if( !(dpdmux->options & DPDMUX_OPT_BRIDGE_EN) && if_id != 0 )
		/* on VEPA mode only interface 0 need to be updated */
		return err;

	if( if_id == 0 ) {
		/* use maximum frame len on interface 0 */
		for (i = 0; i < dpdmux->num_ifs; i++) {
			memset(&ep, 0, sizeof(ep));
			get_connection(dpdmux, i, &ep, &attr);
			if (ep.type == FSL_MOD_DPNI)
			{
				dpni = (struct dpni *)sys_get_handle(FSL_MOD_DPNI, 1, ep.id);
				dpni_get_max_frame_length(dpni, &tmp_mfl);
				if (tmp_mfl > max_frame_len )
					max_frame_len = tmp_mfl;
			}
		}
	}

	iface = &(dpdmux->iface[if_id]);

	eiop_ifp_desc.ifp_id = iface->ap.ifpid;
	eiop_ifp_desc.eiop_id = iface->ap.iop_id;
	err = sys_get_desc(SOC_MODULE_EIOP_IFP,
					SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID,
					&eiop_ifp_desc,	NULL);
	CHECK_COND_RETVAL(err == 0, err);
	CHECK_COND_RETVAL(eiop_ifp_desc.vaddr, -EINVAL);

	err = eiop_ifp_set_max_frame_length(&eiop_ifp_desc, max_frame_len);
	CHECK_COND_RETVAL(err == 0, err);

	iface->mfl = max_frame_len;

	return err;
}

int dpdmux_get_mac_rate(struct dpdmux *dpdmux, uint32_t *rate)
{
	if (dpdmux->dpmac)
		dpmac_get_rate(dpdmux->dpmac, rate);
	else
		*rate = DPDMUX_DEFAULT_RATE;

	return 0;
}

int dpdmux_get_id(struct dpdmux *dpdmux, uint16_t *id)
{
	*id = (uint16_t)dpdmux->id;

	return 0;
}

int dpdmux_get_num_ifs(struct dpdmux *dpdmux, uint16_t *num_ifs)
{
	*num_ifs = dpdmux->num_ifs;

	return 0;
}
