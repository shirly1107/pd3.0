/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPDMUX_CMD_H
#define _DPDMUX_CMD_H

/* default version for all dpdmux commands */
#define DPDMUX_CMD_VER_BASE								CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)
#define DPDMUX_CMD_V0									CMDHDR_CMD_VERSION(0)
#define DPDMUX_CMD_V1									CMDHDR_CMD_VERSION(1)
#define DPDMUX_CMD_V2									CMDHDR_CMD_VERSION(2)
#define DPDMUX_CMD_V3									CMDHDR_CMD_VERSION(3)
#define DPDMUX_CMD_V4									CMDHDR_CMD_VERSION(4)

/* Command IDs */
#define DPDMUX_CMD_CODE_CLOSE                              0x800
#define DPDMUX_CMD_CODE_OPEN                               0x806
#define DPDMUX_CMD_CODE_CREATE                             0x906
#define DPDMUX_CMD_CODE_DESTROY                            0x900
#define DPDMUX_CMD_CODE_GET_API_VERSION                    0xa06

#define DPDMUX_CMD_CODE_ENABLE                             0x002
#define DPDMUX_CMD_CODE_DISABLE                            0x003
#define DPDMUX_CMD_CODE_GET_ATTR                           0x004
#define DPDMUX_CMD_CODE_RESET                              0x005
#define DPDMUX_CMD_CODE_IS_ENABLED                         0x006

#define DPDMUX_CMD_CODE_SET_IRQ                            0x010
#define DPDMUX_CMD_CODE_GET_IRQ                            0x011
#define DPDMUX_CMD_CODE_SET_IRQ_ENABLE                     0x012
#define DPDMUX_CMD_CODE_GET_IRQ_ENABLE                     0x013
#define DPDMUX_CMD_CODE_SET_IRQ_MASK                       0x014
#define DPDMUX_CMD_CODE_GET_IRQ_MASK                       0x015
#define DPDMUX_CMD_CODE_GET_IRQ_STATUS                     0x016
#define DPDMUX_CMD_CODE_CLEAR_IRQ_STATUS                   0x017

#define DPDMUX_CMD_CODE_SET_MAX_FRAME_LENGTH               0x0a1
#define DPDMUX_CMD_CODE_GET_MAX_FRAME_LENGTH               0x0a2

#define DPDMUX_CMD_CODE_UL_RESET_COUNTERS                  0x0a3

#define DPDMUX_CMD_CODE_IF_SET_ACCEPTED_FRAMES             0x0a7
#define DPDMUX_CMD_CODE_IF_GET_ATTR                        0x0a8
#define DPDMUX_CMD_CODE_IF_ENABLE                          0x0a9
#define DPDMUX_CMD_CODE_IF_DISABLE                         0x0aa

#define DPDMUX_CMD_CODE_IF_ADD_L2_RULE                     0x0b0
#define DPDMUX_CMD_CODE_IF_REMOVE_L2_RULE                  0x0b1
#define DPDMUX_CMD_CODE_IF_GET_COUNTER                     0x0b2
#define DPDMUX_CMD_CODE_IF_SET_LINK_CFG                    0x0b3
#define DPDMUX_CMD_CODE_IF_GET_LINK_STATE                  0x0b4

#define DPDMUX_CMD_CODE_SET_CUSTOM_KEY                     0x0b5
#define DPDMUX_CMD_CODE_ADD_CUSTOM_CLS_ENTRY               0x0b6
#define DPDMUX_CMD_CODE_REMOVE_CUSTOM_CLS_ENTRY            0x0b7

#define DPDMUX_CMD_CODE_IF_SET_DEFAULT                     0x0b8
#define DPDMUX_CMD_CODE_IF_GET_DEFAULT                     0x0b9

#define DPDMUX_CMD_CODE_SET_RESETABLE                      0x0ba
#define DPDMUX_CMD_CODE_GET_RESETABLE                      0x0bb

#define DPDMUX_CMD_CODE_IF_SET_TAILDROP                    0x0bc
#define DPDMUX_CMD_CODE_IF_GET_TAILDROP                    0x0bd

#define DPDMUX_CMD_CODE_DUMP_TABLE		                   0x0be

#define DPDMUX_CMD_CODE_IF_SET_ERRORS_BEHAVIOR				0x0bf

#endif /* _DPDMUX_CMD_H */
