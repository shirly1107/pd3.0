/*
 * Copyright 2013-2020 NXP
 */

#ifndef _LEGACY_DPDMUX_DPLIB_H
#define _LEGACY_DPDMUX_DPLIB_H

/* 
 * File used to maintain compatibility with older version of dplib/flib
 * All previous version of dpdmux commands should be placed here
 */

/**********************************************/
/********* V0 version of dpdmux commands ******/
/**********************************************/

/*                cmd, param, offset, width, type, arg_name */
#define DPDMUX_CMD_CREATE(cmd, cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  enum dpdmux_method, cfg->method);\
	MC_CMD_OP(cmd, 0, 8,  8,  enum dpdmux_manip, cfg->manip);\
	MC_CMD_OP(cmd, 0, 16, 16, uint16_t, cfg->num_ifs);\
	MC_CMD_OP(cmd, 1, 0,  16, uint16_t, cfg->adv.max_dmat_entries);\
	MC_CMD_OP(cmd, 1, 16, 16, uint16_t, cfg->adv.max_mc_groups);\
	MC_CMD_OP(cmd, 1, 32, 16, uint16_t, cfg->adv.max_vlan_ids);\
	MC_CMD_OP(cmd, 2, 0,  64, uint64_t, cfg->adv.options);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMUX_RSP_GET_ATTRIBUTES_V0(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0,  8, enum dpdmux_method, (attr)->method);\
	MC_RSP_OP(cmd, 0,  8,  8, enum dpdmux_manip,  (attr)->manip);\
	MC_RSP_OP(cmd, 0, 16, 16, uint16_t, (attr)->num_ifs);\
	MC_RSP_OP(cmd, 0, 32, 16, uint16_t, (attr)->mem_size);\
	MC_RSP_OP(cmd, 2,  0, 32, int,      (attr)->id);\
	MC_RSP_OP(cmd, 3,  0, 64, uint64_t, (attr)->options);\
	MC_RSP_OP(cmd, 4,  0, 16, uint16_t, (attr)->version.major);\
	MC_RSP_OP(cmd, 4, 16, 16, uint16_t, (attr)->version.minor);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMUX_RSP_GET_ATTRIBUTES(cmd, attr) \
do { \
	MC_RSP_OP(cmd, 0,  0,  8, enum dpdmux_method, (attr)->method);\
	MC_RSP_OP(cmd, 0,  8,  8, enum dpdmux_manip,  (attr)->manip);\
	MC_RSP_OP(cmd, 0, 16, 16, uint16_t, (attr)->num_ifs);\
	MC_RSP_OP(cmd, 0, 32, 16, uint16_t, (attr)->mem_size);\
	MC_RSP_OP(cmd, 2,  0, 32, int,      (attr)->id);\
	MC_RSP_OP(cmd, 3,  0, 64, uint64_t, (attr)->options);\
} while (0)


/*                cmd, param, offset, width, type, arg_name */
#define DPDMUX_CMD_SET_IRQ(cmd, irq_index, irq_cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,  irq_index);\
	MC_CMD_OP(cmd, 0, 32, 32, uint32_t, irq_cfg->val);\
	MC_CMD_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr);\
	MC_CMD_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMUX_CMD_GET_IRQ(cmd, irq_index) \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMUX_RSP_GET_IRQ(cmd, type, irq_cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, irq_cfg->val); \
	MC_RSP_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr); \
	MC_RSP_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
	MC_RSP_OP(cmd, 2, 32, 32, int,	    type); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMUX_CMD_IF_SET_LINK_CFG_V1(cmd, if_id, cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  16, uint16_t, if_id);\
	MC_CMD_OP(cmd, 1, 0,  32, uint32_t, cfg->rate);\
	MC_CMD_OP(cmd, 2, 0,  64, uint64_t, cfg->options);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMUX_RSP_IF_GET_LINK_STATE_V1(cmd, state) \
do { \
	MC_RSP_OP(cmd, 0, 32, 1,  int,      state->up);\
	MC_RSP_OP(cmd, 1, 0,  32, uint32_t, state->rate);\
	MC_RSP_OP(cmd, 2, 0,  64, uint64_t, state->options);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDMUX_CMD_ADD_CUSTOM_CLS_ENTRY_V1(cmd, rule, action) \
do { \
	MC_CMD_OP(cmd, 0, 24,  8,  uint8_t, (rule)->key_size); \
	MC_CMD_OP(cmd, 0, 48, 16, uint16_t, (action)->dest_if); \
	MC_CMD_OP(cmd, 1,  0, 64, uint64_t, (rule)->key_iova); \
	MC_CMD_OP(cmd, 2,  0, 64, uint64_t, (rule)->mask_iova); \
} while (0)

#endif /* _LEGACY_DPDMUX_DPLIB_H */
