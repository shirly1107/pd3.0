/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpdmux_drv.c

 @Description   Driver implementation

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "kernel/layout.h"
#include "dplib/fsl_dpdmux_cmd.h"
#include "fsl_event_pipe.h"
#include "fsl_dpdmux_mc.h"
#include "fsl_cmdif.h"
#include "fsl_dbg.h"
#include "kernel/device.h"
#include "fsl_sys.h"
#include "fsl_cmdif_mc.h"
#include "dtc/dtc.h"
#include "dpdmux_cmd.h"
#include "legacy_dpdmux_dplib.h"

/* DPDMUX last supported api version */
#define DPDMUX_V0_API_VER_MAJOR				5
#define DPDMUX_V0_API_VER_MINOR				0

int dpdmux_drv_init(void);

/*            cmd, cfg, param, offset, width, type, arg_name */
#define DPDMUX_LO_CREATE(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  8,  enum dpdmux_method, cfg->method);\
	MC_RSP_OP(cmd, 0, 8,  8,  enum dpdmux_manip, cfg->manip);\
	MC_RSP_OP(cmd, 0, 16, 16, uint16_t, cfg->num_ifs);\
	MC_RSP_OP(cmd, 0, 32, 32, int,      cfg->control_if);\
	MC_RSP_OP(cmd, 1, 0,  16, uint16_t, cfg->adv.max_dmat_entries);\
	MC_RSP_OP(cmd, 1, 16, 16, uint16_t, cfg->adv.max_mc_groups);\
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t, cfg->adv.max_vlan_ids);\
	MC_RSP_OP(cmd, 2, 0,  64, uint64_t, cfg->adv.options);\
} while (0)

/*            cmd, cfg, param, offset, width, type, arg_name */
#define DPDMUX_LO_CREATE_V2(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  8,  enum dpdmux_method, cfg->method);\
	MC_RSP_OP(cmd, 0, 8,  8,  enum dpdmux_manip, cfg->manip);\
	MC_RSP_OP(cmd, 0, 16, 16, uint16_t, cfg->num_ifs);\
	MC_RSP_OP(cmd, 0, 32, 16, uint16_t,	cfg->default_if);\
	MC_RSP_OP(cmd, 1, 0,  16, uint16_t, cfg->adv.max_dmat_entries);\
	MC_RSP_OP(cmd, 1, 16, 16, uint16_t, cfg->adv.max_mc_groups);\
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t, cfg->adv.max_vlan_ids);\
	MC_RSP_OP(cmd, 2, 0,  64, uint64_t, cfg->adv.options);\
} while (0)

/*            cmd, cfg, param, offset, width, type, arg_name */
#define DPDMUX_LO_CREATE_V3(cmd, cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  8,  enum dpdmux_method, cfg->method);\
	MC_RSP_OP(cmd, 0, 8,  8,  enum dpdmux_manip, cfg->manip);\
	MC_RSP_OP(cmd, 0, 16, 16, uint16_t, cfg->num_ifs);\
	MC_RSP_OP(cmd, 0, 32, 16, uint16_t,	cfg->default_if);\
	MC_RSP_OP(cmd, 1, 0,  16, uint16_t, cfg->adv.max_dmat_entries);\
	MC_RSP_OP(cmd, 1, 16, 16, uint16_t, cfg->adv.max_mc_groups);\
	MC_RSP_OP(cmd, 1, 32, 16, uint16_t, cfg->adv.max_vlan_ids);\
	MC_RSP_OP(cmd, 1, 48, 16, uint16_t,	cfg->adv.mem_size);\
	MC_RSP_OP(cmd, 2, 0,  64, uint64_t, cfg->adv.options);\
} while (0)

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	struct dpdmux *dpdmux;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	return dpdmux_set_dev_ctx(dpdmux, dev_ctx);
}

static int create_comon(struct device *dev, struct dpdmux_cfg *cfg, int ver)
{
	struct dpdmux *dpdmux;
	struct dpmng_dev_cfg dev_cfg = { 0 };
	int err;

	if (ver < 2)
		cfg->default_if = 0;

	if (ver < 3)
		cfg->adv.mem_size = 0;

	if(ver < 4)
		/* this flag exists starting with command version 4 */
		cfg->adv.options &= (~DPDMUX_OPT_AUTO_MAX_FRAME_LEN);

	dpdmux = device_get_priv(dev);

	/* should be NULL unless special cases: reset, etc. */
	if (!dpdmux) {
		/* NULL */
		dpdmux = dpdmux_allocate();
		if (!dpdmux) {
			pr_err("No memory for dpdmux\n");
			return -ENOMEM;
		}

		dev_cfg.id = device_get_id(dev);
		dev_cfg.device = dev;
		resman_get_dev_ctx(dev, &(dev_cfg.ctx), 1);

		err = dpdmux_init(dpdmux, cfg, &dev_cfg);
		if (err) {
			dpdmux_deallocate(dpdmux);
			return err;
		}

		device_set_priv(dev, dpdmux);
		sys_add_handle(dpdmux, FSL_MOD_DPDMUX, 1, dev_cfg.id);

		assign(dev, &(dev_cfg.ctx));
	}
	else
		return -EINVAL;

	return 0;
}

static int init_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux_cfg dpdmux_cfg;
	struct dpdmux_cfg *cfg = &dpdmux_cfg;

	memset(cfg, 0, sizeof(struct dpdmux_cfg));
	DPDMUX_CMD_CREATE(cmd_data, cfg);

	return create_comon(dev, cfg, 1);
}

static int init_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux_cfg dpdmux_cfg;
	struct dpdmux_cfg *cfg = &dpdmux_cfg;

	memset(cfg, 0, sizeof(struct dpdmux_cfg));
	DPDMUX_CMD_CREATE_V2(cmd_data, cfg);

	return create_comon(dev, cfg, 2);
}

static int init_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux_cfg dpdmux_cfg;
	struct dpdmux_cfg *cfg = &dpdmux_cfg;

	memset(cfg, 0, sizeof(struct dpdmux_cfg));
	DPDMUX_CMD_CREATE_V3(cmd_data, cfg);

	return create_comon(dev, cfg, 3);
}

static int init_v4(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux_cfg dpdmux_cfg;
	struct dpdmux_cfg *cfg = &dpdmux_cfg;

	memset(cfg, 0, sizeof(struct dpdmux_cfg));
	DPDMUX_CMD_CREATE_V3(cmd_data, cfg);

	return create_comon(dev, cfg, 4);
}

static int destroy(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;

	UNUSED(cmd_data);

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	dpdmux_destroy(dpdmux);

	sys_remove_handle(FSL_MOD_DPDMUX, 1, device_get_id(dev));
	dpdmux_deallocate(dpdmux);

	return 0;
}

static int destroy_by_resman(struct device *dev)
{
	return destroy(dev, NULL);
}

static int get_attributes_v0(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	struct dpdmux_attr attr = { 0 };
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	err = dpdmux_get_attributes(dpdmux, &attr);
	CHECK_COND_RETVAL(!err, err);

	attr.version.major = DPDMUX_V0_API_VER_MAJOR;
	attr.version.minor = DPDMUX_V0_API_VER_MINOR;

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMUX_RSP_GET_ATTRIBUTES_V0(cmd_data, &attr);

	return 0;
}

static int get_attributes_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	struct dpdmux_attr attr = { 0 };
	struct resman *resman;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	err = dpdmux_get_attributes(dpdmux, &attr);
	CHECK_COND_RETVAL(!err, err);

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -EUNKNOWN);

	resman_get_ver(resman, dev,
			&(attr.version.minor),
			&(attr.version.major));

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMUX_RSP_GET_ATTRIBUTES(cmd_data, &attr);

	return 0;
}

static int get_attributes_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	struct dpdmux_attr attr = { 0 };
	struct resman *resman;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	err = dpdmux_get_attributes(dpdmux, &attr);
	CHECK_COND_RETVAL(!err, err);

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -EUNKNOWN);

	resman_get_ver(resman, dev,
			&(attr.version.minor),
			&(attr.version.major));

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMUX_RSP_GET_ATTRIBUTES_V2(cmd_data, &attr);

	return 0;
}

static int get_attributes_v3(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	struct dpdmux_attr attr = { 0 };
	struct resman *resman;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	err = dpdmux_get_attributes(dpdmux, &attr);
	CHECK_COND_RETVAL(!err, err);

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -EUNKNOWN);

	resman_get_ver(resman, dev,
			&(attr.version.minor),
			&(attr.version.major));

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMUX_RSP_GET_ATTRIBUTES_V3(cmd_data, &attr);

	return 0;
}

static int enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	int err = 0;

	UNUSED(cmd_data);

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	device_set_enable(dev, 1);

	err = dpdmux_enable(dpdmux);
	if (err){
		device_set_enable(dev, 0);
		return 0;
	}

	return err;
}

static int disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	int err = 0;

	UNUSED(cmd_data);

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	err = dpdmux_disable(dpdmux);
	if (!err){
		device_set_enable(dev, 0);
		return 0;
	}

	return err;
}

static int reset(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	int err;

	UNUSED(cmd_data);

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	err = dpdmux_reset(dpdmux);
	if (!err)
		device_set_enable(dev, 0);

	return err;
}

static int reset_by_resman(struct device *dev)
{
	return reset(dev, NULL);
}

static int is_enabled(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	int en;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	err = device_get_enable(dev, &en);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDMUX_RSP_IS_ENABLED(cmd_data, en);
	}

	return err;
}
#if 0
static int set_scheduling(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	struct dpdmux_rate_cfg rate_cfg = { 0 };
	struct dpdmux_rate_cfg *cfg = &rate_cfg;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_SET_SCHEDULING(cmd_data, cfg);

	return dpdmux_set_scheduling(dpdmux, cfg);
}
#endif

static int set_max_frame_length(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t max_frame_length;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_SET_MAX_FRAME_LENGTH(cmd_data, max_frame_length);

	return dpdmux_set_max_frame_length(dpdmux, max_frame_length);
}

static int get_max_frame_length(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t max_frame_length = 0;
	uint16_t if_id;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_GET_MAX_FRAME_LENGTH(cmd_data, if_id);

	err = dpdmux_get_max_frame_length(dpdmux, if_id, &max_frame_length);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));

	DPDMUX_RSP_GET_MAX_FRAME_LENGTH(cmd_data, max_frame_length);

	return err;
}

static int if_get_counter(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	enum dpdmux_counter_type counter_type;
	uint64_t counter;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_GET_COUNTER(cmd_data, if_id, counter_type);

	err = dpdmux_if_get_counter(dpdmux, if_id, counter_type, &counter);
	if (!err)
		DPDMUX_RSP_IF_GET_COUNTER(cmd_data, counter);

	return err;
}

static int ul_reset_counters(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	return dpdmux_ul_reset_counters(dpdmux);

}

#if 0
static int if_get_transmit_rate(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	struct dpdmux_transmit_rate trans_cfg = { 0 };
	struct dpdmux_transmit_rate *cfg = &trans_cfg;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_GET_TRANSMIT_RATE(cmd_data, if_id);

	err = dpdmux_if_get_transmit_rate(dpdmux, if_id, cfg);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDMUX_RSP_IF_GET_TRANSMIT_RATE(cmd_data, cfg);
	}
	return err;
}

static int if_set_tci(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	struct dpdmux_tci_val val = { 0 };
	struct dpdmux_tci_val *cfg = &val;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_SET_TCI(cmd_data, if_id, cfg);

	return dpdmux_if_set_tci(dpdmux, if_id, cfg);
}
#endif
static int if_set_accepted_frames(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	struct dpdmux_accepted_frames val;
	struct dpdmux_accepted_frames *cfg = &val;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	memset(&val, 0, sizeof(struct dpdmux_accepted_frames));

	DPDMUX_CMD_IF_SET_ACCEPTED_FRAMES(cmd_data, if_id, cfg);

	return dpdmux_if_set_accepted_frames(dpdmux, if_id, cfg);
}

static int if_get_attributes(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	struct dpdmux_if_attr val = { 0 };
	struct dpdmux_if_attr *attr = &val;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_GET_ATTR(cmd_data, if_id);

	err = dpdmux_if_get_attributes(dpdmux, if_id, attr);
	if (!err){
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDMUX_RSP_IF_GET_ATTR(cmd_data, attr);
	}
	return err;
}

static int if_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_ENABLE(cmd_data, if_id);

	return dpdmux_if_enable(dpdmux, if_id);
}

static int if_disable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_DISABLE(cmd_data, if_id);

	return dpdmux_if_disable(dpdmux, if_id);
}

#if 0//add after release 5
static int if_set_transmit_rate(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	struct dpdmux_transmit_rate val = { 0 };
	struct dpdmux_transmit_rate *cfg = &val;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_SET_TRANSMIT_RATE(cmd_data, if_id, cfg);

	return dpdmux_if_set_transmit_rate(dpdmux, if_id, cfg);
}
#endif

static int if_add_l2_rule(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	struct dpdmux_l2_rule val = { 0 };
	struct dpdmux_l2_rule *l2_rule = &val;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_ADD_L2_RULE(cmd_data, if_id, l2_rule);

	return dpdmux_if_add_l2_rule(dpdmux,
	                              if_id,
	                              l2_rule,
	                              DPDMUX_OWNER_MANAGEMENT);
}

static int if_remove_l2_rule(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	struct dpdmux_l2_rule val = { 0 };
	struct dpdmux_l2_rule *l2_rule = &val;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_REMOVE_L2_RULE(cmd_data, if_id, l2_rule);

	return dpdmux_if_remove_l2_rule(dpdmux,
	                              if_id,
	                              l2_rule,
	                              DPDMUX_OWNER_MANAGEMENT);
}

static int if_set_link_cfg(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	struct dpdmux_link_cfg link_cfg = { 0 };
	struct dpdmux_link_cfg *cfg = &link_cfg;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	if (ver < 2)
	{
		DPDMUX_CMD_IF_SET_LINK_CFG_V1(cmd_data, if_id, cfg);
		cfg->advertising = 0;
	}
	else
		DPDMUX_CMD_IF_SET_LINK_CFG(cmd_data, if_id, cfg);

	return dpdmux_if_set_link_cfg(dpdmux, if_id, cfg);
}

static int if_set_link_cfg_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_set_link_cfg(dev, cmd_data, 1);
}

static int if_set_link_cfg_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_set_link_cfg(dev, cmd_data, 2);
}

static int if_get_link_state(struct device *dev, struct mc_cmd_data *cmd_data, int ver)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	struct dpdmux_link_state link_state = { 0 };
	struct dpdmux_link_state *state = &link_state;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_GET_LINK_STATE(cmd_data, if_id);

	err = dpdmux_if_get_link_state(dpdmux, if_id, state);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	if (ver < 2)
		DPDMUX_RSP_IF_GET_LINK_STATE_V1(cmd_data, state);
	else
		DPDMUX_RSP_IF_GET_LINK_STATE(cmd_data, state);

	return 0;
}

static int if_get_link_state_v1(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_get_link_state(dev, cmd_data, 1);
}

static int if_get_link_state_v2(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return if_get_link_state(dev, cmd_data, 2);
}

static int dpdmux_open_cb(void *dev, int portal_id)
{
	UNUSED(portal_id);
	pr_info("Handling command: dpdmux_open on DPDMUX %d\n", device_get_id(dev));

	return 0;
}

static int dpdmux_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(portal_id);
	UNUSED(token);
	pr_info("Handling command: dpdmux_close on DPDMUX %d\n", device_get_id(dev));

	return 0;
}

static int set_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint8_t irq_index;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_SET_IRQ(cmd_data, irq_index, irq_cfg);

	if (resman_is_irq_cfg_allowed(dev) == 0)
		return -EPERM;

	resman_get_dev_ctx(dev, &irq_cfg->dev_ctx, 0);

	return dpdmux_set_irq(dpdmux, irq_index, irq_cfg);
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpdmux *dpdmux;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	return dpdmux_set_irq(dpdmux, (uint8_t)irq_index, irq_cfg);
}

static int get_irq(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	struct mc_irq_cfg mc_irq_cfg = { 0 };
	struct mc_irq_cfg *irq_cfg = &mc_irq_cfg;
        uint8_t irq_index;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	/* Read parameters from portal */
	DPDMUX_CMD_GET_IRQ(cmd_data, irq_index);

	err = dpdmux_get_irq(dpdmux, irq_index, irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMUX_RSP_GET_IRQ(cmd_data, irq_cfg->type, irq_cfg);

	return 0;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	struct dpdmux *dpdmux;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	err = dpdmux_get_irq(dpdmux, (uint8_t)irq_index, irq_cfg);
	CHECK_COND_RETVAL(err == 0, err);

	return 0;
}

static int set_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint8_t irq_index;
	uint8_t en;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	/* Read parameters from portal */
	DPDMUX_CMD_SET_IRQ_ENABLE(cmd_data, irq_index, en);

	return dpdmux_set_irq_enable(dpdmux, irq_index, en);
}

static int get_irq_enable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint8_t irq_index;
	uint8_t en;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	/* Read parameters from portal */
	DPDMUX_CMD_GET_IRQ_ENABLE(cmd_data, irq_index);

	err = dpdmux_get_irq_enable(dpdmux, irq_index, &en);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMUX_RSP_GET_IRQ_ENABLE(cmd_data, en);

	return 0;
}

static int set_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint8_t irq_index;
	uint32_t mask;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	/* Read parameters from portal */
	DPDMUX_CMD_SET_IRQ_MASK(cmd_data, irq_index, mask);

	return dpdmux_set_irq_mask(dpdmux, irq_index, mask);
}

static int get_irq_mask(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint8_t irq_index;
	uint32_t mask;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	/* Read parameters from portal */
	DPDMUX_CMD_GET_IRQ_MASK(cmd_data, irq_index);

	err = dpdmux_get_irq_mask(dpdmux, irq_index, &mask);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMUX_RSP_GET_IRQ_MASK(cmd_data, mask);

	return 0;
}

static int get_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint8_t irq_index;
	uint32_t status;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	/* Read parameters from portal */
	DPDMUX_CMD_GET_IRQ_STATUS(cmd_data, irq_index, status);

	err = dpdmux_get_irq_status(dpdmux, irq_index, &status);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMUX_RSP_GET_IRQ_STATUS(cmd_data, status);

	return 0;
}

static int clear_irq_status(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint8_t irq_index;
	uint32_t status;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	/* Read parameters from portal */
	DPDMUX_CMD_CLEAR_IRQ_STATUS(cmd_data, irq_index, status);

	return dpdmux_clear_irq_status(dpdmux, irq_index, status);
}

static int get_api_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
    uint32_t major = DPDMUX_VER_MAJOR;
    uint32_t minor = DPDMUX_VER_MINOR;

    DPDMUX_RSP_GET_API_VERSION(cmd_data, major, minor);

    return 0;
}

#define DPDMUX_CMD_EXTRACT_EXT_PARAMS		32

static int set_custom_key(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint64_t iova;
	struct dpkg_profile_cfg extract_cfg = { 0 };
	uint64_t ext_params[32] = { DPDMUX_CMD_EXTRACT_EXT_PARAMS };
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_SET_CUSTOM_KEY(cmd_data, iova);

	CHECK_COND_RETVAL(iova, -EINVAL);

	err = dpmng_dev_memcpy(dev, ext_params, iova,
			DPDMUX_CMD_EXTRACT_EXT_PARAMS * sizeof(uint64_t), 1);
	CHECK_COND_RETVAL(err == 0, err, "Error reading extended DMA parameters");

	/* Read extention, use DPNI code for now */
	err = dpkg_read_extract_cfg_extention(&extract_cfg, ext_params);
	CHECK_COND_RETVAL(err == 0, err);

	return dpdmux_set_custom_key(dpdmux, &extract_cfg);
}

static int add_custom_cls_entry_common(struct device *dev,
		struct mc_cmd_data *cmd_data, int version)
{
	struct dpdmux *dpdmux;
	uint8_t key[DPDMUX_CUSTOM_KEY_SIZE] = { 0 };
	uint8_t mask[DPDMUX_CUSTOM_KEY_SIZE] = { 0 };
	struct dpdmux_rule_cfg_tmp cfg = { 0 };
	struct dpdmux_rule_cfg rule = {
			.key = key,
			.mask = mask };
	int err;
	struct dpdmux_cls_action action = { 0 };

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	if( version == 1 ) {
		DPDMUX_CMD_ADD_CUSTOM_CLS_ENTRY_V1(cmd_data, &cfg, &action);
		cfg.entry_index = 0;
	}
	else {
		DPDMUX_CMD_ADD_CUSTOM_CLS_ENTRY(cmd_data, &cfg, &action);
	}

	rule.size = cfg.key_size;
	CHECK_COND_RETVAL((rule.size > 0) && (rule.size <= DPDMUX_CUSTOM_KEY_SIZE),
			-EINVAL,
			"key size must be > 0 and <= 24\n");

	if (cfg.key_iova) {
		err = dpmng_dev_memcpy(dev, key, cfg.key_iova,
				rule.size, 1);
		CHECK_COND_RETVAL(err == 0, err, "Error reading extended DMA parameters\n");
	}

	if (cfg.mask_iova) {
		err = dpmng_dev_memcpy(dev, rule.mask, cfg.mask_iova,
				rule.size, 1);
		CHECK_COND_RETVAL(err == 0, err, "Error reading extended DMA parameters\n");
	}
	else {
		memset(rule.mask, 0xff, cfg.key_size);
	}

	return dpdmux_add_custom_cls_entry(dpdmux, &rule, cfg.entry_index, &action);
}

static int add_custom_cls_entry_v1(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return add_custom_cls_entry_common(dev, cmd_data, 1);
}

static int add_custom_cls_entry_v2(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	return add_custom_cls_entry_common(dev, cmd_data, 2);
}

static int remove_custom_cls_entry(struct device *dev,
		struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint8_t key[DPDMUX_CUSTOM_KEY_SIZE] = { 0 };
	uint8_t mask[DPDMUX_CUSTOM_KEY_SIZE] = { 0 };
	struct dpdmux_rule_cfg_tmp cfg = { 0 };
	struct dpdmux_rule_cfg rule = {
			.key = key,
			.mask = mask };
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_REMOVE_CUSTOM_CLS_ENTRY(cmd_data, &cfg);

	rule.size = cfg.key_size;
	CHECK_COND_RETVAL((rule.size > 0) && (rule.size <= DPDMUX_CUSTOM_KEY_SIZE),
			-EINVAL, "key size must be > 0 and <= 24\n");

	if (cfg.key_iova) {
		err = dpmng_dev_memcpy(dev, key, cfg.key_iova,
				rule.size, 1);
		CHECK_COND_RETVAL(err == 0, err, "Error reading extended DMA parameters\n");
	}

	if (cfg.mask_iova) {
		err = dpmng_dev_memcpy(dev, rule.mask, cfg.mask_iova,
				rule.size, 1);
		CHECK_COND_RETVAL(err == 0, err, "Error reading extended DMA parameters\n");
	}
	else {
		memset(rule.mask, 0xff, cfg.key_size);
	}

	return dpdmux_remove_custom_cls_entry(dpdmux, &rule);
}

static int if_set_default(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_SET_DEFAULT(cmd_data, if_id);

	return dpdmux_set_default_if(dpdmux, if_id, (if_id > 0) ? 0 : 1);
}

static int if_get_default(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint16_t if_id;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	err = dpdmux_get_default_if(dpdmux, &if_id);
	if (!err)
		DPDMUX_RSP_IF_GET_DEFAULT(cmd_data, if_id);

	return err;
}

static int set_resetable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint8_t skip_reset_flags;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_SET_RESETABLE(cmd_data, skip_reset_flags);

	return dpdmux_set_resetable(dpdmux, skip_reset_flags);
}

static int get_resetable(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	uint8_t skip_reset_flags;
	int err;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	err = dpdmux_get_resetable(dpdmux, &skip_reset_flags);
	CHECK_COND_RETVAL(err == 0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));
	DPDMUX_RSP_GET_RESETABLE(cmd_data, skip_reset_flags);

	return err;
}

static int if_set_taildrop(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux_taildrop_cfg cfg;
	struct dpdmux *dpdmux;
	uint16_t if_id;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_SET_TAILDROP(cmd_data, if_id, (&cfg));

	return dpdmux_if_set_taildrop(dpdmux, if_id, &cfg);
}

static int if_get_taildrop(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	struct dpdmux_taildrop_cfg cfg;
	uint16_t if_id;
	int err = 0;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_GET_TAILDROP(cmd_data, if_id);

	err = dpdmux_if_get_taildrop(dpdmux, if_id, &cfg);
	if( !err ) {
		memset(cmd_data, 0, sizeof(struct mc_cmd_data));
		DPDMUX_RSP_IF_GET_TAILDROP(cmd_data, (&cfg));
	}

	return err;

}

static int dump_table(struct device *dev, struct mc_cmd_data *cmd_data)
{
	uint16_t table_type;
	uint64_t snapshot_iova;
	uint32_t iova_size;
	uint16_t table_size;
	uint16_t table_index;
	int err;

	DPDMUX_CMD_DUMP_TABLE(cmd_data, table_type, table_index, snapshot_iova, iova_size);

	err = dpdmux_dump_table(dev, table_type, table_index, snapshot_iova, (int)iova_size, &table_size);
	CHECK_COND_RETVAL(err==0, err);

	memset(cmd_data, 0, sizeof(struct mc_cmd_data));	
	DPDMUX_RSP_DUMP_TABLE(cmd_data, table_size);

	return 0;
}

static int if_set_errors_behavior(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct dpdmux *dpdmux;
	struct dpdmux_error_cfg error_cfg = { 0 };
	struct dpdmux_error_cfg *cfg = &error_cfg;
	uint16_t if_id;

	dpdmux = device_get_priv(dev);
	CHECK_COND_RETVAL(dpdmux, -ENODEV);

	DPDMUX_CMD_IF_SET_ERRORS_BEHAVIOR(cmd_data, if_id, cfg);

	return dpdmux_set_errors_behavior(dpdmux, if_id, cfg);
}

static int dpdmux_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev,
		                struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	/* New command handlers must be added at the end of the commands list */
	} map_commands[] = {
			{ DPDMUX_CMD_CODE_CREATE, init_v1, "dpdmux_init", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_DESTROY, destroy, "dpdmux_destroy", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_GET_ATTR, get_attributes_v0, "dpdmux_get_attributes", DPDMUX_CMD_V0 },
			{ DPDMUX_CMD_CODE_ENABLE, enable, "dpdmux_enable", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_DISABLE, disable, "dpdmux_disable", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_RESET, reset, "dpdmux_reset", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IS_ENABLED, is_enabled, "dpdmux_is_enabled", DPDMUX_CMD_VER_BASE },
#if 0
			{ DPDMUX_CMD_CODE_SET_SCHEDULING, set_scheduling, "dpdmux_set_scheduling", DPDMUX_CMD_VER_BASE },
#endif
			{ DPDMUX_CMD_CODE_SET_MAX_FRAME_LENGTH, set_max_frame_length, "dpdmux_set_max_frame_length", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_GET_COUNTER, if_get_counter, "dpdmux_if_get_counter", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_UL_RESET_COUNTERS, ul_reset_counters, "dpdmux_ul_reset_counters", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_SET_LINK_CFG, if_set_link_cfg_v1, "dpdmux_if_set_link_cfg", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_GET_LINK_STATE, if_get_link_state_v1, "dpdmux_if_get_link_state", DPDMUX_CMD_VER_BASE },
#if 0
			{ DPDMUX_CMD_CODE_IF_GET_TRANSMIT_RATE, if_get_transmit_rate, "dpdmux_if_get_transmit_rate", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_SET_TCI, if_set_tci, "dpdmux_if_set_tci", DPDMUX_CMD_VER_BASE },
#endif
#if 0
			{ DPDMUX_CMD_CODE_IF_SET_ACCEPTED_FRAMES, if_set_accepted_frames, "dpdmux_if_set_accepted_frames", DPDMUX_CMD_VER_BASE },
#endif
			{ DPDMUX_CMD_CODE_IF_GET_ATTR, if_get_attributes, "dpdmux_if_get_attributes", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_ENABLE, if_enable, "dpdmux_if_enable", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_DISABLE, if_disable, "dpdmux_if_disable", DPDMUX_CMD_VER_BASE },
#if 0
			{ DPDMUX_CMD_CODE_IF_SET_TRANSMIT_RATE, if_set_transmit_rate, "dpdmux_if_set_transmit_rate", DPDMUX_CMD_VER_BASE },
#endif
			{ DPDMUX_CMD_CODE_IF_ADD_L2_RULE, if_add_l2_rule, "dpdmux_if_add_l2_rule", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_REMOVE_L2_RULE, if_remove_l2_rule, "dpdmux_if_remove_l2_rule", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_SET_IRQ, set_irq, "dpdmux_set_irq", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_GET_IRQ, get_irq, "dpdmux_get_irq", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_SET_IRQ_ENABLE, set_irq_enable, "dpdmux_set_irq_enable", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_GET_IRQ_ENABLE, get_irq_enable, "dpdmux_get_irq_enable", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_SET_IRQ_MASK, set_irq_mask, "dpdmux_set_irq_mask", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_GET_IRQ_MASK, get_irq_mask, "dpdmux_get_irq_mask", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_GET_IRQ_STATUS, get_irq_status, "dpdmux_get_irq_status", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_CLEAR_IRQ_STATUS, clear_irq_status, "dpdmux_clear_irq_status", DPDMUX_CMD_VER_BASE },

			/* New command handlers start here */
			{ DPDMUX_CMD_CODE_GET_API_VERSION, get_api_version, "dpdmux_get_api_version", DPDMUX_CMD_V1 },
			{ DPDMUX_CMD_CODE_GET_ATTR, get_attributes_v1, "dpdmux_get_attributes", DPDMUX_CMD_V1 },
			{ DPDMUX_CMD_CODE_SET_CUSTOM_KEY, set_custom_key, "dpdmux_set_custom_key", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_ADD_CUSTOM_CLS_ENTRY, add_custom_cls_entry_v1, "dpdmux_add_custom_cls_entry", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_REMOVE_CUSTOM_CLS_ENTRY, remove_custom_cls_entry, "dpdmux_remove_custom_cls_entry", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_SET_DEFAULT, if_set_default, "dpdmux_if_set_default", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_GET_DEFAULT, if_get_default, "dpdmux_if_get_default", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_SET_LINK_CFG, if_set_link_cfg_v2, "dpdmux_if_set_link_cfg", DPDMUX_CMD_V2 },
			{ DPDMUX_CMD_CODE_IF_GET_LINK_STATE, if_get_link_state_v2, "dpdmux_if_get_link_state", DPDMUX_CMD_V2 },
			{ DPDMUX_CMD_CODE_ADD_CUSTOM_CLS_ENTRY, add_custom_cls_entry_v2, "dpdmux_add_custom_cls_entry", DPDMUX_CMD_V2 },
			{ DPDMUX_CMD_CODE_CREATE, init_v2, "dpdmux_init", DPDMUX_CMD_V2 },
			{ DPDMUX_CMD_CODE_CREATE, init_v3, "dpdmux_init", DPDMUX_CMD_V3 },
			{ DPDMUX_CMD_CODE_GET_ATTR, get_attributes_v2, "dpdmux_get_attributes", DPDMUX_CMD_V2 },
			{ DPDMUX_CMD_CODE_SET_RESETABLE, set_resetable, "dpdmux_set_resetable", DPDMUX_CMD_V1 },
			{ DPDMUX_CMD_CODE_GET_RESETABLE, get_resetable, "dpdmux_get_resetable", DPDMUX_CMD_V1 },
			{ DPDMUX_CMD_CODE_IF_SET_TAILDROP, if_set_taildrop, "dpdmux_if_set_taildrop", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_GET_TAILDROP, if_get_taildrop, "dpdmux_if_get_taildrop", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_DUMP_TABLE, dump_table, "dpdmux_dump_table", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_IF_SET_ERRORS_BEHAVIOR, if_set_errors_behavior, "dpdmux_if_set_errors_behavior", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_GET_MAX_FRAME_LENGTH, get_max_frame_length, "dpdmux_get_max_frame_length", DPDMUX_CMD_VER_BASE },
			{ DPDMUX_CMD_CODE_CREATE, init_v4, "dpdmux_init", DPDMUX_CMD_V4 },
			{ DPDMUX_CMD_CODE_GET_ATTR, get_attributes_v3, "dpdmux_get_attributes", DPDMUX_CMD_V3 },
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) && 
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))){
			if (cmd == DPDMUX_CMD_CODE_CREATE)
				pr_info("Handling command: %s\n", map_commands[i].cmd_str);
			else
				pr_info("Handling command: %s on DPDMUX %d\n", map_commands[i].cmd_str, device_get_id(dev));
			return map_commands[i].function((struct device *)dev,
			                                cmd_data);
	}

        pr_err("Invalid command %d\n",cmd);
        return -ENOTSUP;
}

static enum dpdmux_method get_dpdmux_method(void *lo, int node_off)
{
	char *opt_str;
	int i,len;
	struct {
		char *opt_str;
		enum dpdmux_method method;
	} map[] = {
	                    { "DPDMUX_METHOD_NONE", DPDMUX_METHOD_NONE },
	                    { "DPDMUX_METHOD_C_VLAN_MAC", DPDMUX_METHOD_C_VLAN_MAC },
	                    { "DPDMUX_METHOD_MAC", DPDMUX_METHOD_MAC },
	                     { "DPDMUX_METHOD_C_VLAN", DPDMUX_METHOD_C_VLAN },
	                     { "DPDMUX_METHOD_S_VLAN", DPDMUX_METHOD_S_VLAN },
	                    { "DPDMUX_METHOD_CUSTOM", DPDMUX_METHOD_CUSTOM },
#ifdef IP_SUPPORT
	                     { "DPDMUX_METHOD_IPV4", DPDMUX_METHOD_IPV4 },
	                     { "DPDMUX_METHOD_IPV6", DPDMUX_METHOD_IPV6 }
#endif
	};

	opt_str = (char *)fdt_getprop(lo, node_off, "method", &len);
	for ( i = 0 ; i < ARRAY_SIZE(map) ; i++)
		if (!strcmp(opt_str, map[i].opt_str))
			return map[i].method;
	pr_err("method is not defined correctly in layout - setting default to DPDMUX_METHOD_NONE\n");
	return DPDMUX_METHOD_NONE;
}

static enum dpdmux_manip get_dpdmux_manip(void *lo, int node_off)
{
	char *opt_str;
	int i,len;
	struct {
		char *opt_str;
		enum dpdmux_manip manip;
	} map[] = {
	                    { "DPDMUX_MANIP_NONE", DPDMUX_MANIP_NONE },
	                    { "DPDMUX_MANIP_ADD_REMOVE_S_VLAN", DPDMUX_MANIP_ADD_REMOVE_S_VLAN }
	};

	opt_str = (char *)fdt_getprop(lo, node_off, "manip", &len);
	for ( i = 0 ; i < ARRAY_SIZE(map) ; i++)
		if (!strcmp(opt_str, map[i].opt_str))
			return map[i].manip;
	pr_err("manip is not defined correctly in layout - setting default to DPDMUX_METHOD_NONE\n");
	return DPDMUX_MANIP_NONE;
}

static uint64_t get_options(void *lo, int node_off)
{
	char *opt_str;
	int total_len;
	int len;
	int i = 0;
	uint64_t options = 0;
	struct {
		char *opt_str;
		uint64_t options;
	} map[] = {
				{ "DPDMUX_OPT_BRIDGE_EN", DPDMUX_OPT_BRIDGE_EN },
				{ "DPDMUX_OPT_CLS_MASK_SUPPORT", DPDMUX_OPT_CLS_MASK_SUPPORT },
				{ "DPDMUX_OPT_AUTO_MAX_FRAME_LEN", DPDMUX_OPT_AUTO_MAX_FRAME_LEN },
	};

	opt_str = (char *)fdt_getprop(lo, node_off, "options", &total_len);

	if (opt_str && (int)(*opt_str) != 0 ) {
		while (total_len > 0){
			while (i < (ARRAY_SIZE(map) - 1) && strcmp(opt_str,map[i].opt_str))
				i++;
			if (!strcmp(opt_str,map[i].opt_str))
				options |= map[i].options;
			len = (int)strlen(opt_str) + 1;
			total_len -= len;
			opt_str = PTR_MOVE(opt_str, len );
			i=0;
		}
	}

	return options;
}

static int dpdmux_probe_cb(void *lo, int node_off)
{
	int err = 0;
	struct mc_cmd_data cmd = { 0 };
	struct mc_cmd_data *cmd_data = &cmd;
	struct device *dev;
	struct resman *resman;
	struct dpdmux_cfg dpdmux_cfg;
	struct dpdmux_cfg *cfg = &dpdmux_cfg;
//	int subnode_off;
	int id;
	uint64_t val;
	int destroy = 0;

	memset(&dpdmux_cfg, 0, sizeof(struct dpdmux_cfg));
	/* get dpdmux ID */
	err = get_node_id(lo, node_off, &id);
	CHECK_COND_RETVAL(err == 0, err);

	/* DPSW cfg */
	dpdmux_cfg.method = get_dpdmux_method(lo, node_off);
	dpdmux_cfg.manip = get_dpdmux_manip(lo, node_off);
	if(getprop_val(lo, node_off, "num_ifs", 0, 0, &val)){
		pr_err("'num_ifs' is a required field for layout dpdmux\n");
		return -EINVAL;
	}
	dpdmux_cfg.num_ifs = (uint16_t)val;
	getprop_val(lo, node_off, "default_if", 0, 0, &val);
	dpdmux_cfg.default_if = (uint16_t)val;
	dpdmux_cfg.adv.options = get_options(lo, node_off);
	getprop_val(lo, node_off, "max_dmat_entries", 0, 0, &val);
	dpdmux_cfg.adv.max_dmat_entries = (uint16_t)val;
	getprop_val(lo, node_off, "max_mc_groups", 0, 0, &val);
	dpdmux_cfg.adv.max_mc_groups = (uint16_t)val;
	getprop_val(lo, node_off, "max_vlan_ids", 0, 0, &val);
	dpdmux_cfg.adv.max_vlan_ids = (uint16_t)val;
	getprop_val(lo, node_off, "mem_size", 0, 0, &val);
	dpdmux_cfg.adv.mem_size = (uint16_t)val;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV, "Can't find resman");
	/* create & open resman device */
	dev = resman_open_dev(resman, "dpdmux", (uint16_t)id,  NO_PORTAL_ID,
			DPRC_OPEN_DEV_ONLY, NULL);
	CHECK_COND_RETVAL(dev, -ENODEV, "Can't create DPDMUX %.4x\n",id);

	DPDMUX_LO_CREATE_V3(cmd_data, cfg);
	/* create object */
	err = dpdmux_ctrl_cb(dev, DPDMUX_CMD_V4, DPDMUX_CMD_CODE_CREATE,
			NO_PORTAL_ID, (uint8_t*)cmd_data);
	if (err)
		destroy = 1;

	err = resman_close_dev(resman, dev, "dpdmux", NO_PORTAL_ID, destroy);

	return err;
}

static int dpdmux_remove_cb(void *lo, int node_off)
{
	UNUSED(lo);
	UNUSED(node_off);

	return 0;
}

static char *dpdmux_match[] = { "fsl,dpdmux", "dpdmux" };

int dpdmux_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	struct linkman *linkman;
	int err = 0;

	pr_info("Executing dpdmux_drv_init...\n");
	
	dtc_params.num_compats = ARRAY_SIZE(dpdmux_match);
	dtc_params.compatibles = dpdmux_match;
	dtc_params.f_prob_module = dpdmux_probe_cb;
	dtc_params.f_remove_module = dpdmux_remove_cb;
	err = sys_dtc_register_module(&dtc_params);
	CHECK_COND_RETVAL(err == 0, err);

	cmdif_ops.open_cb = dpdmux_open_cb;
	cmdif_ops.close_cb = dpdmux_close_cb;
	cmdif_ops.ctrl_cb = dpdmux_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	err = cmdif_register_module(CMDIF_MOD_DPDMUX, &cmdif_ops);
	CHECK_COND_RETVAL(err == 0, err);

	strcpy(dev_type_param.device_type, "dpdmux");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPDMUX_MAX_IRQ_NUM;
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPDMUX_VER_MAJOR;
	dev_type_param.ver_minor = DPDMUX_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENAVAIL);

	err = resman_register_device_operation(resman, "dpdmux",
	                                 &dev_type_param);
	if (err != 0)
		return err;

	/*! Register link manager */
	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	CHECK_COND_RETVAL(linkman, -ENAVAIL);
	err = linkman_register_cb(linkman,
	                          FSL_MOD_DPDMUX,
	                          dpdmux_event_cb,
	                          dpdmux_event_complete_cb);

	return err;
}
