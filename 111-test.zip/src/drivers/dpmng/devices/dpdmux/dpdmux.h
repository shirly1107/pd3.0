/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
@File          dpdmux.h

@Description   DPDMUX library implementation

@Cautions      None.
*//***************************************************************************/

#ifndef __DPDMUX_H
#define __DPDMUX_H

/* STL (Standard Template Library )*/
#include "common/fsl_string.h"			/* memcpy */
#include "fsl_errors.h"			/* errors */
/* Operating System */
#include "fsl_platform.h"			/* sys_get_handle */
/* QMan & BMan */
#include "drivers/fsl_qbman_portal.h"		/* BMan */
#include "drivers/fsl_qbman_portal_ex.h"	/* CEETM */
#include "fsl_qbman.h"				/* qbman_desc */
/* WRIOP */
#include "fsl_eiop_ifp.h"			/* IFP */
#include "fsl_eiop.h"				/* Dequeue Context */
/* Services */
#include "fsl_resman.h"				/* Resource Manager */
#include "fsl_dpmng_mc.h"			/* get SWP */
/* System API */
#include "fsl_sys.h"		/* sys_get_handle */

#include "fsl_dpparser.h"
#include "fsl_dppolicy.h"
#include "fsl_dpkg.h"
#include "fsl_dptbl.h"
#include "fsl_event_pipe.h"
#include "fsl_qbman.h"				/* qbman_desc */
#include "fsl_ctlu.h"

#include "fsl_types.h"
#include "fsl_replic.h"
#include "fsl_hmap.h"
#include "fsl_dpdmux_mc.h"		/* Internal (MC) API */
#include "fsl_dpbp_mc.h"
#include "fsl_dpmac_mc.h"		/*! Internal (DPMAC) API */
#include "fsl_dpni_mc.h"
#include "fsl_ceetm_if.h"		/* ceetm interface */
#include "fsl_dpqos.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPDMUX

#define DPDMUX_OPT_REPLICATION_DIS 0x0000000000000001 /* !< Disable replication */

#define DPDMUX_MAX_POLICY  		3
#define DPDMUX_POLICY_ALL 		0
#define DPDMUX_POLICY_TAG_ONLY  	1
#define DPDMUX_POLICY_UN_TAG_ONLY   	2
#define DPDMUX_MAX_POLICY_RULES		10

#define DPDMUX_POLICY_PRI_ERR		0	/* High priority */
#define DPDMUX_POLICY_PRI_1_VLAN	1
#define DPDMUX_POLICY_PRI_N_VLAN	2

#define DPDMUX_MAX_KG			5
#define DPDMUX_KG_DMAT_IDX		0
#define DPDMUX_KG_MISS_IDX		1
#define DPDMUX_KG_PRUNE_IDX		2


#define DPDMUX_MAX_TBL 			3
#define DPDMUX_DMAT_IDX                	0
#define DPDMUX_MISS_TBL_IDX           	1
#define DPDMUX_PRUNE_TBL_IDX           	2

#define DPDMUX_MAX_HMAP			4
#define DPDMUX_HMAP_UNICAST_IDX		0
#define DPDMUX_HMAP_PRUNE_IDX		1
#define DPDMUX_HMAP_MULTICAST_IDX	2
#define DPDMUX_HMAP_MISS_IDX		3


#define DPDMUX_MAC_KEY_SIZE		6
#define DPDMUX_VLAN_KEY_SIZE		2
#define DPDMUX_VLAN_MAC_KEY_SIZE	\
			DPDMUX_MAC_KEY_SIZE + DPDMUX_VLAN_KEY_SIZE

#define DPDMUX_UL_INDEX 		0
#define DPDMUX_FIRST_VIRT_IF         	1

/* Default Parameters */
#define DPDMUX_MAX_MISS_KEY_SIZE        3
#define MAX_FRAME_LENGTH		1536

#define DPDMUX_BP_MEMORY_ALIGN	256		/* alignment in bytes */
#define DPDMUX_BP_BUFFER_SIZE	256		/* size of one buffer */
#define DPDMUX_BP_MEMORY_SIZE	(256 * KILOBYTE)	/* L2 Switch PEB size */
#define DPDMUX_BP_CHUNK		7

#define DPDMUX_NUM_UNICAST_ADDR 16

#define DPDMUX_CHID          0xFF0

#define DPDMUX_IFP_PRUNE_TBL_KEY_SIZE   2
#define DPDMUX_SRC_MAC_PRUNE_TBL_KEY_SIZE   6

#define DPDMUX_MISS_ENTRY_KEY_IN_VLAN_METHOD  0xffff /* this is the indication in the hmap_multicast of the miss 
                                                      * entry in the dmat when the method is vlan only */

#define DEFAULT_BURST_DURATION  5	/* five milliseconds */

#define KBIT_PER_SECOND	1000UL
#define MBIT_PER_SECOND	(KBIT_PER_SECOND * KBIT_PER_SECOND)
#define GBIT_PER_SECOND	(KBIT_PER_SECOND * MBIT_PER_SECOND)
#define MS_IN_SECOND	1000UL

#define SCHED_UPPER_BOUND 		10000
#define SCHED_LOWER_BOUND 		100
#define DPDMUX_BUFFER_DEPLETION_CCGIDX	0
#define DPDMUX_TAIL_DROP_CCGIDX		1
#define DPDMUX_TAIL_DROP_THRESHOLD     	((20 * KILOBYTE)/DPDMUX_BP_BUFFER_SIZE)

enum dpdmux_counter_operation {
	DPDMUX_CNT_OPERATION_ADD = 0x0,
	DPDMUX_CNT_OPERATION_SUB = 0x1,
	DPDMUX_CNT_OPERATION_SET = 0x2
};

struct dpdmux_hndl {
    struct dpparser     *dpparser_ing;  /* Ingress Parser */
    struct dpparser     *dpparser_egr;  /* Egress Parser */
    struct dppolicy_mng *dppolicy_ing;  /* Ingress FALU */
    struct dpkg     	*dpkg_ing;  	/* Ingress Key Generation */
    struct dpkg     	*dpkg_egr;  	/* Egress Key Generation */
    struct dptbl_mng    *dptbl_ing; 	/* Ingress Tables */
    struct dpqos_mng 	*dpqos_ing;		/* QoS tables */
    struct linkman      *linkman;   	/* Link manager */
    struct dpmng        *dpmng;     	/* General manager */
    struct device       *dprc;      	/* Resource manager */
};

struct dpdmux_id {
    int         inuse;  /*! in use flag */
    int         id;     /*! ID */
};

struct dpdmux_replicator {
    int         	qdid;       /*! QDID */
    int             	qprid; /*! Queue pri record ID */
    int         	fqid;       /*! Frame Queue ID */
    int             	cgid;       /*! Congestion Group ID */
    int             	max_pri;        /*! max priorities */
};

/**************************************************************************//**
@Collection    Internal structures

@{
 *//***************************************************************************/

/**
 * @brief	Policy internal structure
 */
struct dpdmux_policy {
	struct dppolicy		*handle;	/**< Policy handle */
	int			id;		/**< Policy ID */
};

/**
 * @brief	DMux Address Table internal structure
 */
struct dpdmux_table {
	struct dptbl		*handle;	/**< table handle */
	int			id;		/**< table ID */
	uint32_t		key_size;
};

/**
 * @brief	DMux Address Table internal structure
 */
struct dpdmux_prune {
	struct dpdmux_table		table;	/**< table structure */
	struct dpdmux_id                kg;	/**< kg structure */
};

/**************************************************************************//**
@Description   Traffic class structure

*//***************************************************************************/
struct dpdmux_tc {
	int	lfqmtidx;	/**< Logical Frame Queue Mapping idx */
};

/**************************************************************************//**
@Description    CEETM Queuing Priority

 *//***************************************************************************/
struct dpdmux_qpri {
	int 	qprid; 		/**< Queuing priority record ID */
	int 	tc;		/**< Traffic Class */
};

struct dpdmux_cqch {
	int		dcpid;		/*! Direct Connect Portal ID */
	int		instance_id;	/*! CEETM Instance ID */
	int 		cqchid; 	/*! CEETM Class Queue Channel */

	int             cqch_connected; /*! indicates if the channel is already
	connected to the physical port - relevant in case of VEPA mode */
	int 		cqch_valid;

};

struct dpdmux_ifp {
	int		id;		/*! Direct Connect Portal ID */
	int 		valid;
};

struct dpdmux_irq {
        uint16_t        event;
        int             pending;
};

#define DPDMUX_LINKRES_CONNECTION_ALLOCATED	0x00000001ul
#define DPDMUX_LINKRES_AP_CONNECTED			0x00000002ul
#define DPDMUX_LINKRES_ALLOC_BW				0x00000004ul
#define DPDMUX_LINKRES_CHANNEL_ALLOCATED	0x00000008ul
#define DPDMUX_LINKRES_LFQ_ALLOCATED		0x00000010ul

/**
 * @brief	DMux interface internal structure
 */
struct dpdmux_if {
	int			multicast_promisc;	/* mucast promiscuous */
	int			unicast_promisc;	/* unicast promiscuous*/
	struct dpdmux_tci_val 		tci;		
	struct dpdmux_accepted_frames 	accept_frame_types;

	/* dpni lookup information for forwarding frame to this interface */
	int		kid;
	int		tid;

	/* Enable/Disable */
	int		enable;
	
	/* Initial Parameters */
	int         	policy_id;

	/* resources */
	int 		conn_id;	/* connection id */
	struct dpmng_accesspoint ap;	/* access-point */
        
	/* handlers */
	struct dpqos			*dpqos;	/* QoS Mapping handler */
        struct ceetm_if                 *ceetm_if;        

	int next_ifpid;/* required for dpdmux_if_get_counter - VEPA mode */

	/* configurations */
	struct dpdmux_link_cfg		link_cfg;
    struct dpdmux_tx_selection_cfg	tx_sel;	/* transmission selection cfg */
    int fc_idx; /* channel index to perform flow control in recycle port connections */

    /* Counters */
    uint64_t 			counters[DPDMUX_MAX_CNT];

	/* IRQ  */
	struct dpdmux_irq		irq;

	uint32_t link_res_flags; /* keep track of the resources allocated during
								connection procedure. Used to deallocate
								resources when an error appeared while connecting*/

	uint16_t mfl;

	int num_lfq;		/* number of LFQ's allocated for this interface */
	struct dpdmux_early_drop_cfg drop_cfg;		/* Temporary store for drop configuration */
};

/**
 * hmap data stored with the keys
 */
struct dpdmux_hmap_data {
	enum dpdmux_owner owner;
	int priority;
	uint8_t mask[DPDMUX_CUSTOM_KEY_SIZE];
};

/**
 * @brief	DMux internal structure
 */
struct dpdmux {
	int		id;
	int     		ceetm_id;

	uint64_t 		options;/*!< DMux options */
	uint16_t 		max_dmat_entries;
				/*!< max entries in DMux address table */
	uint16_t 		max_vlan_ids;
				/*!< max allowed vlans in DMux address table */
	uint16_t		mem_size;
				/*!< max allowed memory usage for DMux */
	uint16_t 		dmux_control_num_entries;
				/*!< max entries per DMux control table */
	uint16_t 		max_frame_length;
	uint16_t 		max_mc_groups;

	enum dpdmux_method method;
	enum dpdmux_manip  manip;

	/* internal parameters */
	struct dpbp		*dpbp;		/*!< Buffer pool */
	struct dpdmux_policy	policy[DPDMUX_MAX_POLICY];
	struct dpdmux_id	kg[DPDMUX_MAX_KG];
	struct dpdmux_table	table[DPDMUX_MAX_TBL];
//	struct dpdmux_prune     prune_info;
	int			err_fqid;	/*! Error FQID */

	/* DMux interface information */
	uint16_t		num_ifs; /*!< Number of virtual interfaces */
	struct dpdmux_if	*iface;  /*!< interfaces dbase */

	uint16_t    		default_if;
				/*!< the ID of the default interface */
	uint16_t    		default_create_if;
					/*!< the ID of the default interface set at create, used for reset*/

        /**< Resource Manager information */
	void 		*resman;

   	struct mc_irq irqs[DPDMUX_MAX_IRQ_NUM];

	/*! resources */
   	struct dpdmux_id 	prp_ing;	/*! Parser Profile ID, Ingress */
   	struct dpdmux_id 	prp_egr;	/*! Parser Profile ID, Egress */

   	/*! Miscellaneous */
   	struct dpdmux_hndl	hndl;		/*! handlers */

   	/*! replication */
   	struct dpdmux_replicator replicator;
//   	struct hmap *hmap_multicast;
//   	struct hmap *hmap_miss;

   	/*unicast handling */
   	//struct hmap *hmap_unicast;
	struct hmap	*hmap[DPDMUX_MAX_HMAP];

	int added_broadcast_address;
	int added_ul_in_miss;
   	int ul_allocated; /* required for dpmng */
	struct dpmac *dpmac;

	int custom_cls_rule_size;

#ifdef TKT508412
	struct dpdmux_table fc_filtering_tbl;
	struct dpdmux_id fc_filtering_kid;
#endif

	/* Flags used to chose what to NOT reset */
	uint8_t skip_reset_flags;
};

/* @} */

#endif /* __DPDMUX_H */

