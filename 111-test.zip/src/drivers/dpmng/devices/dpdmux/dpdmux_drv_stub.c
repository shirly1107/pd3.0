/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dpdmux_drv_stub.c

 @Description   Driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "kernel/layout.h"
#include "dplib/fsl_dpdmux_cmd.h"
#include "fsl_event_pipe.h"
#include "fsl_dpdmux_mc.h"
#include "fsl_cmdif.h"
#include "fsl_dbg.h"
#include "kernel/device.h"
#include "fsl_sys.h"
#include "fsl_cmdif_mc.h"
#include "dtc/dtc.h"

int dpdmux_drv_init(void);

static int assign(struct device *dev, const struct dpmng_dev_ctx *dev_ctx)
{
	UNUSED(dev);
	UNUSED(dev_ctx);

	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int reset_by_resman(struct device *dev)
{
	UNUSED(dev);
	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int destroy_by_resman(struct device *dev)
{
	pr_err("DPDMUX is not supported in this SOC!\n");
	return 0;
}


static int dpdmux_open_cb(void *dev, int portal_id)
{
	UNUSED(dev);
	UNUSED(portal_id);
	
	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpdmux_close_cb(void *dev, int portal_id, uint32_t token)
{
	UNUSED(dev);
	UNUSED(portal_id);
	
	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int set_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	UNUSED(dev);
	UNUSED(irq_cfg);
	UNUSED(irq_index);

	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int get_irq_by_resman(struct device *dev, struct mc_irq_cfg *irq_cfg, int irq_index)
{
	UNUSED(dev);
	UNUSED(irq_cfg);
	UNUSED(irq_index);

	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpdmux_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	UNUSED(dev);
	UNUSED(cmd);
	UNUSED(portal_id);
	UNUSED(data);

	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

static int dpdmux_probe_cb(void *lo, int node_off)
{
	UNUSED(lo);
	UNUSED(node_off);
	
	pr_warn("DPDMUX defined in DPL - Not supported in this SOC!\n");
	return 0;
}

static int dpdmux_remove_cb(void *lo, int node_off)
{
	UNUSED(lo);
	UNUSED(node_off);

	return 0;
}

static char *dpdmux_match[] = { "fsl,dpdmux", "dpdmux" };

int dpdmux_drv_init(void)
{
	t_sys_dtc_mod_params dtc_params = { 0 };
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dp_dev_type_param dev_type_param = { 0 };
	struct resman *resman;
	struct linkman *linkman;
	int err = 0;
	
	dtc_params.num_compats = ARRAY_SIZE(dpdmux_match);
	dtc_params.compatibles = dpdmux_match;
	dtc_params.f_prob_module = dpdmux_probe_cb;
	dtc_params.f_remove_module = dpdmux_remove_cb;
	err = sys_dtc_register_module(&dtc_params);
	if (err != 0)
		return err;

	cmdif_ops.open_cb = dpdmux_open_cb;
	cmdif_ops.close_cb = dpdmux_close_cb;
	cmdif_ops.ctrl_cb = dpdmux_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	err = cmdif_register_module(CMDIF_MOD_DPDMUX, &cmdif_ops);
	if (err != 0)
		return err;

	strcpy(dev_type_param.device_type, "dpdmux");
	dev_type_param.flags = 0;
	dev_type_param.irq_count = DPDMUX_MAX_IRQ_NUM;/*TODO */
	dev_type_param.region_count = 0;
	dev_type_param.ver_major = DPDMUX_VER_MAJOR;
	dev_type_param.ver_minor = DPDMUX_VER_MINOR;
	dev_type_param.vendor = 0x1957;
	dev_type_param.f_destroy = destroy_by_resman;
	dev_type_param.f_reset = reset_by_resman;
	dev_type_param.f_assign = assign;
	dev_type_param.f_set_irq = set_irq_by_resman;
	dev_type_param.f_get_irq = get_irq_by_resman;
//	       dev_type_param.max_quota = ?;
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	ASSERT_COND(resman);

	err = resman_register_device_operation(resman, "dpdmux",
	                                 &dev_type_param);
	return err;
}

int dpdmux_if_remove_l2_rule(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_l2_rule *l2_rule,
	enum dpdmux_owner owner)
{
	UNUSED(dpdmux);
	UNUSED(if_id);
	UNUSED(l2_rule);
	UNUSED(owner);

	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

int dpdmux_if_add_l2_rule(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_l2_rule *l2_rule,
	enum dpdmux_owner owner)
{
	UNUSED(dpdmux);
	UNUSED(if_id);
	UNUSED(l2_rule);
	UNUSED(owner);

	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

int dpdmux_if_set_multicast_promisc(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t vlan_id,
	int en)
{
	UNUSED(dpdmux);
	UNUSED(if_id);
	UNUSED(vlan_id);
	UNUSED(en);

	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

int dpdmux_if_set_unicast_promisc(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t vlan_id,
	int en)
{
	UNUSED(dpdmux);
	UNUSED(if_id);
	UNUSED(vlan_id);
	UNUSED(en);

	pr_err("DPDMUX is not supported in this SOC!\n");
	return -ENOTSUP;
}

int dpdmux_get_ap_ppid(struct dpdmux *dpdmux, int if_id, int *ppid)
{
	UNUSED(dpdmux);
	UNUSED(if_id);
	UNUSED(ppid);

	return -ENOTSUP;
}

int dpdmux_clean_flow_control_config(struct dpdmux *dpdmux, int if_id)
{
	UNUSED(dpdmux);
	UNUSED(if_id);

	return -ENOTSUP;
}

int dpdmux_if_update_max_frame_len(struct dpdmux *dpdmux, uint16_t if_id, uint16_t max_frame_len)
{
	UNUSED(dpdmux);
	UNUSED(if_id);
	UNUSED(max_frame_len);

	return -ENOTSUP;
}

int dpdmux_get_mac_rate(struct dpdmux *dpdmux, uint32_t *rate)
{
	*rate = 0;

	return 0;
}

int dpdmux_get_id(struct dpdmux *dpdmux, uint16_t *id)
{
	*id = 0;
	return 0;
}

int dpdmux_get_num_ifs(struct dpdmux *dpdmux, uint16_t *num_ifs)
{
	*num_ifs = 0;
	return 0;
}
