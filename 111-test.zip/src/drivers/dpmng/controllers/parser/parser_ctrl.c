/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_soc.h"
#include "parser_ctrl.h"

#include "ctlu.h"
#include "fsl_dpparser.h"

/******************************************************************************/
/** EIOP/AIOP parsers driver structure */
static struct parser_ctrl	parser_ctrl;

/******************************************************************************/
static inline struct parser_regs *parser_ctrl_get_regs_ptr(enum ctlu_type ptype)
{
	struct parser_regs	*regs;

	switch (ptype) {
	case CTLU_EIOP_INGRESS:
		regs = parser_ctrl.eiop_ingress.regs;
		break;
	case CTLU_EIOP_EGRESS:
		regs = parser_ctrl.eiop_egress.regs;
		break;
	case CTLU_AIOP:
		regs = parser_ctrl.aiop_ctlu.regs;
		break;
	default:
		pr_warn("Not supported CTLU type 0x%x\n", ptype);
		regs = 0;
		break;
	}
	return regs;
}

/******************************************************************************/
static inline uint32_t *parser_ctrl_get_mem_ptr(enum ctlu_type ptype)
{
	uint32_t	*pmem;

	switch (ptype) {
	case CTLU_EIOP_INGRESS:
		pmem = parser_ctrl.eiop_ingress.mem;
		break;
	case CTLU_EIOP_EGRESS:
		pmem = parser_ctrl.eiop_egress.mem;
		break;
	case CTLU_AIOP:
		pmem = parser_ctrl.aiop_ctlu.mem;
		break;
	default:
		pr_warn("Not supported CTLU type 0x%x\n", ptype);
		pmem = 0;
		break;
	}
	return pmem;
}

/******************************************************************************/
static void parser_ctrl_dump_regs(enum ctlu_type ptype)
{
	struct parser_regs	*regs;

	regs = parser_ctrl_get_regs_ptr(ptype);
	switch (ptype) {
	case CTLU_EIOP_INGRESS:
		pr_info("EIOP INGRESS parser registers at 0x%08x\n",
			(uint32_t)regs);
		break;
	case CTLU_EIOP_EGRESS:
		pr_info("EIOP EGRESS parser registers at 0x%08x\n",
			(uint32_t)regs);
		break;
	case CTLU_AIOP:
		pr_info("AIOP CTLU parser registers at 0x%08x\n",
			(uint32_t)regs);
		break;
	default:
		break;
	}
	if (!regs)
		return;
	pr_info("\t CFG      = 0x%08x\n", ioread32(&regs->cfg));
	pr_info("\t IDLE     = 0x%08x\n", ioread32(&regs->idle));
	pr_info("\t PCLIM    = 0x%08x\n", ioread32(&regs->pclim));
	pr_info("\t IP_REV_1 = 0x%08x\n", ioread32(&regs->ip_rev_1));
	pr_info("\t IP_REV_2 = 0x%08x\n", ioread32(&regs->ip_rev_2));
}

/******************************************************************************/
void parser_ctrl_dump_mem(enum ctlu_type ptype)
{
	uint32_t	*pmem, val32;
	int		i;

	pmem = parser_ctrl_get_mem_ptr(ptype);
	switch (ptype) {
	case CTLU_EIOP_INGRESS:
		pr_info("EIOP INGRESS parser memory at 0x%08x\n",
			(uint32_t)pmem);
		break;
	case CTLU_EIOP_EGRESS:
		pr_info("EIOP EGRESS parser memory at 0x%08x\n",
			(uint32_t)pmem);
		break;
	case CTLU_AIOP:
		pr_info("AIOP CTLU parser memory at 0x%08x\n",
			(uint32_t)pmem);
		break;
	default:
		break;
	}
	if (!pmem)
		return;
	fsl_print("\n\t 020 (040) : ");
	for (i = 0; i < PARSER_MEM_SIZE; i++) {
		val32 = ioread32(pmem++);
		fsl_print("%08x ", val32);
		if (!((i + 1) % 8))
			fsl_print("\n\t %03x (%03x) : ",
				  (0x40 + 4 * (i + 1)) / 2,
				  0x40 + 4 * (i + 1));
	}
	fsl_print("\n");
}

/******************************************************************************/
static inline int parser_ctrl_stop(enum ctlu_type ptype)
{
	struct parser_regs	*regs;
	uint32_t		cfg, idle;
	int			retry;

	regs = parser_ctrl_get_regs_ptr(ptype);
	if (!regs)
		return -ENODEV;
	retry = PARSER_STOP_RETRY;
	/* Disable parser */
	do {
		cfg = ioread32(&regs->cfg) & ~PARSER_ENABLE;
		iowrite32(cfg, &regs->cfg);
		idle = ioread32(&regs->idle);
		retry--;
	} while (!(idle & PARSER_IDLE) && retry > 0);
	if (retry <= 0) {
		pr_warn("Can't stop parser after %d retries !\n",
			PARSER_STOP_RETRY);
		return -ENODEV;
	}
	return 0;
}

/******************************************************************************/
static inline void parser_ctrl_start(enum ctlu_type ptype)
{
	struct parser_regs	*regs;
	uint32_t		cfg;

	regs = parser_ctrl_get_regs_ptr(ptype);
	if (!regs)
		return;
	/* Enable parser */
	cfg = ioread32(&regs->cfg) | PARSER_ENABLE;
	iowrite32(cfg, &regs->cfg);
}

/******************************************************************************/
uint32_t parser_ctrl_get_pclim(enum ctlu_type ptype)
{
	struct parser_regs	*regs;

	regs = parser_ctrl_get_regs_ptr(ptype);
	if (!regs)
		return 0;
	return ioread32(&regs->pclim);
}

/******************************************************************************/
uint32_t parser_ctrl_get_ip_rev_1(enum ctlu_type ptype)
{
	struct parser_regs	*regs;

	regs = parser_ctrl_get_regs_ptr(ptype);
	if (!regs)
		return 0;
	return ioread32(&regs->ip_rev_1);
}

/******************************************************************************/
uint32_t parser_ctrl_get_ip_rev_2(enum ctlu_type ptype)
{
	struct parser_regs	*regs;

	regs = parser_ctrl_get_regs_ptr(ptype);
	if (!regs)
		return 0;
	return ioread32(&regs->ip_rev_2);
}

/******************************************************************************/
void parser_ctrl_set_pclim(uint32_t limit, enum ctlu_type ptype)
{
	struct parser_regs	*regs;

	regs = parser_ctrl_get_regs_ptr(ptype);
	if (!regs)
		return;
	if (limit > PARSER_CYCLE_LIMIT_MAX) {
		pr_info("Parser cycles limit adjusted to maximum %d\n",
			PARSER_CYCLE_LIMIT_MAX);
		limit = PARSER_CYCLE_LIMIT_MAX;
	}
	if (!limit)
		pr_info("Parser cycles limit check is disabled\n");
	iowrite32(limit, &regs->pclim);
}

/******************************************************************************/
void parser_ctrl_set_atomic_fragment_detection(uint8_t set,
					       enum ctlu_type ptype)
{
	struct parser_regs	*regs;
	uint32_t		cfg;

	regs = parser_ctrl_get_regs_ptr(ptype);
	if (!regs)
		return;
	cfg = ioread32(&regs->cfg);
	if (set)
		cfg |= PARSER_ICMPV6_ATOMIC_FRAG;
	else
		cfg &= ~PARSER_ICMPV6_ATOMIC_FRAG;
	iowrite32(cfg, &regs->cfg);
}

/******************************************************************************/
void parser_ctrl_set_clock_power_down(uint8_t set, enum ctlu_type ptype)
{
	struct parser_regs	*regs;
	uint32_t		cfg;

	regs = parser_ctrl_get_regs_ptr(ptype);
	if (!regs)
		return;
	cfg = ioread32(&regs->cfg);
	if (set)
		cfg |= PARSER_CLOCK_POWER_DOWN;
	else
		cfg &= ~PARSER_CLOCK_POWER_DOWN;
	iowrite32(cfg, &regs->cfg);
}

/******************************************************************************/
int parser_ctrl_load_soft_parser(struct soft_parser *sp, enum ctlu_type ptype)
{
	uint32_t	*pmem, *psp;
	uint16_t	i, size;
	int		ret;

	/* All checks are performed by the driver */
	switch (ptype) {
	case CTLU_EIOP_INGRESS:
		pr_info("PC = 0x%03x, %d bytes : Load on INGRESS parser\n",
			sp->pc, sp->size);
		break;
	case CTLU_EIOP_EGRESS:
		pr_info("PC = 0x%03x, %d bytes : Load on EGRESS parser\n",
			sp->pc, sp->size);
		break;
	case CTLU_AIOP:
		pr_info("PC = 0x%03x, %d bytes : Load on AIOP parser\n",
			sp->pc, sp->size);
		break;
	default:
		break;
	}
	/* Stop parser */
	ret = parser_ctrl_stop(ptype);
	if (ret)
		return ret;
	pmem = parser_ctrl_get_mem_ptr(ptype);
	/* Set SP loading address */
	pmem += (sp->pc - PARSER_MIN_PC) / 2;
	/* SP source address and size */
	psp = (uint32_t *)sp->byte_code;
	size = sp->size / sizeof(uint32_t);
	for (i = 0; i < size; i++)
		iowrite32(*psp++, pmem++);
	/* Start parser */
	parser_ctrl_start(ptype);
	/*parser_ctrl_dump_mem(ptype);*/
	return 0;
}

/******************************************************************************/
static int parser_init(struct ctlu_desc *cdesc, struct parser *desc)
{
	uint32_t	*pmem;
	int		i, ret;

	memset(desc, 0, sizeof(struct parser));
	desc->vaddr = cdesc->block_vaddr;
	desc->num_profiles = (uint8_t)cdesc->num_dpparser_profiles;
	desc->type = cdesc->type;
	desc->regs = (struct parser_regs *)desc->vaddr;
	desc->mem = (uint32_t *)((uint8_t *)desc->vaddr +
				 sizeof(struct parser_regs));
	/* Clear soft parser instructions memory */
	/*pr_info("Clear soft parser instructions memory space\n");*/
	/* Dump before clear */
	/*parser_ctrl_dump_mem(desc->type);*/
	/* Stop parser */
	ret = parser_ctrl_stop(desc->type);
	if (ret)
		return ret;
	pmem = desc->mem;
	for (i = 0; i < PARSER_MEM_SIZE; i++)
		iowrite32(0, pmem++);
	/* Dump after clear */
	/*parser_ctrl_dump_mem(desc->type);*/
	/* Start parser */
	parser_ctrl_start(desc->type);
	return 0;
}

#ifdef TKT011436 
/******************************************************************************/
static int parser_restore(struct parser *desc)
{
	uint32_t *pmem;
	int i, ret;

	/* Clear soft parser instructions memory */
	pr_debug("Clear soft parser instructions memory space\n");
	/* Dump before clear */
	/*parser_ctrl_dump_mem(desc->type);*/
	/* Stop parser */
	ret = parser_ctrl_stop(desc->type);
	if (ret)
		return ret;
	pmem = desc->mem;
	for (i = 0; i < PARSER_MEM_SIZE; i++)
		iowrite32(0, pmem++);
	/* Dump after clear */
	/*parser_ctrl_dump_mem(desc->type);*/
	/* Start parser */
	parser_ctrl_start(desc->type);

	return 0;
}

/**************************************************************************//**
 @Function     parser_ctrl_restore
*//***************************************************************************/
int parser_ctrl_restore(void)
{
	int	ret = 0, iter = 0;
	struct ctlu_desc ctlu_desc;

	pr_info("Executing parser_ctrl_restore...\n");
	if (parser_ctrl.cnt) {
		/* Search all platform defined HW parsers */
		iter = 0;
		memset(&ctlu_desc, 0, sizeof(struct ctlu_desc));
		while (sys_get_desc(SOC_MODULE_CTLU, 0, &ctlu_desc, &iter) == 0) {
			
			if (ctlu_desc.type == CTLU_AIOP_MFLU)
				continue;
			
			if (ctlu_desc.type == CTLU_EIOP_EGRESS) {
				if(parser_ctrl.eiop_egress_initialized){
					ret |= parser_restore(&parser_ctrl.eiop_egress);
					CHECK_COND_RETVAL(!ret, ret, "CTRL Egress Parser restore Failed\n");
					pr_info("EGRESS parser : present - restore\n");
					/*parser_ctrl_dump_regs(CTLU_EIOP_EGRESS);*/
				}
			}
			if (ctlu_desc.type == CTLU_EIOP_INGRESS) {
				if(parser_ctrl.eiop_ingress_initialized) {
					ret |= parser_restore(&parser_ctrl.eiop_ingress);
					CHECK_COND_RETVAL(!ret, ret, "CTRL Ingress Parser restore Failed\n");
					pr_info("INGRESS parser : present - restore\n");
					/*parser_ctrl_dump_regs(CTLU_EIOP_INGRESS);*/
				}
			}
			if (ctlu_desc.type == CTLU_AIOP) {
				if(parser_ctrl.aiop_ctlu_initialized){
					ret |= parser_restore(&parser_ctrl.aiop_ctlu);
					CHECK_COND_RETVAL(!ret, ret, "CTRL AIOP Parser restore Failed\n");
					pr_info("AIOP parser : present - restore\n");
					/*parser_ctrl_dump_regs(CTLU_AIOP);*/
				}
			}
		}
		if(!ret)
			return 0;
	}
	pr_err("No parser present\n");
	return -ENODEV;
}
#endif /* TKT011436 */

/******************************************************************************/
int parser_ctrl_init(void)
{
	int			ret, iter = 0;
	struct ctlu_desc	ctlu_desc;

	pr_info("Executing parser_ctrl_init...\n");
	/* Search all platform defined HW parsers */
	iter = 0;
	memset(&ctlu_desc, 0, sizeof(struct ctlu_desc));
	parser_ctrl.cnt = 0;
	parser_ctrl.eiop_ingress_initialized = 0;
	parser_ctrl.eiop_egress_initialized = 0;
	parser_ctrl.aiop_ctlu_initialized = 0;
	while (sys_get_desc(SOC_MODULE_CTLU, 0, &ctlu_desc, &iter) == 0) {
		/* MFLU = Multi Field Lookup Unit
		 *
		 * In wriop_3_0.1_bg_non_cust_Aug22_2017.pdf document on page
		 * 227, is written the following comment :
		 * "Gross running sum : MFLU: This field is N/A (since there is
		 * no parser)"
		 *
		 * See "Chapter 4 Multi Field Lookup Unit (MFLU)" in the
		 * WRIOP_bg_non_cust_10092014.pdf document.
		 * MFLU performs only lookup commands. There is no parser.
		 */
		if (ctlu_desc.type == CTLU_AIOP_MFLU)
			continue;
		if (ctlu_desc.type == CTLU_EIOP_EGRESS) {
			pr_info("EGRESS parser : present\n");
			ret = parser_init(&ctlu_desc, &parser_ctrl.eiop_egress);
			if (!ret)
				parser_ctrl.eiop_egress_initialized = 1;
			/*parser_ctrl_dump_regs(CTLU_EIOP_EGRESS);*/
		}
		if (ctlu_desc.type == CTLU_EIOP_INGRESS) {
			pr_info("INGRESS parser : present\n");
			ret = parser_init(&ctlu_desc,
					  &parser_ctrl.eiop_ingress);
			if (!ret)
				parser_ctrl.eiop_ingress_initialized = 1;
			/*parser_ctrl_dump_regs(CTLU_EIOP_INGRESS);*/
		}
		if (ctlu_desc.type == CTLU_AIOP) {
			pr_info("AIOP parser : present\n");
			ret = parser_init(&ctlu_desc, &parser_ctrl.aiop_ctlu);
			if (!ret)
				parser_ctrl.aiop_ctlu_initialized = 1;
			/*parser_ctrl_dump_regs(CTLU_AIOP);*/
		}
		if (ret)
			pr_warn("Parser initialization failed\n");
		else
			parser_ctrl.cnt++;
	}
	if (parser_ctrl.cnt) {
		sys_add_handle(&parser_ctrl, FSL_MOD_PARSER_CTRL, 1, 0);
		return 0;
	}
	pr_warn("No parser present\n");
	return -ENODEV;
}

/******************************************************************************/
static void parser_ctrl_disable_parser(enum ctlu_type ptype)
{
	switch (ptype) {
	case CTLU_EIOP_INGRESS:
		parser_ctrl.eiop_ingress_initialized = 0;
		pr_info("Power-down INGRESS parser\n");
		break;
	case CTLU_EIOP_EGRESS:
		parser_ctrl.eiop_egress_initialized = 0;
		pr_info("Power-down EGRESS parser\n");
		break;
	case CTLU_AIOP:
		parser_ctrl.aiop_ctlu_initialized = 0;
		pr_info("Power-down AIOP parser\n");
		break;
	default:
		pr_warn("Not supported CTLU type 0x%x\n", ptype);
		break;
	}
}

/******************************************************************************/
static int parser_ctrl_alloc_mem_parser(struct dpparser_cfg *cfg)
{
	struct dpparser		*dpparser;

	dpparser = parser_ctrl_get_dpparser(cfg->ctlu->type);
	if (!dpparser) {
		pr_err("Parser device not present\n");
		return -ENODEV;
	}
	dpparser->shadow = (struct shadow_profile *)
		fsl_malloc(sizeof(struct shadow_profile) * cfg->num_profiles);
	if (!dpparser->shadow) {
		pr_err("Can't allocate parser profiles memory\n");
		return -ENOMEM;
	}
	memset(dpparser->shadow, 0, sizeof(struct shadow_profile) *
	       cfg->num_profiles);
	dpparser->ss_layout = (struct dpparser_ss_layout *)
		fsl_malloc(sizeof(struct dpparser_ss_layout));
	if (!dpparser->ss_layout) {
		fsl_free(dpparser->shadow);
		dpparser->shadow = 0;
		pr_err("Can't allocate parser layout memory\n");
		return -ENOMEM;
	}
	memset(dpparser->ss_layout, 0, sizeof(struct dpparser_ss_layout));
	return 0;
}

/******************************************************************************/
struct dpparser *parser_ctrl_get_dpparser(enum ctlu_type ptype)
{
	struct dpparser		*dpparser;

	dpparser = NULL;
	switch (ptype) {
	case CTLU_EIOP_INGRESS:
		if (parser_ctrl.eiop_ingress_initialized)
			dpparser = &parser_ctrl.eiop_ingress.dpparser;
		break;
	case CTLU_EIOP_EGRESS:
		if (parser_ctrl.eiop_egress_initialized)
			dpparser = &parser_ctrl.eiop_egress.dpparser;
		break;
	case CTLU_AIOP:
		if (parser_ctrl.aiop_ctlu_initialized)
			dpparser = &parser_ctrl.aiop_ctlu.dpparser;
		break;
	default:
		break;
	}
	return dpparser;
}

/******************************************************************************/
int parser_ctrl_config_parser(const struct dpparser_cfg *cfg, int restore)
{
	struct dpparser		*dpparser;
	int			err;

	ASSERT_COND(cfg);

	err = parser_ctrl_stop(cfg->ctlu->type);
	if (err)
		return err;
	/* Clock power down flag */
	if (cfg->options & DPPARSER_CLK_POWER_DOWN_ENABLE) {
		/* Parser remains stopped */
		parser_ctrl_disable_parser(cfg->ctlu->type);
		parser_ctrl_set_clock_power_down(1, cfg->ctlu->type);
		return 0;
	}
	dpparser = parser_ctrl_get_dpparser(cfg->ctlu->type);
	ASSERT_COND(dpparser);
	if (!restore) {
		dpparser->num_profiles = cfg->num_profiles;
		dpparser->ctlu = cfg->ctlu;
		dpparser->min_pc = PARSER_MIN_PC;
		dpparser->max_pc = PARSER_MAX_PC;
		dpparser->ss_idx = 0;
		dpparser->restore = 0;
	} else {
		dpparser->restore = 1;
	}
	/* Set ICMP_V6 atomic fragment flag */
	if (cfg->options & DPPARSER_MARK_ICMPV6_ATOMIC_FRAGS)
		parser_ctrl_set_atomic_fragment_detection(1, cfg->ctlu->type);
	/* Set PCLIM */
	parser_ctrl_set_pclim(cfg->cycle_limit, cfg->ctlu->type);
	if (!restore) {
		/* Allocate memory for shadow profiles, layout, ... */
		err = parser_ctrl_alloc_mem_parser((struct dpparser_cfg *)cfg);
		if (err) {
			/* Parser remains stopped */
			parser_ctrl_disable_parser(cfg->ctlu->type);
			return err;
		}
	}
	parser_ctrl_start(cfg->ctlu->type);
	switch (cfg->ctlu->type) {
	case CTLU_EIOP_INGRESS:
		pr_info("INGRESS : Profiles = %d PCLIM = 0x%x ATOMIC = %d\n",
			cfg->num_profiles, cfg->cycle_limit,
			(cfg->options & DPPARSER_MARK_ICMPV6_ATOMIC_FRAGS) ?
			1 : 0);
		break;
	case CTLU_EIOP_EGRESS:
		pr_info("EGRESS : Profiles = %d PCLIM = 0x%x ATOMIC = %d\n",
			cfg->num_profiles, cfg->cycle_limit,
			(cfg->options & DPPARSER_MARK_ICMPV6_ATOMIC_FRAGS) ?
			1 : 0);
		break;
	case CTLU_AIOP:
		pr_info("AIOP : Profiles = %d PCLIM = 0x%x ATOMIC = %d\n",
			cfg->num_profiles, cfg->cycle_limit,
			(cfg->options & DPPARSER_MARK_ICMPV6_ATOMIC_FRAGS) ?
			1 : 0);
		break;
	default:
		break;
	}
	return 0;
}

/******************************************************************************/
void parser_ctrl_stop_parser(struct dpparser *dpparser)
{
	int	i, ret;

	ASSERT_COND(dpparser);
	ret = parser_ctrl_stop(dpparser->ctlu->type);
	if (ret)
		return;
	if (dpparser->shadow) {
		for (i = 0; i < dpparser->num_profiles; i++) {
			if (dpparser->shadow[i].profile)
				fsl_free(dpparser->shadow[i].profile);
		}
		fsl_free(dpparser->shadow);
		dpparser->shadow = 0;
	}
	if (dpparser->ss_layout) {
		fsl_free(dpparser->ss_layout);
		dpparser->ss_layout = 0;
	}
}
