/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_SP_H
#define __FSL_SP_H

#include "fsl_types.h"
#include "fsl_ctlu.h"

#include "dpparser.h"

/**************************************************************************//**
 @Group		PARSER_MACRO_DEF Parser macro definitions

 @Description	Constant values definitions.

 @{
*//***************************************************************************/
/** Minimum value of program counter */
#define PARSER_MIN_PC			0x20
/** Maximum value of program counter */
#define PARSER_MAX_PC			0x7FC
/** Parser enable(d) flag */
#define PARSER_ENABLE			0x01
/** Parser idle flag */
#define PARSER_IDLE			0x01
/** Parser ICMPv6 atomic fragment flag */
#define PARSER_ICMPV6_ATOMIC_FRAG	0x02
/** Parser clock power down */
#define PARSER_CLOCK_POWER_DOWN		0x04
/** Parser stop retry counter */
#define	PARSER_STOP_RETRY		100
/** Maximum value of PCLIM */
#define PARSER_CYCLE_LIMIT_MAX		0x1FFF
/** Soft Parser instructions memory size in 32-bit words */
#define PARSER_MEM_SIZE	((4 * KILOBYTE - 2 * PARSER_MIN_PC) / sizeof(uint32_t))
/** @} end of group PARSER_MACRO_DEF */

/**************************************************************************//**
 @Group		PARSER_REGS Parser registers

 @Description	Parser registers and soft parser program space. Parser register
		space overloads HXS region of the soft parser addressable space.
 @{
*//***************************************************************************/
struct parser_regs {
	/** Parser Configuration Register */
	uint32_t cfg;
	/** Parser Idle Register */
	uint32_t idle;
	/** Parsing Cycle Limit Register */
	uint32_t pclim;
	/** Parser IP Block Revision 1 Register */
	uint32_t ip_rev_1;
	/** Parser IP Block Revision 2 Register */
	uint32_t ip_rev_2;
	/** Reserved */
	uint32_t reserved[11];
};

/** @} end of group PARSER_REGS */

struct parser {
	/** Parser registers virtual address */
	void			*vaddr;
	/** Number of Parser profiles */
	uint8_t			num_profiles;
	 /** Type of parser */
	enum ctlu_type		type;
	/** Parser registers */
	struct parser_regs	*regs;
	/** Soft Parser instructions memory (4028 bytes). PC addresses 0x7fe
	 * and 0x7ff are not to be used as normal instructions, and must be
	 * zeroed for proper operation. */
	uint32_t		*mem;
	/**/
	struct dpparser		dpparser;
};

struct parser_ctrl {
	/** WRIOP ingress parser */
	struct parser		eiop_ingress;
	/** WRIOP egress parser */
	struct parser		eiop_egress;
	/** AIOP parser */
	struct parser		aiop_ctlu;
	/** Number of initialized parsers */
	uint8_t			cnt;
	uint8_t			eiop_ingress_initialized;
	uint8_t			eiop_egress_initialized;
	uint8_t			aiop_ctlu_initialized;
};

/**************************************************************************//**
@Description	Structure representing the information needed load a Soft
		Parser.

*//***************************************************************************/
struct soft_parser {
	/* Soft Parser loading address (starting PC) */
	uint16_t	pc;
	/* Number of bytes in the Soft Parser byte-code. Must be a multiple of
	 * four bytes. */
	uint16_t	size;
	/* Pointer to the array containing the Soft Parser byte-code. Must be
	 * aligned on a 4 bytes boundary. */
	uint8_t		*byte_code;
};

/**************************************************************************//**
 @Description   enum for defining SP Exceptions
*//***************************************************************************/

enum parser_exceptions {
	E_SP_SYSTEM_BUS_ERROR = 0,
	E_SP_STALL_EVENT = 1,
};

/**************************************************************************//**
 @Function      parser_ctrl_set_exceptions

 @Description   Define SP exceptions.

 @Param[in]     regs - Pointer to the area of specific SP register location
 @Param[in]     exception - Specific exception

 @Param[in]     enable - 1 to enable

 @Return        int
*//***************************************************************************/
int parser_ctrl_set_exceptions(struct parser *parser,
			       enum parser_exceptions exception, int enable);

void parser_ctrl_force_exceptions(struct parser *parser,
				  enum parser_exceptions exception);

/******************************************************************************/
uint32_t parser_ctrl_get_pclim(enum ctlu_type ptype);
uint32_t parser_ctrl_get_ip_rev_1(enum ctlu_type ptype);
uint32_t parser_ctrl_get_ip_rev_2(enum ctlu_type ptype);
void parser_ctrl_set_pclim(uint32_t limit, enum ctlu_type ptype);
void parser_ctrl_set_atomic_fragment_detection(uint8_t set,
					       enum ctlu_type ptype);
void parser_ctrl_set_clock_power_down(uint8_t set, enum ctlu_type ptype);
int parser_ctrl_restore(void);
int parser_ctrl_init(void);
int parser_ctrl_load_soft_parser(struct soft_parser *sp, enum ctlu_type ptype);
void parser_ctrl_dump_mem(enum ctlu_type ptype);

/******************************************************************************/
struct dpparser *parser_ctrl_get_dpparser(enum ctlu_type ptype);
int parser_ctrl_config_parser(const struct dpparser_cfg *cfg, int restore);
void parser_ctrl_stop_parser(struct dpparser *dpparser);

#endif /* __FSL_SP_H */
