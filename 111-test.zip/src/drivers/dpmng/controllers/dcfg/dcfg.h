/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpmng.h

 @Description   dpmng internal structures and definitions.
 *//***************************************************************************/
#ifndef __LCFG_H
#define __LCFG_H

#include "kernel/device.h"
#include "fsl_types.h"
#include "fsl_dcfg.h"

/*#define SVR_MNFCTR_ID_MASK		0xF0000000
#define SVR_FAMILY_MASK			0x0F000000
#define SVR_DEVICE_ID_MASK		0x003F0000
#define SVR_PERSONALITY_MASK	0x00003F00*/
#define SVR_MAJOR_MASK			0x000000F0
#define SVR_MINOR_MASK			0x0000000F

/*#define SVR_MNFCTR_ID_SHIFT		28
#define SVR_FAMILY_SHIFT		24
#define SVR_DEVICE_ID_SHIFT		16
#define SVR_PERSONALITY_SHIFT	8*/
#define SVR_MAJOR_SHIFT			4
#define SVR_MINOR_SHIFT			0
//#define SVR_SEC				0x00000100
//#define SVR_AIOP				0x00001000 - changes between chips!


#define DCFG_DISABLE_XMAN	0x40000000
#define DCFG_DISABLE_DFL		0x08000000
#define DCFG_DISABLE_DPI		0x04000000
#define DCFG_DISABLE_DCE		0x02000000
#define DCFG_DISABLE_RMAN	0x01000000
#define DCFG_DISABLE_SEC		0x00400000
#define DCFG_DISABLE_PME		0x00200000
#define DCFG_DISABLE_SATA2	0x00020000
#define DCFG_DISABLE_SATA1	0x00010000
#define DCFG_DISABLE_USB2	0x00002000
#define DCFG_DISABLE_USB1	0x00001000
#define DCFG_DISABLE_QDMA	0x00000100
#define DCFG_DISABLE_EDMA	0x00000800
#define DCFG_DISABLE_eSDHC	0x00000004

#define DCFG_DISABLE_MAC	0x00ffffff


#define DCFG_DISABLE_AIOP	0x00010000
#define DCFG_DISABLE_QBMAN	0x00001000
#define DCFG_DISABLE_PEX1	0x00000001

#define DCFG_DISABLE_I2C1	0x00000001
#define DCFG_DISABLE_I2C2	0x00000002
#define DCFG_DISABLE_I2C3	0x00000100
#define DCFG_DISABLE_I2C4	0x00000200
#define DCFG_DISABLE_SPI	0x00000020
#define DCFG_DISABLE_QSPI	0x00000010
#define DCFG_DISABLE_DUART	0x0000c00c

#define DCFG_DISABLE_PEBM	0x00100000
#define DCFG_DISABLE_FLX_TMR5_8	0x00008000
#define DCFG_DISABLE_FLX_TMR1_4	0x00004000
#define DCFG_DISABLE_TMU	0x00002000
#define DCFG_DISABLE_OCRAM	0x00001000
#define DCFG_DISABLE_DBG	0x00000400
#define DCFG_DISABLE_GPIO	0x00000200
#define DCFG_DISABLE_IFC	0x00000100
#define DCFG_DISABLE_DPDDR	0x00000080
#define DCFG_DISABLE_DDR	0x00000007

#define DCFG_DISABLE_WRIOP	0x00000001


struct dcfg_regs {
	uint32_t porsr[2]; 	/*0h POR Status 1 (PORSR1-2) 32 RO 00400F7Fh*/
	uint32_t reserved0[6];
	uint32_t gpporcr[4]; 	/*20h - 2Ch General-Purpose POR Configuration
				(GPPORCR1 - GPPORCR4) 32 RO 00000000h */
	uint32_t reserved1[12];
	uint32_t fusesr; 	/* 60h Fuse Status (FUSESR) 32 RO 00000000h */
	uint32_t reserved2[3];
	uint32_t devdisr[6];	/* 70h Device Disable 1 (DEVDISR1-6) 32 RW
				00000000h */
	uint32_t reserved4[3];
	uint32_t coredisr;	/* 94h Core Disable (COREDISR) 32 RW 00000000h*/
	uint32_t reserved5[2];
	uint32_t pvr;		/* A0h Processor Version (PVR) 32 RO 00008040h*/
	uint32_t svr;		/* A4h System Version (SVR) 32 RO 021C0422h */
	uint32_t reserved6[22];
	uint32_t rcwsr[32];	/* 100h Reset Control Word Status 1 (RCWSR1-32
				UNUSED 3!!!) */
};


#endif /* __LCFG_H */
