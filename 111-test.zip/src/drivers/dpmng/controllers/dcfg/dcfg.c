/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          pebm.c

 @Description   pebm library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_soc.h"
#include "fsl_platform.h"
#include "fsl_io.h"
#include "fsl_dpmng_mc.h"

#include "dcfg.h"

static uint32_t get_rcw(struct dcfg_desc *dcfg_desc, uint8_t rcwsr_id, uint32_t mask)
{
	uint32_t rcw;
	uint32_t shift;

	rcw = ioread32(&((struct dcfg_regs *)dcfg_desc->vaddr)->rcwsr[rcwsr_id]);

	/* calculate "shift" by mask */
	shift = 0;
	while (!((mask >> shift) & 1))
		shift ++;

	return ((rcw & mask) >> shift);
}


uint32_t dcfg_get_sys_clk(void)
{
	uint32_t sys_clk;
	struct dcfg_desc dcfg_desc = {0};

	sys_get_desc(SOC_MODULE_DCFG,
		SOC_DB_NO_MATCH_FIELDS,
		&dcfg_desc,
		NULL);

	sys_clk = get_rcw(&dcfg_desc, dcfg_desc.sys_clk_rcwsr_id, dcfg_desc.sys_clk_rcwsr_mask);

	return (sys_clk * 166667)/1000;
}

uint32_t dcfg_get_platform_clk(void)
{
	uint32_t sys_pll_rat;
	struct dcfg_desc dcfg_desc = {0};
	uint32_t platform_clk = 0;

	sys_get_desc(SOC_MODULE_DCFG,
		SOC_DB_NO_MATCH_FIELDS,
		&dcfg_desc,
		NULL);

	sys_pll_rat = get_rcw(&dcfg_desc, dcfg_desc.sys_pll_rat_rcwsr_id, dcfg_desc.sys_pll_rat_rcwsr_mask);

	if (dcfg_desc.sys_clk_div != 0)
		platform_clk = dcfg_get_sys_clk()*sys_pll_rat/dcfg_desc.sys_clk_div;
	
	return platform_clk;
}

int dcfg_has_rgmii(struct dcfg_desc *dcfg_desc, int ec_index)
{
	return ((int)get_rcw(dcfg_desc, dcfg_desc->ec[ec_index].rcwsr_id, dcfg_desc->ec[ec_index].rcwsr_mask) == 0);
}

int dcfg_get_ec_pmux(struct dcfg_desc *dcfg_desc, int ec_index)
{
	return (int)get_rcw(dcfg_desc, dcfg_desc->ec[ec_index].rcwsr_id, dcfg_desc->ec[ec_index].rcwsr_mask);
}

void dcfg_get_revision(uint8_t *major,
			uint8_t *minor,
	uint32_t *system_version)
{
	struct dcfg_regs *regs;
	uint32_t svr;
	struct dcfg_desc dcfg_desc = {0};

	soc_db_get_desc(SOC_MODULE_DCFG,
		SOC_DB_NO_MATCH_FIELDS,
		&dcfg_desc,
		NULL);
	regs = (struct dcfg_regs *)dcfg_desc.vaddr;
	svr = ioread32(&regs->svr);

	*system_version = svr;
	/*info->manufactor_id = (uint8_t)((svr & SVR_MNFCTR_ID_MASK) >> SVR_MNFCTR_ID_SHIFT);
	info->family = (uint8_t)((svr & SVR_FAMILY_MASK) >> SVR_FAMILY_SHIFT);
	info->device_id = (uint8_t)((svr & SVR_DEVICE_ID_MASK) >> SVR_DEVICE_ID_SHIFT);
	info->personality = (uint8_t)((svr & SVR_PERSONALITY_MASK) >> SVR_PERSONALITY_SHIFT);*/
	*major = (uint8_t)((svr & SVR_MAJOR_MASK) >> SVR_MAJOR_SHIFT);
	*minor = (uint8_t)((svr & SVR_MINOR_MASK) >> SVR_MINOR_SHIFT);
}

void dcfg_get_proc_version(
	uint32_t *proc_version)
{
	struct dcfg_regs *regs;
	struct dcfg_desc dcfg_desc = {0};

	soc_db_get_desc(SOC_MODULE_DCFG,
		SOC_DB_NO_MATCH_FIELDS,
		&dcfg_desc,
		NULL);
	regs = (struct dcfg_regs *)dcfg_desc.vaddr;
	*proc_version = ioread32(&regs->pvr);
}


int dcfg_is_unavailable(enum dcfg_disabled_devices dev, uint32_t *status)
{
	uint32_t devdisr, svr;
	struct dcfg_regs *regs;	
	struct dcfg_desc dcfg_desc = {0};
	int shift = 0;
	int retval;
	struct devdis_data {
		enum dcfg_disabled_devices dev;
		int id;
		uint32_t mask;
	};
	
	struct devdis_data devdis_data[] = {{DCFG_DEVDIS_NONE, 0, 0},
	                                    {DCFG_DEVDIS_DCE, 0, DCFG_DISABLE_DCE},
	                                    {DCFG_DEVDIS_SEC, 0, DCFG_DISABLE_SEC},
	                                    {DCFG_DEVDIS_PEBM, 4, DCFG_DISABLE_PEBM},
	                                    {DCFG_DEVDIS_DPDDR, 4, DCFG_DISABLE_DPDDR},
	                                    {DCFG_DEVDIS_DDR, 4, DCFG_DISABLE_DDR},
	                                    {DCFG_DEVDIS_EIOP, 5, DCFG_DISABLE_WRIOP},
	                                    {DCFG_DEVDIS_AIOP, 2, DCFG_DISABLE_AIOP},
	                                    {DCFG_DEVDIS_DUART, 3, DCFG_DISABLE_DUART},
	                                    {DCFG_DEVDIS_MAC, 1, DCFG_DISABLE_MAC},
	                                    {DCFG_DEVDIS_QBMAN, 2, DCFG_DISABLE_QBMAN},
	                                    {DCFG_DEVDIS_EDMA, 0, DCFG_DISABLE_EDMA},
	                                    {DCFG_DEVDIS_QDMA, 0, DCFG_DISABLE_QDMA},
	                                    {DCFG_DEVDIS_DBG, 5, DCFG_DISABLE_DBG},
	};

	char *devdis_names[14] = {
		"DCFG_DEVDIS_NONE",
		"DCFG_DEVDIS_DCE",
		"DCFG_DEVDIS_SEC",
		"DCFG_DEVDIS_PEBM",
		"DCFG_DEVDIS_DPDDR",
		"DCFG_DEVDIS_DDR",
		"DCFG_DEVDIS_EIOP",
		"DCFG_DEVDIS_AIOP",
		"DCFG_DEVDIS_DUART",
		"DCFG_DEVDIS_MAC",
		"DCFG_DEVDIS_QBMAN",
		"DCFG_DEVDIS_EDMA",
		"DCFG_DEVDIS_QDMA",
		"DCFG_DEVDIS_DBG",
	};

	ASSERT_COND(devdis_data[dev].dev == dev);

	soc_db_get_desc(SOC_MODULE_DCFG,
		SOC_DB_NO_MATCH_FIELDS,
		&dcfg_desc,
		NULL);

	regs = (struct dcfg_regs *)dcfg_desc.vaddr;
	svr = ioread32(&regs->svr);

	/* Some module may not exist on a certain SoC */
	if ((dev == DCFG_DEVDIS_AIOP) && (svr & dcfg_desc.svr_aiop_disable_mask))
			return 1;

	if ((dev == DCFG_DEVDIS_SEC) && (svr & dcfg_desc.svr_sec_disable_mask))
			return 1;

	devdisr = ioread32(&regs->devdisr[devdis_data[dev].id]);

	/* cases with more than 1 bit in mask */
	if (!is_power_of_2(devdis_data[dev].mask))
	{
		while(!((devdis_data[dev].mask >> shift) & 1))
			shift++;
		/* shift enabled bits mask to the right */
		if (status)
			*status = (devdisr & devdis_data[dev].mask) >> shift;
	}
	else
		if (status)
			*status = 1;

	retval = (int)((uint32_t)(devdisr & devdis_data[dev].mask) == devdis_data[dev].mask);
	if( retval ) {
		pr_warn("Module id %d (%s) disabled\n", (int)dev, (int)dev < ARRAY_SIZE(devdis_names) ? devdis_names[dev] : "NULL");
	}
	else {
		pr_info("Module id %d (%s) enabled\n", (int)dev, (int)dev < ARRAY_SIZE(devdis_names) ? devdis_names[dev] : "NULL");
	}

	return retval;
}


uint32_t dcfg_get_serdes_protocol(uint8_t rcwsr_id, uint32_t rcwsr_mask)
{
	struct dcfg_desc dcfg_desc = {0};

	sys_get_desc(SOC_MODULE_DCFG,
		SOC_DB_NO_MATCH_FIELDS,
		&dcfg_desc,
		NULL);

	return get_rcw(&dcfg_desc, rcwsr_id, rcwsr_mask);
}
