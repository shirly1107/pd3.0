/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          aiop.c

 @Description   AIOP library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_sys.h"
#include "fsl_dbg.h"
#include "fsl_dpmng_mc.h"
#include "fsl_timer.h"
#include "fsl_mpic.h"

#include "aiop.h"
//#include "dpaiop.h" /* remove? */
#define ALLOWED_INTR_MAX_INTERVAL	60000 /* 1 minute */

static void intr_timer_cb(void *irq_id)
{
	mpic_enable_intr((uint32_t)(irq_id));
}

static void tmp_block_irq(struct aiop_tile *aiop_tile, int irq_id)
{
	mpic_disable_intr((uint32_t)irq_id);

	/* Initiate timer parameters */
	timer_init(aiop_tile->timer, 
		ALLOWED_INTR_MAX_INTERVAL, 
		intr_timer_cb, 
		(void *)irq_id, 
		E_TIMER_MODE_SINGLE, 
		0);

	/* Start the timer */
	timer_start(aiop_tile->timer);
}

static void aiop_ecc_error(struct aiop_tile *aiop_tile,
	uint32_t mbeesr1,
	uint32_t mbeesr2)
{
	struct aiop_err_mng_intr *aiop_err_mng_intr =
			(struct aiop_err_mng_intr *)PTR_MOVE(
				aiop_tile->desc.vaddr_dcsr,
				AIOP_DCSR_ERR_MNG_INTR_OFFSET);
	uint64_t cur_time;


	pr_err("AIOP Multi-bit ECC error event mbeesr1 = 0x%08x, mbeesr2 = 0x%08x.\n",
	       mbeesr1, mbeesr2);
	
	if (aiop_tile->intr_cnt++ == 0)
		aiop_tile->base_time = timer_current_time();
	else
	{
		cur_time = timer_current_time();
		/* if we get 5 recoverable interrupts within ALLOWED_INTR_MAX_INTERVAL */
		if ((aiop_tile->intr_cnt >= 5) && 
			(cur_time - aiop_tile->base_time <= ALLOWED_INTR_MAX_INTERVAL))
		{		
			aiop_tile->intr_cnt = 0;
			tmp_block_irq(aiop_tile, aiop_tile->desc.irq_cat_err);
		}
	}


	/* disable ecc interrupts */
	iowrite32((ioread32(&aiop_err_mng_intr->cerrcr) | ERRCR_DISABLE), &aiop_err_mng_intr->cerrcr);
	iowrite32((ioread32(&aiop_err_mng_intr->pserrcr) | ERRCR_DISABLE), &aiop_err_mng_intr->cerrcr);
	iowrite32((ioread32(&aiop_err_mng_intr->shserrcr) | ERRCR_DISABLE), &aiop_err_mng_intr->cerrcr);
}

static void aiop_ste_error(struct aiop_tile *aiop_tile)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile->desc.paddr;
	uint32_t status, stecr1;

	status = ioread32(&(regs->cmgw_regs.stesr));

	if (status & STESR_AXI_CMD_DEC)
		pr_err("AIOP STE  AXI Command Decode Error\n");
	if (status & STESR_CMD_DESC)
		pr_err("AIOP STE  Command Descriptor Error\n");
	if (status & STESR_AXI_OUT_ADDR)
		pr_err("AIOP STE  AXI  Outbound Address Error\n");
	if (status & STESR_AXI_OUT_RD)
		pr_err("AIOP STE  AXI Outbound Read Error\n");
	if (status & STESR_AXI_OUT_WR)
		pr_err("AIOP STE  AXI Outbound Write Error\n");

	/* Clear captured registers */
	stecr1 = (ioread32(&(regs->cmgw_regs.stecr1)) | STECR1_CLR_ERR);
	iowrite32( stecr1, &(regs->cmgw_regs.stecr1));
	stecr1 &= ~STECR1_RESET;
	iowrite32(stecr1, &(regs->cmgw_regs.stecr1));

	//err_code = (uint8_t)((ioread32(&(regs->cmgw_regs.ste_err_captr[0])) & STE_ERR_CODE_MASK) >> STE_ERR_CODE_SHIFT);
}

static void aiop_osm_error(struct aiop_tile *aiop_tile, int recoverable)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile->desc.paddr;
	uint32_t event = 0;

	event = ioread32(&regs->osm_regs.oedr);
	iowrite32(event, &(regs->osm_regs.oedr));

	if (event & AIOP_OSM_ERR_ME)
		pr_err("AIOP OSM Multiple events detected\n");

	if (recoverable)
	{
		if (event & AIOP_OSM_ERR_TNS)
			pr_err("AIOP OSM Transition from no scope event\n");
		if (event & AIOP_OSM_ERR_RC)
			pr_err("AIOP OSM relinquish event\n");
		if (event & AIOP_OSM_ERR_ENS)
			pr_err("AIOP OSM Exit no scope event\n");
		if (event & AIOP_OSM_ERR_ESE)
			pr_err("AIOP OSM Enter scope exhausted event\n");
	}
	else
		if (event & AIOP_OSM_ERR_DID)
			pr_err("AIOP OSM Duplicate scope identifier event\n");

}



static void aiop_aap_error(struct aiop_tile *aiop_tile)
{
	pr_err("AIOP AAP error event\n");

}

static void aiop_wrks_error(struct aiop_tile *aiop_tile)
{
	pr_err("EIOP NR WRKS event\n");
}

static int sp_check(struct aiop_tile_desc *aiop_tile_desc,
		   	   uint32_t sp_id,
		   	   struct aiop_sp_cfg *cfg)
{
	if (sp_id >= aiop_tile_desc->num_sp) {
		pr_err("The provided entry ID of %d exceeds the supported %d "
		"Profile SRAM entries", sp_id, aiop_tile_desc->num_sp);
		return -EINVAL;
	}

	if ((cfg->pass_thru_ann_room) && (cfg->pass_thru_ann_room != 64)) {
		pr_err("The only valid value for pass-through annotation "
		"room is 64 bytes");
		return -EINVAL;
	}

	if (cfg->accel_specific_ann_room % 64) {
		pr_err("Accelerator-specific annotation room must be a "
		"multiple of 64 bytes");
		return -EINVAL;
	}

	if (cfg->accel_specific_ann_room > SP_MAX_ASAR_VAL) {
		pr_err("Accelerator-specific annotation room exceeds "
		"maximal value of %d\n", SP_MAX_ASAR_VAL);
		return -EINVAL;
	}

	if (cfg->num_pools > SP_MAX_NUM_POOLS) {
		pr_err("SP number of pools room exceeds "
		"maximal value of %d\n", SP_MAX_NUM_POOLS);
		return -EINVAL;
	}

	return 0;
}

static void aiop_tile_write_ep(struct aiop_tile_desc *aiop_tile_desc, uint32_t epid, struct aiop_ep_entry_cfg *ep_entry)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	struct aiop_ws_regs *ws_regs = &regs->ws_regs;

	iowrite32(epid, &ws_regs->epas);
	iowrite32(ep_entry->pc, &ws_regs->ep_pc);
	iowrite32(ep_entry->parameter, &ws_regs->ep_pm);
}

static int aiop_tile_write_sp(struct aiop_tile_desc *aiop_tile_desc,
		   	   uint32_t sp_id,
		   	   struct aiop_sp_cfg *cfg)
{
	struct aiop_psram_entry *sp;
	uint32_t val;
	int i;
	void *psram_vaddr;
	struct dpmng_amq amq = {0};

	/* Define SoC window for accessing Profile SRAM */
	dpmng_mc_lock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
	dpmng_get_amq(&amq);

	psram_vaddr = dpmng_mc_set_soc_window(
		aiop_tile_desc->psram_paddr, &amq);

	/* Calculate Storage profile address based on its entry ID in Profile
	   SRAM */
	sp = (struct aiop_psram_entry *)(PTR_MOVE(psram_vaddr, (SP_BASE_ADDR
	                                 + (sp_id)
	                                   * sizeof(struct aiop_psram_entry))));

	memset((uint8_t*)sp, 0, sizeof(struct aiop_psram_entry));
	/* Setting AIOP specific Storage profile information */
	val = (uint32_t)(cfg->icid & AIOP_AMQ_ICID_MASK);
	val |= (cfg->pl ? AIOP_AMQ_PL : 0);
	val |= (cfg->bdi ? AIOP_SP_BDI : 0);
	iowrite32(val, &sp->aiop_specific);

	/* Setting Frame Format and Data Placement controls */
	val = (uint32_t)(cfg->data_length & SP_FF_LOW_DL_MASK);
	iowrite32(val, &sp->frame_format_low);

	val = (uint32_t)(cfg->data_head_room & SP_FF_HIGH_DHR_MASK);
	val |= (cfg->buff_src ? SP_FF_HIGH_BS : 0);
	val |= ((((uint32_t)cfg->frame_format) << SP_FF_HIGH_FF_SHIFT)
	        & SP_FF_HIGH_FF_MASK);
	val |= (cfg->virt_addr ? SP_FF_HIGH_VA : 0);
	val |= (cfg->data_lenght_ctrl ? SP_FF_HIGH_DLC : 0);
	val |= (cfg->pass_thru_ann_room ? SP_FF_HIGH_PTAR : 0);
	val |= (cfg->sg_head_room ? SP_FF_HIGH_SGHR : 0);
	val |= (((((uint32_t)cfg->accel_specific_ann_room) / 64)
	         << SP_FF_HIGH_ASAR_SHIFT)
	        & SP_FF_HIGH_ASAR_MASK);
	iowrite32(val, &sp->frame_format_high);

	/* Setting SP buffer pools controls */
	for (i = 0; i < cfg->num_pools; i++) {
		val = (uint32_t)(((uint32_t)cfg->bp_cfg[i].bpid
		                  << SP_BP_BPID_SHIFT)
		                 & SP_BP_BPID_MASK);
		val |= (cfg->bp_cfg[i].bmt ? SP_BP_BMT : 0);
		val |= (((uint32_t)(cfg->bp_cfg[i].bp_size / 64)
		         << SP_BP_PBS_SHIFT)
		        & SP_BP_PBS_MASK);
		val |= (cfg->bp_cfg[i].scarce_resource ? SP_BP_SR : 0);
		val |= (cfg->bp_cfg[i].backup_pool ? SP_BP_BP : 0);
		val |= SP_BP_BPV;
		if (cfg->num_pools == 1)
			iowrite32(val, &sp->bp1);
		else
		{
			int cur = i;
			int other =  (i == 0) ? 1 : 0;

			if (cfg->bp_cfg[cur].bp_size < cfg->bp_cfg[other].bp_size)
				iowrite32(val, &sp->bp1);
			else
				iowrite32(val, &sp->bp2);
		}
		
	}

	/* Restore previous SoC window */
	dpmng_mc_unlock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	return 0;
}

static void aiop_tile_init_srams(struct aiop_tile_desc *aiop_tile_desc)
{
	struct aiop_err_mng_intr *aiop_err_mng_intr;
	phys_addr_t iram_base_addr;
	struct dpmng_amq amq = {0};
	void *addr;
	uint32_t i;

	aiop_err_mng_intr = (struct aiop_err_mng_intr *)
							PTR_MOVE(aiop_tile_desc->vaddr_dcsr,
									AIOP_DCSR_ERR_MNG_INTR_OFFSET);

	dpmng_get_amq(&amq);

	/* Clearing ECC enable bits for all SRAMs */
	iowrite32((ioread32(&aiop_err_mng_intr->cerrcr) & (~DCSR_CERRCR_IEE)),
				   &aiop_err_mng_intr->cerrcr);
	iowrite32((ioread32(&aiop_err_mng_intr->shserrcr) & (~DCSR_SHSERRCR_SEE)),
				   &aiop_err_mng_intr->shserrcr);
	iowrite32((ioread32(&aiop_err_mng_intr->pserrcr) & (~DCSR_PSERRCR_PEE)),
				   &aiop_err_mng_intr->pserrcr);

	/* Define CCSR window for accessing IRAMs and nullify all IRAMs */
	iram_base_addr = aiop_tile_desc->iram_paddr -
			(aiop_tile_desc->num_clusters - 1) * aiop_tile_desc->iram_offset;
	addr = dpmng_mc_set_ccsr_window(iram_base_addr, &amq);
	for (i = 0; i < aiop_tile_desc->num_clusters; i++)
		memset(PTR_MOVE(addr, i*aiop_tile_desc->iram_offset),
		         	 0, aiop_tile_desc->iram_size);
	dpmng_mc_revert_ccsr_window();

	/* Define CCSR window for accessing Shared SRAM and nullify */
	dpmng_mc_lock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
	addr = dpmng_mc_set_soc_window(aiop_tile_desc->sram_paddr, &amq);
	memset(addr, 0, aiop_tile_desc->sram_size);
	/* Restore previous SoC window */
	dpmng_mc_unlock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	/* Define SoC window for accessing Profile SRAM and nullify */
	dpmng_mc_lock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
	addr = dpmng_mc_set_soc_window(aiop_tile_desc->psram_paddr, &amq);
	addr = PTR_MOVE(addr, SP_BASE_ADDR);
	memset(addr, 0, aiop_tile_desc->num_sp * sizeof(struct aiop_psram_entry));
	/* Restore previous SoC window */
	dpmng_mc_unlock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	/* Set the ECC enable bits for all SRAMs */
	iowrite32((ioread32(&aiop_err_mng_intr->cerrcr) | DCSR_CERRCR_IEE),
				   &aiop_err_mng_intr->cerrcr);
	iowrite32((ioread32(&aiop_err_mng_intr->shserrcr) | DCSR_SHSERRCR_SEE),
				   &aiop_err_mng_intr->shserrcr);
	iowrite32((ioread32(&aiop_err_mng_intr->pserrcr) | DCSR_PSERRCR_PEE),
				   &aiop_err_mng_intr->pserrcr);
}

void aiop_err_isr(uint32_t arg)
{
	uint32_t event;
	uint64_t cur_time;

	struct aiop_tile *aiop_tile = (struct aiop_tile *)arg;
	struct aiop_err_mng_intr *aiop_err_mng_intr =
			(struct aiop_err_mng_intr *)PTR_MOVE(
				aiop_tile->desc.vaddr_dcsr,
				AIOP_DCSR_ERR_MNG_INTR_OFFSET);

	event = ioread32(&aiop_err_mng_intr->resr);
	iowrite32(event, &aiop_err_mng_intr->resr);

	if (event & AIOP_IP_OSM)
		aiop_osm_error(aiop_tile, 1);
	if (event & AIOP_IP_STE)
		aiop_ste_error(aiop_tile);
	if (event & AIOP_IP_AAP_SEC)
		aiop_aap_error(aiop_tile);

	if (aiop_tile->intr_cnt++ == 0)
		aiop_tile->base_time = timer_current_time();
	else
	{
		cur_time = timer_current_time();
		/* if we get 5 recoverable interrupts within ALLOWED_INTR_MAX_INTERVAL */
		if ((aiop_tile->intr_cnt >= 5) && 
			(cur_time - aiop_tile->base_time <= ALLOWED_INTR_MAX_INTERVAL))
		{		
			aiop_tile->intr_cnt = 0;
			tmp_block_irq(aiop_tile, aiop_tile->desc.irq_rec_err);
		}
	}

}

void aiop_cat_err_isr(uint32_t arg)
{
	uint32_t event, mbeesr1, mbeesr2;
	struct aiop_tile *aiop_tile = (struct aiop_tile *)arg;
	struct aiop_err_mng_intr *aiop_err_mng_intr =
			(struct aiop_err_mng_intr *)PTR_MOVE(
				aiop_tile->desc.vaddr_dcsr,
				AIOP_DCSR_ERR_MNG_INTR_OFFSET);

	event = ioread32(&aiop_err_mng_intr->nresr);
	iowrite32(event, &aiop_err_mng_intr->nresr);

	if (event & AIOP_IP_OSM)
		aiop_osm_error(aiop_tile, 0);
	if (event & AIOP_IP_WRKS)
		aiop_wrks_error(aiop_tile);

	mbeesr1 = ioread32(&aiop_err_mng_intr->mbeesr[0]);
	mbeesr2 = ioread32(&aiop_err_mng_intr->mbeesr[1]);
	if (mbeesr1 || mbeesr2)
		aiop_ecc_error(aiop_tile, mbeesr1, mbeesr2);

	if (aiop_tile->isr_cb)
		aiop_tile->isr_cb(aiop_tile->isr_cb_arg, aiop_tile->isr_cb_irq_id,
		AIOP_EVENT_NON_RECOVERABLE_ERR);
}

void aiop_tile_disable(struct aiop_tile_desc *aiop_tile_desc)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	uint32_t val;

	val = ioread32(&(regs->cmgw_regs.tcr));
	iowrite32((val & ~AIOP_TILE_CFG_EN), &(regs->cmgw_regs.tcr));
}

void aiop_tile_enable(struct aiop_tile_desc *aiop_tile_desc)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	uint32_t val;

	val = ioread32(&(regs->cmgw_regs.tcr));
	iowrite32((val | AIOP_TILE_CFG_EN), &(regs->cmgw_regs.tcr));
}

void aiop_tile_disable_dbg_intr_requests(struct aiop_tile_desc *aiop_tile_desc)
{
	struct aiop_run_control *aiop_run_control = 0;

	/* Disable all debug interrupt requests (UDE and DEVT) to the AIOP cores:
	 - DEVTs are disabled by setting A-RC's CGACRE[PCAC] = CGACRD[PCAC] = CGACRR[PCAC] = 4'h0 (No Action)
	 - UDEs are disabled by setting A-RC's  CGACRE[ICAC] = CGACRD[ICAC] = CGACRR[ICAC] = 4'h0 (No Action)
	 */

	aiop_run_control = (struct aiop_run_control *)
				PTR_MOVE(aiop_tile_desc->vaddr_dcsr,
				         AIOP_DCSR_RUN_CTRL_OFFSET);

	iowrite32((ioread32(&aiop_run_control->cgacre) & (~(DCSR_RC_PCAC_MASK | DCSR_RC_ICAC_MASK))),
		   &aiop_run_control->cgacre);
	iowrite32((ioread32(&aiop_run_control->cgacrd) & (~(DCSR_RC_PCAC_MASK | DCSR_RC_ICAC_MASK))),
			   &aiop_run_control->cgacrd);
	iowrite32((ioread32(&aiop_run_control->cgacrr) & (~(DCSR_RC_PCAC_MASK | DCSR_RC_ICAC_MASK))),
			   &aiop_run_control->cgacrr);
}

int aiop_tile_set_storage_profile(struct aiop_tile *aiop_tile,
                             uint32_t sp_id,
                             struct aiop_sp_cfg *cfg)
{
	int err;

	err = sp_check(&aiop_tile->desc, sp_id, cfg);
	if (err)
		return err;

	aiop_tile_write_sp(&aiop_tile->desc, sp_id, cfg);

	/* save sp in table */
	aiop_tile->sp_table[sp_id].init = 1;
	aiop_tile->sp_table[sp_id].cfg = *cfg;

	return 0;
}

void aiop_tile_restore_sp_table(struct aiop_tile *aiop_tile)
{
	uint32_t sp_id = 0;

	/*dpmng_mc_lock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
	psram_vaddr = dpmng_mc_set_soc_window(
	        dpaiop->desc.psram_paddr,);*/
	
	while (sp_id < aiop_tile->desc.num_sp) {
		if (aiop_tile->sp_table[sp_id].init)
			aiop_tile_write_sp(&aiop_tile->desc,
			                   sp_id,
			                   &aiop_tile->sp_table[sp_id].cfg);
		sp_id++;
	}

	/* Restore previous SoC window */
	//dpmng_mc_unlock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
}

int aiop_tile_ws_set_ep_entry(struct aiop_tile *aiop_tile,
                         uint32_t epid,
                         struct aiop_ep_entry_cfg *cfg)
{
	if (epid >= aiop_tile->desc.num_ep) {
		pr_err("Upto %d EPIDs are supported\n", aiop_tile->desc.num_ep);
		return -EINVAL;
	}

	/* save epid entry for future use */
	aiop_tile->ep_table[epid].init = 1;
	aiop_tile->ep_table[epid].cfg = *cfg;

	aiop_tile_write_ep(&aiop_tile->desc, epid, &aiop_tile->ep_table[epid].cfg);

	return 0;
}

void aiop_tile_restore_ep_table(struct aiop_tile *aiop_tile)
{
	uint32_t epid = 0;

	while (epid < aiop_tile->desc.num_ep) {
		if (aiop_tile->ep_table[epid].init) {
			aiop_tile_write_ep(&aiop_tile->desc, epid, &aiop_tile->ep_table[epid].cfg);
		}
		epid++;
	}
}

void aiop_tile_set_isr_params(struct aiop_tile *aiop_tile, 
	int (*isr_cb)(void *arg, uint8_t irq_id, uint32_t event), 
	void *arg, 
	uint8_t irq_id)
{
	aiop_tile->isr_cb = isr_cb;
	aiop_tile->isr_cb_arg = arg;
	aiop_tile->isr_cb_irq_id = irq_id;	
}


int aiop_tile_early_init(struct aiop_tile_desc *aiop_tile_desc)
{
	struct aiop_tile *aiop_tile;
	
	ASSERT_COND(aiop_tile_desc->num_ep <= AIOP_EP_TABLE_NUM_OF_ENTRIES);
	ASSERT_COND(aiop_tile_desc->num_sp <= AIOP_PSRAM_NUM_OF_ENTRIES);
	
	aiop_tile = (struct aiop_tile *)fsl_malloc(sizeof(struct aiop_tile));
	if (!aiop_tile)
	{
		pr_debug("No memory for aiop_tile\n");
		return -ENOMEM;
	}
	memset(aiop_tile, 0, sizeof(struct aiop_tile));
	aiop_tile->id = aiop_tile_desc->tile_id;
	aiop_tile->desc = *aiop_tile_desc;
	aiop_tile->timer = timer_create();
	sys_add_handle(aiop_tile, FSL_MOD_AIOP_TILE, 1, 0);
	
	return 0;
}

void aiop_tile_init(struct aiop_tile_desc *aiop_tile_desc, uint8_t tasks_per_core)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	uint32_t val;

#ifdef ERR008247
	{
		struct aiop_err_mng_intr *aiop_err_mng_intr =
			(struct aiop_err_mng_intr *)PTR_MOVE(
				aiop_tile_desc->vaddr_dcsr,
				AIOP_DCSR_ERR_MNG_INTR_OFFSET);

		iowrite32((ioread32(&aiop_err_mng_intr->ecccr1) | AIOP_IP_STE),
			&aiop_err_mng_intr->ecccr1);
		iowrite32((ioread32(&aiop_err_mng_intr->sbeesr[0]) | AIOP_IP_STE),
			&aiop_err_mng_intr->sbeesr[0]);
		iowrite32((ioread32(&aiop_err_mng_intr->mbeesr[0]) | AIOP_IP_STE),
			&aiop_err_mng_intr->mbeesr[0]);

	}
#endif
	LOG2(tasks_per_core, val);

	if (!aiop_tile_desc->wscr_disable)
		iowrite32((val & AIOP_TILE_WSCR_NTASKS_MASK), &(regs->cmgw_regs.wscr));

	/* Initialize tile's SRAMs */
	aiop_tile_init_srams(aiop_tile_desc);
}

void aiop_tile_ws_init(struct aiop_tile_desc *aiop_tile_desc, const struct aiop_ws_cfg *cfg)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	uint32_t i, val;

	/* Initialize Entry point table */
	for (i = 0; i < aiop_tile_desc->num_ep; i++) {
		iowrite32((uint32_t)i, &(regs->ws_regs.epas));

		val = (((AIOP_EP_FDPA_DEFAULT << AIOP_EP_FDPA_FDPA_SHIFT) & AIOP_EP_FDPA_FDPA_MASK) |
			((AIOP_EP_ADPCA_DEFAULT << AIOP_EP_FDPA_ADPCA_SHIFT) & AIOP_EP_FDPA_ADPCA_MASK));
		iowrite32(val, &(regs->ws_regs.ep_fdpa));


		if (aiop_tile_desc->pta_support)
			val = ((AIOP_EP_PTAPA_DEFAULT << AIOP_EP_PTAPA_SHIFT) & AIOP_EP_PTAPA_MASK);
		else
			val = ((AIOP_EP_PTAPA_DISABLE << AIOP_EP_PTAPA_SHIFT) & AIOP_EP_PTAPA_MASK);
		iowrite32(val, &(regs->ws_regs.ep_ptapa));

		val = (((AIOP_EP_ASAPS_DEFAULT << AIOP_EP_ASAPA_ASAPS_SHIFT) & AIOP_EP_ASAPA_ASAPS_MASK) |
		       ((AIOP_EP_ASAPA_DEFAULT << AIOP_EP_ASAPA_ASAPA_SHIFT) & AIOP_EP_ASAPA_ASAPA_MASK) |
		       (AIOP_EP_ASAPO_DEFAULT & AIOP_EP_ASAPA_ASAPO_MASK));
		iowrite32(val, &(regs->ws_regs.ep_asapa));

		val = (((AIOP_EP_SPA_SIZE_DEFAULT << AIOP_EP_SPA_SIZE_SHIFT) & AIOP_EP_SPA_SIZE_MASK) |
			(AIOP_EP_SPA_ADDR_DEFAULT & AIOP_EP_SPA_ADDR_MASK));
		iowrite32(val, &(regs->ws_regs.ep_spa));

		val = (AIOP_EP_SPO_SR_FROM_START | (AIOP_EP_SPO_DEFAULT & AIOP_EP_SPO_SPO_MASK));
		iowrite32(val, &(regs->ws_regs.ep_spo));

		val = (AIOP_EP_OSC_SRC_FROM_FD | AIOP_EP_OSC_EP_CONCURENT | AIOP_EP_OSC_OSRM_1);
		iowrite32(val, &(regs->ws_regs.ep_osc));
	}

	/* Set WS configuration register */
	val = (uint32_t)(((cfg->ch_fairness_mode == AIOP_FAIR_MODE_BANDWIDTH ?
	                         0x00010000 : 0))
	                 | ((cfg->high_prio_threshold << 8) & 0x00000700));
#ifdef TKT256609
	val |= 0xC0000000;
#endif /* TKT256609*/
	iowrite32(val, &(regs->ws_regs.cfg));

	/* Set registers default values */
	iowrite32(0x80000000, &(regs->ws_regs.ecclog));
	iowrite32(0, &(regs->ws_regs.fc_cgbcf));
	iowrite32(0, &(regs->ws_regs.fc_bpbcf));
	iowrite32(0, &(regs->ws_regs.db_cfga));
	iowrite32(0, &(regs->ws_regs.db_cfgb));

	/* Set channels default configuration */
	for (i = 0; i < 64; i++) {
		iowrite32(i,          &(regs->ws_regs.cas));
		iowrite32(0x00008000, &(regs->ws_regs.ch_cfga));
		iowrite32(0,          &(regs->ws_regs.ch_cfgb));

		/* Channel's flow control setup */
		iowrite32(0, &(regs->ws_regs.fc_cfg));
	}
}

void aiop_tile_fdma_init(struct aiop_tile_desc *aiop_tile_desc,
	phys_addr_t sru_base,
	const struct aiop_fdma_cfg *cfg)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	uint32_t val = 0;

	iowrite32(UINT32_HI(sru_base), &(regs->fdma_regs.sru_base_h));
	iowrite32(UINT32_LO(sru_base), &(regs->fdma_regs.sru_base_l));

	val = (AIOP_FDMA_SRU_SIZE_EN
	         | (cfg->sru_size & AIOP_FDMA_SRU_SIZE_MASK));
	iowrite32(val, &(regs->fdma_regs.sru_size));

	/* Set FDMA SRU AMQs */
	val = 	ioread32(&(regs->fdma_regs.cfg)) & AIOP_CFG_DADPCA_MASK;
	val |= (uint32_t)(cfg->amq.icid & AIOP_AMQ_ICID_MASK);
	val |= (cfg->amq.pl ? AIOP_AMQ_PL : 0);
	val |= (cfg->amq.bmt ? AIOP_AMQ_BMT : 0);
	val |= (cfg->amq.va ? AIOP_AMQ_VA : 0);
	iowrite32(val, &(regs->fdma_regs.cfg));

	/* Configure memory cache attributes for SRUs and frame data accesses */
	val = (uint32_t)(((cfg->data_write_attr << AIOP_FDMA_SMCACR_FDWC_SHIFT)
	                  & AIOP_FDMA_SMCACR_FDWC_MASK)
	                 | ((cfg->sru_write_attr
	                     << AIOP_FDMA_SMCACR_SRUWC_SHIFT)
	                    & AIOP_FDMA_SMCACR_SRUWC_MASK)
	                 | ((cfg->data_read_attr
	                     << AIOP_FDMA_SMCACR_FDRC_SHIFT)
	                    & AIOP_FDMA_SMCACR_FDRC_MASK)
	                 | (cfg->sru_read_attr & AIOP_FDMA_SMCACR_SRURC_MASK));
	iowrite32(val, &(regs->fdma_regs.smcacr));

#ifdef ERR008610
	/* Initialize the hop count limit value to 0: disables the limit
	   protection on the maximum number of scatter/gather table links
	   that FDMA will follow */
	iowrite32(0, &(regs->fdma_regs.hcl));
#else
	/* Define the limit protection on the maximum number of
	 * scatter/gather table links that FDMA will follow */
	iowrite32(cfg->hcl & AIOP_FDMA_HCL_MASK, &regs->fdma_regs.hcl);
#endif
}

void aiop_tile_cdma_init(struct aiop_tile_desc *aiop_tile_desc,
                    const struct aiop_cdma_cfg *cfg)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	uint32_t val;

	/* Set CDMA SRU AMQs */
	val = (uint32_t)(cfg->amq.icid & AIOP_AMQ_ICID_MASK);
	val |= (cfg->bdi ? AIOP_CDMA_CFG_BDI : 0);
	val |= (cfg->amq.pl ? AIOP_AMQ_PL : 0);
	val |= (cfg->amq.bmt ? AIOP_AMQ_BMT : 0);
	val |= (cfg->amq.va ? AIOP_AMQ_VA : 0);
	iowrite32(val, &(regs->cdma_regs.cfg));

	/* Configure memory cache attributes for context memory */
	val = (uint32_t)(((cfg->context_write_attr
	                   << AIOP_CDMA_SMCACR_CMWC_SHIFT)
	                   & AIOP_CDMA_SMCACR_CMWC_MASK)
	                | (cfg->context_read_attr
	                   & AIOP_CDMA_SMCACR_CMRC_MASK));
	iowrite32(val, &(regs->cdma_regs.smcacr));
}

void aiop_tile_osm_init(struct aiop_tile_desc *aiop_tile_desc,
                   const struct aiop_osm_cfg *cfg)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	uint32_t oerr = 0, oeddr = 0;

	if (cfg->err_mng.mult_err == AIOP_ERR_DISABLE)
		oeddr |= AIOP_OSM_ERR_ME;
	if (cfg->err_mng.mult_err == AIOP_ERROR_REPORT)
		oerr |= AIOP_OSM_ERR_ME;

	if (cfg->err_mng.relinquish_concurrent == AIOP_ERR_DISABLE)
		oeddr |= AIOP_OSM_ERR_RC;
	if (cfg->err_mng.relinquish_concurrent == AIOP_ERROR_REPORT)
		oerr |= AIOP_OSM_ERR_RC;

	if (cfg->err_mng.exit_no_scope == AIOP_ERR_DISABLE)
		oeddr |= AIOP_OSM_ERR_ENS;
	if (cfg->err_mng.exit_no_scope == AIOP_ERROR_REPORT)
		oerr |= AIOP_OSM_ERR_ENS;

	if (cfg->err_mng.enter_scope_exhausted == AIOP_ERR_DISABLE)
		oeddr |= AIOP_OSM_ERR_ESE;
	if (cfg->err_mng.enter_scope_exhausted == AIOP_ERROR_REPORT)
		oerr |= AIOP_OSM_ERR_ESE;

	if (cfg->err_mng.duplicate_scope == AIOP_ERR_DISABLE)
		oeddr |= AIOP_OSM_ERR_DID;
	if (cfg->err_mng.duplicate_scope == AIOP_ERROR_REPORT)
		oerr |= AIOP_OSM_ERR_DID;

	if (cfg->err_mng.no_scope_transition == AIOP_ERR_DISABLE)
		oeddr |= AIOP_OSM_ERR_TNS;
	if (cfg->err_mng.no_scope_transition == AIOP_ERROR_REPORT)
		oerr |= AIOP_OSM_ERR_TNS;


	iowrite32(oerr, &(regs->osm_regs.oerr));
	iowrite32(oeddr, &(regs->osm_regs.oeddr));
}

int aiop_tile_tman_init(struct aiop_tile_desc *aiop_tile_desc,
	phys_addr_t tman_ctrl_mem,
        const struct aiop_tman_cfg *cfg)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	uint32_t val, prescale, prescale_frac;
	int tries;

	val = (uint32_t)(cfg->amq.icid & AIOP_AMQ_ICID_MASK);
	val |= (cfg->bdi ? AIOP_TMAN_AMQ_BDI : 0);
	val |= (cfg->amq.bmt ? AIOP_AMQ_BMT : 0);
	val |= (cfg->amq.pl ? AIOP_AMQ_PL : 0);
	val |= (cfg->amq.va ? AIOP_AMQ_VA : 0);
	iowrite32(val, &(regs->tman_regs.tmamq));

	prescale = (uint32_t)(cfg->freq - 2);
	prescale_frac = (cfg->freq_frac * 256) / 1000;

	iowrite32((uint32_t)(((prescale << AIOP_TMAN_PRESCALE_SHIFT) &
		  AIOP_TMAN_PRESCALE_MASK) |
		  ((prescale_frac << AIOP_TMAN_PRESCALE_FRAC_SHIFT) &
		  AIOP_TMAN_PRESCALE_FRAC_MASK)),
	          &(regs->tman_regs.tmcfg));

	iowrite32(UINT32_LO(tman_ctrl_mem), &(regs->tman_regs.tmbal));
	iowrite32(UINT32_HI(tman_ctrl_mem), &(regs->tman_regs.tmbah));

	/* Clearing TMan error event reg */
	val = ioread32(&(regs->tman_regs.tmev));
	if (val == AIOP_TMAN_SYS_BUS_ERR)
	{
		pr_err("TMAN bus error\n");
		return -EFAULT;
	}

	/* Clearing TMan stop */
	iowrite32((ioread32(&(regs->tman_regs.tmsc)) & ~AIOP_TMAN_TMSC_STOP),
	          &(regs->tman_regs.tmsc));

	/* Writing to INIT bit to trigger TMan initialization flow */
	iowrite32(AIOP_TMAN_TM_INIT, &(regs->tman_regs.tminit));


	/* Waiting for TMan initialization flow completion */
	tries = 24000;
	do {
		val = ioread32(&(regs->tman_regs.tminit));
		timer_udelay(1000);
	} while ((val & AIOP_TMAN_TM_INIT) && tries--);

	if (val & AIOP_TMAN_TM_INIT)
	{
		pr_err("TMAN Init Timeout\n");
		return -ETIMEDOUT;
	}

	return 0;
}

void aiop_tile_tman_get_timestamp(struct aiop_tile_desc *aiop_tile_desc,
                                 uint64_t *timestamp)
{
    struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
    uint32_t high, low, new_high;

    high = ioread32(&(regs->tman_regs.tmtstmph));
    low = ioread32(&(regs->tman_regs.tmtstmpl));
    new_high = ioread32(&(regs->tman_regs.tmtstmph));

    /* If the high timestamp value differs from previously read value,
       we need to update the lower value, as an overflow may have occurred. */
    if (new_high != high)
	    low = ioread32(&(regs->tman_regs.tmtstmpl));

    *timestamp = (((uint64_t)new_high << 32) | low);
}

void aiop_tile_tman_stop(struct aiop_tile_desc *aiop_tile_desc)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

	iowrite32(AIOP_TMAN_TMSC_STOP, &(regs->tman_regs.tmsc));
}

void aiop_tile_tman_is_busy(struct aiop_tile_desc *aiop_tile_desc, uint32_t *is_busy)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

	*is_busy = (ioread32(&(regs->tman_regs.tmss)) & AIOP_TMAN_TMSS_BUSY);
}

void aiop_tile_ste_init(struct aiop_tile_desc *aiop_tile_desc,
                   const struct aiop_ste_cfg *cfg)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	uint32_t val, stecr1;

	/* keep register's default values */
	stecr1 = ioread32(&regs->cmgw_regs.stecr1);

	stecr1 |= STECR1_XDW;
	iowrite32(stecr1, &regs->cmgw_regs.stecr1);

#ifdef TKT255570
	stecr1 |= STECR1_LE_SYS_STRAP;
	iowrite32(stecr1, &regs->cmgw_regs.stecr1);
#endif

#ifdef ERR008246
	stecr1 |= STECR1_SAU;
	iowrite32(stecr1, &regs->cmgw_regs.stecr1);
#endif
	/* Set AMQ parameters */
	val = (uint32_t)(cfg->amq.icid & AIOP_AMQ_ICID_MASK);
	val |= (cfg->amq.bmt ? AIOP_AMQ_BMT : 0);
	val |= (cfg->amq.pl ? AIOP_AMQ_PL : 0);
	val |= (cfg->amq.va ? AIOP_AMQ_VA : 0);
	iowrite32(val, &(regs->cmgw_regs.amq_ste_cr));
#ifdef ERR008246
	stecr1 &= ~STECR1_SAU;
	iowrite32(stecr1, &regs->cmgw_regs.stecr1);
#endif

#ifdef TKT241224
	/* On reset all bits in STE_SMCACR are zero */
	val = (uint32_t)(((cfg->data_write_attr
	                   << AIOP_STE_SMCACR_WRATTR_SHIFT)
	                   & AIOP_STE_SMCACR_WRATTR_MASK)
	                | (cfg->data_read_attr
	                   & AIOP_STE_SMCACR_RDATTR_MASK));
	iowrite32(val, &(regs->cmgw_regs.ste_smcacr));
#endif

	iowrite32((ioread32(&(regs->cmgw_regs.rgcr)) | AIOP_RGCR_R0_NON_GUARDED),
	          &(regs->cmgw_regs.rgcr));
}

void aiop_tile_ste_reset(struct aiop_tile_desc *aiop_tile_desc,
                const struct aiop_ste_cfg *cfg)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	uint32_t stecr1;

	/* keep register's default, and reset */
	stecr1 = ioread32(&regs->cmgw_regs.stecr1);

	/* In case Soft-Reset is invoked it is required Slave Address Update */
	stecr1 |= STECR1_SAU;
	iowrite32(stecr1, &regs->cmgw_regs.stecr1);
	stecr1 |= STECR1_RESET;
	iowrite32(stecr1, &regs->cmgw_regs.stecr1);
	stecr1 &= ~STECR1_RESET;
	iowrite32(stecr1, &regs->cmgw_regs.stecr1);
	stecr1 &= ~STECR1_SAU;
	iowrite32(stecr1, &regs->cmgw_regs.stecr1);

	/* Clear all STE errors, as they are not needed any more */
	stecr1 |= STECR1_CLR_ERR;
	iowrite32(stecr1, &(regs->cmgw_regs.stecr1));
	stecr1 &= ~STECR1_CLR_ERR;
	iowrite32(stecr1, &regs->cmgw_regs.stecr1);
}

#ifdef FUTURE_SUPPORT
uint32_t aiop_tile_get_rbase(struct aiop_tile_desc *aiop_tile_desc)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

	return ioread32(&regs->cmgw_regs.rbase);
}

void aiop_tile_set_rbase(struct aiop_tile_desc *aiop_tile_desc, uint32_t rbase)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

	iowrite32(rbase, &regs->cmgw_regs.rbase);
}
#endif /* FUTURE_SUPPORT */

void aiop_tile_halt(struct aiop_tile_desc *aiop_tile_desc)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

	iowrite32(AIOP_PM_TILE_HALT, &regs->pm_regs.tpmhr);
}

void aiop_tile_reset(struct aiop_tile_desc *aiop_tile_desc)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

	iowrite32(AIOP_RSTCR_REQ, &regs->cmgw_regs.rstcr);
}

void aiop_tile_release_cores_boot(struct aiop_tile_desc *aiop_tile_desc, uint64_t cores_mask)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

	iowrite32((uint32_t)cores_mask, &regs->cmgw_regs.abrr);
}

uint32_t aiop_tile_get_cores_boot_status(struct aiop_tile_desc *aiop_tile_desc)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

	return ioread32(&regs->cmgw_regs.abcr);
}

uint32_t aiop_tile_get_core_gpr(struct aiop_tile_desc *aiop_tile_desc, int i)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

	return ioread32(&regs->cmgw_regs.acgpr[i]);
}


int aiop_tile_atu_win_enable(struct aiop_tile_desc *aiop_tile_desc,
                        const struct aiop_atu_win_cfg *win_cfg)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	struct aiop_atu_regs *atu_regs = &(regs->atu_regs);
	uint32_t val, err_bit;

	if (win_cfg->num != 0)
	{
		/* Setting OWBAR: window base address and window size */
		LOG2((win_cfg->size >> 16), val);
		val |= (win_cfg->base_addr & AIOP_ATU_OWBAR_WBA_MASK);
		iowrite32(
			val, &(atu_regs->win_regs[win_cfg->num].acore_owbar));
	}

	/* Setting OTEAR: outbound extended translated address */
	val = (uint32_t)(win_cfg->trans_addr >> 32);
	iowrite32(val, &(atu_regs->win_regs[win_cfg->num].acore_otear));

	/* Setting OTAR: outbound translated address */
	val = (uint32_t)(win_cfg->trans_addr & AIOP_ATU_OTAR_TA_MASK);
	iowrite32(val, &(atu_regs->win_regs[win_cfg->num].acore_otar));

	/* Setting OWAR: window attributes and enablement */
	val = (AIOP_ATU_OWAR_EN | (win_cfg->amq.icid & AIOP_AMQ_ICID_MASK));
	val |= (win_cfg->amq.bmt ? AIOP_AMQ_BMT : 0);
	val |= (win_cfg->amq.pl ? AIOP_AMQ_PL : 0);
	val |= (win_cfg->amq.va ? AIOP_AMQ_VA : 0);
	val |= (win_cfg->instr_access ? AIOP_ATU_OWAR_I : 0);
	val |= (win_cfg->data_access ? AIOP_ATU_OWAR_D : 0);
	iowrite32(val, &(atu_regs->win_regs[win_cfg->num].acore_owar));

	/* Verifying that no programming error occurred for this window */
	err_bit = (0x1 << win_cfg->num);
	val = ioread32(&atu_regs->atusr);

	if (val & err_bit) {
		aiop_tile_atu_win_disable(aiop_tile_desc, win_cfg->num);
		pr_err("Programming error on window %d", win_cfg->num);
		return -EINVAL;
	}

	return 0;
}

int aiop_tile_atu_win_disable(struct aiop_tile_desc *aiop_tile_desc, uint8_t win_num)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	struct aiop_atu_regs *atu_regs = &(regs->atu_regs);

	if (win_num >= AIOP_ATU_NUM_OF_WINDOWS) {
		pr_err("Window number exceeds maximal value of %d", AIOP_ATU_NUM_OF_WINDOWS - 1);
		return -EINVAL;
	}

	if (win_num == 0) {
		pr_err("Default window #0 cannot be disabled");
		return -ENOTSUP;
	}

	iowrite32(0, &(atu_regs->win_regs[win_num].acore_owar));

	return 0;
}

int aiop_tile_atu_win_in_use(struct aiop_tile_desc *aiop_tile_desc, uint8_t win_num)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	struct aiop_atu_regs *atu_regs = &(regs->atu_regs);
	uint32_t val;
	int in_use;

	val = ioread32(&(atu_regs->win_regs[win_num].acore_owar));
	if (val & AIOP_ATU_OWAR_EN)
		in_use = 1;
	else
		in_use = 0;

	return in_use;
}


int aiop_tile_ws_set_ch_sched_cfg(struct aiop_tile_desc *aiop_tile_desc,
                             uint8_t ch_id,
                             struct aiop_ws_ch_sched_cfg *sched_cfg)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	struct aiop_ws_regs *ws_regs = &regs->ws_regs;
	uint32_t val;

	if (ch_id >= AIOP_WS_MAX_NUM_OF_CHANNELS) {
		pr_err("Upto %d channels are supported",
		       AIOP_WS_MAX_NUM_OF_CHANNELS);
		return -EINVAL;
	}

	/* Reading CH_CFGA current value */
	iowrite32((uint32_t)(ch_id & AIOP_WS_CH_ID_MASK), &ws_regs->cas);
	val = ioread32(&ws_regs->ch_cfga);

	/* Setting channel's priority, cluster mask and scheduling weight */
	val &= ~(AIOP_WS_CHCFGA_PRIO_MASK | AIOP_WS_CHCFGA_CMASK_MASK
	         | AIOP_WS_CHCFGA_WEIGHT_MASK);
	val |= (((sched_cfg->priority << AIOP_WS_CHCFGA_PRIO_SHIFT)
	         & AIOP_WS_CHCFGA_PRIO_MASK)
	        | ((sched_cfg->cmask << AIOP_WS_CHCFGA_CMASK_SHIFT)
	           & AIOP_WS_CHCFGA_CMASK_MASK)
	        | (sched_cfg->weight & AIOP_WS_CHCFGA_WEIGHT_MASK));
	iowrite32(val, &ws_regs->ch_cfga);

	/* Setting task count limit and channel DQ limit */
	iowrite32(0, &ws_regs->ch_cfgb);

	return 0;
}

void aiop_tile_write_rbase(struct aiop_tile_desc *aiop_tile_desc, uint32_t core_out_of_reset_addr)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

	iowrite32(core_out_of_reset_addr, &regs->cmgw_regs.rbase);
}

/*
 Sets or resets the WRKS[CFG]:{1-0} field.
 This field enables/disables operation of the work scheduler. If changed during
 operation, the work scheduler will respond gracefully and start or stop assigning new tasks.
 This setting can be modified at any time.
 Values:
 00b - WRKS disabled. New tasks are not assigned from any source (TMan or QMan) and
 operation gracefully ceases. This setting is intended for use during verification and will
 interfere with real time events from TMan, etc.
 01b - Enable level 1. New tasks are assigned only from QMan. TMan work available
 indications are ignored and will not cause tasks to be assigned.
 10b - Enable level 2. New tasks are assigned only from TMan or CMGW. QMan work
 available indications are ignored and will not cause tasks to be assigned.
 11b - Enable level 3. Work scheduler is fully operational, new tasks are assigned from all
 sources.
 */
int aiop_tile_ws_enable(struct aiop_tile_desc *aiop_tile_desc, enum aiop_ws_en_mode en_mode)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	struct aiop_ws_regs *ws_regs = &regs->ws_regs;
	uint32_t val;

	val = ioread32(&ws_regs->cfg);

	switch (en_mode) {
	case AIOP_WS_DISABLE:
		val &= ~AIOP_WS_ENABLE_ALL;
		break;

	case AIOP_WS_ENABLE_QMAN:
		val |= AIOP_WS_ENABLE_QMAN;
		break;

	case AIOP_WS_ENABLE_TMAN:
		val |= AIOP_WS_ENABLE_TMAN;
		break;

	case AIOP_WS_ENABLE_ALL:
		val |= AIOP_WS_ENABLE_ALL;
		break;

	default:
		pr_err("Unsupported work scheduler enablement mode");
		return -EINVAL;
	}

	iowrite32(val, &ws_regs->cfg);

	return 0;
}

void aiop_ws_get_pending_tasks(struct aiop_tile_desc *aiop_tile_desc, uint32_t *pending)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	struct aiop_ws_regs *ws_regs = &regs->ws_regs;

	*pending = ioread32(&ws_regs->cpend);
}

void aiop_ws_get_cores_idle(struct aiop_tile_desc *aiop_tile_desc, uint32_t *idle_bits)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	struct aiop_ws_regs *ws_regs = &regs->ws_regs;

	*idle_bits = ioread32(&ws_regs->cidle);
}

int aiop_tile_get_atu(struct aiop_tile_desc *aiop_tile_desc, int i, void **vbase, phys_addr_t *pbase, uint64_t *size)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;
	struct aiop_atu_regs *atu_regs = &(regs->atu_regs);
	uint64_t high;
	uint32_t low, val;

	if (ioread32(&(atu_regs->win_regs[i].acore_owar)) & AIOP_ATU_OWAR_EN)
	{
		*vbase = (void *)(ioread32(&(atu_regs->win_regs[i].acore_owbar))  & AIOP_ATU_OWBAR_WBA_MASK);

		high = (uint64_t)ioread32(&(atu_regs->win_regs[i].acore_otear));
		low = ioread32(&(atu_regs->win_regs[i].acore_otar)) & AIOP_ATU_OTAR_TA_MASK;
		*pbase = (high << 32) | low;

		val = ioread32(&(atu_regs->win_regs[i].acore_owbar)) & AIOP_ATU_OWBAR_OWS_MASK;
		*size = (uint64_t)(1 << val) *64*KILOBYTE;

		return 0;
	}
	else
		return -ENODEV;
}

void aiop_tile_set_mng_gpr(struct aiop_tile_desc *aiop_tile_desc, uint8_t reg_num, uint32_t value)
{
    struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

    iowrite32(value, &(regs->cmgw_regs.mgpr[reg_num]));
}

uint32_t aiop_tile_get_mng_gpr(struct aiop_tile_desc *aiop_tile_desc, uint8_t reg_num)
{
    struct aiop_tile_regs *regs = (struct aiop_tile_regs *)aiop_tile_desc->paddr;

    return ioread32(&(regs->cmgw_regs.mgpr[reg_num]));
}


#ifdef UNDER_CONSTRUCTION
int aiop_tile_ws_set_ch_flow_ctrl_cfg(struct dpaiop *dpaiop,
	uint8_t ch_id,
	struct aiop_ws_ch_flow_cfg *flow_cfg)
{
	struct aiop_ws_regs *regs =
	&dpaiop->ws_regs;
	uint32_t val;

	if (ch_id >= AIOP_WS_MAX_NUM_OF_CHANNELS) {
		pr_err("Upto %d channels are supported",
			AIOP_WS_MAX_NUM_OF_CHANNELS);
		return -EINVAL;
	}

	/* Reading CH_CFGA current value */
	iowrite32((uint32_t)(ch_id & AIOP_WS_CH_ID_MASK), &regs->cas);
	val = ioread32(&regs->ch_cfga);

	/* Setting channel's ICID */
	val &= ~AIOP_WS_CHCFGA_ICID_MASK;
	val |= ((flow_cfg->icid << AIOP_WS_CHCFGA_ICID_SHIFT) &
		AIOP_WS_CHCFGA_ICID_MASK);
	iowrite32(val, &regs->ch_cfga);

	/*
	 ch_id to CAS

	 FC_CFG: BDI, HW mapping EN, create task, msg select, EPID

	 FC_CGMC 0..7: CGID + CG mask
	 FC_BPMC 0..7: BPID + BP mask
	 FC_FQID 0..7: FQID

	 */

	return 0;
}
#endif /* UNDER_CONSTRUCTION */

