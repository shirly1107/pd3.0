/**************************************************************************//*
 * Copyright 2013 Freescale Semiconductor, Inc.

 @File		sys_eild.c

 @Description	MC4AIOP ELF image loader.
 Based on http://sourceforge.net/apps/trac/elftoolchain/wiki/libelf

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "common/fsl_stdio.h"
#include "fsl_malloc.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "fsl_errors.h"
#include "fsl_aiop_common.h"

#include "aiop_elf_loader.h"
#include "dpaiop.h"

#define IS_AIOP_INIT_STRUCT(PHDR) \
	((PHDR)->p_vaddr == (dma_addr_t)AIOP_INIT_DATA_FIXED_ADDR)

static int aiop_2_mc_map(struct dpaiop *dpaiop,
	uint64_t aiop_vaddr,
	uint64_t memsz,
	phys_addr_t *paddr,
	void **vaddr,
	int *iram)
{
	int i;
	int ret = -1;
	struct vrt2phy_mem_rgn_entry *map = dpaiop->mem_map;
	void *trans_vaddr;
	struct dpmng_amq mc_amq;

	*iram = 0;
	dpmng_get_amq(&mc_amq);
	for (i = 0; i < MAX_NUM_OF_MEM_MAP_ENTRIES; i++) {
		if ((aiop_vaddr >= map[i].vrt_base_addr)
			&& ((aiop_vaddr + memsz)
				<= (map[i].vrt_base_addr + map[i].mem_size))) {
			*paddr = aiop_vaddr - map[i].vrt_base_addr
					+ map[i].phy_base_addr;

			if (map[i].phy_base_addr == dpaiop->desc.iram_paddr) {
				/* IRAM */
				trans_vaddr = dpmng_mc_set_ccsr_window(
					map[i].phy_base_addr,
					&mc_amq);
				*iram = 1;
			} else
				trans_vaddr = dpmng_mc_set_soc_window(
					map[i].phy_base_addr,
					&mc_amq);
			*vaddr = (void *)(*paddr - map[i].phy_base_addr
						+ (uint64_t)trans_vaddr);

			ret = 0;
			break;
		}
	}

	return ret;
}

static void phy_2_mc_vrt_revert(struct dpaiop *dpaiop, phys_addr_t paddr)
{
	int i;
	struct vrt2phy_mem_rgn_entry *map = dpaiop->mem_map;

	for (i = 0; i < MAX_NUM_OF_MEM_MAP_ENTRIES; i++) {
		if ((paddr >= map[i].phy_base_addr)
			&& ((paddr) < (map[i].phy_base_addr + map[i].mem_size))) {
			if (map[i].phy_base_addr == dpaiop->desc.iram_paddr)
				/* IRAM */
				dpmng_mc_revert_ccsr_window();
			return;
		}
	}
}

static int load_segment(struct dpaiop *dpaiop, int seg_id, uint8_t *img, GElf_Phdr *phdr, phys_addr_t *aiop_init_s_paddr)
{
	int j, iram = 0;
	size_t size; /* number of entries in ELF program header */
	phys_addr_t phy_addr;
	void *dst_addr, *ret_code, *addr;
	char *str;
	uint32_t str_size = 0;

	if (phdr->p_memsz < phdr->p_filesz) { /* TODO: assumption: memsz should be greater or equal to filesz */
		pr_err(
			"Input error: Segment (%d): file size (0x%08x bytes) larger than memory size (0x%08x bytes).\n", seg_id, (uint32_t)phdr->p_filesz, (uint32_t)phdr->p_memsz);
		return -EINVAL;
	}
	if (aiop_2_mc_map(dpaiop, (uint32_t)phdr->p_vaddr,
				(uint64_t)phdr->p_memsz, &phy_addr, &dst_addr,
				&iram)
		>= 0) {
		if (IS_AIOP_INIT_STRUCT(phdr))
			*aiop_init_s_paddr = phy_addr;
		if (phdr->p_filesz > 0) {
			/* For accessing IRAM during memcpy, aiop2mc_addr_map configures 
			 * CCSR SoC window registers that must be reverted. */
			if (iram) {
				size = ALIGN_UP(phdr->p_filesz, 64);
				str_size = (uint32_t)(dpaiop->desc.num_clusters * 11);
				str = (char *)fsl_malloc(str_size);
				if (str == NULL)
				{
					phy_2_mc_vrt_revert(dpaiop, phy_addr);
					pr_err("No Memory\n");
					return -ENOMEM;
				}
				memset(str, 0, (uint32_t)(dpaiop->desc.num_clusters * 11));
				/* align to 64 bytes for fast copying */
				for (j = 0; j < dpaiop->desc.num_clusters; j++) {
					addr =
						PTR_MOVE(dst_addr, (j * -dpaiop->desc.iram_offset));

					ret_code = memcpy64(
						addr,
						(void *)(img + phdr->p_offset),
						size);
					if (ret_code != addr) {
						phy_2_mc_vrt_revert(
							dpaiop, phy_addr);
						pr_err(
							"memcpy(): Error: failed to copy 0x%08x bytes of segment (%d) from %p addr [img] to %p addr [dst].\n", (uint32_t)phdr->p_filesz, seg_id, (uint32_t)(img + phdr->p_offset), (uint32_t)addr);
						return -ENAVAIL;
					}
					snprintf(str, str_size, "%s%p; ",str, addr);
				}
				phy_2_mc_vrt_revert(dpaiop, phy_addr);
				pr_info(
					"Segment (%d): 0x%08x bytes written to  %s addr [dst] from %p addr [img].\n", seg_id, (uint32_t)phdr->p_filesz, str, (uint32_t)(img + phdr->p_offset));
				fsl_free(str);
			} else {
				ret_code = memcpy(
					dst_addr,
					(const void *)(img + phdr->p_offset),
					(size_t)phdr->p_filesz);
				if (ret_code != dst_addr) {
					pr_err(
						"memcpy(): Error: failed to copy 0x%08x bytes of segment (%d) from %p addr [img] to %p addr [dst].\n", (uint32_t)phdr->p_filesz, seg_id, (uint32_t)(img + phdr->p_offset), (uint32_t)dst_addr);
					return -ENAVAIL;
				}
				pr_info(
					"Segment (%d): 0x%08x bytes written to %p addr [dst] from %p addr [img].\n", seg_id, (uint32_t)phdr->p_filesz, (uint32_t)dst_addr, (uint32_t)(img + phdr->p_offset));
			}

		} else {
			if (iram)
				/* For accessing IRAM during memcpy, aiop2mc_addr_map configures 
				 * CCSR SoC window registers that must be reverted. */
				phy_2_mc_vrt_revert(dpaiop, phy_addr);
		}
		if (phdr->p_memsz > phdr->p_filesz) {
			dst_addr = (uint8_t *)dst_addr + phdr->p_filesz;
			if (memset(dst_addr, 0,
					(size_t)(phdr->p_memsz - phdr->p_filesz))
				!= dst_addr) {
				pr_err(
					"memset(): Error: failed to initialize 0x%08x bytes initialized at %p addr [dst].\n", (uint32_t)(phdr->p_memsz - phdr->p_filesz), (uint32_t)dst_addr);
				return -ENAVAIL;
			}
			pr_info(
				"Segment (%d): 0x%08x bytes initialized at %p addr [dst].\n", seg_id, (uint32_t)(phdr->p_memsz - phdr->p_filesz), (uint32_t)dst_addr);
		}
	} else { /* vrt2phy_addr_map(): appropriate memory region not found */
		pr_info(
			"Segment (%d): with start virt addr %p [per img] and size 0x%08x bytes omitted.\n", seg_id, (uint32_t)phdr->p_vaddr, (uint32_t)phdr->p_memsz);
	}
	
	return 0;
}

int eld_get_aiop_struct(uint8_t *img, void **aiop_init_s)
{
	int i;
	int ec; /* ELF class */
	size_t phdr_nentries; /* number of entries in ELF program header */
	Elf *e;
	GElf_Ehdr ehdr; /* ELF executable header */
	GElf_Phdr phdr; /* ELF program header */

	if (img == NULL) {
		pr_err("Input error: NULL as a pointer to the ELF image.\n");
		return -EINVAL;
	}

	if (elf_version(EV_CURRENT) == EV_NONE) {
		pr_err(
			"elf_version(): Error: cannot initialize the ELF library.\n");
		return -ENAVAIL;
	}

	/* img_sz is zero; workaround to bypass libelf's ELF image size requirement */
	if ((e = libelf_memory((char *)img, ELF_IMG_DFLT_SZ, 1)) == NULL) { /* use ELF_IMG_DFLT_SZ instead */
		pr_err(
			"libelf_memory(): Error: cannot create the ELF object.\n");
		return -ENAVAIL;
	}

	if (elf_kind(e) != ELF_K_ELF) {
		pr_err(
			"elf_kind(): Input error: the image is not of ELF type.\n");
		return -EINVAL;
	}

	if ((ec = gelf_getclass(e)) == ELFCLASSNONE) { /* expect 32- or 64-bit ELF image class */
		pr_err(
			"gelf_getclass(): Input error: undefined ELF class.\n");
		return -EINVAL;
	}

	if (gelf_getehdr(e, &ehdr) == NULL) {
		pr_err(
			"gelf_gethdr(): Error: cannot retrieve the ELF executable header.\n");
		return -ENAVAIL;
	}

	if (ehdr.e_type != ET_EXEC) {
		pr_err(
			"Input error: not executable ELF image type not supported.\n");
		return -EINVAL;
	}

	if (elf_getphdrnum(e, &phdr_nentries) != 0) {
		pr_err(
			"elf_getphdrnum(): Error: cannot retrieve number of entries in the program header table.\n");
		return -ENAVAIL;
	}

	*aiop_init_s = NULL;
	for (i = 0; i < phdr_nentries; i++) { /* for each program header entry */
		if (gelf_getphdr(e, i, &phdr) != &phdr) {
			pr_err(
				"gelf_getphdr(): Error: cannot retrieve an entry in the  program header table.\n");
			return -ENAVAIL;
		}

		if (IS_AIOP_INIT_STRUCT(&phdr)) {

			if (phdr.p_type == PT_LOAD) { /* load only load-able segments */
				if (ec == ELFCLASS32) {
					*aiop_init_s =
						(void *)(img + phdr.p_offset);
					pr_info(
						"Found memory_data segment (%d): 0x%08x bytes at %p addr [img].\n", i, (uint32_t)phdr.p_memsz, (uint32_t)(img + phdr.p_offset));
					break;
				} else { /* ELFCLASS64 */
					pr_err(
						"Error: Loading of 64-bit ELF image is not supported yet.\n");
					return -ENOTSUP;
				} /* end of if case: if  (ec == ELFCLASS32)... */
			} /* end of if case: if (phdr.p_type == PT_LOAD)... */
		}
	} /*  end of for loop: for (i = 0; i < n; i++)... */
	if (*aiop_init_s == NULL)
	{
		pr_err("AIOP struct not found at 0x%08x\n", AIOP_INIT_DATA_FIXED_ADDR);
		return -ENAVAIL;
	}

	elf_end(e);

	return 0;
}

static int check_image(uint8_t *img, Elf *e, size_t *phdr_nentries, int *ec)
{
	GElf_Ehdr ehdr; /* ELF executable header */

	if (elf_kind(e) != ELF_K_ELF) {
		pr_err(
			"elf_kind(): Input error: the image is not of ELF type.\n");
		return -EINVAL;
	}

	if ((*ec = gelf_getclass(e)) == ELFCLASSNONE) { /* expect 32- or 64-bit ELF image class */
		pr_err(
			"gelf_getclass(): Input error: undefined ELF class.\n");
		return -EINVAL;
	}

	if (gelf_getehdr(e, &ehdr) == NULL) {
		pr_err(
			"gelf_gethdr(): Error: cannot retrieve the ELF executable header.\n");
		return -ENAVAIL;
	}

	if (ehdr.e_type != ET_EXEC) {
		pr_err(
			"Input error: not executable ELF image type not supported.\n");
		return -EINVAL;
	}

	if (elf_getphdrnum(e, phdr_nentries) != 0) {
		pr_err(
			"elf_getphdrnum(): Error: cannot retrieve number of entries in the program header table.\n");
		return -ENAVAIL;
	}
		
	return 0;
}

int eld_load_image(struct dpaiop *dpaiop,
	uint8_t *img,
	size_t img_sz,
	phys_addr_t *aiop_init_s_paddr)
{
	int i, err;
	Elf *e;
	GElf_Phdr phdr; /* ELF program header */
	size_t phdr_nentries; /* number of entries in ELF program header */
	int ec; /* ELF class */

	if (img == NULL) {
		pr_err("Input error: NULL as a pointer to the ELF image.\n");
		return -EINVAL;
	}
	if (elf_version(EV_CURRENT) == EV_NONE) {
		pr_err(
			"elf_version(): Error: cannot initialize the ELF library.\n");
		return -ENAVAIL;
	}

	if (img_sz > 0) { /* libelf's libelf_memory() requires ELF image size */
		if ((e = libelf_memory((char *)img, img_sz, 1)) == NULL) {
			pr_err(
				"libelf_memory(): Error: cannot create the ELF object.\n");
			return -ENAVAIL;
		}
	} else { /* img_sz is zero; workaround to bypass libelf's ELF image size requirement */
		if ((e = libelf_memory((char *)img, ELF_IMG_DFLT_SZ, 1))
			== NULL) { /* use ELF_IMG_DFLT_SZ instead */
			pr_err(
				"libelf_memory(): Error: cannot create the ELF object.\n");
			return -ENAVAIL;
		}
	}

	err = check_image(img, e, &phdr_nentries, &ec);
	if (err)
		return err;

	for (i = 0; i < phdr_nentries; i++) { /* for each program header entry */
		if (gelf_getphdr(e, i, &phdr) != &phdr) {
			pr_err( "gelf_getphdr(): Error: cannot retrieve an entry in the  program header table.\n");
			return -ENAVAIL;
		}
		if (phdr.p_type == PT_LOAD) { /* load only load-able segments */
			if (ec == ELFCLASS32) {
				err = load_segment(dpaiop, i, img, &phdr,
							aiop_init_s_paddr);
				if (err)
					return err;
			} else { /* ELFCLASS64 */
				pr_err( "Error: Loading of 64-bit ELF image is not supported yet.\n");
				return -ENOTSUP;
			} /* end of if case: if  (ec == ELFCLASS32)... */
		} /* end of if case: if (phdr.p_type == PT_LOAD)... */
	} /*  end of for loop: for (i = 0; i < n; i++)... */
	elf_end(e);

	return 0;
}

