/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          aiop.h

 @Description   AIOP internal structures and definitions.
*//***************************************************************************/
#ifndef __AIOP_H
#define __AIOP_H

#include "common/fsl_string.h"
#include "fsl_aiop_common.h"
#include "drivers/fsl_aiop.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPAIOP

/**************************************************************************//**
 @Description   AIOP Profile SRAM definitions
*//***************************************************************************/
#define SP_BASE_ADDR                0x000030000
#define AIOP_SP_BDI                 0x00080000

#define SP_FF_LOW_DL_MASK           0x0000FFFF
#define SP_FF_HIGH_BS               0x80000000
#define SP_FF_HIGH_FF_SHIFT         28
#define SP_FF_HIGH_FF_MASK          0x30000000
#define SP_FF_HIGH_VA               0x04000000
#define SP_FF_HIGH_DLC              0x01000000
#define SP_FF_HIGH_PTAR             0x00800000
#define SP_FF_HIGH_SGHR             0x00100000
#define SP_FF_HIGH_ASAR_SHIFT       16
#define SP_FF_HIGH_ASAR_MASK        0x000F0000
#define SP_FF_HIGH_DHR_MASK         0x00000FFF

#define SP_BP_BMT                   0x80000000
#define SP_BP_BPID_MASK             0x3FFF0000
#define SP_BP_BPID_SHIFT            16
#define SP_BP_PBS_MASK              0x0000FFC0
#define SP_BP_PBS_SHIFT             6
#define SP_BP_SR                    0x00000020
#define SP_BP_BP                    0x00000002
#define SP_BP_BPV                   0x00000001

#define SP_MAX_ASAR_VAL             (64*15)
#define SP_MAX_NUM_POOLS            2

#define ERRCR_DISABLE		0x00000040


#define AIOP_PM_TILE_HALT	    0x00000001
#define AIOP_RSTCR_REQ		    0x00000001


struct aiop_psram_entry {
    uint32_t    aiop_specific;
    uint32_t    reserved0;
    uint32_t    frame_format_low;
    uint32_t    frame_format_high;
    uint32_t    bp1;
    uint32_t    bp2;
    uint32_t    reserved1;
    uint32_t    reserved2;
};

/**************************************************************************//**
 @Description   AIOP registers definitions
*//***************************************************************************/
#define AIOP_AMQ_PL                     0x00040000
#define AIOP_AMQ_BMT                    0x00020000
#define AIOP_AMQ_VA                     0x00010000
#define AIOP_AMQ_ICID_MASK              0x00007FFF
#define AIOP_CFG_DADPCA_MASK          	0xFFE00000

#define AIOP_RGCR_R0_NON_GUARDED        0x00000001


#define AIOP_TILE_WSCR_NTASKS_MASK      0x0000000F
#define AIOP_TILE_CFG_EN                0x00000001

#define AIOP_WS_MAX_NUM_OF_CHANNELS     64
#define AIOP_WS_CH_ID_MASK              0x000000FF
#define AIOP_WS_CHCFGA_ICID_MASK        0x7FFF0000
#define AIOP_WS_CHCFGA_ICID_SHIFT       16
#define AIOP_WS_CHCFGA_PRIO_MASK        0x00007000
#define AIOP_WS_CHCFGA_PRIO_SHIFT       12
#define AIOP_WS_CHCFGA_CMASK_MASK       0x00000F00
#define AIOP_WS_CHCFGA_CMASK_SHIFT      8
#define AIOP_WS_CHCFGA_WEIGHT_MASK      0x000000FF

/* EP_FDPA - Entry Point Frame Descriptor Presentation Address */
#define AIOP_EP_FDPA_FDPA_MASK		0xFFE00000
#define AIOP_EP_FDPA_FDPA_SHIFT		21
#define AIOP_EP_FDPA_DEFAULT		0x3
#define AIOP_EP_FDPA_ADPCA_MASK		0x0000FFE0
#define AIOP_EP_FDPA_ADPCA_SHIFT	5
#define AIOP_EP_ADPCA_DEFAULT		0x2

/* EP_PTAPA � Entry Point Pass Through Annotation Presentation Address */
#define AIOP_EP_PTAPA_MASK		0x0000FFC0
#define AIOP_EP_PTAPA_SHIFT		6
#define AIOP_EP_PTAPA_DEFAULT		0xB
#define AIOP_EP_PTAPA_DISABLE		0x3FF

/* EP_ASAPA � Entry Point Accelerator Specific Annotation Presentation Address */
#define AIOP_EP_ASAPA_ASAPS_MASK	0x000F0000
#define AIOP_EP_ASAPA_ASAPS_SHIFT	16
#define AIOP_EP_ASAPS_DEFAULT		0
#define AIOP_EP_ASAPA_ASAPA_MASK	0x0000FFC0
#define AIOP_EP_ASAPA_ASAPA_SHIFT	6
#define AIOP_EP_ASAPA_DEFAULT		0
#define AIOP_EP_ASAPA_ASAPO_MASK	0x0000000F
#define AIOP_EP_ASAPO_DEFAULT		0

/* EP_SPA � Entry Point Segment Presentation Address */
#define AIOP_EP_SPA_SIZE_MASK		0xFFFF0000
#define AIOP_EP_SPA_SIZE_SHIFT		16
#define AIOP_EP_SPA_SIZE_DEFAULT	0x80
#define AIOP_EP_SPA_ADDR_MASK		0x0000FFFF
#define AIOP_EP_SPA_ADDR_DEFAULT	0x1c0

/* EP_SPO � Entry Point Segment Presentation Offset */
#define AIOP_EP_SPO_SR_FROM_END		0x80000000	/* Reference within the frame to present from end */
#define AIOP_EP_SPO_SR_FROM_START	0		/* Reference within the frame to present from start */
#define AIOP_EP_SPO_NDS			0x02000000	/* Specify that a data segment not be allocated and opened by the h/w */
#define AIOP_EP_SPO_SPO_MASK		0x0000FFFF	/* Byte offset within the frame to start presenting data from */
#define AIOP_EP_SPO_DEFAULT		0

/* EP_OSC � Entry Point Order Scope Construction */
#define AIOP_EP_OSC_SRC_NO_SCOPE	0		/* No order scope specified, task does not enter a scope */
#define AIOP_EP_OSC_SRC_FROM_FD		0x10000000	/* Scope ID taken from the specified slice of the received frame�s FD[FLC] field. */
#define AIOP_EP_OSC_SEL_0		0x00000000	/* When SRC=1, Order Scope ID is taken from FLC[63:32] */
#define AIOP_EP_OSC_SEL_1		0x00010000	/* When SRC=1, Order Scope ID is taken from FLC[47:16] */
#define AIOP_EP_OSC_SEL_2		0x00020000	/* When SRC=1, Order Scope ID is taken from FLC[39:8] */
#define AIOP_EP_OSC_SEL_3		0x00030000	/* When SRC=1, Order Scope ID is taken from FLC[31:0] */
#define AIOP_EP_OSC_OSRM_0		0		/* A mask of 0xFFFFFFFF applied to the specified slice of FD[FLC] to construct the order scope ID value */
#define AIOP_EP_OSC_OSRM_1		0x00000001	/* A mask of 0xFFFFFF00 applied to the specified slice of FD[FLC] to construct the order scope ID value */
#define AIOP_EP_OSC_OSRM_2		0x00000002	/* A mask of 0xFFFF0000 applied to the specified slice of FD[FLC] to construct the order scope ID value */
#define AIOP_EP_OSC_OSRM_3		0x00000003	/* A mask of 0xFF000000 applied to the specified slice of FD[FLC] to construct the order scope ID value */
#define AIOP_EP_OSC_OSRM_4		0x00000004	/* A mask of 0x000000FF applied to the specified slice of FD[FLC] to construct the order scope ID value */
#define AIOP_EP_OSC_OSRM_5		0x00000005	/* A mask of 0x0000FFFF applied to the specified slice of FD[FLC] to construct the order scope ID value */
#define AIOP_EP_OSC_OSRM_6		0x00000006	/* A mask of 0x00FFFFFF applied to the specified slice of FD[FLC] to construct the order scope ID value */
#define AIOP_EP_OSC_OSRM_7		0x00000007	/* A mask of 0x00000000 applied to the specified slice of FD[FLC] to construct the order scope ID value */
#define AIOP_EP_OSC_EP_CONCURENT	0 		/* The initial execution phase is executing concurrently */
#define AIOP_EP_OSC_EP_EXCLUSIVE	0x01000000	/* The initial execution phase is executing exclusively */

#define AIOP_FDMA_CFG_DADPCA_MASK       0xFFE00000
#define AIOP_FDMA_CFG_DADPCA_SHIFT      21
#define AIOP_FDMA_SRU_SIZE_EN           0x80000000
#define AIOP_FDMA_SRU_SIZE_MASK         0x0FFFFFC0

/* Defines for cache attributes fields from the
System Memory Cache Attribute Control Registers - accelerators*/
#define AIOP_FDMA_SMCACR_FDWC_MASK      0x1F000000
#define AIOP_FDMA_SMCACR_FDWC_SHIFT     24
#define AIOP_FDMA_SMCACR_SRUWC_MASK     0x001F0000
#define AIOP_FDMA_SMCACR_SRUWC_SHIFT    16
#define AIOP_FDMA_SMCACR_FDRC_MASK      0x00001F00
#define AIOP_FDMA_SMCACR_FDRC_SHIFT     8
#define AIOP_FDMA_SMCACR_SRURC_MASK     0x0000001F

#define AIOP_CDMA_SMCACR_CMWC_MASK      0x001F0000
#define AIOP_CDMA_SMCACR_CMWC_SHIFT     16
#define AIOP_CDMA_SMCACR_CMRC_MASK      0x0000001F
#define AIOP_CDMA_CFG_BDI               0x00080000

/* Stats Engine System Memory Cache Attribute Control Register
 * See Table 8-37/8-62 and AXI4 Appendix A
 */
#define AIOP_STE_SMCACR_WRATTR_MASK	0x001F0000
#define AIOP_STE_SMCACR_WRATTR_SHIFT     16
#define AIOP_STE_SMCACR_RDATTR_MASK	0x0000001F

#define AIOP_OSM_ERR_ME                 0x80000000
#define AIOP_OSM_ERR_RC                 0x00000010
#define AIOP_OSM_ERR_ENS                0x00000008
#define AIOP_OSM_ERR_ESE                0x00000004
#define AIOP_OSM_ERR_TNS                0x00000002
#define AIOP_OSM_ERR_DID                0x00000001

#define AIOP_TMAN_TMSC_STOP		0x00000001
#define AIOP_TMAN_TMSS_BUSY		0x00000001

#define AIOP_ATU_OWBAR_WBA_MASK         0xFFFF0000
#define AIOP_ATU_OWBAR_OWS_MASK         0x0000001F
#define AIOP_ATU_OWAR_EN                0x80000000
#define AIOP_ATU_OWAR_I                 0x40000000
#define AIOP_ATU_OWAR_D                 0x20000000
#define AIOP_ATU_OTAR_TA_MASK           0xFFFF0000

#define AIOP_TMAN_PRESCALE_MASK         0x0000FFF0
#define AIOP_TMAN_PRESCALE_SHIFT        4
#define AIOP_TMAN_PRESCALE_FRAC_SHIFT   16
#define AIOP_TMAN_PRESCALE_FRAC_MASK    0x00FF0000
#define AIOP_TMAN_AMQ_BDI               0x00008000
#define AIOP_TMAN_TM_INIT               0x00000001
#define AIOP_TMAN_SYS_BUS_ERR		0x80000000

#define STECR1_RESET			0x00000002
#define STECR1_LE_SYS_STRAP		0x00000004
#define STECR1_XDW			0x00004000
#define STECR1_CLR_ERR			0x00000001
#define STECR1_SAU			0x00008000

#define STE_ERR_CODE_MASK		0xE0000000
#define STE_ERR_CODE_SHIFT		29

#define STE_ERR_CODE_AXI_CMD_DEC	1
#define STE_ERR_CODE_CMD_DESC		2
#define STE_ERR_CODE_AXI_OUT_ADDR	3
#define STE_ERR_CODE_AXI_OUT_RD		4
#define STE_ERR_CODE_AXI_OUT_WR		5

#define STESR_AXI_CMD_DEC		0x00000002
#define STESR_CMD_DESC			0x00000004
#define STESR_AXI_OUT_ADDR		0x00000008
#define STESR_AXI_OUT_RD		0x00000010
#define STESR_AXI_OUT_WR		0x00000020

#define AIOP_IP_STE			0x20000000
#define AIOP_IP_TMAN			0x10000000 /* RESR: rev 2 only */
#define AIOP_IP_AAP_SEC			0x08000000
#define AIOP_IP_AACL			0x00100000 /* RESR: rev 2 only */
#define AIOP_IP_CTLU			0x00010000 /* RESR: rev 2 only */
#define AIOP_IP_ATU			0x00008000 /* RESR: rev 2 only */
#define AIOP_IP_PSRAM			0x00000100 /* RESR: rev 2 only */ /* not ECCCR1 */
#define AIOP_IP_SSRAM			0x00000200 /* not ECCCR1 */
#define AIOP_IP_IRAM			0x00000400 /* not ECCCR1 */
#define AIOP_IP_FDMA			0x00000010 /* RESR: rev 2 only */
#define AIOP_IP_OSM			0x00000002
#define AIOP_IP_WRKS			0x00000001

#define DCSR_CERRCR_IEE			0x00000001
#define DCSR_SHSERRCR_SEE		0x00000001
#define DCSR_PSERRCR_PEE		0x00000001

#define DCSR_RC_PCAC_MASK		0x00FFFF00
#define DCSR_RC_ICAC_MASK		0x000000F0

#define AIOP_DCSR_ERR_MNG_INTR_OFFSET	0x400
#define AIOP_DCSR_RUN_CTRL_OFFSET	0x24000

#define AIOP_PSRAM_NUM_OF_ENTRIES   256

struct aiop_err_mng_intr {
	uint32_t ecccr1; /*0x400 ECCCR1 - ECC Control Register */
	uint32_t reserved0;
	uint32_t sbeesr[2]; /* 0x408-0x40c SBEESR - Single bit ECC Status Register */
	uint32_t mbeesr[2]; /* 0x410-0x414 MBEESR1 - Multi-bit ECC Status Register */
	uint32_t reserved1[2];
	uint32_t cerrcr; /* 0x420 CERRCR - Core Error Control Register */
	uint32_t shserrcr; /*0x424 SHSERRCR - Shared SRAM Error Control Register */
	uint32_t pserrcr; /* 0x428 PSERRCR - Profile SRAM Error Control Register */
	uint32_t reserved2;
	uint32_t resr; /* 0x430 RESR - Recoverable Error Status Register */
	uint32_t nresr; /* 0x434 NRESR - Non-Recoverable Error Status Register */
	uint32_t reserved3[2];
};

struct aiop_run_control {
	uint8_t  reserved0[0xC];
	uint32_t dcdsr; /* Ch Device Run Control Debug Status n */
	uint8_t  reserved1[0xC];
	uint32_t cdhltsr; /* 1Ch  Run Control Debug Halted Status n */
	uint8_t  reserved2[0xC];
	uint32_t cdhltcr; /* 2Ch Run Control Debug Halt Control n */
	uint32_t cfrzsr; /* 30h  Run Control Freeze Request Status n */
	uint8_t  reserved3[0xC];
	uint32_t cfrzcr; /* 40h  Run Control Freeze Control n */
	uint8_t  reserved4[0x18];
	uint32_t crsmcr; /* 5Ch  Run Control Resume Control n */
	uint32_t csstpsr; /* 60h Run Control Softstop Request Status n */
	uint8_t  reserved5[0xC];
	uint32_t csstpcr; /* 70h Run Control Softstop Control n */
	uint8_t  reserved6[0x1C];
	uint32_t desre; /* 90h Device Event Status for EPU Events */
	uint32_t desrd; /* 94h Device Event Status for Device Events */
	uint32_t desrr; /* 98h Device Event Status for RUNN Events */
	uint8_t  reserved7[0x14];
	uint32_t crtdsr; /* ACh Run Control Reset To Debug Status n */
	uint8_t  reserved8[0x8];
	uint32_t crtdcr; /* BCh Run Control Reset To Debug Control n */
	uint8_t  reserved9[0xC];
	uint32_t csscr; /* CCh Run Control Singlestep Control n */
	uint8_t  reserved10[0x30];
	uint32_t cdsr; /* 100h Run Control Debug Status n */
	uint8_t  reserved11[0x208];
	uint32_t cg0cr; /* 30Ch Core Group 0 Configuration n */
	uint8_t  reserved12[0x4F0];
	uint32_t runnctr0; /* 800h RUNN Counter 0 most significant 16-bits */
	uint32_t runnctr1; /* 804h RUNN Counter 1 least significant 32-bits */
	uint32_t runnctrval0; /* 808h RUNN Counter Value 0 most significant 16-bits */
	uint32_t runnctrval1; /* 80Ch RUNN Counter Value 1 least significant 32-bits */
	uint32_t runncr; /* 810h RUNN Control n */
	uint8_t reserved13[0x8C];
	uint32_t runnsr; /* 8A0h  RUNN Status */
	uint8_t  reserved14[0x5C];
	uint32_t cgacre; /* 900h Core Group Action Control n for EPU Events */
	uint8_t  reserved15[0x7C];
	uint32_t dacre; /* 980h Device Action Control n for EPU Events */
	uint8_t  reserved16[0x7C];
	uint32_t cgacrd; /* A00h Core Group Action Control n for Device Events0 */
	uint8_t  reserved17[0x7C];
	uint32_t dacrd; /* A80h Device Action Control n for Device Events */
	uint8_t  reserved18[0x7C];
	uint32_t csttacr; /* B00h Core State Action Control n for EPU triggering off Core State */
	uint8_t  reserved19[0x13C];
	uint32_t cgacrr; /* C40h Core Group Action Control for RUNN Events */
	uint8_t  reserved20[0xC];
	uint32_t dacrr; /* C50h Device Action Control for RUNN Events */
	uint8_t  reserved21[0xAC];
	uint32_t cesrr; /* D00h Run Control Event Status n for RUNN Events */
};

#define AIOP_EVENT_NON_RECOVERABLE_ERR		0x80000000

struct aiop_tile {
	int id;
	struct aiop_tile_desc desc;

	struct {
		int init;
		struct aiop_ep_entry_cfg cfg;
	} ep_table[AIOP_EP_TABLE_NUM_OF_ENTRIES];
	struct {
		int init;
		struct aiop_sp_cfg cfg;
	} sp_table[AIOP_PSRAM_NUM_OF_ENTRIES];
	int (*isr_cb)(void *arg, uint8_t irq_id, uint32_t event);
	void *isr_cb_arg;
	uint8_t isr_cb_irq_id;	
	void *timer;
	uint64_t base_time;
	int intr_cnt;
};


#endif /* __AIOP_H */
