/**************************************************************************//**
 * Copyright 2013 Freescale Semiconductor, Inc.

@File		sys_eild.h

@Description	This file contains MC4AIOP ELF image loader API.
						Based on http://sourceforge.net/apps/trac/elftoolchain/wiki/libelf
@Cautions      None.
*//***************************************************************************/
#ifndef	_SYS_EILD_H_
#define	_SYS_EILD_H_

#include "gelf.h" /* libelf library include file */

#include "dpaiop.h"

/**************************************************************************//**
 @Group         aiopapp_init INIT (Initialization and Shutdown)

 @{
*//***************************************************************************/

#define ELF_IMG_DFLT_SZ	0X400
/**< ELF image default size; workaround for libelf's ELF image size requirement */
#define SYS_EILD_SH_STRUCT		1
/**< Load only AIOP and MC shared structure */
#define SYS_EILD_ALL_BUT_NOT_SH_STRUCT	2
/**< Load all besides AIOP and MC shared structure */
#define SYS_EILD_ALL (SYS_EILD_SH_STRUCT | SYS_EILD_ALL_BUT_NOT_SH_STRUCT)
/**< Load full AIOP image */

/**************************************************************************//**
 @Function      sys_eild

 @Description   MC4AIOP ELF image loader.

                Loads AIOP ELF image from MC.

 @Param[in]	img - MC vrt addr of AIOP ELF image.
 @Param[in]	img_sz - AIOP ELF image size; optional: pass zero to bypass.
 @Param[in]	vrt2phy_addr_map - AIOP virtual to physical address mapping function.
 @Param[in]	phy2vrt_addr_map - Physical to MC virtual address mapping function.
 @Param[in]	flags - Possible modes for elf loader, see #SYS_EILD_SH_STRUCT
 	 	#SYS_EILD_ALL_BUT_NOT_SH_STRUCT #SYS_EILD_ALL .
 @Param[out]	aiop_init_s - Virtual address inside SHRAM where AIOP boot structure is.

 @Retval		0: Success.
 @Retval		EINVAL: Invalid argument, or conflicting arguments.
 @Retval		ENOTSUP: Operation not supported.
 @Retval		ENAVAIL: Resource not available, or not found

 @Cautions      None.
*//***************************************************************************/
int
eld_get_aiop_struct( /* MC4AIOP ELF image loader */
		uint8_t *img, 	/* MC vrt addr of AIOP ELF image */
		void **aiop_init_s
);

int eld_load_image(struct dpaiop *dpaiop,
	uint8_t *img,
	size_t img_sz,
	phys_addr_t *aiop_init_s_paddr);


/** @} */ /* end of aiopapp_init group */
#endif /* _SYS_EILD_H_ */
