/*
 * Copyright 2013-2020 NXP
 */


/**************************************************************************//*
 @File          aiop_drv.c

 @Description   AIOP driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "inc/fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_types.h"
#include "fsl_dbg.h"
#include "fsl_errors.h"
#include "fsl_io.h"
#include "fsl_malloc.h"
#include "aiop_elf_loader.h"
#include "drivers/fsl_mc.h"
#include "platform.h"
#include "ls2085_mc/fsl_platform.h" /* TODO */
#include "fsl_dpmng_mc.h"
#include "fsl_ctlu.h"
#include "fsl_dpci_mc.h"
#include "kernel/device.h" /* TODO */

#include "fsl_eiop_rtc.h" /* TODO */
#include "fsl_dptbl.h"
#include "fsl_dpparser.h"
#include "fsl_dpkg.h"
#include "fsl_resman.h"
#include "soc_db/fsl_soc.h"

#include "aiop.h"
#include "aiop_common.h"
#include "drivers/fsl_aiop.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_AIOP

int aiop_drv_init(void);
void aiop_drv_free(void);

/**************************************************************************//**
 AIOP internal routines
 *//***************************************************************************/

static int win_cfg_check(struct aiop_tile *aiop_tile, const struct aiop_atu_win_cfg *win_cfg)
{
	uint32_t addr_mask;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	if (win_cfg->num == 0) {
		if (win_cfg->base_addr) {
			pr_err("Window #0 is default and doesn't have a "
			"base address");
			return -EINVAL;
		}
		if ((win_cfg->instr_access) || (win_cfg->data_access)) {
			pr_err("'Instruction access' or 'Data access' cannot "
			"be set for default window #0");
			return -EINVAL;
		}
	} else {
		if (win_cfg->num >= AIOP_ATU_NUM_OF_WINDOWS) {
			pr_err("Window number exceeds maximal value of %d",
			       AIOP_ATU_NUM_OF_WINDOWS - 1);
			return -EINVAL;
		}

		/* Check this window number isn't already in use */
		if (aiop_atu_win_in_use(aiop_tile,
		                        win_cfg->num)) {
			pr_err("Window %d already in use", win_cfg->num);
			return -EINVAL;
		}

		if (!is_power_of_2(win_cfg->size)) {
			pr_err("Window size must be a power-of-2");
			return -EINVAL;
		}
		if ((win_cfg->size < (64 * KILOBYTE))
			|| (win_cfg->size > (2 * GIGABYTE))) {
			pr_err("Window size must be between 64KB upto 2GB");
			return -EINVAL;
		}

		/* Checking that the provided addresses are aligned to the
		 * window size */
		addr_mask = (uint32_t)(win_cfg->size - 1);
		if (win_cfg->base_addr & addr_mask) {
			pr_err("Window base address must be aligned to window "
			"size");
			return -EINVAL;
		}
		if (win_cfg->trans_addr & addr_mask) {
			pr_err("Window translation address must be aligned to "
			"window size");
			return -EINVAL;
		}

		if ((win_cfg->instr_access) && (win_cfg->data_access)) {
			pr_err("'Instruction access' and 'Data access' cannot "
			"both be set");
			return -EINVAL;
		}

	}
	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;
}

static int init_tables(struct aiop_tile *aiop_tile, struct ctlu *ctlu)
{
	struct dptbl_mng_cfg dptbl_mng_cfg;
	struct dptbl_mng *dptbl_mng;
	uint32_t sys_ddr_tables;
	int err;
	enum ctlu_type type = ctlu_get_type(ctlu);
	uint32_t num_peb_entries;
	uint32_t num_dpddr_entries;
	uint32_t num_sys_ddr_entries;
	struct mem_paddrs *mem_paddrs;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 
	if (type == CTLU_AIOP)
	{
		num_peb_entries = aiop_tile->cfg.ctlu_peb_num_entries;
		num_dpddr_entries = aiop_tile->cfg.ctlu_dp_ddr_num_entries;
		num_sys_ddr_entries =aiop_tile->cfg.ctlu_sys_ddr_num_entries;
		mem_paddrs = &aiop_tile->ctlu_paddrs;
	}
	else
	{
		num_peb_entries = aiop_tile->cfg.mflu_peb_num_entries;
		num_dpddr_entries = aiop_tile->cfg.mflu_dp_ddr_num_entries;
		num_sys_ddr_entries =aiop_tile->cfg.mflu_sys_ddr_num_entries;
		mem_paddrs = &aiop_tile->mflu_paddrs;
	}

	memset(&dptbl_mng_cfg, 0, sizeof(dptbl_mng_cfg));

	dptbl_mng_cfg.ctlu = ctlu;

	/* initialize external table 1*/
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[0].mem_type = DPTBL_PEB;
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[0].num_entries = num_peb_entries;

	err = fsl_get_mem(
			 dptbl_get_tbl_size_by_entries(
					dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[0].num_entries),
			MEM_PART_PEB, 64, &mem_paddrs->peb);
	if (err)
		return err;
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[0].tbl_paddr = mem_paddrs->peb;

	/*initialize external table 2 */
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[1].mem_type = DPTBL_EXT_MEMORY_1; /* DPDDR */
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[1].num_entries = num_dpddr_entries;

	err = fsl_get_mem(
			 dptbl_get_tbl_size_by_entries(
					dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[1].num_entries),
			MEM_PART_DP_DDR, 64, &mem_paddrs->dp_ddr);
	if (err)
		return err;

	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[1].tbl_paddr = mem_paddrs->dp_ddr;

	/* initialize  SYS DDR table */
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[2].mem_type = DPTBL_EXT_MEMORY_2;
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[2].num_entries =
			num_sys_ddr_entries;

	/* include in the SYS DDR allocated section both the size of the SYS
	 * DDR tables and the table descriptors table */
	sys_ddr_tables = dptbl_get_tbl_size_by_entries(
			dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[2].num_entries);
	ASSERT_COND((sys_ddr_tables%64) == 0);

	err = fsl_get_mem(
			(sys_ddr_tables + dptbl_get_int_list_size(ctlu)),
			MEM_PART_SYSTEM_DDR1, 64, &mem_paddrs->sys_ddr);
	if (err)
		return err;

	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.mem_cfg[2].tbl_paddr = mem_paddrs->sys_ddr;

	/* define the base for the table descriptors table */
	dptbl_mng_cfg.u.aiop_tbl_mng_cfg.int_list_paddr = mem_paddrs->sys_ddr
			+ sys_ddr_tables;

	dptbl_mng = dptbl_mng_init(&dptbl_mng_cfg);
	if (dptbl_mng == NULL) {
		pr_err("dptbl_mng_init() failed.\n");
		return -ENODEV;
	}

	sys_add_handle(dptbl_mng, FSL_MOD_TABLES_MNG, 2, /*iop_id*/
		aiop_tile->id, /* CTLU type */type);

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;
}

static int cfg_aiop_tile(struct aiop_tile *aiop_tile)
{
	struct aiop_tile_cfg *cfg = &aiop_tile->cfg;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	if ((cfg->tasks_per_core > AIOP_TILE_NTASKS_MAX)
	    || (!is_power_of_2(cfg->tasks_per_core))) {
		pr_err("Number of tasks must be a power of 2 that doesn't "
			"exceed %d", AIOP_TILE_NTASKS_MAX);
		return -EINVAL;
	}

	if ((uint32_t)(cfg->tasks_per_core * 16)
	    <= cfg->defcfg.ws_cfg.high_prio_threshold)
	{
		pr_err("High priority task threshold equals or exceeds the "
			"total number of available tasks, so no low priority "
			"work will ever get scheduled");
		return -EINVAL;
	}

	aiop_tile_init(aiop_tile, cfg);

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;
}

static int cfg_aiop_ws(struct aiop_tile *aiop_tile,
		       const struct aiop_ws_cfg *cfg)
{
	pr_debug("enter\n"); 

	if (!is_power_of_2(cfg->high_prio_threshold)) {
		pr_err("High priority task reservation threshold must be "
		"power-of-2");
		return -EINVAL;
	}

	if (cfg->high_prio_threshold > 128) {
		pr_err("High priority task reservation threshold must not "
		"exceed 128 tasks");
		return -EINVAL;
	}

	aiop_ws_init(aiop_tile, cfg);

	pr_debug("exit\n"); 

	return 0;
}

static int cfg_aiop_fdma(struct aiop_tile *aiop_tile,
        	 	 const struct aiop_fdma_cfg *cfg)
{
	int err;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	if (cfg->sru_size & (AIOP_FDMA_SRU_ALIGN - 1)) {
		pr_err("SRU size must be aligned to 64 bytes");
		return -EINVAL;
	}

	/* if this is the first time, or if required memory is
	* different than existing - allocate memory */
	if (!aiop_tile->sru_base) {
		/* release previous memory */
		/* TODO - how to free? */
		/*if (aiop_tile->sru_base)
		 fsl_xfree(aiop_tile->sru_base); */
		err = fsl_get_mem(cfg->sru_size,
				MEM_PART_DP_DDR,
				AIOP_FDMA_SRU_ALIGN,
				&aiop_tile->sru_base);
		if (err)
			return -ENOMEM;
	}

	aiop_fdma_init(aiop_tile, cfg);

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 
	return 0;
}

static int cfg_aiop_tman(struct aiop_tile *aiop_tile,
			 struct aiop_tile_regs *regs,
                   	 const struct aiop_tman_cfg *cfg)
{
	int err;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	/* if no memory already exists */
	if (!aiop_tile->tman_ctrl_mem) {
		err = fsl_get_mem((uint32_t)TMAN_MEM_SIZE,
				MEM_PART_DP_DDR,
				AIOP_TMAN_CTRL_ALIGN,
				&aiop_tile->tman_ctrl_mem);
		if (err)
			return -ENOMEM;
	}

	aiop_tman_init(aiop_tile, cfg);

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;
}

static int cfg_tile(struct aiop_tile *aiop_tile)
{
	struct aiop_tile_regs *regs = aiop_tile->regs;
	struct aiop_tile_cfg *cfg = &aiop_tile->cfg;
	int err, i;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	/* General tile initializations */
	err = cfg_aiop_tile(aiop_tile);
	if (err)
		return err;

	/* Initialize tile blocks */
	aiop_cdma_init(aiop_tile, &(cfg->cdma_cfg));
	aiop_osm_init(aiop_tile, &(cfg->defcfg.osm_cfg));
	aiop_ste_init(aiop_tile, &(cfg->ste_cfg));

	err = cfg_aiop_ws(aiop_tile, &(cfg->defcfg.ws_cfg));
	if (err)
		return err;

	err = cfg_aiop_fdma(aiop_tile, &(cfg->fdma_cfg));
	if (err)
		return err;

	err = cfg_aiop_tman(aiop_tile, regs, &(cfg->tman_cfg));
	if (err)
		return err;

	for (i = 0; i < cfg->num_atu_win; i++)
	{
		if(cfg->atu_cfg[i].size)
		{
			pr_debug("ATU Window #%d (0x%08x) paddr: 0x%08x%08x --> vaddr: 0x%08x%08x\n",
				        cfg->atu_cfg[i].num,
				        (uint32_t)cfg->atu_cfg[i].size,
				        UINT32_HI(cfg->atu_cfg[i].trans_addr),
				        UINT32_LO(cfg->atu_cfg[i].trans_addr),
				        UINT32_HI(cfg->atu_cfg[i].base_addr),
				        UINT32_LO(cfg->atu_cfg[i].base_addr));
			err = win_cfg_check(aiop_tile, &cfg->atu_cfg[i]);
			if (err)
				return err;
			err = aiop_atu_win_enable(aiop_tile, &cfg->atu_cfg[i]);
			if (err) 
				return err;
		}
	}

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 
	
	return 0;
}

static int allocate_aiop_rsrcs(struct aiop_tile *aiop_tile,
	struct aiop_app_init_info *aiop_app_info)
{
	int err;
	uint64_t size;
	struct resman_res_req req;
	char str[16];
	int *tmp_array;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	/* allocate memory from all partitions for AIOP SW */
	size = ioread64be(&aiop_app_info->peb_size);
	if (size) {
		err = fsl_get_mem(size, MEM_PART_PEB, size,
				&aiop_tile->mem_paddrs.peb);
		if (err)
			return err;
	}
	size = ioread64be(&aiop_app_info->dp_ddr_size);
	if (size) {
		err = fsl_get_mem(size, MEM_PART_DP_DDR, size,
				&aiop_tile->mem_paddrs.dp_ddr);
		if (err)
			return err;
	}
	size = ioread64be(&aiop_app_info->sys_ddr1_size);
	if (size) {
		err = fsl_get_mem(size, MEM_PART_SYSTEM_DDR1, size,
				&aiop_tile->mem_paddrs.sys_ddr);

		if (err)
			return err;
	}
	
	
	/* allocate SP's for AIOP use */
	aiop_tile->spid_count = ioread32be(&aiop_app_info->spid_count);
	if (aiop_tile->spid_count)
	{
		memset(&req, 0, sizeof(struct resman_res_req));
		snprintf(str, sizeof(str), "sp.aiop%d", aiop_tile->id);
		strcpy(req.type, str);
		req.num = aiop_tile->spid_count;
		req.options = DPRC_RES_REQ_OPT_ALIGNED;
		tmp_array = (int *)fsl_malloc(req.num *sizeof(int));
		if (tmp_array == NULL)
		{
			pr_err("No Memory\n");
			return -ENOMEM;
		}

		err = resman_bind(aiop_tile->resman_device, &req, tmp_array);
		if (err)
		{
			fsl_free(tmp_array);
			return err;
		}
		aiop_tile->base_spid = *tmp_array;
		fsl_free(tmp_array);
	}


	pr_debug("ID[%d]: exit\n", aiop_tile->id); 
	
	return 0;
}

/**************************************************************************//**
 AIOP API routines
 *//***************************************************************************/
static int build_aiop_cfg(struct aiop_tile *aiop_tile,
		struct aiop_app_init_info *aiop_app_info,
		struct resman_container_attributes *attributes,
		uint32_t options)
{
	int err, i;
	struct mc_desc mc_desc;
	struct soc_mc_portal_desc soc_mc_portal_desc;
	struct aiop_tile_cfg *cfg = &aiop_tile->cfg;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	/* get mc descriptor */
	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, SOC_DB_NO_MATCH_FIELDS, &mc_desc, NULL);
	ASSERT_COND (!err);

	/* get first portal descriptor (this is the portals base) */
	soc_mc_portal_desc.portal_id = 0;
	memset(&soc_mc_portal_desc, SOC_DB_SOC_MC_PORTAL_DESC_ID, sizeof(soc_mc_portal_desc));
	err = sys_get_desc(SOC_MODULE_SOC_MC_PORTAL, SOC_DB_NO_MATCH_FIELDS, &soc_mc_portal_desc, NULL);
	ASSERT_COND (!err);

	/* Set AIOP tile parameters */
	cfg->tasks_per_core = (uint8_t)ioread32be(&aiop_app_info->tasks_per_core);

	cfg->cdma_cfg.amq.bmt = attributes->bmt;
	cfg->cdma_cfg.amq.pl = attributes->pl;
	cfg->cdma_cfg.amq.va = 	(options & AIOP_LOAD_OPTION_SMMU) ? 
		1 : attributes->va;
	cfg->cdma_cfg.amq.icid = attributes->icid;
	cfg->cdma_cfg.bdi = attributes->bdi;
	cfg->cdma_cfg.context_read_attr = AIOP_CACHE_ATTR_CACHE;
	cfg->cdma_cfg.context_write_attr = AIOP_CACHE_ATTR_CACHE;

	cfg->fdma_cfg.sru_size = ioread32be(&aiop_app_info->sru_size);
	cfg->fdma_cfg.amq.bmt = attributes->bmt;
	cfg->fdma_cfg.amq.pl = attributes->pl;
	cfg->fdma_cfg.amq.va = attributes->va;
	cfg->fdma_cfg.amq.icid = attributes->icid;
	cfg->fdma_cfg.data_read_attr = AIOP_CACHE_ATTR_CACHE;
	cfg->fdma_cfg.data_write_attr = AIOP_CACHE_ATTR_CACHE;
	cfg->fdma_cfg.sru_read_attr = AIOP_CACHE_ATTR_NO_CACHE;
	cfg->fdma_cfg.sru_write_attr = AIOP_CACHE_ATTR_NO_CACHE;

	cfg->ste_cfg.amq.bmt = attributes->bmt;
	cfg->ste_cfg.amq.pl = attributes->pl;
	cfg->ste_cfg.amq.va = (options & AIOP_LOAD_OPTION_SMMU) ? 
		1 : attributes->va;
	cfg->ste_cfg.amq.icid = attributes->icid;

	cfg->tman_cfg.amq.bmt = attributes->bmt;
	cfg->tman_cfg.amq.pl = attributes->pl;
	cfg->tman_cfg.amq.va = attributes->va;
	cfg->tman_cfg.amq.icid = attributes->icid;
	cfg->tman_cfg.bdi = 0; /* TODO: Why? why not attributes->bdi; */

	cfg->defcfg.osm_cfg.err_mng.relinquish_concurrent = AIOP_ERR_DETECT;

	cfg->tman_cfg.freq = ioread32be(&aiop_app_info->tman_freq);
	/* TODO: insert correct IPG clock frequency */

	cfg->num_atu_win = 5;

	for( i = 0; i < cfg->num_atu_win; i++)
	{
		cfg->atu_cfg[i].num = (uint8_t)( i + 1);
		cfg->atu_cfg[i].amq.bmt = attributes->bmt;
		cfg->atu_cfg[i].amq.pl = attributes->pl;
		cfg->atu_cfg[i].amq.va = attributes->va;
		cfg->atu_cfg[i].amq.icid = attributes->icid;
		cfg->atu_cfg[i].data_access = 0;
		cfg->atu_cfg[i].instr_access = 0;
	}

	/* Open ATU window to MC-Portals: */
	cfg->atu_cfg[MC_PORTALS_ATU].base_addr = AIOP_MC_PORTALS_VADDR;
	cfg->atu_cfg[MC_PORTALS_ATU].trans_addr = soc_mc_portal_desc.paddr;
	cfg->atu_cfg[MC_PORTALS_ATU].size = 64*MEGABYTE; /* TODO mc_desc.portals_size? */
	cfg->atu_cfg[MC_PORTALS_ATU].amq.bmt = 0;
	cfg->atu_cfg[MC_PORTALS_ATU].amq.pl = 0;


	/* Open ATU window to CCSR:  */
	cfg->atu_cfg[CCSR_ATU].base_addr = AIOP_CCSR_VADDR;
	cfg->atu_cfg[CCSR_ATU].trans_addr = mc_desc.ccsr_paddr;
	cfg->atu_cfg[CCSR_ATU].size = mc_desc.ccsr_size;
	cfg->atu_cfg[CCSR_ATU].amq.bmt = 0;
	cfg->atu_cfg[CCSR_ATU].amq.pl = 0;


	/* Open ATU window to DP-DDR:  */
	cfg->atu_cfg[DPDDR_ATU].base_addr = PTR_TO_UINT(aiop_tile->dp_ddr_vaddr);
	cfg->atu_cfg[DPDDR_ATU].trans_addr = aiop_tile->mem_paddrs.dp_ddr;
	cfg->atu_cfg[DPDDR_ATU].size = MIN(aiop_tile->dp_ddr_atu_size, aiop_app_info->dp_ddr_size);

	/* Open ATU window to PEB:  */
	cfg->atu_cfg[PEB_ATU].base_addr = PTR_TO_UINT(aiop_tile->peb_vaddr);
	cfg->atu_cfg[PEB_ATU].trans_addr = aiop_tile->mem_paddrs.peb;
	cfg->atu_cfg[PEB_ATU].size = MIN(aiop_tile->peb_atu_size, aiop_app_info->peb_size);

	/* Open ATU window to Sys-DDR */
	cfg->atu_cfg[SYS_DDR_ATU].base_addr = AIOP_SYS_DDR_VADDR;
	cfg->atu_cfg[SYS_DDR_ATU].trans_addr = aiop_tile->mem_paddrs.sys_ddr;
	cfg->atu_cfg[SYS_DDR_ATU].size = MIN(AIOP_SYS_DDR_ATU_SIZE, aiop_app_info->sys_ddr1_size);

	cfg->ctlu_peb_num_entries = aiop_app_info->ctlu_peb_num_entries;
	cfg->ctlu_dp_ddr_num_entries = aiop_app_info->ctlu_dp_ddr_num_entries;
	cfg->ctlu_sys_ddr_num_entries = aiop_app_info->ctlu_sys_ddr_num_entries;
	cfg->mflu_peb_num_entries = aiop_app_info->mflu_peb_num_entries;
	cfg->mflu_dp_ddr_num_entries = aiop_app_info->mflu_dp_ddr_num_entries;
	cfg->mflu_sys_ddr_num_entries = aiop_app_info->mflu_sys_ddr_num_entries;

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;
}



static int get_ctlu_str(int iop_id, enum ctlu_type type, char *str)
{
	switch (type) {
	case CTLU_EIOP_EGRESS:
		sprintf(str,"wr%d.ctlue", iop_id);
		break;
	case CTLU_EIOP_INGRESS:
		sprintf(str,"wr%d.ctlui", iop_id);
		break;
	case CTLU_AIOP:
		sprintf(str,"aiop%d.ctlu", iop_id);
		break;
	case CTLU_AIOP_MFLU:
		sprintf(str,"aiop%d.mflu", iop_id);
		break;
	default:
		return -EINVAL;
	}
	return 0;
}

static int init_parser(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	struct dpparser_cfg dpparser_cfg;
	struct dpparser *dpparser;
	struct resman_res_req req;
	char str[16];
	int err;

	pr_debug("enter\n"); 

	/* Create resman parser profile pool */
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = (uint32_t)ctlu_desc->num_dpparser_profiles;
	get_ctlu_str(ctlu_desc->iop_id, ctlu_desc->type, str);
	snprintf(req.type, sizeof(req.type), "prp.%s", str);
	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(
	        sys_get_unique_handle(FSL_MOD_RESMAN), &req))
	    != 0)
		return err;

	memset(&dpparser_cfg, 0, sizeof(dpparser_cfg));

	dpparser_cfg.ctlu = ctlu;
	dpparser_cfg.cycle_limit = 256;
	dpparser_cfg.options = 0;
	dpparser_cfg.num_profiles = ctlu_desc->num_dpparser_profiles;
	dpparser_cfg.options = 0;
	dpparser = dpparser_init(&dpparser_cfg);
	if (dpparser == NULL)
		return -ENODEV;

	sys_add_handle(dpparser, FSL_MOD_PARSER, 2,
	/*iop_id*/ctlu_desc->iop_id,
	               /* CTLU type */ctlu_desc->type);

	pr_debug("exit\n"); 
	
	return 0;
}

static int init_kg(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	struct dpkg_cfg dpkg_cfg;
	struct dpkg *dpkg;
	struct resman_res_req req;
	char str[16];
	int err;

	pr_debug("enter\n"); 

	/* Create resman Keygen profiles pool */
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = (uint32_t)ctlu_desc->num_dpkg_profiles;
	get_ctlu_str(ctlu_desc->iop_id, ctlu_desc->type, str);
	snprintf(req.type, sizeof(req.type), "kp.%s", str);
	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(
	        sys_get_unique_handle(FSL_MOD_RESMAN), &req))
	    != 0)
		return err;

	memset(&dpkg_cfg, 0, sizeof(dpkg_cfg));

	dpkg_cfg.ctlu = ctlu;
	dpkg_cfg.num_profiles = ctlu_desc->num_dpkg_profiles;
	dpkg = dpkg_init(&dpkg_cfg);
	if (dpkg == NULL) 
		return -ENODEV;
	
	sys_add_handle(dpkg, FSL_MOD_KG, 2, /*iop_id*/ctlu_desc->iop_id, 
		/* CTLU type */ ctlu_get_type(ctlu));

	pr_debug("exit\n"); 

	return 0;
}

static void free_ctlu(struct aiop_tile *aiop_tile, enum ctlu_type type)
{
	void *handle;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	if ((handle = sys_get_handle(FSL_MOD_PARSER, /*num of ids*/2,
				/* iop_id */aiop_tile->id,
				/*ctlu type */type))
			!= NULL) {
			dpparser_done((struct dpparser *)handle);
			sys_remove_handle(FSL_MOD_PARSER, 2, /* iop_id */
						aiop_tile->id, /*ctlu type */
						type);
		}

		if ((handle = sys_get_handle(FSL_MOD_KG, 2,/* iop_id */
					aiop_tile->id, /*ctlu type */
					type))
			!= NULL) {
			dpkg_done((struct dpkg *)handle);
			sys_remove_handle(FSL_MOD_KG, 2,
				/* iop_id */aiop_tile->id, /*ctlu type */
				type);
		}

		if ((handle = sys_get_handle(FSL_MOD_TABLES_MNG, 2,
					/* iop_id */aiop_tile->id,
					/*ctlu type */type))
			!= NULL) {
			dptbl_mng_done((struct dptbl_mng *)handle);
			sys_remove_handle(FSL_MOD_TABLES_MNG, 2,/* iop_id */
				aiop_tile->id, /*ctlu type */
				type);

		}

		if ((handle = sys_get_handle(FSL_MOD_CTLU, 2, /* iop_id */
					aiop_tile->id, /*ctlu type */
					type))
			!= NULL) {
			ctlu_done((struct ctlu *)handle);
			sys_remove_handle(FSL_MOD_CTLU, 2,
				/* iop_id */aiop_tile->id, /*ctlu type */
				type);

		}

		pr_debug("ID[%d]: exit\n", aiop_tile->id); 

		return;

	}

static int cfg_ctlu(struct aiop_tile *aiop_tile,
                     enum ctlu_type type)
{
	int err = 0;
	struct ctlu_desc ctlu_desc;
	struct ctlu_cfg ctlu_cfg;
	struct ctlu *ctlu;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	/* get CTLU descriptor */
	memset(&ctlu_desc, 0, sizeof(ctlu_desc));
	ctlu_desc.iop_id = aiop_tile->id;
	ctlu_desc.type = type;
	err = sys_get_desc(
		SOC_MODULE_CTLU,
		SOC_DB_CTLU_DESC_TYPE | SOC_DB_CTLU_DESC_IOP_ID,
		&ctlu_desc, NULL);
	ASSERT_COND(err == 0);

	/*******************************************/
	/* initialize CTLU general internal module */
	/*******************************************/
	memset(&ctlu_cfg, 0, sizeof(ctlu_cfg));
	ctlu = ctlu_init(&ctlu_desc, &ctlu_cfg);
	if (!ctlu) 			
		return err;


	/***********************/
	/* Parser init         */
	/***********************/
	if (type == CTLU_AIOP) {
		err |= init_parser(ctlu, &ctlu_desc);
		if (err) {
			free_ctlu(aiop_tile, type);
			return -ENODEV;
		}
	}

	/**********************/
	/* Key generator init */
	/**********************/
	err = init_kg(ctlu, &ctlu_desc);
	if (err)
		return err;


	/***********************/
	/* Tables manager init */
	/***********************/
	err = init_tables(aiop_tile, ctlu);
	if (err) {
		free_ctlu(aiop_tile, type);
		return -ENODEV;
	}

	sys_add_handle(ctlu, FSL_MOD_CTLU, 2, /*iop_id*/ctlu_desc.iop_id, /* CTLU type */
	               type);

	ctlu_enable(ctlu);

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;
}

static int free_dpci(struct aiop_tile *aiop_tile)
{
	int err = 0;
	struct dpci_attr dpci_attr;
	struct resman *resman = \
		(struct resman *)sys_get_unique_handle(FSL_MOD_RESMAN);
	
	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	if (resman == NULL)
		return -ENODEV;

	if (aiop_tile->dpci == NULL)
		return -EINVAL;

	memset(&dpci_attr, 0, sizeof(struct dpci_attr));
	err = dpci_get_attributes(aiop_tile->dpci, &dpci_attr);
	if (err)
		return err;

	/*  TODO Destroy resman device */
/*
	err = resman_close_dev(resman,
	       device, TODO need to keep resman device ??
	       "dpci",
	       NO_PORTAL_ID,
	       1);
*/

	err = dpci_destroy(aiop_tile->dpci);
	if (err)
		return err;

	err = sys_remove_handle(FSL_MOD_CMDIF_CL_REGS, 1, 0);
	ASSERT_COND(!err);
	err = sys_remove_handle(FSL_MOD_DPCI, 1, dpci_attr.id);
	ASSERT_COND(!err);

	aiop_tile->dpci = NULL;

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return err;
}

static int get_resman_device(void **device)
{
	struct resman *resman = NULL;

	resman = (struct resman *)sys_get_unique_handle(FSL_MOD_RESMAN);
	if (resman == NULL)
		return -ENODEV;

	*device = resman_open_dev(resman,
                            "dpci",
                            RESMAN_NO_DEVICE_ID,
                            NO_PORTAL_ID, 1);
	
	if (*device == NULL)
	{
		pr_err("resman_open_dev failed for DPCI");
		return -ENODEV;
	}
	
	return 0;
}


static int set_get(struct aiop_tile *aiop_tile, int *id )
{
	struct dpci_rx_queue_cfg queue_cfg;
	struct dpci_attr dpci_attr;
	int err;
	
	
	memset(&dpci_attr, 0, sizeof(struct dpci_attr));
	memset(&queue_cfg, 0, sizeof(struct dpci_rx_queue_cfg));

	queue_cfg.dest_cfg.dest_type = DPCI_DEST_NONE;
	queue_cfg.dest_cfg.priority = 1;
	queue_cfg.user_ctx = 0;
	err = dpci_set_rx_queue(aiop_tile->dpci, 0, &queue_cfg);
	if (err)
		return err;
	queue_cfg.dest_cfg.priority = 0;
	queue_cfg.user_ctx = 0;
	err = dpci_set_rx_queue(aiop_tile->dpci, 1, &queue_cfg);
	if (err)
		return err;
	
	err = dpci_set_amq(aiop_tile->dpci, &aiop_tile->dpmng_amq);
	if (err)
		return err;

	err = dpci_get_attributes(aiop_tile->dpci, &dpci_attr);
	if (err)
		return err;
	
	*id = dpci_attr.id;

	return 0;
}

#if 0
static int init_dpci(struct aiop_tile *aiop_tile, int *dpci_id)
{
	struct dpci_cfg dpci_cfg;
	int err = 0;
	struct dpci_mc_internal_info info;
	void *device = NULL;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	memset(&dpci_cfg, 0, sizeof(struct dpci_cfg));

	err = get_resman_device(&device);
	if (err)
		return err;
	
		
	aiop_tile->dpci = dpci_allocate();
	ASSERT_COND(aiop_tile->dpci);

	info.id = device_get_id(device);
	info.device = device;
	info.app_type =	 DPCI_APP_T_GPP;
	err = dpci_set_mc_info(aiop_tile->dpci, &info);
	if (err)
		return err;

	dpci_cfg.num_of_priorities = 2;
	err = dpci_init(aiop_tile->dpci, &dpci_cfg);
	if (err)
		return err;

	err = set_get(aiop_tile, dpci_id);
	if (err)
		return err;

	err = sys_add_handle(aiop_tile->dpci, FSL_MOD_CMDIF_CL_REGS, 1, 0);
	ASSERT_COND(!err);
	err = sys_add_handle(aiop_tile->dpci, FSL_MOD_DPCI, 1, dpci_id);
	ASSERT_COND(!err);

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return err;
}
#else
/* Added by Ira for testing */
static int init_dpci(struct aiop_tile *aiop_tile, int *dpci_id)
{
	struct dpci_cfg dpci_cfg;
	struct dpci_rx_queue_cfg queue_cfg;
	int err = 0;
	struct dpci_mc_internal_info info;
	struct resman *resman = NULL;
	void *device = NULL;
	struct dpci_attr dpci_attr;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	memset(&dpci_attr, 0, sizeof(struct dpci_attr));
	memset(&dpci_cfg, 0, sizeof(struct dpci_cfg));
	memset(&queue_cfg, 0, sizeof(struct dpci_rx_queue_cfg));

	resman = (struct resman *)sys_get_unique_handle(FSL_MOD_RESMAN);
	if (resman == NULL)
		return -ENODEV;

	device = resman_open_dev(resman,
	                            "dpci",
	                            RESMAN_NO_DEVICE_ID,
	                            NO_PORTAL_ID, 1);
	if (device == NULL)
		return -ENODEV;

	aiop_tile->dpci = dpci_allocate();
	ASSERT_COND(aiop_tile->dpci);

	info.id = device_get_id(device);
	info.device = device;
	info.app_type =	 DPCI_APP_T_GPP;
	err = dpci_set_mc_info(aiop_tile->dpci, &info);
	if (err)
		return err;

	dpci_cfg.num_of_priorities = 2;
	err = dpci_init(aiop_tile->dpci, &dpci_cfg);
	if (err)
		return err;

	queue_cfg.dest_cfg.dest_type = DPCI_DEST_NONE;
	queue_cfg.dest_cfg.priority = 1;
	queue_cfg.user_ctx = 0;
	err = dpci_set_rx_queue(aiop_tile->dpci, 0, &queue_cfg);
	if (err)
		return err;
	queue_cfg.dest_cfg.priority = 0;
	queue_cfg.user_ctx = 0;
	err = dpci_set_rx_queue(aiop_tile->dpci, 1, &queue_cfg);
	if (err)
		return err;

	err = dpci_set_amq(aiop_tile->dpci, &aiop_tile->dpmng_amq);
	if (err)
		return err;

	err = dpci_get_attributes(aiop_tile->dpci, &dpci_attr);
	if (err)
		return err;

	err = sys_add_handle(aiop_tile->dpci, FSL_MOD_CMDIF_CL_REGS, 1, 0);
	ASSERT_COND(!err);
	err = sys_add_handle(aiop_tile->dpci, FSL_MOD_DPCI, 1, dpci_attr.id);
	ASSERT_COND(!err);

	*dpci_id = dpci_attr.id;

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return err;
}
#endif

static int get_container_attributes(int container_id,
	struct resman_container_attributes *attributes)
{
	void *resman, *dprc;
	int err = 0;

	pr_debug("enter\n"); 

	resman = (struct resman *)sys_get_unique_handle(FSL_MOD_RESMAN);
	if (resman == NULL)
		return -ENODEV;

	dprc = resman_get_container(resman, container_id);
	if (dprc == NULL)
		return -ENODEV;

	memset(attributes, 0, sizeof(struct resman_container_attributes));
	err = resman_get_attributes(dprc, attributes);
	if (err)
		return err;

	pr_debug("exit\n"); 

	return 0;
}

static void free_tile_runtime_resources(struct aiop_tile *aiop_tile)
{
	free_ctlu(aiop_tile, CTLU_AIOP);
	free_ctlu(aiop_tile, CTLU_AIOP_MFLU);

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	aiop_atu_win_disable(aiop_tile, AIOP_WS_DISABLE);
	/* TODO -error check 
	if (err)
		return err;*/
/*
	fsl_put_mem(aiop_tile->mem_paddrs.dp_ddr);
	fsl_put_mem(aiop_tile->mem_paddrs.sys_ddr);
	fsl_put_mem(aiop_tile->mem_paddrs.peb);
	fsl_put_mem(aiop_tile->mflu_paddrs.dp_ddr);
	fsl_put_mem(aiop_tile->mflu_paddrs.sys_ddr);
	fsl_put_mem(aiop_tile->mflu_paddrs.peb);
	fsl_put_mem(aiop_tile->cltu_paddrs.dp_ddr);
	fsl_put_mem(aiop_tile->cltu_paddrs.sys_ddr);
	fsl_put_mem(aiop_tile->cltu_paddrs.peb);
*/
/* Free:
	(aiop_tile->sru_base);
	(aiop_tile->tman_ctrl_mem); */
	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

}

static void restore_sp_table(struct aiop_tile *aiop_tile)
{
	uint32_t entry_id = 0;
	void *psram_vaddr;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	/* Define SoC window for accessing IRAM */
	dpmng_mc_lock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
	psram_vaddr = dpmng_mc_set_soc_window(
	        aiop_tile->psram_paddr, &aiop_tile->dpmng_amq);

	while (entry_id < AIOP_PSRAM_NUM_OF_ENTRIES) {
		if (aiop_tile->sp_table[entry_id].init)
			aiop_write_sp(psram_vaddr, entry_id,
			              &aiop_tile->sp_table[entry_id].cfg);
		entry_id++;
	}

	/* Restore previous SoC window */
	dpmng_mc_unlock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
	
	pr_debug("ID[%d]: exit\n", aiop_tile->id); 
}

static int runtime_init(struct aiop_tile *aiop_tile)
{
	int err;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	/* re-initialize all registers as before */
	err = cfg_tile(aiop_tile);
	if (err)
		return err;
	restore_ep_table(aiop_tile);
	restore_sp_table(aiop_tile);

	/* initialize CTLU and MFLU */
	err = cfg_ctlu(aiop_tile, CTLU_AIOP);
	if (err)
		return err;

	err = cfg_ctlu(aiop_tile, CTLU_AIOP_MFLU);
	if (err)
		return err;

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return err;
}

static int load_image(struct aiop_tile *aiop_tile, uint8_t *img_addr, phys_addr_t *aiop_boot_s_paddr)
{
	struct aiop_tile_cfg *cfg = &aiop_tile->cfg;
	int err;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	dpmng_mc_lock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
	//dpmng_mc_lock_ccsr_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	/* save in aiop memory map */
	/* Define SRAM address translation */
	aiop_tile->mem_map[0].phy_base_addr = aiop_tile->sram_paddr;
	aiop_tile->mem_map[0].mem_size = aiop_tile->sram_size;
	aiop_tile->mem_map[0].vrt_base_addr = (dma_addr_t)aiop_tile->sram_vaddr; //TODO - type

	/* Define IRAM address translation */
	aiop_tile->mem_map[1].phy_base_addr = aiop_tile->iram_paddr;
	aiop_tile->mem_map[1].mem_size = aiop_tile->iram_size;
	aiop_tile->mem_map[1].vrt_base_addr = (dma_addr_t)aiop_tile->iram_vaddr;

	/* Define DPDDR address translation */
	aiop_tile->mem_map[2].phy_base_addr = cfg->atu_cfg[DPDDR_ATU].trans_addr;; //aiop_boot_s->sl_info.dp_ddr_paddr;
	aiop_tile->mem_map[2].mem_size = cfg->atu_cfg[DPDDR_ATU].size;//1 * GIGABYTE; //aiop_boot_s->app_info.dp_ddr_size;
	aiop_tile->mem_map[2].vrt_base_addr = cfg->atu_cfg[DPDDR_ATU].base_addr;//0x40000000; //(dma_addr_t)aiop_boot_s->sl_info.dp_ddr_vaddr;

	err = eld_load_image((void *)aiop_tile, img_addr, (size_t)0,
				aiop_boot_s_paddr);
	if (err) {
		/* restore the SoC window mapping */
		dpmng_mc_unlock_soc_window(
			sys_get_unique_handle(FSL_MOD_DPMNG));
		//dpmng_mc_unlock_ccsr_window(
		//sys_get_unique_handle(FSL_MOD_DPMNG));
		return err;
	}
	/* duplicate IRAM for all clusters */

	/* restore the SoC window mapping */
	dpmng_mc_unlock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));
	//dpmng_mc_unlock_ccsr_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;
}

static uint32_t check_available_clusters(uint8_t num_clusters, uint32_t cores_mask)
{

	uint32_t available_cores_mask = 0;
	int i;

	pr_debug("enter\n");

	for (i = 0; i < num_clusters; i++)
		available_cores_mask |= (0xf << i*4);


	if ((cores_mask & available_cores_mask) != cores_mask)
		pr_warn("aiop_drv_tile_run called for cores of non available clusters (avail clusters: %d).\n Continuing without unavailable cores\n",
		        num_clusters);

	pr_debug("exit\n");
	
	return (cores_mask & available_cores_mask);
}

static int set_aiop_sl_params(struct aiop_tile *aiop_tile,
			      phys_addr_t aiop_boot_s_paddr,
			      struct resman_container_attributes *attributes,
			      int dpci_id)
{
	uint32_t period;
	uint64_t tmp_64;
	struct aiop_init_info *aiop_boot_s_vaddr;
	struct aiop_app_init_info *aiop_app_info;
	struct aiop_sl_init_info *aiop_sl_info;
	struct aiop_tile_cfg *cfg = &aiop_tile->cfg;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	/* Use the SoC window to write to SRAM */
	dpmng_mc_lock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	aiop_boot_s_vaddr = (struct aiop_init_info *)dpmng_mc_set_soc_window(aiop_boot_s_paddr, &aiop_tile->dpmng_amq);

	aiop_app_info = &aiop_boot_s_vaddr->app_info;
	aiop_sl_info = &aiop_boot_s_vaddr->sl_info;

	iowrite32be(2, &aiop_sl_info->uart_port_id);
	iowrite32be((uint32_t)attributes->portal_id, &aiop_sl_info->mc_portal_id);
	iowrite32be((uint32_t)dpci_id, &aiop_sl_info->mc_dpci_id);
	iowrite32be((uint32_t)aiop_tile->base_spid, &aiop_sl_info->base_spid);
	period = eiop_rtc_get_timestamp_period(sys_get_handle(FSL_MOD_EIOP_RTC,
	                            	               1,
	                            	               0) /*TODO eiop id???*/
	                            	               );
	iowrite32be(period, &aiop_sl_info->clock_period);



	/* set virt addresses for all blocks */
	if (ioread64be(&aiop_app_info->dp_ddr_size))
	{
		iowrite64be(cfg->atu_cfg[DPDDR_ATU].trans_addr, &aiop_sl_info->dp_ddr_paddr);
		iowrite64be(cfg->atu_cfg[DPDDR_ATU].base_addr, &aiop_sl_info->dp_ddr_vaddr);
	}

	if (ioread64be(&aiop_app_info->peb_size))
	{
		iowrite64be(cfg->atu_cfg[PEB_ATU].trans_addr, &aiop_sl_info->peb_paddr);
		iowrite64be(cfg->atu_cfg[PEB_ATU].base_addr, &aiop_sl_info->peb_vaddr);
	}
	if (ioread64be(&aiop_app_info->sys_ddr1_size))
	{
		iowrite64be(cfg->atu_cfg[SYS_DDR_ATU].trans_addr, &aiop_sl_info->sys_ddr1_paddr);
		iowrite64be(cfg->atu_cfg[SYS_DDR_ATU].base_addr, &aiop_sl_info->sys_ddr1_vaddr);
	}

	iowrite64be(cfg->atu_cfg[MC_PORTALS_ATU].trans_addr, &aiop_sl_info->mc_portals_paddr);
	iowrite64be(cfg->atu_cfg[MC_PORTALS_ATU].base_addr, &aiop_sl_info->mc_portals_vaddr);

	iowrite64be(cfg->atu_cfg[CCSR_ATU].trans_addr, &aiop_sl_info->ccsr_paddr);
	iowrite64be(cfg->atu_cfg[CCSR_ATU].base_addr, &aiop_sl_info->ccsr_vaddr);

	pr_debug("AIOP Struct fields:\n");
	tmp_64 = ioread64be(&aiop_sl_info->sys_ddr1_paddr);
	pr_debug("SYS DDR phys: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->sys_ddr1_vaddr);
	pr_debug("SYS DDR virt: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->peb_paddr);
	pr_debug("PEB DDR phys: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->peb_vaddr);
	pr_debug("PEB DDR virt:  0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->dp_ddr_paddr);
	pr_debug("DP DDR phys: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->dp_ddr_vaddr);
	pr_debug("DP DDR virt:  0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->ccsr_paddr);
	pr_debug("CCSR phys: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->ccsr_vaddr);
	pr_debug("CCSR virt: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->mc_portals_paddr);
	pr_debug("MC Portals phys: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));
	tmp_64 = ioread64be(&aiop_sl_info->mc_portals_vaddr);
	pr_debug("MC Portals virt: 0x%08x%08x\n",
	        UINT32_HI(tmp_64), UINT32_LO(tmp_64));

	dpmng_mc_unlock_soc_window(sys_get_unique_handle(FSL_MOD_DPMNG));

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;
}

static struct aiop_tile *aiop_drv_tile_init(const struct aiop_tile_desc *desc, void *resman_device)
{
	struct aiop_tile_regs *regs = (struct aiop_tile_regs *)(desc->vaddr);

	pr_debug("ID[%d]: enter\n", desc->tile_id); 

	struct aiop_tile *aiop_tile = (struct aiop_tile *)fsl_malloc(
	        sizeof(struct aiop_tile));
	if (!aiop_tile) {
		pr_err("aiop_drv_tile_init failed.");
		return NULL;
	}

	memset(aiop_tile, 0, sizeof(struct aiop_tile));

	dpmng_get_amq(sys_get_unique_handle(FSL_MOD_DPMNG), &aiop_tile->dpmng_amq);

	aiop_tile->id = desc->tile_id;
	aiop_tile->regs = regs;
	aiop_tile->num_ep = desc->num_ep;
	aiop_tile->num_sp = desc->num_sp;
	aiop_tile->status = AIOP_TILE_STATUS_IDLE;
	aiop_tile->resman_device = resman_device;

	/* PSRAM */
	aiop_tile->psram_paddr = desc->psram_paddr;
	aiop_tile->num_clusters = desc->num_clusters;

	/* SRAM */
	aiop_tile->sram_paddr = desc->sram_paddr;
	aiop_tile->sram_vaddr = desc->sram_vaddr;
	aiop_tile->sram_size = desc->sram_size;

	/* IRAM*/
	aiop_tile->iram_paddr = desc->iram_paddr;
	aiop_tile->iram_vaddr = desc->iram_vaddr;
	aiop_tile->iram_offset = desc->iram_offset;
	aiop_tile->iram_size = desc->iram_size;

	/* SYS DDR */
	aiop_tile->sys_ddr_vaddr = desc->sys_ddr_vaddr;

	/* PEB */
	aiop_tile->peb_vaddr = desc->peb_vaddr;
	aiop_tile->peb_atu_size = desc->peb_atu_size;

	/* DP DDR */
	aiop_tile->dp_ddr_vaddr = desc->dp_ddr_vaddr;
	aiop_tile->dp_ddr_atu_size = desc->dp_ddr_atu_size;

	pr_debug("ID[%d]: exit\n", desc->tile_id); 

	return aiop_tile;
}

static void aiop_drv_tile_free(struct aiop_tile *aiop_tile)
{
	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	free_tile_runtime_resources(aiop_tile);

	fsl_free(aiop_tile);
	
	pr_debug("ID[%d]: exit\n", aiop_tile->id); 
}

int aiop_drv_tile_reset(struct aiop_tile *aiop_tile, int container_id)
{
	uint32_t rbase;
	int err;
	
	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	if (container_id < 0) {
		pr_err("Invalid AIOP container id.\n");
		return -EINVAL;
	}

	rbase = aiop_get_rbase(aiop_tile);

	/*Pauses the TMan�s Wall Clock
	 <<<TODO:  mechanism is TBD, see TMan�s TMDBG[DHD]. >>>*/

	/* Disable the creation of any new tasks into AIOP by disabling ws */
	aiop_ws_enable(aiop_tile, AIOP_WS_DISABLE);

	//TODO: free_ctlu
	//free_tile_runtime_resources(aiop_tile);

	/* Request a graceful stop of the AIOP using PM�s TPMHR[PM_HALT] */
	aiop_tile_halt(aiop_tile);

	/* Poll for completion of the graceful stop using PM�s */
	/* TODO - not working ?
	 //while (!(ioread32(&aiop_tile->regs->pm_regs.tmphaltedr) & AIOP_PM_TILE_HALT)) ;

	 /* Request a reset of the tile by writing to CM-GW�s RSTCR[REQ] */
	aiop_tile_reset(aiop_tile);

	/* Poll RSTRQ[REQ] to check that reset operation has completed*/
//	while (!(ioread32(&aiop_tile->regs->cmgw_regs.rstrq) & AIOP_RSTCR_REQ)) ;

	aiop_tile_disable(aiop_tile);

	err = runtime_init(aiop_tile);
	ASSERT_COND(!err);

	/* restore core_out_of_reset_addr */
	aiop_set_rbase(aiop_tile, rbase);

	aiop_tile_enable(aiop_tile);

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;

}

int aiop_drv_tile_run(struct aiop_tile *aiop_tile, uint32_t cores_mask_in, int mc_internal)
{
	uint32_t val, cores_mask, boot_fail_val;
	int64_t tries;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	cores_mask = check_available_clusters(aiop_tile->num_clusters, cores_mask_in);

	/* Releasing cores for boot */
	aiop_release_cores_boot(aiop_tile, cores_mask);

	if (mc_internal) {
		tries = 0xffffffffffffffff;
		/* Poll core boot completion */
		pr_info("Running AIOP Boot....\n"); 
		aiop_tile->status |= AIOP_TILE_STATUS_BOOTING;

		do {
			val = aiop_get_cores_boot_status(aiop_tile);
			boot_fail_val = aiop_get_core_gpr(aiop_tile, 0);
		} while (!(val & 0x1) 
			&& (boot_fail_val == 0)
			&& --tries);

		if (tries == 0)
		{
			pr_err("AIOP boot failed\n");
			aiop_tile->status |= AIOP_TILE_STATUS_BOOT_ERR;
			return -ETIMEDOUT;
		}
		
	       if(boot_fail_val != 0) {
		      pr_err("AIOP boot failed\n");
		      aiop_tile->status |= AIOP_TILE_STATUS_BOOT_ERR;
		      return -EACCES;
	       }

		/* clear boot completion indication*/
		aiop_clear_cores_boot_complete(aiop_tile, cores_mask);
	}
	
	aiop_tile->status |= AIOP_TILE_STATUS_BOOT_COMPLETED;
	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;
}

int aiop_drv_tile_load_img(struct aiop_tile *aiop_tile,  int container_id, uint8_t *img_addr, uint32_t options)
{
	struct aiop_cmgw_regs *regs = &aiop_tile->regs->cmgw_regs;
	uint32_t core_out_of_reset_addr = *(uint32_t *)(img_addr + 0x18);
	struct aiop_tile_cfg cfg;
	int err, dpci_id;
	struct aiop_init_info *aiop_boot_s = NULL;
	struct aiop_tile_desc aiop_tile_desc;
	struct resman_container_attributes attributes;
	struct dpci_attr dpci_attr;
	phys_addr_t aiop_boot_s_paddr;

	pr_debug("ID[%d]: enter\n", aiop_tile->id); 

	/* TODO: aiop_tile_reset(aiop_tile); - where should this be??? */

	if (container_id < 0) {
		pr_err("Invalid AIOP container id.\n");
		aiop_tile->status |= AIOP_TILE_STATUS_LOAD_ERR;
		return -EINVAL;
	}

	/* Get AIOP parameters Structure from image, also verify elf */
	/* load AIOP app structure from image (This happens first to make sure elf exists) */
	err = eld_get_aiop_struct(img_addr, (void**) &aiop_boot_s);
	if (err) 
	{
		aiop_tile->status |= AIOP_TILE_STATUS_LOAD_ERR;
		return err;
	}
	/* Get container attributes and verify ownership */
	err = get_container_attributes(container_id, &attributes);
	if (err)
	{
		aiop_tile->status |= AIOP_TILE_STATUS_LOAD_ERR;
		return err;
	}

	/* Allocate and save memory dedicated for AIOP */
	err = allocate_aiop_rsrcs(aiop_tile, &aiop_boot_s->app_info);
	if (err)
	{
		aiop_tile->status |= AIOP_TILE_STATUS_LOAD_ERR;
		return err;
	}

	/* create dpci */
	if (aiop_tile->dpci == NULL) {
		err = init_dpci(aiop_tile, &dpci_id);
		if (err) 
		{
			aiop_tile->status |= AIOP_TILE_STATUS_LOAD_ERR;
			return err;
		}
	} else {
		dpci_get_attributes(aiop_tile->dpci, &dpci_attr);
			dpci_id = dpci_attr.id;
	}

	/* get aiop tile descriptor */
	memset(&aiop_tile_desc, 0, sizeof(struct aiop_tile_desc));
	aiop_tile_desc.tile_id = aiop_tile->id;
	err = sys_get_desc(SOC_MODULE_AIOP, SOC_DB_AIOP_TILE_DESC_ID,
	                   &aiop_tile_desc, NULL);
	ASSERT_COND(!err);

	/* get AIOP cfg parameters */
	memset(&cfg, 0, sizeof(struct aiop_tile_cfg));
	err = build_aiop_cfg(aiop_tile, &aiop_boot_s->app_info,  &attributes, options);
	if (err)
	{
		aiop_tile->status |= AIOP_TILE_STATUS_LOAD_ERR;
		return err;
	}

	/* re-initialize AIOP */
	err = runtime_init(aiop_tile);
	if (err)
	{
		aiop_tile->status |= AIOP_TILE_STATUS_LOAD_ERR;
		return err;
	}

	/* load image */
	pr_info("Loading AIOP version %d.%d,%d\n", ioread32be(&aiop_boot_s->sl_info.aiop_rev_major), ioread32be(&aiop_boot_s->sl_info.aiop_rev_minor), ioread32be(&aiop_boot_s->sl_info.aiop_revision));
	err = load_image(aiop_tile, img_addr, &aiop_boot_s_paddr);
	if (err)
	{
		aiop_tile->status |= AIOP_TILE_STATUS_LOAD_ERR;
		return err;
	}

	/* set AIOP SW parameters */
	err = set_aiop_sl_params(aiop_tile, aiop_boot_s_paddr, &attributes, dpci_id);
	if (err)
	{
		aiop_tile->status |= AIOP_TILE_STATUS_LOAD_ERR;
		return err;
	}

	aiop_tile->status |= AIOP_TILE_STATUS_IMG_LOADED;

	/* Setting core's out-of-reset address (__sys_start) in RBASE */
	iowrite32(core_out_of_reset_addr, &regs->rbase);

	aiop_tile_enable(aiop_tile);

	pr_debug("ID[%d]: exit\n", aiop_tile->id); 

	return 0;
}

int aiop_drv_init(void)
{
	struct aiop_tile *aiop_tile;
	struct resman_res_req req;
	int iter = 0;
	int err;
	struct aiop_tile_desc aiop_tile_desc;
	void *resman_device;


	pr_debug("enter\n");
	
	while (sys_get_desc(SOC_MODULE_AIOP, 0, &aiop_tile_desc, &iter) == 0) {
		/* Create a resman device for AIOP resources */
		resman_device = resman_create_mc_device(sys_get_unique_handle(FSL_MOD_RESMAN));
		if (resman_device == NULL)
			return -ENODEV;

		aiop_tile = aiop_drv_tile_init(&aiop_tile_desc, resman_device);
		if (!aiop_tile) {
			pr_err("AIOP tile initialization\n");
			return -EACCES;
		}

		/* Create resman pool */
		memset(&req, 0, sizeof(struct resman_res_req));
		snprintf(req.type, sizeof(req.type), "ep.aiop%d", aiop_tile_desc.tile_id);
		req.id_base_align = AIOP_EPID_DPNI_START;
		req.num = aiop_tile_desc.num_ep - req.id_base_align;
		req.options |= DPRC_RES_REQ_OPT_EXPLICIT;
		err = resman_create_res_pool(
			sys_get_unique_handle(FSL_MOD_RESMAN), &req);
		if (err)
			return err;
		memset(&req, 0, sizeof(struct resman_res_req));
		snprintf(req.type, sizeof(req.type), "sp.aiop%d", aiop_tile_desc.tile_id);
		req.id_base_align = 0;
		req.num = aiop_tile_desc.num_sp;
		req.options |= DPRC_RES_REQ_OPT_EXPLICIT;
		err = resman_create_res_pool(
			sys_get_unique_handle(FSL_MOD_RESMAN), &req);
		if (err)
			return err;

		/* save AIOP tile handle for system use */
		err = sys_add_handle(aiop_tile, FSL_MOD_AIOP_TILE, 1,
					aiop_tile_desc.tile_id);
		ASSERT_COND(!err);
	}

	pr_debug("exit\n");
	
	return 0;
}

void aiop_drv_free(void)
{
	struct aiop_tile *aiop_tile;
	struct aiop_tile_desc aiop_tile_desc;
	int iter = 0;

	pr_debug("enter\n");
	
	while (sys_get_desc(SOC_MODULE_AIOP, 0, &aiop_tile_desc, &iter) == 0) {

		aiop_tile = sys_get_handle(FSL_MOD_AIOP_TILE, 1,
						aiop_tile_desc.tile_id);
		ASSERT_COND(aiop_tile);

		aiop_drv_tile_free(aiop_tile);

		/* remove tile handle from handles list */
		sys_remove_handle(FSL_MOD_AIOP_TILE, 1,
					aiop_tile_desc.tile_id);
	}
	
	pr_debug("exit\n"); 

}

int aiop_tile_virt2phys(struct aiop_tile *aiop_tile,  void *vaddr, phys_addr_t *paddr)
{
	uint64_t size;
	phys_addr_t pbase;
	int i;
	uint32_t vbase;

	/* if address is in SRAM */
	vbase = (uint32_t)aiop_tile->sram_vaddr;
	pbase = aiop_tile->sram_paddr;
	size = (uint64_t)aiop_tile->sram_size;
		
	if (((uint32_t)vaddr >= vbase) && ((uint32_t)vaddr < (uint64_t)vbase + size))
	{
		*paddr = (pbase + (uint64_t)((uint32_t)vaddr-vbase));
		return 0;
	}

	for (i = 0; i < AIOP_ATU_NUM_OF_WINDOWS; i++)
	{
		/* if ATU window is enabled */
		if (aiop_get_atu(aiop_tile, i, (void *)&vbase, &pbase, &size) == 0)
		{
			if (((uint32_t)vaddr >= vbase) && ((uint32_t)vaddr < (uint64_t)vbase + size))
			{
				*paddr = (pbase + (uint64_t)((uint32_t)vaddr-vbase));
				return 0;
			}
		}
	}
	
	return -ENODEV;
}

uint32_t aiop_drv_tile_get_status(struct aiop_tile *aiop_tile)
{
	return aiop_tile->status;
}

