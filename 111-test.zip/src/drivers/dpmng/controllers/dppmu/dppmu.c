/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dppmu.c

 @Description   DP Performance Management unit implementation

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_sys.h"
#include "fsl_dbg.h"
#include "fsl_dpmng_mc.h"

#include "dppmu.h"

void dppmu_ph10_state_request(struct dppmu_desc *desc, uint32_t mask)
{
	struct dppmu_regs *regs = (struct dppmu_regs *)desc->vaddr;

	iowrite32(mask, &(regs->tph10setr0));
}

void dppmu_ph10_state_status(struct dppmu_desc *desc, uint32_t *status)
{
	struct dppmu_regs *regs = (struct dppmu_regs *)desc->vaddr;

	*status = ioread32(&(regs->tph10sr0));
}

void dppmu_ph15_state_request(struct dppmu_desc *desc, uint32_t mask)
{
	struct dppmu_regs *regs = (struct dppmu_regs *)desc->vaddr;

	iowrite32(mask, &(regs->pcph15setr));
}

void dppmu_ph15_state_status(struct dppmu_desc *desc, uint32_t *status)
{
	struct dppmu_regs *regs = (struct dppmu_regs *)desc->vaddr;

	*status = ioread32(&(regs->pcph15sr));
}

void dppmu_aiop_tile_reset_request(struct dppmu_desc *desc)
{
	struct dppmu_regs *regs = (struct dppmu_regs *)desc->vaddr;

	iowrite32(RSTCR_AIOP_TILE_RESET, &(regs->rstcr));
}

void dppmu_aiop_tile_reset_status(struct dppmu_desc *desc, uint32_t *status)
{
	struct dppmu_regs *regs = (struct dppmu_regs *)desc->vaddr;

	*status = (ioread32(&(regs->rstcr)) & RSTCR_AIOP_TILE_RESET);
}
