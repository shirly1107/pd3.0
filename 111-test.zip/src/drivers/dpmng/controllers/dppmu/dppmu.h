/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dppmu.h

 @Description   DP Performance Management unit internal structures and definitions
*//***************************************************************************/
#ifndef __DPPMU_H
#define __DPPMU_H

#include "common/fsl_string.h"
#include "fsl_dppmu.h"

#define RSTCR_AIOP_TILE_RESET		0x00000001

struct dppmu_regs {
	uint32_t tph10sr0;	/* 0h Thread PH10 Status */
	uint8_t  reserved0[0xC];
	uint32_t tph10setr0;	/* 10h Thread PH10 Set Control */
	uint8_t  reserved1[0xC];
	uint32_t tph10clrr;	/* 20h Thread PH10 Clear Control */
	uint8_t  reserved2[0xC];
	uint32_t tph10psr0;	/* 30h Thread PH10 Previous Status */
	uint8_t  reserved3[0xC];
	uint32_t twaitsr0;	/* 40h Thread Wait Status */
	uint8_t  reserved4[0x10C];

	uint32_t tpmimr0;	/* 150h Thread Power Management Interrupt Masking 0 */
	uint8_t  reserved5[0xC];
	uint32_t tpmcimr0;	/* 160h Thread Power Management Critical Interrupt Masking 0 */
	uint8_t  reserved6[0xC];
	uint32_t tpmmcmr0;	/* 170h Thread Power Management Machine Check Masking 0 */
	uint8_t  reserved7[0x68C];

	uint32_t pcph15sr; 	/* 800h Physical Core PH15 Status */
	uint32_t pcph15setr; 	/* 804h Physical Core PH15 Set Control */
	uint32_t pcph15clrr; 	/* 808h Physical Core PH15 Clear Control */
	uint32_t pcph15psr; 	/* 80Ch Physical Core PH15 Previous Status */

	uint8_t reserved8[0xB7F0];

	uint32_t rstcr;		/* C000h Reset control */

	uint8_t reserved9[0x3BF4];

	uint32_t iprevnr;	/* FBF8h IP Revision */
};


#endif /* __DPPMU_H */
