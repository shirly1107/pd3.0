/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_lcfg.h"
#include "fsl_dbg.h"

int lcfg_drv_init(void);

int lcfg_drv_init(void)
{
	pr_info("Executing lcfg_drv_init...\n");

	lcfg_init();

	return 0;
}
