/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpmng.h

 @Description   dpmng internal structures and definitions.
 *//***************************************************************************/
#ifndef __LCFG_H
#define __LCFG_H

#include "kernel/device.h"
#include "fsl_types.h"
#include "fsl_lcfg.h"

struct lcfg_regs {
	uint32_t tbsalr; /* 0x000 Translation Bypass Start Address Low Register */
	uint32_t tbsahr; /* 0x004 Translation Bypass Start Address High Register */
	uint32_t tbealr; /* 0x008 Translation Bypass End Address Low Register */
	uint32_t tbeahr; /* 0x00C Translation Bypass End Address High Register */
};

#define LCFG_LOW_REG_MASK 	0x00000000FC000000
#define LCFG_HIGH_REG_MASK 	0x000000FF00000000

#endif /* __LCFG_H */
