/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          pebm.c

 @Description   pebm library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_soc.h"
#include "fsl_platform.h"
#include "fsl_io.h"
#include "fsl_dpmng_mc.h"

#include "lcfg.h"

extern uint64_t dpaa_lcfg_base; 
extern uint64_t dpaa_lcfg_size;


int lcfg_init()
{
	int err;
	struct lcfg_desc lcfg_desc;
	phys_addr_t mem_end, mem_base;
	uint32_t low, high;
	struct lcfg_regs *regs;
	
	mem_base = dpaa_lcfg_base;
	mem_end = mem_base + dpaa_lcfg_size - 1;

	err = sys_get_desc(SOC_MODULE_LCFG, 0, &lcfg_desc, 0);
	ASSERT_COND(!err);

	pr_info("LCFG CCSR: 0x%08x%08x\n",UINT32_HI(lcfg_desc.paddr), UINT32_LO(lcfg_desc.paddr));

	pr_info("LCFG Window base: 0x%08x%08x; LCFG Window size = 0x%08x%08x\n", 
								UINT32_HI(dpaa_lcfg_base),
								UINT32_LO(dpaa_lcfg_base),
								UINT32_HI(dpaa_lcfg_size),
								UINT32_LO(dpaa_lcfg_size));
	regs = (struct lcfg_regs *)(lcfg_desc.vaddr);

	/* register is in 64MB resolution */
	ASSERT_COND(!(mem_base & ((64*MEGABYTE) - 1)));
	/* [31:26] */
	low = (uint32_t)(mem_base & LCFG_LOW_REG_MASK);
	/* [39:32] */
	high = (uint32_t)((mem_base & LCFG_HIGH_REG_MASK) >> 32);
	/* Write start registers */
	iowrite32(low, &regs->tbsalr);
	iowrite32(high, &regs->tbsahr);

	/* [31:26] */
	low = (uint32_t)(mem_end & LCFG_LOW_REG_MASK);
	/* [39:32] */
	high = (uint32_t)((mem_end & LCFG_HIGH_REG_MASK) >> 32);
	/* Write start registers */
	iowrite32(low, &regs->tbealr);
	iowrite32(high, &regs->tbeahr);
	return 0;
}

