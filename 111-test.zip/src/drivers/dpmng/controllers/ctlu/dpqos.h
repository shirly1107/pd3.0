/*
 * Copyright 2013-2020 NXP
 */

#ifndef __DPQOS_H
#define __DPQOS_H

#include "fsl_dpqos.h"


#define DPQOS_BASED_ON_VLAN_MAX_NUM_OF_ENTRIES		8
#define DPQOS_BASED_ON_IP_MAX_NUM_OF_ENTRIES		64

#define DPQOS_SKIP_POLICER							0x10000000
#define DPQOS_SET_POLICER_ID						0x20000000
#define DPQOS_SET_QPRI								0x80000000

#define DPQOS_QPRI_SHIFT						24
#define DPQOS_DPPOLICER_ID_SHIFT				8

#define DPQOS_MAX_DPPOLICER_PROFILE_ID			0xfff			
#define DPQOS_MAX_NUM_OF_QPRIs					0xf			

#define DPQOS_CHUNK_ENTRIES						8
#define DPQOS_CHUNK_SHIFT						16
#define DPQOS_VLAN_PRIORITY						0x00080000
#define DPQOS_ENTRY_SIZE						4

#define DPQOS_IFP_ID_MASK						0xffff
struct dpqos_mng {
	struct ctlu *ctlu;
};

struct dpqos{
    int                    ifp_id;
    struct dpqos_mng 		*dpqos_mng;
    uint8_t chunk_array_ip[(DPQOS_BASED_ON_IP_MAX_NUM_OF_ENTRIES  / DPQOS_CHUNK_ENTRIES)];
    uint8_t chunk_array_vlan[(DPQOS_BASED_ON_VLAN_MAX_NUM_OF_ENTRIES / DPQOS_CHUNK_ENTRIES)];
};

struct qos_entry_message {
	uint32_t info;
};
#endif /* __DPQOS_H */
