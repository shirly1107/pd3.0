/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_malloc.h"
#include "fsl_io.h"

#include "dppolicer.h"

static uint32_t calc_fpp(uint32_t fpp)
{
	if (fpp > 15)
		return 15 - (0x1f - fpp);
	else
		return 16 + fpp;
}

static void get_info_rate_reg(enum dppolicer_rate_mode rate_mode,
                           uint32_t rate,
                           uint32_t ts_period,
                           uint32_t fpp_shift,
                           uint64_t *integer,
                           uint64_t *fraction)
{
	uint64_t tmp, div;

	if (rate_mode == DPPPLICER_BYTE_RATE_MODE) {
		/* now we calculate the initial integer for the bigger rate */
		/* from Kbps to Bytes/TSU */
		tmp = (uint64_t)rate;
		tmp *= 1000; /* kb --> b */
		tmp *= (uint64_t)(ts_period * 10); /* bps --> bpTsu(in 10nano) */

		div = 1000000000; /* nano */
		div *= 10; /* 10 nano */
		div *= 8; /* bit to byte */
	} else {
		/* now we calculate the initial integer for the bigger rate */
		/* from Kbps to Bytes/TSU */
		tmp = (uint64_t)rate;
		tmp *= (uint64_t)(ts_period * 10); /* bps --> bpTsu(in 10nano) */

		div = 1000000000; /* nano */
		div *= 10; /* 10 nano */
	}
	*integer = (tmp << fpp_shift) / div;

	/* for calculating the fraction, we will recalculate cir and deduct the integer.
	 * For precision, we will multiply by 2^16. we do not divid back, since we write
	 * this value as fraction - see spec.
	 */
	*fraction = (((tmp << fpp_shift) << 16) - ((*integer << 16) * div))
	            / div;
	pr_debug("exit\n");
}

/* .......... */

static int calc_rates(const struct dppolicer_non_passthrough *non_passthrough,
				      uint32_t ts_period,
                      uint32_t *cir,
                      uint32_t *cbs,
                      uint32_t *pir_eir,
                      uint32_t *pbs_ebs,
                      uint32_t *fpp)
{
	uint64_t integer, fraction;
	uint32_t temp;
	uint8_t fpp_shift = 0;

	/* we choose the faster rate to calibrate fpp */
	/* The meaning of this step:
	 * when fpp_shift is 0 it means all TS bits are treated as integer and TSU is the TS LSB count.
	 * In this configuration we calculate the integer and fraction that represent the higher infoRate
	 * When this is done, we can tell where we have "spare" unused bits and optimize the division of TS
	 * into "integer" and "fraction" where the logic is - as many bits as possible for integer at
	 * high rate, as many bits as possible for fraction at low rate.
	 */
	if (non_passthrough->committed_info_rate
	    > non_passthrough->peak_or_excessive_info_rate)
		get_info_rate_reg(non_passthrough->rate_mode,
		               non_passthrough->committed_info_rate,
		               ts_period, 0, &integer, &fraction);
	else
		get_info_rate_reg(non_passthrough->rate_mode,
		               non_passthrough->peak_or_excessive_info_rate,
		               ts_period, 0, &integer, &fraction);

	/* we shift integer, as in cir/pir it is represented by the MSB 16 bits, and
	 * the LSB bits are for the fraction */
	temp = (uint32_t)((integer << 16) & 0x00000000FFFFFFFF);
	/* temp is effected by the rate. For low rates it may be as low as 0, and then we'll
	 * take max FP = 31.
	 * For high rates it will never exceed the 32 bit reg (after the 16 shift), as it is
	 * limited by the 10G physical port.
	 */
	if (temp != 0) {
		/* In this case, the largest rate integer is non 0, if it does not occupy all (high) 16
		 * bits of the PIR_EIR we can use this fact and enlarge it to occupy all 16 bits.
		 * The logic is to have as many bits for integer in the higher rates, but if we have "0"s
		 * in the integer part of the cir/pir register, than these bits are wasted. So we want
		 * to use these bits for the fraction. in this way we will have for fraction - the number
		 * of "0" bits and the rest - for integer.
		 * In other words: For each bit we shift it in PIR_EIR, we move the FP in the TS
		 * one bit to the left - preserving the relationship and achieving more bits
		 * for integer in the TS.
		 */

		/* count zeroes left of the higher used bit (in order to shift the value such that
		 * unused bits may be used for fraction).
		 */
		while ((temp & 0x80000000) == 0) {
			temp = temp << 1;
			fpp_shift++;
		}
		if (fpp_shift > 15) {
			pr_err("timeStampPeriod to Information rate ratio is too small\n");
			return -EINVAL;
		}
	} else {
		temp = (uint32_t)fraction; /* fraction will alyas be smaller than 2^16 */
		if (!temp)
			/* integer and fraction are 0, we set FP to its max val */
			fpp_shift = 31;
		else {
			/* integer was 0 but fraction is not. FP is 16 for the fraction,
			 * + all left zeroes of the fraction. */
			fpp_shift = 16;
			/* count zeroes left of the higher used bit (in order to shift the value such that
			 * unused bits may be used for fraction).
			 */
			while ((temp & 0x8000) == 0) {
				temp = temp << 1;
				fpp_shift++;
			}
		}
	}

	/*
	 * This means that the FM TS register will now be used so that 'fpp_shift' bits are for
	 * fraction and the rest for integer */
	/* now we re-calculate cir and pir_eir with the calculated FP */
	get_info_rate_reg(non_passthrough->rate_mode,
	               non_passthrough->committed_info_rate, ts_period,
	               fpp_shift, &integer, &fraction);
	*cir = (uint32_t)(integer << 16 | (fraction & 0xFFFF));
	get_info_rate_reg(non_passthrough->rate_mode,
	               non_passthrough->peak_or_excessive_info_rate,
	               ts_period, fpp_shift, &integer, &fraction);
	*pir_eir = (uint32_t)(integer << 16 | (fraction & 0xFFFF));

	*cbs = non_passthrough->committed_burst_size;
	*pbs_ebs = non_passthrough->peak_or_excessive_burst_size;

	/* convert FP as it should be written to reg.
	 * 0-15 --> 16-31
	 * 16-31 --> 0-15
	 */
	*fpp = calc_fpp(fpp_shift);

	return 0;
}

static int check_cfg(const struct dppolicer_profile_cfg *cfg, int profile_id)
{
	if ((cfg->green_drop_pri >= DPPOLICER_MAX_NUM_PRIS)
	    || (cfg->yellow_drop_pri >= DPPOLICER_MAX_NUM_PRIS)
	    || (cfg->red_drop_pri >= DPPOLICER_MAX_NUM_PRIS)) {
		pr_err("Invalid Policer profile drop priority (profile %d)\n", profile_id);
		return -EINVAL;
	}
	switch (cfg->alg) {
	case (DPPPLICER_PASS_THROUGH):
	case (DPPPLICER_RFC_2698):
	case (DPPPLICER_RFC_4115):
		break;
	default: {
		pr_err("Invalid Policer profile algorithm "
		"(profile %d)\n", profile_id);
		return -EINVAL;
	}
	}
	switch (cfg->default_color) {
	case (DPPPLICER_GREEN):
	case (DPPPLICER_YELLOW):
	case (DPPPLICER_RED):
		break;
	default: {
		pr_err("Invalid Policer profile color (profile %d)\n", profile_id);
		return -EINVAL;
	}
	}
	switch (cfg->non_passthrough_cfg.byte_rate_cfg.rollback_frame_select) {
	case (DPPPLICER_ROLLBACK_L2_FRM_LEN):
	case (DPPPLICER_ROLLBACK_FULL_FRM_LEN):
		break;
	default: {
		pr_err("Invalid Policer profile rollback (profile %d)\n", profile_id);
		return -EINVAL;
	}
	}

	switch (cfg->non_passthrough_cfg.rate_mode) {
	case (DPPPLICER_BYTE_RATE_MODE):
	case (DPPPLICER_PACKET_RATE_MODE):
		break;
	default: {
		pr_err("Invalid Policer profile rate mode (profile %d)\n", profile_id);
		return -EINVAL;
	}
	}

	switch (cfg->non_passthrough_cfg.byte_rate_cfg.frame_len_select) {
	case (DPPPLICER_L2_FRM_LEN):
	case (DPPPLICER_L3_FRM_LEN):
	case (DPPPLICER_L4_FRM_LEN):
	case (DPPPLICER_FULL_FRM_LEN):
		break;
	default: {
		pr_err("Invalid Policer profile frame length (profile %d)\n", profile_id);
		return -EINVAL;
	}
	}

	return 0;
}

static int build_dppolicer_profile(struct dppolicer *dppolicer, const struct dppolicer_profile_cfg *cfg,
                                    struct dppolicer_profile_map *regs)
{
	uint32_t mode_reg = 0;
	uint32_t cir = 0, cbs = 0, pir_eir = 0, pbs_ebs = 0, fpp = 0;
	uint32_t ts_period;
	int err = 0;

	memset(regs, 0, sizeof(struct dppolicer_profile_map));

	mode_reg |= cfg->red_drop_pri << MODE_RDROPP_SHIFT;
	mode_reg |= cfg->yellow_drop_pri << MODE_YDROPP_SHIFT;
	mode_reg |= cfg->green_drop_pri << MODE_GDROPP_SHIFT;

	mode_reg |= GET_ALG_MASK(cfg->alg);
	mode_reg |= GET_COLOR_MASK(cfg->default_color);

	if (cfg->options & DPPOLICER_OPT_COLOR_BLIND)
		mode_reg |= MODE_COLOR_BLIND;
	if (cfg->options & DPPOLICER_OPT_KEEP_DROP_PRI)
		mode_reg |= MODE_KEEP_DROP_PRI;
	if (cfg->options & DPPOLICER_OPT_DISCARD_RED)
		mode_reg |= MODE_DISCARD_RED;

	if (cfg->alg != DPPPLICER_PASS_THROUGH) {
		if (cfg->non_passthrough_cfg.rate_mode
		    == DPPPLICER_BYTE_RATE_MODE) {
			mode_reg |=
			        GET_FRAME_LEN_MASK(
				        cfg->non_passthrough_cfg.byte_rate_cfg.frame_len_select);
			if (cfg->non_passthrough_cfg.byte_rate_cfg.rollback_frame_select
			    == DPPPLICER_ROLLBACK_FULL_FRM_LEN)
				mode_reg |= MODE_ROLLBACK_FULL_FRM_LEN;
		} else
			mode_reg |= MODE_PACKET_RATE;

		/* get timestamp ts_period (in nanoseconds) */
		ts_period = ctlu_get_timestamp_period(dppolicer->ctlu);

		err = calc_rates(&cfg->non_passthrough_cfg, ts_period, &cir, &cbs, &pir_eir,
		          &pbs_ebs, &fpp);
		if (err)
			return err;

		regs->iop_cplpcir = cir;
		regs->iop_cplpcbs = cbs;
		regs->iop_cplppir_eir = pir_eir;
		regs->iop_cplppbs_ebs = pbs_ebs;
		mode_reg |= fpp << MODE_FPP_SHIFT;
	}
	regs->iop_mode = (mode_reg | MODE_VALID);
	regs->iop_cplpcts = 0xffffffff;
	regs->iop_cplppts_ets = 0xffffffff;

	return 0;
}

static int compare_profile(struct dppolicer *dppolicer,
                           int profile_id,
                           const void *cmd_if_cfg,
                           const struct dppolicer_profile_cfg *cfg,
                           int *match)
{
	int cmd_err_code = 0, err = 0;
	struct dppolicer_msg *dppolicer_in_msg = NULL/* *dppolicer_out_msg */;
	void *cmd_cfg;
	uint16_t status;
	uint32_t *mtypein_addr, mtypeout;
	struct dppolicer_profile_map dppolicer_profile_new, *dppolicer_out_msg;

	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dppolicer->ctlu, &cmd_cfg,
	                                  (void*)&dppolicer_in_msg,
	                                  &mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;

	memset(dppolicer_in_msg, 0, sizeof(struct dppolicer_msg));

	*mtypein_addr |= (profile_id << MTYPEIN_PLID_SHIFT);

	/* dppolicer_out_msg is the address of the output msg. We do not need to
	 * allocate it. it is the responsibility of the ctlu layer to make
	 * sure this memory is available until ctlu_free_cmd_cfg is called */
	cmd_err_code = ctlu_execute_cmd(dppolicer->ctlu, cmd_if_cfg, cmd_cfg,
	                                MNG_CMD_DPPOLICER_PROFILE_QUERY,
	                                &status, &mtypeout,
	                                (void**)&(dppolicer_out_msg));
	err = ctlu_free_cmd_cfg(dppolicer->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;

	/* set new Profile parameters */
	cmd_err_code = build_dppolicer_profile(dppolicer, cfg, &dppolicer_profile_new);
	if (cmd_err_code)
		return cmd_err_code;

	/* assume match, then change if a difference is found */
	*match = 1;
	if (dppolicer_out_msg->iop_mode != dppolicer_profile_new.iop_mode)
		*match = 0;
	else {
		if ((dppolicer_out_msg->iop_mode & MADE_ALG_MASK)
		    == GET_ALG_MASK(cfg->alg)) {
			if (dppolicer_out_msg->iop_cplpcir
			    != dppolicer_profile_new.iop_cplpcir)
				*match = 0;
			if (dppolicer_out_msg->iop_cplpcbs
			    != dppolicer_profile_new.iop_cplpcbs)
				*match = 0;
			if (dppolicer_out_msg->iop_cplppir_eir
			    != dppolicer_profile_new.iop_cplppir_eir)
				*match = 0;
			if (dppolicer_out_msg->iop_cplppbs_ebs
			    != dppolicer_profile_new.iop_cplppbs_ebs)
				*match = 0;
		}
	}

	cmd_err_code = ctlu_free_cmd_cfg(dppolicer->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;

	return 0;
}

#ifdef TKT011436
/**************************************************************************//**
 @Function     dppolicer_restore
*//***************************************************************************/
int dppolicer_restore(const struct dppolicer *dppolicer)
{

	int err = 0, i;
	
/*	err = ctlu_get_mem_base(dppolicer->ctlu, CTLU_DPPOLICER,
	                        (void **)&dppolicer->regs);
	if (err) {
		fsl_free(dppolicer);
		return -EINVAL;
	}*/

	/* clear global counters */
	for (i = 0; i < DPPOLICER_MAX_NUM_PRIS; i++)
		iowrite32(0, &dppolicer->regs->iop_cpldrop[i]);

	return err;
}
#endif /* TKT011436 */

struct dppolicer *dppolicer_init(const struct dppolicer_cfg *cfg)
{

	int err = 0, i;

	struct dppolicer *dppolicer = (struct dppolicer *)fsl_malloc(
	        sizeof(struct dppolicer));

	if (!dppolicer) {
		pr_err("fsl_malloc() failed");
		return NULL;
	}
	memset(dppolicer, 0, sizeof(struct dppolicer));

	/* check - par_pclim <= PAR_PCLIM_MAX */
	err = ctlu_get_mem_base(cfg->ctlu, CTLU_DPPOLICER,
	                        (void **)&dppolicer->regs);
	if (err) {
		fsl_free(dppolicer);
		return NULL;
	}

	dppolicer->ctlu = cfg->ctlu;
	dppolicer->num_profiles = cfg->num_profiles;

	/* clear global counters */
	for (i = 0; i < DPPOLICER_MAX_NUM_PRIS; i++)
		iowrite32(0, &dppolicer->regs->iop_cpldrop[i]);

	return dppolicer;
}

void dppolicer_done(struct dppolicer *dppolicer)
{
	fsl_free(dppolicer);
}

int dppolicer_init_profile(struct dppolicer *dppolicer,
                           int profile_id,
                           const void *cmd_if_cfg,
                           struct dppolicer_profile_cfg *cfg)

{
	int cmd_err_code = 0, err = 0;
	struct dppolicer_msg *dppolicer_in_msg = NULL,
	        *dppolicer_out_msg = NULL;
	void *cmd_cfg;
	uint16_t status;
	uint32_t *mtypein_addr, mtypeout;

	if ((profile_id < 0) || (profile_id >= dppolicer->num_profiles)) {
		pr_err("Invalid Policer profile id (profile %d)\n", profile_id);
		return -EINVAL;
	}

	/* check profile parameters */
	cmd_err_code = check_cfg(cfg, profile_id);
	if (cmd_err_code)
		return cmd_err_code;

	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dppolicer->ctlu, &cmd_cfg,
	                                  (void*)&dppolicer_in_msg,
	                                  &mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;
	memset(dppolicer_in_msg, 0, sizeof(struct dppolicer_msg));

	/* profile_id and valid bits mask */
	*mtypein_addr = (MTYPEIN_CFG_REGS_MASK | MTYPEIN_CFG_REGS_CNTS_MASK
	                 | MTYPEIN_CFG_REGS_CLEAR_MASK);
	*mtypein_addr |= (profile_id << MTYPEIN_PLID_SHIFT);

	/* set Profile parameters */
	cmd_err_code = build_dppolicer_profile(dppolicer, cfg, &dppolicer_in_msg->dppolicer_profile_map);
	if (cmd_err_code)
		return cmd_err_code;

	cmd_err_code = ctlu_execute_cmd(dppolicer->ctlu, cmd_if_cfg, cmd_cfg, /* interface handle */
	                                MNG_CMD_DPPOLICER_PROFILE_CREATE_UPDATE,
	                                &status, &mtypeout,
	                                (void**)&dppolicer_out_msg);
	
	err = ctlu_free_cmd_cfg(dppolicer->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;

	return 0;

}

int dppolicer_delete_profile(struct dppolicer *dppolicer,
                             int profile_id,
                             const void *cmd_if_cfg)
{
	int cmd_err_code = 0, err = 0;
	struct dppolicer_msg *dppolicer_in_msg = NULL,
	        *dppolicer_out_msg = NULL;
	void *cmd_cfg;
	uint16_t status;
	uint32_t *mtypein_addr, mtypeout;

	if ((profile_id < 0) || (profile_id >= dppolicer->num_profiles)) {
		pr_err("Invalid Policer profile id (profile %d)\n", profile_id);
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dppolicer->ctlu, &cmd_cfg,
	                                  (void*)&dppolicer_in_msg,
	                                  &mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;

	memset(dppolicer_in_msg, 0, sizeof(struct dppolicer_msg));

	/* profile_id and valid bits mask */
	*mtypein_addr = MTYPEIN_MODE_MASK;
	*mtypein_addr |= (profile_id << MTYPEIN_PLID_SHIFT);

	/* Invalidate Profile */
	dppolicer_in_msg->dppolicer_profile_map.iop_mode = 0;

	cmd_err_code = ctlu_execute_cmd(dppolicer->ctlu, cmd_if_cfg, cmd_cfg, /* interface handle */
	                                MNG_CMD_DPPOLICER_PROFILE_CREATE_UPDATE,
	                                &status, &mtypeout,
	                                (void**)&dppolicer_out_msg);
	err = ctlu_free_cmd_cfg(dppolicer->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;

	return 0;

}

int dppolicer_find_profile(struct dppolicer *dppolicer,
                           const void *cmd_if_cfg,
                           void *attr,
                           int start_from,
                           int *match_id)
{
	int match = 0;
	int i = 0, ret_code = 0;
	struct dppolicer_profile_cfg *cfg = (struct dppolicer_profile_cfg *)attr;

	for (i = start_from; i < dppolicer->num_profiles; i++) {
		if ((ret_code = compare_profile(dppolicer, i, cmd_if_cfg, cfg,
		                                &match))
		    < 0) {
			/*TODO -treat error */
			return ret_code;
		}
		if (match) {
			*match_id = i;
			pr_debug("exit\n");
			return 0;
		}
	}

	pr_debug("exit\n");
	return -ENODEV;
}

int dppolicer_get_drop_pri_counter(struct dppolicer *dppolicer,
                                   uint8_t priority,
                                   uint32_t *val)
{
	if (priority >= DPPOLICER_MAX_NUM_PRIS)
		return -EINVAL;

	*val = ioread32(&dppolicer->regs->iop_cpldrop[priority]);
	return 0;
}

int dppolicer_set_drop_pri_counter(struct dppolicer *dppolicer,
                                   uint8_t priority,
                                   uint32_t val)
{

	if (priority >= DPPOLICER_MAX_NUM_PRIS)
		return -EINVAL;

	iowrite32(val, &dppolicer->regs->iop_cpldrop[priority]);

	return 0;
}

int dppolicer_get_profile_counter(struct dppolicer *dppolicer,
                                  int profile_id,
                                  const void *cmd_if_cfg,
                                  enum dppolicer_profile_counter counter,
                                  uint32_t *val)
{
	int cmd_err_code = 0, err = 0;
	struct dppolicer_msg *dppolicer_in_msg = NULL,
	        *dppolicer_out_msg = NULL;
	void *cmd_cfg;
	uint16_t status;
	uint32_t *mtypein_addr, mtypeout;

	if ((profile_id < 0) || (profile_id >= dppolicer->num_profiles)) {
		pr_err("Invalid Policer profile id (profile %d)\n", profile_id);
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dppolicer->ctlu, &cmd_cfg,
	                                  (void*)&dppolicer_in_msg,
	                                  &mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;

	memset(dppolicer_in_msg, 0, sizeof(struct dppolicer_msg));

	/* profile_id and valid bits mask */
	*mtypein_addr |= (profile_id << MTYPEIN_PLID_SHIFT);

	cmd_err_code = ctlu_execute_cmd(dppolicer->ctlu, cmd_if_cfg, cmd_cfg, /* interface handle */
	                                MNG_CMD_DPPOLICER_PROFILE_QUERY,
	                                &status, &mtypeout,
	                                (void**)&dppolicer_out_msg);
	err = ctlu_free_cmd_cfg(dppolicer->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;

	switch (counter) {
	case (DPPOLICER_CNT_RED):
		*val = dppolicer_out_msg->dppolicer_profile_map.iop_cplprpc;
		break;
	case (DPPOLICER_CNT_YELLOW):
		*val = dppolicer_out_msg->dppolicer_profile_map.iop_cplpypc;
		break;
	case (DPPOLICER_CNT_GREEN):
		*val = dppolicer_out_msg->dppolicer_profile_map.iop_cplpgpc;
		break;
	case (DPPOLICER_CNT_RE_RED):
		*val = dppolicer_out_msg->dppolicer_profile_map.iop_cplprrpc;
		break;
	case (DPPOLICER_CNT_RE_YELLOW):
		*val = dppolicer_out_msg->dppolicer_profile_map.iop_cplprypc;
		break;
	default:
		pr_err("Invalid counter");
		return -EINVAL;
	}

	return 0;
}

int dppolicer_get_profile_counters(struct dppolicer *dppolicer,
                                   int profile_id,
                                   const void *cmd_if_cfg,
                                   struct dppolicer_counters *counters)
{
	int cmd_err_code = 0, err = 0;
	struct dppolicer_msg *dppolicer_in_msg = NULL,
	        *dppolicer_out_msg = NULL;
	void *cmd_cfg;
	uint16_t status;
	uint32_t *mtypein_addr, mtypeout;

	if ((profile_id < 0) || (profile_id >= dppolicer->num_profiles)) {
		pr_err("Invalid Policer profile id (profile %d)\n", profile_id);
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dppolicer->ctlu, &cmd_cfg,
	                                  (void*)&dppolicer_in_msg,
	                                  &mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;

	memset(dppolicer_in_msg, 0, sizeof(struct dppolicer_msg));

	/* profile_id and valid bits mask */
	*mtypein_addr |= (profile_id << MTYPEIN_PLID_SHIFT);

	cmd_err_code = ctlu_execute_cmd(dppolicer->ctlu, cmd_if_cfg, cmd_cfg, /* interface handle */
	                                MNG_CMD_DPPOLICER_PROFILE_QUERY,
	                                &status, &mtypeout,
	                                (void**)&dppolicer_out_msg);
	err = ctlu_free_cmd_cfg(dppolicer->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;

	counters->cnt_red = dppolicer_out_msg->dppolicer_profile_map.iop_cplprpc;
	counters->cnt_yellow = dppolicer_out_msg->dppolicer_profile_map.iop_cplpypc;
	counters->cnt_green = dppolicer_out_msg->dppolicer_profile_map.iop_cplpgpc;
	counters->cnt_re_red = dppolicer_out_msg->dppolicer_profile_map.iop_cplprrpc;
	counters->cnt_re_yellow = dppolicer_out_msg->dppolicer_profile_map.iop_cplprypc;

	return 0;
}

int dppolicer_reset_profile_counters(struct dppolicer *dppolicer,
                                     int profile_id,
                                     const void *cmd_if_cfg)
{
	int cmd_err_code = 0, err = 0;
	struct dppolicer_msg *dppolicer_in_msg = NULL,
	        *dppolicer_out_msg = NULL;
	void *cmd_cfg;
	uint16_t status;
	uint32_t *mtypein_addr, mtypeout;

	if ((profile_id < 0) || (profile_id >= dppolicer->num_profiles)) {
		pr_err("Invalid Policer profile id (profile %d)\n", profile_id);
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dppolicer->ctlu, &cmd_cfg,
	                                  (void*)&dppolicer_in_msg,
	                                  &mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;

	memset(dppolicer_in_msg, 0, sizeof(struct dppolicer_msg));

	/* profile_id and valid bits mask */
	*mtypein_addr = MTYPEIN_CFG_REGS_CNTS_MASK;
	*mtypein_addr |= (profile_id << MTYPEIN_PLID_SHIFT);

	cmd_err_code = ctlu_execute_cmd(dppolicer->ctlu, cmd_if_cfg, cmd_cfg, /* interface handle */
	                                MNG_CMD_DPPOLICER_PROFILE_CREATE_UPDATE,
	                                &status, &mtypeout,
	                                (void**)&dppolicer_out_msg);
	err = ctlu_free_cmd_cfg(dppolicer->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;

	return 0;
}

int dppolicer_set_profile_counter(struct dppolicer *dppolicer,
                                  int profile_id,
                                  const void *cmd_if_cfg,
                                  enum dppolicer_profile_counter counter,
                                  uint32_t val)
{
	int cmd_err_code = 0, err = 0;
	struct dppolicer_msg *dppolicer_in_msg = NULL,
	        *dppolicer_out_msg = NULL;
	void *cmd_cfg;
	uint16_t status, mask;
	uint32_t *mtypein_addr, mtypeout;

	if ((profile_id < 0) || (profile_id >= dppolicer->num_profiles)) {
		pr_err("Invalid Policer profile id (profile %d)\n", profile_id);
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dppolicer->ctlu, &cmd_cfg,
	                                  (void*)&dppolicer_in_msg,
	                                  &mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;

	memset(dppolicer_in_msg, 0, sizeof(struct dppolicer_msg));

	/* profile_id and valid bits mask */
	get_counter_mask(counter, &mask);
	*mtypein_addr = (uint32_t)mask;
	*mtypein_addr |= (profile_id << MTYPEIN_PLID_SHIFT);

	/* set Profile counter */
	switch (counter) {
	case (DPPOLICER_CNT_RED):
		dppolicer_in_msg->dppolicer_profile_map.iop_cplprpc = val;
		break;
	case (DPPOLICER_CNT_YELLOW):
		dppolicer_in_msg->dppolicer_profile_map.iop_cplpypc = val;
		break;
	case (DPPOLICER_CNT_GREEN):
		dppolicer_in_msg->dppolicer_profile_map.iop_cplpgpc = val;
		break;
	case (DPPOLICER_CNT_RE_RED):
		dppolicer_in_msg->dppolicer_profile_map.iop_cplprrpc = val;
		break;
	case (DPPOLICER_CNT_RE_YELLOW):
		dppolicer_in_msg->dppolicer_profile_map.iop_cplprypc = val;
		break;
	default:
		pr_err("Invalid counter");
		ctlu_free_cmd_cfg(dppolicer->ctlu, cmd_cfg);
		return -EINVAL;
	}

	cmd_err_code = ctlu_execute_cmd(dppolicer->ctlu, cmd_if_cfg, cmd_cfg, /* interface handle */
	                                MNG_CMD_DPPOLICER_PROFILE_CREATE_UPDATE,
	                                &status, &mtypeout,
	                                (void**)&dppolicer_out_msg);
	err = ctlu_free_cmd_cfg(dppolicer->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;

	return 0;
}

