/*
 * Copyright 2013-2020 NXP
 */

#ifndef __CTLU_H
#define __CTLU_H

#include "fsl_ctlu.h"
#include "fsl_eiop_ifp.h"
#include "fsl_slab.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_CTLU

/* TMP - Should be in AIOP file */
struct aiop_acc_ws {
	int cmd; /**< Command type */
	void *in_msg;
	uint32_t mtypein;
	uint16_t status;
	uint32_t mtypeout;

	int x;
	int y;
	void *out_msg;
};

#define CSBEV_SBEV 0x80000000
#define MAX_NUM_OF_CKDRULES_REGS  16
/* Memory map blocks */
struct ctlu_ctrl_mem_map {
	uint32_t iop_cmode; /**< CTLU mode register */
	uint32_t iop_ctimestamp; /**< CTLU timestamp window register */
	uint32_t iop_mnlth; /**< CTLU maximum number of lookps threshold */
	uint32_t iop_cticid; /**< CTLU Lookup tables ICID */
	uint32_t iop_cagtim; /**< CTLU aging timer */
	uint32_t iop_cmfmg; /**< CTLU memory fill margin */
	uint32_t iop_cllck; /**< CTLU local lock */
	uint32_t iop_cinitdone; /**< CTLU initialization is completed */
	uint32_t res_1020h_1050h[12];
	/* CTLU profiling registers */
	uint32_t iop_cpccr; /**0x1050: CTLU profiling counters control register*/
	uint32_t res_1054h_1060[3];
	uint32_t iop_cpcrl; /** 0x1060 CTLU profiling counter rule lookups*/
	uint32_t iop_cpcrh; /**CTLU profiling counter rule hits*/
	uint32_t iop_cpcel; /**CTLU profiling counter entry lookups*/
	uint32_t iop_cpceh; /**CTLU profiling counter entry hits*/
	uint32_t iop_cpcca; /**CTLU profiling counter cache accesses*/
	uint32_t iop_cpcch; /**CTLU profiling counter cache hits*/
	uint32_t iop_cpccu; /**CTLU profiling counter cache updates*/
	uint32_t iop_cpcma; /**CTLU profiling counter memory accesses*/
	/* CTLU Debug Registers */
	uint32_t iop_cpmr; /** < 0x10F0 - CTLU Probe Mode Register*/
	uint32_t iop_cpar; /** < 0x10F4- CTLU Probe Address Register*/
	uint32_t iop_cpdr; /** < 0x10F8 - CTLU Probe Data Register*/
	uint32_t iop_res0fc;
	uint32_t iop_ckdcmp[16]; /*0x1100 - CTLU debug key reference value*/
	uint32_t iop_ckdmsk[16];/*0x1140 - CTLU debug key mask*/
	uint32_t iop_ckdrule[16];/*0x1180 - CTLU Key composition debug rule*/
};

struct ctlu_dma_mem_map {
	uint32_t iop_csbev; /**< CTLU external bus error event */
	uint32_t iop_csbem; /**< CTLU external bus error event mask register */
};

/* define which commands need sync */
#define IS_CMD_SYNC(cmd)	(((cmd == MNG_CMD_DPTBL_DEL) || 	\
			  (cmd == MNG_CMD_DPTBL_RULE_DEL) || 	\
			  (cmd == MNG_CMD_DPPARSER_PROFILE_DEL) || \
			  (cmd == MNG_CMD_DPPOLICY_RULE_DEL)) ? 1 : 0)

/************************************************************************//**
 @Description   Management Commands Input Parameters
 This structure is used to pass Management Command parameters
 *//*************************************************************************/
struct ctlu_cmd_if {
	enum ctlu_cmd_id mng_cmd; /**< Command type */
	void *msg;
	uint32_t mtypein;
	uint16_t status;
	/*enum dp_ctrl_type type;  wriop/aiop */
	union {
		struct {
			uint16_t option_flags;
			/* one or more of : CMD_IF_EGRESS,
			 CMD_IF_SYNC,  CMD_IF_BDI */
			uint16_t icid;
		} wriop;
		struct {
			void *out_msg;
			void *buffer;
		} aiop;
	} ctrl;
};

struct ctlu {
	enum ctlu_type type;
	int iop_id; /*! EIOP/AIOP id */
	struct ctlu_ctrl_mem_map *ctrl_regs;
	struct ctlu_dma_mem_map *dma_regs;
	void *dpparser_regs;
	void *dptbl_mng_regs;
	void *dpkg_regs;
	void *dppolicer_regs;
	struct slab *slab;
	void *resman_device;
	uint32_t soc_options;
	uint8_t profiling_enabled;

	/* EIOP only */
	struct eiop_ifp_desc ifp_desc; /* IFP descriptor  */
	void *cmd_if_ring; /* IFP Command descriptor ring base */

	/* management command callbacks */
	int (*execute_cmd_cb)(struct ctlu *ctlu,
	                      const void *cmd_if,
	                      void *cmd_cfg,
	                      enum ctlu_cmd_id cmd,
	                      uint16_t *status,
	                      uint32_t *mtypeout,
	                      void **out_msg);
	int (*build_cmd_cfg_cb)(struct ctlu *ctlu,
				  void **cmd_cfg,
	                          void **input_msg,
	                          uint32_t **mtypein_addr);
	int (*free_cmd_cfg_cb)(struct ctlu *ctlu, void *cmd_cfg);
	uint32_t (*get_timestamp_period_cb)(struct ctlu *ctlu);
	int (*get_cmd_code_cb)(enum ctlu_cmd_id cmd, uint32_t *code);
};

/* CTLU Blocks offsets */
#define CTRL_REGS_OFFSET	0x1000
#define CTRL_DMA_REGS_OFFSET	0x1800
/*
#define CTRL_MEM_ACCESS_ATTR	0x1400
#define DPPARSER_OFFSET		0x0000
#define DPPKG_OFFSET		0x2000
#define DPPOLICER_OFFSET	0x1C00
*/

/* CTLU registers masks */
#define CTLU_IOP_CMODE_CINIT	0x80000000
#define CTLU_IOP_CINITDONE	0x80000000
#define CTLU_MAX_LU_LOOPS	0xFF
#define CTLU_UNLIMITED_LU_LOOPS	0
#define CTLU_IOP_CTICID		0x00060000
#define CTLU_IOP_CLLCK		0x80000000
#define CTLU_IOP_CPCCR_TIDQE	0x2
#define CTLU_IOP_CPCCR_PCE		0x1

struct ctlu_cmd_code_map {
	enum ctlu_cmd_id cmd;
	uint32_t code;
};

#endif /* __CTLU_H */

