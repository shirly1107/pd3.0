/*
 * Copyright 2013-2020 NXP
 */

#ifndef __DPKG_H
#define __DPKG_H

#include "fsl_types.h"
#include "fsl_dpkg.h"

/* TODO packed */

struct dpkg_profile_regs {
		uint32_t iop_ckrhcnt; /**<CTLU Key composition rule hit Counter */
		uint32_t iop_ckcerr; /**< CTLU Key composition rule error */
};

/* end packed */

#define MNG_CMD_DPKG_RULE_CREATE_REPLACE_SIZE	64
#define MNG_CMD_DPKG_RULE_QUERY_SIZE			0x3f

#define DPKG_EXTRACT_FROM_FCV_IFP_OFFSET_MODE		0x18
#define DPKG_EXTRACT_FROM_PR_SPECIFIC_PROTOCOL_OFFSET_MODE	0x10

#define DPKG_EXTRACT_FROM_FCV_IFP_OFFSET			0x6
#define DPKG_EXTRACT_FROM_FCV_IFP_SIZE				2

#define DPKG_EXTRACT_FROM_FCV_L2SWITCH_FDB_SPECIFIC_OFFSET_MODE		0x19
#define DPKG_EXTRACT_FROM_FCV_L2SWITCH_FDB_SPECIFIC_OFFSET			0x2
#define DPKG_EXTRACT_FROM_FCV_L2SWITCH_FDB_SPECIFIC_SIZE			6

#define DPKG_EXTRACT_FROM_FCV_OPAQUE_IN_SPECIFIC_OFFSET				0x8
#define DPKG_FROM_FCV_L2SWITCH_FD_FLC_FOR_REPLIC_SRC_QDID_SPECIFIC_OFFSET 0x6
#define DPKG_EXTRACT_FROM_FCV_OPAQUE_IN_SPECIFIC_OFFSET_MODE	0x14
#define DPKG_EXTRACT_FROM_FCV_L2SWITCH_FD_FLC_FOR_REPLIC_SRC_QDID_SPECIFIC_SIZE 2

#define FEC_FORMAT_4_MASK_EXTENTION_SIZE 7
#define FEC_FORMAT_3_MASK_EXTENTION_SIZE 5
#define FEC_FORMAT_2_MASK_EXTENTION_SIZE 4
#define FEC_FORMAT_1_MASK_EXTENTION_SIZE 2

#define FEC_FORMAT_FULL_FIELD_SIZE 	1
#define FEC_FORMAT_INSRT_CONSTANT_SIZE	3
#define FEC_FORMAT_EXTRACT_GENERIC_SIZE 4

#define FEC_MASK_EXT_NMSK_SHIFFT	4
#define FEC_MASK_EXT_MOFF1_SHIFFT	4
#define FECID_SHIFFT			1
#define OP0_HET_SHIFFT			7

#define PR_UNKNOWN_OFFSET				0xff
#define PR_LLC_SNAP_OFFSET				0x14
#define PR_PPPoE_OFFSET					0x18
#define PR_MPLS_1_OFFSET				0x19
#define PR_MPLS_N_OFFSET				0x1a
#define PR_ARP_OR_IP_1_OFFSET			0x1b
#define PR_ARP_OFFSET					PR_ARP_OR_IP_1_OFFSET
#define PR_MINENCAP_OR_IP_N_OFFSET		0x1c
#define PR_MINENCAP_OFFSET				PR_MINENCAP_OR_IP_N_OFFSET
#define PR_GRE_OFFSET					0x1d
#define PR_L4_OFFSET					0x1e
#define PR_GTP_OR_ESP_OR_IPSEC_OFFSET	0x1f
#define PR_SHIM1_OFFSET					0x10
#define PR_SHIM2_OFFSET					0x11

#define PR_ETHYPE_OFFSET				0x17
#define PR_VLAN_TCI_1_OFFSET			0x15
#define PR_VLAN_TCI_N_OFFSET			0x16


#define FECID_UNKNOWN			0xff
#define FECID_GENERIC			0
#define FECID_PROTOCOL_BASED_HET	0
#define FECID_GENERIC_HET		1
#define FECID_INSERT_CONSTANT		1

#define FECID_ETH_MACDST		3
#define FECID_ETH_MACSRC		4
#define FECID_VLANTCI_1			5
#define FECID_VLANTCI_N			6
#define FECID_ETH_TYPE			7

#define FECID_PPPoE_SID			8
#define FECID_PPPoE_PID			9

#define FECID_MPLSL_1			10
#define FECID_MPLSL_2			11
#define FECID_MPLSL_N			12

#define FECID_ARP_OP			13
#define FECID_ARP_SPA			14
#define FECID_ARP_TPA			15
#define FECID_ARP_SHA			16
#define FECID_ARP_THA			17

#define FECID_IP_SRC_IP_1		18
#define FECID_IP_DST_IP_1		19
#define FECID_IP_PROTO_1		20
#define FECID_IP_TOS_1			21
#define FECID_IP_ID_1			22

#define FECID_IP_SRC_IP_N_OR_MINENCAP_SRC		24
#define FECID_IP_DST_IP_N_OR_MINENCAP_DST		25
#define FECID_IP_PROTO_N_OR_MINENCAP_TYPE		26
#define FECID_IP_TOS_N			27
#define FECID_IP_ID_N			28

#define FECID_IP_SRC_FROM_BASIC		0
#define FECID_IP_DST_FROM_BASIC		1
#define FECID_IP_PROTO_FROM_BASIC	2
#define FECID_IP_TOS_FROM_BASIC		3
#define FECID_IP_ID_FROM_BASIC		4


#define FECID_IPv6_FL_1			23
#define FECID_IPv6_FL_N			29

#define FECID_L4_SRC			31
#define FECID_L4_DST			32
#define FECID_TCP_FLAGS			33

#define FECID_GRE_TYPE			30

#define FECID_GTP_TEID			36

#define FECID_IPSEC_SPI			34
#define FECID_IPSEC_AH_NH			35

#define FECID_ICMP_TYPE			37
#define FECID_ICMP_CODE			38


typedef uint8_t  (t_dpkg_get_full_field_fecid) ( uint32_t field,
                             			int 	hdr_index);


struct full_field {
	uint32_t field;
	uint8_t hdr_index;
	uint8_t opcode;
};
struct kg_prf_info{
//	t_dpkg_get_full_field_fecid *f_get_full_field_fecid;
	struct full_field *full_field;
	uint8_t protocol_based_offset;
	uint8_t last_protocol_based_offset;
};

struct dpkg{
	struct dpkg_profile_regs *dpkg_regs_base;
	int num_profiles;
	struct kg_prf_info prf_prot_info[NET_PROT_DUMMY_LAST];
	struct ctlu *ctlu;
};



struct fec_format{
	uint8_t fecid;
	uint8_t op0;
	uint8_t op1;
	uint8_t op2;
};
struct fec_mask_extention{
	uint8_t nmask_moff0;
	uint8_t mask0;
	uint8_t moff1_moff2;
	uint8_t mask1;
	uint8_t mask2;
	uint8_t moff3;
	uint8_t mask3;
};
struct fecid_0{
	uint8_t size;
	uint8_t offset;
	uint8_t offset_mode;
	uint8_t extract_type;
};
struct fecid_1{
	uint8_t constant;
	uint8_t num_of_times_repeat;
};
struct profile_tmp{
	uint8_t fecid;
	uint8_t fec_format_size;
	uint8_t fec_format_mask_ext_size;
	union{
		struct fecid_0 fecid0;
		struct fecid_1 fecid1;
	}specific;

};
struct dpkg_profiles_tmp {
	struct profile_tmp prfl_tmp[DPKG_MAX_NUM_OF_EXTRACTS];
};

struct dpkg_profile{
	int profile_id;
	const struct dpkg *profile_mng;

};


#endif /* __DPKG_H */
