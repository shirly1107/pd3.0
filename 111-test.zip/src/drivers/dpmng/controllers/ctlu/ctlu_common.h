/*
 * Copyright 2013-2020 NXP
 */

#ifndef __CTLU_COMMON_H
#define __CTLU_COMMON_H

#include "fsl_net.h"

#define MNG_CMD_STATUS_TLUMISS		0x0800
#define MNG_CMD_STATUS_KSE		0x0400
#define MNG_CMD_STATUS_EOFH		0x0200
#define MNG_CMD_STATUS_MNLE		0x0100
#define MNG_CMD_STATUS_TIDE		0x0080
#define MNG_CMD_STATUS_PIEE		0x0040
#define MNG_CMD_STATUS_NORSC		0x0020
#define MNG_CMD_STATUS_TEMPNOR		0x0010
#define MNG_CMD_STATUS_ICIDE		0x0008

#define NO_AVAILABLE_RESMAN_IDS		0xffffffff

#define ACTION_MAX_DPPOLICER_PROFILE_ID		0xffff
#define ACTION_MAX_NUM_OF_QPRIs			16
#define ACTION_MAX_NUM_OF_IFP_IDs		0xfff
#define ACTION_MAX_NUM_OF_DPKG_PROFILE_IDs	0xff
#define ACTION_MAX_NUM_OF_QD_IDs		0xffff
#define ACTION_MAX_NUM_OF_QD_BINs		ACTION_MAX_NUM_OF_QD_IDs
#define ACTION_MAX_NUM_OF_DPTBL_IDs		0xffff
#define ACTION_MAX_NUM_OF_REPLIC_IDs		0xffff

#define ACTION_PLIDV			0x00400000
#define ACTION_QoSMMV			0x00200000
#define ACTION_IFDIDV			0x00040000
#define ACTION_FLCTYPV			0x00800000

#define ACTION_FLC_TYPE_AIOP 		0x00002000
#define ACTION_EPIDV			0x00010000
#define ACTION_RPLIDV			0x00020000
#define ACTION_FLC_GPPV			ACTION_RPLIDV
#define ACTION_SET_SC			0x00000008
#define ACTION_SET_CBMT			0x00000010

#define ACTION_DISCARD			0x00001000

#define ACTION_QPRIV			0x80
#define ACTION_QDIDV_QDBINV		0x04
#define ACTION_TKIDV			0x02
#define ACTION_HKIDV			0x08
#define ACTION_DISCARDV			0x20

#define ACTION_QPRI_SHIFT		8
#define ACTION_QoSMM_SHIFT		14

#define ACTION_FCVTYPE_TO_GPP_QDID	0x10000000
#define ACTION_FCVTYPE_TO_GPP_QDBIN	0x30000000
#define ACTTION_FCVTYPE_MASK		0xf0000000

struct action_common {
	uint32_t info1;
	uint8_t info2;
	uint8_t hkid;
	uint16_t qdid;
};

struct action_lookup {
	struct action_common action_common;
	uint16_t tid;
	uint8_t kid;
	uint8_t res1;
	uint16_t plid;
	uint16_t ifpid;
	uint16_t replic_id;
	uint8_t aiop_opaque[2];
};

struct action_done {
	struct action_common action_common;
	uint16_t plid;
	uint16_t ifpid;
	uint8_t gpp_opaque[8];
};

#define ACTION_SET_CONTEXT_IOMMU_BYPASS 		0x00002000
#define ACTION_SET_POLICER_ID     			0x80000000
#define ACTION_SET_QOS_MAP_METHOD  			0x40000000
#define ACTION_SET_QPRI          			0x20000000
#define ACTION_SET_IFP_ID         			0x10000000
#define ACTION_SET_HASH_KID      			0x00800000
#define ACTION_SET_DISCARD_FLAG   			0x00400000
#define ACTION_CLEAR_DISCARD_FLAG  			0x00200000
#define ACTION_SET_QDID          			0x00080000
#define ACTION_SET_QDBIN         			0x00040000
#define ACTION_SET_STASHING				0x00008000
#define ACTION_SET_CONTEXT_IOMMU_BYPASS 		0x00002000

#define ACTION_SET_FLC_FOR_AIOP  			0x08000000
#define ACTION_SET_REPLIC_ID 				0x04000000
#define ACTION_SET_OPAQUE				0x02000000

enum qos_map_method {
	ACTION_QoS_BASED_ON_VLAN_PRI = 0x4000,
	ACTION_QoS_BASED_ON_IP_DSCP = 0x8000
};

enum next_action {
	NEXT_ACTION_LOOKUP,
	NEXT_ACTION_DONE
};

struct action_cfg {
	enum next_action next_action;
	uint32_t options;
	int dppolicer_profile_id;
	enum qos_map_method qos_map_method;
	int qpri;
	int ifp_id;
	int hash_dpkg_profile_id;
	int qd_id;
	int qd_bin;
	int replic_id;
	uint64_t opaque;
	int dptbl_id;
	int dpkg_profile_id;
};

void get_action(uint8_t *ptr, struct action_cfg *action);

int fill_action(uint8_t *ptr, const struct action_cfg *action);

#endif /* __CTLU_COMMON_H */
