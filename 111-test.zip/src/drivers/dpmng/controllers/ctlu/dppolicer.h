/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 @File          dppolicer.h

 @Description   Policer Application Programming Interface.
 *//***************************************************************************/
#ifndef __DPPOLICER_H
#define __DPPOLICER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stdint.h"
#include "fsl_dppolicer.h"

/******************************************************/
/*********** Internal Header file *********************/
/******************************************************/

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_CTLU

struct dppolicer_mem_map {
	uint32_t iop_cpldrop[DPPOLICER_MAX_NUM_PRIS]; /**< CTLU Policer drop priority i*/
};

struct dppolicer_profile_map {
	uint32_t iop_mode;
	uint32_t res0[2];
	uint32_t iop_cplpwrap_cnt;
	uint32_t iop_cplpcir;
	uint32_t iop_cplpcbs;
	uint32_t iop_cplppir_eir;
	uint32_t iop_cplppbs_ebs;
	uint32_t iop_cplplts;
	uint32_t iop_cplpcts;
	uint32_t iop_cplppts_ets;
	uint32_t iop_cplpgpc;
	uint32_t iop_cplpypc;
	uint32_t iop_cplprpc;
	uint32_t iop_cplprypc;
	uint32_t iop_cplprrpc;
};
#define MTYPEIN_MODE_MASK		0x8000
#define MTYPEIN_CFG_REGS_MASK		0x8F60 /* mode, (0x8)
						  cir,cbs,pir_eir,pbs_ebs,(0xf)
						  cts, pts_ets (0x6)*/
#define MTYPEIN_CFG_REGS_CNTS_MASK		0x001F /* all counters */
#define MTYPEIN_CFG_REGS_CLEAR_MASK		0x1080 /* clear registers */

#define MODE_ROLLBACK_FULL_FRM_LEN	0x00400000
#define MODE_PACKET_RATE		0x00800000
#define MODE_DISCARD_RED		0x01000000
#define MODE_KEEP_DROP_PRI		0x02000000
#define MODE_COLOR_BLIND		0x40000000
#define MODE_VALID			0x80000000
#define MADE_ALG_MASK			0x03000000

#define MODE_GDROPP_SHIFT		8
#define MODE_YDROPP_SHIFT		4
#define MODE_RDROPP_SHIFT		0
#define MODE_FPP_SHIFT			16

#define MTYPEIN_PLID_SHIFT		16

#define GET_FRAME_LEN_MASK(len)		((len == DPPPLICER_L2_FRM_LEN) ? \
					0x00003000:((len == DPPPLICER_L3_FRM_LEN) ? \
						0x0000B000: ((len == DPPPLICER_L4_FRM_LEN) ? \
							0x0000E000: 0x0000F000)))	

#define GET_ALG_MASK(alg)		((alg == DPPPLICER_PASS_THROUGH) ? \
					0x0: ((alg == DPPPLICER_RFC_2698) ? \
						0x10000000: 0x20000000))

#define GET_COLOR_MASK(color)		((color == DPPPLICER_GREEN) ? \
					0x0: ((color == DPPPLICER_YELLOW) ? \
						0x04000000: 0x08000000))

static inline int get_counter_mask(enum dppolicer_profile_counter counter,
                                   uint16_t *mask)
{
	switch (counter) {
	case (DPPOLICER_CNT_GREEN):
		*mask = 0x0010;
		break;
	case (DPPOLICER_CNT_YELLOW):
		*mask = 0x0008;
		break;
	case (DPPOLICER_CNT_RED):
		*mask = 0x0004;
		break;
	case (DPPOLICER_CNT_RE_YELLOW):
		*mask = 0x0002;
		break;
	case (DPPOLICER_CNT_RE_RED):
		*mask = 0x0001;
		break;
	default:
		pr_err("Invalid counter\n");
		return -EINVAL;
	}
	return 0;
}

/**************************************************************************//**
 @Description   Policer Management Command Input Parameters
 This structure is used to pass Management Command parameters
 *//***************************************************************************/
struct dppolicer_msg {
	struct dppolicer_profile_map dppolicer_profile_map;
};

struct dppolicer {
	struct ctlu *ctlu;
	struct dppolicer_mem_map *regs;
	int num_profiles;
};

/* end - packed */
/***************************************************************************************************************/

#endif /* __DPPOLICER_H */
