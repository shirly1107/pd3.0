/*
 * Copyright 2013-2020 NXP
 */

#ifndef __DPTBL_H
#define __DPTBL_H

#include "fsl_dptbl.h"
#define DPTBL_REAL_SIZE_UNINIT 0xfffffff

#define SEC_TO_TS_UNITS(secs)	(secs* 1000000000/ctlu_get_timestamp_period(ctlu))


#define DPTBL_TCAM_ACL_TENUM_MASK 0x3ff
#define DPTBL_TCAM_ACL_QUERY_MASK 0x80000000
#define DPTBL_TCAM_ACL_QUERY_RULE 0x40000000
struct dptbl_mng_mem_map_set {
	uint32_t iop_ctaddh; /**< CTLU Tables base address high */
	uint32_t iop_ctaddl; /**< CTLU Tables base address low */
	uint32_t iop_ctsize; /**< Total CTLU Tables size */
	uint32_t res0;
	uint32_t iop_ctnce; /**< CTLU number of committed entries in table */
	uint32_t iop_cnee; /**< CTLU number of excess entries in table. */
	uint32_t res1[2];
};

#define MNG_CMD_DPTBL_CREATE_SIZE	0x8B
#define MNG_CMD_DPTBL_RULE_CREATE_SIZE	0x9f
#define MNG_CMD_DPTBL_RULE_QUERY_SIZE   0x3f
#define ILLEGAL_SET_OFFSET	TBLS_MAX_SETS

#define DPTBL_MAX_KEY_SIZE_EM   124

#define         DPTBL_INT_MEM     0x02000000
#define         DPTBL_PEB_MEM     0x03000000
#define         DPTBL_EXT_MEM_1   0x04000000
#define         DPTBL_EXT_MEM_2   0x05000000

#define         DTBL_EM                 0x00000000
#define         DPTBL_LPM               0x10000000
#define         DPTBL_TCAM_ACL          0x20000000
#define         DPTBL_ALG_ACL           0x40000000
#define         DPTBL_L2SWITCH_VLAN           0x60000000
#define         DPTBL_L2SWITCH_FDB           0x70000000

#define         DTBL_DELETE_PROCESS_OMGOING     0x00200000

#define DPTBL_ACTION_ON_MISS_DISCARD	0x00400000
#define DPTBL_ACTION_ON_MISS_PROGRAMMED	0x00800000
#define DPTBL_ACTION_ON_MISS_LOGICAL	0x00080000

#define DPTBL_ACTION_MISS_MASK          0x00c00000

#define DPTBL_L2SWITCH_FDB_KEY_SIZE   6
#define DPTBL_L2SWITCH_VLAN_KEY_SIZE   4

#define DPTBL_SIZE			0x8f
#define DPTBL_AGT_SHIFFT		16
#define DPTBL_BDI			0x00008000
#define DPTBL_MAX_NUM_OF_ICIDS 0x7fff

#define DPTBL_GET_INFO(type, mem_type, aging_threshold)\
	type | mem_type \
	(aging_threshold << DPTBL_AGT_SHIFFT)

#define DPTBL_KEY_ENTRY_SIZE 27

#define DPTBL_MAX_KEY_SIZE DPTBL_KEY_ENTRY_SIZE*4

#define DPTBL_GET_NUM_OF_ENTRIES(key_size) \
	(((key_size/DPTBL_KEY_ENTRY_SIZE) + (key_size % DPTBL_KEY_ENTRY_SIZE?1:0)))
	
/*#define DPTBL_GET_NUM_OF_ENTRIES(key_size) \
	((key_size <=24) ? 1 : \
	(((key_size > 24) && (key_size <=52)) ? 2 :\
	(((key_size >52) && (key_size <=88)) ? 3 : 4)))
*/

#define VALIDATE_TBL_TYPE(type)\
	(type == DPTBL_TYPE_EXACT_MATCH) ? 0 : 1

#define VALIDATE_MEM_TYPE(type)\
	(type == 0) ? 0 : 1


#define TABLE_ID_TCAM	1

typedef int (t_dptbl_check_params)(struct dptbl_cfg *params);
typedef void * (t_dptbl_init_obj)(void *params);
typedef int (t_dptbl_mod_get_rule)(struct dptbl* dptbl,
	struct dptbl_rule *rule,
	struct dptbl_action *action);
typedef int (t_dptbl_add_rule)(struct dptbl* dptbl,
	struct dptbl_rule *rule,
	struct dptbl_action *action,
	int restore);
typedef int (t_dptbl_remove_rule)(struct dptbl* dptbl, struct dptbl_rule *rule);
typedef int (t_dptbl_modify_miss_action)(struct dptbl* dptbl, struct dptbl_action *action);

struct dptbl_mng {
	struct ctlu *ctlu;
	struct dptbl_mng_mem_map_set *regs;
};

struct dptbl_tmp_init_params {
	uint32_t mem_type;
	uint32_t type;
	uint32_t max_rules;
	uint8_t num_of_entries_per_key;
	uint32_t max_key_size; /**< key size */
	uint32_t aging_threshold;
	t_dptbl_check_params *f_check_params;
	t_dptbl_init_obj *f_init_obj;
	t_dptbl_add_rule *f_add_rule;
	t_dptbl_mod_get_rule *f_modify_rule;
	t_dptbl_mod_get_rule *f_get_action;
	t_dptbl_remove_rule *f_remove_rule;
	t_dptbl_modify_miss_action *f_modify_miss_action;
	uint32_t action_on_miss_opcode;
	struct dptbl_action *action_on_miss;
	uint32_t options;
	uint32_t icid;

};
//struct dptbl_init_params;
struct dptbl_entry {
	int abs_index;
	int init;
};

struct em_key_storage {
	uint8_t *data;
	uint8_t **key_array;
	uint8_t *miss_key_data;
	uint32_t miss_key_offset;
	uint32_t key_offset;
	uint32_t key_size;
};

struct dptbl {
	uint32_t type;
	uint16_t tid;
	uint32_t max_key_size; /**< key size */
	uint32_t real_key_size; /**< key size */
	uint8_t num_of_entries_per_key;
	t_dptbl_add_rule *f_add_rule;
	t_dptbl_mod_get_rule *f_modify_rule;
	t_dptbl_mod_get_rule *f_get_action;
	t_dptbl_remove_rule *f_remove_rule;
	t_dptbl_modify_miss_action *f_modify_miss_action;
	uint32_t max_rules;
	uint32_t used_rules;
	uint32_t conf_table_rules;
	struct dptbl_mng *dptbl_mng;
	uint32_t action_on_miss_opcode;
	struct dptbl_entry	*entries;
	struct em_key_storage key_storage;
	int restore;
};

struct tbl_rule {
	uint8_t key[0x80];
	uint8_t res[8];
	uint32_t info1;
	uint8_t tlur[20];
};

struct tbl_rule_output {
	uint8_t res[0x2c];
	uint8_t tlur[20];
};

struct lookup_tbl {
	uint32_t info;
	uint32_t max_rules;
	uint32_t max_entries;
	uint32_t commited_entries;
};

struct lookup_tbl_query {
	struct lookup_tbl lookup_tbl;
	uint32_t res;
	uint32_t current_rules;
	uint32_t current_entries;
};

/*TCAM ACL PART*/
struct dptbl_tcam_acl_add_entry_message {
	uint8_t key[0x38];
	uint8_t res1[8];
	uint8_t mask[0x38];
	uint8_t res2[4];
	uint32_t info;
	uint8_t res3[8];
	uint32_t info1;
	uint8_t tlur[20];

};
struct dptbl_tcam_acl_move_entry_message{
	uint16_t from_tenum;
	uint16_t to_tenum;
};

struct dptbl_tcam_acl_delete_entry_message{
	uint32_t tenum;
};

struct dptbl_tcam_acl_query_entry_message{
	uint32_t tenum;
};

#define DPTBL_UPDATE_USED_NUM_OF_RULES(dptbl, add)\
	((add == 1) ? (((struct dptbl *)dptbl)->used_rules+=1): \
		 (((struct dptbl *)dptbl)->used_rules-=1))

#define DPTBL_UPDATE_ENTRY_INIT(dptbl, index, init)\
		dptbl->entries[index].init = init

#define DPTBL_IS_ENTRY_INIT(dptbl, index)\
		dptbl->entries[index].init

#define DPTBL_GET_ABS_INDEX(dptbl, index)\
		dptbl->entries[index].abs_index

#define NUM_OF_BYTES_PER_TBL_ENTRY 	64
#define NUM_OF_BYTES_PER_TID 		32
#define TCAM_KEY_SIZE				(ctlu_get_tcam_key_size()+1)

#define TCAM_MAX_KEY_SIZE			56

#define DPTBL_TCM_GET_NUM_OF_ENTRIES(key_size)\
		((key_size/(TCAM_KEY_SIZE + 1)) + 1)

struct dptbl* create_tbl(struct dptbl_mng *dptbl_mng,
	struct dptbl_tmp_init_params *init_params);

#endif /*__DPTBL_H*/
