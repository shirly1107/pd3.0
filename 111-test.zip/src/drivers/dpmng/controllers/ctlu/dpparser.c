/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_malloc.h"
#include "fsl_io.h"
#include "ctlu_common.h"
#include "ctlu.h"
#include "dpparser_sw_seq.h"
#include "parser_ctrl.h"
#include "dpsparser.h"

#ifndef OBSOLETED_SP_API
static void dpparser_load_lib_parsers(struct dpparser *dpparser);
#endif	/* OBSOLETED_SP_API */

/******************************************************************************/
struct hxs_code_prot {
	enum net_prot	prot;
	uint16_t	code;
};

const struct hxs_code_prot hxs_codes[] = {
	{NET_PROT_ETH, HXS_ETH},
	{NET_PROT_LLC_SNAP, HXS_LLC_SNAP},
	{NET_PROT_VLAN, HXS_VLAN},
	{NET_PROT_PPPOE, HXS_PPPOE_PPP},
	{NET_PROT_PPP, HXS_PPPOE_PPP},
	{NET_PROT_MPLS, HXS_MPLS},
	{NET_PROT_ARP, HXS_ARP},
	{NET_PROT_IP, HXS_IP},
	{NET_PROT_IPV4, HXS_IPV4},
	{NET_PROT_IPV6, HXS_IPV6},
	{NET_PROT_GRE, HXS_GRE},
	{NET_PROT_MINENCAP, HXS_MINENCAP},
	{NET_PROT_TCP, HXS_TCP},
	{NET_PROT_UDP, HXS_UDP},
	{NET_PROT_IPSEC_AH, HXS_IPSEC},
	{NET_PROT_IPSEC_ESP, HXS_IPSEC},
	{NET_PROT_SCTP, HXS_SCTP},
	{NET_PROT_DCCP, HXS_DCCP},
	{NET_PROT_GTP, HXS_GTP},
	{NET_PROT_UDP_ENC_ESP, HXS_ESP},
	{NET_PROT_USER_DEFINED_L3, HXS_OTHER_L3_SHELL},
	{NET_PROT_USER_DEFINED_L4, HXS_OTHER_L4_SHELL}
};

/******************************************************************************/
#ifdef	DUMP_PROFILE
void dump_profile(struct dpparser_profile_map *pr, int id, const char *what)
{
	int		i;
	uint8_t		*pch;

	fsl_print("Dump of parse profile ID %d [%s]\n", id, what);
/*#define PP_ROW_DUMP*/
#ifdef PP_ROW_DUMP
	/* Row dump */
	pch = (uint8_t *)&pr->start_hxs;
	fsl_print("\t 00 : ");
	for (i = 0; i < sizeof(struct dpparser_profile_map); i++) {
		fsl_print("%02x ", *pch++);
		if (!((i + 1) % 16))
			fsl_print("\n\t %02x : ", i + 1);
	}
	fsl_print("\n");
#endif	/* PP_ROW_DUMP */
	fsl_print("\t start_hxs       = 0x%08x\n", pr->start_hxs);
	fsl_print("\t enet_hxs        = 0x%04x\n", pr->enet_hxs);
	fsl_print("\t llc_snap_hxs    = 0x%04x\n", pr->llc_snap_hxs);
	fsl_print("\t vlan_hxs_base   = 0x%04x\n", pr->vlan_hxs_base);
	fsl_print("\t vlan_tpid1      = 0x%04x\n", pr->vlan_tpid1);
	fsl_print("\t vlan_tpid2      = 0x%04x\n", pr->vlan_tpid2);
	fsl_print("\t ppp_hxs         = 0x%04x\n", pr->ppp_hxs);
	fsl_print("\t mpls_hxs        = 0x%08x\n", pr->mpls_hxs);
	fsl_print("\t arp_hxs         = 0x%04x\n", pr->arp_hxs);
	fsl_print("\t ip_hxs          = 0x%04x\n", pr->ip_hxs);
	fsl_print("\t ipv4_hxs        = 0x%04x\n", pr->ipv4_hxs);
	fsl_print("\t ipv6_hxs        = 0x%04x\n", pr->ipv6_hxs);
	fsl_print("\t gre_hxs         = 0x%04x\n", pr->gre_hxs);
	fsl_print("\t minenc_hxs      = 0x%04x\n", pr->minenc_hxs);
	fsl_print("\t other_l3_hxs    = 0x%04x\n", pr->other_l3_hxs);
	fsl_print("\t tcp_hxs         = 0x%04x\n", pr->tcp_hxs);
	fsl_print("\t udp_hxs         = 0x%04x\n", pr->udp_hxs);
	fsl_print("\t ipsec_hxs       = 0x%04x\n", pr->ipsec_hxs);
	fsl_print("\t sctp_hxs        = 0x%04x\n", pr->sctp_hxs);
	fsl_print("\t dccp_hxs        = 0x%04x\n", pr->dccp_hxs);
	fsl_print("\t other_l4_hxs    = 0x%04x\n", pr->other_l4_hxs);
	fsl_print("\t gtp_hxs         = 0x%04x\n", pr->gtp_hxs);
	fsl_print("\t esp_hxs         = 0x%04x\n", pr->esp_hxs);
	fsl_print("\t vxlan_hxs       = 0x%04x\n", pr->vxlan_hxs);
	fsl_print("\t l5_shell_hxs    = 0x%04x\n", pr->l5_shell_hxs);
	fsl_print("\t final_shell_hxs = 0x%04x\n", pr->final_shell_hxs);
	fsl_print("\t soft_seq_params = ");
	pch = (uint8_t *)&pr->soft_seq_params[0];
	for (i = 0; i < 16 * sizeof(uint32_t); i++) {
		fsl_print("%02x ", *pch++);
		if (!((i + 1) % 16))
			fsl_print("\n\t                   ");
	}
	fsl_print("\n");
}
#endif	/* DUMP_PROFILE */

/******************************************************************************/
static void init_profile_shadow(struct dpparser *dpparser,
	int profile_id,
	const struct dpparser_profile_map *profile)
{
	if( !dpparser->shadow[profile_id].used ) {
		dpparser->shadow[profile_id].profile =
				(struct dpparser_profile_map *)fsl_malloc(
				sizeof(struct dpparser_profile_map));
	}

	memcpy(dpparser->shadow[profile_id].profile, profile,
		sizeof(struct dpparser_profile_map));

	dpparser->shadow[profile_id].used = 1;
}

static void delete_profile_shadow(struct dpparser *dpparser,
	int profile_id)
{
	fsl_free(dpparser->shadow[profile_id].profile);
	dpparser->shadow[profile_id].used = 0;
}

static void query_profile(struct dpparser *dpparser,
	int profile_id,
	int *exist, struct dpparser_profile_map **profile)
{
	*exist = dpparser->shadow[profile_id].used;
	if (*exist)
		*profile = dpparser->shadow[profile_id].profile;
}

static uint16_t *get_hxs_ptr(struct dpparser_profile_map *dpparser_profile_map,
                             enum hxs_code hxs)
{
	struct hxs_ptr hxs_ptrs[] = {
		{HXS_ETH, (uint16_t*)&dpparser_profile_map->enet_hxs},
		{HXS_LLC_SNAP,
		 	 (uint16_t*)&dpparser_profile_map->llc_snap_hxs},
		{HXS_VLAN,
		 	 (uint16_t*)&dpparser_profile_map->vlan_hxs_base},
		{HXS_PPPOE_PPP, (uint16_t*)&dpparser_profile_map->ppp_hxs},
		{HXS_MPLS, (uint16_t*)&dpparser_profile_map->mpls_hxs},
		{HXS_ARP, (uint16_t*)&dpparser_profile_map->arp_hxs},
		{HXS_IP, (uint16_t*)&dpparser_profile_map->ip_hxs},
		{HXS_IPV4, (uint16_t*)&dpparser_profile_map->ipv4_hxs},
		{HXS_IPV6, (uint16_t*)&dpparser_profile_map->ipv6_hxs},
		{HXS_GRE, (uint16_t*)&dpparser_profile_map->gre_hxs},
		{HXS_MINENCAP,
		 	 (uint16_t*)&dpparser_profile_map->minenc_hxs},
		{HXS_OTHER_L3_SHELL,
			 (uint16_t*)&dpparser_profile_map->other_l3_hxs},
		{HXS_TCP, (uint16_t*)&dpparser_profile_map->tcp_hxs},
		{HXS_UDP, (uint16_t*)&dpparser_profile_map->udp_hxs},
		{HXS_IPSEC,
		 	 (uint16_t*)&dpparser_profile_map->ipsec_hxs},
		{HXS_SCTP, (uint16_t*)&dpparser_profile_map->sctp_hxs},
		{HXS_DCCP, (uint16_t*)&dpparser_profile_map->dccp_hxs},
		{HXS_OTHER_L4_SHELL,
		 	 (uint16_t*)&dpparser_profile_map->other_l4_hxs},
		{HXS_GTP, (uint16_t*)&dpparser_profile_map->gtp_hxs},
		{HXS_ESP,
		 	 (uint16_t*)&dpparser_profile_map->esp_hxs},
		{HXS_VXLAN, (uint16_t*)&dpparser_profile_map->vxlan_hxs},
		{HXS_L5_SHELL, (uint16_t*)&dpparser_profile_map->l5_shell_hxs},
		{HXS_FINAL_SHELL, (uint16_t*)&dpparser_profile_map->final_shell_hxs},
	};

	int i = 0, size = ARRAY_SIZE(hxs_ptrs);

	while ( (i < size) && (hxs_ptrs[i].code != hxs) ) i++;

	CHECK_COND_RETVAL(i != size, NULL);
	
	return hxs_ptrs[i].ptr;
}

static void build_dpparser_profile(
	const struct dpparser_profile_opt_cfg *input_cfg,
        struct dpparser_profile_map *regs)
{
	uint16_t *hxs_ptr;
	int i;
	struct dpparser_profile_opt_cfg def_cfg, *cfg;

	memset(regs, 0, sizeof(struct dpparser_profile_map));

	if (input_cfg == NULL)
	{
		cfg = &def_cfg;
		/* an all "0" cfg structure represents the default
		 * configuration */
		memset(&def_cfg, 0, sizeof(def_cfg));
		/*Initialize DA with correct valid VxLAN UDP Dest Port */
		def_cfg.vxlan_da[0] = DPPAPRSER_DEF_VXLAN;
		def_cfg.vxlan_da[1] = DPPAPRSER_DEF_VXLAN;
	}
	else
	{
		cfg = (struct dpparser_profile_opt_cfg *)input_cfg;
	}

	for (i = 0; i < cfg->num_of_disable_fd_err_report; i++) {
		hxs_ptr = get_hxs_ptr(regs, cfg->disable_fd_err_report[i]);
		 /* Legality was checked by calling rotuine */
		*hxs_ptr = HXS_DISABLE_ERR_REPORT;
	}

	if (cfg->vlan_tpid[0]) {
		hxs_ptr = get_hxs_ptr(regs, HXS_VLAN);
		*(hxs_ptr + 1) |= cfg->vlan_tpid[0];
	}
	if (cfg->vlan_tpid[1]) {
		hxs_ptr = get_hxs_ptr(regs, HXS_VLAN);
		*(hxs_ptr + 2) |= cfg->vlan_tpid[1];
	}
	
	if (cfg->vxlan_da[0]) {
		hxs_ptr = get_hxs_ptr(regs, HXS_VXLAN);
		*(hxs_ptr) |= cfg->vxlan_da[0];
	}
	if (cfg->vxlan_da[1]) {
		hxs_ptr = get_hxs_ptr(regs, HXS_VXLAN);
		*(hxs_ptr + 1) |= cfg->vxlan_da[1];
	}
	
	if (cfg->options & DPPARSER_IPV6_ROUTE_HDR_ENABLE) {
		hxs_ptr = get_hxs_ptr(regs, HXS_IPV6);
		*hxs_ptr |= HXS_IPV6_RHE;
	}
	if (!(cfg->options & DPPARSER_PPP_DISABLE_MTU_CHECK)) {
		hxs_ptr = get_hxs_ptr(regs, HXS_PPPOE_PPP);
		*hxs_ptr |= HXS_PPP_EMC;
	}
	if (cfg->options & DPPARSER_L4_IGNORE_PAD_FOR_CHECKSUM) {
		hxs_ptr = get_hxs_ptr(regs, HXS_UDP);
		*hxs_ptr |= HXS_L4_SPPR;
		hxs_ptr = get_hxs_ptr(regs, HXS_TCP);
		*hxs_ptr |= HXS_L4_SPPR;
	}
	if (!(cfg->options & DPPARSER_MPLS_LABEL_INTERPRETATION_DISABLE)) {
		hxs_ptr = get_hxs_ptr(regs, HXS_MPLS);
		*(hxs_ptr + 1) |= HXS_MPLS_LIE;
	}
	if (cfg->mpls_next_hxs != HXS_NULL) {
		hxs_ptr = get_hxs_ptr(regs, HXS_MPLS);
		*(hxs_ptr + 1) |= (cfg->mpls_next_hxs & HXS_MPLS_DNP_MASK);
	}
}

static void compare_profile(struct dpparser *dpparser,
	int profile_id,
	struct dpparser_profile_map *new_profile,
	int *match)
{
	struct dpparser_profile_map *current_profile;
	int exist = 1;

	ASSERT_COND(dpparser);

	query_profile(dpparser, profile_id, &exist, &current_profile);
	
	if ( exist && memcmp(new_profile, current_profile,
			sizeof(struct dpparser_profile_map)) == 0)
		*match = 1;
	else
		/* no match */
		*match = 0;
}

static void dpparser_layout_update_params(struct dpparser *dpparser, struct dpparser_ss_layout_entry *entry){
	int		i;
	
	for (i = 0; i < dpparser->ss_idx; i++) {
		if (entry->ss_offset == dpparser->ss_layout->ss_entry[i].ss_offset) {
			dpparser->ss_layout->ss_entry[i].param_offset = entry->param_offset;
			dpparser->ss_layout->ss_entry[i].param_size = entry->param_size;
			break;
		}
	}
}

#ifdef TKT011436
/**************************************************************************//**
 @Function     dpparser_restore
*//***************************************************************************/
int dpparser_restore(const struct dpparser_cfg *cfg, struct dpparser *dpparser)
{
	int			err;

	ASSERT_COND(cfg);

	err = parser_ctrl_config_parser(cfg, 1);
	if (err)
		return err;
	if (cfg->options & DPPARSER_CLK_POWER_DOWN_ENABLE) {
		pr_warn("Parser of type %d : stopped and clock power-down\n",
			(uint32_t)cfg->ctlu->type);
		return -EINVAL;;
	}
	
	/* TODO Consider configuring all profiles for MPLS support */
#ifndef OBSOLETED_SP_API
	dpparser_load_lib_parsers(dpparser);
#endif	/* OBSOLETED_SP_API */

	pr_debug("DPPARSER restore finished\n");
	dpparser->restore = 0;

	return err;
}
#endif /* TKT011436 */

struct dpparser *dpparser_init(const struct dpparser_cfg *cfg)
{
	struct dpparser		*dpparser;
	int			err;

	ASSERT_COND(cfg);
	dpparser = parser_ctrl_get_dpparser(cfg->ctlu->type);
	if (!dpparser) {
		pr_warn("A parser of %d type is not present\n",
			(uint32_t)cfg->ctlu->type);
		return NULL;
	}
	err = parser_ctrl_config_parser(cfg, 0);
	if (err)
		return NULL;
	if (cfg->options & DPPARSER_CLK_POWER_DOWN_ENABLE) {
		pr_warn("Parser of type %d : stopped and clock power-down\n",
			(uint32_t)cfg->ctlu->type);
		return NULL;
	}
	/* TODO Consider configuring all profiles for MPLS support */
#ifndef OBSOLETED_SP_API
	dpparser_load_lib_parsers(dpparser);
#endif	/* OBSOLETED_SP_API */
	return dpparser;
}

/******************************************************************************/
void dpparser_done(struct dpparser *dpparser)
{
	parser_ctrl_stop_parser(dpparser);
}


/************************************************************************//**
 @Function     dpparser_init_profile

 @Description  This function initializes the Parser-Profile module hardware
 registers.

 Note: This function should be called only once
 during the lifetime of the object

 @Param[in]    cfg_params   - Default Parser-Profile parameters as returned by
 dpparser_profile_defconfig and possibly modified by user
 prior to this routine's call
 @Param[in]    init_params  - MUST Parser-Profile parameters as defined by user

 @Retval       Error code.
 *//*************************************************************************/
int dpparser_init_profile(struct dpparser *dpparser,
                          int profile_id,
                          const void *cmd_if_cfg,
                          const struct dpparser_profile_opt_cfg *cfg)

{
	int i, cmd_err_code = 0, err = 0;
	struct dpparser_msg *dpparser_in_msg, *dpparser_out_msg;
	void *cmd_cfg;
	uint16_t status;
	uint32_t *mtypein_addr, mtypeout, cmd_code;

	if(cfg)
	{ /* check input legality */
		for (i = 0; i < cfg->num_of_disable_fd_err_report; i++)
			if (cfg->disable_fd_err_report[i] >= HXS_NULL || dpparser_check_hxs(cfg->disable_fd_err_report[i]))
				return -ENOTSUP;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dpparser->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&dpparser_in_msg,
	                             &mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;
	
	/* common building of parameters */
	memset(dpparser_in_msg, 0, sizeof(struct dpparser_msg));
	dpparser_in_msg->profile_id = (uint8_t)profile_id;

	cmd_err_code = ctlu_get_cmd_code(dpparser->ctlu, MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
	                                 &cmd_code);
	if (cmd_err_code)
		return cmd_err_code;

	dpparser_in_msg->mtype = (uint8_t)cmd_code;
	/* in this command, no input parameters are required except for
	 profile_id */
	*mtypein_addr = 0;
	/* Configures the parse profile parameters */
	build_dpparser_profile(cfg, &dpparser_in_msg->dpparser_profile_map);
	/* Creates the parse profile */
	cmd_err_code = ctlu_execute_cmd(dpparser->ctlu, cmd_if_cfg,
					cmd_cfg,
					MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
					&status, &mtypeout,
					(void **)&dpparser_out_msg);
	/* Put the profile in the shadow */
	if (!cmd_err_code)
		init_profile_shadow(dpparser, profile_id,
				    &dpparser_in_msg->dpparser_profile_map);
	/* Frees allocated data structures */
	err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;
	return 0;
}

/******************************************************************************/
int dpparser_attach_default_soft_parser(struct dpparser *dpparser, int profile_id,
				      uint16_t *start_pc, uint8_t is_egress, const void *cmd_if_cfg)
{
	uint8_t sp_profile[MAX_SP_PROFILE_ID_SIZE];
	memset(sp_profile, 0, MAX_SP_PROFILE_ID_SIZE);
	                
	/* If NULL is used for SP Profile name then the Default SP Profile is used */
	return dpparser_attach_soft_parser(dpparser, sp_profile, profile_id,
								start_pc, is_egress, cmd_if_cfg);
}

/******************************************************************************/
int dpparser_attach_soft_parser(struct dpparser *dpparser, uint8_t sp_profile[], 
			int profile_id, uint16_t *start_pc, uint8_t is_egress, const void *cmd_if_cfg)
{
	int				exist, cmd_err_code, err, i, pidx;
	void				*cmd_cfg;
	uint16_t			status, *hxs_ptr;
	uint32_t			*mtypein_addr, mtypeout, code;
	uint8_t				*pdst, name[9];
	struct dpparser_msg		*dpparser_in_msg, *dpparser_out_msg;
	struct dpparser_profile_map	*current_profile;
	struct dpsparser		*dpsparser;
	struct profile_info		*pinfo;
	struct profile_info 	profile_info;

	#define HXS_PTR(_str_ptr, _fld)	((uint16_t *)			\
		((uint32_t)(_str_ptr) +					\
		 (uint32_t)offsetof(struct dpparser_profile_map, _fld)))

	dpsparser = (struct dpsparser *)sys_get_handle(FSL_MOD_DPSPARSER, 1, 1);
	/* No DPSPARSER module registered */
	if (!dpsparser)
		return 0;
	
	switch (dpparser->ctlu->type) {
	case CTLU_EIOP_INGRESS:
		is_egress = 0;
		pr_info("Enable system WRIOP INGRESS SPs on PPID %d\n",
			profile_id);
		break;
	case CTLU_EIOP_EGRESS:
		is_egress = 0;
		pr_info("Enable system WRIOP EGRESS SPs on PPID %d\n",
			profile_id);
		break;
	case CTLU_AIOP:
		if (is_egress)
			pr_info("Prepare system AIOP EGRESS SPs on PPID %d\n",
				profile_id);
		else
			pr_info("Prepare system AIOP INGRESS SPs on PPID %d\n",
				profile_id);
		break;
	default:
		pr_warn("Parser of the %d type is not supported\n",
			(uint32_t)dpparser->ctlu->type);
		return 0;
	}
	/* Build SP parse profile */
	pinfo = &profile_info;
	memset(pinfo, 0, sizeof(struct profile_info));
	err = dpsparser_build_profile(dpsparser, dpparser->ctlu->type, sp_profile, pinfo);
	if (err)
		return err;
	
	/* Set attached Soft Parser */
	memcpy(dpparser->shadow[profile_id].sp_profile_id, sp_profile, MAX_SP_PROFILE_ID_SIZE);
	
	/* No soft parser enabled by default on this parser */
	if (!pinfo->proto_count) {
		pr_info("No system soft parsers configured\n");
		return 0;
	}

	/* There are enabled soft parsers in this default profile.
	 * Get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dpparser->ctlu, &cmd_cfg,
					  (void *)&dpparser_in_msg,
					  &mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;
	/* Get the profile content */
	query_profile(dpparser, profile_id, &exist, &current_profile);
	if (!exist)
		return -ENODEV;
	
	/* Enable system level soft parser on this profile. For every matching
	 * SP, set the enable bit and the starting PC in the current profile.
	 *
	 * A soft parser of the 'LNK_BEFORE_FIRST_HXS' kind, is not enabled
	 * trough an enable bit in the parse profile. However, its parameters,
	 *  if any must be written in the parameters array. */	
	for (i = 0; i < pinfo->proto_count; i++) {
		switch (pinfo->proto[i].lnk) {
		case LNK_ETH_HXS:
			hxs_ptr = HXS_PTR(current_profile, enet_hxs);
			break;
		case LNK_LLC_SNAP_HXS:
			hxs_ptr = HXS_PTR(current_profile, llc_snap_hxs);
			break;
		case LNK_VLAN_HXS:
			hxs_ptr = HXS_PTR(current_profile, vlan_hxs_base);
			break;
		case LNK_PPPOE_PPP_HXS:
			hxs_ptr = HXS_PTR(current_profile, ppp_hxs);
			break;
		case LNK_MPLS_HXS:
			hxs_ptr = HXS_PTR(current_profile, mpls_hxs);
			break;
		case LNK_ARP_HXS:
			hxs_ptr = HXS_PTR(current_profile, arp_hxs);
			break;
		case LNK_IP_HXS:
			hxs_ptr = HXS_PTR(current_profile, ip_hxs);
			break;
		case LNK_IPV4_HXS:
			hxs_ptr = HXS_PTR(current_profile, ipv4_hxs);
			break;
		case LNK_IPV6_HXS:
			hxs_ptr = HXS_PTR(current_profile, ipv6_hxs);
			break;
		case LNK_GRE_HXS:
			hxs_ptr = HXS_PTR(current_profile, gre_hxs);
			break;
		case LNK_MINENCAP_HXS:
			hxs_ptr = HXS_PTR(current_profile, minenc_hxs);
			break;
		case LNK_OTHER_L3_SHELL_HXS:
			hxs_ptr = HXS_PTR(current_profile, other_l3_hxs);
			break;
		case LNK_TCP_HXS:
			hxs_ptr = HXS_PTR(current_profile, tcp_hxs);
			break;
		case LNK_UDP_HXS:
			hxs_ptr = HXS_PTR(current_profile, udp_hxs);
			break;
		case LNK_IPSEC_HXS:
			hxs_ptr = HXS_PTR(current_profile, ipsec_hxs);
			break;
		case LNK_SCTP_HXS:
			hxs_ptr = HXS_PTR(current_profile, sctp_hxs);
			break;
		case LNK_DCCP_HXS:
			hxs_ptr = HXS_PTR(current_profile, dccp_hxs);
			break;
		case LNK_OTHER_L4_SHELL_HXS:
			hxs_ptr = HXS_PTR(current_profile, other_l4_hxs);
			break;
		case LNK_GTP_HXS:
			hxs_ptr = HXS_PTR(current_profile, gtp_hxs);
			break;
		case LNK_ESP_HXS:
			hxs_ptr = HXS_PTR(current_profile, esp_hxs);
			break;
		case LNK_VXLAN_HXS:
			hxs_ptr = HXS_PTR(current_profile, vxlan_hxs);
			break;
		case LNK_L5_SHELL_HXS:
			hxs_ptr = HXS_PTR(current_profile, l5_shell_hxs);
			break;
		case LNK_FINAL_SHELL_HXS:
			hxs_ptr = HXS_PTR(current_profile, final_shell_hxs);
			break;
		case LNK_BEFORE_FIRST_HXS:
			hxs_ptr = HXS_PTR(current_profile, start_hxs);
			break;
		default:
			hxs_ptr = 0;
			break;
		}
		if (!hxs_ptr) {
			pr_warn("Invalid 0x%x HXS detected - Skipped !\n",
				(uint32_t)pinfo->proto[i].lnk);
			continue;
		}
		memcpy(&name[0], &pinfo->proto[i].name[0], 8);
		name[8] = '\0';
		if (pinfo->proto[i].lnk != LNK_BEFORE_FIRST_HXS) {
			/* Set the 'enable' bit and soft sequence start PC
			 * address */
			*hxs_ptr |= HXS_EN_SOFT_SEQ;
			*hxs_ptr |= (pinfo->proto[i].pc & HXS_EN_SOFT_SEQ_MASK);
			pr_info("'%s' : HXS = 0x%x PC = 0x%x Parameters = %d\n",
				name, (uint32_t)pinfo->proto[i].lnk,
				pinfo->proto[i].pc,
				pinfo->proto[i].num_params);
		} else {
			if (start_pc)
				*start_pc = pinfo->proto[i].pc;

			/* Set start_hxs for attached Soft Parser */
			dpparser->shadow[profile_id].start_hxs = pinfo->proto[i].pc;
			
			pr_info("'%s' : HXS = none PC = 0x%x Parameters = %d\n",
				name, pinfo->proto[i].pc,
				pinfo->proto[i].num_params);
		}
		/* Set the SP parameters values (if any) */
		for (pidx = 0; pidx < pinfo->proto[i].num_params; pidx++) {
			pdst = (uint8_t *)((uint32_t)HXS_PTR(current_profile,
							     soft_seq_params));
			pdst += pinfo->proto[i].par_array[pidx].offset;
			/* Store parameter value */
			if (pinfo->proto[i].par_array[pidx].size)
				memcpy(pdst,
				       pinfo->proto[i].par_array[pidx].value,
				       pinfo->proto[i].par_array[pidx].size);
			/* Log information */
			memcpy(&name[0],
			       &pinfo->proto[i].par_array[pidx].name[0], 8);
			name[8] = '\0';
			pr_info("'%s' : O = %d S = %d V = %02x %02x %02x ...\n",
				name,
				pinfo->proto[i].par_array[pidx].offset,
				pinfo->proto[i].par_array[pidx].size,
				pinfo->proto[i].par_array[pidx].value[0],
				pinfo->proto[i].par_array[pidx].value[1],
				pinfo->proto[i].par_array[pidx].value[2]);
		}
	}

	if (dpparser->ctlu->type == CTLU_AIOP) {
		if (is_egress)
			dump_profile(current_profile, profile_id,
				     "AIOP EGRESS");
		else
			dump_profile(current_profile, profile_id,
				     "AIOP INGRESS");
	} else {
		dump_profile(current_profile, profile_id, "WRIOP");
	}
	
	/* Update the current profile */
	memcpy(&dpparser_in_msg->dpparser_profile_map, current_profile,
	       sizeof(struct dpparser_profile_map));
	dpparser_in_msg->profile_id = (uint8_t)profile_id;
	cmd_err_code =
		ctlu_get_cmd_code(dpparser->ctlu,
				  MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
				  &code);
	if (cmd_err_code)
		return cmd_err_code;
	dpparser_in_msg->mtype = (uint8_t)code;
	dpparser_out_msg = NULL;
	cmd_err_code =
		ctlu_execute_cmd(dpparser->ctlu, cmd_if_cfg, cmd_cfg,
				 MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
				 &status, &mtypeout,
				 (void **)&dpparser_out_msg);
	err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;
	
	return 0;
}

/******************************************************************************/
int dpparser_is_valid_sp_profile_id(struct dpparser *dpparser, uint8_t sp_profile[])
{
	int err;
	struct dpsparser		*dpsparser;
	struct profile_info		*pinfo;

	dpsparser = (struct dpsparser *)sys_get_handle(FSL_MOD_DPSPARSER, 1, 1);
	/* No DPSPARSER module registered */
	if (!dpsparser)
		return 0;

	/* Find SP Profile */
	err = dpsparser_get_profile_by_name(dpsparser, dpparser->ctlu->type, sp_profile, &pinfo);
	if (err)
		return err;

	return 0;
}

/******************************************************************************/
int dpparser_get_profile_map(struct dpparser *dpparser, int profile_id,
			     struct dpparser_profile_map **profile)
{
	int	exist;

	/* Get the profile content */
	query_profile(dpparser, profile_id, &exist, profile);
	if (!exist)
		return -ENODEV;
	return 0;
}

int dpparser_delete_profile(struct dpparser *dpparser,
                            int profile_id,
                            const void *cmd_if_cfg)
{
	struct dpparser_profile_opt_cfg cfg;
	int err;

	ASSERT_COND(dpparser);

	/* Deleting a profile is just like initialzing an all "0"
	 * profile
	 */
	memset(&cfg, 0, sizeof(cfg));

	err = dpparser_init_profile(dpparser,
	                             profile_id,
	                             cmd_if_cfg,
	                             &cfg);
	
	if (!err)
		delete_profile_shadow(dpparser, profile_id);
	
	return err;
}

int dpparser_find_profile(struct dpparser *dpparser,
	const void *cmd_if_cfg,
	void *attr,
	int start_from,
	int *match_id)
{
	int match = 0;
	int i = 0;
	struct dpparser_profile_map dpparser_profile_new;
	struct dpparser_profile_opt_cfg *cfg =
		(struct dpparser_profile_opt_cfg *)attr;

	/* set new Profile parameters */
	build_dpparser_profile(cfg, &dpparser_profile_new);


	*match_id = -1;

	for (i = start_from; i < dpparser->num_profiles; i++)
	{
		compare_profile(dpparser, 
				       i, 
				       &dpparser_profile_new, 
				       &match);
		if (match)
		{
			*match_id = i;
			return 0;
		}
	}

	return -ENODEV;
}


int dpparser_add_tpid(struct dpparser *dpparser,
	int profile_id,
	const void *cmd_if_cfg,
	uint16_t tpid)
{
	int cmd_err_code = 0, err = 0;
	struct dpparser_msg *dpparser_in_msg, *dpparser_out_msg = NULL;
	void *cmd_cfg;
	uint16_t status;
	uint32_t *mtypein_addr, mtypeout, code;
	struct dpparser_profile_map *current_profile;
	int exist;

	ASSERT_COND(dpparser);

	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dpparser->ctlu, &cmd_cfg,
						(void*)&dpparser_in_msg,
						&mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;

	query_profile(dpparser, profile_id, &exist, &current_profile);
	if (!exist)
	{	
		err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
		if (err)
			pr_err("ctlu_free_cmd_cfg failed\n");
		return -ENODEV;

	}

	/* check if not full and if new TPID doesn't exist */
	if ((current_profile->vlan_tpid1 == 0) && 
		(current_profile->vlan_tpid2 != tpid))
			current_profile->vlan_tpid1 = tpid;
	else if ((current_profile->vlan_tpid2 == 0) && 
		(current_profile->vlan_tpid1 != tpid))
			current_profile->vlan_tpid2 = tpid;
	else
	{
		pr_err("No free TPID\n");
		err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
		if (err)
			pr_err("ctlu_free_cmd_cfg failed\n");
		return -EBUSY;
	}

	/* build a new input message basd on the current profile */
	memcpy(&dpparser_in_msg->dpparser_profile_map, current_profile,
		sizeof(struct dpparser_profile_map));
	dpparser_in_msg->profile_id = (uint8_t)profile_id;

	cmd_err_code = ctlu_get_cmd_code(
		dpparser->ctlu, MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
		&code);
	if (cmd_err_code)
	{	
		err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
		if (err)
			pr_err("ctlu_free_cmd_cfg failed\n");
		return cmd_err_code;

	}
	dpparser_in_msg->mtype = (uint8_t)code;

	cmd_err_code = ctlu_execute_cmd(dpparser->ctlu, cmd_if_cfg, cmd_cfg,
	/* interface handle */
	MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
					&status, &mtypeout,
					(void**)&dpparser_out_msg);
	err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;

	return 0;
}

int dpparser_remove_tpid(struct dpparser *dpparser,
	int profile_id,
	const void *cmd_if_cfg,
	uint16_t tpid)
{
	int cmd_err_code = 0, err = 0;
	struct dpparser_msg *dpparser_in_msg, *dpparser_out_msg = NULL;
	void *cmd_cfg;
	uint16_t status;
	uint32_t *mtypein_addr, mtypeout, code;
	struct dpparser_profile_map *current_profile;
	int exist;

	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dpparser->ctlu, &cmd_cfg,
						(void*)&dpparser_in_msg,
						&mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;

	query_profile(dpparser, profile_id, &exist, &current_profile);
	if (!exist)
	{	
		err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
		if (err)
			pr_err("ctlu_free_cmd_cfg\n");
		return -ENODEV;
	}

	/* check if TPID available */
	if ((current_profile->vlan_tpid1 == tpid) || tpid == 0)
		current_profile->vlan_tpid1 = 0;
	else
		if ((current_profile->vlan_tpid2 == tpid) || tpid == 0)
			current_profile->vlan_tpid2 = 0;
		else
		{	
			err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
			if (err)
				pr_err("ctlu_free_cmd_cfg\n");
			return -ENAVAIL;
		}


	/* build a new input message based on the current profile */
	memcpy(&dpparser_in_msg->dpparser_profile_map, current_profile,
		sizeof(struct dpparser_profile_map));
	dpparser_in_msg->profile_id = (uint8_t)profile_id;
	cmd_err_code = ctlu_get_cmd_code(
		dpparser->ctlu, MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
		&code);
	if (cmd_err_code)
	{	
		err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
		if (err)
			pr_err("ctlu_free_cmd_cfg\n");
		return cmd_err_code;
	}
	dpparser_in_msg->mtype = (uint8_t)code;

	cmd_err_code = ctlu_execute_cmd(dpparser->ctlu, cmd_if_cfg, cmd_cfg,
	/* interface handle */
	MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
					&status, &mtypeout,
					(void**)&dpparser_out_msg);
	err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;

	return 0;
}

int dpparser_get_tpid(struct dpparser *dpparser,
		int profile_id,
		uint16_t *tpid1, uint16_t *tpid2)
{
	int cmd_err_code = 0, err = 0;
	struct dpparser_profile_map *current_profile;
	int exist;

	ASSERT_COND(dpparser);

	query_profile(dpparser, profile_id, &exist, &current_profile);
	if (!exist)
	{
		return -ENODEV;

	}

	*tpid1 = current_profile->vlan_tpid1;
	*tpid2 = current_profile->vlan_tpid2;

	return 0;
}

int dpparser_check_hxs(uint16_t hxs) {
	/*There is a reserved zone in 0x15-0x1D and the 0x7FE value*/
	if ((hxs > 0x14 && hxs < 0x1e) ||
			hxs == 0x7FE) {
		pr_err("HXS has a reserved value\n");
		return -EINVAL;
	}
	
	return 0;
}

void dpparser_get_resource_str(struct dpparser *dpparser, char *res_type)
{
	char str[16];
	
	ctlu_get_str(ctlu_get_iop_id(dpparser->ctlu),
			ctlu_get_type(dpparser->ctlu), str);
	
	snprintf(res_type, sizeof(str), "prp.%s", str);
}

int dpparser_get_hdr_code(enum net_prot prot, uint16_t *code)
{
	int i = 0, size = ARRAY_SIZE(hxs_codes);

	while ((hxs_codes[i].prot != prot) && (++i < size)) ;

	if (i == size)
		return -EINVAL;
	else
	{
		*code = hxs_codes[i].code;
		return 0;
	}
}

int dpparser_get_hdr_prot(uint16_t code, enum net_prot *prot)
{
	int i = 0, size = ARRAY_SIZE(hxs_codes), err = 0;
	
	err = dpparser_check_hxs(code);
	CHECK_COND_RETVAL(err == 0, err);

	while ((hxs_codes[i].code != code) && (++i < size)) ;

	if (i == size)
		*prot = NET_PROT_NONE;
	else
		*prot = hxs_codes[i].prot;	
	
	return 0;
}

#ifndef OBSOLETED_SP_API
/******************************************************************************/
static void dpparser_layout_add_entry(struct dpparser *dpparser,
				      struct dpparser_ss_layout_entry *entry)
{
	if (dpparser->ss_idx < DPPARSER_MAX_SP) {
		dpparser->ss_layout->ss_entry[dpparser->ss_idx].ss_offset =
				entry->ss_offset;
		dpparser->ss_layout->ss_entry[dpparser->ss_idx].ss_size =
				entry->ss_size;
		dpparser->ss_idx++;
	} else {
		pr_warn("Can't manage soft parser. Out of range\n");
	}
}

/******************************************************************************/
static void dpparser_load_lib_parsers(struct dpparser *dpparser)
{
	struct dpparser_ss_layout_entry		lib_entry;
	struct soft_parser			sp;
	int					err;

	/* Loads SP library byte-code at the end of instructions memory */
	sp.pc = 0x73c;
	sp.byte_code = &sp_wriop_lib_parsers[0];
	sp.size = sizeof(sp_wriop_lib_parsers);
	pr_info("Load SP library\n");
	err = parser_ctrl_load_soft_parser(&sp, dpparser->ctlu->type);
	if (err) {
		pr_info("SP library not loaded\n");
	} else {
		pr_info("SP library loaded\n");
		/* Add library to layout at init stage, not restore stage*/
		if(!dpparser->restore){
			lib_entry.ss_offset = sp.pc;
			lib_entry.ss_size = sp.size;
			dpparser_layout_add_entry(dpparser, &lib_entry);
		}
	}
}

/******************************************************************************/
static int dpparser_check_sw_seq(struct dpparser *dpparser,
				 struct dpparser_sw_seq_info *ss_info)
{
	if (ss_info->pc < dpparser->min_pc || ss_info->pc >= dpparser->max_pc) {
		pr_err("Invalid starting PC 0x%x (< 0x%x or >= 0x%x)\n",
		       ss_info->pc, dpparser->min_pc, dpparser->max_pc);
		return -EINVAL;
	}
	if (!ss_info->size) {
		pr_err("SP size is 0\n");
		return -EINVAL;
	}
	if (ss_info->size % 4) {
		pr_err("SP size %d is not 4 multiple\n", ss_info->size);
		return -EINVAL;
	}
	if ((DIV_CEIL(ss_info->size, 2) + ss_info->pc) >= dpparser->max_pc) {
		pr_err("SP code exceeds maximum PC (>= 0x%x)\n",
		       dpparser->max_pc);
		return -EINVAL;
	}
	return 0;
}

/******************************************************************************/
int dpparser_load_sw_seq(struct dpparser *dpparser,
			 struct dpparser_sw_seq_info *ss_info)
{
	int					err;
	struct dpparser_ss_layout_entry		entry;
	struct soft_parser			sp;

	err = dpparser_check_sw_seq(dpparser, ss_info);
	CHECK_COND_RETVAL(err == 0, err);
	/* Loads SP in parser instructions memory */
	sp.pc = ss_info->pc;
	sp.byte_code = ss_info->byte_code;
	sp.size = ss_info->size;
	pr_info("Load Soft Parser\n");
	err = parser_ctrl_load_soft_parser(&sp, dpparser->ctlu->type);
	if (err) {
		pr_info("Soft Parser not loaded\n");
	} else {
		pr_warn("Soft Parser loaded\n");
		/* Add library to layout */
		entry.ss_offset = sp.pc;
		entry.ss_size = sp.size;
		dpparser_layout_add_entry(dpparser, &entry);
	}
	return 0;
}

/******************************************************************************/
int dpparser_enable_sw_seq(struct dpparser *dpparser, int profile_id,
			   const void *cmd_if_cfg,
			   struct dpparser_sw_seq_profile_info *ss_pr_info)
{
	int				cmd_err_code, err;
	struct dpparser_msg		*dpparser_in_msg,
					*dpparser_out_msg = NULL;
	void				*cmd_cfg;
	uint16_t			status;
	uint32_t			*mtypein_addr, mtypeout, code;
	uint16_t			*hxs_ptr;
	uint8_t				*param_load_addr;
	struct dpparser_profile_map	*current_profile;
	int				exist;
	struct dpparser_ss_layout_entry	entry;

	/* Get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = ctlu_build_cmd_cfg(dpparser->ctlu, &cmd_cfg,
					  (void *)&dpparser_in_msg,
					  &mtypein_addr);
	if (cmd_err_code)
		return cmd_err_code;
	query_profile(dpparser, profile_id, &exist, &current_profile);
	if (!exist)
		return -ENODEV;
	if (ss_pr_info->hxs != HXS_NULL) {
		hxs_ptr = get_hxs_ptr(current_profile, ss_pr_info->hxs);
		ASSERT_COND(hxs_ptr);
		if (ss_pr_info->start_pc == 0)
			*hxs_ptr &= ~(HXS_EN_SOFT_SEQ);
		else
			*hxs_ptr |= HXS_EN_SOFT_SEQ;
		*hxs_ptr |= (ss_pr_info->start_pc & HXS_EN_SOFT_SEQ_MASK);
	}
	if (ss_pr_info->param_size > 0 && ss_pr_info->start_pc != 0) {
		/* Copy ss parameters in profile */
		param_load_addr = (uint8_t *)
				PTR_MOVE(current_profile->soft_seq_params,
					 ss_pr_info->param_offset);
		memcpy(param_load_addr, ss_pr_info->param_array,
		       ss_pr_info->param_size);
		/* Update parameters in layout */
		entry.param_offset = ss_pr_info->param_offset;
		entry.param_size = ss_pr_info->param_size;
		entry.ss_offset = ss_pr_info->start_pc;
		dpparser_layout_update_params(dpparser, &entry);
	}
	/* Build a new input message based on the current profile */
	memcpy(&dpparser_in_msg->dpparser_profile_map, current_profile,
	       sizeof(struct dpparser_profile_map));
	dpparser_in_msg->profile_id = (uint8_t)profile_id;
	cmd_err_code =
		ctlu_get_cmd_code(dpparser->ctlu,
				  MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
				  &code);
	if (cmd_err_code)
		return cmd_err_code;
	dpparser_in_msg->mtype = (uint8_t)code;
	cmd_err_code =
		ctlu_execute_cmd(dpparser->ctlu, cmd_if_cfg, cmd_cfg,
				 MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
				 &status, &mtypeout,
				 (void **)&dpparser_out_msg);
	err = ctlu_free_cmd_cfg(dpparser->ctlu, cmd_cfg);
	if (cmd_err_code)
		return cmd_err_code;
	if (err)
		return err;
	return 0;
}

#endif	/* OBSOLETED_SP_API */
