/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_timer.h"
#include "common/fsl_string.h"
#include "fsl_io.h"
#include "fsl_platform.h"
#include "fsl_eiop_ifp.h"
#include "fsl_resman.h"
#include "fsl_dpmng_mc.h"
#include "fsl_eiop_rtc.h"
#include "fsl_timer.h"
#include "ctlu.h"
#include "dpparser.h"

/************************************************/
/***********     EIOP Routines     **************/
/************************************************/
static uint32_t get_timestamp_period_eiop(struct ctlu *ctlu)
{
	struct eiop_rtc *eiop_rtc;
	uint32_t period;
	eiop_rtc = sys_get_handle(FSL_MOD_EIOP_RTC,
	               1, ctlu->iop_id);
	if (eiop_rtc == NULL)
	{
		pr_err("No timer available");
		return 0;
	}
	period = eiop_rtc_get_timestamp_period(eiop_rtc);
	/* move "period" to reflect the relevant portion of the timestamp
	 * as defind in the timestamp window register. */
	return (period << ioread32(&ctlu->ctrl_regs->iop_ctimestamp));
}

static int enq_deq(struct eiop_mng_cmd_cfg *eiop_mng_cmd_cfg, void *ring, struct eiop_ifp_desc *ifp_desc)
{
	int ret_code = 0, tries;
	uint16_t index;

	/* call IFP routine to enqueue command */
	/* wait (in fact 10 usec is enough) */
	tries = 1000;
	do {
		ret_code = ifp_mng_cmd_enqueue(ifp_desc, ring,
						eiop_mng_cmd_cfg, &index);
		timer_udelay(1);
	} while ((ret_code == -EBUSY) && tries--);

	if (ret_code == -EBUSY)
		return -ETIMEDOUT;

	/* wait until command is completed */
	/* wait (in fact 10 usec is enough) */
	tries = 1000;
	do {
		ret_code = ifp_mng_cmd_try_dequeue(ifp_desc, ring, index,
							eiop_mng_cmd_cfg);
		timer_udelay(1);
	} while ((ret_code == -EBUSY) && tries--);

	if (ret_code == -EBUSY)
		return -ETIMEDOUT;

	return ret_code;
}

static int get_eiop_cmd_code(enum ctlu_cmd_id cmd, uint32_t *code)
{
	int i;

	const struct ctlu_cmd_code_map ctlu_cmd_codes[] = {
		{MNG_CMD_DPTBL_CREATE, 0x004C},
		{MNG_CMD_DPTBL_PARAMS_QUERY, 0x0043},
		{MNG_CMD_DPTBL_DEL, 0x0042},
		{MNG_CMD_DPTBL_NEXT_RULEID_QUERY, 0x004F},
		{MNG_CMD_DPTBL_RULE_QUERY_WITH_RULEID, 0x0073},

		{MNG_CMD_DPTBL_RULE_CREATE, 0x007C},
		{MNG_CMD_DPTBL_RULE_CREATE_REPLACE, 0x007D},
		{MNG_CMD_DPTBL_RULE_REPLACE, 0x0076},
		{MNG_CMD_DPTBL_RULE_QUERY, 0x0077},
		{MNG_CMD_DPTBL_RULE_DEL, 0x0072},

		{MNG_CMD_DPTBL_TCAM_RULE_CREATE, 0x007D},
		{MNG_CMD_DPTBL_TCAM_RULE_MOVE, 0x007C},
		{MNG_CMD_DPTBL_TCAM_RULE_REPLACE, 0x0076},
		{MNG_CMD_DPTBL_TCAM_RULE_QUERY, 0x0077},
		{MNG_CMD_DPTBL_TCAM_RULE_DEL, 0x0072},

		{MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE, 0x00AD},
		{MNG_CMD_DPPARSER_PROFILE_QUERY, 0x00A7},
		{MNG_CMD_DPPARSER_PROFILE_DEL, 0x00A2},

		{MNG_CMD_DPPOLICY_RULE_CREATE_REPLACE, 0x002D},
		{MNG_CMD_DPPOLICY_RULE_QUERY, 0x0027},
		{MNG_CMD_DPPOLICY_RULE_DEL, 0x0022},
		{MNG_CMD_DPPOLICY_RULE_MOVE, 0x002c},

		{MNG_CMD_DPKG_RULE_CREATE_REPLACE, 0x003D},
		{MNG_CMD_DPKG_RULE_QUERY, 0x0037},

		{MNG_CMD_QOS_PROFILE_CREATE_UPDATE, 0x00CD},
		{MNG_CMD_QOS_PROFILE_QUERY, 0x00C7},

		{MNG_CMD_DPPOLICER_PROFILE_CREATE_UPDATE, 0x00D5},
		{MNG_CMD_DPPOLICER_PROFILE_QUERY, 0x00D7},
		{MNG_CMD_NULL_ACTION, 0x8000} };

	for (i = 0; i < ARRAY_SIZE(ctlu_cmd_codes); i++)
		if (ctlu_cmd_codes[i].cmd == cmd)
		{
			*code = ctlu_cmd_codes[i].code;
			return 0;
		}

	/*if (i == ARRAY_SIZE(ctlu_cmd_codes))*/
	return -EINVAL;
}

static int execute_cmd_eiop(struct ctlu *ctlu,
	const void *cmd_if,
	void *cmd_cfg,
	enum ctlu_cmd_id cmd,
	uint16_t *status,
	uint32_t *mtypeout,
	void **out_msg)

{
	int ret_code = 0;
	struct eiop_ifp_desc *ifp_desc;
	void *ring;
	struct eiop_mng_cmd_cfg *eiop_mng_cmd_cfg =
		(struct eiop_mng_cmd_cfg *)cmd_cfg;

	/* check if PCD resource has a private IFP */
	if (!cmd_if) {
		ring = ctlu->cmd_if_ring;
		ifp_desc = &ctlu->ifp_desc;
	} else {
		ring = ((struct eiop_ifp_cmd_if_cfg *)cmd_if)->cmd_if_ring;
		ifp_desc = ((struct eiop_ifp_cmd_if_cfg *)cmd_if)->ifp_desc;

	}

	/* initialize 'eiop_mng_cmd_cfg' - this structure holds all
	 * parameters required for issuing a management command
	 */
	ret_code = get_eiop_cmd_code(cmd, &eiop_mng_cmd_cfg->mng_cmd);
	if (ret_code)
		return ret_code;

	if (IS_CMD_SYNC(cmd))
		eiop_mng_cmd_cfg->option_flags |= MNG_CMD_IF_SYNC;
	/* set physical address for message */
	eiop_mng_cmd_cfg->msg_paddr = fsl_virt_to_phys(
		eiop_mng_cmd_cfg->msg_vaddr);
	/* We don't need to Clear output fields as they are overwritten. */
	/* mtypein & input message are already initialized by caller */

#ifdef ERR009038
	if ((!IS_SIM) && (cmd_if))
	{
		uint16_t index;

		ret_code = ifp_mng_cmd_enqueue(ifp_desc, ring,
								eiop_mng_cmd_cfg, &index);
		return ret_code;
	}
#endif
	ret_code = enq_deq(eiop_mng_cmd_cfg, ring, ifp_desc);

	*status = eiop_mng_cmd_cfg->status;
	*mtypeout = eiop_mng_cmd_cfg->mtypeout;
	*out_msg = eiop_mng_cmd_cfg->msg_vaddr;

	return ret_code;
}

static int build_cmd_cfg_eiop(struct ctlu *ctlu,
                              	void **cmd_cfg,
                                void **input_msg,
                                uint32_t **mtypein_addr)
{
	struct eiop_mng_cmd_cfg *eiop_mng_cmd_cfg;
	uint64_t tmp_addr;
	int err_code;

	/* Allocate 'eiop_mng_cmd_cfg' using a pre-initialized pool (slab). */
	err_code = slab_acquire(ctlu->slab, &tmp_addr);
	if (err_code)
		return err_code;
	eiop_mng_cmd_cfg = (struct eiop_mng_cmd_cfg *)UINT_TO_PTR(tmp_addr);

	memset(eiop_mng_cmd_cfg, 0, sizeof(struct eiop_mng_cmd_cfg));
	if (ctlu->type == CTLU_EIOP_EGRESS)
		eiop_mng_cmd_cfg->option_flags |= MNG_CMD_IF_EGRESS;

	/* return the addresses of parameters that need to be set by
	 * resource
	 */
	*input_msg = eiop_mng_cmd_cfg->msg_vaddr =
		PTR_MOVE(eiop_mng_cmd_cfg, sizeof(struct eiop_mng_cmd_cfg));

	*mtypein_addr = &eiop_mng_cmd_cfg->mtypein;

	*cmd_cfg = eiop_mng_cmd_cfg;

	return 0;

}

static int free_cmd_cfg_eiop(struct ctlu *ctlu, void *eiop_mng_cmd_cfg)
{
	/* release memory back to slab */
	return slab_release(ctlu->slab, (uint64_t)eiop_mng_cmd_cfg);
}

static int init_ifp(struct ctlu *ctlu,
	const struct ctlu_cfg *ctlu_cfg,
	int eiop_id)
{
	struct eiop_ifp_cfg ifp_init;
	struct resman_res_req req;
	int err, ifp_id;
	struct dpmng_amq	amq;

	memset(&ifp_init, 0, sizeof(ifp_init));
	memset(&req, 0, sizeof(req));

	/* get IFP for CTLU commands */
	strcpy(req.type, "ifp.wr0");
	req.num = 1;
	req.options = 0;
	err = resman_bind(ctlu_cfg->resman_device, &req, &ifp_id);
	if (err)
		return err;

	/* allocate command descriptors ring */
	ctlu->cmd_if_ring =
		(uint32_t *)fsl_xmalloc(MNG_CMD_RING_SIZE * MNG_CMD_DESC_SIZE,
			MEM_PART_SYSTEM_DDR1_NON_CACHEABLE,
			32);
	if (ctlu->cmd_if_ring == NULL) {
		pr_err("cmd_if_ring\n");
		return -ENOMEM;
	}
	memset(ctlu->cmd_if_ring, 0,
		(size_t)(MNG_CMD_RING_SIZE * MNG_CMD_DESC_SIZE));
	ifp_init.mng_cmd_ring_vaddr = ctlu->cmd_if_ring;
	/* we pass physical address as this is flib */
	ifp_init.mng_cmd_ring_paddr = fsl_virt_to_phys(
		UINT_TO_PTR(ifp_init.mng_cmd_ring_vaddr));

	dpmng_get_amq(&amq);
	ifp_init.mng_cmd_icid = amq.icid;
	ifp_init.mng_cmd_bmt = amq.bmt;
	ifp_init.mng_cmd_pl = amq.pl;
	ifp_init.mng_cmd_va = amq.va;
	ctlu->ifp_desc.ifp_id = ifp_id;
	ctlu->ifp_desc.eiop_id = eiop_id;
	ifp_init.use_mng_cmd = 1;
	pr_debug("init ifp_id = %d, wriop_id=%d \n", ctlu->ifp_desc.ifp_id, ctlu->ifp_desc.eiop_id);
	err = sys_get_desc(SOC_MODULE_EIOP_IFP,
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID,
				&ctlu->ifp_desc, NULL);
	ASSERT_COND(!err);

	/* Initialize IFP */
	err = eiop_ifp_init(&ctlu->ifp_desc, &ifp_init);
	if (err != 0)
		return err;

	pr_debug("ID[%d:%d]: exit\n", ctlu->iop_id, ctlu->type);
	return 0;
}

static int init_ctlu_eiop(struct ctlu *ctlu,
	const struct ctlu_desc *desc,
	const struct ctlu_cfg *ctlu_cfg)
{
	int err_code = 0;

	/* initialize CTLU registers */
	iowrite32(CTLU_MAX_LU_LOOPS, &ctlu->ctrl_regs->iop_mnlth);
	iowrite32(ioread32(&ctlu->ctrl_regs->iop_cllck) | CTLU_IOP_CLLCK,
			&ctlu->ctrl_regs->iop_cllck);

	if (desc->type != CTLU_EIOP_EGRESS) {
		/* set CTLU timestamp to 1588 timestamp shifted by 10.
		 * This will produce a 1024 nano timestamp. */
		iowrite32(0xa, &ctlu->ctrl_regs->iop_ctimestamp);
		iowrite32(0, &ctlu->ctrl_regs->iop_cmfmg);
		iowrite32(desc->dptbl_scanning_speed, &ctlu->ctrl_regs->iop_cagtim);
		/*! iowrite32(3, &ctlu->ctrl_regs->iop_cagtim); */

	}

	/* Init IFP for management commands */
	err_code = init_ifp(ctlu, ctlu_cfg, desc->iop_id);
	if (err_code)
		return err_code;

	/* assign callback routines */
	ctlu->execute_cmd_cb = execute_cmd_eiop;
	ctlu->build_cmd_cfg_cb = build_cmd_cfg_eiop;
	ctlu->free_cmd_cfg_cb = free_cmd_cfg_eiop;
	ctlu->get_timestamp_period_cb = get_timestamp_period_eiop;
	ctlu->get_cmd_code_cb = get_eiop_cmd_code;

	/* initialize slab allocator for runtime memory allocation */
	err_code = slab_create(
		"CTLU",
		&ctlu->slab,
		8,
		(uint16_t)(sizeof(struct eiop_mng_cmd_cfg)
				+ sizeof(MAX_MNG_CMD_MSG)),
		0, 0, 16, MEM_PART_SYSTEM_DDR1_NON_CACHEABLE,
		0);
	if (err_code)
		return err_code;

	return 0;
}

/******************************************************************************/
static uint32_t get_timestamp_period_aiop(struct ctlu *ctlu)
{
	UNUSED(ctlu);
	return 0;
}

/******************************************************************************/
static int get_aiop_cmd_code(enum ctlu_cmd_id cmd, uint32_t *code)
{
	const struct ctlu_cmd_code_map ctlu_cmd_codes[] = {
		{MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE, 0x00AD},
		{MNG_CMD_DPPARSER_PROFILE_QUERY, 0x00A7},
		{MNG_CMD_DPPARSER_PROFILE_DEL, 0x00A2}
	};
	int		i;

	for (i = 0; i < ARRAY_SIZE(ctlu_cmd_codes); i++)
		if (ctlu_cmd_codes[i].cmd == cmd) {
			*code = ctlu_cmd_codes[i].code;
			break;
		}
	/* Command not found */
	if (i == ARRAY_SIZE(ctlu_cmd_codes))
		return -EINVAL;
	return 0;
}

/******************************************************************************/
static int execute_cmd_aiop(struct ctlu *ctlu, const void *cmd_if,
			    void *cmd_cfg, enum ctlu_cmd_id cmd,
			    uint16_t *status, uint32_t *mtypeout,
			    void **out_msg)
{
	int				ret_code;
	struct eiop_mng_cmd_cfg		*eiop_mng_cmd_cfg;

	eiop_mng_cmd_cfg = (struct eiop_mng_cmd_cfg *)cmd_cfg;
	/* Initialize 'eiop_mng_cmd_cfg' - this structure holds all
	 * parameters required for issuing a management command */
	ret_code = get_aiop_cmd_code(cmd, &eiop_mng_cmd_cfg->mng_cmd);
	if (ret_code)
		return ret_code;
	/* Set physical address for message */
	eiop_mng_cmd_cfg->msg_paddr =
		fsl_virt_to_phys(eiop_mng_cmd_cfg->msg_vaddr);
	*status = eiop_mng_cmd_cfg->status;
	*mtypeout = eiop_mng_cmd_cfg->mtypeout;
	*out_msg = eiop_mng_cmd_cfg->msg_vaddr;
	return 0;
}

/******************************************************************************/
static int build_cmd_cfg_aiop(struct ctlu *ctlu, void **cmd_cfg,
			      void **input_msg, uint32_t **mtypein_addr)
{
	void				*mc_mem;
	struct eiop_mng_cmd_cfg		*eiop_mng_cmd_cfg;

	mc_mem = fsl_malloc(sizeof(struct dpparser_msg));
	if (!mc_mem) {
		pr_err("Cannot allocate memory for 'dpparser_msg'\n");
		return -ENOMEM;
	}
	*input_msg = mc_mem;
	mc_mem = fsl_malloc(sizeof(struct eiop_mng_cmd_cfg));
	if (!mc_mem) {
		fsl_free(*input_msg);
		*input_msg = 0;
		pr_err("Cannot allocate memory for 'eiop_mng_cmd_cfg'\n");
		return -ENOMEM;
	}
	eiop_mng_cmd_cfg = (struct eiop_mng_cmd_cfg *)mc_mem;
	memset(eiop_mng_cmd_cfg, 0, sizeof(struct eiop_mng_cmd_cfg));
	eiop_mng_cmd_cfg->msg_vaddr = *input_msg;
	*mtypein_addr = &eiop_mng_cmd_cfg->mtypein;
	*cmd_cfg = eiop_mng_cmd_cfg;
	return 0;
}

/******************************************************************************/
static int free_cmd_cfg_aiop(struct ctlu *ctlu, void *cmd_cfg)
{
	struct eiop_mng_cmd_cfg		*eiop_mng_cmd_cfg;

	if (cmd_cfg) {
		eiop_mng_cmd_cfg = (struct eiop_mng_cmd_cfg *)cmd_cfg;
		/* Free input message */
		if (eiop_mng_cmd_cfg->msg_vaddr)
			fsl_free(eiop_mng_cmd_cfg->msg_vaddr);
		/* Free management command */
		fsl_free(cmd_cfg);
	}
	return 0;
}

/******************************************************************************/
static int init_ctlu_aiop(struct ctlu *ctlu, const struct ctlu_desc *desc)
{
	/* initialize CTLU registers */
	iowrite32(0, &ctlu->ctrl_regs->iop_ctimestamp);
	iowrite32(0, &ctlu->ctrl_regs->iop_cmfmg);
	iowrite32(desc->dptbl_scanning_speed, &ctlu->ctrl_regs->iop_cagtim);
	iowrite32(0x00060000, &ctlu->ctrl_regs->iop_cticid);
	/* CTLU DMA registers: clear event reg */
	iowrite32(CSBEV_SBEV, &ctlu->dma_regs->iop_csbev);
	iowrite32(ioread32(&ctlu->ctrl_regs->iop_cllck) | CTLU_IOP_CLLCK,
			&ctlu->ctrl_regs->iop_cllck);

	/* assign callback routines */
	ctlu->execute_cmd_cb = execute_cmd_aiop;
	ctlu->build_cmd_cfg_cb = build_cmd_cfg_aiop;
	ctlu->free_cmd_cfg_cb = free_cmd_cfg_aiop;
	ctlu->get_timestamp_period_cb = get_timestamp_period_aiop;
	ctlu->get_cmd_code_cb = get_aiop_cmd_code;

	return 0;
}


/************************************************/
/***********   General CTLU Routines  ***********/
/************************************************/
uint32_t ctlu_get_soc_options(struct ctlu *ctlu)
{
	return ctlu->soc_options;
}

void *ctlu_get_resman(struct ctlu *ctlu)
{
	return ctlu->resman_device;
}


enum ctlu_type ctlu_get_type(struct ctlu *ctlu)
{
	ASSERT_COND(ctlu);

	return (ctlu->type);
}

 int ctlu_get_iop_id(struct ctlu *ctlu)
{
	ASSERT_COND(ctlu);

	return (ctlu->iop_id);
}

int ctlu_get_mem_base(struct ctlu *ctlu,
	enum ctlu_module module,
	void **addr)
{
	ASSERT_COND(ctlu);

	switch (module) {
	case (CTLU_DPPARSER):
		*addr = ctlu->dpparser_regs;
		break;
	case (CTLU_DPKG):
		*addr = ctlu->dpkg_regs;
		break;
	case (CTLU_DPTABLE_MNG):
		*addr = ctlu->dptbl_mng_regs;
		break;
	case (CTLU_DPPOLICER):
		*addr = ctlu->dppolicer_regs;
		break;
	default:
		pr_err("module not supported");
		return -ENOTSUP;
	}
	return 0;
}

int ctlu_get_str(int iop_id, enum ctlu_type type, char *str)
{
	switch (type) {
	case CTLU_EIOP_EGRESS:
		sprintf(str,"wr%d.ctlue", iop_id);
		break;
	case CTLU_EIOP_INGRESS:
		sprintf(str,"wr%d.ctlui", iop_id);
		break;
	case CTLU_AIOP:
		sprintf(str,"aiop%d.ctlu", iop_id);
		break;
	case CTLU_AIOP_MFLU:
		sprintf(str,"aiop%d.mflu", iop_id);
		break;
	default:
		return -EINVAL;
	}
	return 0;
}

struct ctlu * ctlu_init(const struct ctlu_desc *desc,
	const struct ctlu_cfg *ctlu_cfg)
{
	int err_code;

	struct ctlu *ctlu = (struct ctlu *)fsl_malloc(sizeof(struct ctlu));
	if (!ctlu) {
		return NULL;
	}
	memset(ctlu, 0, sizeof(struct ctlu));

	/* initialize CTLU internal structure */
	ctlu->type = desc->type;
	ctlu->ctrl_regs =
		(struct ctlu_ctrl_mem_map *)PTR_MOVE(desc->block_paddr,
			CTRL_REGS_OFFSET);
	ctlu->dma_regs =
		(struct ctlu_dma_mem_map *)PTR_MOVE(desc->block_paddr,
			CTRL_DMA_REGS_OFFSET);
	ctlu->resman_device = ctlu_cfg->resman_device;
	ctlu->dpparser_regs = desc->dpparser_vaddr;
	ctlu->dptbl_mng_regs = desc->dptbl_mng_vaddr;
	ctlu->dpkg_regs = desc->dpkg_vaddr;
	ctlu->dppolicer_regs = desc->dppolicer_vaddr;
	ctlu->soc_options = desc->options;
	ctlu->iop_id = desc->iop_id;

	/* type specific initialization */
	if ((desc->type == CTLU_EIOP_EGRESS)
		|| (desc->type == CTLU_EIOP_INGRESS)) {
		if (ctlu->resman_device == NULL)
		{
			pr_err("No resman device\n");
			return NULL;
		}
		err_code = init_ctlu_eiop(ctlu, desc, ctlu_cfg);
	} else {
		/* AIOP & MFLU */
		err_code = init_ctlu_aiop(ctlu, desc);
	}
	if (err_code)
		return NULL;

	return ctlu;
}

#ifdef TKT011436
/******************************************************************************/
static int restore_ctlu_aiop(const struct ctlu *ctlu, const struct ctlu_desc *desc)
{
	/* initialize CTLU registers */
	iowrite32(0, &ctlu->ctrl_regs->iop_ctimestamp);
	iowrite32(0, &ctlu->ctrl_regs->iop_cmfmg);
	iowrite32(desc->dptbl_scanning_speed, &ctlu->ctrl_regs->iop_cagtim);
	iowrite32(0x00060000, &ctlu->ctrl_regs->iop_cticid);
	/* CTLU DMA registers: clear event reg */
	iowrite32(CSBEV_SBEV, &ctlu->dma_regs->iop_csbev);
	iowrite32(ioread32(&ctlu->ctrl_regs->iop_cllck) | CTLU_IOP_CLLCK,
			&ctlu->ctrl_regs->iop_cllck);

	return 0;
}

static int restore_ifp(const struct ctlu *ctlu,
	int eiop_id)
{
	struct eiop_ifp_cfg ifp_init;
	int err;
	struct dpmng_amq	amq;

	memset(&ifp_init, 0, sizeof(ifp_init));

	CHECK_COND_RETVAL(ctlu->cmd_if_ring, -ENOMEM);

/*	memset(ctlu->cmd_if_ring, 0,
		(size_t)(MNG_CMD_RING_SIZE * MNG_CMD_DESC_SIZE));*/
	ifp_init.mng_cmd_ring_vaddr = ctlu->cmd_if_ring;
	/* we pass physical address as this is flib */
	ifp_init.mng_cmd_ring_paddr = fsl_virt_to_phys(
		UINT_TO_PTR(ifp_init.mng_cmd_ring_vaddr));

	dpmng_get_amq(&amq);
	ifp_init.mng_cmd_icid = amq.icid;
	ifp_init.mng_cmd_bmt = amq.bmt;
	ifp_init.mng_cmd_pl = amq.pl;
	ifp_init.mng_cmd_va = amq.va;
	ifp_init.use_mng_cmd = 1;
	pr_debug("restore ifp_id = %d, wriop_id=%d \n", ctlu->ifp_desc.ifp_id, ctlu->ifp_desc.eiop_id);
	err = sys_get_desc(SOC_MODULE_EIOP_IFP,
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID,
				&ctlu->ifp_desc, NULL);
	CHECK_COND_RETVAL(err == 0, err);

	/* Initialize IFP */
	err = eiop_ifp_init(&ctlu->ifp_desc, &ifp_init);
	if (err != 0)
		return err;

	pr_debug("ID[%d:%d]: Finish restore IFP\n", ctlu->iop_id, ctlu->type);
	return 0;
}

/******************************************************************************/
static int restore_ctlu_eiop(const struct ctlu *ctlu,
	const struct ctlu_desc *desc)
{
	int err_code = 0;

	/* initialize CTLU registers */
	iowrite32(CTLU_MAX_LU_LOOPS, &ctlu->ctrl_regs->iop_mnlth);
	iowrite32(ioread32(&ctlu->ctrl_regs->iop_cllck) | CTLU_IOP_CLLCK,
			&ctlu->ctrl_regs->iop_cllck);

	if (desc->type != CTLU_EIOP_EGRESS) {
		/* set CTLU timestamp to 1588 timestamp shifted by 10.
		 * This will produce a 1024 nano timestamp. */
		iowrite32(0xa, &ctlu->ctrl_regs->iop_ctimestamp);
		iowrite32(0, &ctlu->ctrl_regs->iop_cmfmg);
		iowrite32(desc->dptbl_scanning_speed, &ctlu->ctrl_regs->iop_cagtim);
		/*! iowrite32(3, &ctlu->ctrl_regs->iop_cagtim); */

	}

	/* Restore IFP for management commands */
	err_code = restore_ifp(ctlu, desc->iop_id);
	CHECK_COND_RETVAL(err_code == 0, err_code, "Failed to restore IFP for management commands\n");

	return 0;
}

/**************************************************************************//**
 @Function     restore_ctlu
*//***************************************************************************/
int restore_ctlu(const struct ctlu_desc *desc,
		const struct ctlu *ctlu)
{
		int err_code = 0;
		
	/* type specific initialization */
	if ((desc->type == CTLU_EIOP_EGRESS)
		|| (desc->type == CTLU_EIOP_INGRESS)) {
		if (ctlu->resman_device == NULL)
		{
			pr_err("No resman device\n");
			return -ENAVAIL;
		}
		err_code = restore_ctlu_eiop(ctlu, desc);
	} else {
		/* AIOP & MFLU */
		err_code = restore_ctlu_aiop(ctlu, desc);
	}
	pr_debug("Exit restore CTLU\n");
	return err_code;
}
#endif /* TKT011436 */

/* wait time should be proportional or more that max CTLU table size - 2^20 */
#define CTLU_WAIT_CINITDONE_TRIES (1 << 24)

void ctlu_enable(struct ctlu *ctlu)
{
	uint32_t val;
	uint32_t tries;
	uint64_t time = 0;
	uint64_t end_time;
	struct eiop_rtc* eiop_rtc;

	if (ctlu->type != CTLU_EIOP_EGRESS) {
		eiop_rtc = sys_get_handle(FSL_MOD_EIOP_RTC, 1, 0);
		if (eiop_rtc)
			eiop_rtc_get_current_timestamp(eiop_rtc, &time);
		iowrite32(CTLU_IOP_CMODE_CINIT, &ctlu->ctrl_regs->iop_cmode);
		/* poll for init completion */
		tries = CTLU_WAIT_CINITDONE_TRIES;
		do {
			val = ioread32(&ctlu->ctrl_regs->iop_cinitdone);
		} while (!(val & CTLU_IOP_CINITDONE) && tries--);

		if (eiop_rtc && !eiop_rtc_get_current_timestamp(eiop_rtc, &end_time))
			time = end_time - time;
		if(!(val & CTLU_IOP_CINITDONE))
			pr_err("ctlu init timeout after ~%d uS\n",
					UINT32_LO(time/1000));
		else
			pr_debug("ctlu init done after ~%d uS (%d tries)\n",
					UINT32_LO(time/1000),
					UINT32_LO(CTLU_WAIT_CINITDONE_TRIES - tries));
	}
}

void ctlu_done(struct ctlu *ctlu)
{
	int err;

	/* release CTLU resources */
	if ((ctlu->type == CTLU_EIOP_EGRESS)
		|| (ctlu->type == CTLU_EIOP_INGRESS)) {
		/* Release IFP as resource                     */

		err = resman_unbind(ctlu->resman_device, "ifp.wr0",
		                    ctlu->ifp_desc.ifp_id);
		if (err)
			pr_warn("resman_unbind failed");

		fsl_free(ctlu->cmd_if_ring);

		slab_free(ctlu->slab);
	}

	fsl_free(ctlu);
}

int ctlu_execute_cmd(struct ctlu *ctlu,
	const void *cmd_if,
	void *cmd_cfg,
	enum ctlu_cmd_id cmd,
	uint16_t *status,
	uint32_t *mtypeout,
	void **out_msg)
{
	return ctlu->execute_cmd_cb(ctlu, cmd_if, cmd_cfg, cmd, status,
					mtypeout, out_msg);
}

int ctlu_build_cmd_cfg(struct ctlu *ctlu,
                       	 void **cmd_cfg,
                         void **input_msg,
                         uint32_t **mtypein_addr)
{
	return ctlu->build_cmd_cfg_cb(ctlu, cmd_cfg, input_msg, mtypein_addr);
}

int ctlu_free_cmd_cfg(struct ctlu *ctlu, void *cmd_cfg)
{
	return ctlu->free_cmd_cfg_cb(ctlu, cmd_cfg);
}

uint32_t ctlu_get_timestamp_period(struct ctlu *ctlu)
{
	return ctlu->get_timestamp_period_cb(ctlu);
}

int ctlu_get_cmd_code(struct ctlu *ctlu, enum ctlu_cmd_id cmd, uint32_t *code)
{
	return ctlu->get_cmd_code_cb(cmd, code);

}

#ifdef ERR009038
static int get_ifp(void *resman_device, struct eiop_ifp_cmd_if_cfg *if_cfg)
{
	struct eiop_ifp_cfg ifp_init;
	struct resman_res_req req;
	int err, ifp_id;
	struct dpmng_amq amq;
	struct eiop_ifp_desc ifp_desc;

	memset(&ifp_init, 0, sizeof(ifp_init));
	memset(&req, 0, sizeof(req));
	memset(&ifp_desc, 0, sizeof(ifp_desc));

	/* get extra IFP for CTLU commands */
	strcpy(req.type, "ifp.wr0");
	req.num = 1;
	req.options = 0;
	err = resman_bind(resman_device, &req, &ifp_id);
	if (err)
		return err;

	/* allocate command descriptors ring */
	if_cfg->cmd_if_ring =
	(uint32_t *)fsl_xmalloc(MNG_CMD_RING_SIZE * MNG_CMD_DESC_SIZE,
			MEM_PART_SYSTEM_DDR1_NON_CACHEABLE,
			32);
	if (if_cfg->cmd_if_ring == NULL) {
		pr_err("cmd_if_ring\n");
		return -ENOMEM;
	}
	memset(if_cfg->cmd_if_ring, 0, (size_t)(MNG_CMD_RING_SIZE * MNG_CMD_DESC_SIZE));
	ifp_init.mng_cmd_ring_vaddr = if_cfg->cmd_if_ring;

	/* we pass physical address as this is flib */
	ifp_init.mng_cmd_ring_paddr = fsl_virt_to_phys(
			UINT_TO_PTR(ifp_init.mng_cmd_ring_vaddr));

	dpmng_get_amq(&amq);
	ifp_init.mng_cmd_icid = amq.icid;
	ifp_init.mng_cmd_bmt = amq.bmt;
	ifp_init.mng_cmd_pl = amq.pl;
	ifp_init.mng_cmd_va = amq.va;
	ifp_desc.ifp_id = ifp_id;
	ifp_desc.eiop_id = 0;
	ifp_init.use_mng_cmd = 1;

	err = sys_get_desc(SOC_MODULE_EIOP_IFP,
			SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID,
			&ifp_desc, NULL);
	ASSERT_COND(!err);

	/* Initialize IFP */
	err = eiop_ifp_init(&ifp_desc, &ifp_init);
	if (err != 0)
		return err;

	memcpy(if_cfg->ifp_desc, &ifp_desc, sizeof (ifp_desc));

	return 0;
}

void ctlu_wa_ERR009038(struct ctlu *ctlu)
{
	uint32_t save;
	void *cmd_cfg;
	uint8_t *in_msg, *out_msg;
	uint32_t *mtypein_addr, mtypeout;
	uint16_t status;
	struct eiop_port_desc port_desc;
	struct eiop_ifp_cmd_if_cfg *if_cfg;
	int cmd_err_code, i;
	static int wa_done = 0;

	/* This WQ should only run once. */
	if (wa_done)
		return;

	/* mark as done */
	wa_done = 1;

	/* create NULL command */
	/* get a cmd_cfg handle and a pointer for the input message */
	cmd_err_code = build_cmd_cfg_eiop(ctlu,
	                             &cmd_cfg,
	                      	     (void*)&in_msg,
	                             &mtypein_addr);
	if (cmd_err_code)
	{
		pr_err("ctlu_wa_ERR009038() failed.\n");
		return;
	}

	/* clear command */
	memset(in_msg, 0, 0x100);
	*mtypein_addr = 0;

	/* run 3 NULL commands */
	for (i = 0; i < 3; i++)
		cmd_err_code = execute_cmd_eiop(ctlu,
	                                NULL,
	                                cmd_cfg,
	                                MNG_CMD_NULL_ACTION,
	                                &status, &mtypeout,
	                                (void**)&out_msg);
	if (cmd_err_code)
	{
		pr_err("ctlu_wa_ERR009038() failed.\n");
		return;
	}

	/* Change NIA of QMI */
	port_desc.eiop_id = 0;
	port_desc.port_id = 0;
	cmd_err_code = sys_get_desc(SOC_MODULE_EIOP_PORT,
				SOC_DB_PORT_DESC_ID | SOC_DB_PORT_DESC_EIOP_ID,
				&port_desc, NULL);
	ASSERT_COND(!cmd_err_code);

	save = eiop_port_set_qmi_nia(&port_desc, 0);

	/* get extra IFP for CTLU commands */
	if_cfg = (struct eiop_ifp_cmd_if_cfg *)fsl_malloc(sizeof(struct eiop_ifp_cmd_if_cfg));
	if (if_cfg == NULL)
	{
		pr_err("ctlu_wa_ERR009038() failed - no memory.\n");
		return;
	}
		
	memset(if_cfg, 0, sizeof(struct eiop_ifp_cmd_if_cfg));
	if_cfg->ifp_desc = (struct eiop_ifp_desc *)fsl_malloc(sizeof(struct eiop_ifp_desc));
	if (if_cfg->ifp_desc == NULL)
	{
		pr_err("ctlu_wa_ERR009038() failed - no memory.\n");
		return;
	}
	memset(if_cfg->ifp_desc, 0, sizeof(struct eiop_ifp_desc));

	cmd_err_code = get_ifp(ctlu->resman_device, if_cfg);
	if (cmd_err_code)
	{
		pr_err("ctlu_wa_ERR009038() failed.\n");
		return;
	}

	/* run a NULL command on the tmp IFP ring */
	cmd_err_code = execute_cmd_eiop(ctlu,
					if_cfg,
	                                cmd_cfg,
	                                MNG_CMD_NULL_ACTION,
	                                &status, &mtypeout,
	                                (void**)&out_msg);
	if (cmd_err_code)
	{
		pr_err("ctlu_wa_ERR009038() failed.\n");
		return;
	}

	cmd_err_code = ctlu_free_cmd_cfg(ctlu, cmd_cfg);
	if (cmd_err_code)
	{
		pr_err("ctlu_wa_ERR009038() failed.\n");
		return;
	}

	/* wait 1ms*/
	timer_udelay(1000);

	/* Revert NIA of QMI */
	eiop_port_set_qmi_nia(&port_desc, save);

	/* wait 1ms*/
	timer_udelay(1000);

	fsl_free(if_cfg->ifp_desc);
	fsl_free(if_cfg);
}

#endif /* ERR009038 */

void ctlu_dpkg_global_profile_create(struct ctlu *ctlu, uint8_t *ptr) {

	struct ctlu_ctrl_mem_map *ctrl_regs =
			ctlu->ctrl_regs;
	int i = 0;
	uint32_t *ptr_temp = (uint32_t *)ptr;

	for (i = 0; i < MAX_NUM_OF_CKDRULES_REGS; i++)
		iowrite32(ptr_temp[i], &ctrl_regs->iop_ckdrule[i]);

}

void ctlu_dptbl_global_rule_add(struct ctlu *ctlu, uint8_t *ptr, int size) {

	struct ctlu_ctrl_mem_map *ctrl_regs =
			ctlu->ctrl_regs;
	int i = 0;
	uint32_t *ptr_temp = (uint32_t *)ptr;
	uint32_t size_temp, size_temp_reminder;
	uint32_t temp = 0;

	size_temp = (uint32_t)size / 4;
	size_temp_reminder = (uint32_t)size % 4;

	for (i = 0; i < size_temp; i++)
		iowrite32(ptr_temp[i], &ctrl_regs->iop_ckdcmp[i]);
	if (size_temp_reminder) {
		memcpy(&temp, &ptr[size - size_temp_reminder], size_temp_reminder);
		iowrite32(temp, &ctrl_regs->iop_ckdcmp[i]);
	}

}

void ctlu_dptbl_global_mask_add(struct ctlu *ctlu, uint8_t *ptr, int size) {

	struct ctlu_ctrl_mem_map *ctrl_regs =
			ctlu->ctrl_regs;
	int i = 0;
	uint32_t *ptr_temp = (uint32_t *)ptr;
	uint32_t size_temp, size_temp_reminder;
	uint32_t temp = 0;

	size_temp = (uint32_t)size / 4;
	size_temp_reminder =(uint32_t)size % 4;

	for (i = 0; i < size_temp; i++)
		iowrite32(ptr_temp[i], &ctrl_regs->iop_ckdmsk[i]);
	if (size_temp_reminder) {
		memcpy(&temp, &ptr[size - size_temp_reminder], size_temp_reminder);
		iowrite32(temp, &ctrl_regs->iop_ckdmsk[i]);
	}
}

int ctlu_get_tcam_key_size(void)
{
	struct ctlu_desc desc = {0};
	int err;

	err = soc_db_get_desc(SOC_MODULE_CTLU, SOC_DB_NO_MATCH_FIELDS, &desc, NULL);
	if( !err )
		return desc.tcam_key_size;
	else
		return err;
}

int ctlu_set_profiling(struct ctlu* ctlu,
		struct ctlu_profiling_options* prof_options) {
	uint32_t cr_val;
	CHECK_COND_RETVAL(ctlu && prof_options, -EINVAL);
	if (prof_options->enable_profiling_counters) {
		cr_val = CTLU_IOP_CPCCR_PCE; /*enable profiling counters*/
		struct ctlu_ctrl_mem_map *ctrl_regs = ctlu->ctrl_regs;
		if (ctlu->profiling_enabled) {
			/* disable counters */
			iowrite32(0x0, &ctlu->ctrl_regs->iop_cpccr);
		}
		if (prof_options->enable_profiling_for_tid) {
			cr_val = prof_options->table_id;
			cr_val <<= 16;
			cr_val |= CTLU_IOP_CPCCR_TIDQE;
		}
		/* clear counters */
		iowrite32(0x0, &ctrl_regs->iop_cpcrl);
		iowrite32(0x0, &ctrl_regs->iop_cpcrh);
		iowrite32(0x0, &ctrl_regs->iop_cpcel);
		iowrite32(0x0, &ctrl_regs->iop_cpceh);
		iowrite32(0x0, &ctrl_regs->iop_cpcca);
		iowrite32(0x0, &ctrl_regs->iop_cpcch);
		iowrite32(0x0, &ctrl_regs->iop_cpccu);
		iowrite32(0x0, &ctrl_regs->iop_cpcma);
		ctlu->profiling_enabled = 1;
	} else {
		ctlu->profiling_enabled = 0;
		cr_val = 0;
	}
	iowrite32(cr_val, &ctlu->ctrl_regs->iop_cpccr);
	return 0;
}

int ctlu_get_profiling_counters(struct ctlu* ctlu,
		struct ctlu_profiling_counters* counters) {
	struct ctlu_ctrl_mem_map *ctrl_regs;

	CHECK_COND_RETVAL(counters && ctlu, -EINVAL);
	ctrl_regs = ctlu->ctrl_regs;
	/* stop & save current configuration */
	uint32_t cr_config = ioread32(&ctrl_regs->iop_cpccr);
	if (cr_config & CTLU_IOP_CPCCR_PCE)
		iowrite32(0x0, &ctrl_regs->iop_cpccr);
	counters->rule_lookups = ioread32(&ctrl_regs->iop_cpcrl);
	counters->rule_hits = ioread32(&ctrl_regs->iop_cpcrh);
	counters->entry_lookups = ioread32(&ctrl_regs->iop_cpcel);
	counters->entry_hits = ioread32(&ctrl_regs->iop_cpceh);
	counters->cache_accesses = ioread32(&ctrl_regs->iop_cpcca);
	counters->cache_hits = ioread32(&ctrl_regs->iop_cpcch);
	counters->cache_updates = ioread32(&ctrl_regs->iop_cpccu);
	counters->memory_accesses = ioread32(&ctrl_regs->iop_cpcma);
	/* restore current configuration */
	if (cr_config & CTLU_IOP_CPCCR_PCE)
		iowrite32(cr_config, &ctrl_regs->iop_cpccr);
	return 0;
}
