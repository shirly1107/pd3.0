/*
 * Copyright 2013-2020 NXP
 */

#ifndef __DPPOLICY_H
#define __DPPOLICY_H

#include "fsl_dppolicy.h"
#include "fsl_net.h"

#define DPPOLICY_TENUM_MASK			0xffffffff


#define DPPOLICY_RULE_MASK_SIZE		32
#define DPPOLICY_ABS_INDEX_UNAVAILABLE		0xffffffff
#define POLICY_ENTRY_SIZE			0x3f

#define MSG_MASK_FALU_GRP_OFFSET		4
#define DPPOLICY_QUERY_RULE			0x40000000
#define DPPOLICY_QUERY_MASK			0x80000000


#define PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE	0xff

#define PROT_ETH_TO_FAF_OFFSET			10
#define PROT_LLC_SNAP_TO_FAF_OFFSET		18
#define PROT_VLAN_TO_FAF_OFFSET			21
#define PROT_VLAN_N_TO_FAF_OFFSET		22

#define PROT_PPPoE_TO_FAF_OFFSET		25
#define PROT_MPLS_TO_FAF_OFFSET			27
#define PROT_MPLS_N_TO_FAF_OFFSET		28

#define PROT_ARP_TO_FAF_OFFSET			30
#define PROT_IPv4_TO_FAF_OFFSET			34
#define PROT_IPv6_TO_FAF_OFFSET			42
#define PROT_ICMP_TO_FAF_OFFSET			57
#define PROT_IGMP_TO_FAF_OFFSET			58
#define PROT_UDP_LITE_TO_FAF_OFFSET		60
#define PROT_MINENCAP_TO_FAF_OFFSET		62
#define PROT_GRE_TO_FAF_OFFSET			65
#define PROT_UDP_TO_FAF_OFFSET			70
#define PROT_TCP_TO_FAF_OFFSET			72
#define PROT_ICMPV6_TO_FAF_OFFSET		59
#define PROT_DCCP_TO_FAF_OFFSET			83
#define PROT_GTP_TO_FAF_OFFSET			87
#define PROT_FIP_TO_FAF_OFFSET			16
#define PROT_FCoE_TO_FAF_OFFSET			15
#define PROT_SCTP_TO_FAF_OFFSET			81
#define PROT_IPv4_N_TO_FAF_OFFSET		38
#define PROT_IPv6_N_TO_FAF_OFFSET		45
#define PROT_IPSEC_AH_TO_FAF_OFFSET		79
#define PROT_IPSEC_ESP_TO_FAF_OFFSET		78
#define PROT_UDP_ENCAP_TO_FAF_OFFSET		89
#define PROT_CAPWAP_CNTRL_TO_FAF_OFFSET		92
#define PROT_CAPWAP_DATA_TO_FAF_OFFSET		93
#define PROT_ISCSI_TO_FAF_OFFSET		91

#define PROT_ETH_PRS_ERR_TO_FAF_OFFSET		17
#define PROT_LLC_SNAP_PRS_ERR_TO_FAF_OFFSET	20
#define PROT_VLAN_PRS_ERR_TO_FAF_OFFSET		24
#define PROT_PPPoE_PRS_ERR_TO_FAF_OFFSET	26
#define PROT_MPLS_PRS_ERR_TO_FAF_OFFSET		29
#define PROT_ARP_PRS_ERR_TO_FAF_OFFSET		31
#define PROT_MINENCAP_PRS_ERR_TO_FAF_OFFSET	64
#define PROT_GRE_PRS_ERR_TO_FAF_OFFSET		67
#define PROT_UDP_PRS_ERR_TO_FAF_OFFSET		71
#define PROT_TCP_PRS_ERR_TO_FAF_OFFSET		76
#define PROT_DCCP_PRS_ERR_TO_FAF_OFFSET		84
#define PROT_GTP_PRS_ERR_TO_FAF_OFFSET		88
#define PROT_SCTP_PRS_ERR_TO_FAF_OFFSET		82
#define PROT_IP_PRS_ERR_TO_FAF_OFFSET		52
#define PROT_IP_N_PRS_ERR_TO_FAF_OFFSET		61
#define PROT_IPSEC_PRS_ERR_TO_FAF_OFFSET	80
#define PROT_UDP_ENCAP_PRS_ERR_TO_FAF_OFFSET	90

#define PROT_L2_SOFT_PRS_ERR_TO_FAF_OFFSET	33
#define PROT_L3_SOFT_PRS_ERR_TO_FAF_OFFSET	69
#define PROT_L4_SOFT_PRS_ERR_TO_FAF_OFFSET	86
#define PROT_L5_SOFT_PRS_ERR_TO_FAF_OFFSET	94

#define PROT_L2_UNRECOGNIZED_TO_FAF_OFFSET	32
#define PROT_L3_UNRECOGNIZED_TO_FAF_OFFSET	68
#define PROT_L4_UNRECOGNIZED_TO_FAF_OFFSET	85


#define PROT_GEN_PRS_ERR_TO_FAF_OFFSET		9

#define PROT_OPT_UNICAST_TO_FAF_OFFSET		1
#define PROT_OPT_MULTICAST_TO_FAF_OFFSET	2
#define PROT_OPT_BROADCAST_TO_FAF_OFFSET	3

#define PROT_ETH_UNICAST_TO_FAF_OFFSET		11
#define PROT_ETH_MULITACST_TO_FAF_OFFSET	12
#define PROT_ETH_BROADCAST_TO_FAF_OFFSET 	13
#define PROT_ETH_BDPU_TO_FAF_OFFSET		14

#define PROT_GRE_ROUT_PRESENT_TO_FAF_OFFSET	66
#define PROT_MINENCAP_SRC_ADDR_PRESENT_TO_FAF_OFFSET	63

#define PROT_TCP_OPTIONS_TO_FAF_OFFSET		73
#define PROT_TCP_CONTROL_HIGH_BITS_TO_FAF_OFFSET 74
#define PROT_TCP_CONTROL_LOW_BITS_TO_FAF_OFFSET 75

/*TODO - check what is going on with LLC_CNAP_OOI ... */
#define PROT_LLC_SNAP_ERROR_TO_FAF_OFFSET	1

#define PROT_VLAN_CFI_SET_TO_FAF_OFFSET		23

#define PROT_IPv4_UNICAST_TO_FAF_OFFSET		PROT_OPT_UNICAST_TO_FAF_OFFSET
#define PROT_IPv4_MULITACST_TO_FAF_OFFSET\
					PROT_OPT_MULTICAST_TO_FAF_OFFSET
#define PROT_IPv4_BROADCAST_TO_FAF_OFFSET\
					PROT_OPT_BROADCAST_TO_FAF_OFFSET
#define PROT_IPv6_UNICAST_TO_FAF_OFFSET\
					PROT_OPT_UNICAST_TO_FAF_OFFSET
#define PROT_IPv6_MULITACST_TO_FAF_OFFSET\
					PROT_OPT_MULTICAST_TO_FAF_OFFSET



#define PROT_PROT_OPT_IP_N_IS_INITIAL_FRAG_TO_FAF_OFFSET	56
#define PROT_PROT_OPT_IP_IS_INITIAL_FRAG_TO_FAF_OFFSET		51
#define PROT_PROT_OPT_IP_N_OPTION_TO_FAF_OFFSET			53
#define PROT_PROT_OPT_IP_OPTION_TO_FAF_OFFSET			48
#define PROT_PROT_OPT_IP_N_FRAG_TO_FAF_OFFSET			55
#define PROT_PROT_OPT_IP_FRAG_TO_FAF_OFFSET			50

struct prot_opt_to_faf_offset {
	uint32_t option;
	uint8_t hdr_index;
	uint8_t offset;
};

struct prot_info{
	uint8_t prot_to_faf_offset;
	uint8_t prot_prs_err_to_faf_offset;
	struct prot_opt_to_faf_offset *prot_opt_faf_offset;
	uint8_t prot_last_index_to_faf_offset;
	uint8_t prot_prs_err_last_index_to_faf_offset;
};
struct dppolicy_mng {
	struct prot_info prot_info[NET_PROT_DUMMY_LAST];
	struct ctlu *ctlu;
	int num_dppolicy_entries;
};

struct fa_message{
	uint32_t falu_grp;
	uint8_t  faf[12];
	uint8_t	 mask[16];
	uint8_t  res_20[8];
	uint32_t tenum;
	uint8_t  tlur[16];
};
struct priority {
	int 		priority;
	uint16_t	abs_index;
	uint8_t		init;
};

struct fa_move_entry_message{
	uint16_t from_tenum;
	uint16_t to_tenum;
};

struct fa_delete_entry_message{
	uint32_t tenum;
};

struct fa_query_entry_message{
	uint32_t tenum;
};

struct dppolicy_entry {
	int abs_index;
	int init;
};
struct dppolicy{
	const struct dppolicy_mng	*policy_mng;
	uint16_t		max_rules;
	int 			dppolicy_id;
	uint8_t			used_rules;
	struct dppolicy_entry	*entries;
};


#define DPPOLICY_UPDATE_USED_NUM_OF_RULES(policy, add)\
	((add == 1) ? (((struct dppolicy *)policy)->used_rules+=1): \
		 (((struct dppolicy *)policy)->used_rules-=1))

#define DPPOLICY_UPDATE_ENTRY_INIT(dpolicy, index, init)\
		dpolicy->entries[index].init = init

#define DPPOLICY_IS_ENTRY_INIT(dpolicy, index)\
		dpolicy->entries[index].init

#define DPPOLICY_GET_ABS_INDEX(dpolicy, index)\
		dpolicy->entries[index].abs_index




#endif /* __DPPOLICY_H */
