/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"

#include "fsl_eiop_ifp.h"
#include "dptbl_l2switch.h"
#include "dptbl.h"
#include "ctlu_common.h"

static void fill_stdy_l2switch_vlan(uint32_t *info1, uint32_t options)
{
	*info1 = (options & DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_STATS) ?
		VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_STATS :
		((options & DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_TIMESTAMP) ?
		VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_TIMESTAMP :
		((options & DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_AGING)?
		VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_AGING : 0));
}

static void fill_stdy_l2switch_fdb(uint32_t *info1, uint32_t options)
{
	if ( options & DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS)
		*info1 |= VLAN_ENTRY_DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS;
	else if (options & DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_AGING)
		*info1 |= VLAN_ENTRY_DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_AGING;
#ifndef ERR008523
	else if (options & DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_TIMESTAMP)
				*info1 |= VLAN_ENTRY_DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_TIMESTAMP;

#endif
}
int dptbl_l2switch_vlan_delete(struct dptbl* dptbl)
{
	if(dptbl->type != DPTBL_L2SWITCH_VLAN)
	{
		pr_err("user asked for dptbl_l2switch_vlan_delete function"
				"with table of invalid type  - "
				"Type should be DPTBL_L2SWITCH_VLAN");
		return -EINVAL;
	}
	return dptbl_delete(dptbl);

}

struct dptbl* dptbl_l2switch_vlan_create(struct dptbl_mng *dptbl_mng,
                                         const struct dptbl_l2switch_vlan_cfg *init_params)
{
	struct dptbl_tmp_init_params tmp_init_params;

	memset(&tmp_init_params, 0, sizeof(struct dptbl_tmp_init_params));
	tmp_init_params.mem_type = DPTBL_PEB_MEM;
	tmp_init_params.type = DPTBL_L2SWITCH_VLAN;
	tmp_init_params.max_rules = init_params->max_rules;
	tmp_init_params.max_key_size = DPTBL_L2SWITCH_VLAN_KEY_SIZE;
	tmp_init_params.num_of_entries_per_key = DPTBL_L2SWITCH_VLAN_NUM_OF_ENTRIES_PER_KEY;
	tmp_init_params.options = init_params->options &
		DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
	tmp_init_params.icid = init_params->icid;
	tmp_init_params.aging_threshold = init_params->aging_threshold;

	if (init_params->action_on_miss)
	{
		if ((init_params->action_on_miss->next_action ==
				DPTBL_ACTION_DONE) &&
			(init_params->options & DPTBL_OPTIONS_OPTIMIZIED_DISCARD) ==
					DPTBL_OPTIONS_OPTIMIZIED_DISCARD)
			tmp_init_params.action_on_miss_opcode =
				DPTBL_ACTION_ON_MISS_DISCARD;
		else {
			tmp_init_params.action_on_miss_opcode =
					DPTBL_ACTION_ON_MISS_PROGRAMMED;
			tmp_init_params.action_on_miss =
					init_params->action_on_miss;
		}
	}
	if ((init_params->options & DPTBL_OPTIONS_OPTIMIZIED_DISCARD) &&
			(!init_params->action_on_miss ||
			(init_params->action_on_miss->next_action != DPTBL_ACTION_DONE)))
	{
		pr_err("Function dptbl_l2switch_vlan_create has inconsistent "
				"parameters -"
				"options & DPTBL_OPTIONS_OPTIMIZIED_DISCARD "
				"but the next_action != DPTBL_ACTION_DISCARD \n");
	}

	if (tmp_init_params.action_on_miss_opcode &
			DPTBL_ACTION_ON_MISS_PROGRAMMED)
		tmp_init_params.max_rules += 1;

	return create_tbl(dptbl_mng,&tmp_init_params);

}

int dptbl_l2switch_fdb_delete(struct dptbl* dptbl)
{
	if(dptbl->type != DPTBL_L2SWITCH_FDB)
	{
		pr_err("user asked for dptbl_l2switch_vlan_delete function"
				"with table of dptbl_l2switch_fdb_delete type  - "
				"Type should be DPTBL_L2SWITCH_FDB");
		return -EINVAL;
	}
	return dptbl_delete(dptbl);

}
struct dptbl* dptbl_l2switch_fdb_create(struct dptbl_mng *dptbl_mng,
                                        const struct dptbl_l2switch_fdb_cfg *init_params)
{
	struct dptbl_tmp_init_params tmp_init_params;

	memset(&tmp_init_params, 0, sizeof(struct dptbl_tmp_init_params));
	tmp_init_params.mem_type = DPTBL_PEB_MEM;
	tmp_init_params.type = DPTBL_L2SWITCH_FDB;
	tmp_init_params.max_rules = init_params->max_rules;
	tmp_init_params.max_key_size = DPTBL_L2SWITCH_FDB_KEY_SIZE;
	tmp_init_params.num_of_entries_per_key = DPTBL_L2SWITCH_FDB_NUM_OF_ENTRIES_PER_KEY;
	tmp_init_params.max_rules = init_params->max_rules;
	tmp_init_params.aging_threshold = init_params->aging_threshold;
	tmp_init_params.options = init_params->options &
		DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
	tmp_init_params.icid = init_params->icid;
	return create_tbl(dptbl_mng,&tmp_init_params);

}
static int check_dptbl_vlan_action_params (const struct dptbl_l2switch_vlan_action *action)
{
	if (action->lookup_fdb_cfg.dptbl_id > L2SWITCH_VLAN_MAX_TIDs)
	{
		pr_err("dptbl_id defined in action for dptbl_vlan  can not be larger %d\n",
				L2SWITCH_VLAN_MAX_TIDs);
		return -EINVAL;
	}
	if (action->lookup_fdb_cfg.dpkg_profile_id > L2SWITCH_VLAN_MAX_KIDs)
	{
		pr_err("dpkg_profile_id defined in action for dptbl_vlan can not be larger %d\n",
				L2SWITCH_VLAN_MAX_KIDs);
		return -EINVAL;
	}
	if (action->vlan_dppolicer_profile_id > L2SWITCH_VLAN_MAX_PLIDs)
	{
		pr_err("vlan_dppolicer_profile_id defined in action for dptbl_vlan can not be larger %d\n",
				L2SWITCH_VLAN_MAX_PLIDs);
		return -EINVAL;
	}
	if (action->learning_cfg.replic_list_id > L2SWITCH_MAX_RPLIDs)
	{
		pr_err("replic_list_id defined in action for dptbl_vlan can not be larger %d\n",
				L2SWITCH_MAX_RPLIDs);
		return -EINVAL;
	}
	if (action->learning_cfg.qd_id > L2SWITCH_MAX_QDIDs)
	{
		pr_err("qd_id defined in action for dptbl_vlan can not be larger %d\n",
				L2SWITCH_MAX_QDIDs);
		return -EINVAL;
	}
	if (action->flooding_replic_list_id > L2SWITCH_MAX_RPLIDs)
	{
		pr_err("flooding_replic_list_id defined in action for dptbl_vlan can not be larger %d\n",
				L2SWITCH_MAX_RPLIDs);
		return -EINVAL;
	}
	if (action->general_replic_qd_id > L2SWITCH_MAX_QDIDs)
	{
		pr_err("general_replic_qd_id defined in action for dptbl_vlan can not be larger %d\n",
				L2SWITCH_MAX_QDIDs);
		return -EINVAL;
	}
	if (!is_power_of_2((action->options &(DPTBL_L2SWITCH_VLAN_ACTION_SET_AUTOMATIC_LEARNING |
							DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_SECURED |
							DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_UNSECURED))>>20))
	{
			pr_err("only one of 3 next options can be set in action for dptbl_vlan :"
					"DPTBL_L2SWITCH_VLAN_ACTION_SET_AUTOMATIC_LEARNING or"
					"DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_SECURED or"
					"DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_UNSECURED");
			return -EINVAL;
	}
	if (!is_power_of_2((action->options &(DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_BLOCKING |
			DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LISTENING |
			DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LEARNING |
			DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_FORWORDING)>>16)))
	{
			pr_err("only one of 4 next options can be set in action for dptbl_vlan :"
					"DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_BLOCKING or"
					"DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LISTENING or"
					"DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LEARNING or"
					"DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_FORWORDING\n");
			return -EINVAL;
	}

	if (!is_power_of_2((action->options & (DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_REMOVE |
			DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_INSERT |
			DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_UPDATE_QOS) >> 4)))
	{
			pr_err("only one of 3 next options can be set in action for dptbl_vlan :"
					"DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_REMOVE or"
					"DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_INSERT or"
					"DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_UPDATE_QOS\n");
			return -EINVAL;
	}
#if 0 /* TODO */
	if (!is_power_of_2((action->options & (DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_STATS |
		DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_TIMESTAMP |
		DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_AGING))))
	{
			pr_err("only one of 3 next options can be set in action for dptbl_vlan :"
					"DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_STATS or"
					"DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_TIMESTAMP or"
					"DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_AGING\n");
			return -EINVAL;
	}
#endif
	return 0;
}

static int fill_vlan_action(uint8_t *ptr, const struct dptbl_l2switch_vlan_action *action)
{
	int err;
	struct action_l2switch_vlan *ptr_msg = (struct action_l2switch_vlan *)ptr;

	err = check_dptbl_vlan_action_params(action);
	if(err)
		return err;
	ptr_msg->mac_tid = (uint16_t)action->lookup_fdb_cfg.dptbl_id;
	ptr_msg->mac_kid = (uint8_t)action->lookup_fdb_cfg.dpkg_profile_id;

	ptr_msg->vlan_plid = (uint16_t)action->vlan_dppolicer_profile_id;

	ptr_msg->src_rplid = (uint16_t)action->learning_cfg.replic_list_id;
	ptr_msg->src_qdid = (uint16_t)action->learning_cfg.qd_id;

	ptr_msg->flood_qdid = (uint16_t)action->general_replic_qd_id;
	ptr_msg->flood_rplid = (uint16_t)action->flooding_replic_list_id;

	ptr_msg->info7 |= (((action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_BROADCAST) ?
							DPTBL_VLAN_INF07_BC_EN : 0) 	|
						((action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_MULTICAST) ?
							DPTBL_VLAN_INF07_MC_EN : 0)		|
						((action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_FLOODING) ?
							DPTBL_VLAN_INF07_FLD_EN : 0) 	|
						((action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_MIRRORING) ?
							DPTBL_VLAN_INF07_MIR_EN : 0));

	if(action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_AUTOMATIC_LEARNING)
		ptr_msg->info7 |= VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_AUTOMATIC_LEARNING;
	else if (action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_SECURED)
		ptr_msg->info7 |= VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_SECURED;
	else if (action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_UNSECURED)
		ptr_msg->info7 |= VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_UNSECURED;

	/*blocking is 0x0, so shoudn't be translated*/
	if (action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LISTENING)
		ptr_msg->info7 |= VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LISTENING;
	else if (action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LEARNING)
		ptr_msg->info7 |= VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LEARNING;
	else if (action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_FORWORDING)
		ptr_msg->info7 |= VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_FORWORDING;
		
	ptr_msg->info5 |= ((action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_EDISC) ?
						DPTBL_VLAN_INF05_EDISC_EN : 0);

	ptr_msg->info5 |= ((action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_PRUNING) ?
						DPTBL_VLAN_INF05_PRUNE_EN : 0);

	ptr_msg->info3 |= ((action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_ACL_AFTER_FDB) ?
						DPTBL_VLAN_INF03_ACL_EN : 0);
	ptr_msg->info1 |= DPTBL_VLAN_ENTRY_OPCODE;

	if (action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_REMOVE)
		ptr_msg->info3 |= DPTBL_VLAN_INF03_EVMODE_REMOVE;
	else if (action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_UPDATE_QOS)
		ptr_msg->info3 |= DPTBL_VLAN_INF03_EVMODE_UPDATE_QOS;
	else if (action->options & DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_INSERT)
		ptr_msg->info3 |= DPTBL_VLAN_INF03_EVMODE_INSERT;

	if (action->qos_map_method == DPTBL_L2SWITCH_VLAN_ACTION_QoS_BASED_ON_VLAN_PRI)
		ptr_msg->info5 |= DPTBL_VLAN_INF05_QoS_BASED_ON_VLAN;
	else
		ptr_msg->info5 |= DPTBL_VLAN_INF05_QoS_BASED_ON_IP;
	return 0;
}

static int check_dptbl_fdb_action_params(const struct dptbl_l2switch_fdb_action *action)
{
	uint32_t options;

	if (action->qd_id > L2SWITCH_MAX_QDIDs)
	{
		pr_err("qd_id defined in action for dptbl_fdb can not be larger %d\n",
				L2SWITCH_MAX_QDIDs);
		return -EINVAL;
	}
	if (action->replic_list_id > L2SWITCH_MAX_RPLIDs)
	{
		pr_err("replic_list_id defined in action for dptbl_fdb can not be larger %d\n",
				L2SWITCH_MAX_RPLIDs);
		return -EINVAL;
	}


	options = action->options & (DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS
#ifndef ERR008523
		| 	DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_TIMESTAMP
#endif
		|	DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_AGING);
	if (!is_power_of_2(options))
	{
			pr_err("only one of 3 next options can be set in action for dptbl_vlan :"
					"DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS or"
					"DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_TIMESTAMP or"
					"DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_AGING\n");
			return -EINVAL;
	}
	return 0;
}
static int fill_fdb_action(uint8_t *ptr, const struct dptbl_l2switch_fdb_action *action)
{
	int err;
	struct action_l2switch_fdb *ptr_msg = (struct action_l2switch_fdb *)ptr;

	err = check_dptbl_fdb_action_params(action);
	if(err)
		return err;

	ptr_msg->rplid = (uint16_t)action->replic_list_id;
	ptr_msg->qdid = (uint16_t)action->qd_id;
	ptr_msg->info1 |= DPTBL_FDB_ENTRY_OPCODE;

	return 0;

}

int dptbl_add_rule_l2switch_vlan(struct dptbl* dptbl,
                                 const struct dptbl_l2switch_vlan_rule_cfg *rule,
                                 const struct dptbl_l2switch_vlan_action *action)
{
	uint8_t 		*ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err;

	if(dptbl->type != DPTBL_L2SWITCH_VLAN)
	{
		pr_err("user asked for dptbl_add_rule_l2switch_vlan function"
				"with table of invalid type  - "
				"Type should be DPTBL_L2SWITCH_VLAN");
		return -EINVAL;
	}

	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/*prepare the MNG_CMD_DPTBL_RULE_CREATE message*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
	fill_stdy_l2switch_vlan(&((struct tbl_rule *)ptr_in_msg)->info1,
					action->options);
	err = fill_vlan_action(((struct tbl_rule *)ptr_in_msg)->tlur,action);
	if (err) {
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return err;
	}
	*mtypein_addr = (dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
	/*execute the MNG_CMD_DPTBL_RULE_CREATE message*/
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
	                       MNG_CMD_DPTBL_RULE_CREATE,
	                       &status, &mtypeout,
	                       (void**)&ptr_out_msg);
	if (err) {
		if (status) {
			if (status & MNG_CMD_STATUS_NORSC) {
				pr_err("Function - dptbl_add_rule_l2switch_vlan:\n"
						" CTLU rule is not created,"
						"not enough resource available\n");
				err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err);
				return -ENOSPC;
			}
		}
	}
	else {
		if (((status & MNG_CMD_STATUS_TLUMISS) != MNG_CMD_STATUS_TLUMISS) &&
			((status & MNG_CMD_STATUS_PIEE) != MNG_CMD_STATUS_PIEE))
			{
				pr_err("matching rule is found in the table "
						"and no change is executed. \n");
				err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err);
				return -EEXIST;
			}
	}
	ASSERT_COND(!err);

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);
	return 0;
}

int dptbl_add_rule_l2switch_fdb(struct dptbl* dptbl,
        			const struct dptbl_l2switch_fdb_rule_cfg *rule,
        			const struct dptbl_l2switch_fdb_action *action)
{
	uint8_t 		*ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err;

	if(dptbl->type != DPTBL_L2SWITCH_FDB)
	{
		pr_err("user asked for dptbl_add_rule_l2switch_fdb function"
				"with table of invalid type  - "
				"Type should be DPTBL_L2SWITCH_FDB");
		return -EINVAL;
	}
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/*prepare the MNG_CMD_DPTBL_RULE_CREATE message*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
	fill_stdy_l2switch_fdb(&((struct tbl_rule *)ptr_in_msg)->info1,
				action->options);

	err = fill_fdb_action(((struct tbl_rule *)ptr_in_msg)->tlur,action);
	if (err) {
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return err;
	}
	*mtypein_addr = (dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
	/*execute the MNG_CMD_DPTBL_RULE_CREATE message*/
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
	                       MNG_CMD_DPTBL_RULE_CREATE,
	                       &status, &mtypeout,
	                       (void**)&ptr_out_msg);
	if (err) {
		if (status) {
			if (status & MNG_CMD_STATUS_NORSC) {
				pr_err("Function - dptbl_add_rule_l2switch_fdb:\n"
						" CTLU rule is not created,"
						"not enough resource available\n");
				err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err);
				return -ENOSPC;
			}
			/*can not be that this rule is found in the table - we checked it before*/
		}
	}
	else {
		if (((status & MNG_CMD_STATUS_TLUMISS) != MNG_CMD_STATUS_TLUMISS) &&
			((status & MNG_CMD_STATUS_PIEE) != MNG_CMD_STATUS_PIEE))
			{
				pr_err("matching rule is found in the table "
						"and no change is executed. \n");
				err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err);
				return -EEXIST;
			}
	}

	ASSERT_COND(!err);
	/*can not be that this rule is found in the table - we checked it before
	 * by query*/
	ASSERT_COND((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS);
	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return 0;

}


int dptbl_remove_rule_l2switch_fdb(struct dptbl* dptbl,
        			const struct dptbl_l2switch_fdb_rule_cfg *rule)
{
	uint8_t 		*ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp;

	if(dptbl->type != DPTBL_L2SWITCH_FDB)
	{
		pr_err("user asked for dptbl_add_rule_l2switch_fdb function"
				"with table of invalid type  - "
				"Type should be DPTBL_L2SWITCH_FDB");
		return -EINVAL;
	}
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/*prepare the MNG_CMD_DPTBL_RULE_CREATE message*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
	*mtypein_addr = (dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
	/*execute the MNG_CMD_DPTBL_RULE_CREATE message*/
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
	                       MNG_CMD_DPTBL_RULE_DEL,
	                       &status, &mtypeout,
	                       (void**)&ptr_out_msg);
	if ((status & MNG_CMD_STATUS_TLUMISS ) == MNG_CMD_STATUS_TLUMISS )
	{
		pr_err("Function - dptbl_add_rule_l2switch_fdb, matching rule "
			"is not found in the table."
			"Can not execute remove\n.");
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -EEXIST;
	}
	if (err) {
		err_tmp= ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
		
	}
	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return 0;

}

int dptbl_remove_rule_l2switch_vlan(struct dptbl* dptbl,
                                 const struct dptbl_l2switch_vlan_rule_cfg *rule)
{
	uint8_t 		*ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp;

	if(dptbl->type != DPTBL_L2SWITCH_VLAN)
	{
		pr_err("user asked for dptbl_add_rule_l2switch_vlan function"
				"with table of invalid type  - "
				"Type should be DPTBL_L2SWITCH_VLAN\n");
		return -EINVAL;
	}

	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);
	/*prepare the MNG_CMD_DPTBL_RULE_CREATE message*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
	*mtypein_addr = (dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
	/*execute the MNG_CMD_DPTBL_RULE_CREATE message*/
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
	                       MNG_CMD_DPTBL_RULE_DEL,
	                       &status, &mtypeout,
	                       (void**)&ptr_out_msg);
	if ((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS) {
		pr_err("matching rule is not found in the table."
			"Can not execute remove.\n");
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -ENAVAIL;	/*!< Resource not available */
	}
	err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err_tmp);
	return err;
}

int dptbl_modify_rule_l2switch_fdb(struct dptbl* dptbl,
        			const struct dptbl_l2switch_fdb_rule_cfg *rule,
        			const struct dptbl_l2switch_fdb_action *action)
{
	uint8_t 		*ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp;

	if(dptbl->type != DPTBL_L2SWITCH_FDB)
	{
		pr_err("user asked for dptbl_add_rule_l2switch_fdb function"
				"with table of invalid type  - "
				"Type should be DPTBL_L2SWITCH_FDB");
		return -EINVAL;
	}
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);


	/*prepare the MNG_CMD_DPTBL_RULE_CREATE message*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
	fill_stdy_l2switch_fdb(&((struct tbl_rule *)ptr_in_msg)->info1,
				action->options);
	err = fill_fdb_action(((struct tbl_rule *)ptr_in_msg)->tlur,action);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	*mtypein_addr = (dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
	/*execute the MNG_CMD_DPTBL_RULE_REPLACE message*/
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
							MNG_CMD_DPTBL_RULE_REPLACE,
	                       &status, &mtypeout,
	                       (void**)&ptr_out_msg);
	/*can not be that this rule is found in the table - we checked it before
	 * by query*/
	if (status) {
			pr_err("Rule is not found:"
			" No modification is executed. \n");
			err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			ASSERT_COND(!err);
			return -EINVAL;
	}

	err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err_tmp);

	return err;

}

int dptbl_modify_rule_l2switch_vlan(struct dptbl* dptbl,
                                 const struct dptbl_l2switch_vlan_rule_cfg *rule,
                                 const struct dptbl_l2switch_vlan_action *action)
{
	uint8_t 		*ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp;

	if(dptbl->type != DPTBL_L2SWITCH_VLAN)
	{
		pr_err("user asked for dptbl_modify_rule_l2switch_vlan function"
				"with table of invalid type  - "
				"Type should be DPTBL_L2SWITCH_VLAN");
		return -EINVAL;
	}

	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/*prepare the MNG_CMD_DPTBL_RULE_CREATE message*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
	fill_stdy_l2switch_vlan(&((struct tbl_rule *)ptr_in_msg)->info1,
					action->options);
	err = fill_vlan_action(((struct tbl_rule *)ptr_in_msg)->tlur,action);
	if (err) {
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return err;
	}
	*mtypein_addr = (dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
	/*execute the MNG_CMD_DPTBL_RULE_CREATE message*/
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
							MNG_CMD_DPTBL_RULE_REPLACE,
	                       &status, &mtypeout,
	                       (void**)&ptr_out_msg);
	/*can not be that this rule is found in the table - we checked it before
	 * by query*/
	if (status) {
			pr_err("Rule is not found:"
			" No modification is executed. \n");
			err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			ASSERT_COND(!err);
			return -EINVAL;
	}

	err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err_tmp);
	return err;
}

static void  build_fdb_action(uint8_t *ptr,struct dptbl_l2switch_fdb_action *action)
{
	struct action_l2switch_fdb *ptr_msg = (struct action_l2switch_fdb *)ptr;

	memset(action , 0, sizeof(struct dptbl_l2switch_fdb_action));
	action->qd_id = ptr_msg->qdid;
	action->replic_list_id = ptr_msg->rplid;


}

static void build_fdb_stdy(uint32_t info1, struct dptbl_l2switch_fdb_action *action)
{
	if ((info1 & VLAN_ENTRY_DPTBL_L2SWITCH_FDB_STDY_MASK) ==
		VLAN_ENTRY_DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS)
		action->options |= DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS;
#ifndef ERR008523
	else if ((info1 & VLAN_ENTRY_DPTBL_L2SWITCH_FDB_STDY_MASK) ==
		VLAN_ENTRY_DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_TIMESTAMP)
		action->options |= DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_TIMESTAMP;
#endif
	else if ((info1 & VLAN_ENTRY_DPTBL_L2SWITCH_FDB_STDY_MASK) ==
		VLAN_ENTRY_DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_AGING)
		action->options |= DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_AGING;
}

int dptbl_get_l2switch_fdb(struct dptbl* dptbl,
        			const struct dptbl_l2switch_fdb_rule_cfg *rule,
        			struct dptbl_l2switch_fdb_action *action)
{
	uint8_t 		*ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp;

	if(dptbl->type != DPTBL_L2SWITCH_FDB)
	{
		pr_err("user asked for dptbl_add_rule_l2switch_fdb function"
				"with table of invalid type  - "
				"Type should be DPTBL_L2SWITCH_FDB");
		return -EINVAL;
	}
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/*execute query to be sure that this rule wasn't added before*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_QUERY_SIZE);
	memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
	*mtypein_addr = (uint16_t)(dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
							MNG_CMD_DPTBL_RULE_QUERY,
	                        &status, &mtypeout,
	                        (void**)&ptr_out_msg);
	if ((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS) {
		pr_err("Function dptbl_get_l2switch_fdb : "
			"matching rule is not found in the table."
			"Can not execute dptbl_get_l2switch_fdb rule\n.");
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -ENAVAIL;	/*!< Resource not available */
	}

	if (err) {
		err_tmp= ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;	
	}
	build_fdb_action(((struct tbl_rule_output *)ptr_in_msg)->tlur, action);
	build_fdb_stdy((*(uint32_t *)ptr_in_msg), action);
	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);
	return 0;

}

static void  build_vlan_action(uint8_t *ptr,struct dptbl_l2switch_vlan_action *action)
{
	struct action_l2switch_vlan *ptr_msg = (struct action_l2switch_vlan *)ptr;

	memset(action , 0, sizeof(struct dptbl_l2switch_vlan_action));
	
	action->lookup_fdb_cfg.dptbl_id = ptr_msg->mac_kid;
	action->lookup_fdb_cfg.dpkg_profile_id = ptr_msg->mac_kid;
	
	action->vlan_dppolicer_profile_id = ptr_msg->vlan_plid;

	action->learning_cfg.replic_list_id = ptr_msg->src_rplid;
	action->learning_cfg.qd_id = ptr_msg->src_qdid;
	
	action->general_replic_qd_id = ptr_msg->flood_qdid;
	action->flooding_replic_list_id = ptr_msg->flood_rplid;
	
	action->options |= (((ptr_msg->info7 & DPTBL_VLAN_INF07_BC_EN) ?
							DPTBL_L2SWITCH_VLAN_ACTION_SET_BROADCAST : 0) |
							((ptr_msg->info7 & DPTBL_VLAN_INF07_MC_EN) ?
							DPTBL_L2SWITCH_VLAN_ACTION_SET_MULTICAST : 0) |
							((ptr_msg->info7 & DPTBL_VLAN_INF07_FLD_EN) ?
							DPTBL_L2SWITCH_VLAN_ACTION_SET_FLOODING : 0) |
							((ptr_msg->info7 & DPTBL_VLAN_INF07_MIR_EN) ?
							DPTBL_L2SWITCH_VLAN_ACTION_SET_MIRRORING : 0));
							
	if 	(ptr_msg->info7 & VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_AUTOMATIC_LEARNING)
		action->options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_AUTOMATIC_LEARNING;
	else if (ptr_msg->info7 & VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_SECURED)
		action->options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_SECURED;
	else if  (ptr_msg->info7 & VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_UNSECURED)
		action->options |= 	DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_UNSECURED;

	if ((ptr_msg->info7 & VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_STP_MASK) == 
		VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LISTENING)
		action->options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LISTENING;
	else if ((ptr_msg->info7 & VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_STP_MASK) ==
			VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LEARNING)
		action->options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LEARNING;
	else if  ((ptr_msg->info7 & VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_STP_MASK) == 
			VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_FORWORDING)
		action->options |= 	DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_FORWORDING;
	else
		action->options |= 	DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_BLOCKING;
	
	if (ptr_msg->info5 & DPTBL_VLAN_INF05_PRUNE_EN)
		action->options |= 	DPTBL_L2SWITCH_VLAN_ACTION_SET_PRUNING;
	
	if (ptr_msg->info3 & DPTBL_VLAN_INF03_ACL_EN)
		action->options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_ACL_AFTER_FDB;
	
	if 	(ptr_msg->info3 & DPTBL_VLAN_INF03_EVMODE_REMOVE)
		action->options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_REMOVE;
	else if (ptr_msg->info3 & DPTBL_VLAN_INF03_EVMODE_UPDATE_QOS)
		action->options |= DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_UPDATE_QOS;
	else if  (ptr_msg->info3 & DPTBL_VLAN_INF03_EVMODE_INSERT)
		action->options |= 	DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_INSERT;
	
	if 	(ptr_msg->info5 & DPTBL_VLAN_INF05_QoS_BASED_ON_VLAN)
		action->qos_map_method = DPTBL_L2SWITCH_VLAN_ACTION_QoS_BASED_ON_VLAN_PRI;
}

static void build_vlan_stdy(uint32_t info1, struct dptbl_l2switch_vlan_action *action)
{
	if ((info1 & VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_STDY_MASK) ==
			VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_STATS)
		action->options |= DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_STATS;
	else if ((info1 & VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_STDY_MASK) ==
			VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_TIMESTAMP)
		action->options |= DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_TIMESTAMP;
	else if ((info1 & VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_STDY_MASK) ==
			VLAN_ENTRY_DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_AGING)
		action->options |= DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_AGING;
}

int dptbl_get_l2switch_vlan(struct dptbl* dptbl,
        			const struct dptbl_l2switch_vlan_rule_cfg *rule,
        			struct dptbl_l2switch_vlan_action *action)
{
	uint8_t 		*ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp;

	if(dptbl->type != DPTBL_L2SWITCH_VLAN)
	{
		pr_err("user asked for dptbl_modify_rule_l2switch_vlan function"
						"with table of invalid type  - "
						"Type should be DPTBL_L2SWITCH_VLAN");
		return -EINVAL;
	}
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/*execute query to be sure that this rule wasn't added before*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_QUERY_SIZE);
	memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
	*mtypein_addr = (uint16_t)(dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
							MNG_CMD_DPTBL_RULE_QUERY,
	                        &status, &mtypeout,
	                        (void**)&ptr_out_msg);
	if ((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS) {
		pr_err("Function dptbl_get_l2switch_vlan : "
			"matching rule is not found in the table."
			"Can not execute dptbl_get_l2switch_vlan rule\n.");
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -ENAVAIL;	/*!< Resource not available */
	}

	if (err) {
		err_tmp= ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;	
	}
	build_vlan_action(((struct tbl_rule_output *)ptr_out_msg)->tlur, action);
	build_vlan_stdy((*(uint32_t *)ptr_out_msg), action);
	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);
	return 0;

}


int dptbl_add_or_modify_rule_l2switch_fdb(struct dptbl* dptbl,
                           const struct dptbl_l2switch_fdb_rule_cfg *rule,
                           const struct dptbl_l2switch_fdb_action *action)
{
       uint8_t              *ptr_in_msg, *ptr_out_msg;
       uint16_t status;
       uint32_t mtypeout;
       void *cmd_cfg;
       uint32_t *mtypein_addr;
       int err, err_tmp;
       struct dptbl_l2switch_fdb_action action_tmp;
       int modify_create = 0;
       
       if(dptbl->type != DPTBL_L2SWITCH_FDB)
       {
              pr_err("user asked for dptbl_add_rule_l2switch_fdb function"
                           "with table of invalid type  - "
                           "Type should be DPTBL_L2SWITCH_FDB");
              return -EINVAL;
       }
       memset(&action_tmp, 0, sizeof(struct dptbl_l2switch_fdb_action));
       
       err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
                                    &cmd_cfg,
                                       (void*)&ptr_in_msg,
                                    &mtypein_addr);
       ASSERT_COND(!err);

       if (action->options & DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS)
	       modify_create = 1;
       if (!modify_create) {
	       /*execute query to be sure that this rule wasn't added before*/
	       memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_QUERY_SIZE);
	       memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
	       *mtypein_addr = (uint16_t)(dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
	       err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
							MNG_CMD_DPTBL_RULE_QUERY,
				       &status, &mtypeout,
				       (void**)&ptr_out_msg);
	       if (err) {
	              err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	              ASSERT_COND(!err_tmp);
	              return err;
	       }
	       if ((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS) {
		       modify_create = 1; /*rule is not exists - should create/modify*/
	       }
	       else {
		       build_fdb_stdy((*(uint32_t *)ptr_out_msg), &action_tmp);
		       if(action_tmp.options &  DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS) {
		              err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		              ASSERT_COND(!err);
		              return -EEXIST;
		       }
		       else {
			       modify_create = 1;  
		       }
	       }
       }

       /*check if defined entry static or dynamic.
       * In the case of existing entry defined as static 
        * and new modifed entry is dynamic - can not be modified, 
        * otherwise it should be modifed
       */
       /*prepare the MNG_CMD_DPTBL_RULE_CREATE message*/
       memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
       memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
       fill_stdy_l2switch_fdb(&((struct tbl_rule *)ptr_in_msg)->info1,
                           action->options);

       err = fill_fdb_action(((struct tbl_rule *)ptr_in_msg)->tlur,action);
       if (err) {
              err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
              ASSERT_COND(!err_tmp);
              return err;
       }
       *mtypein_addr = (dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
       /*execute the MNG_CMD_DPTBL_RULE_CREATE message*/
       err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
                                         MNG_CMD_DPTBL_RULE_CREATE_REPLACE,
                              &status, &mtypeout,
                              (void**)&ptr_out_msg);
       if (err) {
              if (status) {
                     if (status & MNG_CMD_STATUS_NORSC) {
                           pr_err("Function - dptbl_add_rule_l2switch_fdb:\n"
                                         " CTLU rule is not created,"
                                         "not enough resource available\n");
                           err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
                           ASSERT_COND(!err);
                           return -ENOSPC;
                     }
                     /*can not be that this rule is found in the table - we checked it before*/
              }
              err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
               ASSERT_COND(!err_tmp);
       }

       /*can not be that this rule is found in the table - we checked it before
       * by query*/
       err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
       ASSERT_COND(!err);

       return 0;

}


int dptbl_add_or_modify_rule_l2switch_vlan(struct dptbl* dptbl,
                                 const struct dptbl_l2switch_vlan_rule_cfg *rule,
                                 const struct dptbl_l2switch_vlan_action *action)
{
	uint8_t 		*ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp;

	if(dptbl->type != DPTBL_L2SWITCH_VLAN)
	{
		pr_err("user asked for dptbl_modify_rule_l2switch_vlan function"
				"with table of invalid type  - "
				"Type should be DPTBL_L2SWITCH_VLAN");
		return -EINVAL;
	}

	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/*prepare the MNG_CMD_DPTBL_RULE_CREATE message*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, rule->key,(uint32_t)dptbl->max_key_size);
	fill_stdy_l2switch_vlan(&((struct tbl_rule *)ptr_in_msg)->info1,
					action->options);
	err = fill_vlan_action(((struct tbl_rule *)ptr_in_msg)->tlur,action);
	if (err) {
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return err;
	}
	*mtypein_addr = (dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);
	/*execute the MNG_CMD_DPTBL_RULE_CREATE message*/
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
							MNG_CMD_DPTBL_RULE_CREATE_REPLACE,
	                       &status, &mtypeout,
	                       (void**)&ptr_out_msg);
	if (err) {
		if (status) {
			if (status & MNG_CMD_STATUS_NORSC) {
				pr_err("Function - dptbl_add_rule_l2switch_fdb:\n"
						" CTLU rule is not created,"
						"not enough resource available\n");
				err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err);
				return -ENOSPC;
			}
			/*can not be that this rule is found in the table - we checked it before*/
		}
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);
	return 0;
}
