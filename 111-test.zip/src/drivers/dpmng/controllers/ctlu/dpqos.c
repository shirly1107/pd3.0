/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_malloc.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_ctlu.h"

#include "dpqos.h"

/* FUNCTIONS for QOS_MANAGER */

#ifdef TKT011436 
/**************************************************************************//**
 @Function     dpqos_mng_restore
*//***************************************************************************/
int dpqos_mng_restore(const struct dpqos_mng_cfg *dpqos_mng_cfg)
{
	return 0;
}
#endif /* TKT011436 */

struct dpqos_mng * dpqos_mng_init(const struct dpqos_mng_cfg *dpqos_mng_cfg)
{
	struct dpqos_mng *dpqos_mng = (struct dpqos_mng *)fsl_malloc(
		sizeof(struct dpqos_mng));

	if (!dpqos_mng)
		return NULL;

	memset(dpqos_mng, 0, sizeof(struct dpqos_mng));

	dpqos_mng->ctlu = dpqos_mng_cfg->ctlu;

	return dpqos_mng;

}

void dpqos_mng_done(struct dpqos_mng *dpqos_mng)
{
	ASSERT_COND(dpqos_mng);

	fsl_free(dpqos_mng);
}

/* FUNCTIONS for QOS */

struct dpqos* dpqos_init(struct dpqos_mng *dpqos_mng, int ifp_id)
{
	struct dpqos *dpqos;

	dpqos = (struct dpqos *)fsl_malloc(sizeof(struct dpqos));
	ASSERT_COND(dpqos);
	memset(dpqos, 0, sizeof(struct dpqos));

	dpqos->ifp_id = ifp_id;
	dpqos->dpqos_mng = dpqos_mng;

	return dpqos;
}

int dpqos_done(struct dpqos* dpqos)
{
	ASSERT_COND(dpqos);

	fsl_free(dpqos);

	return 0;
}

static void fill_qos_action(uint8_t *ptr, const struct dpqos_action *action)
{
	struct qos_entry_message *ptr_msg = (struct qos_entry_message *)ptr;

	memset(ptr_msg, 0, sizeof(struct qos_entry_message));

	if (action->next_action == DPQOS_ACTION_DONE)
		ptr_msg->info |= DPQOS_SKIP_POLICER;
	ptr_msg->info |= (action->dppolicer_profile_id
				& DPQOS_MAX_DPPOLICER_PROFILE_ID)
				<< DPQOS_DPPOLICER_ID_SHIFT;
	ptr_msg->info |= (action->qpri & DPQOS_MAX_NUM_OF_QPRIs)
				<< DPQOS_QPRI_SHIFT;
	ptr_msg->info |=
		(action->options & DPQOS_ACTION_SET_POLICER_ID) ?
			DPQOS_SET_POLICER_ID : 0;
	ptr_msg->info |=
		(action->options & DPQOS_ACTION_SET_QPRI) ? DPQOS_SET_QPRI : 0;

}

static int dpqos_check_cfg(const struct dpqos_action *action)
{
	if ((action->next_action == DPQOS_ACTION_DONE)
		&& ((action->options & DPQOS_ACTION_SET_POLICER_ID)
			== DPQOS_ACTION_SET_POLICER_ID)) {
		pr_err("If next_action != DPQOS_ACTION_POLICER"
		"can not be set DPQOS_ACTION_SET_POLICER_ID in options\n");
		return -EINVAL;
	}

	if ((action->options & DPQOS_ACTION_SET_POLICER_ID)
		== DPQOS_ACTION_SET_POLICER_ID) {
		if ((action->dppolicer_profile_id
			> DPQOS_MAX_DPPOLICER_PROFILE_ID)
			|| (action->dppolicer_profile_id < 0)) {

			pr_err("dppolicer_profile_id %d is incorrect."
				"Should be in the range %d %d \n",
				action->dppolicer_profile_id,
				0,
				DPQOS_MAX_DPPOLICER_PROFILE_ID);
			return -EINVAL;
		}
	}

	if ((action->options & DPQOS_ACTION_SET_QPRI) == DPQOS_ACTION_SET_QPRI) {
		if ((action->qpri > DPQOS_MAX_NUM_OF_QPRIs)
			|| (action->qpri < 0)) {
			pr_err("qpri %d  is incorrect ."
				"should be in the range %d %d \n",
				action->qpri,
				0,
				DPQOS_MAX_NUM_OF_QPRIs);

			return -EINVAL;
		}
	}
	return 0;
}

static int dpqos_common(struct dpqos* dpqos,
	const struct dpqos_rule *rule,
	const struct dpqos_action *action)
{
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg = NULL;
	uint32_t *mtypein_addr, indx_in_chunk;
	uint8_t *ptr_in_msg, *ptr_out_msg;
	int max_rules;
	int err, err_tmp;

	if (rule->method == DPQOS_METHOD_BASED_ON_VLAN)
		max_rules = DPQOS_BASED_ON_VLAN_MAX_NUM_OF_ENTRIES;
	else
		max_rules = DPQOS_BASED_ON_IP_MAX_NUM_OF_ENTRIES;

	if (rule->priority >= max_rules) {
		pr_err("DPQos priority can not be greater than  %d.\n", max_rules);
		return -EINVAL;
	}
	err = dpqos_check_cfg(action);
	if (err)
		return err;

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dpqos->dpqos_mng->ctlu, &cmd_cfg,
					(void*)&ptr_in_msg, &mtypein_addr);
	ASSERT_COND(!err);

	*mtypein_addr = (uint32_t)(dpqos->ifp_id & DPQOS_IFP_ID_MASK)
			| ((rule->method == DPQOS_METHOD_BASED_ON_IP) ?
				((rule->priority / DPQOS_CHUNK_ENTRIES)
					<< DPQOS_CHUNK_SHIFT) :
				DPQOS_VLAN_PRIORITY);

	err = ctlu_execute_cmd(dpqos->dpqos_mng->ctlu, NULL, cmd_cfg, /* interface handle */
				MNG_CMD_QOS_PROFILE_QUERY, &status, &mtypeout,
				(void**)&ptr_out_msg);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dpqos->dpqos_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	ASSERT_COND(!status);

	if (ptr_in_msg != ptr_out_msg)
		memcpy(ptr_in_msg, ptr_out_msg,
			DPQOS_CHUNK_ENTRIES * DPQOS_ENTRY_SIZE);
	indx_in_chunk = (uint32_t)(rule->priority % DPQOS_CHUNK_ENTRIES);
	fill_qos_action(
		PTR_MOVE(ptr_in_msg, (indx_in_chunk * DPQOS_ENTRY_SIZE)),
		action);
	err = ctlu_execute_cmd(dpqos->dpqos_mng->ctlu, NULL, cmd_cfg, /* interface handle */
				MNG_CMD_QOS_PROFILE_CREATE_UPDATE, &status,
				&mtypeout, (void**)&ptr_out_msg);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dpqos->dpqos_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	ASSERT_COND(!status);

	err_tmp = ctlu_free_cmd_cfg(dpqos->dpqos_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err_tmp);

	return 0;

}

int dpqos_add_rule(struct dpqos* dpqos,
	const struct dpqos_rule *rule,
	const struct dpqos_action *action)
{
	int err = 0;
	uint32_t chunk_id, indx_in_chunk;
	uint8_t *chunk_array;
	uint8_t tmp;

	if (rule->method == DPQOS_METHOD_BASED_ON_VLAN)
		chunk_array = dpqos->chunk_array_vlan;
	else
		chunk_array = dpqos->chunk_array_ip;
	chunk_id = (uint32_t)(rule->priority / DPQOS_CHUNK_ENTRIES);
	indx_in_chunk = (uint32_t)(rule->priority % DPQOS_CHUNK_ENTRIES);
	tmp = chunk_array[chunk_id];

	if (tmp & (1 << indx_in_chunk)) {
		pr_debug("This rule exists.Use modify function\n");
		return -EEXIST;
	}
	err = dpqos_common(dpqos, rule, action);
	if (err)
		return err;

	tmp |= (1 << indx_in_chunk);
	chunk_array[chunk_id] = tmp;

	return 0;

}

int dpqos_remove_rule(struct dpqos *dpqos, const struct dpqos_rule *rule)
{
	struct dpqos_action action;
	int err;
	uint8_t tmp;
	uint32_t chunk_id, indx_in_chunk;
	uint8_t *chunk_array;

	if (rule->method == DPQOS_METHOD_BASED_ON_VLAN)
		chunk_array = dpqos->chunk_array_vlan;
	else
		chunk_array = dpqos->chunk_array_ip;
	chunk_id = (uint32_t)(rule->priority / DPQOS_CHUNK_ENTRIES);
	indx_in_chunk = (uint32_t)(rule->priority % DPQOS_CHUNK_ENTRIES);

	tmp = chunk_array[chunk_id];
	if (!(tmp & (1 << indx_in_chunk))) {
		pr_debug("This rule doesn't exist. Remove rule can not be executed\n");
		return -EINVAL;
	}
	memset(&action, 0, sizeof(struct dpqos_action));
	action.next_action = DPQOS_ACTION_POLICER;

	err = dpqos_common(dpqos, rule, &action);
	if (err)
		return err;

	tmp &= ~(1 << indx_in_chunk);
	chunk_array[chunk_id] = tmp;

	return 0;
}

int dpqos_modify_rule(struct dpqos* dpqos,
	const struct dpqos_rule *rule,
	const struct dpqos_action *action)
{
	int err;
	uint8_t tmp;
	uint32_t chunk_id, indx_in_chunk;
	uint8_t *chunk_array;

	if (rule->method == DPQOS_METHOD_BASED_ON_VLAN)
		chunk_array = dpqos->chunk_array_vlan;
	else
		chunk_array = dpqos->chunk_array_ip;

	chunk_id = (uint32_t)(rule->priority / DPQOS_CHUNK_ENTRIES);
	indx_in_chunk = (uint32_t)(rule->priority % DPQOS_CHUNK_ENTRIES);
	tmp = chunk_array[chunk_id];

	if (!(tmp & (1 << indx_in_chunk))) {
		pr_debug("This rule doesn't exist. Use add function\n");
		return -EINVAL;
	}

	err = dpqos_common(dpqos, rule, action);

	return err;
}

