/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_malloc.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_dpni_mc.h"

#include "fsl_eiop_ifp.h"
#include "dptbl.h"
#include "ctlu_common.h"

static void free_key_storage(struct em_key_storage *storage ) 
{
	if( storage->data ) {
		fsl_free(storage->data);
		storage->data = NULL;
		storage->miss_key_data = NULL;
		storage->key_array = NULL;
	}
}

static void free_dptbl(struct dptbl* dptbl)
{
	if (dptbl)
	{
		if(dptbl->entries)
			fsl_free(dptbl->entries);
		free_key_storage(&dptbl->key_storage);
		fsl_free(dptbl);
	}
}

static uint8_t get_id_by_type(enum dptbl_mem_type type)
{
	switch (type) {
	case (DPTBL_INT_MEMORY):
		return 2;
	case (DPTBL_PEB):
		return 3;
	case (DPTBL_EXT_MEMORY_1):
		return 4;
	case (DPTBL_EXT_MEMORY_2):
		return 5;
	default:
		return ILLEGAL_SET_OFFSET;
	}
}

static void add_abs_index_to_array_priority_abs_index_in_asc_order
									(struct dptbl_entry *entries,
                                         int abs_index,
                                         int count,
                                         uint32_t max_num_of_entries)
{
	int k = 0, i = 0;

	ASSERT_COND(count > 0);
	ASSERT_COND(count <= max_num_of_entries);

	for (i = 0; i < count; i++)
	{
		if (i == (count - 1))
			entries[i].abs_index = abs_index;
		else {
			if (abs_index < entries[i].abs_index)
			{
				for (k = (count - 1) ; k > i; k--)
					entries[k].abs_index =
							entries[k - 1].abs_index;

				entries[k].abs_index =
						(uint16_t)abs_index;
				break;
			}
			else
				ASSERT_COND(abs_index != entries[i].abs_index);
}

	}
}

static int tptbl_mng_check(struct dptbl_mng_cfg *cfg)
{
	enum dptbl_mem_type mem_type;
	int i;
	enum ctlu_type type = ctlu_get_type(cfg->ctlu);

	if (type == CTLU_EIOP_EGRESS) {
		pr_err("Invalid for CTLU_EIOP_EG");
		return -EINVAL;;
	}

	if ((type == CTLU_AIOP) || (type == CTLU_AIOP_MFLU)) {
		if (!cfg->u.aiop_tbl_mng_cfg.int_list_paddr)
			return -EINVAL;;

		for (i = 0; i < DPTBL_MEM_TYPES; i++) {
			if(cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].num_entries == 0)
				continue;
			mem_type = cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].mem_type;
			if ((mem_type != DPTBL_PEB)
			    && (mem_type != DPTBL_EXT_MEMORY_1)
			    && (mem_type != DPTBL_EXT_MEMORY_2)) {
				pr_err("Invalid mem_type");
				return -EINVAL;;
			}

			if (!is_power_of_2(cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].num_entries)) {
				pr_err("num_of_entries must be a power of 2");
				return -EINVAL;;
			}
			if (cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].num_entries
				< 4) {
				pr_err("num_of_entries must not be larger than 2");
				return -EINVAL;;

			}
		}
	}

	return 0;
}

static inline uint32_t dptbl_fix_tcam_index(uint32_t index, uint8_t num_of_entries_per_key, struct dptbl* dptbl)
{
	index = index * num_of_entries_per_key;
	return index;
}

static inline void dptbl_update_tcam_entries(struct dptbl* dptbl, uint32_t index, int rule_key_size, int init)
{
	DPTBL_UPDATE_ENTRY_INIT(dptbl, index, init);
	if( TCAM_KEY_SIZE < rule_key_size )
		DPTBL_UPDATE_ENTRY_INIT(dptbl, index+1, init);
}

struct dptbl_mng *dptbl_mng_init(struct dptbl_mng_cfg *cfg)
{
	struct dptbl_mng *dptbl_mng;
	struct dptbl_mng_mem_map_set *regs;
	phys_addr_t addr;
	uint32_t ctsize;
	int i, id, err = 0;
	enum ctlu_type type = ctlu_get_type(cfg->ctlu);

	/* check parameters */
	if (tptbl_mng_check(cfg) != 0)
		return NULL;

	dptbl_mng = (struct dptbl_mng *)fsl_malloc(
		sizeof(struct dptbl_mng));
	if (!dptbl_mng) {
		pr_err("No memory for allocation internal dptbl management"
				"data structure \n");
		return NULL;
	}
	memset(dptbl_mng, 0, sizeof(struct dptbl_mng));

	err = ctlu_get_mem_base(cfg->ctlu, CTLU_DPTABLE_MNG,
	                        (void **)&dptbl_mng->regs);
	if (err) {
		fsl_free(dptbl_mng);
		return NULL;
	}

	dptbl_mng->ctlu = cfg->ctlu;

	if ((type == CTLU_AIOP) || (type == CTLU_AIOP_MFLU)) {
		/* initialize the table descriptors list */
		regs = dptbl_mng->regs;
		addr = cfg->u.aiop_tbl_mng_cfg.int_list_paddr;
		iowrite32((uint32_t)(addr >> 32), &regs->iop_ctaddh);
		iowrite32((uint32_t)(addr), &regs->iop_ctaddl);
		pr_debug("Initialize PEB & external tables for AIOP-%s:\n",
				type == CTLU_AIOP ? "CTLU" : "MFLU");
		/* initialize the PEB & external tables */
		for (i = 0; i < DPTBL_MEM_TYPES; i++) {
			id = get_id_by_type(
			        cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].mem_type);
			regs = dptbl_mng->regs + (int)id;

			addr = cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].tbl_paddr;
			iowrite32((uint32_t)(addr >> 32), &regs->iop_ctaddh);
			iowrite32((uint32_t)(addr), &regs->iop_ctaddl);

			LOG2(cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].num_entries,
				ctsize);
			iowrite32(ctsize, &regs->iop_ctsize);
			pr_debug("MEM #%d (%s), ctsize:0x%x/entries:%d, bar:0x%x%08x\n",
					id, (id == 3 ? "PEB" : (id == 4 ? "DP-DDR" : "sys-DDR")),
					ctsize, cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].num_entries,
					UINT32_HI(cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].tbl_paddr),
					UINT32_LO(cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].tbl_paddr));
		}
	}
	else {
	/*	if (cfg->u.l2sw_present) {
			regs = dptbl_mng->regs + get_id_by_type(DPTBL_PEB);
			iowrite32(0x0000000C, &regs->iop_ctsize);
		}*/
		if (ctlu_get_soc_options(cfg->ctlu) & CTLU_DESC_OPT_REDUCED_TCAM)
		{
			regs = dptbl_mng->regs + TABLE_ID_TCAM;
			iowrite32(ioread32(&regs->iop_ctsize) - 1, &regs->iop_ctsize);
		}
	}

	return dptbl_mng;
}

void dptbl_mng_done(struct dptbl_mng *dptbl_mng)
{
	fsl_free(dptbl_mng);
}

static int fill_dptbl_action(uint8_t *ptr, const struct dptbl_action *action)
{

	struct action_cfg action_cfg;

	memset(&action_cfg, 0, sizeof(struct action_cfg));

	if (action->next_action == DPTBL_ACTION_LOOKUP)
		action_cfg.next_action = NEXT_ACTION_LOOKUP;
	else if (action->next_action == DPTBL_ACTION_DONE)
		action_cfg.next_action = NEXT_ACTION_DONE;

	if (action->options & DPTBL_ACTION_SET_POLICER_ID)
		action_cfg.options |=
				ACTION_SET_POLICER_ID;

	if (action->options & DPTBL_ACTION_SET_QOS_MAP_METHOD)
		action_cfg.options |=
				ACTION_SET_QOS_MAP_METHOD;

	if (action->options & DPTBL_ACTION_SET_QPRI)
		action_cfg.options |= ACTION_SET_QPRI;

	if (action->options & DPTBL_ACTION_SET_STASHING_CNTRL)
		action_cfg.options |= ACTION_SET_STASHING;

	if (action->options & DPTBL_ACTION_SET_IFP_ID)
		action_cfg.options |= ACTION_SET_IFP_ID;

	if (action->options & DPTBL_ACTION_SET_HASH_KID)
		action_cfg.options |= ACTION_SET_HASH_KID;

	if (action->options & DPTBL_ACTION_SET_DISCARD_FLAG)
		action_cfg.options |= ACTION_SET_DISCARD_FLAG;

	if (action->options & DPTBL_ACTION_CLEAR_DISCARD_FLAG)
		action_cfg.options |= ACTION_CLEAR_DISCARD_FLAG;

	if (action->options & DPTBL_ACTION_SET_QDID)
		action_cfg.options |= ACTION_SET_QDID;

	if (action->options & DPTBL_ACTION_SET_QDBIN)
		action_cfg.options |= ACTION_SET_QDBIN;

	if (action->options & DPTBL_ACTION_SET_FLC_FOR_AIOP)
		action_cfg.options |= ACTION_SET_FLC_FOR_AIOP;

	if (action->options & DPTBL_ACTION_SET_REPLIC_ID)
		action_cfg.options |= ACTION_SET_REPLIC_ID;

	if (action->options & DPTBL_ACTION_SET_OPAQUE)
		action_cfg.options |= ACTION_SET_OPAQUE;

	if (action->options & DPTBL_ACTION_SET_CONTEXT_IOMMU_BYPASS)
		action_cfg.options |= ACTION_SET_CONTEXT_IOMMU_BYPASS;

	switch(action->qos_map_method) {
	case(DPTBL_ACTION_QoS_BASED_ON_VLAN_PRI) :
		action_cfg.qos_map_method = ACTION_QoS_BASED_ON_VLAN_PRI;
	break;
	case(DPTBL_ACTION_QoS_BASED_ON_IP_DSCP) :
		action_cfg.qos_map_method = ACTION_QoS_BASED_ON_IP_DSCP;
	break;
	default:
	break;

	}

	action_cfg.dppolicer_profile_id = action->dppolicer_profile_id;
	action_cfg.qpri = action->qpri;
	action_cfg.ifp_id = action->ifp_id;
	action_cfg.hash_dpkg_profile_id = action->hash_dpkg_profile_id;
	action_cfg.qd_id = action->qd_id;
	action_cfg.qd_bin = action->qd_bin;
	action_cfg.replic_id = action->replic_id;
	action_cfg.opaque = action->opaque;
	action_cfg.dptbl_id = action->lookup_params.dptbl_id;
	action_cfg.dpkg_profile_id = action->lookup_params.dpkg_profile_id;

	return fill_action(ptr, &action_cfg);

}

static void get_dptbl_action(uint8_t *ptr, struct dptbl_action *action)
{

	struct action_cfg action_cfg;

	memset(&action_cfg, 0, sizeof(struct action_cfg));
	get_action(ptr, &action_cfg);


	if (action_cfg.next_action == NEXT_ACTION_LOOKUP)
		action->next_action = DPTBL_ACTION_LOOKUP;
	else if (action_cfg.next_action == NEXT_ACTION_DONE)
		action->next_action = DPTBL_ACTION_DONE;

	action->options |=  (action_cfg.options & ACTION_SET_POLICER_ID) ?
						DPTBL_ACTION_SET_POLICER_ID : 0;

	action->options |=  (action_cfg.options & ACTION_SET_QOS_MAP_METHOD) ?
						DPTBL_ACTION_SET_QOS_MAP_METHOD : 0;

	action->options |=  (action_cfg.options & ACTION_SET_QPRI) ?
						DPTBL_ACTION_SET_QPRI : 0;

	action->options |=  (action_cfg.options & ACTION_SET_IFP_ID) ?
						DPTBL_ACTION_SET_IFP_ID : 0;

	action->options |=  (action_cfg.options & ACTION_SET_HASH_KID) ?
						DPTBL_ACTION_SET_HASH_KID : 0;

	action->options |=  (action_cfg.options & ACTION_SET_DISCARD_FLAG) ?
						DPTBL_ACTION_SET_DISCARD_FLAG : 0;

	action->options |=  (action_cfg.options & ACTION_CLEAR_DISCARD_FLAG) ?
						DPTBL_ACTION_CLEAR_DISCARD_FLAG : 0;

	action->options |=  (action_cfg.options & ACTION_SET_QDID) ?
						DPTBL_ACTION_SET_QDID : 0;

	action->options |=  (action_cfg.options & ACTION_SET_QDBIN) ?
						DPTBL_ACTION_SET_QDBIN : 0;

	action->options |=  (action_cfg.options & ACTION_SET_FLC_FOR_AIOP) ?
						DPTBL_ACTION_SET_FLC_FOR_AIOP : 0;

	action->options |=  (action_cfg.options & ACTION_SET_REPLIC_ID) ?
						DPTBL_ACTION_SET_REPLIC_ID : 0;

	action->options |=  (action_cfg.options & ACTION_SET_OPAQUE) ?
						DPTBL_ACTION_SET_OPAQUE : 0;

	action->options |=  (action_cfg.options & ACTION_SET_STASHING) ?
			DPTBL_ACTION_SET_STASHING_CNTRL : 0;

	action->options |=  (action_cfg.options & ACTION_SET_CONTEXT_IOMMU_BYPASS) ?
						DPTBL_ACTION_SET_CONTEXT_IOMMU_BYPASS : 0;

	switch(action_cfg.qos_map_method) {
	case(ACTION_QoS_BASED_ON_VLAN_PRI):
		action->qos_map_method = DPTBL_ACTION_QoS_BASED_ON_VLAN_PRI;
		break;
	case(ACTION_QoS_BASED_ON_IP_DSCP):
		action->qos_map_method = DPTBL_ACTION_QoS_BASED_ON_IP_DSCP;
		break;
	default:
		break;
	}
	action->dppolicer_profile_id = action_cfg.dppolicer_profile_id;
	action->qpri = action_cfg.qpri;
	action->ifp_id = action_cfg.ifp_id;
	action->hash_dpkg_profile_id = action_cfg.hash_dpkg_profile_id;
	action->qd_id = action_cfg.qd_id;
	action->qd_bin = action_cfg.qd_bin;
	action->replic_id = action_cfg.replic_id;
	action->opaque = action_cfg.opaque;
	action->lookup_params.dptbl_id = action_cfg.dptbl_id;
	action->lookup_params.dpkg_profile_id = action_cfg.dpkg_profile_id;

}

static int dptbl_get_action_em(struct dptbl* dptbl, struct dptbl_rule *rule,
								struct dptbl_action *action)
{
	uint8_t *ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp = 0;

	ASSERT_COND(dptbl->type == DTBL_EM);

	if (dptbl->real_key_size == DPTBL_REAL_SIZE_UNINIT) {
		pr_err("Remove rule can not be executed before adding the rule\n");
		return -EINVAL;
	}
	if (dptbl->real_key_size != rule->rule_cfg.exact.size) {
		pr_err("key_size for every rule in the table MUST be the same\n");
		return -EINVAL;
	}

	memset(action, 0, sizeof (struct dptbl_action));

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/* fill ptr_in_msg with key */
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_QUERY_SIZE);
	memcpy(ptr_in_msg, rule->rule_cfg.exact.key,
		(uint32_t)rule->rule_cfg.exact.size);

	/*execute query for the key to be sure this rule doen't exist*/
	*mtypein_addr = (uint16_t)(dptbl->tid)
			| ((uint32_t)rule->rule_cfg.exact.size << 16);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
				MNG_CMD_DPTBL_RULE_QUERY, &status, &mtypeout,
				(void**)&ptr_out_msg);

	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
		
	/*status MNG_CMD_STATUS_TLUMISS says that this rul deson't exist*/
	if ((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS) {
		pr_err("Function dptbl_get_action_em for exact match :"
		"matching rule is not found in the table.\n");
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -EEXIST;
	}


	get_dptbl_action(((struct tbl_rule_output *)ptr_in_msg)->tlur,
	                       	       action);

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return 0;
}

static int dptbl_modify_miss_action_em(struct dptbl* dptbl,
                             struct dptbl_action *new_action)
{
	uint8_t *ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp = 0;

	if (dptbl->action_on_miss_opcode != DPTBL_ACTION_ON_MISS_PROGRAMMED) {
		pr_err(" With initial parameters of this table,"
		"Miss rule can not be modified\n");
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/*execute add rule*/
	/*fill ptr_in_msg with key and action*/
	memset(ptr_in_msg, 0,
		sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	err = fill_dptbl_action(((struct tbl_rule *)ptr_in_msg)->tlur,
	                        new_action);
	if (err) {
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return err;
	}
	*mtypein_addr = (uint16_t)(dptbl->tid);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
				MNG_CMD_DPTBL_RULE_CREATE_REPLACE, &status,
				&mtypeout, (void**)&ptr_out_msg);
	if(err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	ASSERT_COND(!status);

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);
	return 0;

}
static int dptbl_modify_rule_em(struct dptbl* dptbl,
                                struct dptbl_rule *rule,
                                struct dptbl_action *action)
{

	uint8_t *ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp;
	struct dptbl_action action_tmp;

	memset(&action_tmp, 0, sizeof(struct dptbl_action));

	ASSERT_COND(dptbl->type == DTBL_EM);

	if (dptbl->real_key_size == DPTBL_REAL_SIZE_UNINIT) {
		pr_err("Modify rule can not be executed before adding the rule\n");
		return -EINVAL;
	}
	if (dptbl->real_key_size != rule->rule_cfg.exact.size) {
		pr_err("key_size for every rule in the table MUST be the same"
				"Now defined size = %d previously defined size = %d\n",
				rule->rule_cfg.exact.size,dptbl->real_key_size);
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/*fill ptr_in_msg with key and action*/
	memset(ptr_in_msg, 0,
		sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, rule->rule_cfg.exact.key,
		(uint32_t)rule->rule_cfg.exact.size);

	/*fill  action*/
	err = fill_dptbl_action(((struct tbl_rule *)ptr_in_msg)->tlur, action);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}

	/*execute modify rule*/
	*mtypein_addr = (uint16_t)(dptbl->tid)
			| ((uint32_t)rule->rule_cfg.exact.size << 16);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPTBL_RULE_REPLACE, &status,
				&mtypeout, (void**)&ptr_out_msg);
	if (status) {
			pr_err("Rule is not found:"
			" No modification is executed.\n");
			err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			ASSERT_COND(!err);
			return -EINVAL;
	}
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);
#if 0
	/*TODO - only for testing*/
	err =  dptbl_get_action_em( dptbl, rule,
								&action_tmp);
	if (memcmp(&action_tmp, action, sizeof(struct dptbl_action)) == 0)
		return 0;
	else
		return 1;

#endif
	return 0;
}


static int dptbl_remove_stored_key(struct dptbl *dptbl, uint8_t *key)
{
	int i=0;
	int found = 0;

	for( i=0 ; i<dptbl->max_rules ; i++ ) {
		if( dptbl->key_storage.key_array[i]==NULL )
			continue;
		if( memcmp(dptbl->key_storage.key_array[i], key, dptbl->real_key_size)==0 ) {
			dptbl->key_storage.key_array[i] = NULL;
			found = 1;
		}
	}
	CHECK_COND_RETVAL(found, -ERANGE, "Key not found inside internal table\n");

	return 0;
}

static int dptbl_remove_rule_em(struct dptbl* dptbl, struct dptbl_rule *rule)
{

	int add = 0;
	uint8_t *ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err = 0, err_tmp = 0;

	ASSERT_COND(dptbl->type == DTBL_EM);

	if (dptbl->real_key_size == DPTBL_REAL_SIZE_UNINIT) {
		pr_err("Remove rule can not be executed before adding the rule\n");
		return -EINVAL;
	}
	if (dptbl->real_key_size != rule->rule_cfg.exact.size) {
		pr_err("key_size for every rule in the table MUST be the same ",
		"Now defined size = %d previously defined size = %d\n",
		rule->rule_cfg.exact.size,dptbl->real_key_size);
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);


	/*fill ptr_in_msg with key*/
	memset(ptr_in_msg, 0,
		sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, rule->rule_cfg.exact.key,
		(uint32_t)rule->rule_cfg.exact.size);


	/*execute delete rule*/
	*mtypein_addr = (uint16_t)(dptbl->tid)
			| ((uint32_t)rule->rule_cfg.exact.size << 16);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
				MNG_CMD_DPTBL_RULE_DEL, &status, &mtypeout,
				(void**)&ptr_out_msg);
	if(status) {
		pr_err("Rule is not found, no delete is executed.\n");
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return -EINVAL;
	}

	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	dptbl_remove_stored_key(dptbl, rule->rule_cfg.exact.key);

	DPTBL_UPDATE_USED_NUM_OF_RULES(dptbl, add);
	if (dptbl->used_rules == 0)
	{
		if (dptbl->real_key_size > DPTBL_KEY_ENTRY_SIZE){
				if (dptbl->action_on_miss_opcode & DPTBL_ACTION_ON_MISS_PROGRAMMED)
					dptbl->max_rules = dptbl->conf_table_rules-2;
				else
					dptbl->max_rules = dptbl->conf_table_rules;
		}

		dptbl->real_key_size = DPTBL_REAL_SIZE_UNINIT;
	}

	return 0;
}

static inline uint8_t *dptbl_get_key_ptr_from_storage(struct em_key_storage *storage, int index)
{
	uint8_t *key_ptr;
	key_ptr = storage->data + storage->key_offset + index*DPTBL_MAX_KEY_SIZE_EM;
	return key_ptr;
}

static int dptbl_store_em_key(struct dptbl *dptbl, uint8_t *key)
{
	int i=0;

	while( dptbl->key_storage.key_array[i]!=NULL && i<dptbl->max_rules ) i++;
	CHECK_COND_RETVAL(i<dptbl->max_rules, -ERANGE, "Key table full\n");

	dptbl->key_storage.key_array[i] = dptbl_get_key_ptr_from_storage(&dptbl->key_storage, i);
	memset(dptbl->key_storage.key_array[i], 0, dptbl->key_storage.key_size);
	memcpy(dptbl->key_storage.key_array[i], key, dptbl->real_key_size);

	return 0;
}

static int dptbl_add_rule_em(struct dptbl* dptbl,
                             struct dptbl_rule *rule,
                             struct dptbl_action *action,
                             int restore)
{

	int add = 1;
	uint8_t *ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp = 0;
	uint32_t max_rules;
	struct dptbl_action action_tmp;

	memset(&action_tmp, 0, sizeof(struct dptbl_action));

	ASSERT_COND(dptbl->type == DTBL_EM);

	if (dptbl->real_key_size != DPTBL_REAL_SIZE_UNINIT) {
		if (dptbl->real_key_size != rule->rule_cfg.exact.size) {
			pr_err("key_size for every rule in the table MUST be the same\n");
			return -EINVAL;
		}
	}
	else if ((rule->rule_cfg.masked.size > DPTBL_MAX_KEY_SIZE)  || 
			(rule->rule_cfg.exact.size == 0)){
		pr_err("rule key_size should be less or equal to the max_key_size "
				"and rule key_size can not be 0 "
				"Table key size = %d, now defined key size = %d.\n",
				dptbl->max_key_size, rule->rule_cfg.exact.size);
		return -EINVAL;

	}
		
	max_rules  = dptbl->max_rules;
	
	/*new rule can not be added due to the reach of max_num_of_rules*/
	/* In case of restore, used_rules = max_rules */
	if ((dptbl->used_rules == max_rules) && !restore)
	{
		pr_err("can not add rule to this table since - exceed the "
				 "max_num_of_rules declared in the creation of the policy "
				 "max_rules was defined as %d \n", max_rules);
		return -EDOM;
	}
	
	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/* fill ptr_in_msg with key */
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, rule->rule_cfg.exact.key,
		(uint32_t)rule->rule_cfg.exact.size);

	/* fill ad with key */
	err = fill_dptbl_action(((struct tbl_rule *)ptr_in_msg)->tlur, action);
	if (err) {
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return err;
	}

	/*execute add rule*/
	*mtypein_addr = (uint16_t)(dptbl->tid)
			| ((uint32_t)rule->rule_cfg.exact.size << 16);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
				MNG_CMD_DPTBL_RULE_CREATE, &status, &mtypeout,
				(void**)&ptr_out_msg);
	if (err) {
		if (status) {
			if (status & MNG_CMD_STATUS_NORSC) {
				pr_err("Function dptbl_add_rule  for exact match:\n"
				" CTLU rule is not created,"
				"not enough resource available\n");
				err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err);
				return -ENOSPC;
			}
		}
		else {
			err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			ASSERT_COND(!err_tmp);
			return err;
		}
		
	}
	else {
		if (((status & MNG_CMD_STATUS_TLUMISS) != MNG_CMD_STATUS_TLUMISS) &&
			((status & MNG_CMD_STATUS_PIEE) != MNG_CMD_STATUS_PIEE))
			{
				pr_err("matching rule is found in the table "
						"and no change is executed.\n");
				err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err);
				return -EEXIST;
			}

	}

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	/* At restore stage, do not modify key_size and max_rules */
	if (!restore) {
		if (dptbl->real_key_size == DPTBL_REAL_SIZE_UNINIT)
		{
			dptbl->real_key_size = rule->rule_cfg.exact.size;

			if (dptbl->real_key_size > DPTBL_KEY_ENTRY_SIZE)
			{
				dptbl->max_rules = dptbl->max_rules/DPTBL_GET_NUM_OF_ENTRIES(dptbl->real_key_size);
			}
		}
	}

#if 0
	/*TODO - only for testing*/
	err =  dptbl_get_action_em( dptbl, rule,
								&action_tmp);
	if (memcmp(&action_tmp, action, sizeof(struct dptbl_action)) == 0)
		return 0;
	else
		return 1;
#endif

	/* At restore stage, rule is already stored and counted */
	if(!restore){
		dptbl_store_em_key(dptbl, rule->rule_cfg.exact.key);

		DPTBL_UPDATE_USED_NUM_OF_RULES(dptbl, add);
	}

	return 0;
}

static void dptbl_memcpy_key_masked(void *dst, void *key, void *mask,
				    uint32_t size)
{
	uint64_t *dst64, *key64, *mask64;
	uint32_t *dst32, *key32, *mask32;
	uint8_t *dst8, *key8, *mask8;

	dst64 = (uint64_t *)dst;
	key64 = (uint64_t *)key;
	mask64 = (uint64_t *)mask;
	while (size >= 8) {
		*dst64++ = *key64++ & *mask64++;
		size -= 8;
	}

	dst32 = (uint32_t *)dst64;
	key32 = (uint32_t *)key64;
	mask32 = (uint32_t *)mask64;
	while (size >= 4) {
		*dst32++ = *key32++ & *mask32++;
		size -= 4;
	}

	dst8 = (uint8_t *)dst32;
	key8 = (uint8_t *)key32;
	mask8 = (uint8_t *)mask32;
	while (size > 0) {
		*dst8++ = *key8++ & *mask8++;
		size--;
	};
}

static int dptbl_check_params_em(struct dptbl_cfg *init_params)
{
	if ((init_params->max_key_size >= DPTBL_MAX_KEY_SIZE_EM)
		|| (init_params->max_key_size == 0))
	{
		pr_err("Function dptbl_check_params_em - check parameters for "
				"creating exact match table has wrong parameter"
				"key_size can not excced %d", DPTBL_MAX_KEY_SIZE_EM);
		return 1;
	}

	if ((init_params->options & DPTBL_OPTIONS_OPTIMIZIED_DISCARD) &&
		(!init_params->action_on_miss ||
		(init_params->action_on_miss->next_action!=
				DPTBL_ACTION_DONE)))
	{
		pr_err("Function dptbl_check_params_em - check parameters for "
				"creating exact match table has inconsistent parameter"
				":options & DPTBL_ACTION_DISCARD but the next action for "
				"Miss rule is not defined as DISCARD\n");
		return 1;
	}

	return 0;
}

static void fill_dptbl_query_tcam_acl_result_entry_message(uint8_t *ptr,
															int abs_index)
{
	struct dptbl_tcam_acl_query_entry_message 	*ptr_msg =
					(struct dptbl_tcam_acl_query_entry_message *)ptr;

	memset(ptr_msg, 0, sizeof (struct dptbl_tcam_acl_query_entry_message));
	ptr_msg->tenum = (uint32_t)(abs_index & DPTBL_TCAM_ACL_TENUM_MASK);


}

static void fill_dptbl_query_tcam_acl_rule_entry_message(uint8_t *ptr,
														int abs_index)
{
	struct dptbl_tcam_acl_query_entry_message 	*ptr_msg  =
					(struct dptbl_tcam_acl_query_entry_message *)ptr;

	memset(ptr_msg, 0, sizeof (struct dptbl_tcam_acl_query_entry_message));
	ptr_msg->tenum = (uint32_t)(abs_index & DPTBL_TCAM_ACL_TENUM_MASK);
	ptr_msg->tenum |= DPTBL_TCAM_ACL_QUERY_RULE;


}

static void fill_dptbl_query_tcam_acl_mask_entry_message(uint8_t *ptr,
														int abs_index)
{
	struct dptbl_tcam_acl_query_entry_message 	*ptr_msg  =
					(struct dptbl_tcam_acl_query_entry_message *)ptr;

	memset(ptr_msg, 0, sizeof (struct dptbl_tcam_acl_query_entry_message));
	ptr_msg->tenum = (uint32_t)(abs_index & DPTBL_TCAM_ACL_TENUM_MASK);
	ptr_msg->tenum |= DPTBL_TCAM_ACL_QUERY_MASK;
}

static int execute_dptbl_query_tcam_acl_entry(struct dptbl *dptbl, uint8_t *ptr, void *cmd_cfg, int abs_index, unsigned int size, struct dump_table_entry *entry)
{
	int err;
	uint8_t *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;

	fill_dptbl_query_tcam_acl_rule_entry_message(ptr, abs_index);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, MNG_CMD_DPTBL_TCAM_RULE_QUERY, &status, &mtypeout, (void **)&ptr_out_msg);
	if (err)
		return err;
	ASSERT_COND(!status);
	memcpy(&entry->key, ptr_out_msg, size);

	fill_dptbl_query_tcam_acl_mask_entry_message (ptr, abs_index);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, MNG_CMD_DPTBL_TCAM_RULE_QUERY, &status, &mtypeout, (void **)&ptr_out_msg);
	if (err)
		return err;
	ASSERT_COND(!status);
	memcpy(&entry->mask, ptr_out_msg, size);

	return 0;
}

static int execute_dptbl_compare_tcam_acl_entry(
		struct dptbl *dptbl, uint8_t *ptr, void *cmd_cfg, int abs_index,
		struct dptbl_tcam_acl_add_entry_message *user_rule,
		unsigned int size, int *found)
{
	int err;
	uint8_t *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	
	*found = 0;

	fill_dptbl_query_tcam_acl_rule_entry_message(ptr, abs_index);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL,
			       cmd_cfg, /* interface handle */
			       MNG_CMD_DPTBL_TCAM_RULE_QUERY, &status,
			       &mtypeout, (void **)&ptr_out_msg);
	if (err)
		return err;
	ASSERT_COND(!status);

	if (memcmp(user_rule->key, ptr_out_msg, size) == 0) {
		fill_dptbl_query_tcam_acl_mask_entry_message (ptr, abs_index);
		err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL,
				       cmd_cfg, /* interface handle */
				       MNG_CMD_DPTBL_TCAM_RULE_QUERY,
				       &status, &mtypeout, (void **)&ptr_out_msg);
		if (err)
			return err;
		ASSERT_COND(!status);

		if (memcmp(user_rule->mask, ptr_out_msg, size) == 0)
			*found = 1;
	}

	return 0;
}

static void fill_dptbl_delete_tcam_acl_entry_message(uint8_t *ptr, int abs_index)
{
		struct dptbl_tcam_acl_delete_entry_message 	*ptr_msg  =
		(struct dptbl_tcam_acl_delete_entry_message *)ptr;

	memset(ptr_msg, 0, sizeof (struct dptbl_tcam_acl_delete_entry_message));
	ptr_msg->tenum = (uint32_t)(abs_index & DPTBL_TCAM_ACL_TENUM_MASK);

}

static int  execute_dptbl_delete_tcam_acl_entry(struct dptbl* dptbl, uint8_t *ptr,
										void *cmd_cfg, int abs_index)
{
	int err;
	uint8_t *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;

	fill_dptbl_delete_tcam_acl_entry_message(ptr, abs_index);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPTBL_TCAM_RULE_DEL,
            &status, &mtypeout,
            (void**)&ptr_out_msg);
	if (err)
		return err;
	if( status )
		pr_debug("execute_dptbl_delete_tcam_acl_entry: ctlu_execute_cmd status %04x\n", status);

	return 0;
}


static int dptbl_remove_rule_tcam_acl(struct dptbl* dptbl,
                             struct dptbl_rule *rule)
{

	int add = 0, init = 0;
	int abs_index;
	void *cmd_cfg;
	int err, err_tmp = 0;
	int found = 0;
	uint32_t *mtypein_addr;
	uint8_t *ptr_in_msg;
	struct dptbl_tcam_acl_add_entry_message user_rule_msg;
	uint32_t max_rules;
	int tcam_key_size; 
	uint32_t priority_idx;

	ASSERT_COND(dptbl->type == DPTBL_TCAM_ACL);

	tcam_key_size = ctlu_get_tcam_key_size();
	CHECK_COND_RETVAL(tcam_key_size >= 0, tcam_key_size);
	
	max_rules  = dptbl->max_rules;

	if (dptbl->real_key_size == DPTBL_REAL_SIZE_UNINIT) {
		pr_err("Remove rule can not be executed before adding the rule\n");
		return -EINVAL;
	}

	/*due to the decision that the priority is relative index
	to priority, priority can not be larger than max_num_of_rules*/
	if(rule->rule_cfg.masked.priority >= max_rules)
	{
		pr_err("Priority of the rule should be in the range %d, %d.\n",
				0 ,max_rules);
		return -EINVAL;
	}

	/*for this function the rule with defined priority MUST be added*/
	priority_idx = dptbl_fix_tcam_index((uint32_t)rule->rule_cfg.masked.priority, dptbl->num_of_entries_per_key ,dptbl);
	if (DPTBL_IS_ENTRY_INIT(dptbl, priority_idx) == 0)
	{
		pr_err("Rule with the priority = %d was  not initialized. "
				"Change priority or remove existing rule\n",
				rule->rule_cfg.masked.priority);
		return -EINVAL;
	}

	/*get absolute index*/
	abs_index = dptbl->entries[priority_idx].abs_index;

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
								 &cmd_cfg,
								 (void*)&ptr_in_msg,
								 &mtypein_addr);
	ASSERT_COND(!err);


	*mtypein_addr = (uint16_t)(dptbl->tid)
			| ((uint32_t)rule->rule_cfg.masked.size << 16);

	/* check if this exact rule was initialized,
	 * based on priority, key, mask:
	 * build key and mask user defined in the HW format;
	 * Note: TCAM automatically masks the key upon insertion, so we make sure
	 * we provide the masked key for comparison, too
	 */
	memset(&user_rule_msg, 0, sizeof(struct dptbl_tcam_acl_add_entry_message));
	if (rule->rule_cfg.masked.mask)
		memcpy(&user_rule_msg.mask, rule->rule_cfg.masked.mask,
			   rule->rule_cfg.masked.size);
	else
		memset(&user_rule_msg.mask, 0xff, rule->rule_cfg.masked.size);

	dptbl_memcpy_key_masked(&user_rule_msg.key,
				rule->rule_cfg.masked.key,
				&user_rule_msg.mask,
				rule->rule_cfg.masked.size);

	err = execute_dptbl_compare_tcam_acl_entry(dptbl, ptr_in_msg, cmd_cfg,
						   abs_index, &user_rule_msg,
						   rule->rule_cfg.masked.size,
						   &found);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	if (found == 0) {
		pr_err("There is mismatch between rule (key and mask) itself and priority. "
				"On this priority was defined another rule\n");
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -EINVAL;
	}

	/*execute delete rule*/
	err = execute_dptbl_delete_tcam_acl_entry(dptbl, ptr_in_msg, cmd_cfg, abs_index);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}

	if( rule->rule_cfg.masked.size > tcam_key_size ) {
		abs_index++;
		*mtypein_addr = (uint16_t)(dptbl->tid) | ((uint32_t)tcam_key_size << 16);
		err = execute_dptbl_delete_tcam_acl_entry(dptbl, ptr_in_msg, cmd_cfg, abs_index);
		if (err) {
			err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			ASSERT_COND(!err_tmp);
			return err;
		}
	}

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	/*sign entry as uninitialized*/
	dptbl_update_tcam_entries(dptbl, priority_idx, (int)rule->rule_cfg.masked.size, init);

	/*update number of used entry (-1)*/
	DPTBL_UPDATE_USED_NUM_OF_RULES(dptbl, add);

	if (dptbl->used_rules == 0)
	{
		if (dptbl->real_key_size > TCAM_KEY_SIZE){
			if (dptbl->action_on_miss_opcode & DPTBL_ACTION_ON_MISS_LOGICAL)
				dptbl->max_rules = dptbl->conf_table_rules-2;
			else
				dptbl->max_rules = dptbl->conf_table_rules;
		}
		dptbl->real_key_size = DPTBL_REAL_SIZE_UNINIT;
		dptbl->num_of_entries_per_key = (uint8_t)DPTBL_TCM_GET_NUM_OF_ENTRIES(dptbl->max_key_size);
	}

	return 0;


}

static int dptbl_modify_rule_tcam_acl(struct dptbl* dptbl,
                             struct dptbl_rule *rule,
                             struct dptbl_action *action)
{

	uint8_t *ptr_in_msg, *ptr_out_msg;
	int abs_index;
	void *cmd_cfg;
	int err, err_tmp;
	int found = 0;
	uint32_t *mtypein_addr;
	uint16_t status;
	uint32_t mtypeout;
	struct dptbl_tcam_acl_add_entry_message user_rule_msg;
	uint32_t max_rules;
	uint32_t priority_idx;
	int tcam_key_size;

	ASSERT_COND(dptbl->type == DPTBL_TCAM_ACL);

	max_rules  = dptbl->max_rules;

	if (dptbl->real_key_size == DPTBL_REAL_SIZE_UNINIT) {
		pr_err("Remove rule can not be executed before adding the rule\n");
		return -EINVAL;
	}

	if (rule->rule_cfg.masked.size != dptbl->real_key_size) {
		pr_err("Size of the rule is not consistent with sizes of the rest of "
				"the rules. The size of the rules was defined as %d,"
				"current rule size is %d\n",
				dptbl->real_key_size, rule->rule_cfg.masked.size);

		return -EINVAL;
	}

	/*due to the decision that the priority is relative index
	to priority, priority can not be larger than max_num_of_rules*/
	if(rule->rule_cfg.masked.priority >= max_rules)
	{
		pr_err("Priority of the rule should be in the range %d, %d.\n",
				0 ,max_rules - 1);
		return -EINVAL;
	}

	/*get absolute index*/
	tcam_key_size = ctlu_get_tcam_key_size();
	CHECK_COND_RETVAL(tcam_key_size >= 0, tcam_key_size);
	priority_idx = dptbl_fix_tcam_index((uint32_t)rule->rule_cfg.masked.priority, dptbl->num_of_entries_per_key, dptbl);
	abs_index = dptbl->entries[priority_idx].abs_index;

	/*for this function the rule with defined priority MUST be added*/
	if (DPTBL_IS_ENTRY_INIT(dptbl, priority_idx) == 0)
	{
		pr_err("Rule with the same priority was not initialized. "
				"Change priority or remove existing rule\n");
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);


	*mtypein_addr = (uint16_t)(dptbl->tid)
			| ((uint32_t)rule->rule_cfg.masked.size << 16);

	/* check if this exact rule was initialized,
	 * based on priority, key, mask:
	 * build key and mask user defined in the HW format; because the TCAM
	 * automatically masks the key upon insertion, we will make sure to
	 * explicitly mask the key as well.
	 */
	memset(&user_rule_msg, 0, sizeof(struct dptbl_tcam_acl_add_entry_message));
	if (rule->rule_cfg.masked.mask)
		memcpy(&user_rule_msg.mask, rule->rule_cfg.masked.mask,
		       rule->rule_cfg.masked.size);
	else
		memset(&user_rule_msg.mask, 0xff, rule->rule_cfg.masked.size);
	dptbl_memcpy_key_masked(&user_rule_msg.key,
				rule->rule_cfg.masked.key,
				&user_rule_msg.mask,
				rule->rule_cfg.masked.size);

	err = execute_dptbl_compare_tcam_acl_entry(dptbl, ptr_in_msg, cmd_cfg,
						   abs_index, &user_rule_msg,
						   rule->rule_cfg.masked.size,
						   &found);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	if (found == 0) {
		pr_err("There is mismatch between rule (key and mask) itself and priority. "
				"On this priority was defined another rule\n");
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -EINVAL;
	}

	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	*(uint32_t *)ptr_in_msg = (uint32_t)(abs_index & DPTBL_TCAM_ACL_TENUM_MASK);

	/*fill action*/
	err = fill_dptbl_action
			(((struct dptbl_tcam_acl_add_entry_message *)ptr_in_msg)->tlur,
					action);
	if (err) {
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return err;
	}

	/*execute command*/
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPTBL_TCAM_RULE_REPLACE, &status, &mtypeout,
				(void**)&ptr_out_msg);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	ASSERT_COND(!status);


	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return 0;
}

static int dptbl_modify_miss_action_tcam_acl(struct dptbl* dptbl,
                             struct dptbl_action *action)
{

	int abs_index;

	uint8_t *ptr_in_msg, *ptr_out_msg;
	void *cmd_cfg;
	int err, err_tmp;
	uint32_t *mtypein_addr;
	uint16_t status;
	uint32_t mtypeout;
	uint32_t last_rule_idx;

	ASSERT_COND(dptbl->type == DPTBL_TCAM_ACL);


	if ((dptbl->action_on_miss_opcode & DPTBL_ACTION_ON_MISS_LOGICAL) == 0) {
			pr_err("this table wasn't conifigured as miss action, "
						"impossible tp modify\n");
			return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	last_rule_idx = dptbl_fix_tcam_index(dptbl->max_rules, dptbl->num_of_entries_per_key ,dptbl);
	abs_index = dptbl->entries[last_rule_idx].abs_index;

	*mtypein_addr = (uint16_t)(dptbl->tid)
			| ( (uint32_t) TCAM_MAX_KEY_SIZE << 16);
	
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	*(uint32_t *)ptr_in_msg = (uint32_t)(abs_index & DPTBL_TCAM_ACL_TENUM_MASK);

	/*fill action*/
	err = fill_dptbl_action
			(((struct dptbl_tcam_acl_add_entry_message *)ptr_in_msg)->tlur,
					action);
	if (err) {
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return err;
	}

	/*execute command*/
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPTBL_TCAM_RULE_REPLACE, &status, &mtypeout,
				(void**)&ptr_out_msg);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	ASSERT_COND(!status);


	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return 0;

}

static int dptbl_flush_entries_tcam_acl (struct dptbl* dptbl,
											uint8_t *ptr,
											void *cmd_cfg,
											uint32_t *mtypein_addr)
{
	uint32_t i = 0;
	int abs_index;
	int err;
	int init = 0;
	uint32_t entry_idx;
	uint32_t tmp;
	int tcam_key_size;

	tcam_key_size = ctlu_get_tcam_key_size();
	CHECK_COND_RETVAL(tcam_key_size >= 0, tcam_key_size, "Could not get platform TCAM key size\n");

	for (i = 0; i < dptbl->max_rules; i++)
	{
		entry_idx = dptbl_fix_tcam_index(i, dptbl->num_of_entries_per_key ,dptbl);
		if (DPTBL_IS_ENTRY_INIT(dptbl, entry_idx)) {
			abs_index = dptbl->entries[entry_idx].abs_index;
			/*execute delete rule*/
			err = execute_dptbl_delete_tcam_acl_entry(dptbl, ptr,cmd_cfg, abs_index);
			if (err) {
				pr_err("Failed to delete TCAM rule... continue to next rule\n");
				continue;
			}
			dptbl_update_tcam_entries(dptbl, entry_idx, (int)dptbl->real_key_size, init);

			if( dptbl->real_key_size==DPTBL_REAL_SIZE_UNINIT ) {
				pr_warn("Invalid table configuration: rule present but key size not initialized...\n");
				continue;
			}

			if( dptbl->real_key_size <= DPTBL_KEY_ENTRY_SIZE )
				continue;

			if( tcam_key_size == TCAM_MAX_KEY_SIZE )
				/* platforms with large TCAM entries */
				continue;

			/* delete upper half of the rule */
			abs_index++;
			tmp = *mtypein_addr;
			*mtypein_addr = (uint16_t)(dptbl->tid) | ( (uint32_t)(tcam_key_size) << 16);
			/*execute delete rule*/
			err = execute_dptbl_delete_tcam_acl_entry(dptbl, ptr,cmd_cfg, abs_index);
			*mtypein_addr = tmp;
			if (err) {
				pr_warn("Failed to delete second half of TCAM rule\n");
				continue;
			}
		}
	}

	if( dptbl->action_on_miss_opcode & DPTBL_ACTION_ON_MISS_LOGICAL ) {
		entry_idx = dptbl_fix_tcam_index(dptbl->max_rules, dptbl->num_of_entries_per_key, dptbl);
		if (DPTBL_IS_ENTRY_INIT(dptbl, entry_idx)) {
			abs_index = dptbl->entries[entry_idx].abs_index;
			tmp = *mtypein_addr;
			*mtypein_addr = (uint16_t)(dptbl->tid) | ( (uint32_t)(tcam_key_size) << 16);
			/* execute delete rule */
			err = execute_dptbl_delete_tcam_acl_entry(dptbl, ptr, cmd_cfg, abs_index);
			*mtypein_addr = tmp;
			if (err) {
				pr_err("Failed to delete miss rule\n");
				return err;
			}
			dptbl_update_tcam_entries(dptbl, entry_idx, TCAM_MAX_KEY_SIZE, init);

			if( tcam_key_size == TCAM_MAX_KEY_SIZE )
				return 0;

			/* delete upper half of the rule */
			abs_index++;
			tmp = *mtypein_addr;
			*mtypein_addr = (uint16_t)(dptbl->tid) | ( (uint32_t)(tcam_key_size) << 16);
			err = execute_dptbl_delete_tcam_acl_entry(dptbl, ptr, cmd_cfg, abs_index);
			*mtypein_addr = tmp;
			if (err) {
				pr_warn("Failed to delete second half of miss rule from TCAM table\n");
				return err;
			}
		}
	}

	return 0;
}

static int dptbl_query_entries_tcam_acl(struct dptbl* dptbl, struct dump_table_entry *entries, int max_entries, uint16_t *num_of_queried_entries)
{
	int err, err1 = 0;
	uint32_t i;
	uint32_t entry_idx;
	uint8_t *ptr_in_msg;
	uint32_t *mtypein_addr;
	void *cmd_cfg;

	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu, &cmd_cfg, (void*)&ptr_in_msg, &mtypein_addr);
	if (err) {
		pr_err("Error while building ctlu command config\n");
		return err;
	}

	*mtypein_addr = (uint16_t)(dptbl->tid) | (( (uint32_t)dptbl->real_key_size) << 16);

	for (i = 0; i < dptbl->max_rules; i++)
	{
		entry_idx = dptbl_fix_tcam_index(i, dptbl->num_of_entries_per_key, dptbl);
		if (DPTBL_IS_ENTRY_INIT(dptbl, entry_idx)) {
			if(*num_of_queried_entries >= max_entries) {
				pr_warn("More entries are available but the allocated area is too small\n");
				break;
			}

			err1 = execute_dptbl_query_tcam_acl_entry(dptbl, ptr_in_msg, cmd_cfg, dptbl->entries[entry_idx].abs_index, dptbl->max_key_size, &entries[*num_of_queried_entries]);
			if (err1) {
				pr_err("Error in executing dptbl query tcam entry\n");
				break;
			}

			entries[*num_of_queried_entries].rule_index = (uint16_t)i;
			*num_of_queried_entries += 1;
		}
	}

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	if (err)
		pr_err("Error while releasing ctlu command config\n");

	return err1;

}

static int dptbl_query_entries_em(struct dptbl* dptbl, struct dump_table_entry *entries, int max_entries, uint16_t *num_of_queried_entries)
{
	int err;
	uint8_t key[DPNI_MAX_KEY_SIZE];
	uint64_t ruleid;
	uint32_t size;

	size = dptbl->real_key_size;

	do {
		err = dptbl_get_next_ruleid(dptbl, &ruleid);
		if( err ) {
			pr_err("No entry found for ruleid %08x%08x\n", (uint32_t)((ruleid>>32)&0xffffffff), (uint32_t)(ruleid&0xffffffff));
			break;
		}

		if( ruleid==0 ) {
			err = 0;
			break;
		}

		if(*num_of_queried_entries >= max_entries) {
			pr_warn("More entries are available but the allocated area is too small\n");
			err = 0;
			break;
		}

		err = dptbl_query_with_ruleid(dptbl, &ruleid, key, (int)size);
		if( err ) {
			pr_err("Query failed for ruleid %08x%08x\n", (uint32_t)((ruleid>>32)&0xffffffff), (uint32_t)(ruleid&0xffffffff));
			break;
		}

		memcpy(&entries[*num_of_queried_entries].key, key, size);

		*num_of_queried_entries += 1;
		ruleid++;
	} while (ruleid!=0);

	return err;
}

static int dptbl_add_rule_tcam_acl(struct dptbl* dptbl,
                             struct dptbl_rule *rule,
                             struct dptbl_action *action,
                             int restore)
{

	uint8_t *ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp;
	int abs_index;
	int add = 1, init = 1;
	uint32_t max_rules;
	uint32_t max_entries;
	struct tbl_rule_output rule_output;
	uint32_t last_rule_idx;
	uint32_t priority_idx;
	uint8_t temp_num_of_entries_per_key = 0;

	ASSERT_COND(dptbl->type == DPTBL_TCAM_ACL);

	max_rules  = dptbl->max_rules;
	
	if ((dptbl->real_key_size == DPTBL_REAL_SIZE_UNINIT) && (rule->rule_cfg.masked.size > dptbl->max_key_size))
	{
		temp_num_of_entries_per_key = (uint8_t)DPTBL_TCM_GET_NUM_OF_ENTRIES(rule->rule_cfg.masked.size);
		max_rules  = dptbl->max_rules/temp_num_of_entries_per_key;
	}
	else
	{
		temp_num_of_entries_per_key = dptbl->num_of_entries_per_key;
		max_rules  = dptbl->max_rules;
	}

	max_entries = dptbl_fix_tcam_index(max_rules, temp_num_of_entries_per_key, dptbl);

	if ((rule->rule_cfg.masked.size > TCAM_MAX_KEY_SIZE)||
		(rule->rule_cfg.masked.size == 0)){
		pr_err("rule key_size should be less or equal to the max_key_size "
				"and rule key_size can not be 0. "
				"max_key_size is defined as %d, current rule = %d\n",
				TCAM_MAX_KEY_SIZE,rule->rule_cfg.masked.size);
		return -EINVAL;

	}
	/*new rule can not be added due to the reach of max_num_of_rules*/
	/* In case of restore, used_rules = max_rules */
	if ((dptbl->used_rules == max_rules) && !restore)
	{
		pr_err("can not add rule to this table since - exceed the "
				 "max_num_of_rules declared in the creation of the policy "
				 "max_rules was defined as %d\n", max_rules);
		return -EDOM;
	}

	/*as priority is index between 0 - and max_rules can not be greater than
	 * max_rules*/
	if(rule->rule_cfg.masked.priority >= max_entries)
	{
		pr_err("Priority =%d is of the range. rule should be in the range %d, %d.\n",
				rule->rule_cfg.masked.priority, 0, max_entries);
		return -EINVAL;
	}
	
	/*check if entry with this priority was not initialized ,
	 * otherwise can not be added*/
	priority_idx = dptbl_fix_tcam_index((uint32_t)rule->rule_cfg.masked.priority,
										temp_num_of_entries_per_key,dptbl);

	/* Is already init, do not verify at restore stage*/
	if (DPTBL_IS_ENTRY_INIT(dptbl, priority_idx) && !restore)
	{
		pr_err("Rule with the same priority = %d was initialized."
				"Change priority or remove existing rule\n",
				rule->rule_cfg.masked.priority);
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	if (((dptbl->used_rules == 0) || dptbl->restore) &&
		(dptbl->action_on_miss_opcode & DPTBL_ACTION_ON_MISS_LOGICAL)) {
		if(dptbl->restore)
			dptbl->restore = 0;
		/*get result of the logical miss*/
		memset(ptr_in_msg, 0, sizeof (struct dptbl_tcam_acl_query_entry_message));
		last_rule_idx = dptbl_fix_tcam_index(max_rules, temp_num_of_entries_per_key ,dptbl);
		/*get absolute index*/
		abs_index = dptbl->entries[last_rule_idx].abs_index;
		/*fill nessage for querry of result*/
		((struct dptbl_tcam_acl_query_entry_message *)ptr_in_msg)->tenum =
				(uint32_t)(abs_index & DPTBL_TCAM_ACL_TENUM_MASK);
		*mtypein_addr = (uint16_t)(dptbl->tid)
				| ((uint32_t) TCAM_MAX_KEY_SIZE << 16);
		/*execute command*/
		err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL,
								cmd_cfg, /* interface handle */
								MNG_CMD_DPTBL_TCAM_RULE_QUERY,
		                        &status, &mtypeout,
		                        (void**)&ptr_out_msg);
		if (err) {
			err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			ASSERT_COND(!err_tmp);
			return err;
		}
		ASSERT_COND(!status);
		memcpy(&rule_output, ptr_out_msg, sizeof(struct tbl_rule_output));

		memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
		memcpy(&((struct dptbl_tcam_acl_add_entry_message *)ptr_in_msg)->tlur,
				&rule_output.tlur, 20);
		((struct dptbl_tcam_acl_query_entry_message *)ptr_in_msg)->tenum =
				(uint32_t)(abs_index & DPTBL_TCAM_ACL_TENUM_MASK);
		*mtypein_addr = (uint16_t)(dptbl->tid)
				| ((uint32_t) TCAM_MAX_KEY_SIZE << 16);
		err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
				MNG_CMD_DPTBL_TCAM_RULE_REPLACE, &status, &mtypeout,
					(void**)&ptr_out_msg);
		if (err) {
			err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			ASSERT_COND(!err_tmp);
			return err;
		}
		ASSERT_COND(!status);
	}
	
	/*get absolute index*/
	abs_index = dptbl->entries[priority_idx].abs_index;
	
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	/* fill ptr_in_msg with mask */
	if (rule->rule_cfg.masked.mask)
		memcpy(((struct dptbl_tcam_acl_add_entry_message *)ptr_in_msg)->mask,
			rule->rule_cfg.masked.mask,
			rule->rule_cfg.masked.size);
	else
		memset(((struct dptbl_tcam_acl_add_entry_message *)ptr_in_msg)->mask,
			0xff,
			rule->rule_cfg.masked.size);

	/* fill ptr_in_msg with key;
	 * Note: TCAM seems to automatically masks out the key upon insertion;
	 * we will do the same in software, as a guarantee; this means that the
	 * caller could have the rule insertion rejected
	 */
	dptbl_memcpy_key_masked(
		((struct dptbl_tcam_acl_add_entry_message *)ptr_in_msg)->key,
		rule->rule_cfg.masked.key,
		((struct dptbl_tcam_acl_add_entry_message *)ptr_in_msg)->mask,
		rule->rule_cfg.masked.size);

	/*fill action*/
	err = fill_dptbl_action
			(((struct dptbl_tcam_acl_add_entry_message *)ptr_in_msg)->tlur,
					action);
	if (err) {
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return err;
	}
	((struct dptbl_tcam_acl_add_entry_message *)ptr_in_msg)->info =
			(uint32_t)(abs_index & DPTBL_TCAM_ACL_TENUM_MASK);
	*mtypein_addr = (uint16_t)(dptbl->tid)
			| ((uint32_t)rule->rule_cfg.masked.size << 16);
	/*execute command*/
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPTBL_TCAM_RULE_CREATE, &status, &mtypeout,
				(void**)&ptr_out_msg);
	if (err) {
		if (status) {
			if (status & MNG_CMD_STATUS_NORSC) {
				pr_err("Function dptbl_add_rule  for tcam ACL:\n"
				" CTLU rule is not created,"
				"not enough resource available\n");
				err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu,
							cmd_cfg);
				ASSERT_COND(!err_tmp);
				return -ENOSPC;
			}
		}
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu,
					cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	/* Need to be investigated - different behavior after WRIOP reset */
	if (((status & MNG_CMD_STATUS_TLUMISS) != MNG_CMD_STATUS_TLUMISS) && !restore) {
		pr_err("Function dptbl_add_rule  for tcam ACL:\n"
		" CTLU rule exists - can not add - prior to add - remove\n");
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu,
					cmd_cfg);
		ASSERT_COND(!err_tmp);
		return -EEXIST;
	}

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	/* Do not modify them at restore stage */
	if (!restore) {
		/*update real_key_eize if wasn't updated earlier*/
		if (dptbl->real_key_size == DPTBL_REAL_SIZE_UNINIT) {
			dptbl->real_key_size = rule->rule_cfg.masked.size;
			if (dptbl->real_key_size > dptbl->max_key_size) {
				dptbl->max_rules = dptbl->max_rules / 2;
				dptbl->num_of_entries_per_key = temp_num_of_entries_per_key;
			}
		}

		/*sign entry as inintialized*/
		dptbl_update_tcam_entries(dptbl, priority_idx,
				(int)rule->rule_cfg.masked.size, init);

		/*update number of used entry (+1)*/
		DPTBL_UPDATE_USED_NUM_OF_RULES(dptbl, add);
	}

	return 0;
}

static int dptbl_get_action_tcam_acl(struct dptbl* dptbl, struct dptbl_rule *rule,
								struct dptbl_action *action)
{
	uint8_t *ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp = 0;
	int abs_index;
	uint32_t priority_idx;

	ASSERT_COND(dptbl->type == DPTBL_TCAM_ACL);

	if (dptbl->real_key_size == DPTBL_REAL_SIZE_UNINIT) {
		pr_err("Remove rule can not be executed before adding the rule\n");
		return -EINVAL;
	}
	if (dptbl->real_key_size != rule->rule_cfg.masked.size) {
		pr_err("key_size for every rule in the table MUST be the same\n");
		return -EINVAL;
	}

	memset(action, 0, sizeof (struct dptbl_action));

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
								 &cmd_cfg,
								 (void*)&ptr_in_msg,
								 &mtypein_addr);
	ASSERT_COND(!err);

	/* fill ptr_in_msg with key */
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_QUERY_SIZE);
	memcpy(ptr_in_msg, rule->rule_cfg.masked.key,
		(uint32_t)rule->rule_cfg.masked.size);

	/*get absolute index*/
	priority_idx = dptbl_fix_tcam_index((uint32_t)rule->rule_cfg.masked.priority,dptbl->num_of_entries_per_key, dptbl);
	abs_index = dptbl->entries[priority_idx].abs_index;

	fill_dptbl_query_tcam_acl_result_entry_message(ptr_in_msg, abs_index);
	/*execute query for the key to be sure this rule doen't exist*/
	*mtypein_addr = (uint16_t)(dptbl->tid)
			| ((uint32_t)rule->rule_cfg.masked.size << 16);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
				MNG_CMD_DPTBL_TCAM_RULE_QUERY, &status, &mtypeout,
				(void**)&ptr_out_msg);

	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}

	/*status MNG_CMD_STATUS_TLUMISS says that this rule deson't exist*/
	if ((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS) {
		pr_err("Function dptbl_get_action_tcam_acl for TCAM: "
		"matching rule is not found in the table.\n");
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -EEXIST;
	}

	get_dptbl_action(((struct tbl_rule_output *)ptr_in_msg)->tlur,
									action);

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return 0;
}

static int dptbl_check_params_tcam(struct dptbl_cfg *init_params)
{

	if ((init_params->max_key_size >= DPTBL_MAX_KEY_SIZE_EM)
		|| (init_params->max_key_size == 0))
	{
		pr_err("Function dptbl_check_params_em - check parameters for "
				"creating exact match table has wrong parameter"
				"key_size can not excced %d", DPTBL_MAX_KEY_SIZE_EM);
		return -EINVAL;

	}

#if 0
	if ((init_params->options & DPTBL_OPTIONS_OPTIMIZIED_DISCARD) &&
		(!init_params->action_on_miss ||
		(init_params->action_on_miss->next_action!=
				DPTBL_ACTION_DONE)))
	{
		pr_err("Function dptbl_check_params_tcam - check parameters for "
				"creating tcam acl match table has inconsistent parameter"
				":options & DPTBL_ACTION_DISCARD but the next action for "
				"Miss rule is not defined as DISCARD\n");
		return -EINVAL;
	}
	if (init_params->action_on_miss &&
		((init_params->options & DPTBL_OPTIONS_OPTIMIZIED_DISCARD)!=
				DPTBL_OPTIONS_OPTIMIZIED_DISCARD))
	{
		pr_err("Function dptbl_check_params_tcam - check parameters for "
				"creating tcam acl match table has invalid parameters"
				"the next action for "
				"Miss rule  if defined MUST be DISCARD with options "
				"DPTBL_OPTIONS_OPTIMIZIED_DISCARD\n");
		return -EINVAL;
	}
#endif
	return 0;
}

static void build_create_tbl_message(struct ctlu *ctlu, uint8_t *ptr,
                                     struct dptbl_tmp_init_params *params)
{
	struct lookup_tbl *ptr_msg = (struct lookup_tbl *)ptr;
	uint8_t agt = 0;
	uint64_t  units;

	if ((uint32_t)params->aging_threshold) {
		units = SEC_TO_TS_UNITS(((uint64_t)params->aging_threshold));
		NEXT_POWER_OF_2(units, units);
		LOG2(units, agt);
	}
	ptr_msg->info = params->type | params->mem_type
			| (agt << DPTBL_AGT_SHIFFT)
	        | (params->action_on_miss_opcode & DPTBL_ACTION_MISS_MASK)
	        | (params->icid & DPTBL_MAX_NUM_OF_ICIDS)
	        | ((params->options & DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION) ?
	        		DPTBL_BDI : 0);
	ptr_msg->max_rules = params->max_rules;
	ptr_msg->max_entries = params->max_rules
	                       * params->num_of_entries_per_key;
	ptr_msg->commited_entries = ptr_msg->max_entries;
}

static int tcam_acl_specific(struct dptbl * dptbl)
{
	struct resman_res_req	res_req ;
	int 				*res_ids = NULL;
	int i = 0;
	int err, abs_index;
	char str[16];
	uint32_t num_entries;
	int tcam_key_size;

	tcam_key_size = ctlu_get_tcam_key_size();
	CHECK_COND_RETVAL(tcam_key_size >= 0, tcam_key_size);

	num_entries = dptbl_fix_tcam_index(dptbl->conf_table_rules, dptbl->num_of_entries_per_key,dptbl);

	dptbl->entries = (struct dptbl_entry *)fsl_malloc
					(num_entries *
					sizeof(struct dptbl_entry));
	if (!dptbl->entries)
	{
		pr_err("no memory for allocation internal data structure");
		return -ENOMEM;
	}

	memset(dptbl->entries, 0, num_entries *
					sizeof(struct dptbl_entry));


	/*get resources from resource manager
	supposed to be in ascending order*/
	memset(&res_req, 0, sizeof(struct resman_res_req));
	ctlu_get_str(ctlu_get_iop_id(dptbl->dptbl_mng->ctlu),
					ctlu_get_type(dptbl->dptbl_mng->ctlu), str);
	snprintf(res_req.type, sizeof(res_req.type), "tcame.%s", str);
	res_req.num = num_entries;
	res_req.options = DPRC_RES_REQ_OPT_ALIGNED;
	res_req.id_base_align = 1;
	res_ids = (int *)fsl_malloc(sizeof(int) * res_req.num);
	if (!res_ids)
	{
		pr_err("no memory for internal data structure");
		return -ENOMEM;
	}
	memset(res_ids, NO_AVAILABLE_RESMAN_IDS, sizeof(int) * res_req.num);
	err =  resman_bind(ctlu_get_resman(dptbl->dptbl_mng->ctlu), &res_req, res_ids);
	if (err) {
		pr_err("user asked for table with max_num_of_rules greater than "
				"system can supply - Please try initialization of this table later."
				"Maybe the required resources will be available later.\n");
		fsl_free(res_ids);
		return err;
	}
	/*fill the relevant data structure with returned indexes
	 * in ascending order */
	for (i = 0; i < num_entries; i++)
	{
		abs_index = res_ids[i];
		add_abs_index_to_array_priority_abs_index_in_asc_order
		(dptbl->entries, abs_index,i+1,num_entries);
	}
	fsl_free(res_ids);
	return 0;
}

static int dptbl_store_em_miss_rule_key(struct dptbl *dptbl, uint8_t *key)
{
	if( dptbl->key_storage.miss_key_data==NULL ) {
		dptbl->key_storage.miss_key_data = dptbl_get_key_ptr_from_storage(&dptbl->key_storage, -1);
	}
	memcpy(dptbl->key_storage.miss_key_data, key, DPTBL_MAX_KEY_SIZE_EM);

	return 0;
}

static int dptbl_delete_em_miss_rule(struct dptbl *dptbl)
{
	int add = 0;
	uint8_t *ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err = 0, err_tmp = 0;

	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
			&cmd_cfg,
			(void*)&ptr_in_msg,
			&mtypein_addr);
	CHECK_COND_RETVAL(err==0, err);

	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
	memcpy(ptr_in_msg, dptbl->key_storage.miss_key_data, DPTBL_MAX_KEY_SIZE_EM);

	*mtypein_addr = (uint16_t)(dptbl->tid);
	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPTBL_RULE_DEL, &status, &mtypeout,
			(void**)&ptr_out_msg);
	if( status ) {
		pr_err("Rule is not found, no delete is executed.\n");
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		CHECK_COND_RETVAL(err_tmp==0, err, "Failed to release command memory space\n");
		return -EINVAL;
	}

	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		CHECK_COND_RETVAL(err_tmp==0, err, "Failed to release command memory space\n");
		return err;
	}

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	CHECK_COND_RETVAL(err_tmp==0, err, "Failed to release command memory space\n");

	return 0;
}

static int dptbl_flush_em_entries(struct dptbl* dptbl)
{
	int i;
	int err;
	struct dptbl_rule rule;

	if( dptbl->key_storage.miss_key_data ) {
		dptbl_delete_em_miss_rule(dptbl);
		dptbl->key_storage.miss_key_data = NULL;
	}

	for( i=0 ; i<dptbl->max_rules ; i++ ) {
		if( dptbl->key_storage.key_array[i]!=NULL ) {
			memset(&rule, 0, sizeof(struct dptbl_rule));
			rule.rule_cfg.exact.key = dptbl->key_storage.key_array[i];
			rule.rule_cfg.exact.size = dptbl->real_key_size;
			err = dptbl->f_remove_rule(dptbl, &rule);
			if( err ) {
				pr_warn("Could not delete CTLU rule\n");
			}
			dptbl->key_storage.key_array[i] = NULL;
		}
	}

	return 0;
}

static int dptbl_create_em_key_storage(struct dptbl *dptbl)
{
	uint32_t alloc_size;
	uint8_t *ptr;
	uint32_t key_array_size;
	uint32_t rules_size;

	memset(&dptbl->key_storage, 0, sizeof(struct em_key_storage));

	// allocate memory for storage
	key_array_size = dptbl->max_rules * sizeof(uint8_t **);
	rules_size = DPTBL_MAX_KEY_SIZE_EM + dptbl->max_rules*DPTBL_MAX_KEY_SIZE_EM;
	alloc_size = key_array_size + rules_size;
	ptr = fsl_malloc(alloc_size);
	CHECK_COND_RETVAL(ptr!=NULL, -ENOMEM, "Could not allocate memory");
	memset(ptr, 0, alloc_size);

	// init storage
	dptbl->key_storage.data = ptr;
	dptbl->key_storage.key_array = (unsigned char **)dptbl->key_storage.data;
	dptbl->key_storage.key_size = DPTBL_MAX_KEY_SIZE_EM;
	dptbl->key_storage.miss_key_offset = key_array_size;
	dptbl->key_storage.key_offset = key_array_size + dptbl->key_storage.key_size;

	return 0;
}

struct dptbl* create_tbl(struct dptbl_mng *dptbl_mng,
                         struct dptbl_tmp_init_params *init_params)
{
	struct dptbl * dptbl;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	uint8_t *ptr_in_msg, *ptr_out_msg;
	int err, err_tmp;
	int init = 1;
	int abs_index;
	uint32_t last_rule_idx;
	int tcam_key_size;

	if ((init_params->max_rules == 0) || (init_params->max_key_size == 0))
		return NULL;

	if ((init_params->options & DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION) !=
			DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION) {
		if (init_params->icid > DPTBL_MAX_NUM_OF_ICIDS) {
			pr_err("icid is out of range. "
					"The allowed range is 0 - %d\n",DPTBL_MAX_NUM_OF_ICIDS);
			return NULL;
		}
	}

	dptbl = (struct dptbl *)fsl_malloc(sizeof(struct dptbl));
	if (!dptbl)
	{
		pr_err("no memory for allocation internal data structure");
		return NULL;
	}
	memset(dptbl, 0, sizeof(struct dptbl));

	dptbl->type = init_params->type;
	dptbl->max_key_size = init_params->max_key_size;
	dptbl->f_add_rule = init_params->f_add_rule;
	dptbl->f_modify_miss_action = init_params->f_modify_miss_action;
	dptbl->f_modify_rule = init_params->f_modify_rule;
	dptbl->f_get_action = init_params->f_get_action;
	dptbl->f_remove_rule = init_params->f_remove_rule;
	dptbl->max_rules = init_params->max_rules;
	dptbl->conf_table_rules = init_params->max_rules;
	dptbl->dptbl_mng = dptbl_mng;
	dptbl->action_on_miss_opcode = init_params->action_on_miss_opcode;
	dptbl->real_key_size = DPTBL_REAL_SIZE_UNINIT;
	dptbl->num_of_entries_per_key = init_params->num_of_entries_per_key;
	
	if (dptbl->type == DPTBL_TCAM_ACL) {
		err = tcam_acl_specific(dptbl);
		if (err) {
			free_dptbl(dptbl);
			return NULL;
		}
	}
	else {
		err = dptbl_create_em_key_storage(dptbl);
		if( err ) {
			free_dptbl(dptbl);
			return NULL;
		}
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	tcam_key_size = ctlu_get_tcam_key_size();
	CHECK_COND_RETVAL(tcam_key_size >= 0, NULL);

	/*create table*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_CREATE_SIZE);

	build_create_tbl_message(dptbl_mng->ctlu, ptr_in_msg, init_params);

	err = ctlu_execute_cmd(dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
				MNG_CMD_DPTBL_CREATE, &status, &mtypeout,
				(void**)&ptr_out_msg);
	if (err) {
		if ((status & MNG_CMD_STATUS_NORSC) == MNG_CMD_STATUS_NORSC) {
			pr_err("Function create_tbl  "
				" CTLU table is not created,"
				"not enough resource available\n");

		}
		err_tmp = ctlu_free_cmd_cfg(dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		free_dptbl(dptbl);
		return NULL;

	}
	dptbl->tid = *(uint16_t *)ptr_out_msg;

	/*execute add rule for Miss action*/
	if (init_params->action_on_miss) {
			if (dptbl->action_on_miss_opcode &
				DPTBL_ACTION_ON_MISS_PROGRAMMED) {
				
		if (TCAM_KEY_SIZE == TCAM_MAX_KEY_SIZE)
			dptbl->max_rules -= 1;
		else
			dptbl->max_rules -= 2;

		memset(ptr_in_msg, 0,
			sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
		err = fill_dptbl_action(((struct tbl_rule *)ptr_in_msg)->tlur,
					init_params->action_on_miss);
		if (err) {
			err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			ASSERT_COND(!err_tmp);
			free_dptbl(dptbl);
			return NULL;
		}
		err = dptbl_store_em_miss_rule_key(dptbl, ((struct tbl_rule *)ptr_in_msg)->key);
		if( err ) {
			err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			free_dptbl(dptbl);
			CHECK_COND_RETVAL(err_tmp!=0, NULL);
		}

		*mtypein_addr = (uint16_t)(dptbl->tid);
		err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
					MNG_CMD_DPTBL_RULE_CREATE, &status, &mtypeout,
					(void**)&ptr_out_msg);
#if 0
	ASSERT_COND((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS);
#endif
		if (err) {
			if (status)
			{
				if (status & MNG_CMD_STATUS_NORSC) {
					pr_err("Function dptbl_add_rule  "
						"for exact match:\n"
						" CTLU rule is not created,"
						"not enough resource available\n");
					err_tmp =
					ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu,
					                  cmd_cfg);
					ASSERT_COND(!err_tmp);
					free_dptbl(dptbl);
					return NULL;
				}
			}
			err_tmp =
			ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu,
			                  cmd_cfg);
			ASSERT_COND(!err_tmp);
			free_dptbl(dptbl);
			return NULL;
		
		}
			}
			else if (dptbl->action_on_miss_opcode &
						DPTBL_ACTION_ON_MISS_LOGICAL) {
				ASSERT_COND(dptbl->entries);
				
				if (TCAM_KEY_SIZE == TCAM_MAX_KEY_SIZE)
					dptbl->max_rules -= 1;
				else
					dptbl->max_rules -= 2;

				last_rule_idx = dptbl->max_rules;
				if (dptbl->type == DPTBL_TCAM_ACL) {
					last_rule_idx = dptbl_fix_tcam_index(last_rule_idx,dptbl->num_of_entries_per_key, dptbl);
				}
				/*get absolute index*/
				abs_index =
						dptbl->entries[last_rule_idx].abs_index;
				/* set key , mask with 0 */
				memset(ptr_in_msg, 0,
						sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);

				/*fill action*/
				err = fill_dptbl_action
						(((struct dptbl_tcam_acl_add_entry_message *)
								ptr_in_msg)->tlur,
								init_params->action_on_miss);
				if (err) {
					err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
					ASSERT_COND(!err_tmp);
					free_dptbl(dptbl);
					return NULL;
				}

				((struct dptbl_tcam_acl_add_entry_message *)ptr_in_msg)->info =
					(uint32_t)(abs_index & DPTBL_TCAM_ACL_TENUM_MASK);
				*mtypein_addr = (uint16_t)(dptbl->tid)
						| ((uint32_t) TCAM_MAX_KEY_SIZE << 16);
				/*execute command*/
				err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
						MNG_CMD_DPTBL_TCAM_RULE_CREATE, &status, &mtypeout,
							(void**)&ptr_out_msg);
				if (err) {
					if (status) {
						if (status & MNG_CMD_STATUS_NORSC) {
							pr_err("Function dptbl_add_rule  for tcam ACL:\n"
							" CTLU rule is not created,"
							"not enough resource available\n");
							err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu,
										cmd_cfg);
							ASSERT_COND(!err_tmp);
							free_dptbl(dptbl);
							return NULL;
						}
					}
					err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu,
								cmd_cfg);
					ASSERT_COND(!err_tmp);
					free_dptbl(dptbl);
					return NULL;
					
				}
				/*sign last entry as inintialized*/
				if (dptbl->type == DPTBL_TCAM_ACL) {
					dptbl_update_tcam_entries(dptbl, last_rule_idx, TCAM_MAX_KEY_SIZE, init);
				}
				else {
					DPTBL_UPDATE_ENTRY_INIT(dptbl, last_rule_idx, init);
				}

		}
	}
	err = ctlu_free_cmd_cfg(dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return dptbl;

}
int dptbl_get_attributes(struct dptbl* dptbl,
						struct dptbl_attr *attr)
{
	int err;
	uint32_t *mtypein_addr;
	uint16_t status;
	void *cmd_cfg;
	uint8_t *ptr_in_msg, *ptr_out_msg;
	uint32_t mtypeout;
	struct lookup_tbl_query  tbl_query;

	ASSERT_COND(dptbl);
	ASSERT_COND(dptbl);

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	/*execute query for the key to be sure this rule doen't exist*/
	*mtypein_addr = (uint16_t)(dptbl->tid);

	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPTBL_PARAMS_QUERY, &status, &mtypeout,
				(void**)&ptr_out_msg);
	if (err)
	{
		if (status & MNG_CMD_STATUS_TIDE) {
			pr_err("This table with tableId = %d doesn't exist.\n",
					dptbl->tid);
			err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			ASSERT_COND(!err);
			return -ENODEV;
		}
	}

	ASSERT_COND(!err);
	ASSERT_COND(!status);

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	memcpy(&tbl_query, ptr_out_msg, sizeof(struct lookup_tbl_query));
	attr->max_rules = tbl_query.lookup_tbl.max_rules;
	attr->current_rules = tbl_query.current_rules;
	attr->delete_process_ongoing =
			(tbl_query.lookup_tbl.info & DTBL_DELETE_PROCESS_OMGOING) ? 1 : 0;

	return 0;
}
int dptbl_delete(struct dptbl* dptbl)
{
	uint8_t *ptr_in_msg, *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	int err, err_tmp, i;
	char str[16];
	struct resman_res_req	res_req ;
	uint32_t num_tcam_entries;
	int tcam_key_size;


	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);
	
	*mtypein_addr = (uint16_t)(dptbl->tid)
			| (( (uint32_t)dptbl->real_key_size) << 16);
	if(dptbl->type == DPTBL_TCAM_ACL) {
		err = dptbl_flush_entries_tcam_acl(dptbl, ptr_in_msg, cmd_cfg, mtypein_addr);
		if (err) {
			err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
			ASSERT_COND(!err_tmp);
			return err;
		}
	}
	else {
		dptbl_flush_em_entries(dptbl);
	}

	/*execute query for the key to be sure this rule doen't exist*/
	*mtypein_addr = (uint16_t)(dptbl->tid);

	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPTBL_DEL, &status, &mtypeout,
				(void**)&ptr_out_msg);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	ASSERT_COND(!status);

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	memset(str, 0, sizeof(str));
	if (dptbl->type == DPTBL_TCAM_ACL) {
		tcam_key_size = ctlu_get_tcam_key_size();
		CHECK_COND_RETVAL(tcam_key_size >= 0, tcam_key_size);
		num_tcam_entries = dptbl_fix_tcam_index(dptbl->conf_table_rules, dptbl->num_of_entries_per_key,dptbl);

		ctlu_get_str(ctlu_get_iop_id(dptbl->dptbl_mng->ctlu),
				ctlu_get_type(dptbl->dptbl_mng->ctlu), str);
		snprintf(res_req.type, sizeof(res_req.type), "tcame.%s", str);
		for (i = 0; i < num_tcam_entries; i++)
				resman_unbind(ctlu_get_resman(dptbl->dptbl_mng->ctlu),
						res_req.type,
						dptbl->entries[i].abs_index);

	}

	free_dptbl(dptbl);

	return 0;

}

int dptbl_query(struct dptbl* dptbl, struct dump_table_entry *entries, int max_entries, uint16_t *num_entries)
{
	if(dptbl->type == DPTBL_TCAM_ACL)
		return dptbl_query_entries_tcam_acl(dptbl, entries, max_entries, num_entries);
	else
		return dptbl_query_entries_em(dptbl, entries, max_entries, num_entries);
}

#ifdef TKT011436
/**************************************************************************//**
 @Function     dptbl_mng_restore
*//***************************************************************************/
int dptbl_mng_restore(struct dptbl_mng_cfg *cfg, struct dptbl_mng *dptbl_mng)
{

	struct dptbl_mng_mem_map_set *regs;
	phys_addr_t addr;
	uint32_t ctsize;
	int i, id, err = 0;
	enum ctlu_type type = ctlu_get_type(cfg->ctlu);

	/* check parameters */
	if (tptbl_mng_check(cfg) != 0)
		return -ENAVAIL;
	
/*	err = ctlu_get_mem_base(cfg->ctlu, CTLU_DPTABLE_MNG,
	                        (void **)&dptbl_mng->regs);
	if (err) {
		fsl_free(dptbl_mng);
		return -ENAVAIL;
	}*/

	if ((type == CTLU_AIOP) || (type == CTLU_AIOP_MFLU)) {
		/* initialize the table descriptors list */
		regs = dptbl_mng->regs;
		addr = cfg->u.aiop_tbl_mng_cfg.int_list_paddr;
		iowrite32((uint32_t)(addr >> 32), &regs->iop_ctaddh);
		iowrite32((uint32_t)(addr), &regs->iop_ctaddl);
		pr_debug("Initialize PEB & external tables for AIOP-%s:\n",
				type == CTLU_AIOP ? "CTLU" : "MFLU");
		/* initialize the PEB & external tables */
		for (i = 0; i < DPTBL_MEM_TYPES; i++) {
			id = get_id_by_type(
			        cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].mem_type);
			regs = dptbl_mng->regs + (int)id;

			addr = cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].tbl_paddr;
			iowrite32((uint32_t)(addr >> 32), &regs->iop_ctaddh);
			iowrite32((uint32_t)(addr), &regs->iop_ctaddl);

			LOG2(cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].num_entries,
				ctsize);
			iowrite32(ctsize, &regs->iop_ctsize);
			pr_debug("MEM #%d (%s), ctsize:0x%x/entries:%d, bar:0x%x%08x\n",
					id, (id == 3 ? "PEB" : (id == 4 ? "DP-DDR" : "sys-DDR")),
					ctsize, cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].num_entries,
					UINT32_HI(cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].tbl_paddr),
					UINT32_LO(cfg->u.aiop_tbl_mng_cfg.mem_cfg[i].tbl_paddr));
		}
	}
	else {
	/*	if (cfg->u.l2sw_present) {
			regs = dptbl_mng->regs + get_id_by_type(DPTBL_PEB);
			iowrite32(0x0000000C, &regs->iop_ctsize);
		}*/
		if (ctlu_get_soc_options(cfg->ctlu) & CTLU_DESC_OPT_REDUCED_TCAM)
		{
			regs = dptbl_mng->regs + TABLE_ID_TCAM;
			iowrite32(ioread32(&regs->iop_ctsize) - 1, &regs->iop_ctsize);
		}
	}

	return err;
}

static int restore_tbl( struct dptbl *dptbl,
						const struct dptbl_mng *dptbl_mng,
                        struct dptbl_tmp_init_params *init_params)
{
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	uint8_t *ptr_in_msg, *ptr_out_msg;
	int err, err_tmp;
	int init = 1;
	int abs_index;
	uint32_t last_rule_idx;
	int tcam_key_size;

	pr_debug("Start restore TBL\n");
	if ((init_params->max_rules == 0) || (init_params->max_key_size == 0)) {
		pr_err("Number of rules or the key size is 0\n");
		return -EINVAL;
	}
	if ((init_params->options & DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION)
			!= DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION) {
		if (init_params->icid > DPTBL_MAX_NUM_OF_ICIDS) {
			pr_err("icid is out of range. "
			"The allowed range is 0 - %d\n", DPTBL_MAX_NUM_OF_ICIDS);
			return -EINVAL;
		}
	}
	//dptbl->real_key_size = DPTBL_REAL_SIZE_UNINIT;

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dptbl_mng->ctlu, &cmd_cfg, (void*) &ptr_in_msg,
			&mtypein_addr);
	CHECK_COND_RETVAL(err == 0, err, "ctlu_build_cmd_cfg Failed\n");
	tcam_key_size = ctlu_get_tcam_key_size();
	CHECK_COND_RETVAL(tcam_key_size >= 0, -EINVAL, "tcam_key_size is < 0\n");
	/*create table*/
	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_CREATE_SIZE);

	build_create_tbl_message(dptbl_mng->ctlu, ptr_in_msg, init_params);

	err = ctlu_execute_cmd(dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
	MNG_CMD_DPTBL_CREATE, &status, &mtypeout, (void**) &ptr_out_msg);
	if (err) {
		if ((status & MNG_CMD_STATUS_NORSC) == MNG_CMD_STATUS_NORSC) {
			pr_err("Function create_tbl  "
			" CTLU table is not created,"
			"not enough resource available\n");

		}
		err_tmp = ctlu_free_cmd_cfg(dptbl_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		free_dptbl(dptbl);
		return err;

	}
	dptbl->tid = *(uint16_t *) ptr_out_msg;

	/*execute add rule for Miss action*/
	if (init_params->action_on_miss) {
		if (dptbl->action_on_miss_opcode & DPTBL_ACTION_ON_MISS_PROGRAMMED) {

			memset(ptr_in_msg, 0,
					sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);
			err = fill_dptbl_action(((struct tbl_rule *) ptr_in_msg)->tlur,
					init_params->action_on_miss);
			if (err) {
				err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err_tmp);
				free_dptbl(dptbl);
				return err;
			}
			*mtypein_addr = (uint16_t) (dptbl->tid);
			err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPTBL_RULE_CREATE, &status, &mtypeout,
					(void**) &ptr_out_msg);
			if (err) {
				if (status) {
					if (status & MNG_CMD_STATUS_NORSC) {
						pr_err("Function dptbl_add_rule  "
						"for exact match:\n"
						" CTLU rule is not created,"
						"not enough resource available\n");
						err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu,
								cmd_cfg);
						ASSERT_COND(!err_tmp);
						free_dptbl(dptbl);
						return err;
					}
				}
				err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err_tmp);
				free_dptbl(dptbl);
				return err;

			}
		} else if (dptbl->action_on_miss_opcode & DPTBL_ACTION_ON_MISS_LOGICAL) {
			ASSERT_COND(dptbl->entries);

			last_rule_idx = dptbl->max_rules;
			if (dptbl->type == DPTBL_TCAM_ACL) {
				last_rule_idx = dptbl_fix_tcam_index(last_rule_idx,
						dptbl->num_of_entries_per_key, dptbl);
			}
			/*get absolute index*/
			abs_index = dptbl->entries[last_rule_idx].abs_index;
			/* set key , mask with 0 */
			memset(ptr_in_msg, 0,
					sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_CREATE_SIZE);

			/*fill action*/
			err =
					fill_dptbl_action(
							((struct dptbl_tcam_acl_add_entry_message *) ptr_in_msg)->tlur,
							init_params->action_on_miss);
			if (err) {
				err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err_tmp);
				free_dptbl(dptbl);
				return err;
			}

			((struct dptbl_tcam_acl_add_entry_message *) ptr_in_msg)->info =
					(uint32_t) (abs_index & DPTBL_TCAM_ACL_TENUM_MASK);
			*mtypein_addr = (uint16_t) (dptbl->tid)
					| ((uint32_t) TCAM_MAX_KEY_SIZE << 16);
			/*execute command*/
			err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPTBL_TCAM_RULE_CREATE, &status, &mtypeout,
					(void**) &ptr_out_msg);
			if (err) {
				if (status) {
					if (status & MNG_CMD_STATUS_NORSC) {
						pr_err("Function dptbl_add_rule  for tcam ACL:\n"
						" CTLU rule is not created,"
						"not enough resource available\n");
						err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu,
								cmd_cfg);
						ASSERT_COND(!err_tmp);
						free_dptbl(dptbl);
						return err;
					}
				}
				err_tmp = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
				ASSERT_COND(!err_tmp);
				free_dptbl(dptbl);
				return err;

			}
		}
	}
	err = ctlu_free_cmd_cfg(dptbl_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	pr_debug("Finish restore TBL\n");
	return err;

}

/**************************************************************************//**
 @Function     dptbl_restore
*//***************************************************************************/
int dptbl_restore( struct dptbl *dptbl,
						const struct dptbl_mng *dptbl_mng,
                         struct dptbl_cfg *init_params)
{

	int err;
	struct dptbl_tmp_init_params tmp_init_params;

	memset(&tmp_init_params, 0, sizeof(struct dptbl_tmp_init_params));
	switch (init_params->mem_type) {
	case (DPTBL_INT_MEMORY):
		tmp_init_params.mem_type = DPTBL_INT_MEM;
		break;
	case (DPTBL_PEB):
		tmp_init_params.mem_type = DPTBL_PEB_MEM;
		break;
	case (DPTBL_EXT_MEMORY_1):
		tmp_init_params.mem_type = DPTBL_EXT_MEM_1;
		break;
	case (DPTBL_EXT_MEMORY_2):
		tmp_init_params.mem_type = DPTBL_EXT_MEM_2;
		break;
	default:
		pr_err("Unknown mem_type \n");
		return -EINVAL;
	}
	switch (init_params->type) {
	case (DPTBL_TYPE_EXACT_MATCH):
		tmp_init_params.type = DTBL_EM;
		tmp_init_params.num_of_entries_per_key =
			DPTBL_GET_NUM_OF_ENTRIES(init_params->max_key_size);
		tmp_init_params.f_check_params = dptbl_check_params_em;

		if (init_params->action_on_miss) {
			if (init_params->action_on_miss->next_action
			    == DPTBL_ACTION_DONE
			    && (init_params->options
			        & DPTBL_OPTIONS_OPTIMIZIED_DISCARD)
			       == DPTBL_OPTIONS_OPTIMIZIED_DISCARD)
				tmp_init_params.action_on_miss_opcode =
				        DPTBL_ACTION_ON_MISS_DISCARD;
			else {
				tmp_init_params.action_on_miss_opcode =
				        DPTBL_ACTION_ON_MISS_PROGRAMMED;
				tmp_init_params.action_on_miss =
				        init_params->action_on_miss;
			}
		}
		break;
	case (DPTBL_TYPE_LPM):
			pr_err("Unsupported type of the table\n");
			return -EINVAL;
	case (DPTBL_TYPE_TCAM_ACL):
			tmp_init_params.type = DPTBL_TCAM_ACL;
			tmp_init_params.num_of_entries_per_key = 
					DPTBL_TCM_GET_NUM_OF_ENTRIES(init_params->max_key_size);
			tmp_init_params.f_check_params = dptbl_check_params_tcam;

			if (init_params->action_on_miss) {
				if (init_params->action_on_miss->next_action
					== DPTBL_ACTION_DONE
					&& (init_params->options
						& DPTBL_OPTIONS_OPTIMIZIED_DISCARD)
						== DPTBL_OPTIONS_OPTIMIZIED_DISCARD) {
					tmp_init_params.action_on_miss_opcode =
						DPTBL_ACTION_ON_MISS_DISCARD;}
				else {
					tmp_init_params.action_on_miss_opcode =
							DPTBL_ACTION_ON_MISS_LOGICAL;
					dptbl->restore = 1;
					tmp_init_params.action_on_miss =
					        init_params->action_on_miss;
				}
			}
			break;
	case (DPTBL_TYPE_ALG_ACL):
			pr_err("Unsupported type of the table\n");
			return -EINVAL;
	default:
		pr_err("Unsupported type of the table\n");
		return -EINVAL;
	}
	tmp_init_params.max_rules = init_params->max_rules;
	/*if table consists Miss action as programmed rule
	 * it should be included as regular rule*/
	if ((tmp_init_params.action_on_miss_opcode & DPTBL_ACTION_ON_MISS_PROGRAMMED) ||
			(tmp_init_params.action_on_miss_opcode & DPTBL_ACTION_ON_MISS_LOGICAL))
		if (TCAM_KEY_SIZE == TCAM_MAX_KEY_SIZE)
			tmp_init_params.max_rules += 1;
		else
			tmp_init_params.max_rules += 2;
	tmp_init_params.max_key_size = init_params->max_key_size;
	tmp_init_params.options = init_params->options;
	tmp_init_params.icid = init_params->icid;
	err = tmp_init_params.f_check_params(init_params);
	if (err)
		return err;
	return restore_tbl(dptbl, dptbl_mng, &tmp_init_params);

}
#endif /* TKT011436 */

struct dptbl* dptbl_init(struct dptbl_mng *dptbl_mng,
                         struct dptbl_cfg *init_params)
{

	int err;
	struct dptbl_tmp_init_params tmp_init_params;

	memset(&tmp_init_params, 0, sizeof(struct dptbl_tmp_init_params));
	switch (init_params->mem_type) {
	case (DPTBL_INT_MEMORY):
		tmp_init_params.mem_type = DPTBL_INT_MEM;
		break;
	case (DPTBL_PEB):
		tmp_init_params.mem_type = DPTBL_PEB_MEM;
		break;
	case (DPTBL_EXT_MEMORY_1):
		tmp_init_params.mem_type = DPTBL_EXT_MEM_1;
		break;
	case (DPTBL_EXT_MEMORY_2):
		tmp_init_params.mem_type = DPTBL_EXT_MEM_2;
		break;
	default:
		pr_err("Unknown mem_type \n");
		return NULL;
	}
	switch (init_params->type) {
	case (DPTBL_TYPE_EXACT_MATCH):
		tmp_init_params.type = DTBL_EM;
		tmp_init_params.num_of_entries_per_key =
			DPTBL_GET_NUM_OF_ENTRIES(init_params->max_key_size);
		tmp_init_params.f_check_params = dptbl_check_params_em;
		tmp_init_params.f_add_rule = dptbl_add_rule_em;
		tmp_init_params.f_modify_miss_action = dptbl_modify_miss_action_em;
		tmp_init_params.f_modify_rule = dptbl_modify_rule_em;
		tmp_init_params.f_remove_rule = dptbl_remove_rule_em;
		tmp_init_params.f_get_action = dptbl_get_action_em;

		if (init_params->action_on_miss) {
			if (init_params->action_on_miss->next_action
			    == DPTBL_ACTION_DONE
			    && (init_params->options
			        & DPTBL_OPTIONS_OPTIMIZIED_DISCARD)
			       == DPTBL_OPTIONS_OPTIMIZIED_DISCARD)
				tmp_init_params.action_on_miss_opcode =
				        DPTBL_ACTION_ON_MISS_DISCARD;
			else {
				tmp_init_params.action_on_miss_opcode =
				        DPTBL_ACTION_ON_MISS_PROGRAMMED;
				tmp_init_params.action_on_miss =
				        init_params->action_on_miss;
			}
		}
		break;
	case (DPTBL_TYPE_LPM):
			pr_err("Unsupported type of the table\n");
			return NULL;
	case (DPTBL_TYPE_TCAM_ACL):
			tmp_init_params.type = DPTBL_TCAM_ACL;
			tmp_init_params.num_of_entries_per_key = 
					(uint8_t)DPTBL_TCM_GET_NUM_OF_ENTRIES(init_params->max_key_size);
			tmp_init_params.f_check_params = dptbl_check_params_tcam;
			tmp_init_params.f_add_rule = dptbl_add_rule_tcam_acl;
			tmp_init_params.f_modify_rule = dptbl_modify_rule_tcam_acl;
			tmp_init_params.f_remove_rule = dptbl_remove_rule_tcam_acl;
			tmp_init_params.f_modify_miss_action = dptbl_modify_miss_action_tcam_acl;
			tmp_init_params.f_get_action = dptbl_get_action_tcam_acl;

			if (init_params->action_on_miss) {
				if (init_params->action_on_miss->next_action
					== DPTBL_ACTION_DONE
					&& (init_params->options
						& DPTBL_OPTIONS_OPTIMIZIED_DISCARD)
						== DPTBL_OPTIONS_OPTIMIZIED_DISCARD) {
					tmp_init_params.action_on_miss_opcode =
						DPTBL_ACTION_ON_MISS_DISCARD;}
				else {
					tmp_init_params.action_on_miss_opcode =
							DPTBL_ACTION_ON_MISS_LOGICAL;
					tmp_init_params.action_on_miss =
					        init_params->action_on_miss;
				}
			}
			break;
	case (DPTBL_TYPE_ALG_ACL):
			pr_err("Unsupported type of the table\n");
			return NULL;
	default:
		pr_err("Unsupported type of the table\n");
		return NULL;
	}
	tmp_init_params.max_rules = init_params->max_rules;
	/*if table consists Miss action as programmed rule
	 * it should be included as regular rule*/
	if ((tmp_init_params.action_on_miss_opcode & DPTBL_ACTION_ON_MISS_PROGRAMMED) ||
			(tmp_init_params.action_on_miss_opcode & DPTBL_ACTION_ON_MISS_LOGICAL))
		if (TCAM_KEY_SIZE == TCAM_MAX_KEY_SIZE)
			tmp_init_params.max_rules += 1;
		else
			tmp_init_params.max_rules += 2;
	tmp_init_params.max_key_size = init_params->max_key_size;
	tmp_init_params.options = init_params->options;
	tmp_init_params.icid = init_params->icid;
	err = tmp_init_params.f_check_params(init_params);
	if (err)
		return NULL;
	return create_tbl(dptbl_mng, &tmp_init_params);
}

int dptbl_add_rule(struct dptbl* dptbl,
                   struct dptbl_rule *rule,
                   struct dptbl_action *action,
                   int restore)
{
	ASSERT_COND(dptbl);
	ASSERT_COND(rule);
	ASSERT_COND(action);
	ASSERT_COND(dptbl->f_add_rule);
	return dptbl->f_add_rule(dptbl, rule, action, restore);
}

int dptbl_mng_add_debug_rule(struct dptbl_mng *dptbl_mng, uint8_t *rule, uint8_t *mask, int size)
{
	uint8_t mask_tmp[DPTBL_MAX_KEY_SIZE_EM];
	
	ASSERT_COND(dptbl_mng);
	ASSERT_COND(dptbl_mng->ctlu);
	ASSERT_COND(rule);

	ctlu_dptbl_global_rule_add(dptbl_mng->ctlu, rule,  size);
	if (mask)
		ctlu_dptbl_global_mask_add(dptbl_mng->ctlu, mask, size);
	else {
		memset(mask_tmp, 0xff, (uint32_t)size);
		ctlu_dptbl_global_mask_add(dptbl_mng->ctlu, mask_tmp, size);
	}
	return 0;
}
int dptbl_modify_rule(struct dptbl* dptbl,
                      struct dptbl_rule *rule,
                      struct dptbl_action *action)
{
	ASSERT_COND(dptbl);
	ASSERT_COND(rule);
	ASSERT_COND(action);
	ASSERT_COND(dptbl->f_modify_rule);
	return dptbl->f_modify_rule(dptbl, rule, action);
}

int dptbl_modify_miss_action(struct dptbl* dptbl,
                      struct dptbl_action *action)
{
	ASSERT_COND(dptbl);
	ASSERT_COND(action);
	ASSERT_COND(dptbl->f_modify_miss_action);
	return dptbl->f_modify_miss_action(dptbl, action);
}

int dptbl_remove_rule(struct dptbl* dptbl, struct dptbl_rule *rule)
{
	ASSERT_COND(dptbl);
	ASSERT_COND(rule);
	ASSERT_COND(dptbl->f_remove_rule);
	return dptbl->f_remove_rule(dptbl, rule);
}

void dptbl_get_id(struct dptbl* dptbl, int *tid)
{
	*tid = dptbl->tid;
}

void dptbl_get_max_key_size(struct dptbl* dptbl, uint32_t *key_size)
{
	*key_size = dptbl->max_key_size;
}

uint32_t dptbl_get_int_list_size(struct ctlu *ctlu)
{
	struct dptbl_mng_mem_map_set *regs = NULL;
	int err;

	err = ctlu_get_mem_base(ctlu, CTLU_DPTABLE_MNG, (void **)&regs);
	ASSERT_COND(!err);

	return (uint32_t)((int)ioread32(&regs->iop_ctsize) * NUM_OF_BYTES_PER_TID);
}

uint32_t dptbl_get_tbl_size_by_entries(uint32_t num_of_entries)
{
	return (num_of_entries * NUM_OF_BYTES_PER_TBL_ENTRY);
}

int dptbl_get_num_of_used_rules(struct dptbl* dptbl, int *num_of_used_rules) {
	*num_of_used_rules = (int)dptbl->used_rules;
	return 0;
}

int dptbl_get_num_of_max_rules(struct dptbl* dptbl, int *num_of_max_rules) {
	*num_of_max_rules = (int)dptbl->max_rules;
	return 0;
}

int dptbl_get_tbl_type(struct dptbl* dptbl, int *tbl_type) {
	*tbl_type = (int)dptbl->type;
	return 0;
}

int dptbl_get_tbl_id(struct dptbl* dptbl, int *tbl_id) {
	*tbl_id = (int)dptbl->tid;
	return 0;
}

int dptbl_get_real_key_size(struct dptbl* dptbl, int *real_key_size) {
	*real_key_size = (int)dptbl->real_key_size;
	return 0;
}

int dptbl_get_action (struct dptbl* dptbl,
							struct dptbl_rule *rule,
							struct dptbl_action *action)
{
	ASSERT_COND(dptbl);
	ASSERT_COND(rule);
	ASSERT_COND(action);
	ASSERT_COND(dptbl->f_get_action);
	return dptbl->f_get_action(dptbl, rule, action);
}

int dptbl_get_next_ruleid(struct dptbl* dptbl, uint64_t *ruleid)
{
	uint8_t	*ptr_in_msg, *ptr_out_msg;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	uint32_t mtypeout;
	uint64_t *p_ruleid;
	uint16_t status;
	int err;

	CHECK_COND_RETVAL(ruleid!=NULL, -EINVAL);

	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
			&cmd_cfg,
			(void*)&ptr_in_msg,
			&mtypein_addr);
	CHECK_COND_RETVAL(err==0, err);

	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_QUERY_SIZE);
	memcpy(ptr_in_msg+8, ruleid, sizeof(uint64_t));
	*mtypein_addr = (uint16_t)(dptbl->tid) | ((uint32_t)dptbl->max_key_size << 16);

	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
								MNG_CMD_DPTBL_NEXT_RULEID_QUERY,
		                        &status, &mtypeout,
		                        (void**)&ptr_out_msg);
	if ((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS) {
		*ruleid = 0;
	} else {
		p_ruleid = (uint64_t *)(ptr_out_msg+8);
		*ruleid = *p_ruleid;
	}

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);

	return 0;
}

int dptbl_query_with_ruleid(struct dptbl* dptbl, uint64_t *ruleid, uint8_t *key, int key_size)
{
	uint8_t	*ptr_in_msg, *ptr_out_msg;
	void *cmd_cfg;
	uint32_t *mtypein_addr;
	uint32_t mtypeout;
	uint16_t status;
	int err;
	uint32_t entype;
	int key_offset;

	CHECK_COND_RETVAL(ruleid!=NULL, -EINVAL);

	err = ctlu_build_cmd_cfg(dptbl->dptbl_mng->ctlu,
			&cmd_cfg,
			(void*)&ptr_in_msg,
			&mtypein_addr);
	CHECK_COND_RETVAL(err==0, err);

	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPTBL_RULE_QUERY_SIZE);
	memcpy(ptr_in_msg+8, ruleid, sizeof(uint64_t));
	*mtypein_addr = (uint16_t)(dptbl->tid) | ((uint32_t)0x20 << 16);

	err = ctlu_execute_cmd(dptbl->dptbl_mng->ctlu, NULL, cmd_cfg, /* interface handle */
								MNG_CMD_DPTBL_RULE_QUERY_WITH_RULEID,
		                        &status, &mtypeout,
		                        (void**)&ptr_out_msg);
	if ((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS) {
		pr_err("Function dptbl_query_with_ruleid : "
					"matching rule is not found in the table."
					"Can not execute dptbl_query_with_ruleid.\n");
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		return -ENAVAIL;	/*!< Resource not available */
	}

	entype = (uint32_t)((*ptr_out_msg) & 0x0f);
	switch( entype ) {
	case 0x00:		// EME44
	case 0x01:		// EME24
	case 0x05:		// LPM Result
	case 0x0d:		// L2 MAC
	case 0x0f:		// L2 Vlan
		key_offset = 0x14;
		break;
	case 0x02:		// EME36
	case 0x03:		// EME16
	case 0x04:		// LPM Marker
	case 0x08:		// MFLU RuleEntry
	case 0x09:		// MFLU ResultEntry
	case 0x0a:		// MFLU branching entry
		key_offset = 0x1c;
		break;
	default:
		key_offset = 0;
		pr_err("Entry type %02x not supported in this MC version\n", entype);
		err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);
		return -ENOTSUP; // table type not supported
	}

	memcpy(key, ptr_out_msg+key_offset, (size_t)key_size);

	err = ctlu_free_cmd_cfg(dptbl->dptbl_mng->ctlu, cmd_cfg);

	return 0;
}
