/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_malloc.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_net.h"
#include "fsl_eiop_ifp.h"
#include "fsl_ctlu.h"
#include "fsl_resman.h"

#include "dppolicy.h"
#include "ctlu_common.h"

/*********************************************************/
/*			FUNCTIONS for DPPOLICY_MANAGER				 */
/*********************************************************/

struct prot_opt_to_faf_offset vlan_opt_faf_offset[] =
{
		{NH_OPT_VLAN_CFI,	 	0,	PROT_VLAN_CFI_SET_TO_FAF_OFFSET},
		{0, 					0,	PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE}
};

struct prot_opt_to_faf_offset eth_opt_faf_offset[] =
{
		{NH_OPT_ETH_UNICAST,	0,	PROT_ETH_UNICAST_TO_FAF_OFFSET},
		{NH_OPT_ETH_MULTICAST, 	0,	PROT_ETH_MULITACST_TO_FAF_OFFSET},
		{NH_OPT_ETH_BROADCAST, 	0,	PROT_ETH_BROADCAST_TO_FAF_OFFSET},
		{NH_OPT_ETH_BPDU, 		0,	PROT_ETH_BDPU_TO_FAF_OFFSET},
		{0,						0,	PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE}
};

struct prot_opt_to_faf_offset min_encap_opt_faf_offset[] =
{
		{NH_OPT_MINENCAP_SRC_ADDR_PRESENT,	 	0,	PROT_MINENCAP_SRC_ADDR_PRESENT_TO_FAF_OFFSET},
		{0,										0,	PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE}
};

struct prot_opt_to_faf_offset gre_opt_faf_offset[] =
{
		{NH_OPT_GRE_ROUTING_PRESENT,	 	0,	PROT_GRE_ROUT_PRESENT_TO_FAF_OFFSET},
		{0,									0,	PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE}
};

struct prot_opt_to_faf_offset tcp_opt_faf_offset[] =
{
		{NH_OPT_TCP_OPTIONS,	 		0,	PROT_TCP_OPTIONS_TO_FAF_OFFSET},
		{NH_OPT_TCP_CONTROL_HIGH_BITS, 	0,	PROT_TCP_CONTROL_HIGH_BITS_TO_FAF_OFFSET},
		{NH_OPT_TCP_CONTROL_LOW_BITS, 	0,	PROT_TCP_CONTROL_LOW_BITS_TO_FAF_OFFSET},
		{0,								0,	PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE}
};

struct prot_opt_to_faf_offset ip_opt_faf_offset[] =
{
		{NH_OPT_IP_OPTION,	 	0,				PROT_PROT_OPT_IP_OPTION_TO_FAF_OFFSET},
		{NH_OPT_IP_OPTION,	 	(uint8_t)LAST_HDR_INDEX,	PROT_PROT_OPT_IP_N_OPTION_TO_FAF_OFFSET},
		{NH_OPT_IP_FRAG, 		0,				PROT_PROT_OPT_IP_FRAG_TO_FAF_OFFSET},
		{NH_OPT_IP_FRAG, 		(uint8_t)LAST_HDR_INDEX,	PROT_PROT_OPT_IP_N_FRAG_TO_FAF_OFFSET},
		{NH_OPT_IP_INITIAL_FRAG, 0,				PROT_PROT_OPT_IP_IS_INITIAL_FRAG_TO_FAF_OFFSET},
		{NH_OPT_IP_INITIAL_FRAG, (uint8_t)LAST_HDR_INDEX,PROT_PROT_OPT_IP_N_IS_INITIAL_FRAG_TO_FAF_OFFSET},
		{0,						  0,			PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE}
};


struct prot_opt_to_faf_offset ipv4_opt_faf_offset[] =
{
		{NH_OPT_IPV4_UNICAST,	 	0,
				PROT_IPv4_TO_FAF_OFFSET +PROT_IPv4_UNICAST_TO_FAF_OFFSET},
		{NH_OPT_IPV4_UNICAST,	 	(uint8_t)LAST_HDR_INDEX,
				PROT_IPv4_N_TO_FAF_OFFSET + PROT_IPv4_UNICAST_TO_FAF_OFFSET},
		{NH_OPT_IPV4_MULTICAST, 	0,
				PROT_IPv4_TO_FAF_OFFSET + PROT_IPv4_MULITACST_TO_FAF_OFFSET},
		{NH_OPT_IPV4_MULTICAST, 	(uint8_t)LAST_HDR_INDEX,
				PROT_IPv4_N_TO_FAF_OFFSET + PROT_IPv4_MULITACST_TO_FAF_OFFSET},
		{NH_OPT_IPV4_BROADCAST, 	0,
				PROT_IPv4_TO_FAF_OFFSET + PROT_IPv4_BROADCAST_TO_FAF_OFFSET},
		{NH_OPT_IPV4_BROADCAST, 	(uint8_t)LAST_HDR_INDEX,
				PROT_IPv4_N_TO_FAF_OFFSET + PROT_IPv4_BROADCAST_TO_FAF_OFFSET},
		{0,							0,
				PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE}
};

struct prot_opt_to_faf_offset ipv6_opt_faf_offset[] =
{
		{NH_OPT_IPV6_UNICAST,	 	0,
				PROT_IPv6_TO_FAF_OFFSET +PROT_IPv6_UNICAST_TO_FAF_OFFSET},
		{NH_OPT_IPV6_UNICAST,	 	(uint8_t)LAST_HDR_INDEX,
				PROT_IPv6_N_TO_FAF_OFFSET + PROT_IPv6_UNICAST_TO_FAF_OFFSET},
		{NH_OPT_IPV6_MULTICAST, 	0,
				PROT_IPv6_TO_FAF_OFFSET + PROT_IPv6_MULITACST_TO_FAF_OFFSET},
		{NH_OPT_IPV6_MULTICAST, 	(uint8_t)LAST_HDR_INDEX,
				PROT_IPv6_N_TO_FAF_OFFSET + PROT_IPv6_MULITACST_TO_FAF_OFFSET},
		{0,							0,
				PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE}
};


static uint8_t policy_message_ident_prot(const struct dppolicy_mng* dppolicy_mng,
                                         const struct identifier *identifier)
{
	uint8_t offset = PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE;

	/*get relevant bit in faf*/
	offset = dppolicy_mng->prot_info[identifier->prot].prot_to_faf_offset;

	if (identifier->hdr_index) {
	/*check if hdr_index LAST because only last in this configuration
	is allowed besides 0, yes->get relevant offset*/
		if (identifier->hdr_index == (uint8_t)LAST_HDR_INDEX)
			offset =
			dppolicy_mng->prot_info[identifier->prot].
			prot_last_index_to_faf_offset;
		/*hdr_index differs from 0 and LAST->
		error*/
		else
			offset = PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE;
	}
	return offset;
}

static uint8_t policy_message_ident_prot_prs_err (const struct dppolicy_mng* dppolicy_mng,
                                                  const struct identifier *identifier)
{
	uint8_t offset = PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE;

	/*get relevant bit in faf*/
	offset = dppolicy_mng->prot_info[identifier->prot].prot_prs_err_to_faf_offset;

	if (identifier->hdr_index) {
	/*check if hdr_index LAST because only last in this configuration
	is allowed besides 0, yes->get relevant offset*/
		if (identifier->hdr_index == (uint8_t)LAST_HDR_INDEX)
			offset =
			dppolicy_mng->prot_info[identifier->prot].
			prot_prs_err_last_index_to_faf_offset;
		/*hdr_index differs from 0 and LAST->
		error*/
		else
			offset = PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE;
	}

	return offset;
}




static uint8_t policy_message_ident_prot_opt(const struct dppolicy_mng* dppolicy_mng,
                                             const struct identifier *identifier)
{

	struct prot_opt_to_faf_offset *prot_opt_faf_offset;
	/*get the relevant function of specific protocol
	for identification of alowed options*/
	prot_opt_faf_offset = dppolicy_mng->prot_info[identifier->prot].prot_opt_faf_offset;
	if (prot_opt_faf_offset) {
		while (((prot_opt_faf_offset->option != identifier->opt)
				|| (prot_opt_faf_offset->hdr_index != identifier->hdr_index)) &&
				(prot_opt_faf_offset->offset != PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE))
				prot_opt_faf_offset++;
		return prot_opt_faf_offset->offset;
	}
	return  PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE;

}

static void fill_policy_mng_info (struct dppolicy_mng *dppolicy_mng)
{

	struct prot_info *prot_array = dppolicy_mng->prot_info;

	/*ETH*/
	prot_array[NET_PROT_ETH].prot_to_faf_offset =
					 PROT_ETH_TO_FAF_OFFSET;
	prot_array[NET_PROT_ETH].prot_prs_err_to_faf_offset =
					 PROT_ETH_PRS_ERR_TO_FAF_OFFSET;
	prot_array[NET_PROT_ETH].prot_opt_faf_offset =
			eth_opt_faf_offset;

	/*NET_PROT_LLC_SNAP*/
	prot_array[NET_PROT_LLC_SNAP].prot_to_faf_offset =
					 PROT_LLC_SNAP_TO_FAF_OFFSET;
	prot_array[NET_PROT_LLC_SNAP].prot_prs_err_to_faf_offset =
					PROT_LLC_SNAP_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_VLAN*/
	prot_array[NET_PROT_VLAN].prot_to_faf_offset =
					PROT_VLAN_TO_FAF_OFFSET;
	prot_array[NET_PROT_VLAN].prot_prs_err_to_faf_offset =
					PROT_VLAN_PRS_ERR_TO_FAF_OFFSET;
	prot_array[NET_PROT_VLAN].prot_opt_faf_offset =
					vlan_opt_faf_offset;
	prot_array[NET_PROT_VLAN].prot_last_index_to_faf_offset =
					PROT_VLAN_N_TO_FAF_OFFSET;

	/*NET_PROT_PPPOE*/
	prot_array[NET_PROT_PPPOE].prot_to_faf_offset =
					PROT_PPPoE_TO_FAF_OFFSET;
	prot_array[NET_PROT_PPPOE].prot_prs_err_to_faf_offset =
					PROT_PPPoE_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_MPLS*/
	prot_array[NET_PROT_MPLS].prot_to_faf_offset =
					PROT_MPLS_TO_FAF_OFFSET;
	prot_array[NET_PROT_MPLS].prot_prs_err_to_faf_offset =
					PROT_MPLS_PRS_ERR_TO_FAF_OFFSET;
	prot_array[NET_PROT_MPLS].prot_last_index_to_faf_offset =
					PROT_MPLS_N_TO_FAF_OFFSET;

	/*NET_PROT_ARP*/
	prot_array[NET_PROT_ARP].prot_to_faf_offset =
					PROT_ARP_TO_FAF_OFFSET;
	prot_array[NET_PROT_ARP].prot_prs_err_to_faf_offset =
					PROT_ARP_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_IPv4*/
	prot_array[NET_PROT_IPV4].prot_to_faf_offset =
					PROT_IPv4_TO_FAF_OFFSET;
	prot_array[NET_PROT_IPV4].prot_opt_faf_offset =
						ipv4_opt_faf_offset;
	prot_array[NET_PROT_IPV4].prot_last_index_to_faf_offset =
					PROT_IPv4_N_TO_FAF_OFFSET;

	/*NET_PROT_IPv6*/
	prot_array[NET_PROT_IPV6].prot_to_faf_offset =
					PROT_IPv6_TO_FAF_OFFSET;
	prot_array[NET_PROT_IPV6].prot_opt_faf_offset =
						ipv6_opt_faf_offset;
	prot_array[NET_PROT_IPV6].prot_last_index_to_faf_offset =
					PROT_IPv6_N_TO_FAF_OFFSET;

	/*NET_PROT_MINENCAP*/
	prot_array[NET_PROT_MINENCAP].prot_to_faf_offset =
					PROT_MINENCAP_TO_FAF_OFFSET;
	prot_array[NET_PROT_MINENCAP].prot_prs_err_to_faf_offset =
					PROT_MINENCAP_PRS_ERR_TO_FAF_OFFSET;
	prot_array[NET_PROT_MINENCAP].prot_opt_faf_offset =
					min_encap_opt_faf_offset;

	/*NET_PROT_GRE*/
	prot_array[NET_PROT_GRE].prot_to_faf_offset =
					PROT_GRE_TO_FAF_OFFSET;
	prot_array[NET_PROT_GRE].prot_prs_err_to_faf_offset =
					PROT_GRE_PRS_ERR_TO_FAF_OFFSET;
	prot_array[NET_PROT_GRE].prot_opt_faf_offset =
					gre_opt_faf_offset;

	/*NET_PROT_UDP*/
	prot_array[NET_PROT_UDP].prot_to_faf_offset =
					PROT_UDP_TO_FAF_OFFSET;
	prot_array[NET_PROT_UDP].prot_prs_err_to_faf_offset =
					PROT_UDP_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_TCP*/
	prot_array[NET_PROT_TCP].prot_to_faf_offset =
					PROT_TCP_TO_FAF_OFFSET;
	prot_array[NET_PROT_TCP].prot_prs_err_to_faf_offset =
					PROT_TCP_PRS_ERR_TO_FAF_OFFSET;
	prot_array[NET_PROT_TCP].prot_opt_faf_offset =
					tcp_opt_faf_offset;

	/*NET_PROT_DCCP*/
	prot_array[NET_PROT_DCCP].prot_to_faf_offset =
					PROT_DCCP_TO_FAF_OFFSET;
	prot_array[NET_PROT_DCCP].prot_prs_err_to_faf_offset =
					PROT_DCCP_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_GTP*/
	prot_array[NET_PROT_GTP].prot_to_faf_offset =
					PROT_GTP_TO_FAF_OFFSET;
	prot_array[NET_PROT_GTP].prot_prs_err_to_faf_offset =
					PROT_GTP_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_IPSEC_AH*/
	prot_array[NET_PROT_IPSEC_AH].prot_to_faf_offset =
					PROT_IPSEC_AH_TO_FAF_OFFSET;
	prot_array[NET_PROT_IPSEC_AH].prot_prs_err_to_faf_offset =
					PROT_IPSEC_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_IPSEC_AH*/
	prot_array[NET_PROT_IPSEC_ESP].prot_to_faf_offset =
					PROT_IPSEC_ESP_TO_FAF_OFFSET;
	prot_array[NET_PROT_IPSEC_ESP].prot_prs_err_to_faf_offset =
					PROT_IPSEC_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_SCTP*/
	prot_array[NET_PROT_SCTP].prot_to_faf_offset =
					PROT_SCTP_TO_FAF_OFFSET;
	prot_array[NET_PROT_SCTP].prot_prs_err_to_faf_offset =
					PROT_SCTP_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_UDP_ENC_ESP*/
	prot_array[NET_PROT_UDP_ENC_ESP].prot_to_faf_offset =
					PROT_UDP_ENCAP_TO_FAF_OFFSET;
	prot_array[NET_PROT_UDP_ENC_ESP].prot_prs_err_to_faf_offset =
					PROT_UDP_ENCAP_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_IP*/
	prot_array[NET_PROT_IP].prot_prs_err_to_faf_offset =
					PROT_IP_PRS_ERR_TO_FAF_OFFSET;
	prot_array[NET_PROT_IP].prot_opt_faf_offset =
			ip_opt_faf_offset;
	prot_array[NET_PROT_IP].prot_prs_err_last_index_to_faf_offset =
					PROT_IP_N_PRS_ERR_TO_FAF_OFFSET;

	/*NET_PROT_CAPWAP_CTRL*/
	prot_array[NET_PROT_CAPWAP_CTRL].prot_to_faf_offset =
					PROT_CAPWAP_CNTRL_TO_FAF_OFFSET;
	/*NET_PROT_CAPWAP_DATA*/
	prot_array[NET_PROT_CAPWAP_DATA].prot_to_faf_offset =
					PROT_CAPWAP_DATA_TO_FAF_OFFSET;
	/*NET_PROT_ISCSI*/
	prot_array[NET_PROT_ISCSI].prot_to_faf_offset =
					PROT_ISCSI_TO_FAF_OFFSET;
	/*NET_PROT_ICMP*/
	prot_array[NET_PROT_ICMP].prot_to_faf_offset =
					PROT_ICMP_TO_FAF_OFFSET;
	/*NET_PROT_IGMP*/
	prot_array[NET_PROT_IGMP].prot_to_faf_offset =
					PROT_IGMP_TO_FAF_OFFSET;
	/*NET_PROT_UDP_LITE*/
	prot_array[NET_PROT_UDP_LITE].prot_to_faf_offset =
					PROT_UDP_LITE_TO_FAF_OFFSET;
	/*NET_PROT_ICMPV6*/
	prot_array[NET_PROT_ICMPV6].prot_to_faf_offset =
					PROT_ICMPV6_TO_FAF_OFFSET;
	/*NET_PROT_FIP*/
	prot_array[NET_PROT_FIP].prot_to_faf_offset =
					PROT_FIP_TO_FAF_OFFSET;
	/*NET_PROT_FCOE*/
	prot_array[NET_PROT_FCOE].prot_to_faf_offset =
					PROT_FCoE_TO_FAF_OFFSET;

	/*NET_PROT_USER_DEFINED_L2*/
	prot_array[NET_PROT_USER_DEFINED_L2].prot_prs_err_to_faf_offset =
					PROT_L2_SOFT_PRS_ERR_TO_FAF_OFFSET;
	/*NET_PROT_USER_DEFINED_L3*/
	prot_array[NET_PROT_USER_DEFINED_L3].prot_prs_err_to_faf_offset =
					PROT_L3_SOFT_PRS_ERR_TO_FAF_OFFSET;
	/*NET_PROT_USER_DEFINED_L4*/
	prot_array[NET_PROT_USER_DEFINED_L4].prot_prs_err_to_faf_offset =
					PROT_L4_SOFT_PRS_ERR_TO_FAF_OFFSET;
	/*NET_PROT_USER_DEFINED_L5*/
	prot_array[NET_PROT_USER_DEFINED_L5].prot_prs_err_to_faf_offset =
					PROT_L5_SOFT_PRS_ERR_TO_FAF_OFFSET;

}

static void fill_policy_rule_mask_key_offset	(struct fa_message *ptr_msg,
					uint8_t offset,
					int exclude)
{
	if (exclude)
		ptr_msg->faf[offset / 8] &= ~(0x80 >> (offset % 8));
	else
		ptr_msg->faf[offset / 8] |= 0x80 >> (offset % 8);

	/*fill mask specific offset*/
	ASSERT_COND((MSG_MASK_FALU_GRP_OFFSET + (offset / 8)) < ARRAY_SIZE(ptr_msg->mask));
	ptr_msg->mask[MSG_MASK_FALU_GRP_OFFSET + (offset / 8)] |= 0x80 >> (offset % 8);

}




static int fill_policy_action (uint8_t *ptr, const struct dppolicy_action *action)
{


	struct action_cfg action_cfg;

	memset(&action_cfg, 0, sizeof(struct action_cfg));

	if (action->next_action ==  DPPOLICY_ACTION_LOOKUP)
			action_cfg.next_action = NEXT_ACTION_LOOKUP;
	else if (action->next_action ==  DPPOLICY_ACTION_DONE)
		action_cfg.next_action = NEXT_ACTION_DONE;


	if (action->options & DPPOLICY_ACTION_SET_POLICER_ID)
		action_cfg.options |= ACTION_SET_POLICER_ID;

	if (action->options & DPPOLICY_ACTION_SET_QOS_MAP_METHOD)
		action_cfg.options |= ACTION_SET_QOS_MAP_METHOD;

	if (action->options & DPPOLICY_ACTION_SET_QPRI)
		action_cfg.options |= ACTION_SET_QPRI;

	if (action->options & DPPOLICY_ACTION_SET_IFP_ID)
		action_cfg.options |= ACTION_SET_IFP_ID;

	if (action->options & DPPOLICY_ACTION_SET_HASH_KID)
		action_cfg.options |= ACTION_SET_HASH_KID;

	if (action->options & DPPOLICY_ACTION_SET_DISCARD_FLAG)
		action_cfg.options |= ACTION_SET_DISCARD_FLAG;

	if (action->options & DPPOLICY_ACTION_CLEAR_DISCARD_FLAG)
		action_cfg.options |= ACTION_CLEAR_DISCARD_FLAG;

	if (action->options & DPPOLICY_ACTION_SET_QDID)
		action_cfg.options |= ACTION_SET_QDID;

	if (action->options & DPPOLICY_ACTION_SET_QDBIN)
		action_cfg.options |= ACTION_SET_QDBIN;

	if (action->options & DPPOLICY_ACTION_SET_FLC_FOR_AIOP)
		action_cfg.options |= ACTION_SET_FLC_FOR_AIOP;

	if (action->options & DPPOLICY_ACTION_SET_REPLIC_ID)
		action_cfg.options |= ACTION_SET_REPLIC_ID;

	if (action->options & DPPOLICY_ACTION_SET_OPAQUE)
		action_cfg.options |= ACTION_SET_OPAQUE;

	if (action->options & DPPOLICY_ACTION_SET_STASHING_CNTRL)
		action_cfg.options |= ACTION_SET_STASHING;

	if (action->options & DPPOLICY_ACTION_SET_CONTEXT_IOMMU_BYPASS)
		action_cfg.options |= ACTION_SET_CONTEXT_IOMMU_BYPASS;

	switch(action->qos_map_method) {
	case(DPPOLICY_ACTION_QoS_BASED_ON_VLAN_PRI) :
		action_cfg.qos_map_method = ACTION_QoS_BASED_ON_VLAN_PRI;
	break;
	case(DPPOLICY_ACTION_QoS_BASED_ON_IP_DSCP) :
		action_cfg.qos_map_method = ACTION_QoS_BASED_ON_IP_DSCP;
	break;
	default:
	break;
	}
	action_cfg.dppolicer_profile_id = action->dppolicer_profile_id;
	action_cfg.qpri = action->qpri;
	action_cfg.ifp_id = action->ifp_id;
	action_cfg.hash_dpkg_profile_id = action->hash_dpkg_profile_id;
	action_cfg.qd_id = action->qd_id;
	action_cfg.qd_bin = action->qd_bin;
	action_cfg.replic_id = action->replic_id;
	action_cfg.opaque = action->opaque;
	action_cfg.dptbl_id = action->lookup_params.dptbl_id;
	action_cfg.dpkg_profile_id = action->lookup_params.dpkg_profile_id;


	return fill_action(ptr, &action_cfg);

}
static int build_policy_create_entry_message (uint8_t *ptr,
				struct dppolicy* policy,
				const struct dppolicy_rule *dppolicy_rule,
				const struct dppolicy_action *action,
				int abs_index)
{
	uint8_t 		offset;
	struct fa_message 	*ptr_msg  = (struct fa_message *)ptr;
	int err = 0;

	int i = 0;

	memset(ptr_msg, 0, sizeof(struct fa_message));

	for (i = 0; i < dppolicy_rule->num_of_identifiers; i++) {
		switch (dppolicy_rule->identifiers[i].type) {
			case(DPPOLICY_IDENTIFIER_PROT) :
				offset = policy_message_ident_prot
					(policy->policy_mng,
					&dppolicy_rule->identifiers[i]);
			break;
			case(DPPOLICY_IDENTIFIER_PROT_PRS_ERR) :
				offset = policy_message_ident_prot_prs_err
					(policy->policy_mng,
					&dppolicy_rule->identifiers[i]);

			break;
			case(DPPOLICY_IDENTIFIER_GEN_PRS_ERR) :
				offset = PROT_GEN_PRS_ERR_TO_FAF_OFFSET;
			break;
			case(DPPOLICY_IDENTIFIER_L2_UNRECOGNIZED_PROT) :
				offset = PROT_L2_UNRECOGNIZED_TO_FAF_OFFSET;
			break;
			case(DPPOLICY_IDENTIFIER_L3_UNRECOGNIZED_PROT) :
				offset = PROT_L3_UNRECOGNIZED_TO_FAF_OFFSET;
			break;
			case(DPPOLICY_IDENTIFIER_L4_UNRECOGNIZED_PROT) :
				offset = PROT_L4_UNRECOGNIZED_TO_FAF_OFFSET;
			break;
			case(DPPOLICY_IDENTIFIER_PROT_OPT) :
				offset = policy_message_ident_prot_opt
					(policy->policy_mng,
					&dppolicy_rule->identifiers[i]);

			break;
			default:
				offset = PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE;
				break;
		}

		if (offset == PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE)
		{
			pr_err("user asked to perform identifications of the unsupported "
					"protocols/fields. Please check it again\n");
			return -EINVAL;
		}

		/*fill faf specific offset according to requirements :
		exclude or include specific protocol*/

		fill_policy_rule_mask_key_offset(ptr_msg,
					 offset,
				dppolicy_rule->identifiers[i].exclude);

	}

	ptr_msg->falu_grp = (uint32_t)policy->dppolicy_id;


	/*fill mask FALU_GRP - FALU_GRP is always taking into account*/
	ptr_msg->mask[0] = 0xff;
	ptr_msg->mask[1] = 0xff;
	ptr_msg->mask[2] = 0xff;
	ptr_msg->mask[3] = 0xff;

	ptr_msg->tenum = (uint32_t)abs_index;
	if (action)
		err =  fill_policy_action(ptr_msg->tlur,action);

	return err;
}



static void fill_policy_delete_entry_message(uint8_t *ptr, int abs_index)
{
	struct fa_delete_entry_message 	*ptr_msg  = (struct fa_delete_entry_message *)ptr;

	memset(ptr_msg, 0, sizeof (struct fa_delete_entry_message));
	ptr_msg->tenum = (uint32_t)(abs_index & DPPOLICY_TENUM_MASK);
}

static int execute_policy_delete_entry(struct dppolicy* policy, uint8_t *ptr,
									void *cmd_cfg, int abs_index)
{

	uint32_t mtypeout;
	uint8_t *ptr_out_msg;
	int err;
	uint16_t status;

	fill_policy_delete_entry_message(ptr, abs_index);
	err = ctlu_execute_cmd(policy->policy_mng->ctlu, NULL, cmd_cfg, /* interface handle */
			MNG_CMD_DPPOLICY_RULE_DEL,
            &status, &mtypeout,
            (void**)&ptr_out_msg);
	if (err)
		return err;
	ASSERT_COND(!status);
	return 0;
}

static void fill_policy_query_rule_entry_message(uint8_t *ptr, int abs_index)
{
	struct fa_query_entry_message 	*ptr_msg  = (struct fa_query_entry_message *)ptr;

	memset(ptr_msg, 0, sizeof (struct fa_query_entry_message));
	ptr_msg->tenum = (uint32_t)(abs_index & DPPOLICY_TENUM_MASK);
	ptr_msg->tenum |= DPPOLICY_QUERY_RULE;


}

static void fill_policy_query_mask_entry_message(uint8_t *ptr, int abs_index)
{
	struct fa_query_entry_message 	*ptr_msg  = (struct fa_query_entry_message *)ptr;

	memset(ptr_msg, 0, sizeof (struct fa_query_entry_message));
	ptr_msg->tenum = (uint32_t)(abs_index & DPPOLICY_TENUM_MASK);
	ptr_msg->tenum |= DPPOLICY_QUERY_MASK;


}

static void fill_policy_move_entry_message(uint8_t *ptr, int from_abs_index, int to_abs_index)
{
	struct fa_move_entry_message 	*ptr_msg  = (struct fa_move_entry_message *)ptr;

	memset(ptr_msg, 0, sizeof (struct fa_move_entry_message));

	ptr_msg->from_tenum = (uint16_t)(from_abs_index & DPPOLICY_TENUM_MASK);
	ptr_msg->to_tenum = (uint16_t)(to_abs_index & DPPOLICY_TENUM_MASK);

}
static int execute_policy_compare_entry(struct dppolicy* policy, uint8_t *ptr,
										void *cmd_cfg, int abs_index,
										void *user_rule_msg, int *found)
{
	int err;
	uint8_t *ptr_out_msg;
	uint16_t status;
	uint32_t mtypeout;

	*found = 0;
	fill_policy_query_rule_entry_message (ptr, abs_index);

	err = ctlu_execute_cmd(policy->policy_mng->ctlu, NULL,
							cmd_cfg, /* interface handle */
							MNG_CMD_DPPOLICY_RULE_QUERY,
	                        &status, &mtypeout,
	                        (void**)&ptr_out_msg);
	if (err)
		return err;
	ASSERT_COND(!status);

	if (memcmp(user_rule_msg,
			ptr_out_msg, DPPOLICY_RULE_MASK_SIZE/2) == 0) {

		fill_policy_query_mask_entry_message (ptr, abs_index);
		err = ctlu_execute_cmd(policy->policy_mng->ctlu, NULL,
								cmd_cfg, /* interface handle */
								MNG_CMD_DPPOLICY_RULE_QUERY,
		                        &status, &mtypeout,
		                        (void**)&ptr_out_msg);
		if (err)
			return err;
		ASSERT_COND(!status);

		if (memcmp(PTR_MOVE(user_rule_msg,DPPOLICY_RULE_MASK_SIZE/2) ,
				PTR_MOVE(ptr_out_msg, DPPOLICY_RULE_MASK_SIZE/2),
				DPPOLICY_RULE_MASK_SIZE/2) == 0) {
			*found = 1;
		}
	}

	return 0;

}

static int execute_policy_move_entry	(struct dppolicy* policy, uint8_t *ptr, void *cmd_cfg,
										int from_abs_index, int to_abs_index)
{
	uint32_t mtypeout;
	uint8_t *ptr_out_msg;
	int err;
	uint16_t status;
	ASSERT_COND(from_abs_index != to_abs_index);

	fill_policy_move_entry_message	(ptr,
									from_abs_index,
									to_abs_index);

	err = ctlu_execute_cmd(policy->policy_mng->ctlu, NULL, cmd_cfg, /* interface handle */
							MNG_CMD_DPPOLICY_RULE_MOVE,
	                        &status, &mtypeout,
	                        (void**)&ptr_out_msg);
	if (err)
		return err;
	ASSERT_COND(!status);
	return 0;
}

/*********************************************************/
/*			FUNCTIONS for DPPOLICY			 */
/*********************************************************/



static void add_abs_index_to_array_priority_abs_index_in_asc_order
									(struct dppolicy_entry *entries,
                                         int abs_index,
                                         int count,
                                         uint32_t max_num_of_entries)
{
	int k = 0, i = 0;

	ASSERT_COND(count > 0);
	ASSERT_COND(count <= max_num_of_entries);

	for (i = 0; i < count; i++)
	{
		if (i == (count - 1))
			entries[i].abs_index = abs_index;
		else {
			if (abs_index < entries[i].abs_index)
			{
				for (k = (count - 1) ; k > i; k--)
					entries[k].abs_index =
							entries[k - 1].abs_index;

				entries[k].abs_index =
						(uint16_t)abs_index;
				break;
			}
			else
				ASSERT_COND(abs_index != entries[i].abs_index);
}

	}
}

static void dppolicy_free(struct dppolicy *dppolicy, int *res_ids)
{
	int i = 0;
	void *resman;
	char str[16];
	struct resman_res_req res_req;
	int err;

	if (dppolicy)
	{
		ctlu_get_str(ctlu_get_iop_id(dppolicy->policy_mng->ctlu),
				ctlu_get_type(dppolicy->policy_mng->ctlu), str);
		snprintf(res_req.type, sizeof(res_req.type), "plcye.%s", str);

		resman = ctlu_get_resman(dppolicy->policy_mng->ctlu);

		if (res_ids) {
			for (i = 0; i < dppolicy->max_rules; i++)
			{
				if (res_ids[i] != NO_AVAILABLE_RESMAN_IDS)
					resman_unbind(resman,
							res_req.type,
							res_ids[i]);
			}
		}
		else if (dppolicy->entries) {
			for (i = 0; i < dppolicy->max_rules; i++)
			{
				err = resman_unbind(resman,
						res_req.type,
						dppolicy->entries[i].abs_index);
				ASSERT_COND(!err);
			}
			fsl_free(dppolicy->entries);
		}

		fsl_free(dppolicy);
	}
}

struct dppolicy*  dppolicy_init	(struct dppolicy_mng *dppolicy_mng,
                                 int dppolicy_id,
                                 const struct dppolicy_cfg *cfg)
{

	struct dppolicy 	*dppolicy = NULL;
	int 				i = 0;
	int 				abs_index;
	int 				*res_ids = NULL;
	int 				err;
	struct resman_res_req	res_req ;
	char str[16];

	dppolicy = (struct dppolicy *)fsl_malloc(sizeof(struct dppolicy));
	if (!dppolicy) {
		pr_err("memory allocation for internal dppolicy structure failed \n");
		return NULL;
	}
	memset(dppolicy, 0, sizeof(struct dppolicy));

	dppolicy->dppolicy_id = dppolicy_id;
	dppolicy->max_rules = cfg->max_num_of_rules;
	dppolicy->policy_mng = dppolicy_mng;

	/*get resources from resource manager
	supposed to be in ascending order*/
	memset(&res_req, 0, sizeof(struct resman_res_req));
	ctlu_get_str(ctlu_get_iop_id(dppolicy_mng->ctlu), ctlu_get_type(dppolicy_mng->ctlu), str);
	snprintf(res_req.type, sizeof(res_req.type), "plcye.%s", str);
	res_req.num = dppolicy->max_rules;
	res_req.options = DPRC_RES_REQ_OPT_ALIGNED;
	res_req.id_base_align = 1;
	res_ids = (int *)fsl_malloc (sizeof(int) * res_req.num);
	if (!res_ids) {
		pr_err("memory allocation for internal dppolicy structure failed \n");
		dppolicy_free(dppolicy, NULL);
		return NULL;

	}
	memset(res_ids, NO_AVAILABLE_RESMAN_IDS, sizeof(int) * res_req.num);
	err =  resman_bind(ctlu_get_resman(dppolicy_mng->ctlu), &res_req, res_ids);
	if (err) {
		pr_err("user asked for policy with max_num_of_rules greater than "
				"system can supply - Please try initialization of this policy later."
				"Maybe the required resources will be available later.\n");
		dppolicy_free(dppolicy, res_ids);
		fsl_free(res_ids);
		return NULL;
	}
	/*fill the relevant data structure with returned indexes
	 * in ascending order */

	dppolicy->entries = (struct dppolicy_entry *)fsl_malloc
						(cfg->max_num_of_rules *
						sizeof(struct dppolicy_entry));

	if (!dppolicy->entries) {
		pr_err("memory allocation for internal dppolicy structure failed \n");
		fsl_free(res_ids);
		dppolicy_free(dppolicy, NULL);
		return NULL;
	}
	memset(dppolicy->entries, 0, cfg->max_num_of_rules *
						sizeof(struct dppolicy_entry));


	for (i = 0; i < dppolicy->max_rules; i++)
	{
		abs_index = res_ids[i];
		add_abs_index_to_array_priority_abs_index_in_asc_order
		(dppolicy->entries, abs_index,i+1,dppolicy->max_rules);
	}
	fsl_free(res_ids);
	return dppolicy;
}



int  dppolicy_done(struct dppolicy* dppolicy)
{

	int i;
	void 			*cmd_cfg = NULL;
	uint32_t 		*mtypein_addr;
	uint8_t 		*ptr_in_msg;
	int 			abs_index;
	int 			err, err_tmp;
	int 			init = 0;
	ASSERT_COND(dppolicy);

	if (dppolicy->used_rules)
	{
		/* get a cmd_cfg handle and a pointer for the input message */
		err = ctlu_build_cmd_cfg(dppolicy->policy_mng->ctlu,
		                             &cmd_cfg,
		                      	     (void*)&ptr_in_msg,
		                             &mtypein_addr);
		ASSERT_COND(!err);

		for(i = 0; i < dppolicy->max_rules; i++)
		{
			if (dppolicy->entries[i].init)
			{
				abs_index = dppolicy->entries[i].abs_index;
				err = execute_policy_delete_entry(dppolicy, ptr_in_msg, cmd_cfg, abs_index);
				if (err) {
					err_tmp = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
					ASSERT_COND(!err_tmp);
					return err;			
				}
				DPPOLICY_UPDATE_ENTRY_INIT(dppolicy, i,init);

			}
		}
		err = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
	}

	dppolicy_free(dppolicy, NULL);

	return 0;

}

struct dppolicy_mng *  dppolicy_mng_init(const struct dppolicy_mng_cfg *dppolicy_mng_cfg)
{
	int i = 0;
	struct dppolicy_mng *dppolicy_mng ;

	dppolicy_mng = (struct dppolicy_mng *)fsl_malloc(
	        sizeof(struct dppolicy_mng));

	if (!dppolicy_mng) {
		pr_err("No memory allocation for internal dpmng data structure\n");
		return NULL;
	}
	memset(dppolicy_mng, 0, sizeof(struct dppolicy_mng));

	dppolicy_mng->ctlu = dppolicy_mng_cfg->ctlu;
	dppolicy_mng->num_dppolicy_entries = dppolicy_mng_cfg->num_dppolicy_entries;

	for(i = 0; i < NET_PROT_DUMMY_LAST; i++) {
		dppolicy_mng->prot_info[i].prot_to_faf_offset =
					PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE;
		dppolicy_mng->prot_info[i].prot_prs_err_to_faf_offset =
					PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE;
		dppolicy_mng->prot_info[i].prot_last_index_to_faf_offset =
					PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE;
		dppolicy_mng->prot_info[i].
				prot_prs_err_last_index_to_faf_offset =
					PROTOCOL_TO_FAF_OFFSET_UNAVAILABLE;
	}
	fill_policy_mng_info(dppolicy_mng);

	return dppolicy_mng;

}

void dppolicy_mng_done (struct dppolicy_mng *dppolicy_mng)
{
	if (dppolicy_mng)
		fsl_free(dppolicy_mng);
}

int dppolicy_rule_check_cfg(struct dppolicy* dppolicy,
							const struct dppolicy_rule 	*rule,
							const struct dppolicy_action *action)
{
	int 			err = 0;
	struct fa_message 	ptr_msg;

	memset(&ptr_msg, 0, sizeof(struct fa_message));
	err = build_policy_create_entry_message((uint8_t *)&ptr_msg, dppolicy,
						rule, action, 0);
	return err;
}
int dppolicy_add_rule	(struct dppolicy* dppolicy,
						const struct dppolicy_rule 	*rule,
			const struct dppolicy_action *action,
			int restore)
{
	uint8_t 		*ptr_in_msg, *ptr_out_msg;
	int				abs_index;
	int 			err = 0, err_tmp = 0;
	uint16_t 		status;
	uint32_t 		mtypeout;
	void 			*cmd_cfg = NULL;
	uint32_t 		*mtypein_addr;
	int 			add = 1, init = 1;


	/*new rule can not be added due to the reach of max_num_of_rules*/
	/* In case of hardware restore, used_rules = max_rules */
	if ((dppolicy->used_rules == dppolicy->max_rules) && !restore)
	{
		pr_err("Can not add rule to the policy since - exceed the"
				 "max_num_of_rules declared in the creation of the policy."
				 "used_num_of_rules is %d,"
				 "maximum number of rules defined for this policy = %d\n",
				 dppolicy->used_rules, dppolicy->max_rules);
		return -EDOM;
	}

	/*due to the decision that the priority is relative index
	to priority, priority can not be larger than max_num_of_rules*/
	if(rule->priority >= dppolicy->max_rules)
	{
		pr_err("Priority of the rule should be in the range %d, %d.\n",
				0 ,dppolicy->max_rules);
		return -EINVAL;
	}

	/*this priority can not be initialized entry as this function
	is used*/
	/* In case of restore, the rule is already initialized */
	if (DPPOLICY_IS_ENTRY_INIT(dppolicy, rule->priority) && !restore)
	{
		pr_err("Rule with the same priority was initialized."
				"Change priority or remove existing rule\n");
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dppolicy->policy_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);


	/* get absolute index in TCAM ACL FRAME ATTRIB */
	abs_index = DPPOLICY_GET_ABS_INDEX(dppolicy, rule->priority);

	err = build_policy_create_entry_message(ptr_in_msg, dppolicy,
						rule, action, abs_index);
	pr_debug(" Add rule with abs_index = %d, used_rules = %d, max_rules = %d, priority = %d \n", 
			abs_index, dppolicy->used_rules, dppolicy->max_rules, rule->priority);
	if (err != 0){
		err_tmp = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}

	err = ctlu_execute_cmd(dppolicy->policy_mng->ctlu, NULL,
							cmd_cfg, /* interface handle */
							MNG_CMD_DPPOLICY_RULE_CREATE_REPLACE,
	                        &status, &mtypeout,
	                        (void**)&ptr_out_msg);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	/* Seams that the rule is present after WRIOP reset */
	/* Need to be investigated */
	if(!restore)
		ASSERT_COND((status & MNG_CMD_STATUS_TLUMISS) == MNG_CMD_STATUS_TLUMISS);

	err = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	/* Do not modify at restore, rule is already init and counted */
	if(!restore){
		DPPOLICY_UPDATE_ENTRY_INIT(dppolicy, rule->priority, init);
		DPPOLICY_UPDATE_USED_NUM_OF_RULES(dppolicy, add);
	}

	return 0;

}


int dppolicy_remove_rule(struct dppolicy *dppolicy,
                         const struct dppolicy_rule *rule)
{

	int abs_index;
	void *cmd_cfg;
	uint8_t *ptr_in_msg;
	int err, err_tmp;
	uint32_t *mtypein_addr;
	int add = 0, init = 0;
	struct fa_message 	user_rule_msg;
	int found = 0;


	/*due to the decision that the priority is relative index
	to priority, priority can not be larger than max_num_of_rules*/
	if(rule->priority >= dppolicy->max_rules)
	{
		pr_err("Priority of the rule (%d) should be in the range %d, %d.\n",
				rule->priority, 0 ,dppolicy->max_rules);
		return -EINVAL;
	}

	/*for this function the rule with defined priority MUST be added*/
	if (DPPOLICY_IS_ENTRY_INIT(dppolicy, rule->priority) == 0)
	{
		pr_err("Rule with the same priority (%d) was not initialized."
				"Change priority or add_entry with this rule\n",
				rule->priority);
		return -EINVAL;
	}

	abs_index = DPPOLICY_GET_ABS_INDEX(dppolicy, rule->priority);

	/*for being sure that the rule itself the same as user intended
	 * to delete and not relying only on priority*/
	memset(&user_rule_msg, 0, sizeof(struct fa_message));
	err = build_policy_create_entry_message((uint8_t *)&user_rule_msg, dppolicy,
											rule, NULL, abs_index);
	if (err) {
		pr_err("provided rule is not correct\n");
		return -EINVAL;
	}


	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dppolicy->policy_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	err  = execute_policy_compare_entry(dppolicy, ptr_in_msg, cmd_cfg,
									abs_index,(void *)&user_rule_msg, &found);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	if (found == 0) {
		pr_err("There is mismatch between rule itself and priority"
				"On this priority was defined another rule\n");
		err = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -EINVAL;
	}

	err = execute_policy_delete_entry(dppolicy, ptr_in_msg, cmd_cfg, abs_index);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
		
	
	err = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	DPPOLICY_UPDATE_ENTRY_INIT(dppolicy, rule->priority, init);
	DPPOLICY_UPDATE_USED_NUM_OF_RULES(dppolicy, add);

	return 0;
}

int dppolicy_move_rule(struct dppolicy *dppolicy,
                       const int old_priority, const int new_priority)
{

	int abs_old_index, abs_new_index;
	void *cmd_cfg;
	uint8_t *ptr_in_msg;
	int err, err_tmp;
	uint32_t *mtypein_addr;
	int init;

	/*due to the decision that the priority is relative index
	to priority, priority can not be larger than max_num_of_rules*/
	if(old_priority >= dppolicy->max_rules)
	{
		pr_err("old priority %d should be in the range %d, %d.\n",
				old_priority, 0 ,dppolicy->max_rules);
		return -EINVAL;
	}

	/*due to the decision that the priority is relative index
	to priority, priority can not be larger than max_num_of_rules*/
	if(new_priority >= dppolicy->max_rules)
	{
		pr_err("new priority %d  should be in the range %d, %d.\n",
				new_priority, 0 ,dppolicy->max_rules);
		return -EINVAL;
	}

	/*rule with index we want to move from MUST be initialized*/
	if (DPPOLICY_IS_ENTRY_INIT(dppolicy, old_priority) == 0)
	{
		pr_err("Rule with old priority was not initialized."
				"Change priority or add_entry with this priority\n");
		return -EINVAL;
	}

	/*rule with index we want to move from MUST be uninitialized*/
	if (DPPOLICY_IS_ENTRY_INIT(dppolicy, new_priority) )
	{
		pr_err("Rule with new_priority priority is existing."
				"Change priority or remove rulefrom new priority \n");
		return -EINVAL;
	}


	abs_old_index = DPPOLICY_GET_ABS_INDEX(dppolicy, old_priority);
	abs_new_index = DPPOLICY_GET_ABS_INDEX(dppolicy, new_priority);

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dppolicy->policy_mng->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	err = execute_policy_move_entry(dppolicy, ptr_in_msg, cmd_cfg,
								abs_old_index, abs_new_index);

	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	err = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	/*sign entry we moved from as free*/
	init = 0;
	DPPOLICY_UPDATE_ENTRY_INIT(dppolicy, old_priority, init);

	/*sign entry we moved to as free*/
	init = 1;
	DPPOLICY_UPDATE_ENTRY_INIT(dppolicy, new_priority,init);

	return 0;
}

int dppolicy_modify_rule(struct dppolicy* dppolicy,
	const struct dppolicy_rule *rule,
	const struct dppolicy_action *action)
{
	uint8_t *ptr_in_msg, *ptr_out_msg;
	int abs_index;
	int err = 0, err_tmp = 0;
	uint16_t status;
	uint32_t mtypeout;
	void *cmd_cfg = NULL;
	uint32_t *mtypein_addr;

	/*due to the decision that the priority is relative index
	to priority, priority can not be larger than max_num_of_rules*/
	if(rule->priority >= dppolicy->max_rules)
	{
		pr_err("Priority of the rule (%d) should be in the range %d, %d.\n",
				rule->priority, 0 ,dppolicy->max_rules);
		return -EINVAL;
	}

	/*this priority can not be initialized entry as this function
	 is used*/
	if (DPPOLICY_IS_ENTRY_INIT(dppolicy, rule->priority) == 0) {
		pr_err("Rule with priority = %d  was initialized."
		"Change priority or remove existing rule\n",
		rule->priority);
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dppolicy->policy_mng->ctlu, &cmd_cfg,
					(void*)&ptr_in_msg, &mtypein_addr);
	ASSERT_COND(!err);

	/* get absolute index in TCAM ACL FRAME ATTRIB */
	abs_index = DPPOLICY_GET_ABS_INDEX(dppolicy, rule->priority);

	err = build_policy_create_entry_message(ptr_in_msg, dppolicy, rule,
						action, abs_index);
	if (err != 0) {
		err_tmp = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}

	err = ctlu_execute_cmd(dppolicy->policy_mng->ctlu, NULL, cmd_cfg, /* interface handle */
				MNG_CMD_DPPOLICY_RULE_CREATE_REPLACE, &status,
				&mtypeout, (void**)&ptr_out_msg);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	
	ASSERT_COND(
		(status & MNG_CMD_STATUS_TLUMISS) != MNG_CMD_STATUS_TLUMISS);

	err = ctlu_free_cmd_cfg(dppolicy->policy_mng->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return 0;
}

