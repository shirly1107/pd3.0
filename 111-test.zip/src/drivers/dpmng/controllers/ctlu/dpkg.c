/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "common/fsl_string.h"
#include "fsl_net.h"
#include "fsl_eiop_ifp.h"
#include "fsl_ctlu.h"
#include "fsl_io.h"

#include "dpkg.h"

struct full_field eth_full_field[] =
{
		{NH_FLD_ETH_DA,	 	0,	FECID_ETH_MACDST},
		{NH_FLD_ETH_SA, 	0,	FECID_ETH_MACSRC},
		{NH_FLD_ETH_TYPE, 	0,	FECID_ETH_TYPE},
		{0,					0,	FECID_UNKNOWN}
};

struct full_field vlan_full_field[] =
{
		{NH_FLD_VLAN_TCI,	0,				FECID_VLANTCI_1},
		{NH_FLD_VLAN_TCI, 	(uint8_t)LAST_HDR_INDEX,	FECID_VLANTCI_N},
		{0, 				0,				FECID_UNKNOWN}
};

struct full_field udp_full_field[] =
{
		{NH_FLD_UDP_PORT_SRC,	0,	FECID_L4_SRC},
		{NH_FLD_UDP_PORT_DST, 	0,	FECID_L4_DST},
		{0, 					0,	FECID_UNKNOWN}
};

struct full_field tcp_full_field[] =
{
		{NH_FLD_TCP_PORT_SRC,	0,	FECID_L4_SRC},
		{NH_FLD_TCP_PORT_DST, 	0,	FECID_L4_DST},
		{NH_FLD_TCP_FLAGS, 		0,	FECID_TCP_FLAGS},
		{0, 					0,	FECID_UNKNOWN}
};

struct full_field minencap_full_field[] =
{
		{NH_FLD_MINENCAP_SRC_IP,	0,	FECID_IP_SRC_IP_N_OR_MINENCAP_SRC},
		{NH_FLD_MINENCAP_DST_IP,	0,	FECID_IP_DST_IP_N_OR_MINENCAP_DST},
		{NH_FLD_MINENCAP_TYPE,		0,	FECID_IP_PROTO_N_OR_MINENCAP_TYPE},
		{0,							0,	FECID_UNKNOWN}
};

struct full_field sctp_full_field[] =
{
		{NH_FLD_SCTP_PORT_SRC,	0,	FECID_L4_SRC},
		{NH_FLD_SCTP_PORT_DST, 	0,	FECID_L4_DST},
		{0, 					0,	FECID_UNKNOWN}
};

struct full_field dccp_full_field[] =
{
		{NH_FLD_DCCP_PORT_SRC,	0,	FECID_L4_SRC},
		{NH_FLD_DCCP_PORT_DST, 	0,	FECID_L4_DST},
		{0, 					0,	FECID_UNKNOWN}
};

struct full_field pppoe_full_field[] =
{
		{NH_FLD_PPPOE_SID,	0,	FECID_PPPoE_SID},
		{NH_FLD_PPPOE_PID, 	0,	FECID_PPPoE_PID},
		{0, 				0,	FECID_UNKNOWN}
};

struct full_field arp_full_field[] =
{
		{NH_FLD_ARP_OPER,	0,	FECID_ARP_OP},
		{NH_FLD_ARP_SPA,	0,	FECID_ARP_SPA},
		{NH_FLD_ARP_TPA,	0,	FECID_ARP_TPA},
		{NH_FLD_ARP_SHA,	0,	FECID_ARP_SHA},
		{NH_FLD_ARP_THA,	0,	FECID_ARP_THA},
		{0,					0,	FECID_UNKNOWN}
};

struct full_field gre_full_field[] =
{
		{NH_FLD_GRE_TYPE,	0,	FECID_GRE_TYPE},
		{0,					0,	FECID_UNKNOWN}
};

struct full_field gtp_full_field[] =
{
		{NH_FLD_GTP_TEID,	0,	FECID_GTP_TEID},
		{0,					0,	FECID_UNKNOWN}
};

struct full_field ipsec_ah_full_field[] =
{
		{NH_FLD_IPSEC_AH_SPI,	0,	FECID_IPSEC_SPI},
		{NH_FLD_IPSEC_AH_NH,	0,	FECID_IPSEC_AH_NH},
		{0,						0,	FECID_UNKNOWN}
};

struct full_field ipsec_esp_full_field[] =
{
		{NH_FLD_IPSEC_ESP_SPI,	0,	FECID_IPSEC_SPI},
		{0,						0,	FECID_UNKNOWN}
};

struct full_field icmp_full_field[] =
{
		{NH_FLD_ICMP_TYPE,	0,	FECID_ICMP_TYPE},
		{NH_FLD_ICMP_CODE,	0,	FECID_ICMP_CODE},
		{0,					0,	FECID_UNKNOWN}
};


struct full_field ip_full_field[] =
{
		{NH_FLD_IP_SRC,		0,
				FECID_IP_SRC_IP_1 + FECID_IP_SRC_FROM_BASIC},
		{NH_FLD_IP_DST,		0,
				FECID_IP_SRC_IP_1 + FECID_IP_DST_FROM_BASIC},
		{NH_FLD_IP_PROTO,	0,
				FECID_IP_SRC_IP_1 + FECID_IP_PROTO_FROM_BASIC},
		{NH_FLD_IP_TOS_TC,	0,
				FECID_IP_SRC_IP_1 + FECID_IP_TOS_FROM_BASIC},
		{NH_FLD_IP_ID,		0,
				FECID_IP_SRC_IP_1 + FECID_IP_ID_FROM_BASIC},
		{NH_FLD_IP_SRC,		(uint8_t)LAST_HDR_INDEX,
				FECID_IP_SRC_IP_N_OR_MINENCAP_SRC + FECID_IP_SRC_FROM_BASIC},
		{NH_FLD_IP_DST,		(uint8_t)LAST_HDR_INDEX,
				FECID_IP_SRC_IP_N_OR_MINENCAP_SRC + FECID_IP_DST_FROM_BASIC},
		{NH_FLD_IP_PROTO,	(uint8_t)LAST_HDR_INDEX,
				FECID_IP_SRC_IP_N_OR_MINENCAP_SRC + FECID_IP_PROTO_FROM_BASIC},
		{NH_FLD_IP_TOS_TC,	(uint8_t)LAST_HDR_INDEX,
				FECID_IP_SRC_IP_N_OR_MINENCAP_SRC + FECID_IP_TOS_FROM_BASIC},
		{NH_FLD_IP_ID,		(uint8_t)LAST_HDR_INDEX,
				FECID_IP_SRC_IP_N_OR_MINENCAP_SRC + FECID_IP_ID_FROM_BASIC},
		{0,					0,	FECID_UNKNOWN}
};



struct full_field ipv6_full_field[] =
{
		{NH_FLD_IPV6_FL,	0,				FECID_IPv6_FL_1},
		{NH_FLD_IPV6_FL,	(uint8_t)LAST_HDR_INDEX,	FECID_IPv6_FL_N},
		{0,					0,	FECID_UNKNOWN}
};


struct full_field mpls_full_field[] =
{
		{NH_FLD_MPLS_MPLSL_1,	0,	FECID_MPLSL_1},
		{NH_FLD_MPLS_MPLSL_2,	0,	FECID_MPLSL_2},
		{NH_FLD_MPLS_MPLSL_N,	0,	FECID_MPLSL_N},
		{0,						0,	FECID_UNKNOWN}
};






int dpkg_get_counter(struct dpkg *dpkg, int profile_id)
{
	struct dpkg_profile_regs *regs = dpkg->dpkg_regs_base + profile_id;

	return (int)ioread32(&regs->iop_ckrhcnt);
}

void dpkg_set_counter(struct dpkg *dpkg, int profile_id, uint32_t val)
{
	struct dpkg_profile_regs *regs = dpkg->dpkg_regs_base + profile_id;

	iowrite32(val, &regs->iop_ckrhcnt);
}

int dpkg_get_error(struct dpkg *dpkg, int profile_id)
{
	struct dpkg_profile_regs *regs = dpkg->dpkg_regs_base + profile_id;

	return (int)ioread32(&regs->iop_ckcerr);
}



static void build_mask_extention(uint8_t *ptr, uint8_t num_of_byte_masks,
			 const struct dpkg_mask *masks)
{
	struct fec_mask_extention *ptr_mask;

	if(num_of_byte_masks == 0)
		return;
	ptr_mask = (struct fec_mask_extention *)ptr;

	switch(num_of_byte_masks){
		case(4) :
			ptr_mask->moff3 = masks[3].offset;
			ptr_mask->mask3 = masks[3].mask;
		case(3) :
			ptr_mask->moff1_moff2 = masks[2].offset;
			ptr_mask->mask2 = masks[2].mask;
		case(2) :
			ptr_mask->moff1_moff2 |= masks[1].offset <<
					FEC_MASK_EXT_MOFF1_SHIFFT;
			ptr_mask->mask1 = masks[1].mask;
		case(1) :
			ptr_mask->nmask_moff0 = masks[0].offset;
			ptr_mask->mask0 = masks[0].mask;
			break;
		default :
			break;

	}
	ptr_mask->nmask_moff0 |=
		((num_of_byte_masks - 1) << FEC_MASK_EXT_NMSK_SHIFFT);

}
static void build_full_field (uint8_t *ptr,
			uint8_t fecid,
			uint8_t nmsk)
{
	struct fec_format *ptr_fec = (struct fec_format *)ptr;
	ptr_fec->fecid = (uint8_t )((fecid << FECID_SHIFFT) |
			((nmsk > 0) ? 1 : 0));
}

static void build_generic_extraction 	(uint8_t *ptr,
				uint8_t nmsk,
				struct fecid_0 *fecid_0)
{
	struct fec_format *ptr_fec = (struct fec_format *)ptr;

	ptr_fec->fecid = (uint8_t)((nmsk > 0) ? 1 : 0);

	ptr_fec->op0 = (uint8_t)((fecid_0->extract_type << OP0_HET_SHIFFT) |
			fecid_0->offset_mode);
	ptr_fec->op1 = fecid_0->offset;
	ptr_fec->op2 = fecid_0->size;


}

static void build_insert_constant 	(uint8_t *ptr,
				uint8_t nmsk,
				struct fecid_1 *fecid_1)
{
	struct fec_format *ptr_fec = (struct fec_format *)ptr;
	ptr_fec->fecid = (uint8_t )((FECID_INSERT_CONSTANT << FECID_SHIFFT) |
			 ((nmsk > 0) ? 1 : 0));

	ptr_fec->op0 = fecid_1->num_of_times_repeat;
	ptr_fec->op1 = fecid_1->constant;
}

static void build_kg_profile_create_message	(uint8_t *ptr,
				const struct dpkg_profile_cfg *cfg,
				struct dpkg_profiles_tmp *tmp_params)
{
	int i = 0;
	uint8_t *ptr_tmp;
	const struct dpkg_extract *extract;
	struct profile_tmp *prfl_tmp;

	ptr_tmp = ptr;
	ptr_tmp += 1;

	for (i = 0; i < cfg->num_extracts; i++) {
		extract = &cfg->extracts[i];
		prfl_tmp = &tmp_params->prfl_tmp[i];
		switch(prfl_tmp->fecid) {
		case(0):
			build_generic_extraction(ptr_tmp,
						extract->num_of_byte_masks,
						&prfl_tmp->specific.fecid0);
			break;
		case(1):
			build_insert_constant	(ptr_tmp,
						extract->num_of_byte_masks,
						&prfl_tmp->specific.fecid1);
			break;
		case(2):
		//	build_validate_fileds();
			break;
		default:
			build_full_field	(ptr_tmp,
						prfl_tmp->fecid,
						extract->num_of_byte_masks);

			break;
		}
		ptr_tmp += prfl_tmp->fec_format_size;

		build_mask_extention	(ptr_tmp,
					extract->num_of_byte_masks,
					extract->masks);
		ptr_tmp += prfl_tmp->fec_format_mask_ext_size;

	}

	ptr[0] = cfg->num_extracts;


}

static void fill_kg_prf_info_info(struct dpkg *dpkg)
{

	dpkg->prf_prot_info[NET_PROT_ETH].full_field = eth_full_field;

	dpkg->prf_prot_info[NET_PROT_VLAN].full_field =
					vlan_full_field;

	dpkg->prf_prot_info[NET_PROT_PPPOE].full_field =
					pppoe_full_field;
	dpkg->prf_prot_info[NET_PROT_PPPOE].protocol_based_offset =
					PR_PPPoE_OFFSET;

	dpkg->prf_prot_info[NET_PROT_ARP].full_field =
					arp_full_field;
	dpkg->prf_prot_info[NET_PROT_ARP].protocol_based_offset =
					PR_ARP_OFFSET;

	dpkg->prf_prot_info[NET_PROT_IP].full_field =
					ip_full_field;
	dpkg->prf_prot_info[NET_PROT_IP].protocol_based_offset =
					PR_ARP_OR_IP_1_OFFSET;
	dpkg->prf_prot_info[NET_PROT_IP].last_protocol_based_offset =
					PR_MINENCAP_OR_IP_N_OFFSET;

	dpkg->prf_prot_info[NET_PROT_IPV6].full_field =
					ipv6_full_field;

	dpkg->prf_prot_info[NET_PROT_GRE].full_field =
					gre_full_field;
	dpkg->prf_prot_info[NET_PROT_GRE].protocol_based_offset =
					PR_GRE_OFFSET;

	dpkg->prf_prot_info[NET_PROT_UDP].full_field =
					udp_full_field;
	dpkg->prf_prot_info[NET_PROT_UDP].protocol_based_offset =
					PR_L4_OFFSET;

	dpkg->prf_prot_info[NET_PROT_TCP].full_field =
					tcp_full_field;
	dpkg->prf_prot_info[NET_PROT_TCP].protocol_based_offset =
					PR_L4_OFFSET;

	dpkg->prf_prot_info[NET_PROT_SCTP].full_field =
					sctp_full_field;
	dpkg->prf_prot_info[NET_PROT_SCTP].protocol_based_offset =
					PR_L4_OFFSET;

	dpkg->prf_prot_info[NET_PROT_DCCP].full_field =
					dccp_full_field;
	dpkg->prf_prot_info[NET_PROT_DCCP].protocol_based_offset =
					PR_L4_OFFSET;

#ifndef ERR008679
	dpkg->prf_prot_info[NET_PROT_ICMP].full_field =
					icmp_full_field;
#endif
	dpkg->prf_prot_info[NET_PROT_GTP].full_field =
					gtp_full_field;
	dpkg->prf_prot_info[NET_PROT_GTP].protocol_based_offset =
					PR_GTP_OR_ESP_OR_IPSEC_OFFSET;

	dpkg->prf_prot_info[NET_PROT_MINENCAP].full_field =
					minencap_full_field;
	dpkg->prf_prot_info[NET_PROT_MINENCAP].protocol_based_offset =
					PR_MINENCAP_OFFSET;

	dpkg->prf_prot_info[NET_PROT_LLC_SNAP].protocol_based_offset =
					PR_LLC_SNAP_OFFSET;

	dpkg->prf_prot_info[NET_PROT_MPLS].protocol_based_offset =
					PR_MPLS_1_OFFSET;
	dpkg->prf_prot_info[NET_PROT_MPLS].last_protocol_based_offset =
					PR_MPLS_N_OFFSET;
	dpkg->prf_prot_info[NET_PROT_MPLS].full_field = mpls_full_field;

	dpkg->prf_prot_info[NET_PROT_UDP_ENC_ESP].protocol_based_offset =
					PR_GTP_OR_ESP_OR_IPSEC_OFFSET;

	dpkg->prf_prot_info[NET_PROT_IPSEC_AH].protocol_based_offset =
					PR_GTP_OR_ESP_OR_IPSEC_OFFSET;
	dpkg->prf_prot_info[NET_PROT_IPSEC_AH].full_field =
					ipsec_ah_full_field;

	dpkg->prf_prot_info[NET_PROT_IPSEC_ESP].protocol_based_offset =
					PR_GTP_OR_ESP_OR_IPSEC_OFFSET;
	dpkg->prf_prot_info[NET_PROT_IPSEC_ESP].full_field =
					ipsec_esp_full_field;

}

static uint8_t fill_full_field_fecid	(const struct dpkg * dpkg,
				enum net_prot prot,
				uint8_t hdr_index,
				uint32_t field)
{

	struct full_field *full_field;

	full_field = dpkg->prf_prot_info[prot].full_field;
	if (full_field) {
	while	(((full_field->field != field) ||
			(full_field->hdr_index != hdr_index)) &&
			(full_field->opcode !=  FECID_UNKNOWN))
		full_field++;
	return full_field->opcode;
	}
	return FECID_UNKNOWN;
}

static uint8_t fill_protocol_based_offset_mode	(const struct dpkg *dpkg,
					enum net_prot prot,
					int hdr_index)
{
	uint8_t offset;

	offset = dpkg->prf_prot_info[prot].protocol_based_offset;

	if (hdr_index) {
		if (hdr_index == LAST_HDR_INDEX)
			offset = dpkg->prf_prot_info[prot].last_protocol_based_offset;
		else
			offset = PR_UNKNOWN_OFFSET;
	}
	return offset;

}


static uint8_t fill_field_based_offset_mode	(enum net_prot prot,
					uint32_t	field,
					int hdr_index)
{
	switch (prot) {
		case (NET_PROT_ETH) :
			if (field == NH_FLD_ETH_TYPE)
				return PR_ETHYPE_OFFSET;
			break;
		case (NET_PROT_VLAN) :
			if (field == NH_FLD_VLAN_TCI) {
				if (hdr_index == 0)
					return PR_VLAN_TCI_1_OFFSET;
				else if (hdr_index == LAST_HDR_INDEX)
					return PR_VLAN_TCI_N_OFFSET;
			}
			break;

	}
	return PR_UNKNOWN_OFFSET;
}

static int fill_full_field_format	(const struct dpkg * dpkg,
										const struct dpkg_extract *extract,
				struct profile_tmp *extract_tmp,
				uint8_t *fec_format_size)
{
	extract_tmp->fecid = fill_full_field_fecid
			(dpkg,
			extract->extract.from_hdr.prot,
			extract->extract.from_hdr.hdr_index,
			extract->extract.from_hdr.field);

	if (extract_tmp->fecid==FECID_UNKNOWN)
	{
		pr_err("was request to extract unsupported full field");
		return -EINVAL;
	}
	extract_tmp->fec_format_size = FEC_FORMAT_FULL_FIELD_SIZE;
	*fec_format_size += FEC_FORMAT_FULL_FIELD_SIZE;

	return 0;

}


static int fill_protocol_based_format	(const struct dpkg *dpkg,
										const struct dpkg_extract *extract,
				struct profile_tmp *extract_tmp,
				uint8_t *fec_format_size)
{
	/*get offset of relevant protocol in PR*/
	if (extract->extract.from_hdr.type == DPKG_FROM_HDR)
		extract_tmp->specific.fecid0.offset_mode =
				fill_protocol_based_offset_mode
				(dpkg,extract->extract.from_hdr.prot,
				extract->extract.from_hdr.hdr_index);
	else if (extract->extract.from_hdr.type == DPKG_FROM_FIELD)
	/*get offset of specific field in PR*/
		extract_tmp->specific.fecid0.offset_mode =
				fill_field_based_offset_mode
				(extract->extract.from_hdr.prot,
				extract->extract.from_hdr.field,
				extract->extract.from_hdr.hdr_index);
	else
		CHECK_COND_RETVAL( 0 , -EINVAL, "Unsupported field\n");

	CHECK_COND_RETVAL( extract_tmp->specific.fecid0.offset_mode != PR_UNKNOWN_OFFSET, -EINVAL,
			"was request to extract unsupported field\n" );

	if ((extract->extract.from_hdr.size > 16) ||
		(extract->extract.from_hdr.size < 1))
	{
		pr_err("was request to extract size not in the range."
				"the allowed range from %d to %d\n", 1,16);
		return -EINVAL;
	}

	if (extract->extract.from_hdr.offset > 15)
		return 1;
	/*fill other relevant parameters*/
	extract_tmp->fecid = FECID_GENERIC;
	extract_tmp->specific.fecid0.extract_type =
					FECID_PROTOCOL_BASED_HET;
	extract_tmp->specific.fecid0.size =
				(uint8_t )(extract->extract.from_hdr.size - 1);
	extract_tmp->specific.fecid0.offset =
				extract->extract.from_hdr.offset;

	extract_tmp->fec_format_size = FEC_FORMAT_EXTRACT_GENERIC_SIZE;
	*fec_format_size += FEC_FORMAT_EXTRACT_GENERIC_SIZE;

	return 0;

}

static int fill_insert_constant_format	(const struct dpkg_extract *extract,
				struct profile_tmp *extract_tmp,
				uint8_t *fec_format_size)
{

	if ((extract->extract.constant.num_of_repeats < 1) ||
		(extract->extract.constant.num_of_repeats > 16))
	{
		pr_err("user asked DPKG_EXTRACT_CONSTANT - invalid range"
				"of num_of_repeats. MUST be in range - "
				"%d to %d\n", 1, 16);
		return -EINVAL;
	}
	*fec_format_size += FEC_FORMAT_INSRT_CONSTANT_SIZE;
	extract_tmp->fec_format_size =
				FEC_FORMAT_INSRT_CONSTANT_SIZE;
	extract_tmp->fecid = FECID_INSERT_CONSTANT;
	extract_tmp->specific.fecid1.constant =
				extract->extract.constant.constant;
	extract_tmp->specific.fecid1.num_of_times_repeat =
				(uint8_t)(extract->extract.constant.num_of_repeats - 1);
	return 0;
}

static void fill_from_ifp_format(struct profile_tmp *extract_tmp)
{
	extract_tmp->specific.fecid0.offset = DPKG_EXTRACT_FROM_FCV_IFP_OFFSET;
	extract_tmp->specific.fecid0.offset_mode =
								DPKG_EXTRACT_FROM_FCV_IFP_OFFSET_MODE;
	extract_tmp->specific.fecid0.size = DPKG_EXTRACT_FROM_FCV_IFP_SIZE - 1;

}

static void fill_from_pr_specific_protocol_format
						(const struct dpkg_extract *extract,
						struct profile_tmp *extract_tmp)
{
	extract_tmp->specific.fecid0.offset = extract->extract.from_context.offset;
	extract_tmp->specific.fecid0.offset_mode =
			DPKG_EXTRACT_FROM_PR_SPECIFIC_PROTOCOL_OFFSET_MODE;
	extract_tmp->specific.fecid0.size =  extract->extract.from_context.size - 1;

}


static void fill_from_fcv_l2switch_fdb_specific_format(struct profile_tmp *extract_tmp)
{
	extract_tmp->specific.fecid0.offset = DPKG_EXTRACT_FROM_FCV_L2SWITCH_FDB_SPECIFIC_OFFSET;
	extract_tmp->specific.fecid0.offset_mode =
			DPKG_EXTRACT_FROM_FCV_L2SWITCH_FDB_SPECIFIC_OFFSET_MODE;
	extract_tmp->specific.fecid0.size = DPKG_EXTRACT_FROM_FCV_L2SWITCH_FDB_SPECIFIC_SIZE - 1;

}

static void fill_from_opaque_in_src_qdid_protocol_format(struct profile_tmp *extract_tmp)
{
	extract_tmp->specific.fecid0.offset = DPKG_EXTRACT_FROM_FCV_OPAQUE_IN_SPECIFIC_OFFSET + 
			DPKG_FROM_FCV_L2SWITCH_FD_FLC_FOR_REPLIC_SRC_QDID_SPECIFIC_OFFSET;
	extract_tmp->specific.fecid0.offset_mode =
			DPKG_EXTRACT_FROM_FCV_OPAQUE_IN_SPECIFIC_OFFSET_MODE;
	extract_tmp->specific.fecid0.size = 
			DPKG_EXTRACT_FROM_FCV_L2SWITCH_FD_FLC_FOR_REPLIC_SRC_QDID_SPECIFIC_SIZE - 1;

}

static int fill_extract_from_context_format(const struct dpkg_extract *extract,
											struct profile_tmp *extract_tmp,
											uint8_t *fec_format_size)
{
	extract_tmp->fecid = FECID_GENERIC;
	extract_tmp->specific.fecid0.extract_type =
								FECID_GENERIC_HET;
	switch(extract->extract.from_context.src) {
		case(DPKG_FROM_IFP) :
				fill_from_ifp_format(extract_tmp);
		break;
		case(DPKG_FROM_PARSE_RESULT_SPECIFIC_PROTOCOL) :
				fill_from_pr_specific_protocol_format(extract,
												extract_tmp);
		break;
		case(DPKG_FROM_FCV_L2SWITCH_FDB_SPECIFIC) :
				fill_from_fcv_l2switch_fdb_specific_format(extract_tmp);
		break;
		case(DPKG_FROM_FCV_FD_FLC_FOR_REPLIC_SRC_QDID) :
				fill_from_opaque_in_src_qdid_protocol_format(extract_tmp);
		break;
		default :
			pr_err("user asked to perform extraction from unsupported context");
			return -EINVAL;
	}

	extract_tmp->fec_format_size = FEC_FORMAT_EXTRACT_GENERIC_SIZE;
	*fec_format_size += FEC_FORMAT_EXTRACT_GENERIC_SIZE;

	return 0;

}

static int fill_data_format	(const struct dpkg_extract *extract,
			struct profile_tmp *extract_tmp,
			uint8_t *fec_format_size)
{

	if (extract->extract.from_data.size < 1)
	{
		pr_err("user asked to perform extraction from_data with size 0\n");
		return -EINVAL;
	}
	extract_tmp->fecid = FECID_GENERIC;
	extract_tmp->specific.fecid0.extract_type =
					FECID_GENERIC_HET;
	extract_tmp->specific.fecid0.offset_mode =
			(uint8_t)(extract->extract.from_data.offset / 16);

	extract_tmp->specific.fecid0.size =
			(uint8_t )(extract->extract.from_data.size - 1);
	extract_tmp->specific.fecid0.offset =
			(uint8_t)(extract->extract.from_data.offset % 16);

	extract_tmp->fec_format_size = FEC_FORMAT_EXTRACT_GENERIC_SIZE;
	*fec_format_size += FEC_FORMAT_EXTRACT_GENERIC_SIZE;

	return 0;
}

static int fill_params		(const struct dpkg * dpkg,
								const struct dpkg_extract *extract,
								struct profile_tmp *extract_tmp,
								uint8_t *fec_format_size)
{
	switch (extract->type) {
		case(DPKG_EXTRACT_FROM_HDR):
			switch (extract->extract.from_hdr.type) {
				case(DPKG_FULL_FIELD):
					return fill_full_field_format
					(dpkg, extract,extract_tmp, fec_format_size);
				break;
				case(DPKG_FROM_HDR):
				case(DPKG_FROM_FIELD):
					return fill_protocol_based_format
					(dpkg,extract,extract_tmp,
					fec_format_size);
				default :
					pr_err("extract type DPKG_EXTRACT_FROM_HDR but inside "
							"from_hdr params type is not valid.\n");
					return -EINVAL;
			}
		break;
		case (DPKG_EXTRACT_CONSTANT) :
			return fill_insert_constant_format
				(extract,extract_tmp,
				fec_format_size);

		break;
		case (DPKG_EXTRACT_FROM_DATA) :
			return fill_data_format
				(extract,extract_tmp,
				fec_format_size);

		break;
		case (DPKG_EXTRACT_FROM_CONTEXT) :
				return fill_extract_from_context_format
						(extract, extract_tmp, fec_format_size);
		default :
			pr_err("extract type is not valid.\n");
			return -EINVAL;
	}
	return 0;
}

static int fill_mask_params	(struct profile_tmp  *tmp_params,
			uint8_t num_of_byte_masks,uint8_t *fec_format_size)
{
	switch (num_of_byte_masks) {
	case (4) :
		*fec_format_size += FEC_FORMAT_4_MASK_EXTENTION_SIZE;
		tmp_params->fec_format_mask_ext_size =
				FEC_FORMAT_4_MASK_EXTENTION_SIZE;
	break;
	case (3) :
		*fec_format_size += FEC_FORMAT_3_MASK_EXTENTION_SIZE;
		tmp_params->fec_format_mask_ext_size =
				FEC_FORMAT_3_MASK_EXTENTION_SIZE;
	break;
	case (2) :
		*fec_format_size += FEC_FORMAT_2_MASK_EXTENTION_SIZE;
		tmp_params->fec_format_mask_ext_size =
				FEC_FORMAT_2_MASK_EXTENTION_SIZE;
	break;
	case (1) :
		*fec_format_size += FEC_FORMAT_1_MASK_EXTENTION_SIZE;
		tmp_params->fec_format_mask_ext_size =
				FEC_FORMAT_1_MASK_EXTENTION_SIZE;
	break;
	case (0) :
	break;
	default :
	{
		pr_err("the parameter num_of_byte_masks in extraction is "
				"out of range - can be from %d to %d \n", 0, 4);
		return -EINVAL;
	}
	}
	return 0;
}
static int kg_check_fill_params(const struct dpkg * dpkg,
								const struct dpkg_profile_cfg *cfg,
				struct dpkg_profiles_tmp *tmp_params)
{
	int 	i = 0;
	const struct 	dpkg_extract *extract;
	struct profile_tmp *extract_tmp;
	int err;
	uint8_t fec_format_size = 0;

	if (cfg->num_extracts > DPKG_MAX_NUM_OF_EXTRACTS)
	{
		pr_err("num_extracts can not exceed %d\n", DPKG_MAX_NUM_OF_EXTRACTS);
		return -EINVAL;
	}

	if (cfg->num_extracts == 0)
	{
		pr_err("num_extracts shouldn't be  %d\n", 0);
		return -EINVAL;
	}
	for (i = 0; i < cfg->num_extracts; i++) {
		extract = &cfg->extracts[i];
		extract_tmp = &tmp_params->prfl_tmp[i];
		err = fill_params(dpkg,extract,
					extract_tmp, &fec_format_size);
		if (err)
			return err;
		err = fill_mask_params(extract_tmp,
				extract->num_of_byte_masks,
				&fec_format_size);
		if (err)
			return err;
		if (fec_format_size >= 63)
		{
			pr_err("internal data structure size is greater than maximum"
					"try to remove extraction format\n");
			return -EINVAL;
		}

	}
//	fec_format_size+=1;
	return 0;
}


/**************************************************************************//**
 @Function     dpkg_restore
*//***************************************************************************/
#ifdef TKT011436 
int dpkg_restore(struct dpkg *dpkg)
{
	int i = 0, err = 0;
	struct dpkg_profile_regs *regs;
	
	pr_debug("DPKG restore\n");
/*	err = ctlu_get_mem_base(dpkg->ctlu, CTLU_DPKG, (void **)&dpkg->dpkg_regs_base);
	if(err)
	{
		fsl_free(dpkg);
		return -EINVAL;
	}*/

	regs = dpkg->dpkg_regs_base;
	/* clear memory mapped counters */
	for(i = 0; i < dpkg->num_profiles; i++)
	{
		iowrite32(0, &regs->iop_ckrhcnt);
		iowrite32(0, &regs->iop_ckcerr);
		regs++;
	}

	return err;

}
#endif /* TKT011436 */

/**************************************************************************//**
 @Function     dpkg_init
*//***************************************************************************/

struct dpkg *dpkg_init(struct dpkg_cfg *cfg)
{
	int i = 0, err = 0;
	struct dpkg *dpkg;
	struct dpkg_profile_regs *regs;

	dpkg = (struct dpkg *)fsl_malloc(
		        sizeof(struct dpkg));
	if (!dpkg) {
		pr_err("No memory for allocation dpkg internal data structure\n");
		return NULL;
	}
	memset(dpkg, 0, sizeof(struct dpkg));

	dpkg->num_profiles = cfg->num_profiles;
	dpkg->ctlu = cfg->ctlu;

	err = ctlu_get_mem_base(cfg->ctlu, CTLU_DPKG, (void **)&dpkg->dpkg_regs_base);
	if(err)
	{
		fsl_free(dpkg);
		return NULL;
	}

	regs = dpkg->dpkg_regs_base;
	/* clear memory mapped counters */
	for(i = 0; i < dpkg->num_profiles; i++)
	{
		iowrite32(0, &regs->iop_ckrhcnt);
		iowrite32(0, &regs->iop_ckcerr);
		regs++;
	}

	for(i = 0; i < NET_PROT_DUMMY_LAST; i++) {
		dpkg->prf_prot_info[i].protocol_based_offset =
					PR_UNKNOWN_OFFSET;
		dpkg->prf_prot_info[i].last_protocol_based_offset =
					PR_UNKNOWN_OFFSET;
	}

	fill_kg_prf_info_info(dpkg);


	return dpkg;

}
/**************************************************************************//**
 @Function     dpkg_done
*//***************************************************************************/
void dpkg_done(struct dpkg *dpkg)
{
	fsl_free(dpkg);
}

/**************************************************************************//**
 @Function     dpkg_profile_create
*//***************************************************************************/
/*all required LOCK are taken care in logical objects*/

int dpkg_profile_check_cfg(const struct dpkg * dpkg,
							const struct dpkg_profile_cfg *cfg)
{
	struct dpkg_profiles_tmp 	profiles_tmp;
	int 	err = 0;

	memset(&profiles_tmp, 0, sizeof(struct dpkg_profiles_tmp));

	err = kg_check_fill_params	(dpkg,cfg,
								&profiles_tmp);

	return err;

}
int 	dpkg_profile_create(const struct dpkg * dpkg,
							int profile_id,
							const struct dpkg_profile_cfg *cfg)
{
	uint8_t 			*ptr_in_msg, *ptr_out_msg;
	uint32_t 			*mtypein_addr, mtypeout;
	struct dpkg_profiles_tmp 	profiles_tmp;
	int 				err, err_tmp;
	void *cmd_cfg;
	uint16_t status;

	pr_debug("DPKG profile create with id =%d\n", profile_id);
	if (profile_id > dpkg->num_profiles)
	{
		pr_err("profile_id  = %d should be in the range from %d to %d\n",
				profile_id, 0, dpkg->num_profiles);
		return -EINVAL;
	}
	memset(&profiles_tmp, 0, sizeof(struct dpkg_profiles_tmp));

	err = kg_check_fill_params	(dpkg,cfg,
					&profiles_tmp);
	if (err)
		return err;


	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dpkg->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPKG_RULE_QUERY_SIZE);
	*mtypein_addr = (uint32_t)(profile_id << 16);
	err = ctlu_execute_cmd(dpkg->ctlu, NULL, cmd_cfg, /* interface handle */
	                       MNG_CMD_DPKG_RULE_QUERY,
	                       &status, &mtypeout,
	                        (void**)&ptr_out_msg);

	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	if(ptr_out_msg[0] != 0)
	{	pr_err("dpkg_profile_create was called but the dpkg_profile = %d "
				"with this profile_id was created earlier."
				"First delete and after it create\n",
				profile_id);
		err = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -EINVAL;
	}

	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPKG_RULE_CREATE_REPLACE_SIZE);
	build_kg_profile_create_message(ptr_in_msg, cfg, &profiles_tmp);
	*mtypein_addr = (uint32_t)(profile_id << 16);
	err = ctlu_execute_cmd(dpkg->ctlu, NULL, cmd_cfg, /* interface handle */
	                       MNG_CMD_DPKG_RULE_CREATE_REPLACE,
	                       &status, &mtypeout,
	                        (void**)&ptr_out_msg);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	ASSERT_COND(!status);

	err = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return 0;

}
int dpkg_debug_profile_create(const struct dpkg * dpkg,
								const struct dpkg_profile_cfg *cfg) {

	struct dpkg_profiles_tmp 	profiles_tmp;
	int 				err;
	uint8_t ptr[MNG_CMD_DPKG_RULE_CREATE_REPLACE_SIZE];

	memset(&profiles_tmp, 0, sizeof(struct dpkg_profiles_tmp));
	memset(&ptr, 0, sizeof(uint8_t) * MNG_CMD_DPKG_RULE_CREATE_REPLACE_SIZE);

	err = kg_check_fill_params	(dpkg,cfg,
					&profiles_tmp);
	if (err)
		return err;

	build_kg_profile_create_message(ptr, cfg, &profiles_tmp);

	ctlu_dpkg_global_profile_create(dpkg->ctlu, ptr);

	return 0;

}

int 	dpkg_profile_delete(const struct dpkg * dpkg,
							int profile_id)
{
	uint8_t 			*ptr_in_msg, *ptr_out_msg;
	uint32_t 			*mtypein_addr, mtypeout;
	int 				err, err_tmp;
	void *cmd_cfg;
	uint16_t status;


	if (profile_id > dpkg->num_profiles)
	{
		pr_err("profile_id  = %d should be in the range from %d to %d\n",
				profile_id, 0, dpkg->num_profiles);
		return -EINVAL;
	}

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dpkg->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPKG_RULE_QUERY_SIZE);
	*mtypein_addr = (uint32_t)(profile_id << 16);
	err = ctlu_execute_cmd(dpkg->ctlu, NULL, cmd_cfg, /* interface handle */
	                       MNG_CMD_DPKG_RULE_QUERY,
	                       &status, &mtypeout,
	                        (void**)&ptr_out_msg);

	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	if(ptr_out_msg[0] == 0)
	{	pr_err("user asked to delete dpkg_profile = %d  which wasn't "
			"created\n", profile_id);
		err = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -EINVAL;
	}

	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPKG_RULE_CREATE_REPLACE_SIZE);
	*mtypein_addr = (uint32_t)(profile_id << 16);
	err = ctlu_execute_cmd(dpkg->ctlu, NULL, cmd_cfg, /* interface handle */
	                       MNG_CMD_DPKG_RULE_CREATE_REPLACE,
	                       &status, &mtypeout,
	                        (void**)&ptr_out_msg);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	ASSERT_COND(!status);

	err = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return 0;
}

int 	dpkg_profile_modify	(const struct dpkg * dpkg,
							int profile_id,
							const struct dpkg_profile_cfg *cfg)
{
	uint8_t 			*ptr_in_msg, *ptr_out_msg;
	uint32_t 			*mtypein_addr, mtypeout;
	struct dpkg_profiles_tmp 	profiles_tmp;
	int 				err, err_tmp;
	void *cmd_cfg;
	uint16_t status;


	if (profile_id > dpkg->num_profiles)
	{
		pr_err("profile_id = %d is out of range."
				"should be in the range from %d to %d\n",
				profile_id, 0, dpkg->num_profiles);
		return -EINVAL;
	}
	memset(&profiles_tmp, 0, sizeof(struct dpkg_profiles_tmp));

	err = kg_check_fill_params	(dpkg,cfg,
					&profiles_tmp);
	if (err)
		return err;

	/* get a cmd_cfg handle and a pointer for the input message */
	err = ctlu_build_cmd_cfg(dpkg->ctlu,
	                             &cmd_cfg,
	                      	     (void*)&ptr_in_msg,
	                             &mtypein_addr);
	ASSERT_COND(!err);

	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPKG_RULE_QUERY_SIZE);
	*mtypein_addr = (uint32_t)(profile_id << 16);
	err = ctlu_execute_cmd(dpkg->ctlu, NULL, cmd_cfg, /* interface handle */
	                       MNG_CMD_DPKG_RULE_QUERY,
	                       &status, &mtypeout,
	                        (void**)&ptr_out_msg);

	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	if(ptr_out_msg[0] == 0)
	{	pr_err("dpkg_profile_modify was called but the dpkg_profile"
				"with this profile_id = %d wasn't created earlier."
				"First create and after that modify\n",
				profile_id);
		err = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
		ASSERT_COND(!err);
		return -ENAVAIL;
	}

	memset(ptr_in_msg, 0, sizeof(uint8_t) * MNG_CMD_DPKG_RULE_CREATE_REPLACE_SIZE);
	build_kg_profile_create_message(ptr_in_msg, cfg, &profiles_tmp);
	*mtypein_addr = (uint32_t)(profile_id << 16);
	err = ctlu_execute_cmd(dpkg->ctlu, NULL, cmd_cfg, /* interface handle */
	                       MNG_CMD_DPKG_RULE_CREATE_REPLACE,
	                       &status, &mtypeout,
	                        (void**)&ptr_out_msg);
	if (err) {
		err_tmp = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
		ASSERT_COND(!err_tmp);
		return err;
	}
	ASSERT_COND(!status);

	err = ctlu_free_cmd_cfg(dpkg->ctlu, cmd_cfg);
	ASSERT_COND(!err);

	return 0;

}

void dpkg_get_resource_str(const struct dpkg * dpkg, char *res_type)
{
	char str[16];
	
	ctlu_get_str(ctlu_get_iop_id(dpkg->ctlu),
			ctlu_get_type(dpkg->ctlu), str);
	
	snprintf(res_type, sizeof(str), "kp.%s", str);
}

int dpkg_read_extract_cfg_extention(struct dpkg_profile_cfg *extract_cfg,
	uint64_t *ext_params)
{
	int i, j;
	int offset = 0;
	int param = 1;

	extract_cfg->num_extracts = (uint8_t)u64_dec(
		swap_uint64(ext_params[0]), 0, 8);

	if (extract_cfg->num_extracts > DPKG_EXT_MAX_NUM_OF_EXTRACTS) {
		pr_err("num_extracts = %d. can not be larger then %d!\n", extract_cfg->num_extracts, DPKG_EXT_MAX_NUM_OF_EXTRACTS);
		return -EINVAL;
	}

	for (i = 0; i < extract_cfg->num_extracts; i++) {
		extract_cfg->extracts[i].type =
			(enum dpkg_extract_type)u64_dec(
				swap_uint64(ext_params[param + 1]), 32, 4);
		switch (extract_cfg->extracts[i].type) {
		case DPKG_EXTRACT_FROM_HDR:
			extract_cfg->extracts[i].extract.from_hdr.prot =
				(enum net_prot)u64_dec(
					swap_uint64(ext_params[param]), 0, 8);
			extract_cfg->extracts[i].extract.from_hdr.type =
				(enum dpkg_extract_from_hdr_type)u64_dec(
					swap_uint64(ext_params[param]), 8, 4);
			extract_cfg->extracts[i].extract.from_hdr.size =
				(uint8_t)u64_dec(
					swap_uint64(ext_params[param]), 16, 8);
			extract_cfg->extracts[i].extract.from_hdr.offset =
				(uint8_t)u64_dec(
					swap_uint64(ext_params[param]), 24, 8);
			extract_cfg->extracts[i].extract.from_hdr.field =
				(uint32_t)u64_dec(
					swap_uint64(ext_params[param]), 32,
					32);
			param++;
			extract_cfg->extracts[i].extract.from_hdr.hdr_index =
				(uint8_t)u64_dec(
					swap_uint64(ext_params[param]), 0, 8);
			break;
		case DPKG_EXTRACT_FROM_DATA:
			extract_cfg->extracts[i].extract.from_data.size =
				(uint8_t)u64_dec(
					swap_uint64(ext_params[param]), 16, 8);
			extract_cfg->extracts[i].extract.from_data.offset =
				(uint8_t)u64_dec(
					swap_uint64(ext_params[param]), 24, 8);
			param++;
			break;
		case DPKG_EXTRACT_FROM_CONTEXT:
			extract_cfg->extracts[i].extract.from_context.src =
				DPKG_FROM_PARSE_RESULT_SPECIFIC_PROTOCOL;
			extract_cfg->extracts[i].extract.from_context.size =
				(uint8_t)u64_dec(
					swap_uint64(ext_params[param]), 16, 8);
			extract_cfg->extracts[i].extract.from_context.offset =
				(uint8_t)u64_dec(
					swap_uint64(ext_params[param]), 24, 8);
			param++;
			break;
		default:
			return -EINVAL;
		}

		extract_cfg->extracts[i].num_of_byte_masks = (uint8_t)u64_dec(
			swap_uint64(ext_params[param]), 24, 8);
		if (extract_cfg->extracts[i].num_of_byte_masks
			> DPKG_NUM_OF_MASKS) {
			pr_err("num_of_byte_masks = %d. can not be larger then %d!\n", extract_cfg->extracts[i].num_of_byte_masks, DPKG_NUM_OF_MASKS);
			return -EINVAL;
		}

		param++;
		for (offset = 0, j = 0;
			j < extract_cfg->extracts[i].num_of_byte_masks;
			offset += 16, j++) {
			extract_cfg->extracts[i].masks[j].mask =
				(uint8_t)u64_dec(
					swap_uint64(ext_params[param]), offset,
					8);
			extract_cfg->extracts[i].masks[j].offset =
				(uint8_t)u64_dec(
					swap_uint64(ext_params[param]),
					offset + 8, 8);
		}
		param++;
	}

	return 0;
}

