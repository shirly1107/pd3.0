/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 @File          dpparser.h

 @Description   Parser Application Programming Interface.
 *//***************************************************************************/
#ifndef __DPPARSER_H
#define __DPPARSER_H

#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdint.h"
#include "fsl_dpparser.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_CTLU

/******************************************************/
/*********** Internal Header file *********************/
/******************************************************/

struct dpparser_profile_map {
	uint32_t start_hxs;
	uint16_t enet_hxs;
	uint16_t llc_snap_hxs;
	uint16_t vlan_hxs_base;
	uint16_t vlan_tpid1;
	uint16_t vlan_tpid2;
	uint16_t ppp_hxs;
	uint32_t mpls_hxs;
	uint16_t arp_hxs;
	uint16_t ip_hxs;
	uint16_t ipv4_hxs;
	uint16_t ipv6_hxs;
	uint16_t gre_hxs;
	uint16_t minenc_hxs;
	uint16_t other_l3_hxs;
	uint16_t tcp_hxs;
	uint16_t udp_hxs;
	uint16_t ipsec_hxs;
	uint16_t sctp_hxs;
	uint16_t dccp_hxs;
	uint16_t other_l4_hxs;
	uint16_t gtp_hxs;
	uint16_t esp_hxs;
	uint16_t vxlan_hxs;
	uint16_t l5_shell_hxs;
	uint16_t final_shell_hxs;
	uint32_t soft_seq_params[16];
} _packed;

/**************************************************************************//**
 @Description   Parser Management Command Input Parameters
 This structure is used to pass Management Command parameters
 *//***************************************************************************/
struct dpparser_msg {
	uint8_t				res1;
	uint8_t				mtype;
	uint8_t				res2;
	uint8_t				profile_id_h;
	uint8_t				profile_id;
	uint8_t				res3[3];
	struct dpparser_profile_map	dpparser_profile_map;
};

struct shadow_profile {
	int				used;
	struct dpparser_profile_map	*profile;
	/** soft parser profile attached to this HW profile */
	uint8_t sp_profile_id[MAX_SP_PROFILE_ID_SIZE];
	/** used if we need soft parser before HW parser */
	uint16_t start_hxs;
};

struct dpparser_ss_layout_entry {
	uint16_t			ss_offset;
	uint16_t			ss_size;
	uint8_t				param_offset;
	uint8_t				param_size;
};

struct dpparser_ss_layout {
	struct dpparser_ss_layout_entry	ss_entry[DPPARSER_MAX_SP];
};

struct dpparser {
	struct ctlu			*ctlu;
	int				num_profiles;
	struct shadow_profile		*shadow;
	uint16_t			min_pc;
	uint16_t			max_pc;
	uint8_t				ss_idx;
	struct dpparser_ss_layout	*ss_layout;
	int restore; /* Used at restore stage */
};

#define STARTING_HXS_MASK 		0x07FF
#define HXS_MPLS_DNP_MASK       0x03FF

#define HXS_DISABLE_ERR_REPORT	0x1000
#define HXS_PPP_EMC	     		0x2000
#define HXS_MPLS_LIE			0x1000
#define HXS_IPV6_RHE			0x2000
#define HXS_L4_SPPR			0x2000
#define HXS_EN_SOFT_SEQ			0x8000
#define HXS_EN_SOFT_SEQ_MASK		0x07FF

int dpparser_get_profile_map(struct dpparser *dpparser, int profile_id,
			     struct dpparser_profile_map **profile);

int dpparser_attach_default_soft_parser(struct dpparser *dpparser, int profile_id,
				      uint16_t *start_pc, uint8_t is_egress, const void *cmd_if_cfg);

int dpparser_is_valid_sp_profile_id(struct dpparser *dpparser, uint8_t sp_profile[]);

/*#define DUMP_PROFILE*/
#ifdef	DUMP_PROFILE
	void dump_profile(struct dpparser_profile_map *pr, int id,
			  const char *what);
#else
	#define dump_profile(_a, _b, _c)
#endif	/* DUMP_PROFILE */

#endif /* __DPPARSER_H */
