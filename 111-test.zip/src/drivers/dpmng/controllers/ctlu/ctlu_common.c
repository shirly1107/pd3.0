/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "fsl_gen.h"
#include "fsl_io.h"

#include "ctlu_common.h"

static void get_action_common(uint8_t *ptr, struct action_cfg *action) 
{
	struct action_common *ptr_msg = (struct action_common *)ptr;


	if (ptr_msg->info1 & ACTION_PLIDV)
		action->options |= ACTION_SET_POLICER_ID;
	
	if (ptr_msg->info1 & ACTION_QoSMMV)
		action->options|= ACTION_SET_QOS_MAP_METHOD;
	
	if (ptr_msg->info2 & ACTION_QPRIV) { 
		action->options |= ACTION_SET_QPRI;
		action->qpri = (int)((ptr_msg->info1 >> ACTION_QPRI_SHIFT)
						& (ACTION_MAX_NUM_OF_QPRIs - 1));
	}

	if (ptr_msg->info1 & ACTION_IFDIDV)
		action->options |= ACTION_SET_IFP_ID;

	if (ptr_msg->info2 & ACTION_HKIDV) {
		action->options |= ACTION_SET_HASH_KID;
		action->hash_dpkg_profile_id = (int)(ptr_msg->hkid);
	}
	
	if (ptr_msg->info2 & ACTION_DISCARDV) {
		if (ptr_msg->info1 & ACTION_DISCARD)
			action->options |= ACTION_SET_DISCARD_FLAG;
		else
			action->options |= ACTION_CLEAR_DISCARD_FLAG;
	}
			
}

static int fill_action_common (uint8_t *ptr, const struct action_cfg *action)
{
	struct action_common *ptr_msg = (struct action_common *)ptr;

	if (action->options & ACTION_SET_POLICER_ID) {
		ptr_msg->info1 |= ACTION_PLIDV;
		if (action->dppolicer_profile_id > ACTION_MAX_DPPOLICER_PROFILE_ID)
		{
			pr_err("dppolicer_profile_id = %d "
					"defined in action can not be larger %d\n", 
					action->dppolicer_profile_id,
					ACTION_MAX_DPPOLICER_PROFILE_ID);
			return -EINVAL;
		}
	}
	if (action->options & ACTION_SET_QOS_MAP_METHOD) {
		ptr_msg->info1 |= ACTION_QoSMMV;
	}
	if (action->options & ACTION_SET_QPRI) {
		ptr_msg->info2 |= ACTION_QPRIV;
		if (action->qpri > ACTION_MAX_NUM_OF_QPRIs)
		{
			pr_err("qpri = %d defined in action can not be larger %d\n", 
					action->qpri,ACTION_MAX_NUM_OF_QPRIs);
			return -EINVAL;
		}
		ptr_msg->info1 |= action->qpri << ACTION_QPRI_SHIFT;
	}
	if (action->options & ACTION_SET_IFP_ID)
	{
		ptr_msg->info1 |= ACTION_IFDIDV;
		if (action->ifp_id > ACTION_MAX_NUM_OF_IFP_IDs)
		{
			pr_err("ifp_id = %d defined in action can not be larger %d\n",
					action->ifp_id , ACTION_MAX_NUM_OF_IFP_IDs);
			return -EINVAL;
		}
	}

	if (action->options & ACTION_SET_HASH_KID) {
		ptr_msg->info2 |= ACTION_HKIDV;
		if (action->hash_dpkg_profile_id > ACTION_MAX_NUM_OF_DPKG_PROFILE_IDs)
		{
			pr_err("hash_dpkg_profile_id = %d defined in "
					"action can not be larger %d\n", 
					action->hash_dpkg_profile_id,
					ACTION_MAX_NUM_OF_DPKG_PROFILE_IDs);
			return -EINVAL;
		}
		ptr_msg->hkid = (uint8_t)action->hash_dpkg_profile_id;
	}

	if (action->options & ACTION_SET_QDID) {
		 ptr_msg->info2 |= ACTION_QDIDV_QDBINV;
		 if (action->qd_id > ACTION_MAX_NUM_OF_QD_IDs)
		 {
				pr_err("qd_id = %d defined in action can not be larger %d\n", 
						action->qd_id, ACTION_MAX_NUM_OF_QD_IDs);
				return -EINVAL;
		 }
		 ptr_msg->qdid = (uint16_t)action->qd_id;
	 }

	if (action->options & ACTION_SET_QDBIN) {
		 ptr_msg->info2 |= ACTION_QDIDV_QDBINV;
		 if (action->qd_bin > ACTION_MAX_NUM_OF_QD_BINs)
		 {
				pr_err("qd_bin = %d defined in action can not be "
						"larger %d\n", action->qd_bin,
						ACTION_MAX_NUM_OF_QD_BINs);
				return -EINVAL;
		 }
		 ptr_msg->qdid = (uint16_t)action->qd_bin;
	 }

	if (action->next_action == NEXT_ACTION_LOOKUP) {
		ptr_msg->info2 |= ACTION_TKIDV;
		if (action->dpkg_profile_id > ACTION_MAX_NUM_OF_DPKG_PROFILE_IDs)
		{
			pr_err("dpkg_profile_id = %d defined in action can not "
					"be larger %d\n", action->dpkg_profile_id,
					ACTION_MAX_NUM_OF_DPKG_PROFILE_IDs);
			return -EINVAL;
		}
		if (action->dptbl_id > ACTION_MAX_NUM_OF_DPTBL_IDs)
		{
			pr_err("dptbl_id = %d defined in action can not be larger %d\n", 
					action->dptbl_id,ACTION_MAX_NUM_OF_DPTBL_IDs);
			return -EINVAL;
		}
	}

	if (action->options & ACTION_SET_DISCARD_FLAG) {
		ptr_msg->info2 |= ACTION_DISCARDV;
		ptr_msg->info1 |= ACTION_DISCARD;
	}

	if (action->options & ACTION_CLEAR_DISCARD_FLAG) {
		ptr_msg->info2 |= ACTION_DISCARDV;
		ptr_msg->info1 &= ~ACTION_DISCARD;
	}

	if (action->options & ACTION_SET_REPLIC_ID) {
		if (action->replic_id > ACTION_MAX_NUM_OF_REPLIC_IDs)
		{
			pr_err("replic_id = %d defined in action can not be larger %d\n", 
					action->replic_id, ACTION_MAX_NUM_OF_REPLIC_IDs);
			return -EINVAL;
		}
	}

	return 0;
}

static void get_action_done(uint8_t *ptr, struct action_cfg *action)
{
	struct action_done *ptr_msg = (struct action_done *)ptr;
	
	action->dppolicer_profile_id = (int)(ptr_msg->plid);
	action->ifp_id = (int)(ptr_msg->ifpid & 0x0fff);
	action->qos_map_method = (enum qos_map_method)(ptr_msg->ifpid  & 0xc000);
	
	if (ptr_msg->action_common.info2 & ACTION_QDIDV_QDBINV) {
		if ((ptr_msg->action_common.info1 & ACTION_FCVTYPE_TO_GPP_QDBIN) 
				== ACTION_FCVTYPE_TO_GPP_QDBIN) {
			action->qd_bin = (int)(ptr_msg->action_common.qdid);
			action->options |= ACTION_SET_QDBIN;
		}
		else  {
			action->qd_id = (int)(ptr_msg->action_common.qdid);
			action->options |= ACTION_SET_QDID;
		}
	}
	
	if (!((ptr_msg->action_common.info2 & ACTION_DISCARDV) &&
		(ptr_msg->action_common.info1 & ACTION_DISCARD))) {
		memcpy(&action->opaque, &ptr_msg->gpp_opaque, sizeof(action->opaque));
		action->options |= ACTION_SET_OPAQUE;
	}
	
	if (ptr_msg->action_common.info1 & ACTION_SET_SC)
		action->options |= ACTION_SET_STASHING;
	
	if (ptr_msg->action_common.info1 & ACTION_SET_CBMT)
		action->options |= ACTION_SET_CONTEXT_IOMMU_BYPASS;

	action->next_action = NEXT_ACTION_DONE;
}

static void get_action_lookup(uint8_t *ptr, struct action_cfg *action)
{
	struct action_lookup *ptr_msg = (struct action_lookup *)ptr;

	if ((ptr_msg->action_common.info2 & ACTION_TKIDV) || 
			(ptr_msg->action_common.info1 & ACTION_FLCTYPV)) {
		action->next_action = NEXT_ACTION_LOOKUP;
	}
	else {
		action->next_action = NEXT_ACTION_DONE;
	}
	
	action->dppolicer_profile_id = (int)(ptr_msg->plid);
	action->ifp_id = (int)(ptr_msg->ifpid & 0x0fff);
	action->qos_map_method =(enum qos_map_method)(ptr_msg->ifpid & 0xc000);
	action->replic_id = (int)(ptr_msg->replic_id);
	action->dptbl_id = (int)(ptr_msg->tid);
	action->dpkg_profile_id = (int)(ptr_msg->kid);

	if (ptr_msg->action_common.info2 & ACTION_QDIDV_QDBINV) {
		action->qd_id = ptr_msg->action_common.qdid;
		action->options |= ACTION_SET_QDID;
	}
	
	if (ptr_msg->action_common.info1 & ACTION_FLCTYPV) {
		if (ptr_msg->action_common.info1 & ACTION_RPLIDV)
			action->options |= ACTION_SET_REPLIC_ID;
		if (ptr_msg->action_common.info1 & ACTION_FLC_TYPE_AIOP)
			action->options |= ACTION_SET_FLC_FOR_AIOP;
	}

	if (ptr_msg->action_common.info1 & ACTION_EPIDV) {
		action->options |= ACTION_SET_OPAQUE;
		action->opaque = (uint64_t)(ptr_msg->aiop_opaque[1] |
				((uint64_t)ptr_msg->aiop_opaque[0] << 8));
	}
	
			
}
void get_action(uint8_t *ptr, struct action_cfg *action)
{
	struct action_common *ptr_msg = (struct action_common *)ptr;

	if (ptr_msg->info1 & ACTTION_FCVTYPE_MASK)
		get_action_done(ptr, action);
	else
		get_action_lookup(ptr, action);
	
	get_action_common(ptr, action);
	
}
static int fill_action_done(uint8_t *ptr, const struct action_cfg *action)
{
	int err;
	struct action_done *ptr_msg = (struct action_done *)ptr;

	memset(ptr_msg, 0, sizeof(struct action_done));
	err = fill_action_common(ptr, action);
	if (err)
		return err;

	ptr_msg->plid = (uint16_t)action->dppolicer_profile_id;
	ptr_msg->ifpid = (uint16_t)action->ifp_id & 0x0fff;
	ptr_msg->ifpid |= (uint16_t)action->qos_map_method;

	if (action->options & ACTION_SET_OPAQUE) {
		memcpy (&ptr_msg->gpp_opaque, &action->opaque, sizeof(action->opaque));

		if (action->options & ACTION_SET_QDBIN )
			ptr_msg->action_common.info1 |= ACTION_FCVTYPE_TO_GPP_QDBIN;

		if (action->options & ACTION_SET_QDID )
			ptr_msg->action_common.info1 |= ACTION_FCVTYPE_TO_GPP_QDID;
	}

	if (action->options & ACTION_SET_STASHING)
		ptr_msg->action_common.info1 |= ACTION_SET_SC;

	if (action->options & ACTION_SET_CONTEXT_IOMMU_BYPASS)
		ptr_msg->action_common.info1 |= ACTION_SET_CBMT;

	return 0;
}

static int fill_action_lookup(uint8_t *ptr, const struct action_cfg *action)
{
	int err;
	struct action_lookup *ptr_msg = (struct action_lookup *)ptr;

	memset(ptr_msg, 0, sizeof(struct action_lookup));

	err = fill_action_common(ptr, action);
	if (err)
		return err;

	ptr_msg->plid 	= (uint16_t)action->dppolicer_profile_id;
	ptr_msg->ifpid 	= (uint16_t)action->ifp_id & 0x0fff;
	ptr_msg->ifpid 	|= (uint16_t)action->qos_map_method;
	ptr_msg->replic_id = (uint16_t)action->replic_id;
	ptr_msg->tid 	= (uint16_t)action->dptbl_id;
	ptr_msg->kid 	= (uint8_t)action->dpkg_profile_id;

	if (action->options & ACTION_SET_REPLIC_ID) {
		if(ptr_msg->replic_id) {
			ptr_msg->action_common.info1 |= ACTION_FLCTYPV;
			ptr_msg->action_common.info1 |= ACTION_RPLIDV;
		}
	}

	if (action->options & ACTION_SET_FLC_FOR_AIOP) {
		ptr_msg->action_common.info1 |= ACTION_FLCTYPV;
		ptr_msg->action_common.info1 |= ACTION_FLC_TYPE_AIOP;
	}

	if (action->options & ACTION_SET_OPAQUE) {
		ptr_msg->action_common.info1 |= ACTION_EPIDV;
		ptr_msg->aiop_opaque[0] = (uint8_t)(action->opaque >> 8);
		ptr_msg->aiop_opaque[1] = (uint8_t)action->opaque;
	}

	return 0;

}
static int action_check_cfg(const struct action_cfg *action)
{
	/* check action configuration */

	if ((action->options & ACTION_SET_QDBIN) &&
	((action->options & ACTION_SET_REPLIC_ID) ||
		(action->options & ACTION_SET_FLC_FOR_AIOP)))
	{
		pr_err("options  ACTION_SET_QDBIN and "
				"( ACTION_SET_REPLIC_ID ||ACTION_SET_FLC_FOR_AIOP"
				"can not be together\n");
		return -EINVAL;
	}
	if ((action->options & ACTION_SET_QDBIN) &&
			(action->options & ACTION_SET_QDID))
	{
		pr_err("options  ACTION_SET_QDBIN and "
				"ACTION_SET_QDID"
				"can not be together\n");
		return -EINVAL;
	}

	if ((action->options & ACTION_SET_QDBIN) &&
	(action->next_action == NEXT_ACTION_LOOKUP))
	{
		pr_err("options  ACTION_SET_QDBIN is allowed  "
				"only if next_action = ACTION_DONE\n");
		return -EINVAL;
	}
	if((action->options & ACTION_SET_HASH_KID) &&
			(action->options & ACTION_SET_QDBIN))
	{
		pr_err("options  ACTION_SET_HASH_KID can not be with  "
				"ACTION_SET_QDBIN\n");
		return -EINVAL;
	}

	if((action->next_action == NEXT_ACTION_LOOKUP) &&
			((action->options & ACTION_SET_STASHING ==
					ACTION_SET_STASHING) ||
			(action->options & ACTION_SET_CONTEXT_IOMMU_BYPASS ==
					ACTION_SET_CONTEXT_IOMMU_BYPASS)))
	{
		pr_err("if next_action = NEXT_ACTION_LOOKUP  "
				"can not be options set for ACTION_SET_STASHING ||"
				"ACTION_SET_CONTEXT_IOMMU_BYPASS\n");
		return -EINVAL;
	}

	return 0;
}

int fill_action(uint8_t *ptr, const struct action_cfg *action)
{
	int err;
	err = action_check_cfg(action);
	if (err)
		return err;
	if (((action->next_action == NEXT_ACTION_DONE) &&
		((action->options & ACTION_SET_OPAQUE) || 
		 (action->options & ACTION_SET_QDID)) &&
		!(action->options & ACTION_SET_REPLIC_ID) &&
		!(action->options & ACTION_SET_FLC_FOR_AIOP)) ||
		(action->options & ACTION_SET_QDBIN) ||
		(action->options & ACTION_SET_DISCARD_FLAG))
		return fill_action_done(ptr, action);
	else
		return fill_action_lookup(ptr, action);

}

#if 0 /* SHULAMIT ADDED */
int get_action(uint8_t *ptr, struct action_cfg *action)
{
	struct action_common *ptr_msg = (struct action_common *)ptr;

	if (ptr_msg->info1 & ACTION_RPLIDV)
	{
		action->options |= ACTION_SET_REPLIC_ID;
		action->replic_id = ((struct action_lookup *)ptr_msg)->replic_id;
	}
		 
	if (ptr_msg->info2 & ACTION_QDIDV_QDBINV)
	{
		action->options |= ACTION_SET_QDID;
		action->qd_id = ptr_msg->qdid;
	}
	return 0;
}
#endif /* SHULAMIT ADDED */
