/**
*   Copyright 2009-2015, Freescale Semiconductor, Inc.  All Rights Reserved.
*
*    NOTICE: The information contained in this file is proprietary
*    to Freescale Semiconductor and is being made available to
*    Freescale's customers under a specific license agreement.
*    Use or disclosure of this information is permissible only
*    under the terms of the license agreement.
*
*/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_cmdif.h"
#include "fsl_types.h"
#include "fsl_io.h"
#include "fsl_endian.h"
#include "fsl_gen.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_platform.h"
#include "regs.h"
#include "desc_constr.h"
#include "fsl_mem_mng.h"
#include "fsl_stdio.h"
#include "fsl_dbg.h"
#include "fsl_sec.h"

int caam_ctrl_init(void *ccsr_base, int coherency_mode);


#define   RNG4_MAX_HANDLES 2

#define GET_REG_FIELD(reg, fname) \
	(((reg) & (fname##_MASK)) >> (fname##_SHIFT))

#ifdef EMULATOR
#define RNG_INIT_DESC_SZ	(CAAM_CMD_SZ * 9)
#else
#define RNG_INIT_DESC_SZ	(CAAM_CMD_SZ * 7)
#endif

/*
 * Descriptor to instantiate RNG State Handle 0 in normal mode and
 * load the JDKEK, TDKEK and TDSK registers
 */
static int build_instantiation_desc(u32 *desc, int handle, int do_sk)
{
	u32 *jump_cmd, op_flags;

	init_job_desc(desc, 0);

	op_flags = (u32)(OP_TYPE_CLASS1_ALG | OP_ALG_ALGSEL_RNG |
			(handle << OP_ALG_AAI_SHIFT) | OP_ALG_AS_INIT |
			 OP_ALG_PR_ON);

#ifdef EMULATOR
	append_load_imm_u32(desc, 0, LDST_CLASS_1_CCB |
			    LDST_SRCDST_WORD_KEYSZ_REG | LDST_IMM);
	op_flags |= OP_ALG_RNG_TST;
#endif

	/* INIT RNG */
	append_operation(desc, op_flags);

	if (!handle && do_sk) {
		/*
		 * For SH0, Secure Keys must be generated as well
		 */

		/* wait for done */
		jump_cmd = append_jump(desc, JUMP_CLASS_CLASS1);
		set_jump_tgt_here(desc, jump_cmd);

		/*
		 * load 1 to clear written reg:
		 * resets the done interrrupt and returns the RNG to idle.
		 */
		append_load_imm_u32(desc, 1, LDST_SRCDST_WORD_CLRW);

		op_flags = OP_TYPE_CLASS1_ALG | OP_ALG_ALGSEL_RNG |
			   OP_ALG_AAI_RNG4_SK;

#ifdef EMULATOR
		op_flags |= OP_ALG_RNG_TST;
#endif

		/* Initialize State Handle  */
		append_operation(desc, op_flags);
	}

	append_jump(desc, JUMP_CLASS_CLASS1 | JUMP_TYPE_HALT);

	return 0;
}

/* Descriptor for deinstantiation of State Handle 0 of the RNG block. */
static void build_deinstantiation_desc(u32 *desc, int handle)
{
	init_job_desc(desc, 0);

	/* Uninstantiate State Handle 0 */
	append_operation(desc, OP_TYPE_CLASS1_ALG | OP_ALG_ALGSEL_RNG |
			 (handle << OP_ALG_AAI_SHIFT) | OP_ALG_AS_INITFINAL |
			 (uint32_t)OP_ALG_PR_OFF);

	append_jump(desc, JUMP_CLASS_CLASS1 | JUMP_TYPE_HALT);
}

/*
 * run_descriptor_deco0 - runs a descriptor on DECO0, under direct control of
 *			  the software (no JR/QI used).
 * @status - descriptor status, after being run
 *
 * Return: - 0 if no error occurred
 *	   - -ENODEV if the DECO couldn't be acquired
 *	   - -EAGAIN if an error occurred while executing the descriptor
 */
static int run_descriptor_deco0(void *ccsr_base, u32 *desc, u32 *status)
{
	struct caam_full *topregs;
	unsigned int timeout = 100000;
	u32 deco_dbg_reg, deco_state, flags;
	int i;
	u8 era;

	/* Set the bit to request direct access to DECO0 */
	topregs = (struct caam_full  *)ccsr_base;
	setbits32(&topregs->ctrl.deco_rq, DECORR_RQD0ENABLE);

	while (!(rd_reg32(&topregs->ctrl.deco_rq) & DECORR_DEN0) &&
								 --timeout) ;

	if (!timeout) {
		pr_err("failed to acquire DECO 0\n");
		clrbits32(&topregs->ctrl.deco_rq, DECORR_RQD0ENABLE);
		return -ENODEV;
	}

	for (i = 0; ((i < desc_len(desc)) && (i < 64)); i++)
		wr_reg32(&topregs->deco.descbuf[i], *(desc + i));

	flags = DECO_JQCR_WHL;
	/*
	 * If the descriptor length is longer than 4 words, then the
	 * FOUR bit in JRCTRL register must be set.
	 */
	if (desc_len(desc) >= 4)
		flags |= DECO_JQCR_FOUR;

	/* Instruct the DECO to execute it */
	wr_reg32(&topregs->deco.jr_ctl_hi, flags);

	era = (u8)GET_REG_FIELD(rd_reg32(&topregs->ctrl.perfmon.ccb_id),
				CCBVID_ERA);

	timeout = 10000000;
	do {
		deco_dbg_reg = rd_reg32(&topregs->deco.desc_dbg);

		if (era < 10) {
			deco_state = (deco_dbg_reg & DESC_DBG_DECO_STAT_MASK) >>
				     DESC_DBG_DECO_STAT_SHIFT;
		} else {
			deco_state = (rd_reg32(&topregs->deco.dbg_exec) &
				      DESC_DER_DECO_STAT_MASK) >>
				     DESC_DER_DECO_STAT_SHIFT;
		}

		/*
		 * If an error occured in the descriptor, then
		 * the DECO status field will be set to 0x0D
		 */
		if (deco_state == DECO_STAT_HOST_ERR)
			break;
	} while ((deco_dbg_reg & DESC_DBG_DECO_STAT_VALID) && --timeout);

	*status = rd_reg32(&topregs->deco.op_status_hi) &
		  DECO_OP_STATUS_HI_ERR_MASK;

	/* Mark the DECO as free */
	clrbits32(&topregs->ctrl.deco_rq, DECORR_RQD0ENABLE);

	if (!timeout)
		return -EAGAIN;

	return 0;
}

/*
 * deinstantiate_rng - builds and executes a descriptor on DECO0,
 *		       which deinitializes the RNG block.
 * @state_handle_mask - bitmask containing the instantiation status
 *			for the RNG4 state handles which exist in
 *			the RNG4 block: 1 if it's been instantiated
 *
 * Return: - 0 if no error occurred
 *	   - -ENOMEM if there isn't enough memory to allocate the descriptor
 *	   - -ENODEV if DECO0 couldn't be acquired
 *	   - -EAGAIN if an error occurred when executing the descriptor
 */
static int deinstantiate_rng(void *ccsr_base, int state_handle_mask)
{
	u32 *desc, status;
	int sh_idx, ret = 0;

	desc = kmalloc(CAAM_CMD_SZ * 3, GFP_KERNEL);
	if (!desc)
		return -ENOMEM;

	for (sh_idx = 0; sh_idx < RNG4_MAX_HANDLES; sh_idx++) {
		/*
		 * If the corresponding bit is set, then it means the state
		 * handle was initialized by us, and thus it needs to be
		 * deinitialized as well
		 */
		if ((1 << sh_idx) & state_handle_mask) {
			/*
			 * Create the descriptor for deinstantating this state
			 * handle
			 */
			build_deinstantiation_desc(desc, sh_idx);

			/* Try to run it through DECO0 */
			ret = run_descriptor_deco0(ccsr_base, desc, &status);

			if (ret ||
			    (status && status != JRSTA_SSRC_JUMP_HALT_CC)) {
				pr_err("Failed to deinstantiate RNG4 SH%d\n",
					sh_idx);
				break;
			}
			pr_info("Deinstantiated RNG4 SH%d\n", sh_idx);
		}
	}

	kfree(desc);

	return ret;
}

/*
 * instantiate_rng - builds and executes a descriptor on DECO0,
 *		     which initializes the RNG block.
 * @state_handle_mask - bitmask containing the instantiation status
 *			for the RNG4 state handles which exist in
 *			the RNG4 block: 1 if it's been instantiated
 *			by an external entry, 0 otherwise.
 * @gen_sk  - generate data to be loaded into the JDKEK, TDKEK and TDSK;
 *	      Caution: this can be done only once; if the keys need to be
 *	      regenerated, a POR is required
 *
 * Return: - 0 if no error occurred
 *	   - -ENOMEM if there isn't enough memory to allocate the descriptor
 *	   - -ENODEV if DECO0 couldn't be acquired
 *	   - -EAGAIN if an error occurred when executing the descriptor
 *	      f.i. there was a RNG hardware error due to not "good enough"
 *	      entropy being aquired.
 */
static int instantiate_rng(void *ccsr_base, int state_handle_mask, int gen_sk)
{
	struct caam_full *topregs;
	u32 *desc, status = 0, rdsta_val;
	int ret = 0, sh_idx;

	topregs = (struct caam_full *)ccsr_base;

	desc = kmalloc(RNG_INIT_DESC_SZ, GFP_KERNEL);
	if (!desc)
		return -ENOMEM;


	for (sh_idx = 0; sh_idx < RNG4_MAX_HANDLES; sh_idx++) {
		/*
		 * If the corresponding bit is set, this state handle
		 * was initialized by somebody else, so it's left alone.
		 */
		if ((RDSTA_IF0 << sh_idx) & state_handle_mask) {
			if ((RDSTA_PR0 << sh_idx) & state_handle_mask) {
				continue;
			} else {
				pr_info("RNG4 SH%d instantiated without prediction resistance\n",
					 sh_idx);
				/* Deinstantiate it for proper instantiation. */
				ret = deinstantiate_rng(ccsr_base, (RDSTA_IF0 << sh_idx));
				if (ret)
					break;
			}
		}

		/* Create the descriptor for instantiating RNG State Handle */
		build_instantiation_desc(desc, sh_idx, gen_sk);

		/* Try to run it through DECO0 */
		ret = run_descriptor_deco0(ccsr_base, desc, &status);

		/*
		 * If ret is not 0, or descriptor status is not 0, then
		 * something went wrong. No need to try the next state
		 * handle (if available), bail out here.
		 * Also, if for some reason, the State Handle didn't get
		 * instantiated although the descriptor has finished
		 * without any error (HW optimizations for later
		 * CAAM eras), then try again.
		 */
#ifdef EMULATOR
		rdsta_val = rd_reg32(&topregs->ctrl.r4tst[0].rdsta);
		rdsta_val = ((rdsta_val & RDSTA_TFMASK) >> RDSTA_TFSHIFT) |
			    (rdsta_val & RDSTA_PRMASK);
#else
		rdsta_val = rd_reg32(&topregs->ctrl.r4tst[0].rdsta) &
			    (RDSTA_PRMASK | RDSTA_IFMASK);
#endif
		if ((status && status != JRSTA_SSRC_JUMP_HALT_CC) ||
		    !(rdsta_val & (RDSTA_IF0 << sh_idx)) ||
		    !(rdsta_val & (RDSTA_PR0 << sh_idx))) {
			pr_info("RNG: handle %d init failed with status %08x, RDSTA %08x\n",
				sh_idx, status, rdsta_val);
			ret = -EAGAIN;
		}
		if (ret)
			break;

		pr_debug( "Instantiated RNG4 SH%d\n", sh_idx);
		/* Clear the contents before recreating the descriptor */
		memset(desc, 0x00, RNG_INIT_DESC_SZ);
	}

	kfree(desc);

	return ret;
}

/*
 * kick_trng - sets the various parameters for enabling the initialization
 *	       of the RNG4 block in CAAM
 * @pdev - pointer to the platform device
 * @ent_delay - Defines the length (in system clocks) of each entropy sample.
 */
static void kick_trng(void *ccsr_base, int ent_delay)
{
	struct caam_full *topregs;
	struct rng4tst *r4tst;
	u32 val;

	topregs = (struct caam_full *)ccsr_base;
	r4tst = &topregs->ctrl.r4tst[0];

	/* Put RNG4 into program mode and set TRNG access mode
	 * to invalidate the entropy from the entropy register.
	 */
	setbits32(&r4tst->rtmctl, RTMCTL_PRGM | RTMCTL_ACC);

	/*
	 * Performance-wise, it does not make sense to
	 * set the delay to a value that is lower
	 * than the last one that worked (i.e. the state handles
	 * were instantiated properly. Thus, instead of wasting
	 * time trying to set the values controlling the sample
	 * frequency, the function simply returns.
	 */
	val = (rd_reg32(&r4tst->rtsdctl) & RTSDCTL_ENT_DLY_MASK)
	      >> RTSDCTL_ENT_DLY_SHIFT;
	if (ent_delay <= val) {
		/* put RNG4 into run mode */
		clrbits32(&r4tst->rtmctl, RTMCTL_PRGM | RTMCTL_ACC);
		return;
	}

	val = rd_reg32(&r4tst->rtsdctl);
	val = (val & ~RTSDCTL_ENT_DLY_MASK) |
	      (ent_delay << RTSDCTL_ENT_DLY_SHIFT);
	wr_reg32(&r4tst->rtsdctl, val);
	/* min. freq. count, equal to 1/4 of the entropy sample length */
	wr_reg32(&r4tst->rtfrqmin, (u32)ent_delay >> 2);
	/* disable maximum frequency count */
	wr_reg32(&r4tst->rtfrqmax, RTFRQMAX_DISABLE);
	/* put RNG4 into run mode */
	clrbits32(&r4tst->rtmctl, RTMCTL_PRGM | RTMCTL_ACC);
}

/* Initialize the CAAM top (controller) level */
int caam_ctrl_init(void *ccsr_base, int coherency_mode)
{
	struct caam_ctrl  *ctrl;
	struct caam_full  *topregs;
	int ret, gen_sk, ent_delay = RTSDCTL_ENT_DLY_MIN;
	u32 rng_vid, comp_parms_ms, rng4_sh_init;
	u8 era;

	/* First, get register page */
	ctrl = (struct caam_ctrl *)ccsr_base;

	/* topregs used to derive pointers to CAAM sub-blocks only */
	topregs = (struct caam_full *)ctrl;

	u32 mcr = rd_reg32(&topregs->ctrl.mcr);	
	/* Configure PS = 1 in MCR, we may have some configuration parameter also
	 * which tells us whether to configure this or not */
	mcr |= MCFGR_WDENABLE | MCFGR_LONG_PTR | MCFGR_LARGE_BURST;
	
	/* Set CAAM transactions to be cache coherent by setting MCR's
	 * ARCACHE - 4'b0110 (Read Allocate, Cacheable) and
	 * AWCACHE - 4'b1011 (Write Allocate, Cacheable, Bufferable) */
	if (coherency_mode == SEC_COHERENCY_MODE_REV1) {
		mcr = (mcr & ~MCFGR_ARCACHE_MASK) | MCFGR_ARCACHE_RA |
			MCFGR_ARCACHE_CACHEABLE;
		mcr = (mcr & ~MCFGR_AWCACHE_MASK) | MCFGR_AWCACHE_WA |
			MCFGR_AWCACHE_CACHEABLE | MCFGR_AWCACHE_BUFFERABLE;	
	}
	wr_reg32(&topregs->ctrl.mcr, mcr);

	comp_parms_ms = rd_reg32(&topregs->ctrl.perfmon.comp_parms_ms);

	/* Check to see if QI present. If so, enable */
	if (comp_parms_ms & CTPR_MS_QI_MASK) {
		pr_debug("QI is present. Enable it\n");
		/* This is all that's required to physically enable QI */
		wr_reg32(&topregs->qi.qi_control_lo, QICTL_DQEN);
	}

	/* Check to see if AIOP is present. If so, enable */
	if (comp_parms_ms & CTPR_MS_AI_MASK) {
		pr_debug("AI is present. Enable it\n");
		wr_reg32(&topregs->aiop.aictl, AICTL_DQEN);
	}

	era = (uint8_t)GET_REG_FIELD(rd_reg32(&ctrl->perfmon.ccb_id),
				     CCBVID_ERA);
	if (era < 10)
		rng_vid = GET_REG_FIELD(rd_reg32(&ctrl->perfmon.cha_id_ls),
					CHA_ID_LS_RNG);
	else
		rng_vid = GET_REG_FIELD(rd_reg32(&ctrl->vreg.rng), CHA_VER_VID);

	/*
	 * If SEC has RNG version >= 4 and RNG state handle has not been
	 * already instantiated, do RNG instantiation
	 */
	if (rng_vid >= 4) {
#ifndef EMULATOR
		pr_debug("Instantiating RNG\n");
#else
		pr_debug("Instantiating RNG, not tested on emulator\n");
#endif
		rng4_sh_init =
			rd_reg32(&topregs->ctrl.r4tst[0].rdsta);
		/*
		 * If the secure keys (TDKEK, JDKEK, TDSK), were already
		 * generated, signal this to the function that is instantiating
		 * the state handles. An error would occur if RNG4 attempts
		 * to regenerate these keys before the next POR.
		 */
		gen_sk = rng4_sh_init & RDSTA_SKVN ? 0 : 1;
		rng4_sh_init &= RDSTA_IFMASK;
		do {
			int inst_handles =
				(int)(rd_reg32(&topregs->ctrl.r4tst[0].rdsta) &
						(RDSTA_PRMASK | RDSTA_IFMASK));
#ifndef EMULATOR
			/*
			 * If either SH were instantiated by somebody else
			 * (e.g. u-boot) then it is assumed that the entropy
			 * parameters are properly set and thus the function
			 * setting these (kick_trng(...)) is skipped.
			 * Also, if a handle was instantiated, do not change
			 * the TRNG parameters.
			 */
			if (!(rng4_sh_init || inst_handles)) {
				kick_trng(ccsr_base, ent_delay);
				ent_delay += 400;
			}
#endif
			/*
			 * if instantiate_rng(...) fails, the loop will rerun
			 * and the kick_trng(...) function will modfiy the
			 * upper and lower limits of the entropy sampling
			 * interval, leading to a sucessful initialization of
			 * the RNG.
			 */
			ret = instantiate_rng(ccsr_base, inst_handles,
					      gen_sk);
			if (ret == -EAGAIN)
				pr_debug("RNG: init failed, rtmctl: %08x, rtstatus: %08x\n",
					 rd_reg32(&topregs->ctrl.r4tst[0].rtmctl),
					 rd_reg32(&topregs->ctrl.r4tst[0].rtstatus));
#ifdef EMULATOR
			break;
#endif
			if( IS_SIM ) break;
		} while ((ret == -EAGAIN) && (ent_delay < RTSDCTL_ENT_DLY_MAX));
		if (ret) {
			if( IS_SIM ) ret = 0;
			pr_err("RNG instantiation FAILED\n");
			return ret;
		} else
			pr_debug("RNG instantiated\n");

		/* Enable RDB bit so that RNG works faster */
		setbits32(&topregs->ctrl.scfgr, SCFGR_RDBENABLE);

	}

	pr_debug("Exiting\n");
	return 0;
}

int caam_get_attributes(struct sec_desc *desc, struct caam_attr *attr)
{
	struct caam_ctrl *ctrl = (struct caam_ctrl *)desc->vaddr;
	uint32_t tmp;

	tmp = rd_reg32(&ctrl->perfmon.sec_vid_ms);
	attr->ip_id = (uint16_t)GET_REG_FIELD(tmp, SECVID_MS_IP_ID);
	attr->major_rev = (uint8_t)GET_REG_FIELD(tmp, SECVID_MS_MAJ_REV);
	attr->minor_rev = (uint8_t)GET_REG_FIELD(tmp, SECVID_MS_MIN_REV);

	attr->era = (uint8_t)GET_REG_FIELD(rd_reg32(&ctrl->perfmon.ccb_id),
					   CCBVID_ERA);

	if (attr->era < 10) {
		tmp = rd_reg32(&ctrl->perfmon.cha_num_ms);
		attr->crc_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_NUM_MS_CRC);
		attr->snow_f9_acc_num =
			(uint8_t)GET_REG_FIELD(tmp, CHA_NUM_MS_SNW9);
		attr->zuc_enc_acc_num =
			(uint8_t)GET_REG_FIELD(tmp, CHA_NUM_MS_ZE);
		attr->zuc_auth_acc_num =
			(uint8_t)GET_REG_FIELD(tmp, CHA_NUM_MS_ZA);
		attr->deco_num = (uint8_t)GET_REG_FIELD(tmp, CHA_NUM_MS_DECO);

		tmp = rd_reg32(&ctrl->perfmon.cha_num_ls);
		attr->aes_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_NUM_LS_AES);
		attr->des_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_NUM_LS_DES);
		attr->arc4_acc_num =
			(uint8_t)GET_REG_FIELD(tmp,  CHA_NUM_LS_ARC4);
		attr->md_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_NUM_LS_MD);
		attr->rng_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_NUM_LS_RNG);
		attr->snow_f8_acc_num =
			(uint8_t)GET_REG_FIELD(tmp, CHA_NUM_LS_SNW8);
		attr->kasumi_acc_num =
			(uint8_t)GET_REG_FIELD(tmp, CHA_NUM_LS_KAS);
		attr->pk_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_NUM_LS_PK);

		attr->ccha_acc_num = 0;
		attr->ptha_acc_num = 0;
	} else {
		tmp = rd_reg32(&ctrl->vreg.crca);
		attr->crc_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.snw9a);
		attr->snow_f9_acc_num =
			(uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.zuce);
		attr->zuc_enc_acc_num =
			(uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.zuca);
		attr->zuc_auth_acc_num =
			(uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.deco);
		attr->deco_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.aesa);
		attr->aes_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.desa);
		attr->des_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.afha);
		attr->arc4_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.mdha);
		attr->md_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.rng);
		attr->rng_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.snw8a);
		attr->snow_f8_acc_num =
			(uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.kfha);
		attr->kasumi_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.pkha);
		attr->pk_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.ccha);
		attr->ccha_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);

		tmp = rd_reg32(&ctrl->vreg.ptha);
		attr->ptha_acc_num = (uint8_t)GET_REG_FIELD(tmp, CHA_VER_NUM);
	}

	return 0;
}

int caam_get_counters(struct sec_desc *desc, struct caam_counters *ctr)
{
	struct caam_ctrl *ctrl = (struct caam_ctrl *)desc->vaddr;

	ctr->dequeued_requests = rd_reg64(&ctrl->perfmon.req_dequeued);
	ctr->ob_enc_requests = rd_reg64(&ctrl->perfmon.ob_enc_req);
	ctr->ib_dec_requests = rd_reg64(&ctrl->perfmon.ib_dec_req);
	ctr->ob_enc_bytes = rd_reg64(&ctrl->perfmon.ob_enc_bytes);
	ctr->ob_prot_bytes = rd_reg64(&ctrl->perfmon.ob_prot_bytes);
	ctr->ib_dec_bytes = rd_reg64(&ctrl->perfmon.ib_dec_bytes);
	ctr->ib_valid_bytes = rd_reg64(&ctrl->perfmon.ib_valid_bytes);

	return 0;
}

