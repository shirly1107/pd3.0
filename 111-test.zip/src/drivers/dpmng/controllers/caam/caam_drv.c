/*
 * Copyright 2013-2020 NXP
 */

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_cmdif.h"
#include "fsl_types.h"
#include "fsl_io.h"
#include "fsl_gen.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_platform.h"
#include "fsl_sec.h"
#include "fsl_dbg.h"

extern int caam_ctrl_init(void *ccsr_base, int coherency_mode);

int caam_drv_init(void);

int caam_drv_init(void)
{
	struct sec_desc desc;
	int ret, iter = 0;

	pr_info("Executing caam_drv_init...\n");

	/**************************/
	/* Set up the CAAM CTRL block */
	/**************************/
	ret = sys_get_desc(SOC_MODULE_SEC, 0, &desc, &iter);
	if (ret)
		return ret;

	pr_info("CAAM CCSR: 0x%08x%08x\n",UINT32_HI(desc.paddr), UINT32_LO(desc.paddr));

	return caam_ctrl_init(desc.vaddr, desc.coherency_mode);
}
