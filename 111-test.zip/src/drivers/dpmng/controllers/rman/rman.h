/*
 * Copyright 2012 Freescale Semiconductor, Inc.
 */

#ifndef __FL_RMAN_H
#define __FL_RMAN_H

#include "common/general.h"


/* misc */
#define MMIER_ENABLE_ALL	0x800000ff
#define MMEDR_CLEAR		0x800000ff

/*
 * The magic is a workaround for mailbox transaction.
 * The MMSEPR0 setting assigns AG0 to only execute on SU0
 * AG1 on SU1, AG2 on SU2, AG3 on SU3.
 */
#define MMSEPR0_MAILBOX 0x010234f8
#define MMSEPR0_DEFAULT 0x030f3fff

/* IP CFG */
#define IP_CFG_IB_SHIFT 6
#define IP_CFG_RC_SHIFT 4
#define IP_CFG_RU_SHIFT 3

#define IP_CFG_IB_MASK 0x3
#define IP_CFG_RC_MASK 0x3
#define IP_CFG_RU_MASK 0x1
#define IP_CFG_SG_MASK 0x3

/* shifts */
#define IBCU_MMMR_MDD_SHIFT	31
#define IBCU_MMMR_OSID_SHIFT	28

/* frame queue assembly */
#define IBCU_FQAR_SID_SHIFT	16
#define IBCU_FQAR_PORT_SHIFT	4
#define IBCU_FQAR_COS_SHIFT	12
#define IBCU_FQAR_STREAM_SHIFT	7
#define IBCU_FQAR_XMB_SHIFT	12
#define IBCU_FQAR_MB_SHIFT	10
#define IBCU_FQAR_LTR_SHIFT	8

#define IBCU_MR_CUE_SHIFT	31
#define IBCU_MR_FQM_SHIFT	28
#define IBCU_MR_FTYPE_SHIFT	24

#define IBCU_RVR_SID_SHIFT	16
#define IBCU_RVR_FLOWLVL_SHIFT	28
#define IBCU_RVR_PORT_SHIFT	24
#define IBCU_RMR_SID_SHIFT	16
#define IBCU_RMR_FCM_SHIFT	28
#define IBCU_RMR_PORT_SHIFT	24

#define IBCU_DBPR_SIZE_SHIFT	16

/* data streaming */
#define IBCU_MR_EXT_SHIFT	23
#define IBCU_RVR_COS_SHIFT	16
#define IBCU_RMR_COS_SHIFT	16
#define IBCU_SGBPR_SIZE_SHIFT	16

/* mailbox */
#define IBCU_RVR_MSGLEN_SHIFT	8
#define IBCU_RVR_LTR_SHIFT	6
#define IBCU_RVR_XMBOX_SHIFT	2
#define IBCU_RMR_MSGLEN_SHIFT	8
#define IBCU_RMR_LTR_SHIFT	6
#define IBCU_RMR_XMBOX_SHIFT	2

/* Inbound Block TypeX Classification Registers */
struct rman_ibcu_regs {
	uint32_t mr;		/* 0xmn00 - Mode Register */
	uint8_t  reserved0[4];
	uint32_t fqr;		/* 0xmn08 - Frame Queue Register */
	uint8_t  reserved1[4];
	uint32_t rvr[2];	/* 0xmn10 - Rule Value Register 0/1 */
	uint32_t rmr[2];	/* 0xmn18 - Rule Mask Register 0/1 */
	uint32_t t9fcdr;	/* 0xmn20 -
				   Type9 Flow Control Destination Register */
	uint8_t  reserved2[12];
	uint32_t dbpr;		/* 0xmn30 - Data Buffer Pool Register */
	uint32_t dor;		/* 0xmn34 - Data Offset Register */
	uint32_t t9sgbpr;	/* 0xmn38 -
				   Type9 Scatter/Gather Buffer Poll Register */
};

struct rman_global_regs {
	uint8_t  reserved0[248];	/* 0x1e_0B00 - beginning of regs*/
	uint32_t ipbrr[2];	/* 0x1e_0BFB - IP block revision register 0/1 */
	uint8_t  reserved1[768];
	uint32_t mmmr;		/* 0x1e_0F00 - Message manager Mode Register */
	uint32_t mmsr;		/* 0x1e_0F04 -
				   Message manager Status Register */
	uint8_t  reserved2[8];
	uint32_t mmt8fqar;	/* 0x1e_0F10 - Message manager
				   T8 Frame Queue Assembly Register */
	uint32_t mmt9fqar;	/* 0x1e_0F14 - Message manager
				   T9 Frame Queue Assembly Register */
	uint32_t mmt10fqar;	/* 0x1e_0F18 - Message manager
				   T10 Frame Queue Assembly Register */
	uint32_t mmt11fqar;	/* 0x1e_0F1c - Message manager
				   T11 Frame Queue Assembly Register */
	uint32_t mmier;		/* 0x1e_0F20 - Message manager
				   Interrupt Enable Register */
	uint32_t mmedr;		/* 0x1e_0F24 - Message manager
				   Error Detect Register */
	uint32_t mmicr;		/* 0x1e_0F28 - Message manager
				   Interrupt Coalescing Registers */
	uint32_t mmt8dcr;	/* 0x1e_0F2C - Message manager
				   T8 Drop Counter Register */
	uint32_t mmt9dcr;	/* 0x1e_0F30 - Message manager
				   T9 Drop Counter Register */
	uint32_t mmecqfqr;	/* 0x1e_0F34 - Message manager
				   Error Capture Frame Queue Register */
	uint32_t mmecfdr[4];	/* 0x1e_0F38 - Message manager
				   Error Capture FD Register 0/1/2/3 */
	uint32_t mmecar[2];	/* 0x1e_0F48 - Message manager
				   Error Capture Address Register 0/1 */
	uint32_t mmawr;		/* 0x1e_0F50 - Message manager
				   Arbitration Weight Register */
	uint32_t mmiomr;	/* 0x1e_0F54 - Message manager
				   Outbound Interleaving Mask Register */
	uint8_t  reserved3[12];
	uint32_t mmliodnbr;	/* 0x1e_0F64 - Message manager
				   logical I/O device number base Register */
	uint32_t mmitar;	/* 0x1e_0F68- Message manager
				   Inbound Translation Address Register*/
	uint32_t mmitdr;	/* 0x1e_0F6c- Message manager
				   Inbound Translation Data Register*/
	uint32_t mmsepr0;	/* 0x1e_0F70- Message Unit Segmentation
				   Execution Privilege Register 0 */
	uint8_t  reserved4[12];
	uint32_t mmrcar[3];	/* 0x1e_0F80- Message manager
				   Reassembly Context Assignment Register */
	uint8_t  reserved5[84];
	uint32_t mmsmr;		/* 0x1e_0FE0- Message manager
				   support mode register */
};

enum RIO_TYPE {
	RIO_TYPE0 = 0,
	RIO_TYPE1,
	RIO_TYPE2,
	RIO_TYPE3,
	RIO_TYPE4,
	RIO_TYPE5,
	RIO_TYPE6,
	RIO_TYPE7,
	RIO_TYPE8,
	RIO_TYPE9,
	RIO_TYPE10,
	RIO_TYPE11,
	RIO_TYPE_NUM,
	RIO_TYPE_DSTR = RIO_TYPE9,
	RIO_TYPE_DBELL = RIO_TYPE10,
	RIO_TYPE_MBOX = RIO_TYPE11
};

enum RMAN_FQ_MODE {
	DIRECT_FQID,
	ALGORITHMIC_FQID
};

enum RMAN_MD_MODE {
	CREATE_MD,
	NON_MD
};

struct rio_tran {
	uint8_t type;
	uint8_t flowlvl;
	uint8_t fcm;
	union {
		struct mbox_attr {
			uint8_t mbox;
			uint8_t mbox_mask;
			uint8_t ltr;
			uint8_t ltr_mask;
			uint8_t msglen;
			uint8_t msglen_mask;
		} mbox;

		struct dstr_attr {
			uint16_t streamid;
			uint16_t streamid_mask;
			uint8_t cos;
			uint8_t cos_mask;
		} dstr;
	};
};

struct ibcu_cfg {
	uint8_t  port;
	uint8_t  port_mask;
	uint16_t sid;
	uint16_t sid_mask;
	uint16_t did;
	uint16_t did_mask;
	uint32_t fqid;
	uint8_t  bpid;
	uint8_t  sgbpid;
	uint32_t msgsize;
	uint32_t sgsize;
	uint32_t data_offset;
	enum RMAN_FQ_MODE fq_mode;
	struct rio_tran *tran;
};

struct rman_cfg {
	uint8_t fq_bits[RIO_TYPE_NUM];
	enum RMAN_MD_MODE md_create;
};

/**
 * rman_ibcu_disable() - Stop ibcu receiving messages.
 *
 * @ibcu:	The virtual base address of the desired ibcu register space.
 */
void rman_ibcu_disable(struct rman_ibcu_regs *ibcu);

/**
 * rman_ibcu_enable() - Configure and enable ibcu according to the
 *		specified configuration.
 *
 * @ibcu:	The virtual base address of the desired ibcu register space.
 * @cfg:	The pointer to structure ibcu configuration
 * @return:	0 if successful, otherwise errno
 */
int rman_ibcu_enable(struct rman_ibcu_regs *ibcu, const struct ibcu_cfg *cfg);

/**
 * rman_init() - Initialize rman global attributes according to the rman
 *		configuration.
 *
 * @rman:	The virtual base address of the rman global register space.
 * @cfg:	The pointer to structure rman configuration
 * @return:	0 if successful, otherwise errno
 */
int rman_init(struct rman_global_regs *rman, const struct rman_cfg *cfg);

/**
 * rman_set_dstr_fqsr() - Set frame queue ID assembly rule which queue rman
 *		will enqueue data-streaming frame to.
 *
 * @rman:	The virtual base address of the rman global register space.
 * @sidbits:	The number of sid bits to include from the mask field
 *		specified in IBmT9CnRMR0[SID]. If the assembly count
 *		is greater than the number of consecutive mask bits, zeros
 *		are concatenated to the result. If the value is less, the
 *		result is truncated.
 * @cosbits:	The number of cos(class of service) bits to include
 *		from the corresponding mask field
 * @streamidbits:	The number of stream ID bits to include from
 *		the corresponding mask  filed
 */
void rman_set_dstr_fqsr(struct rman_global_regs *rman,
			int sidbits, int cosbits, int streamidbits);

/**
 * rman_set_mbox_fqsr() - Set frame queue ID assembly rule which queue rman
 *		will enqueue data-streaming frame to.
 *
 * @rman:	The virtual base address of the rman global register space.
 * @sidbits:	The number of sid(source ID) bits to include
 *		from the corresponding mask field.
 * @mbbits:	The number of mailbox bits to include
 *		from the corresponding mask field.
 * @ltrbits:		The number of letter bits to include
 *		from the corresponding mask field.
 */
void rman_set_mbox_fqsr(struct rman_global_regs *rman,
			int sidbits, int mbbits, int ltrbits);

/**
 * rman_create_md() - Set message descriptor creation mode yes or not.
 *
 * @rman:	The virtual base address of the rman global register space.
 * @create_flag: If 1 rman creates the md, otherwise dose not create md.
 */
void rman_create_md(struct rman_global_regs *rman, int create_flag);

/**
 * rman_get_ib_num() - Get the number of inbound blocks.
 *
 * @rman:	The virtual base address of the rman global register space.
 * @return:	The number of inbound blocks
 */
int rman_get_ib_num(struct rman_global_regs *rman);

/**
 * rman_get_ib_num() - Enable the mailbox workaround.
 *
 * @rman:	The virtual base address of the rman global register space.
 */
void rman_set_mbox_workaround(struct rman_global_regs *rman);

/**
 * rman_enable_interrupt() - Enable the interrupt.
 *
 * @rman:	The virtual base address of the rman global register space.
 */
void rman_enable_interrupt(struct rman_global_regs *rman);

/**
 * rman_disable_interrupt() - Disable the interrupt.
 *
 * @rman:	The virtual base address of the rman global register space.
 */
void rman_disable_interrupt(struct rman_global_regs *rman);

/**
 * rman_clear_interrupt() - Clear the interrupt status register.
 *
 * @rman:	The virtual base address of the rman global register space.
 */
void rman_clear_interrupt(struct rman_global_regs *rman);

/**
 * rman_dev_reset() - Reset rman device.
 *
 * @rman:	The virtual base address of the rman global register space.
 */
void rman_dev_reset(struct rman_global_regs *rman);

#endif /* FL_RMAN_H */

