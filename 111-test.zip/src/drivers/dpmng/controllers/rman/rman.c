/*
 * Copyright 2012 Freescale Semiconductor, Inc.
 */

#include "rman.h"


/************************* ibcu handler ***************************/
void rman_ibcu_disable(struct rman_ibcu_regs *ibcu)
{
	uint32_t value;

	value = ioread32be(&ibcu->mr);
	value = value & (~(1 << IBCU_MR_CUE_SHIFT));
	iowrite32be(value, &ibcu->mr);
}

int rman_ibcu_enable(struct rman_ibcu_regs *ibcu, const struct ibcu_cfg *cfg)
{
	const struct rio_tran *tran = cfg->tran;

	/* Set frame queue id */
	iowrite32be(cfg->fqid, &ibcu->fqr);

	/* Set classification rule 0 - source ID and destination ID */
	iowrite32be(cfg->sid << IBCU_RVR_SID_SHIFT | cfg->did,
		    &ibcu->rvr[0]);

	/* Set rule 0 mask - source ID mask and destination ID mask */
	iowrite32be(cfg->sid_mask << IBCU_RMR_SID_SHIFT | cfg->did_mask,
		    &ibcu->rmr[0]);

	/* Set buffer pool ID and size which used to store packets */
	iowrite32be(cfg->msgsize << IBCU_DBPR_SIZE_SHIFT |
		    cfg->bpid,
		    &ibcu->dbpr);

	/* Set data offset */
	iowrite32be(cfg->data_offset, &ibcu->dor);

	/* Set classification rule 1 and mask - transaction header field */
	switch (tran->type) {
	case RIO_TYPE_DBELL:
		iowrite32be(tran->flowlvl << IBCU_RVR_FLOWLVL_SHIFT |
			    cfg->port << IBCU_RVR_PORT_SHIFT,
			    &ibcu->rvr[1]);
		iowrite32be(tran->fcm << IBCU_RMR_FCM_SHIFT |
			    cfg->port_mask << IBCU_RMR_PORT_SHIFT,
			    &ibcu->rmr[1]);
		break;
	case RIO_TYPE_MBOX:
		iowrite32be(tran->flowlvl << IBCU_RVR_FLOWLVL_SHIFT |
			    cfg->port << IBCU_RVR_PORT_SHIFT |
			    tran->mbox.msglen << IBCU_RVR_MSGLEN_SHIFT |
			    tran->mbox.ltr << IBCU_RVR_LTR_SHIFT |
			    tran->mbox.mbox,
			    &ibcu->rvr[1]);
		iowrite32be(tran->fcm << IBCU_RMR_FCM_SHIFT |
			    cfg->port_mask << IBCU_RMR_PORT_SHIFT |
			    tran->mbox.msglen_mask << IBCU_RMR_MSGLEN_SHIFT |
			    tran->mbox.ltr_mask << IBCU_RMR_LTR_SHIFT |
			    tran->mbox.mbox_mask,
			    &ibcu->rmr[1]);
		break;
	case RIO_TYPE_DSTR:
		iowrite32be(tran->flowlvl << IBCU_RVR_FLOWLVL_SHIFT |
			    cfg->port << IBCU_RVR_PORT_SHIFT |
			    tran->dstr.cos << IBCU_RVR_COS_SHIFT |
			    tran->dstr.streamid,
			    &ibcu->rvr[1]);
		iowrite32be(tran->fcm << IBCU_RMR_FCM_SHIFT |
			    cfg->port_mask << IBCU_RMR_PORT_SHIFT |
			    tran->dstr.cos_mask << IBCU_RMR_COS_SHIFT |
			    tran->dstr.streamid_mask,
			    &ibcu->rmr[1]);
		iowrite32be(cfg->sgsize << IBCU_SGBPR_SIZE_SHIFT |
			    cfg->sgbpid,
			    &ibcu->t9sgbpr);
		break;
	default:
		return -EINVAL;
	}

	/* Enable classification unit with transaction type and fq mode */
	iowrite32be(1 << IBCU_MR_CUE_SHIFT |
		    cfg->fq_mode << IBCU_MR_FQM_SHIFT |
		    tran->type << IBCU_MR_FTYPE_SHIFT,
		    &ibcu->mr);
	return 0;
}

void rman_set_dstr_fqsr(struct rman_global_regs *rman,
			int sidbits, int cosbits, int streamidbits)
{
	iowrite32be(sidbits << IBCU_FQAR_SID_SHIFT |
		    cosbits << IBCU_FQAR_COS_SHIFT |
		    streamidbits << IBCU_FQAR_STREAM_SHIFT,
		    &rman->mmt9fqar);
}

void rman_set_mbox_fqsr(struct rman_global_regs *rman,
			int sidbits, int mbbits, int ltrbits)
{
	iowrite32be(sidbits << IBCU_FQAR_SID_SHIFT |
		    mbbits << IBCU_FQAR_MB_SHIFT |
		    ltrbits << IBCU_FQAR_LTR_SHIFT,
		    &rman->mmt11fqar);
}

void rman_create_md(struct rman_global_regs *rman, int create_flag)
{
	uint32_t value;

	value = ioread32be(&rman->mmmr);
	value = (value & ~(1 << IBCU_MMMR_MDD_SHIFT)) |
		(create_flag << IBCU_MMMR_MDD_SHIFT);
	iowrite32be(value, &rman->mmmr);
}

void rman_enable_interrupt(struct rman_global_regs *rman)
{
	iowrite32be(MMIER_ENABLE_ALL, &rman->mmier);
}

void rman_disable_interrupt(struct rman_global_regs *rman)
{
	iowrite32be(0, &rman->mmier);
}

void rman_clear_interrupt(struct rman_global_regs *rman)
{
	iowrite32be(MMEDR_CLEAR, &rman->mmedr);
}

int rman_get_ib_num(struct rman_global_regs *rman)
{
	uint32_t ip_cfg;

	ip_cfg = ioread32be(&rman->ipbrr[1]);
	return 2 << (((ip_cfg >> IP_CFG_IB_SHIFT) & IP_CFG_IB_MASK) + 1);
}

void rman_set_mbox_workaround(struct rman_global_regs *rman)
{
	iowrite32be(MMSEPR0_MAILBOX, &rman->mmsepr0);
}

int rman_init(struct rman_global_regs *rman, const struct rman_cfg *cfg)
{
	/* Set inbound message descriptor write status */
	rman_create_md(rman, cfg->md_create);

	/* Clear and enable Error Interrupt */
	rman_clear_interrupt(rman);
	rman_enable_interrupt(rman);

	/* Initialize the frame queue assembly register */
	rman_set_mbox_fqsr(rman, 0, 0, cfg->fq_bits[RIO_TYPE_MBOX]);
	rman_set_dstr_fqsr(rman, 0, 0, cfg->fq_bits[RIO_TYPE_DSTR]);

	/* Set MMSEPR0 default value to avoid mailbox workaround impact */
	iowrite32be(MMSEPR0_DEFAULT, &rman->mmsepr0);
	return 0;
}

void rman_reset(struct rman_global_regs *rman)
{
	iowrite32be(1, &rman->mmmr);
}
