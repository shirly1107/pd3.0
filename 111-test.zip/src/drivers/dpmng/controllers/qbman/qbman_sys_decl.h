/*
 * Copyright 2013-2020 NXP
 */

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_malloc.h"
#include "fsl_types.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_dbg.h"

	/*********************************/
	/* Linux interface compatibility */
	/*********************************/

#include "drivers/fsl_qbman_base.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_QBMAN

#define kmalloc(a,b) fsl_malloc(a)
#define kfree(a) fsl_free(a)
#define get_free_page(a) (unsigned long)fsl_xmalloc(4*1024, 0, 4*1024)
#define free_page(a) fsl_xfree((void *)a)

#if defined(CORE_IS_BIG_ENDIAN)
#define __BIG_ENDIAN
#elif defined(CORE_IS_LITTLE_ENDIAN)
#define __LITTLE_ENDIAN
#else
#error "No endianness?"
#endif

/* Linux's BUG_ON() is the opposite of MC's ASSERT_COND() */
#define BUG_ON(_cond) ASSERT_COND(!(_cond))

#define likely(x)   __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)

#define __stringify_1(x) #x
#define __stringify(x)  __stringify_1(x)

/* The maximum number of times to poll in a read loop */
#define MAX_TRYS 100000

static inline unsigned int ilog2(uint32_t x)
{
	unsigned int e = 31;
	uint32_t mask = (uint32_t)1 << e;
	do {
		if (x & mask)
			return e;
		e--;
		mask >>= 1;
	} while (mask);
	ASSERT_COND(0);
	return (unsigned int)-1;
}

#define upper32(a) (uint32_t)((uint64_t)(a) >> 32)
#define lower32(a) (uint32_t)(a)

	/****************/
	/* arch assists */
	/****************/

static inline void dcbz(void *ptr)
{
	uint32_t *p = ptr;
	BUG_ON((unsigned long)ptr & 63);
	p[0] = p[1] = p[2] = p[3] = p[4] = p[5] = p[6] = p[7] = p[8] = p[9] =
		p[10] = p[11] = p[12] = p[13] = p[14] = p[15] = 0;
}

#define lwsync() do { ; } while (0)

/* The platform-independent code shouldn't need endianness, except for
 * weird/fast-path cases like qbman_result_has_token(), which needs to
 * perform a passive and endianness-specific test on a read-only data structure
 * very quickly. It's an exception, and this symbol is used for that case. */
#if defined(__BIG_ENDIAN)
#define DQRR_TOK_OFFSET 0
#define FQRN_TOK_OFFSET 0
#define QBMAN_RESULT_VERB_OFFSET_IN_MEM 24
#define SCN_STATE_OFFSET_IN_MEM 8
#define SCN_RID_OFFSET_IN_MEM 8
#else
#define DQRR_TOK_OFFSET 24
#define FQRN_TOK_OFFSET 24
#define QBMAN_RESULT_VERB_OFFSET_IN_MEM 0
#define SCN_STATE_OFFSET_IN_MEM 16
#define SCN_RID_OFFSET_IN_MEM 0
#endif
