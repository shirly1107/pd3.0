/*
 * Copyright 2013-2020 NXP
 */

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_malloc.h"
#include "fsl_types.h"
#include "fsl_io.h"

/* qbman_sys_decl.h and qbman_sys.h are the two platform-specific files in the
 * driver. They are only included via qbman_private.h, which is itself a
 * platform-independent file and is included by all the other driver source.
 *
 * qbman_sys_decl.h is included prior to all other declarations and logic, and
 * it exists to provide compatibility with any linux interfaces our
 * single-source driver code is dependent on (eg. kmalloc). Ie. this file
 * provides linux compatibility.
 *
 * This qbman_sys.h header, on the other hand, is included *after* any common
 * and platform-neutral declarations and logic in qbman_private.h, and exists to
 * implement any platform-specific logic of the qbman driver itself. Ie. it is
 * *not* to provide linux compatibility.
 */

/* Trace the 3 different classes of read/write access to QBMan. #undef as
 * required. */
//#define QBMAN_CCSR_TRACE
//#define QBMAN_CINH_TRACE
//#define QBMAN_CENA_TRACE

/* When using QBMan's "MC access registers", we need to choose which set
 * according to the MC core. This function is a place-holder for the routine
 * that returns the index of the core the code is executing on. TODO: when MC
 * goes SMP, hook this up to the proper "current cpu" API. */
static inline unsigned int current_cpu(void)
{
	return core_get_id();
}

static inline void word_copy(void *d, const void *s, unsigned int cnt)
{
	uint32_t *dd = d;
	const uint32_t *ss = s;
	while (cnt--)
		*(dd++) = *(ss++);
}

/* Currently, the CENA support code expects each 32-bit word to be written in
 * host order, and these are converted to hardware (little-endian) order on
 * command submission. However, 64-bit quantities are must be written (and read)
 * as two 32-bit words with the least-significant word first, irrespective of
 * host endianness. */
static inline void u64_to_le32_copy(void *d, const uint64_t *s, unsigned int cnt)
{
	uint32_t *dd = d;
	const uint32_t *ss = (const uint32_t *)s;
	while (cnt--) {
		/* TBD: the toolchain was choking on the use of 64-bit types up
		 * until recently so this works entirely with 32-bit variables.
		 * When 64-bit types become usable again, investigate better
		 * ways of doing this. */
#if defined(__BIG_ENDIAN)
		*(dd++) = ss[1];
		*(dd++) = ss[0];
		ss += 2;
#else
		*(dd++) = *(ss++);
		*(dd++) = *(ss++);
#endif
	}
}
static inline void u64_from_le32_copy(uint64_t *d, const void *s, unsigned int cnt)
{
	const uint32_t *ss = s;
	uint32_t *dd = (uint32_t *)d;
	while (cnt--) {
#if defined(__BIG_ENDIAN)
		dd[1] = *(ss++);
		dd[0] = *(ss++);
		dd += 2;
#else
		*(dd++) = *(ss++);
		*(dd++) = *(ss++);
#endif
	}
}

/* Convert a host-native 32bit value into little endian */
#if defined(__BIG_ENDIAN)
static inline uint32_t make_le32(uint32_t val)
{
	return (((val & 0xff) << 24) | ((val & 0xff00) << 8) |
		((val & 0xff0000) >> 8) | ((val & 0xff000000) >> 24));
}
static inline uint32_t make_le24(uint32_t val)
{
	return (((val & 0xff) << 16) | (val & 0xff00) |
		((val & 0xff0000) >> 16));
}
#else
#define make_le32(val) (val)
#define make_le24(val) (val)
#endif
static inline void make_le32_n(uint32_t *val, unsigned int num)
{
	while (num--) {
		*val = make_le32(*val);
		val++;
	}
}

	/***************/
	/* CCSR access */
	/***************/

static inline void qbman_ccsr_write(void *ccsr, uint32_t offset, uint32_t val)
{
#ifdef QBMAN_CCSR_TRACE
	pr_info("qbman_ccsr_write(%p:0x%03x) 0x%08x\n", ccsr, offset, val);
#endif
	iowrite32(val, PTR_MOVE(ccsr, offset));
}
static inline uint32_t qbman_ccsr_read(void *ccsr, uint32_t offset)
{
	uint32_t reg = ioread32(PTR_MOVE(ccsr, offset));
#ifdef QBMAN_CCSR_TRACE
	pr_info("qbman_ccsr_read(%p:0x%03x) 0x%08x\n", ccsr, offset, reg);
#endif
	return reg;
}

	/**************************/
	/* Portal access via CCSR */
	/**************************/

/* The CCSR "access registers" are special, as they aren't used by qbman_ctrl,
 * unlike all the other CCSR use comes from. So use of them is declared locally
 * here. Note that we use current_cpu() to pick which set of registers we are
 * accessing. */
#define QBMAN_CCSR_ACCESS_CMD     (0x0e0 + (current_cpu() * 0x04))
#define QBMAN_CCSR_ACCESS_DATA(n) (0x100 + (current_cpu() * 0x40) + ((n) * 0x04))

struct qbman_swp_sys {
	/* On MC, the sys support for qbman_swp is here. The CENA region is not
	 * an mmap() of the real portal registers, but an allocated
	 * place-holder, because the actual writes/reads to/from the portal are
	 * marshalled from these allocated areas using QBMan's "MC access
	 * registers". CINH accesses are atomic so there's no need for a
	 * place-holder. */
	void *cena;
	void *ccsr_reg_bar;
	uint32_t idx;
};

/* P_OFFSET is (ACCESS_CMD,0,12) - offset within the portal
 * C is (ACCESS_CMD,12,1) - is inhibited? (0==CENA, 1==CINH)
 * SWP_IDX is (ACCESS_CMD,16,10) - Software portal index
 * T is (ACCESS_CMD,29,1) - Command type (0==READ, 1==WRITE)
 * E is (ACCESS_CMD,31,1) - Command execute (1 to issue, poll for 0==complete)
 */

static inline int qbman_cinh_write(struct qbman_swp_sys *s, uint32_t offset,
				    uint32_t val)
{
	/*uint32_t reg = e32_uint32_t(0, 12, offset) | e32_int(12, 1, 1) |
		e32_uint32_t(16, 10, s->idx) | e32_int(29, 1, 1) |
		e32_int(31, 1, 1); */
	int loopvar = MAX_TRYS;
	uint32_t reg = e32_uint32_t(0, 12, offset);
		reg|= e32_int(12, 1, 1);
		reg |=	e32_uint32_t(16, 10, s->idx);
		reg |= e32_int(29, 1, 1);
		reg |=e32_int(31, 1, 1);

	#ifdef QBMAN_CINH_TRACE
	pr_info("qbman_cinh_write(%p:%d:0x%03x) 0x%08x\n",
		s->ccsr_reg_bar, s->idx, offset, val);
#endif
	qbman_ccsr_write(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_DATA(0), val);
	qbman_ccsr_write(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_CMD, reg);
	do {
		if (loopvar-- < 1)
			return -EIO;
		reg = qbman_ccsr_read(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_CMD);
	} while (d32_int(31, 1, reg));
	return 0;
}

static inline uint32_t qbman_cinh_read(struct qbman_swp_sys *s, uint32_t offset)
{
/*	uint32_t reg = e32_uint32_t(0, 12, offset) | e32_int(12, 1, 1) |
		e32_uint32_t(16, 10, s->idx) | e32_int(29, 1, 0) |
		e32_int(31, 1, 1);*/
	int loopvar = MAX_TRYS;
	uint32_t reg = e32_uint32_t(0, 12, offset);
	reg|= e32_int(12, 1, 1);
	reg |=	e32_uint32_t(16, 10, s->idx);
	reg |= e32_int(29, 1, 0);
	reg |=	e32_int(31, 1, 1);

	qbman_ccsr_write(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_CMD, reg);
	do {
		if (loopvar-- < 1) {
			pr_err("QMAN CINH access failed\n");
			return 0;
		}
		reg = qbman_ccsr_read(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_CMD);
	} while (d32_int(31, 1, reg));
	reg = qbman_ccsr_read(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_DATA(0));
#ifdef QBMAN_CINH_TRACE
	pr_info("qbman_cinh_read(%p:%d:0x%03x) 0x%08x\n",
		s->ccsr_reg_bar, s->idx, offset, reg);
#endif
	return reg;
}

static inline void *qbman_cena_write_start(struct qbman_swp_sys *s, uint32_t offset)
{
	void *shadow = PTR_MOVE(s->cena, offset);
#ifdef QBMAN_CENA_TRACE
	pr_info("qbman_cena_write_start(%p:%d:0x%03x) %p\n",
		s->ccsr_reg_bar, s->idx, offset, shadow);
#endif
	BUG_ON(offset & 63);
	dcbz(shadow);
	return shadow;
}

static inline int qbman_cena_write_complete(struct qbman_swp_sys *s, uint32_t offset,
					     void *cmd)
{
	const uint32_t *shadow = cmd;
	/*uint32_t reg = e32_uint32_t(0, 12, offset) | e32_int(12, 1, 0) |
		e32_uint32_t(16, 10, s->idx) | e32_int(29, 1, 1) |
		e32_int(31, 1, 1); */
	unsigned int loop;
	int loopvar = MAX_TRYS;
	uint32_t reg = e32_uint32_t(0, 12, offset);
	reg|= e32_int(12, 1, 0);
	reg|=	e32_uint32_t(16, 10, s->idx);
	reg|= e32_int(29, 1, 1);
	reg|=e32_int(31, 1, 1);

#ifdef QBMAN_CENA_TRACE
	pr_info("qbman_cena_write_complete(%p:%d:0x%03x) %p\n",
		s->ccsr_reg_bar, s->idx, offset, shadow);
	hexdump(cmd, 64);
#endif
	/* Copy 64 bytes to the 16 32-bit registers */
	for (loop = 0; loop < 16; loop++)
		qbman_ccsr_write(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_DATA(loop),
				 shadow[loop]);
	qbman_ccsr_write(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_CMD, reg);
	do {
		if (loopvar-- < 1)
			return -EIO;
		reg = qbman_ccsr_read(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_CMD);
	} while (d32_int(31, 1, reg));
	return 0;
}

static inline void *qbman_cena_read(struct qbman_swp_sys *s, uint32_t offset)
{
	uint32_t *shadow = PTR_MOVE(s->cena, offset);
/*	uint32_t reg = e32_uint32_t(0, 12, offset) | e32_int(12, 1, 0) |
		e32_uint32_t(16, 10, s->idx) | e32_int(29, 1, 0) |
		e32_int(31, 1, 1);*/
	unsigned int loop;
	int loopvar = MAX_TRYS;
	uint32_t reg = e32_uint32_t(0, 12, offset);
	reg|= e32_int(12, 1, 0);
	reg|=e32_uint32_t(16, 10, s->idx);
		reg|= e32_int(29, 1, 0);
	reg|=e32_int(31, 1, 1);

#ifdef QBMAN_CENA_TRACE
	pr_info("qbman_cena_read(%p:%d:0x%03x) %p\n",
		s->ccsr_reg_bar, s->idx, offset, shadow);
#endif
	qbman_ccsr_write(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_CMD, reg);
	do {
		if (loopvar-- < 1) {
			pr_err("QMAN CENA access failed\n");
			return NULL;
		}
		reg = qbman_ccsr_read(s->ccsr_reg_bar, QBMAN_CCSR_ACCESS_CMD);
	} while (d32_int(31, 1, reg));
	/* Copy 64 bytes out of the 16 32-bit registers */
	for (loop = 0; loop < 16; loop++)
		shadow[loop] = qbman_ccsr_read(s->ccsr_reg_bar,
					       QBMAN_CCSR_ACCESS_DATA(loop));
#ifdef QBMAN_CENA_TRACE
	hexdump(shadow, 64);
#endif
	return shadow;
}

static inline void qbman_cena_invalidate_prefetch(struct qbman_swp_sys *s,
						  uint32_t offset)
{
}

	/******************/
	/* Portal support */
	/******************/

/* The SWP_CFG portal register is special, in that it is used by the
 * platform-specific code rather than the platform-independent code in
 * qbman_portal.c. So use of it is declared locally here. */
#define QBMAN_CINH_SWP_CFG   0xd00

/* For MC portal use, we always configure with
 * DQRR_MF is (SWP_CFG,20,3) - DQRR max fill (<- 0x4)
 * EST is (SWP_CFG,16,3) - EQCR_CI stashing threshold (<- 0x0)
 * RPM is (SWP_CFG,12,2) - RCR production notification mode (<- 0x3)
 * DCM is (SWP_CFG,10,2) - DQRR consumption notification mode (<- 0x2)
 * EPM is (SWP_CFG,8,2) - EQCR production notification mode (<- 0x3)
 * SD is (SWP_CFG,5,1) - memory stashing drop enable (<- FALSE)
 * SP is (SWP_CFG,4,1) - memory stashing priority (<- TRUE)
 * SE is (SWP_CFG,3,1) - memory stashing enable (<- 0x0)
 * DP is (SWP_CFG,2,1) - dequeue stashing priority (<- TRUE)
 * DE is (SWP_CFG,1,1) - dequeue stashing enable (<- 0x0)
 * EP is (SWP_CFG,0,1) - EQCR_CI stashing priority (<- FALSE)
 */
#define MC_SWP_CFG \
	(e32_uint8_t(20, (uint32_t)(3 + (dqrr_size >> 3)), dqrr_size) | \
	e32_uint8_t(16, 3, 0) | e32_uint8_t(12, 2, 0x3) | \
	e32_uint8_t(10, 2, 0x2) | e32_uint8_t(8, 2, 0x3) | e32_int(5, 1, 0) | \
	e32_int(4, 1, 1) | e32_int(3, 1, 0) | e32_int(2, 1, 1) | \
	e32_int(1, 1, 0) | e32_int(0, 1, 0))

static inline int qbman_swp_sys_init(struct qbman_swp_sys *s,
				     const struct qbman_swp_desc *d,
				     uint8_t dqrr_size)
{
#ifdef QBMAN_CHECKING
	uint32_t reg;
#endif
	s->ccsr_reg_bar = d->block->ccsr_reg_bar;
	s->idx = (uint32_t)d->idx;
	s->cena =fsl_xmalloc(0x1000, 0, 0x1000);
	if (!s->cena)
		return -ENOMEM;
	BUG_ON(d->idx < 0);
#ifdef QBMAN_CHECKING
	/* We should never be asked to initialise for a portal that isn't in the
	 * power-on state. (Ie. don't forget to reset portals when they are
	 * decommissioned!)
	 */
	reg = qbman_cinh_read(s, QBMAN_CINH_SWP_CFG);
	BUG_ON(reg);
#endif
	qbman_cinh_write(s, QBMAN_CINH_SWP_CFG, MC_SWP_CFG);
	return 0;
}

#ifdef MC_CLI
#ifdef QMAN_4_1
        #define DQRR_MF_FIELD 4
        #define DQRR_MF_VALUE 0x8
#else
        #define DQRR_MF_FIELD 3
        #define DQRR_MF_VALUE 0x4
#endif

#ifdef DISABLE_EQCR_CI_STASHING
    #define EST 0
#else
    #define EST 0x2
#endif

#ifdef DISABLE_DQRR_DATA_STASHING
    #define SE_BIT 0
#else
    #define SE_BIT 1
#endif

#ifdef DISABLE_DQRR_ENTRY_STASHING
    #define DE_BIT 0
#else
    #define DE_BIT 1
#endif

#define MC_SWP_CFG_GPP \
       (e32_uint8_t(20, DQRR_MF_FIELD, DQRR_MF_VALUE) | e32_uint8_t(16, 3, EST)   |  \
       e32_uint8_t(12, 2, 0x3) | e32_uint8_t(10, 2, 0x2) | e32_uint8_t(8, 2, 0x2) |  \
       e32_int(5, 1, 0) | e32_int(4, 1, 0) | e32_int(3, 1, SE_BIT ) | e32_int(2, 1, 0) | \
       e32_int(1, 1,DE_BIT) | e32_int(0, 1, 0))

static inline int qbman_swp_sys_init_gpp(struct qbman_swp_sys *s,
                                    const struct qbman_swp_desc *d)
{
       uint32_t reg;
       s->ccsr_reg_bar = d->block->ccsr_reg_bar;
       s->idx = (uint32_t)d->idx;
       s->cena =fsl_xmalloc(0x1000, 0, 0x1000);
       if (!s->cena)
               return -ENOMEM;
       BUG_ON(d->idx < 0);
#ifdef QBMAN_CHECKING
       /* We should never be asked to initialise for a portal that isn't in the
        * power-on state. (Ie. don't forget to reset portals when they are
        * decommissioned!)
        */
       reg = qbman_cinh_read(s, QBMAN_CINH_SWP_CFG);
#endif
       reg = MC_SWP_CFG_GPP;
       qbman_cinh_write(s, QBMAN_CINH_SWP_CFG, reg);
       return 0;
}
#endif

static inline void qbman_swp_sys_finish(struct qbman_swp_sys *s)
{
	fsl_xfree(s->cena);
}
