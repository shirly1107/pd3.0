/*
 * Copyright 2013-2020 NXP
 */

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_cmdif.h"
#include "fsl_types.h"
#include "fsl_io.h"
#include "fsl_gen.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_platform.h"
#include "fsl_qbman.h"
#include "fsl_dpmng_mc.h"
#include "fsl_mpic.h"
#include "dpc.h"
#include "fsl_timer.h"
#include "fsl_tasklet.h"

#include "drivers/fsl_qbman_ctrl.h"
#include "drivers/fsl_qbman_portal.h"
#include "drivers/fsl_qbman_portal_ex.h"
#include "qbman_private.h"

#include "fsl_resman.h"

/*************/
/* Debugging */
/*************/

/* When things go wrong, it is a convenient trick to insert a few FOO()
 * statements in the code to trace progress. */
#define FOO() pr_info("FOO: %s:%d\n", __FILE__, __LINE__)

/***********************/
/* Linux-like routines */
/***********************/

#define upper32(a) (uint32_t)((uint64_t)(a) >> 32)
#define lower32(a) (uint32_t)(a)

/***************************/
/* Support for test builds */
/***************************/

/* When QBMAN_TEST is defined, we will deliberately hide some primitve
 * resources from the resource manager so that MC-based and GPP-based test
 * cases can run without interference from "regular users".
 */
#ifdef QBMAN_TEST
#define QBMAN_TEST_QD
#define QBMAN_FIRST_8CH 4
#define QBMAN_FIRST_BPID 20
#define QBMAN_FIRST_SWP 5
#define QBMAN_FIRST_FQID 20
#define QBMAN_FIRST_QPRID 20
#define QBMAN_FIRST_QDID 20
#define QBMAN_FIRST_CGID 20
#define QBMAN_FIRST_LNI 4
#define QBMAN_FIRST_CQ_CHANNEL 10
#define QBMAN_FIRST_LFQID 20
#define QBMAN_FIRST_DCTIDX 20
#define QBMAN_FIRST_LFQMTIDX 20

#define QBMAN_PORTAL_IDX 1

/* Set up resources for kernel test */
#define QBMAN_GPP_TEST_FQID 5
#define QBMAN_GPP_TEST_BPID 5
#define QBMAN_GPP_TEST_QPRID 5
#define QBMAN_GPP_TEST_QDID 5
#define QBMAN_GPP_SWP_IDX 2
#define QBMAN_GPP_SWP_ICID 0xa
#define QBMAN_GPP_SWP_IOBYPASS 0
#define QBMAN_GPP_SWP_ISOLATION 1
#define QBMAN_GPP_SWP_VA        0

#define FQCTX_HI 0xabbaf00d
#define FQCTX_LO 0x98765432
#define FQ_VFQID 0x123456

#define QBMAN_DCPID 0
#define QBMAN_CEETM_INSTANCEID 0
#define QBMAN_CEETM_LFQMTID 1
#define QBMAN_CEETM_CQID 3
#define QBMAN_CEETM_DCTID 2
#define QBMAN_CEETM_CQ_CHANNELID 2
#define QBMAN_CEETM_LNIID 1
#define QBMAN_CEETM_SPID 1

/* Setup resources for user space test */
#define QBMAN_US_TEST_FQID 10
#define QBMAN_US_TEST_BPID 10
#define QBMAN_US_TEST_QPRID 10
#define QBMAN_US_TEST_QDID 10
#define QBMAN_US_SWP_IDX 3
#define QBMAN_US_SWP_ICID 0x1a
#define QBMAN_US_SWP_IOBYPASS 0
#define QBMAN_US_SWP_ISOLATION 1
#define QBMAN_US_SWP_VA        0

#define FQCTX_US_HI 0xabbaddaa
#define FQCTX_US_LO 0x98765111
#define FQ_US_VFQID 0x654321

#define QBMAN_DCPID 0
#define QBMAN_CEETM_INSTANCEID 0
#define QBMAN_CEETM_US_LFQMTID 1
#define QBMAN_CEETM_US_CQID 1
#define QBMAN_CEETM_US_DCTID 10
#define QBMAN_CEETM_US_CQ_CHANNELID 3
#define QBMAN_CEETM_US_LNIID 3
#define QBMAN_CEETM_US_SPID 3

static struct qbman_swp *swp;
static struct qbman_attr fqdesc;
uint32_t ctx = 0;
#else
#define QBMAN_FIRST_8CH 0
#define QBMAN_FIRST_BPID 0
#define QBMAN_FIRST_SWP 0
#define QBMAN_FIRST_CGID 0
#ifdef MC_CLI
#define QBMAN_FIRST_QPRID 1 /* using 1 to avoid confusion with un-initialized qpri values */
#else
#define QBMAN_FIRST_QPRID 0
#endif
#define QBMAN_FIRST_ORPID 1
#define QBMAN_FIRST_QDID 1
#define QBMAN_FIRST_LNI 0
#define QBMAN_FIRST_CQ_CHANNEL 0
#define QBMAN_FIRST_LFQID 0
#define QBMAN_FIRST_DCTIDX 0
#define QBMAN_FIRST_LFQMTIDX 0

#endif

uint16_t qman_pres;
uint32_t qman_freq;

/**********************/
/* State and settings */
/**********************/

/* qbman_drv.c is a stub to call all the device setup stuff that will
 * eventually be called from other management logic in MC. We statically assume
 * the existence of a single QBMan block, with hard-coded attributes, and we
 * allocate device memory for the block according to hard-coded parameters. */

static struct qbman_block_desc bd;
static struct qbman_block *qb;
static uint64_t fbpr_paddr;
static uint64_t pfdr_paddr;
static uint64_t wqpr_paddr;

/* timer is used to delay re-enablement of PFDR_LOW event so MC doesn't get
 * flooded with events from QM
 */
static void *pfdr_low_timer;

#define QBMAN_DEFAULT_TOTAL_BUFFERS (896*KILOBYTE)
#define QBMAN_FBPR_RECORD_SIZE 64
#define QBMAN_PFDR_RECORD_SIZE 128


#define QBMAN_ICID 0
#define QBMAN_IOBYPASS 1
#define QBMAN_VA 0


#ifdef QBMAN_TEST
extern void qbman_test(void);
static int setup_gpp_qbman_test(struct qbman_block *qb)
{
	struct qbman_swp_desc pd;
	struct qbman_swp_desc gpp_pd;
	uint32_t lfqid;
	uint32_t ceetmid;
	int ps = 0;

	ps = qbman_cacheable_pfdr();
	pd.block = qbman_block_get_desc(qb);
	pd.cena_bar = NULL; /* Should be ignored */
	pd.cinh_bar = NULL; /* Should be ignored */
	pd.irq = -1;
	pd.idx = QBMAN_PORTAL_IDX; /* <-- this is the value we care about */

	qbman_block_set_swp_icid(qb, pd.idx, QBMAN_ICID);
	qbman_block_set_swp_iobypass(qb, pd.idx, QBMAN_IOBYPASS);
	qbman_block_set_swp_sdest(qb, pd.idx, 0);
	qbman_block_set_swp_va(qb, pd.idx, QBMAN_VA);
	qbman_block_set_swp_isolated(qb, pd.idx, 0);
	qbman_block_set_swp_enabled(qb, pd.idx, 1);

	/*******************/
	/* Init the portal */
	/*******************/
	swp = qbman_swp_init(&pd);
	if (!swp)
		return -1;

	/********************************/
	/* Initialise a FQ for GPP test */
	/********************************/
	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_ctx(&fqdesc, FQCTX_HI, FQCTX_LO);
	qbman_fq_attr_set_fqctrl(&fqdesc, QBMAN_FQCTRL_HOLDACTIVE);
	qbman_fq_attr_set_icid(&fqdesc, QBMAN_ICID, 0);
	qbman_fq_attr_set_vfqid(&fqdesc, FQ_VFQID);
	qbman_fq_attr_set_destwq(&fqdesc, 0x20); /* use channel id 4 */
	qbman_fq_configure(swp, QBMAN_GPP_TEST_FQID, &fqdesc);
#ifdef QBMAN_TEST_QD
	static uint16_t qprids[16];
	qbman_qpr_configure(swp, QBMAN_GPP_TEST_QPRID,
		QBMAN_GPP_TEST_FQID, 1, 0);
	qprids[3] = QBMAN_GPP_TEST_QPRID;
	qbman_qd_configure(swp, QBMAN_GPP_TEST_QDID, qprids);
#endif
	/*******************************************/
	/* Initialise a FQ for GPP user space test */
	/*******************************************/
	qbman_fq_attr_clear(&fqdesc);
	qbman_fq_attr_set_ctx(&fqdesc, FQCTX_US_HI, FQCTX_US_LO);
	qbman_fq_attr_set_fqctrl(&fqdesc, QBMAN_FQCTRL_HOLDACTIVE);
	qbman_fq_attr_set_icid(&fqdesc, QBMAN_ICID, 0);
	qbman_fq_attr_set_vfqid(&fqdesc, FQ_US_VFQID);
	qbman_fq_attr_set_destwq(&fqdesc, 0x40); /* use channel id 8 */
	qbman_fq_configure(swp, QBMAN_US_TEST_FQID, &fqdesc);
#ifdef QBMAN_TEST_QD
	memset(qprids, 0, sizeof(qprids));
	qbman_qpr_configure(swp, QBMAN_US_TEST_QPRID,
		QBMAN_US_TEST_FQID, 1, 0);
	qprids[1] = QBMAN_US_TEST_QPRID;
	qbman_qd_configure(swp, QBMAN_US_TEST_QDID, qprids);
#endif

	/*****************************/
	/* Configure CEETM resources */
	/*****************************/
	ceetmid = qbman_ceetmid_compose(QBMAN_DCPID, QBMAN_CEETM_INSTANCEID);
	qbman_subportal_configure(swp, ceetmid, QBMAN_CEETM_SPID,
		QBMAN_CEETM_LNIID, 0);
	qbman_cchannel_configure(swp, ceetmid, QBMAN_CEETM_CQ_CHANNELID,
		QBMAN_CEETM_LNIID, 0);
	qbman_dct_configure(swp, ceetmid, QBMAN_CEETM_DCTID, 0, 0, 0, 0, ctx);
	qbman_cq_configure(swp, ceetmid,
		((uint16_t)QBMAN_CEETM_CQ_CHANNELID << 4) |
		QBMAN_CEETM_CQID, 0, ps, 0);
	lfqid = qbman_lfqid_compose_ex(ceetmid, QBMAN_CEETM_LFQMTID);
	qbman_lfq_configure(swp, lfqid,
		((uint16_t)QBMAN_CEETM_CQ_CHANNELID << 4) |
		QBMAN_CEETM_CQID, QBMAN_CEETM_DCTID, 0);

	/* Configure another LFQID for user space */
	qbman_subportal_configure(swp, ceetmid, QBMAN_CEETM_US_SPID,
		QBMAN_CEETM_US_LNIID, 0);
	qbman_cchannel_configure(swp, ceetmid, QBMAN_CEETM_US_CQ_CHANNELID,
		QBMAN_CEETM_US_LNIID, 0);
	qbman_dct_configure(swp, ceetmid, QBMAN_CEETM_US_DCTID, 0, 0, 0, 0,
		ctx);
	qbman_cq_configure(swp, ceetmid,
		((uint16_t)QBMAN_CEETM_US_CQ_CHANNELID << 4) |
		QBMAN_CEETM_US_CQID, 0, ps, 0);
	lfqid = qbman_lfqid_compose_ex(ceetmid, QBMAN_CEETM_US_LFQMTID);
	qbman_lfq_configure(swp, lfqid,
		((uint16_t)QBMAN_CEETM_US_CQ_CHANNELID << 4) |
		QBMAN_CEETM_US_CQID, QBMAN_CEETM_US_DCTID, 0);

	/******************************/
	/* Setup authorization table  */
	/******************************/
	qbman_auth_add(swp, QBMAN_GPP_SWP_ICID, qbman_auth_type_fqid,
		19, QBMAN_GPP_TEST_FQID, QBMAN_AUTH_SWP);
	qbman_auth_add(swp, QBMAN_GPP_SWP_ICID, qbman_auth_type_bpid,
		23, QBMAN_GPP_TEST_BPID, QBMAN_AUTH_SWP);
	qbman_auth_add(swp, QBMAN_GPP_SWP_ICID, qbman_auth_type_channel,
		4, 4, QBMAN_AUTH_SWP);
	qbman_auth_add(swp, QBMAN_GPP_SWP_ICID, qbman_auth_type_qdid,
		1, QBMAN_GPP_TEST_QDID, QBMAN_AUTH_SWP);
	qbman_auth_add(swp, QBMAN_GPP_SWP_ICID, qbman_auth_type_fqid,
		0xf00010,lfqid, QBMAN_AUTH_SWP);

	/* Setup auth table for user space */
	qbman_auth_add(swp, QBMAN_US_SWP_ICID, qbman_auth_type_fqid,
		29, QBMAN_US_TEST_FQID, QBMAN_AUTH_SWP);
	qbman_auth_add(swp, QBMAN_US_SWP_ICID, qbman_auth_type_bpid,
		33, QBMAN_US_TEST_BPID, QBMAN_AUTH_SWP);
	qbman_auth_add(swp, QBMAN_US_SWP_ICID, qbman_auth_type_channel,
		0, 8, QBMAN_AUTH_SWP);
	qbman_auth_add(swp, QBMAN_US_SWP_ICID, qbman_auth_type_qdid,
		5, QBMAN_US_TEST_QDID, QBMAN_AUTH_SWP);
	qbman_auth_add(swp, QBMAN_US_SWP_ICID, qbman_auth_type_fqid,
		0xf00020,lfqid, QBMAN_AUTH_SWP);

	/******************************************/
	/* Enable the isolated portal used in GPP */
	/******************************************/
	gpp_pd.block = qbman_block_get_desc(qb);
	gpp_pd.idx = QBMAN_GPP_SWP_IDX;
	qbman_block_set_swp_icid(qb, gpp_pd.idx, QBMAN_GPP_SWP_ICID);
	qbman_block_set_swp_iobypass(qb, gpp_pd.idx, QBMAN_GPP_SWP_IOBYPASS);
	qbman_block_set_swp_sdest(qb, gpp_pd.idx, 0);
	qbman_block_set_swp_va(qb, gpp_pd.idx, QBMAN_GPP_SWP_VA);
	qbman_block_set_swp_isolated(qb, gpp_pd.idx, QBMAN_GPP_SWP_ISOLATION);
	qbman_block_set_swp_enabled(qb, gpp_pd.idx, 1);
	/* SDQMR0, En, channel id 4 */
	qbman_block_set_swp_channel(qb, gpp_pd.idx, 0, 1, 4);

	/* Enable SWP used for User space */
	gpp_pd.idx = QBMAN_US_SWP_IDX;
	qbman_block_set_swp_icid(qb, gpp_pd.idx, QBMAN_US_SWP_ICID);
	qbman_block_set_swp_iobypass(qb, gpp_pd.idx, QBMAN_US_SWP_IOBYPASS);
	qbman_block_set_swp_sdest(qb, gpp_pd.idx, 0);
	qbman_block_set_swp_va(qb, gpp_pd.idx, QBMAN_US_SWP_VA);
	qbman_block_set_swp_isolated(qb, gpp_pd.idx, QBMAN_US_SWP_ISOLATION);
	qbman_block_set_swp_enabled(qb, gpp_pd.idx, 1);
	/* SDQMR1, En, channel id 8 */
	qbman_block_set_swp_channel(qb, gpp_pd.idx, 1, 1, 8);

	/****************************************/
	/* Cleanup, reset and deallocate portal */
	/****************************************/
	qbman_swp_finish(swp);
	if (qbman_block_reset_swp(qb, pd.idx)) {
		pr_err("SWP %d reset failed\n", pd.idx);
		return -1;
	}

	pr_info("*****QBMan_test: Finish setup resources for GPP test\n");
	return 0;
}
#endif

/* PLWI3,PLWI2,PLWI1,PLWI, PEBI */
#define QBMAN_ISR_PFDR_LOW_MASK 0xe00c0000
/* RPLI,RPQI,AVI,IFSI,ICVI,IDDI,IDFI,IDSI,IDQI,IERE,IEOI,IESI,IEQI */
#define QBMAN_ISR_RERR_Q_MASK 0x07030f2d

#define QBMAN_RERR_ENABLE_DEFAULT	0xffffffff
static void qbman_q_query_tasklet(uint64_t data)
{
	int i, j, tmp;
	uint32_t num;
	struct qbman_swp *sw_portal;
	struct qbman_attr cq_attr, fq_attr;
	int err;

	dpmng_get_swportal(sys_get_unique_handle(FSL_MOD_DPMNG), (void**)&sw_portal);

	pr_err("CQ and FQ counters after PFDR low threshold\n");
	/* Query all CQs */
	for (i = 0; i < 2; i++)
		for (j = 0; j < 512; j++) {
			qbman_cq_query(sw_portal,
					qbman_ceetmid_compose(0, (uint8_t)i),
					(uint16_t)j, (uint8_t*)&tmp,
					&tmp, &cq_attr, NULL);
			num = qbman_cq_num_of_frames(&cq_attr);
			if (num)
				pr_err("[CEETM#%d, CQ#%d]: %d\n", i, j, num);
		}
	/* Query all FQs */
	for (j = 0; j < 2048; j++) {
		err = qbman_fq_query_state(sw_portal, (uint32_t)j, &fq_attr);
		if( err ) continue;
		num = qbman_fq_state_frame_count(&fq_attr);
		if (num)
			pr_err("[FQ#%d]: %d\n", j, num);
	}
	dpmng_put_swportal(sys_get_unique_handle(FSL_MOD_DPMNG), (void*)sw_portal);
	timer_start(pfdr_low_timer);
}
static void qbman_arm_pfdr_low(void *arg)
{
	struct qbman_block *qb = (struct qbman_block *)arg;
	
	if (qbman_block_get_disable_interrupts(qb)) {
		qbman_block_set_rerr_enable(qb, QBMAN_RERR_ENABLE_DEFAULT & (~QBMAN_ISR_PFDR_LOW_MASK));
	} else {
		qbman_block_set_rerr_enable(qb, QBMAN_RERR_ENABLE_DEFAULT);
	}
}

static void qbman_rec_isr(uint32_t arg)
{
	uint32_t pending;
	struct qbman_block *qb = (struct qbman_block *)arg;

	pending = qbman_block_get_rerr_status(qb);
	pr_err("QBMAN recoverable event 0x%x\n", pending);

	dpmng_set_last_rerr_isr(pending);

	if (pending & QBMAN_ISR_RERR_Q_MASK)
		dpmng_dump_rerr_fqid(sys_get_unique_handle(FSL_MOD_DPMNG));

	if (pending & QBMAN_ISR_PFDR_LOW_MASK)
	{
		/* don't activate this event right away, it can flood MC with
		 * interrupts
		 */
		if (pending & 0x20000000) {
			qbman_block_set_disable_interrupts(qb, 1);
		}

		qbman_block_set_rerr_enable(qb, QBMAN_RERR_ENABLE_DEFAULT &
				~QBMAN_ISR_PFDR_LOW_MASK);
		fsl_schedule_tasklet(qbman_q_query_tasklet, 0, tsk_priority_immediate);
	}
	qbman_block_set_rerr_status(qb, pending);
}

static void qbman_nrec_isr(uint32_t arg)
{
	uint32_t pending;
	struct qbman_block *qb = (struct qbman_block *)arg;
#define QBMAN_ISR_RFQE 0x00000020

	pending = qbman_block_get_nrerr_status(qb);
	pr_err("QBMAN non-recoverable event 0x%x\n", pending);
	if (pending & QBMAN_ISR_RFQE)
		qbman_block_set_nrerr_enable(qb,
		                             qbman_block_get_nrerr_enable(qb) & ~QBMAN_ISR_RFQE);
	qbman_block_set_nrerr_status(qb, pending);
}

/* NB: these predeclarations are because they don't get predeclared in a header,
 * and gcc (quite rightly) things that linkable (non-static) functions cannot
 * possibly be useful unless they're predeclared - after all, who will call
 * them? In our case though, the existence of these functions is also
 * predeclared locally in whichever other C file uses them, which is a bit of a
 * hack, and explains why a similar hack is required here. If an MC s/w
 * architect wants to move these declarations to a common header (which one?),
 * be my guest. */
int qbman_drv_init(void);

static void dpc_qbman_process(uint64_t *fbpr_size,
			      uint64_t *pfdr_size,
			      uint16_t *num_2_wq_ch,
			      enum orl_oree_mode *oree_mode)
{
	uint32_t total_bman_buffers;

	total_bman_buffers = (dpc.qbman.dpc_mask & DPC_QBMAN_MASK_TOTAL_BUFFERS) ?
		dpc.qbman.total_bman_buffers : QBMAN_DEFAULT_TOTAL_BUFFERS;
	*fbpr_size = DIV_CEIL(total_bman_buffers, 7) * QBMAN_FBPR_RECORD_SIZE;
	*pfdr_size = DIV_CEIL(total_bman_buffers, 3) * QBMAN_PFDR_RECORD_SIZE;
	/* Add extra 20% for GPP buffers */
	*pfdr_size = *pfdr_size * 120 / 100;

	*num_2_wq_ch = (dpc.qbman.dpc_mask & DPC_QBMAN_MASK_WQ_CH) ?
		(dpc.qbman.wq_ch_conversion*4) : 0;
	
	*oree_mode = (dpc.qbman.dpc_mask & DPC_QBMAN_MASK_OREE_MODE) ?
			(dpc.qbman.oree_mode) : OREE_MODE_OFF;
	
	
}

static int pfdr_init(uint64_t pfdr_size,
		const struct memory_partition_list* mem_types,
		uint32_t num_orl_recs, uint8_t pps, uint8_t pfdr_pool_min_value)
{
	uint64_t pfdr_paddr;
	int ret = fsl_get_mem_mp(pfdr_size, mem_types, pfdr_size, &pfdr_paddr);

	if (ret)
		return ret;
	ret = qbman_block_set_mem_pfdr(qb, upper32(pfdr_paddr),
				lower32(pfdr_paddr), (size_t)pfdr_size, 0,
				num_orl_recs, pps, pfdr_pool_min_value);
	return ret;
}

// fix PFDR and FBPR sizes to ensure MC starting with default values
static void fix_fbpr_pfdr_sizes(uint64_t *fbpr_size, uint64_t *pfdr_size)
{
	if( (dpc.qbman.dpc_mask & DPC_QBMAN_MASK_TOTAL_BUFFERS) ) {
		// if total_bman_buffers is present in DPC, user wants to make the configuration
		return;
	}

	if( sys_mem_exists(MEM_PART_SYSTEM_DDR2) ) {
		// when DDR2 memory partition is available defaults can be implemented
		return;
	}

	if( (sys_mem_size(MEM_PART_SYSTEM_DDR1) <= (128*MEGABYTE)) && ((qman_version & 0xFFFF0000) >= QMAN_REV_5000) ) {
		// this partition must accommodate PFDR, FBPR and 64M DDR portal backing
		if( *pfdr_size > (32ull*MEGABYTE) ) {
			pr_warn("Defaulting PFDR size to 32 MB\n");
			*pfdr_size = 32*MEGABYTE;
			pr_warn("Defaulting FBPR size to 8 MB\n");
			*fbpr_size = 8*MEGABYTE;
		}
	}
}

/***************/
/* Driver init */
/***************/
int qbman_drv_init(void)
{
	struct qbman_desc qbman_desc;
	struct resman *resman;
	struct dpmng *dpmng;
	struct resman_res_req req;
	mpic_intr_params_t intr_params;
	uint16_t num8ch, num2ch = 0, pres;
	enum orl_oree_mode oree_mode;
	uint32_t i, j, max_items_held_in_WQs, num_wqpr;
	uint64_t fbpr_size, pfdr_size, wqpr_size;
	uint64_t pfdr_peb_size;
	int err, iter = 0;
	int num_swp = 0;
	int srcid;
	struct qbman_swportal_desc qbman_swportal_desc = {0};
	const struct memory_partition_list qbman_mem_partitions = {
			.mem_part_ids = {MEM_PART_SYSTEM_DDR2, MEM_PART_SYSTEM_DDR1,
							MEM_PART_LAST /* mark end of list*/ }
	};
	pr_info("Executing qbman_drv_init...\n");

	/***********************************/
	/* Reading DPC initialization file */
	/***********************************/
	dpc_qbman_process(&fbpr_size, &pfdr_size, &num2ch, &oree_mode);

	/**************************/
	/* Set up the QBMan block */
	/**************************/
	memset(&qbman_desc, 0, sizeof(struct qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, &iter);
	if (err)
		return -1;

	pr_info("QBMAN CCSR: 0x%08x%08x\n",UINT32_HI(qbman_desc.paddr), UINT32_LO(qbman_desc.paddr));

	bd.ccsr_reg_bar = qbman_desc.vaddr;
	ASSERT_COND(bd.ccsr_reg_bar);

	qb = qbman_block_init(&bd, oree_mode);
	if (!qb)
		return -1;

	/* The WQPR window size must be programmed based on the maximum number of items that can be held in all
	 WQs, which is:
	 max_items_held_in WQs = number of FQs supported in this SoC
	 + max number of SWP channels supported in this SoC (for CDANs), = number of SWP WQs / 2
	 + number of FQ congestion groups supported in this SoC (for CSCNs)
	 + total number of CEETM congestion groups in all DCP portals supported in this SoC (for CSCNs)
	 then the number of WQPR required is:
	 num_WQPR_required = (max_items_held_in WQs / (number of WQ items per WQPR for this SoC)) + 1.
	 (the + 1 comes about because proxy record ID of 0 is used as a null indicator)
	 which then gives the required window size as :
	 required WQPR window size = (num_WQPR_required + 8) * 64
	 If this is a small MC image (128M) do not involve number of queues into wqpr calculation
	 */
	max_items_held_in_WQs = (dpmng_mctiny() ? 0 : qbman_desc.num_int_fqs)
				+ qbman_desc.num_swp_wqs / 2
				+ qbman_desc.num_fq_cgs;
	for (i = 0; i < QBMAN_MAX_DCP; i++) {
		if (!qbman_desc.dcp[i].ceetm_support)
			continue;
		for (j = 0; j < QBMAN_MAX_CEETM_INS; j++) {
			if (!qbman_desc.dcp[i].ceetm_instance[j].valid)
				continue;
			max_items_held_in_WQs +=
				qbman_desc.dcp[i].ceetm_instance[j].num_ccg;
		}
	}
	num_wqpr = (max_items_held_in_WQs / qbman_desc.num_wq_per_wqpr) + 1;
	wqpr_size = (num_wqpr + 8) * 64;

	NEXT_POWER_OF_2(fbpr_size, fbpr_size);
	if( dpmng_mctiny() ) {
		// set to max available value for this case
		fbpr_size = 4 * MEGABYTE;
		pr_warn("Set FBPR size to 4Mb\n");
	}

	NEXT_POWER_OF_2(pfdr_size, pfdr_size);
	if( dpmng_mctiny() ) {
		// set to maximum available value for this case
		pfdr_size = 16 * MEGABYTE;
		pr_warn("Set PFDR size to 16Mb\n");
	}

	fix_fbpr_pfdr_sizes(&fbpr_size, &pfdr_size);

	err = fsl_get_mem_mp(fbpr_size, &qbman_mem_partitions, fbpr_size,
	                     &fbpr_paddr);
	ASSERT_COND(!err);

	NEXT_POWER_OF_2(wqpr_size, wqpr_size);
	err = fsl_get_mem_mp(wqpr_size, &qbman_mem_partitions, wqpr_size,
	                     &wqpr_paddr);
	ASSERT_COND(!err);

	if( qbman_desc.multiple_pfdr_support ) {
		qbman_block_set_mem_attributes(qb, QBMAN_ICID, QBMAN_IOBYPASS,
							QBMAN_VA, 1, 0, 0);
	} else {
		qbman_block_set_mem_attributes(qb, QBMAN_ICID, QBMAN_IOBYPASS,
					QBMAN_VA, 0, 0, 0);
	}
	qbman_block_set_mem_fbpr(qb, upper32(fbpr_paddr), lower32(fbpr_paddr),
					(size_t)fbpr_size);
	err = pfdr_init(pfdr_size, &qbman_mem_partitions,
			qbman_desc.num_orl_recs, QBMAN_PFDR_POOL_BASE,qbman_desc.pfdr_pool_min_value);
	if( err ) {
		pr_err("Could not initialize PFDR base pool\n");
		return err;
	}
	if( qbman_desc.multiple_pfdr_support ) {
		const struct memory_partition_list qbman_peb_mem_part = {
			.mem_part_ids = {MEM_PART_PEB, MEM_PART_LAST /* end of list */ }
		};

		/* check is pfdr_peb_size entry exists in dpc qbman node */
		if (dpc.qbman.dpc_mask & DPC_QBMAN_MASK_PFDR_PEB_SIZE) {
			pr_debug("Configured pfdr_peb_size is %dk\n", dpc.qbman.pfdr_peb_size);

			/* pfdr_peb_size value is converted to multiple of KB */
			dpc.qbman.pfdr_peb_size *= KILOBYTE;

			/* check for lower/upper limits */
			if (dpc.qbman.pfdr_peb_size < 128*KILOBYTE) {
				pr_warn("Configured pfdr_peb_size(%dk) is lower than minimum(128k)\n",
						dpc.qbman.pfdr_peb_size/KILOBYTE);
				dpc.qbman.pfdr_peb_size = 128*KILOBYTE;
			} else if (dpc.qbman.pfdr_peb_size > 2 * qbman_desc.pfdr_peb_size) {
					pr_warn("Configured pfdr_peb_size(%dk) exceeds maximum value(%dk)\n",
							dpc.qbman.pfdr_peb_size/KILOBYTE,
							2*qbman_desc.pfdr_peb_size/KILOBYTE);
					dpc.qbman.pfdr_peb_size = 2 * qbman_desc.pfdr_peb_size;
			}

			/* update value once it has been validated */
			pfdr_peb_size = dpc.qbman.pfdr_peb_size;
		} else {
			/* defaults to qbman_desc@soc_db_arch */
			pr_debug("Default pfdr_peb_size is %dk\n", qbman_desc.pfdr_peb_size/KILOBYTE);
			pfdr_peb_size = qbman_desc.pfdr_peb_size;
		}

		ASSERT_COND(pfdr_peb_size>0);    // configuration from soc_db is consistent
		NEXT_POWER_OF_2(pfdr_peb_size, pfdr_peb_size);

		err = pfdr_init(pfdr_peb_size, &qbman_peb_mem_part,
						qbman_desc.num_orl_recs, QBMAN_PFDR_POOL_PEB, qbman_desc.pfdr_pool_min_value);
		if( err ) {
			pr_err("Could not initialize PFDR PEB pool\n");
			return err;
		}
	}

	qbman_block_set_mem_wqpr(qb, upper32(wqpr_paddr), lower32(wqpr_paddr),
					(size_t)wqpr_size);
	qbman_block_set_swp_bar(qb, upper32(qbman_desc.portals_paddr),
				lower32(qbman_desc.portals_paddr));

	if ((qman_version & 0xFFFF0000) >= QMAN_REV_5000) {
		uint64_t swp_bar_cp_mem_paddr;
		uint64_t swp_bar_cp_mem_size = 64 * 1024 * 1024;

		if( dpmng_mctiny() ) {
			pr_err("MC small memory footprint is not supported on this platform."
					"It needs 64MB for QBMAN memory backed portals.\n");
			return -ENOTSUP;
		}

		NEXT_POWER_OF_2(swp_bar_cp_mem_size, swp_bar_cp_mem_size);
		err = fsl_get_mem_mp(swp_bar_cp_mem_size, &qbman_mem_partitions,
				swp_bar_cp_mem_size, &swp_bar_cp_mem_paddr);
		if (err) {
			pr_err("Couldn't allocate memory for QBMAN memory backed portals\n");
			return err;
		}
		qbman_block_set_swp_bar_cp_mem(qb,
					       upper32(swp_bar_cp_mem_paddr),
					       lower32(swp_bar_cp_mem_paddr));
	}

	qbman_block_set_pfdr_threshold(qb, 512, 64, QBMAN_PFDR_POOL_BASE);
	if( qbman_desc.multiple_pfdr_support ) {
		if ((qman_version & 0xFFFF0000) < QMAN_REV_5000)
			qbman_block_set_pfdr_threshold(qb, 256, 64,
						 QBMAN_PFDR_POOL_PEB);
		else
			/* QMan 5.0 requires K of PFDR_CFG1/2/3 to be 0 */
			qbman_block_set_pfdr_threshold(qb, 256, 0,
						 QBMAN_PFDR_POOL_PEB);
	}

	num2ch = MIN(num2ch, (uint16_t)(qbman_desc.num_swp_wqs / 2));
	num8ch = (uint16_t)((qbman_desc.num_swp_wqs - num2ch * 2) / 8);
	pr_debug("DPC: wq_ch_conversion = %d; %d QM WQ configured as %d 8WQ channels and %d 2WQ channels\n",
			dpc.qbman.wq_ch_conversion, qbman_desc.num_swp_wqs, num8ch, num2ch);
	qbman_block_set_num8ch(qb, num8ch);
	qbman_block_init_complete(qb);
	sys_add_handle(qb, FSL_MOD_QBMAN, 1, 0);

	/* Because the token credit rate is limited under 2048 (with 11 bit
	 * integer and 13 bit fractional part) on QMan 4.x or 32768 (with 15
	 * bit integer and 13 bit fractional part) on QMan5.0, we have:
	 * For QMan 4.x:
	 * The shaper output rate max = (2048 * 8 * QMan frequency * PRES) /
								4194304
	 * PRES = (max shaper rate * 4194304) / (2048 * 8 * QMan freq)
	 * PRES = (max shaper rate * 256) / (QMan freq)
	 * Note: the token credit update reference period is not 1000ns any
	 * more, it can be calculated with:
	 * The token credit update reference period = (4194304 / PRES) /
						       QMan freq.
	 * For QMan 5.x:
	 * The shaper output rate max = (32768 * 8 * QMan frequency * PRES) /
								2 ^ 23
	 * PRES = (max shaper rate * 2 ^ 23) / (2 ^ 15 * 8 * QMan freq)
	 * PRES = (max shaper rate * 32) / (QMan freq)
	 * Note: the token credit update reference period is not 1000ns any
	 * more, it can be calculated with:
	 * The token credit update reference period = (8388608 / PRES) /
						       QMan freq.
	 *
	 */
	if ((qman_version & 0xFFFF0000) < QMAN_REV_5000)
		pres = (uint16_t)(((qbman_desc.ceetm_max_shaper_output_rate
				 << 8) / (uint64_t)qbman_desc.clk));
	else
		pres = (uint16_t)(((qbman_desc.ceetm_max_shaper_output_rate
                                 << 5) / (uint64_t)qbman_desc.clk));
	pres += 1; /* to round up */
	pr_debug("Calculated PRES value: %d\n", pres);

	if (pres > qbman_block_get_max_pres(qb))
	       pr_err("This pres is not supported, please adjust the max"
			       " shaper output rate\n");
	qman_pres = pres;
	qman_freq = qbman_desc.clk;

	for (i = 0; i < QBMAN_MAX_DCP; i++) {
		if (!qbman_desc.dcp[i].ceetm_support)
			continue;

		for (j = 0; j < QBMAN_MAX_CEETM_INS; j++) {
			if (!qbman_desc.dcp[i].ceetm_instance[j].valid)
				continue;
			qbman_block_set_shaper_prescalar(qb, i, j, pres);
		}
	}

	pfdr_low_timer = timer_create();
	if (!pfdr_low_timer) {
		pr_err("Internal error: Cannot allocate timer for PFDR IRQ throttling!\n");
		return -ENOMEM;
	}
	timer_init(pfdr_low_timer, 100, &qbman_arm_pfdr_low, (void*)qb,
			E_TIMER_MODE_SINGLE, 1);

	qbman_block_set_init_rerr(qb);
	qbman_block_set_init_nrerr(qb);

	intr_params.polarity = OS_MPIC_INTR_POLARITY_HIGH;
	intr_params.priority = 8;
	intr_params.sense = OS_MPIC_INTR_SENSE_LEVEL;
	intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;

	err = mpic_set_config_intr((uint32_t)qbman_desc.irq_recoverable,
                                   (uint32_t)0,
                                   qbman_rec_isr,
                                   (mpic_arg)qb,
                                   &intr_params);
	if (err != 0) {
		return err;
	}
	err = mpic_enable_intr((uint32_t)qbman_desc.irq_recoverable);
	if (err != 0) {
		return err;
	}

	err = mpic_set_config_intr((uint32_t)qbman_desc.irq_non_recoverable,
                                   (uint32_t)0,
                                   qbman_nrec_isr,
                                   (mpic_arg)qb,
                                   &intr_params);
	if (err != 0) {
		return err;
	}
	err = mpic_enable_intr((uint32_t)qbman_desc.irq_non_recoverable);
	if (err != 0) {
		return err;
	}

	/* Create Resource Manager pools for QBMan resources */
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	ASSERT_COND(resman);

	for (i = QBMAN_FIRST_8CH; i < num8ch; i++) {
		req.id_base_align = (int)i * 4;
		req.num = 1;
		strcpy(req.type, "swpch.8wq");
		req.options = DPRC_RES_REQ_OPT_EXPLICIT;
		if ((err = resman_create_res_pool(resman, &req)) != 0)
			return err;
	}

	for (i = (uint32_t)num8ch * 4; i < qbman_desc.num_swp_wqs / 2; i++) {
		req.id_base_align = (int)i;
		req.num = 1;
		strcpy(req.type, "swpch.2wq");
		req.options = DPRC_RES_REQ_OPT_EXPLICIT;
		if ((err = resman_create_res_pool(resman, &req)) != 0)
			return err;
	}

	qbman_swportal_desc.qbman_id = 0;
	while (sys_get_desc(SOC_MODULE_QBMAN_PORTAL,
	                        (SOC_DB_QBMAN_PORTAL_DESC_QBMAN_ID),
	                        &qbman_swportal_desc,
	                        &num_swp) == 0) ;


	req.num = (uint32_t)num_swp - QBMAN_FIRST_SWP;
	req.id_base_align = QBMAN_FIRST_SWP;
	strcpy(req.type, "swp");
	req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	if ((err = resman_create_res_pool(resman, &req)) != 0)
		return err;

	req.id_base_align = QBMAN_FIRST_FQID;
	req.num = qbman_desc.num_int_fqs - QBMAN_FIRST_FQID;
	strcpy(req.type, "fq");
	req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	if ((err = resman_create_res_pool(resman, &req)) != 0)
		return err;

	req.id_base_align = QBMAN_FIRST_CGID;
	req.num = qbman_desc.num_fq_cgs - QBMAN_FIRST_CGID;
	strcpy(req.type, "cg");
	req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	if ((err = resman_create_res_pool(resman, &req)) != 0)
		return err;

	req.id_base_align = QBMAN_FIRST_BPID;
	req.num = qbman_desc.num_bpids - QBMAN_FIRST_BPID;
	strcpy(req.type, "bp");
	req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	if ((err = resman_create_res_pool(resman, &req)) != 0)
		return err;

	req.id_base_align = QBMAN_FIRST_QDID;
	req.num = qbman_desc.num_qds - QBMAN_FIRST_QDID;
	strcpy(req.type, "qd");
	req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	if ((err = resman_create_res_pool(resman, &req)) != 0)
		return err;

	req.id_base_align = QBMAN_FIRST_QPRID;
	req.num = qbman_desc.num_qprs - QBMAN_FIRST_QPRID;
	strcpy(req.type, "qpr");
	req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	if ((err = resman_create_res_pool(resman, &req)) != 0)
		return err;

	if (dpmng_soc_has_orp()) {
		req.id_base_align = QBMAN_FIRST_ORPID;
		req.num = qbman_desc.num_odps_orps;
		strcpy(req.type, "opr");
		req.options = DPRC_RES_REQ_OPT_EXPLICIT;
		if ((err = resman_create_res_pool(resman, &req)) != 0)
			return err;
	}


	req.id_base_align = 1;
	req.num = qbman_desc.num_replication_records;
	strcpy(req.type, "rplr");
	req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	if ((err = resman_create_res_pool(resman, &req)) != 0)
		return err;

	for (i = 0; i < QBMAN_MAX_DCP; i++) {
		// Add AIOP & other DCP channel resources
		if (!qbman_desc.dcp[i].ceetm_support) {
			if (!qbman_desc.dcp[i].valid)
				continue;
			if (qbman_desc.dcp[i].dcp_type == QBMAN_DCP_AIOP) {
				req.id_base_align = QBMAN_FIRST_USER_AIOP_DCP_CHID;
				req.num = qbman_desc.dcp[i].num_fq_wq_channels;
				strcpy(req.type, "dcp.aiop.ch");
				req.options = DPRC_RES_REQ_OPT_EXPLICIT;
				err = resman_create_res_pool(resman, &req);
				CHECK_COND_RETVAL(err == 0, err,
						"Fail to register AIOP DCP channel resources\n");
			}
			continue;
		}
		for (j = 0; j < QBMAN_MAX_CEETM_INS; j++) {
			if (!qbman_desc.dcp[i].ceetm_instance[j].valid)
				continue;

			req.id_base_align = QBMAN_FIRST_LNI;
			req.options = DPRC_RES_REQ_OPT_EXPLICIT;

			req.num = qbman_desc.dcp[i].ceetm_instance[j].num_lnis
					- QBMAN_FIRST_LNI;
			snprintf(req.type, sizeof(req.type), "lni.ctm%d.ins%d",
					(int)i, (int)j);
			if ((err = resman_create_res_pool(resman, &req)) != 0)
				return err;

			req.id_base_align = QBMAN_FIRST_CQ_CHANNEL;
			req.num =
				qbman_desc.dcp[i].ceetm_instance[j].num_cq_channels
				- QBMAN_FIRST_CQ_CHANNEL;
			snprintf(req.type, sizeof(req.type), "cqch.ctm%d.ins%d",
					(int)i, (int)j);
			if ((err = resman_create_res_pool(resman, &req)) != 0)
				return err;

			req.id_base_align = QBMAN_FIRST_LFQMTIDX;
			req.num = qbman_desc.dcp[i].ceetm_instance[j].num_lfqids;
			snprintf(req.type, sizeof(req.type), "lfqmt.ctm%d.ins%d",
					(int)i, (int)j);
			if ((err = resman_create_res_pool(resman, &req)) != 0)
				return err;

			req.id_base_align = QBMAN_FIRST_DCTIDX;
			req.num = qbman_desc.dcp[i].ceetm_instance[j].num_lfqids;
			snprintf(req.type, sizeof(req.type), "dct.ctm%d.ins%d",
					(int)i, (int)j);
			if ((err = resman_create_res_pool(resman, &req)) != 0)
				return err;
		}
	}

	for(srcid = 0; srcid < qbman_desc.num_sdest_srcid; srcid++) {
		qbman_block_set_swp_srcid_map(qb, srcid, qbman_desc.sdest_srcid[srcid].srcid, qbman_desc.sdest_srcid[srcid].sdest);
	}

	dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	ASSERT_COND(dpmng);
	dpmng_set_rate_limit(dpmng, qbman_desc.ceetm_max_shaper_output_rate);

#ifdef QBMAN_TEST
	setup_gpp_qbman_test(qb);
	/* Once FIL fix run_apps(), we can defer the MC-based test case to
	 * there (meaning it can run in parallel with GPP boot). The setup for
	 * GPP-based test case must occur in this boot-up code though,
	 * otherwise it will race with the GPP test case that depends on it.
	 */
	/*qbman_test(); */
#endif

	return 0;
}
