/*
 * Copyright 2013-2020 NXP
 */

#include "qbman_private.h"
#include "fsl_errors.h"
#include "fsl_qbman.h"
#include "drivers/fsl_qbman_ctrl.h"

/* CCSR register offsets */
#define QBMAN_CCSR_SWP_CCSR_IDX       0x000
#define QBMAN_CCSR_SWP_CCSR_IDX_LOCK  0x004
#define QBMAN_CCSR_SWP_CCSR_CFG       0x008
#define QBMAN_CCSR_SWP_DD_CFG         0x00c
#define QBMAN_CCSR_SWP_SDQMR(n)       (0x010 + ((uint32_t)(n) << 2))
#define QBMAN_CCSR_SWP_INT_MSG        0x050
#define QBMAN_CCSR_SWP_INT_MSG_BAR    0x080
#define QBMAN_CCSR_SWP_INT_MSG_BARE   0x084
#define QBMAN_CCSR_SWP_INT_CFG(n)     (0x090 + ((uint32_t)(n) << 2))
#define QBMAN_CCSR_SWP_SRCID_MAP      0x0d0
#define QBMAN_CCSR_QMAN_DD_CFG        0x200
#define QBMAN_CCSR_SWP_DD_IDX         0x204
#define QBMAN_CCSR_SWP_DD_IDX_LOCK    0x208
#define QBMAN_CCSR_SWP_DD_IHRSR       0x210
#define QBMAN_CCSR_SWP_DD_IHRFR       0x214
#define QBMAN_CCSR_SWP_DD_HASR        0x218
#define QBMAN_CCSR_DCP_DD_IHRSR       0x220
#define QBMAN_CCSR_DCP_DD_IHRFR       0x224
#define QBMAN_CCSR_DCP_DD_HASR        0x228
#define QBMAN_CCSR_DCP_CFG_IDX        0x300
#define QBMAN_CCSR_DCP_CFG_IDX_LOCK   0x304
#define QBMAN_CCSR_DCP_DD_CFG         0x308
#define QBMAN_CCSR_PFDR_FP_LWIT(n)    (0x410 + (uint32_t)(n) * 0x20)
#define QBMAN_CCSR_PFDR_CFG(n)        (0x414 + (uint32_t)(n) * 0x20)
#define QBMAN_CCSR_WQ_SWP_CH_CFG      0x60c
#define QBMAN_CCSR_WQ_CH_CFG_IDX      0x610
#define QBMAN_CCSR_WQ_CH_CFG_IDX_LOCK 0x614
#define QBMAN_CCSR_WQ_CH_CDAN_CFG     0x618
#define QBMAN_CCSR_WQ_CH_DD_CFG       0x61c
#define QBMAN_CCSR_FBPR_BAR           0x7c0
#define QBMAN_CCSR_FBPR_BARE          0x7c4
#define QBMAN_CCSR_FBPR_AR            0x7c8
#define QBMAN_CCSR_CM_CFG             0x800
#define QBMAN_CCSR_CEETM_CFG_IDX      0x900
#define QBMAN_CCSR_CEETM_CFG_IDX_LOCK 0x904
#define QBMAN_CCSR_CEETM_CFG_PRES     0x908
#define QBMAN_CCSR_CEETM_DD_CFG       0x910
#define QBMAN_CCSR_QMAN_MCR           0xb00
#define QBMAN_CCSR_QMAN_MCP0          0xb04
#define QBMAN_CCSR_QMAN_MCP1          0xb08
#define QBMAN_CCSR_QMAN_MISC_CFG      0xbe0
#define QBMAN_CCSR_QMAN_OR_RDCR       0xbe4
#define QBMAN_CCSR_QMAN_IP_REV_1      0xbf8
#define QBMAN_CCSR_QMAN_IP_REV_2      0xbfc
#define QBMAN_CCSR_PFDR_BAR           0xc20
#define QBMAN_CCSR_PFDR_BARE          0xc24
#define QBMAN_CCSR_PFDR_AR            0xc28
#define QBMAN_CCSR_PFDR_BAR_N(n)      (0xc40 + (uint32_t)(n - 1) * 0x10)
#define QBMAN_CCSR_PFDR_BARE_N(n)     (0xc44 + (uint32_t)(n - 1) * 0x10)
#define QBMAN_CCSR_PFDR_AR_N(n)       (0xc48 + (uint32_t)(n- 1) * 0x10)
#define QBMAN_CCSR_WQPR_BAR           0xc30
#define QBMAN_CCSR_WQPR_BARE          0xc34
#define QBMAN_CCSR_WQPR_AR            0xc38
#define QBMAN_CCSR_SWP_BAR            0xc80
#define QBMAN_CCSR_SWP_BARE           0xc84
#define QBMAN_CCSR_SWP_WAS_CFG        0xc90
#define QBMAN_CCSR_SWP_AMQ_CFG        0xc94
#define QBMAN_CCSR_SWP_BAR_CP_MEM     0xca0
#define QBMAN_CCSR_SWP_BARE_CP_MEM    0xca4
#define QBMAN_CCSR_CI_SCHED_CFG       0xd00
#define QBMAN_CCSR_QMAN_SRCIDR        0xd04
#define QBMAN_CCSR_QMAN_ICIDR         0xd08
#define QBMAN_CCSR_RERR_ISR           0xe00
#define QBMAN_CCSR_RERR_IER           0xe04
#define QBMAN_CCSR_RERR_ISDR          0xe08
#define QBMAN_CCSR_RERR_IIR           0xe0c
#define QBMAN_CCSR_RERR_HER           0xe14
#define QBMAN_CCSR_RERR_REL_FQID      0xa10
#define QBMAN_CCSR_NRERR_ISR          0xe20
#define QBMAN_CCSR_NRERR_IER          0xe24
#define QBMAN_CCSR_NRERR_ISDR         0xe28
#define QBMAN_CCSR_NRERR_IIR          0xe2c
#define QBMAN_CCSR_NRERR_HER          0xe34


#define DEFAULT_WRED_PRESCALAR      99
#define DEFAULT_ICS_PRECEDENCE_MODE 0
#define DEFAULT_NUM8CH              0xf
#define DEFAULT_BMAN_W              4
#define DEFAULT_QMAN_W              4
#define DEFAULT_SRQ_W               4
#define DEFAULT_SRCCIV              4

/*Oree bit*/
#define OREE_ENABLE					1

/* Constants */
#define MCR_CMD_INIT_PFDR   0x01 /* QMAN_MCR::CMD_RSLT */
#define MCR_RSLT_IS_DONE(r) ((r) >= 0xf0)
#define MCR_RSLT_IS_OK(r)   ((r) <= 0xf1)

/* Bits to represent only-set-them-once registers */
#define ONCE_MEM_ATTRIBUTES 0x01
#define ONCE_FBPR           0x02
#define ONCE_PFDR           0x04
#define ONCE_WQPR           0x08
#define ONCE_SWP            0x10
#define ONCE_SWP_CP_MEM     0x20
#define ONCE_ALL            0x3f /* the OR of everything */

#define ONLY_ONCE(block, what) \
({ \
	BUG_ON((block)->only_once & ONCE_##what); \
	(block)->only_once |= ONCE_##what; \
})

uint32_t qman_version;
uint64_t qbman_swp_cp_mem = 0;

struct qbman_block {
	const struct qbman_block_desc *desc;
	void *ccsr;
	int irreversible_settings_are_done;
	uint32_t only_once;
	int disable_interrupts;
};

struct qbman_block *qbman_block_init(const struct qbman_block_desc *d, enum orl_oree_mode oree_mode)
{
	struct qbman_block *b = kmalloc(sizeof(*b), GFP_KERNEL);
	if (!b)
		return NULL;
	b->desc = d;
	b->ccsr = d->ccsr_reg_bar;
	b->irreversible_settings_are_done = 0;
	b->only_once = 0;
	pr_info("qbman_block_init, CCSR=0x%p, block=0x%p\n", b->ccsr, b);
	/* Apply same defaults */
	qbman_block_set_wred_prescalar(b, DEFAULT_WRED_PRESCALAR);
	qbman_block_set_num8ch(b, DEFAULT_NUM8CH);
	qbman_block_set_initiator_sched_weight(b, DEFAULT_BMAN_W,
					       DEFAULT_QMAN_W, DEFAULT_SRQ_W);
	qbman_block_set_initiator_stash_credit(b, DEFAULT_SRCCIV);
	qbman_block_set_orl_external_memory(b, oree_mode);
	qbman_block_get_qman_version(b);
	return b;
}

void qbman_block_finish(struct qbman_block *b)
{
	pr_info("qbman_block_finish, block=0x%p\n", b);
	kfree(b);
}

const struct qbman_block_desc *qbman_block_get_desc(struct qbman_block *b)
{
	return b->desc;
}

void qbman_block_init_complete(struct qbman_block *b)
{
	if ((qman_version & 0xFFFF0000) < QMAN_REV_5000) {
		/* Register is not supported for versions before QMAN 5.0 */
		ONLY_ONCE(b, SWP_CP_MEM);
	}
	if (b->only_once != ONCE_ALL)
		pr_err("init=0x%x required=0x%x, continuing anyway!\n",
		       b->only_once, ONCE_ALL);
	pr_info("qbman_block_init_complete, block=0x%p\n", b);
	b->irreversible_settings_are_done = 1;
}

	/*******************/
	/* qbman_block API */
	/*******************/

/* WRED_PRESCALAR is (CM_CFG,0,16) */
void qbman_block_get_wred_prescalar(struct qbman_block *b, uint16_t *pres)
{
	uint32_t reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_CM_CFG);
	*pres = d32_uint16_t(0, 16, reg);
}
void qbman_block_set_wred_prescalar(struct qbman_block *b, uint16_t pres)
{
	uint32_t reg = e32_uint16_t(0, 16, pres);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_CM_CFG, reg);
}

/* ICS_PRECEDENCE_MODE is (QMAN_MISC_CFG,2,1) */
void qbman_block_get_ics_precedence_mode(struct qbman_block *b, int *ics_pm)
{
	uint32_t reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_QMAN_MISC_CFG);
	*ics_pm = d32_int(2, 1, reg);
}
void qbman_block_set_ics_precedence_mode(struct qbman_block *b, int ics_pm)
{
	uint32_t reg = e32_int(2, 1, !!ics_pm);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_QMAN_MISC_CFG, reg);
}
/* ORL_EXTERNAL_MEMORY is (QMAN_MISC_CFG,3,1) */
void qbman_block_get_orl_external_memory(struct qbman_block *b, int *oree)
{
       uint32_t reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_QMAN_MISC_CFG);
       *oree = d32_int(3, 1, reg);
}
void qbman_block_set_orl_external_memory(struct qbman_block *b, int oree)
{
       uint32_t reg = e32_int(3, 1, !!oree);
       qbman_ccsr_write(b->ccsr, QBMAN_CCSR_QMAN_MISC_CFG, reg);
}

/* Order Restoration Resource Depletion Control */
void qbman_block_get_order_restoration_depletion(struct qbman_block *b,
						 int *ordbe, uint16_t *ordt)
{
	uint32_t reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_QMAN_OR_RDCR);

	*ordbe = !!d32_int(16, 1, reg);
	*ordt = d32_uint16_t(0, 16, reg);
}
void qbman_block_set_order_restoration_depletion(struct qbman_block *b,
						 int ordbe, uint16_t ordt)
{
	uint32_t reg;

	reg = e32_int(16, 1, !!ordbe) | e32_uint16_t(0, 16, ordt);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_QMAN_OR_RDCR, reg);
}

/* SRCID is (QMAN_SRCIDR,0,8) */
void qbman_block_get_bus_source_id(struct qbman_block *b, uint8_t *srcid)
{
	uint32_t reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_QMAN_SRCIDR);
	*srcid = d32_uint8_t(0, 8, reg);
}

/* NUM8CH is (WQ_SWP_CH_CFG,0,12) */
void qbman_block_get_num8ch(struct qbman_block *b, uint16_t *num8ch)
{
	uint32_t reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_WQ_SWP_CH_CFG);
	*num8ch = d32_uint16_t(0, 12, reg);
}
void qbman_block_set_num8ch(struct qbman_block *b, uint16_t num8ch)
{
	uint32_t reg = e32_uint16_t(0, 12, num8ch);
	BUG_ON(b->irreversible_settings_are_done);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_WQ_SWP_CH_CFG, reg);
}

/* BMAN_W is (CI_SCHED_CFG,0,3) - BMan flush/fetch
 * RW_W is (CI_SCHED_CFG,4,3) - QMan read/write
 * SRQ_W is (CI_SCHED_CFG,8,3) - Stash request queue
 * SRCCIV is (CI_SCHED_CFG,24,4) - Stash request credit initial value
 * SW is (CI_SCHED_CFG,31,1) - SRCCIV write-enable
 */
void qbman_block_get_initiator_sched_weight(struct qbman_block *b,
					    uint8_t *bman, uint8_t *qman, uint8_t *srq)
{
	uint32_t reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_CI_SCHED_CFG);
	*bman = d32_uint8_t(0, 3, reg);
	*qman = d32_uint8_t(4, 3, reg);
	*srq = d32_uint8_t(8, 3, reg);
}
void qbman_block_get_initiator_stash_credit(struct qbman_block *b, uint8_t *srcciv)
{
	uint32_t reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_CI_SCHED_CFG);
	*srcciv = d32_uint8_t(24, 4, reg);
}
void qbman_block_set_initiator_sched_weight(struct qbman_block *b,
					    uint8_t bman, uint8_t qman, uint8_t srq)
{
	uint32_t reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_CI_SCHED_CFG);
	reg = e32_uint8_t(0, 3, bman) | e32_uint8_t(4, 3, qman) | e32_uint8_t(8, 3, srq) |
		i32_uint8_t(24, 4, reg) | i32_int(31, 1, reg);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_CI_SCHED_CFG, reg);
}
void qbman_block_set_initiator_stash_credit(struct qbman_block *b, uint8_t srcciv)
{
	uint32_t reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_CI_SCHED_CFG);
	reg = i32_uint8_t(0, 3, reg) | i32_uint8_t(4, 3, reg) | i32_uint8_t(8, 3, reg) |
	      e32_uint8_t(24, 4, srcciv) | e32_int(31, 1, 1);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_CI_SCHED_CFG, reg);
}

/* ICID is (QMAN_ICIDR,0,15)
 * PL is (QMAN_ICIDR,15,1) - Privilege level, "iobypass"
 * VA is (QMAN_ICIDR,16,1) - Virtual address
 */
void qbman_block_set_mem_attributes(struct qbman_block *b, uint16_t icid,
				    int iobypass, int va, int iobypass1,
				    int iobypass2, int iobypass3)
{
	uint32_t reg = e32_uint16_t(0, 15, icid) | e32_int(15, 1, !!iobypass) |
		e32_int(16, 1, !!va);
	if ((qman_version & 0xFFFF0000) >= QMAN_REV_4100)
		reg |= e32_int(29, 1, !!iobypass1) | e32_int(30, 1, !!iobypass2) |
			e32_int(31, 1, !!iobypass3);
	if ((qman_version & 0xFFFF0000) >= QMAN_REV_5000)
		reg |= e32_int(17, 1, !!iobypass);
	BUG_ON(b->irreversible_settings_are_done);
	ONLY_ONCE(b, MEM_ATTRIBUTES);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_QMAN_ICIDR, reg);
}

/* BA is (FBPR_BAR,0,32) - Base address
 * EBA is (FBPR_BARE,0,32) - Extended base address
 * SIZE is (FBPR_AR,0,6) - Memory size is 2^(SIZE+1)
 * P is (FBPR_AR,30,1) - priority, ignored for now (TODO)
 */
void qbman_block_set_mem_fbpr(struct qbman_block *b, uint32_t fbpr_bare,
			      uint32_t fbpr_bar, size_t fbpr_size)
{
	unsigned int pow = ilog2(fbpr_size);
	uint32_t reg = e32_uint32_t(0, 6, pow - 1);
	BUG_ON(pow < 11); /* SIZE==b001011 --> 4KB */
	BUG_ON(pow > 33); /* SIZE==b100010 --> 16GB */
	BUG_ON(!is_power_of_2(fbpr_size));
	BUG_ON(b->irreversible_settings_are_done);
	ONLY_ONCE(b, FBPR);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_FBPR_BARE, fbpr_bare);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_FBPR_BAR, fbpr_bar);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_FBPR_AR, reg);
}

/* TH is (PFDR_FP_LWIT, 0, 24) - PFDR low watermark interrupt threshold
 * K is (PFDR_CFG, 0, 8) - PFDR base constant
 */
void qbman_block_set_pfdr_threshold(struct qbman_block *b, uint32_t th,
				    uint8_t k, uint8_t pps)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_PFDR_FP_LWIT(pps), th & 0xffffff);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_PFDR_CFG(pps), k);
}

/* BA is (PFDR_BAR,0,32) - Base address
 * EBA is (PFDR_BARE,0,32) - Extended base address
 * SIZE is (PFDR_AR,0,6) - Memory size is 2^(SIZE+1) on qman_4.0
 * SIZE_MAX is (PFDR_AR, 0, 22) - Maximum PFDR index or size of PFDR pool
 * on qman_4.1.
 * SM (PFDR_AR, 22, 1) - Size mode to control whether PFDR size is power-of-2
 * SE is (PFDR_AR,29,1) - CPC stash enable, enable for qman_4.1+
 * P is (PFDR_AR,30,1) - priority, ignored for now (TODO)
 * EN is (PFDR_AR,31,1) - Data structure access enable
 * PARAM0 is (QMAN_MCP0,0,32) - Generic parameter for QMan management command
 * PARAM1 is (QMAN_MCP1,0,32) - Generic parameter for QMan management command
 * CMD_RSLT is (QMAN_MCR,0,8) - QMan management command/result
 */
int qbman_block_set_mem_pfdr(struct qbman_block *b, uint32_t pfdr_bare,
			      uint32_t pfdr_bar, size_t pfdr_size, int sm,
			      uint32_t num_orl_recs, uint8_t pps, uint8_t pfdr_pool_min_value)
{
	unsigned int pow;
	uint32_t reg;
	uint8_t rslt;
	int loopvar = MAX_TRYS, ret = 0;
	uint32_t size_max;

	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100){
 		pow = ilog2(pfdr_size);
		BUG_ON(pow < 12); /* SIZE==b001011 --> 4KB */
		BUG_ON(pow > 31); /* SIZE==b011110 --> 2GB */
		BUG_ON(!is_power_of_2(pfdr_size));
		/* Disable CPC stashing for qman_4.0 */
		reg = e32_uint32_t(0, 6, pow - 1) | e32_int(31, 1, 1);
	} else {
		if (!sm) {
			pow = ilog2(pfdr_size);
			BUG_ON(pow < 12); /* SIZE==b001011 --> 4KB */
			BUG_ON(pow > 29); /* SIZE==b011100 --> 512MB */
			BUG_ON(!is_power_of_2(pfdr_size));
			reg = e32_uint32_t(0, 6, pow - 1) | e32_int(29, 1, 1) |
				e32_int(31, 1, 1);
		} else {
			size_max = (pfdr_size / 128);
			size_max &= ~(uint32_t)7;
			reg = e32_uint32_t(0, 22, size_max) | e32_int(22, 1, 1)
				 | e32_int(29, 1, 1) | e32_int(31, 1, 1);
		}
	}
	BUG_ON(b->irreversible_settings_are_done);
	if (!pps) {
		ONLY_ONCE(b, PFDR);
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_PFDR_BARE, pfdr_bare);
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_PFDR_BAR, pfdr_bar);
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_PFDR_AR, reg);
	} else {
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_PFDR_BARE_N(pps), pfdr_bare);
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_PFDR_BAR_N(pps), pfdr_bar);
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_PFDR_AR_N(pps), reg);
	}
	/* Issue "Initialize PFDR" command.
	 * The minimum value for this field in the base PFDR pool
	 * is total_number_of_ORL_records/2. The number of ORL records
	 * (also known as deferred enqueue records) supported is SoC specific.
	 * If the total number of ORL records supported is 0, the first 8 PFDR
	 * indices are reserved, in which case the minimum value for this field
	 * is 0x00_0008.
	 * In QMan 5.0, If the total number of ORL records supported is 0,
	 * the first 16 PFDR indices are reserved, in which case the minimum value for this field
	 * is 0x00_0010. For the alternate PFDR pools, the minimum value for this field is
	 * 0x00_0010.*/
	if( pps==QBMAN_PFDR_POOL_BASE ) {
		// base PFDR pool: PFDR index values from 0 to num_orl_recs/2 are reserved
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_QMAN_MCP0, (pps << 22) | MAX(pfdr_pool_min_value, num_orl_recs/2));
	} else {
		// alternate PFDR pools: PFDR index starts from minimum available value
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_QMAN_MCP0, (pps << 22) | (uint32_t)pfdr_pool_min_value);
	}
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_QMAN_MCP1, (pfdr_size / 128) - pfdr_pool_min_value);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_QMAN_MCR, MCR_CMD_INIT_PFDR);
	do {
		if (loopvar-- < 1) {
			/* The error code is EIO and not ENOMEM because the
			 * failure is not in allocating memory for PFDR but in
			 * configuring QMan to use the allocated memory */
			ret= -EIO;
			break;
		}
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_QMAN_MCR);
		rslt = d32_uint8_t(0, 8, reg);
	} while (!MCR_RSLT_IS_DONE(rslt));
	if (!MCR_RSLT_IS_OK(rslt)) {
		pr_err("PFDR init failed for pfdr pool %d: 0x%02x, %d..%d\n",
		       pps, rslt, MAX(pfdr_pool_min_value, num_orl_recs/2), (pfdr_size / 128) - pfdr_pool_min_value);
		ret = -EIO;
	}
	return ret;
}

/* BA is (WQPR_BAR,0,32) - Base address
 * EBA is (WQPR_BARE,0,32) - Extended base address
 * SIZE is (WQPR_AR,0,6) - Memory size is 2^(SIZE+1)
 * SE is (WQPR_AR,29,1) - CPC stash enable
 * P is (WQPR_AR,30,1) - priority, ignored for now (TODO)
 * EN is (WQPR_AR,31,1) - Data structure access enable
 */
void qbman_block_set_mem_wqpr(struct qbman_block *b, uint32_t wqpr_bare,
			      uint32_t wqpr_bar, size_t wqpr_size)
{
	unsigned int pow = ilog2(wqpr_size);
	uint32_t reg = e32_uint32_t(0, 6, pow - 1) |
			e32_int(29, 1, 1) | e32_int(31, 1, 1);
	BUG_ON(pow < 11); /* SIZE==b001011 --> 4KB */
	BUG_ON(pow > 33); /* SIZE==b100010 --> 16GB */
	BUG_ON(!is_power_of_2(wqpr_size));
	BUG_ON(b->irreversible_settings_are_done);
	ONLY_ONCE(b, WQPR);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_WQPR_BARE, wqpr_bare);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_WQPR_BAR, wqpr_bar);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_WQPR_AR, reg);
}

/* BA is (SWP_BAR,0,32) - Base address (27 ls-bits are expected to be zero)
 * EBA is (SWP_BARE,0,32) - Extended base address
 */
void qbman_block_set_swp_bar(struct qbman_block *b, uint32_t swp_bare, uint32_t swp_bar)
{
	BUG_ON(b->irreversible_settings_are_done);
	ONLY_ONCE(b, SWP);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_BARE, swp_bare);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_BAR, swp_bar);
}

/* BA is (SWP_BAR_CP_MEM,0,32) - Base address (26 ls-bits are expected
 *					       to be zero)
 * EBA is (SWP_BARE_CP_MEM,0,32) - Extended base address
 */
void qbman_block_set_swp_bar_cp_mem(struct qbman_block *b,
				    uint32_t swp_bare_cp_mem,
				    uint32_t swp_bar_cp_mem)
{
	BUG_ON(b->irreversible_settings_are_done);
	ONLY_ONCE(b, SWP_CP_MEM);
	qbman_swp_cp_mem = ((uint64_t)swp_bare_cp_mem << 32) |
				(uint64_t)swp_bar_cp_mem;
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_BARE_CP_MEM, swp_bare_cp_mem);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_BAR_CP_MEM, swp_bar_cp_mem);
}

/* Support for the per-SWP settings */

/* SWP_IDX is (SWP_CCSR_IDX,0,10) - Software portal index
 */
static void lock_swp_idx(struct qbman_block *b, int idx)
{
	uint32_t reg;
	uint32_t timeout = 10000;
	BUG_ON(!b->irreversible_settings_are_done);
	BUG_ON(idx < 0);
	do {
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_CCSR_IDX_LOCK);
		if (reg & 0x01)
			goto grant_lock;
	} while(timeout--);
	pr_info("Breaking the CCSR_IDX lock register!\n");
grant_lock:
	reg = e32_int(0, 10, idx);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_CCSR_IDX, reg);
}
static void unlock_swp_idx(struct qbman_block *b)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_CCSR_IDX_LOCK, 0x1);
}

/*
 * IDX is (CEETM_CFG_IDX, 0, 4) - DCP portal index
 * IID is (CEETM_CFG_IDX, 4, 2) - CEETM Instance ID
 */
static void lock_ceetm_cfg_idx(struct qbman_block *b,
				unsigned int idx, unsigned int iid)
{
	uint32_t reg;
	uint32_t timeout = 10000;
	BUG_ON(!b->irreversible_settings_are_done);
	do {
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_CEETM_CFG_IDX_LOCK);
		if (reg & 0x01)
			goto grant_lock;
	} while(timeout--);
	pr_info("Breaking the CEETM_CFG_IDX lock register!\n");
grant_lock:
	reg = e32_uint32_t(0, 4, idx) | e32_uint32_t(4, 2, iid);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_CEETM_CFG_IDX, reg);
}

static void unlock_ceetm_cfg_idx(struct qbman_block *b)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_CEETM_CFG_IDX_LOCK, 0x1);
}

/*
 * IDX is (WQ_CH_CFG_IDX, 0, 12) - Channel index
 */
static void lock_wq_ch_cfg_idx(struct qbman_block *b,
				unsigned int chid)
{
	uint32_t reg;
	uint32_t timeout = 10000;
	BUG_ON(!b->irreversible_settings_are_done);
	do {
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_WQ_CH_CFG_IDX_LOCK);
		if (reg & 0x01)
			goto grant_lock;
	} while(timeout--);
	pr_info("Breaking the WQ_CH_CFG_IDX lock register!\n");
grant_lock:
	reg = e32_uint32_t(0, 12, chid);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_WQ_CH_CFG_IDX, reg);
}

static void unlock_wq_ch_cfg_idx(struct qbman_block *b)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_WQ_CH_CFG_IDX_LOCK, 0x1);
}

/* ICID is (SWP_CCSR_CFG,0,15) - Isolation context ID
 * PL is (SWP_CCSR_CFG,15,1) - Privilege level
 * SDEST is (SWP_CCSR_CFG,16,8) - Stashing destination
 * SS is (SWP_CCSR_CFG,24,1) - SDEST source
 * VA is (SWP_CCSR_CFG,28,1) - Virtual address
 * BDI is (SWP_CCSR_CFG,29,1) - Bypass DPAA resource isolation
 * E is (SWP_CCSR_CFG,31,1) - Portal enable
 */
#define SAVECODE_SWP_GET_CFG(type, name, lsoffset, width) \
	do { \
		uint32_t reg; \
		lock_swp_idx(b, idx); \
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_CCSR_CFG); \
		*name = d32_##type(lsoffset, width, reg); \
		unlock_swp_idx(b); \
	} while (0)
void qbman_block_get_swp_icid(struct qbman_block *b,
			      int idx, uint16_t *icid)
{
	SAVECODE_SWP_GET_CFG(uint16_t, icid, 0, 15);
}
void qbman_block_get_swp_iobypass(struct qbman_block *b,
				  int idx, int *iobypass)
{
	SAVECODE_SWP_GET_CFG(int, iobypass, 15, 1);
}
void qbman_block_get_swp_sdest(struct qbman_block *b,
			       int idx, uint8_t *sdest)
{
	SAVECODE_SWP_GET_CFG(uint8_t, sdest, 16, 8);
}
void qbman_block_get_swp_ss(struct qbman_block *b, int idx, uint8_t *ss)
{
	SAVECODE_SWP_GET_CFG(uint8_t, ss, 24, 1);
}
void qbman_block_get_swp_va(struct qbman_block *b,
			    int idx, int *va)
{
	SAVECODE_SWP_GET_CFG(int, va, 28, 1);
}
void qbman_block_get_swp_isolated(struct qbman_block *b,
				  int idx,
				  int *isolated)
{
	SAVECODE_SWP_GET_CFG(int, isolated, 29, 1);
	*isolated = !*isolated; /* Need to invert sense for this field */
}
void qbman_block_get_swp_enabled(struct qbman_block *b,
				 int idx,
				 int *enabled)
{
	SAVECODE_SWP_GET_CFG(int, enabled, 31, 1);
}
#define SAVECODE_SWP_SET_CFG(type, name, lsoffset, width) \
	do { \
		uint32_t reg; \
		lock_swp_idx(b, idx); \
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_CCSR_CFG); \
		reg = r32_##type(lsoffset, width, reg) | \
			e32_##type(lsoffset, width, name); \
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_CCSR_CFG, reg); \
		if ((qman_version & 0xFFFF0000) >= QMAN_REV_4100) \
			qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_WAS_CFG, 0x8000); \
		if ((qman_version & 0xFFFF0000) >= QMAN_REV_5000) \
			qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_AMQ_CFG, 0x8000); \
		unlock_swp_idx(b); \
	} while (0)
void qbman_block_set_swp_icid(struct qbman_block *b,
			      int idx, uint16_t icid)
{
	SAVECODE_SWP_SET_CFG(uint16_t, icid, 0, 15);
}
void qbman_block_set_swp_iobypass(struct qbman_block *b,
				  int idx, int iobypass)
{
	SAVECODE_SWP_SET_CFG(int, iobypass, 15, 1);
}
void qbman_block_set_swp_sdest(struct qbman_block *b,
			       int idx, uint8_t sdest)
{
	SAVECODE_SWP_SET_CFG(uint8_t, sdest, 16, 8);
}
void qbman_block_set_swp_ss(struct qbman_block *b, int idx, uint8_t ss)
{
	SAVECODE_SWP_SET_CFG(uint8_t, ss, 24, 1);
}
void qbman_block_set_swp_va(struct qbman_block *b,
			    int idx, int va)
{
	SAVECODE_SWP_SET_CFG(int, va, 28, 1);
}
void qbman_block_set_swp_isolated(struct qbman_block *b,
				  int idx, int isolated)
{
	isolated = !isolated; /* Need to invert sense for this field */
	SAVECODE_SWP_SET_CFG(int, isolated, 29, 1);
}

#ifdef QBMAN_TEST
static inline int qbman_write_eqcr_indicator(void *ccsr_reg_bar,
					int index,
					int enabled)
{
	uint32_t shadow[16];
	int loop;
	int loopvar = MAX_TRYS;
	uint32_t reg = e32_uint32_t(0, 12, 0) | e32_int(12, 1, 0) |
		e32_int(16, 10, index) | e32_int(28, 1, 1) |
		e32_int(29, 1, 1) | e32_int(31, 1, 1);
	if (!enabled)
		return;
	memset(shadow, 0, sizeof(uint32_t) * 16);
	shadow[1] = 0xdeadbeef;
	/* Copy 64 bytes to the 16 32-bit registers */
	for (loop = 0; loop < 16; loop++)
		qbman_ccsr_write(ccsr_reg_bar, QBMAN_CCSR_ACCESS_DATA(loop),
			shadow[loop]);
	qbman_ccsr_write(ccsr_reg_bar, QBMAN_CCSR_ACCESS_CMD, reg);
	do {
		if (loopvar-- < 1)
			return -EIO;
		reg = qbman_ccsr_read(ccsr_reg_bar, QBMAN_CCSR_ACCESS_CMD);
	} while (d32_int(31, 1, reg));
}
#endif

int qbman_block_set_swp_enabled(struct qbman_block *b,
				 int idx, int enabled)
{
	int ret = 0;
	SAVECODE_SWP_SET_CFG(int, enabled, 31, 1);
#ifdef QBMAN_TEST
	ret = (qbman_write_eqcr_indicator(b->desc->ccsr_reg_bar,
					idx, enabled));
#endif
	return ret;
}

/* ADDR is (QBMAN_CCSR_SWP_INT_MSG_BAR,0,32) - address
 * EADDR is (QBMAN_CCSR_SWP_INT_MSG_BARE,0,32) - extended address
 */
static void _qbman_block_set_msi_address(struct qbman_block *b, int idx,
				 uint32_t msi_bare, uint32_t msi_bar)
{
	if ((qman_version & 0xFFFF0000) >= QMAN_REV_4100)
		lock_swp_idx(b, idx);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_INT_MSG_BARE, msi_bare);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_INT_MSG_BAR, msi_bar);
	if ((qman_version & 0xFFFF0000) >= QMAN_REV_4100)
		unlock_swp_idx(b);
}


static uint32_t unique_msi_bare = (uint32_t) - 1;
static uint32_t unique_msi_bar = (uint32_t) - 1;

int qbman_block_set_msi_address(struct qbman_block *b, int idx,
				 uint32_t msi_bare, uint32_t msi_bar)
{
	/* Versions previous to qman_4.1 require setting an unique msi address */
	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		if (unique_msi_bare == (uint32_t) - 1 || unique_msi_bar == (uint32_t) - 1) {
			unique_msi_bare = msi_bare;
			unique_msi_bar = msi_bar;
			_qbman_block_set_msi_address( b, idx, msi_bare, msi_bar);
		} else if (msi_bare != unique_msi_bare || msi_bar != unique_msi_bar){
			pr_err("DPIO requires a constant MSI address");
			return -EINVAL;
		}
	} else {
		_qbman_block_set_msi_address( b, idx, msi_bare, msi_bar);
	}

	return 0;
}

/* INT_MSG is (SWP_INT_MSG,0,16) - interrupt messsage payload
 */
void qbman_block_get_swp_msi_data(struct qbman_block *b, int idx, uint16_t *data)
{
	uint32_t reg;
	lock_swp_idx(b, idx);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_INT_MSG);
	*data = d32_uint16_t(0, 16, reg);
	unlock_swp_idx(b);
}
void qbman_block_set_swp_msi_data(struct qbman_block *b, int idx, uint16_t data)
{
	uint32_t reg;
	lock_swp_idx(b, idx);
	reg = e32_uint16_t(0, 16, data);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_INT_MSG, reg);
	unlock_swp_idx(b);
}

/* E is (SWP_SDQMRn,16,1) - Enable
 * CHAN is (SWP_SDQMRn,0,12) - Channel ID
 */
void qbman_block_get_swp_channel(struct qbman_block *b,
				 int idx, uint8_t sdqmr_idx,
				 int *enabled, uint16_t *channel_id)
{
	uint32_t reg;
	BUG_ON(sdqmr_idx > 15);
	lock_swp_idx(b, idx);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_SDQMR(sdqmr_idx));
	*channel_id = d32_uint16_t(0, 12, reg);
	*enabled = d32_int(16, 1, reg);
	unlock_swp_idx(b);
}
void qbman_block_set_swp_channel(struct qbman_block *b,
				 int idx, uint8_t sdqmr_idx,
				 int enabled, uint16_t channel_id)
{
	uint32_t reg;
	BUG_ON(sdqmr_idx > 15);
	lock_swp_idx(b, idx);
	reg = e32_uint16_t(0, 12, channel_id) | e32_int(16, 1, !!enabled);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_SDQMR(sdqmr_idx), reg);
	unlock_swp_idx(b);
}

void qbman_block_get_swp_srcid_map(struct qbman_block *b, int idx,
				   uint8_t *srcid, uint8_t *sdest)
{
	uint32_t reg;

	lock_swp_idx(b, idx);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_SRCID_MAP);
	*srcid = d32_uint8_t(0, 8, reg);
	*sdest = d32_uint8_t(8, 8, reg);
	unlock_swp_idx(b);
}

void qbman_block_set_swp_srcid_map(struct qbman_block *b, int idx,
				   uint8_t srcid, uint8_t sdest)
{
	uint32_t reg;

	lock_swp_idx(b, idx);
	reg = e32_uint8_t(0, 8, srcid) | e32_uint8_t(8, 8, sdest);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_SRCID_MAP, reg);
	unlock_swp_idx(b);
}

#ifdef MC_CLI
int qbman_block_swp_cinh_write(struct qbman_block *b, int idx, uint32_t offset,
				    uint32_t val)
{
	int loopvar = MAX_TRYS;
	uint32_t reg = e32_uint32_t(0, 12, offset);
		reg|= e32_int(12, 1, 1);
		reg |=	e32_uint32_t(16, 10, idx);
		reg |= e32_int(29, 1, 1);
		reg |=e32_int(31, 1, 1);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_ACCESS_DATA(0), val);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_ACCESS_CMD, reg);
	do {
		if (loopvar-- < 1)
			return -EIO;
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_ACCESS_CMD);
	} while (d32_int(31, 1, reg));
}
uint32_t qbman_block_swp_cinh_read(struct qbman_block *b, int idx, uint32_t offset)
{
    int loopvar = MAX_TRYS;
	uint32_t reg = e32_uint32_t(0, 12, offset);
	reg|= e32_int(12, 1, 1);
	reg |=	e32_uint32_t(16, 10, idx);
	reg |= e32_int(29, 1, 0);
	reg |=	e32_int(31, 1, 1);

	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_ACCESS_CMD, reg);
	do {
		if (loopvar-- < 1)
			return NULL;
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_ACCESS_CMD);
	} while (d32_int(31, 1, reg));
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_ACCESS_DATA(0));
	return reg;
}
int qbman_block_swp_cena_write(struct qbman_block *b, int idx, uint32_t offset,
				    uint32_t *val)
{
    const uint32_t *shadow = val;
	unsigned int loop;
	int loopvar = MAX_TRYS;
	uint32_t reg = e32_uint32_t(0, 12, offset);
	reg|= e32_int(12, 1, 0);
	reg|= e32_uint32_t(16, 10, idx);
	reg|= e32_int(29, 1, 1);
	reg|= e32_int(31, 1, 1);

	/* Copy 64 bytes to the 16 32-bit registers */
	for (loop = 0; loop < 16; loop++)
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_ACCESS_DATA(loop),
				 shadow[loop]);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_ACCESS_CMD, reg);
	do {
		if (loopvar-- < 1)
			return -EIO;
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_ACCESS_CMD);
	} while (d32_int(31, 1, reg));
}
int qbman_block_swp_cena_read(struct qbman_block *b, int idx, uint32_t offset,
				    uint32_t *val)
{
    uint32_t *shadow = val;
	unsigned int loop;
	int loopvar = MAX_TRYS;
	uint32_t reg = e32_uint32_t(0, 12, offset);
	reg|= e32_int(12, 1, 0);
	reg|= e32_uint32_t(16, 10, idx);
    reg|= e32_int(29, 1, 0);
	reg|= e32_int(31, 1, 1);

	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_ACCESS_CMD, reg);
	do {
		if (loopvar-- < 1)
			return -EIO;
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_ACCESS_CMD);
	} while (d32_int(31, 1, reg));
	/* Copy 64 bytes out of the 16 32-bit registers */
	for (loop = 0; loop < 16; loop++)
		shadow[loop] = qbman_ccsr_read(b->ccsr,
					       QBMAN_CCSR_ACCESS_DATA(loop));
}
#endif

/* E is (SWP_INT_CFGn,31,1) - Enable
 * SWP_IDX is (SWP_INT_CFGn,0,10) - Software Portal Index
 */
void qbman_block_get_non_msi_portal(struct qbman_block *b, unsigned int irq_idx,
				    unsigned int *swp_idx, int *enabled)
{
	uint32_t reg;
	BUG_ON(irq_idx > 3);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_INT_CFG(irq_idx));
	*swp_idx = d32_uint16_t(0, 10, reg);
	*enabled = d32_int(31, 1, reg);
}
void qbman_block_set_non_msi_portal(struct qbman_block *b, unsigned int irq_idx,
				    unsigned int swp_idx, int enabled)
{
	uint32_t reg;
	BUG_ON(irq_idx > 3);
	reg = e32_uint16_t(0, 10, (uint16_t)swp_idx) | e32_int(31, 1, !!enabled);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_INT_CFG(irq_idx), reg);
}

/* R is (SWP_CCSR_CFG,30,1) - Portal reset
 */
int qbman_block_reset_swp(struct qbman_block *b, int idx)
{
	uint32_t reg = e32_int(30, 1, 1);
	int loopvar = MAX_TRYS, ret = 0;
	lock_swp_idx(b, idx);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_CCSR_CFG, reg);
	do {
		if (loopvar-- < 1) {
			ret= -EIO;
			break;
		}
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_CCSR_CFG);
	} while (d32_int(30, 1, reg));
	unlock_swp_idx(b);
	return ret;
}

/* Per-DCP attributes of the block. These will have sane defaults. */
void qbman_block_get_shaper_prescalar(struct qbman_block *b,
					unsigned int idx,
					unsigned int iid,
					uint16_t *pres)
{
	uint32_t reg;
	lock_ceetm_cfg_idx(b, idx, iid);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_CEETM_CFG_PRES);
	*pres = d32_uint16_t(0, 16, reg);
	unlock_ceetm_cfg_idx(b);
}

void qbman_block_set_shaper_prescalar(struct qbman_block *b,
					unsigned int idx,
					unsigned int iid,
					uint16_t pres)
{
	uint32_t reg = e32_int(0, 15, pres);
	lock_ceetm_cfg_idx(b, idx, iid);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_CEETM_CFG_PRES, reg);
	unlock_ceetm_cfg_idx(b);
}

void qbman_block_set_init_rerr(struct qbman_block *b)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_RERR_ISDR, 0);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_RERR_ISR, 0xffffffff);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_RERR_IER, 0xffffffff);
}

void qbman_block_set_init_rerr_fqid(struct qbman_block *b, uint32_t fqid)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_RERR_REL_FQID, fqid);
}

void qbman_block_set_init_nrerr(struct qbman_block *b)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_NRERR_ISDR, 0);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_NRERR_ISR, 0xffffffff);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_NRERR_IER, 0xffffffff);
}

void qbman_block_set_rerr_status(struct qbman_block *b, uint32_t status)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_RERR_ISR, status);
}

uint32_t qbman_block_get_rerr_status(struct qbman_block *b)
{
	return qbman_ccsr_read(b->ccsr, QBMAN_CCSR_RERR_ISR);
}

void qbman_block_set_rerr_enable(struct qbman_block *b, uint32_t enable)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_RERR_IER, enable);
}

uint32_t qbman_block_get_rerr_enable(struct qbman_block *b)
{
	return qbman_ccsr_read(b->ccsr, QBMAN_CCSR_RERR_IER);
}

void qbman_block_set_nrerr_status(struct qbman_block *b, uint32_t status)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_NRERR_ISR, status);
}

uint32_t qbman_block_get_nrerr_status(struct qbman_block *b)
{
	return qbman_ccsr_read(b->ccsr, QBMAN_CCSR_NRERR_ISR);
}

void qbman_block_set_nrerr_enable(struct qbman_block *b, uint32_t enable)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_NRERR_IER, enable);
}

uint32_t qbman_block_get_nrerr_enable(struct qbman_block *b)
{
	return qbman_ccsr_read(b->ccsr, QBMAN_CCSR_NRERR_IER);
}

void qbman_block_set_wq_ch_cdan(struct qbman_block *b,
				uint16_t chid,
				unsigned int bdi,
				uint16_t wqid,
				uint16_t vchid)
{
	uint32_t reg;

	lock_wq_ch_cfg_idx(b, chid);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_WQ_CH_CDAN_CFG);
	reg = i32_int(30, 1, reg) | e32_int(0, 15, wqid) | e32_int(16, 12, vchid) |
			e32_int(31, 1, !!bdi);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_WQ_CH_CDAN_CFG, reg);
	unlock_wq_ch_cfg_idx(b);
}

void qbman_block_get_wq_ch_cdan(struct qbman_block *b,
				uint16_t chid,
				unsigned int *bdi,
				uint16_t *wqid,
				uint16_t *vchid)
{
	uint32_t reg;
	lock_wq_ch_cfg_idx(b, chid);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_WQ_CH_CDAN_CFG);
	*wqid = d32_uint16_t(0, 15, reg);
	*vchid = d32_uint16_t(16, 12, reg);
	*bdi = (reg >> 31) & 0x1;
	unlock_wq_ch_cfg_idx(b);
}

void qbman_block_enable_wq_ch_cdan(struct qbman_block *b,
				   uint16_t chid, int enable)
{
	uint32_t reg;
	lock_wq_ch_cfg_idx(b, chid);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_WQ_CH_CDAN_CFG);
	reg = r32_int(30, 1, reg ) | e32_int(30, 1, !!enable);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_WQ_CH_CDAN_CFG, reg);
	unlock_wq_ch_cfg_idx(b);
}

void qbman_block_get_qman_version(struct qbman_block *b)
{
	uint32_t ip_rev1, ip_rev2;
	ip_rev1 = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_QMAN_IP_REV_1);
	ip_rev2 = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_QMAN_IP_REV_2);
	qman_version = (uint32_t)((((ip_rev1 & 0xFFFF) << 16) |
					(ip_rev2 & 0xFFFF)));
}

uint16_t qbman_block_get_max_pres(struct qbman_block *b)
{
	if ((qman_version & 0xFFFF0000) <= QMAN_REV_4101) {
		return 11915;
	} else if ((qman_version & 0xFFFF0000) <= QMAN_REV_5000) {
		return 13312;
	} else {
		pr_info("Should define the max prescaler value for this version\n");
		return 0;
	}
}

uint32_t qbman_block_get_version(void)
{
	return qman_version;
}

uint64_t qbman_block_get_cp_mem_paddr(void)
{
	return qbman_swp_cp_mem;
}

/* Dynamic Debug configuration */
void qbman_block_set_qman_dd_cfg(struct qbman_block *b,
				 int m_mode, uint8_t m_dd_code,
				 uint16_t m_cfg)
{
	uint32_t reg;

	reg = e32_uint16_t(0, 16, m_cfg) | e32_uint8_t(16, 4, m_dd_code) |
	      e32_int(20, 1, !!m_mode);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_QMAN_DD_CFG, reg);
}

void qbman_block_get_qman_dd_cfg(struct qbman_block *b,
				 int *l_mode, int *full,
				 int *m_mode, uint8_t *m_dd_code,
				 uint16_t *m_cfg)
{
	uint32_t reg;

	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_QMAN_DD_CFG);
	if (l_mode)
		*l_mode = d32_int(31, 1, reg);
	if (full)
		*full = d32_int(30, 1, reg);
	if (m_mode)
		*m_mode = d32_int(20, 1, reg);
	if (m_dd_code)
		*m_dd_code = d32_uint8_t(16, 4, reg);
	if (m_cfg)
		*m_cfg = d32_uint16_t(0, 16, reg);
}

/* Support for the per-SWP DD settings */
/* TP0 is (SWP_DD_CFG,0,8) - Trace point 0 configuration
 * TP1 is (SWP_DD_CFG,8,8) - Trace point 1 configuration
 * EMDD is (SWP_DD_CFG,16,4) - Enquer Marking DD code
 * EM is (SWP_DD_CFG,20,1) - Enqueue Marking
 */
#define SAVECODE_SWP_SET_DD_CFG(type, name, lsoffset, width) \
	do { \
		uint32_t reg; \
		lock_swp_idx(b, idx); \
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_DD_CFG); \
		reg = r32_##type(lsoffset, width, reg) | \
			e32_##type(lsoffset, width, name); \
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_DD_CFG, reg); \
		unlock_swp_idx(b); \
	} while (0)

#define SAVECODE_SWP_GET_DD_CFG(type, name, lsoffset, width) \
	do { \
		uint32_t reg; \
		lock_swp_idx(b, idx); \
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_DD_CFG); \
		*name = d32_##type(lsoffset, width, reg); \
		unlock_swp_idx(b); \
	} while (0)

void qbman_block_set_swp_dd_em(struct qbman_block *b,
			       int idx, int em, uint8_t emdd, int emm)
{
	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		SAVECODE_SWP_SET_DD_CFG(int, !!em, 20, 1);
		if (em)
			SAVECODE_SWP_SET_DD_CFG(uint8_t, emdd, 16, 4);
	} else {
		SAVECODE_SWP_SET_DD_CFG(int, !!em, 28, 1);
		if (em) {
			SAVECODE_SWP_SET_DD_CFG(uint8_t, emdd, 12, 4);
			SAVECODE_SWP_SET_DD_CFG(uint8_t, !!emm, 29, 1);
		}
	}
}

void qbman_block_get_swp_dd_em(struct qbman_block *b,
			       int idx, int *em, uint8_t *emdd, int *emm)
{
	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		SAVECODE_SWP_GET_DD_CFG(int, em, 20, 1);
		SAVECODE_SWP_GET_DD_CFG(uint8_t, emdd, 16, 4);
	} else {
		SAVECODE_SWP_GET_DD_CFG(int, em, 28, 1);
		SAVECODE_SWP_GET_DD_CFG(uint8_t, emdd, 12, 4);
		SAVECODE_SWP_GET_DD_CFG(int, emm, 29, 1);
	}
}

void qbman_block_set_swp_dd_tp(struct qbman_block *b, int idx,
			       int tp_idx, uint8_t tp_cmpv, uint8_t tp_mask,
			       uint32_t tp_config_flag, int tp_type)
{
	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		if (tp_idx) {
			SAVECODE_SWP_SET_DD_CFG(int, tp_type, 15, 1);
			SAVECODE_SWP_SET_DD_CFG(uint8_t, tp_cmpv, 8, 4);
			SAVECODE_SWP_SET_DD_CFG(uint8_t,
				parse_tp_config(tp_config_flag), 12, 3);
		} else {
			SAVECODE_SWP_SET_DD_CFG(int, tp_type, 7, 1);
			SAVECODE_SWP_SET_DD_CFG(uint8_t, tp_cmpv, 0, 4);
			SAVECODE_SWP_SET_DD_CFG(uint8_t,
				parse_tp_config(tp_config_flag), 4, 3);
		}
	} else {
		if (tp_idx) {
			SAVECODE_SWP_SET_DD_CFG(int, tp_type, 27, 1);
			SAVECODE_SWP_SET_DD_CFG(uint8_t, tp_mask, 20, 4);
			SAVECODE_SWP_SET_DD_CFG(uint8_t, tp_cmpv, 16, 4);
			SAVECODE_SWP_SET_DD_CFG(uint8_t,
				parse_tp_config(tp_config_flag), 24, 3);
		} else {
			SAVECODE_SWP_SET_DD_CFG(int, tp_type, 11, 1);
			SAVECODE_SWP_SET_DD_CFG(uint8_t, tp_mask, 4, 4);
			SAVECODE_SWP_SET_DD_CFG(uint8_t, tp_cmpv, 0, 4);
			SAVECODE_SWP_SET_DD_CFG(uint8_t,
				parse_tp_config(tp_config_flag), 8, 3);
		}
	}
}

void qbman_block_get_swp_dd_tp(struct qbman_block *b, int idx,
			       int tp_idx, uint8_t *tp_cmpv, uint8_t *tp_mask,
			       uint8_t *tp_cfg, int *tp_type)
{
	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		if (tp_idx) {
			SAVECODE_SWP_GET_DD_CFG(int, tp_type, 15, 1);
			SAVECODE_SWP_GET_DD_CFG(uint8_t, tp_cmpv, 8, 4);
			SAVECODE_SWP_GET_DD_CFG(uint8_t, tp_cfg, 12, 3);
		} else {
			SAVECODE_SWP_GET_DD_CFG(int, tp_type, 7, 1);
			SAVECODE_SWP_GET_DD_CFG(uint8_t, tp_cmpv, 0, 4);
			SAVECODE_SWP_GET_DD_CFG(uint8_t, tp_cfg, 4, 3);
		}
	} else {
		if (tp_idx) {
			SAVECODE_SWP_GET_DD_CFG(int, tp_type, 27, 1);
			SAVECODE_SWP_GET_DD_CFG(uint8_t, tp_mask, 20, 4);
			SAVECODE_SWP_GET_DD_CFG(uint8_t, tp_cmpv, 16, 4);
			SAVECODE_SWP_GET_DD_CFG(uint8_t, tp_cfg, 24, 3);
		} else {
			SAVECODE_SWP_GET_DD_CFG(int, tp_type, 11, 1);
			SAVECODE_SWP_GET_DD_CFG(uint8_t, tp_mask, 4, 4);
			SAVECODE_SWP_GET_DD_CFG(uint8_t, tp_cmpv, 0, 4);
			SAVECODE_SWP_GET_DD_CFG(uint8_t, tp_cfg, 8, 3);
		}
	}
}

/* SWP_DD_IDX is (SWP_CCSR_IDX, 5, 5) - Software portal index
 */
static void lock_swp_dd_idx(struct qbman_block *b, int idx)
{
	uint32_t reg;
	uint32_t timeout = 10000;
	BUG_ON(!b->irreversible_settings_are_done);
	BUG_ON(idx < 0);
	do {
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_DD_IDX_LOCK);
		if (reg & 0x01)
			goto grant_lock;
	} while (timeout--);
	pr_info("Breaking the SWP_DD_IDX lock register!\n");
grant_lock:
	reg = e32_int(5, 5, idx);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_DD_IDX, reg);
}
static void unlock_swp_dd_idx(struct qbman_block *b)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_DD_IDX_LOCK, 0x1);
}

int qbman_block_swp_ihr_is_asserted(struct qbman_block *b, int idx)
{
	uint32_t reg;
	int group_idx = idx / 32;

	lock_swp_dd_idx(b, group_idx);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_DD_IHRSR);
	unlock_swp_dd_idx(b);
	return (int)(reg >> (idx % 32)) & 1;
}

void qbman_block_swp_ihr_clear(struct qbman_block *b, int idx)
{
	uint32_t reg;
	int group_idx = idx / 32;

	lock_swp_dd_idx(b, group_idx);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_DD_IHRSR);
	reg |= e32_int(((uint32_t)idx % 32), 1, 1);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_DD_IHRSR, reg);
	unlock_swp_dd_idx(b);
}

void qbman_block_swp_ihrf_set(struct qbman_block *b, int idx)
{
	uint32_t reg;
	int group_idx = idx / 32;

	lock_swp_dd_idx(b, group_idx);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_DD_IHRFR);
	reg |= e32_int(((uint32_t)idx % 32), 1, 1);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_SWP_DD_IHRFR, reg);
	unlock_swp_dd_idx(b);
}

int qbman_block_swp_is_in_halted_state(struct qbman_block *b, int idx)
{
	uint32_t reg;
	int group_idx = idx / 32;

	lock_swp_dd_idx(b, group_idx);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_SWP_DD_HASR);
	unlock_swp_dd_idx(b);
	return (int)(reg >> (idx % 32)) & 1;
}

/*
 * DCP_IDX is (DCP_CFG_IDX, 0, 4) - DCP portal index
 * SPID is (DCP_CFG_IDX, 8, 6) - Subportal ID
 */
static void lock_dcp_cfg_idx(struct qbman_block *b,
			     uint16_t idx, uint16_t spid)
{
	uint32_t reg;
	uint32_t timeout = 10000;
	BUG_ON(!b->irreversible_settings_are_done);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_DCP_CFG_IDX_LOCK, 0x1);
	do {
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_DCP_CFG_IDX_LOCK);
		if (reg & 0x01)
			goto grant_lock;
	} while (timeout--);
	pr_info("Breaking the DCP_CFG_IDX lock register!\n");
grant_lock:
	reg = e32_uint16_t(0, 4, idx) | e32_uint16_t(8, 6, spid);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_CEETM_CFG_IDX, reg);
}

static void unlock_dcp_cfg_idx(struct qbman_block *b)
{
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_DCP_CFG_IDX_LOCK, 0x1);
}

void qbman_block_set_dcp_dd_tp(struct qbman_block *b,
			       uint16_t idx, int tp_idx, uint8_t tp_cmpv,
			       uint8_t tp_mask, uint32_t tp_config_flag)
{
	uint8_t tp;
	uint32_t reg;

	lock_dcp_cfg_idx(b, idx, 0);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_DCP_DD_CFG);
	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		tp = (parse_tp_config(tp_config_flag) << 4) | (tp_cmpv & 0xF);
		if (tp_idx)
			reg = r32_uint8_t(8, 7, reg) | e32_uint8_t(8, 7, tp);
		else
			reg = r32_uint8_t(0, 7, reg) | e32_uint8_t(0, 7, tp);
	} else {
		if (tp_idx)
			reg = r32_uint16_t(16, 12, reg) |
				e32_uint8_t(16, 4, tp_cmpv) |
				e32_uint8_t(20, 4, tp_mask) |
				e32_uint8_t(24, 3,
					parse_tp_config(tp_config_flag));
		else
			reg = r32_uint16_t(0, 12, reg) |
				e32_uint8_t(0, 4, tp_cmpv) |
				e32_uint8_t(4, 4, tp_mask) |
				e32_uint8_t(8, 3,
					parse_tp_config(tp_config_flag));
	}
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_DCP_DD_CFG, reg);
	unlock_dcp_cfg_idx(b);
}
void qbman_block_get_dcp_dd_tp(struct qbman_block *b,
			       uint16_t idx, int tp_idx, uint8_t *tp_cmpv,
			       uint8_t *tp_mask, uint8_t *tp_cfg)
{
	uint32_t reg;
	uint8_t tp;

	lock_dcp_cfg_idx(b, idx, 0);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_DCP_DD_CFG);
	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		if (tp_idx)
			tp = d32_uint8_t(8, 7, reg);
		else
			tp = d32_uint8_t(0, 7, reg);
		*tp_cmpv = tp & 0xF;
		*tp_cfg = (tp >> 4) & 0x7;
	} else {
		if (tp_idx) {
			*tp_cmpv = d32_uint8_t(16, 4, reg);
			*tp_mask = d32_uint8_t(20, 4, reg);
			*tp_cfg = d32_uint8_t(24, 3, reg);
		} else {
			*tp_cmpv = d32_uint8_t(0, 4, reg);
			*tp_mask = d32_uint8_t(4, 4, reg);
			*tp_cfg = d32_uint8_t(8, 3, reg);
		}
	}
	unlock_dcp_cfg_idx(b);
}

int qbman_block_dcp_ihr_is_asserted(struct qbman_block *b, int idx)
{
	uint32_t reg;

	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_DCP_DD_IHRSR);
	return (int)(reg >> idx) & 1;
}

void qbman_block_dcp_ihr_clear(struct qbman_block *b, int idx)
{
	uint32_t reg;

	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_DCP_DD_IHRSR);
	reg |= e32_int((uint32_t)idx, 1, 1);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_DCP_DD_IHRSR, reg);
}
void qbman_block_dcp_ihrf_set(struct qbman_block *b, int idx)
{
	uint32_t reg;

	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_DCP_DD_IHRFR);
	reg |= e32_int((uint32_t)idx, 1, 1);
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_DCP_DD_IHRFR, reg);
}
int qbman_block_dcp_is_in_halted_state(struct qbman_block *b, int idx)
{
	uint32_t reg;

	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_DCP_DD_HASR);
	return (int)(reg >> idx) & 1;
}

/* WQ_CH_DD_CFG */
void qbman_block_set_wq_ch_dd_tp(struct qbman_block *b,
				 uint16_t chid, int tp_idx, uint8_t tp_cmpv,
				 uint8_t tp_mask, uint32_t tp_config_flag)
{
	uint8_t tp;
	uint32_t reg;

	lock_wq_ch_cfg_idx(b, chid);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_WQ_CH_DD_CFG);
	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		tp = (parse_tp_config(tp_config_flag) << 4) | (tp_cmpv & 0xF);
		if (tp_idx)
			reg = r32_uint8_t(8, 7, reg) | e32_uint8_t(8, 7, tp);
		else
			reg = r32_uint8_t(0, 7, reg) | e32_uint8_t(0, 7, tp);
	} else {
		if (tp_idx)
			reg = r32_uint16_t(16, 12, reg) |
				e32_uint8_t(16, 4, tp_cmpv) |
				e32_uint8_t(20, 4, tp_mask) |
				e32_uint8_t(24, 3,
					parse_tp_config(tp_config_flag));
		else
			reg = r32_uint16_t(0, 12, reg) |
				e32_uint8_t(0, 4, tp_cmpv) |
				e32_uint8_t(4, 4, tp_mask) |
				e32_uint8_t(8, 3,
					parse_tp_config(tp_config_flag));
	}
	qbman_ccsr_write(b->ccsr, QBMAN_CCSR_WQ_CH_DD_CFG, reg);
	unlock_wq_ch_cfg_idx(b);
}

void qbman_block_get_wq_ch_dd_tp(struct qbman_block *b,
				 uint16_t chid, int tp_idx,  uint8_t *tp_cmpv,
				 uint8_t *tp_mask, uint8_t *tp_cfg)
{
	uint32_t reg;

	lock_wq_ch_cfg_idx(b, chid);
	reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_WQ_CH_DD_CFG);
	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		if (tp_idx) {
			*tp_cmpv = d32_uint8_t(8, 4, reg);
			*tp_cfg = d32_uint8_t(12, 3, reg);
		} else {
			*tp_cmpv = d32_uint8_t(0, 4, reg);
			*tp_mask = d32_uint8_t(4, 3, reg);
		}
	} else {
		if (tp_idx) {
			*tp_cmpv = d32_uint8_t(16, 4, reg);
			*tp_mask = d32_uint8_t(20, 4, reg);
			*tp_cfg = d32_uint8_t(24, 3, reg);
		} else {
			*tp_cmpv = d32_uint8_t(0, 4, reg);
			*tp_mask = d32_uint8_t(4, 4, reg);
			*tp_cfg = d32_uint8_t(8, 3, reg);
		}
	}
	unlock_wq_ch_cfg_idx(b);
}

/* Configure the CEETM_DD_CFG */
int qbman_block_set_ceetm_dd_cfg(struct qbman_block *b,
				 unsigned int idx, unsigned int iid,
				 uint16_t dct_idx, int tp_idx,
				 uint8_t tp_cmpv, uint8_t tp_mask,
				 uint32_t tp_config_flag)
{
	uint32_t reg;
	int cpend, loopvar = MAX_TRYS, ret = 0;

	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		pr_err("This register is not support for < QMan_4.1\n");
		return -EINVAL;
	}
	reg = e32_uint16_t(16, 12, dct_idx) | e32_int(12, 1, tp_idx) |
		e32_uint8_t(8, 3, parse_tp_config(tp_config_flag)) |
		e32_uint8_t(4, 4, tp_mask) | e32_uint8_t(0, 4, tp_cmpv);
	lock_ceetm_cfg_idx(b, idx, iid);
	while (!(qbman_ccsr_read(b->ccsr, QBMAN_CCSR_CEETM_DD_CFG) >> 31)) {
		/* Start the configure command */
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_CEETM_DD_CFG, reg);
	}
	/* poll cpend to see whether configure command is completed */
	do {
		if (loopvar-- < 1) {
			ret = -EIO;
			break;
		}
		cpend = (int)(qbman_ccsr_read(b->ccsr,
				QBMAN_CCSR_CEETM_DD_CFG) >> 31);
	} while (cpend);
	unlock_ceetm_cfg_idx(b);
	return ret;
}

int qbman_block_get_ceetm_dd_cfg(struct qbman_block *b,
				 unsigned int idx, unsigned int iid,
				 uint16_t dct_idx,
				 int tp_idx, uint8_t *tp_cmpv,
				 uint8_t *tp_mask, uint8_t *tp_cfg)
{
	uint32_t reg;
	int cpend, loopvar = MAX_TRYS, ret = 0;

	if ((qman_version & 0xFFFF0000) < QMAN_REV_4100) {
		pr_err("This register is not support for < QMan_4.1\n");
		return -EINVAL;
	}
	lock_ceetm_cfg_idx(b, idx, iid);
	reg = e32_int(30, 1, 1) | e32_uint16_t(16, 12, dct_idx) |
		e32_int(12, 1, tp_idx);

	while (!(qbman_ccsr_read(b->ccsr, QBMAN_CCSR_CEETM_DD_CFG) >> 31)) {
		/* Start the query command */
		qbman_ccsr_write(b->ccsr, QBMAN_CCSR_CEETM_DD_CFG, reg);
	}
	/* poll cpend to see whether query command is completed */
	do {
		if (loopvar-- < 1) {
			ret = -EIO;
			break;
		}
		reg = qbman_ccsr_read(b->ccsr, QBMAN_CCSR_CEETM_DD_CFG);
		cpend = (int)(reg >> 31) & 1;
	} while (cpend);
	unlock_ceetm_cfg_idx(b);
	if (cpend)
		return ret;
	*tp_cmpv = d32_uint8_t(0, 4, reg);
	*tp_mask = d32_uint8_t(4, 4, reg);
	*tp_cfg = d32_uint8_t(8, 3, reg);
	return ret;
}

void qbman_block_set_disable_interrupts(struct qbman_block *b,
				 int disable_interrupts) {
	b->disable_interrupts = disable_interrupts;
}

int qbman_block_get_disable_interrupts(struct qbman_block *b) {
	return b->disable_interrupts;
}
