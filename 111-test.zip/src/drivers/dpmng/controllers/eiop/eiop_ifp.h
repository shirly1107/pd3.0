/*
 * Copyright 2013-2020 NXP
 */

#ifndef __EIOP_IFP_H
#define __EIOP_IFP_H

#include "fsl_types.h"
#include "fsl_eiop_ifp.h"

/**************************************************************************//**
 @Description   Definition of valid ranges
*//***************************************************************************/
#define EIOP_IFP_MAX_NUM_OF_FQIDS		0xffffff
#define EIOP_IFP_MAX_NUM_OF_FBPS		8
#define EIOP_IFP_MAX_FBP_SIZE			0x3ff
#define EIOP_IFP_MAX_BPID				0x3fff
#define EIOP_IFP_MAX_NUM_OF_REPLIC_IDS	0xffff
#define EIOP_IFP_MAX_NUM_OF_QDIDS		0xffff
#define EIOP_IFP_MAX_NUM_OF_PARSER_PROFILE_IDS 0x7ff
#define EIOP_IFP_MAX_NUM_OF_POLICER_PROFILE_IDS 0xffff
#define EIOP_IFP_MAX_NUM_OF_TBL_IDS 	0xffff
#define EIOP_IFP_MAX_NUM_OF_DPKG_PROFILE_IDS 0xff
#define EIOP_IFP_MAX_NUM_OF_ICIDS		0x7fff
#define EIOP_IFP_DEFCFG_RX_BUF_LAYOUT_DHR 0xfff
#define EIOP_IFP_DEFCFG_RX_BUF_LAYOUT_BEM 0x1ff
/**************************************************************************//**
 @Description   Definition of default values
*//***************************************************************************/

#define DEFAULT_IFP_MNG_CMND                4
#define IFP_MNG_CMND_RING_ENTRY_SIZE        32

#define DEFAULT_IFP_FRM_LENGTH              2
#define DEFAULT_IFP_FRM_ANNOT_CASHE_ATTR    E_DMA_NO_STASH
#define DEFAULT_IFP_HDR_CACHE_ATTR          E_DMA_NO_STASH
#define DEFAULT_IFP_SG_CACHE_ATTR           E_DMA_NO_STASH
#define DEFAULT_IFP_SG_DIS                  0
#define DEFAULT_IFP_SG_WRT_OPT              0

#define DEFAULT_IFP_RX_LO_FAS               0
#define DEFAULT_IFP_RX_LO_TS                0
#define DEFAULT_IFP_RX_LO_AD                0
#define DEFAULT_IFP_RX_LO_PR                0
#define DEFAULT_IFP_RX_LO_SWO              	0
#define DEFAULT_IFP_RX_LO_PRIV_DATA_SIZE    64
#define DEFAULT_IFP_RX_LO_DATA_ALIGM        4
#define DEFAULT_IFP_TX_LO_DATA_ALIGM        4
#define EIOP_IFP_PTA_SIZE				    64

#define DEFAULT_IFP_NUM_OF_RX_BP_POOLS		0


#define DEFAULT_IFP_TX_LO_FAS               0
#define DEFAULT_IFP_TX_LO_ICFD              0
#define DEFAULT_IFP_TX_LO_AD                0
#define DEFAULT_IFP_TX_CONF_LO_FAS          0
#define DEFAULT_IFP_TX_CONF_LO_FAS          0
#define DEFAULT_IFP_TX_MODE	0
#define DEFAULT_IFP_RX_MODE	0
#define DEFAULT_ERRORS_TO_DISCARD		EIOP_IFP_ERR_KS | 			\
										EIOP_IFP_ERR_EOF | 			\
										EIOP_IFP_ERR_MNL | 			\
										EIOP_IFP_ERR_TID | 			\
										EIOP_IFP_ERR_PIE | 			\
										EIOP_IFP_ERR_FL | 			\
										EIOP_IFP_ERR_FP | 			\
										EIOP_IFP_ERR_PARSER_CL| 	\
										EIOP_IFP_ERR_PARSER_ISF | 	\
										EIOP_IFP_ERR_PARSER_HDR | 	\
										EIOP_IFP_ERR_PARSER_BL | 	\
										EIOP_IFP_ERR_PARSER_L3C | 	\
										EIOP_IFP_ERR_PARSER_L4C

#define ERRORS_LIMIT_DROP				EIOP_IFP_ERR_PIE | 			\
										EIOP_IFP_ERR_FL
										


/**************************************************************************//**
 @Description   Definition of frame annotation internal data structure
*//***************************************************************************/
#define FA_STATUS_TS_INDX   0
#define FA_FIRST_INDX       FA_STATUS_TS_INDX
#define FA_PR_INDX          FA_STATUS_TS_INDX + 1
#define FA_INGR_AD_INDX     FA_PR_INDX + 1
#define FA_SWOPAQUE_INDX    FA_INGR_AD_INDX+1
#define FA_EGGR_AD_INDX     FA_SWOPAQUE_INDX + 1
#define FA_ICFD_INDX        FA_EGGR_AD_INDX + 1
#define FA_NUM_INDXS        FA_ICFD_INDX+1

#define FA_STATUS_TS_OFFSET 0
#define FA_STATUS_TS_SIZE   16

#define FA_PR_OFFSET        0x10
#define FA_PR_SIZE          48

#define FA_INGR_AD_OFFSET   0x40
#define FA_INGR_AD_SIZE     16

#define FA_SWOPAQUE_OFFSET       0x50
#define FA_SWOPAQUE_SIZE         8

#define FA_EGGR_AD_OFFSET   0x58
#define FA_EGGR_AD_SIZE     8

#define FA_ICFD_OFFSET      0x60
#define FA_ICFD_SIZE        32


/**************************************************************************//**
 @Description   Definition for registers
*//***************************************************************************/
#define EIOP_IFP_ICID_MASK 		0x00007fff
#define EIOP_IFP_SPFF_ASAR_UNITS 	64
#define EIOP_IFP_BMP_BUFFER_POOL_SIZE_UNITS 	64
#define EIOP_IFP_SPFF_ASAR_MASK			0x000f0000

#define EIOP_IFP_FA_FASV_INGR        	0x80000000
#define EIOP_IFP_FA_EADV_INGR        	0x40000000
#define EIOP_IFP_FA_PRV_INGR        	0x20000000
#define EIOP_IFP_FA_IADV_INGR       	0x10000000
#define EIOP_IFP_FA_SWOV_INGR        	0x08000000
#define EIOP_IFP_FA_ICFDV_INGR      	0x04000000

#define EIOP_IFP_FA_FASV_EGGR        	0x00000080
#define EIOP_IFP_FA_EADV_EGGR        	0x00000040
#define EIOP_IFP_FA_PRV_EGGR        	0x00000020
#define EIOP_IFP_FA_IADV_EGGR       	0x00000010
#define EIOP_IFP_FA_SWOV_EGGR        	0x00000008
#define EIOP_IFP_FA_ICFDV_EGGR      	0x00000004

#define EIOP_IFP_FAS_DISC				0x80000000
#define EIOP_IFP_IEIFQID_FDOVR			0x80000000

#define EIOP_IFP_IEBM_SGD               0x80000000
#define EIOP_IFP_IEMBPI_BPV             0x00000001
#define EIOP_IFP_IEMBPI_BP              0x00000002
#define EIOP_IFP_IEMBPI_SR				0x00000020
#define EIOP_IFP_IEMBPI_BMT				0x80000000
#define EIOP_IFP_EMCHAN_MCV             0x10000000
#define EIOP_IFP_IFSPFF_PTAR			0x00800000
#define EIOP_IFP_IFSPFF_VA				0x04000000
#define EIOP_IFP_IFSPFF_FF				0x20000000
#define EIOP_IFP_FSDM_DISCV				0x80000000
#define EIOP_IFP_ICID_BDI				0x00008000
#define EIOP_IFP_ICID_PL				0x00040000
#define EIOP_IFP_ICID_BPAS				0x00020000
#define EIOP_IFP_ICID_WOPT				0x00100000
#define EIOP_IFP_ICID_FPC_STASH			0x00080000
#define EIOP_IFP_ICID_FAC_STASH			0x00800000
#define EIOP_IFP_ICID_FHC_STASH			0x00400000
#define EIOP_IFP_ICID_SGC_STASH			0x00200000

#define EIOP_IFP_EXT_RX_SKIP_PARSER	0x00004000
#define EIOP_IFP_EXT_RX_SKIP_POLICER	0x00002000
#define EIOP_IFP_EXT_RX_SKIP_QoS_MAP 	0x00001000
#define EIOP_IFP_EXT_RX_SKIP_POLICY  	0x00000800
#define EIOP_IFP_EXT_RX_SKIP_LK		0x00000400
#define EIOP_IFP_EXT_RX_SKIP_HASH_GEN 	0x00000200

#define EIOP_IFP_EXT_TX_SKIP_PARSER 	0x00004000
#define EIOP_IFP_EXT_PARSER_PROFILE_ID_MASK     0x000007ff
#define EIOP_IFP_EXT_TX_SKIP_POLICER 	0x00002000
#define EIOP_IFP_EXT_TX_SKIP_QoS_MAP 	0x00001000
#define EIOP_IFP_EXT_TX_SKIP_POLICY	0x00000800
#define EIOP_IFP_EXT_TX_SKIP_LK 	0x00000400
#define EIOP_IFP_EXT_TX_SKIP_HASH_GEN 	0x00000200

#define EIOP_IFP_EXT_PARSER_L3CSV			0x00001000
#define EIOP_IFP_EXT_PARSER_L4CSV			0x00000800
#define EIOP_IFP_RX_EXT_TKIDV			0x40000000
#define EIOP_IFP_RX_EXT_HKIDV			0x80000000
#define EIOP_IFP_TX_EXT_TKIDV			0x00000004
#define EIOP_IFP_RX_EXT_QoS_BASED_ON_VLAN	0x00000040
#define EIOP_IFP_RX_EXT_QoS_BASED_ON_IP		0x00000080
#define EIOP_IFP_RX_EXT_IPRE			0x00000020

#define EIOP_IFP_EXT_RX_SC_SET		0x00001000
#define EIOP_IFP_EXT_RX_FLC_TYPE_MASK	0x0000e000
#define EIOP_IFP_EXT_RX_FLC_TYPE_AIOP	0x00002000
#define EIOP_IFP_EXT_RX_FLC_TYPE_GPP		0x00004000
#define EIOP_IFP_EXT_RX_FLC_TYPE_PASSTHRU	0x00008000
#define EIOP_IFP_EXT_RX_OPAQUEV		0x10000000
#define EIOP_IFP_MAX_SIZE_OF_OPAQUE_VALUE	64
#define EIOP_IFP_EXT_INGR_POLICY_PROFILE_ID_SHIFT	16
#define EIOP_IFP_EXT_INGR_DPTBL_ID_SHIFT		16
#define EIOP_IFP_EXT_INGR_DPKG_PROFILE_ID_SHIFT	8
#define EIOP_IFP_EXT_INGR_POLICER_PROFILE_ID_SHIFT	16
#define EIOP_IFP_EXT_EGR_DPTBL_ID_SHIFT		16
#define EIOP_IFP_EXT_EGR_DPTBL_ID_MASK		0xffff0000
#define EIOP_IFP_EXT_EGR_DPKG_PROFILE_ID_SHIFT	8
#define EIOP_IFP_EXT_EGR_DPKG_PROFILE_ID_MASK	0x0000ff00
#define EIOP_IFP_EXT_EGR_PARSER_START_HXS_SHIFFT		13
#define EIOP_IFP_EXT_EGR_PARSER_START_HXS_MASK 0x00ffe000
#define EIOP_IFP_EXT_EGR_PARSER_START_OFFSET_SHIFFT	24
#define EIOP_IFP_EXT_INGR_PARSER_START_HXS_SHIFFT		13
#define EIOP_IFP_EXT_INGR_PARSER_START_HXS_MASK 0x00ffe000
#define EIOP_IFP_EXT_INGR_PARSER_START_OFFSET_SHIFFT	24



#define EIOP_IFP_IVMODE_VLAN_ACTION_MASK	0x0000000f
#define EIOP_IFP_IVMODE_VLAN_ACTION_COND_INSERT		0x00000002
#define EIOP_IFP_IVMODE_VLAN_ACTION_INSERT		0x00000001
#define EIOP_IFP_IVMODE_COND_INSERT_ETHYPE_NOT_FOUND_SHIFT	16

#define EIOP_IFP_EVMODE_VLAN_ACTION_MASK		0x00c00000
#define EIOP_IFP_EVMODE_VLAN_ACTION_REMOVE		0x00400000
#define EIOP_IFP_EVMODE_VLAN_ACTION_UPDATE_QOS	0x00800000
#define EIOP_IFP_EVMODE_VLAN_ACTION_INSERT		0x00c00000

/**************************************************************************//**
 @Description   Definition shifts and masks for registers
*//***************************************************************************/
#define EIOP_IFP_IEBM_OFFSET_SHIFT 	16
#define EIOP_IFP_IFSPFF_ASAR_SHIFT 	16
#define EIOP_IFP_IEBMPI_BPID_SHIFT 	16
#define EIOP_IFP_IEBMPI_PBS_SHIFT 	6
#define EIOP_IFP_IQDID_FA_SHIFT 	24
#define EIOP_IFP_EMCHAN_MCHAN_SHIFT 	24

#define MC_ENTRY_SIZE           	16


#define EIOP_IFP_INGR_EN             	0x80000000
#define EIOP_IFP_EGGR_EN             	0x40000000
#define EIOP_IFP_INGR_BSY				0x80000000
#define EIOP_IFP_EGGR_BSY				0x80000000
#define EIOP_IFP_INGR_EBC				0x00000FFF
#define EIOP_IFP_EGGR_EBC				0x00000FFF




/**************************************************************************//**
 @Description   Management Commands Definitions
*//***************************************************************************/
#define IFP_CMD_MNG_INDEX_REG_NEGATIVE_OFFSET 	0x1c0


	/**************************************************************************//**

 @Group         MNG_CMD_runtime_grp Management Commands Runtime  API

 @Description   Management Commands Initialization functions, definitions and enums

 @{
*//***************************************************************************/


#define MNG_CMD_INPUT_MSG_MAX_SIZE		256
#define IFMICID_ICID_MASK				0x7FF
#define IFMICID_VA					0x00010000
#define IFMICID_PL					0x00040000
#define IFMICID_BMT					0x00020000

#define MNG_CMD_DESC_FLC_SYNC			0x02000000
#define MNG_CMD_DESC_FLC_IE			0x01000000
#define MNG_CMD_DESC_FLC			0x00110000


#define MNG_CMD_DESC_FRC_MGCF			0x80000000
#define MNG_CMD_DESC_FRC_MGINV			0x40000000
#define MNG_CMD_DESC_FRC_MGCV			0x20000000

#define MNG_CMD_DESC_MAX_MSG_SIZE		0x100

#define MNG_CMD_DESC_ERR_MGCNV			0x00000080
#define MNG_CMD_DESC_ERR_FSE			0x00000020
#define MNG_CMD_DESC_ERR_SBE			0x00000008

#define ILLEGAL_MTYPE 				0x0000FFFF

#define MNG_CMD_DESC_MTYPE_MASK			0x0000FFFF

#if 0
struct mng_cmd_desc {
	uint64_t	ext_addr;			/**< Pointer to input/output message;
	                                     Optional, depending on command. */
	uint32_t	res0;
	uint32_t	length;				/**< Message length - up to 256 bytes */
	uint8_t		res1[3];				/**< Output errors. */
	uint8_t		err;				/**< Output errors. */
	uint16_t	status;
	uint16_t	mem_attr;
	uint32_t	mtype_params;
	uint16_t	misc;
	uint16_t	mtype;
};

struct mng_cmd_desc {
	uint32_t	ext_addr_h;			/**< Pointer to input/output message;
	                                     Optional, depending on command. */
	uint32_t	ext_addr_l;			/**< Pointer to input/output message;
	                                     Optional, depending on command. */
	uint32_t	res0;
	uint32_t	length;				/**< Message length - up to 256 bytes */
	uint32_t	err;				/**< Output errors. */
	uint32_t	status_mem_attr;
	uint32_t	mtype_params;
	uint32_t	misc_mtype;
};
#endif
struct mng_cmd_desc {
	uint32_t	ext_addr_l;			/**< Pointer to input/output message;
	                                     Optional, depending on command. */
	uint32_t	ext_addr_h;			/**< Pointer to input/output message;
	                                     Optional, depending on command. */
	uint32_t	length;				/**< Message length - up to 256 bytes */
	uint32_t	res0;
	uint32_t	status_mem_attr;
	uint32_t	err;				/**< Output errors. */
	uint32_t	misc_mtype;
	uint32_t	mtype_params;
};
#if 0
struct mng_cmd_desc {
	uint32_t	ext_addr_l;			/**< Pointer to input/output message;
	                                     Optional, depending on command. */
	uint32_t	ext_addr_h;			/**< Pointer to input/output message;
	                                     Optional, depending on command. */
	uint32_t	length;				/**< Message length - up to 256 bytes */
	uint32_t	res0;
	uint32_t	status_mem_attr;
	uint32_t	mtype_params;
	uint32_t	misc_mtype;
	uint32_t	err;				/**< Output errors. */
};
#endif


/**************************************************************************//**
 @Description   Definition of internal data structure
*//***************************************************************************/
enum fa_type {
        E_INGRESS,
        E_EGRESS
};

enum layout_type {
	E_LAYOUT_RX,
	E_LAYOUT_TX
};
struct tmp_buff_layout {
    uint16_t offset;
    uint16_t size;
    int     user_def;
};




#ifndef VERIFICATION_SUPPORT
enum dma_cache {
        E_DMA_NO_STASH = 0,     /**< Cacheable, no Allocate (No Stashing) */
        E_DMA_STASH = 1         /**< Cacheable and Allocate (Stashing on) */
};
#endif


struct eiop_ifp {
     void *regs;
};




/**************************************************************************//**
 @Description   Definition of registers
*//***************************************************************************/
struct eiop_ifp_ext_regs {
	uint32_t cidef0_rx_policy_id_skip_qos_map;
	uint32_t cidef1_rx_tid_kid_hkid;
	uint32_t cidef2_rx_plid;
	uint32_t cidef3_parser;
	uint32_t cidef4_replic_id_qdid;
	uint32_t cidef5_info;
	uint32_t cidef6_opaque_high;
	uint32_t cidef6_opaque_low;
	uint32_t cedef0_tx_info1_skip_info2;
	uint32_t cedef1_tid_kid_res;
	uint32_t cedef2_parser;
};

struct eiop_ifp_regs {
	uint8_t ifp_extension[0x40];
	uint32_t ifpmcr;
	uint32_t ifibsy;
	uint32_t ifebsy;
	uint8_t  res[0x1b4];
        uint32_t ifpv;
        uint32_t reserved204;
        uint32_t ifml;
        uint32_t debug;
        uint32_t reserved210[4];
        uint32_t ifiomb;
        uint32_t ifiqdid;
        uint32_t ifiqdbin;
        uint32_t reserved21c;
        uint32_t ifivlan;
        uint32_t ifivmode;
        uint32_t reserved238[2];
        uint32_t ififsdm;
        uint32_t ififseqm;
        uint32_t ififsem;
        uint32_t ifisvm;
        uint32_t ifiefqid;
        uint32_t reserved254[7];
        uint32_t ifmcrsiz;
        uint32_t ifmicid;
        uint32_t ifmcaddh;
        uint32_t ifmcaddl;
        uint32_t ingress_fch;
        uint32_t ingress_fcl;
        uint32_t ingress_bch;
        uint32_t ingress_bcl;
        uint32_t ingress_ffch;
        uint32_t ingress_ffcl;
        uint32_t ingress_fdch;
        uint32_t ingress_fdcl;
        uint32_t ingress_mfch;
        uint32_t ingress_mfcl;
        uint32_t ingress_mbch;
        uint32_t ingress_mbcl;
        uint32_t ingress_bfch;
        uint32_t ingress_bfcl;
        uint32_t ingress_bbch;
        uint32_t ingress_bbcl;
        uint32_t ingress_odch;
        uint32_t ingress_odcl;
        uint32_t reserved2c0[6];
        uint32_t ifera;
        uint32_t ifewa;
        uint32_t ifeefqid;
        uint32_t ifemchan;
        uint32_t ifeqosm;
        uint32_t ifevlan;
        uint32_t ififpid;
        uint32_t reserved2fc;
        uint32_t ifiicid;
        uint32_t reserved304;
        uint32_t ifiebm;
        uint32_t ifispff;
        uint32_t ifebmpp[2];
        uint32_t reserved318[2];
        uint32_t ifebmpi[IFP_MAX_NUM_OF_EXT_POOLS];
        uint32_t reserved340[16];
        uint32_t egress_fch;
        uint32_t egress_fcl;
        uint32_t egress_bch;
        uint32_t egress_bcl;
        uint32_t egress_fdch;
        uint32_t egress_fdcl;
        uint32_t egress_sptdch;
        uint32_t egress_sptdcl;
        uint32_t egress_mfch;
        uint32_t egress_mfcl;
        uint32_t egress_mbch;
        uint32_t egress_mbcl;
        uint32_t egress_bfch;
        uint32_t egress_bfcl;
        uint32_t egress_bbch;
        uint32_t egress_bbcl;
        uint32_t egress_cfch;
        uint32_t egress_cfcl;

};
#endif /*__EIOP_IFP_H*/
