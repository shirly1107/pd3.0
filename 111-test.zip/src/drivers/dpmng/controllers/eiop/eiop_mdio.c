/*
 * Copyright 2020 NXP
 */

/**************************************************************************//**
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_malloc.h"
#include "fsl_eiop.h"
#include "fsl_dbg.h"
#include "fsl_platform.h"

#include "eiop_mdio.h"

static uint32_t get_emdio_cfg(struct eiop_emdio_regs *regs)
{
	return ioread32(&regs->emdio_cfg);
}

static void set_emdio_cfg(struct eiop_emdio_regs *regs, uint32_t val)
{
	iowrite32(val, &regs->emdio_cfg);
}

static uint32_t get_emdio_ctl(struct eiop_emdio_regs *regs)
{
	return ioread32(&regs->emdio_ctl);
}

static void set_emdio_ctl(struct eiop_emdio_regs *regs, uint32_t val)
{
	iowrite32(val, &regs->emdio_ctl);
}

static uint32_t get_emdio_addr(struct eiop_emdio_regs *regs)
{
	return ioread32(&regs->emdio_addr);
}

static void set_emdio_addr(struct eiop_emdio_regs *regs, uint32_t val)
{
	iowrite32(val, &regs->emdio_addr);
}

static uint32_t get_emdio_data(struct eiop_emdio_regs *regs)
{
	return ioread32(&regs->emdio_data);
}

static void set_emdio_data(struct eiop_emdio_regs *regs, uint32_t val)
{
	iowrite32(val, &regs->emdio_data);
}

static int restore_hardware(const struct eiop_emdio *eiop_emdio)
{
	struct eiop_emdio_regs *regs;
	uint32_t clkdiv_value;
	uint32_t mdio_cfg;

	regs = eiop_emdio->regs;
	clkdiv_value = EMDIO_CFG_CLKDIV( EMDIO_CFG_CLKDIV_VAL );
	mdio_cfg = EMDIO_CFG;

	/* Verify if CLK_DIV is corect configured and fix if not */
	if((get_emdio_cfg(regs) & EMDIO_CFG_CLKDIV_MASK) != clkdiv_value)
		set_emdio_cfg(regs, mdio_cfg);

	return 0;
}
/*****************************************************************************/
struct eiop_emdio *eiop_emdio_init(const struct mdio_desc *mdio_desc)
{
	struct eiop_emdio *eiop_emdio;

	/* Allocate memory for the MDIO driver parameters */
	eiop_emdio = (struct eiop_emdio *)fsl_malloc(sizeof(struct eiop_emdio));
	if (!eiop_emdio) {
		pr_err("EIOP External MDIO memory allocation failed");
		return NULL;
	}

	memset(eiop_emdio, 0, sizeof(struct eiop_emdio));

	/* Store MDIO parameters in the MDIO control structure */
	eiop_emdio->regs = (struct eiop_emdio_regs *) 
			((int)(mdio_desc->vaddr) + BASE_TO_MII_OFFSET);
	/* MDIO1 -> id = 0 */
	eiop_emdio->id = mdio_desc->id;
	eiop_emdio->enet_if = (enum enet_interface)mdio_desc->enet_if;
	eiop_emdio->eiop_id = mdio_desc->eiop_id;

	return eiop_emdio;
}

int eiop_emdio_restore(const struct eiop_emdio *eiop_emdio)
{
	return restore_hardware(eiop_emdio);
}
