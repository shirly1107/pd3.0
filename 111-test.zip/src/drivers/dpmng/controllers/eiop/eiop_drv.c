/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_soc.h"
#include "fsl_errors.h"
#include "fsl_malloc.h"
#include "fsl_eiop.h"
#include "fsl_eiop_ifp.h"
#include "fsl_eiop_rtc.h"
#include "fsl_eiop_mdio.h"
#include "fsl_ctlu.h"
#include "fsl_platform.h"
#include "fsl_resman.h"
#include "fsl_ctlu.h"
#include "fsl_dpparser.h"
#include "fsl_dptbl.h"
#include "fsl_dppolicy.h"
#include "fsl_dppolicer.h"
#include "fsl_dpkg.h"
#include "fsl_dpqos.h"
#include "fsl_mc.h"
#include "parser_ctrl.h"
#include "fsl_dpmac_mc.h"
#include "fsl_dpsparser_mc.h"
#include "dpmac.h"

int eiop_drv_hardware_restore(void);
int eiop_drv_init(void);

struct eiop_drv {
	uint64_t pfc_buffer;
	void *ctlu_resman_device;
};

static int create_ifps_pool(struct eiop_desc *eiop_desc)
{
	int err = 0;
	struct eiop_ifp_desc ifp_desc;
	uint32_t ifp_cnt = 0;
	struct resman_res_req req;

	/* get number of IFP's to create a resman pool */
	memset(&ifp_desc, 0, sizeof(ifp_desc));
	ifp_desc.eiop_id = eiop_desc->eiop_id;
	while (sys_get_desc(SOC_MODULE_EIOP_IFP, SOC_DB_IFP_DESC_EIOP_ID,
				&ifp_desc, (int *)&ifp_cnt) == 0) ;

	/* Create IFP Pool */
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = ifp_cnt - 1;
	snprintf(req.type, sizeof(req.type), "ifp.wr%d", eiop_desc->eiop_id);
	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(
		sys_get_unique_handle(FSL_MOD_RESMAN), &req))
		!= 0)
		pr_err("DP_RES_TYPE_IFPID");
	return err;
}

static int init_external_mdio(const struct eiop_desc *eiop_desc)
{
	int err = 0, iter = 0;
	struct mdio_desc mdio_desc;
	struct eiop_emdio *eiop_emdio;
	
	memset(&mdio_desc, 0, sizeof(struct mdio_desc));
	mdio_desc.eiop_id = eiop_desc->eiop_id;
	/* The number of external MDIOs depends on platform
	 * MDIO1 -> id = 0
	 * MDIO2 -> id = 1
	 */
	while (sys_get_desc(SOC_MODULE_MDIO, SOC_DB_MDIO_DESC_EIOP_ID,
				&mdio_desc, &iter) == 0)
	{
		eiop_emdio = eiop_emdio_init(&mdio_desc);
		if (!eiop_emdio) {
			pr_err("Failed to init External MDIO[%d]\n", mdio_desc.id);
			return -ENAVAIL;
		}

		err = sys_add_handle(eiop_emdio, FSL_MOD_EIOP_EXT_MDIO, 2,
				mdio_desc.eiop_id, mdio_desc.id);
		CHECK_COND_RETVAL(!err, err, "Cannot add handle for External MDIO[%d]\n", mdio_desc.id);
	}

	return err;
}

static int init_rtc(struct eiop_desc *eiop_desc)
{
	int err = 0;
	struct eiop_rtc *eiop_rtc;
	struct eiop_rtc_desc eiop_rtc_desc;
	struct eiop_rtc_cfg eiop_rtc_cfg;
	struct eiop_rtc_event_cfg periodic_cfg = {0};

	memset(&eiop_rtc_cfg, 0, sizeof(struct eiop_rtc_cfg));
	memset(&eiop_rtc_desc, 0, sizeof(struct eiop_rtc_desc));
	eiop_rtc_desc.eiop_id = eiop_desc->eiop_id;
	err = sys_get_desc(SOC_MODULE_EIOP_RTC, SOC_DB_RTC_DESC_EIOP_ID,
				&eiop_rtc_desc, NULL);
	ASSERT_COND(!err);
	eiop_rtc = eiop_rtc_init(&eiop_rtc_desc, &eiop_rtc_cfg);
	if (!eiop_rtc) {
		pr_err("eiop_rtc_init Failed\n");
		return -ENAVAIL;
	}
	/* set periodic pulse every second */
	periodic_cfg.id = 0;
	periodic_cfg.time = 1000000000;
	periodic_cfg.event_mask = 0x08000000;
	periodic_cfg.disable_intr = 1;
	err = eiop_rtc_set_periodic_pulse(eiop_rtc, &periodic_cfg);
	if (err != 0)
		return err;
	periodic_cfg.id = 1;
	periodic_cfg.time = 0xffffffff;
	periodic_cfg.event_mask = 0x04000000;
	periodic_cfg.disable_intr = 1;
	err = eiop_rtc_set_periodic_pulse(eiop_rtc, &periodic_cfg);
	if (err != 0)
		return err;
	err = eiop_rtc_enable(eiop_rtc, 1);
	if (err != 0)
		return err;

	err = sys_add_handle(eiop_rtc, FSL_MOD_EIOP_RTC, 1,
			eiop_rtc_desc.eiop_id);
	ASSERT_COND(!err);

	return err;
}

static int init_parser(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	struct dpparser_cfg dpparser_cfg;
	struct dpparser *dpparser;
	struct resman_res_req req;
	int err;

	memset(&dpparser_cfg, 0, sizeof(dpparser_cfg));

	dpparser_cfg.ctlu = ctlu;
	dpparser_cfg.cycle_limit = DPPARSER_PCLIM_MAX;
	dpparser_cfg.options = 0;
	dpparser_cfg.num_profiles = ctlu_desc->num_dpparser_profiles;
	dpparser_cfg.options = 0;
	dpparser = dpparser_init(&dpparser_cfg);
	if (dpparser == NULL) {
		pr_err("dpparser_init() failed.\n");
		return -ENODEV;
	}

	sys_add_handle(dpparser, FSL_MOD_PARSER, 2,
	/*iop_id*/ctlu_desc->iop_id,
	               /* CTLU type */ctlu_desc->type);

	/* some SoC's do not have egress CTLU. Ingress is used for both. In order for
	 * devices to be able to get the appropriate handle in both flavors,
	 * we set here the Egress handle as the Ingress handle. */
	if (ctlu_desc->options & CTLU_DESC_OPT_USE_AS_EGRESS)
		sys_add_handle(dpparser,
		               FSL_MOD_PARSER,
		                2, /*iop_id*/
				ctlu_desc->iop_id, /* CTLU type */
				CTLU_EIOP_EGRESS);

	/* Create resman parser profile pool */
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = (uint32_t)ctlu_desc->num_dpparser_profiles;
	dpparser_get_resource_str(dpparser, req.type);
	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(
	        sys_get_unique_handle(FSL_MOD_RESMAN), &req))
	    != 0) {
		pr_err("DP_RES_TYPE_PRPID");
		return err;
	}


	return 0;
}

static int init_policy(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	struct dppolicy_mng_cfg dppolicy_mng_cfg;
	struct dppolicy_mng *dppolicy_mng;
	struct resman_res_req req;
	char str[16];
	int err;

	/* Create resman Policy entries pool */
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = (uint32_t)ctlu_desc->num_dppolicy_entries;
	ctlu_get_str(ctlu_desc->iop_id, ctlu_desc->type, str);
	snprintf(req.type, sizeof(req.type), "plcye.%s", str);

	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(
	        sys_get_unique_handle(FSL_MOD_RESMAN), &req))
	    != 0)
		pr_err("DP_RES_TYPE_POLICY_ENTRY_ID");

	/* Create resman Policies pool */
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = (uint32_t)ctlu_desc->num_dppolicy_entries;
	ctlu_get_str(ctlu_desc->iop_id, ctlu_desc->type, str);
	snprintf(req.type, sizeof(req.type), "plcy.%s", str);
	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(
	        sys_get_unique_handle(FSL_MOD_RESMAN), &req))
	    != 0)
		pr_err("DP_RES_TYPE_POLICY_ID");

	memset(&dppolicy_mng_cfg, 0, sizeof(dppolicy_mng_cfg));

	dppolicy_mng_cfg.ctlu = ctlu;
	dppolicy_mng_cfg.num_dppolicy_entries = ctlu_desc->num_dppolicy_entries;
	dppolicy_mng = dppolicy_mng_init(&dppolicy_mng_cfg);
	if (dppolicy_mng == NULL) {
		pr_err("dppolicy_mng_init() failed.\n");
		return -ENODEV;
	}
	sys_add_handle(dppolicy_mng, FSL_MOD_POLICIES_MNG, 2, /*iop_id*/
	               ctlu_desc->iop_id, /* CTLU type */ctlu_get_type(ctlu));

	return 0;
}


static int init_qos(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	struct dpqos_mng_cfg dpqos_mng_cfg;
	struct dpqos_mng *dpqos_mng;


	memset(&dpqos_mng_cfg, 0, sizeof(dpqos_mng_cfg));

	dpqos_mng_cfg.ctlu = ctlu;
	dpqos_mng = dpqos_mng_init(&dpqos_mng_cfg);
	if (dpqos_mng == NULL) {
		pr_err("dpqos_mng_init() failed.\n");
		return -ENODEV;
	}
	sys_add_handle(dpqos_mng, FSL_MOD_QoS_MNG, 2, /*iop_id*/
	               ctlu_desc->iop_id, /* CTLU type */ctlu_get_type(ctlu));

	return 0;
}



static int init_kg(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	struct dpkg_cfg dpkg_cfg;
	struct dpkg *dpkg;
	struct resman_res_req req;
	int err;

	memset(&dpkg_cfg, 0, sizeof(dpkg_cfg));

	dpkg_cfg.ctlu = ctlu;
	dpkg_cfg.num_profiles = ctlu_desc->num_dpkg_profiles;
	dpkg = dpkg_init(&dpkg_cfg);
	if (dpkg == NULL) {
		pr_err("dpkg_init() failed.\n");
		return -ENODEV;
	}
	sys_add_handle(dpkg, FSL_MOD_KG, 2, /*iop_id*/ctlu_desc->iop_id,
		/* CTLU type */ ctlu_get_type(ctlu));

	/* some SoC's do not have egress CTLU. Ingress is used for both. In order for
	 * devices to be able to get the appropriate handle in both flavors,
	 * we set here the Egress handle as the Ingress handle. */
	if (ctlu_desc->options & CTLU_DESC_OPT_USE_AS_EGRESS)
		sys_add_handle(dpkg,
		               FSL_MOD_KG,
		                2, /*iop_id*/
				ctlu_desc->iop_id, /* CTLU type */
				CTLU_EIOP_EGRESS);

	/* Create resman Keygen profiles pool */
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = (uint32_t)ctlu_desc->num_dpkg_profiles;
	dpkg_get_resource_str(dpkg, req.type);
	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(
	        sys_get_unique_handle(FSL_MOD_RESMAN), &req))
	    != 0)
		pr_err("DP_RES_TYPE_KEY_PROFILE_ID");


	return 0;
}

#ifdef ERR008524
static void wa_ERR008524(struct ctlu_desc *ctlu_desc)
{
	struct dptbl_cfg tbl_cfg;
	struct dptbl_action action;
	struct dptbl *dptbl_peb, *dptbl_int;
	struct dptbl_mng *dptbl_mng;
	struct mem_desc pebm_desc = { 0 };

	if (ctlu_desc->type == CTLU_EIOP_INGRESS) {
		dptbl_mng = (struct dptbl_mng *)sys_get_handle(
			FSL_MOD_TABLES_MNG, 2, /*iop_id*/
			ctlu_desc->iop_id, /* CTLU type */
			ctlu_desc->type);
		ASSERT_COND(dptbl_mng);

		memset(&tbl_cfg, 0, sizeof(tbl_cfg));
		memset(&action, 0, sizeof(action));

		tbl_cfg.type = DPTBL_TYPE_EXACT_MATCH;
		tbl_cfg.mem_type = DPTBL_INT_MEMORY;
		tbl_cfg.options = DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION;
		tbl_cfg.aging_threshold = 0;
		tbl_cfg.action_on_miss = NULL;
		tbl_cfg.max_key_size = 1;
		tbl_cfg.max_rules = 0;
		action.next_action = DPTBL_ACTION_DONE;
		action.options = DPTBL_ACTION_SET_DISCARD_FLAG;
		tbl_cfg.action_on_miss = &action;

		dptbl_int = dptbl_init(dptbl_mng, &tbl_cfg);
		if (!dptbl_int) {
			pr_err("wa_ERR008524 dptbl_init() failed.\n");
			return;
		}

		/* if PEB exists and enabled */
		if ((sys_get_desc(SOC_MODULE_PEBM, 0, &pebm_desc, NULL) == 0) &&
				!pebm_desc.disable)
		{
			/* if PEB used */
			if (!(ctlu_desc->options & CTLU_DESC_OPT_NO_PEBM)) {
				tbl_cfg.mem_type = DPTBL_PEB;
				dptbl_peb = dptbl_init(dptbl_mng, &tbl_cfg);
				if (!dptbl_peb) {
					pr_err("wa_ERR008524 dptbl_init() failed.\n");
					return;
				}
			}
		}
	}
}
#endif /* ERR008524 */

static int init_policer(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	struct dppolicer_cfg dppolicer_cfg;
	struct dppolicer *dppolicer;
	struct resman_res_req req;
	char str[16];
	int err;

	/* Create resman Policer profiles pool */
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = (uint32_t)ctlu_desc->num_dppolicer_profiles;
	ctlu_get_str(ctlu_desc->iop_id, ctlu_desc->type, str);
	snprintf(req.type, sizeof(req.type), "plcr.%s", str);
	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(
	        sys_get_unique_handle(FSL_MOD_RESMAN), &req))
	    != 0)
		pr_err("DP_RES_TYPE_POLICY_ID");

	memset(&dppolicer_cfg, 0, sizeof(dppolicer_cfg));
	dppolicer_cfg.ctlu = ctlu;
	dppolicer_cfg.num_profiles = ctlu_desc->num_dppolicer_profiles;
	dppolicer = dppolicer_init(&dppolicer_cfg);
	if (dppolicer == NULL) {
		pr_err("dppolicer_init() failed.\n");
		return -ENODEV;
	}

	sys_add_handle(dppolicer, FSL_MOD_POLICER, 2,/*iop_id*/
	               ctlu_desc->iop_id, /* CTLU type */ctlu_get_type(ctlu));


	return 0;

}

static void free_ctlu(void *resman_device)
{
	int iter = 0;
	void *handle;
	struct ctlu_desc ctlu_desc;

	memset(&ctlu_desc, 0, sizeof(struct ctlu_desc));
	while (sys_get_desc(SOC_MODULE_CTLU, 0, &ctlu_desc, &iter) == 0) {
		if (!((ctlu_desc.type == CTLU_EIOP_EGRESS) || (ctlu_desc.type == CTLU_EIOP_INGRESS)))
			continue;
		if ((handle = sys_get_handle(FSL_MOD_PARSER, /*num of ids*/2,
		/* iop_id */ctlu_desc.iop_id,
		                             /*ctlu type */ctlu_desc.type))
		    != NULL) {
			dpparser_done((struct dpparser *)handle);
			sys_remove_handle(FSL_MOD_PARSER, 2, /* iop_id */
			                  ctlu_desc.iop_id, /*ctlu type */
			                  ctlu_desc.type);
		}

		if ((handle = sys_get_handle(FSL_MOD_POLICIES_MNG, 2,
		/* iop_id */ctlu_desc.iop_id,
		                             /*ctlu type */ctlu_desc.type))
		    != NULL) {
			dppolicy_mng_done((struct dppolicy_mng *)handle);
			sys_remove_handle(FSL_MOD_POLICIES_MNG, 2,
			/* iop_id */ctlu_desc.iop_id,
			                  /*ctlu type */ctlu_desc.type);
		}


		if ((handle = sys_get_handle(FSL_MOD_QoS_MNG, 2,
		/* iop_id */ctlu_desc.iop_id,
		                             /*ctlu type */ctlu_desc.type))
		    != NULL) {
			dpqos_mng_done((struct dpqos_mng *)handle);
			sys_remove_handle(FSL_MOD_QoS_MNG, 2,
			/* iop_id */ctlu_desc.iop_id,
			          /*ctlu type */ctlu_desc.type);
		}


		if ((handle = sys_get_handle(FSL_MOD_KG, 2,/* iop_id */
		                             ctlu_desc.iop_id, /*ctlu type */
		                             ctlu_desc.type))
		    != NULL) {
			dpkg_done((struct dpkg *)handle);
			sys_remove_handle(FSL_MOD_KG, 2,
			/* iop_id */ctlu_desc.iop_id, /*ctlu type */
			                  ctlu_desc.type);
		}

		if ((handle = sys_get_handle(FSL_MOD_TABLES_MNG, 2,
		/* iop_id */ctlu_desc.iop_id,
		                             /*ctlu type */ctlu_desc.type))
		    != NULL) {
			dptbl_mng_done((struct dptbl_mng *)handle);
			sys_remove_handle(FSL_MOD_TABLES_MNG, 2,/* iop_id */
			                  ctlu_desc.iop_id, /*ctlu type */
			                  ctlu_desc.type);

		}
		if ((handle = sys_get_handle(FSL_MOD_POLICER, 2,/* iop_id */ctlu_desc.iop_id, /*ctlu type */ctlu_desc.type)) != NULL)
		{
			dppolicer_done((struct dppolicer *)handle);
			sys_remove_handle(FSL_MOD_POLICER, 2,/* iop_id */ctlu_desc.iop_id, /*ctlu type */ctlu_desc.type);

		}
		if ((handle = sys_get_handle(FSL_MOD_CTLU, 2, /* iop_id */
		                             ctlu_desc.iop_id, /*ctlu type */
		                             ctlu_desc.type))
		    != NULL) {
			ctlu_done((struct ctlu *)handle);
			sys_remove_handle(FSL_MOD_CTLU, 2,
			/* iop_id */ctlu_desc.iop_id, /*ctlu type */
			                  ctlu_desc.type);

		}
		memset(&ctlu_desc, 0, sizeof(struct ctlu_desc));
	}

	return;

}

static int init_tables(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	struct dptbl_mng_cfg dptbl_mng_cfg;
	struct dptbl_mng *dptbl_mng;
	struct resman_res_req req;
	int err;
	enum ctlu_type type = ctlu_get_type(ctlu);
	char str[16];
	memset(&dptbl_mng_cfg, 0, sizeof(dptbl_mng_cfg));

	/* Create TCAM entries pool */
	if (ctlu_desc->num_dptbl_tcam_entries)
	{
		memset(&req, 0, sizeof(struct resman_res_req));
		req.id_base_align = 0;
		req.num = (uint32_t)ctlu_desc->num_dptbl_tcam_entries;
		ctlu_get_str(ctlu_desc->iop_id, ctlu_desc->type, str);
		snprintf(req.type, sizeof(req.type), "tcame.%s", str);
		req.options |= DPRC_RES_REQ_OPT_EXPLICIT;
	
		if ((err = resman_create_res_pool(
				sys_get_unique_handle(FSL_MOD_RESMAN), &req))
			!= 0) {
			pr_err("DP_RES_TYPE_PRPID");
			return err;
		}
	}
	dptbl_mng_cfg.ctlu = ctlu;
	/* Always TRUE for rev1 due to SR */
	dptbl_mng_cfg.u.l2sw_present = 1;
	dptbl_mng = dptbl_mng_init(&dptbl_mng_cfg);
	if (dptbl_mng == NULL) {
		pr_err("dptbl_mng_init() failed.\n");
		return -ENODEV;
	}

	sys_add_handle(dptbl_mng, FSL_MOD_TABLES_MNG, 2, /*iop_id*/
		               ctlu_desc->iop_id, /* CTLU type */
		               type);
	return 0;
}

static int init_ctlus(const struct eiop_desc *eiop_desc, void *resman_device)
{
	int err = 0, iter = 0;
	struct ctlu_cfg ctlu_cfg;
	struct ctlu *ctlu;
	struct ctlu_desc ctlu_desc;

	memset(&ctlu_desc, 0, sizeof(struct ctlu_desc));
	ctlu_desc.iop_id = eiop_desc->eiop_id;

	while (sys_get_desc(SOC_MODULE_CTLU, SOC_DB_CTLU_DESC_IOP_ID,
				&ctlu_desc, &iter)
		== 0) {
		if (!((ctlu_desc.type == CTLU_EIOP_EGRESS)
			|| (ctlu_desc.type == CTLU_EIOP_INGRESS)))
			continue;

		memset(&ctlu_cfg, 0, sizeof(ctlu_cfg));
		ctlu_cfg.resman_device = resman_device;

		/*******************************************/
		/* initialize CTLU general internal module */
		/*******************************************/
		ctlu = ctlu_init(&ctlu_desc, &ctlu_cfg);
		if (!ctlu) {
			pr_err("ctlu_init() failed.\n");
			return -ENODEV;
		}

		/***********************/
		/* Parser init         */
		/***********************/
		err |= init_parser(ctlu, &ctlu_desc);

		/**********************/
		/* Key generator init */
		/**********************/
		if (!err)
			err |= init_kg(ctlu, &ctlu_desc);

		if (ctlu_desc.type == CTLU_EIOP_INGRESS) {
			/***********************/
			/* Policy manager init */
			/***********************/
			if (!err)
				err |= init_policy(ctlu, &ctlu_desc);
			/***********************/
			/* Tables manager init */
			/***********************/
			if (!err)
				err |= init_tables(ctlu, &ctlu_desc);

			/***********************/
			/* QoS manager init */
			/***********************/
			if (!err)
				err |= init_qos(ctlu, &ctlu_desc);

			/****************/
			/* Policer init */
			/****************/
			if (!err)
				err |= init_policer(ctlu, &ctlu_desc);
		}

		if (err)
			return -ENODEV;

		sys_add_handle(ctlu, FSL_MOD_CTLU, 2, /*iop_id*/
				ctlu_desc.iop_id, /* CTLU type */
				ctlu_desc.type);

		/* some SoC's do not have egress CTLU. Ingress is used for both. In order for
		 * devices to be able to get the appropriate handle in both flavors,
		 * we set here the Egress handle as the Ingress handle. */
		if (ctlu_desc.options & CTLU_DESC_OPT_USE_AS_EGRESS)
			sys_add_handle(ctlu,
			                FSL_MOD_CTLU,
			                2, /*iop_id*/
					ctlu_desc.iop_id, /* CTLU type */
					CTLU_EIOP_EGRESS);

		ctlu_enable(ctlu);
#ifdef ERR009038
		if (!IS_SIM)
			ctlu_wa_ERR009038(ctlu);
#endif /* ERR009038 */
#ifdef ERR008524
		wa_ERR008524(&ctlu_desc);
#endif /* ERR008524 */


#if 0

		if (ctlu_desc.type == CTLU_EIOP_INGRESS) {
			struct dppolicer_profile_cfg dppolicer_profile_cfg;
			struct dpparser *dpparser = (struct dpparser *)sys_get_handle(
				FSL_MOD_PARSER, 2, /* iop_id */ctlu_desc.iop_id, /*ctlu type */
				ctlu_desc.type);
			struct dppolicer *dppolicer = (struct dppolicer *)sys_get_handle(
				FSL_MOD_POLICER, 2, /* iop_id */ctlu_desc.iop_id, /*ctlu type */
				ctlu_desc.type);
			int match;

			dpparser_init_profile(dpparser, 3, NULL, NULL);
			dpparser_enable_sw_seq(dpparser, 3, NULL, NET_PROT_VLAN, 0x1e0);

			dpparser_find_profile(dpparser, NULL, NULL, 0, &match);
			if (match == -1)
			pr_err("dpparser_compare_profile() failed.\n");
			else
			pr_info("dpparser_compare_profile() matched profile %d.\n", match);
			err = dpparser_add_tpid(dpparser, 3, NULL, 0xAAAA);
			if (err)
			pr_err("dpparser_add_tpid(0xAAAA) failed.\n");
			else
			pr_info("dpparser_add_tpid(0xAAAA).\n");

			err = dpparser_add_tpid(dpparser, 3, NULL, 0x5555);
			if (err)
			pr_err("dpparser_add_tpid(0x5555) failed.\n");
			else
			pr_info("dpparser_add_tpid(0x5555).\n");

			err = dpparser_add_tpid(dpparser, 3, NULL, 0x1111);
			if (err)
			{
				pr_info("dpparser_add_tpid(0x1111) failed.\n");
				dpparser_remove_tpid(dpparser, 3, NULL, 0x5555);
				pr_info("dpparser_remove_tpid(0x5555).\n");
				err = dpparser_add_tpid(dpparser, 3, NULL, 0x1111);
				if (err)
				pr_err("Failed to replace TPID.\n");
				else
				pr_info("dpparser_add_tpid(0x1111).\n");
			}
			else
			pr_info("dpparser_add_tpid(0x1111).\n");

			dpparser_remove_tpid(dpparser, 3, NULL, 0);

			dppolicer_profile_cfg.options = DPPOLICER_OPT_COLOR_BLIND |
			DPPOLICER_OPT_KEEP_DROP_PRI |
			DPPOLICER_OPT_DISCARD_RED;

			dppolicer_profile_cfg.alg = DPPPLICER_RFC_2698;
			dppolicer_profile_cfg.default_color = DPPPLICER_GREEN;
			dppolicer_profile_cfg.non_passthrough_cfg.rate_mode = DPPPLICER_BYTE_RATE_MODE;
			dppolicer_profile_cfg.non_passthrough_cfg.comitted_info_rate = 14;
			dppolicer_profile_cfg.non_passthrough_cfg.comitted_burst_size = 240;
			dppolicer_profile_cfg.non_passthrough_cfg.peak_or_eccessive_info_rate = 16;
			dppolicer_profile_cfg.non_passthrough_cfg.peak_or_eccessive_burst_size = 240;
			dppolicer_profile_cfg.non_passthrough_cfg.byte_rate_cfg.frame_len_select = DPPPLICER_FULL_FRM_LEN;
			dppolicer_profile_cfg.non_passthrough_cfg.byte_rate_cfg.rollback_frame_select = DPPPLICER_ROLLBACK_FULL_FRM_LEN;
			dppolicer_profile_cfg.green_drop_pri = 2;
			dppolicer_profile_cfg.yellow_drop_pri = 1;
			dppolicer_profile_cfg.red_drop_pri = 0;

			dppolicer_init_profile(dppolicer, 3, NULL, &dppolicer_profile_cfg);
			dppolicer_find_profile(dppolicer, NULL, NULL, 0, &match);
			if (!match)
			pr_err("dppolicer_compare_profile() failed.\n");
			else
			pr_info("dppolicer_compare_profile() matched profile %d.\n", match);

		}
#endif
	}

	return 0;
}

int eiop_drv_init(void)
{
	struct eiop_cfg cfg;
	int err, iter = 0;;
	struct eiop_desc *eiop_desc;
	struct eiop_drv *eiop_drv;
	void *resman_device;
	const struct memory_partition_list pfc_buff_mem_partitions = {
			.mem_part_ids = {MEM_PART_SYSTEM_DDR2, MEM_PART_SYSTEM_DDR1,
							MEM_PART_LAST /* mark end of list*/ }
	};

	pr_info("Executing eiop_drv_init...\n");

	eiop_desc = (struct eiop_desc *)fsl_malloc(sizeof(struct eiop_desc));
	if (!eiop_desc) {
		pr_err("EIOP descriptor");
		return -ENOMEM;

	}

	memset(eiop_desc, 0, sizeof(struct eiop_desc));

	/* Create a resman device for CTLU resources */
	resman_device = resman_create_mc_device(sys_get_unique_handle(FSL_MOD_RESMAN));

	while (sys_get_desc(SOC_MODULE_EIOP, 0, eiop_desc, &iter) == 0) {

		pr_info("EIOP %d CCSR: 0x%08x%08x\n",iter - 1, UINT32_HI(eiop_desc->paddr), UINT32_LO(eiop_desc->paddr));

		/* Allocate AIOP tile structure */
		eiop_drv = (struct eiop_drv *)fsl_malloc(
			sizeof(struct eiop_drv));
		if (!eiop_drv) {
			pr_err("EIOP structure");
			return -ENOMEM;

		}
		memset((void *)eiop_drv, 0, sizeof(struct eiop_drv));

		eiop_drv->ctlu_resman_device = resman_device;

		memset(&cfg, 0, sizeof(cfg));
		err = fsl_get_mem_mp(eiop_get_temp_pfc_buffer_size(), &pfc_buff_mem_partitions, 64, &cfg.temp_pfc_buffer);

		if ( err ) {
			pr_err("pfc_buffer structure");
			fsl_free(eiop_drv);
			return -ENOMEM;
		}

		eiop_drv->pfc_buffer = cfg.temp_pfc_buffer;
		cfg.temp_pfc_icid = 0;
		err = eiop_init(eiop_desc, &cfg);

		if (!err) {
			/* save EIOP driver handle for freeing process */
			err = sys_add_handle(eiop_drv, FSL_MOD_EIOP, 1,
						eiop_desc->eiop_id);
			ASSERT_COND(!err);
		}
#if 0
		if (!err)
			err = eiop_set_exceptions(&eiop_desc, E_EIOP_STALL_EVENT, 1);

		eiop_force_exceptions(&eiop_desc, E_EIOP_STALL_EVENT);

		if (!err)
			err = eiop_set_exceptions(&eiop_desc, E_EIOP_SYSTEM_BUS_ERROR, 1);

		eiop_force_exceptions(&eiop_desc, E_EIOP_SYSTEM_BUS_ERROR);


#endif
		if (!err)
			/* create IFP's pool */
			err = create_ifps_pool(eiop_desc);

		if ((!err) && (sys_get_desc(SOC_MODULE_EIOP_RTC, 0, NULL, NULL) == 0))
			/* Initialize RTC (1588) timer */
			err = init_rtc(eiop_desc);

		/*********External MDIO init ************************/
		if ((!err) && (sys_get_desc(SOC_MODULE_MDIO, 0, NULL, NULL) == 0))
			err = init_external_mdio(eiop_desc);

		/********* must come after RTC init ************************/

		if (!err)
			/* Initialize CTLU */
			err = init_ctlus(eiop_desc, resman_device);
		if (err) {
			fsl_put_mem(eiop_drv->pfc_buffer);
			fsl_free(eiop_drv);
			return err;
		}
		//memset(eiop_desc, 0, sizeof(struct eiop_desc));
	}

	return 0;
}

#ifdef TKT011436 
static int restore_rtc(struct eiop_desc *eiop_desc) 
{	
	struct eiop_rtc_desc eiop_rtc_desc;
	struct eiop_rtc *eiop_rtc;
	struct eiop_rtc_event_cfg periodic_cfg = { 0 };
	int err = 0;

	pr_debug("Restore 1588\n");
	memset(&eiop_rtc_desc, 0, sizeof(struct eiop_rtc_desc));
	eiop_rtc_desc.eiop_id = eiop_desc->eiop_id;
	err = sys_get_desc(SOC_MODULE_EIOP_RTC, SOC_DB_RTC_DESC_EIOP_ID,
			&eiop_rtc_desc, NULL);
	CHECK_COND_RETVAL(err == 0, err, "Failed to get WRIOP RTC descriptor\n");

	eiop_rtc = (struct eiop_rtc*) sys_get_handle(FSL_MOD_EIOP_RTC, 1,
			eiop_rtc_desc.eiop_id);
	CHECK_COND_RETVAL(eiop_rtc, -ENAVAIL, "Failed to get RTC handle\n");

	err = eiop_rtc_restore_hardware(eiop_rtc);
	CHECK_COND_RETVAL(err == 0, err, "Failed to restore RTC\n");

	/* set periodic pulse every second */
	periodic_cfg.id = 0;
	periodic_cfg.time = 1000000000;
	periodic_cfg.event_mask = 0x08000000; //is already set
	periodic_cfg.disable_intr = 1; //was set before
	err = eiop_rtc_set_periodic_pulse(eiop_rtc, &periodic_cfg);
	CHECK_COND_RETVAL(err == 0, err, "eiop_rtc_set_periodic_pulse failed\n");

	periodic_cfg.id = 1;
	periodic_cfg.time = 0xffffffff;
	periodic_cfg.event_mask = 0x04000000; //is already set
	periodic_cfg.disable_intr = 1; //was set before
	err = eiop_rtc_set_periodic_pulse(eiop_rtc, &periodic_cfg);
	CHECK_COND_RETVAL(err == 0, err, "eiop_rtc_set_periodic_pulse failed\n");

	err = eiop_rtc_enable(eiop_rtc, 1);
	CHECK_COND_RETVAL(err == 0, err, "Failed to enable 1588\n");

	err = rtc_restore_runtime_config(eiop_rtc);
	CHECK_COND_RETVAL(err == 0, err, "Failed to restore runtime config for 1588\n");
	pr_debug("Finish to restore 1588\n");
	return 0;
}

static int restore_policer(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc) {
	struct dppolicer *dppolicer;
	int err;

	pr_debug("Restore policer\n");
	dppolicer = (struct dppolicer *) sys_get_handle(FSL_MOD_POLICER, 2,
									ctlu_desc->iop_id, /*iop_id*/
									ctlu_get_type(ctlu)); /* CTLU type */
	CHECK_COND_RETVAL(dppolicer, -ENAVAIL, "Failed to get dppolicer handle\n");

	err = dppolicer_restore(dppolicer);
	CHECK_COND_RETVAL(err == 0, err, "dppolicer_restore Failed\n");

	return 0;
}

static int restore_qos(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc) {
	struct dpqos_mng_cfg dpqos_mng_cfg;
	struct dpqos_mng *dpqos_mng;
	int err = 0;

	pr_debug("restore QOS\n");
	dpqos_mng = (struct dpqos_mng *) sys_get_handle(FSL_MOD_QoS_MNG, 2,
									ctlu_desc->iop_id, /*iop_id*/
									ctlu_get_type(ctlu));/* CTLU type */
	CHECK_COND_RETVAL(dpqos_mng, -ENAVAIL, "Failed to get dpqos handle\n");

	memset(&dpqos_mng_cfg, 0, sizeof(dpqos_mng_cfg));

	dpqos_mng_cfg.ctlu = ctlu;
	err = dpqos_mng_restore(&dpqos_mng_cfg);
	CHECK_COND_RETVAL(err == 0, err, "dpqos_mng_restore Failed\n");

	return 0;
}

static int restore_tables(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc) {
	struct dptbl_mng_cfg dptbl_mng_cfg;
	struct dptbl_mng *dptbl_mng = NULL;
	int err;
	enum ctlu_type type = ctlu_get_type(ctlu);

	pr_debug("Restore tables\n");
	memset(&dptbl_mng_cfg, 0, sizeof(dptbl_mng_cfg));

	dptbl_mng_cfg.ctlu = ctlu;
	/* Always TRUE for rev1 due to SR */
	dptbl_mng_cfg.u.l2sw_present = 1;

	dptbl_mng = (struct dptbl_mng *) sys_get_handle(FSL_MOD_TABLES_MNG, 2, /*! number of params */
									ctlu_desc->iop_id, /*iop_id*/
									type); /* CTLU type */
	CHECK_COND_RETVAL(dptbl_mng, -ENAVAIL, "Failed to get dptbl_mng handle\n");

	err = dptbl_mng_restore(&dptbl_mng_cfg, dptbl_mng);
	CHECK_COND_RETVAL(err == 0, err, "dptbl_mng_restore Failed\n");

	return err;
}

static int restore_policy(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc)
{
	return 0;
}

static int restore_kg(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc) {
	struct dpkg *dpkg;
	int err = 0;

	pr_debug("Restore KG\n");
	dpkg = (struct dpkg *) sys_get_handle(FSL_MOD_KG, 2, 
							ctlu_desc->iop_id, /* iop_id */
							ctlu_get_type(ctlu));/*ctlu type */
	CHECK_COND_RETVAL(dpkg, -EINVAL, "Failed to get dpkg handle\n");

	err = dpkg_restore(dpkg);
	CHECK_COND_RETVAL(err == 0, err, "dpkg_restore Failed\n");

	return err;
}

static int restore_parser(struct ctlu *ctlu, const struct ctlu_desc *ctlu_desc) {
	struct dpparser_cfg dpparser_cfg;
	int err;
	struct dpparser *dpparser;
	memset(&dpparser_cfg, 0, sizeof(dpparser_cfg));

	dpparser_cfg.ctlu = ctlu;
	dpparser_cfg.cycle_limit = DPPARSER_PCLIM_MAX;
	dpparser_cfg.options = 0;
	dpparser_cfg.num_profiles = ctlu_desc->num_dpparser_profiles;
	dpparser = (struct dpparser *) sys_get_handle(FSL_MOD_PARSER, 2,
									ctlu_desc->iop_id,/*iop_id*/
									ctlu_desc->type);/* CTLU type */
	CHECK_COND_RETVAL(dpparser, -EINVAL, "Cannot get dpparser handle\n");

	err = dpparser_restore(&dpparser_cfg, dpparser);
	CHECK_COND_RETVAL(err == 0, err, "dpparser_restore Failed\n");

	return 0;
}

static int restore_ctlus(const struct eiop_desc *eiop_desc) 
{
	int err = 0, iter = 0;
	struct ctlu *ctlu;
	struct ctlu_desc ctlu_desc;

	pr_debug("Restore CTLUs\n");
	memset(&ctlu_desc, 0, sizeof(struct ctlu_desc));
	ctlu_desc.iop_id = eiop_desc->eiop_id;

	while (sys_get_desc(SOC_MODULE_CTLU, SOC_DB_CTLU_DESC_IOP_ID, &ctlu_desc,
			&iter) == 0) {
		/***********************/
		/* CTLU restore        */
		/***********************/
		/* type specific initialization */
		if (!((ctlu_desc.type == CTLU_EIOP_EGRESS)
				|| (ctlu_desc.type == CTLU_EIOP_INGRESS)))
			continue;
		ctlu = (struct ctlu*) sys_get_handle(FSL_MOD_CTLU, 2, 
								ctlu_desc.iop_id, /* iop_id */
								ctlu_desc.type); /*ctlu type */
		CHECK_COND_RETVAL(ctlu, -ENODEV, "Failed to get CTLU handle\n");

		err = restore_ctlu(&ctlu_desc, ctlu);
		CHECK_COND_RETVAL(err == 0, err, "restore_ctlu Failed\n");

		/***********************/
		/* Parser restore      */
		/***********************/
		err = restore_parser(ctlu, &ctlu_desc);
		CHECK_COND_RETVAL(err == 0, err, "restore_parser Failed\n");

		/***********************/
		/* KG restore      */
		/***********************/
		err = restore_kg(ctlu, &ctlu_desc);
		CHECK_COND_RETVAL(err == 0, err, "restore_kg Failed\n");

		if (ctlu_desc.type == CTLU_EIOP_INGRESS) {

			/***********************/
			/* Policy manager init */
			/***********************/
			err = restore_policy(ctlu, &ctlu_desc);
			CHECK_COND_RETVAL(err == 0, err, "restore_policy Failed\n");

			/***********************/
			/* Tables manager init */
			/***********************/
			err = restore_tables(ctlu, &ctlu_desc);
			CHECK_COND_RETVAL(err == 0, err, "restore_tables Failed\n");

			/***********************/
			/* QoS manager init */
			/***********************/
			err = restore_qos(ctlu, &ctlu_desc);
			CHECK_COND_RETVAL(err == 0, err, "restore_qos Failed\n");

			/****************/
			/* Policer init */
			/****************/
			err = restore_policer(ctlu, &ctlu_desc);
			CHECK_COND_RETVAL(err == 0, err, "restore_policer Failed\n");
		}
		/* only CTLU ingress will be enabled */
		ctlu_enable(ctlu);
	}

	pr_debug("Restore CTLUs finished\n");
	return 0;
}

static int restore_external_mdio(const struct eiop_desc *eiop_desc)
{
	int err = 0, iter = 0;
	struct mdio_desc mdio_desc;
	struct eiop_emdio *eiop_emdio;

	memset(&mdio_desc, 0, sizeof(struct mdio_desc));
	mdio_desc.eiop_id = eiop_desc->eiop_id;
	/* The number of external MDIOs depends on platform
	 * MDIO1 -> id = 0
	 * MDIO2 -> id = 1
	 */
	while (sys_get_desc(SOC_MODULE_MDIO, SOC_DB_MDIO_DESC_EIOP_ID,
				&mdio_desc, &iter) == 0)
	{
		eiop_emdio = (struct eiop_emdio *)sys_get_handle( FSL_MOD_EIOP_EXT_MDIO, 2,
											mdio_desc.eiop_id,  /* EIOP id */
											mdio_desc.id);	/* MDIO id */

		CHECK_COND_RETVAL(eiop_emdio, -ENAVAIL, "Cannot get handle for External MDIO[%d]\n", mdio_desc.id);

		err = eiop_emdio_restore(eiop_emdio);
		CHECK_COND_RETVAL(!err, err, "Cannot restore External MDIO[%d]\n", mdio_desc.id);

	}

	return err;
}

/**************************************************************************//**
 @Function     eiop_drv_hardware_restore
*//***************************************************************************/
int eiop_drv_hardware_restore(void) {
	struct eiop_cfg cfg;
	int err, iter = 0;
	struct eiop_desc eiop_desc;
	struct eiop_drv *eiop_drv;
	struct dpsparser *dpsparser;
	struct dpmng *dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	CHECK_COND_RETVAL(dpmng, -ENODEV, "DPMNG get handle Failed\n");

	pr_info("Executing eiop_drv_hardware_restore...\n");

	err = dpmng_init_management_port(dpmng);
	CHECK_COND_RETVAL(err == 0, err, "dpmng_init_management_port Failed\n");

	err = parser_ctrl_restore();
	CHECK_COND_RETVAL(err == 0, err, "parser_ctrl_restore Failed\n");

	memset(&eiop_desc, 0, sizeof(struct eiop_desc));

	while (sys_get_desc(SOC_MODULE_EIOP, 0, &eiop_desc, &iter) == 0) {

		pr_debug("EIOP %d CCSR: 0x%08x%08x\n", iter - 1, UINT32_HI(eiop_desc.paddr), UINT32_LO(eiop_desc.paddr));

		memset(&cfg, 0, sizeof(cfg));

		eiop_drv = (struct eiop_drv *) sys_get_handle(FSL_MOD_EIOP, 1,
				eiop_desc.eiop_id);
		CHECK_COND_RETVAL(eiop_drv, -ENODEV,
				"FSL_MOD_EIOP get handle Failed\n");
		cfg.temp_pfc_buffer = eiop_drv->pfc_buffer;
		cfg.temp_pfc_icid = 0;

		/* MPIC is already initialized */
		err = eiop_temp_pfc_buffer_restore(&eiop_desc, &cfg);
		CHECK_COND_RETVAL(err == 0, err,
				"eiop_temp_pfc_buffer_restore Failed\n");

		/* create IFP's pool */
		//err = create_ifps_pool(eiop_desc);

		if (sys_get_desc(SOC_MODULE_EIOP_RTC, 0, NULL, NULL) == 0) {
			err = restore_rtc(&eiop_desc);
			CHECK_COND_RETVAL(err == 0, err, "Restore RTC Failed\n");
		}
		
		/* Initially, External MDIOs are configured by Linux driver 
		 * In case of mEMAC errata, MDIO registers will be reset without inform linux driver
		 * In this case MDIO_CFG register have to be restored by MC	
		 */
		if (sys_get_desc(SOC_MODULE_MDIO, 0, NULL, NULL) == 0) {
			err = restore_external_mdio(&eiop_desc);
			CHECK_COND_RETVAL(err == 0, err, "Restore External MDIOs Failed\n");
		}

		/* CTLUs have to be restored after 1588 */
		err = restore_ctlus(&eiop_desc);
		CHECK_COND_RETVAL(err == 0, err, "restore_ctlus Failed\n");
	}

	err = dpmng_post_controllers_restore();
	CHECK_COND_RETVAL(err == 0, err, "dpmng_post_controllers_restore Failed\n");

	/* Get DPSPARSER handle */
	dpsparser = (struct dpsparser *)sys_get_handle(FSL_MOD_DPSPARSER, 1, 1);
	CHECK_COND_RETVAL(dpsparser, -EINVAL, "Cannot get dpsparser handle\n");

	err = dpsparser_restore(dpsparser);
	CHECK_COND_RETVAL(err == 0, err, "dpsparser_restore Failed\n");

	return err;
}
#endif /* TKT011436 */
