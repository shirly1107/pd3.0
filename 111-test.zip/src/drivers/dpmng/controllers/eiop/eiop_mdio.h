/*
 * Copyright 2020 NXP
 */

#ifndef __EIOP_MDIO_H
#define __EIOP_MDIO_H

#include "fsl_types.h"
#include "fsl_enet.h"
#include "fsl_eiop_mdio.h"

/**************************************************************************//**
 @Description   Definition of valid ranges
 *//***************************************************************************/

/* Offset from external MDIO base address in Global memory region. */
#define BASE_TO_MII_OFFSET         0x030

/**************************************************************************//**
 @Description   Definition of default values
 *//***************************************************************************/

/**************************************************************************//**
 @Description   Definition for registers
 *//***************************************************************************/

/*----------------------------------------------------*/
/* MII Configuration Control Memory Map Registers     */
/*----------------------------------------------------*/
struct eiop_emdio_regs {
	uint32_t   emdio_cfg;       /* 0x030  */
	uint32_t   emdio_ctl;      /* 0x034  */
	uint32_t   emdio_data;      /* 0x038  */
	uint32_t   emdio_addr;      /* 0x03c  */
};

/**************************************************************************//**
 @Description   Definition shifts and masks for registers
 *//***************************************************************************/

/* General definitions */

#define EMDIO_CFG_CLKDIV_MASK	 0x0000FF80
#define EMDIO_CFG_CLKDIV(x)      ((((x) >> 1) & 0xff) << 8)
#define EMDIO_CFG_BSY            0x00000001
#define EMDIO_CFG_RD_ER          0x00000002
#define EMDIO_CFG_HOLD_MASK		 0x0000001C
#define EMDIO_CFG_HOLD(x)        (((x) << 2) & (EMDIO_CFG_HOLD_MASK))
#define EMDIO_CFG_ENC45          0x00000040
 /* external MDIO only - driven on neg MDC edge */
#define EMDIO_CFG_NEG            0x00800000

#define EMDIO_CFG_CLKDIV_VAL	258
#define EMDIO_CFG_HOLD_VAL		2

#define EMDIO_CFG \
        (EMDIO_CFG_HOLD( EMDIO_CFG_HOLD_VAL ) | \
         EMDIO_CFG_CLKDIV( EMDIO_CFG_CLKDIV_VAL ) | \
         EMDIO_CFG_NEG)

/**************************************************************************//**
 @Description MDIO FM driver control structure.
 *//***************************************************************************/
struct eiop_emdio {
	struct eiop_emdio_regs *regs;
	int id;
	enum enet_interface enet_if;
	int eiop_id;
};

#endif /* __EIOP_MDIO_H */
