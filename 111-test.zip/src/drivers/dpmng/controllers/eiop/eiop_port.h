/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_eiop_port.h"

/*NOTE - should be defined on ldpaa level*/
#define DONT_CARE 0xffffffff
#define NON_VALID 0xffffffff

#define EIOP_PORT_MAX_NUM_OF_IFPs	0xfff

/**************************************************************************//**
 @Description   Definition shifts and masks for registers
 *//***************************************************************************/
#define EIOP_PORT_PCR_PTY_SHIFT		28
#define EIOP_PORT_PCR_PRT_SHIFT		20
#define EIOP_PORT_PDEF_IFPID_SHIFT	16

/**************************************************************************//**
 @Description   Definition of registers offset
 *//***************************************************************************/
#define EIOP_PORT_EGRESS_OFFSET 	0x2000
#define EIOP_BMI_PORT_INGRESS_OFFSET	0
#define EIOP_BMI_PORT_EGRESS_OFFSET	0
#define EIOP_BMI_PORT_OFFSET		0
#define EIOP_QMI_PORT_OFFSET		0x00000400
#define EIOP_NTI_PORT_OFFSET		0x00000800
#define EIOP_FPM_PORT_OFFSET		0x00000c00
#define EIOP_TP_PORT_MXT_SHIFT			24
#define EIOP_FLCL_PORT_EMFR_SHIFT	16

#define MAP_EIOP_PORT_TYPE_TO_PCR_PTY_PRT(_type, _rate, 	\
					_reg_type, _reg_rate){	\
	switch(type){						\
		case(EIOP_MANAGEMENT_COMMAND_PORT):		\
			_reg_type = 0xf;			\
			break;					\
		case(EIOP_RECYCLE_PORT):			\
			switch(rate) {				\
				case(EIOP_PORT_RATE_10_G):	\
					_reg_type = 0xe;	\
					_reg_rate = 0x2;	\
					break;			\
				case(EIOP_PORT_RATE_20_G):	\
					_reg_type = 0xe;	\
					_reg_rate = 0x3;	\
					break;			\
				case(EIOP_PORT_RATE_50_G):	\
					_reg_type = 0xe;	\
					_reg_rate = 0x4;	\
					break;			\
				default:			\
				/*NOTE - think*/		\
				break;				\
			}					\
			break;					\
		case(EIOP_ETHERNET_PORT):			\
			switch(_rate){				\
				case(EIOP_PORT_RATE_1_G):	\
					_reg_type = 0;		\
					_reg_rate = 0;		\
					break;			\
				case(EIOP_PORT_RATE_2_5_G):	\
					_reg_type = 0;		\
					_reg_rate = 0;		\
					break;			\
				case(EIOP_PORT_RATE_5_G):	\
					_reg_type = 0;		\
					_reg_rate = 1;		\
					break;			\
				case(EIOP_PORT_RATE_10_G):	\
					_reg_type = 0;		\
					_reg_rate = 2;		\
					break;			\
				case(EIOP_PORT_RATE_20_G):	\
					_reg_type = 0;		\
					_reg_rate = 3;		\
					break;			\
				case(EIOP_PORT_RATE_25_G):	\
					_reg_type = 0;		\
					_reg_rate = 3;		\
					break;			\
				case(EIOP_PORT_RATE_40_G):	\
					_reg_type = 1;		\
					_reg_rate = 4;		\
					break;			\
				case(EIOP_PORT_RATE_50_G):	\
					_reg_type = 1;		\
					_reg_rate = 4;		\
					break;			\
				case(EIOP_PORT_RATE_100_G):	\
					_reg_type = 1;		\
					_reg_rate = 5;		\
					break;			\
				default:			\
				/*NOTE - think*/		\
				break;				\
			}					\
		default:					\
				/*NOTE - think*/		\
				break;}				\
};
/**************************************************************************//**
 @Description   Definition for registers
 *//***************************************************************************/
#define EIOP_PORT_EN			0x80000000
#define EIOP_PORT_RX_ST_BSY		0x80000000
#define EIOP_PORT_RX_ST_NTSKS	0x000000ff
#define EIOP_PORT_TX_ST_BSY		0x80000000
#define EIOP_PORT_TX_ST_NTSKS	0x000000ff
#define EIOP_PORT_TX_CFG_FM		0x20000000

#define EIOP_PORT_TX_DC_SP_MASK	0x000000ff

/**************************************************************************//**
 @Description   Definition of internal data structure
 *//***************************************************************************/
struct default_specific {
	enum eiop_port_ethernet_rate rate;	/* port rate */
	enum eiop_clk clk;	/* WRIOP clock */
	int type; /*0 - receive, 1 - transmit*/
	int val; /* register value */
};
/**************************************************************************//**
 @Description   Definition of registers
 *//***************************************************************************/

struct eiop_bmi_port {
	uint32_t pcr;
	uint32_t cged;
	uint32_t res_08;
	uint32_t res_0c;
	uint32_t intlim;
	uint32_t pfs;
	uint32_t fp;
	uint32_t dp;
	uint32_t res0020[8];
	uint32_t rfne;
	uint32_t fene;
	uint32_t cmne;
	uint32_t res004c[45];
	uint32_t flec;
	uint32_t fufdc;
	uint32_t dsbec;
	uint32_t bdc;
	uint32_t fqdc;
	uint32_t odc;
	uint32_t flsbec;
	uint32_t pec;
	uint32_t iblkc;
	uint32_t irdc;
	uint32_t pcp;
	uint32_t fuc;

};

struct eiop_qmi_port {
	uint32_t etfc;
	uint32_t dn;
	uint32_t en;
	uint32_t dc;
	uint32_t dtfc;
	uint32_t rrfc;
	uint32_t eblkc;
	uint32_t ecwdc;
	uint32_t res_420;
	uint32_t txpfmc0;
	uint32_t res_428;
	uint32_t flcf;

};

struct eiop_nti_port {
	uint32_t pdef;
	uint32_t res0004;
	uint32_t ntne;
	uint32_t res000c;
	uint32_t cved;
	uint32_t res0014;
	uint32_t dsnrc;
};

struct eiop_fpm_port {
	uint32_t cfg;
	uint32_t st;
	uint32_t tp;
};

