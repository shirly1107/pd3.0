/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_eiop.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_EIOP

/*NOTE - should be defined on ldpaa level*/
#define DONT_CARE (-1)

/**************************************************************************//**
 @Description   Definition of default values
*//***************************************************************************/

#define DEFAULT_EIOP_BUS_ERROR_EXCEPTION 	FALSE
#define DEFAULT_EIOP_STALL_EVENT_EXCEPTION 	FALSE

/**************************************************************************//**
 @Description   Definition of registers offset
*//***************************************************************************/
#define EIOP_QMI_EGRESS_OFFSET		0x00001400
#define EIOP_DMA_OFFSET			0x00001800
#define EIOP_FPM_OFFSET			0x00002000
#define EIOP_BMI_INGRESS_OFFSET 0x00000000
#define EIOP_DEBUG_GLOBAL_OFFSET 0x0000f800

/**************************************************************************//**
 @Description   Definition for registers
*//***************************************************************************/
#define EIOP_DMA_SBEV_SBE		0x80000000

#define EIOP_FPM_GEEV_STLE		0x80000000

#define EIOP_QMI_EGRESS_TPBICID_ICEN	0x80000000

#define EIOP_DMA_THRESHOLD		0x00600060
#define EIOP_DMA_HYSTERESIS		0x00400000



/**************************************************************************//**
 @Description   Definition for IOP_EPI fields
*//***************************************************************************/
#define EIOP_EPI_PECCEI			0x80000000
#define EIOP_EPI_PGEI			0x40000000
#define EIOP_EPI_SBEI			0x20000000
#define EIOP_EPI_PILKEI			0x10000000


/**************************************************************************//**
 @Description   Definition for IOP_NPI1 fields
*//***************************************************************************/
#define EIOP_NPI1_PTMRNI		0x20000000
#define EIOP_NPI1_PILKEI		0x10000000

/**************************************************************************//**
 @Description   Definition for IOP_RSTC fields
*//***************************************************************************/
#define EIOP_RSTC_RSTC			0x80000000	//WRIOP soft reset command
#define EIOP_RSTC_QBRSTC		0x40000000	//QBMan interface reset

/**************************************************************************//**
 @Description   Definition of internal data structure
*//***************************************************************************/
struct tmp_eiop_cfg {
	uint64_t tpbb;
	uint16_t tpbb_icid;
	int system_bus_error_exception_en;
	int stall_event_exception_en;
};

/*
 * EIOP BMI registers
 */
#define EIOP_BMI_CGPA_CB		0x8000

/**************************************************************************//**
 @Description   Definition for debug
*//***************************************************************************/
#define EIOP_DEBUG_MAX_DST_IFP	0xfff
#define EIOP_DEBUG_MAX_DST_QDID	0xffff
#define EIOP_DEBUG_MAX_DST_QPRI 0xf
#define EIOP_DEBUG_MAX_BPID		0x3fff
#define EIOP_DEBUG_MAX_QDBIN	0xffff
#define EIOP_DEBUG_MAX_FD_DD	0xf
#define EIOP_DEBUG_MAX_COND_FQID 0xffffff
#define EIOP_DEBUG_MAX_FRM_MARK_EGGR	0xf
#define EIOP_DEBUG_MAX_FRM_MARK_INGR	0xf

#define EIOP_DEBUG_DST_IFP_MATCH_SHIFT_DCMP0_1_DMSK0_1	16
#define EIOP_DEBUG_DST_QPRI_MATCH_SHIFT_DCMP0_1_DMSK0_1	28
#define EIOP_DEBUG_DST_BPID_MATCH_SHIFT_DCMP0_1_DMSK0_1	16
#define EIOP_DEBUG_DEQ_FD_DD_MATCH_SHIFT_DCMP1_DMSK1 	28
#define EIOP_DEBUG_MARK_INGR_SHIFT_DDVAL0				4
#define EIOP_DEBUG_CTLU_MARK_INGR_SHIFT_DDVAL0			20
#define EIOP_DEBUG_MARK_EGGR_SHIFT_DDVAL1				4
#define EIOP_DEBUG_CTLU_MARK_EGGR_SHIFT_DDVAL1			20

#define EIOP_DEBUG_FRM_MARK_INGR_EN_DDVAL0 0x00000001
#define EIOP_DEBUG_FRM_MARK_EGGR_EN_DDVAL1 0x00000001
#define EIOP_DEBUG_MARK_INGR_ORED_WITH_FD_DD_DDVAL0 0x80000000
#define EIOP_DEBUG_MARK_EGGR_ORED_WITH_FD_DD_DDVAL1 0x80000000

#define EIOP_CTLU_DEBUG_TRACE_INGR_DMR		0x10000000
#define EIOP_DEBUG_TRACE_INGR_DMR 			0x40000000
#define EIOP_DEBUG_TRACE_EGGR_DMR			0x20000000

/**************************************************************************//**
 @Description   Definition of registers
*//***************************************************************************/
struct eiop_bmi_ingress {
	uint32_t cgpa;
	uint32_t cgpd;
	uint32_t ibfd;
	uint32_t ibfs;
	uint32_t init;/*0x1_0010 - Initialize ingress*/
	uint32_t bsy;/*0x1_0014 - Ingress port FIFO busy*/
	uint32_t res[122];
	uint32_t ddval0_0;/*0x1_0200 - Ingress Dynamic debug marking value*/
	uint32_t ddval0_1;/*0x1_0204 - Ingress Dynamic debug marking value*/
	uint32_t dcmp0_0;/*0x1_0208 - Ingress Debug trigger event reference value*/
	uint32_t dcmp0_1;/*0x1_020c - Ingress Debug trigger event reference value*/
	uint32_t dmsk0_0;/*0x1_0210 - Ingress Debug trigger event reference mas*/
	uint32_t dmsk0_1;/*0x1_0214 - Ingress Debug trigger event reference mas*/
};

struct eiop_bmi_egress {
	uint32_t ebfd;
	uint32_t ebfs;
};

struct eiop_qmi_ingress {
	uint32_t etfc;
};

struct eiop_qmi_egress {
	uint32_t etcfc;
	uint32_t dtfc;
	uint32_t reserved[2];
	uint32_t tpbbh;
	uint32_t tpbbl;
	uint32_t tpbicid;
	uint32_t res_420_600[121];
	uint32_t ddval1; /*1600 - Egress Dynamic debug marking value*/
	uint32_t res_604;
	uint32_t dcmp1; /*1608- Egress Debug event reference value*/
	uint32_t res_60c;
	uint32_t dmsk1; /*1610 - Egress Debug event reference value*/
};

struct eiop_nti {
	uint32_t vtype;
};

struct eiop_dma {
	uint32_t sbev;
	uint32_t sbem;
	uint32_t sbef;
	uint32_t dccr;
	uint32_t sbdcm;
	uint32_t sbmr;
	uint32_t tr;
	uint32_t hy;
	uint32_t tah;
	uint32_t tal;
	uint32_t tcid1;
	uint32_t tcid2;
};

struct eiop_fpm {
	uint32_t reserved0_2c[12];
	uint32_t epi;
	uint32_t npi1;
	uint32_t npi2;
	uint32_t npi3;
	uint32_t npi4;
	uint32_t npi5;
	uint32_t geev;
	uint32_t geem;
	uint32_t geef;
	uint32_t tsc1;
	uint32_t tsc2;
	uint32_t tsp;
	uint32_t tsf;
	uint32_t ip_rev1;
	uint32_t ip_rev2;
	uint32_t rstc;
};

struct eiop_debug_global {
	uint32_t dmr;
	uint32_t par;
	uint32_t pdr;
};
