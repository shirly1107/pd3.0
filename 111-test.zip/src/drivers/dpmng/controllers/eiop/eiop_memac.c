/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_io.h"
#include "fsl_gen.h"
#include "fsl_timer.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "fsl_eiop_memac.h"

static int write_phy_reg_clause45(struct memac_mii_access_mem_map *mii_regs,
                                  uint8_t phy_addr, uint32_t reg, uint16_t data)
{
	uint32_t tmp_reg;
	int 	 tries;

	tmp_reg = ioread32(&mii_regs->mdio_cfg);
	/* Leave only MDIO_CLK_DIV bits set on */
	tmp_reg &= MDIO_CFG_CLK_DIV_MASK;
	/* Set maximum MDIO_HOLD value to allow phy to see
	change of data signal */
	tmp_reg |= MDIO_CFG_HOLD_MASK;
	/* Add 10G interface mode */
	tmp_reg |= MDIO_CFG_ENC45;
	iowrite32(tmp_reg, &mii_regs->mdio_cfg);

	/* Wait for command completion */
	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_cfg) & MDIO_CFG_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	/* Specify phy and register to be accessed */
	iowrite32(phy_addr, &mii_regs->mdio_ctrl);
	iowrite32(reg, &mii_regs->mdio_addr);
	core_memory_barrier();

	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_cfg) & MDIO_CFG_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	/* Write data */
	iowrite32(data, &mii_regs->mdio_data);
	core_memory_barrier();

	/* Wait for write transaction end */
	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_data) & MDIO_DATA_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	return 0;
}

static int read_phy_reg_clause45(struct memac_mii_access_mem_map *mii_regs,
                                 uint8_t phy_addr, uint32_t reg, uint16_t *data)
{
	uint32_t tmp_reg;
	int 	 tries;

	tmp_reg = ioread32(&mii_regs->mdio_cfg);
	/* Leave only MDIO_CLK_DIV bits set on */
	tmp_reg &= MDIO_CFG_CLK_DIV_MASK;
	/* Set maximum MDIO_HOLD value to allow phy to see
	change of data signal */
	tmp_reg |= MDIO_CFG_HOLD_MASK;
	/* Add 10G interface mode */
	tmp_reg |= MDIO_CFG_ENC45;
	iowrite32(tmp_reg, &mii_regs->mdio_cfg);

	/* Wait for command completion */
	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_cfg) & MDIO_CFG_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	/* Specify phy and register to be accessed */
	iowrite32(phy_addr, &mii_regs->mdio_ctrl);
	iowrite32(reg, &mii_regs->mdio_addr);
	core_memory_barrier();

	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_cfg) & MDIO_CFG_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	/* Read cycle */
	tmp_reg = phy_addr;
	tmp_reg |= MDIO_CTL_READ;
	iowrite32(tmp_reg, &mii_regs->mdio_ctrl);
	core_memory_barrier();

	/* Wait for data to be available */
	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_data) & MDIO_DATA_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	*data =  (uint16_t)ioread32(&mii_regs->mdio_data);

	/* Check if there was an error */
	if (ioread32(&mii_regs->mdio_cfg) & MDIO_CFG_READ_ERR)
		return -EINVAL;

	return 0;
}

static int write_phy_reg_clause22(struct memac_mii_access_mem_map *mii_regs,
                                  uint8_t phy_addr, uint32_t reg, uint16_t data)
{
	uint32_t tmp_reg;
	int 	 tries;

	/* Leave only MDIO_CLK_DIV and MDIO_HOLD bits set on */
	tmp_reg = ioread32(&mii_regs->mdio_cfg);
	tmp_reg &= (MDIO_CFG_CLK_DIV_MASK | MDIO_CFG_HOLD_MASK);
	iowrite32(tmp_reg, &mii_regs->mdio_cfg);

	/* Wait for command completion */
	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_cfg) & MDIO_CFG_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	/* Write transaction */
	tmp_reg = (uint32_t)(phy_addr << MDIO_CTL_PHY_ADDR_SHIFT);
	tmp_reg |= reg;
	iowrite32(tmp_reg, &mii_regs->mdio_ctrl);

	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_cfg) & MDIO_CFG_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	iowrite32(data, &mii_regs->mdio_data);

	core_memory_barrier();

	/* Wait for write transaction to end */
	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_data) & MDIO_DATA_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	return 0;
}

static int read_phy_reg_clause22(struct memac_mii_access_mem_map *mii_regs,
                                 uint8_t phy_addr, uint32_t reg, uint16_t *data)
{
	uint32_t tmp_reg;
	int 	 tries;

	/* Leave only MDIO_CLK_DIV and MDIO_HOLD bits set on */
	tmp_reg = ioread32(&mii_regs->mdio_cfg);
	tmp_reg &= (MDIO_CFG_CLK_DIV_MASK | MDIO_CFG_HOLD_MASK);
	iowrite32(tmp_reg, &mii_regs->mdio_cfg);

	/* Wait for command completion */
	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_cfg) & MDIO_CFG_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	/* Read transaction */
	tmp_reg = (uint32_t)(phy_addr << MDIO_CTL_PHY_ADDR_SHIFT);
	tmp_reg |= reg;
	tmp_reg |= MDIO_CTL_READ;
	iowrite32(tmp_reg, &mii_regs->mdio_ctrl);

	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_cfg) & MDIO_CFG_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	/* Wait for data to be available */
	tries = 100;
	do {
		timer_udelay(1);
	} while ((ioread32(&mii_regs->mdio_data) & MDIO_DATA_BSY) && --tries);
	if (!tries)
		return -ETIMEDOUT;

	*data =  (uint16_t)ioread32(&mii_regs->mdio_data);

	/* Check if there was an error */
	if (ioread32(&mii_regs->mdio_cfg) & MDIO_CFG_READ_ERR)
		return -EINVAL;

	return 0;
}

uint32_t eiop_memac_get_event(struct eiop_memac_desc *desc, uint32_t ev_mask)
{
	struct emac_csr_2_regs *regs = 
			(struct emac_csr_2_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);
	return ioread32(&regs->ievent) & ev_mask;
}

uint32_t eiop_memac_get_interrupt_mask(struct eiop_memac_desc *desc)
{
	int32_t *imask =
			(int32_t*)(desc->vaddr + desc->mem_map[E_EMAC_INTERRUPT_MASK_REGISTERS]);

	return ioread32(imask);
}

void eiop_memac_ack_event(struct eiop_memac_desc *desc, uint32_t ev_mask)
{
	struct emac_csr_2_regs *regs =
			(struct emac_csr_2_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);

	iowrite32(ev_mask, &regs->ievent);
}

#ifdef FUTURE_SUPPORT
void eiop_memac_set_promiscuous(struct eiop_memac_desc *desc, int val)
{
	uint32_t tmp;
	struct memac_regs *regs = (struct memac_regs *)desc->vaddr;

	tmp = ioread32(&regs->command_config);

	if (val)
		tmp |= CMD_CFG_PROMIS_EN;
	else
		tmp &= ~CMD_CFG_PROMIS_EN;

	iowrite32(tmp, &regs->command_config);
}

int eiop_memac_get_promiscuous(struct eiop_memac_desc *desc)
{
	uint32_t tmp;
	struct memac_regs *regs = (struct memac_regs *)desc->vaddr;

	tmp = ioread32(&regs->command_config);

	return (int)
		(((tmp & CMD_CFG_PROMIS_EN) >> CMD_CFG_PROMIS_EN_MODE_SHIFT));
}

void eiop_memac_clear_addr_in_paddr(struct eiop_memac_desc *desc, uint8_t paddr_num)
{
	struct memac_regs *regs = (struct memac_regs *)desc->vaddr;

	if (paddr_num == 0) {
		iowrite32(0, &regs->mac_addr0.mac_addr_l);
		iowrite32(0, &regs->mac_addr0.mac_addr_u);
	} else {
		iowrite32(0x0, &regs->mac_addr[paddr_num - 1].mac_addr_l);
		iowrite32(0x0, &regs->mac_addr[paddr_num - 1].mac_addr_u);
	}
}

void eiop_memac_add_addr_in_paddr(struct eiop_memac_desc *desc,
                                  uint8_t *adr,
                                  uint8_t paddr_num)
{
	uint32_t tmp0, tmp1;
	struct memac_regs *regs = (struct memac_regs *)desc->vaddr;

	tmp0 = (uint32_t)(adr[0] | adr[1] << 8 | adr[2] << 16 | adr[3] << 24);
	tmp1 = (uint32_t)(adr[4] | adr[5] << 8);

	if (paddr_num == 0) {
		iowrite32(tmp0, &regs->mac_addr0.mac_addr_l);
		iowrite32(tmp1, &regs->mac_addr0.mac_addr_u);
	} else {
		iowrite32(tmp0, &regs->mac_addr[paddr_num-1].mac_addr_l);
		iowrite32(tmp1, &regs->mac_addr[paddr_num-1].mac_addr_u);
	}
}
#endif /* FUTURE_SUPPORT */

void eiop_memac_enable(struct eiop_memac_desc *desc, int apply_rx, int apply_tx)
{
	uint32_t tmp;
	struct emac_csr_1_regs *regs =
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = ioread32(&regs->command_config);

	if (apply_rx)
		tmp |= CMD_CFG_RX_EN;

	if (apply_tx)
		tmp |= CMD_CFG_TX_EN;

	iowrite32(tmp, &regs->command_config);
}

int eiop_memac_rx_graceful_stop(const struct eiop_memac_desc *desc)
{
	int tries = 100;
	uint32_t tmp;
	struct emac_csr_1_regs *csr_1_regs =
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	struct emac_csr_2_regs *csr_2_regs =
			(struct emac_csr_2_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);
	
	tmp = ioread32(&csr_1_regs->command_config);
	tmp |= CMD_CFG_RXSTP;
	iowrite32(tmp, &csr_1_regs->command_config);

	/* cEMAC does not implement RX_EMPTY register */
	if (desc->type != E_EMAC_40G_50G_100G_TYPE)
	{
		do {
			tmp = ioread32(&csr_2_regs->ievent);
		} while (!(tmp & MEMAC_IEVENT_RX_EMPTY) && --tries);

		if ((!(tmp & MEMAC_IEVENT_RX_EMPTY)) && tries == 0) {
			pr_err("mEMAC RX graceful stop failed\n");
			return -ETIMEDOUT;
		}
	}

	eiop_memac_disable(desc, 1, 0);

	tmp = ioread32(&csr_1_regs->command_config);
	tmp &= ~CMD_CFG_RXSTP;

	iowrite32(tmp, &csr_1_regs->command_config);

	return 0;
}

int eiop_memac_tx_graceful_stop(struct eiop_memac_desc *desc)
{
  	
   	eiop_memac_disable(desc, 0, 1);

	return 0;
}

void eiop_memac_disable(const struct eiop_memac_desc *desc, int apply_rx, int apply_tx)
{
	uint32_t tmp;
	struct emac_csr_1_regs *regs =
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = ioread32(&regs->command_config);

	if (apply_rx)
		tmp &= ~CMD_CFG_RX_EN;

	if (apply_tx)
		tmp &= ~CMD_CFG_TX_EN;

	iowrite32(tmp, &regs->command_config);
}

void eiop_memac_reset_stat(struct eiop_memac_desc *desc)
{
	uint32_t tmp;
	uint32_t *statn_config = NULL;
	
	if (desc->mem_map[E_EMAC_STATISTICS_CONFIGURATION_REGISTERS] == 0x000)
		return;
	
	statn_config =
			(uint32_t *)(desc->vaddr + desc->mem_map[E_EMAC_STATISTICS_CONFIGURATION_REGISTERS]);

	tmp = ioread32(statn_config);

	tmp |= STATS_CFG_CLR;

	iowrite32(tmp, statn_config);

	while (ioread32(statn_config) & STATS_CFG_CLR) ;
}

void eiop_memac_reset(struct eiop_memac_desc *desc)
{
	uint32_t tmp;
	struct emac_csr_1_regs *regs = 
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = ioread32(&regs->command_config);

	tmp |= CMD_CFG_SW_RESET;

	iowrite32(tmp, &regs->command_config);

	while (ioread32(&regs->command_config) & CMD_CFG_SW_RESET) {};
}

int eiop_memac_init(struct eiop_memac_desc *desc,
                    struct memac_cfg *cfg,
                    enum enet_interface enet_interface,
                    uint32_t rate,
                    uint32_t exceptions)
{
	uint32_t tmp;
	struct emac_csr_1_regs *csr_1_regs =
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);
	
	struct emac_csr_2_regs *csr_2_regs =
			(struct emac_csr_2_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);
	
	struct emac_line_if_ctrl_regs *line_if_ctrl_regs = NULL;
	
	if (desc->mem_map[E_EMAC_LINE_INTERFACE_CONTROL_REGISTERS] != 0x000 )
		line_if_ctrl_regs =
				(struct emac_line_if_ctrl_regs *)(desc->vaddr + desc->mem_map[E_EMAC_LINE_INTERFACE_CONTROL_REGISTERS]);

	UNUSED(rate);

	/* Config */
	tmp = 0;
	if (cfg->wan_mode_enable)
		tmp |= CMD_CFG_WAN_MODE;
	if (cfg->promiscuous_mode_enable)
		tmp |= CMD_CFG_PROMIS_EN;
	if (cfg->pause_forward_enable)
		tmp |= CMD_CFG_PAUSE_FWD;
	if (cfg->pause_ignore)
		tmp |= CMD_CFG_PAUSE_IGNORE;
	if (cfg->tx_addr_ins_enable)
		tmp |= CMD_CFG_TX_ADDR_INS;
	if (cfg->loopback_enable)
		tmp |= CMD_CFG_LOOPBACK_EN;
	if (cfg->cmd_frame_enable)
		tmp |= CMD_CFG_CNT_FRM_EN;
	if (cfg->send_idle_enable)
		tmp |= CMD_CFG_SEND_IDLE;
	if (cfg->no_length_check_enable)
		tmp |= CMD_CFG_NO_LEN_CHK;
	if (cfg->rx_sfd_any)
		tmp |= CMD_CFG_SFD_ANY;
	if (cfg->pad_enable)
		tmp |= CMD_CFG_TX_PAD_EN;
	if (cfg->disable_flt_hdl)
		tmp |= CMD_CFG_FLT_HDL_DIS;

	iowrite32(tmp, &csr_1_regs->command_config);

	/* Max Frame Length */
	iowrite32((uint32_t)cfg->max_frame_length, &csr_1_regs->maxfrm);

	/* Pause Time */
	iowrite32((uint32_t)cfg->pause_quanta, &csr_2_regs->pause_quanta[0]);
	iowrite32((uint32_t)0, &csr_2_regs->pause_thresh[0]);
	/* Inter packet gap */
	iowrite32((uint32_t)cfg->tx_ipg_length, &csr_2_regs->tx_ipg_length);

	/* IF_MODE */
	tmp = 0;
	if (line_if_ctrl_regs) {
		switch (enet_interface) {
		case FSL_ENET_IF_XGMII:
		case FSL_ENET_IF_XFI:
		case FSL_ENET_IF_CAUI:
		case FSL_ENET_IF_USXGMII:
			if (desc->type == E_EMAC_1G_10G_25G_TYPE)
				tmp |= IF_MODE_25G_XGMII;
			break;
		default:
			switch (desc->type) {
			case E_EMAC_1G_10G_25G_TYPE:
				tmp |= IF_MODE_25G_GMII;
				if (enet_interface == FSL_ENET_IF_RGMII
						&& !cfg->loopback_enable)
					tmp |= IF_MODE_RGMII | IF_MODE_25G_RGMII_AUTO;
				break;
			default:
				tmp |= IF_MODE_GMII;
				if (enet_interface == FSL_ENET_IF_RGMII
						&& !cfg->loopback_enable)
					tmp |= IF_MODE_RGMII | IF_MODE_RGMII_AUTO;
			}
		}
		iowrite32(tmp, &line_if_ctrl_regs->if_mode);
	}
	
	/* Set TX_FIFO_SECTIONS */
	switch (rate) {
	case 100000:
		tmp = TX_AVAIL_100000 | TX_EMPTY_100000;
		break;
	case 50000:
	case 40000:
		tmp = TX_AVAIL_40000 | TX_EMPTY_40000;
		break;
	case 25000:
		tmp = TX_AVAIL_25000 | TX_EMPTY_25000;
		break;
	case 10000:
		/* In EIOP revision 1.0.0 the values are EIOP frequency
		 * dependent and different then in EIOP revision 1.1.1 and
		 * above
		 */
		if (desc->options & MEMAC_DESC_OPT_FIFO_SECTIONS) {
			uint32_t eiop_clk;

			/* Save EIOP clock (in MHz) */
			eiop_clk = sys_get_platform_clk() / 1000;
			
			if (eiop_clk < 599)
				tmp = TX_AVAIL_10000_EIOP_1_0_0_500MHz |
				      TX_EMPTY_10000_EIOP_1_0_0_500MHz;
			else if (eiop_clk < 699)
				tmp = TX_AVAIL_10000_EIOP_1_0_0_600MHz |
				      TX_EMPTY_10000_EIOP_1_0_0_600MHz;
			else	/* 700MHz and above */
				tmp = TX_AVAIL_10000 | TX_EMPTY_10000;
		} else {
			tmp = TX_AVAIL_10000 | TX_EMPTY_10000;
		}
		break;
	case 2500:
		tmp = TX_AVAIL_2500 | TX_EMPTY_2500;
		break;
	case 1000:
		tmp = TX_AVAIL_1000 | TX_EMPTY_1000;
		break;
	default:
		return -EINVAL;
	}
	iowrite32(tmp, &csr_1_regs->tx_fifo_sections);

	/* Set RX_FIFO_SECTIONS */
	switch (rate) {
	/* cEmac */
	case 100000:
	case 50000:
	case 40000:
		tmp = RX_CEMAC_SECTION_EMPTY | RX_CEMAC_SECTION_AVAIL;
		break;
	/* mEmac */
	case 25000:
	case 10000:
	case 2500:
	case 1000:
		tmp = RX_MEMAC_SECTION_EMPTY | RX_MEMAC_SECTION_AVAIL;
		break;
	default:
		return -EINVAL;
	}
	iowrite32(tmp, &csr_1_regs->rx_fifo_sections);

	/* clear all pending events and set-up interrupts */
	eiop_memac_ack_event(desc, 0xffffffff);
	eiop_memac_set_exception(desc, exceptions, 1);

	return 0;
}

void eiop_memac_set_exception(struct eiop_memac_desc *desc, uint32_t val, int enable)
{
	uint32_t tmp;
	uint32_t *imask =
			(uint32_t *)(desc->vaddr + desc->mem_map[E_EMAC_INTERRUPT_MASK_REGISTERS]);

	tmp = ioread32(imask);
	if (enable)
		tmp |= val;
	else
		tmp &= ~val;

	iowrite32(tmp, imask);
}

#ifdef FUTURE_SUPPORT
void eiop_memac_reset_filter_table(struct eiop_memac_desc *desc)
{
	uint32_t i;
	struct memac_regs *regs = (struct memac_regs *)desc->vaddr;

	for (i = 0; i < 64; i++)
		iowrite32(i & ~HASH_CTRL_MCAST_EN, &regs->hashtable_ctrl);
}

void eiop_memac_set_hash_table_entry(struct eiop_memac_desc *desc, uint32_t crc)
{
	struct memac_regs *regs = (struct memac_regs *)desc->vaddr;

	iowrite32(crc | HASH_CTRL_MCAST_EN, &regs->hashtable_ctrl);
}

void eiop_memac_set_hash_table(struct eiop_memac_desc *desc, uint32_t val)
{
	struct memac_regs *regs = (struct memac_regs *)desc->vaddr;

	iowrite32(val, &regs->hashtable_ctrl);
}
#endif /* FUTURE_SUPPORT */

uint16_t eiop_memac_get_max_frame_len(struct eiop_memac_desc *desc)
{
	uint32_t tmp;
	struct emac_csr_1_regs *regs =
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = (ioread32(&regs->maxfrm) & MEMAC_MFL_MASK);

	return (uint16_t)tmp;
}

void eiop_memac_set_max_frame_len(struct eiop_memac_desc *desc, uint16_t length)
{
	uint32_t tmp;
	struct emac_csr_1_regs *regs =
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = (ioread32(&regs->maxfrm) & ~MEMAC_MFL_MASK);

	tmp |= length;

	iowrite32(tmp, &regs->maxfrm);
}

void eiop_memac_set_pfc_mode(struct eiop_memac_desc *desc, int mode)
{
	uint32_t tmp;
	struct emac_csr_1_regs *regs = 
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = ioread32(&regs->command_config);
	if (mode)
		tmp |= CMD_CFG_PFC_MODE;
	else
		tmp &= ~CMD_CFG_PFC_MODE;

	iowrite32(tmp, &regs->command_config);
}

void eiop_memac_set_tx_pfc_frames(struct eiop_memac_desc *desc, uint8_t priority, uint16_t pause_time, uint16_t thresh_time)
{
	uint32_t tmp = 0;
	struct emac_csr_2_regs *regs =
			(struct emac_csr_2_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);

	tmp = ioread32(&regs->pause_quanta[priority / 2]);
	if (priority % 2)
		tmp &= 0x0000ffff;
	else
		tmp &= 0xffff0000;
	tmp |= ((uint32_t)pause_time << (16 * (priority % 2)));
	iowrite32(tmp, &regs->pause_quanta[priority / 2]);

	tmp = ioread32(&regs->pause_thresh[priority / 2]);
	if (priority % 2)
		tmp &= 0x0000ffff;
	else
		tmp &= 0xffff0000;
	tmp |= ((uint32_t)thresh_time << (16 * (priority % 2)));
	iowrite32(tmp, &regs->pause_thresh[priority / 2]);
}

void eiop_memac_set_tx_pause_frames(struct eiop_memac_desc *desc, int enable)
{
	struct emac_csr_2_regs *regs =
			(struct emac_csr_2_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);
	uint16_t pause_quanta;
	uint16_t pause_thresh;
	uint8_t idx;

	if (enable) {
		pause_quanta = DEFAULT_PAUSE_QUANTA;
		pause_thresh = DEFAULT_PAUSE_THRESH;
	}
	else {
		pause_quanta = 0;
		pause_thresh = 0;
	}

	for( idx=0 ; idx<8 ; idx++ ) {
		eiop_memac_set_tx_pfc_frames(desc, idx, pause_quanta, pause_thresh);
	}
}

void eiop_memac_set_rx_ignore_pause_frames(struct eiop_memac_desc *desc,
                                           int enable)
{
	uint32_t tmp;
	struct emac_csr_1_regs *regs =
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = ioread32(&regs->command_config);
	if (enable)
		tmp |= CMD_CFG_PAUSE_IGNORE;
	else
		tmp &= ~CMD_CFG_PAUSE_IGNORE;

	iowrite32(tmp, &regs->command_config);
}

void eiop_memac_set_ptp(struct eiop_memac_desc *desc,
                        int enable,
                        uint8_t offset,
                        int checksum_update,
                        uint32_t peer_delay)
{
	uint32_t tmp;
	struct emac_csr_1588_regs *regs = 
			(struct emac_csr_1588_regs *)(desc->vaddr + desc->mem_map[E_EMAC_1588_CONTROL_STATUS_REGISTERS]);

	tmp = ioread32(&regs->single_step);
	tmp &= ~SINGLE_STEP_MASK;

	if (enable)
		tmp |= SINGLE_STEP_ENABLE;
	if (checksum_update)
		tmp |= SINGLE_STEP_CHECKSUM_UPDATE;
	if (offset)
		tmp |= (offset << SINGLE_STEP_OFFSET_SHIFT);

	iowrite32(tmp, &regs->single_step);
	iowrite32(peer_delay, &regs->peer_delay);
}

void eiop_memac_get_ptp(struct eiop_memac_desc *desc,
                        int* enable,
                        uint8_t* offset,
                        int* checksum_update)
{
	uint32_t tmp;
	struct emac_csr_1588_regs *regs =
			(struct emac_csr_1588_regs *)(desc->vaddr + desc->mem_map[E_EMAC_1588_CONTROL_STATUS_REGISTERS]);

	tmp = ioread32(&regs->single_step);
	tmp &= SINGLE_STEP_MASK;

	if (tmp & SINGLE_STEP_ENABLE)
		*(enable) = 1;

	if (tmp & SINGLE_STEP_CHECKSUM_UPDATE)
		*(checksum_update) = 1;

	*(offset) = (uint8_t)
		(((tmp & SINGLE_STEP_OFFSET_MASK) >> SINGLE_STEP_OFFSET_SHIFT));
}

void eiop_memac_set_wan(struct eiop_memac_desc *desc, int enable)
{
	uint32_t tmp; 
	struct emac_csr_1_regs *regs = 
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = ioread32(&regs->command_config);

	if (enable)
		tmp |= CMD_CFG_WAN_MODE;
	else
		tmp &= ~(CMD_CFG_WAN_MODE);
	
	iowrite32(tmp, &regs->command_config);
}

int eiop_memac_get_wan(struct eiop_memac_desc *desc)
{
	uint32_t tmp;
	struct emac_csr_1_regs *regs = 
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = ioread32(&regs->command_config);

	return (int)(((tmp & CMD_CFG_WAN_MODE) >> CMD_CFG_WAN_MODE_SHIFT));
}

void eiop_memac_set_ipg_len(struct eiop_memac_desc *desc, int length)
{
	uint32_t tmp;
	struct emac_csr_2_regs *regs = 
				(struct emac_csr_2_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);

	tmp = ioread32(&regs->tx_ipg_length);

	tmp &= ~MEMAC_TX_IPG_LENGTH_MASK;

	tmp |= length;

	iowrite32(tmp, &regs->tx_ipg_length);
}

uint8_t eiop_memac_get_ipg_len(struct eiop_memac_desc *desc)
{
	uint32_t tmp;
	struct emac_csr_2_regs *regs = 
				(struct emac_csr_2_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);

	tmp = ioread32(&regs->tx_ipg_length);

	tmp &= MEMAC_TX_IPG_LENGTH_MASK;

	return (uint8_t)tmp;
}

void  eiop_memac_set_loopback(struct eiop_memac_desc *desc, int enable)
{
	uint32_t tmp;
	struct emac_csr_1_regs *regs =
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = ioread32(&regs->command_config);

	if (enable)
		tmp |= CMD_CFG_LOOPBACK_EN;
	else
		tmp &= ~CMD_CFG_LOOPBACK_EN;

	iowrite32(tmp, &regs->command_config);
}

int eiop_memac_get_loopback(struct eiop_memac_desc *desc)
{
	uint32_t tmp;
	struct emac_csr_1_regs *regs =
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);

	tmp = ioread32(&regs->command_config);

	return (int)((tmp & CMD_CFG_LOOPBACK_EN) >> CMD_CFG_LOOPBACK_EN_SHIFT);
}

#ifdef WOL_SUPPORT
void eiop_memac_set_wol(struct eiop_memac_desc *desc, int enable)
{
	uint32_t tmp;
	struct memac_regs *regs = (struct memac_regs *)desc->vaddr;

	tmp = ioread32(&regs->command_config);

	if (enable)
		tmp |= CMD_CFG_MG;
	else
		tmp &= ~CMD_CFG_MG;

	iowrite32(tmp, &regs->command_config);
}

int eiop_memac_get_wol(struct eiop_memac_desc *desc)
{
	uint32_t tmp;
	struct memac_regs *regs = (struct memac_regs *)desc->vaddr;

	tmp = ioread32(&regs->command_config);

	return (int)((tmp & CMD_CFG_MG) >> CMD_CFG_MG_SHIFT);
}
#endif /* WOL_SUPPORT */

#define GET_EMAC_CNTR_64(bn) \
        (ioread32(&regs->bn ## _l) | \
        ((uint64_t)ioread32(&regs->bn ## _u) << 32))

static uint64_t eiop_memac_get_counter(struct eiop_memac_desc *desc,
	enum memac_counters reg_name)
{
	uint64_t ret_val;
	struct memac_rx_tx_stat_regs *regs =
			(struct memac_rx_tx_stat_regs *)(desc->vaddr + desc->mem_map[E_EMAC_RX_TX_STATISTICS_COUNTER_REGISTERS]);

	switch (reg_name) {
	case E_MEMAC_COUNTER_R64:
		ret_val = GET_EMAC_CNTR_64(r64);
		break;
	case E_MEMAC_COUNTER_R127:
		ret_val = GET_EMAC_CNTR_64(r127);
		break;
	case E_MEMAC_COUNTER_R255:
		ret_val = GET_EMAC_CNTR_64(r255);
		break;
	case E_MEMAC_COUNTER_R511:
		ret_val = GET_EMAC_CNTR_64(r511);
		break;
	case E_MEMAC_COUNTER_R1023:
		ret_val = GET_EMAC_CNTR_64(r1023);
		break;
	case E_MEMAC_COUNTER_R1518:
		ret_val = GET_EMAC_CNTR_64(r1518);
		break;
	case E_MEMAC_COUNTER_R1519X:
		ret_val = GET_EMAC_CNTR_64(r1519x);
		break;
	case E_MEMAC_COUNTER_RFRG:
		ret_val = GET_EMAC_CNTR_64(rfrg);
		break;
	case E_MEMAC_COUNTER_RJBR:
		ret_val = GET_EMAC_CNTR_64(rjbr);
		break;
	case E_MEMAC_COUNTER_RDRP:
		ret_val = GET_EMAC_CNTR_64(rdrp);
		break;
	case E_MEMAC_COUNTER_RALN:
		ret_val = GET_EMAC_CNTR_64(raln);
		break;
	case E_MEMAC_COUNTER_TUND:
		ret_val = GET_EMAC_CNTR_64(tund);
		break;
	case E_MEMAC_COUNTER_ROVR:
		ret_val = GET_EMAC_CNTR_64(rovr);
		break;
	case E_MEMAC_COUNTER_RXPF:
		ret_val = GET_EMAC_CNTR_64(rxpf);
		break;
	case E_MEMAC_COUNTER_TXPF:
		ret_val = GET_EMAC_CNTR_64(txpf);
		break;
	case E_MEMAC_COUNTER_ROCT:
		ret_val = GET_EMAC_CNTR_64(roct);
		break;
	case E_MEMAC_COUNTER_RMCA:
		ret_val = GET_EMAC_CNTR_64(rmca);
		break;
	case E_MEMAC_COUNTER_RBCA:
		ret_val = GET_EMAC_CNTR_64(rbca);
		break;
	case E_MEMAC_COUNTER_RPKT:
		ret_val = GET_EMAC_CNTR_64(rpkt);
		break;
	case E_MEMAC_COUNTER_RUCA:
		ret_val = GET_EMAC_CNTR_64(ruca);
		break;
	case E_MEMAC_COUNTER_RERR:
		ret_val = GET_EMAC_CNTR_64(rerr);
		break;
	case E_MEMAC_COUNTER_TOCT:
		ret_val = GET_EMAC_CNTR_64(toct);
		break;
	case E_MEMAC_COUNTER_TMCA:
		ret_val = GET_EMAC_CNTR_64(tmca);
		break;
	case E_MEMAC_COUNTER_TBCA:
		ret_val = GET_EMAC_CNTR_64(tbca);
		break;
	case E_MEMAC_COUNTER_TUCA:
		ret_val = GET_EMAC_CNTR_64(tuca);
		break;
	case E_MEMAC_COUNTER_TERR:
		ret_val = GET_EMAC_CNTR_64(terr);
		break;
	case E_MEMAC_COUNTER_RFRM:
		ret_val = GET_EMAC_CNTR_64(rfrm);
		break;
	case E_MEMAC_COUNTER_TFRM:
		ret_val = GET_EMAC_CNTR_64(tfrm);
		break;
	default:
		ret_val = 0;
	}

	return ret_val;
}

static uint64_t eiop_hemac_get_counter(struct eiop_memac_desc *desc,
	enum memac_counters reg_name)
{
	uint64_t ret_val;
	struct hemac_rx_tx_stat_regs *regs =
			(struct hemac_rx_tx_stat_regs *)(desc->vaddr + desc->mem_map[E_EMAC_RX_TX_STATISTICS_COUNTER_REGISTERS]);

	switch (reg_name) {
	case E_MEMAC_COUNTER_R64:
		ret_val = GET_EMAC_CNTR_64(r64);
		break;
	case E_MEMAC_COUNTER_R127:
		ret_val = GET_EMAC_CNTR_64(r127);
		break;
	case E_MEMAC_COUNTER_R255:
		ret_val = GET_EMAC_CNTR_64(r255);
		break;
	case E_MEMAC_COUNTER_R511:
		ret_val = GET_EMAC_CNTR_64(r511);
		break;
	case E_MEMAC_COUNTER_R1023:
		ret_val = GET_EMAC_CNTR_64(r1023);
		break;
	case E_MEMAC_COUNTER_R1518:
		ret_val = GET_EMAC_CNTR_64(r1518);
		break;
	case E_MEMAC_COUNTER_R1519X:
		ret_val = GET_EMAC_CNTR_64(r1519x);
		break;
	case E_MEMAC_COUNTER_RFRG:
		ret_val = GET_EMAC_CNTR_64(rfrg);
		break;
	case E_MEMAC_COUNTER_RJBR:
		ret_val = GET_EMAC_CNTR_64(rjbr);
		break;
	case E_MEMAC_COUNTER_RDRP:
		ret_val = GET_EMAC_CNTR_64(rdrp);
		break;
	case E_MEMAC_COUNTER_RALN:
		ret_val = GET_EMAC_CNTR_64(raln);
		break;
	case E_MEMAC_COUNTER_TUND:
		ret_val = 0; /* not available on hemac */
		break;
	case E_MEMAC_COUNTER_ROVR:
		ret_val = GET_EMAC_CNTR_64(rovr);
		break;
	case E_MEMAC_COUNTER_RXPF:
		ret_val = GET_EMAC_CNTR_64(rxpf);
		break;
	case E_MEMAC_COUNTER_TXPF:
		ret_val = GET_EMAC_CNTR_64(txpf);
		break;
	case E_MEMAC_COUNTER_ROCT:
		ret_val = GET_EMAC_CNTR_64(roct);
		break;
	case E_MEMAC_COUNTER_RMCA:
		ret_val = GET_EMAC_CNTR_64(rmca);
		break;
	case E_MEMAC_COUNTER_RBCA:
		ret_val = GET_EMAC_CNTR_64(rbca);
		break;
	case E_MEMAC_COUNTER_RPKT:
		ret_val = GET_EMAC_CNTR_64(rpkt);
		break;
	case E_MEMAC_COUNTER_RUCA:
		ret_val = GET_EMAC_CNTR_64(ruca);
		break;
	case E_MEMAC_COUNTER_RERR:
		ret_val = GET_EMAC_CNTR_64(rerr);
		break;
	case E_MEMAC_COUNTER_TOCT:
		ret_val = GET_EMAC_CNTR_64(toct);
		break;
	case E_MEMAC_COUNTER_TMCA:
		ret_val = GET_EMAC_CNTR_64(tmca);
		break;
	case E_MEMAC_COUNTER_TBCA:
		ret_val = GET_EMAC_CNTR_64(tbca);
		break;
	case E_MEMAC_COUNTER_TUCA:
		ret_val = GET_EMAC_CNTR_64(tuca);
		break;
	case E_MEMAC_COUNTER_TERR:
		ret_val = GET_EMAC_CNTR_64(terr);
		break;
	case E_MEMAC_COUNTER_RFRM:
		ret_val = GET_EMAC_CNTR_64(rfrm);
		break;
	case E_MEMAC_COUNTER_TFRM:
		ret_val = GET_EMAC_CNTR_64(tfrm);
		break;
	default:
		ret_val = 0;
	}

	return ret_val;
}

uint64_t eiop_emac_get_counter(struct eiop_memac_desc *desc,
		enum memac_counters reg_name)
{
	if ( desc->type == E_EMAC_40G_50G_100G_TYPE ) {
		return eiop_hemac_get_counter(desc, reg_name);
	}
	
	return eiop_memac_get_counter(desc, reg_name);
}

void eiop_memac_adjust_link(struct eiop_memac_desc *desc,
                            enum enet_interface iface_mode,
                            uint32_t rate,
                            int full_dx,
                            int fixed)
{
	uint32_t tmp;
	struct emac_line_if_ctrl_regs *regs = NULL;
	
	/* not all emac models support line control interface */
	if (desc->mem_map[E_EMAC_LINE_INTERFACE_CONTROL_REGISTERS] == 0x000)
		return;
	
	regs = (struct emac_line_if_ctrl_regs *)(desc->vaddr + desc->mem_map[E_EMAC_LINE_INTERFACE_CONTROL_REGISTERS]);

	tmp = ioread32(&regs->if_mode);

	if (full_dx)
		tmp &= ~IF_MODE_HD;
	else
		tmp |= IF_MODE_HD;

	if (iface_mode == FSL_ENET_IF_RGMII) {
		/* Some PHYs used for RGMII ports might not have speed signaling capability
		 * hence the Autoneg must be disabled.
		 * The PHYs on LS1088 where RGMII ports are present do have this capability
		 * so autoneg can be enabled.
		 */
		if(fixed)
			if(desc->type == E_EMAC_10_100_1G_10G_TYPE)
				tmp &= ~IF_MODE_RGMII_AUTO;
			else
				tmp &= ~IF_MODE_25G_RGMII_AUTO;

		if (desc->type == E_EMAC_10_100_1G_10G_TYPE)
			tmp &= ~IF_MODE_RGMII_SP_MASK;
		else
			tmp &= ~IF_MODE_25G_RGMII_SP_MASK;

		/* no half duplex on the new mEmacs */
		if (desc->type == E_EMAC_10_100_1G_10G_TYPE)
			if (full_dx)
				tmp |= IF_MODE_RGMII_FD;
			else
				tmp &= ~IF_MODE_RGMII_FD;

		switch (rate) {
		case 1000:
			if (desc->type == E_EMAC_10_100_1G_10G_TYPE)
				tmp |= IF_MODE_RGMII_1000;
			else
				tmp |= IF_MODE_25G_RGMII_1000;
			break;
		case 100:
			/* IF_MODE_25G_RGMII_100 = IF_MODE_RGMII_100 = 0 */
			break;
		case 10:
			if (desc->type == E_EMAC_10_100_1G_10G_TYPE)
				tmp |= IF_MODE_RGMII_10;
			else
				tmp |= IF_MODE_25G_RGMII_10;
			break;
		default:
			break;
		}
	}

	iowrite32(tmp, &regs->if_mode);
}

void eiop_memac_defconfig(struct memac_cfg *cfg)
{
	cfg->reset_on_init 		= 0;
	cfg->wan_mode_enable 		= 0;
	cfg->promiscuous_mode_enable 	= 0;
	cfg->pause_forward_enable 	= 0;
	cfg->pause_ignore 		= 0;
	cfg->tx_addr_ins_enable 	= 0;
	cfg->loopback_enable 		= 0;
	cfg->cmd_frame_enable 		= 0;
	cfg->rx_error_discard 		= 0;
	cfg->send_idle_enable 		= 0;
	cfg->no_length_check_enable 	= 1;
	cfg->lgth_check_nostdr 		= 0;
	cfg->time_stamp_enable 		= 0;
	cfg->tx_ipg_length 		= DEFAULT_TX_IPG_LENGTH;
	cfg->max_frame_length 		= DEFAULT_FRAME_LENGTH;
	cfg->pause_quanta 		= DEFAULT_PAUSE_QUANTA;
	cfg->pad_enable 		= 1;
	cfg->phy_tx_ena_on 		= 0;
	cfg->rx_sfd_any 		= 0;
	cfg->rx_pbl_fwd 		= 0;
	cfg->tx_pbl_fwd 		= 0;
	cfg->debug_mode 		= 0;
}

int eiop_memac_mii_write_phy_reg(struct memac_mii_access_mem_map *mii_regs,
                                 uint8_t phy_addr, uint32_t reg, uint16_t data,
                                 int clause)
{
	int err;

	/* Check the requested clause */
	if (clause == MDIO_CLAUSE22)
		err = write_phy_reg_clause22(mii_regs, phy_addr, reg, data);
	else
		err = write_phy_reg_clause45(mii_regs, phy_addr, reg, data);

	return err;
}

int eiop_memac_mii_read_phy_reg(struct memac_mii_access_mem_map *mii_regs,
                                uint8_t phy_addr, uint32_t reg, uint16_t *data,
                                int clause)
{
	int err;

	/* Check the requested clause */
	if (clause == MDIO_CLAUSE22)
		err = read_phy_reg_clause22(mii_regs, phy_addr, reg, data);
	else
		err = read_phy_reg_clause45(mii_regs, phy_addr, reg, data);

	return err;
}

void eiop_memac_dump_regs(struct eiop_memac_desc *desc)
{
	   int rx_tx_stat_mem_size = 0;

       pr_info("EIOP MAC %d REGS:\n", desc->mac_id);
       pr_info("General control and status registers - offset %d \n",
    		   desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);
       mem_disp((uint8_t*)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]),
    		   sizeof(struct emac_csr_1_regs));

       pr_info("General control and status registers - offset %d \n",
    		   desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);
       mem_disp((uint8_t*)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]),
    		   sizeof(struct emac_csr_2_regs));

       if (desc->mem_map[E_EMAC_EEE_CONTROL_STATUS_REGISTERS] != 0x00) {
           pr_info("EEE control status registers - offset %d \n",
        		   desc->mem_map[E_EMAC_EEE_CONTROL_STATUS_REGISTERS]);
           mem_disp((uint8_t*)(desc->vaddr + desc->mem_map[E_EMAC_EEE_CONTROL_STATUS_REGISTERS]),
        		   sizeof(struct emac_csr_eee_regs));
       }

       if (desc->mem_map[E_EMAC_1588_CONTROL_STATUS_REGISTERS] != 0x00) {
           pr_info("1588 control status registers - offset %d \n",
        		   desc->mem_map[E_EMAC_1588_CONTROL_STATUS_REGISTERS]);
           mem_disp((uint8_t*)(desc->vaddr + desc->mem_map[E_EMAC_1588_CONTROL_STATUS_REGISTERS]),
        		   sizeof(struct emac_csr_1588_regs));
       }

       if (desc->mem_map[E_EMAC_STATISTICS_CONFIGURATION_REGISTERS] != 0x00) {
           pr_info("Statistics configuration register - offset %d \n",
        		   desc->mem_map[E_EMAC_STATISTICS_CONFIGURATION_REGISTERS]);
           mem_disp((uint8_t*)(desc->vaddr + desc->mem_map[E_EMAC_STATISTICS_CONFIGURATION_REGISTERS]),
        		   sizeof(uint32_t));
       }

       if (desc->type == E_EMAC_40G_50G_100G_TYPE) {
    	   rx_tx_stat_mem_size = sizeof(struct hemac_rx_tx_stat_regs);
       }
       else {
    	   rx_tx_stat_mem_size = sizeof(struct memac_rx_tx_stat_regs);
       }
       pr_info("Rx/TX statistics registers - offset %d \n",
    		   desc->mem_map[E_EMAC_RX_TX_STATISTICS_COUNTER_REGISTERS]);
       mem_disp((uint8_t*)(desc->vaddr + desc->mem_map[E_EMAC_RX_TX_STATISTICS_COUNTER_REGISTERS]),
    		   rx_tx_stat_mem_size);

       if (desc->mem_map[E_EMAC_LINE_INTERFACE_CONTROL_REGISTERS] != 0x00) {
           pr_info("Line control interface registers - offset %d \n",
        		   desc->mem_map[E_EMAC_LINE_INTERFACE_CONTROL_REGISTERS]);
           mem_disp((uint8_t*)(desc->vaddr + desc->mem_map[E_EMAC_LINE_INTERFACE_CONTROL_REGISTERS]),
        		   sizeof(struct emac_line_if_ctrl_regs));
       }

       if (desc->mem_map[E_EMAC_PFC_STATISTICS_COUNTERS_REGISTERS] != 0x00) {
           pr_info("Priority flow control registers - offset %d \n",
        		   desc->mem_map[E_EMAC_PFC_STATISTICS_COUNTERS_REGISTERS]);
           mem_disp((uint8_t*)(desc->vaddr + desc->mem_map[E_EMAC_PFC_STATISTICS_COUNTERS_REGISTERS]),
        		   sizeof(struct emac_pfc_stat_regs));
       }

       pr_info("Interrupt mask register - offset %d \n",
    		   desc->mem_map[E_EMAC_INTERRUPT_MASK_REGISTERS]);
       mem_disp((uint8_t*)(desc->vaddr + desc->mem_map[E_EMAC_INTERRUPT_MASK_REGISTERS]),
    		   sizeof(uint32_t));
}

void dump_hardware_mac(struct eiop_memac_desc *desc)
{
	struct emac_csr_1_regs *csr_1_regs =
			(struct emac_csr_1_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS]);
	
	struct emac_csr_2_regs *csr_2_regs =
			(struct emac_csr_2_regs *)(desc->vaddr + desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);
	
	struct emac_line_if_ctrl_regs *line_if_ctrl_regs = NULL;
	
	if (desc->mem_map[E_EMAC_LINE_INTERFACE_CONTROL_REGISTERS] != 0x000 )
		line_if_ctrl_regs =
				(struct emac_line_if_ctrl_regs *)(desc->vaddr + desc->mem_map[E_EMAC_LINE_INTERFACE_CONTROL_REGISTERS]);
	pr_debug("DUMPING HARDWARE FOR MAC %d\n", desc->mac_id);
	pr_debug("MAC[%d] command_config is %x\n", desc->mac_id, ioread32(&csr_1_regs->command_config));
	pr_debug("MAC[%d] maxfrm  %x\n", desc->mac_id, ioread32(&csr_1_regs->maxfrm));
	pr_debug("MAC[%d] pause_quanta  %x\n", desc->mac_id, ioread32(&csr_2_regs->pause_quanta[0]));
	pr_debug("MAC[%d] pause_thresh  %x\n", desc->mac_id, ioread32(&csr_2_regs->pause_thresh[0]));
	pr_debug("MAC[%d] tx_ipg_length  %x\n", desc->mac_id, ioread32(&csr_2_regs->tx_ipg_length));
	pr_debug("MAC[%d] if_mode  %x\n", desc->mac_id, ioread32(&line_if_ctrl_regs->if_mode));
	pr_debug("MAC[%d] tx_fifo_sections  %x\n", desc->mac_id, ioread32(&csr_1_regs->tx_fifo_sections));
	pr_debug("MAC[%d] rx_fifo_sections  %x\n", desc->mac_id, ioread32(&csr_1_regs->rx_fifo_sections));
}
