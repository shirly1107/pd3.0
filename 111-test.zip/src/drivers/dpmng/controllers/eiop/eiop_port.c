/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
*//***************************************************************************/
#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"

#include "eiop_port.h"
#include "fsl_eiop_memac.h"

/* The maximum number of concurrent tasks that the port can run.
 *
 * IOP_TP<f>_<n>[MXT] values recommended for 500MHz by WRIOP BG
 */
struct default_specific max_task_reg_cfg[] =
{
		/* ingress */
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_500MHZ,	0,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_600MHZ,	0,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_700MHZ,	0,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_800MHZ,	0,	0x03},

		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_500MHZ,	0,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_600MHZ,	0,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_700MHZ,	0,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_800MHZ,	0,	0x03},

		{EIOP_PORT_RATE_5_G,	EIOP_CLK_500MHZ,	0,	0x07},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_600MHZ,	0,	0x07},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_700MHZ,	0,	0x07},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_800MHZ,	0,	0x07},

		{EIOP_PORT_RATE_10_G,	EIOP_CLK_500MHZ,	0,	0x17},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_600MHZ,	0,	0x13},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_700MHZ,	0,	0x11},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_800MHZ,	0,	0x0E},

		{EIOP_PORT_RATE_20_G,	EIOP_CLK_500MHZ,	0,	0x17}, /* undocumented */
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_600MHZ,	0,	0x17}, /* undocumented */
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_700MHZ,	0,	0x17}, /* undocumented */
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_800MHZ,	0,	0x17},

		{EIOP_PORT_RATE_25_G,	EIOP_CLK_500MHZ,	0,	0x25},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_600MHZ,	0,	0x25},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_700MHZ,	0,	0x25},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_800MHZ,	0,	0x25},

		{EIOP_PORT_RATE_40_G,	EIOP_CLK_500MHZ,	0,	0x3C},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_600MHZ,	0,	0x3C},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_700MHZ,	0,	0x3C},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_800MHZ,	0,	0x3C},

		{EIOP_PORT_RATE_50_G,	EIOP_CLK_500MHZ,	0,	0x4B}, /* undocumented */
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_600MHZ,	0,	0x4B},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_700MHZ,	0,	0x4B},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_800MHZ,	0,	0x4B},

		{EIOP_PORT_RATE_100_G,	EIOP_CLK_500MHZ,	0,	0x97}, /* undocumented */
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_600MHZ,	0,	0x97}, /* undocumented */
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_700MHZ,	0,	0x97}, /* undocumented */
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_800MHZ,	0,	0x97},

		/* egress */
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_500MHZ,	1,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_600MHZ,	1,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_700MHZ,	1,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_800MHZ,	1,	0x03},

		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_500MHZ,	1,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_600MHZ,	1,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_700MHZ,	1,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_800MHZ,	1,	0x03},

		{EIOP_PORT_RATE_5_G,	EIOP_CLK_500MHZ,	1,	0x07},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_600MHZ,	1,	0x07},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_700MHZ,	1,	0x07},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_800MHZ,	1,	0x07},

		{EIOP_PORT_RATE_10_G,	EIOP_CLK_500MHZ,	1,	0x17},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_600MHZ,	1,	0x13},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_700MHZ,	1,	0x11},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_800MHZ,	1,	0x0E},

		{EIOP_PORT_RATE_20_G,	EIOP_CLK_500MHZ,	1,	0x17}, /* undocumented */
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_600MHZ,	1,	0x17}, /* undocumented */
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_700MHZ,	1,	0x17}, /* undocumented */
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_800MHZ,	1,	0x17},

		{EIOP_PORT_RATE_25_G,	EIOP_CLK_500MHZ,	1,	0x25},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_600MHZ,	1,	0x25},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_700MHZ,	1,	0x25},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_800MHZ,	1,	0x25},

		{EIOP_PORT_RATE_40_G,	EIOP_CLK_500MHZ,	1,	0x3C},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_600MHZ,	1,	0x3C},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_700MHZ,	1,	0x3C},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_800MHZ,	1,	0x3C},

		{EIOP_PORT_RATE_50_G,	EIOP_CLK_500MHZ,	1,	0x4B}, /* undocumented */
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_600MHZ,	1,	0x4B},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_700MHZ,	1,	0x4B},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_800MHZ,	1,	0x4B},

		{EIOP_PORT_RATE_100_G,	EIOP_CLK_500MHZ,	1,	0x97}, /* undocumented */
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_600MHZ,	1,	0x97}, /* undocumented */
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_700MHZ,	1,	0x97}, /* undocumented */
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_800MHZ,	1,	0x97},
};

/* Number of maximum outstanding external bus access (DMA) requests allowed to
 * the port.
 *
 * IOP_DP<f>_<n>[MXD] values recommended for 500MHz by WRIOP BG
 */
struct default_specific max_dma_reg_cfg[] =
{
		/* ingress */
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_500MHZ,	0,	0x01},	/* use 0x07 for rev1; see below */
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_600MHZ,	0,	0x01},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_700MHZ,	0,	0x01},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_800MHZ,	0,	0x01},

		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_500MHZ,	0,	0x01},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_600MHZ,	0,	0x01},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_700MHZ,	0,	0x01},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_800MHZ,	0,	0x01},

		{EIOP_PORT_RATE_5_G,	EIOP_CLK_500MHZ,	0,	0x03},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_600MHZ,	0,	0x03},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_700MHZ,	0,	0x03},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_800MHZ,	0,	0x03},

		{EIOP_PORT_RATE_10_G,	EIOP_CLK_500MHZ,	0,	0x07},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_600MHZ,	0,	0x07},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_700MHZ,	0,	0x07},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_800MHZ,	0,	0x07},

		{EIOP_PORT_RATE_20_G,	EIOP_CLK_500MHZ,	0,	0x0f},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_600MHZ,	0,	0x0f},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_700MHZ,	0,	0x0f},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_800MHZ,	0,	0x0f},

		{EIOP_PORT_RATE_25_G,	EIOP_CLK_500MHZ,	0,	0x13},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_600MHZ,	0,	0x13},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_700MHZ,	0,	0x13},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_800MHZ,	0,	0x13},

		{EIOP_PORT_RATE_40_G,	EIOP_CLK_500MHZ,	0,	0x1f},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_600MHZ,	0,	0x1f},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_700MHZ,	0,	0x1f},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_800MHZ,	0,	0x1f},

		{EIOP_PORT_RATE_50_G,	EIOP_CLK_500MHZ,	0,	0x27},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_600MHZ,	0,	0x27},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_700MHZ,	0,	0x27},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_800MHZ,	0,	0x27},

		{EIOP_PORT_RATE_100_G,	EIOP_CLK_500MHZ,	0,	0x4f},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_600MHZ,	0,	0x4f},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_700MHZ,	0,	0x4f},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_800MHZ,	0,	0x4f},

		/* egress */
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_500MHZ,	1,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_600MHZ,	1,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_700MHZ,	1,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_800MHZ,	1,	0x03},

		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_500MHZ,	1,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_600MHZ,	1,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_700MHZ,	1,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_800MHZ,	1,	0x03},

		{EIOP_PORT_RATE_5_G,	EIOP_CLK_500MHZ,	1,	0x07},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_600MHZ,	1,	0x07},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_700MHZ,	1,	0x07},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_800MHZ,	1,	0x07},

		{EIOP_PORT_RATE_10_G,	EIOP_CLK_500MHZ,	1,	0x0f},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_600MHZ,	1,	0x0f},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_700MHZ,	1,	0x0f},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_800MHZ,	1,	0x0f},

		{EIOP_PORT_RATE_20_G,	EIOP_CLK_500MHZ,	1,	0x1f},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_600MHZ,	1,	0x1f},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_700MHZ,	1,	0x1f},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_800MHZ,	1,	0x1f},

		{EIOP_PORT_RATE_25_G,	EIOP_CLK_500MHZ,	1,	0x27},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_600MHZ,	1,	0x27},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_700MHZ,	1,	0x27},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_800MHZ,	1,	0x27},

		{EIOP_PORT_RATE_40_G,	EIOP_CLK_500MHZ,	1,	0x3f},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_600MHZ,	1,	0x3f},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_700MHZ,	1,	0x3f},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_800MHZ,	1,	0x3f},

		{EIOP_PORT_RATE_50_G,	EIOP_CLK_500MHZ,	1,	0x4f},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_600MHZ,	1,	0x4f},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_700MHZ,	1,	0x4f},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_800MHZ,	1,	0x4f},

		{EIOP_PORT_RATE_100_G,	EIOP_CLK_500MHZ,	1,	0x9f},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_600MHZ,	1,	0x9f},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_700MHZ,	1,	0x9f},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_800MHZ,	1,	0x9f},
};

/* The IOP initiates next frame dequeue only if the current total size of
 * frames serviced on the port is not greater than FTH.
 *
 * IOP_FLCL<f>_<n>[EMFR] values recommended by WRIOP BG
 */
struct default_specific max_efr_flcl_reg[] = {
		/* egress only */
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_500MHZ,	1,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_600MHZ,	1,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_700MHZ,	1,	0x03},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_800MHZ,	1,	0x03},

		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_500MHZ,	1,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_600MHZ,	1,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_700MHZ,	1,	0x03},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_800MHZ,	1,	0x03},

		{EIOP_PORT_RATE_5_G,	EIOP_CLK_500MHZ,	1,	0x03},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_600MHZ,	1,	0x03},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_700MHZ,	1,	0x03},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_800MHZ,	1,	0x03},

		{EIOP_PORT_RATE_10_G,	EIOP_CLK_500MHZ,	1,	0x03},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_600MHZ,	1,	0x03},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_700MHZ,	1,	0x03},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_800MHZ,	1,	0x03},

		{EIOP_PORT_RATE_20_G,	EIOP_CLK_500MHZ,	1,	0x07},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_600MHZ,	1,	0x07},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_700MHZ,	1,	0x07},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_800MHZ,	1,	0x07},

		{EIOP_PORT_RATE_25_G,	EIOP_CLK_500MHZ,	1,	0x09},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_600MHZ,	1,	0x09},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_700MHZ,	1,	0x09},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_800MHZ,	1,	0x09},

		{EIOP_PORT_RATE_40_G,	EIOP_CLK_500MHZ,	1,	0x0f},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_600MHZ,	1,	0x0f},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_700MHZ,	1,	0x0f},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_800MHZ,	1,	0x0f},

		{EIOP_PORT_RATE_50_G,	EIOP_CLK_500MHZ,	1,	0x13},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_600MHZ,	1,	0x13},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_700MHZ,	1,	0x13},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_800MHZ,	1,	0x13},

		{EIOP_PORT_RATE_100_G,	EIOP_CLK_500MHZ,	1,	0x27},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_600MHZ,	1,	0x27},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_700MHZ,	1,	0x27},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_800MHZ,	1,	0x27},
};

struct default_specific max_flcl_flcl_reg[] = {
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_500MHZ,	1,	0x50},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_600MHZ,	1,	0x50},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_700MHZ,	1,	0x50},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_800MHZ,	1,	0x50},
};

/* The size of port's FIFO committed by the IOP to allocate from the internal
 * buffer pool.
 *
 *  IOP_PFS<f>_<n>[IFSZ] values recommended by WRIOP BG
 */
struct default_specific ifsz_pfs_reg[] =
{
		/* ingress */
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_500MHZ,	0,	0x02F},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_600MHZ,	0,	0x02F},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_700MHZ,	0,	0x02F},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_800MHZ,	0,	0x02F},

		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_500MHZ,	0,	0x02F},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_600MHZ,	0,	0x02F},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_700MHZ,	0,	0x02F},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_800MHZ,	0,	0x02F},

		{EIOP_PORT_RATE_5_G,	EIOP_CLK_500MHZ,	0,	0x033},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_600MHZ,	0,	0x033},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_700MHZ,	0,	0x033},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_800MHZ,	0,	0x033},

		{EIOP_PORT_RATE_10_G,	EIOP_CLK_500MHZ,	0,	0x037},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_600MHZ,	0,	0x037},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_700MHZ,	0,	0x037},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_800MHZ,	0,	0x037},

		{EIOP_PORT_RATE_20_G,	EIOP_CLK_500MHZ,	0,	0x03F},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_600MHZ,	0,	0x03F},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_700MHZ,	0,	0x03F},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_800MHZ,	0,	0x03F},

		{EIOP_PORT_RATE_25_G,	EIOP_CLK_500MHZ,	0,	0x03F},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_600MHZ,	0,	0x03F},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_700MHZ,	0,	0x03F},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_800MHZ,	0,	0x03F},

		{EIOP_PORT_RATE_40_G,	EIOP_CLK_500MHZ,	0,	0x07F},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_600MHZ,	0,	0x07F},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_700MHZ,	0,	0x07F},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_800MHZ,	0,	0x07F},

		{EIOP_PORT_RATE_50_G,	EIOP_CLK_500MHZ,	0,	0x07F},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_600MHZ,	0,	0x07F},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_700MHZ,	0,	0x07F},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_800MHZ,	0,	0x07F},

		{EIOP_PORT_RATE_100_G,	EIOP_CLK_500MHZ,	0,	0x0FF},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_600MHZ,	0,	0x0FF},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_700MHZ,	0,	0x0FF},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_800MHZ,	0,	0x0FF},

		/* egress */
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_500MHZ,	1,	0x02F},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_600MHZ,	1,	0x02F},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_700MHZ,	1,	0x02F},
		{EIOP_PORT_RATE_1_G,	EIOP_CLK_800MHZ,	1,	0x02F},

		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_500MHZ,	1,	0x02F},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_600MHZ,	1,	0x02F},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_700MHZ,	1,	0x02F},
		{EIOP_PORT_RATE_2_5_G,	EIOP_CLK_800MHZ,	1,	0x02F},

		{EIOP_PORT_RATE_5_G,	EIOP_CLK_500MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_600MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_700MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_5_G,	EIOP_CLK_800MHZ,	1,	0x03F},

		{EIOP_PORT_RATE_10_G,	EIOP_CLK_500MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_600MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_700MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_10_G,	EIOP_CLK_800MHZ,	1,	0x03F},

		{EIOP_PORT_RATE_20_G,	EIOP_CLK_500MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_600MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_700MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_20_G,	EIOP_CLK_800MHZ,	1,	0x03F},

		{EIOP_PORT_RATE_25_G,	EIOP_CLK_500MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_600MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_700MHZ,	1,	0x03F},
		{EIOP_PORT_RATE_25_G,	EIOP_CLK_800MHZ,	1,	0x03F},

		{EIOP_PORT_RATE_40_G,	EIOP_CLK_500MHZ,	1,	0x07F},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_600MHZ,	1,	0x07F},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_700MHZ,	1,	0x07F},
		{EIOP_PORT_RATE_40_G,	EIOP_CLK_800MHZ,	1,	0x07F},

		{EIOP_PORT_RATE_50_G,	EIOP_CLK_500MHZ,	1,	0x07F},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_600MHZ,	1,	0x07F},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_700MHZ,	1,	0x07F},
		{EIOP_PORT_RATE_50_G,	EIOP_CLK_800MHZ,	1,	0x07F},

		{EIOP_PORT_RATE_100_G,	EIOP_CLK_500MHZ,	1,	0x0FF},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_600MHZ,	1,	0x0FF},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_700MHZ,	1,	0x0FF},
		{EIOP_PORT_RATE_100_G,	EIOP_CLK_800MHZ,	1,	0x0FF},
};

static uint8_t fill_default_specific_cfg(struct default_specific *specific_cfg,
					   int type,
					   enum eiop_port_ethernet_rate rate,
					   enum eiop_clk clk)
{

	uint8_t index = 0;
	while	((rate != specific_cfg[index].rate) ||
			(specific_cfg[index].type != type) ||
			(specific_cfg[index].clk != clk)) {
		index++;

		/* avoid endless loop in case any of the parameters are invalid */
		if (index == 0xFF) {
			return index;
		}
	}

	return index;
}

static uint32_t fill_pcr(enum eiop_port_type type,
			enum eiop_port_ethernet_rate rate)
{
	uint32_t reg_type= 0, reg_rate = 0;
	MAP_EIOP_PORT_TYPE_TO_PCR_PTY_PRT(type, rate,
					reg_type, reg_rate);

	switch(type){
		case(EIOP_MANAGEMENT_COMMAND_PORT):
		case(EIOP_RECYCLE_PORT):
		case(EIOP_ETHERNET_PORT):
			return ((reg_type << EIOP_PORT_PCR_PTY_SHIFT) |
				(reg_rate << EIOP_PORT_PCR_PRT_SHIFT));
		break;
		default:
			/*NOTE - think what to do*/
		break;

	}

	return NON_VALID;
}

#define IOWRITE32_CHECK(a,b,c) iowrite32_check((a), (b), (c), __FUNCTION__, __LINE__)

static void iowrite32_check(uint32_t val, volatile uint32_t *addr,
							const char *hint_str, const char *func_str, const int line)
{
	uint32_t tmp = 0;

	tmp = ioread32((const volatile uint32_t *)addr);
	pr_debug("[%-6s] val=0x%08x was=0x%08x\n", hint_str, val, tmp);

	iowrite32(val, addr);

	tmp = ioread32((const volatile uint32_t *)addr);
	if (val != tmp) {
		pr_warn("[%-6s] val=0x%08x got=0x%08x\n", hint_str, val, tmp);
	}
}

int eiop_port_init(	const struct eiop_port_desc *desc,
		/*	struct eiop_port_cfg_params *cfg_params,*/
                       	struct eiop_port_init_params *init_params,
                       	int reset)
{

	void *tmp_regs;
	uint32_t tmp = 0;
	int index = 0, err;
	void *regs;
	enum eiop_port_ethernet_rate rate;
	enum eiop_clk eiop_clk = EIOP_CLK_500MHZ;
	uint32_t eiop_clk_mhz;
	struct eiop_desc eiop_desc;
	
	if (init_params->type == EIOP_RECYCLE_PORT)
		rate = desc->rate;
	else
		rate = init_params->rate;
	/*TODO - check parameters -
	1. type and rate is huki
	2. check init_params->default_ingress_ifpid huki
	3. check regs != NULL;
	*/

	eiop_clk_mhz = sys_get_platform_clk() / 1000;

	if (eiop_clk_mhz < 600)
		eiop_clk = EIOP_CLK_500MHZ;
	else if (eiop_clk_mhz < 700)
		eiop_clk = EIOP_CLK_600MHZ;
	else if (eiop_clk_mhz < 800)
		eiop_clk = EIOP_CLK_700MHZ;
	else
		eiop_clk = EIOP_CLK_800MHZ;

	/***********************Ingress*************************/
	/*pointer to BMI Port registers*/
	regs = UINT_TO_PTR(PTR_TO_UINT(desc->vaddr));
	tmp_regs = (struct eiop_bmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_BMI_PORT_OFFSET);
	/*initialization of port configuration register - */
	tmp = fill_pcr(init_params->type,rate);
	IOWRITE32_CHECK(tmp, &((struct eiop_bmi_port *)tmp_regs)->pcr, "PCR");

	if (desc->port_id != 0) {
		if (!reset) {
			index = fill_default_specific_cfg(max_dma_reg_cfg, 0, rate, eiop_clk);
			ASSERT_COND(index < ARRAY_SIZE(max_dma_reg_cfg));
			tmp = (uint32_t) (max_dma_reg_cfg[index].val);

			if ((rate == EIOP_PORT_RATE_1_G) || (rate == EIOP_PORT_RATE_2_5_G)) {
				memset(&eiop_desc, 0, sizeof(eiop_desc));
				err = sys_get_desc(SOC_MODULE_EIOP, SOC_DB_EIOP_DESC_ID, 
								   &eiop_desc, NULL);
				CHECK_COND_RETVAL(err == 0, err);

				/* for rev1 WRIOP BG recommends 0x07 value */
				if (eiop_desc.wriop_version == WRIOP_VERSION(1, 0, 0))
					tmp = (uint32_t)0x07;
			}
		}
		else
			tmp = 0x1;

		IOWRITE32_CHECK(tmp, &((struct eiop_bmi_port *)tmp_regs)->dp, "DP");

		if (!reset) {
			index = fill_default_specific_cfg(ifsz_pfs_reg, 0, rate, eiop_clk);
			ASSERT_COND(index < ARRAY_SIZE(ifsz_pfs_reg));
			tmp = (uint32_t) (ifsz_pfs_reg[index].val);
		}
		else
			tmp = 0x1;

		IOWRITE32_CHECK(tmp, &((struct eiop_bmi_port *)tmp_regs)->pfs, "PFS");
	} else {
		/* management command port (port_id == 0) */
		if (reset) {
			tmp = 0x1;
			IOWRITE32_CHECK(tmp, &((struct eiop_bmi_port *)tmp_regs)->dp, "DP");
			IOWRITE32_CHECK(tmp, &((struct eiop_bmi_port *)tmp_regs)->pfs, "PFS");
		}
	}

	/*pointer to NTI registers */
	tmp_regs = (struct eiop_nti_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_NTI_PORT_OFFSET);
	tmp = (uint32_t)init_params->default_ingress_ifpid << EIOP_PORT_PDEF_IFPID_SHIFT;
	IOWRITE32_CHECK(tmp, &((struct eiop_nti_port *)tmp_regs)->pdef, "PDEF");

	/*pointer to FPM Port registers*/
	tmp_regs = (struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
				EIOP_FPM_PORT_OFFSET);
	/*TP register*/
	if (desc->port_id != 0) {
		if (!reset) {
			index = fill_default_specific_cfg(max_task_reg_cfg, 0, rate, eiop_clk);
			ASSERT_COND(index < ARRAY_SIZE(max_task_reg_cfg));

			memset(&eiop_desc, 0, sizeof(eiop_desc));
			err = sys_get_desc(SOC_MODULE_EIOP, SOC_DB_EIOP_DESC_ID,
					&eiop_desc, NULL);

			/* IOP_TP for 20G recycle ports changed only for WRIOP3.0 (was 0x17, now is 0x15).
			 * Since we keep a single table for all platforms, the override will happen here.
			 * Keep this in mind when a redesign to support various wriop versions will occur !
			 * 
			 * According to the WRIOP BG 0x15 should be set when the BW of the recycle port
			 * is set to 20Gbps. For 50Gbps we use the values from the max_task_reg_cfg table.
			 */
			if ((init_params->type == EIOP_RECYCLE_PORT) &&
					(rate == EIOP_PORT_RATE_20_G) &&
					(eiop_desc.wriop_version == WRIOP_VERSION(3,0,0)))
				tmp = (uint32_t) (0x15 << EIOP_TP_PORT_MXT_SHIFT);
			else
				tmp = (uint32_t) ((max_task_reg_cfg[index].val) << EIOP_TP_PORT_MXT_SHIFT);
		} else
			tmp = 0x1 << EIOP_TP_PORT_MXT_SHIFT;

		IOWRITE32_CHECK(tmp, &((struct eiop_fpm_port *)tmp_regs)->tp, "TP");
	}
	/*******************************************************/


	/***********************Egress*************************/
	/*pointer to Egress Port area registers*/
	regs = UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) + EIOP_PORT_EGRESS_OFFSET);
	tmp_regs = (void *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_BMI_PORT_EGRESS_OFFSET);

	if (desc->port_id != 0) {
		if (!reset) {
			index = fill_default_specific_cfg(max_dma_reg_cfg, 1, rate, eiop_clk);
			tmp = (uint32_t) (max_dma_reg_cfg[index].val);
		} else
			tmp = 0x1;

		IOWRITE32_CHECK(tmp, &((struct eiop_bmi_port *)tmp_regs)->dp, "DP");

		if (!reset) {
			index = fill_default_specific_cfg(ifsz_pfs_reg, 1, rate, eiop_clk);
			ASSERT_COND(index < ARRAY_SIZE(ifsz_pfs_reg));
			tmp = (uint32_t) (ifsz_pfs_reg[index].val);
		} else
			tmp = 0x1;

		IOWRITE32_CHECK(tmp, &((struct eiop_bmi_port *)tmp_regs)->pfs, "PFS");

		/*TODO - should be checked in other revision than 1.0
		 * what to do - for now for 1G put 1,
		 * for other rates should be as default
		 */
		if (rate == EIOP_PORT_RATE_1_G)
			tmp = 0x00000001;
		else
			tmp = 0x00000004;
		IOWRITE32_CHECK(tmp, &((struct eiop_bmi_port *)tmp_regs)->intlim, "INTLIM");

		/*pointer to FPM Port registers*/
		tmp_regs =
			(struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
				EIOP_FPM_PORT_OFFSET);
		/*TP register*/
		if (!reset) {
			index = fill_default_specific_cfg(max_task_reg_cfg, 1,
					rate, eiop_clk);
			/* IOP_TP for 20G recycle ports changed only for WRIOP3.0 (was 0x17, now is 0x15).
			 * Since we keep a single table for all platforms, the override will happen here.
			 * Keep this in mind when a redesign to support various wriop versions will occur !
			 * 
			 * According to the WRIOP BG 0x15 should be set when the BW of the recycle port
			 * is set to 20Gbps. For 50Gbps we use the values from the max_task_reg_cfg table. 
			 */
			if ((init_params->type == EIOP_RECYCLE_PORT) &&
					(rate == EIOP_PORT_RATE_20_G) &&
					(eiop_desc.wriop_version == WRIOP_VERSION(3,0,0)))
				tmp = (uint32_t) (0x15 << EIOP_TP_PORT_MXT_SHIFT);
			else
				tmp = (uint32_t) ((max_task_reg_cfg[index].val) << EIOP_TP_PORT_MXT_SHIFT);
		}
		else
			tmp = 0x1 << EIOP_TP_PORT_MXT_SHIFT;

		IOWRITE32_CHECK(tmp, &((struct eiop_fpm_port *)tmp_regs)->tp, "TP");

		/*pointer to QMI Port registers*/
		tmp_regs = (struct eiop_qmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
				EIOP_QMI_PORT_OFFSET);
		/*FLCFL register*/
		if (!reset) {
			index = fill_default_specific_cfg(max_efr_flcl_reg, 1, rate, eiop_clk);
			ASSERT_COND(index < ARRAY_SIZE(max_efr_flcl_reg));
			tmp = (uint32_t) ((max_efr_flcl_reg[index].val) <<
					EIOP_FLCL_PORT_EMFR_SHIFT);
			index = fill_default_specific_cfg(max_flcl_flcl_reg, 1, rate, eiop_clk);
			if( index < ARRAY_SIZE(max_flcl_flcl_reg) ) {
				tmp = tmp | max_flcl_flcl_reg[index].val;
			}
			else {
				tmp = tmp | (ioread32( &((struct eiop_qmi_port *)tmp_regs)->flcf) & 0xff00ffff);
			}
			IOWRITE32_CHECK(tmp,
					&((struct eiop_qmi_port *)tmp_regs)->flcf, "FLCL");
		} else {
			/* The reset value in this register is set to match IOP_PCR<n>=0x0 */
			tmp = 0x1 << EIOP_FLCL_PORT_EMFR_SHIFT;
			IOWRITE32_CHECK(tmp |
					(ioread32( &((struct eiop_qmi_port *)tmp_regs)->flcf) &
							0xff00ffff),
					&((struct eiop_qmi_port *)tmp_regs)->flcf, "FLCL");
		}
	}
	/*******************************************************/

	return 0;
}
#ifdef ERR009038
uint32_t eiop_port_set_qmi_nia(const struct eiop_port_desc *desc, uint32_t val)
{
	void *regs;
	void *tmp_regs;
	uint32_t cur;

	regs = UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) + EIOP_PORT_EGRESS_OFFSET);
    tmp_regs = (struct eiop_qmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_QMI_PORT_OFFSET);

    cur = ioread32(&((struct eiop_qmi_port *)tmp_regs)->dn);

    iowrite32(val, &((struct eiop_qmi_port *)tmp_regs)->dn);

    return cur;
}
#endif /* */

int eiop_port_set_map_pfc_cls_to_qman_traffic_cls(const struct eiop_port_desc *desc,
						  uint8_t pfc_class,
						uint8_t qman_traffic_class)
{
	void *regs;
	struct eiop_qmi_port *tmp_regs;
	uint32_t tmp = 0;
	uint32_t mask = 0;
	/*TODO - check parameters -
	1. pfc_class in the right range.
	2. traffic_class in the right range
	3. check regs != NULL;
	*/

	/***********************Egress*************************/
	regs = (void *)UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) + EIOP_PORT_EGRESS_OFFSET);

	/*pointer to QMI Port registers*/
	tmp_regs = (struct eiop_qmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) + EIOP_QMI_PORT_OFFSET);

        /*initialization of tx priority based flow control mapping register*/
	tmp = ioread32(&tmp_regs->txpfmc0);
	mask = 0x0f << (28 - (pfc_class * 4));
	tmp = tmp & (~mask);
	tmp = tmp | ((uint32_t )qman_traffic_class << (28 - (pfc_class * 4)));
    iowrite32(tmp, &tmp_regs->txpfmc0);
	/*******************************************************/

	return 0;
}

/*NOTE - this function enable receive and transmit direction.
What to do with disable*/

void eiop_port_rx_enable(const struct eiop_port_desc *desc)
{
	void *tmp_regs;
	uint32_t tmp = 0;


	tmp_regs = (void *)UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) +
			EIOP_BMI_PORT_INGRESS_OFFSET);

	tmp_regs = (struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(tmp_regs) +
    			EIOP_FPM_PORT_OFFSET);

	/*configuration of port configuration register*/
	tmp = EIOP_PORT_EN;
	iowrite32(tmp, &((struct eiop_fpm_port *)tmp_regs)->cfg);

}

static int eiop_port_rx_disable(void *regs)
{
	void *tmp_regs;
	uint32_t tmp = 0;

	tmp_regs = (void *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_BMI_PORT_INGRESS_OFFSET);

	tmp_regs = (struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(tmp_regs) +
    			EIOP_FPM_PORT_OFFSET);

	/*configuration of port configuration register*/
	tmp = ioread32(&((struct eiop_fpm_port *)tmp_regs)->cfg) & ~EIOP_PORT_EN;
	iowrite32(tmp, &((struct eiop_fpm_port *)tmp_regs)->cfg);

	return 0;
}

int eiop_port_rx_graceful_stop(const struct eiop_port_desc *desc)
{
	int tries;
	void *tmp_regs;
	uint32_t tmp;

	ASSERT_COND(desc->vaddr);

	tmp_regs = (void *)UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) +
			EIOP_BMI_PORT_INGRESS_OFFSET);

	tmp_regs = (struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(tmp_regs) +
    			EIOP_FPM_PORT_OFFSET);

	tries = 100;
	eiop_port_rx_disable(desc->vaddr);

	/* After restore, BSY bit is asserted without NTSKS, check by tasks */
	do {
		tmp = ioread32(&((struct eiop_fpm_port *)tmp_regs)->st) &
				EIOP_PORT_RX_ST_NTSKS;
	}while(tmp && --tries);
	if (tmp && tries == 0) {
		pr_err("Graceful stop can not be executed, frames still being processed.\n");
		return -ETIMEDOUT;
	}

	return 0;
}

#if 0
/* Graceful stop procedure as per hardware documentation */
int eiop_ingress_flow_graceful_stop(const struct eiop_port_desc *port_desc,const struct eiop_memac_desc *memac_desc)
{
	int err = 0;
	/*In order to gracefully stop the receiver, the following steps are taken:
	 * Perform the Rx graceful stop procedure which is described in mEMAC.
	 */
	err = eiop_memac_rx_graceful_stop(memac_desc);
	CHECK_COND_RETVAL(err==0, err, "eiop_memac_rx_graceful_stop FAILED\n");
	/*
	 * Clear the IOP_CFG0_<n>[EN]=0 for the relevant physical port.
	 * Poll IOP_ST0_<n>[BSY] until it is cleared (IOP_ST0_<n>[BSY]=0). This ensures that no frames
	 are being processed by the WRIOP (i.e. all frames have been received) for this physical port.
	 */
	err = eiop_port_rx_graceful_stop(port_desc);
	CHECK_COND_RETVAL(err==0, err, "eiop_port_rx_graceful_stop FAILED\n");
	
	return err;
	
}

int eiop_egress_flow_graceful_stop(const struct eiop_port_desc *port_desc,const struct eiop_memac_desc *memac_desc)
{
	int err = 0;
	int tries = 100;
	uint32_t tmp;

	struct emac_csr_2_regs *csr_2_regs =
			(struct emac_csr_2_regs *)(memac_desc->vaddr + memac_desc->mem_map[E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS]);
	/*In order to stop transmit :
	1) Perform the graceful stop procedure as described in WRIOP chapter, section Graceful stop of egress
	flow.
		- Stop enqueueing frames to all queues destined to the physical port
		- Optional step: Enable flush discard mode (set IOP_CFG1_<n>[FM]).
		- Query QMan for empty egress queues associated with port <n> being disabled.
		- Poll IOP_ST1_<n>[BSY] until it is cleared (IOP_ST1_<n>[BSY]=0). This ensures that no frames
			are being processed by the WRIOP (i.e. all frames have been flushed) for this physical port.
		- If enabled, Disable flush discard mode (clear IOP_CFG1_<n>[FM]).
		- Disable WRIOP physical port (clear IOP_CFG1_<n>[EN]). This stops the operation of the
		WRIOP physical port Tx.
	*/
	
	err = eiop_port_tx_graceful_stop(port_desc);
	CHECK_COND_RETVAL(err==0, err, "eiop_port_rx_graceful_stop FAILED\n");
	/*
	2) wait for IEVENT[TX_EMPTY] to be set
	3) Write COMMAND_CONFIG[TX_EN]=0;
	 */

	/* cEMAC does not implement RX_EMPTY register */
	if (memac_desc->type != E_EMAC_40G_50G_100G_TYPE)
	{
		do {
			tmp = ioread32(&csr_2_regs->ievent);
		} while (!(tmp & MEMAC_IEVENT_TX_EMPTY) && --tries);

		if ((!(tmp & MEMAC_IEVENT_TX_EMPTY)) && tries == 0) {
			pr_err("mEMAC TX graceful stop failed\n");
			return -ETIMEDOUT;
		}
	}

	eiop_memac_disable(memac_desc, 0, 1);

	return err;

}
#endif

void eiop_port_tx_enable(const struct eiop_port_desc *desc)
{
	void *tmp_regs, *regs;
	uint32_t tmp = 0;

	/*pointer to Egress Port area registers*/
	regs = (void *)UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) +
    			EIOP_PORT_EGRESS_OFFSET);
	/*pointer to FPM Port registers*/
    tmp_regs = (struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
    			EIOP_FPM_PORT_OFFSET);
	/*configuration of port configuration register*/
	tmp = EIOP_PORT_EN;
	iowrite32(tmp, &((struct eiop_fpm_port *)tmp_regs)->cfg);
        /*******************************************************/

}

static int eiop_port_tx_disable(void *regs)
{
	void *tmp_regs;
	uint32_t tmp = 0;

	/*pointer to Egress Port area registers*/
	tmp_regs = (void *)UINT_TO_PTR(PTR_TO_UINT(regs) +
    			EIOP_PORT_EGRESS_OFFSET);
	/*pointer to FPM Port registers*/
    	tmp_regs = (struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(tmp_regs) +
    			EIOP_FPM_PORT_OFFSET);
	/*configuration of port configuration register*/
    	/*configuration of port configuration register*/
    	tmp = ioread32(&((struct eiop_fpm_port *)tmp_regs)->cfg) & ~EIOP_PORT_EN;
    	iowrite32(tmp, &((struct eiop_fpm_port *)tmp_regs)->cfg);
        /*******************************************************/

	return 0;
}
int eiop_port_tx_set_flush(const struct eiop_port_desc *desc)
{
	void 	*tmp_regs, *regs;

	ASSERT_COND(desc->vaddr);
	/*pointer to Egress Port area registers*/
	regs = (void *)UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) +
    			EIOP_PORT_EGRESS_OFFSET);
	/*pointer to FPM Port registers*/
    	tmp_regs = (struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
    			EIOP_FPM_PORT_OFFSET);

    	iowrite32(ioread32(&((struct eiop_fpm_port *)tmp_regs)->cfg) |
    				EIOP_PORT_TX_CFG_FM,
    				&((struct eiop_fpm_port *)tmp_regs)->cfg);
    	return 0;

}

int eiop_port_tx_graceful_stop(const struct eiop_port_desc *desc)
{
	void 	*tmp_regs, *regs;
	uint32_t tmp = 0;
	int 	tries;
	ASSERT_COND(desc->vaddr);

	/*pointer to Egress Port area registers*/
	regs = (void *)UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) +
    			EIOP_PORT_EGRESS_OFFSET);
	/*pointer to FPM Port registers*/
    	tmp_regs = (struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
    			EIOP_FPM_PORT_OFFSET);

    	/*Poll BSY until it is cleared. This ensures that no frames
    	are being processed by the EIOP
    	(i.e. all frames have been flushed) for this physical port.*/
    	tries = 100;
    	do {
    		tmp = ioread32(&((struct eiop_fpm_port *)tmp_regs)->st) &
    				EIOP_PORT_TX_ST_BSY;
    	}while((tmp == EIOP_PORT_TX_ST_BSY) && --tries);

    	if ((tmp == EIOP_PORT_TX_ST_BSY) && tries == 0) {
    		pr_err("Graceful stop can not be executed, frames still being processed.\n");
    		return -ETIMEDOUT;

    	}
    	/*Disable flush discard mode. This stops automatic discard operation
    	on EIOP dequeue */
    	tmp = ioread32(&((struct eiop_fpm_port *)tmp_regs)->cfg) & ~EIOP_PORT_TX_CFG_FM;
    	iowrite32(tmp, &((struct eiop_fpm_port *)tmp_regs)->cfg);

    	/*Disable WRIOP physical port (clear IOP_CFG1_<n>[EN]).
    	 This stops the operation of the WRIOP physical port Tx.*/
    	eiop_port_tx_disable(desc->vaddr);

	return 0;
}

int eiop_port_set_default_ingress_ifpid(const struct eiop_port_desc *desc, int default_ingress_ifpid)
{
	void *tmp_regs, *regs;
	uint32_t tmp = 0;

	ASSERT_COND(desc->vaddr);

	/*check default_ingress_ifpid in the range of 12 bits*/
	if (default_ingress_ifpid > EIOP_PORT_MAX_NUM_OF_IFPs) {
		pr_err("set default_ingress_ifpid (%d) not in the range, the value should be in the range: 0 - %d",
		       default_ingress_ifpid, EIOP_PORT_MAX_NUM_OF_IFPs);
		return -EDOM;
	}

	/******************
	 * check port is disable
	 ******************/
	/*pointer Rx Port registers area*/
	regs = (void *)UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) +
			EIOP_BMI_PORT_INGRESS_OFFSET);

	/*pointer Rx FPM Port registers area*/
	tmp_regs = (struct eiop_fpm_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
    			EIOP_FPM_PORT_OFFSET);

	/*read cfg register to be sure port disable*/
	tmp = ioread32( &((struct eiop_fpm_port *)tmp_regs)->cfg);
	if (tmp & EIOP_PORT_EN) {
		pr_err("eiop_port_set_default_ingress_ifpid function can be called only when EIOP_PORT is disabled\n");
		return -EINVAL;
	}
	pr_debug("Setting default ingress port ifp = %d\n", default_ingress_ifpid);
	/******************
	 * update default_ingress_ifpid
	 ******************/
	/*pointer to NTI area registers*/
	tmp_regs = (struct eiop_nti_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_NTI_PORT_OFFSET);
    /*update pdef register with default_ingress_ifpid*/
    tmp = (uint32_t)default_ingress_ifpid <<
    				EIOP_PORT_PDEF_IFPID_SHIFT;
    iowrite32(tmp, &((struct eiop_nti_port *)tmp_regs)->pdef);

    return 0;
}

void eiop_port_tx_get_dsp(const struct eiop_port_desc *desc, int *sp)
{

	void *tmp_regs, *regs;
	uint32_t tmp = 0;

	/*pointerTx Port registers area*/
	regs = (void *)UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) +
			EIOP_PORT_EGRESS_OFFSET);

	/*pointer QMI Port registers area of Tx*/
	tmp_regs = (struct eiop_qmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_QMI_PORT_OFFSET);

	/*read dequeue config register*/
	tmp = ioread32( &((struct eiop_qmi_port *)tmp_regs)->dc);

	*sp = (int)(tmp & EIOP_PORT_TX_DC_SP_MASK);
}

uint32_t eiop_get_counter(const struct eiop_port_desc *desc,
                                                enum eiop_port_counter_type type)
{
       void *tmp_regs;
       void *regs;
       uint32_t counter = 0;

       regs = UINT_TO_PTR(PTR_TO_UINT(desc->vaddr));
       tmp_regs = (struct eiop_bmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
                     EIOP_BMI_PORT_OFFSET);

       switch (type) {
       case(E_INGRESS_FLEC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->flec);
       break;
       case(E_INGRESS_BDC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->bdc);
       break;
       case(E_INGRESS_FQDC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->fqdc);
       break;
       case(E_INGRESS_ODC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->odc);
       break;
       case(E_INGRESS_PEC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->pec);
       break;
       case(E_INGRESS_BLKC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->iblkc);
       break;
       case(E_INGRESS_RDC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->irdc);
       break;
       default :
              break;
       }

       regs = UINT_TO_PTR(PTR_TO_UINT(desc->vaddr));
       tmp_regs = (struct eiop_bmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
                                           EIOP_QMI_PORT_OFFSET);
       switch (type) {
        case(E_INGRESS_ETFC) :
               counter  = (uint16_t)ioread32(&((struct eiop_qmi_port *)tmp_regs)->etfc);
        break;
        default:
        	break;
       }
       regs = UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) + EIOP_PORT_EGRESS_OFFSET);
       tmp_regs = (void *)UINT_TO_PTR(PTR_TO_UINT(regs) +
                           EIOP_BMI_PORT_EGRESS_OFFSET);

       switch (type) {
       case(E_EGRESS_FLEC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->flec);
       break;
       case(E_EGRESS_PEC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->pec);
       break;
       case(E_EGRESS_FUFDC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->fufdc);
       break;
       case(E_EGRESS_DSBEC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->dsbec);
       break;
       case(E_EGRESS_BDC) :
              counter  = (uint16_t)ioread32(&((struct eiop_bmi_port *)tmp_regs)->bdc);
       break;
       default :
              break;
       }
       tmp_regs = (struct eiop_qmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
                     EIOP_QMI_PORT_OFFSET);

       switch (type) {
       case(E_EGRESS_ETFC) :
              counter  = (uint16_t)ioread32(&((struct eiop_qmi_port *)tmp_regs)->etfc);
       break;
       case(E_EGRESS_DTFC) :
              counter  = (uint16_t)ioread32(&((struct eiop_qmi_port *)tmp_regs)->dtfc);
       break;
       case(E_EGRESS_RRFC) :
              counter  = (uint16_t)ioread32(&((struct eiop_qmi_port *)tmp_regs)->rrfc);
       break;
       default :
              break;
       }
              return counter;


}


void eiop_port_dump_regs(const struct eiop_port_desc *desc)
{
       void *regs;
       void *tmp_regs;

       regs = desc->vaddr;
       tmp_regs = (struct eiop_bmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
		     EIOP_BMI_PORT_OFFSET);
       pr_info("EIOP PORT %d: RX BMI REGS:\n", desc->port_id);
       mem_disp((uint8_t*)tmp_regs, sizeof(struct eiop_bmi_port));

       tmp_regs = (struct eiop_qmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
					   EIOP_QMI_PORT_OFFSET);
       pr_info("EIOP PORT %d: RX QMI REGS:\n", desc->port_id);
       mem_disp((uint8_t*)tmp_regs, sizeof(struct eiop_qmi_port));

       regs = UINT_TO_PTR(PTR_TO_UINT(desc->vaddr) + EIOP_PORT_EGRESS_OFFSET);
       tmp_regs = (void *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			   EIOP_BMI_PORT_EGRESS_OFFSET);

       pr_info("EIOP PORT %d: TX BMI REGS:\n", desc->port_id);
       mem_disp((uint8_t*)tmp_regs, sizeof(struct eiop_bmi_port));

       tmp_regs = (struct eiop_qmi_port *)UINT_TO_PTR(PTR_TO_UINT(regs) +
		     EIOP_QMI_PORT_OFFSET);

       pr_info("EIOP PORT %d: TX QMI REGS:\n", desc->port_id);
       mem_disp((uint8_t*)tmp_regs, sizeof(struct eiop_qmi_port));
}

void eiop_port_set_cgp(const struct eiop_port_desc *desc,
		struct eiop_cgp *cgp, int cmd)
{
	eiop_set_port_cgp(desc->eiop_id, desc->port_id, cgp, cmd);
}

int eiop_port_get_ppid(struct eiop_port_desc *desc)
{
	return desc->port_id;
}
