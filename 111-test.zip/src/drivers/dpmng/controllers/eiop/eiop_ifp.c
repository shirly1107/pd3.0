/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_gen.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"

#include "fsl_eiop.h"
#include "eiop_ifp.h"
#include "ctlu_common.h"
#include "dpparser.h"

#ifdef ERR008425
static void execute_errata_008425(uint32_t tmp32, uint32_t reg)
{
	uint32_t tmp_err_8425;

	tmp_err_8425 = ioread32(&reg);

	while (tmp_err_8425 != tmp32) {
		iowrite32(tmp32, &reg);
		tmp_err_8425 = ioread32(&reg);
	}
}
#endif
static uint32_t build_rx_skip_info(uint32_t activate_modules)
{
	uint32_t skip_info = 0;

	if ((activate_modules & EIOP_IFP_ACTIVATE_MODULE_POLICER)
		!= EIOP_IFP_ACTIVATE_MODULE_POLICER)
		skip_info |= EIOP_IFP_EXT_RX_SKIP_POLICER;

	if ((activate_modules & EIOP_IFP_ACTIVATE_MODULE_PARSER)
		!= EIOP_IFP_ACTIVATE_MODULE_PARSER) {
		skip_info |= (EIOP_IFP_EXT_RX_SKIP_PARSER
				| EIOP_IFP_EXT_RX_SKIP_POLICY
				| EIOP_IFP_EXT_RX_SKIP_LK
				| EIOP_IFP_EXT_RX_SKIP_HASH_GEN
				| EIOP_IFP_EXT_RX_SKIP_QoS_MAP);

		return skip_info;
	}

	if ((activate_modules & EIOP_IFP_ACTIVATE_MODULE_POLICY)
		!= EIOP_IFP_ACTIVATE_MODULE_POLICY)
		skip_info |= EIOP_IFP_EXT_RX_SKIP_POLICY;

	if ((activate_modules & EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION)
		!= EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION)
		skip_info |= EIOP_IFP_EXT_RX_SKIP_HASH_GEN;

	if ((activate_modules & EIOP_IFP_ACTIVATE_MODULE_LOOKUP)
		!= EIOP_IFP_ACTIVATE_MODULE_LOOKUP)
		skip_info |= EIOP_IFP_EXT_RX_SKIP_LK;

	if ((activate_modules & EIOP_IFP_ACTIVATE_MODULE_QoS_MAPPING)
		!= EIOP_IFP_ACTIVATE_MODULE_QoS_MAPPING)
		skip_info |= EIOP_IFP_EXT_RX_SKIP_QoS_MAP;

	return skip_info;

}
static uint32_t build_tx_skip_info(uint32_t activate_modules)
{
	uint32_t skip_info = (EIOP_IFP_EXT_TX_SKIP_POLICY
				| EIOP_IFP_EXT_TX_SKIP_HASH_GEN
				| EIOP_IFP_EXT_TX_SKIP_QoS_MAP
				| EIOP_IFP_EXT_TX_SKIP_POLICER);

	if ((activate_modules & EIOP_IFP_ACTIVATE_MODULE_PARSER)
		!= EIOP_IFP_ACTIVATE_MODULE_PARSER) {
		skip_info |= EIOP_IFP_EXT_TX_SKIP_PARSER;
		skip_info |= EIOP_IFP_EXT_TX_SKIP_LK;
		return skip_info;
	}
	if (activate_modules == EIOP_IFP_ACTIVATE_MODULE_PARSER)
		skip_info |= EIOP_IFP_EXT_TX_SKIP_LK;

	return skip_info;
}

static void mng_cmd_init(void *regs, const struct eiop_ifp_cfg *cfg)
{
	struct eiop_ifp_regs *ifp_regs = (struct eiop_ifp_regs *)regs;
	uint32_t tmp_reg = 0, size;
	struct mng_cmd_desc *mng_cmd_desc;
	int i;

	/* make sure size is synchronized */
	ASSERT_COND(MNG_CMD_DESC_SIZE == sizeof(struct mng_cmd_desc));

	if (!cfg->defcfg.mng_cmd_ring_size)
		size = (uint32_t)(DEFAULT_IFP_MNG_CMND - 1);
	else
		size = (uint32_t)(cfg->defcfg.mng_cmd_ring_size - 1);

	/* initialize management command registers */
	iowrite32(size, &ifp_regs->ifmcrsiz);

	tmp_reg = ((uint32_t)cfg->mng_cmd_icid & IFMICID_ICID_MASK);
	if (cfg->mng_cmd_bmt)
		tmp_reg |= IFMICID_BMT;
	if (cfg->mng_cmd_pl)
		tmp_reg |= IFMICID_PL;
	if (cfg->mng_cmd_va)
		tmp_reg |= IFMICID_VA;
	iowrite32(tmp_reg, &ifp_regs->ifmicid);
	iowrite32(UINT32_HI(cfg->mng_cmd_ring_paddr), &ifp_regs->ifmcaddh);
	iowrite32(UINT32_LO(cfg->mng_cmd_ring_paddr), &ifp_regs->ifmcaddl);
	/* set index to "0" */
	//iowrite32(0, &ifp_regs->ifpmcr);
	/* Clear MD ring */
	mng_cmd_desc = (struct mng_cmd_desc *)cfg->mng_cmd_ring_vaddr;
	for (i = 0; i <= size; i++, mng_cmd_desc++) {
		memset(mng_cmd_desc, 0, sizeof(struct mng_cmd_desc));
		/* set software acknowledge */
		mng_cmd_desc->misc_mtype = CPU_TO_LE32(ILLEGAL_MTYPE);
	}
	core_memory_barrier();
}

/**************************************************************************//**
 @Description   Function which calculate data Offset and HW annotation length
 *//***************************************************************************/
static void calc_hwal_offset(const struct buf_layout *layout,
	uint32_t *hwal,
	enum layout_type layout_type)
{

	uint32_t tmp_hwal = 0;
	uint8_t last = 0, i = 0;
	struct tmp_buff_layout tmp_layout[] = {
		{ FA_STATUS_TS_OFFSET, FA_STATUS_TS_SIZE, 0 }, {
			FA_PR_OFFSET, FA_PR_SIZE, 0 },
		{ FA_INGR_AD_OFFSET, FA_INGR_AD_SIZE, 0 }, {
			FA_SWOPAQUE_OFFSET, FA_SWOPAQUE_SIZE, 0 },
		{ FA_EGGR_AD_OFFSET, FA_EGGR_AD_SIZE, 0 },
		{ FA_ICFD_OFFSET, FA_ICFD_SIZE, 0 }, };

	if ((layout->pass_fas != 0) || (layout->pass_ts != 0)) {
		tmp_layout[FA_STATUS_TS_INDX].user_def = 1;
	} else {
		tmp_layout[FA_STATUS_TS_INDX].user_def = 0;
	}
	tmp_layout[FA_PR_INDX].user_def = layout->pass_pr;
	tmp_layout[FA_SWOPAQUE_INDX].user_def = layout->pass_sw_opaque;

	tmp_layout[FA_INGR_AD_INDX].user_def = layout->pass_ing_ad;
	tmp_layout[FA_EGGR_AD_INDX].user_def = layout->pass_egr_ad;

	last = FA_NUM_INDXS - 1;

	while ((tmp_layout[last].user_def == 0) && (last != 0))
		last--;
	while (i <= last) {
		if (i == last) {
			if (tmp_layout[last].user_def)
				tmp_hwal += tmp_layout[i].size;
		} else
			tmp_hwal += tmp_layout[i].size;
		i++;
	}

	*hwal = tmp_hwal /*+ layout->priv_data_size*/;

}

static void calc_data_offset(const struct buf_layout *layout,
	uint32_t hwal,
	uint32_t *data_offset,
	uint32_t *delta_for_data_align)
{
	uint32_t tmp;
	uint32_t tmp_data_offset;

	if (((uint32_t)hwal % 64) != 0)
		tmp_data_offset = (((uint32_t)hwal / 64) + 1) * 64;
	else
		tmp_data_offset = hwal;

	tmp_data_offset += (layout->priv_data_size ? 64 : 0);

	tmp_data_offset += layout->data_headroom;
	*delta_for_data_align = 0;
	if (layout->data_align) {
		tmp = tmp_data_offset % layout->data_align;
		if (tmp)
			*delta_for_data_align = (layout->data_align - tmp);
	}
	tmp_data_offset += *delta_for_data_align;
	*data_offset = tmp_data_offset;
}

/**************************************************************************//**
 @Description   Function which fills parameters of external buffer pools
 of the same type in ascending order.This is the one of
 "help"functions for ordering the user defined buffer pools
 in ascending order.
 *//***************************************************************************/
static void fill_tmp_pools_in_asc_ord(const struct ldpa_buf_pool_cfg *tmp_pools,
	struct ldpa_buf_pool_cfg *ord_tmp_pools,
	uint16_t num_of_pools_used)
{

	int i = 0, j = 0, k = 0;
	uint16_t buf_size;

	for (i = 0; i < num_of_pools_used; i++) {
		buf_size = (uint16_t)tmp_pools[i].size;
		for (j = 0; j <= i; j++) {
			if (j == i)
				memcpy(&ord_tmp_pools[i], &tmp_pools[i],
					sizeof(struct ldpa_buf_pool_cfg));
			else {
				if (buf_size < ord_tmp_pools[j].size) {
					for (k = i; k > j; k--)
						memcpy(&ord_tmp_pools[k],
							&ord_tmp_pools[k - 1],
							sizeof(struct ldpa_buf_pool_cfg));

					memcpy(&ord_tmp_pools[k],
						&tmp_pools[i],
						sizeof(struct ldpa_buf_pool_cfg));
					break;
				}
			}
		}
	}

}

/**************************************************************************//**
 @Description   Function which fills parameters of external buffer pools
 in ascending order and according HW restrictions.
 This is the one of "help"functions for ordering
 the user defined buffer pools in ascending order.
 *//***************************************************************************/
static void fill_ord_pools_cfg(struct ldpa_buf_pool_cfg *ord_tmp_pools,
	struct ldpa_buf_pool_cfg *ord_cfg,
	uint16_t first_indx,
	uint16_t num_of_used)
{
	int tmp_indx = first_indx;
	int i = 0;

	for (i = 0; i < num_of_used; i++) {
		memcpy(&ord_cfg[tmp_indx], &ord_tmp_pools[i],
			sizeof(struct ldpa_buf_pool_cfg));
		tmp_indx++;
	}
}

/**************************************************************************//**
 @Description   Function which fills parameters of external buffer pools
 in ascending order and according HW restrictions.
 *//***************************************************************************/

static void set_buff_pools_in_asc_order(uint16_t num_of_pools_used,
	uint16_t num_of_backup_pools_used,
	const struct ldpa_buf_pool_cfg *pools_cfg,
	const struct ldpa_buf_pool_cfg *backup_pools_cfg,
	struct ldpa_buf_pool_cfg *ord_pools_cfg)
{
	int i = 0;
	uint16_t first_indx = 0, tmp_num_of_pools = 0;
	struct ldpa_buf_pool_cfg ord_tmp_pools[IFP_MAX_NUM_OF_EXT_POOLS];
	const struct ldpa_buf_pool_cfg *tmp_pools;

	for (i = 0; i < 2; i++) {
		if (i == 0) {
			tmp_num_of_pools = num_of_pools_used;
			first_indx = 0;
			tmp_pools = pools_cfg;

		} else {

			tmp_num_of_pools = num_of_backup_pools_used;
			first_indx =
				(uint16_t)(first_indx + num_of_pools_used);
			tmp_pools = backup_pools_cfg;
		}

		if (tmp_num_of_pools) {
			memset(&ord_tmp_pools,
				0,
				sizeof(struct ldpa_buf_pool_cfg)
				* IFP_MAX_NUM_OF_EXT_POOLS);
			fill_tmp_pools_in_asc_ord(tmp_pools, ord_tmp_pools,
							tmp_num_of_pools);
			fill_ord_pools_cfg(ord_tmp_pools, ord_pools_cfg,
						first_indx, tmp_num_of_pools);

		}
	}
}

/*NOTE - what to do here with ingress/egress*/

static uint32_t fill_fd_fa_ingress(struct buf_layout *layout)
{
	uint32_t tmp = 0;

	if ((layout->pass_fas != 0) || (layout->pass_ts != 0))
		tmp |= EIOP_IFP_FA_FASV_INGR;
	if (layout->pass_pr != 0)
		tmp |= EIOP_IFP_FA_PRV_INGR;
	if (layout->pass_sw_opaque != 0)
		tmp |= EIOP_IFP_FA_SWOV_INGR;
	if (layout->pass_ing_ad != 0)
		tmp |= EIOP_IFP_FA_IADV_INGR;
	if (layout->pass_egr_ad != 0)
		tmp |= EIOP_IFP_FA_EADV_INGR;

#ifdef VERIFICATION_SUPPORT
	if (layout->pass_icfd != 0)
	tmp |= EIOP_IFP_FA_ICFDV_INGR;
#endif

	return tmp;

}

static uint32_t fill_fd_fa_egress(struct buf_layout *layout)
{
	uint32_t tmp = 0;

	if ((layout->pass_fas != 0) || (layout->pass_ts != 0))
		tmp |= EIOP_IFP_FA_FASV_EGGR;
	if (layout->pass_pr != 0)
		tmp |= EIOP_IFP_FA_PRV_EGGR;
	if (layout->pass_sw_opaque != 0)
		tmp |= EIOP_IFP_FA_SWOV_EGGR;
	if (layout->pass_ing_ad != 0)
		tmp |= EIOP_IFP_FA_IADV_EGGR;
	if (layout->pass_egr_ad != 0)
		tmp |= EIOP_IFP_FA_EADV_EGGR;


	return tmp;

}
static uint32_t fill_fd_fa(struct buf_layout *layout, enum fa_type type)
{
	if (type == E_INGRESS)
		return fill_fd_fa_ingress(layout);
	else
		return fill_fd_fa_egress(layout);

}

/**************************************************************************//**
 @Description   API functions
 *//***************************************************************************/
int eiop_ifp_rx_enable(const struct eiop_ifp_desc *desc)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)desc->vaddr;
	int i = 0;
	uint32_t tmp32;

	for(i = 0; i < IFP_MAX_NUM_OF_EXT_POOLS; i++) {
		tmp32 = ioread32(&regs->ifebmpi[i]);
		pr_debug("eiop_ifp_rx_enable, pool = %d, EIOP_IFP_IEMBPI_BPV = %s, EIOP_IFP_IEMBPI_BP = %s\n", i,
				(tmp32 & EIOP_IFP_IEMBPI_BPV)?"true":"false", (tmp32 & EIOP_IFP_IEMBPI_BP)?"true":"false");
		if ((tmp32 & EIOP_IFP_IEMBPI_BPV) &&
			!(tmp32 & EIOP_IFP_IEMBPI_BP))
		break;
	}
	if (i == IFP_MAX_NUM_OF_EXT_POOLS)
	{
		pr_err("ifp can not be enable - no valid rx buffer pools\n");
		return -EINVAL;
	}

	iowrite32(ioread32(&regs->ifpv) | EIOP_IFP_INGR_EN, &regs->ifpv);
	return 0;
}

void eiop_ifp_tx_enable(const struct eiop_ifp_desc *desc)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)desc->vaddr;

	iowrite32(ioread32(&regs->ifpv) | EIOP_IFP_EGGR_EN, &regs->ifpv);
}

int eiop_ifp_rx_is_enable(const struct eiop_ifp_desc *desc)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)desc->vaddr;
	uint32_t tmp32;

	ASSERT_COND(desc->vaddr);

	tmp32 = ioread32(&regs->ifpv);
	if ((tmp32 & EIOP_IFP_INGR_EN) == EIOP_IFP_INGR_EN)
		return 1;

	return 0;

}

int eiop_ifp_tx_is_enable(const struct eiop_ifp_desc *desc)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)desc->vaddr;
	uint32_t tmp32;

	tmp32 = ioread32(&regs->ifpv);
	if ((tmp32 & EIOP_IFP_EGGR_EN) == EIOP_IFP_EGGR_EN)
		return 1;

	return 0;

}
int eiop_ifp_rx_disable(void *ifp_regs)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)ifp_regs;

	iowrite32(ioread32(&regs->ifpv) & ~EIOP_IFP_INGR_EN, &regs->ifpv);

	return 0;
}

static int eiop_ifp_tx_disable(void *ifp_regs)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)ifp_regs;

	iowrite32(ioread32(&regs->ifpv) & ~EIOP_IFP_EGGR_EN, &regs->ifpv);

	return 0;
}
int eiop_ifp_rx_graceful_stop(const struct eiop_ifp_desc *desc)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)desc->vaddr;
	int tries;
	uint32_t tmp;

	ASSERT_COND(desc->vaddr);
	/*disable valid bit*/
	eiop_ifp_rx_disable(desc->vaddr);

	/*be sure valid bit is cleared*/
	tries = 100;
	do {
		tmp = ioread32(&regs->ifpv) & EIOP_IFP_INGR_EN;
	} while ((tmp == EIOP_IFP_INGR_EN) && --tries);

	if ((tmp == EIOP_IFP_INGR_EN) && tries == 0) {
		pr_err("function - eiop_ifp_rx_graceful_stop . "
		"Graceful stop can not be executed"
		"Can not clear valid bit.\n");
		return -ETIMEDOUT;

	}
	/*Poll till BSY is cleared - This ensures that no frames are being processed*/
	tries = 100;
	do {
		tmp = ioread32(&regs->ifibsy) & EIOP_IFP_INGR_BSY;
	} while ((tmp == EIOP_IFP_INGR_BSY) && --tries);
	if ((tmp == EIOP_IFP_INGR_BSY) && tries == 0) {
		pr_err("function - eiop_ifp_rx_graceful_stop . "
		"Graceful stop can not be executed"
		"BSY bit is not cleared.\n");
		return -ETIMEDOUT;

	}
	return 0;
}

int eiop_ifp_tx_graceful_stop(const struct eiop_ifp_desc *desc)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)desc->vaddr;
	int tries;
	uint32_t tmp;

	eiop_ifp_tx_disable(desc->vaddr);

	/*Poll till BSY is cleared - This ensures that no frames are being processed*/
	tries = 100;
	do {
		tmp = ioread32(&regs->ifebsy) & EIOP_IFP_EGGR_BSY;
	} while ((tmp == EIOP_IFP_EGGR_BSY) && --tries);
	if ((tmp == EIOP_IFP_EGGR_BSY) && tries == 0) {
		pr_err("function - eiop_ifp_tx_graceful_stop . "
		"Graceful stop can not be executed"
		"BSY bit is not cleared.\n");
		return -ETIMEDOUT;

	}
	return 0;
}

int eiop_ifp_set_max_frame_length(const struct eiop_ifp_desc *desc,
	int max_frame_length)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)desc->vaddr;

	if (max_frame_length > IFP_MAX_FRAME_LENGTH) {
		pr_err("max_frame_length should be in the range 0 - %d",
		       IFP_MAX_FRAME_LENGTH);
		return -EINVAL;
	}
	iowrite32((uint32_t)max_frame_length, &regs->ifml);

	return 0;
}

int eiop_ifp_set_macsec_enable(const struct eiop_ifp_desc *desc,
	int macsec_encrypts_channel)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)desc->vaddr;
	uint32_t tmp = 0;

	/*check  macsec_encrypts_channel in the range*/
	tmp = ioread32(&regs->ifpv);
	if ((tmp & EIOP_IFP_INGR_EN) != 0) {
		pr_err("Function can be called only when"
		"EIOP_IFP is disabled\n");
		return -EINVAL;
	}
	/*configuration of egress command register*/
	tmp = EIOP_IFP_EMCHAN_MCV;
	tmp |= (uint32_t)macsec_encrypts_channel << EIOP_IFP_EMCHAN_MCHAN_SHIFT;
	iowrite32(tmp, &regs->ifemchan);
	return 0;
}

int eiop_ifp_set_macsec_disable(const struct eiop_ifp_desc *desc)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)desc->vaddr;
	uint32_t tmp = 0;

	tmp = ioread32(&regs->ifpv);
	if ((tmp & (EIOP_IFP_INGR_EN | EIOP_IFP_EGGR_EN)) != 0) {
		{
			pr_err("eiop_ifp_set_macsec_disable can be called only when"
			"EIOP_IFP is disabled\n");
			return -EINVAL;
		}
	}
	/*configuration of egress command register*/
	tmp = tmp & ~EIOP_IFP_EMCHAN_MCV;
	iowrite32(tmp, &regs->ifemchan);

	return 0;
}

static int check_buffer_pools_cfg(const struct eiop_ifp_defcfg *defcfg,
	const struct eiop_ifp_cfg *cfg)
{
	int buffer_pools[IFP_MAX_NUM_OF_EXT_POOLS];
	int i = 0, k = 0;

	memset(buffer_pools, 0xffffffff,
		sizeof(int) * IFP_MAX_NUM_OF_EXT_POOLS);
	if ((cfg->num_of_pools_used + defcfg->num_of_backup_pools_used)
		> EIOP_IFP_MAX_NUM_OF_FBPS) {
		pr_err("num_of_pools_used is out of range."
		"The range is - %d, %d\n"
		"User defined num_of_pools_used = %d,"
		"num_of_backup_pools_used = %d \n", 0, EIOP_IFP_MAX_NUM_OF_FBPS, cfg->num_of_pools_used, defcfg->num_of_backup_pools_used);
		return -EINVAL;
	}
	for (i = 0; i < cfg->num_of_pools_used; i++) {
		if (cfg->pools_cfg[i].id > EIOP_IFP_MAX_BPID) {
			pr_err("buffer pool id %d out of range"
			"The range : %d - %d\n", cfg->pools_cfg[i].id, 0, EIOP_IFP_MAX_BPID);
			return -EINVAL;
		}
		for (k = 0; k < IFP_MAX_NUM_OF_EXT_POOLS; k++) {
			if (buffer_pools[k] == 0xffffffff)
				break;
			if (buffer_pools[k] == cfg->pools_cfg[i].id) {
				pr_err("user gave as argument the same buffer pools "
				"ids for 2 different buffers.\n "
				"The wrong id is %d\n", cfg->pools_cfg[i].id);
				return -EINVAL;
			}
		}
		CHECK_COND_RETVAL(k < IFP_MAX_NUM_OF_EXT_POOLS, -EINVAL);
		buffer_pools[k] = cfg->pools_cfg[i].id;
		if ((cfg->pools_cfg[i].size
			% EIOP_IFP_BMP_BUFFER_POOL_SIZE_UNITS)
			!= 0) {
			pr_err("buffer pools size %d for buffer pool id %d is not"
			"multiple of 64.\n ", cfg->pools_cfg[i].size, cfg->pools_cfg[i].id);
			return -EINVAL;
		}

		if ((cfg->pools_cfg[i].size
			/ EIOP_IFP_BMP_BUFFER_POOL_SIZE_UNITS)
			> EIOP_IFP_MAX_FBP_SIZE) {
			pr_err("buffer pools size %d for buffer pool id %d is out of range."
			"The range is: %d - %d \n.", cfg->pools_cfg[i].size, cfg->pools_cfg[i].id, 0, EIOP_IFP_MAX_FBP_SIZE);
			return -EINVAL;
		}
	}

	memset(buffer_pools, 0xffffffff,
		sizeof(int) * IFP_MAX_NUM_OF_EXT_POOLS);
	for (i = 0; i < defcfg->num_of_backup_pools_used; i++) {
		if (defcfg->backup_pool_cfg[i].id > EIOP_IFP_MAX_BPID) {
			pr_err("backup buffer pool id %d out of range."
			"The range is: %d, %d\n", defcfg->backup_pool_cfg[i].id, 0, EIOP_IFP_MAX_BPID);
			return -EINVAL;
		}
		for (k = 0; k < IFP_MAX_NUM_OF_EXT_POOLS; k++) {
			if (buffer_pools[k] == 0xffffffff)
				break;
			if (buffer_pools[k] == defcfg->backup_pool_cfg[i].id) {
				pr_err("user gave as argument the same buffer pools ids "
				"for 2 different buffers.\n "
				"The wrong id is %d\n", defcfg->backup_pool_cfg[i].id);
				return -EINVAL;
			}
		}
		CHECK_COND_RETVAL(k < IFP_MAX_NUM_OF_EXT_POOLS, -EINVAL);
		buffer_pools[k] = defcfg->backup_pool_cfg[i].id;
		if ((defcfg->backup_pool_cfg[i].size
			% EIOP_IFP_BMP_BUFFER_POOL_SIZE_UNITS)
			!= 0) {
			pr_err("backup buffer pools size %d for buffer pool id %d is not"
			"multiple of 64.\n ", defcfg->backup_pool_cfg[i].size, defcfg->backup_pool_cfg[i].id);
			return -EINVAL;
		}

		if ((defcfg->backup_pool_cfg[i].size
			/ EIOP_IFP_BMP_BUFFER_POOL_SIZE_UNITS)
			> EIOP_IFP_MAX_FBP_SIZE) {
			pr_err("backup buffer pools size %d for buffer pool id "
			"%d is out of range."
			"The range is: %d, - %d \n.\n ", defcfg->backup_pool_cfg[i].size, defcfg->backup_pool_cfg[i].id, 0, EIOP_IFP_MAX_FBP_SIZE);
			return -EINVAL;
		}
	}
	return 0;
}
static int check_default_cfg(const struct eiop_ifp_cfg *cfg)
{
	if (cfg->default_cfg.qd_id > EIOP_IFP_MAX_NUM_OF_QDIDS) {
		pr_err("default_cfg.qd_id  = %d is out of range "
		"The range is: %d, %d \n", cfg->default_cfg.qd_id, 0, EIOP_IFP_MAX_NUM_OF_QDIDS);
		return -EINVAL;
	}
	if (cfg->default_cfg.replic_list_id > EIOP_IFP_MAX_NUM_OF_REPLIC_IDS) {
		pr_err("default_cfg.replic_list_id  = %d is out of range "
		"The range is: %d -  %d \n", cfg->default_cfg.replic_list_id, 0, EIOP_IFP_MAX_NUM_OF_REPLIC_IDS);
		return -EINVAL;
	}
	return 0;

}

int eiop_ifp_check_buffer_layout(const struct eiop_ifp_defcfg *defcfg,
	const struct buf_layout *buf_layout, int rx)
{
	if (buf_layout->priv_data_size > EIOP_IFP_PTA_SIZE) {
		pr_err("priv_data_size = %d is not in the range."
		" Range is  %d - %d\n", buf_layout->priv_data_size, 0, EIOP_IFP_PTA_SIZE);
		return -EINVAL;
	}

	if (rx) {
		if (buf_layout->data_headroom
			> EIOP_IFP_DEFCFG_RX_BUF_LAYOUT_DHR) {
			pr_err("data_headroom = %d is out of range."
			" The range is: %d - %d\n", buf_layout->data_headroom, 0, EIOP_IFP_DEFCFG_RX_BUF_LAYOUT_DHR);
			return -EINVAL;
		}

		if ((buf_layout->data_headroom % 64 != 0)
			&& (defcfg->options
				& EIOP_IFP_DEFCFG_OPT_SET_WRITE_OPTIMIZE))
			pr_warn("data_headroom is not aligned to 64 and "
			"EIOP_IFP_DEFCFG_OPT_SET_WRITE_OPTIMIZE is set"
			" may be corrupted area of data_headroom.\n");

		if (buf_layout->data_tailroom
			> EIOP_IFP_DEFCFG_RX_BUF_LAYOUT_BEM) {
			pr_err("data_tailroom = %d is out of range."
			" The range is: %d - %d\n", buf_layout->data_tailroom, 0, EIOP_IFP_DEFCFG_RX_BUF_LAYOUT_BEM);
			return -EINVAL;
		}

#ifdef ERR009354
	{
		uint32_t data_offset = 0;
		eiop_ifp_get_data_offset(buf_layout, &data_offset, 1);
		if ((data_offset % 256) != 0) {
			pr_err("ERR009354 requires that data-offset "
			"(currently %d) is a multiple of 256\n", data_offset);
			return -EINVAL;
		}
	}
#endif /* ERR009354 */

	} else {

		if (buf_layout->data_headroom != 0) {
			pr_err("data_headroom = %d MUST be 0.\n");
			return -EINVAL;
		}

		if (buf_layout->data_tailroom != 0) {
			pr_err("data_tailroom = %d MUST be 0.\n");
			return -EINVAL;
		}
	}

	return 0;
}

static int check_cfg(const struct eiop_ifp_cfg *cfg)
{
	int err;

	const struct eiop_ifp_defcfg *defcfg = &cfg->defcfg;

	if (cfg->rx_err_fqid > EIOP_IFP_MAX_NUM_OF_FQIDS) {
		pr_err("rx_err_fqid  = %d is out of range.\n"
		"The range is: %d - %d \n", cfg->rx_err_fqid, 0, EIOP_IFP_MAX_NUM_OF_FQIDS);
		return -EINVAL;
	}

	if (cfg->tx_err_fqid > EIOP_IFP_MAX_NUM_OF_FQIDS) {
		pr_err("tx_err_fqid  = %d is out of range.\n"
		"The range is: %d - %d", cfg->tx_err_fqid, 0, EIOP_IFP_MAX_NUM_OF_FQIDS);
		return -EINVAL;
	}
	if ((defcfg->options & EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION)
		== 0) {
		if (defcfg->icid > EIOP_IFP_MAX_NUM_OF_ICIDS) {
			pr_err("icid = %d is out of range.\n"
			"The range is: %d - %d", defcfg->icid, 0, EIOP_IFP_MAX_NUM_OF_ICIDS);
			return -EINVAL;
		}
	}

	if (cfg->max_frame_length > IFP_MAX_FRAME_LENGTH) {
		pr_err("max_frame_length should be in the range 0 - %d", IFP_MAX_FRAME_LENGTH);
		return -EINVAL;
	}

	err = eiop_ifp_check_buffer_layout(defcfg, &defcfg->rx_buf_layout, 1);
	if (err) {
		pr_err("rx buffer layout\n");
		return err;
	}

	err = eiop_ifp_check_buffer_layout(defcfg, &defcfg->tx_buf_layout, 0);
	if (err) {
		pr_err("tx buffer layout\n");
		return err;
	}

	err = eiop_ifp_check_buffer_layout(defcfg, &defcfg->txconf_buf_layout, 0);
	if (err) {
		pr_err("tx conf buffer layout\n");
		return err;
	}

	err = check_buffer_pools_cfg(defcfg, cfg);
	if (err)
		return err;

	err = check_default_cfg(cfg);
	if (err)
		return err;

	return 0;
}
static void fill_rx_buffer_layout(const struct buf_layout *user_buf_layout,
	struct buf_layout *buf_layout)
{
	/* Rx buf_layout */
	buf_layout->pass_fas = user_buf_layout->pass_fas;
	buf_layout->pass_ts = user_buf_layout->pass_ts;
	buf_layout->pass_pr = user_buf_layout->pass_pr;
	buf_layout->priv_data_size = user_buf_layout->priv_data_size;
	if (!user_buf_layout->data_align)
		buf_layout->data_align = DEFAULT_IFP_RX_LO_DATA_ALIGM;
	else
		buf_layout->data_align = user_buf_layout->data_align;
	buf_layout->pass_sw_opaque = user_buf_layout->pass_sw_opaque;
	buf_layout->pass_ing_ad = user_buf_layout->pass_ing_ad;
	buf_layout->pass_egr_ad = user_buf_layout->pass_egr_ad;

}

static void fill_tx_buffer_layout(const struct buf_layout *user_buf_layout,
	struct buf_layout *buf_layout)
{
	/* Rx buf_layout */
	buf_layout->pass_fas = user_buf_layout->pass_fas;
	buf_layout->pass_sw_opaque = user_buf_layout->pass_sw_opaque;
	buf_layout->pass_ing_ad = user_buf_layout->pass_ing_ad;
	buf_layout->pass_egr_ad = user_buf_layout->pass_egr_ad;

}

static void fill_txconf_buffer_layout(const struct buf_layout *user_buf_layout,
	struct buf_layout *buf_layout)
{
	/* Rx buf_layout */
	buf_layout->pass_fas = user_buf_layout->pass_fas;
	buf_layout->pass_ts = user_buf_layout->pass_ts;
	buf_layout->pass_ing_ad = user_buf_layout->pass_ing_ad;
	buf_layout->pass_egr_ad = user_buf_layout->pass_egr_ad;

}

static void fill_ifp_ingress(const struct eiop_ifp_desc *eiop_ifp_desc,
	const struct eiop_ifp_cfg *cfg)
{
	struct eiop_ifp_regs *regs =
		(struct eiop_ifp_regs *)eiop_ifp_desc->vaddr;
	uint32_t tmp32 = 0,tmp32_tmp = 0;
	uint32_t hwal, data_offset, delta_for_data_align, errors;
	int err, i;
	struct buf_layout buf_layout;
	struct eiop_ifp_rx_vlan_cfg rx_vlan_cfg;
	struct eiop_ifp_err_cfg err_cfg;
	struct ldpa_buf_pool_cfg ord_pools_cfg[IFP_MAX_NUM_OF_EXT_POOLS];
	uint8_t priority_mask;
	tmp32 = 0;
#ifdef MC_CLI
	tmp32 |= EIOP_IFP_ICID_FAC_STASH
	    | EIOP_IFP_ICID_FHC_STASH
		| EIOP_IFP_ICID_SGC_STASH
		| EIOP_IFP_ICID_WOPT
        | EIOP_IFP_ICID_FPC_STASH;
#else
#if 0
	tmp32 |= EIOP_IFP_ICID_FAC_STASH
	    | EIOP_IFP_ICID_FHC_STASH
		| EIOP_IFP_ICID_SGC_STASH;
#endif
#endif

	if ((cfg->defcfg.options & EIOP_IFP_DEFCFG_OPT_SET_HEADER_STASHING) == EIOP_IFP_DEFCFG_OPT_SET_HEADER_STASHING)
		tmp32 |= EIOP_IFP_ICID_FHC_STASH;
	if ((cfg->defcfg.options & EIOP_IFP_DEFCFG_OPT_SET_PAYLOAD_STASHING) == EIOP_IFP_DEFCFG_OPT_SET_PAYLOAD_STASHING)
		tmp32 |= EIOP_IFP_ICID_FPC_STASH;

	if ((cfg->defcfg.options
		& EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION)
		== EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION)
		tmp32 |= EIOP_IFP_ICID_BDI;
	if ((cfg->defcfg.options & EIOP_IFP_DEFCFG_OPT_SET_PRIVIL_LEVEL)
		== EIOP_IFP_DEFCFG_OPT_SET_PRIVIL_LEVEL)
		tmp32 |= EIOP_IFP_ICID_PL;
	if ((cfg->defcfg.options & EIOP_IFP_DEFCFG_OPT_SET_WRITE_OPTIMIZE)
		== EIOP_IFP_DEFCFG_OPT_SET_WRITE_OPTIMIZE)
		tmp32 |= EIOP_IFP_ICID_WOPT;
	
	if ((cfg->defcfg.options & EIOP_IFP_DEFCFG_OPT_SET_BUFFER_POOL_ON_QDBIN)
		== EIOP_IFP_DEFCFG_OPT_SET_BUFFER_POOL_ON_QDBIN)
		tmp32 |= EIOP_IFP_ICID_BPAS;

	tmp32 |= (cfg->defcfg.icid & EIOP_IFP_ICID_MASK);
	iowrite32(tmp32, &regs->ifiicid);
#ifdef MC_CLI
    pr_user("ifiicid %p 0x%08x\n", &regs->ifiicid, tmp32);
#endif


	/*initialization of ifspff*/
	memset(&buf_layout, 0, sizeof(struct buf_layout));
	fill_rx_buffer_layout(&cfg->defcfg.rx_buf_layout, &buf_layout);
	calc_hwal_offset(&buf_layout, &hwal, E_LAYOUT_RX);
	if (((uint32_t)hwal % EIOP_IFP_SPFF_ASAR_UNITS) == 0)
		tmp32 = ((uint32_t)hwal / EIOP_IFP_SPFF_ASAR_UNITS)
			<< EIOP_IFP_IFSPFF_ASAR_SHIFT;
	else
		tmp32 = (((uint32_t)hwal / EIOP_IFP_SPFF_ASAR_UNITS) + 1)
			<< EIOP_IFP_IFSPFF_ASAR_SHIFT;
	if (cfg->defcfg.rx_buf_layout.priv_data_size)
		tmp32 |= EIOP_IFP_IFSPFF_PTAR;
	if (cfg->defcfg.rx_buf_layout.no_sg)
		tmp32 |= EIOP_IFP_IFSPFF_FF;
	if ((cfg->defcfg.options & EIOP_IFP_DEFCFG_OPT_SET_VIRT_ADDR)
		== EIOP_IFP_DEFCFG_OPT_SET_VIRT_ADDR)
		tmp32 |= EIOP_IFP_IFSPFF_VA;
	calc_data_offset(&cfg->defcfg.rx_buf_layout, hwal, &data_offset,
		&delta_for_data_align);
	tmp32 |= ((cfg->defcfg.rx_buf_layout.data_headroom +
		delta_for_data_align) & 0xfff);
	iowrite32(tmp32, &regs->ifispff);


	/*initialization of ingress Ingress External Buffer Margins Register*/
	tmp32 = cfg->defcfg.rx_buf_layout.data_tailroom;
	iowrite32(tmp32, &regs->ifiebm);


	/*initialization of ingress external buffers manager pool information
	 register*/
	set_buff_pools_in_asc_order((uint16_t)cfg->num_of_pools_used,
					cfg->defcfg.num_of_backup_pools_used,
					cfg->pools_cfg,
					cfg->defcfg.backup_pool_cfg,
					ord_pools_cfg);
	for (i = 0;
		i
		< cfg->num_of_pools_used + cfg->defcfg.num_of_backup_pools_used;
		i++) {
		tmp32 = 0;
		tmp32 |= (uint32_t)ord_pools_cfg[i].id
				<< EIOP_IFP_IEBMPI_BPID_SHIFT;
		tmp32 |= ((uint32_t)ord_pools_cfg[i].size
				/ EIOP_IFP_BMP_BUFFER_POOL_SIZE_UNITS)
				<< EIOP_IFP_IEBMPI_PBS_SHIFT;
		if (i >= cfg->num_of_pools_used)
			tmp32 |= EIOP_IFP_IEMBPI_BP;
		if ((ord_pools_cfg[i].options
			& EIOP_IFP_BUF_POOL_OPT_SCARCE_RESOURCE)
			== EIOP_IFP_BUF_POOL_OPT_SCARCE_RESOURCE)
			tmp32 |= EIOP_IFP_IEMBPI_SR;
		if ((ord_pools_cfg[i].options & EIOP_IFP_BUF_POOL_OPT_BMT)
			== EIOP_IFP_BUF_POOL_OPT_BMT)
			tmp32 |= EIOP_IFP_IEMBPI_BMT;
		tmp32 |= EIOP_IFP_IEMBPI_BPV;

		iowrite32(tmp32, &regs->ifebmpi[i]);
		
		/*initialization of priority mask of buffer_pool*/
		if(ord_pools_cfg[i].priority_mask == 0)
			priority_mask = 0xff;
		else
			priority_mask = REVERSE_BITS_u8(ord_pools_cfg[i].priority_mask); // seems the wriop priority is inverted
		if((i % 4) == 0)
			tmp32_tmp = 0;			
		tmp32_tmp |= (uint32_t)priority_mask << (24-8*(i % 4));
		iowrite32(tmp32_tmp, &regs->ifebmpp[i/4]);
	}

	/*initialization of ingress frame QDID register*/
	tmp32 = ((uint32_t)fill_fd_fa(&buf_layout, E_INGRESS));
	tmp32 |= (uint32_t)cfg->default_cfg.qd_id;
	iowrite32(tmp32, &regs->ifiqdid);

	/*initialization of ingress frame QDID register*/
	iowrite32((uint32_t)cfg->rx_err_fqid, &regs->ifiefqid);

	/*initialization of ingress maximum frame length*/
	iowrite32((uint16_t)cfg->max_frame_length, &regs->ifml);

	//tmp32 = 0xffffffff;
	//iowrite32(tmp32, &regs->ifebmpp_0);
	//iowrite32(tmp32, &regs->ifebmpp_1);

	if (cfg->errors_settings != EIOP_IFP_CFG_OPT_ERROR_SKIP_CFG) {
		/*initialization of FSDM, FSEM, FSEQM, FSVM*/
		tmp32 = EIOP_IFP_FSDM_DISCV;
		iowrite32(tmp32, &regs->ififsdm);

		memset(&err_cfg, 0, sizeof(struct eiop_ifp_err_cfg));		
		if (cfg->errors_settings == EIOP_IFP_CFG_OPT_ERROR_DEFAULT)
		{
			err_cfg.action = EIOP_IFP_ERR_DROP;
			errors = DEFAULT_ERRORS_TO_DISCARD;
			eiop_ifp_set_err_behavior(eiop_ifp_desc, errors, &err_cfg);
		}else
		{
			eiop_ifp_set_err_behavior_limit_drop(eiop_ifp_desc);
		}
			
	} else
		iowrite32(ioread32(&regs->ififsdm) | EIOP_IFP_FSDM_DISCV,
				&regs->ififsdm);

	/*initialization of ifivlan, ifivmode*/
	memset(&rx_vlan_cfg, 0, sizeof(struct eiop_ifp_rx_vlan_cfg));
	rx_vlan_cfg.action = EIOP_IFP_RX_VLAN_ACTION_NONE;
	err = eiop_ifp_rx_vlan_cfg(eiop_ifp_desc, &rx_vlan_cfg);
	ASSERT_COND(!err);

}

static void fill_ifp_egress(const struct eiop_ifp_desc *eiop_ifp_desc,
	const struct eiop_ifp_cfg *cfg)
{
	struct eiop_ifp_regs *regs =
		(struct eiop_ifp_regs *)eiop_ifp_desc->vaddr;
	uint32_t tmp32 = 0;
	struct eiop_ifp_tx_vlan_cfg tx_vlan_cfg;
	struct buf_layout buf_layout;
	int err;

	/*initialization of egress read annotation register*/
	memset(&buf_layout, 0, sizeof(struct buf_layout));
	fill_tx_buffer_layout(&cfg->defcfg.tx_buf_layout, &buf_layout);
	tmp32 = (uint32_t)fill_fd_fa(&buf_layout, E_EGRESS);
	iowrite32(tmp32, &regs->ifera);

	/*initialization of egress write annotation register*/
	memset(&buf_layout, 0, sizeof(struct buf_layout));
	fill_txconf_buffer_layout(&cfg->defcfg.txconf_buf_layout, &buf_layout);
	tmp32 = (uint32_t)fill_fd_fa(&buf_layout, E_EGRESS);
	iowrite32(tmp32, &regs->ifewa);

	/*initialization of egress error frame queue ID register*/
	iowrite32((uint32_t)cfg->tx_err_fqid, &regs->ifeefqid);

	/*initialization of ifevlan, ifevmode*/
	memset(&tx_vlan_cfg, 0, sizeof(struct eiop_ifp_tx_vlan_cfg));
	tx_vlan_cfg.action = EIOP_IFP_TX_VLAN_ACTION_NONE;
	err = eiop_ifp_tx_vlan_cfg(eiop_ifp_desc, &tx_vlan_cfg);
	//ASSERT_COND(!err);

}

static void fill_ifp_extention(const struct eiop_ifp_desc *eiop_ifp_desc,
	const struct eiop_ifp_cfg *cfg)
{
	struct eiop_ifp_ext_regs *regs_ext =
		(struct eiop_ifp_ext_regs *)eiop_ifp_desc->vaddr;
	uint32_t tmp32;

	tmp32 = 0;

	if( cfg->default_cfg.options & EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_PASSTHRU ) {
		tmp32 &= ~EIOP_IFP_EXT_RX_FLC_TYPE_MASK;
		tmp32 |= EIOP_IFP_EXT_RX_FLC_TYPE_PASSTHRU;
	}
	else {
		if (cfg->default_cfg.options
			& EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_REPLIC_ID)
			tmp32 &= ~EIOP_IFP_EXT_RX_FLC_TYPE_MASK;

		if (cfg->default_cfg.options
			& EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_FOR_AIOP)
			tmp32 |= EIOP_IFP_EXT_RX_FLC_TYPE_AIOP;

		if (((cfg->default_cfg.options
			& EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_FOR_AIOP)
			== 0)
			&& ((cfg->default_cfg.options
				& EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_REPLIC_ID)
				== 0))
			tmp32 |= EIOP_IFP_EXT_RX_FLC_TYPE_GPP;
	}

	if (cfg->default_cfg.options
			& EIOP_IFP_DEFAULT_CFG_OPT_SET_STASHING_CNTRL)
		tmp32 |= EIOP_IFP_EXT_RX_SC_SET;
	iowrite32(tmp32, &regs_ext->cidef5_info);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs_ext->cidef5_info);
#endif

	iowrite32((uint32_t)(cfg->default_cfg.opaque >> 32),
			&regs_ext->cidef6_opaque_high);
#ifdef ERR008425
	execute_errata_008425 ((uint32_t)(cfg->default_cfg.opaque >> 32),
					regs_ext->cidef6_opaque_high);
#endif

	iowrite32((uint32_t)(cfg->default_cfg.opaque),
			&regs_ext->cidef6_opaque_low);
#ifdef ERR008425
	execute_errata_008425 ((uint32_t)(cfg->default_cfg.opaque),
							regs_ext->cidef6_opaque_low);
#endif

	tmp32 = ((uint32_t)cfg->default_cfg.qd_id
			| ((uint32_t)cfg->default_cfg.replic_list_id << 16));

	iowrite32(tmp32, &regs_ext->cidef4_replic_id_qdid);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs_ext->cidef4_replic_id_qdid);
#endif

	tmp32 = build_rx_skip_info(0);
	if (cfg->default_cfg.options & EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_OPAQUE)
		tmp32 |= EIOP_IFP_EXT_RX_OPAQUEV;
	if (cfg->default_cfg.options & EIOP_IFP_DEFAULT_CFG_OPT_SET_IPRE)
		tmp32 |= EIOP_IFP_RX_EXT_IPRE;
	iowrite32(tmp32, &regs_ext->cidef0_rx_policy_id_skip_qos_map);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs_ext->cidef0_rx_policy_id_skip_qos_map);
#endif

	tmp32 = build_tx_skip_info(0);
	iowrite32(tmp32, &regs_ext->cedef0_tx_info1_skip_info2);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs_ext->cedef0_tx_info1_skip_info2);
#endif

}
static void fill_ifp_regs(const struct eiop_ifp_desc *eiop_ifp_desc,
	const struct eiop_ifp_cfg *cfg)
{
	fill_ifp_ingress(eiop_ifp_desc, cfg);
	fill_ifp_egress(eiop_ifp_desc, cfg);
	fill_ifp_extention(eiop_ifp_desc, cfg);

}

static int mng_cmd_check_err(struct mng_cmd_desc *mng_cmd_desc)
{
	int err = 0;

	/* This is the confirmation stage, there must be something in the MTYPE field */
	ASSERT_COND(
		(LE32_TO_CPU(mng_cmd_desc->misc_mtype) & MNG_CMD_DESC_MTYPE_MASK) != ILLEGAL_MTYPE);

	/* management command errors */
	/* HW received invalid descriptor */
	ASSERT_COND(
		!(LE32_TO_CPU(mng_cmd_desc->err) & MNG_CMD_DESC_ERR_MGCNV));
	/* Message size error */
	ASSERT_COND( !(LE32_TO_CPU(mng_cmd_desc->err) & MNG_CMD_DESC_ERR_FSE));
	/* Invalid MTYPE value */
	ASSERT_COND(
		!(LE32_TO_CPU(mng_cmd_desc->status_mem_attr) & MNG_CMD_DESC_FRC_MGINV));

	/* Bus error */
	if (LE32_TO_CPU(mng_cmd_desc->err) & MNG_CMD_DESC_ERR_SBE) { /* Mark MCD as confirmed */
		mng_cmd_desc->misc_mtype = CPU_TO_LE32(ILLEGAL_MTYPE);
		core_memory_barrier();
		pr_err("Bus Error\n");
		return -EFAULT;
	}
	return err;
}

int eiop_ifp_init_pools(const struct eiop_ifp_desc *eiop_ifp_desc,
	const struct eiop_ifp_cfg *cfg)
{
	void *regs = eiop_ifp_desc->vaddr;
	int err;

	err = check_cfg(cfg);
	if (err)
		return err;

	if (cfg->use_mng_cmd)
		/* initialize Management command parameters */
		mng_cmd_init(regs, cfg);
	
	fill_ifp_ingress(eiop_ifp_desc, cfg);
	fill_ifp_extention(eiop_ifp_desc, cfg);
	
	return 0;
}

int eiop_ifp_init_egress(const struct eiop_ifp_desc *eiop_ifp_desc,
	const struct eiop_ifp_cfg *cfg)
{
	void *regs = eiop_ifp_desc->vaddr;
	int err;

	err = check_cfg(cfg);
	if (err)
		return err;

	if (cfg->use_mng_cmd)
		/* initialize Management command parameters */
		mng_cmd_init(regs, cfg);
	
	fill_ifp_egress(eiop_ifp_desc, cfg);

	return 0;
}

int eiop_ifp_init(const struct eiop_ifp_desc *eiop_ifp_desc,
	const struct eiop_ifp_cfg *cfg)
{
	void *regs = eiop_ifp_desc->vaddr;
	int err;

	err = check_cfg(cfg);
	if (err)
		return err;

	if (cfg->use_mng_cmd)
		/* initialize Management command parameters */
		mng_cmd_init(regs, cfg);
	
	fill_ifp_regs(eiop_ifp_desc, cfg);

	return 0;
}

int eiop_ifp_set_enqueue_ifp(const struct eiop_ifp_desc *desc, int ifp_id)

{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs*)desc->vaddr;
	uint32_t tmp;

	tmp = ioread32(&regs->ifpv);

	if ((tmp & EIOP_IFP_EGGR_EN) || (tmp & EIOP_IFP_INGR_EN)) {
		pr_err("Function eiop_ifp_set_enqueue_ifp can be called "
		"only if IFP disable\n");
		return -EINVAL;

	}
	iowrite32((ioread32(&regs->ififpid) & ~0xfff) | ifp_id,
			&regs->ififpid);

	return 0;
}

static int check_rx_pcd_cfg(struct eiop_ifp_rx_pcd_cfg *cfg)
{
	int err = 0;

	if (((cfg->activate_modules
		& (EIOP_IFP_ACTIVATE_MODULE_LOOKUP
			| EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION
			| EIOP_IFP_ACTIVATE_MODULE_QoS_MAPPING
			| EIOP_IFP_ACTIVATE_MODULE_POLICY))
		!= 0)
		&& ((cfg->activate_modules & EIOP_IFP_ACTIVATE_MODULE_PARSER)
			!= EIOP_IFP_ACTIVATE_MODULE_PARSER)) {
		pr_err("If activate_modules for rx PCD includes at least "
		"of one of the next options :"
		"EIOP_IFP_ACTIVATE_MODULE_LOOKUP,"
		"EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION ,"
		"EIOP_IFP_ACTIVATE_MODULE_QoS_MAP_METHOD,"
		"EIOP_IFP_ACTIVATE_MODULE_POLICY -"
		"PARSER MUST be set.\n");
		return -EINVAL;
	}
	if (cfg->activate_modules & EIOP_IFP_ACTIVATE_MODULE_PARSER) {
		err = dpparser_check_hxs(cfg->parser.start_hxs);
		CHECK_COND_RETVAL(err == 0, err);
		
		if (cfg->parser.profile_id
			> EIOP_IFP_MAX_NUM_OF_PARSER_PROFILE_IDS) {
			pr_err("Parser is activated for Rx PCD ,"
			"Parser profile_id  = %d is out of range."
			"The range is: %d - %d \n", cfg->parser.profile_id, 0, EIOP_IFP_MAX_NUM_OF_PARSER_PROFILE_IDS);
			return -EINVAL;
		}
#ifdef ERR008637
		if ((cfg->parser.start_hxs != 0) ||
				(cfg->parser.start_offset != 0)) {
			pr_err("Parser start_hdr should be only ETH "
					"and start_offset should be only 0\n");
			return -EINVAL;
		}
#endif
		}

	if (cfg->activate_modules & EIOP_IFP_ACTIVATE_MODULE_POLICER) {
		if (cfg->default_policer.profile_id
			> EIOP_IFP_MAX_NUM_OF_POLICER_PROFILE_IDS) {
			pr_err("Policer is activated for Rx PCD , "
			"Policer profile_id = %d is out of range."
			"The range is: %d, - %d \n", cfg->default_policer.profile_id, 0, EIOP_IFP_MAX_NUM_OF_POLICER_PROFILE_IDS);
			return -EINVAL;
		}
	}

	if (cfg->activate_modules & EIOP_IFP_ACTIVATE_MODULE_LOOKUP) {

		if (cfg->default_lookup.dpkg_profile_id
			> EIOP_IFP_MAX_NUM_OF_DPKG_PROFILE_IDS) {
			pr_err("Lookup is activated for Rx PCD ,"
			"Lookup dpkg_profile_id = %d is out of range."
			"The range is: %d, - %d \n", cfg->default_lookup.dpkg_profile_id, 0, EIOP_IFP_MAX_NUM_OF_DPKG_PROFILE_IDS);
			return -EINVAL;
		}

		if (cfg->default_lookup.dptbl_id > EIOP_IFP_MAX_NUM_OF_TBL_IDS) {
			pr_err("Lookup is activated for Rx PCD ,"
			"Lookup -  dptbl_id = %d is out of range."
			"The range is: %d, - %d \n", cfg->default_lookup.dptbl_id, 0, EIOP_IFP_MAX_NUM_OF_TBL_IDS);
			return -EINVAL;
		}
	}

	if (cfg->activate_modules & EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION) {
		if (cfg->default_hash_generation.profile_id
			> EIOP_IFP_MAX_NUM_OF_DPKG_PROFILE_IDS) {
			pr_err("Hash generation is activated for Rx PCD , but "
			"Hash profile_id = %d is out of range."
			"The range is: %d, - %d \n", cfg->default_hash_generation.profile_id, 0, EIOP_IFP_MAX_NUM_OF_DPKG_PROFILE_IDS);
			return -EINVAL;
		}
	}

	if (cfg->default_qos_map_method == EIOP_IFP_QoS_BASED_ON_FCV) {
		pr_err("default_qos_map_method  EIOP_IFP_QoS_BASED_ON_FCV "
				"is not supprted yet\n");
			return -EINVAL;

	}

	return 0;
}

int eiop_ifp_rx_pcd_set(const struct eiop_ifp_desc *desc,
	struct eiop_ifp_rx_pcd_cfg *cfg)
{
	uint32_t tmp32 = 0;
	uint32_t skip_info;
	struct eiop_ifp_ext_regs *regs =
		(struct eiop_ifp_ext_regs *)desc->vaddr;
	int err;


	err = check_rx_pcd_cfg(cfg);
	CHECK_COND_RETVAL(err == 0, err);
	
	skip_info = build_rx_skip_info(cfg->activate_modules);

	/*initialization of ingress CTLU initial IFP */
	tmp32 =
		(cfg->parser.profile_id
			| ((uint32_t)cfg->parser.start_offset
				<< EIOP_IFP_EXT_INGR_PARSER_START_OFFSET_SHIFFT)
			| ((((uint32_t)cfg->parser.start_hxs)
				<< EIOP_IFP_EXT_INGR_PARSER_START_HXS_SHIFFT)
				& EIOP_IFP_EXT_INGR_PARSER_START_HXS_MASK)
			| ((cfg->parser.rx_options
				& EIOP_IFP_PARSER_RX_OPT_L3_CHECKSUM_VALIDATE) ?
				EIOP_IFP_EXT_PARSER_L3CSV : 0)
			| ((cfg->parser.rx_options
				& EIOP_IFP_PARSER_RX_OPT_L4_CHECKSUM_VALIDATE) ?
				EIOP_IFP_EXT_PARSER_L4CSV : 0));
	iowrite32(tmp32, &regs->cidef3_parser);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs->cidef3_parser);
#endif

	/* read and get previously defined relevant parameters */
	tmp32 = (uint32_t)(ioread32(&regs->cidef0_rx_policy_id_skip_qos_map)
				& (EIOP_IFP_EXT_RX_OPAQUEV|EIOP_IFP_RX_EXT_IPRE));

	tmp32 |= skip_info;

	if ((skip_info & EIOP_IFP_EXT_RX_SKIP_LK) == 0)
		tmp32 |= EIOP_IFP_RX_EXT_TKIDV;

	if ((skip_info & EIOP_IFP_EXT_RX_SKIP_HASH_GEN) == 0)
		tmp32 |= EIOP_IFP_RX_EXT_HKIDV;

	if (cfg->default_qos_map_method == EIOP_IFP_QoS_BASED_ON_VLAN_PRI)
		tmp32 |= EIOP_IFP_RX_EXT_QoS_BASED_ON_VLAN;
	else
		tmp32 |= EIOP_IFP_RX_EXT_QoS_BASED_ON_IP;

	tmp32 |= (uint32_t)(cfg->policy.profile_id
				<< EIOP_IFP_EXT_INGR_POLICY_PROFILE_ID_SHIFT);

	iowrite32(tmp32, &regs->cidef0_rx_policy_id_skip_qos_map);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs->cidef0_rx_policy_id_skip_qos_map);
#endif

	tmp32 = (((uint32_t)cfg->default_lookup.dptbl_id
			<< EIOP_IFP_EXT_INGR_DPTBL_ID_SHIFT)
			| ((uint32_t)cfg->default_lookup.dpkg_profile_id
				<< EIOP_IFP_EXT_INGR_DPKG_PROFILE_ID_SHIFT)
			| (uint32_t)cfg->default_hash_generation.profile_id);

	iowrite32(tmp32, &regs->cidef1_rx_tid_kid_hkid);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs->cidef1_rx_tid_kid_hkid);
#endif

	iowrite32(
		(uint32_t)cfg->default_policer.profile_id
		<< EIOP_IFP_EXT_INGR_POLICER_PROFILE_ID_SHIFT,
		&regs->cidef2_rx_plid);
#ifdef ERR008425
	execute_errata_008425 ((uint32_t)cfg->default_policer.profile_id
			<< EIOP_IFP_EXT_INGR_POLICER_PROFILE_ID_SHIFT,
					regs->cidef2_rx_plid);
#endif

	return 0;
}


void eiop_ifp_rx_pcd_set_policer_profile_id (const struct eiop_ifp_desc *desc,
						int profile_id)
{
	struct eiop_ifp_ext_regs *regs =
		(struct eiop_ifp_ext_regs *)desc->vaddr;

	iowrite32(
		(uint32_t)profile_id
		<< EIOP_IFP_EXT_INGR_POLICER_PROFILE_ID_SHIFT,
		&regs->cidef2_rx_plid);
#ifdef ERR008425
	execute_errata_008425 ((uint32_t)profile_id
			<< EIOP_IFP_EXT_INGR_POLICER_PROFILE_ID_SHIFT,
					regs->cidef2_rx_plid);
#endif

}

static int check_tx_pcd_cfg(struct eiop_ifp_tx_pcd_cfg *cfg)
{
	int err = 0;

	if ((cfg->activate_modules
		& (~EIOP_IFP_ACTIVATE_MODULE_PARSER
			& ~EIOP_IFP_ACTIVATE_MODULE_LOOKUP))
		!= 0) {
		pr_err("For activate_modules tx PCD the only allowed options are: "
		"EIOP_IFP_ACTIVATE_MODULE_PARSER"
		"AND/OR EIOP_IFP_ACTIVATE_MODULE_LOOKUP\n");
		return -EINVAL;
	}

	if ((cfg->activate_modules & EIOP_IFP_ACTIVATE_MODULE_LOOKUP)
		&& !(cfg->activate_modules & EIOP_IFP_ACTIVATE_MODULE_PARSER)) {
		pr_err("Lookup is activated for Tx PCD ,"
		"EIOP_IFP_ACTIVATE_MODULE_PARSER MUST be activated\n");
		return -EINVAL;
	}

	if (cfg->activate_modules & EIOP_IFP_ACTIVATE_MODULE_PARSER) {		
		err = dpparser_check_hxs(cfg->parser.start_hxs);
		CHECK_COND_RETVAL(err == 0, err);
		
		if (cfg->parser.profile_id
			> EIOP_IFP_MAX_NUM_OF_PARSER_PROFILE_IDS) {
			pr_err("Parser is activated for Tx PCD ,"
			"Parser profile_id = %d is out of range."
			"The range is: %d, - %d \n", cfg->parser.profile_id, 0, EIOP_IFP_MAX_NUM_OF_PARSER_PROFILE_IDS);
			return -EINVAL;
		}
#ifdef ERR008637
		if ((cfg->parser.start_hxs != 0) ||
				(cfg->parser.start_offset != 0)) {
			pr_err("Parser start_hdr should be only ETH "
					"and start_offset should be only 0\n");
			return -EINVAL;
		}
#endif
		}

	if (cfg->activate_modules & EIOP_IFP_ACTIVATE_MODULE_LOOKUP) {
		if (cfg->default_lookup.dpkg_profile_id
			> EIOP_IFP_MAX_NUM_OF_DPKG_PROFILE_IDS) {
			pr_err("Lookup is activated for Tx PCD ."
			"Lookup  dpkg_profile_id = %d is out of range."
			"The range is: %d, - %d \n", cfg->default_lookup.dpkg_profile_id, 0, EIOP_IFP_MAX_NUM_OF_DPKG_PROFILE_IDS);
			return -EINVAL;
		}
		if (cfg->default_lookup.dptbl_id > EIOP_IFP_MAX_NUM_OF_TBL_IDS) {
			pr_err("Lookup is activated for Tx PCD. "
			"Lookup dptbl_id = %d is out of range."
			"The range is: %d, - %d \n", cfg->default_lookup.dptbl_id, 0, EIOP_IFP_MAX_NUM_OF_TBL_IDS);
			return -EINVAL;
		}
	}


	return 0;
}
int eiop_ifp_tx_pcd_set(const struct eiop_ifp_desc *desc,
	struct eiop_ifp_tx_pcd_cfg *cfg)
{

	struct eiop_ifp_ext_regs *regs =
		(struct eiop_ifp_ext_regs *)desc->vaddr;
	uint32_t skip_info;
	uint32_t tmp32;
	int err;
	
	err = check_tx_pcd_cfg(cfg);
	if (err)
		return err;

	skip_info = build_tx_skip_info(cfg->activate_modules);

	tmp32 = (cfg->parser.profile_id
			| ((uint32_t)cfg->parser.start_offset
				<< EIOP_IFP_EXT_EGR_PARSER_START_OFFSET_SHIFFT)
			| ((((uint32_t)cfg->parser.start_hxs)
				<< EIOP_IFP_EXT_EGR_PARSER_START_HXS_SHIFFT)
				& EIOP_IFP_EXT_EGR_PARSER_START_HXS_MASK));
	iowrite32(tmp32, &regs->cedef2_parser);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs->cedef2_parser);
#endif

	tmp32 = 0;
	tmp32 |= ((((uint32_t)cfg->default_lookup.dptbl_id)
			<< EIOP_IFP_EXT_EGR_DPTBL_ID_SHIFT)
			& EIOP_IFP_EXT_EGR_DPTBL_ID_MASK);
	tmp32 |= ((((uint32_t)cfg->default_lookup.dpkg_profile_id)
			<< EIOP_IFP_EXT_EGR_DPKG_PROFILE_ID_SHIFT)
			& EIOP_IFP_EXT_EGR_DPKG_PROFILE_ID_MASK);
	iowrite32(tmp32, &regs->cedef1_tid_kid_res);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs->cedef1_tid_kid_res);
#endif

	tmp32 = ioread32(&regs->cedef0_tx_info1_skip_info2);
	tmp32 &= EIOP_IFP_EVMODE_VLAN_ACTION_MASK;
	if ((skip_info & EIOP_IFP_EXT_TX_SKIP_LK) == 0)
		tmp32 |= EIOP_IFP_TX_EXT_TKIDV;
	tmp32 |= skip_info;
	iowrite32(tmp32, &regs->cedef0_tx_info1_skip_info2);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs->cedef0_tx_info1_skip_info2);
#endif

	return 0;

}

void eiop_ifp_rx_pcd_set_opaque_h (const struct eiop_ifp_desc *desc,
									uint32_t opaque)
{
	struct eiop_ifp_ext_regs *regs_ext =
		(struct eiop_ifp_ext_regs *)desc->vaddr;
	iowrite32(opaque,
			&regs_ext->cidef6_opaque_high);

#ifdef ERR008425
	execute_errata_008425 (opaque, regs_ext->cidef6_opaque_high);
#endif

}
static uint64_t build_counter(uint32_t *h_reg, uint32_t *l_reg)
{
	uint32_t h_count, l_count, h_count_tmp;
	uint64_t count;
	do {
		h_count = ioread32(h_reg);
		l_count = ioread32(l_reg);
		h_count_tmp = ioread32(h_reg);

	} while (h_count_tmp != h_count);

	count = ((uint64_t)h_count << 32 | ((uint64_t)l_count));

	return count;

}



uint64_t eiop_ifp_get_counter(const struct eiop_ifp_desc *desc,
	enum counter_type type)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs *)desc->vaddr;
	uint32_t *h_reg, *l_reg;

	switch (type) {
	case (E_INGRESS_FC):
		h_reg = &regs->ingress_fch;
		l_reg = &regs->ingress_fcl;
		break;
	case (E_INGRESS_BC):
		h_reg = &regs->ingress_bch;
		l_reg = &regs->ingress_bcl;
		break;
	case (E_INGRESS_FFC):
		h_reg = &regs->ingress_ffch;
		l_reg = &regs->ingress_ffcl;
		break;
	case (E_INGRESS_FDC):
		h_reg = &regs->ingress_fdch;
		l_reg = &regs->ingress_fdcl;
		break;
	case (E_INGRESS_MFC):
		h_reg = &regs->ingress_mfch;
		l_reg = &regs->ingress_mfcl;
		break;
	case (E_INGRESS_MBC):
		h_reg = &regs->ingress_mbch;
		l_reg = &regs->ingress_mbcl;
		break;
	case (E_INGRESS_BFC):
		h_reg = &regs->ingress_bfch;
		l_reg = &regs->ingress_bfcl;
		break;
	case (E_INGRESS_BBC):
		h_reg = &regs->ingress_bbch;
		l_reg = &regs->ingress_bbcl;
		break;
	case (E_EGRESS_FC):
		h_reg = &regs->egress_fch;
		l_reg = &regs->egress_fcl;
		break;
	case (E_EGRESS_BC):
		h_reg = &regs->egress_bch;
		l_reg = &regs->egress_bcl;
		break;
	case (E_EGRESS_FDC):
		h_reg = &regs->egress_fdch;
		l_reg = &regs->egress_fdcl;
		break;
	case (E_EGRESS_MFC):
		h_reg = &regs->egress_mfch;
		l_reg = &regs->egress_mfcl;
		break;
	case (E_EGRESS_MBC):
		h_reg = &regs->egress_mbch;
		l_reg = &regs->egress_mbcl;
		break;
	case (E_EGRESS_BFC):
		h_reg = &regs->egress_bfch;
		l_reg = &regs->egress_bfcl;
		break;
	case (E_EGRESS_BBC):
		h_reg = &regs->egress_bbch;
		l_reg = &regs->egress_bbcl;
		break;
       case (E_EGRESS_STDC):
	      h_reg = &regs->egress_sptdch;
	      l_reg = &regs->egress_sptdcl;
	      break;
	case (E_INGRESS_OODC):
		h_reg = &regs->ingress_odch;
		l_reg = &regs->ingress_odcl;
		break;
	case (E_EGRESS_CFC):
		h_reg = &regs->egress_cfch;
		l_reg = &regs->egress_cfcl;
		break;
	default:
		return 0;
	}

	return build_counter(h_reg, l_reg);
}

static void set_counter(uint32_t *h_reg, uint32_t *l_reg, uint64_t counter)
{

	iowrite32((uint32_t)(counter >> 32), h_reg);
	iowrite32((uint32_t)(counter), l_reg);

}

void eiop_ifp_set_counter(const struct eiop_ifp_desc *desc,
	enum counter_type type,
	volatile uint64_t value)
{
	struct eiop_ifp_regs *regs = (struct eiop_ifp_regs *)desc->vaddr;
	uint32_t *h_reg, *l_reg;

	switch (type) {
	case (E_INGRESS_FC):
		h_reg = &regs->ingress_fch;
		l_reg = &regs->ingress_fcl;
		break;
	case (E_INGRESS_BC):
		h_reg = &regs->ingress_bch;
		l_reg = &regs->ingress_bcl;
		break;
	case (E_INGRESS_FFC):
		h_reg = &regs->ingress_ffch;
		l_reg = &regs->ingress_ffcl;
		break;
	case (E_INGRESS_FDC):
		h_reg = &regs->ingress_fdch;
		l_reg = &regs->ingress_fdcl;
		break;
	case (E_INGRESS_MFC):
		h_reg = &regs->ingress_mfch;
		l_reg = &regs->ingress_mfcl;
		break;
	case (E_INGRESS_MBC):
		h_reg = &regs->ingress_mbch;
		l_reg = &regs->ingress_mbcl;
		break;
	case (E_INGRESS_BFC):
		h_reg = &regs->ingress_bfch;
		l_reg = &regs->ingress_bfcl;
		break;
	case (E_INGRESS_BBC):
		h_reg = &regs->ingress_bbch;
		l_reg = &regs->ingress_bbcl;
		break;
	case (E_EGRESS_FC):
		h_reg = &regs->egress_fch;
		l_reg = &regs->egress_fcl;
		break;
	case (E_EGRESS_BC):
		h_reg = &regs->egress_bch;
		l_reg = &regs->egress_bcl;
		break;
	case (E_EGRESS_FDC):
		h_reg = &regs->egress_fdch;
		l_reg = &regs->egress_fdcl;
		break;
	case (E_EGRESS_MFC):
		h_reg = &regs->egress_mfch;
		l_reg = &regs->egress_mfcl;
		break;
	case (E_EGRESS_MBC):
		h_reg = &regs->egress_mbch;
		l_reg = &regs->egress_mbcl;
		break;
	case (E_EGRESS_BFC):
		h_reg = &regs->egress_bfch;
		l_reg = &regs->egress_bfcl;
		break;
	case (E_EGRESS_BBC):
		h_reg = &regs->egress_bbch;
		l_reg = &regs->egress_bbcl;
		break;
       case (E_EGRESS_STDC):
	      h_reg = &regs->egress_sptdch;
	      l_reg = &regs->egress_sptdcl;
	      break;
	case (E_INGRESS_OODC):
		h_reg = &regs->ingress_odch;
		l_reg = &regs->ingress_odcl;
		break;
	case (E_EGRESS_CFC):
		h_reg = &regs->egress_cfch;
		l_reg = &regs->egress_cfcl;
		break;
	default:
		break;
	}

	set_counter(h_reg,l_reg,value);
}

int ifp_mng_cmd_enqueue(const struct eiop_ifp_desc *desc,
	void *cmd_if_ring,
	struct eiop_mng_cmd_cfg *eiop_mng_cmd_cfg,
	uint16_t *index)
{
	struct eiop_ifp_regs *ifp_regs = (struct eiop_ifp_regs *)desc->vaddr;
	//uint32_t frc = 0;
	struct mng_cmd_desc *mng_cmd_desc = (struct mng_cmd_desc *)cmd_if_ring;
	uint32_t misc = MNG_CMD_DESC_FLC;

	/* get the index of the next available Management Command Descriptor */
	*index = (uint16_t)ioread32(&ifp_regs->ifpmcr);

#ifdef ERR008754
		if (*index == ((uint16_t)ioread32(&ifp_regs->ifmcrsiz)+1))
			*index = 0;
#endif

	/* Advance to the next available Management Command Descriptor */
	mng_cmd_desc += *index;

	/*invalidate_addr(mng_cmd_desc);*/

	if ((LE32_TO_CPU(mng_cmd_desc->status_mem_attr) & MNG_CMD_DESC_FRC_MGCV) /* not handled by HW */
		|| ((LE32_TO_CPU(mng_cmd_desc->misc_mtype)
			& MNG_CMD_DESC_MTYPE_MASK)
			!= ILLEGAL_MTYPE)) /* not handled by SW (confirmed) */
	{
		pr_err("Busy: No available Management command descriptor\n");
		return -EBUSY;
	}

	/* build FLC */
	if (eiop_mng_cmd_cfg->option_flags & MNG_CMD_IF_SYNC)
		misc |= MNG_CMD_DESC_FLC_SYNC;
	if (eiop_mng_cmd_cfg->option_flags & MNG_CMD_IF_EGRESS)
		misc |= MNG_CMD_DESC_FLC_IE;

	/* Initialize the command descriptor */
	mng_cmd_desc->ext_addr_h =
		CPU_TO_LE32(UINT32_HI(eiop_mng_cmd_cfg->msg_paddr));
	mng_cmd_desc->ext_addr_l =
		CPU_TO_LE32(UINT32_LO(eiop_mng_cmd_cfg->msg_paddr));

	mng_cmd_desc->length = CPU_TO_LE32(MNG_CMD_DESC_MAX_MSG_SIZE);
	mng_cmd_desc->mtype_params = CPU_TO_LE32(eiop_mng_cmd_cfg->mtypein);
	mng_cmd_desc->misc_mtype =
		CPU_TO_LE32(misc | eiop_mng_cmd_cfg->mng_cmd);
	mng_cmd_desc->status_mem_attr = /*| MNG_CMD_DESC_FRC_BDI, MC access */
		CPU_TO_LE32(MNG_CMD_DESC_FRC_MGCV);
	core_memory_barrier();

	/* Update the index to trigger Hardware */


#ifndef ERR008754
	if (*index == (uint16_t)ioread32(&ifp_regs->ifmcrsiz))
		iowrite32((uint32_t)0, &ifp_regs->ifpmcr);
	else
#endif
		iowrite32((uint32_t)((*index) + 1), &ifp_regs->ifpmcr);

	return 0;
}

int ifp_mng_cmd_try_dequeue(const struct eiop_ifp_desc *desc,
	void *cmd_if_ring,
	int index,
	struct eiop_mng_cmd_cfg *eiop_mng_cmd_cfg)
{
	struct mng_cmd_desc *mng_cmd_desc = (struct mng_cmd_desc *)cmd_if_ring;
	int err = 0;

	/* Advance to the relevant Management Command Descriptor */
	mng_cmd_desc += index;

	/*invalidate_addr(mng_cmd_desc);*/

	/* check for command completion */
	if ((LE32_TO_CPU(mng_cmd_desc->status_mem_attr) & MNG_CMD_DESC_FRC_MGCV)
		== 0) {

		err = mng_cmd_check_err(mng_cmd_desc);
		if (err)
			return err;
		eiop_mng_cmd_cfg->status =
			(uint16_t)(LE32_TO_CPU(mng_cmd_desc->status_mem_attr)
					>> 16);
		eiop_mng_cmd_cfg->mtypeout =
			LE32_TO_CPU(mng_cmd_desc->mtype_params);

		//mng_cmd_out->size

		/* Mark MCD as confirmed */
		mng_cmd_desc->misc_mtype = CPU_TO_LE32(ILLEGAL_MTYPE);
		core_memory_barrier();

		/*invalidate_addr(eiop_mng_cmd_cfg->msg_vaddr);
		 invalidate_addr(PTR_MOVE(eiop_mng_cmd_cfg->msg_vaddr, 32));
		 invalidate_addr(PTR_MOVE(eiop_mng_cmd_cfg->msg_vaddr, 64));
		 invalidate_addr(PTR_MOVE(eiop_mng_cmd_cfg->msg_vaddr, 96));*/


		if (LE32_TO_CPU(mng_cmd_desc->status_mem_attr) &
			MNG_CMD_DESC_FRC_MGCF)
		{
			pr_err("Command failed\n");
			return -EACCES;
		}
		return 0;
	}

	pr_warn("Command not completed yet.\n");
	return -EBUSY;
}

void eiop_ifp_set_err_behavior(const struct eiop_ifp_desc *eiop_ifp_desc,
	uint32_t errors,
	struct eiop_ifp_err_cfg *err_cfg)
{
	struct eiop_ifp_regs *regs;
	uint32_t ififsdm, ififseqm, ififsem, ifisvm;
	uint32_t ifiefqid;

	regs = (struct eiop_ifp_regs*)eiop_ifp_desc->vaddr;

	/*get discard register value */
	ififsdm = ioread32(&regs->ififsdm);
	/*get error Q resgister value*/
	ififseqm = ioread32(&regs->ififseqm);
	/* get status valid mask register updated */
	ifisvm = ioread32(&regs->ifisvm);
	/* get FD err register updated */
	ififsem = ioread32(&regs->ififsem);
	/* get error queue id */
	ifiefqid = ioread32(&regs->ifiefqid);

	switch (err_cfg->action) {
	case (EIOP_IFP_ERR_DROP):
		/*set discard register value*/
		ififsdm |= errors;
		/*clear the value for errors Q register for the same
		 * errors that were defined for discard*/
		ififseqm &= ~ififsdm;
		/* do not overwrite frame discard operation */
		ifiefqid &= ~EIOP_IFP_IEIFQID_FDOVR;
		break;
	case (EIOP_IFP_ERR_ENQ_TO_ERR_Q):
		/*set error Q register value*/
		ififseqm |= errors;
		/*clear the value for discard register for the same
		 * errors that were defined for enqueue to error Q*/
		ififsdm &= ~ififseqm;
		/* enable/disable FDOVR field depending on DISC field */
		if( errors & EIOP_IFP_FAS_DISC ) {
			/* do not overwrite frame discard operation
			 *  discarded frames sent to error queue */
			ifiefqid |= EIOP_IFP_IEIFQID_FDOVR;
		} else {
			/* do not overwrite frame discard operation */
			ifiefqid &= ~EIOP_IFP_IEIFQID_FDOVR;
		}
		break;
	case (EIOP_IFP_ERR_ENQ):
		/*clear the value for error Q register*/
		ififseqm &= ~errors;
		/*clear the value for discard register*/
		ififsdm &= ~errors;
		/* do not overwrite frame discard operation */
		ifiefqid &= ~EIOP_IFP_IEIFQID_FDOVR;
		break;
	default:
		break;
	}

	/* update status valid mask register updated */
	if ((err_cfg->options & EIOP_IFP_ERR_CFG_OPT_SET_FD_STATUS)
		== EIOP_IFP_ERR_CFG_OPT_SET_FD_STATUS)
		ifisvm |= errors;
	else
		ifisvm &= ~errors;

	/* update FD ERR register updated */
	if ((err_cfg->options & EIOP_IFP_ERR_CFG_OPT_SET_FD_ERR)
		== EIOP_IFP_ERR_CFG_OPT_SET_FD_ERR)
		ififsem |= errors;
	else
		ififsem &= ~errors;

	/*update error Q register*/
	iowrite32(ififseqm, &regs->ififseqm);
	/*update discard register*/
	iowrite32(ififsdm, &regs->ififsdm);
	/* update status valid mask register updated */
	iowrite32(ifisvm, &regs->ifisvm);
	/* update FD err register updated */
	iowrite32(ififsem, &regs->ififsem);
	/* */
	iowrite32(ifiefqid, &regs->ifiefqid);
}

static void eiop_ifp_set_err_behavior_limit_drop(const struct eiop_ifp_desc *eiop_ifp_desc)
{
	struct eiop_ifp_regs *regs;
	uint32_t ififsdm, ififseqm, ififsem, ifisvm;

	regs = (struct eiop_ifp_regs*)eiop_ifp_desc->vaddr;
	
	/*get discard register value */
	ififsdm = ioread32(&regs->ififsdm);

	/*get error Q register value*/
	ififseqm = ioread32(&regs->ififseqm);

	ififsdm |= ERRORS_LIMIT_DROP;
	
	ififseqm &= ~ififsdm;
	
	ifisvm = 0;
	ififsem = 0;
	
	/*update error Q register*/
	iowrite32(ififseqm, &regs->ififseqm);
	/*update discard register*/
	iowrite32(ififsdm, &regs->ififsdm);
	/* update status valid mask register updated */
	iowrite32(ifisvm, &regs->ifisvm);
	/* update FD err register updated */
	iowrite32(ififsem, &regs->ififsem);
}

uint16_t eiop_ifp_get_max_frame_length(const struct eiop_ifp_desc *desc)
{
	struct eiop_ifp_regs *regs;

	regs = (struct eiop_ifp_regs*)desc->vaddr;

	return (uint16_t)ioread32(&regs->ifml);

}

void eiop_ifp_get_rx_vlan_cfg(const struct eiop_ifp_desc *desc,
	struct eiop_ifp_rx_vlan_cfg *rx_vlan_cfg)
{
	struct eiop_ifp_regs *regs;
	uint32_t tmp32;

	ASSERT_COND(rx_vlan_cfg);

	regs = (struct eiop_ifp_regs*)desc->vaddr;

	memset(rx_vlan_cfg, 0, sizeof(struct eiop_ifp_rx_vlan_cfg));

	rx_vlan_cfg->insert_vlan_hdr = ioread32(&regs->ifivlan);

	tmp32 = ioread32(&regs->ifivmode);
	rx_vlan_cfg->cond_insert_ethype_not_found =
		(uint16_t)(tmp32
				>> EIOP_IFP_IVMODE_COND_INSERT_ETHYPE_NOT_FOUND_SHIFT);
	tmp32 &= ~EIOP_IFP_IVMODE_VLAN_ACTION_MASK;

	switch (tmp32) {
	case (EIOP_IFP_IVMODE_VLAN_ACTION_COND_INSERT):
		rx_vlan_cfg->action = EIOP_IFP_RX_VLAN_ACTION_COND_INSERT;
		break;
	case (EIOP_IFP_IVMODE_VLAN_ACTION_INSERT):
		rx_vlan_cfg->action = EIOP_IFP_RX_VLAN_ACTION_INSERT;
		break;
	default:
		rx_vlan_cfg->action = EIOP_IFP_RX_VLAN_ACTION_NONE;
		break;
	}

}

int eiop_ifp_rx_vlan_cfg(const struct eiop_ifp_desc *desc,
	struct eiop_ifp_rx_vlan_cfg *rx_vlan_cfg)
{
	struct eiop_ifp_regs *regs;
	uint32_t tmp32;

	regs = (struct eiop_ifp_regs*)desc->vaddr;

	tmp32 = ioread32(&regs->ifpv);

	if (tmp32 & EIOP_IFP_INGR_EN) {
		pr_err("Function can be called "
		"only if IFP ingress side disable\n");
		return -EINVAL;

	}
	iowrite32(rx_vlan_cfg->insert_vlan_hdr, &regs->ifivlan);
	tmp32 =
		(uint32_t)(rx_vlan_cfg->cond_insert_ethype_not_found
				<< EIOP_IFP_IVMODE_COND_INSERT_ETHYPE_NOT_FOUND_SHIFT);
	tmp32 &= ~EIOP_IFP_IVMODE_VLAN_ACTION_MASK;

	switch (rx_vlan_cfg->action) {
	case (EIOP_IFP_RX_VLAN_ACTION_COND_INSERT):
		tmp32 |= EIOP_IFP_IVMODE_VLAN_ACTION_COND_INSERT;
		break;
	case (EIOP_IFP_RX_VLAN_ACTION_INSERT):
		tmp32 |= EIOP_IFP_IVMODE_VLAN_ACTION_INSERT;
		break;
	default:
		tmp32 &= ~EIOP_IFP_IVMODE_VLAN_ACTION_MASK;
		break;

	}
	iowrite32(tmp32, &regs->ifivmode);
	return 0;
}

int eiop_ifp_tx_vlan_cfg(const struct eiop_ifp_desc *desc,
	struct eiop_ifp_tx_vlan_cfg *tx_vlan_cfg)
{
	struct eiop_ifp_regs *regs;
	struct eiop_ifp_ext_regs *regs_ext;
	uint32_t tmp32;

	regs = (struct eiop_ifp_regs*)desc->vaddr;
	regs_ext = (struct eiop_ifp_ext_regs *)desc->vaddr;
/*
	tmp32 = ioread32(&regs->ifpv);
	if (tmp32 & EIOP_IFP_EGGR_EN) {
		pr_err("Function can be called "
		"only if IFP egress side disable\n");
		return -EINVAL;
	}
*/


	tmp32 = ioread32(&regs_ext->cedef0_tx_info1_skip_info2);
	tmp32 &= ~EIOP_IFP_EVMODE_VLAN_ACTION_MASK;

	switch (tx_vlan_cfg->action) {
	case (EIOP_IFP_TX_VLAN_ACTION_REMOVE):
		tmp32 |= EIOP_IFP_EVMODE_VLAN_ACTION_REMOVE;
		iowrite32(tx_vlan_cfg->insert_vlan_hdr, &regs->ifevlan);
		iowrite32(tmp32, &regs_ext->cedef0_tx_info1_skip_info2);
		break;
	case (EIOP_IFP_TX_VLAN_ACTION_UPDATE_QOS):
		tmp32 |= EIOP_IFP_EVMODE_VLAN_ACTION_UPDATE_QOS;
		iowrite32(tx_vlan_cfg->insert_vlan_hdr, &regs->ifevlan);
		iowrite32(tmp32, &regs_ext->cedef0_tx_info1_skip_info2);
		break;
	case (EIOP_IFP_TX_VLAN_ACTION_INSERT):
		tmp32 |= EIOP_IFP_EVMODE_VLAN_ACTION_INSERT;
		iowrite32(tx_vlan_cfg->insert_vlan_hdr, &regs->ifevlan);
		iowrite32(tmp32, &regs_ext->cedef0_tx_info1_skip_info2);
		break;
	default:
		tmp32 &= ~EIOP_IFP_EVMODE_VLAN_ACTION_MASK;
		iowrite32(tmp32, &regs_ext->cedef0_tx_info1_skip_info2);
		iowrite32(tx_vlan_cfg->insert_vlan_hdr, &regs->ifevlan);
		break;
	}

#ifdef ERR008425
	execute_errata_008425 (tmp32, regs_ext->cedef0_tx_info1_skip_info2);
#endif

	return 0;

}

void eiop_ifp_get_data_offset(const struct buf_layout *buf_layout,
	uint32_t *data_offset,
	int rx)
{
	uint32_t hwal, tmp;

	if (rx)
		calc_hwal_offset(buf_layout, &hwal, E_LAYOUT_RX);
	else
		calc_hwal_offset(buf_layout, &hwal, E_LAYOUT_TX);
	calc_data_offset(buf_layout, hwal, data_offset, &tmp);
}

void eiop_ifp_set_l3csv(const struct eiop_ifp_desc *desc, int en)
{
	struct eiop_ifp_ext_regs *regs_ext;
	uint32_t tmp32;

	regs_ext = (struct eiop_ifp_ext_regs *)desc->vaddr;

	/*update cidef3_parser register with SET/CLEAR L3 checksun validation option*/
	tmp32 = ioread32(&regs_ext->cidef3_parser);
	if (en)
		tmp32 |= EIOP_IFP_EXT_PARSER_L3CSV;
	else
		tmp32 &= ~EIOP_IFP_EXT_PARSER_L3CSV;

	iowrite32(tmp32, &regs_ext->cidef3_parser);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs_ext->cidef3_parser);
#endif

}

void eiop_ifp_set_l4csv(const struct eiop_ifp_desc *desc, int en)
{
	struct eiop_ifp_ext_regs *regs_ext;
	uint32_t tmp32;

	regs_ext = (struct eiop_ifp_ext_regs *)desc->vaddr;

	/*update cidef3_parser register with SET/CLEAR L4 checksun validation option*/
	tmp32 = ioread32(&regs_ext->cidef3_parser);
	if (en)
		tmp32 |= EIOP_IFP_EXT_PARSER_L4CSV;
	else
		tmp32 &= ~EIOP_IFP_EXT_PARSER_L4CSV;

	iowrite32(tmp32, &regs_ext->cidef3_parser);
#ifdef ERR008425
	execute_errata_008425 (tmp32, regs_ext->cidef3_parser);
#endif

}

void eiop_ifp_get_hw_annotation_room(const struct eiop_ifp_desc *desc, uint16_t *size)
{
	struct eiop_ifp_regs *regs;

	regs = (struct eiop_ifp_regs*)desc->vaddr;

	*size = (uint16_t)(((ioread32(&regs->ifispff) & EIOP_IFP_SPFF_ASAR_MASK) >>
			EIOP_IFP_IFSPFF_ASAR_SHIFT)
			* EIOP_IFP_SPFF_ASAR_UNITS);

}

void eiop_ifp_dump_regs(const struct eiop_ifp_desc *desc)
{
       void *regs;

       regs = (struct eiop_ifp_regs*)desc->vaddr;
       pr_info("eiop_ifp_dump_regs\n", desc->ifp_id);
       mem_disp((uint8_t*)regs, sizeof(struct eiop_ifp_regs));
}

int eiop_ifp_set_in_egress_read_iad(const struct eiop_ifp_desc *desc)
{
	struct eiop_ifp_regs *regs =
		(struct eiop_ifp_regs *)desc->vaddr;
	uint32_t tmp32 = 0;

	tmp32 = ioread32(&regs->ifpv);
	if ((tmp32 & (EIOP_IFP_INGR_EN | EIOP_IFP_EGGR_EN)) != 0) {
			pr_err("function can be called only when"
			"EIOP_IFP is disabled\n");
			return -EINVAL;
	}

	tmp32 = ioread32(&regs->ifera);
	tmp32 |= EIOP_IFP_FA_IADV_EGGR;
	iowrite32(tmp32, &regs->ifera);

	return 0;
}

int eiop_ifp_clear_in_egress_read_iad(const struct eiop_ifp_desc *desc)
{
	struct eiop_ifp_regs *regs =
		(struct eiop_ifp_regs *)desc->vaddr;
	uint32_t tmp32 = 0;

	tmp32 = ioread32(&regs->ifpv);
	if ((tmp32 & (EIOP_IFP_INGR_EN | EIOP_IFP_EGGR_EN)) != 0) {
			pr_err("function can be called only when"
			"EIOP_IFP is disabled\n");
			return -EINVAL;
	}

	tmp32 = ioread32(&regs->ifera);
	tmp32 &= ~EIOP_IFP_FA_IADV_EGGR;
	iowrite32(tmp32, &regs->ifera);

	return 0;
}

int eiop_ifp_rx_pcd_set_parser_profile_id(const struct eiop_ifp_desc *desc,
                                                int profile_id)
{
       struct eiop_ifp_ext_regs *regs_ext;
       uint32_t tmp32;

       if (profile_id
              > EIOP_IFP_MAX_NUM_OF_PARSER_PROFILE_IDS) {
              pr_err("Parser is activated for Tx PCD ,"
              "Parser profile_id = %d is out of range."
              "The range is: %d, - %d \n", profile_id, 0, EIOP_IFP_MAX_NUM_OF_PARSER_PROFILE_IDS);
              return -EINVAL;
       }
       regs_ext = (struct eiop_ifp_ext_regs *)desc->vaddr;

       /*update cidef3_parser register with SET/CLEAR L3 checksun validation option*/
       tmp32 = ioread32(&regs_ext->cidef3_parser);
       tmp32 &= ~EIOP_IFP_EXT_PARSER_PROFILE_ID_MASK;
       tmp32 |= profile_id;
       iowrite32(tmp32, &regs_ext->cidef3_parser);
#ifdef ERR008425
       execute_errata_008425 (tmp32, regs_ext->cidef3_parser);
#endif
       return 0;
}
