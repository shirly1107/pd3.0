/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
*//***************************************************************************/
#include "fsl_types.h"
#include "fsl_dbg.h"
#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_io.h"
#include "fsl_mpic.h"
#include "fsl_eiop_rtc.h"
#include "fsl_dpmac_mc.h"
#include "fsl_dprtc_mc.h"
#include "fsl_platform.h"
#include "fsl_timer.h"

#include "eiop.h"

static void err_intr_handle(struct eiop_desc *eiop_desc)
{
	void *tmp_regs;
	uint32_t event;

    	/*pointer to DMA*/
	tmp_regs =
		(struct eiop_fpm *)UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr) +
			EIOP_FPM_OFFSET);

	event = ioread32(&((struct eiop_fpm *)tmp_regs)->geev);
	iowrite32(event, &((struct eiop_fpm *)tmp_regs)->geev);

	event &= ioread32(&((struct eiop_fpm *)tmp_regs)->geev);
	if (event & EIOP_FPM_GEEV_STLE)
		pr_info("EIOP STALL event\n");

}

static void system_bus_err_intr_handle(struct eiop_desc *eiop_desc)
{
	void *tmp_regs;
	uint32_t event;

    	/*pointer to FPM*/
	tmp_regs =
		(struct eiop_dma *)UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr) +
		                               EIOP_DMA_OFFSET);

	event = ioread32(&((struct eiop_dma *)tmp_regs)->sbev);
	iowrite32(event, &((struct eiop_dma *)tmp_regs)->sbev);

	event &= ioread32(&((struct eiop_dma *)tmp_regs)->sbem);
	if (event & EIOP_DMA_SBEV_SBE)
		pr_err("EIOP System Bus error\n");
}

static void ecc_err_intr_handle(struct eiop_desc *eiop_desc)
{
	pr_err("EIOP error event: ECC\n");
}

static void eiop_err_isr(uint32_t arg)
{
	void *tmp_regs;
	uint32_t pending;
	struct eiop_desc *eiop_desc = (struct eiop_desc*)arg;

	pr_err("EIOP error event\n");

	/*pointer to FPM*/
	tmp_regs =
		(struct eiop_fpm *)UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr) +
			EIOP_FPM_OFFSET);

	/* check IOP_EPI for pending error interrupts */
	pending = ioread32(&((struct eiop_fpm *)tmp_regs)->epi);

	if (pending & EIOP_EPI_PECCEI)
		ecc_err_intr_handle(eiop_desc);
	if (pending & EIOP_EPI_PGEI)
		err_intr_handle(eiop_desc);
	if (pending & EIOP_EPI_SBEI)
		pr_err("EIOP error event: System bus error\n");
		//system_bus_err_intr_handle(eiop_desc);
	if (pending & EIOP_EPI_PILKEI)
		pr_err("EIOP error event: interlaken\n");
		//interlaken_err_intr_handle(eiop_desc);

}

extern void *g_dprtc;
static void eiop_isr(uint32_t arg)
{
	void *tmp_regs;
	uint32_t pending;
	int i = 0;
	struct eiop_desc *eiop_desc = (struct eiop_desc*)arg;

	pr_debug("EIOP error event\n");

	/*pointer to FPM*/
	tmp_regs =
		(struct eiop_fpm *)UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr) +
			EIOP_FPM_OFFSET);

	/* check IOP_NPI1 for pending error interrupts */
	pending = ioread32(&((struct eiop_fpm *)tmp_regs)->npi1);

	if (pending & EIOP_NPI1_PILKEI)
		//interlaken_intr_handle(eiop_desc);
		pr_info("EIOP runtime event: interlaken\n");
	if (pending & EIOP_NPI1_PTMRNI)
		dprtc_exceptions(g_dprtc);

	/* check IOP_NPI2 for pending error interrupts */
	pending = ioread32(&((struct eiop_fpm *)tmp_regs)->npi2);
	if (pending)
		pr_info("EIOP runtime event: MACSEC\n");

	/* check IOP_NPI4 for pending error interrupts */
	pending = ioread32(&((struct eiop_fpm *)tmp_regs)->npi4);
	while (pending)
	{
		if (pending & 1)
			dpmac_interrupt_handler(i);
		i++;
		pending >>= 1;
	}

}

static void fill_regs(void *regs, struct tmp_eiop_cfg *eiop_cfg)
{
	void *tmp_regs;
	uint32_t temp = 0;

    	/*pointer to DMA*/
    	tmp_regs     = (struct eiop_dma *)PTR_MOVE(regs, EIOP_DMA_OFFSET);
        /*sbev - w1C, sbem - mask*/
        iowrite32(0x80000000, &((struct eiop_dma *)tmp_regs)->sbev);
        iowrite32(0x00000003, &((struct eiop_dma *)tmp_regs)->sbmr);

        /*Write hysteresis and threshold*/
        iowrite32(EIOP_DMA_THRESHOLD, &((struct eiop_dma *)tmp_regs)->tr);
        iowrite32(EIOP_DMA_HYSTERESIS, &((struct eiop_dma *)tmp_regs)->hy);

    	/*pointer to FPM*/
    	tmp_regs     = (struct eiop_fpm *)PTR_MOVE(regs, EIOP_FPM_OFFSET);
        /*geev - w1C, geem - mask*/
        iowrite32(0x80000000, &((struct eiop_fpm *)tmp_regs)->geev);
    	/*pointer to QMI_EGRESS*/
    	tmp_regs     = (struct eiop_qmi_egress *)PTR_MOVE(regs, EIOP_QMI_EGRESS_OFFSET);
/*NOTE - be sure its initialized before*/
        /*geev, geem*/
		temp = (uint32_t)(eiop_cfg->tpbb & 0xffffffff);
		iowrite32(temp, &((struct eiop_qmi_egress *)tmp_regs)->tpbbl);
		temp = (uint32_t)((eiop_cfg->tpbb>>32)&0xffffffff);
		iowrite32(temp, &((struct eiop_qmi_egress *)tmp_regs)->tpbbh);
        if (eiop_cfg->tpbb_icid != DONT_CARE) {
        	temp = EIOP_QMI_EGRESS_TPBICID_ICEN;
        	temp |= (uint32_t)eiop_cfg->tpbb_icid;
        	iowrite32(temp,
        		&((struct eiop_qmi_egress *)tmp_regs)->tpbicid);
        }
}


/**************************************************************************//**
					eiop_init
*//***************************************************************************/
int eiop_init( struct eiop_desc *eiop_desc, struct eiop_cfg *cfg)
{
/*NOTE - check regs != NULL*/
        struct tmp_eiop_cfg  tmp_eiop_cfg;
	mpic_intr_params_t intr_params;
	int err;

        memset(&tmp_eiop_cfg, 0, sizeof(struct tmp_eiop_cfg));

/*NOTE -  the size which should be allocated for temp_pfc_buffer
	"number of possible frames in recycle queue per TC per port" - 64 *
 	"number of ports that connect to ethernet MAC" - for first draft 16 *
 	 number of TC - 8*
 	 64.
*/
        tmp_eiop_cfg.tpbb = cfg->temp_pfc_buffer;
        tmp_eiop_cfg.tpbb_icid = cfg->temp_pfc_icid;

        fill_regs(eiop_desc->vaddr, &tmp_eiop_cfg);

        intr_params.polarity = OS_MPIC_INTR_POLARITY_HIGH;
        intr_params.priority = 8;
        intr_params.sense = OS_MPIC_INTR_SENSE_LEVEL;
        intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;

        err = mpic_set_config_intr((uint32_t)eiop_desc->irq, (uint32_t)0, eiop_isr, (mpic_arg)eiop_desc, &intr_params);
	if(err != 0) {
		return err;
	}
	err = mpic_enable_intr((uint32_t)eiop_desc->irq);
	if(err != 0) {
		return err;
	}

	err = mpic_set_config_intr((uint32_t)eiop_desc->irq_rec_err, (uint32_t)0, eiop_err_isr, (mpic_arg)eiop_desc, &intr_params);
	if(err != 0) {
		return err;
	}
	err = mpic_enable_intr((uint32_t)eiop_desc->irq_rec_err);
	if(err != 0) {
		return err;
	}

	return 0;
}

/**************************************************************************//**
					eiop_get_revision
*//***************************************************************************/
int eiop_get_revision(int eiop_id, uint32_t *rev1, uint32_t *rev2)
{
	void *tmp_regs;
	struct eiop_desc *eiop_desc;
	int iter = 0;
	int err = -EINVAL;

	eiop_desc = (struct eiop_desc *)fsl_malloc(sizeof(struct eiop_desc));
	CHECK_COND_RETVAL( eiop_desc != NULL, -ENOMEM, "Out of memory\n");

	if( sys_get_desc(SOC_MODULE_EIOP, 0, eiop_desc, &iter) == 0 ) {
		tmp_regs = (struct eiop_fpm *)UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr) + EIOP_FPM_OFFSET);

		*rev1 = ioread32(&((struct eiop_fpm *)tmp_regs)->ip_rev1);
		*rev2 = ioread32(&((struct eiop_fpm *)tmp_regs)->ip_rev2);

		err = 0;
	}

	fsl_free(eiop_desc);

	return err;
}

#ifdef TKT508412
/**************************************************************************//**
					eiop_need_TKT508412_fix
*//***************************************************************************/
int eiop_wriop_apply_TKT508412_fix(void)
{
	uint32_t iop_ip_rev_1, iop_ip_rev_2;
	int err;

	err = eiop_get_revision(8, &iop_ip_rev_1, &iop_ip_rev_2);
	CHECK_COND_RETVAL( err == 0, 0, "Could not obtain wriop revision");

	if( iop_ip_rev_1 == 0x0A080300 && iop_ip_rev_2 == 0x00000000 ) {
		/* LX2160 rev1
		 * In this case MAC needs to forward all flow control frames; objects
		 * connected to this MAC need a supplementary table to filter these
		 * packets */
		return 1;
	}
	else {
		return 0;
	}
}
#endif

/**************************************************************************//**
					eiop_set_exceptions
*//***************************************************************************/
int eiop_set_exceptions(struct eiop_desc *eiop_desc, enum eiop_exceptions exception, int enable)
{
	void *tmp_regs;
/*NOTE = check regs != NULL*/

	if (exception == E_EIOP_SYSTEM_BUS_ERROR) {
    		/*pointer to DMA*/
    		tmp_regs     = (struct eiop_dma *)UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr) +
    							EIOP_DMA_OFFSET);
		if (enable)
        		iowrite32(EIOP_DMA_SBEV_SBE,
        				&((struct eiop_dma *)tmp_regs)->sbem);
		else
        		iowrite32(0, &((struct eiop_dma *)tmp_regs)->sbem);
	}

	if (exception == E_EIOP_STALL_EVENT) {
    		/*pointer to FPM*/
     		tmp_regs     = (struct eiop_fpm *)UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr) +
    							EIOP_FPM_OFFSET);
		if (enable)
        		iowrite32(EIOP_FPM_GEEV_STLE,
        				&((struct eiop_fpm *)tmp_regs)->geem);
		else
        		iowrite32(0, &((struct eiop_fpm *)tmp_regs)->geem);
	}

	return 0;
}

void eiop_force_exceptions(struct eiop_desc *eiop_desc, enum eiop_exceptions exception)
{
	void *tmp_regs;
	if (exception == E_EIOP_STALL_EVENT) {
    		/*pointer to FPM*/
     		tmp_regs     = (struct eiop_fpm *)UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr) +
    							EIOP_FPM_OFFSET);
		iowrite32(EIOP_FPM_GEEV_STLE,
				&((struct eiop_fpm *)tmp_regs)->geef);
	}

	if (exception == E_EIOP_SYSTEM_BUS_ERROR) {
    		/*pointer to FPM*/
     		tmp_regs     = (struct eiop_dma *)UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr) +
    							EIOP_DMA_OFFSET);
		iowrite32(EIOP_DMA_SBEV_SBE,
				&((struct eiop_dma *)tmp_regs)->sbef);
	}
}
/**************************************************************************//**
				eiop_get_temp_pfc_buffer_size
*//***************************************************************************/
int eiop_get_temp_pfc_buffer_size(void)
{
/*NOTE -  the size which should be allocated for temp_pfc_buffer
	"number of possible frames in recycle queue per TC per port" - 64 *
 	"number of ports that connect to ethernet MAC" - for first draft 16 *
 	 number of TC - 8*
 	 64.
*/

	return 64 * 16 * 8 * 64;
}


/****************************************************************************
 * DEBUG options
 ****************************************************************************/
static int check_dynamic_debug_cfg_ifp(struct eiop_debug_dynamic_rule *rule)
{
	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_IFP_MATCH) {
		if (rule->dst_ifp.id > EIOP_DEBUG_MAX_DST_IFP) {

			pr_err("rule->dst_ifp.id should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_DST_IFP);
			return -EINVAL;

		}
		if (rule->dst_ifp.mask  > EIOP_DEBUG_MAX_DST_IFP) {
			pr_err("rule->dst_ifp.mask should be in the range %d, %d\n",
						0, EIOP_DEBUG_MAX_DST_IFP);
				return -EINVAL;

		}
	}
	return 0;
}

static int check_dynamic_debug_cfg_qdid(struct eiop_debug_dynamic_rule *rule)
{
	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_QDID_MATCH) {
		if (rule->dst_qdid.id > EIOP_DEBUG_MAX_DST_QDID) {
			pr_err("rule->dst_qdid.id should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_DST_QDID);
			return -EINVAL;
		}
		if (rule->dst_qdid.mask > EIOP_DEBUG_MAX_DST_QDID) {
			pr_err("rule->dst_qdid.mask should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_DST_QDID);
			return -EINVAL;
		}
	}
	return 0;
	
}
static int check_dynamic_debug_cfg_qpri(struct eiop_debug_dynamic_rule *rule)
{
	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_QPRI_MATCH) {
		if (rule->dst_qpri.id > EIOP_DEBUG_MAX_DST_QPRI) {
			pr_err("rule->dst_qpri.id should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_DST_QPRI);
			return -EINVAL;
		}
		if (rule->dst_qpri.mask > EIOP_DEBUG_MAX_DST_QPRI) {
			pr_err("rule->dst_qpri.mask should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_DST_QPRI);
			return -EINVAL;
		}
	}
	return 0;
	
}

static int check_dynamic_debug_cfg_bpid(struct eiop_debug_dynamic_rule *rule)
{
	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_BPID_MATCH) {
		if (rule->dst_bpid.id > EIOP_DEBUG_MAX_BPID) {
			pr_err("rule->dst_bpid.id should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_BPID);
			return -EINVAL;
		}
		if (rule->dst_bpid.mask > EIOP_DEBUG_MAX_BPID) {
			pr_err("rule->dst_bpid.mask should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_BPID);
			return -EINVAL;
		}
	}
	return 0;

}
static int check_dynamic_debug_cfg_qdbin(struct eiop_debug_dynamic_rule *rule)
{
	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_QDBIN_MATCH) {
		if (rule->dst_qdbin.id > EIOP_DEBUG_MAX_QDBIN) {
			pr_err("rule->dst_qdbin should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_QDBIN);
			return -EINVAL;
		}
		if (rule->dst_qdbin.mask > EIOP_DEBUG_MAX_QDBIN) {
			pr_err("rule->dst_qdbin.mas should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_QDBIN);
			return -EINVAL;
		}
	}
	return 0;
	
}

static int check_dynamic_debug_cfg_fqid(struct eiop_debug_dynamic_rule *rule)
{
	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_CONF_FQID_MATCH) {

		if (rule->conf_fqid.id > EIOP_DEBUG_MAX_COND_FQID) {
			pr_err("rule->conf_fqid.id should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_COND_FQID);
			return -EINVAL;
		}
		if (rule->conf_fqid.mask > EIOP_DEBUG_MAX_COND_FQID) {
			pr_err("rule->conf_fqid.mask should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_COND_FQID);
			return -EINVAL;
		}

	}
	return 0;

}
static int check_dynamic_debug_cfg_dd(struct eiop_debug_dynamic_rule *rule)
{
	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_DEQ_FD_DD_MATCH) {
		if (rule->deq_fd_dd.id > EIOP_DEBUG_MAX_FD_DD) {
			pr_err("rule->deq_fd_dd.id should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_FD_DD);
			return -EINVAL;
		}
		if (rule->deq_fd_dd.mask > EIOP_DEBUG_MAX_FD_DD) {
			pr_err("rule->deq_fd_dd.mask should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_FD_DD);
			return -EINVAL;
		}
	}
	return 0;
	
}

static int check_dynamic_debug_cfg_frm_mark_eggr(struct eiop_debug_dynamic_action *action)
{
	if ((action->options & EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_EGGR) ||
			(action->options &
					EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_EGGR_ORED_WITH_FD_DD)) {
		if (action->eggr_mark > EIOP_DEBUG_MAX_FRM_MARK_EGGR)
		{
			pr_err("action->eggr_mark should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_FRM_MARK_EGGR);
			return -EINVAL;

		}
		if (action->ctlu_eggr_mark > EIOP_DEBUG_MAX_FRM_MARK_EGGR)
		{
			pr_err("action->eggr_ctlu_mark should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_FRM_MARK_EGGR);
			return -EINVAL;

		}

	}	
	return 0;

}

static int check_dynamic_debug_cfg_frm_mark_ingr(struct eiop_debug_dynamic_action *action)
{
	if ((action->options & EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_INGR) ||
			(action->options &
					EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_INGR_ORED_WITH_FD_DD)) {
		if (action->ingr_mark > EIOP_DEBUG_MAX_FRM_MARK_INGR)
		{
			pr_err("action->eggr_mark should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_FRM_MARK_INGR);
			return -EINVAL;

		}
		if (action->ctlu_ingr_mark > EIOP_DEBUG_MAX_FRM_MARK_INGR)
		{
			pr_err("action->eggr_ctlu_mark should be in the range %d, %d\n",
					0, EIOP_DEBUG_MAX_FRM_MARK_INGR);
			return -EINVAL;

		}

	}
	return 0;
	
}
static int check_dynamic_debug_cfg(struct eiop_debug_dynamic_cfg *debug_cfg) {

	struct eiop_debug_dynamic_rule *rule = &debug_cfg->rule;
	struct eiop_debug_dynamic_action *action = &debug_cfg->action;
	int err;
	
	err = check_dynamic_debug_cfg_ifp(rule);
	if (!err)
		err = check_dynamic_debug_cfg_qdid(rule);
	if (!err)
		err = check_dynamic_debug_cfg_qpri(rule);
	if (!err)
		err = check_dynamic_debug_cfg_bpid(rule);
	if (!err)
		err = check_dynamic_debug_cfg_qdbin(rule);
	if (!err)
		err = check_dynamic_debug_cfg_fqid(rule);
	if (!err)
		err = check_dynamic_debug_cfg_dd(rule);
	if (!err)
		err = check_dynamic_debug_cfg_frm_mark_eggr(action);
	if (!err)
		err = check_dynamic_debug_cfg_frm_mark_ingr(action);
	
	return err;

}

/*TODO - Yevgenii told that it should be BE. Now its LE.
 * Should be checked on board
 */

static void fill_debug_match_reg_ifp_qdid_qpri(struct eiop_desc *eiop_desc,
		struct eiop_debug_dynamic_rule *rule)
{
	uint32_t tmp32_0 = 0, tmp32_1= 0;
	void *tmp_regs, *regs;
	/********************************************************************************/
		/*fill debug match on ingr event for execution of actions*/
		/*match on 	dest_ifp, dest_qdid, dest_qpri - part1,
		 	 	 	dest_bpid, dest_qdbin          - part2
	/********************************************************************************/

		/*here - tmp32_0 - dcmp0_0, tmp32_1 - dmsk0_0*/
		/*fill rule and mask for debug trigger - part 1*/
	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_IFP_MATCH) {
		tmp32_0 |= rule->dst_ifp.id << EIOP_DEBUG_DST_IFP_MATCH_SHIFT_DCMP0_1_DMSK0_1;
		tmp32_1 |= rule->dst_ifp.mask << EIOP_DEBUG_DST_IFP_MATCH_SHIFT_DCMP0_1_DMSK0_1;
	}

	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_QDID_MATCH) {
		tmp32_0 |= rule->dst_qdid.id;
		tmp32_1 |= rule->dst_qdid.mask;
	}

	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_QPRI_MATCH) {
		tmp32_0 |= rule->dst_qpri.id << EIOP_DEBUG_DST_QPRI_MATCH_SHIFT_DCMP0_1_DMSK0_1;
		tmp32_1 |= rule->dst_qpri.mask << EIOP_DEBUG_DST_QPRI_MATCH_SHIFT_DCMP0_1_DMSK0_1;
	}


	regs = UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr));
	tmp_regs = (struct eiop_bmi_ingress *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_BMI_INGRESS_OFFSET);

	iowrite32(tmp32_0, &((struct eiop_bmi_ingress *)tmp_regs)->dcmp0_0);
	iowrite32(tmp32_1, &((struct eiop_bmi_ingress *)tmp_regs)->dmsk0_0);
	
}

static void fill_debug_match_reg_conf_fqid_fd_dd(struct eiop_desc *eiop_desc,
		struct eiop_debug_dynamic_rule *rule)
{
	uint32_t tmp32_0 = 0, tmp32_1= 0;
	void *tmp_regs, *regs;
	/********************************************************************************/
		/*fill debug match on eggr event for execution of actions*/
		/*match on 	conf_fqid, deq_fd[dd]
	/********************************************************************************/
		/*here - tmp32_0 - dcmp1, tmp32_1 - dmsk1*/

	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_CONF_FQID_MATCH) {
		tmp32_0 |= rule->conf_fqid.id ;
		tmp32_1 |= rule->conf_fqid.mask;
	}

	if (rule->options &
			EIOP_DEBUG_DYNAMIC_RULE_OPT_DEQ_FD_DD_MATCH) {
		tmp32_0 |= rule->deq_fd_dd.id <<   EIOP_DEBUG_DEQ_FD_DD_MATCH_SHIFT_DCMP1_DMSK1;
		tmp32_1 |= rule->deq_fd_dd.mask << EIOP_DEBUG_DEQ_FD_DD_MATCH_SHIFT_DCMP1_DMSK1;
	}

	regs = UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr));
	/*pointer to QMI Port registers*/
	tmp_regs = (struct eiop_qmi_egress *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_QMI_EGRESS_OFFSET);

	iowrite32(tmp32_0, &((struct eiop_qmi_egress *)tmp_regs)->dcmp1);
	iowrite32(tmp32_1, &((struct eiop_qmi_egress *)tmp_regs)->dmsk1);
	
}

static void fill_marking_frame_ingr_reg(struct eiop_desc *eiop_desc,
		struct eiop_debug_dynamic_action *action)
{
	uint32_t tmp32_0 = 0;
	void *tmp_regs, *regs;
	
	/********************************************************************************/
		/*fill marking frame on ingress flow and recycle with the relevant values
	/********************************************************************************/

	if ((action->options & EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_INGR) ||
		(action->options &
				EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_INGR_ORED_WITH_FD_DD)) {
		tmp32_0 |= EIOP_DEBUG_FRM_MARK_INGR_EN_DDVAL0;
		tmp32_0 |= action->ingr_mark << EIOP_DEBUG_MARK_INGR_SHIFT_DDVAL0;
		tmp32_0|= action->ctlu_ingr_mark << EIOP_DEBUG_CTLU_MARK_INGR_SHIFT_DDVAL0;
		if (action->options &
				EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_INGR_ORED_WITH_FD_DD) {
			tmp32_0 |= EIOP_DEBUG_MARK_INGR_ORED_WITH_FD_DD_DDVAL0;
		}

	}

	regs = UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr));
	tmp_regs = (struct eiop_bmi_ingress *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_BMI_INGRESS_OFFSET);

	iowrite32(tmp32_0, &((struct eiop_bmi_ingress *)tmp_regs)->ddval0_0);

}

static void fill_marking_frame_eggr_recycle_reg(struct eiop_desc *eiop_desc,
		struct eiop_debug_dynamic_action *action)
{
	uint32_t tmp32_0 = 0;
	void *tmp_regs, *regs;

	/********************************************************************************/
		/*fill marking frame on eggress flow and recycle with the relevant values
	/********************************************************************************/


	if ((action->options & EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_EGGR) ||
			(action->options &
					EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_EGGR_ORED_WITH_FD_DD)) {
		tmp32_0 |= EIOP_DEBUG_FRM_MARK_EGGR_EN_DDVAL1;
		tmp32_0 |= action->eggr_mark << EIOP_DEBUG_MARK_EGGR_SHIFT_DDVAL1;
		tmp32_0|= action->ctlu_eggr_mark << EIOP_DEBUG_CTLU_MARK_EGGR_SHIFT_DDVAL1;
		if (action->options &
					EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_EGGR_ORED_WITH_FD_DD) {
			tmp32_0 |= EIOP_DEBUG_MARK_EGGR_ORED_WITH_FD_DD_DDVAL1;
		}
	
	}
	regs = UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr));
	/*pointer to QMI Port registers*/
	tmp_regs = (struct eiop_qmi_egress *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_QMI_EGRESS_OFFSET);
	
	iowrite32(tmp32_0, &((struct eiop_qmi_egress *)tmp_regs)->ddval1);

}

static void fill_debug_global_and_trace_opt(struct eiop_desc *eiop_desc,
		struct eiop_debug_dynamic_action *action)
{
	uint32_t tmp32_0 = 0;
	void *tmp_regs, *regs;
	/********************************************************************************/
	/*fill trace option in debug global are dmr
	/********************************************************************************/

	if (action->options & EIOP_DEBUG_DYNAMIC_ACTION_OPT_CTLU_DEBUG_TRACE_INGR)
		tmp32_0 |=  EIOP_CTLU_DEBUG_TRACE_INGR_DMR;

	if (action->options & EIOP_DEBUG_DYNAMIC_ACTION_OPT_DEBUG_TRACE_INGR)
		tmp32_0 |=  EIOP_DEBUG_TRACE_INGR_DMR;

	if (action->options & EIOP_DEBUG_DYNAMIC_ACTION_OPT_DEBUG_TRACE_EGGR)
		tmp32_0 |=  EIOP_DEBUG_TRACE_EGGR_DMR;

	regs = UINT_TO_PTR(PTR_TO_UINT(eiop_desc->vaddr));
	/*pointer to QMI Port registers*/
	tmp_regs = (struct eiop_debug_global *)UINT_TO_PTR(PTR_TO_UINT(regs) +
			EIOP_DEBUG_GLOBAL_OFFSET);

	iowrite32(tmp32_0, &((struct eiop_debug_global *)tmp_regs)->dmr);

}
static int eiop_set_dynamic_debug(struct eiop_desc *eiop_desc,
					struct eiop_debug_dynamic_cfg *debug_cfg) {

	int err = 0;
	struct eiop_debug_dynamic_rule *rule = &debug_cfg->rule;
	struct eiop_debug_dynamic_action *action = &debug_cfg->action;

	err = check_dynamic_debug_cfg(debug_cfg);
	if (err)
		return err;

	fill_debug_match_reg_ifp_qdid_qpri(eiop_desc, rule);
	fill_debug_match_reg_conf_fqid_fd_dd(eiop_desc, rule);
	fill_marking_frame_ingr_reg(eiop_desc, action);
	fill_marking_frame_eggr_recycle_reg(eiop_desc, action);
	fill_debug_global_and_trace_opt(eiop_desc, action);


    return 0;
}

/* This code sets up the following tables, described in WRIOP documentation:
 * "Congestion Group Priority Mapping table"
 * "Buffer Depletion Priority Mapping table"
 * cmd == 0 clear the bits set to one in cgp->bits
 * cmd == 1 set the bits set to one in cgp->bits
 * cmd == 2 write whole value from cgp->bits
 */
void eiop_set_port_cgp(int eiop_id, int port_id, struct eiop_cgp *cgp, int cmd)
{
	struct eiop_desc eiop_desc = {.eiop_id = eiop_id};
	struct eiop_bmi_ingress *g_bmi;
	int iter = 0, err, lsh = (3 - (port_id & 0x3)) * 8;
	uint32_t tmp;

	err = sys_get_desc(SOC_MODULE_EIOP, SOC_DB_EIOP_DESC_ID, &eiop_desc,
			NULL);
	ASSERT_COND (!err);

	g_bmi = (struct eiop_bmi_ingress*)(PTR_TO_UINT(eiop_desc.vaddr) +
			EIOP_BMI_INGRESS_OFFSET);
	tmp = (cgp->type)?EIOP_BMI_CGPA_CB:0;
	tmp |= cgp->id * 64;
	tmp |= port_id & 0xfc;
	iowrite32(tmp , &g_bmi->cgpa);

	tmp = ioread32(&g_bmi->cgpd);
	switch( cmd ) {
	case 0:
		tmp &= (uint32_t)( ~cgp->bits << lsh );
		break;
	case 1:
		tmp |= (uint32_t)cgp->bits << lsh;
		break;
	case 2:
		tmp &= ~(0xff << lsh);
		tmp |= (uint32_t)cgp->bits << lsh;
		break;
	}

	iowrite32(tmp, &g_bmi->cgpd);
}

int eiop_set_debug (struct eiop_desc *eiop_desc, struct eiop_debug_cfg *debug_cfg) {
	int err = 0;

	if (debug_cfg->options & EIOP_DEBUG_OPTIONS_SET_DYNAMIC_DEBUG)
		err = eiop_set_dynamic_debug(eiop_desc, &debug_cfg->debug_dynamic_cfg);

	return err;
}

#ifdef TKT011436 
/**************************************************************************//**
					eiop_temp_pfc_buffer_restore
*//***************************************************************************/
int eiop_temp_pfc_buffer_restore( struct eiop_desc *eiop_desc, struct eiop_cfg *cfg)
{
	struct tmp_eiop_cfg  tmp_eiop_cfg;

	memset(&tmp_eiop_cfg, 0, sizeof(struct tmp_eiop_cfg));

	/*NOTE -  the size which should be allocated for temp_pfc_buffer
		"number of possible frames in recycle queue per TC per port" - 64 *
	 	"number of ports that connect to ethernet MAC" - for first draft 16 *
	 	 number of TC - 8*
	 	 64.
	*/
	tmp_eiop_cfg.tpbb = cfg->temp_pfc_buffer;
	tmp_eiop_cfg.tpbb_icid = cfg->temp_pfc_icid;

	fill_regs(eiop_desc->vaddr, &tmp_eiop_cfg);
	        
	return 0;
}
/**************************************************************************//**
					eiop_reset - perform a WRIOP soft reset
*//***************************************************************************/
int eiop_reset() {

	void *tmp_regs;
	uint32_t reg;
	uint32_t timeout = 10000;
	struct eiop_desc eiop_desc;
	int iter = 0;

	memset(&eiop_desc, 0, sizeof(struct eiop_desc));
	/*pointer to DMA*/
	if (sys_get_desc(SOC_MODULE_EIOP, SOC_DB_EIOP_DESC_ID, &eiop_desc, &iter)
			== 0)
		tmp_regs =
				(struct eiop_fpm *) UINT_TO_PTR(PTR_TO_UINT(eiop_desc.vaddr) +
						EIOP_FPM_OFFSET);

	reg = ioread32(&((struct eiop_fpm *) tmp_regs)->rstc);
	reg &= ~EIOP_RSTC_QBRSTC; /*do not reset QBMAN interface with WRIOP*/
	reg |= EIOP_RSTC_RSTC;	/* WRIOP reset, will include MDIO, MACs */
	iowrite32(reg, &((struct eiop_fpm *) tmp_regs)->rstc);

	while ((ioread32(&((struct eiop_fpm *) tmp_regs)->rstc) & EIOP_RSTC_RSTC)
			&& --timeout)
		timer_udelay(1);
	pr_debug("WRIOP reset in %d us\n", (10000 - timeout));
	if (!timeout) {
		pr_err("Wriop reset TIMEOUT\n");
		return -ETIMEDOUT;
	}

	return 0;

}
#endif /* TKT011436 */
