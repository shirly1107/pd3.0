/**
*   Copyright 2009-2016, Freescale Semiconductor, Inc.  All Rights Reserved.
*
*    NOTICE: The information contained in this file is proprietary
*    to Freescale Semiconductor and is being made available to
*    Freescale's customers under a specific license agreement.
*    Use or disclosure of this information is permissible only
*    under the terms of the license agreement.
*/
/**************************************************************************//**
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_gen.h"
#include "fsl_io.h"
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "fsl_malloc.h"
#include "fsl_eiop.h"
#include "fsl_platform.h"

#include "eiop_rtc.h"

/*****************************************************************************/
static void get_defaults(const struct eiop_rtc_desc *desc,
                         const struct eiop_rtc_defcfg *defcfg,
                         struct eiop_rtc_defcfg *defaults)
{
	int i;

	memcpy(defaults, defcfg, sizeof(struct eiop_rtc_defcfg));

	if (defcfg->src_clk == 0)
		defaults->src_clk = EIOP_RTC_SOURCE_CLOCK_SYSTEM;
	if (defcfg->clock_period_nanosec == 0)
		defaults->clock_period_nanosec = DEFAULT_CLOCK_PERIOD;
	if (defcfg->output_clock_divisor == 0)
		defaults->output_clock_divisor = DEFAULT_OUTPUT_CLOCK_DIVISOR;
	for (i = 0; i < desc->num_alarms; i++) {
		if (defcfg->alarm_polarity[i] == 0)
			defaults->alarm_polarity[i] =
			        EIOP_RTC_ALARM_POLARITY_ACTIVE_HIGH;
	}
	for (i = 0; i < desc->num_ext_triggers; i++) {
		if (defcfg->trigger_polarity[i] == 0)
			defaults->trigger_polarity[i] =
			        EIOP_RTC_TRIGGER_ON_FALLING_EDGE;
	}
}

static uint32_t get_events(struct eiop_rtc_regs *regs)
{
	return ioread32(&regs->tmr_tevent);
}

static uint32_t get_event(struct eiop_rtc_regs *regs, uint32_t ev_mask)
{
	return ioread32(&regs->tmr_tevent) & ev_mask;
}

static uint32_t get_interrupt_mask(struct eiop_rtc_regs *regs)
{
	return ioread32(&regs->tmr_temask);
}

static void set_interrupt_mask(struct eiop_rtc_regs *regs, uint32_t mask)
{
	iowrite32(mask, &regs->tmr_temask);
}

static void ack_event(struct eiop_rtc_regs *regs, uint32_t events)
{
	iowrite32(events, &regs->tmr_tevent);
}

static uint32_t check_and_clear_event(struct eiop_rtc_regs *regs)
{
	uint32_t event;

	event = ioread32(&regs->tmr_tevent);
	event &= ioread32(&regs->tmr_temask);

	if (event)
		iowrite32(event, &regs->tmr_tevent);
	return event;
}

static uint32_t get_frequency_compensation(struct eiop_rtc_regs *regs)
{
	return ioread32(&regs->tmr_add);
}

static void set_frequency_compensation(struct eiop_rtc_regs *regs, uint32_t val)
{
	iowrite32(val, &regs->tmr_add);
}

static void enable_interupt(struct eiop_rtc_regs *regs, uint32_t events)
{
	set_interrupt_mask(regs, get_interrupt_mask(regs) | events);
}

static void disable_interupt(struct eiop_rtc_regs *regs, uint32_t events)
{
	set_interrupt_mask(regs, get_interrupt_mask(regs) & ~events);
}

static void set_timer_alarm_l(struct eiop_rtc_regs *regs,
                              int index,
                              uint32_t val)
{
	iowrite32(val, &regs->tmr_alarm[index].tmr_alarm_l);
}

static void set_periodic_pulse_time(struct eiop_rtc_regs *regs, int index, uint32_t val)
{
	iowrite32(val, &regs->tmr_fiper[index]);
}

static void set_alarm_time(struct eiop_rtc_regs *regs, int index, int64_t val)
{
	iowrite32((uint32_t)val, &regs->tmr_alarm[index].tmr_alarm_l);
	iowrite32((uint32_t)(val >> 32), &regs->tmr_alarm[index].tmr_alarm_h);
}

static void set_timer_offset(struct eiop_rtc_regs *regs, uint64_t val)
{
	iowrite32((uint32_t)val, &regs->tmr_off_l);
	iowrite32((uint32_t)(val >> 32), &regs->tmr_off_h);
}

static uint64_t get_timer_offset(struct eiop_rtc_regs *regs)
{
	uint64_t time;

	time = (uint64_t)ioread32(&regs->tmr_off_l);
	time |= ((uint64_t)ioread32(&regs->tmr_off_h) << 32);

	return time;
}

static uint64_t get_trigger_stamp(struct eiop_rtc_regs *regs, int id)
{
	uint64_t time;
	/* TMR_CNT_L must be read first to get an accurate value */
	time = (uint64_t)ioread32(&regs->tmr_etts[id].tmr_etts_l);
	time |= ((uint64_t)ioread32(&regs->tmr_etts[id].tmr_etts_h) << 32);

	return time;
}

static uint32_t get_timer_status(struct eiop_rtc_regs *regs)
{
	return ioread32(&regs->tmr_stat);
}

static uint32_t get_timer_ctrl(struct eiop_rtc_regs *regs)
{
	return ioread32(&regs->tmr_ctrl);
}

static void set_timer_ctrl(struct eiop_rtc_regs *regs, uint32_t val)
{
	iowrite32(val, &regs->tmr_ctrl);
}

static void timers_soft_reset(struct eiop_rtc_regs *regs)
{
	set_timer_ctrl(regs, EIOP_RTC_TMR_CTRL_TMSR);
	//TODO: udelay(10);
	set_timer_ctrl(regs, 0);
}

static void init(const struct eiop_rtc_defcfg *cfg,
                 struct eiop_rtc_regs *regs,
                 int num_alarms,
                 int num_periodics,
                 int num_ext_triggers,
                 int init_freq_comp,
                 uint32_t freq_compensation,
                 uint32_t clk_period,
                 uint32_t output_clock_divisor)
{
	uint32_t tmr_ctrl;
	int i;

	timers_soft_reset(regs);

	/* Set the source clock */
	switch (cfg->src_clk) {
	case EIOP_RTC_SOURCE_CLOCK_SYSTEM:
		tmr_ctrl = EIOP_RTC_TMR_CTRL_CKSEL_MAC_CLK;
		break;
	case EIOP_RTC_SOURCE_CLOCK_OSCILATOR:
		tmr_ctrl = EIOP_RTC_TMR_CTRL_CKSEL_OSC_CLK;
		break;
	default:
		/* Use a clock from the External TMR reference clock.*/
		tmr_ctrl = EIOP_RTC_TMR_CTRL_CKSEL_EXT_CLK;
		break;
	}

	tmr_ctrl |= ((clk_period << EIOP_RTC_TMR_CTRL_TCLK_PERIOD_SHIFT)
	             & EIOP_RTC_TMR_CTRL_TCLK_PERIOD_MASK);

	if (cfg->options & EIOP_RTC_OPT_INVERT_INPUT)
		tmr_ctrl |= EIOP_RTC_TMR_CTRL_CIPH;
	if (cfg->options & EIOP_RTC_OPT_INVERT_OUTPUT)
		tmr_ctrl |= EIOP_RTC_TMR_CTRL_COPH;

	for (i = 0; i < num_alarms; i++) {
		if (cfg->alarm_polarity[i]
		    == EIOP_RTC_ALARM_POLARITY_ACTIVE_LOW)
			tmr_ctrl |= (EIOP_RTC_TMR_CTRL_ALMP1 >> i);
	}

	for (i = 0; i < num_ext_triggers; i++)
		if (cfg->trigger_polarity[i]
		    == EIOP_RTC_TRIGGER_ON_FALLING_EDGE)
			tmr_ctrl |= (EIOP_RTC_TMR_CTRL_ETEP1 << i);

	if (!(cfg->options & EIOP_RTC_OPT_SLAVE_MODE) && (cfg->options & EIOP_RTC_OPT_BYPASS))
		tmr_ctrl |= EIOP_RTC_TMR_CTRL_BYP;

	if (cfg->options & EIOP_RTC_OPT_DISABLE_REALIGN)
		tmr_ctrl |= EIOP_RTC_TMR_CTRL_FRD;

	set_timer_ctrl(regs, tmr_ctrl);

	if (init_freq_comp)
		set_frequency_compensation(regs, freq_compensation);

	/* Clear TMR_ALARM registers */
	for (i = 0; i < num_alarms; i++)
		set_alarm_time(regs, i, 0xFFFFFFFFFFFFFFFFLL);

	/* Clear TMR_TEVENT */
	ack_event(regs, EIOP_RTC_TMR_TEVENT_ALL);

	/* Initialize TMR_TEMASK */
	set_interrupt_mask(regs, 0);

	/* Clear TMR_FIPER registers */
	for (i = 0; i < num_periodics; i++)
		set_periodic_pulse_time(regs, i, 0xFFFFFFFF);

	/* Initialize TMR_PRSC */
	iowrite32(output_clock_divisor, &regs->tmr_prsc);

	/* Clear TMR_OFF */
	set_timer_offset(regs, 0);
}

static int is_enabled(struct eiop_rtc_regs *regs)
{
	return (int)(get_timer_ctrl(regs) & EIOP_RTC_TMR_CTRL_TE);
}

static void clear_periodic_pulse_intr(struct eiop_rtc_regs *regs, int id)
{
	uint32_t tmp_reg;
	switch (id) {
	case (0):
	tmp_reg = EIOP_RTC_TMR_TEVENT_PP1;
	break;
	case (1):
	tmp_reg = EIOP_RTC_TMR_TEVENT_PP2;
	break;
	case (2):
		tmp_reg = EIOP_RTC_TMR_TEVENT_PP3;
	break;
	default:
		return;
	}
	disable_interupt(regs, tmp_reg);
}

static void clear_periodic_pulse(struct eiop_rtc_regs *regs, int id)
{
	uint32_t tmp_reg;
	
	clear_periodic_pulse_intr(regs, id);

	tmp_reg = get_timer_ctrl(regs);
	if (tmp_reg & EIOP_RTC_TMR_CTRL_FS)
	set_timer_ctrl(regs, tmp_reg & ~EIOP_RTC_TMR_CTRL_FS);

	set_periodic_pulse_time(regs, id, 0xFFFFFFFF);
}

static void clear_external_trigger(struct eiop_rtc_regs *regs, int id)
{
	uint32_t tmpReg;

	if (id == 0)
	tmpReg = EIOP_RTC_TMR_TEVENT_ETS1;
	else
	tmpReg = EIOP_RTC_TMR_TEVENT_ETS2;
	disable_interupt(regs, tmpReg);

}

static void set_alarm_intr(struct eiop_rtc_regs *regs, int id)
{
	uint32_t tmpReg;
		if (id == 0)
		tmpReg = EIOP_RTC_TMR_TEVENT_ALM1;
		else
		tmpReg = EIOP_RTC_TMR_TEVENT_ALM2;
	
		enable_interupt(regs, tmpReg);
	}

static void set_periodic_pulse_intr(struct eiop_rtc_regs *regs,
	int id)
{
	uint32_t tmpReg;
	
		switch (id) {
		case (0):
			tmpReg = EIOP_RTC_TMR_TEVENT_PP1;
		break;
		case (1):
			tmpReg = EIOP_RTC_TMR_TEVENT_PP2;
		break;
		case (2):
			tmpReg = EIOP_RTC_TMR_TEVENT_PP3;
		break;
	default:
		return;
		}
		enable_interupt(regs, tmpReg);
	}

static void set_ext_trigger(struct eiop_rtc_regs *regs,
	int id,
	int use_pulse_as_input)
{
	uint32_t tmpReg, tmp_ctrl;

	if (id == 0)
		tmpReg = EIOP_RTC_TMR_CTRL_PP1L;
	else
		tmpReg = EIOP_RTC_TMR_CTRL_PP2L;

	tmp_ctrl = get_timer_ctrl(regs);

	if (use_pulse_as_input) {
		if (!(tmp_ctrl & tmpReg))
			set_timer_ctrl(regs, tmp_ctrl | tmpReg);
	} else {
		if (tmp_ctrl & tmpReg)
			set_timer_ctrl(regs, tmp_ctrl & ~tmpReg);
	}
}

static void set_ext_trigger_intr(struct eiop_rtc_regs *regs,
	int id)
{
	uint32_t tmpReg;
	if (id == 0)
		tmpReg = EIOP_RTC_TMR_TEVENT_ETS1;
	else
		tmpReg = EIOP_RTC_TMR_TEVENT_ETS2;
	enable_interupt(regs, tmpReg);
}

static int check_cfg(struct eiop_rtc *eiop_rtc, struct eiop_rtc_defcfg *cfg)
{
	int i;

	if ((cfg->src_clk != EIOP_RTC_SOURCE_CLOCK_SYSTEM)
		&& !cfg->ext_src_clk_freq) {
		pr_err("External source clock frequency undefined\n");
		return -EINVAL;
	}
		
	if ((cfg->src_clk != EIOP_RTC_SOURCE_CLOCK_EXTERNAL)
	    && (cfg->src_clk != EIOP_RTC_SOURCE_CLOCK_SYSTEM)
	    && (cfg->src_clk != EIOP_RTC_SOURCE_CLOCK_OSCILATOR)) {
		pr_err("Source clock undefined\n");
		return -EINVAL;
	}

	for (i = 0; i < eiop_rtc->num_alarms; i++) {
		if ((cfg->alarm_polarity[i]
		     != EIOP_RTC_ALARM_POLARITY_ACTIVE_LOW)
		    && (cfg->alarm_polarity[i]
		        != EIOP_RTC_ALARM_POLARITY_ACTIVE_HIGH)) {
			pr_err("Alarm %d signal polarity", i);
			return -EINVAL;
		}
	}
	for (i = 0; i < eiop_rtc->num_ext_triggers; i++) {
		if ((cfg->trigger_polarity[i]
		     != EIOP_RTC_TRIGGER_ON_FALLING_EDGE)
		    && (cfg->trigger_polarity[i]
		        != EIOP_RTC_TRIGGER_ON_RISING_EDGE)) {
			{
				pr_err("Trigger %d signal polarity", i);
				return -EINVAL;
			}
		}
	}

	return 0;
}

/*****************************************************************************/
void eiop_rtc_exceptions(struct eiop_rtc *eiop_rtc)
{
	struct eiop_rtc_regs *regs;
	register uint32_t events;

	ASSERT_COND(eiop_rtc);
	ASSERT_COND(eiop_rtc->isr_cb);
	
	regs = eiop_rtc->regs;

	events = check_and_clear_event(regs);
	if (events & EIOP_RTC_TMR_TEVENT_ALM1) {
			set_timer_alarm_l(regs, 0, 0);
			disable_interupt(regs, EIOP_RTC_TMR_TEVENT_ALM1);
		eiop_rtc->isr_cb(eiop_rtc->isr_cb_arg, eiop_rtc->isr_cb_irq_id,
			eiop_rtc->alarm_event_mask[0]);
	}
	if (events & EIOP_RTC_TMR_TEVENT_ALM2) {
			set_timer_alarm_l(regs, 1, 0);
			disable_interupt(regs, EIOP_RTC_TMR_TEVENT_ALM2);
		eiop_rtc->isr_cb(eiop_rtc->isr_cb_arg, eiop_rtc->isr_cb_irq_id,
		                 eiop_rtc->alarm_event_mask[1]);
	}
	if (events & EIOP_RTC_TMR_TEVENT_PP1) {
		eiop_rtc->isr_cb(eiop_rtc->isr_cb_arg, eiop_rtc->isr_cb_irq_id,
			eiop_rtc->periodic_pulse_event_mask[0]);
	}
	if (events & EIOP_RTC_TMR_TEVENT_PP2) {
		eiop_rtc->isr_cb(eiop_rtc->isr_cb_arg, eiop_rtc->isr_cb_irq_id,
			eiop_rtc->periodic_pulse_event_mask[1]);
	}
	if (events & EIOP_RTC_TMR_TEVENT_PP3) {
		eiop_rtc->isr_cb(eiop_rtc->isr_cb_arg, eiop_rtc->isr_cb_irq_id,
			eiop_rtc->periodic_pulse_event_mask[2]);
	}
	if (events & EIOP_RTC_TMR_TEVENT_ETS1) {
		eiop_rtc->isr_cb(eiop_rtc->isr_cb_arg, eiop_rtc->isr_cb_irq_id,
			eiop_rtc->ext_trigger_event_mask[0]);
	}
	if (events & EIOP_RTC_TMR_TEVENT_ETS2) {
		eiop_rtc->isr_cb(eiop_rtc->isr_cb_arg, eiop_rtc->isr_cb_irq_id,
			eiop_rtc->ext_trigger_event_mask[1]);
	}
}

#ifdef TKT011436 
/**************************************************************************//**
 @Function     rtc_restore_runtime_config
*//***************************************************************************/
int rtc_restore_runtime_config(struct eiop_rtc *eiop_rtc)
{
	struct eiop_rtc_regs *regs;
	uint32_t tmr_ctrl = 0;
	int i;
	
	regs = eiop_rtc->regs;

	tmr_ctrl = get_timer_ctrl(regs);

	/* Restore fipper loopback */
	for (i = 0; i < eiop_rtc->num_ext_triggers; i++) 
	{
		if(eiop_rtc->fipper_loopback[i])
			tmr_ctrl |= (EIOP_RTC_TMR_CTRL_PP1L >> i);

	}
	set_timer_ctrl(regs, tmr_ctrl);

	if (eiop_rtc->freq_compensation)
		set_frequency_compensation(regs, eiop_rtc->freq_compensation);

	/* Restore Alarm 2 (alarm 2 in API, 1 in MC */
	if(eiop_rtc->alarm_time)
		set_alarm_time(regs, 1, eiop_rtc->alarm_time);
	
	/* Restore TMR_OFF */
	if(eiop_rtc->timer_offset)
		set_timer_offset(regs, eiop_rtc->timer_offset);

	/* Restore TMR_TEMASK */
	if(eiop_rtc->interrupt_mask)
		set_interrupt_mask(regs, eiop_rtc->interrupt_mask);

	if(eiop_rtc->timestamp)
		set_timer(eiop_rtc->regs, 
				eiop_rtc->timestamp /
				(uint64_t)eiop_rtc->clock_period_nanosec);

	return 0;
}

static void rtc_restore_hardware (struct eiop_rtc *eiop_rtc)
{
	struct eiop_rtc_regs *regs;
	uint32_t tmr_ctrl;
	int i;
	
	regs = eiop_rtc->regs;
	timers_soft_reset(regs);

	/* Set the source clock */
	switch (eiop_rtc->src_clk) {
	case EIOP_RTC_SOURCE_CLOCK_SYSTEM:
		tmr_ctrl = EIOP_RTC_TMR_CTRL_CKSEL_MAC_CLK;
		break;
	case EIOP_RTC_SOURCE_CLOCK_OSCILATOR:
		tmr_ctrl = EIOP_RTC_TMR_CTRL_CKSEL_OSC_CLK;
		break;
	default:
		/* Use a clock from the External TMR reference clock.*/
		tmr_ctrl = EIOP_RTC_TMR_CTRL_CKSEL_EXT_CLK;
		break;
	}
	tmr_ctrl |= ((eiop_rtc->init.clk_period << EIOP_RTC_TMR_CTRL_TCLK_PERIOD_SHIFT)
	             & EIOP_RTC_TMR_CTRL_TCLK_PERIOD_MASK);

	for (i = 0; i < eiop_rtc->num_alarms; i++) {
		if (eiop_rtc->alarm_polarity[i]
		    == EIOP_RTC_ALARM_POLARITY_ACTIVE_LOW)
			tmr_ctrl |= (EIOP_RTC_TMR_CTRL_ALMP1 >> i);
	}

	for (i = 0; i < eiop_rtc->num_ext_triggers; i++) 
	{
		if (eiop_rtc->trigger_polarity[i]
		    == EIOP_RTC_TRIGGER_ON_FALLING_EDGE)
			tmr_ctrl |= (EIOP_RTC_TMR_CTRL_ETEP1 << i);
	}

	set_timer_ctrl(regs, tmr_ctrl);

	set_frequency_compensation(regs, eiop_rtc->init.freq_compensation);

	/* Set ALARM TIME */
	for (i = 0; i < eiop_rtc->num_alarms; i++)
		set_alarm_time(regs, i, 0xFFFFFFFFFFFFFFFFLL);

	/* Clear TMR_TEVENT */
	ack_event(regs, EIOP_RTC_TMR_TEVENT_ALL);

	/* Clear TMR_TEMASK */
	set_interrupt_mask(regs, 0);

	/* Clear TMR_FIPER registers */
	for (i = 0; i < eiop_rtc->num_periodics; i++)
		set_periodic_pulse_time(regs, i, 0xFFFFFFFF);

	/* Initialize TMR_PRSC */
	iowrite32(eiop_rtc->output_clock_divisor, &regs->tmr_prsc);

	/* Clear TMR_OFF */
	set_timer_offset(regs, 0);

}

/**************************************************************************//**
 @Function     eiop_rtc_restore_hardware
*//***************************************************************************/
int eiop_rtc_restore_hardware (struct eiop_rtc *eiop_rtc)
{
	uint64_t tmp_double;

	/* check the legality of the relation between source and destination clocks */
	/* should be larger than 1.0001 */
	tmp_double = 10000 * (uint64_t)eiop_rtc->clock_period_nanosec
	             * (uint64_t)eiop_rtc->src_clk_freq_mhz;
	if ((tmp_double) <= 10001) {
		pr_err("Invalid relation between source and destination clocks. Should be larger than 1.0001\n");
		fsl_free(eiop_rtc);
		return -EINVAL;
	}
	rtc_restore_hardware(eiop_rtc);

	return 0;
}
#endif /* TKT011436 */

/**************************************************************************//**
 @Function     eiop_rtc_init
*//***************************************************************************/
struct eiop_rtc *eiop_rtc_init(const struct eiop_rtc_desc *eiop_rtc_desc,
                               const struct eiop_rtc_cfg *eiop_rtc_cfg)
{
	int i;
	struct eiop_rtc *eiop_rtc;
	struct eiop_rtc_defcfg defaults;
	struct eiop_desc eiop_desc;
	uint64_t freq_compensation = 0;
	uint64_t tmp_double;
	int init_freq_comp = 0, err = 0;
    uint32_t clk_period = 1;

	/* Allocate memory for the FM RTC driver parameters */
	eiop_rtc = (struct eiop_rtc *)fsl_malloc(sizeof(struct eiop_rtc));
	if (!eiop_rtc) {
		pr_err("EIOP RTC memory allocation failed");
		return NULL;
	}

	memset(eiop_rtc, 0, sizeof(struct eiop_rtc));

	/* Store RTC parameters in the RTC control structure */
	eiop_rtc->regs = (struct eiop_rtc_regs *)eiop_rtc_desc->vaddr;
	eiop_rtc->num_alarms = eiop_rtc_desc->num_alarms;
	eiop_rtc->num_ext_triggers = eiop_rtc_desc->num_ext_triggers;
	eiop_rtc->num_periodics = eiop_rtc_desc->num_periodics;

	/* Set default RTC configuration parameters */
	get_defaults(eiop_rtc_desc, &eiop_rtc_cfg->defcfg, &defaults);

	if (check_cfg(eiop_rtc, &defaults)) {
		pr_err("Init Parameters are not Valid\n");
		fsl_free(eiop_rtc);
		return NULL;
	}

	/* update structure with User's/default parameters */
	eiop_rtc->clock_period_nanosec = defaults.clock_period_nanosec;
	eiop_rtc->output_clock_divisor = defaults.output_clock_divisor;
	eiop_rtc->src_clk = defaults.src_clk;

	for (i = 0; i < eiop_rtc->num_alarms; i++)
		eiop_rtc->alarm_polarity[i] = defaults.alarm_polarity[i];

	for (i = 0; i < eiop_rtc->num_ext_triggers; i++)
		eiop_rtc->trigger_polarity[i] = defaults.trigger_polarity[i];

	/* find source clock frequency in Mhz */
	if (defaults.src_clk != EIOP_RTC_SOURCE_CLOCK_SYSTEM)
		eiop_rtc->src_clk_freq_mhz = defaults.ext_src_clk_freq;
	else
	{
		memset(&eiop_desc, 0, sizeof(eiop_desc));
		eiop_desc.eiop_id = eiop_rtc_desc->eiop_id;
		err = sys_get_desc(SOC_MODULE_EIOP, SOC_DB_EIOP_DESC_ID, &eiop_desc, NULL);
		ASSERT_COND (!err);
		if (IS_SIM)
			eiop_rtc->src_clk_freq_mhz = 600;
		else
			eiop_rtc->src_clk_freq_mhz = sys_get_platform_clk()
							/ 1000;
	}

	/* if timer in Master mode Initialize TMR_CTRL */
	/* We want the counter (TMR_CNT) to count in nano-seconds */
	if (!(defaults.options & EIOP_RTC_OPT_SLAVE_MODE) && (defaults.options & EIOP_RTC_OPT_BYPASS) && 
			(eiop_rtc->src_clk_freq_mhz) != 0)
		eiop_rtc->clock_period_nanosec = (1000
		                                  / eiop_rtc->src_clk_freq_mhz);
	else {
		/* Initialize TMR_ADD with the initial frequency compensation value:
		 freq_compensation = (2^32 / frequency ratio) */
		/* frequency ratio = sorce clock/rtc clock =
		 * (eiop_rtc->src_clk_freq_mhz*1000000))/ 1/(eiop_rtc->clock_period_nanosec * 1000000000) */
		init_freq_comp = 1;
		freq_compensation =
                DIV_CEIL(ACCUMULATOR_OVERFLOW * 1000,
			        eiop_rtc->clock_period_nanosec * eiop_rtc->src_clk_freq_mhz);
		
        /* if freq_compensation is too large for 32 bit reg, divide it by 2 and 
         * increase CLK_PERIOD accordingly */ 
        while (freq_compensation & 0xFFFFFFFF00000000)
        {
            freq_compensation >>= 1;
            clk_period  <<= 1;
        }
	}

	eiop_rtc->init.clk_period = clk_period;
	eiop_rtc->init.freq_compensation = (uint32_t)freq_compensation;

	/* check the legality of the relation between source and destination clocks */
	/* should be larger than 1.0001 */
	tmp_double = 10000 * (uint64_t)eiop_rtc->clock_period_nanosec
	             * (uint64_t)eiop_rtc->src_clk_freq_mhz;
	if ((tmp_double) <= 10001) {
		pr_err("Invalid relation between source and destination clocks. Should be larger than 1.0001\n");
		fsl_free(eiop_rtc);
		return NULL;
	}

	init(&defaults, eiop_rtc->regs, eiop_rtc_desc->num_alarms,
	     eiop_rtc_desc->num_periodics, eiop_rtc_desc->num_ext_triggers,
         init_freq_comp, (uint32_t)freq_compensation, clk_period, eiop_rtc->output_clock_divisor);

	//FmRegisterIntr(eiop_rtc->h_Fm, e_FM_MOD_TMR, 0, e_FM_INTR_TYPE_NORMAL, RtcExceptions , eiop_rtc);
	return eiop_rtc;
}

/*****************************************************************************/
int eiop_rtc_done(struct eiop_rtc *eiop_rtc)
{

	eiop_rtc_disable(eiop_rtc);

	//FmUnregisterIntr(eiop_rtc->h_Fm, e_FM_MOD_TMR, 0, e_FM_INTR_TYPE_NORMAL);
	fsl_free(eiop_rtc);

	return 0;
}

/*****************************************************************************/
void eiop_rtc_set_isr_params(struct eiop_rtc *eiop_rtc, 
	int (*isr_cb)(void *arg, uint8_t irq_id, uint32_t event), 
	void *arg, 
	uint8_t irq_id)
{
	eiop_rtc->isr_cb = isr_cb;
	eiop_rtc->isr_cb_arg = arg;
	eiop_rtc->isr_cb_irq_id = irq_id;	
}

/*****************************************************************************/
int eiop_rtc_enable(struct eiop_rtc *eiop_rtc, int reset_clock)
{
	uint32_t tmr_ctrl = get_timer_ctrl(eiop_rtc->regs);

	if (reset_clock) {
		set_timer_ctrl(eiop_rtc->regs,
		               (tmr_ctrl | EIOP_RTC_TMR_CTRL_TMSR));

		//TODO: udelay(10);
		/* Clear TMR_OFF */
		set_timer_offset(eiop_rtc->regs, 0);
	}

	set_timer_ctrl(eiop_rtc->regs, (tmr_ctrl | EIOP_RTC_TMR_CTRL_TE));

	return 0;
}

/*****************************************************************************/
int eiop_rtc_disable(struct eiop_rtc *eiop_rtc)
{

	set_timer_ctrl(
	        eiop_rtc->regs,
	        (get_timer_ctrl(eiop_rtc->regs) & ~(EIOP_RTC_TMR_CTRL_TE)));

	return 0;
}

/*****************************************************************************/

int eiop_rtc_set_clock_offset(struct eiop_rtc *eiop_rtc, uint64_t offset)
{

	ASSERT_COND(eiop_rtc);
	set_timer_offset(eiop_rtc->regs, offset);
	/*Store the value*/
	eiop_rtc->timer_offset = offset;
	return 0;
}

/*****************************************************************************/
int eiop_rtc_get_clock_offset(struct eiop_rtc *eiop_rtc, uint64_t *offset)
{
	ASSERT_COND(eiop_rtc);

	*offset = get_timer_offset(eiop_rtc->regs);

	return 0;
}

/*****************************************************************************/
int eiop_rtc_set_alarm(struct eiop_rtc *eiop_rtc,
                       struct eiop_rtc_event_cfg *rtc_event_cfg)
{
	uint64_t tmp_alarm;

	ASSERT_COND(eiop_rtc);

	ASSERT_COND(eiop_rtc->isr_cb);
	
	if (rtc_event_cfg->id >= eiop_rtc->num_alarms) {
		pr_err("Alarm ID");
		return -EINVAL;
	}

	if (rtc_event_cfg->time < eiop_rtc->clock_period_nanosec) {
		pr_err("Alarm time must be equal or larger than RTC period - %d nanoseconds", eiop_rtc->clock_period_nanosec);
		return -EINVAL;
	}
	if (rtc_event_cfg->time
	    % (uint64_t)eiop_rtc->clock_period_nanosec) {
		pr_err("Alarm time must be a multiple of RTC period - %d nanoseconds", eiop_rtc->clock_period_nanosec);
		return -EINVAL;
	}
	if (rtc_event_cfg->id > (eiop_rtc->num_alarms - 1)) {
		pr_err("Alarm id must be between 0 - %d ", eiop_rtc->num_alarms - 1);
		return -EINVAL;
	}
	
	tmp_alarm = rtc_event_cfg->time
	            / (uint64_t)eiop_rtc->clock_period_nanosec;
	
	eiop_rtc->alarm_event_mask[rtc_event_cfg->id] = rtc_event_cfg->event_mask;

	set_alarm_time(eiop_rtc->regs, rtc_event_cfg->id,
	          (unsigned long)tmp_alarm);

	/* store the value */
	eiop_rtc->alarm_time = tmp_alarm;

	if(!rtc_event_cfg->disable_intr)
		set_alarm_intr(eiop_rtc->regs, rtc_event_cfg->id);

	/* Store the value from HW */
	eiop_rtc->interrupt_mask = get_interrupt_mask(eiop_rtc->regs);

	return 0;
}

/*****************************************************************************/
int eiop_rtc_set_periodic_pulse(struct eiop_rtc *eiop_rtc,
                                struct eiop_rtc_event_cfg *rtc_event_cfg)
{
	uint64_t tmp_fiper;

	ASSERT_COND(eiop_rtc);

	if (rtc_event_cfg->id
	    >= eiop_rtc->num_periodics) {
		pr_err("Periodic pulse ID\n");
		return -EINVAL;
	}
	if (is_enabled(eiop_rtc->regs)) {
		pr_err("Can't set Periodic pulse when RTC is enabled\n");
		return -EACCES;
	}

	if (rtc_event_cfg->time
	    < eiop_rtc->clock_period_nanosec) {
		pr_err("Periodic pulse must be equal or larger than RTC period - %d nanoseconds\n", eiop_rtc->clock_period_nanosec);
		return -EINVAL;
	}

	if (rtc_event_cfg->time
	    % (uint64_t)eiop_rtc->clock_period_nanosec) {
		pr_err("Periodic pulse must be a multiple of RTC period - %d nanoseconds\n", eiop_rtc->clock_period_nanosec);
		return -EINVAL;
	}
	if (rtc_event_cfg->id > (eiop_rtc->num_periodics - 1)) {
		pr_err("Periodic pulse id must be between 0 - %d ", eiop_rtc->num_periodics - 1);
		return -EINVAL;
	}


	tmp_fiper = rtc_event_cfg->time
	            / (uint64_t)eiop_rtc->clock_period_nanosec;
	if (tmp_fiper & 0xffffffff00000000LL) {
		pr_err("Periodic pulse/RTC Period must be smaller than 4294967296\n", eiop_rtc->clock_period_nanosec);
		return -EINVAL;
	}
	eiop_rtc->periodic_pulse_event_mask[rtc_event_cfg->id] = rtc_event_cfg->event_mask;

	set_periodic_pulse_time(eiop_rtc->regs, rtc_event_cfg->id,
	          (uint32_t)tmp_fiper);
	
	if(!rtc_event_cfg->disable_intr)
		set_periodic_pulse_intr(eiop_rtc->regs,
	                   rtc_event_cfg->id);
	
	return 0;
}

int eiop_rtc_set_periodic_pulse_intr(struct eiop_rtc *eiop_rtc,
                                  uint8_t id, int enable)
{
	if (id > (eiop_rtc->num_periodics - 1)) {
		pr_err("Periodic pulse id must be between 0 - %d ", eiop_rtc->num_periodics - 1);
		return -EINVAL;
	}
	if (enable)
		set_periodic_pulse_intr(eiop_rtc->regs, id);
	else
		clear_periodic_pulse_intr(eiop_rtc->regs, id);

	/* Store the value from HW */
	eiop_rtc->interrupt_mask = get_interrupt_mask(eiop_rtc->regs);

	return 0;
}

/*****************************************************************************/
int eiop_rtc_clear_periodic_pulse(struct eiop_rtc *eiop_rtc,
                                  uint8_t id)
{
	ASSERT_COND(eiop_rtc);


	if (id >= eiop_rtc->num_periodics) {
		pr_err("Periodic pulse ID\n");
		return -EINVAL;
	}
	clear_periodic_pulse(eiop_rtc->regs, id);

	return 0;
}

/*****************************************************************************/
int eiop_rtc_set_ext_trigger(struct eiop_rtc *eiop_rtc,
                             struct eiop_rtc_event_cfg *rtc_event_cfg)
{
	ASSERT_COND(eiop_rtc);

	if (rtc_event_cfg->id
	    >= eiop_rtc->num_ext_triggers) {
		pr_err("External Trigger ID must be between 0 - %d\n",
		       eiop_rtc->num_ext_triggers - 1);
		return -EINVAL;
	}
	eiop_rtc->ext_trigger_event_mask[rtc_event_cfg->id] = rtc_event_cfg->event_mask;

	if(!rtc_event_cfg->disable_intr)
		set_ext_trigger_intr(eiop_rtc->regs,
	                rtc_event_cfg->id);

	/* Store the value from HW */
	eiop_rtc->interrupt_mask = get_interrupt_mask(eiop_rtc->regs);

	return 0;
}

/*****************************************************************************/
int eiop_rtc_set_fiper_loopback(struct eiop_rtc *eiop_rtc,
                                  struct eiop_rtc_event_cfg *rtc_event_cfg)
{
	ASSERT_COND(eiop_rtc);

	if (rtc_event_cfg->id
	    >= eiop_rtc->num_ext_triggers) {
		pr_err("External Trigger ID must be between 0 - %d\n",
		       eiop_rtc->num_ext_triggers - 1);
		return -EINVAL;
	}
	
	/* Store the value */
	eiop_rtc->fipper_loopback[rtc_event_cfg->id] = (uint8_t)rtc_event_cfg->use_pulse_as_input;

	set_ext_trigger(eiop_rtc->regs,
                rtc_event_cfg->id,
	                rtc_event_cfg->use_pulse_as_input);

	return 0;
}

/*****************************************************************************/
int eiop_rtc_clear_ext_trigger(struct eiop_rtc *eiop_rtc,
                               uint8_t id)
{
	ASSERT_COND(eiop_rtc);

	if (id >= eiop_rtc->num_ext_triggers) {
		pr_err("External Trigger ID\n");
		return -EINVAL;
	}

	//eiop_rtc->ext_trigger_params[id].ext_trigger_cb = NULL;

	clear_external_trigger(eiop_rtc->regs, id);

	return 0;
}

/*****************************************************************************/
int eiop_rtc_get_ext_trigger_timestamp(struct eiop_rtc *eiop_rtc,
                                             uint8_t id,
                                             uint64_t *timestamp)
{
	ASSERT_COND(eiop_rtc);
	
	if (id >= eiop_rtc->num_ext_triggers) {
		pr_err("External Trigger ID\n");
		return -EINVAL;
	}
	
	*timestamp = get_trigger_stamp(eiop_rtc->regs, id)
	               * eiop_rtc->clock_period_nanosec;

	return 0;
}

/*****************************************************************************/
int eiop_rtc_get_ext_trigger_timestamp_status(struct eiop_rtc *eiop_rtc,
                                                    uint8_t id,
                                                    uint8_t *status)
{
	uint32_t timer_status;

	ASSERT_COND(eiop_rtc);

	if (id >= eiop_rtc->num_ext_triggers) {
		pr_err("External Trigger ID requested = %d\n", (id + 1));
		return -EINVAL;
	}

	timer_status = get_timer_status(eiop_rtc->regs);

	if((id == 0) && (timer_status & EIOP_RTC_TMR_STATUS_ETS1_VLD) ||
	   (id == 1) && (timer_status & EIOP_RTC_TMR_STATUS_ETS2_VLD))
		*status = 1;
	else
		*status = 0;

	return 0;
}

/*****************************************************************************/
int eiop_rtc_get_current_timestamp(struct eiop_rtc *eiop_rtc, uint64_t *timestamp)
{
	ASSERT_COND(eiop_rtc);

	*timestamp = get_timer(eiop_rtc->regs) * eiop_rtc->clock_period_nanosec;

	return 0;
}

/*****************************************************************************/
int eiop_rtc_set_current_timestamp(struct eiop_rtc *eiop_rtc, uint64_t timestamp)
{
	ASSERT_COND(eiop_rtc);

	/* Store timestamp */
	eiop_rtc->timestamp = timestamp;

	timestamp = timestamp / (uint64_t)eiop_rtc->clock_period_nanosec;
	set_timer(eiop_rtc->regs, timestamp);

	return 0;
}

/*****************************************************************************/
int eiop_rtc_get_freq_compensation(struct eiop_rtc *eiop_rtc, uint32_t *compensation)
{
	ASSERT_COND(eiop_rtc);

	*compensation = get_frequency_compensation(eiop_rtc->regs);

	return 0;
}

/*****************************************************************************/
int eiop_rtc_set_freq_compensation(struct eiop_rtc *eiop_rtc, uint32_t freq_compensation)
{
	ASSERT_COND(eiop_rtc);

	/* set the new freq_compensation */
	set_frequency_compensation(eiop_rtc->regs, freq_compensation);

	/* Store the value */
	eiop_rtc->freq_compensation = freq_compensation;

	return 0;
}

/*****************************************************************************/
uint32_t eiop_rtc_get_timestamp_period(struct eiop_rtc *eiop_rtc)
{
	ASSERT_COND(eiop_rtc);

	return eiop_rtc->clock_period_nanosec;
}

#if 0
/*****************************************************************************/
#if (defined(DEBUG_ERRORS) && (DEBUG_ERRORS > 0))
int eiop_rtc_dump_regs(struct eiop_rtc *eiop_rtc)
{
	struct eiop_rtc_regs *regs = eiop_rtc->regs;
	int i = 0;

	DECLARE_DUMP;

	if (regs) {

		DUMP_TITLE(regs, ("RTC:"));
		DUMP_VAR(regs, tmr_id);
		DUMP_VAR(regs, tmr_id2);
		DUMP_VAR(regs, tmr_ctrl);
		DUMP_VAR(regs, tmr_tevent);
		DUMP_VAR(regs, tmr_temask);
		DUMP_VAR(regs, tmr_cnt_h);
		DUMP_VAR(regs, tmr_cnt_l);
		DUMP_VAR(regs, tmr_ctrl);
		DUMP_VAR(regs, tmr_add);
		DUMP_VAR(regs, tmr_acc);
		DUMP_VAR(regs, tmr_prsc);
		DUMP_VAR(regs, tmr_off_h);
		DUMP_VAR(regs, tmr_off_l);

		DUMP_SUBSTRUCT_ARRAY(i, 2) {
			DUMP_VAR(regs, tmr_alarm[i].tmr_alarm_h);
			DUMP_VAR(regs, tmr_alarm[i].tmr_alarm_l);
		}
		DUMP_SUBSTRUCT_ARRAY(i, 2) {
			DUMP_VAR(regs, tmr_fiper[i]);
			DUMP_VAR(regs, tmr_fiper[i]);
		}
		DUMP_SUBSTRUCT_ARRAY(i, 2) {
			DUMP_VAR(regs, tmr_etts[i].tmr_etts_l);
			DUMP_VAR(regs, tmr_etts[i].tmr_etts_l);
		}
	}

	return 0;
}
#endif /* (defined(DEBUG_ERRORS) && ... */
#endif
