/*
 * Copyright 2013-2020 NXP
 */

#ifndef __EIOP_RTC_H
#define __EIOP_RTC_H

#include "fsl_types.h"
#include "fsl_eiop_rtc.h"

/**************************************************************************//**
 @Description   Definition of valid ranges
 *//***************************************************************************/

/**************************************************************************//**
 @Description   Definition of default values
 *//***************************************************************************/

/**************************************************************************//**
 @Description   Definition for registers
 *//***************************************************************************/

/**************************************************************************//**
 @Description   Definition shifts and masks for registers
 *//***************************************************************************/

/* General definitions */

#define ACCUMULATOR_OVERFLOW            ((uint64_t)(1LL << 32))
#define DEFAULT_OUTPUT_CLOCK_DIVISOR     0x00000002
#define DEFAULT_BYPASS                   FALSE
#define DEFAULT_CLOCK_PERIOD             1

struct eiop_rtc_alarm {
	uint32_t event_mask;
	int clear_on_expiration; /**< TRUE to turn off the alarm once expired. */
};

struct eiop_rtc_periodic {
	uint32_t event_mask;
};

struct eiop_rtc_ext_trigger {
	uint32_t event_mask;
};

/* FM RTC Registers definitions */
#define EIOP_RTC_TMR_CTRL_ALMP1                  0x80000000
#define EIOP_RTC_TMR_CTRL_ALMP2                  0x40000000
#define EIOP_RTC_TMR_CTRL_FS                     0x10000000
#define EIOP_RTC_TMR_CTRL_PP1L                   0x08000000
#define EIOP_RTC_TMR_CTRL_PP2L                   0x04000000
#define EIOP_RTC_TMR_CTRL_TCLK_PERIOD_MASK       0x03FF0000
#define EIOP_RTC_TMR_CTRL_FRD                    0x00004000
#define EIOP_RTC_TMR_CTRL_SLV                    0x00002000
#define EIOP_RTC_TMR_CTRL_ETEP1                  0x00000100
#define EIOP_RTC_TMR_CTRL_COPH                   0x00000080
#define EIOP_RTC_TMR_CTRL_CIPH                   0x00000040
#define EIOP_RTC_TMR_CTRL_TMSR                   0x00000020
#define EIOP_RTC_TMR_CTRL_DBG                    0x00000010
#define EIOP_RTC_TMR_CTRL_BYP                    0x00000008
#define EIOP_RTC_TMR_CTRL_TE                     0x00000004
#define EIOP_RTC_TMR_CTRL_CKSEL_OSC_CLK          0x00000003
#define EIOP_RTC_TMR_CTRL_CKSEL_MAC_CLK          0x00000001
#define EIOP_RTC_TMR_CTRL_CKSEL_EXT_CLK          0x00000000
#define EIOP_RTC_TMR_CTRL_TCLK_PERIOD_SHIFT      16

#define EIOP_RTC_TMR_TEVENT_ETS2                 0x02000000
#define EIOP_RTC_TMR_TEVENT_ETS1                 0x01000000
#define EIOP_RTC_TMR_TEVENT_ALM2                 0x00020000
#define EIOP_RTC_TMR_TEVENT_ALM1                 0x00010000
#define EIOP_RTC_TMR_TEVENT_PP1                  0x00000080
#define EIOP_RTC_TMR_TEVENT_PP2                  0x00000040
#define EIOP_RTC_TMR_TEVENT_PP3                  0x00000020
#define EIOP_RTC_TMR_TEVENT_ALL                  (EIOP_RTC_TMR_TEVENT_ETS2 |\
						EIOP_RTC_TMR_TEVENT_ETS1 |\
						EIOP_RTC_TMR_TEVENT_ALM2 |\
						EIOP_RTC_TMR_TEVENT_ALM1 |\
						EIOP_RTC_TMR_TEVENT_PP1 |\
						EIOP_RTC_TMR_TEVENT_PP2 |\
						EIOP_RTC_TMR_TEVENT_PP3)

#define EIOP_RTC_TMR_PRSC_OCK_MASK               0x0000FFFF
#define EIOP_RTC_TMR_STATUS_ETS2_VLD             0x02000000
#define EIOP_RTC_TMR_STATUS_ETS1_VLD             0x01000000

/* RTC default values */
#define DEFAULT_SRC_CLOCK                E_EIOP_RTC_SOURCE_CLOCK_SYSTEM
#define DEFAULT_INVERT_INPUT_CLK_PHASE   FALSE
#define DEFAULT_INVERT_OUTPUT_CLK_PHASE  FALSE
#define DEFAULT_ALARM_POLARITY           E_EIOP_RTC_ALARM_POLARITY_ACTIVE_HIGH
#define DEFAULT_TRIGGER_POLARITY         E_EIOP_RTC_TRIGGER_ON_FALLING_EDGE
#define DEFAULT_PULSE_REALIGN            FALSE

#define EIOP_RTC_MAX_NUM_OF_ALARMS 		3
#define EIOP_RTC_MAX_NUM_OF_PERIODIC_PULSES 	4
#define EIOP_RTC_MAX_NUM_OF_EXT_TRIGGERS 	4

/**************************************************************************//**
 @Description EIOP RTC timer alarm registers
 *//***************************************************************************/
struct tmr_alarm {
	uint32_t tmr_alarm_h; /**<  */
	uint32_t tmr_alarm_l; /**<  */
};

/**************************************************************************//**
 @Description EIOP RTC timer External trigger registers
 *//***************************************************************************/
struct tmr_ext_trigger {
	uint32_t tmr_etts_h; /**<  */
	uint32_t tmr_etts_l; /**<  */
};

struct eiop_rtc_regs {
	uint32_t tmr_id; /* 0x000 Module ID register */
	uint32_t tmr_id2; /* 0x004 Controller ID register */
	uint32_t reserved0008[30];
	uint32_t tmr_ctrl; /* 0x0080 timer control register */
	uint32_t tmr_tevent; /* 0x0084 timer event register */
	uint32_t tmr_temask; /* 0x0088 timer event mask register */
	uint32_t reserved008c[2];
	uint32_t tmr_stat; /* 0x0094 timer status register */
	uint32_t tmr_cnt_h; /* 0x0098 timer counter high register */
	uint32_t tmr_cnt_l; /* 0x009c timer counter low register */
	uint32_t tmr_add; /* 0x00a0 timer drift compensation addend register */
	uint32_t tmr_acc; /* 0x00a4 timer accumulator register */
	uint32_t tmr_prsc; /* 0x00a8 timer prescale */
	uint32_t reserved00ac;
	uint32_t tmr_off_h; /* 0x00b0 timer offset high */
	uint32_t tmr_off_l; /* 0x00b4 timer offset low  */
	struct tmr_alarm tmr_alarm[EIOP_RTC_MAX_NUM_OF_ALARMS]; /* 0x00b8 timer
	 alarm */
	uint32_t tmr_fiper[EIOP_RTC_MAX_NUM_OF_PERIODIC_PULSES]; /* 0x00d0 timer
	 fixed period interval */
	struct tmr_ext_trigger tmr_etts[EIOP_RTC_MAX_NUM_OF_EXT_TRIGGERS];
	/* 0x00e0 time stamp general purpose external */
	uint32_t reserved00f0[4];
};

struct rtc_init {
	uint32_t freq_compensation;
	uint32_t clk_period;
};

/**************************************************************************//**
 @Description RTC FM driver control structure.
 *//***************************************************************************/
struct eiop_rtc {
	struct eiop_rtc_regs *regs;
	enum eiop_src_clock src_clk; /*!< clock source (default is MAC system clock) */
	enum eiop_rtc_alarm_polarity alarm_polarity[EIOP_RTC_MAX_NUM_OF_ALARMS];
	/*!< Alarm output polarity polarity (default is EIOP_RTC_ALARM_POLARITY_ACTIVE_HIGH) */
	enum eiop_rtc_trigger_polarity trigger_polarity[EIOP_RTC_MAX_NUM_OF_EXT_TRIGGERS];
	/*!< External trigger edge polarity (default is EIOP_RTC_TRIGGER_ON_FALLING_EDGE) */
	uint32_t clock_period_nanosec; /**< RTC clock period in nano-seconds (for FS mode) */
	uint32_t src_clk_freq_mhz;
	uint16_t output_clock_divisor; /**< Output clock divisor (for FS mode) */
	int (*isr_cb)(void *arg, uint8_t irq_id, uint32_t event);
	void *isr_cb_arg;
	uint8_t isr_cb_irq_id;	
	uint8_t num_alarms;
	uint32_t alarm_event_mask[EIOP_RTC_MAX_NUM_OF_ALARMS];
	uint64_t alarm_time;  //only alarm 2 is used
	uint8_t num_periodics;
	uint32_t periodic_pulse_event_mask[EIOP_RTC_MAX_NUM_OF_PERIODIC_PULSES];
	uint8_t num_ext_triggers;
	uint32_t ext_trigger_event_mask[EIOP_RTC_MAX_NUM_OF_EXT_TRIGGERS];
	uint8_t fipper_loopback[EIOP_RTC_MAX_NUM_OF_EXT_TRIGGERS];  //use pulse as input
	uint32_t freq_compensation;
	uint32_t interrupt_mask;
	uint64_t timestamp;
	uint64_t timer_offset;
	struct rtc_init init;

};

/**
 * get_timer() - Get the timer counter
 * @regs:		Pointer to RTC register block
 *
 * Returns: The timer counter
 */
static inline uint64_t get_timer(struct eiop_rtc_regs *regs)
{
	uint64_t time;
	/* TMR_CNT_L must be read first to get an accurate value */
	time = (uint64_t)ioread32(&regs->tmr_cnt_l);
	time |= ((uint64_t)ioread32(&regs->tmr_cnt_h) << 32);

	return time;
}
/**
 * set_timer() - Set timer counter
 * @regs:		Pointer to RTC register block
 * @val:		The value to set
 */
static inline void set_timer(struct eiop_rtc_regs *regs, uint64_t val)
{
	iowrite32((uint32_t)val, &regs->tmr_cnt_l);
	iowrite32((uint32_t)(val >> 32), &regs->tmr_cnt_h);
}
#endif /* __EIOP_RTC_H */
