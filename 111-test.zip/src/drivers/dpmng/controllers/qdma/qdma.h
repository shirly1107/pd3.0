/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_qdma.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_QDMA

#define QDMA_DMR_DEQUEUE_DISABLE	0x40000000

struct dma_priv_regs {
	uint32_t dmr;
	uint32_t dsr_p;
	uint32_t reserved0[0x3];
	uint32_t dlamqr;
	uint32_t reserved1[0xA];
	uint32_t dlpfr;
	uint32_t reserved2[0x7];
	uint32_t deepr;
	uint32_t reserved3[0x3A7];
	uint32_t deuomr;
};

struct dma_priv_regs_v2 {
	uint32_t dmr;
	uint32_t dsr_p;
	uint32_t reserved0[0x3];
	uint32_t dlamqr;
	uint32_t reserved1[0x12];
	uint32_t deagar;
	uint32_t reserved2[0x3];
	uint32_t dwqbqcr0;
	uint32_t dwqbqcr1;
	uint32_t dpwqar;
	uint32_t reserved3[0x3A1];
	uint32_t deuomr;
};


struct dma_mng_regs {
	uint32_t reserved2;
	uint32_t dsr_m;
	uint32_t reserved3[0xE];
	uint32_t dgbtr;
	uint32_t ddpcr;
	uint32_t reserved4[0x2E];
	uint32_t dlmr;
	uint32_t dlsr;
	uint32_t reserved5[0x2];
	uint32_t dlsatr;
	uint32_t dlsar;
	uint32_t dldatr;
	uint32_t dldar;
	uint32_t dlbcr;
	uint32_t reserved6[0x9];
	uint32_t dlesad;
	uint32_t dledad;
	uint32_t reserved7[0x2AA];
	uint32_t ipbrr0;
	uint32_t ipbrr1;
	uint32_t reserved8[0x80];
	uint32_t deier;
	uint32_t dedr;
	uint32_t reserved9[0x2];
	uint32_t decfdw0r;
	uint32_t decfdw1r;
	uint32_t decfdw2r;
	uint32_t decfdw3r;
	uint32_t decfdw4r;
	uint32_t decfdw5r;
	uint32_t decfdw6r;
	uint32_t decfdw7r;
	uint32_t decfqidr;
	uint32_t decbr;
};

struct dma_regs_common {
	struct dma_priv_regs priv_regs;
	uint32_t reserved[0x3C3F];
	struct dma_mng_regs mng_regs;
};

struct dma_regs_v2 {
	struct dma_priv_regs_v2 priv_regs;
	uint32_t reserved[0x3C3F];
	struct dma_mng_regs mng_regs;
};

struct dma_regs {
	uint32_t version;
	union dma_regs_map {
		struct dma_regs_common common;
		struct dma_regs_v2 v2;
	};
};

enum qdma_regs_type {
	QDMA_REGS_TYPE_INVALID = 0,
	QDMA_REGS_TYPE_V1, /* qDMA memory mapping used on LS2088 and below */
	QDMA_REGS_TYPE_V2, /* qDMA memory mapping used on LX2 */
};

/* qDMA DSR_P */
#define QDMA_DSR_DMA_BUSY	0x80000000

/* qDMA DEDR */
#define QDMA_DEDR_MEIE      0x80000000
#define QDMA_DEDR_SBE       0x40000000
#define QDMA_DEDR_FDE       0x20000000
#define QDMA_DEDR_FSE       0x10000000
#define QDMA_DEDR_SDE       0x08000000
#define QDMA_DEDR_DDE       0x04000000


#define QDMA_EXCEPTIONS     (QDMA_DEDR_MEIE|QDMA_DEDR_SBE|QDMA_DEDR_FDE|QDMA_DEDR_FSE|QDMA_DEDR_SDE|QDMA_DEDR_DDE)
