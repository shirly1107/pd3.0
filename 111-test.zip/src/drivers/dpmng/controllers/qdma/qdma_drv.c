/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_soc.h"
#include "fsl_errors.h"
#include "fsl_qdma.h"
#include "fsl_platform.h"
#include "fsl_resman.h"

int qdma_drv_init(void);

int qdma_drv_init(void) {
	struct qdma_desc desc;
	int err, iter = 0;

	pr_info("Executing qdma_drv_init...\n");
	
	/******************************/
	/* Set up the QDMA CTRL block */
	/******************************/
	err = sys_get_desc(SOC_MODULE_QDMA, 0, &desc, &iter);
	pr_info("QDMA block version: v%d\n", desc.version);

	if (err)
		return err;
	
	pr_info("QDMA CCSR: 0x%08x%08x\n",UINT32_HI(desc.paddr), UINT32_LO(desc.paddr));

	return qdma_init(&desc);
}
