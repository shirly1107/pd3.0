/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_dbg.h"
#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_mpic.h"
#include "qdma.h"

static void fill_regs(void *regs_addr, enum qdma_regs_type type)
{
	union dma_regs_map *regs = regs_addr;
	uint32_t val;

	switch(type) {
		case QDMA_REGS_TYPE_V1:
		case QDMA_REGS_TYPE_V2:
			break;
		default:
			pr_err("QDMA error: invalid configuration\n");
			return;
	}

	/* Disable dequeuing of frame descriptor from QMan */
	iowrite32(QDMA_DMR_DEQUEUE_DISABLE, &(regs->common.priv_regs.dmr));

	/* Wait for qDMA idle state */
	do {
		val = ioread32(&(regs->common.priv_regs.dsr_p));
	} while (val & QDMA_DSR_DMA_BUSY);

	/* Set qDMA registers */
	switch(type)
	{
		case QDMA_REGS_TYPE_V1:
			iowrite32(0, &(regs->common.priv_regs.dlpfr));
			iowrite32(0xFFFF0000, &(regs->common.priv_regs.deepr));
			break;
		case QDMA_REGS_TYPE_V2:
			iowrite32(0x0000FFFF, &(regs->v2.priv_regs.deagar));
			break;
	}

	iowrite32(0, &(regs->common.priv_regs.deuomr));
	iowrite32(0x00080000, &(regs->common.mng_regs.dgbtr));
	iowrite32(0, &(regs->common.mng_regs.ddpcr));

	iowrite32(0, &(regs->common.mng_regs.dlmr));
	iowrite32(0, &(regs->common.mng_regs.dlsatr));
	iowrite32(0, &(regs->common.mng_regs.dlsar));
	iowrite32(0, &(regs->common.mng_regs.dldatr));
	iowrite32(0, &(regs->common.mng_regs.dldar));
	iowrite32(0, &(regs->common.mng_regs.dlbcr));
	iowrite32(0, &(regs->common.mng_regs.dlesad));
	iowrite32(0, &(regs->common.mng_regs.dledad));

	switch(type)
	{
		case QDMA_REGS_TYPE_V1:
			iowrite32(QDMA_EXCEPTIONS, &(regs->common.mng_regs.deier));
			iowrite32(QDMA_EXCEPTIONS, &(regs->common.mng_regs.dedr));
			break;
		case QDMA_REGS_TYPE_V2:
			/* DEIER[DDEIE] and DEDR[DDE] not available in v2 block */
			iowrite32(QDMA_EXCEPTIONS & ~QDMA_DEDR_DDE, &(regs->common.mng_regs.deier));
			iowrite32(QDMA_EXCEPTIONS & ~QDMA_DEDR_DDE, &(regs->common.mng_regs.dedr));
			break;
	}

	iowrite32(0, &(regs->common.mng_regs.decfdw0r));
	iowrite32(0, &(regs->common.mng_regs.decfdw1r));
	iowrite32(0, &(regs->common.mng_regs.decfdw2r));
	iowrite32(0, &(regs->common.mng_regs.decfdw3r));
	iowrite32(0, &(regs->common.mng_regs.decfdw4r));
	iowrite32(0, &(regs->common.mng_regs.decfdw5r));
	iowrite32(0, &(regs->common.mng_regs.decfdw6r));
	iowrite32(0, &(regs->common.mng_regs.decfdw7r));
	iowrite32(0, &(regs->common.mng_regs.decfqidr));
	iowrite32(0, &(regs->common.mng_regs.decbr));

	/* Enable dequeuing of frame descriptor from QMan */
	iowrite32((ioread32(&(regs->common.priv_regs.dmr)) & ~QDMA_DMR_DEQUEUE_DISABLE),
	          &(regs->common.priv_regs.dmr));
}

static void qdma_isr(uint32_t arg)
{
	struct qdma_desc *desc = (struct qdma_desc *)arg;
    union dma_regs_map *regs = (union dma_regs_map *)desc->vaddr;
    uint32_t dedr;

    pr_err("QDMA error event(s): \n");

    dedr = ioread32(&(regs->common.mng_regs.dedr));
    if (dedr & QDMA_DEDR_SBE)
        pr_err("System bus error\n");
    if (dedr & QDMA_DEDR_FDE)
        pr_err("Frame descriptor or frame format error\n");
    if (dedr & QDMA_DEDR_FSE)
        pr_err("Frame size error\n");
    if (dedr & QDMA_DEDR_SDE)
        pr_err("Source descriptor error\n");
    /* DEDR[DDE] is reserved/NA in qDMA v2 block */
    if (desc->version != QDMA_REGS_TYPE_V2)
    {
       if (dedr & QDMA_DEDR_DDE)
           pr_err("Destination descriptor error\n");
    }

    pr_err("FD associated with the error:\n 0x%08X 0x%08X\n 0x%08X 0x%08X\n"
           " 0x%08X 0x%08X\n 0x%08X 0x%08X\n 0x%08X\n",
           ioread32(&(regs->common.mng_regs.decfdw0r)),ioread32(&(regs->common.mng_regs.decfdw1r)),
           ioread32(&(regs->common.mng_regs.decfdw2r)),ioread32(&(regs->common.mng_regs.decfdw3r)),
           ioread32(&(regs->common.mng_regs.decfdw3r)),ioread32(&(regs->common.mng_regs.decfdw4r)),
           ioread32(&(regs->common.mng_regs.decfdw5r)),ioread32(&(regs->common.mng_regs.decfdw6r)),
           ioread32(&(regs->common.mng_regs.decfdw7r)));

    pr_err("Producer FQID of the FD above: 0x%x\n", ioread32(&(regs->common.mng_regs.decfqidr)));

    pr_err("0x%x bytes have been transferred prior to the error.\n", ioread32(&(regs->common.mng_regs.decbr)));

    /* Clearing the errors */
    iowrite32(dedr, &(regs->common.mng_regs.dedr));
}

int qdma_init(struct qdma_desc *desc)
{
    mpic_intr_params_t intr_params;
    int err;

	fill_regs(desc->vaddr, (enum qdma_regs_type) desc->version);

    intr_params.polarity = OS_MPIC_INTR_POLARITY_HIGH;
    intr_params.priority = 8;
    intr_params.sense = OS_MPIC_INTR_SENSE_LEVEL;
    intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;

    err = mpic_set_config_intr((uint32_t)desc->irq_err, 0, qdma_isr, (mpic_arg)(desc), &intr_params);
    if (err)
        return err;

    err = mpic_enable_intr((uint32_t)desc->irq_err);
    if (err)
        return err;

	return 0;
}

int qdma_set_exceptions(struct qdma_desc *desc, enum qdma_exceptions exception, int enable)
{
    union dma_regs_map *regs = (union dma_regs_map *)(desc->vaddr);
    uint32_t val = 0;

    val = ioread32(&(regs->common.mng_regs.deier));

    switch (exception) {
        case (E_QDMA_SYSTEM_BUS_ERR):
            if (enable)
                val |= QDMA_DEDR_SBE;
            else
                val &= ~QDMA_DEDR_SBE;
            break;

        case (E_QDMA_FRAME_DESC_ERR):
            if (enable)
                val |= QDMA_DEDR_FDE;
            else
                val &= ~QDMA_DEDR_FDE;
            break;

        case (E_QDMA_FRAME_SIZE_ERR):
            if (enable)
                val |= QDMA_DEDR_FSE;
            else
                val &= ~QDMA_DEDR_FSE;
            break;

        case (E_QDMA_SRC_DESC_ERR):
            if (enable)
                val |= QDMA_DEDR_SDE;
            else
                val &= ~QDMA_DEDR_SDE;
            break;

        case (E_QDMA_DST_DESC_ERR):
            if (desc->version != QDMA_REGS_TYPE_V2)
            {
               if (enable)
                   val |= QDMA_DEDR_DDE;
               else
                   val &= ~QDMA_DEDR_DDE;
            }
            break;
    }

    iowrite32(val, &(regs->common.mng_regs.deier));

    return 0;
}

