/*
 * Copyright 2014-2015 Freescale Semiconductor, Inc.
 */

#ifndef DCE_REGS_H
#define DCE_REGS_H

/* Memory Mapped Registers */

/** @Description struct for defining dce CCSR registes */
struct dce_ctrl {
	/* DCE Global Common Configuration */
	uint32_t cfg;		/* DCE configuration */
	uint8_t reserved1[0x014-0x004];
	uint32_t oll;		/* Output Length Limit */
	uint8_t reserved2[0x024-0x018];
	uint32_t hcl;		/* Hop Count Limit */
	uint8_t reserved3[0x03c-0x028];
	uint32_t idle;		/* DCE Idle status */
	uint8_t reserved4[0x104-0x040];
};

struct dce_memcfg {
	/* System Memory Configuration */
	uint32_t srcidr;	/* Source ID Register */
	uint32_t smcacr;	/* System Memory Cache Attribute Control */
	uint32_t smpcr;		/* System Memory Priority Control */
	uint32_t icir;		/* Internal Context Invalidate */
	uint8_t reserved1[0x200-0x114];
};

struct dce_stats {
	/* Statistics */
	uint32_t cibc_h;	/* Compressor Input Bytes count High */
	uint32_t cibc_l;	/* Compressor Input Bytes count Low */
	uint32_t cobc_h;	/* Compressor Output Bytes count High */
	uint32_t cobc_l;	/* Compressor Output Bytes count Low */
	uint32_t dibc_h;	/* Decompressor Input Bytes count High */
	uint32_t dibc_l;	/* Decompressor Input Bytes count Low */
	uint32_t dobc_h;	/* Decompressor Output Bytes count High */
	uint32_t dobc_l;	/* Decompressor Output Bytes count Low */
	uint8_t reserved1[0x3f8-0x220];
};

struct dce_block_id {
	uint32_t ip_rev_1;	/* DCE IP Block Revision 1 */
	uint32_t ip_rev_2;	/* DCE IP Block Revision 2 */
};

struct dce_interrupt {
	/* Interrupt */
	uint32_t isr;		/* Interrupt Status */
	uint32_t ier;		/* Interrupt Enable */
	uint32_t isdr;		/* Interrupt Status Disable */
	uint32_t iir;		/* Interrupt Inhibit */
	uint32_t ifr;		/* Interrupt Force */
	uint8_t reserved1[0x440-0x414];
};

struct dce_error_status {
	/* Error status */
	uint32_t ecc1bes;	/* ECC 1-Bit Error Status */
	uint32_t ecc2bes;	/* ECC 2-Bit Error Status */
	uint32_t eccaddr;	/* ECC Address */
	uint32_t ecc1th;	/* ECC 1-Bit Threshold */
	uint32_t dhecc1ec;	/*
				 * Decompression History memory ECC 1-Bit Error
				 * Count
				 */
	uint32_t cxecc1ec;	/*
				 * Internal Context memory ECC 1-Bit Error
				 * Count
				 */
	uint32_t cbecc1ec;	/* Internal Data memory ECC 1-Bit Error Count */
	uint8_t reserved1[0x480-0x45C];
	uint32_t uwe_info_h;	/* Unreported Write Error Information High */
	uint32_t uwe_info_l;	/* Unreported Write Error Information Low */
	uint32_t uwe_icid;	/* Unreported Write Error ICID */
	/* pad out to 4k */
	uint8_t reserved2[0x1000-0x48C];
};

struct dce_regs {
	struct dce_ctrl ctrl;
	struct dce_memcfg memcfg;
	struct dce_stats stats;
	struct dce_block_id id;
	struct dce_interrupt interrupt;
	struct dce_error_status error_status;
};

/* masks and shifts */

/* DCE Configuration definitions */

/* Read Safe Behavior */
#define DCE_CFG_RSD_SHIFT	20
#define DCE_CFG_RSD_WIDTH	1

/* Dynamic Power Management Disable */
#define DCE_CFG_DPMD_SHIFT	17
#define DCE_CFG_DPMD_WIDTH	1

/* Enable Level */
#define DCE_CFG_EN_SHIFT	0
#define DCE_CFG_EN_WIDTH	2	

/* Output Length Limit */
#define DCE_OLL_SHIFT		0
#define DCE_OLL_WIDTH		16

/* Hop Count Limit */
#define DCE_HCL_SHIFT		0
#define DCE_HCL_WIDTH		10

/* Idle status */
#define DCE_IDLE_STOPPED_SHIFT	8
#define DCE_IDLE_STOPPED_WIDTH	1

/* Idle */
#define DCE_IDLE_IDLE_SHIFT	0
#define DCE_IDLE_IDLE_WIDTH	1

/* DCE System memory configuration */

/* Source ID */
#define DCE_SCRID_SHIFT			0
#define DCE_SRCID_WIDTH			8

/* System Memory Cache Attribute Control */
#define DCE_SMCACR_CHWC_SHIFT		28
#define DCE_SMCACR_CHWC_WIDTH		2

#define DCE_SMCACR_SCWC_SHIFT		24
#define DCE_SMCACR_SCWC_WIDTH		2

#define DCE_SMCACR_FDWC_SHIFT		20
#define DCE_SMCACR_FDWC_WIDTH		2

#define DCE_SMCACR_DHWC_SHIFT		16
#define DCE_SMCACR_DHWC_WIDTH		2

#define DCE_SMCACR_CHRC_SHIFT		12
#define DCE_SMCACR_CHRC_WIDTH		2

#define DCE_SMCACR_SCRC_SHIFT		8
#define DCE_SMCACR_SCRC_WIDTH		2

#define DCE_SMCACR_FDRC_SHIFT		4
#define DCE_SMCACR_FDRC_WIDTH		2

#define DCE_SMCACR_DHRC_SHIFT		0
#define DCE_SMCACR_DHRC_WIDTH		2

/* System Memory Priority Control */
/* Write Priority */
#define DCE_SMPCR_WP_SHIFT		4
#define DCE_SMPCR_WP_WIDTH		1
/* Read Priority */
#define DCE_SMPCR_RP_SHIFT		0
#define DCE_SMPCR_RP_WIDTH		1

/* Internal Context Invalid */
/* Invalidate Internal Context */
#define DCE_ICIR_ICI_SHIFT		0
#define DCE_ICIR_ICI_WIDTH		1

/* Block ID */
/* Revision 1 */
#define DCE_IP_REV_1_IP_ID_SHIFT	16
#define DCE_IP_REV_1_IP_ID_MASK		(0xffffUL << DCE_IP_REV_1_IP_ID_SHIFT)
/* IP_ID Tokens */
#define DCE_IP_REV_1_IP_ID_DCE		0xaf0UL
/* Major */
#define DCE_IP_REV_1_IP_MJ_SHIFT	8
#define DCE_IP_REV_1_IP_MJ_MASK		(0xffUL << DCE_IP_REV_1_IP_MJ_SHIFT)
/* Minor */
#define DCE_IP_REV_1_IP_MN_SHIFT	0
#define DCE_IP_REV_1_IP_MN_MASK		(0xffUL << DCE_IP_REV_1_IP_MN_SHIFT)
/* Revision 2 */
/* Integration Option */
#define DCE_IP_REV_2_IP_INT_SHIFT	16
#define DCE_IP_REV_2_IP_INT_MASK	(0xffUL << DCE_IP_REV_2_IP_INT_SHIFT)
/* Errata Revision Level */
#define DCE_IP_REV_2_IP_ERR_SHIFT	8
#define DCE_IP_REV_2_IP_ERR_MASK	(0xffUL << DCE_IP_REV_2_IP_ERR_SHIFT)
/* Configuration Option */
#define DCE_IP_REV_2_IP_CFG_SHIFT	0
#define DCE_IP_REV_2_IP_CFG_MASK	(0xffUL << DCE_IP_REV_2_IP_CFG_SHIFT)

/* Interrupt */

/* Interrupt Status */
/* Unreported Write Error */
#define DCE_ISR_UWE_SHIFT		7
#define DCE_ISR_UWE_MASK		(0x1UL << DCE_ISR_UWE_SHIFT)
/* ISR UWE Tokens */
#define DCE_ISR_UWE_NONE		0x0UL
#define DCE_ISR_UWE_AT_LEAST_ONE	0x1UL

/* Single Bit Error */
#define DCE_ISR_SBE_SHIFT		1
#define DCE_ISR_SBE_MASK		(0x1UL << DCE_ISR_SBE_SHIFT)

/* ISR SBE Tokens */
#define DCE_ISR_SBE_NONE		0x0UL
#define DCE_ISR_SBE_AT_LEAST_ONE	0x1UL

/* Double Bit Error */
#define DCE_ISR_DBE_SHIFT		0
#define DCE_ISR_DBE_MASK		(0x1UL << DCE_ISR_DBE_SHIFT)
/* ISR DBE Tokens */
#define DCE_ISR_DBE_NONE		0x0UL
#define DCE_ISR_DBE_AT_LEAST_ONE	0x1UL

/* Interrupt Enable */
/* Unreported Write Error */
#define DCE_IER_UWE_SHIFT		7
#define DCE_IER_UWE_MASK		(0x1UL << DCE_IER_UWE_SHIFT)

/* IER UWE Tokens */
#define DCE_IER_UWE_DISABLE		0x0UL
#define DCE_IER_UWE_ENABLE		0x1UL

/* Single Bit Error */
#define DCE_IER_SBE_SHIFT		1
#define DCE_IER_SBE_MASK		(0x1UL << DCE_IER_SBE_SHIFT)
/* IER SBE Tokens */
#define DCE_IER_SBE_DISABLE		0x0
#define DCE_IER_SBE_ENABLE		0x1

/* Double Bit Error */
#define DCE_IER_DBE_SHIFT		0
#define DCE_IER_DBE_MASK		(0x1UL << DCE_IER_DBE_SHIFT)
/* IER DBE Tokens */
#define DCE_IER_DBE_DISABLE		0x0
#define DCE_IER_DBE_ENABLE		0x1

/* All interrupts */
#define DCE_IER_ALL_MASK \
	(DCE_IER_UWE_MASK | DCE_IER_SBE_MASK | DCE_IER_DBE_MASK)
#define DCE_IER_ALL_SHIFT		0
/* IER ALL Tokens */
#define DCE_IER_ALL_DISABLE		0x0UL
#define DCE_IER_ALL_ENABLE		0x83UL

/* Interrupt Status Disable */
/* Unreported Write Error */
#define DCE_ISDR_UWE_SHIFT		7
#define DCE_ISDR_UWE_MASK		(0x1UL << DCE_ISDR_UWE_SHIFT)

/* IER UWE Tokens */
#define DCE_ISDR_UWE_DISABLE		0x0UL
#define DCE_ISDR_UWE_ENABLE		0x1UL

/* Single Bit Error */
#define DCE_ISDR_SBE_SHIFT		1
#define DCE_ISDR_SBE_MASK		(0x1UL << DCE_ISDR_SBE_SHIFT)
/* IER SBE Tokens */
#define DCE_ISDR_SBE_DISABLE		0x0UL
#define DCE_ISDR_SBE_ENABLE		0x1UL

/* Double Bit Error */
#define DCE_ISDR_DBE_SHIFT		0
#define DCE_ISDR_DBE_MASK		(0x1UL << DCE_ISDR_DBE_SHIFT)
/* IER DBE Tokens */
#define DCE_ISDR_DBE_DISABLE		0x0UL
#define DCE_ISDR_DBE_ENABLE		0x1UL

/* Interrupt Inhibit */
/* Inhibit */
#define DCE_IIR_I_SHIFT			0
#define DCE_IIR_I_MASK			(0x1UL << DCE_IIR_I_SHIFT)

/* IIR I Tokens */
#define DCE_IIR_I_CLEAR			0x0UL
#define DCE_IIR_I_SET			0x1UL

/* Interrupt Force */
/* Unreported Write Error */
#define DCE_IFR_UWE_SHIFT		7
#define DCE_IFR_UWE_MASK		(0x1UL << DCE_IFR_UWE_SHIFT)
/* IFR UWE Tokens */
#define DCE_IFR_UWE_SET			0x1UL

/* Single Bit Error */
#define DCE_IFR_SBE_SHIFT		1
#define DCE_IFR_SBE_MASK		(0x1UL << DCE_IFR_SBE_SHIFT)
/* IFR SBE Tokens */
#define DCE_IFR_SBE_SET			0x1UL

/* Double Bit Error */
#define DCE_IFR_DBE_SHIFT		0
#define DCE_IFR_DBE_MASK		(0x1UL << DCE_IFR_DBE_SHIFT)
/* IFR DBE Tokens */
#define DCE_IFR_DBE_SET			0x1

/* Error Status */

/* ECC 1-Bit Error Status */
/* Compression History Memory */
#define DCE_ECC1BES_CBM_SHIFT		2
#define DCE_ECC1BES_CBM_MASK		(0x1UL << DCE_ECC1BES_CBM_MASK)

/* CBM Tokens */
#define DCE_ECC1BES_CBM_FALSE		0x0UL
#define DCE_ECC1BES_CBM_TRUE		0x1UL
#define DCE_ECC1BES_CBM_CLEAR		0x1UL

/* Decompression History Memory */
#define DCE_ECC1BES_DHM_SHIFT		1
#define DCE_ECC1BES_DHM_MASK		(0x1UL << DCE_ECC1BES_DHM_SHIFT)
/* DHM Tokens */
#define DCE_ECC1BES_DHM_FALSE		0x0UL
#define DCE_ECC1BES_DHM_TRUE		0x1UL
#define DCE_ECC1BES_DHM_CLEAR		0x1UL

/* Internal Context Memory */
#define DCE_ECC1BES_CXM_SHIFT		0
#define DCE_ECC1BES_CXM_MASK		(0x1UL << DCE_ECC1BES_CXM_SHIFT)
/* CXM Tokens */
#define DCE_ECC1BES_CXM_FALSE		0x0UL
#define DCE_ECC1BES_CXM_TRUE		0x1UL
#define DCE_ECC1BES_CXM_CLEAR		0x1UL

/* ECC 2-Bit Error Status */
/* Compression History Memory */
#define DCE_ECC2BES_CBM_SHIFT		2
#define DCE_ECC2BES_CBM_MASK		(0x1UL << DCE_ECC2BES_CBM_SHIFT)
/* CBM Tokens */
#define DCE_ECC2BES_CBM_FALSE		0x0UL
#define DCE_ECC2BES_CBM_TRUE		0x1UL
#define DCE_ECC2BES_CBM_CLEAR		0x1UL

/* Decompression History Memory */
#define DCE_ECC2BES_DHM_SHIFT		1
#define DCE_ECC2BES_DHM_MASK		(0x1UL << DCE_ECC2BES_DHM_SHIFT)
/* DHM Tokens */
#define DCE_ECC2BES_DHM_FALSE		0x0UL
#define DCE_ECC2BES_DHM_TRUE		0x1UL
#define DCE_ECC2BES_DHM_CLEAR		0x1UL

/* Internal Context Memory */
#define DCE_ECC2BES_CXM_SHIFT		0
#define DCE_ECC2BES_CXM_MASK		(0x1UL << DCE_ECC2BES_CXM_SHIFT)
/* CXM Tokens */
#define DCE_ECC2BES_CXM_FALSE		0x0UL
#define DCE_ECC2BES_CXM_TRUE		0x1UL
#define DCE_ECC2BES_CXM_CLEAR		0x1UL

/* ECC Address */
/* Capture Error Indication */
#define DCE_ECCADDR_CAP_SHIFT		31
#define DCE_ECCADDR_CAP_MASK		(0x1UL << DCE_ECCADDR_CAP_SHIFT)
/* CAP Tokens */
#define DCE_ECCADDR_CAP_NONE		0x0UL
#define DCE_ECCADDR_CAP_CAPTURED	0x1UL
#define DCE_ECCADDR_CAP_CLEAR		0x1UL

/* Capture Error Type */
#define DCE_ECCADDR_CAT_SHIFT		30
#define DCE_ECCADDR_CAT_MASK		(0x1UL << DCE_ECCADDR_CAT_SHIFT)
/* CAT Tokens */
#define DCE_ECCADDR_CAT_SB_ECC		0x0UL
#define DCE_ECCADDR_CAT_MB_ECC		0x1UL

/* Memory Identifier */
#define DCE_ECCADDR_MEM_SHIFT		16
#define DCE_ECCADDR_MEM_MASK		(0x1fUL << DCE_ECCADDR_MEM_SHIFT)
/* MEM Tokens */
#define DCE_ECCADDR_MEM_DHM0		0x0UL
#define DCE_ECCADDR_MEM_DHM1		0x1UL
#define DCE_ECCADDR_MEM_DHM2		0x2UL
#define DCE_ECCADDR_MEM_DHM3		0x3UL
#define DCE_ECCADDR_MEM_DHM4		0x4UL
#define DCE_ECCADDR_MEM_DHM5		0x5UL
#define DCE_ECCADDR_MEM_DHM6		0x6UL
#define DCE_ECCADDR_MEM_DHM7		0x7UL
#define DCE_ECCADDR_MEM_CBM0		0x8UL
#define DCE_ECCADDR_MEM_CBM1		0x9UL
#define DCE_ECCADDR_MEM_CBM2		0xaUL
#define DCE_ECCADDR_MEM_CBM3		0xbUL
#define DCE_ECCADDR_MEM_CBM4		0xcUL
#define DCE_ECCADDR_MEM_CBM5		0xdUL
#define DCE_ECCADDR_MEM_CBM6		0xeUL
#define DCE_ECCADDR_MEM_CBM7		0xfUL
#define DCE_ECCADDR_MEM_CXMA0		0x10UL
#define DCE_ECCADDR_MEM_CXMB0		0x11UL
#define DCE_ECCADDR_MEM_CXMA1		0x12UL
#define DCE_ECCADDR_MEM_CXMB1		0x13UL
#define DCE_ECCADDR_MEM_CXMA2		0x14UL
#define DCE_ECCADDR_MEM_CXMB2		0x15UL
#define DCE_ECCADDR_MEM_CXMA3		0x16UL
#define DCE_ECCADDR_MEM_CXMB3		0x17UL
#define DCE_ECCADDR_MEM_CXMA4		0x18UL
#define DCE_ECCADDR_MEM_CXMB4		0x19UL
#define DCE_ECCADDR_MEM_CXMA5		0x1aUL
#define DCE_ECCADDR_MEM_CXMB5		0x1bUL
#define DCE_ECCADDR_MEM_CXMA6		0x1cUL
#define DCE_ECCADDR_MEM_CXMB6		0x1dUL
#define DCE_ECCADDR_MEM_CXMA7		0x1eUL
#define DCE_ECCADDR_MEM_CXMB7		0x1fUL

/* Capture the address within the memory upon which the error occurred */
#define DCE_ECCADDR_ADDR_SHIFT		0
#define DCE_ECCADDR_ADDR_MASK		(0xffffUL << DCE_ECCADDR_ADDR_SHIFT)

/* ECC 1-Bit Threshold */
/* Internal Data Memory */
#define DCE_ECC1TH_DECBM_SHIFT		10
#define DCE_ECC1TH_DECBM_MASK		(0x1UL << DCE_ECC1TH_DECBM_SHIFT)
/* DECBM Tokens */
#define DCE_ECC1TH_DECBM_DISABLE	0x1UL
#define DCE_ECC1TH_DECBM_ENABLE		0x0UL

/* Decompression History Memory */
#define DCE_ECC1TH_DEDHM_SHIFT		9
#define DCE_ECC1TH_DEDHM_MASK		(0x1UL << DCE_ECC1TH_DEDHM_SHIFT)
/* DEDHM Tokens */
#define DCE_ECC1TH_DEDHM_DISABLE	0x1UL
#define DCE_ECC1TH_DEDHM_ENABLE		0x0UL

/* Internal Context Memory */
#define DCE_ECC1TH_DECXM_SHIFT		8
#define DCE_ECC1TH_DECXM_MASK		(0x1UL << DCE_ECC1TH_DECXM_SHIFT)
/* DECXM Tokens */
#define DCE_ECC1TH_DECXM_DISABLE	0x1UL
#define DCE_ECC1TH_DECXM_ENABLE		0x0UL

/* Threshold value */
#define DCE_ECC1TH_THRESH_SHIFT		0
#define DCE_ECC1TH_THRESH_MASK		(0xffUL << DCE_ECC1TH_THRESH_SHIFT)

/* Decompression History memory ECC 1-Bit Count */
/* Count */
#define DCE_ECC1EC_COUNT_SHIFT		0
#define DCE_ECC1EC_COUNT_MASK		(0xffUL << DCE_ECC1EC_COUNT_SHIFT)

/* Internal Context ECC 1-Bit Error Count */
/* Count */
#define DCE_CXECC1EC_COUNT_SHIFT	0
#define DCE_CXECC1EC_COUNT_MASK		(0xffUL << DCE_CXECC1EC_COUNT_SHIFT)

/* Internal Data ECC 1-Bit Error Count */
/* Count */
#define DCE_CBECC1EC_COUNT_SHIFT	0
#define DCE_CBECC1EC_COUNT_MASK		(0xffUL << DCE_CBECC1EC_COUNT_SHIFT)

/* Unreported Write Error Information High */
/* LIODN */
#define DCE_UWE_INFO_H_LIODN_SHIFT	16
#define DCE_UWE_INFO_H_LIODN_MASK	(0xfffUL << DCE_UWE_INFO_H_LIODN_SHIFT)
/* SCRP */
#define DCE_UWE_INFO_H_SCRP_SHIFT	0
#define DCE_UWE_INFO_H_SCRP_MASK (0xffUL << DCE_UWE_INFO_H_SCRP_SHIFT)

/* Unreported Write Error Information Low */
#define DCE_UWE_INFO_L_SCRP_SHIFT	6
#define DCE_UWE_INFO_L_SCRP_MASK (0x3ffffffUL << DCE_UWE_INFO_L_SCRP_SHIFT)

#endif /* DCE_REGS_H */
