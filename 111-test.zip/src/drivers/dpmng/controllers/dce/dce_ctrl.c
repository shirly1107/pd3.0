/*
 * Copyright 2013-2020 NXP
 */

#include "dce_private.h"
#include "dce_regs.h"
#include "drivers/fsl_dce_ctrl.h"


/* Constants */

/* Bits to represent only-set-them-once registers */

struct dce_block {
	const struct dce_block_desc *desc;
	struct dce_regs *ccsr;
};

uint64_t dce_version;

struct dce_block *dce_block_init(const struct dce_block_desc *d)
{
	/* SMRCACR - System Memory Read Cache Attribute Control Register */
	const unsigned int smrcacr_address = 0x00000108;
	/* SMWCACR - System Memory Write Cache Attribute Control Register */
	const unsigned int smwcacr_address = 0x0000010C;
	struct dce_block *b = kmalloc(sizeof(*b), GFP_KERNEL);
	uint8_t *ccsr_ptr = (uint8_t *)d->ccsr_reg_bar;
	uint32_t reg;

	if (!b)
		return NULL;
	b->desc = d;
	b->ccsr = d->ccsr_reg_bar;
	pr_info("dce_block_init, CCSR=0x%p, block=0x%p\n", b->ccsr, b);
	/* Apply same defaults */

	/* Check for DCE snoop bit inversion errata */
	dce_block_get_dce_version(b);
	if (dce_version == ERR010843_DCE_REV) {
		/* The no_snoop bit is inverted in this rev of DCE logic. The
		 * desired behavior is snoop but no_allocate. The actual
		 * behavior is no_snoop no_allocate. This workaround nullifies
		 * the issue by inverting the no_snoop bit */
		pr_info("DCE errata requires setting SMW/RCACR\n");
		/* snoop but do not allocate setting in SMRCACR */
		reg = 0x1b1b1b1b;
		dce_ccsr_write(ccsr_ptr + smrcacr_address, reg);
		/* snoop but do not allocate setting in SMWCACR */
		reg = 0x17171717;
		dce_ccsr_write(ccsr_ptr + smwcacr_address, reg);
	}

	/* Check for DCE decompressor deadlock errata pdm TKT328627  */
	if (dce_version <= ERR010843_DCE_REV) {
		pr_info("DCE errata requires disabling dynamic power management\n");
		dce_block_set_dynamic_power_management_disable(b, 1);
	}

	return b;
}

void dce_block_finish(struct dce_block *b)
{
	pr_info("dce_block_finish, block=0x%p\n", b);
	kfree(b);
}

const struct dce_block_desc *dce_block_get_desc(struct dce_block *b)
{
	return b->desc;
}

	/*******************/
	/* dce_block API */
	/*******************/

void dce_block_get_read_safe_disable(struct dce_block *b, int *is_disable)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl);
	*is_disable = d32_int(DCE_CFG_RSD_SHIFT, DCE_CFG_RSD_WIDTH, reg);
}
void dce_block_set_read_safe_disable(struct dce_block *b, int disable)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl);
	reg = r32_int(DCE_CFG_RSD_SHIFT, DCE_CFG_RSD_WIDTH, reg) |
		e32_int(DCE_CFG_RSD_SHIFT, DCE_CFG_RSD_WIDTH, !!disable);
	dce_ccsr_write(&b->ccsr->ctrl, reg);
}

void dce_block_get_dynamic_power_management_disable(struct dce_block *b,
								int *is_disable)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl);
	*is_disable = d32_int(DCE_CFG_DPMD_SHIFT, DCE_CFG_DPMD_WIDTH, reg);
}
void dce_block_set_dynamic_power_management_disable(struct dce_block *b,
								int disable)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl);
	reg = r32_int(DCE_CFG_DPMD_SHIFT, DCE_CFG_DPMD_WIDTH, reg) |
		e32_int(DCE_CFG_DPMD_SHIFT, DCE_CFG_DPMD_WIDTH, !!disable);
	dce_ccsr_write(&b->ccsr->ctrl, reg);
}

void dce_block_get_enable_level(struct dce_block *b,
				enum dce_enable_level *level)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl.cfg);
	*level = (enum dce_enable_level)d32_uint32_t(DCE_CFG_EN_SHIFT,
						DCE_CFG_EN_WIDTH, reg);
}

void dce_block_set_enable_level(struct dce_block *b,
				enum dce_enable_level level)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl.cfg);
	reg = r32_int(DCE_CFG_EN_SHIFT, DCE_CFG_EN_WIDTH, reg) |
		e32_int(DCE_CFG_EN_SHIFT, DCE_CFG_EN_WIDTH, level);
	dce_ccsr_write(&b->ccsr->ctrl.cfg, reg);
}

void dce_block_get_output_length_limit(struct dce_block *b, uint16_t *limit)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl.oll);
	*limit = d32_uint16_t(DCE_OLL_SHIFT, DCE_OLL_WIDTH, reg);
}

void dce_block_set_output_length_limit(struct dce_block *b, uint16_t limit)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl.oll);
	reg = r32_int(DCE_OLL_SHIFT, DCE_OLL_WIDTH, reg) |
		e32_int(DCE_OLL_SHIFT, DCE_OLL_WIDTH, limit);
	dce_ccsr_write(&b->ccsr->ctrl.oll, reg);
}

void dce_block_get_hop_count_limit(struct dce_block *b, uint16_t *limit)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl.hcl);
	*limit = d32_uint16_t(DCE_HCL_SHIFT, DCE_HCL_WIDTH, reg);
}

void dce_block_set_hop_count_limit(struct dce_block *b, uint16_t limit)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl.hcl);
	reg = r32_int(DCE_HCL_SHIFT, DCE_HCL_WIDTH, reg) |
		e32_int(DCE_HCL_SHIFT, DCE_HCL_WIDTH, limit);
	dce_ccsr_write(&b->ccsr->ctrl.hcl, reg);
}

void dce_block_get_stop_state(struct dce_block *b, int *is_stopped)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl.idle);
	*is_stopped = d32_int(DCE_IDLE_STOPPED_SHIFT,
				DCE_IDLE_STOPPED_WIDTH,
				reg);
}

void dce_block_get_idle_state(struct dce_block *b, int *is_idle)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->ctrl.idle);
	*is_idle = d32_int(DCE_IDLE_IDLE_SHIFT,
				DCE_IDLE_IDLE_WIDTH,
				reg);
}

void dce_block_get_chwc(struct dce_block *b, enum dce_write_cache_type *cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	*cache = (enum dce_write_cache_type)d32_uint32_t(DCE_SMCACR_CHWC_SHIFT,
						DCE_SMCACR_CHWC_WIDTH, reg);
}
void dce_block_set_chwc(struct dce_block *b, enum dce_write_cache_type cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	reg = r32_int(DCE_SMCACR_CHWC_SHIFT, DCE_SMCACR_CHWC_WIDTH, reg) |
		e32_int(DCE_SMCACR_CHWC_SHIFT, DCE_SMCACR_CHWC_WIDTH, cache);
	dce_ccsr_write(&b->ccsr->memcfg.smcacr, reg);
}

void dce_block_get_scwc(struct dce_block *b, enum dce_write_cache_type *cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	*cache = (enum dce_write_cache_type)d32_uint32_t(DCE_SMCACR_SCWC_SHIFT,
						DCE_SMCACR_SCWC_WIDTH, reg);
}
void dce_block_set_scwc(struct dce_block *b, enum dce_write_cache_type cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	reg = r32_int(DCE_SMCACR_SCWC_SHIFT, DCE_SMCACR_SCWC_WIDTH, reg) |
		e32_int(DCE_SMCACR_SCWC_SHIFT, DCE_SMCACR_SCWC_WIDTH, cache);
	dce_ccsr_write(&b->ccsr->memcfg.smcacr, reg);
}

void dce_block_get_fdwc(struct dce_block *b, enum dce_write_cache_type *cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	*cache = (enum dce_write_cache_type)d32_uint32_t(DCE_SMCACR_FDWC_SHIFT,
						DCE_SMCACR_FDWC_WIDTH, reg);
}
void dce_block_set_fdwc(struct dce_block *b, enum dce_write_cache_type cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	reg = r32_int(DCE_SMCACR_FDWC_SHIFT, DCE_SMCACR_FDWC_WIDTH, reg) |
		e32_int(DCE_SMCACR_FDWC_SHIFT, DCE_SMCACR_FDWC_WIDTH, cache);
	dce_ccsr_write(&b->ccsr->memcfg.smcacr, reg);
}

void dce_block_get_dhwc(struct dce_block *b, enum dce_write_cache_type *cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	*cache = (enum dce_write_cache_type)d32_uint32_t(DCE_SMCACR_DHWC_SHIFT,
						DCE_SMCACR_DHWC_WIDTH, reg);
}
void dce_block_set_dhwc(struct dce_block *b, enum dce_write_cache_type cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	reg = r32_int(DCE_SMCACR_DHWC_SHIFT, DCE_SMCACR_DHWC_WIDTH, reg) |
		e32_int(DCE_SMCACR_DHWC_SHIFT, DCE_SMCACR_DHWC_WIDTH, cache);
	dce_ccsr_write(&b->ccsr->memcfg.smcacr, reg);
}

void dce_block_get_chrc(struct dce_block *b, enum dce_read_cache_type *cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	*cache = (enum dce_read_cache_type)d32_uint32_t(DCE_SMCACR_CHRC_SHIFT,
						DCE_SMCACR_CHRC_WIDTH, reg);
}
void dce_block_set_chrc(struct dce_block *b, enum dce_read_cache_type cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	reg = r32_int(DCE_SMCACR_CHRC_SHIFT, DCE_SMCACR_CHRC_WIDTH, reg) |
		e32_int(DCE_SMCACR_CHRC_SHIFT, DCE_SMCACR_CHRC_WIDTH, cache);
	dce_ccsr_write(&b->ccsr->memcfg.smcacr, reg);
}

void dce_block_get_scrc(struct dce_block *b, enum dce_read_cache_type *cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	*cache = (enum dce_read_cache_type)d32_uint32_t(DCE_SMCACR_SCRC_SHIFT,
						DCE_SMCACR_SCRC_WIDTH, reg);
}
void dce_block_set_scrc(struct dce_block *b, enum dce_read_cache_type cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	reg = r32_int(DCE_SMCACR_SCRC_SHIFT, DCE_SMCACR_SCRC_WIDTH, reg) |
		e32_int(DCE_SMCACR_SCRC_SHIFT, DCE_SMCACR_SCRC_WIDTH, cache);
	dce_ccsr_write(&b->ccsr->memcfg.smcacr, reg);
}

void dce_block_get_fdrc(struct dce_block *b, enum dce_read_cache_type *cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	*cache = (enum dce_read_cache_type)d32_uint32_t(DCE_SMCACR_FDRC_SHIFT,
						DCE_SMCACR_FDRC_WIDTH, reg);
}
void dce_block_set_fdrc(struct dce_block *b, enum dce_read_cache_type cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	reg = r32_int(DCE_SMCACR_FDRC_SHIFT, DCE_SMCACR_FDRC_WIDTH, reg) |
		e32_int(DCE_SMCACR_FDRC_SHIFT, DCE_SMCACR_FDRC_WIDTH, cache);
	dce_ccsr_write(&b->ccsr->memcfg.smcacr, reg);
}

void dce_block_get_dhrc(struct dce_block *b, enum dce_read_cache_type *cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	*cache = (enum dce_read_cache_type)d32_uint32_t(DCE_SMCACR_DHRC_SHIFT,
						DCE_SMCACR_DHRC_WIDTH, reg);
}
void dce_block_set_dhrc(struct dce_block *b, enum dce_read_cache_type cache)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smcacr);
	reg = r32_int(DCE_SMCACR_DHRC_SHIFT, DCE_SMCACR_DHRC_WIDTH, reg) |
		e32_int(DCE_SMCACR_DHRC_SHIFT, DCE_SMCACR_DHRC_WIDTH, cache);
	dce_ccsr_write(&b->ccsr->memcfg.smcacr, reg);
}

void dce_block_get_sysmemwpri(struct dce_block *b,
			enum dce_sys_mem_priority_level *level)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smpcr);
	*level = (enum dce_sys_mem_priority_level)						d32_uint32_t(DCE_SMPCR_WP_SHIFT, DCE_SMPCR_WP_WIDTH, reg);
}

void dce_block_set_sysmemwpri(struct dce_block *b,
			enum dce_sys_mem_priority_level level)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smpcr);
	reg = r32_int(DCE_SMPCR_WP_SHIFT, DCE_SMPCR_WP_WIDTH, reg) |
		e32_int(DCE_SMPCR_WP_SHIFT, DCE_SMPCR_WP_WIDTH, level);
	dce_ccsr_write(&b->ccsr->memcfg.smpcr, reg);
}

void dce_block_get_sysmemrpri(struct dce_block *b,
			enum dce_sys_mem_priority_level *level)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smpcr);
	*level = (enum dce_sys_mem_priority_level)						d32_uint32_t(DCE_SMPCR_RP_SHIFT, DCE_SMPCR_RP_WIDTH, reg);
}
void dce_block_set_sysmemrpri(struct dce_block *b,
				enum dce_sys_mem_priority_level level)
{
	uint32_t reg = dce_ccsr_read(&b->ccsr->memcfg.smpcr);
	reg = r32_int(DCE_SMPCR_RP_SHIFT, DCE_SMPCR_RP_WIDTH, reg) |
		e32_int(DCE_SMPCR_RP_SHIFT, DCE_SMPCR_RP_WIDTH, level);
	dce_ccsr_write(&b->ccsr->memcfg.smpcr, reg);
}

void dce_block_invalidate_internal_context(struct dce_block *b)
{
	uint32_t reg = e32_int(DCE_ICIR_ICI_SHIFT, DCE_ICIR_ICI_WIDTH, 1);
	dce_ccsr_write(&b->ccsr->memcfg.icir, reg);
}

void dce_block_get_compressor_input_byte_count(struct dce_block *b,
						uint64_t *count)
{
	*count = dce_ccsr_read(&b->ccsr->stats.cibc_h);
	*count = (*count << 32) | dce_ccsr_read(&b->ccsr->stats.cibc_l);
}

void dce_block_set_compressor_input_byte_count(struct dce_block *b,
						uint64_t count)
{
	dce_ccsr_write(&b->ccsr->stats.cibc_l, (uint32_t)count);
	dce_ccsr_write(&b->ccsr->stats.cibc_h, (uint32_t)(count >> 32));
}

void dce_block_get_compressor_output_byte_count(struct dce_block *b,
						uint64_t *count)
{
	*count = dce_ccsr_read(&b->ccsr->stats.cobc_h);
	*count = (*count << 32) | dce_ccsr_read(&b->ccsr->stats.cobc_l);
}

void dce_block_set_compressor_output_byte_count(struct dce_block *b,
						uint64_t count)
{
	dce_ccsr_write(&b->ccsr->stats.cobc_l, (uint32_t)count);
	dce_ccsr_write(&b->ccsr->stats.cobc_h, (uint32_t)(count >> 32));
}

void dce_block_get_decompressor_input_byte_count(struct dce_block *b,
						uint64_t *count)
{
	*count = dce_ccsr_read(&b->ccsr->stats.dibc_h);
	*count = (*count << 32) | dce_ccsr_read(&b->ccsr->stats.dibc_l);
}

void dce_block_set_decompressor_input_byte_count(struct dce_block *b,
						uint64_t count)
{
	dce_ccsr_write(&b->ccsr->stats.dibc_l, (uint32_t)count);
	dce_ccsr_write(&b->ccsr->stats.dibc_h, (uint32_t)(count >> 32));
}

void dce_block_get_decompressor_output_byte_count(struct dce_block *b,
						uint64_t *count)
{
	*count = dce_ccsr_read(&b->ccsr->stats.dobc_h);
	*count = (*count << 32) | dce_ccsr_read(&b->ccsr->stats.dobc_l);
}

void dce_block_set_decompressor_output_byte_count(struct dce_block *b,
						uint64_t count)
{
	dce_ccsr_write(&b->ccsr->stats.dobc_l, (uint32_t)count);
	dce_ccsr_write(&b->ccsr->stats.dobc_h, (uint32_t)(count >> 32));
}

void dce_block_set_init_err(struct dce_block *b)
{
	dce_ccsr_write(&b->ccsr->interrupt.isdr, 0xffffffff);
	dce_ccsr_write(&b->ccsr->interrupt.isr, 0xffffffff);
}

void dce_block_get_sourceid(struct dce_block *b, uint32_t *sourceid)
{
	*sourceid = dce_ccsr_read(&b->ccsr->memcfg.srcidr);
}

void dce_block_get_dce_version(struct dce_block *b)
{
	uint32_t ip_rev_1, ip_rev_2;

	ip_rev_1 = dce_ccsr_read(&b->ccsr->id.ip_rev_1);
	ip_rev_2 = dce_ccsr_read(&b->ccsr->id.ip_rev_2);
	dce_version = ((uint64_t)ip_rev_1 << 32) | ip_rev_2;

	/* Check for ERR010843 */
	if (dce_version == ERR010843_DCE_REV) {
		uint8_t major, minor;
		uint32_t system_version;

		/* DCE rev register on ls2088 1.1 and ls2088 1.0, but 1.1 has
		 * a fix. The only way to distinguish the DCE versions is to
		 * check the SOC revision numbers */
		dcfg_get_revision(&major, &minor, &system_version);
		if (major == 1 && minor == 1) {
			/* This version of DCE fix for ERR010843. Manually set
			 * errata field to indicate that the issue is fixed */
			dce_version += 0x100;
		}
	}
}

uint64_t dce_block_get_version(void)
{
	return dce_version;
}


