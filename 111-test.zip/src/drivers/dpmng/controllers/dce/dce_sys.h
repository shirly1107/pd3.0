/**
*   Copyright 2009-2015, Freescale Semiconductor, Inc.  All Rights Reserved.
*
*    NOTICE: The information contained in this file is proprietary
*    to Freescale Semiconductor and is being made available to
*    Freescale's customers under a specific license agreement.
*    Use or disclosure of this information is permissible only
*    under the terms of the license agreement.
*
*/
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_types.h"
#include "fsl_io.h"

/* dce_sys_decl.h and dce_sys.h are the two platform-specific files in the
 * driver. They are only included via dce_private.h, which is itself a
 * platform-independent file and is included by all the other driver source.
 *
 * dce_sys_decl.h is included prior to all other declarations and logic, and
 * it exists to provide compatibility with any linux interfaces our
 * single-source driver code is dependent on (eg. kmalloc). Ie. this file
 * provides linux compatibility.
 *
 * This dce_sys.h header, on the other hand, is included *after* any common
 * and platform-neutral declarations and logic in dce_private.h, and exists to
 * implement any platform-specific logic of the dce driver itself. Ie. it is
 * *not* to provide linux compatibility.
 */

/* Trace the read/write access to DCE. #undef as
 * required. */
//#define DCE_CCSR_TRACE

/* When using DCE's "MC access registers", we need to choose which set
 * according to the MC core. This function is a place-holder for the routine
 * that returns the index of the core the code is executing on. TODO: when MC
 * goes SMP, hook this up to the proper "current cpu" API. */
static inline unsigned int current_cpu(void)
{
	return 0;
}

static inline void word_copy(void *d, const void *s, unsigned int cnt)
{
	uint32_t *dd = d;
	const uint32_t *ss = s;
	while (cnt--)
		*(dd++) = *(ss++);
}

/* Currently, the CENA support code expects each 32-bit word to be written in
 * host order, and these are converted to hardware (little-endian) order on
 * command submission. However, 64-bit quantities are must be written (and read)
 * as two 32-bit words with the least-significant word first, irrespective of
 * host endianness. */
static inline void u64_to_le32_copy(void *d, const uint64_t *s, unsigned int cnt)
{
	uint32_t *dd = d;
	const uint32_t *ss = (const uint32_t *)s;
	while (cnt--) {
		/* TBD: the toolchain was choking on the use of 64-bit types up
		 * until recently so this works entirely with 32-bit variables.
		 * When 64-bit types become usable again, investigate better
		 * ways of doing this. */
#if defined(__BIG_ENDIAN)
		*(dd++) = ss[1];
		*(dd++) = ss[0];
		ss += 2;
#else
		*(dd++) = *(ss++);
		*(dd++) = *(ss++);
#endif
	}
}
static inline void u64_from_le32_copy(uint64_t *d, const void *s, unsigned int cnt)
{
	const uint32_t *ss = s;
	uint32_t *dd = (uint32_t *)d;
	while (cnt--) {
#if defined(__BIG_ENDIAN)
		dd[1] = *(ss++);
		dd[0] = *(ss++);
		dd += 2;
#else
		*(dd++) = *(ss++);
		*(dd++) = *(ss++);
#endif
	}
}

/* Convert a host-native 32bit value into little endian */
#if defined(__BIG_ENDIAN)
static inline uint32_t make_le32(uint32_t val)
{
	return (((val & 0xff) << 24) | ((val & 0xff00) << 8) |
		((val & 0xff0000) >> 8) | ((val & 0xff000000) >> 24));
}
#else
#define make_le32(val) (val)
#endif
static inline void make_le32_n(uint32_t *val, unsigned int num)
{
	while (num--) {
		*val = make_le32(*val);
		val++;
	}
}

	/***************/
	/* CCSR access */
	/***************/

static inline void dce_ccsr_write(void *ccsr, uint32_t val)
{
#ifdef DCE_CCSR_TRACE
	pr_info("dce_ccsr_write(%p) 0x%08x\n", ccsr, val);
#endif
	iowrite32(val, ccsr);
}
static inline uint32_t dce_ccsr_read(void *ccsr)
{
	uint32_t reg = ioread32(ccsr);
#ifdef DCE_CCSR_TRACE
	pr_info("dce_ccsr_read(%p) 0x%08x\n", ccsr, reg);
#endif
	return reg;
}

