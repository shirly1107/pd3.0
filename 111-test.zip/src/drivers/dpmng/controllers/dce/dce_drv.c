/*
 * Copyright 2013-2020 NXP
 */

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_cmdif.h"
#include "fsl_types.h"
#include "fsl_io.h"
#include "fsl_gen.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_platform.h"
#include "fsl_dce.h"
#include "fsl_dbg.h"

#include "drivers/fsl_dce_ctrl.h"
#include "fsl_resman.h"

/*************/
/* Debugging */
/*************/

/* When things go wrong, it is a convenient trick to insert a few FOO()
 * statements in the code to trace progress. */
#define FOO() pr_info("FOO: %s:%d\n", __FILE__, __LINE__)

/***********************/
/* Linux-like routines */
/***********************/

#define upper32(a) (uint32_t)((uint64_t)(a) >> 32)
#define lower32(a) (uint32_t)(a)

/***************************/
/* Support for test builds */
/***************************/

/* When DCE_TEST is defined, we will deliberately hide some primitve
 * resources from the resource manager so that MC-based and GPP-based test
 * cases can run without interference from "regular users".
 */
#ifdef DCE_TEST

#else

#endif

/**********************/
/* State and settings */
/**********************/

/* dce_drv.c is a stub to call all the device setup stuff that will
 * eventually be called from other management logic in MC. We statically assume
 * the existence of a single DCE block, with hard-coded attributes, and we
 * allocate device memory for the block according to hard-coded parameters. */

static struct dce_block_desc bd;
static struct dce_block *dcehw;

#define DCE_ICID 0
#define DCE_IOBYPASS 1
#define DCE_VA 0

#ifdef DCE_TEST
extern void dce_test(void);
#endif

/* NB: these predeclarations are because they don't get predeclared in a header,
 * and gcc (quite rightly) things that linkable (non-static) functions cannot
 * possibly be useful unless they're predeclared - after all, who will call
 * them? In our case though, the existence of these functions is also
 * predeclared locally in whichever other C file uses them, which is a bit of a
 * hack, and explains why a similar hack is required here. If an MC s/w
 * architect wants to move these declarations to a common header (which one?),
 * be my guest. */
int dce_drv_init(void);
static int dce_drv_test(void);

/***************/
/* Driver init */
/***************/
int dce_drv_init(void)
{
	struct dce_desc desc;
	int ret, iter;

	iter = 0;

	pr_info("Executing dce_drv_init...\n");
	
	memset(&desc, 0, sizeof(struct dce_desc));
	ret = sys_get_desc(SOC_MODULE_DCE, SOC_DB_NO_MATCH_FIELDS,
				&desc, &iter);
	if (ret)
		return ret;
	
	pr_info("DCE CCSR: 0x%08x%08x\n",UINT32_HI(desc.paddr), UINT32_LO(desc.paddr));

	bd.ccsr_reg_bar = desc.vaddr;
	ASSERT_COND(bd.ccsr_reg_bar);

	dcehw = dce_block_init(&bd);
	if (!dcehw)
		return -ENOMEM;

	dce_block_set_init_err(dcehw);
	dce_block_set_enable_level(dcehw, DCE_ENABLE_LEVEL_ENABLE);

	return 0;
}
