/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          pebm.c

 @Description   pebm driver implementation

 @Cautions      None.
 *//***************************************************************************/
#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_soc.h"
#include "fsl_platform.h"
#include "fsl_io.h"
#include "drivers/fsl_mc.h"
#include "fsl_mpic.h"
#include "fsl_mc.h"

#include "pebm.h"

static void pebm_isr(uint32_t arg)
{
	//void *tmp_regs;
	//uint32_t event;
	//struct pebm_regs *regs = (struct pebm_regs *)arg;

	UNUSED(arg);

	pr_info("PEB event\n");
}

static void pebm_err_isr(uint32_t arg)
{
	//void *tmp_regs;
	//uint32_t event;
	//struct pebm_regs *regs = (struct pebm_regs *)arg;

	UNUSED(arg);

	pr_info("PEB event\n");
}

int pebm_init()
{
	int err;
	mpic_intr_params_t intr_params;
	struct pebm_regs *regs;
	struct mem_desc mem_desc;
	void *peb_vaddr;
	struct dpmng_amq mc_amq;

	/* Get descriptors */
	err = sys_get_desc(SOC_MODULE_PEBM, 0, &mem_desc, 0);
	ASSERT_COND(!err);
	
	pr_info("PEBM CCSR: 0x%08x%08x\n",UINT32_HI(mem_desc.regs_paddr), UINT32_LO(mem_desc.regs_paddr));

	pr_info("PEBM memory base: 0x%X%08X, size: 0x%X\n",
		(uint32_t)(mem_desc.paddr >> 32), (uint32_t)mem_desc.paddr,
		(uint32_t)mem_desc.size);

	/* initialize PEB memory controller */
	regs = (struct pebm_regs *)(mem_desc.regs_vaddr);

	iowrite32(ioread32(&regs->pebm_cr) | PEBM_CR_HASHED_ADDR_MODE,
			&regs->pebm_cr);

	/* Clear PEB memory to prevent ECC errors */
	dpmng_get_amq(&mc_amq);

	peb_vaddr = dpmng_mc_set_soc_window(mem_desc.paddr, &mc_amq);

/*
 * Memory is by default zeroed on emulator so skip PEB memset to save
 * execution time.
 */
#ifndef EMULATOR
	memset32(peb_vaddr, 0, (uint32_t)mem_desc.size);
#endif

	/* Register PEBM interrupts */
	intr_params.polarity = OS_MPIC_INTR_POLARITY_HIGH;
	intr_params.priority = 8;
	intr_params.sense = OS_MPIC_INTR_SENSE_LEVEL;
	intr_params.target = OS_MPIC_INTR_TARGET_DEFAULT;

	err = mpic_set_config_intr((uint32_t)mem_desc.irq_rec_err, 0, pebm_err_isr,
					(mpic_arg)regs, &intr_params);
	if (err != 0) {
		return err;
	}
	err = mpic_enable_intr((uint32_t)mem_desc.irq_rec_err);
	if (err != 0) {
		return err;
	}

	return 0;
}

void pebm_error_inject()
{
	int err;
	struct mem_desc mem_desc;
	struct pebm_regs *regs;

	err = sys_get_desc(SOC_MODULE_PEBM, 0, &mem_desc, 0);
	ASSERT_COND(!err);

	regs = (struct pebm_regs *)(mem_desc.regs_vaddr);

	/* enable error injection */
	iowrite32(0x00000003, &regs->pebm_ecc_err_cr);

	/* error inject */
	iowrite32(0xa5a5a5a5, &regs->pebm_ecc_err_inj_h);
	iowrite32(0xa5a5a5a5, &regs->pebm_ecc_err_inj_l);

	/* disable error injection */
	iowrite32(0x00000000, &regs->pebm_ecc_err_cr);
}

void pebm_enable_exceptions()
{
	int err;
	struct mem_desc mem_desc;
	struct pebm_regs *regs;

	err = sys_get_desc(SOC_MODULE_PEBM, 0, &mem_desc, 0);
	ASSERT_COND(!err);

	regs = (struct pebm_regs *)(mem_desc.regs_vaddr);

	/* enable interrupts on errors */
	iowrite32(PEBM_ERR_MB | PEBM_ERR_RD | PEBM_ERR_WR,
			&regs->pebm_err_int_en);
}

