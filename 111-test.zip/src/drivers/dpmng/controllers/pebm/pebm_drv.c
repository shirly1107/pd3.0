/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_pebm.h"
#include "fsl_dbg.h"


int pebm_drv_init(void);

int pebm_drv_init(void)
{
	pr_info("Executing pebm_drv_init...\n");

	pebm_init();

	pebm_enable_exceptions();

	//pebm_error_inject();

	return 0;
}
