/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpmng.h

 @Description   dpmng internal structures and definitions.
 *//***************************************************************************/
#ifndef __PEBM_H
#define __PEBM_H

#include "kernel/device.h"
#include "fsl_types.h"
#include "fsl_pebm.h"

struct pebm_regs {
	uint32_t pebm_cr; /* 0x000 PEBM Control register */
	uint32_t pebm_sr; /*0x004 PEBM Status register */
	uint32_t reserved0[2];
	uint32_t pebm_tmr; /* 0x010 PEBM Timer register */
	uint32_t reserved1[0x2f9];
	uint32_t pebm_rid1; /* 0xBF8 PEBM Revision ID register 1 */
	uint32_t pebm_rid2; /* 0xBFC PEBM Revision ID register 2 */
	uint32_t reserved2[0x80];
	uint32_t pebm_ecc_err_cr; /* 0xE00 PEBM ECC Error Control register */
	uint32_t pebm_ecc_err_inj_h; /*0xE04 PEBM ECC Error Inject Mask high register */
	uint32_t pebm_ecc_err_inj_l; /*0xE08 PEBM ECC Error Inject Mask low register */
	uint32_t reserved3;
	uint32_t pebm_err_det; /* 0xE10 PEBM Error Detect register */
	uint32_t pebm_err_int_en; /* 0xE14 PEBM Error Interrupt Enable register */
	uint32_t pebm_err_dis; /* 0xE18 PEBM Error Disable register */
	uint32_t reserved4;
	uint32_t pebm_err_cap_sr; /* 0xE20 PEBM Error Capture Status register */
	uint32_t pebm_err_cap0; /* 0xE24 PEBM Error Capture register 0 */
	uint32_t pebm_err_cap1; /* 0xE28 PEBM Error Capture register 1 */
	uint32_t pebm_err_cap2; /* 0xE2C PEBM Error Capture register 2 */
	uint32_t reserved5[4];
	uint32_t pebm_ecc_err_cap_sr; /* 0xE40 PEBM ECC Error Capture Status register */
	uint32_t pebm_ecc_err_cap0; /* 0xE44 PEBM ECC Error Capture register 0 */
};


#define PEBM_CR_HASHED_ADDR_MODE 	0x00000001

#define PEBM_ERR_MB 			0x00000020
#define PEBM_ERR_SB 			0x00000010
#define PEBM_ERR_RD 			0x00000002
#define PEBM_ERR_WR 			0x00000001



#endif /* __PEBM_H */
