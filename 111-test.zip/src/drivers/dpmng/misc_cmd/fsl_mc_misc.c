/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_dbg.h"
#include "fsl_cmdif_mc.h"
#include "kernel/device.h"
#include "fsl_mem_mng.h"
#include "fsl_mc_misc_cmd.h"
#include "fsl_mc_misc.h"

#ifdef MISC_CMD_SUPPORT
int misc_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data);

/**
 * misc command used to configure memory manager allocator in order to
 * have a quick view of allocated/deallocated blocks.
 * call this when you want to start/end monitoring allocation
 */
static int misc_mm_alloc_config_check(struct device *dev, struct mc_cmd_data *cmd_data)
{
	UNUSED(dev);
#ifdef MEM_MNG_COUNT_ALLOC
	uint32_t check_flags = 0u;

	MC_MISC_CMD_MM_ALLOC_CONFIG_CHECK(cmd_data, check_flags);

	sys_mem_mng_set_alloc_flags(check_flags);
#endif //MEM_MNG_COUNT_ALLOC
	return 0;
}

/**
 * misc command used to generate a dump of all registered memory partition.
 * call this whenever you want to see memory partition status.
 */
static int misc_mm_alloc_dump(struct device *dev, struct mc_cmd_data *cmd_data)
{
	UNUSED(dev);
	UNUSED(cmd_data);
	
	sys_mem_mng_print_alloc_info();
	
	return 0;
}

/**
 * misc command used to check if there are memory leaks
 */
static int misc_mm_alloc_check(struct device *dev, struct mc_cmd_data *cmd_data)
{
	UNUSED(dev);
	UNUSED(cmd_data);

	int32_t cnt = 0;
#ifdef MEM_MNG_COUNT_ALLOC	
	sys_mem_mng_check_alloc(&cnt);
#endif //MEM_MNG_COUNT_ALLOC	
	MC_MISC_RSP_MM_ALLOC_CHECK(cmd_data, cnt);
	return 0;
}

int misc_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev,
		struct mc_cmd_data *cmd_data);
		char *cmd_str;
		uint8_t ver;
	} map_commands[] = {
			{ MC_MISC_CMD_CODE_MM_ALLOC_CONFIG_CHECK, 	misc_mm_alloc_config_check, "misc_mm_alloc_config_check", 	MC_MISC_CMD_V1 },
			{ MC_MISC_CMD_CODE_MM_ALLOC_DUMP, 			misc_mm_alloc_dump, 		"misc_mm_alloc_dump", 			MC_MISC_CMD_V1 },
			{ MC_MISC_CMD_CODE_MM_ALLOC_CHECK, 			misc_mm_alloc_check, 		"misc_mm_alloc_check", 			MC_MISC_CMD_V1 }
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
				(cmd_ver == map_commands[i].ver)) {
			pr_info("Handling misc command: %s \n", map_commands[i].cmd_str);
			return map_commands[i].function((struct device *)dev, cmd_data);
		}

	pr_err("Invalid command %d\n", cmd);
	return -ENOTSUP;
}
#endif //#define MISC_CMD_SUPPORT
