/*
 * Copyright 2013-2020 NXP
 */

#ifndef _FSL_MC_MISC_CMD_H
#define _FSL_MC_MISC_CMD_H

#define MC_MISC_CMD_V1										CMDHDR_CMD_VERSION(1)

/* Command IDs */
#define MC_MISC_CMD_CODE_MM_ALLOC_CONFIG_CHECK                    0xF01
#define MC_MISC_CMD_CODE_MM_ALLOC_DUMP                            0xF02
#define MC_MISC_CMD_CODE_MM_ALLOC_CHECK                           0xF03

/*                cmd, param, offset, width, type, arg_name */
#define MC_MISC_CMD_MM_ALLOC_CONFIG_CHECK(cmd, check_flags) \
	MC_CMD_OP(cmd, 0, 0,  32, uint32_t, check_flags)

#define MC_MISC_RSP_MM_ALLOC_CHECK(cmd, check) \
	MC_RSP_OP(cmd, 0, 0,  32,  int32_t,	check)

#endif //_FSL_MC_MISC_CMD_H
