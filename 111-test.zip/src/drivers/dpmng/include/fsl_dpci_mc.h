/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPCI_H
#define __FSL_DPCI_H

#include "fsl_linkman.h"
#include "fsl_opr.h"

struct dpci;

#define DPCI_MAX_IRQ_NUM		1 //TODO

#define DPCI_PRIO_NUM		4
#define DPCI_FQID_NOT_VALID	(uint32_t)(-1)
#define DPCI_ALL_QUEUES		(uint8_t)(-1)

int dpci_open(struct dpci *dpci, int dpci_id);

int dpci_close(struct dpci *dpci);

#define DPCI_OPT_HAS_OPR					0x000040
#define DPCI_OPT_OPR_SHARED					0x000080

struct dpci_cfg {
	uint32_t options;
	uint8_t num_of_priorities;
};

int dpci_create(struct dpci *dpci, const struct dpci_cfg *cfg);

void dpci_destroy(struct dpci *dpci);

int dpci_enable(struct dpci *dpci);

int dpci_disable(struct dpci *dpci);

int dpci_is_enabled(struct dpci *dpci, int *en);

int dpci_reset(struct dpci *dpci);

#define DPCI_IRQ_INDEX						0
#define DPCI_IRQ_EVENT_LINK_CHANGED             0x00000001
#define DPCI_IRQ_EVENT_CONNECTED                0x00000002
#define DPCI_IRQ_EVENT_DISCONNECTED             0x00000004


int dpci_set_irq(struct dpci *dpci,
		 uint8_t irq_index,
		 const struct mc_irq_cfg *irq_cfg);

int dpci_get_irq(struct dpci *dpci,
        	 uint8_t irq_index,
        	 struct mc_irq_cfg *irq_cfg);

int dpci_set_irq_enable(struct dpci *dpci, uint8_t irq_index, uint8_t en);

int dpci_get_irq_enable(struct dpci *dpci, uint8_t irq_index, uint8_t *en);

int dpci_set_irq_mask(struct dpci *dpci, uint8_t irq_index, uint32_t mask);

int dpci_get_irq_mask(struct dpci *dpci, uint8_t irq_index, uint32_t *mask);

int dpci_get_irq_status(struct dpci *dpci,
			uint8_t irq_index,
			uint32_t *status);

int dpci_clear_irq_status(struct dpci *dpci,
			  uint8_t irq_index,
			  uint32_t status);

int dpci_set_opr(struct dpci *dpci, uint8_t index, uint8_t options, struct opr_cfg *cfg);

int dpci_get_opr(struct dpci *dpci, uint8_t index, struct opr_cfg *cfg, struct opr_qry *qry);

struct dpci_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
	uint8_t num_of_priorities;
};

int dpci_get_attributes(struct dpci *dpci, struct dpci_attr *attr);

struct dpci_peer_attr {
	int peer_id;
	uint8_t num_of_priorities;
};

int dpci_get_peer_attributes(struct dpci *dpci, struct dpci_peer_attr *attr);

int dpci_get_link_state(struct dpci *dpci, int *up);

enum dpci_dest {
	DPCI_DEST_NONE = 0,
	DPCI_DEST_DPIO = 1,
	DPCI_DEST_DPCON = 2
};

struct dpci_dest_cfg {
	enum dpci_dest dest_type;
	int dest_id;
	uint8_t priority;
};

#define DPCI_QUEUE_OPT_USER_CTX		0x00000001
#define DPCI_QUEUE_OPT_DEST		0x00000002
#define DPCI_QUEUE_OPT_HOLD_ACTIVE	0x00000004

struct dpci_rx_queue_cfg {
	uint32_t options;
	uint64_t user_ctx;
	struct dpci_dest_cfg dest_cfg;
	int order_preservation_en;
};

int dpci_set_rx_queue(struct dpci *dpci,
	uint8_t priority,
	const struct dpci_rx_queue_cfg *cfg);

struct dpci_rx_queue_attr {
	uint64_t user_ctx;
	struct dpci_dest_cfg dest_cfg;
	uint32_t fqid;
};

int dpci_get_rx_queue(struct dpci *dpci,
	uint8_t priority,
	struct dpci_rx_queue_attr *attr);

struct dpci_tx_queue_attr {
	uint32_t fqid;
};

int dpci_get_tx_queue(struct dpci *dpci,
	uint8_t priority,
	struct dpci_tx_queue_attr *attr);

/* MC internal functions */

/**
 * @brief	Will allocate resources and preliminary initialization
 *
 * @param[in]	dpci - DPCI handle
 * @param[in]	cfg - Configuration structure
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpci_init(struct dpci *dpci,
	      const struct dpci_cfg *cfg,
	      const struct dpmng_dev_cfg *dev_cfg);

struct dpci *dpci_allocate(void);
void dpci_deallocate(struct dpci *dpci);
int dpci_set_dev_ctx(struct dpci *dpci, const struct dpmng_dev_ctx *dev_ctx);

int dpci_event_cb(void *handle,
                   const struct linkman_control   *control,
                   struct linkman_endpoint        *self,
                   const struct linkman_endpoint  *peer,
                   struct linkman_action          *action);
int dpci_event_complete_cb(void *handle,
        	const struct linkman_control   *control,
        	struct linkman_endpoint        *self,
        	const struct linkman_endpoint  *peer,
        	struct linkman_action          *action);

#endif /* __FSL_DPCI_H */
