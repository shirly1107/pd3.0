/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 @File          eiop_rtc_ext.h

 @Description   External definitions and API for FM RTC IEEE1588 Timer Module.

 @Cautions      None.
 *//***************************************************************************/

#ifndef __FSL_EIOP_RTC_H__
#define __FSL_EIOP_RTC_H__

/**************************************************************************//**
 @Group         eiop_rtc_grp FM RTC

 @Description   FM RTC functions, definitions and enums.

 @{
 *//***************************************************************************/

/**************************************************************************//**
 @Group         eiop_rtc_init_grp FM RTC Initialization Unit

 @Description   FM RTC initialization API.

 @{
 *//***************************************************************************/
struct eiop_rtc_desc {
	int eiop_id;
	void *vaddr;
	phys_addr_t paddr;
	uint8_t num_alarms;
	uint8_t num_periodics;
	uint8_t num_ext_triggers;
	uint8_t little_endian;
};

/**************************************************************************//**
 @Description   FM RTC Alarm Polarity Options.
 *//***************************************************************************/
enum eiop_rtc_alarm_polarity {
	EIOP_RTC_ALARM_POLARITY_ACTIVE_HIGH = 1, /**< Active-high output polarity */
	EIOP_RTC_ALARM_POLARITY_ACTIVE_LOW
/**< Active-low output polarity */
};

/**************************************************************************//**
 @Description   FM RTC Trigger Polarity Options.
 *//***************************************************************************/
enum eiop_rtc_trigger_polarity {
	EIOP_RTC_TRIGGER_ON_RISING_EDGE = 1, /**< Trigger on rising edge */
	EIOP_RTC_TRIGGER_ON_FALLING_EDGE
/**< Trigger on falling edge */
};

/**************************************************************************//**
 @Description   IEEE1588 Timer Module FM RTC Optional Clock Sources.
 *//***************************************************************************/
enum eiop_src_clock {
	EIOP_RTC_SOURCE_CLOCK_EXTERNAL, /**< external high precision timer
	 reference clock */
	EIOP_RTC_SOURCE_CLOCK_SYSTEM, /**< MAC system clock */
	EIOP_RTC_SOURCE_CLOCK_OSCILATOR
/**< RTC clock oscilator */
};

#define EIOP_RTC_MAX_NUM_OF_ALARMS 		3
#define EIOP_RTC_MAX_NUM_OF_PERIODIC_PULSES 	4
#define EIOP_RTC_MAX_NUM_OF_EXT_TRIGGERS 	4

#define EIOP_RTC_OPT_SLAVE_MODE		0x80000000 /*!< Operate in slave mode */
#define EIOP_RTC_OPT_INVERT_INPUT	0x40000000 /*!< Invert input clock phase */
#define EIOP_RTC_OPT_INVERT_OUTPUT	0x20000000 /*!< Invert output clock phase */
#define EIOP_RTC_OPT_BYPASS		0x10000000 /*!< bypass frequency compensation */
#define EIOP_RTC_OPT_DISABLE_REALIGN	0x08000000 /*!< disable fixed period interval pulse realignment */

struct eiop_rtc_defcfg {
	uint32_t clock_period_nanosec; /*!< clock period (default is 1 micro) */
	enum eiop_src_clock src_clk; /*!< clock source (default is MAC system clock) */
	uint32_t ext_src_clk_freq; /*!< external source clock frequency.
	 Must be defined if src_clk != e_FM_RTC_SOURCE_CLOCK_SYSTEM */
	uint32_t options; /*!< A combination of EIOP_RTC_OPT_xx options (default
	 is 0*/
	uint16_t output_clock_divisor; /*!< Output clock divisor
	 (default is 2) */
	enum eiop_rtc_alarm_polarity alarm_polarity[EIOP_RTC_MAX_NUM_OF_ALARMS];
	/*!< Alarm output polarity polarity (default is
	 * EIOP_RTC_ALARM_POLARITY_ACTIVE_HIGH) */
	enum eiop_rtc_trigger_polarity trigger_polarity[EIOP_RTC_MAX_NUM_OF_EXT_TRIGGERS];
/*!< External trigger edge polarity (default is
 * EIOP_RTC_TRIGGER_ON_FALLING_EDGE) */

};

struct eiop_rtc_cfg {
	struct eiop_rtc_defcfg defcfg;
};

struct eiop_rtc;

/**************************************************************************//**
 @Description   FM RTC configuration parameters structure.

 This structure should be passed to eiop_rtc_Config().
 *//***************************************************************************/

/**************************************************************************//**
 @Function      rtc_restore_runtime_config

 @Description   Restores 1588 as it was at runtime before WRIOP reset.

 The driver assigns default values to some FM RTC parameters.
 These parameters can be overwritten using the advanced
 configuration routines. Restore all of them.

 @Param[in]     eiop_rtc    - Handle to wiop_rtc.

 @Return        Error code.

 @Cautions      None
 *//***************************************************************************/
int rtc_restore_runtime_config(struct eiop_rtc *eiop_rtc);

/**************************************************************************//**
 @Function      eiop_rtc_restore_hardware

 @Description   Restores hardware after WRIOP reset.

 @Param[in]     eiop_rtc    - Handle to wiop_rtc.

 @Return        Error code. 

 @Cautions      None
 *//***************************************************************************/
int eiop_rtc_restore_hardware (struct eiop_rtc *eiop_rtc);

/**************************************************************************//**
 @Function      eiop_rtc_Config

 @Description   Configures the FM RTC module according to user's parameters.

 The driver assigns default values to some FM RTC parameters.
 These parameters can be overwritten using the advanced
 configuration routines.

 @Param[in]     p_FmRtcParam    - FM RTC configuration parameters.

 @Return        Handle to the new FM RTC object; NULL pointer on failure.

 @Cautions      None
 *//***************************************************************************/
struct eiop_rtc *eiop_rtc_init(const struct eiop_rtc_desc *eiop_rtc_desc,
                               const struct eiop_rtc_cfg *eiop_rtc_cfg);

/**************************************************************************//**
 @Function      eiop_rtc_Free

 @Description   Frees the FM RTC object and all allocated resources.

 @Param[in]     h_FmRtc - Handle to FM RTC object.


 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously created using eiop_rtc_Config().
 *//***************************************************************************/
int eiop_rtc_done(struct eiop_rtc *eiop_rtc);

/**************************************************************************//**
 @Group         eiop_rtc_control_grp FM RTC Control Unit

 @Description   FM RTC runtime control API.

 @{
 *//***************************************************************************/

struct eiop_rtc_event_cfg {
	uint8_t id;
	uint32_t event_mask;	
	uint64_t time;           /* n/a for external trigger */
	int use_pulse_as_input; /* valid only for external trigger */
	int disable_intr; 
};


/**************************************************************************//**
 @Function      eiop_rtc_Enable

 @Description   Enable the RTC (time count is started).

 The user can select to resume the time count from previous
 point, or to restart the time count.

 @Param[in]     h_FmRtc     - Handle to FM RTC object.
 @Param[in]     resetClock  - Restart the time count from zero.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_enable(struct eiop_rtc *eiop_rtc, int reset_clock);

/**************************************************************************//**
 @Function      eiop_rtc_Disable

 @Description   Disables the RTC (time count is stopped).

 @Param[in]     h_FmRtc - Handle to FM RTC object.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_disable(struct eiop_rtc *eiop_rtc);

/**************************************************************************//**
 @Function      eiop_rtc_GetClockOffset

 @Description   Gets the clock offset. Is available only in master mode.
                Current time in is calculated by adding current offset
                with the timer's counter register to adjust current timestamp.

 The user can pass a negative offset value.

 @Param[in]     h_FmRtc  - Handle to FM RTC object.
 @Param[in]     offset   - Clock offset (in nanoseconds).

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_get_clock_offset(struct eiop_rtc *eiop_rtc, uint64_t *offset);

/**************************************************************************//**
 @Function      eiop_rtc_SetClockOffset

 @Description   Sets the clock offset (usually relative to another clock).

 The user can pass a negative offset value.

 @Param[in]     h_FmRtc  - Handle to FM RTC object.
 @Param[in]     offset   - New clock offset (in nanoseconds).

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_set_clock_offset(struct eiop_rtc *eiop_rtc, uint64_t offset);

/**************************************************************************//**
 @Function      eiop_rtc_SetAlarm

 @Description   Schedules an alarm event to a given RTC time.

 @Param[in]     h_FmRtc             - Handle to FM RTC object.
 @Param[in]     p_FmRtcAlarmParams  - Alarm parameters.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 Must be called only prior to eiop_rtc_Enable().
 *//***************************************************************************/
int eiop_rtc_set_alarm(struct eiop_rtc *eiop_rtc,
                       struct eiop_rtc_event_cfg *eiop_rtc_event_cfg);
/**************************************************************************//**
 @Function      eiop_rtc_SetPeriodicPulse

 @Description   Sets a periodic pulse.

 @Param[in]     h_FmRtc                         - Handle to FM RTC object.
 @Param[in]     p_FmRtcPeriodicPulseParams      - Periodic pulse parameters.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 Must be called only prior to eiop_rtc_Enable().
 *//***************************************************************************/
int eiop_rtc_set_periodic_pulse(struct eiop_rtc *eiop_rtc,
                                struct eiop_rtc_event_cfg *eiop_rtc_event_cfg);

int eiop_rtc_set_periodic_pulse_intr(struct eiop_rtc *eiop_rtc,
                                  uint8_t id, int enable);

/**************************************************************************//**
 @Function      eiop_rtc_ClearPeriodicPulse

 @Description   Clears a periodic pulse.

 @Param[in]     h_FmRtc                         - Handle to FM RTC object.
 @Param[in]     periodicPulseId                 - Periodic pulse id.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_clear_periodic_pulse(struct eiop_rtc *eiop_rtc,
                                  uint8_t periodic_pulse_id);

/**************************************************************************//**
 @Function      eiop_rtc_SetExternalTrigger

 @Description   Sets an external trigger indication and define a callback
 routine to be called on such event.

 @Param[in]     h_FmRtc                         - Handle to FM RTC object.
 @Param[in]     p_FmRtcExternalTriggerParams    - External Trigger parameters.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_set_ext_trigger(struct eiop_rtc *eiop_rtc,
                             struct eiop_rtc_event_cfg *eiop_rtc_event_cfg);
/**************************************************************************//**
 @Function      eiop_rtc_SetFiperLoopback

 @Description   Sets the fiper signal as source interrupt for External Timestamp samples

 @Param[in]     h_FmRtc                         - Handle to FM RTC object.
 @Param[in]     id				                - External Trigger id.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_set_fiper_loopback(struct eiop_rtc *eiop_rtc,
                                  struct eiop_rtc_event_cfg *rtc_event_cfg);
/**************************************************************************//**
 @Function      eiop_rtc_ClearExternalTrigger

 @Description   Clears external trigger indication.

 @Param[in]     h_FmRtc                         - Handle to FM RTC object.
 @Param[in]     id                              - External Trigger id.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_clear_ext_trigger(struct eiop_rtc *eiop_rtc,
                               uint8_t ext_trigger_id);

/**************************************************************************//**
 @Function      eiop_rtc_GetExternalTriggerTimeStamp

 @Description   Reads the External Trigger TimeStamp.

 @Param[in]     h_FmRtc                 - Handle to FM RTC object.
 @Param[in]     triggerId               - External Trigger id.
 @Param[out]    p_TimeStamp             - External Trigger timestamp (in nanoseconds).

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_get_ext_trigger_timestamp(struct eiop_rtc *eiop_rtc,
                                       uint8_t ext_trigger_id,
                                       uint64_t *timestamp);

/**************************************************************************//**
 @Function      eiop_rtc_GetExternalTriggerTimeStampStatus

 @Description   Reads the timer status to get the FIFO timestamp status.

 @Param[in]     h_FmRtc                 - Handle to FM RTC object.
 @Param[in]     triggerId               - External Trigger id.
 @Param[out]    p_Status         		- External Trigger timestamp status.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_get_ext_trigger_timestamp_status(struct eiop_rtc *eiop_rtc,
                                                uint8_t ext_trigger_id,
                                                uint8_t *status);

/**************************************************************************//**
 @Function      eiop_rtc_GetCurrentTime

 @Description   Returns the current RTC time.

 @Param[in]     h_FmRtc - Handle to FM RTC object.
 @Param[out]    p_Ts - returned time stamp (in nanoseconds).

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_get_current_timestamp(struct eiop_rtc *eiop_rtc,
                                   uint64_t *timestamp);

/**************************************************************************//**
 @Function      eiop_rtc_SetCurrentTime

 @Description   Sets the current RTC time.

 @Param[in]     h_FmRtc - Handle to FM RTC object.
 @Param[in]     ts - The new time stamp (in nanoseconds).

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_set_current_timestamp(struct eiop_rtc *eiop_rtc,
                                   uint64_t timestamp);

/**************************************************************************//**
 @Function      eiop_rtc_GetFreqCompensation

 @Description   Retrieves the frequency compensation value

 @Param[in]     h_FmRtc         - Handle to FM RTC object.
 @Param[out]    p_Compensation  - A pointer to the returned value of compensation.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_get_freq_compensation(struct eiop_rtc *eiop_rtc,
                                   uint32_t *compensation);

/**************************************************************************//**
 @Function      eiop_rtc_SetFreqCompensation

 @Description   Sets a new frequency compensation value.

 @Param[in]     h_FmRtc             - Handle to FM RTC object.
 @Param[in]     freqCompensation    - The new frequency compensation value to set.

 @Return        E_OK on success; Error code otherwise.

 @Cautions      h_FmRtc must have been previously initialized using eiop_rtc_Init().
 *//***************************************************************************/
int eiop_rtc_set_freq_compensation(struct eiop_rtc *eiop_rtc,
                                   uint32_t freq_compensation);

uint32_t eiop_rtc_get_timestamp_period(struct eiop_rtc *eiop_rtc);

void eiop_rtc_exceptions(struct eiop_rtc *eiop_rtc);

void eiop_rtc_set_isr_params(struct eiop_rtc *eiop_rtc, 
	int (*isr_cb)(void *arg, uint8_t irq_id, uint32_t event), 
	void *arg, 
	uint8_t irq_id);

#if 0
#if (defined(DEBUG_ERRORS) && (DEBUG_ERRORS > 0))
/**************************************************************************//**
 @Function      eiop_rtc_DumpRegs

 @Description   Dumps all FM registers

 @Param[in]     h_FmRtc      A handle to an FM RTC Module.

 @Return        E_OK on success;

 @Cautions      Allowed only FM_Init().
 *//***************************************************************************/
int eiop_rtc_dump_regs(struct eiop_rtc *eiop_rtc);
#endif /* (defined(DEBUG_ERRORS) && ... */
#endif
/** @} *//* end of eiop_rtc_control_grp */
/** @} *//* end of eiop_rtc_grp */

#endif /* __FSL_EIOP_RTC_H__ */
