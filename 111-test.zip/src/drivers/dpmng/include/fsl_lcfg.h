/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_LCFG_H
#define __FSL_LCFG_H

#include "fsl_types.h"
#include "fsl_gen.h"


struct lcfg_desc {
    phys_addr_t paddr;
    void *vaddr;
};

int lcfg_init();

#endif /* __FSL_LCFG_H */

