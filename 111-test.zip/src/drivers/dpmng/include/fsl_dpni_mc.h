/*
 * Copyright 2013-2021 NXP
 */

#ifndef __FSL_DPNI_H
#define __FSL_DPNI_H

#include "fsl_dpmng_mc.h"
#include "fsl_linkman.h"
#include "fsl_dpkg.h"
#include "fsl_dppolicer.h"
#include "fsl_opr.h"
#include "fsl_dpparser.h"

struct dpni;

#define DPNI_MAX_IRQ_NUM		1

#define DPNI_MAX_KEY_SIZE		56
#define DPNI_MAX_RX_TC				8
#define DPNI_MAX_TX_TC				16
#define DPNI_DEFAULT_RX_TC			1
#define DPNI_DEFAULT_TX_TC			16
#define DPNI_DEFAULT_DCP_WQID	0
#define DPNI_MAX_DPBP				8
#define DPNI_MAX_SP				2

#define DPNI_ALL_TCS				(uint8_t)(-1)
#define DPNI_ALL_TC_FLOWS			(uint16_t)(-1)
#define DPNI_NEW_FLOW_ID			(uint16_t)(-1)
#define DPNI_COMMON_TX_CONF			(uint16_t)(-1)

#define DPNI_VLAN_SET_QUEUE_ACTION 0x1
#define DPNI_MAC_SET_QUEUE_ACTION  0x1

int dpni_open(struct dpni *dpni, int dpni_id);

int dpni_close(struct dpni *dpni, uint16_t token);

/* DPNI Create - v0 */

#define DPNI_OPT_ALLOW_DIST_KEY_PER_TC		0x00000001
#define DPNI_OPT_TX_CONF_DISABLED		0x00000002
#define DPNI_OPT_PRIVATE_TX_CONF_ERROR_DISABLED	0x00000004
#define DPNI_OPT_DIST_HASH			0x00000010
#define DPNI_OPT_DIST_FS			0x00000020 /* will be used internally */
#define DPNI_OPT_UNICAST_FILTER			0x00000080
#define DPNI_OPT_MULTICAST_FILTER		0x00000100
#define DPNI_OPT_VLAN_FILTER			0x00000200
#define DPNI_OPT_IPSEC				0x00000400
#define DPNI_OPT_IPR				0x00000800
#define DPNI_OPT_IPF				0x00001000
#define DPNI_OPT_VLAN_MANIPULATION		0x00010000
#define DPNI_OPT_QOS_MASK_SUPPORT		0x00020000
#define DPNI_OPT_FS_MASK_SUPPORT		0x00040000
#define DPNI_OPT_SHARED_MAC_TABLE		0x00080000
#define DPNI_OPT_HAS_OPR				0x00100000
#define DPNI_OPT_OPR_PER_TC				0x00200000
#define DPNI_OPT_FLCTYPE_HASH			0x00400000
#define DPNI_OPT_CUSTOM_CG				0x00800000
#define DPNI_OPT_CUSTOM_OPR				0x01000000
#define DPNI_OPT_SHARED_HASH_KEY		0x02000000
#define DPNI_OPT_SHARED_FS			0x08000000
#ifdef MC_CLI
// DPNI test options
#define DPNI_OPT_RX_TX_HW_ECHO  		0x04000000
#endif

struct dpni_ipr_cfg {
	uint16_t max_reass_frm_size;
	uint16_t min_frag_size_ipv4;
	uint16_t min_frag_size_ipv6;
	uint16_t max_open_frames_ipv4;
	uint16_t max_open_frames_ipv6;
};
/* IPSEC options */
#define DPNI_IPSEC_INCLUDE_IP_SRC_IN_SA_SELECT	0x01
#define DPNI_IPSEC_INCLUDE_IP_DST_IN_SA_SELECT	0x02
//#define DPNI_IPSEC_OPT_SEQ_NUM_ROLLOVER_EVENT		0x00000004

struct dpni_ipsec_cfg {
	uint8_t sa_selectors;
	uint8_t num_sa_ipv4;
	uint8_t num_sa_ipv6;
};

struct dpni_extended_cfg {
	struct {
		uint16_t max_dist;
		uint16_t max_fs_entries;
	} tc_cfg[DPNI_MAX_RX_TC];
	struct dpni_ipr_cfg ipr_cfg;
	struct dpni_ipsec_cfg ipsec_cfg;

};

struct dpni_cfg {
	uint8_t mac_addr[6];
	struct {
		uint32_t options;
		enum net_prot start_hdr;
		uint8_t max_senders;
		uint8_t max_tcs;
		uint8_t max_rx_tcs;
		uint8_t max_unicast_filters;
		uint8_t max_multicast_filters;
		uint8_t max_vlan_filters;
		uint8_t max_qos_entries;
		uint8_t max_qos_key_size;
		uint8_t max_dist_key_size;
		uint8_t max_policers;
		uint8_t max_congestion_ctrl;
		uint8_t shared_congestion;
		uint8_t default_pps;
		struct dpni_extended_cfg ext_cfg;
		uint64_t ext_cfg_iova;
		uint8_t single_sender;
		uint16_t max_opr;
		uint8_t num_ceetm_ch;
	} adv;
};


/* DPNI Create - v1 */
#define DPNI_OPT_V1_TX_FRM_RELEASE			0x00000001
#define DPNI_OPT_V1_NO_MAC_FILTER			0x00000002
#define DPNI_OPT_V1_HAS_POLICING			0x00000004
#define DPNI_OPT_V1_SHARED_CONGESTION		0x00000008
#define DPNI_OPT_V1_HAS_KEY_MASKING			0x00000010
#define DPNI_OPT_V1_NO_FS					0x00000020
#define DPNI_OPT_V1_HAS_OPR					0x00000040
#define DPNI_OPT_V1_OPR_PER_TC				0x00000080
#define DPNI_OPT_V1_SINGLE_SENDER			0x00000100
#define DPNI_OPT_V1_CUSTOM_CG				0x00000200
#define DPNI_OPT_V1_CUSTOM_OPR				0x00000400
#define DPNI_OPT_V5_SHARED_HASH_KEY			0x00000800
#define DPNI_OPT_V5_SHARED_FS				0x00001000
#define DPNI_OPT_V1_PFDR_IN_PEB				0x80000000

struct dpni_cfg_v1 {
	uint32_t options;
	uint16_t fs_entries;
	uint8_t  vlan_filter_entries;
	uint8_t  mac_filter_entries;
	uint8_t  num_queues;
	uint8_t  num_tcs;
	uint8_t  num_rx_tcs;
	uint8_t  qos_entries;
	uint8_t  default_pps;
	uint8_t  num_cgs;
	uint16_t  num_opr;
	uint8_t  dist_key_size;
	uint8_t  num_ceetm_ch;
};

int dpni_create(struct dpni *dpni, const struct dpni_cfg *cfg);

void dpni_destroy(struct dpni *dpni);

#define DPNI_IRQ_INDEX				0
#define DPNI_IRQ_EVENT_LINK_CHANGED		0x00000001
#define DPNI_IRQ_EVENT_ENDPOINT_CHANGED	0x00000002

int dpni_set_irq(struct dpni *dpni,
	uint8_t irq_index,
	const struct mc_irq_cfg *irq_cfg);

int dpni_get_irq(struct dpni *dpni,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg);

int dpni_set_irq_enable(struct dpni *dpni, uint8_t irq_index, uint8_t en);

int dpni_get_irq_enable(struct dpni *dpni, uint8_t irq_index, uint8_t *en);

int dpni_set_irq_mask(struct dpni *dpni, uint8_t irq_index, uint32_t mask);

int dpni_get_irq_mask(struct dpni *dpni, uint8_t irq_index, uint32_t *mask);

int dpni_get_irq_status(struct dpni *dpni, uint8_t irq_index, uint32_t *status);

int dpni_clear_irq_status(struct dpni *dpni,
	uint8_t irq_index,
	uint32_t status);

struct dpni_pools_cfg {
	uint8_t num_dpbp;
	uint8_t pool_options;
	struct {
		int dpbp_id;
		uint8_t priority;
		uint16_t buffer_size;
		int backup_pool;
	} pools[DPNI_MAX_DPBP];
};

int dpni_set_pools(struct dpni *dpni, struct dpni_pools_cfg *cfg);

int dpni_enable(struct dpni *dpni);

int dpni_disable(struct dpni *dpni);

int dpni_is_enabled(struct dpni *dpni, int *en);

int dpni_reset(struct dpni *dpni);

int dpni_restore_after_eiop_reset(struct dpni *dpni);

int dpni_graceful_stop(struct dpni *dpni);

int dpni_empty_check(struct dpni *dpni);

int dpni_resume(struct dpni *dpni);

int dpni_errata_check(struct dpni *dpni, uint32_t depleton_wait_us);

/* DPNI Get Attributes - v0 */

struct dpni_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
	enum net_prot start_hdr;
	uint32_t options;
	uint8_t max_senders;
	uint8_t max_rx_tcs;
	uint8_t max_tx_tcs;
	uint8_t max_unicast_filters;
	uint8_t max_multicast_filters;
	uint8_t max_vlan_filters;
	uint8_t max_qos_entries;
	uint8_t max_qos_key_size;
	uint8_t actual_qos_key_size;
	uint8_t max_dist_key_size;
	uint8_t max_policers;
	uint8_t max_congestion_ctrl;
	struct dpni_extended_cfg ext_cfg;
	uint64_t ext_cfg_iova;
	uint16_t wriop_version;
	uint8_t shared_congestion;
	uint8_t num_cgid;
	uint8_t num_ceetm_ch;
	uint16_t max_opr;
};

int dpni_get_attributes(struct dpni *dpni, struct dpni_attr *attr);

/* DPNI Get Attributes - v1 */
struct dpni_attr_v1 {
	uint32_t options;
	uint8_t  num_queues;
	uint8_t  num_rx_tcs;
	uint8_t  num_tx_tcs;
	uint8_t  mac_filter_entries;
	uint8_t  vlan_filter_entries;
	uint8_t  qos_entries;
	uint16_t fs_entries;
	uint8_t  qos_key_size;
	uint8_t  fs_key_size;
	uint16_t wriop_version;
	uint8_t  num_cgid;
	uint8_t  num_ceetm_ch;
	uint16_t num_opr;
};

#define DPNI_ERROR_DISC		0x80000000
#define DPNI_ERROR_EOFHE	0x00020000
#define DPNI_ERROR_FLE		0x00002000
#define DPNI_ERROR_FPE		0x00001000
#define DPNI_ERROR_PHE		0x00000020
#define DPNI_ERROR_L3CE		0x00000004
#define DPNI_ERROR_L4CE		0x00000001

enum dpni_error_action {
	DPNI_ERROR_ACTION_DISCARD = 0,
	DPNI_ERROR_ACTION_CONTINUE = 1,
	DPNI_ERROR_ACTION_SEND_TO_ERROR_QUEUE = 2
};

struct dpni_error_cfg {
	uint32_t errors;
	enum dpni_error_action error_action;
	int set_frame_annotation;
};

int dpni_set_errors_behavior(struct dpni *dpni, struct dpni_error_cfg *cfg);

#define DPNI_BUF_LAYOUT_OPT_TIMESTAMP			0x00000001
#define DPNI_BUF_LAYOUT_OPT_PARSER_RESULT		0x00000002
#define DPNI_BUF_LAYOUT_OPT_FRAME_STATUS		0x00000004
#define DPNI_BUF_LAYOUT_OPT_PRIVATE_DATA_SIZE	0x00000008
#define DPNI_BUF_LAYOUT_OPT_DATA_ALIGN			0x00000010
#define DPNI_BUF_LAYOUT_OPT_DATA_HEAD_ROOM		0x00000020
#define DPNI_BUF_LAYOUT_OPT_DATA_TAIL_ROOM		0x00000040
#define DPNI_BUF_LAYOUT_OPT_SW_OPAQUE			0x00000080
#define DPNI_BUF_LAYOUT_OPT_NO_SG				0x00000100

struct dpni_buffer_layout {
	uint32_t options;
	int pass_timestamp;
	int pass_parser_result;
	int pass_frame_status;
	int pass_sw_opaque;
	uint16_t private_data_size;
	uint16_t data_align;
	uint16_t data_head_room;
	uint16_t data_tail_room;
};

int dpni_get_rx_buffer_layout(struct dpni *dpni,
	struct dpni_buffer_layout *layout);

int dpni_set_rx_buffer_layout(struct dpni *dpni,
	const struct dpni_buffer_layout *layout);

int dpni_get_tx_buffer_layout(struct dpni *dpni,
	struct dpni_buffer_layout *layout);

int dpni_set_tx_buffer_layout(struct dpni *dpni,
	const struct dpni_buffer_layout *layout);

int dpni_get_tx_conf_buffer_layout(struct dpni *dpni,
	struct dpni_buffer_layout *layout);

int dpni_set_tx_conf_buffer_layout(struct dpni *dpni,
	const struct dpni_buffer_layout *layout);

enum dpni_queue_type {
	DPNI_QUEUE_RX, DPNI_QUEUE_TX, DPNI_QUEUE_TX_CONFIRM, DPNI_QUEUE_RX_ERR,
#ifdef MC_CLI
    DPNI_REAL_QUEUE_RX, DPNI_REAL_QUEUE_TX,
#endif
};

int dpni_set_buffer_layout(struct dpni *dpni, enum dpni_queue_type qtype,
		const struct dpni_buffer_layout *layout);
int dpni_get_buffer_layout(struct dpni *dpni, enum dpni_queue_type qtype,
		struct dpni_buffer_layout *layout);

int dpni_set_l3_chksum_validation(struct dpni *dpni, int en);

int dpni_get_l3_chksum_validation(struct dpni *dpni, int *en);

int dpni_set_l4_chksum_validation(struct dpni *dpni, int en);

int dpni_get_l4_chksum_validation(struct dpni *dpni, int *en);

enum dpni_offload {
	DPNI_OFF_RX_L3_CSUM,
	DPNI_OFF_RX_L4_CSUM,
	DPNI_OFF_TX_L3_CSUM,
	DPNI_OFF_TX_L4_CSUM,
	DPNI_FLCTYPE_HASH,
	DPNI_HEADER_STASHING,
	DPNI_PAYLOAD_STASHING,
};

int dpni_set_offload(struct dpni *dpni, enum dpni_offload type,
		uint32_t config);
int dpni_get_offload(struct dpni *dpni, enum dpni_offload type,
		uint32_t *config);
int dpni_get_qdid(struct dpni *dpni, enum dpni_queue_type qtype,
		uint16_t *qdid);
int dpni_get_qdid_ex(struct dpni *dpni, enum dpni_queue_type qtype,
		uint16_t *qdid);

struct dpni_sp_info {
	uint16_t spids[DPNI_MAX_SP];
};

int dpni_get_sp_info(struct dpni *dpni, struct dpni_sp_info *sp_info);

int dpni_get_tx_data_offset(struct dpni *dpni, uint16_t *data_offset);

enum dpni_counter {
	DPNI_CNT_ING_FRAME = 0x0,
	DPNI_CNT_ING_BYTE = 0x1,
	DPNI_CNT_ING_FRAME_DROP = 0x2,
	DPNI_CNT_ING_FRAME_DISCARD = 0x3,
	DPNI_CNT_ING_MCAST_FRAME = 0x4,
	DPNI_CNT_ING_MCAST_BYTE = 0x5,
	DPNI_CNT_ING_BCAST_FRAME = 0x6,
	DPNI_CNT_ING_BCAST_BYTES = 0x7,
	DPNI_CNT_EGR_FRAME = 0x8,
	DPNI_CNT_EGR_BYTE = 0x9,
	DPNI_CNT_EGR_FRAME_DISCARD = 0xa,
	DPNI_CNT_ING_NO_BUFFER_DISCARD = 0xb,
	DPNI_CNT_EGR_FRAME_CONFIRMED = 0xc,
	DPNI_CNT_EGR_MCAST_FRAME = 0xd,
	DPNI_CNT_EGR_MCAST_BYTE = 0xe,
	DPNI_CNT_EGR_BCAST_FRAME = 0xf,
	DPNI_CNT_EGR_BCAST_BYTES = 0x10,
};

int dpni_get_counter(struct dpni *dpni,
	enum dpni_counter counter,
	uint64_t *value);

int dpni_set_counter(struct dpni *dpni,
	enum dpni_counter counter,
	uint64_t value);

#define DPNI_STATISTICS_CNT		7
union dpni_statistics {
	struct {
		uint64_t ingress_all_frames;
		uint64_t ingress_all_bytes;
		uint64_t ingress_multicast_frames;
		uint64_t ingress_multicast_bytes;
		uint64_t ingress_broadcast_frames;
		uint64_t ingress_broadcast_bytes;
	} page_0;
	struct {
		uint64_t egress_all_frames;
		uint64_t egress_all_bytes;
		uint64_t egress_multicast_frames;
		uint64_t egress_multicast_bytes;
		uint64_t egress_broadcast_frames;
		uint64_t egress_broadcast_bytes;
	} page_1;
	struct {
		uint64_t ingress_filtered_frames;
		uint64_t ingress_discarded_frames;
		uint64_t ingress_nobuffer_discards;
		uint64_t egress_discarded_frames;
		uint64_t egress_confirmed_frames;
	} page_2;
	struct {
		uint64_t ceetm_dequeue_bytes;
		uint64_t ceetm_dequeue_frames;
		uint64_t ceetm_reject_bytes;
		uint64_t ceetm_reject_frames;
	} page_3;
	struct {
		uint64_t cgr_reject_frames;
		uint64_t cgr_reject_bytes;
	} page_4;
	struct {
		uint64_t policer_cnt_red;
		uint64_t policer_cnt_yellow;
		uint64_t policer_cnt_green;
		uint64_t policer_cnt_re_red;
		uint64_t policer_cnt_re_yellow;
	} page_5;
	struct {
		uint64_t tx_pending_frames_cnt;
	} page_6;
	struct {
		uint64_t counter[DPNI_STATISTICS_CNT];
	} raw;
};

int dpni_get_statistics(struct dpni *dpni, uint8_t page,
		union dpni_statistics *stats, uint16_t param);
int dpni_reset_statistics(struct dpni *dpni);


#define DPNI_LINK_OPT_AUTONEG		0x0000000000000001ULL
#define DPNI_LINK_OPT_HALF_DUPLEX	0x0000000000000002ULL
#define DPNI_LINK_OPT_PAUSE			0x0000000000000004ULL
#define DPNI_LINK_OPT_ASYM_PAUSE	0x0000000000000008ULL
#define DPNI_LINK_OPT_PFC_PAUSE 	0x0000000000000010ULL

#define DPNI_ADVERTISED_10BASET_FULL		0x0000000000000001ULL
#define DPNI_ADVERTISED_100BASET_FULL		0x0000000000000002ULL
#define DPNI_ADVERTISED_1000BASET_FULL		0x0000000000000004ULL
#define DPNI_ADVERTISED_AUTONEG				0x0000000000000008ULL
#define DPNI_ADVERTISED_10000BASET_FULL		0x0000000000000010ULL
#define DPNI_ADVERTISED_2500BASEX_FULL		0x0000000000000020ULL
#define DPNI_ADVERTISED_5000BASET_FULL		0x0000000000000040ULL

#define DPNI_ADVERTISED_MASK					0x3f

struct dpni_link_cfg {
	uint32_t rate;
	uint64_t options;
	uint64_t advertising;
};

int dpni_set_link_cfg(struct dpni *dpni, const struct dpni_link_cfg *cfg);
int dpni_get_link_cfg(struct dpni *dpni, struct dpni_link_cfg *cfg);

struct dpni_link_state {
	uint32_t rate;
	uint64_t options;
	int up;
	int state_valid;
	uint64_t supported;
	uint64_t advertising;
};

int dpni_get_link_state(struct dpni *dpni, struct dpni_link_state *state);

struct dpni_tx_shaping_cfg {
	uint32_t rate_limit;
	uint32_t max_burst_size;
};

int dpni_set_tx_shaping(struct dpni *dpni, const int ceetm_ch_idx,
	const struct dpni_tx_shaping_cfg *tx_cr_shaper,
	const struct dpni_tx_shaping_cfg *tx_er_shaper,
	const int shaper_coupling, const int lni_shaping, const uint16_t oal);

int dpni_set_max_frame_length(struct dpni *dpni, uint16_t max_frame_length);

int dpni_get_max_frame_length(struct dpni *dpni, uint16_t *max_frame_length);

int dpni_set_mtu(struct dpni *dpni, uint16_t mtu);

int dpni_get_mtu(struct dpni *dpni, uint16_t *mtu);

int dpni_set_multicast_promisc(struct dpni *dpni, int en);

int dpni_get_multicast_promisc(struct dpni *dpni, int *en);

int dpni_set_unicast_promisc(struct dpni *dpni, int en);

int dpni_get_unicast_promisc(struct dpni *dpni, int *en);

int dpni_set_primary_mac_addr(struct dpni *dpni, const uint8_t mac_addr[6]);

int dpni_get_primary_mac_addr(struct dpni *dpni, uint8_t mac_addr[6]);

int dpni_get_port_mac_addr(struct dpni *dpni, uint8_t addr[6]);

struct dpni_mac_action_cfg{
	uint8_t flags;
	uint8_t tc_id;
	uint8_t fq_id;
};

int dpni_add_mac_addr_action(struct dpni *dpni, const uint8_t addr[6], struct dpni_mac_action_cfg action_cfg);

int dpni_add_mac_addr(struct dpni *dpni, const uint8_t mac_addr[6]);

int dpni_remove_mac_addr(struct dpni *dpni, const uint8_t mac_addr[6]);

int dpni_clear_mac_filters(struct dpni *dpni, int unicast, int multicast);

int dpni_enable_vlan_filter(struct dpni *dpni, int en);

int dpni_add_vlan_id(struct dpni *dpni, uint16_t vlan_id);

int dpni_add_vlan_id_action(struct dpni *dpni, uint16_t vlan_id, uint8_t tc_id, uint8_t flow_id);

int dpni_remove_vlan_id(struct dpni *dpni, uint16_t vlan_id);

int dpni_clear_vlan_filters(struct dpni *dpni);

#if 0
/**
 * struct dpni_congestion_count_update_cfg - count-update configuration
 * @units: units type
 * @boundary: power-of-2 value; each time the counter cross this value
 * 	a write attempt will occur; fixed threshold of minus 1/16th of the
 * 	boundary is used to provide hysteresis;
 * 	For example, setting it to 2K will cause a write to occur whenever the
 * 	counter crosses a 2K (2048) boundary, with a hysteresis threshold of
 * 	128, so when the counter is increasing a write will occur when the
 * 	counter crosses the values 2048, 4096, 6144, and so on, and when the
 * 	counter is decreasing a write will occur when the counter crosses the
 * 	values 6016, 3968, 1920, and when it reaches 0.
 * @message_iova: MUST be given if 'boundary' is not '0' (enable);
 * 	I/O virtual address (must be in DMA-able memory), must be 16B aligned.
 * @coherent_write: if '1' the message write will attempt to allocate into
 * 	a cache (coherent write). */
struct dpni_congestion_count_update_cfg {
	enum dpni_congestion_count_unit units;
	uint32_t boundary;
	uint64_t message_iova;
	int coherent_write;
};

/**
 * dpni_set_tx_tc_count_update() - Set Tx traffic class count update configuration
 * @mc_io:	Pointer to MC portal's I/O object
 * @cmd_flags:	Command flags; one or more of 'MC_CMD_FLAG_'
 * @token:	Token of DPNI object
 * @tc_id:	Traffic class selection (0-7)
 * @cfg:  	count update configuration
 *
 * Return:	'0' on Success; error code otherwise.
 */
int dpni_set_tx_tc_count_update(struct fsl_mc_io *mc_io,
	uint32_t cmd_flags,
	uint16_t token,
	uint8_t tc_id,
	const struct dpni_congestion_count_update_cfg *cfg);
#endif
enum dpni_tx_schedule_mode {
	DPNI_TX_SCHED_STRICT_PRIORITY = 0, DPNI_TX_SCHED_WEIGHTED_A, DPNI_TX_SCHED_WEIGHTED_B,
};

struct dpni_tx_schedule_cfg {
	enum dpni_tx_schedule_mode mode;
	uint16_t delta_bandwidth;
};

struct dpni_tx_priorities {
	struct dpni_tx_schedule_cfg tc_sched[DPNI_MAX_TX_TC+DPNI_MAX_RX_TC];
	uint8_t prio_group_A;
	uint8_t prio_group_B;
	uint8_t separate_groups;
};

int dpni_set_tx_priorities(struct dpni *dpni, int ceetm_ch_id,
	const struct dpni_tx_priorities *cfg);

enum dpni_dist_mode {
	DPNI_DIST_MODE_NONE = 0, DPNI_DIST_MODE_HASH = 1, DPNI_DIST_MODE_FS = 2
};

enum dpni_fs_miss_action {
	DPNI_FS_MISS_DROP = 0,
	DPNI_FS_MISS_EXPLICIT_FLOWID = 1,
	DPNI_FS_MISS_HASH = 2
};

struct dpni_fs_tbl_cfg {
	enum dpni_fs_miss_action miss_action;
	uint16_t default_flow_id;
	char keep_hash_key;
	uint8_t keep_entries;
};

struct dpni_rx_tc_dist_cfg {
	uint16_t dist_size;
	enum dpni_dist_mode dist_mode;
	struct dpkg_profile_cfg *dist_key_cfg;
	struct dpni_fs_tbl_cfg fs_cfg;

	uint64_t key_cfg_iova;
};

int dpni_set_rx_tc_dist(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_dist_cfg *cfg);

#define DPNI_POLICER_OPT_COLOR_AWARE	0x00000001
#define DPNI_POLICER_OPT_DISCARD_RED	0x00000002

enum dpni_policer_mode {
	DPNI_POLICER_MODE_NONE = 0,
	DPNI_POLICER_MODE_PASS_THROUGH,
	DPNI_POLICER_MODE_RFC_2698,
	DPNI_POLICER_MODE_RFC_4115
};

enum dpni_policer_unit {
	DPNI_POLICER_UNIT_BYTES = 0, DPNI_POLICER_UNIT_PACKETS
};

enum dpni_policer_color {
	DPNI_POLICER_COLOR_GREEN = 0,
	DPNI_POLICER_COLOR_YELLOW,
	DPNI_POLICER_COLOR_RED
};

struct dpni_rx_tc_policing_cfg {
	uint32_t options;
	enum dpni_policer_mode mode;
	enum dpni_policer_unit units;
	enum dpni_policer_color default_color;
	uint32_t cir;
	uint32_t cbs;
	uint32_t eir;
	uint32_t ebs;
};

int dpni_set_rx_tc_policing(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rx_tc_policing_cfg *cfg);

int dpni_get_rx_tc_policing(struct dpni *dpni,
	uint8_t tc_id,
	struct dpni_rx_tc_policing_cfg *cfg);

#ifdef MC_CLI
struct dpni_metering_counters {
   uint32_t red;
   uint32_t yellow;
   uint32_t green;     
};

int dpni_get_metering(struct dpni *dpni, 
        uint8_t tc_id,
        struct dpni_metering_counters *counters);
#endif

enum dpni_congestion_unit {
	DPNI_CONGESTION_UNIT_BYTES = 0, DPNI_CONGESTION_UNIT_FRAMES
};

enum dpni_early_drop_mode {
	DPNI_EARLY_DROP_MODE_NONE = 0,
	DPNI_EARLY_DROP_MODE_TAIL,
	DPNI_EARLY_DROP_MODE_WRED
};

struct dpni_wred_cfg {
	uint64_t max_threshold;
	uint64_t min_threshold;
	uint8_t drop_probability;
};

struct dpni_early_drop_cfg {
	enum dpni_congestion_unit units;
	
	uint8_t dpni_wred_enable;
	struct dpni_wred_cfg green;
	struct dpni_wred_cfg yellow;
	struct dpni_wred_cfg red;

	uint8_t dpni_tail_drop_enable;
	uint32_t tail_drop_threshold;
	int16_t oal;
};

int dpni_set_rx_tc_early_drop(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_early_drop_cfg *cfg);

int dpni_get_rx_tc_early_drop(struct dpni *dpni,
	uint8_t tc_id,
	struct dpni_early_drop_cfg *cfg);

int dpni_set_tx_tc_early_drop(struct dpni *dpni, int ceetm_ch_idx,
	uint8_t tc_id,
	const struct dpni_early_drop_cfg *cfg);

int dpni_get_tx_tc_early_drop(struct dpni *dpni, int ceem_ch_idx,
	uint8_t tc_id,
	struct dpni_early_drop_cfg *cfg);

int dpni_set_early_drop(struct dpni *dpni, int ceetm_ch_idx, enum dpni_queue_type qtype,
		uint8_t tc, const struct dpni_early_drop_cfg *cfg);

int dpni_get_early_drop(struct dpni *dpni, int ceem_ch_idx, enum dpni_queue_type qtype,
		uint8_t tc, struct dpni_early_drop_cfg *cfg);

enum dpni_dest {
	DPNI_DEST_NONE = 0, DPNI_DEST_DPIO = 1, DPNI_DEST_DPCON = 2
};

struct dpni_dest_cfg {
	enum dpni_dest dest_type;
	uint32_t dest_id;
	uint8_t priority;
};

#define DPNI_CGN_MODE_WRITE_MEM_ON_ENTER	0x00000001
#define DPNI_CGN_MODE_WRITE_MEM_ON_EXIT		0x00000002
#define DPNI_CGN_MODE_COHERENT_WRITE		0x00000004
#define DPNI_CGN_MODE_NOTIFY_DEST_ON_ENTER	0x00000008
#define DPNI_CGN_MODE_NOTIFY_DEST_ON_EXIT	0x00000010
#define DPNI_CGN_MODE_INTR_COALESCING_DISABLED	0x00000020
#define DPNI_CGN_MODE_FLOW_CONTROL		0x00000040
#define DPNI_CGN_NOTIFY_AIOP_DCP		0x00000080
#define DPNI_CGN_NOTIFY_WRIOP_DCP		0x00000100

struct dpni_congestion_notification_cfg {
	enum dpni_congestion_unit units;
	uint32_t threshold_entry;
	uint32_t threshold_exit;
	uint64_t message_ctx;
	uint64_t message_iova;
	struct dpni_dest_cfg dest_cfg;
	uint16_t notification_mode;
};

int dpni_set_rx_tc_congestion_notification(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_congestion_notification_cfg *cfg);

int dpni_get_rx_tc_congestion_notification(struct dpni *dpni,
	uint8_t tc_id,
	struct dpni_congestion_notification_cfg *cfg);

int dpni_get_rx_cgid_congestion_notification(struct dpni *dpni,
	int cgid_index,
	struct dpni_congestion_notification_cfg *cfg);

int dpni_set_tx_tc_congestion_notification(struct dpni *dpni, int ceetm_ch_idx,
	uint8_t tc_id,
	const struct dpni_congestion_notification_cfg *cfg);

int dpni_get_tx_tc_congestion_notification(struct dpni *dpni, int ceet_ch_idx,
	uint8_t tc_id,
	struct dpni_congestion_notification_cfg *cfg);

enum dpni_congestion_point {
	DPNI_CP_QUEUE,
	DPNI_CP_GROUP,
	DPNI_CP_CONGESTION_GROUP,
};

int dpni_set_congestion_notification(struct dpni *dpni, int ceetm_ch_idx,
		enum dpni_queue_type qtype, uint8_t tc,
		const struct dpni_congestion_notification_cfg *cfg,
		enum dpni_congestion_point cp, int cgi);
int dpni_get_congestion_notification(struct dpni *dpni, int ceet_ch_idx,
		enum dpni_queue_type qtype, uint8_t tc,
		struct dpni_congestion_notification_cfg *cfg,
		enum dpni_congestion_point cp, int cgid);

enum dpni_flc_type {
	DPNI_FLC_USER_DEFINED = 0, DPNI_FLC_STASH = 1,
};

enum dpni_stash_size {
	DPNI_STASH_SIZE_0B = 0,
	DPNI_STASH_SIZE_64B = 1,
	DPNI_STASH_SIZE_128B = 2,
	DPNI_STASH_SIZE_192B = 3,
};

#define DPNI_FLC_STASH_FRAME_ANNOTATION	0x00000001

struct dpni_flc_cfg {
	enum dpni_flc_type flc_type;
	uint32_t options;
	enum dpni_stash_size frame_data_size;
	enum dpni_stash_size flow_context_size;
	uint64_t flow_context;
};

#define DPNI_QUEUE_OPT_USER_CTX		0x00000001
#define DPNI_QUEUE_OPT_DEST		0x00000002
#define DPNI_QUEUE_OPT_FLC		0x00000004
#define DPNI_QUEUE_OPT_ORDER_PRESERVATION	0x00000008
#define DPNI_QUEUE_OPT_TAILDROP_THRESHOLD	0x00000010
#define DPNI_QUEUE_OPT_TAILDROP_OAL			0x00000020
#define DPNI_QUEUE_OPT_SET_CGID				0x00000040
#define DPNI_QUEUE_OPT_CLEAR_CGID			0x00000080

struct dpni_queue_cfg {
	uint32_t options;
	uint64_t user_ctx;
	uint64_t flc;
	struct dpni_dest_cfg dest_cfg;
	struct dpni_flc_cfg flc_cfg;
	int order_preservation_en;
	uint32_t tail_drop_threshold;
	int16_t oal;
	uint8_t cgid_index;
};

struct dpni_queue_attr {
	uint64_t user_ctx;
	struct dpni_dest_cfg dest_cfg;
	struct dpni_flc_cfg flc_cfg;
	int order_preservation_en;
	uint32_t tail_drop_threshold;
	int16_t oal;

	uint32_t fqid;
	int cgid_index;
};

#define DPNI_TX_FLOW_OPT_TX_CONF_ERROR	0x00000001
#define DPNI_TX_FLOW_OPT_L3_CHKSUM_GEN	0x00000010
#define DPNI_TX_FLOW_OPT_L4_CHKSUM_GEN	0x00000020

struct dpni_tx_flow_cfg {
	uint32_t options;
	int use_common_tx_conf_queue;
	int l3_chksum_gen;
	int l4_chksum_gen;
};

int dpni_set_tx_flow(struct dpni *dpni,
	int ceetm_ch_idx, uint16_t *flow_id,
	const struct dpni_tx_flow_cfg *cfg);

struct dpni_tx_flow_attr {
	int use_common_tx_conf_queue;
	int l3_chksum_gen;
	int l4_chksum_gen;
};

int dpni_get_tx_flow(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	struct dpni_tx_flow_attr *attr);

struct dpni_tx_conf_cfg {
	int errors_only;
	struct dpni_queue_cfg queue_cfg;
};

int dpni_set_tx_conf(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	const struct dpni_tx_conf_cfg *cfg);

struct dpni_tx_conf_attr {
	int errors_only;
	struct dpni_queue_attr queue_attr;
};

int dpni_get_tx_conf(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	struct dpni_tx_conf_attr *attr);

int dpni_set_tx_conf_congestion_notification(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	const struct dpni_congestion_notification_cfg *cfg);

int dpni_get_tx_conf_congestion_notification(struct dpni *dpni, int ceetm_ch_idx,
	uint16_t flow_id,
	struct dpni_congestion_notification_cfg *cfg);

int dpni_set_tx_conf_revoke(struct dpni *dpni, int ceetm_ch_idx, int revoke);

int dpni_set_rx_flow(struct dpni *dpni,
	uint8_t tc_id,
	uint16_t flow_id,
	const struct dpni_queue_cfg *cfg);

int dpni_get_rx_flow(struct dpni *dpni,
	uint8_t tc_id,
	uint16_t flow_id,
	struct dpni_queue_attr *attr);

int dpni_set_rx_err_queue(struct dpni *dpni, const struct dpni_queue_cfg *cfg);

int dpni_get_rx_err_queue(struct dpni *dpni, struct dpni_queue_attr *attr);

/* queue API - V1 */

struct dpni_queue {
	struct {
		uint32_t id;
		enum dpni_dest type;
		char hold_active;
		uint8_t priority;
	} destination;
	uint64_t user_context;
	struct {
		uint64_t value;
		char stash_control;
	} flc;
};

struct dpni_queue_id {
	uint32_t fqid;
	uint16_t qdbin;
};

int dpni_get_queue(struct dpni *dpni, int ceetm_ch_idx, enum dpni_queue_type qtype, uint8_t tc,
		uint8_t index, struct dpni_queue *queue,
		struct dpni_queue_id *qid, int *cgid);
int dpni_set_queue(struct dpni *dpni, int ceetm_ch_idx, enum dpni_queue_type qtype, uint8_t tc,
		uint8_t index, uint8_t options, struct dpni_queue *queue, uint8_t cgid);


struct dpni_qos_tbl_cfg {
	struct dpkg_profile_cfg *qos_key_cfg;
	int discard_on_miss;
	uint8_t default_tc;
	/*!< Used in case of no-match and 'discard_on_miss'= 0 */
	uint64_t key_cfg_iova;
	int keep_entries;
};

int dpni_set_qos_table(struct dpni *dpni, const struct dpni_qos_tbl_cfg *cfg);

struct dpni_rule_cfg {
	uint8_t * key;
	uint8_t * mask;
	uint8_t size;
};

#define DPNI_FS_OPT_DISCARD		0x1
#define DPNI_FS_OPT_SET_FLC		0x2
#define DPNI_FS_OPT_SET_STASH_CONTROL	0x4
#define DPNI_FS_OPT_REDIRECT_TO_DPNI_RX		0x08
#define DPNI_FS_OPT_REDIRECT_TO_DPNI_TX		0x10

struct dpni_fs_action_cfg {
	uint64_t flc;
	uint16_t flow_id;
	uint16_t options;
	uint16_t redirect_obj_token;
};

#define DPNI_QOS_OPT_SET_TC_ONLY 0x0
#define DPNI_QOS_OPT_SET_FLOW_ID 0x1

int dpni_add_qos_entry_v0(struct dpni *dpni,
	const struct dpni_rule_cfg *cfg,
	uint8_t tc_id);
int dpni_add_qos_entry_v1(struct dpni *dpni,
	uint16_t entry_index,
	const struct dpni_rule_cfg *cfg,
	uint8_t tc_id, uint8_t flags, uint8_t flow_id);

int dpni_remove_qos_entry(struct dpni *dpni, const struct dpni_rule_cfg *cfg);

int dpni_clear_qos_table(struct dpni *dpni);

int dpni_add_fs_entry_v0(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rule_cfg *cfg,
	uint16_t flow_id);
int dpni_add_fs_entry_v1(struct dpni *dpni,
	uint8_t tc_id,
	uint16_t entry_index,
	const struct dpni_rule_cfg *rule,
	const struct dpni_fs_action_cfg *action);

int dpni_remove_fs_entry(struct dpni *dpni,
	uint8_t tc_id,
	const struct dpni_rule_cfg *rule);

int dpni_clear_fs_entries(struct dpni *dpni, uint8_t tc_id);

int dpni_set_vlan_insertion(struct dpni *dpni, int en);
int dpni_set_vlan_removal(struct dpni *dpni, int en);
int dpni_set_ipr(struct dpni *dpni, int en);
int dpni_set_ipf(struct dpni *dpni, int en);
int dpni_set_ipsec(struct dpni *dpni, int en);

#define DPNI_IPSEC_SA_TRANSPORT				1
#define DPNI_IPSEC_SA_TUNNEL				2

#define DPNI_IPSEC_CIPHER_NULL				0
#define DPNI_IPSEC_CIPHER_DES				2
#define DPNI_IPSEC_CIPHER_DES_IV64			3
#define DPNI_IPSEC_CIPHER_3DES				4
#define DPNI_IPSEC_CIPHER_AES_CBC			5
#define DPNI_IPSEC_CIPHER_AES_CTR			6
#define DPNI_IPSEC_CIPHER_AES_CCM8			7
#define DPNI_IPSEC_CIPHER_AES_CCM12			8
#define DPNI_IPSEC_CIPHER_AES_CCM16			9
#define DPNI_IPSEC_CIPHER_AES_GCM8			10
#define DPNI_IPSEC_CIPHER_AES_GCM12			11
#define DPNI_IPSEC_CIPHER_AES_GCM16			12
#define DPNI_IPSEC_CIPHER_AES_NULL_WITH_GMAC		13

#define DPNI_IPSEC_AUTH_NULL				0
#define DPNI_IPSEC_AUTH_HMAC_MD5_96		 	21
#define DPNI_IPSEC_AUTH_HMAC_SHA1_96			22
#define DPNI_IPSEC_AUTH_AES_XCBC_MAC_96			23
#define DPNI_IPSEC_AUTH_HMAC_MD5_128			24
#define DPNI_IPSEC_AUTH_HMAC_SHA1_160			25
#define DPNI_IPSEC_AUTH_AES_CMAC_96			26
#define DPNI_IPSEC_AUTH_HMAC_SHA2_256_128		27
#define DPNI_IPSEC_AUTH_HMAC_SHA2_384_192		28
#define DPNI_IPSEC_AUTH_HMAC_SHA2_512_256		29

/* IPSEC SA options */
#define DPNI_IPSEC_SA_OPT_EXT_SEQ_NUM		0x00000001
#define DPNI_IPSEC_SA_OPT_RND_GEN_IV		0x00000002
#define DPNI_IPSEC_SA_OPT_IPV6				0x00000004
#define DPNI_IPSEC_SA_COPY_INNER_DF			0x00000008
#define DPNI_IPSEC_SA_CFG_DSCP 				0x00000010

#define DPNI_IPSEC_SA_OUT			1
#define DPNI_IPSEC_SA_IN			2

/* Anti replay window size */
#define DPNI_IPSEC_SA_ANTI_REPLAY_NONE		0
#define DPNI_IPSEC_SA_ANTI_REPLAY_WS_32		2
#define DPNI_IPSEC_SA_ANTI_REPLAY_WS_64		3
#define DPNI_IPSEC_SA_ANTI_REPLAY_WS_128	4

struct dpni_ipsec_sa_in_cfg {
	uint8_t ip_src[16]; /* IP source for SA selection; required
	 only if DPNI_IPSEC_MATCH_IP_SRC is set;
	 Size of address depends on the setting of
	 DPNI_IPSEC_SA_OPT_IPV6. */
	uint8_t ip_dst[16]; /* IP destination for SA selection; required
	 only if DPNI_IPSEC_MATCH_IP_SRC is set;
	 Size of address depends on the setting of
	 DPNI_IPSEC_SA_OPT_IPV6. */
	uint8_t anti_replay; /* anti replay configuration */
};

struct dpni_ipsec_sa_out_cfg {
	uint16_t frag_size;
	uint16_t outer_hdr_size; /**< Outer Header length in bytes
	 (tunnel mode only).*/
	uint64_t outer_hdr_paddr; /**< Outer header content (tunnel mode only)*/
};

struct dpni_ipsec_cipher_cfg {
	uint8_t alg;
	uint8_t iv[16];
	uint8_t nonce_or_salt[4];
	uint8_t key_size;
	uint64_t key_paddr; /* up to 64 byte key */
};

struct dpni_ipsec_auth_cfg {
	uint8_t alg;
	uint8_t key_size;
	uint64_t key_paddr; /* up to 32 byte key */
};

struct dpni_ipsec_sa_lifetime_limits {
	uint64_t soft_kb; /**< Soft Kilobytes limit, in bytes. */
	uint64_t hard_kb; /**< Hard Kilobytes limit, in bytes. */
	uint64_t soft_packet; /**< Soft Packet count limit. */
	uint64_t hard_packet; /**< Hard Packet count limit. */
	uint32_t soft_sec; /**< Soft Seconds limit. */
	uint32_t hard_sec; /**< Hard Second limit. */
};

struct dpni_ipsec_sa_cfg {
	uint32_t options;
	uint32_t spi;
	uint32_t seq_num;
	uint32_t seq_num_ext;
	uint8_t mode;
	uint8_t direction;
	struct dpni_ipsec_sa_in_cfg in;
	struct dpni_ipsec_sa_out_cfg out;
	struct dpni_ipsec_cipher_cfg cipher;
	struct dpni_ipsec_auth_cfg auth;
	struct dpni_ipsec_sa_lifetime_limits lifetime;
};

int dpni_ipsec_add_sa(struct dpni *dpni,
	struct dpni_ipsec_sa_cfg *cfg,
	uint8_t sa_id);
int dpni_ipsec_remove_sa(struct dpni *dpni, uint8_t sa_id);
int dpni_get_sa_tmp_buffer(struct dpni *dpni,
	uint32_t tmp_buff_size,
	void **buf,
	uint8_t *sa_id);
int dpni_ipsec_flush(struct dpni *dpni);
int dpni_ipsec_sa_get_stats(struct dpni *dpni,
	uint8_t sa_id,
	uint64_t *kilobytes,
	uint64_t *packets,
	uint32_t *sec);

struct dpni_taildrop {
	char enable;
	enum dpni_congestion_unit units;
	uint32_t threshold;
	int16_t oal;
};

#ifndef OBSOLETED_SP_API
enum dpni_soft_sequence_dest {
	DPNI_SS_INGRESS = 0,
	DPNI_SS_EGRESS = 1
};

struct dpni_load_ss_cfg {
	enum dpni_soft_sequence_dest	dest;
	uint16_t			ss_size;
	uint16_t			ss_offset;
	void				*ss_iova;
};

struct dpni_enable_ss_cfg {
	enum dpni_soft_sequence_dest	dest;
	uint16_t			hxs;
	uint8_t				set_start;
	uint16_t			ss_offset;
	uint8_t				param_size;
	uint8_t				param_offset;
	void				*param_iova;
};

#define DPNI_SW_SEQUENCE_LAYOUT_SIZE	DPPARSER_MAX_SP

struct dpni_sw_sequence_layout_entry{
	uint16_t			ss_offset;
	uint16_t			ss_size;
	uint8_t				param_offset;
	uint8_t				param_size;
};
#endif	/* OBSOLETED_SP_API */

int dpni_get_taildrop(struct dpni *dpni, int ceetm_ch_idx, enum dpni_congestion_point cg_point,
		enum dpni_queue_type q_type, uint8_t tc, uint8_t queue_index,
		struct dpni_taildrop *taildrop);
int dpni_set_taildrop(struct dpni *dpni, int ceetm_ch_idx, enum dpni_congestion_point cg_point,
		enum dpni_queue_type q_type, uint8_t tc, uint8_t queue_index,
		struct dpni_taildrop *taildrop);

enum dpni_confirmation_mode {
	DPNI_CONF_AFFINE,
	DPNI_CONF_SINGLE,
	DPNI_CONF_DISABLE,
};

int dpni_set_tx_confirmation_mode(struct dpni *dpni, int ceetm_ch_idx,
		enum dpni_confirmation_mode cmode);
int dpni_get_tx_confirmation_mode(struct dpni *dpni,
		enum dpni_confirmation_mode *cmode);

int dpni_set_opr(struct dpni *dpni, uint8_t tc_id, uint8_t index,
		uint8_t options, struct opr_cfg *cfg, uint8_t opr_id);
int dpni_get_opr(struct dpni *dpni, uint8_t tc_id, uint8_t index,
		struct opr_cfg *cfg, struct opr_qry *qry, uint8_t flags, uint8_t opr_id);

#ifndef OBSOLETED_SP_API
int dpni_load_sw_sequence(struct dpni *dpni, struct dpni_load_ss_cfg *cfg);
int dpni_enable_sw_sequence(struct dpni *dpni, struct dpni_enable_ss_cfg *cfg,
			    int set_start);
int dpni_get_sw_sequence_layout(struct dpni *dpni,
				enum dpni_soft_sequence_dest src,
				struct dpni_sw_sequence_layout_entry *layout);
#endif	/* OBSOLETED_SP_API */

#define DPNI_SET_SP_PROFILE_INGRESS 0x1
#define DPNI_SET_SP_PROFILE_EGRESS 	0x2

/* Sets up a Soft Parser Profile on this DPNI
 * 
 * @dpni: dpni object
 * @sp_profile: Soft Parser Profile name (must a valid name for a defined profile)
 * 			if this parameter is empty string (all zeros) 
 * 			then the Default SP Profile is set on this dpni
 * @type: one of the SP Profile types defined above: Ingress or Egress (or both using bitwise OR)
 */
int dpni_set_sp_profile(struct dpni *dpni, uint8_t sp_profile[], uint8_t type);

struct dpni_rx_dist_cfg {
	uint16_t dist_size;
	struct dpkg_profile_cfg *dist_key_cfg;
	uint8_t enable;
	uint8_t tc_id;
	uint16_t flow_id;
	
	uint64_t key_cfg_iova;
	int key_changed;
};

int dpni_set_rx_fs_dist(struct dpni *dpni, uint8_t tc_id, struct dpni_rx_dist_cfg *cfg);
int dpni_set_rx_hash_dist(struct dpni *dpni, uint8_t tc_id, struct dpni_rx_dist_cfg *cfg);

int dpni_add_custom_tpid(struct dpni *dpni, uint16_t tpid);
int dpni_remove_custom_tpid(struct dpni *dpni, uint16_t tpid);

struct dpni_custom_tpid {
	uint16_t tpid1;
	uint16_t tpid2;
};
int dpni_get_custom_tpid(struct dpni *dpni, struct dpni_custom_tpid *tpid);

struct dpni_single_step_cfg {
	int enable;
	int ch_update;
	uint16_t offset;
	uint32_t peer_delay;
};
int dpni_set_single_step_cfg(struct dpni *dpni, struct dpni_single_step_cfg *ptp_cfg);
int dpni_get_single_step_cfg(struct dpni *dpni, struct dpni_single_step_cfg *ptp_cfg);

/* MC internal functions */

struct dpni *dpni_allocate(void);
void dpni_deallocate(struct dpni *dpni);
int dpni_init(struct dpni *dpni,
	struct dpni_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg);
int dpni_set_dev_ctx(struct dpni *dpni, const struct dpmng_dev_ctx *dev_ctx);
int dpni_linkman_event_cb(void *dev,
	const struct linkman_control *control,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action);
int dpni_linkman_event_complete_cb(void *dev,
	const struct linkman_control *control,
	struct linkman_endpoint *self,
	const struct linkman_endpoint *peer,
	struct linkman_action *action);

#define DPNI_PORT_CFG_LOOPBACK		0x00000001

struct dpni_port_cfg{
	int loopback_en;
};


int dpni_set_port_cfg(struct dpni *dpni, uint32_t flags, struct dpni_port_cfg *port_cfg);
int dpni_get_port_cfg(struct dpni *dpni, struct dpni_port_cfg *port_cfg);

enum dpni_table_type {
	DPNI_FS_TABLE = 1,
	DPNI_MAC_TABLE = 2,
	DPNI_QOS_TABLE = 3,
	DPNI_VLAN_TABLE	= 4,
};

#pragma pack(push, 1)
struct dump_table_header {
	uint16_t table_type;
	uint16_t table_num_entries;
	uint16_t table_max_entries;
	uint8_t default_action;
	uint8_t match_type;
	uint8_t reserved[24];
};
#pragma pack(pop)

#pragma pack(push, 1)
struct dump_table_entry {
	uint8_t key[DPNI_MAX_KEY_SIZE];
	uint8_t mask[DPNI_MAX_KEY_SIZE];
	uint8_t key_action;
	uint16_t result[3];
	uint16_t rule_index;
	uint8_t reserved[19];
};
#pragma pack(pop)

int dpni_dump_table(struct device *dev, uint16_t table_type, uint16_t table_index, uint64_t iova_addr, int iova_size, uint16_t *table_size);

int dpni_get_ap_ppid(struct dpni *dpni, int *ppid);
int dpni_clean_flow_control_config(struct dpni *dpni);

#endif /* __FSL_DPNI_MC_H */
