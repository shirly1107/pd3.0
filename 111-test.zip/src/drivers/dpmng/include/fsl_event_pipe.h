/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_EVENT_PIPE_H
#define __FSL_EVENT_PIPE_H

#include "fsl_sys.h"
#include "fsl_dbg.h"
#include "fsl_dpmng_mc.h"

struct dpaiop;
extern int dpaiop_send_event(struct dpaiop *dpaiop,
	uint64_t *data,
	uint32_t size);

struct mc_irq_cfg {
	uint64_t addr;
	uint32_t val;
	int type;
	int irq_num;
	struct dpmng_dev_ctx dev_ctx;
};

#define MC_IRQ_TYPE_MSI			0
#define MC_IRQ_TYPE_SWP			1
#define MC_IRQ_TYPE_AUTO_CLEAR		2

struct mc_irq {
	uint64_t irq_addr;
	uint32_t irq_val;
	int type;
	int irq_num;
	uint32_t pending;
	uint32_t mask;
	uint32_t reported;
	uint8_t enable;
	uint8_t set;
	struct dpmng_dev_ctx dev_ctx;
};

static inline void mc_init_irq(struct mc_irq *irq,
	int type)
{
	irq->type = type;
}

static inline void mc_set_irq(struct mc_irq *irq,
	const struct mc_irq_cfg *irq_cfg)
{
	irq->irq_addr = irq_cfg->addr;
	irq->irq_val = irq_cfg->val;
	irq->irq_num = irq_cfg->irq_num;
	irq->pending = 0;
	irq->mask = 0;
	irq->enable = 0;
	irq->reported = 0;
	irq->set = 1;
	irq->dev_ctx = irq_cfg->dev_ctx;
}

static inline int mc_get_irq(struct mc_irq *irq, struct mc_irq_cfg *irq_cfg)
{
	irq_cfg->addr = irq->irq_addr;
	irq_cfg->val = irq->irq_val;
	irq_cfg->type = irq->type;
	irq_cfg->irq_num = irq->irq_num;
	irq_cfg->dev_ctx = irq->dev_ctx;
	return 0;
}

static inline int mc_set_irq_enable(struct mc_irq *irq, uint8_t en)
{
	if (en && (!irq->set)) {
		pr_err("IRQ not defined\n");
		return -ENODEV;
	}

	irq->enable = en;

	return 0;
}

static inline int mc_get_irq_enable(struct mc_irq *irq, uint8_t *en)
{
	*en = irq->enable;

	return 0;
}

static inline int mc_set_irq_mask(struct mc_irq *irq, uint32_t mask)
{
	irq->mask = mask;

	return 0;
}

static inline int mc_get_irq_mask(struct mc_irq *irq, uint32_t *mask)
{
	*mask = irq->mask;

	return 0;
}

static inline int mc_get_irq_status(struct mc_irq *irq, uint32_t *status)
{
	uint32_t clear_status = *status;
	*status = irq->pending;

	/* clear the requested status */
	if (clear_status != 0)
{
		irq->pending &= ~clear_status;
		irq->reported &= ~clear_status;
}	
	return 0;
}

static inline int mc_clear_irq_status(struct mc_irq *irq, uint32_t status)
{
	irq->pending &= ~status;
	irq->reported &= ~status;

	return 0;
}

static inline void event_send(struct mc_irq *irq, uint32_t status)
{
	void *addr;
	struct dpmng *dpmng;
	uint64_t cmd_data[8] = {0};
	struct dpaiop *dpaiop;
	int err = 0;

	irq->pending |= status;

	if (irq->enable && ((irq->pending & irq->mask) != irq->reported)) {
		pr_debug("event_send icid = %d, status = 0x%x, irq_addr = 0x%x, enable = %d, "
				"pending = 0x%x, mask = 0x%x\n", irq->dev_ctx.amq.icid, status,
				irq->irq_addr, irq->enable, irq->pending, irq->mask);

		/* auto clear interrupts */
		if (irq->type == MC_IRQ_TYPE_AUTO_CLEAR)
			irq->pending &= ~status;

		if (irq->dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
			dpaiop = (struct dpaiop *)sys_get_unique_handle(
				FSL_MOD_DPAIOP);
			/* TODO Need to free the cmd_data buffer
			 * But it should not be reused until AIOP will finish
			 * this no response command */

			cmd_data[0] = irq->irq_addr;
			cmd_data[1] = irq->irq_val;
			err = dpaiop_send_event(dpaiop, cmd_data, 64);
		} else {
			dpmng = (struct dpmng *)sys_get_unique_handle(
				FSL_MOD_DPMNG);
			dpmng_mc_lock_soc_window(dpmng);
			addr = dpmng_mc_set_soc_window(irq->irq_addr,
							&(irq->dev_ctx.amq));
			iowrite32(irq->irq_val, (uint32_t *)addr);
			dpmng_mc_unlock_soc_window(dpmng);
		}
		if ((!err) && (irq->type != MC_IRQ_TYPE_AUTO_CLEAR))
			irq->reported = (irq->pending & irq->mask);
	}
}

#endif /* __FSL_EVENT_PIPE_H */
