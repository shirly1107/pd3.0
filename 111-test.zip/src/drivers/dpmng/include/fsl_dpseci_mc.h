/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPSECI_H
#define __FSL_DPSECI_H

#include "fsl_opr.h"

struct dpseci;

#define DPSECI_MAX_IRQ_NUM	0 //TODO

#define DPSECI_MAX_QUEUE_NUM	16
#define DPSECI_ALL_QUEUES	(uint8_t)(-1)

int dpseci_open(struct dpseci *dpseci, int dpseci_id);

int dpseci_close(struct dpseci *dpseci);

#define DPSECI_OPT_HAS_CG					0x000020
#define DPSECI_OPT_HAS_OPR					0x000040
#define DPSECI_OPT_OPR_SHARED				0x000080

struct dpseci_cfg {
	uint32_t options;
	uint8_t num_tx_queues;
	uint8_t	num_rx_queues;
	uint8_t priorities[DPSECI_MAX_QUEUE_NUM];
};

int dpseci_create(struct dpseci *dpseci, const struct dpseci_cfg *cfg);

int dpseci_destroy(struct dpseci *dpseci);

int dpseci_enable(struct dpseci *dpseci);

int dpseci_disable(struct dpseci *dpseci);

int dpseci_is_enabled(struct dpseci *dpseci, int *en);

int dpseci_reset(struct dpseci *dpseci);

int dpseci_set_irq(struct dpseci *dpseci,
		   uint8_t irq_index,
		   const struct mc_irq_cfg *irq_cfg);

int dpseci_get_irq(struct dpseci *dpseci,
		  uint8_t irq_index,
		  struct mc_irq_cfg *irq_cfg);

int dpseci_set_irq_enable(struct dpseci *dpseci,
			  uint8_t irq_index,
			  uint8_t en);

int dpseci_get_irq_enable(struct dpseci *dpseci,
			  uint8_t irq_index,
			  uint8_t *en);

int dpseci_set_irq_mask(struct dpseci *dpseci,
			uint8_t irq_index,
			uint32_t mask);

int dpseci_get_irq_mask(struct dpseci *dpseci,
			uint8_t irq_index,
			uint32_t *mask);

int dpseci_get_irq_status(struct dpseci *dpseci,
			  uint8_t irq_index,
			  uint32_t *status);

int dpseci_clear_irq_status(struct dpseci *dpseci,
			    uint8_t irq_index,
			    uint32_t status);

int dpseci_set_opr(struct dpseci *dpseci, uint8_t index, uint8_t options, struct opr_cfg *cfg);

int dpseci_get_opr(struct dpseci *dpseci, uint8_t index, struct opr_cfg *cfg, struct opr_qry *qry);

struct dpseci_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
	uint8_t num_tx_queues;
	uint8_t num_rx_queues;
	uint32_t options;

};

int dpseci_get_attributes(struct dpseci *dpseci, struct dpseci_attr *attr);

enum dpseci_dest {
	DPSECI_DEST_NONE = 0,
	DPSECI_DEST_DPIO = 1,
	DPSECI_DEST_DPCON = 2
};

struct dpseci_dest_cfg {
	enum dpseci_dest dest_type;
	int dest_id;
	uint8_t priority;
};

#define DPSECI_QUEUE_OPT_USER_CTX	0x00000001
#define DPSECI_QUEUE_OPT_DEST		0x00000002
#define DPSECI_QUEUE_OPT_ORDER_PRESERVATION    0x00000004


struct dpseci_rx_queue_cfg {
	uint32_t options;
	int order_preservation_en;
	uint64_t user_ctx;
	struct dpseci_dest_cfg dest_cfg;
};

int dpseci_set_rx_queue(struct dpseci *dpseci,
	uint8_t queue,
	const struct dpseci_rx_queue_cfg *cfg);

struct dpseci_rx_queue_attr {
	uint64_t user_ctx;
	int order_preservation_en;
	struct dpseci_dest_cfg dest_cfg;
	uint32_t fqid;
};

int dpseci_get_rx_queue(struct dpseci *dpseci,
	uint8_t queue,
	struct dpseci_rx_queue_attr *attr);

struct dpseci_tx_queue_attr {
	uint32_t fqid;
	uint8_t  priority;
};

int dpseci_get_tx_queue(struct dpseci *dpseci,
	uint8_t queue,
	struct dpseci_tx_queue_attr *attr);


/**
 * struct dpseci_sec_attr - Structure representing attributes of the SEC hardware accelerator
 * @ip_id:	ID for SEC.
 * @major_rev: Major revision number for SEC.
 * @minor_rev: Minor revision number for SEC.
 * @era: SEC Era.
 * @deco_num: The number of copies of the DECO that are implemented in this version of SEC.
 * @zuc_auth_acc_num: The number of copies of ZUCA that are implemented in this version of SEC.
 * @zuc_enc_acc_num: The number of copies of ZUCE that are implemented in this version of SEC.
 * @snow_f8_acc_num: The number of copies of the SNOW-f8 module that are implemented in this version of SEC.
 * @snow_f9_acc_num: The number of copies of the SNOW-f9 module that are implemented in this version of SEC.
 * @crc_acc_num: The number of copies of the CRC module that are implemented in this version of SEC.
 * @pk_acc_num:  The number of copies of the Public Key module that are implemented in this version of SEC.
 * @kasumi_acc_num: The number of copies of the Kasumi module that are implemented in this version of SEC.
 * @rng_acc_num: The number of copies of the Random Number Generator that are implemented in this version of SEC.
 * @md_acc_num: The number of copies of the MDHA (Hashing module) that are implemented in this version of SEC.
 * @arc4_acc_num: The number of copies of the ARC4 module that are implemented in this version of SEC.
 * @des_acc_num: The number of copies of the DES module that are implemented in this version of SEC.
 * @aes_acc_num: The number of copies of the AES module that are implemented in this version of SEC.
 * @ccha_acc_num: The number of copies of the ChaCha20 module that are implemented in this version of SEC.
 * @ptha_acc_num: The number of copies of the Poly1305 module that are implemented in this version of SEC.
 **/
struct dpseci_sec_attr {
	uint16_t 	ip_id;		//Secvid_MS
	uint8_t   	major_rev;
	uint8_t    	minor_rev;
	uint8_t     era;    	//CCBVID
	uint8_t     deco_num;   //CHANUM_MS
	uint8_t     zuc_auth_acc_num;
	uint8_t     zuc_enc_acc_num;
	uint8_t     snow_f8_acc_num;
	uint8_t     snow_f9_acc_num;
	uint8_t     crc_acc_num;
	uint8_t     pk_acc_num;  //CHANUM_LS
	uint8_t     kasumi_acc_num;
	uint8_t     rng_acc_num;
	uint8_t     md_acc_num;
	uint8_t     arc4_acc_num;
	uint8_t     des_acc_num;
	uint8_t     aes_acc_num;
	uint8_t     ccha_acc_num;
	uint8_t     ptha_acc_num;
};

int dpseci_get_sec_attr(struct dpseci *dpseci,
	struct dpseci_sec_attr *attr);

/* global sec counters and not per dpseci counters */
/**
 * struct dpseci_sec_counters - Structure representing global SEC counters and not per dpseci counters
 * @dequeued_requests:	Number of Requests Dequeued
 * @ob_enc_requests:	Number of Outbound Encrypt Requests
 * @ib_dec_requests:	Number of Inbound Decrypt Requests
 * @ob_enc_bytes:		Number of Outbound Bytes Encrypted
 * @ob_prot_bytes:		Number of Outbound Bytes Protected
 * @ib_dec_bytes:		Number of Inbound Bytes Decrypted
 * @ib_valid_bytes:		Number of Inbound Bytes Validated
 */
struct dpseci_sec_counters {
	uint64_t 	dequeued_requests;
	uint64_t	ob_enc_requests;
	uint64_t	ib_dec_requests;
	uint64_t	ob_enc_bytes;
	uint64_t	ob_prot_bytes;
	uint64_t	ib_dec_bytes;
	uint64_t	ib_valid_bytes;
};

int dpseci_get_sec_counters(struct dpseci *dpseci,
	struct dpseci_sec_counters *counters);

enum dpseci_congestion_unit {
	DPSECI_CONGESTION_UNIT_BYTES = 0,
	DPSECI_CONGESTION_UNIT_FRAMES
};

#define DPSECI_CGN_MODE_WRITE_MEM_ON_ENTER		0x00000001
#define DPSECI_CGN_MODE_WRITE_MEM_ON_EXIT		0x00000002
#define DPSECI_CGN_MODE_COHERENT_WRITE			0x00000004
#define DPSECI_CGN_MODE_NOTIFY_DEST_ON_ENTER	0x00000008
#define DPSECI_CGN_MODE_NOTIFY_DEST_ON_EXIT		0x00000010
#define DPSECI_CGN_MODE_INTR_COALESCING_DISABLED	0x00000020

struct dpseci_congestion_notification_cfg {
	enum dpseci_congestion_unit units;
	uint32_t threshold_entry;
	uint32_t threshold_exit;
	uint64_t message_ctx;
	uint64_t message_iova;
	struct dpseci_dest_cfg dest_cfg;
	uint16_t notification_mode;
};

int dpseci_set_congestion_notification(struct dpseci *dpseci,
		const struct dpseci_congestion_notification_cfg *cfg);
int dpseci_get_congestion_notification(struct dpseci *dpseci,
		struct dpseci_congestion_notification_cfg *cfg);

/* MC internal functions */

/**
 * @brief	Will allocate resources and preliminary initialization
 *
 * @param[in]	dpseci - DPSECI handle
 * @param[in]	cfg - Configuration structure
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpseci_init(struct dpseci *dpseci,
		const struct dpseci_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg);

/**************************************************************************//**
 @Description	DPSECI MC internal information
 *//***************************************************************************/

/**
 * @brief	Will allocate resources and preliminary initialization
 *
 * @param[in]	dpseci - DPSECI handle
 * @param[in]	cfg - Configuration structure
 *
 * @returns	'0' on Success; Error code otherwise.
 */
struct dpseci *dpseci_allocate(void);
void dpseci_deallocate(struct dpseci *dpseci);
int dpseci_set_dev_ctx(struct dpseci *dpseci,
		       const struct dpmng_dev_ctx *dev_ctx);

#endif /* __FSL_DPSECI_H */
