/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_PEBM_H
#define __FSL_PEBM_H

#include "fsl_types.h"
#include "fsl_gen.h"


struct dcfg_info {
	uint16_t device_id;
	uint16_t var;
	uint16_t major;
	uint16_t minor;
	uint64_t disabled_devices;
};

//int pebm_drv_init(void);

int pebm_init();
void pebm_error_inject();
void pebm_enable_exceptions();



#endif /* __FSL_PEBM_H */

