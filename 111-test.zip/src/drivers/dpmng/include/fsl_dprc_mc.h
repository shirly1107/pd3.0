/*
 * Copyright 2013-2021 NXP
 */

#ifndef _FSL_DPRC_MC_H
#define _FSL_DPRC_MC_H

struct dprc;

#define DPRC_GET_ICID_FROM_POOL			(uint16_t)(~(0))

#define DPRC_GET_PORTAL_ID_FROM_POOL	(int)(~(0))


#define DPRC_RES_REQ_OPT_EXPLICIT		0x00000001
#define DPRC_RES_REQ_OPT_ALIGNED		0x00000002
#define DPRC_RES_REQ_OPT_PLUGGED		0x00000004

#define DPRC_CFG_OPT_SPAWN_ALLOWED		0x00000001
#define DPRC_CFG_OPT_ALLOC_ALLOWED		0x00000002
#define DPRC_CFG_OPT_OBJ_CREATE_ALLOWED	0x00000004
#define DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED	0x00000008
#define DPRC_CFG_OPT_IOMMU_BYPASS		0x00000010
#define DPRC_CFG_OPT_AIOP				0x00000020
#define DPRC_CFG_OPT_IRQ_CFG_ALLOWED	0x00000040
#define DPRC_CFG_OPT_PL_ALLOWED			0x00000080

#define DPRC_OBJ_STATE_OPEN		0x00000001
#define DPRC_OBJ_STATE_PLUGGED		0x00000002
#define DPRC_OBJ_STATE_ENABLE		0x00000004

#define DPRC_NUM_OF_IRQS		1

#define DPRC_IRQ_EVENT_OBJ_ADDED			0x00000001
#define DPRC_IRQ_EVENT_OBJ_REMOVED			0x00000002
#define DPRC_IRQ_EVENT_RES_ADDED			0x00000004
#define DPRC_IRQ_EVENT_RES_REMOVED			0x00000008
#define DPRC_IRQ_EVENT_CONTAINER_DESTROYED	0x00000010
#define DPRC_IRQ_EVENT_OBJ_DESTROYED		0x00000020
#define DPRC_IRQ_EVENT_OBJ_CREATED			0x00000040

#define DPRC_OBJ_FLAG_NO_MEM_SHAREABILITY 		0x0001

struct dprc_obj_desc {
	char type[16];
	int id;
	uint16_t vendor;
	uint16_t ver_major;
	uint16_t ver_minor;
	uint8_t irq_count;
	uint8_t region_count;
	uint32_t state;
	char label[16];
	uint16_t flags;
};

/* Region flags */
/* Cacheable - Indicates that region should be mapped as cacheable */
#define DPRC_REGION_FLAG_CACHEABLE	0x00000001
/* Shareeable - Indicates that region should be mapped as shareable (coherent) */
#define DPRC_REGION_FLAG_SHAREABLE	0x00000002

/* Region sizes */
/* SW PORTAL old region size for backward compatibility */
#define DPRC_4KB_SW_PORTAL_REGION_SIZE	0x1000
/* SW PORTAL hardware region size */
#define DPRC_64KB_SW_PORTAL_REGION_SIZE	0x10000
/* MC PORTAL old region size for backward compatibility */
#define DPRC_64B_MC_PORTAL_REGION_SIZE	0x40
/* MC PORTAL hardware region size */
#define DPRC_64KB_MC_PORTAL_REGION_SIZE	0x10000

enum dprc_region_type {
	DPRC_REGION_TYPE_MC_PORTAL,
	DPRC_REGION_TYPE_QBMAN_PORTAL
};

struct dprc_region_desc {
	uint32_t base_offset;
	uint32_t size;
	uint32_t flags;
	enum dprc_region_type type;
	uint64_t base_address;
};


enum dprc_iter_status {
	DPRC_ITER_STATUS_FIRST = 0,
	DPRC_ITER_STATUS_MORE = 1,
	DPRC_ITER_STATUS_LAST = 2
};

struct dprc_res_ids_range_desc {
	int base_id;
	int last_id;
	enum dprc_iter_status iter_status;
};

struct dprc_cfg {
	uint32_t icid;
	int portal_id;
	uint64_t options;
	char label[16];
};

struct dprc_endpoint {
	char type[16];
	int id;
	uint16_t if_id;
};

struct dprc_connection_cfg {
    uint32_t committed_rate;
    uint32_t max_rate;
};

struct __attribute__((__packed__)) dprc_mem {
    uint8_t     num_entries;        /* number of valid entries in this response*/
    uint16_t    total_page_count;
    /* current page data */
    uint32_t    offset0;
    uint32_t    size0;
    uint32_t    offset1;
    uint32_t    size1;
    uint32_t    offset2;
    uint32_t    size2;
    uint32_t    offset3;
    uint32_t    size3;
    uint32_t    offset4;
    uint32_t    size4;
};

#endif /* _FSL_DPRC_H */

