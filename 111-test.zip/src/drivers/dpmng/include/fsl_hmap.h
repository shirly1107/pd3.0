/*
 * Copyright 2013-2020 NXP
 */

#ifndef _FSL_HMAP_H
#define _FSL_HMAP_H

#include "fsl_types.h"

typedef void            *hmap_data;
typedef uint8_t   	*hmap_key;

struct hmap_mask
{
	size_t	start;
	size_t	size;
};

/* Constructs a hashmap that maps keys to data */
struct hmap *hmap_create(int size, size_t key_size);

/* destroys a hashmap */
void hmap_destroy(struct hmap *hmap);

/* Sets data for specified index. Used after hmap_create() */
int hmap_set_data(struct hmap *hmap, int index, hmap_data data);

/* Gets data for specified index. Used rigth before hmap_destroy() */
int hmap_get_data(struct hmap *hmap, int index, hmap_data *data);

/*Returns the count (number of elements) in the hash table.*/
int hmap_get_count(struct hmap *hmap);

/* Inserts an element into the map; return an error if a matching key is found */
int hmap_add_key(struct hmap *hmap, hmap_key key);

/* Looks up the data mapped to a given key */
int hmap_lookup(struct hmap *hmap, const hmap_key key, hmap_data *data);

/* Looks up the data mapped to a given key and mask.
 * Only byte mask is aligned and continuous */
int hmap_ternary_lookup(struct hmap *hmap,
		hmap_key key, struct hmap_mask *mask, hmap_data *data);

/* Removes an element specified by a key. */
int hmap_remove_key(struct hmap *hmap, hmap_key key);

/* Removes all keys */
void hmap_remove_all(struct hmap *hmap);

/* Obtains the position of the next element */
int hmap_next_iterator(struct hmap *hmap, int iterator);

/* Obtains the position of the first element. */
int hmap_get_start_iterator(struct hmap *hmap, int *iterator);

/* Retrieves the map entry at iterator, then updates iterator to refer
to the next element in the map.*/
int hmap_iterate(struct hmap *hmap, int *iterator,
            hmap_key key, hmap_data *data);

#endif /* _FSL_HMAP_H */

