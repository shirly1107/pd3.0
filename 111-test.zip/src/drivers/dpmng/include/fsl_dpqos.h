/*
 * Copyright 2013-2020 NXP
 */

#ifndef FSL_DPQOS_H_
#define FSL_DPQOS_H_

#include "fsl_types.h"


enum dpqos_next_action {
    DPQOS_ACTION_POLICER,
    DPQOS_ACTION_DONE
};
enum dpqos_method {
	DPQOS_METHOD_BASED_ON_VLAN,
	DPQOS_METHOD_BASED_ON_IP
};

#define DPQOS_ACTION_SET_POLICER_ID     				0x80000000
#define DPQOS_ACTION_SET_QPRI          					0x40000000

struct dpqos_rule {
	int priority;
	enum dpqos_method method;
};

struct dpqos_action {
      enum dpqos_next_action   	next_action;
      uint32_t                 	options;
      int                   	dppolicer_profile_id;
      int                     	qpri;
  
};
struct dpqos_mng_cfg {
	struct ctlu *ctlu; /* TODO */
};

struct dpqos_mng;

/**************************************************************************//**
 @Function      dpqos_mng_restore

 @Description  	This function restores the Policy Manager module after WRIOP reset.

 @Param[in]    	dpqos_mng_cfg   	- Policy Manager parameters structure

 @Retval        0 on Success; error code otherwise.
 *//**************************************************************************/
int dpqos_mng_restore(const struct dpqos_mng_cfg *dpqos_mng_cfg);

/**************************************************************************//**
 @Function      dppolicy_mng_init

 @Description  	This function initializes the Policy Manager module.

 @Param[in]    	cfg   		- Policy Manager parameters structure

 @Retval        A handle to the Policy Manager object
 *//**************************************************************************/
struct dpqos_mng *dpqos_mng_init(const struct dpqos_mng_cfg *cfg);

/**************************************************************************//**
 @Function     	dppolicy_mng_done

 @Description  	This function deleted all initializations associated
               	with the Policy Manager object

 @Param[in]    	dppolicy_mng   - A handle to the Policy Manager object as returned by the
 	 	 	         dppolicy_mng_alloc routine

 @Retval        None
 *//**************************************************************************/
void dpqos_mng_done(struct dpqos_mng *dpqos_mng);




struct dpqos;
/**************************************************************************//**
 @Function      dpqos_init

 @Description   Create a new empty QOS 

 @Param[in]     dppolicy_id 	- id of the Policy
 @Param[in]     params 			- A structure of parameters for creating a new Policy

 @Return       TBD

 *//***************************************************************************/
struct dpqos* dpqos_init	(struct dpqos_mng *dpqos_mng,
                                 int ifp_id);

/**************************************************************************//**
 @Function      dppolicy_done

 @Description   Deletes an existing Policy

 @Param[in]     dppolicy 		- A handle to the initialized Policy

 @Return        0 on Success; error code otherwise.

 *//***************************************************************************/
int dpqos_done(struct dpqos* dpqos);

/**************************************************************************//**
 @Function      dpqos_add_rule

 @Description   TBD

 @Param[in]     TBD

 @Return        0 on Success; error code otherwise.

 *//***************************************************************************/
int dpqos_add_rule	(struct dpqos* dpqos,
					const struct dpqos_rule 	*rule,
					const struct dpqos_action *action)
;
/**************************************************************************//**
 @Function      dpqos_modify_rule

 @Description   TBD

 @Param[in]     TBD

 @Return        0 on Success; error code otherwise.

 *//***************************************************************************/
int dpqos_modify_rule	(struct dpqos* dpqos,
						const struct dpqos_rule *rule,
						const struct dpqos_action *action);

/**************************************************************************//**
 @Function      dpqos_remove_rule

 @Description   TBD

 @Param[in]     TBD

 @Return        0 on Success; error code otherwise.

 *//***************************************************************************/
int dpqos_remove_rule(struct dpqos *dpqos,
                        const struct dpqos_rule *rule);


#endif /* FSL_DPQOS_H_ */
