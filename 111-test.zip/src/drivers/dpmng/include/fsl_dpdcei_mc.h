/* Copyright 2014-2015 Freescale Semiconductor Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of Freescale Semiconductor nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 *
 * ALTERNATIVELY, this software may be distributed under the terms of the
 * GNU General Public License ("GPL") as published by the Free Software
 * Foundation, either version 2 of that License or (at your option) any
 * later version.
 *
 * THIS SOFTWARE IS PROVIDED BY Freescale Semiconductor ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Freescale Semiconductor BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*!
 *  @file    fsl_dpdcei.h
 *  @brief   Data Path DCE Interface API
 *
 */
#ifndef __FSL_DPDCEI_H
#define __FSL_DPDCEI_HF

/*!
 * @Group grp_dpdcei	Data Path DCE Interface API
 *
 * @brief	Contains initialization APIs and runtime control APIs for DPDCEI
 *
 * @{
 */

struct dpdcei;

/*!
 * @name	General DPDCEI macros
 */
#define DPDCEI_MAX_IRQ_NUM		0 //TODO

#define DPDCEI_FQID_NOT_VALID	(uint32_t)(-1)
/*!< Indicates an invalid frame queue */
/* @} */

/* DCE engine block */
enum dpdcei_engine {
	DPDCEI_ENGINE_COMPRESSION,
	DPDCEI_ENGINE_DECOMPRESSION
};

/**
 * @brief	Open a control session for the specified object
 *
 *		This function can be used to open a control session for an
 *		already created object; an object may have been declared in
 *		the DPL or by calling the dpdcei_create() function.
 *		This function returns a unique authentication token,
 *		associated with the specific object ID and the specific MC
 *		portal; this token must be used in all subsequent commands for
 *		this specific object.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 * @param[in]	dpdcei_id - DPDCEI unique ID
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_open(struct dpdcei *dpdcei, int dpdcei_id);

/**
 * @brief	Close the control session of the object
 *
 *		After this function is called, no further operations are
 *		allowed on the object without opening a new control session.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_close(struct dpdcei *dpdcei);

/**
 * @brief	Structure representing DPDCEI configuration
 */
struct dpdcei_cfg {
	enum dpdcei_engine engine;
	/*!< compression or decompression engine to be selected */
	uint8_t priority;
	/*!< Priorities will be configured values 1-8.*/
};

/**
 * @brief	Create the DPDCEI object, allocate required resources and
 *		perform required initialization.
 *
 *		The object can be created either by declaring it in the
 *		DPL file, or by calling this function.
 *
 *		This function returns a unique authentication token,
 *		associated with the specific object ID and the specific MC
 *		portal; this token must be used in all subsequent calls to
 *		this specific object. For objects that are created using the
 *		DPL file, call dpdcei_open() function to get an authentication
 *		token first.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 * @param[in]	cfg - configuration parameters
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_create(struct dpdcei *dpdcei, const struct dpdcei_cfg *cfg);

/**
 * @brief	Destroy the DPDCEI object and release all its resources.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 *
 * @returns	'0' on Success; error code otherwise.
 */
int dpdcei_destroy(struct dpdcei *dpdcei);

/**
 * @brief	Enable the DPDCEI, allow sending and receiving frames.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_enable(struct dpdcei *dpdcei);

/**
 * @brief	Disable the DPDCEI, stop sending and receiving frames.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_disable(struct dpdcei *dpdcei);

/**
 * @brief	Check if the DPDCEI is enabled.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 * @param[out]  en		'1' for object enabled/'0' otherwise
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_is_enabled(struct dpdcei *dpdcei, int *en);

/**
 * @brief	Reset the DPDCEI, returns the object to initial state.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_reset(struct dpdcei *dpdcei);

/**
 * @brief	Set IRQ information for the DPDCEI to trigger an interrupt.
 *
 * @param[in]	dpdcei		DPDCEI descriptor object
 * @param[in]	irq_index	Identifies the interrupt index to configure.
 * @param[in]	irq_addr	Physical IRQ address that must be written to
 *				signal a message-based interrupt
 * @param[in]	irq_val		Value to write into irq_addr address
 * @param[out]	user_irq_id	A user defined number associated with this IRQ;
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_set_irq(struct dpdcei *dpdcei,
		   uint8_t irq_index,
		   const struct mc_irq_cfg *irq_cfg);

/**
 * @brief	Get IRQ information from the DPDCEI.
 *
 * @param[in]	dpdcei		DPDCEI descriptor object
 * @param[in]   irq_index	The interrupt index to configure;
 * @param[out]  type		Interrupt type: 0 represents message interrupt
 *				type (both irq_addr and irq_val are valid);
 * @param[out]	irq_addr	Physical address that must be written in order
 *				to signal the message-based interrupt
 * @param[out]	irq_val		Value to write in order to signal the
 *				message-based interrupt
 * @param[in]	user_irq_id	A user defined number associated with this IRQ;
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_get_irq(struct dpdcei *dpdcei,
		  uint8_t irq_index,
		  struct mc_irq_cfg *irq_cfg);

/**
 * @brief	Set overall interrupt state.
 *
 * Allows GPP software to control when interrupts are generated.
 * Each interrupt can have up to 32 causes.  The enable/disable control's the
 * overall interrupt state. if the interrupt is disabled no causes will cause
 * an interrupt.
 *
 * @param[in]	dpdcei		DPDCEI descriptor object
 * @param[in]   irq_index	The interrupt index to configure;
 * @param[in]	en	interrupt state - enable = 1, disable = 0.
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_set_irq_enable(struct dpdcei *dpdcei,
			  uint8_t irq_index,
			  uint8_t en);

/**
 * @brief	Get overall interrupt state
 *
 * @param[in]	dpdcei		DPDCEI descriptor object
 * @param[in]   irq_index	The interrupt index to configure;
 * @param[out]	en	interrupt state - enable = 1, disable = 0.
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_get_irq_enable(struct dpdcei *dpdcei,
			  uint8_t irq_index,
			  uint8_t *en);

/**
 * @brief	Set interrupt mask.
 *
 * Every interrupt can have up to 32 causes and the interrupt model supports
 * masking/unmasking each cause independently
 *
 * @param[in]	dpdcei		DPDCEI descriptor object
 * @param[in]   irq_index	The interrupt index to configure;
 * @param[in]	mask		event mask to trigger interrupt.
 *				each bit:
 *					0 = ignore event
 *					1 = consider event for asserting IRQ
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_set_irq_mask(struct dpdcei *dpdcei,
			uint8_t irq_index,
			uint32_t mask);

/**
 * @brief	Get interrupt mask.
 *
 * Every interrupt can have up to 32 causes and the interrupt model supports
 * masking/unmasking each cause independently
 *
 * @param[in]	dpdcei		DPDCEI descriptor object
 * @param[in]   irq_index	The interrupt index to configure;
 * @param[out]	mask		event mask to trigger interrupt
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_get_irq_mask(struct dpdcei *dpdcei,
			uint8_t irq_index,
			uint32_t *mask);

/**
 * @brief	Get the current status of any pending interrupts.
 *
 * @param[in]	dpdcei		DPDCEI descriptor object
 * @param[in]   irq_index	The interrupt index to configure;
 * @param[out]	status		interrupts status - one bit per cause
 *					0 = no interrupt pending
 *					1 = interrupt pending
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_get_irq_status(struct dpdcei *dpdcei,
			  uint8_t irq_index,
			  uint32_t *status);

/**
 * @brief	Clear a pending interrupt's status
 *
 * @param[in]	dpdcei		DPDCEI descriptor object
 * @param[in]   irq_index	The interrupt index to configure;
 * @param[out]	status		bits to clear (W1C) - one bit per cause
 *					0 = don't change
 *					1 = clear status bit
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_clear_irq_status(struct dpdcei *dpdcei,
			    uint8_t irq_index,
			    uint32_t status);
/**
 * @brief	Structure representing DPDCEI attributes
 */
struct dpdcei_attr {
	int id;
	/*!< DPDCEI object ID */
	enum dpdcei_engine engine;
	/* DCE engine block */
	struct {
		uint16_t major;
		/*!< DPDCEI major version */
		uint16_t minor;
		/*!< DPDCEI minor version */
	} version;
	/*!< DPDCEI version */
	uint64_t dce_version;
	/*!< DCE silicon version */
};

/**
 * @brief	Retrieve DPDCEI attributes.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 * @param[out]	attr - Object's attributes
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_get_attributes(struct dpdcei *dpdcei, struct dpdcei_attr *attr);

/**
 * @brief	DPDCEI destination types
 */
enum dpdcei_dest {
	DPDCEI_DEST_NONE = 0,
	/*!< Unassigned destination; The queue is set in parked mode and does
	 * not generate FQDAN notifications; user is expected to dequeue from
	 * the queue based on polling or other user-defined method
	 */
	DPDCEI_DEST_DPIO = 1,
	/*!< The queue is set in schedule mode and generates FQDAN
	 * notifications to the specified DPIO; user is expected to dequeue
	 * from the queue only after notification is received
	 */
	DPDCEI_DEST_DPCON = 2
/*!< The queue is set in schedule mode and does not generate FQDAN
 * notifications, but is connected to the specified DPCON object;
 * user is expected to dequeue from the DPCON channel
 */
};

/**
 * @brief	Structure representing DPDCEI destination parameters
 */
struct dpdcei_dest_cfg {
	enum dpdcei_dest dest_type;
	/*!< Destination type */
	int dest_id;
	/*!< Either DPIO ID or DPCON ID, depending on the destination type */
	uint8_t priority;
/*!< Priority selection within the DPIO or DPCON channel; valid values
 * are 0-1 or 0-7, depending on the number of priorities in that
 * channel; not relevant for 'DPDCEI_DEST_NONE' option
 */
};

/*!
 * @name	DPDCEI queue modification options
 */
#define DPDCEI_QUEUE_OPT_USER_CTX	0x00000001
/*!< Select to modify the user's context associated with the queue */
#define DPDCEI_QUEUE_OPT_DEST		0x00000002
/*!< Select to modify the queue's destination */
/* @} */

struct dpdcei_rx_queue_cfg {
	uint32_t options;
	/*!< Flags representing the suggested modifications to the queue;
	 * Use any combination of 'DPDCEI_QUEUE_OPT_<X>' flags
	 */
	uint64_t user_ctx;
	/*!< User context value provided in the frame descriptor of each
	 * dequeued frame;
	 * valid only if 'DPDCEI_QUEUE_OPT_USER_CTX' is contained in 'options'
	 */
	struct dpdcei_dest_cfg dest_cfg;
/*!< Queue destination parameters;
 * valid only if 'DPDCEI_QUEUE_OPT_DEST' is contained in 'options'
 */
};

/**
 * @brief	Set Rx queue configuration
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 * @param[in]	cfg		Rx queue configuration
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_set_rx_queue(struct dpdcei *dpdcei,
	const struct dpdcei_rx_queue_cfg *cfg);

/**
 * @brief	Structure representing attributes of Rx queues
 */
struct dpdcei_rx_queue_attr {
	uint64_t user_ctx;
	/*!< User context value provided in the frame descriptor of each
	 * dequeued frame
	 */
	struct dpdcei_dest_cfg dest_cfg;
	/*!< Queue destination configuration */
	uint32_t fqid;
/*!< Virtual FQID value to be used for dequeue operations */
};

/**
 * @brief	Retrieve Rx queue attributes.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 * @param[out]	attr 		Rx queue attributes
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_get_rx_queue(struct dpdcei *dpdcei,
	struct dpdcei_rx_queue_attr *attr);

/**
 * @brief	Structure representing attributes of Tx queues
 */
struct dpdcei_tx_queue_attr {
	uint32_t fqid;
/*!< Virtual FQID to be used for sending frames to DCE hardware */
};

/**
 * @brief	Retrieve Tx queue attributes.
 *
 * @param[in]	dpdcei - Pointer to dpdcei object
 * @param[out]	attr		Tx queue attributes
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_get_tx_queue(struct dpdcei *dpdcei,
	struct dpdcei_tx_queue_attr *attr);

/** @} */

/**
 * @brief	Will allocate resources and preliminary initialization
 *
 * @param[in]	dpdcei - DPDCEI handle
 * @param[in]	cfg - Configuration structure
 * @param[in]	dev_cfg -device configuration
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdcei_init(struct dpdcei *dpdcei,
		const struct dpdcei_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg);
/**************************************************************************//**
 @Description	DPDCEI MC internal information
 *//***************************************************************************/


struct dpdcei *dpdcei_allocate(void);
void dpdcei_deallocate(struct dpdcei *dpdcei);
int dpdcei_set_dev_ctx(struct dpdcei *dpdcei,
		       const struct dpmng_dev_ctx *dev_ctx);

#endif /* __FSL_DPDCEI_H */
