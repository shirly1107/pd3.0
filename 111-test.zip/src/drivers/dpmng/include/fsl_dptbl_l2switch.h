/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPTBL_L2SWITCH
#define __FSL_DPTBL_L2SWITCH

#include "fsl_types.h"
#include "fsl_dptbl.h"
#include "fsl_ctlu.h"


/*relevant option is 
 * #define DPTBL_OPTIONS_OPTIMIZIED_DISCARD		0x80000000
 * #define DPTBL_ACTION_SET_CONTEXT_IOMMU_BYPASS 	0x00002000
 * 
 */
struct dptbl_l2switch_vlan_cfg {
    uint32_t            	max_rules;
    uint32_t			options; // the same as for regular table (fsl_dptbl.h)
    struct dptbl_action		*action_on_miss;
    uint16_t 			icid;
    uint32_t 			aging_threshold;
};

struct dptbl_l2switch_fdb_cfg {
    uint32_t            	max_rules;
    uint32_t            	aging_threshold; 
    uint32_t			options; // the same as for regular table (fsl_dptbl.h)
    uint16_t 			icid;
};


/*relevant options*/
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_BROADCAST     	0x80000000
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_MULTICAST  	0x40000000
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_FLOODING         0x20000000
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_MIRRORING        0x10000000
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_PRUNING         	0x08000000
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_ACL_AFTER_FDB 	0x04000000
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_EDISC		 	0x02000000


/* only one of them*/
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_AUTOMATIC_LEARNING 		0x00800000 /*unicast*/
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_SECURED 		0x00400000
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_SW_LEARNING_UNSECURED 	0x00200000

/* only one of them*/
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_BLOCKING 		0x00080000
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LISTENING 		0x00040000
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_LEARNING 		0x00020000
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_STP_STATE_FORWORDING 	0x00010000

/* only one of them*/
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_REMOVE 		0x00000080
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_INSERT 		0x00000040
#define DPTBL_L2SWITCH_VLAN_ACTION_SET_VLAN_MODE_UPDATE_QOS 	0x00000020

/* only one of them*/
#define DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_STATS				0x00000008
#define DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_TIMESTAMP			0x00000004
#define DPTBL_L2SWITCH_VLAN_ACTION_ACTIVATE_AGING				0x00000002

enum dptbl_l2switch_vlan_qos_map_method {
	DPTBL_L2SWITCH_VLAN_ACTION_QoS_BASED_ON_VLAN_PRI,
	DPTBL_L2SWITCH_VLAN_ACTION_QoS_BASED_ON_IP_DSCP,
};

struct dptbl_l2switch_vlan_action {
    uint32_t                   options;
    struct {
    	 int 	dptbl_id;
    	 int 	dpkg_profile_id;
     } lookup_fdb_cfg;
 	struct {
    	 int qd_id;
    	 int replic_list_id;
     }learning_cfg;
 	int 	general_replic_qd_id; /*used for flooding if Miss occurs in unicast lookup,
	when Mirroring enable used for mirroring too*/              
	int 	flooding_replic_list_id; /*used for flooding if Miss occurs in unicast lookup,
    when Mirroring enable used for mirroring replic_list_id + 1*/
    int vlan_dppolicer_profile_id;
    enum dptbl_l2switch_vlan_qos_map_method    qos_map_method;
};
/*relevant options*/
/* only one of them*/
#define DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_STATS					0x00000008
#ifndef ERR008523
#define DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_TIMESTAMP				0x00000004
#endif
#define DPTBL_L2SWITCH_FDB_ACTION_ACTIVATE_AGING					0x00000002

struct dptbl_l2switch_fdb_action {
		uint32_t	options;
		int 		qd_id;              
		int 		replic_list_id;
};
struct dptbl_l2switch_vlan_rule_cfg {
    uint8_t *key; // 4 bytes
};

struct dptbl_l2switch_fdb_rule_cfg {
    uint8_t *key; // 6 bytes
};


struct dptbl* dptbl_l2switch_vlan_create(struct dptbl_mng *dptbl_mng,
                                         const struct 
                                         dptbl_l2switch_vlan_cfg *cfg);
struct dptbl* dptbl_l2switch_fdb_create(struct dptbl_mng *dptbl_mng,
                                        const struct 
                                        dptbl_l2switch_fdb_cfg *cfg);
int dptbl_add_rule_l2switch_vlan(struct dptbl* dptbl,
                                 const struct 
                                 dptbl_l2switch_vlan_rule_cfg *rule,
                                 const struct 
                                 dptbl_l2switch_vlan_action *action);
int dptbl_remove_rule_l2switch_vlan(struct dptbl* dptbl,
                                 const struct 
                                 dptbl_l2switch_vlan_rule_cfg *rule);

int dptbl_add_rule_l2switch_fdb(struct dptbl* dptbl,
        			const struct 
        			dptbl_l2switch_fdb_rule_cfg *rule,
        			const struct 
        			dptbl_l2switch_fdb_action *action);
int dptbl_remove_rule_l2switch_fdb(struct dptbl* dptbl,
        			const struct 
        			dptbl_l2switch_fdb_rule_cfg *rule);

int dptbl_modify_rule_l2switch_vlan(struct dptbl* dptbl,
                                 const struct dptbl_l2switch_vlan_rule_cfg *rule,
                                 const struct dptbl_l2switch_vlan_action *action);

int dptbl_modify_rule_l2switch_fdb(struct dptbl* dptbl,
        			const struct dptbl_l2switch_fdb_rule_cfg *rule,
        			const struct dptbl_l2switch_fdb_action *action);

int dptbl_l2switch_vlan_delete(struct dptbl* dptbl);

int dptbl_l2switch_fdb_delete(struct dptbl* dptbl);

int dptbl_get_l2switch_fdb(struct dptbl* dptbl,
        			const struct dptbl_l2switch_fdb_rule_cfg *rule,
        			struct dptbl_l2switch_fdb_action *action);
int dptbl_add_or_modify_rule_l2switch_fdb(struct dptbl* dptbl,
        			const struct dptbl_l2switch_fdb_rule_cfg *rule,
        			const struct dptbl_l2switch_fdb_action *action);

int dptbl_get_l2switch_vlan(struct dptbl* dptbl,
        			const struct dptbl_l2switch_vlan_rule_cfg *rule,
        			struct dptbl_l2switch_vlan_action *action);

int dptbl_add_or_modify_rule_l2switch_vlan(struct dptbl* dptbl,
                                 const struct dptbl_l2switch_vlan_rule_cfg *rule,
                                 const struct dptbl_l2switch_vlan_action *action);

#endif /*__FSL_DPTBL_L2SWITCH*/
