/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPMCP_MC_H
#define __FSL_DPMCP_MC_H

#include "fsl_event_pipe.h"
#include "fsl_dpmng_mc.h"

struct dpmcp;

#define DPMCP_MAX_IRQ_NUM			1

#define DPMCP_BPID_NOT_VALID			(-1)

#define DPMCP_IRQ_INDEX                             0
#define DPMCP_IRQ_EVENT_CMD_DONE                    0x00000001

struct dpmcp_cfg {
	int portal_id;
};


struct dpmcp_attr {
	int id; 
	struct {
		uint16_t major; 
		uint16_t minor; 
	} version;
	int portal_id;
};

int dpmcp_create(struct dpmcp *dpmcp, const struct dpmcp_cfg *cfg);

int dpmcp_open(struct dpmcp *dpmcp, int dpmcp_id);

int dpmcp_close(struct dpmcp *dpmcp);

void dpmcp_destroy(struct dpmcp *dpmcp);

int dpmcp_get_attributes(struct dpmcp *dpmcp, struct dpmcp_attr *attr);

int dpmcp_set_irq(struct dpmcp *dpmcp,
                  uint8_t irq_index,
                  const struct mc_irq_cfg *irq_cfg);

int dpmcp_get_irq(struct dpmcp *dpmcp,
        	 uint8_t irq_index,
        	 struct mc_irq_cfg *irq_cfg);

int dpmcp_set_irq_enable(struct dpmcp *dpmcp, uint8_t irq_index, uint8_t en);

int dpmcp_get_irq_enable(struct dpmcp *dpmcp, uint8_t irq_index, uint8_t *en);

int dpmcp_set_irq_mask(struct dpmcp *dpmcp, uint8_t irq_index, uint32_t mask);

int dpmcp_get_irq_mask(struct dpmcp *dpmcp, uint8_t irq_index, uint32_t *mask);

int dpmcp_get_irq_status(struct dpmcp *dpmcp,
                         uint8_t irq_index,
                         uint32_t *status);

/* MC internal functions */

struct dpmcp *dpmcp_allocate(void);
void dpmcp_deallocate(struct dpmcp *dpmcp);
int dpmcp_init(struct dpmcp *dpmcp,
	       const struct dpmcp_cfg *cfg,
	       const struct dpmng_dev_cfg *dev_cfg);
int dpmcp_set_dev_ctx(struct dpmcp *dpmcp,
		      const struct dpmng_dev_ctx *dev_ctx);
int dpmcp_invoke_inter(struct dpmcp *dpmcp);
#endif /* __FSL_DPMCP_MC_H */
