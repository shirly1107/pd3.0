/**************************************************************************//**
 Copyright 2013 Freescale Semiconductor, Inc.

 @File          fsl_ldpaa.h

 @Description   This file contains LDPAA general definitions.
 *//***************************************************************************/
#ifndef __FSL_LDPAA_H
#define __FSL_LDPAA_H

#include "fsl_types.h"

/**************************************************************************//**
 @Group         ldpaa_g  LDPAA API

 @Description   TODO

 @{
 *//***************************************************************************/

/**************************************************************************//**
 @Description	Frame Descriptor structure.

 The Frame Descriptor (FD) includes information related to the
 frame, such as frame format, the amount of frame data, presence
 of an annotation section containing frame meta-data.
 *//***************************************************************************/
struct ldpaa_fd {
	uint32_t addr_lo;
	uint32_t addr_hi;
	uint32_t length; /**< Frame data length 	 */
	uint32_t offset; /**< Frame data offset 	 */
	uint32_t frc; /**< Frame Context 	 */
	uint32_t control; /**< Fame control fields */
	uint32_t flc_lo;
	uint32_t flc_hi;
};

/**************************************************************************//**
 @Collection   Frame descriptor macros
 *//***************************************************************************/
#define LDPAA_FD_ADDRL_MASK	0xffffffff		/**< FD ADDRL field mask */
#define LDPAA_FD_ADDRH_MASK	0x0001ffff		/**< FD ADDRH field mask */
#define LDPAA_FD_ADDR_TOK_MASK	0xfffe0000		/**< FD ADDR-TOK field mask */
#define LDPAA_FD_LENGTH_MASK	0xffffffff		/**< FD LENGTH field mask */
#define LDPAA_FD_SHORT_LENGTH_MASK	0x0003ffff	/**< FD LENGTH(short) field mask */
#define LDPAA_FD_MEM_MASK	0xfff00000		/**< FD MEM field mask */
#define LDPAA_FD_SL_MASK 	0x40000000		/**< FD SL field mask */
#define LDPAA_FD_FORMAT_MASK 	0x30000000		/**< FD FORMAT field mask */
#define LDPAA_FD_OFFSET_MASK	0x0fff0000		/**< FD OFFSET field mask */
#define LDPAA_FD_BMT_MASK 	0x00008000		/**< FD BMT field mask */
#define LDPAA_FD_IVP_MASK 	0x00004000		/**< FD IVP field mask */
#define LDPAA_FD_BPID_MASK	0x00003fff		/**< FD BPID field mask */
#define LDPAA_FD_FRC_MASK	0xffffffff		/**< FD FRC field mask */
#define LDPAA_FD_DD_MASK	0xf0000000		/**< FD DD field mask */
#define LDPAA_FD_SC_MASK	0x08000000		/**< FD SC field mask */
#define LDPAA_FD_DROPP_MASK	0x07000000		/**< FD DROPP field mask */
#define LDPAA_FD_PTA_MASK	0x00800000		/**< FD PTA field mask */
#define LDPAA_FD_PTV1_MASK	0x00400000		/**< FD PTV1 field mask */
#define LDPAA_FD_PTV2_MASK	0x00200000		/**< FD PTV2 field mask */
#define LDPAA_FD_ASAL_MASK	0x000f0000		/**< FD ASAL field mask */
#define LDPAA_FD_CBMT_MASK	0x00008000		/**< FD CBMT field mask */
#define LDPAA_FD_VA_MASK	0x00004000		/**< FD VA field mask */
#define LDPAA_FD_ERR_MASK	0x000000ff		/**< FD ERR field mask */
#define LDPAA_FD_FLCL_MASK	0xffffffff		/**< FD FLCL field mask */
#define LDPAA_FD_FLCH_MASK	0x0001ffff		/**< FD FLCH field mask */
#define LDPAA_FD_FLC_TOK_MASK	0xfffe0000		/**< FD FLC-TOK field mask */

/* FD fields Getters and Setters */
#define LDPAA_FD_GET_ADDRH(_fd) (((struct ldpaa_fd *)_fd)->addr_hi & LDPAA_FD_ADDRH_MASK) /**< Macro to get FD ADDRH field */
#define LDPAA_FD_GET_ADDRL(_fd) ((struct ldpaa_fd *)_fd)->addr_lo  /**< Macro to get FD ADDRL field */

#define LDPAA_FD_GET_ADDR(_fd) ((phys_addr_t)(((uint64_t)LDPAA_FD_GET_ADDRH(_fd) << 32) | (uint64_t)LDPAA_FD_GET_ADDRL(_fd))) /**< Macro to get FD ADDR field */
/**< Macro to get FD ADDRESS field.*/
/* Todo - 64/49 bit address. Phys to Virt? */
#define LDPAA_FD_SET_ADDR(_fd,_val)
/**< Macro to set FD ADDRESS field */
/* Todo - 64/49 bit address. Phys to Virt? */
#define LDPAA_FD_GET_SHORT_LENGTH(_fd) (((struct ldpaa_fd *)_fd)->length & LDPAA_FD_SHORT_LENGTH_MASK) /**< Macro to get FD SL-LENGTH field */
#define LDPAA_FD_GET_LENGTH(_fd) (((struct ldpaa_fd *)_fd)->length & LDPAA_FD_LENGTH_MASK) /**< Macro to get FD LENGTH field */
#define LDPAA_FD_SET_LENGTH(_fd,_val)
/**< Macro to set FD LENGTH field */
#define LDPAA_FD_GET_MEM(_fd)	\
	((((struct ldpaa_fd *)_fd)->length & LDPAA_FD_MEM_MASK) >> 20)
/**< Macro to get FD MEM field */
#define LDPAA_FD_SET_MEM(_fd,_val) \
	(((struct ldpaa_fd *)_fd)->length = ((((struct ldpaa_fd *)_fd)->length & ~LDPAA_FD_MEM_MASK) | (((val) << 20) & LDPAA_FD_MEM_MASK)))
/**< Macro to set FD MEM field */
#define LDPAA_FD_GET_BPID(_fd) \
	((((struct ldpaa_fd *)_fd)->offset & LDPAA_FD_BPID_MASK) >> 0)
/**< Macro to get FD BPID field */
#define LDPAA_FD_SET_BPID(_fd,_val)
/**< Macro to set FD BPID field */
#define LDPAA_FD_GET_IVP(_fd)
/**< Macro to get FD IVP field */
#define LDPAA_FD_SET_IVP(_fd,_val)
/**< Macro to set FD IVP field */
#define LDPAA_FD_GET_BMT(_fd)
/**< Macro to get FD BMT field */
#define LDPAA_FD_SET_BMT(_fd,_val)
/**< Macro to set FD BMT field */
#define LDPAA_FD_GET_OFFSET(_fd) \
	((((struct ldpaa_fd *)_fd)->offset & LDPAA_FD_OFFSET_MASK) >> 16)
/**< Macro to get FD OFFSET field */
#define LDPAA_FD_SET_OFFSET(_fd,_val)
/**< Macro to set FD OFFSET field */
#define LDPAA_FD_GET_FMT(_fd)
/**< Macro to get FD FMT field */
#define LDPAA_FD_SET_FMT(_fd,_val)
/**< Macro to set FD FMT field */
#define LDPAA_FD_GET_SL(_fd)
/**< Macro to get FD SL field */
#define LDPAA_FD_SET_SL(_fd,_val)
/**< Macro to set FD SL field */
#define LDPAA_FD_GET_FRC(_fd) \
	(((struct ldpaa_fd *)_fd)->frc)
/**< Macro to get FD FRC field */
#define LDPAA_FD_SET_FRC(_fd,_val) \
	(((struct ldpaa_fd *)_fd)->frc = _val)
/**< Macro to set FD FRC field */
#define LDPAA_FD_GET_ERR(_fd) \
	((((struct ldpaa_fd *)_fd)->control & LDPAA_FD_ERR_MASK) >> 0)
/**< Macro to get FD ERR field */
#define LDPAA_FD_SET_ERR(_fd,_val)
/**< Macro to set FD ERR field */
#define LDPAA_FD_GET_VA(_fd)
/**< Macro to get FD VA field */
#define LDPAA_FD_SET_VA(_fd,_val)
/**< Macro to set FD VA field */
#define LDPAA_FD_GET_CBMT(_fd)
/**< Macro to get FD CBMT field */
#define LDPAA_FD_SET_CBMT(_fd,_val)
/**< Macro to set FD CBMT field */
#define LDPAA_FD_GET_ASAL(_fd) \
	((((struct ldpaa_fd *)_fd)->control & LDPAA_FD_ASAL_MASK) >> 16)
/**< Macro to get FD ASAL field */
#define LDPAA_FD_SET_ASAL(_fd,_val)
/**< Macro to set FD ASAL field */
#define LDPAA_FD_GET_PTV2(_fd)
/**< Macro to get FD PTV2 field */
#define LDPAA_FD_SET_PTV2(_fd,_val)
/**< Macro to set FD PTV2 field */
#define LDPAA_FD_GET_PTV1(_fd)
/**< Macro to get FD PTV1 field */
#define LDPAA_FD_SET_PTV1(_fd,_val)
/**< Macro to set FD PTV1 field */
#define LDPAA_FD_GET_PTA(_fd) \
	((((struct ldpaa_fd *)_fd)->control & LDPAA_FD_PTA_MASK) >> 23)
/**< Macro to get FD PTA field */
#define LDPAA_FD_SET_PTA(_fd,_val)
/**< Macro to set FD PTA field */
#define LDPAA_FD_GET_DROPP(_fd) \
	((((struct ldpaa_fd *)_fd)->control & LDPAA_FD_DROPP_MASK) >> 24)
/**< Macro to get FD DROPP field */
#define LDPAA_FD_SET_DROPP(_fd,_val)
/**< Macro to set FD DROPP field */
#define LDPAA_FD_GET_SC(_fd) \
	((((struct ldpaa_fd *)_fd)->control & LDPAA_FD_SC_MASK) >> 27)
/**< Macro to get FD SC field */
#define LDPAA_FD_SET_SC(_fd,_val)
/**< Macro to set FD SC field */
#define LDPAA_FD_GET_DD(_fd)
/**< Macro to get FD DD field */
#define LDPAA_FD_SET_DD(_fd,_val)
/**< Macro to set FD DD field */
#define LDPAA_FD_GET_CS(_fd)
/**< Macro to get FD CS field */
#define LDPAA_FD_SET_CS(_fd,_val)
/**< Macro to set FD CS field */
#define LDPAA_FD_GET_AS(_fd)
/**< Macro to get FD AS field */
#define LDPAA_FD_SET_AS(_fd,_val)
/**< Macro to set FD AS field */
#define LDPAA_FD_GET_DS(_fd)
/**< Macro to get FD DS field */
#define LDPAA_FD_SET_DS(_fd,_val)
/**< Macro to set FD DS field */
#define LDPAA_FD_GET_FLC(_fd) (((uint64_t)(((struct ldpaa_fd *)_fd)->flc_hi)<<32) | (uint64_t)((struct ldpaa_fd *)_fd)->flc_lo)
/**< Macro to get FD FLC field */
#define LDPAA_FD_SET_FLC(_fd,_val)
/**< Macro to set FD FLC field */

/**************************************************************************//**
@Description   AIOP cache attributes - (rev2 support only)
Common AXI4 cache configuration words for AIOP accelerators
(CDMA, FDMA, STE, TMAN) and other DPAA accelerators (DCE).
They should be used to set xCACR accelerator registers.
All other combinations are either illegal according to ARM
specification or not permitted by this specification
Reference: Layerscape chassis architecture specification
*//***************************************************************************/
/* Common RW */
/* Non-cacheable non-coherent/register space access */
#define CACHE_AXI4_RW_REG_NON_CACHEABLE_NON_COHERENT 0b10000

/* Non-coherent read/write of cacheable memory, do not look up or
allocate in downstream cache */
#define CACHE_AXI4_RW_MEM_NON_COHERENT_NO_ALLOCATE_NO_LOOKUP 0b10011

/*Read*/
/* Coherent copy of cacheable memory, look up in downstream cache,
 * allocate on miss */
#define CACHE_AXI4_READ_MEM_COHERENT_ALLOCATE 0b00111

/* Non-coherent copy of cacheable memory, look up in
downstream cache, allocate on miss */
#define CACHE_AXI4_READ_MEM_NON_COHERENT_ALLOCATE 0b10111

/* Coherent copy of cacheable memory, look up in downstream
cache, no allocate on miss */
#define CACHE_AXI4_READ_MEM_COHERENT_NO_ALLOCATE 0b01011

/* Non-coherent copy of cacheable memory, look up in
downstream cache, no allocate on miss */
#define CACHE_AXI4_READ_MEM_NON_COHERENT_NO_ALLOCATE_LOOKUP 0b11011

/* Write */
/* Coherent write of cacheable memory, look up in downstream
cache, allocate on miss */
#define CACHE_AXI4_WRITE_MEM_COHERENT_ALLOCATE 0b01011

/* Non-coherent write of cacheable memory, look up in
downstream cache, allocate on miss */
#define CACHE_AXI4_WRITE_MEM_NON_COHERENT_ALLOCATE 0b11011

/* Coherent write of cacheable memory, look up in downstream
cache, no allocate on miss */
#define CACHE_AXI4_WRITE_MEM_COHERENT_NO_ALLOCATE 0b00111

/* Non-coherent write of cacheable memory, look up in
downstream cache, no allocate on miss */
#define CACHE_AXI4_WRITE_MEM_NON_COHERENT_NO_ALLOCATE_LOOKUP 0b10111

/** @} *//* end of ldpaa_g group */

#endif /* __FSL_LDPAA_H */
