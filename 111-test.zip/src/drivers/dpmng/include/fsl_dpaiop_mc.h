/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPAIOP_MC_H
#define __FSL_DPAIOP_MC_H

#include "fsl_dpmng_mc.h"
#include "fsl_event_pipe.h"
#include "drivers/fsl_aiop.h"
#include "elfdefinitions.h"

struct dpaiop;

/*! The address that MC expects to find the AIOP elf image */
#define DPAIOP_ELF_LOAD_ADDRESS 0x07000000
#define DPAIOP_ELF_LOAD_ADDRESS_LPVOID ((void*) DPAIOP_ELF_LOAD_ADDRESS)

#define DPAIOP_MAX_IRQ_NUM				1

#define DPAIOP_RESET_WAIT_FOR_TMAN_TRIES 60
#define DPAIOP_RESET_WAIT_FOR_TMAN_DELAY 1000

#define DPAIOP_RESET_WAIT_FOR_WRKS_TRIES 60
#define DPAIOP_RESET_WAIT_FOR_WRKS_DELAY 1000

#define DPAIOP_RESET_WAIT_FOR_TPH10_TRIES 10
#define DPAIOP_RESET_WAIT_FOR_TPH10_DELAY 1000

#define DPAIOP_RESET_WAIT_FOR_PH15_TRIES 10
#define DPAIOP_RESET_WAIT_FOR_PH15_DELAY 1000

#define DPAIOP_RESET_WAIT_FOR_TILE_RESET_TRIES 10
#define DPAIOP_RESET_WAIT_FOR_TILE_RESET_DELAY 1000

struct dpaiop_cfg {
	int aiop_id;
	int aiop_container_id;
};

struct dpaiop_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
};

struct dpaiop *dpaiop_allocate(void);

void dpaiop_deallocate(struct dpaiop *dpaiop);

int dpaiop_init(struct dpaiop *dpaiop,
                const struct dpaiop_cfg *cfg,
                const struct dpmng_dev_cfg *dev_cfg);

int dpaiop_set_dev_ctx(struct dpaiop *dpaiop,
		       const struct dpmng_dev_ctx *dev_ctx);


int dpaiop_virt2phys(struct dpaiop *dpaiop,  uintptr_t aiop_vaddr,
			phys_addr_t *paddr);

int dpaiop_open(struct dpaiop *dpaiop, int dpaiop_id);

int dpaiop_close(struct dpaiop *dpaiop);

void dpaiop_destroy(struct dpaiop *dpaiop);

int dpaiop_reset(struct dpaiop *dpaiop);

int dpaiop_get_attributes(struct dpaiop *dpaiop, struct dpaiop_attr *attr);

int dpaiop_set_irq(struct dpaiop *dpaiop,
                   uint8_t irq_index,
                   const struct mc_irq_cfg *irq_cfg);

int dpaiop_get_irq(struct dpaiop *dpaiop,
		  uint8_t irq_index,
		  struct mc_irq_cfg *irq_cfg);

int dpaiop_set_irq_enable(struct dpaiop *dpaiop,
                          uint8_t irq_index,
                          uint8_t en);

int dpaiop_get_irq_enable(struct dpaiop *dpaiop,
                          uint8_t irq_index,
                          uint8_t *en);

int dpaiop_set_irq_mask(struct dpaiop *dpaiop,
                        uint8_t irq_index,
                        uint32_t mask);

int dpaiop_get_irq_mask(struct dpaiop *dpaiop,
                        uint8_t irq_index,
                        uint32_t *mask);

int dpaiop_get_irq_status(struct dpaiop *dpaiop,
                          uint8_t irq_index,
                          uint32_t *status);

int dpaiop_clear_irq_status(struct dpaiop *dpaiop,
                            uint8_t irq_index,
                            uint32_t status);

int dpaiop_set_time_of_day(struct dpaiop *dpaiop,
                           uint64_t time_of_day);

int dpaiop_get_time_of_day(struct dpaiop *dpaiop,
                           uint64_t *time_of_day);

int dpaiop_set_resetable(struct dpaiop *dpaiop, int resetable);
int dpaiop_get_resetable(struct dpaiop *dpaiop, int *resetable);

#define DPAIOP_LOAD_OPT_DEBUG 			0x4000000000000000

struct dpaiop_load_cfg{
	uint64_t options;
	uint32_t img_size;
	void *img_iova;
	uint32_t args_size;
	void *args_iova;
	uint8_t tpc;
};

#define DPAIOP_RUN_OPT_DEBUG 			0x0000000000000001

#define LIBELF_IS_ELF(P) ((P)[EI_MAG0] == ELFMAG0 &&            \
        (P)[EI_MAG1] == ELFMAG1 && (P)[EI_MAG2] == ELFMAG2 &&   \
        (P)[EI_MAG3] == ELFMAG3)

int dpaiop_load(struct dpaiop *dpaiop, struct dpaiop_load_cfg *cfg);

struct dpaiop_run_cfg {
	uint64_t cores_mask;
	uint64_t options;
	uint32_t args_size;
	void *args_buffer;
	uint8_t tasks_per_core;
};

int dpaiop_run(struct dpaiop *dpaiop, const struct dpaiop_run_cfg *cfg);

struct dpaiop_sl_version {
	uint32_t major;
	uint32_t minor;
	uint32_t revision;
};

int dpaiop_get_sl_version(struct dpaiop *dpaiop,
               struct dpaiop_sl_version *version);

#define DPAIOP_STATE_RESET_DONE      0x00000000
#define DPAIOP_STATE_RESET_ONGOING   0x00000001

#define DPAIOP_STATE_LOAD_DONE       0x00000002
#define DPAIOP_STATE_LOAD_ONGIONG    0x00000004
#define DPAIOP_STATE_LOAD_ERROR      0x00000008

#define DPAIOP_STATE_BOOT_ONGOING    0x00000010
#define DPAIOP_STATE_BOOT_ERROR      0x00000020
#define DPAIOP_STATE_RUNNING         0x00000040

int dpaiop_get_state(struct dpaiop 	*dpaiop, uint32_t *state);

int dpaiop_ws_set_ep_entry(struct dpaiop *dpaiop,
                         uint32_t epid,
                         struct aiop_ep_entry_cfg *cfg);

int dpaiop_set_storage_profile(struct dpaiop *dpaiop,
                             uint32_t entry_id,
                             struct aiop_sp_cfg *cfg);

/* MC internal functions */
int dpaiop_open_cmdif_client(struct dpaiop *dpaiop);
int dpaiop_send_event(struct dpaiop *dpaiop, uint64_t *data, uint32_t size);

#endif /* __FSL_DPAIOP_MC_H */
