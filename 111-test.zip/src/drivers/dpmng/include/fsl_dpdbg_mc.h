/*
 * Copyright 2017-2019 NXP
 */

#ifndef __FSL_DPDBG_MC_H
#define __FSL_DPDBG_MC_H

#include "fsl_dpmng_mc.h"
#include "fsl_dpio_mc.h"
#include "fsl_dpseci_mc.h"
#include "fsl_dpni_mc.h"
#include "fsl_dpmac_mc.h"
#include "fsl_dpbp_mc.h"
#include "fsl_dpcon_mc.h"
#include "fsl_dpci_mc.h"
#include "fsl_dpmcp_mc.h"
#include "fsl_dpsw_mc.h"
#include "fsl_dpdmux_mc.h"
#include "fsl_dpdcei_mc.h"
#include "fsl_dpdmai_mc.h"

#define DPDBG_MAX_IRQ_NUM 		0

struct dpdbg;

struct dpdbg_cfg {
	int dpdbg_id;
	int dpdbg_container_id;
};

struct dpdbg_attr {
	int id;
};

int dpdbg_open(struct dpdbg *dpdbg, int dpdbg_id);
int dpdbg_close(struct dpdbg *dpdbg);

int dpdbg_get_attributes(struct dpdbg *dpdbg, struct dpdbg_attr *attr);
int dpdbg_get_dpmcp_info(struct dpdbg *dpdbg, struct dpmcp *dpmcp);
int dpdbg_get_dpio_info(struct dpdbg *dpdbg, struct dpio *dpio);
int dpdbg_get_dprc_info(struct dpdbg *dpdbg, struct dprc *dprc);
int dpdbg_get_dpbp_info(struct dpdbg *dpdbg, struct dpbp *dpbp);
int dpdbg_get_dpci_info(struct dpdbg *dpdbg, struct dpci *dpci);
int dpdbg_get_dpmac_info(struct dpdbg *dpdbg, struct dpmac *dpmac);
int dpdbg_get_dpni_info(struct dpdbg *dpdbg, struct dpni *dpni);
int dpdbg_get_dpsw_info(struct dpdbg *dpdbg, struct dpsw *dpsw);
int dpdbg_get_dpdmux_info(struct dpdbg *dpdbg, struct dpdmux *dpdmux);
int dpdbg_get_dpseci_info(struct dpdbg *dpdbg, struct dpseci *dpseci);
int dpdbg_get_dpcon_info(struct dpdbg *dpdbg, struct dpcon *dpcon);
int dpdbg_get_dpdcei_info(struct dpdbg *dpdbg, struct dpdcei *dpdcei);
int dpdbg_get_dpdmai_info(struct dpdbg *dpdbg, struct dpdmai *dpdmai);
int dpdbg_get_mem_info();
void get_peb_free_blocks(uint32_t *offset, uint32_t *size, int *used, uint64_t *start_addr);

/* MC internal functions */
struct dpdbg *dpdbg_allocate(void);
int dpdbg_get_container_id(struct dpdbg *dpdbg);
void dpdbg_deallocate(struct dpdbg *dpdbg);
int dpdbg_init(struct dpdbg *dpdbg, const struct dpmng_dev_cfg *dev_cfg, struct dpdbg_cfg *cfg);
void dpdbg_reset(struct dpdbg *dpdbg);
void dpdbg_destroy(struct dpdbg *dpdbg);

#endif /* __FSL_DPDBG_MC_H */
