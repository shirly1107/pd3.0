/**************************************************************************//**
 Copyright 2013 Freescale Semiconductor, Inc.

 @File          fsl_dpmng_mc.h

 @Description   This file contains LINK-MANAGER API.
 *//***************************************************************************/
#ifndef __FSL_DPMNG_MC_H
#define __FSL_DPMNG_MC_H

//#define DPMNG3_0

#include "fsl_types.h"
#include "fsl_enet.h"
#include "common/fsl_string.h"

#include "fsl_dbg.h"
#include "fsl_eiop_port.h"		/* enum eiop_port_type */
#include "drivers/fsl_qbman_portal_ex.h"
#include "fsl_qbman.h"

struct dpmng;

/**
 * @brief	User types (software contexts == container types)
 */
enum dpmng_ctx_type {
	DPMNG_CTX_TYPE_MC, /*! MC context */
	DPMNG_CTX_TYPE_GPP, /*! GPP context */
	DPMNG_CTX_TYPE_AIOP, /*! AIOP context */
	DPMNG_CTX_TYPE_SP
/*! Service Processor context */
};

/**
 * @brief	Access Management Qualifiers
 */
struct dpmng_amq {
	uint16_t icid; /*! Isolation Context ID */
	int pl; /*! Privilege level */
	int va; /*! Virtual Address */
	int bmt; /*! Bypass Memory Translation */
	int bdi; /*! Bypass DPAA Isolation */
};

/**
 * @brief	Device context (internal context needed for MC objects)
 */
struct dpmng_dev_ctx {
	enum dpmng_ctx_type type;
	/*!< User (container) type */
	struct dpmng_amq amq;
	/*!< Access Management Qualifiers of current container */
};

/**
 * @brief	Device context (internal context needed for MC objects)
 */
struct dpmng_dev_cfg {
	uint16_t id;
	/*!< Device id */
	void *device;
	/*!< Device handler for accessing the resource manager */
	struct dpmng_dev_ctx ctx;
};

/**
 * @brief	MC firmware version structure
 */
struct mc_version {
	uint32_t major;
	uint32_t minor;
	uint32_t revision;
};

/**
 * @brief	MC platform description structure
 */
struct mc_soc_version {
	uint32_t svr;
	uint32_t pvr;
};

/**
 * @brief   	Fills the structure of version information which includes:
 * 		soc_major;
 * 		soc_minor;
 * 		fw_major;
 * 		fw_minor;
 *
 * @returns	None.
 *
 */
void mc_get_version(struct mc_version *user_struct);

/**
 * @brief   	Fills the structure of platform information which includes:
 * 		svr - System Version (content of platform SVR register)
 *
 * @returns	None.
 *
 */
void mc_get_platform(struct mc_soc_version *platform);

/**
 * @brief   	allocate memory for dpmng handle
 *
 * @returns	dpmng handle on Success; NULL otherwise.
 *
 * @warning	None.
 */
struct dpmng *dpmng_allocate(void);

/**************************************************************************//**
 @Description	Registration information
 *//***************************************************************************/
struct dpmng_register {
//	uint32_t 		version;	/* L2 switch Version */
	struct device *resman_dev; /**< Resman device */
};

/**
 * @brief   	register required information for dpmng handle
 *
 * @returns	dpmng handle on Success; NULL otherwise.
 *
 * @warning	None.
 */
void dpmng_register(struct dpmng *dpmng, const struct dpmng_register *cfg);

/**************************************************************************//**
 @Group         ldpaa_g  LDPAA API

 @Description   TODO

 @{
 *//***************************************************************************/

/**************************************************************************//**
 @Group         dpmng_g  LDPAA IO API

 @Description   TODO

 @{
 *//***************************************************************************/

/**************************************************************************//**
 @Group		dpmng_init_grp DPMNG Initialization Unit

 @Description	DPMNG Initialization Unit

 @{
 *//***************************************************************************/

/**
 * @brief	Structure representing dpmng initialization parameters
 */
struct dpmng_cfg {
	int num_cores; /**< Number of Power PC cores */
};

/**
 * @brief	Structure representing dpmng portal initialization parameters
 */
struct dpmng_portal_cfg {
	int index;/**< logical id of the software portal */
	int swportal_id;/**< real id number of the software portal */
	void *swp; /**< handle to the software portal */
};

/**
 * @brief   	restore dpmng after WRIOP reset
 *
 * @param[in]	None.
 *
 * @returns	'0' on Success; error code otherwise.
 *
 * @warning	None.
 */
int dpmng_post_controllers_restore(void);

/**
 * @brief   	allocate memory for dpmng handle
 *
 * @returns	dpmng handle on Success; NULL otherwise.
 *
 * @warning	None.
 */
struct dpmng *dpmng_allocate(void);

/**
 * @brief   	initialize dpmng handle
 *
 * @param[in]	dpmng - dpmng handle
 * @param[in]   params - Initialization Parameters
 *
 * @returns	'0' on Success; error code otherwise.
 *
 * @warning	None.
 */
int dpmng_init(struct dpmng *dpmng, struct dpmng_cfg *params);

/**
 * @brief   	free dpmng handle
 *
 * @param[in]	dpmng - dpmng handle
 *
 * @returns	'0' on Success; error code otherwise.
 *
 * @warning	None.
 */
int dpmng_free(struct dpmng *dpmng);

/** @} *//* end of dpmng_init_grp group */
/** @} *//* end of dpmng_g group */
/** @} *//* end of ldpaa_g group */
int dpmng_init_swportal(struct dpmng *dpmng, struct dpmng_portal_cfg *params);

int dpmng_free_swportal(struct dpmng *dpmng, struct dpmng_portal_cfg *params);

/**
 * @brief   	get software portal handle
 *
 * @param[in]	dpmng - dpmng handle
 * @param[out]  portal - portal handle
 *
 * @returns	'0' on Success; error code otherwise.
 *
 * @warning	None.
 */
int dpmng_get_swportal(struct dpmng *dpmng, void **portal);

/**
 * @brief   	return the software portal handle - actually unlock it to
 *              allow different user to use it
 *
 * @param[in]	dpmng - dpmng handle
 * @param[in]   portal - portal handle
 *
 * @returns	'0' on Success; error code otherwise.
 *
 * @warning	None.
 */
int dpmng_put_swportal(struct dpmng *dpmng, void *portal);
void *dpmng_get_scratch(struct dpmng *dpmng);
void dpmng_put_scratch(struct dpmng *dpmng);
int dpmng_get_scratch_size(struct dpmng *dpmng);

int dpmng_init_cgid(struct dpmng *dpmng);
int dpmng_get_cgid(struct dpmng *dpmng);
int dpmng_restore_plcrid(struct dpmng *dpmng);
int dpmng_init_plcrid(struct dpmng *dpmng);
int dpmng_get_plcrid(struct dpmng *dpmng);
int dpmng_get_aiop_container_id(struct dpmng *dpmng);
int dpmng_init_rerr_fqid(struct dpmng *dpmng);
int dpmng_dump_rerr_fqid(struct dpmng *dpmng);
void dpmng_set_last_rerr_isr(uint32_t status);
uint32_t dpmng_rerr_isr_has_errors(uint32_t error_mask);
#ifdef TKT220573
int dpmng_init_rtn_fqid(struct dpmng *dpmng);
#endif
int dpmng_get_rtn_fqid(struct dpmng *dpmng);
void dpmng_set_rate_limit(struct dpmng *dpmng, uint64_t rate);
int dpmng_is_rate_allowed(struct dpmng *dpmng, uint64_t rate);
uint16_t dpmng_get_dcp_wqid(struct dpmng *dpmng, enum qbman_dcp dcp_type, uint8_t index);
int dpmng_init_dcp_wqid(struct dpmng *dpmng);

/*!
 * @name MC Status
 */
#define MC_INIT_DONE    	0x00000001  /*!< MC init done */
#define MC_SYS_INIT_ERR		((1 << 1) | MC_INIT_DONE) /*!< System init
                                                               error */
#define MC_DTC_INIT_ERR		((2 << 1) | MC_INIT_DONE) /*!< DTC init
                                                               error */
#define MC_RESMAN_INIT_ERR	((3 << 1) | MC_INIT_DONE) /*!< Resource Manager
							       init error */
#define MC_LINKMAN_INIT_ERR	((4 << 1) | MC_INIT_DONE) /*!< Link Manager
							       init error */
#define MC_CMDIF_INIT_ERR	((5 << 1) | MC_INIT_DONE) /*!< Command interface
							       init error */
#define MC_QBMAN_INIT_ERR	((6 << 1) | MC_INIT_DONE) /*!< QBMan init
                                                               error */
#define MC_EIOP_INIT_ERR	((7 << 1) | MC_INIT_DONE) /*!< EIOP init
                                                               error */
#define MC_AIOP_INIT_ERR	((8 << 1) | MC_INIT_DONE) /*!< AIOP init
                                                               error */
#define MC_DPMAC_INIT_ERR	((10 << 1) | MC_INIT_DONE) /*!< DPMAC init
                                                               error */
#define MC_DPRC_INIT_ERR	((11 << 1) | MC_INIT_DONE) /*!< DPRC init
                                                               error */
#define MC_DPMNG_INIT_ERR	((12 << 1) | MC_INIT_DONE) /*!< DPMNG init
                                                               error */
#define MC_DPIO_INIT_ERR	((13 << 1) | MC_INIT_DONE) /*!< DPIO init
                                                               error */
#define MC_DPBP_INIT_ERR	((14 << 1) | MC_INIT_DONE) /*!< DPBP init
                                                               error */
#define MC_DPNI_INIT_ERR	((15 << 1) | MC_INIT_DONE) /*!< DPNI init
                                                               error */
#define MC_DPSW_INIT_ERR	((16 << 1) | MC_INIT_DONE) /*!< DPSW init
                                                               error */
#define MC_CAAM_INIT_ERR	((17 << 1) | MC_INIT_DONE) /*!< CAAM init
                                                               error */
#define MC_DPCON_INIT_ERR	((18 << 1) | MC_INIT_DONE) /*!< DPCON init
                                                               error */
#define MC_DPCI_INIT_ERR	((19 << 1) | MC_INIT_DONE) /*!< DPCI init
                                                               error */
#define MC_DPSECI_INIT_ERR	((20 << 1) | MC_INIT_DONE) /*!< DPSECI init
                                                               error */
#define MC_GEN_INIT_ERR		((21 << 1) | MC_INIT_DONE) /*!< General init
							       error */
#define MC_DPDMUX_INIT_ERR	((22 << 1) | MC_INIT_DONE) /*!< DPDMUX init
                                                               error */
#define MC_DPC_ERR		((23 << 1) | MC_INIT_DONE) /*!< DPC init
                                                               error */
#define MC_LOG_INIT_ERR		((24 << 1) | MC_INIT_DONE) /*!< LOG init */

#define MC_DCE_INIT_ERR		((25 << 1) | MC_INIT_DONE) /*!< DCE init
                                                               error */

#define MC_DPAIOP_INIT_ERR	((26 << 1) | MC_INIT_DONE) /*!< DPAIOP init
                                                               error */

#define MC_DPMCP_INIT_ERR	((27 << 1) | MC_INIT_DONE) /*!< DPMCP init
                                                               error */

#define MC_DPDMAI_INIT_ERR	((28 << 1) | MC_INIT_DONE) /*!< DPDMAI init
								error */
#define MC_PEBM_INIT_ERR	((29 << 1) | MC_INIT_DONE) /*!< PEBM init
								error */

#define MC_QDMA_INIT_ERR	((30 << 1) | MC_INIT_DONE) /*!< QDMA init
								error */

#define MC_LO_PROCESS_ERR	((31 << 1) | MC_INIT_DONE) /*!< Layout process
                                                               error */
#define MC_LCFG_INIT_ERR	((35 << 1) | MC_INIT_DONE) /*!< LCFG init
								error */
#define MC_DPDCEI_INIT_ERR	((36 << 1) | MC_INIT_DONE) /*!< DPDCEI init
                                                               error */
#define MC_DPDBG_INIT_ERR	((37 << 1) | MC_INIT_DONE) /*!< DPDBG init
                                                               error */
#define MC_FM_INIT_ERR		((38 << 1) | MC_INIT_DONE) /*!< FM init
                                                               error */
#define MC_DPRTC_INIT_ERR	((39 << 1) | MC_INIT_DONE) /*!< DPRTC init
                                                               error */

#define MC_INCOMPATIBLE_ERR	((40 << 1) | MC_INIT_DONE) /*!< Incompatible SoC 
                                                               version */
/* @} */

/* magic word for delayed DPL processing */
#define BOOT_CODE_DELAYED_DPL_DEPLOYMENT	0xDD00

/**
 * @brief   	changes GSR to reflect an error that occured
 *
 * @param[in]   status - one of MC_ERR_XXXX
 *
 */
void dpmng_set_mc_status(uint32_t status);

/**
 * @brief   	Reads GSR to get the error status
 *
 * @returns    status - one or more ORed MC_ERR_XXXX flags
 *
 */
uint32_t dpmng_get_mc_status(void);

/**
 * @brief	Reads MC memory base (set by boot program)
 *
 * @returns	MC memory base (physical address)
 *
 */
phys_addr_t dpmng_get_mc_mem_base(void);

/**
 * @brief	Forward declaration
 *
 */
struct eiop_port_init_params;

/**
 * @brief	DPMNG port configuration
 *
 */
struct dpmng_port_cfg {
	uint16_t id; /* Port ID */
	int iop_id; /* WRIOP ID */
};

/**
 * @brief	DPMNG channel configuration
 *
 */
struct dpmng_channel_cfg {
	uint8_t cqchid; /* Class Queue Channel ID */
	uint8_t dcpid; /* Direct Connect Portal ID */
	uint8_t instance_id; /* CEETM instance ID */
};

/**
 * @brief        This API is called during attach NIC->L2SW port
 *
 * @param[in]	dpmng		DPMNG handle
 *
 * @param[in]	channel		Channel Configuration
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_port_add_channel_to_recycle(struct dpmng *dpmng,
	const struct dpmng_channel_cfg *channel);

/**
 * @brief        This API is called during attach L2SW->MAC
 *
 * @param[in]	dpmng		DPMNG handle
 *
 * @param[in]	port		Port Configuration
 *
 * @param[in]	channel		Channel Configuration
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_port_set_channel_to_phys(struct dpmng *dpmng,
	const struct dpmng_port_cfg *port,
	const struct dpmng_channel_cfg *channel);

/**
 * @brief        This API obtains MC access management qualifiers
 *
 * @param[out]	amq		access management qualifiers
 *
 * @returns     void
 */
void dpmng_get_amq(struct dpmng_amq *amq);

/**
 * @brief        This API is used for debugging
 *
 * @param[in]	dpmng		DPMNG handle
 *
 *
 * @returns      none
 */
void dpmng_dump(struct dpmng *dpmng);

/*****************************************************************************
 ******************************************************************************
 *			General Routines 				     *
 ******************************************************************************
 ******************************************************************************/

/**
 * @brief       This routine sets MC SoC window to reflect a
 * 				physical address window
 *
 * @param[in]	addr		A physical address to which the SoC window is
 * 				to be mapped to.
 *
 *
 * @returns     The virtual address that maps the base of the requested
 * 				physical address
 *
 * @warning	It is recommended to precede this routine call by a call to
 * 		dpmng_mc_save_soc_window and to follow it by a call to
 * 		dpmng_mc_restore_soc_window
 */
void *dpmng_mc_set_soc_window(phys_addr_t addr, struct dpmng_amq *dpmng_amq);

/**
 * @brief       This routine locks MC SoC window
 *
 * @param[in]	dpmng		DPMNG handle
 *
 *
 * @returns     None
 *
 * @warning	This routine must be followed by a call to
 *         	dpmng_mc_restore_soc_window in order to restore previous
 *         	settings.
 */
void dpmng_mc_lock_soc_window(struct dpmng *dpmng);
/**
 * @brief       This routine releases MC SoC window settings
 *
 * @param[in]	dpmng		DPMNG handle
 *
 *
 * @warning	This routine may only be called following a
 * 		dpmng_mc_set_soc_window call which had saved the previous
 * 		settings.
 */
void dpmng_mc_unlock_soc_window(struct dpmng *dpmng);

/**
 * @brief       This routine sets MC SoC window to reflect a
 * 				physical address window
 *
 * @param[in]	addr		A physical address to which the SoC window is
 * 				to be mapped to.
 *
 *
 * @returns     The virtual address that maps the base of the requested
 * 				physical address
 *
 * @warning	It is recommended to precede this routine call by a call to
 * 		dpmng_mc_save_ccsr_window and to follow it by a call to
 * 		dpmng_mc_restore_ccsr_window
 */
void *dpmng_mc_set_ccsr_window(phys_addr_t addr, struct dpmng_amq *dpmng_amq);
void dpmng_mc_revert_ccsr_window(void);

/**
 * @brief       This routine locks MC SoC window
 *
 * @param[in]	dpmng		DPMNG handle
 *
 *
 * @returns     None
 *
 * @warning	This routine must be followed by a call to
 *         	dpmng_mc_restore_ccsr_window in order to restore previous
 *         	settings.
 */
void dpmng_mc_lock_ccsr_window(struct dpmng *dpmng);
/**
 * @brief       This routine releases MC SoC window settings
 *
 * @param[in]	dpmng		DPMNG handle
 *
 *
 * @warning	This routine may only be called following a
 * 		dpmng_mc_set_ccsr_window call which had saved the previous
 * 		settings.
 */
void dpmng_mc_unlock_ccsr_window(struct dpmng *dpmng);


/**
 * @brief	copy data to/from DMA memory in the context of a device.
 *
 * @param[in]	dev		Device handle
 * @param[in]	local_addr	Local data buffer (effective address)
 * @param[in]	dev_addr	External data buffer (dev DMA address)
 * @param[in]	size		Size of data structure
 * @param[in]	from_device	0 to copy from local buffer to external one,
 *				1 to copy from external buffer to local one
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_dev_memcpy(struct device *dev, void *local_addr, dma_addr_t dev_addr,
		size_t size, int from_device);

/**
 * @brief	It checks if a dma/physical address (source) points to the same location as
 * a local address (destination) plus the MC Fw base address.
 *
 * @param[in]	dev			Device handle
 * @param[in]	local_addr	Local data buffer (effective address)
 * @param[in]	dev_addr	External data buffer (dev DMA address)
 *
 * @returns     .
 */
int dpmng_is_same_local_mc_address(struct device *dev, phys_addr_t src_addr, intptr_t dst_local_addr);

/* DMA direction */
enum dpmng_dma_direction {
	DPMNG_DMA_IN, /* MC is destination */
	DPMNG_DMA_OUT /* MC is source */
};

/**
 * @brief    Send commands using DMA
 *
 * @param[in]	dev		Device handle
 * @param[in]	vaddr		virtual address of data
 * @param[in]	size		size of data structure
 * @param[Out]	dest		destination data structure pointer
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_dma(struct device *dev,
	uint64_t src_addr,
	uint64_t dest_addr,
	uint32_t size,
	enum dpmng_dma_direction dma_dir);

int dpmng_dma_by_amq(struct dpmng_amq *src_amq,
	uint64_t src_addr,
	uint64_t dest_addr,
	uint32_t size,
	enum dpmng_dma_direction dma_dir);

void dpmng_clear_fqid(uint32_t fqid,
	struct qbman_result *retire_storage,
	int *retire_pending);

/* Clears a channel */
void dpmng_clear_channel(uint32_t channel_id);

static inline int resource_authorization(struct qbman_swp *sw_portal,
	int bdi,
	uint16_t icid,
	enum qbman_auth_type_e type,
	uint32_t *vrid,
	uint32_t rrid,
	uint32_t auth_flags,
	char *str)
{
	int err = 0;

	if (bdi)
		*vrid = rrid;
	else {

		ASSERT_COND(sw_portal);
		err = qbman_auth_add_find(sw_portal, icid, type, vrid, rrid,
						auth_flags);
		if (err != 0)
			pr_err("qbman_auth_add_find() failed for %s\n", str);
	}

	return err;
}

static inline int resource_deauthorization(struct qbman_swp *sw_portal,
	int bdi,
	uint16_t icid,
	enum qbman_auth_type_e type,
	uint32_t vrid,
	uint32_t auth_flags,
	char *str)
{
	int err = 0;

	if (!bdi) {
		ASSERT_COND(sw_portal);
		err = qbman_auth_delete(sw_portal, icid, type, vrid,
					auth_flags);
		if (err != 0)
			pr_err("qbman_auth_delete() failed for %s\n", str);
	}

	return err;
}


/**
 * @brief	DPMNG2.0.1
 */

/**
 * @brief	Restore Physical, virtual connections after WRIOP reset.
 *
 * @param[in]	dpmng		DPMNG handle
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_connections_restore(struct dpmng *dpmng);

/**
 * @brief	Initiliaze Physical, virtual connections
 *
 * @param[in]	dpmng		DPMNG handle
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_connections_init(struct dpmng *dpmng);
/**
 * @brief	obtain virtual connection id
 *
 * @param[in]	dpmng		DPMNG handle
 * @param[out]  conn_id		connection id
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_connection_virt_allocate(struct dpmng *dpmng, int *conn_id);

/**
 * @brief   obtain physical connection id
 *
 * @param[in]   dpmng       DPMNG handle
 * @param[in]   iop_id      WRIOP ID
 * @param[in]   mac_id      MAC ID
 * @param[out]  conn_id     connection id
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_connection_phys_allocate(struct dpmng *dpmng,
	int mac_id,
	int *conn_id);

int dpmng_connection_free(struct dpmng *dpmng, int conn_id);

/**
 * @brief	Virtual or physical access-point
 */
struct dpmng_accesspoint {
	int iop_id; /*! WRIOP ID */
	int dcp_id; /*! Direct Connect Portal ID */
	int lniid; /*! Logical Network Interface ID */
	int cqchid; /*! CQ Channel */
	int ceetm_id; /*! CEETM ID */
	int ifpid; /*! IFPID */
	int ppid; /*! Physical Port ID*/
	int dctidx[DPMNG_MAX_DCTIDX_ALLOC]; /*! DCTable index */
	int lfqmtidx[DPMNG_MAX_LFQMTIDX_ALLOC]; /*! Logical frame queue index */
	int lfq_cnt; /*! number of lfq resources */
};

/**
 * @brief	Obtain virtual endpoint
 *
 * @param[in]	dpmng		DPMNG handle
 * @param[in]   conn_id		connection id
 * @param[in]   ap_id		access point id (0/1)
 * @param[out]  ap		end point information
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_connection_get_accesspoint(struct dpmng *dpmng,
	int conn_id,
	int ap_id, uint32_t bandwidth,
	struct dpmng_accesspoint *ap);

/**
 * @brief	Allocate a CEETM channel
 *
 * @param[in]	dpmng				DPMNG handle
 * @param[out]  channel_id_array	array to store channel id values
 * @param[in]   dcp_id				dcp id
 * @param[in]   ceetm_id			ceetm instance
 * @param[in]   num_res				number of allocated resources
 * @returns     Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_connection_alloc_ceetm_channel(struct dpmng *dpmng,
	int *channel_id_array, int dcp_id, int ceetm_id,
	int num_res);

/**
 * @brief	Free a list CEETM channels
 *
 * @param[in]	dpmng				DPMNG handle
 * @param[in]   channel_id_array	array to store channel id values
 * @param[in]   dcp_id				dcp id
 * @param[in]   ceetm_id			ceetm instance
 * @param[in]   num_res				number of allocated resources
 * @returns     Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_connection_free_ceetm_channel(struct dpmng *dpmng,
	int *channel_id_array, int dcp_id, int ceetm_id,
	int num_res);

int dpmng_connection_virt_lniid(struct dpmng *dpmng,
	struct dpmng_accesspoint *ap);

/**
 * @brief	Allocate access point bandwidth
 *
 * @param[in]	dpmng		DPMNG handle
 * @param[in]   ap		access point
 * @param[in]   bandwidth 	required bandwidth
 * @returns     Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_connection_allocate_bandwidth(struct dpmng *dpmng,
	const struct dpmng_accesspoint *ap,
	uint32_t bandwidth);

/**
 * @brief	Free access point bandwidth
 *
 * @param[in]	dpmng		DPMNG handle
 * @param[in]   ap		access point
 * @returns     Completion status. '0' on Success; Error code otherwise.
 */
int dpmng_connection_free_bandwidth(struct dpmng *dpmng,
	const struct dpmng_accesspoint *ap);

int dpmng_phys_allocate_bandwidth(struct dpmng *dpmng,
	const struct dpmng_accesspoint *ap,
	uint32_t bandwidth);

int dpmng_phys_free_bandwidth(struct dpmng *dpmng,
	const struct dpmng_accesspoint *ap);

/**
 * @brief	miscellaneous
 */
int dpmng_init_management_port(struct dpmng *dpmng);

void dpmng_set_dpaa_sys_ddr_region(void);

int dpmng_mctiny(void);

/**
 * @brief	DPMNG3.0
 */
int dpmng_accesspoints_init(struct dpmng *dpmng);

/* Allocate Access point API */
#define DPMNG_COND_EQ_IOP_ID            0x00000001      /* iop_id */
#define DPMNG_COND_EQ_DCP_ID            0x00000002      /* dcp_id */
#define DPMNG_COND_EQ_CEETM_ID          0x00000004      /* ceetm_id */
#define DPMNG_COND_EQ_LNI_ID            0x00000008      /* lni id */

#define DPMNG_COND_NEQ_IOP_ID            0x00000010
#define DPMNG_COND_NEQ_DCP_ID            0x00000020
#define DPMNG_COND_NEQ_CEETM_ID          0x00000040
#define DPMNG_COND_NEQ_LNI_ID            0x00000080

int qbman_connection_phys_set_state(int mac_id, int eiop_id, int txstate);

int qbman_connections_all_phys_recycle_set_state(int txstate);

struct dpmng_allocate_cond {
        uint32_t	cond_fields;
        int             iop_id;         /* WRIOP ID */
        int             dcp_id;         /* Direct Connect Portal ID */
        int             ceetm_id;       /* CEETM ID */
        int		lni_id;		/* lni id */
};

int dpmng_accesspoint_allocate(
        struct dpmng                    *dpmng, /* DPMNG context */
        const struct dpmng_allocate_cond *cond,   /* condition */
        struct dpmng_accesspoint        *ap     /* accesspoint */
        );

int dpmng_accesspoint_free(
        struct dpmng                    *dpmng, /* DPMNG context */
        struct dpmng_accesspoint        *ap     /* accesspoint */
        );


/* returns 1 if the SoC supports TCAM and can do classification masking */
int dpmng_soc_has_tcam(int eiop_id);

int dpmng_soc_has_orp();

/**
 *  @brief	Allocate lfqmtidx resources
 *
 *   @param[in]		dpmng		DPMNG handle
 *   @param[out]	lfqmtidx	array to store allocated resources
 *   @param[in]		dcp_id		DCP id (from AP structure)
 *   @param[in]		ceetm_id	CEETM instance id (from AP structure)
 *   @param[in]		num_res		number of resources to allocate
 */
int dpmng_connection_alloc_lfqmtidx(struct dpmng *dpmng,
		int *lfqmtidx,
		int dcp_id, int ceetm_id,
		int num_res);

/**
 *  @brief	Allocate lfqmtidx resources
 *
 *   @param[in]		dpmng		DPMNG handle
 *   @param[in]		lfqmtidx	array with lfqmtidx resource
 *   @param[in]		dcp_id		DCP id (from AP structure)
 *   @param[in]		ceetm_id	CEETM instance id (from AP structure)
 *   @param[in]		num_res		number of resources
 */
int dpmng_connection_free_lfqmtidx(struct dpmng *dpmng,
		int *lfqmtidx,
		int dcp_id, int ceetm_id,
		int num_res);

#endif /* __FSL_DPMNG_MC_H */
