/*
 * Copyright 2013-2021 NXP
 */

#ifndef __FSL_DPSW_MC_H
#define __FSL_DPSW_MC_H

#include "fsl_net.h"
#include "fsl_types.h"
#include "fsl_linkman.h"
#include "fsl_dpmng_mc.h"

/*!< Forward declaration */
struct dpsw;

#define DPSW_MAX_IRQ_NUM		2
#define DPSW_IRQ_INDEX_IF		0x0000
#define DPSW_IRQ_INDEX_L2SW		0x0001
#define DPSW_IRQ_EVENT_LINK_CHANGED	0x0001
#define DPSW_IRQ_EVENT_ENDPOINT_CHANGED	0x0002

#define DPSW_MAX_PRIORITIES	8	/* Maximum number of Priorities */
#define DPSW_MAX_TC             8       /* Maximum number of TC */
#define DPSW_MAX_IF		64	/* Maximum number of Interfaces */
#define DPSW_MAX_LAG    8

int dpsw_open(struct dpsw *dpsw, int dpsw_id);

int dpsw_close(struct dpsw *dpsw);

#define DPSW_OPT_FLOODING_DIS			0x0000000000000001
#define DPSW_OPT_MULTICAST_DIS			0x0000000000000004
#define DPSW_OPT_CTRL_IF_DIS			0x0000000000000010
#define DPSW_OPT_FLOODING_METERING_DIS	0x0000000000000020
#define DPSW_OPT_METERING_EN			0x0000000000000040
#define DPSW_OPT_BP_PER_IF				0x0000000000000080
#define DPSW_OPT_LAG_DIS				0x0000000000000100

enum dpsw_component_type {
	DPSW_COMPONENT_TYPE_C_VLAN = 0,
	DPSW_COMPONENT_TYPE_S_VLAN	
};

enum dpsw_flooding_cfg {
	DPSW_FLOODING_PER_VLAN = 0,
	DPSW_FLOODING_PER_FDB,
};

enum dpsw_broadcast_cfg {
	DPSW_BROADCAST_PER_OBJECT = 0,
	DPSW_BROADCAST_PER_FDB,
};

struct dpsw_cfg {
	uint16_t num_ifs;
	struct {
		uint64_t options;
		uint16_t max_vlans;
		uint8_t max_fdbs;
		uint16_t max_fdb_entries;
		uint16_t fdb_aging_time;
		uint16_t max_fdb_mc_groups;
		uint8_t max_meters_per_if;
	   	enum dpsw_component_type component_type;
		uint8_t lag[DPSW_MAX_LAG];
	   	/*LAG parameter: Each array element represents the interfaces in each LAG group defined in DPL
	   	 * The LAG interfaces are stored in an 8 bit number; when an interface is in a LAG group, the bit will be set to 1*/
		uint16_t mem_size;
		enum dpsw_flooding_cfg flooding_cfg;
		enum dpsw_broadcast_cfg broadcast_cfg;
	} adv;
};

int dpsw_create(struct dpsw *dpsw, const struct dpsw_cfg *cfg);

void dpsw_destroy(struct dpsw *dpsw);

int dpsw_set_dev_ctx(struct dpsw *dpsw, const struct dpmng_dev_ctx *dev_ctx);

struct dpsw_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
	uint64_t options;
	uint16_t max_vlans;
	uint8_t max_meters_per_if;
	uint8_t max_fdbs;
	uint16_t max_fdb_entries;
	uint16_t fdb_aging_time;
	uint16_t max_fdb_mc_groups;
	uint16_t mem_size;
	uint16_t num_ifs;
	uint16_t num_vlans;
	uint8_t num_fdbs;
   	enum dpsw_component_type component_type;
	enum dpsw_flooding_cfg flooding_cfg;
	enum dpsw_broadcast_cfg broadcast_cfg;
};

int dpsw_get_attributes(struct dpsw *dpsw, struct dpsw_attr *attr);

int dpsw_enable(struct dpsw *dpsw);

int dpsw_disable(struct dpsw *dpsw);

int dpsw_is_enabled(struct dpsw *dpsw, int *en);

int dpsw_reset(struct dpsw *dpsw);

enum dpsw_policer_mode {
	DPSW_POLICER_DIS = 0,
	DPSW_POLICER_EN = 1
};

struct dpsw_policer_cfg {
	enum dpsw_policer_mode mode;
};

int dpsw_set_policer(struct dpsw *dpsw, const struct dpsw_policer_cfg *cfg);

struct dpsw_buffer_depletion_cfg {
	uint32_t entrance_threshold;
	uint32_t exit_threshold;
	uint64_t wr_addr;
};

int dpsw_set_buffer_depletion(struct dpsw *dpsw,
			      const struct dpsw_buffer_depletion_cfg *cfg);

int dpsw_set_reflection_if(struct dpsw *dpsw, uint16_t if_id);

int dpsw_set_ctrl_if(struct dpsw *dpsw, uint16_t if_id);

int dpsw_get_ctrl_if(struct dpsw *dpsw, uint16_t *if_id);

enum dpsw_action {
	DPSW_ACTION_DROP = 0,
	DPSW_ACTION_REDIRECT = 1
};

#define DPSW_PTP_OPT_UPDATE_FCV	0x1

struct dpsw_ptp_v2_cfg {
	int enable;
	uint16_t time_offset;
	uint32_t options;
};

int dpsw_set_ptp_v2(struct dpsw *dpsw, const struct dpsw_ptp_v2_cfg *cfg);

struct dpsw_parser_error_action_cfg {
	uint64_t		error;
	enum dpsw_action	action;
};

#define DPSW_PARSE_ERR     		0x00000001
#define DPSW_PARSE_ERR_ETH     		0x00000002
#define DPSW_PARSE_ERR_LLC_SNAP   	0x00000004
#define DPSW_PARSE_ERR_VLAN VLAN   	0x00000008
#define DPSW_PARSE_ERR_MPLS   		0x00000010
#define DPSW_PARSE_ERR_ARP     		0x00000020
#define DPSW_PARSE_ERR_L2_SOFT     	0x00000040
#define DPSW_PARSE_ERR_IP1    		0x00000080
#define DPSW_PARSE_ERR_IPN    		0x00000100
#define DPSW_PARSE_ERR_MIN_ENCAP     	0x00000200
#define DPSW_PARSE_ERR_GRE     		0x00000400
#define DPSW_PARSE_ERR_L3_SOFT     	0x00000800
#define DPSW_PARSE_ERR_UDP     		0x00001000
#define DPSW_PARSE_ERR_TCP     		0x00002000
#define DPSW_PARSE_ERR_IPSEC     	0x00004000
#define DPSW_PARSE_ERR_SCTP SCTP   	0x00008000
#define DPSW_PARSE_ERR_DCCP DCCP  	0x00010000
#define DPSW_PARSE_ERR_L4_SOFT     	0x00020000
#define DPSW_PARSE_ERR_GTP     		0x00040000
#define DPSW_PARSE_ERR_ESP    		0x00080000
#define DPSW_PARSE_ERR_L5_SOFT     	0x00100000

int dpsw_set_parser_error_action(struct dpsw *dpsw,
        const struct dpsw_parser_error_action_cfg   *cfg
);

int dpsw_if_set_flooding(struct dpsw *dpsw, uint16_t if_id, int en);


int dpsw_if_set_broadcast(struct dpsw *dpsw, uint16_t if_id, int en);


int dpsw_if_set_multicast(struct dpsw *dpsw, uint16_t if_id, int en);

#ifdef MC_CLI
int dpsw_if_get_qdid(struct dpsw *dpsw, uint16_t if_id, int *qdid);
#endif

struct dpsw_tci_cfg {
	uint8_t pcp;
	uint8_t dei;
	uint16_t vlan_id;
};

int dpsw_if_set_tci(struct dpsw *dpsw,
		    uint16_t if_id,
	const struct dpsw_tci_cfg *cfg);

int dpsw_if_get_tci(struct dpsw *dpsw,
		    uint16_t if_id,
		    struct dpsw_tci_cfg *cfg);

enum dpsw_stp_state {
	DPSW_STP_STATE_BLOCKING = 0,
	DPSW_STP_STATE_LISTENING = 1,
	DPSW_STP_STATE_LEARNING = 2,
	DPSW_STP_STATE_FORWARDING = 3
};

struct dpsw_stp_cfg {
	uint16_t vlan_id;
	enum dpsw_stp_state state;
};

int dpsw_if_set_stp(struct dpsw *dpsw,
		    uint16_t if_id,
		    const struct dpsw_stp_cfg *cfg);

enum dpsw_accepted_frames {
	DPSW_ADMIT_ALL = 1,
	DPSW_ADMIT_ONLY_VLAN_TAGGED = 3,
};

struct dpsw_accepted_frames_cfg {
	enum dpsw_accepted_frames type;
	enum dpsw_action unaccept_act;
};


int dpsw_if_set_accepted_frames(struct dpsw *dpsw,
				uint16_t if_id,
	const struct dpsw_accepted_frames_cfg *cfg);

int dpsw_if_set_accept_all_vlan(struct dpsw *dpsw,
				uint16_t if_id,
	int accept_all);

enum dpsw_counter {
	DPSW_CNT_ING_FRAME = 0x0,
	DPSW_CNT_ING_BYTE = 0x1,
	DPSW_CNT_ING_FLTR_FRAME = 0x2,
	DPSW_CNT_ING_FRAME_DISCARD = 0x3,
	DPSW_CNT_ING_MCAST_FRAME = 0x4,
	DPSW_CNT_ING_MCAST_BYTE = 0x5,
	DPSW_CNT_ING_BCAST_FRAME = 0x6,
	DPSW_CNT_ING_BCAST_BYTES = 0x7,
	DPSW_CNT_EGR_FRAME = 0x8,
	DPSW_CNT_EGR_BYTE = 0x9,
	DPSW_CNT_EGR_FRAME_DISCARD = 0xa,
	DPSW_CNT_EGR_STP_FRAME_DISCARD = 0xb,
	DPSW_CNT_ING_NO_BUFFER_DISCARD = 0xc,
};

int dpsw_if_get_counter(struct dpsw *dpsw,
			uint16_t if_id,
	enum dpsw_counter type,
	uint64_t *counter);

int dpsw_if_set_counter(struct dpsw *dpsw,
			uint16_t if_id,
	enum dpsw_counter type,
	uint64_t counter);

struct dpsw_counters_cfg {
	uint64_t	ing_frame;
	uint64_t	ing_byte;
	uint64_t	ing_fltr_frame;
	uint64_t	ing_frame_discard;
	uint64_t	ing_mcast_frame;
	uint64_t	ing_mcast_byte;
	uint64_t	ing_bcast_frame;
	uint64_t	ing_bcast_bytes;
	uint64_t	egr_frame;
	uint64_t	egr_byte;
	uint64_t	egr_frame_discard;
	uint64_t	erg_mcast_frame;
	uint64_t	egr_mcast_byte;
	uint64_t	egr_bcast_frame;
	uint64_t	egr_bcast_bytes;
	uint64_t	egr_stp_frame_discard;	
};

int dpsw_if_get_counters(struct dpsw  *dpsw, uint16_t  if_id,
	struct dpsw_counters_cfg  *counters);

enum dpsw_priority_selector {
        DPSW_PRIORITY_SELECTOR_PCP,
        DPSW_PRIORITY_SELECTOR_DSCP,
        DPSW_PRIORITY_SELECTOR_NO_CHANGE,
};

/**
 * @brief	Traffic classes scheduling
 *
 */
enum dpsw_schedule_mode {
        DPSW_SCHED_STRICT_PRIORITY,     /* Strict priority */
        DPSW_SCHED_WEIGHTED,            /* Enhance transmission selection */
 };

struct dpsw_tx_sched_cfg {
       enum dpsw_schedule_mode mode;	/* Strict or ETS */
       uint16_t  delta_bandwidth;   	/* weighted Bandwidth */
};

struct dpsw_tx_selection_cfg {
        enum dpsw_priority_selector  priority_selector; /* IEEE802.1Q/DSCP */
        uint8_t tc_id[DPSW_MAX_PRIORITIES];     	/* TC mapping */

        /* Traffic classes configuration */
        struct dpsw_tx_sched_cfg  tc_sched[DPSW_MAX_TC];
};

struct dpsw_prio_selector_cfg {
		enum dpsw_priority_selector priority_selector;
};

int dpsw_if_set_tx_selection(struct dpsw *dpsw, uint16_t if_id,
	struct dpsw_tx_selection_cfg *ts);
int dpsw_if_set_prio_selector(struct dpsw *dpsw, uint16_t if_id,
	struct dpsw_prio_selector_cfg *ps);

enum dpsw_reflection_filter {
	DPSW_REFLECTION_FILTER_INGRESS_ALL = 0,
	DPSW_REFLECTION_FILTER_INGRESS_VLAN = 1
};

struct dpsw_reflection_cfg {
	enum dpsw_reflection_filter filter;
	uint16_t vlan_id;
};

int dpsw_if_add_reflection(struct dpsw *dpsw,
			   uint16_t if_id,
	const struct dpsw_reflection_cfg *cfg);

int dpsw_if_remove_reflection(struct dpsw *dpsw,
			      uint16_t if_id,
	const struct dpsw_reflection_cfg *cfg);

enum dpsw_metering_mode {
	DPSW_METERING_MODE_NONE,          /*! metering disabled */
	DPSW_METERING_MODE_RFC2698,       /*! RFC 2698 */
	DPSW_METERING_MODE_RFC4115        /*! RFC 4115 */
};

enum dpsw_metering_unit {
	DPSW_METERING_UNIT_BYTES,
	DPSW_METERING_UNIT_PACKETS
};

struct dpsw_metering_cfg {
        enum dpsw_metering_mode     mode;
        enum dpsw_metering_unit    units;
        uint32_t        cir;    /*! Committed information rate (CIR) b/s */
        uint32_t        eir;    /*! Peak information rate (PIR) b/s  rfc2698
                                    Excess information rate (EIR) b/s rfc4115 */
        uint32_t        cbs;    /*! Committed burst size (CBS) in bytes */
        uint32_t        ebs;    /*! Peak burts size (PBS) in bytes for rfc2698
                                    Excess bust size (EBS) in bytes rfc4115 */
};

int dpsw_if_set_flooding_metering(struct dpsw *dpsw,
                        uint16_t if_id,
                        struct dpsw_metering_cfg *cfg);

int dpsw_if_set_metering(struct dpsw *dpsw,
                        uint16_t if_id,
                        uint8_t tc_id,
                        struct dpsw_metering_cfg *cfg);

#ifdef MC_CLI
struct dpsw_metering_counters {
   uint32_t red;
   uint32_t yellow;
   uint32_t green;     
};

int dpsw_if_get_metering(struct dpsw *dpsw, 
        uint16_t if_id,
        uint8_t tc_id,
        struct dpsw_metering_counters *counters);
#endif

enum dpsw_early_drop_unit {
        DPSW_EARLY_DROP_UNIT_BYTES,
        DPSW_EARLY_DROP_UNIT_PACKETS,
        DPSW_EARLY_DROP_UNIT_BUFFERS
};

enum dpsw_early_drop_mode {
        DPSW_EARLY_DROP_MODE_NONE,
        DPSW_EARLY_DROP_MODE_TAIL,
        DPSW_EARLY_DROP_MODE_WRED
};

struct dpsw_wred_cfg {
        uint64_t                min_threshold;            /* Minimum threshold */
        uint64_t                max_threshold;            /* Maximum threshold */
        /* Maximum probability 0-100% */
        uint8_t                 drop_probability;
};

struct dpsw_early_drop_cfg {
        enum dpsw_early_drop_mode       drop_mode; 	/* Drop mode */
	enum dpsw_early_drop_unit	units;	/* Count mode */
        /* WRED parameters */
        struct dpsw_wred_cfg          yellow; 	/* yellow */
        struct dpsw_wred_cfg       	green;     	/* green */
        /* Tail drop parameters */
        uint32_t                	tail_drop_threshold;   /* Tail drop threshold*/
};

int dpsw_if_tc_set_early_drop(struct dpsw *dpsw,
                        uint16_t if_id,
                        uint8_t tc_id,
                        const struct dpsw_early_drop_cfg *drop_cfg);

struct dpsw_custom_tpid_cfg {
	uint16_t tpid;
};

int dpsw_add_custom_tpid(struct dpsw *dpsw,
	const struct dpsw_custom_tpid_cfg *cfg);

int dpsw_remove_custom_tpid(struct dpsw *dpsw,
	const struct dpsw_custom_tpid_cfg *cfg);

struct dpsw_transmit_rate_cfg {
	uint32_t rate;
};

int dpsw_if_set_transmit_rate(struct dpsw *dpsw,
			      uint16_t if_id,
	const struct dpsw_transmit_rate_cfg *cfg);

enum dpsw_bw_algo {
	DPSW_BW_ALGO_STRICT_PRIORITY = 0,
	DPSW_BW_ALGO_CREDIT_BASED = 1
};

struct dpsw_bandwidth_cfg {
	enum dpsw_bw_algo algo;
	uint8_t delta_bandwidth;
};

int dpsw_if_tc_set_bandwidth(struct dpsw *dpsw,
			     uint16_t if_id,
	uint8_t tc_id,
	const struct dpsw_bandwidth_cfg *cfg);

int dpsw_if_enable(struct dpsw *dpsw, uint16_t if_id);

int dpsw_if_disable(struct dpsw *dpsw, uint16_t if_id);

struct dpsw_queue_congestion_cfg {
	uint32_t entrance_threshold;
	uint32_t exit_threshold;
	uint64_t wr_addr;
};

#define DPSW_PFC_TRIG_QUEUE_CNG		0x01
#define DPSW_PFC_TRIG_BUFFER_DPL	0x02

int dpsw_if_tc_set_queue_congestion(struct dpsw *dpsw,
				    uint16_t if_id,
	uint8_t tc_id,
	const struct dpsw_queue_congestion_cfg *cfg);

struct dpsw_pfc_cfg {
	int receiver;
	int initiator;
	uint32_t initiator_trig;
	uint16_t pause_quanta;
};

int dpsw_if_tc_set_pfc(struct dpsw *dpsw,
		       uint16_t if_id,
	uint8_t tc_id,
	struct dpsw_pfc_cfg *cfg);

struct dpsw_cn_cfg {
	int enable;
};


int dpsw_if_tc_set_cn(struct dpsw *dpsw,
		      uint16_t if_id,
	uint8_t tc_id,
	const struct dpsw_cn_cfg *cfg);

struct dpsw_if_attr {
	uint8_t num_tcs;
	uint32_t rate;
	uint64_t options;
	int    enabled;
	int accept_all_vlan;
	enum dpsw_accepted_frames admit_untagged;
	uint16_t qdid;
};

int dpsw_if_get_attributes(struct dpsw *dpsw,
			   uint16_t if_id,
	struct dpsw_if_attr *attr);

enum dpsw_cipher_suite {
	DPSW_MACSEC_GCM_AES_128 = 0,
	DPSW_MACSEC_GCM_AES_256 = 1
};

struct dpsw_macsec_cfg {
	int enable;
	uint64_t sci;
	enum dpsw_cipher_suite cipher_suite;
};

int dpsw_if_set_macsec(struct dpsw *dpsw,
		       uint16_t if_id,
	const struct dpsw_macsec_cfg *cfg);

int dpsw_if_set_max_frame_length(struct dpsw *dpsw,
				 uint16_t	if_id,
	uint16_t	frame_length);

int dpsw_if_get_max_frame_length(struct dpsw *dpsw,
				 uint16_t    if_id,
	uint16_t    *frame_length);

#define DPSW_LINK_OPT_AUTONEG		0x0000000000000001ULL
#define DPSW_LINK_OPT_HALF_DUPLEX 	0x0000000000000002ULL
#define DPSW_LINK_OPT_PAUSE		0x0000000000000004ULL
#define DPSW_LINK_OPT_ASYM_PAUSE	0x0000000000000008ULL

struct dpsw_link_cfg {
	uint32_t rate;
	uint64_t options;
	uint64_t advertising;
};

struct dpsw_link_state {
        uint32_t rate;
        uint64_t options;
        int      up;
        int      state_valid;
    	uint64_t supported;
    	uint64_t advertising;        
};

int dpsw_if_set_link_cfg(struct dpsw *dpsw, uint16_t if_id,
	struct dpsw_link_cfg *cfg);

int dpsw_if_get_link_state(struct dpsw *dpsw, uint16_t if_id,
	struct dpsw_link_state *state);

struct dpsw_vlan_cfg {
	uint16_t fdb_id;
};

int dpsw_vlan_add(struct dpsw *dpsw,
		  uint16_t vlan_id,
	const struct dpsw_vlan_cfg *cfg);

#define DPSW_VLAN_ADD_IF_OPT_FDB_ID		0x0001

struct dpsw_vlan_if_cfg {
	uint16_t num_ifs;
	uint16_t options;
	uint16_t fdb_id;
	uint16_t if_id[DPSW_MAX_IF];
};

int dpsw_vlan_add_if(struct dpsw *dpsw,
		     uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg);

int dpsw_vlan_add_if_untagged(struct dpsw *dpsw,
			      uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg);

int dpsw_vlan_add_if_flooding(struct dpsw *dpsw,
			      uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg);

int dpsw_vlan_remove_if(struct dpsw *dpsw,
			uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg);

int dpsw_vlan_remove_if_untagged(struct dpsw *dpsw,
				 uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg);

int dpsw_vlan_remove_if_flooding(struct dpsw *dpsw,
				 uint16_t vlan_id,
	const struct dpsw_vlan_if_cfg *cfg);

int dpsw_vlan_remove(struct dpsw *dpsw, uint16_t vlan_id);

struct dpsw_vlan_attr {
	uint16_t 	fdb_id;
	uint16_t 	num_ifs;
	uint16_t	num_untagged_ifs;
	uint16_t	num_flooding_ifs;
};

int dpsw_vlan_get_attributes(struct dpsw *dpsw,
	uint16_t vlan_id,
	struct dpsw_vlan_attr *attr);

int dpsw_vlan_get_if(struct dpsw *dpsw,
	uint16_t vlan_id,
	struct dpsw_vlan_if_cfg *cfg);

int dpsw_vlan_get_if_flooding(struct dpsw *dpsw,
	uint16_t vlan_id,
	struct dpsw_vlan_if_cfg *cfg);

int dpsw_vlan_get_if_untagged(struct dpsw *dpsw,
	uint16_t vlan_id,
	struct dpsw_vlan_if_cfg *cfg);

struct dpsw_fdb_cfg {
	uint16_t num_fdb_entries;
	uint16_t fdb_aging_time;
};

int dpsw_fdb_add(struct dpsw *dpsw,
		 uint16_t *fdb_id,
	const struct dpsw_fdb_cfg *cfg);

int dpsw_fdb_remove(struct dpsw *dpsw, uint16_t fdb_id);

enum dpsw_fdb_entry_type {
	DPSW_FDB_ENTRY_STATIC = 0,
	DPSW_FDB_ENTRY_DINAMIC = 1
};

struct dpsw_fdb_unicast_cfg {
	enum dpsw_fdb_entry_type type;
	uint8_t mac_addr[6];
	uint16_t if_egress;
};

int dpsw_fdb_add_unicast(struct dpsw *dpsw,
			 uint16_t fdb_id,
			 const struct dpsw_fdb_unicast_cfg *cfg);

int dpsw_fdb_get_unicast(struct dpsw *dpsw,
			 uint16_t fdb_id,
			 struct dpsw_fdb_unicast_cfg *cfg);

int dpsw_fdb_remove_unicast(struct dpsw *dpsw,
			    uint16_t fdb_id,
			    const struct dpsw_fdb_unicast_cfg *cfg);

struct dpsw_fdb_multicast_cfg {
	enum dpsw_fdb_entry_type type;
	uint8_t mac_addr[6];
	uint16_t num_ifs;
	uint16_t if_id[DPSW_MAX_IF];
};

struct fdb_dump_entry {
	uint8_t mac_addr[6];
	uint8_t type;
	uint8_t if_info;
	uint8_t if_mask[8];
};

int dpsw_dump_fdb_table(struct device *dev, uint16_t fdb_id, uint64_t iova_addr, int iova_size, uint16_t *table_size);

int dpsw_fdb_add_multicast(struct dpsw *dpsw,
			   uint16_t fdb_id,
			   const struct dpsw_fdb_multicast_cfg *cfg);

int dpsw_fdb_get_multicast(struct dpsw *dpsw,
			   uint16_t fdb_id,
			   struct dpsw_fdb_multicast_cfg *cfg);

int dpsw_fdb_remove_multicast(struct dpsw *dpsw,
			      uint16_t fdb_id,
			      const struct dpsw_fdb_multicast_cfg *cfg);

enum dpsw_learning_mode {
	DPSW_LEARNING_MODE_DIS = 0,
	DPSW_LEARNING_MODE_HW = 1,
	DPSW_LEARNING_MODE_NON_SECURE = 2,
	DPSW_LEARNING_MODE_SECURE = 3
};

int dpsw_fdb_set_learning_mode(struct dpsw *dpsw,
			       uint16_t fdb_id,
			       enum dpsw_learning_mode mode);

struct dpsw_fdb_attr {
	uint16_t max_fdb_entries;
	uint16_t fdb_aging_time;
	enum dpsw_learning_mode learning_mode;
	uint16_t num_fdb_mc_groups;
	uint16_t max_fdb_mc_groups;
};

int dpsw_fdb_get_attributes(struct dpsw *dpsw,
			    uint16_t fdb_id,
			    struct dpsw_fdb_attr *attr);

int dpsw_set_irq(struct dpsw *dpsw,
		 uint8_t irq_index,
         	 const struct mc_irq_cfg *irq_cfg);

int dpsw_get_irq(struct dpsw *dpsw,
		 uint8_t irq_index,
		 struct mc_irq_cfg *irq_cfg);

int dpsw_set_irq_enable(struct dpsw *dpsw,
			uint8_t irq_index,
			uint8_t enable_state);

int dpsw_get_irq_enable(struct dpsw *dpsw,
			uint8_t irq_index,
			uint8_t *enable_state);

int dpsw_set_irq_mask(struct dpsw *dpsw,
		      uint8_t irq_index,
		      uint32_t mask);

int dpsw_get_irq_mask(struct dpsw *dpsw,
		      uint8_t irq_index,
		      uint32_t *mask);

int dpsw_get_irq_status(struct dpsw *dpsw,
			uint8_t irq_index,
			uint32_t *status);

int dpsw_clear_irq_status(struct dpsw *dpsw,
			  uint8_t irq_index,
			  uint32_t status);

/* MC internal Function */

int dpsw_init(struct dpsw *dpsw,
	      const struct dpsw_cfg *cfg,
	      const struct dpmng_dev_cfg *dev_cfg);

/**************************************************************************//**
 @Function	dpsw_allocate

 @Description	Allocates L2 switch object

 @Return	allocated memory for the object.
*//***************************************************************************/
struct dpsw *dpsw_allocate(void);

/**************************************************************************//**
 @Function	dpsw_deallocate

 @Description	de-Allocates L2 switch object

 @Return	void.
*//***************************************************************************/
void dpsw_deallocate(struct dpsw *dpsw);

int dpsw_event_cb(void *dpsw,        			/* L2 Switch handle */
        	const struct linkman_control   *control,/* Control Information*/
        	struct linkman_endpoint        *self,  	/* endpoint 1 info */
        	const struct linkman_endpoint  *peer, 	/* endpoint 2 info */
        	struct linkman_action          *action);/* required action */

int dpsw_event_complete_cb(void *dpsw,        		/* L2 Switch handle */
        	const struct linkman_control   *control,/* Control Information*/
        	struct linkman_endpoint        *self,  	/* endpoint 1 info */
        	const struct linkman_endpoint  *peer, 	/* endpoint 2 info */
        	struct linkman_action          *action);/* required action */

/* ACL */
/**
 * @brief	ACL Configuration
 *
 */
struct dpsw_acl_cfg {
	uint16_t	max_entries;		/*!< Number of FDB entries */
};

/**
 * @brief	ACL fields
 *
 */
struct dpsw_acl_fields {
        /*! Layer 2 */
        /*! Destination MAC address: BPDU, Multicast, Broadcast, unicast,
         * slow protocols, MVRP, STP */
        uint8_t         l2_dest_mac[6];
        /*! Source MAC address */
        uint8_t         l2_source_mac[6];
	/*! Layer 2 (ethernet) protocol type, used to identify the following
	 * protocols: MPLS, PTP, PFC, ARP, Jumbo frames, LLDP, IEEE802.1ae,
	 * Q-in-Q, IPv4, IPv6, PPPoE */
        uint16_t        l2_tpid;		/*! 802.1Q */
        /*! Priority Code Point + DEI 802.1p */
        uint8_t         l2_pcp_dei;
        /*! indicate which protocol is encapsulated in the payload */
        uint16_t        l2_vlan_id;

        uint16_t        l2_ether_type;

        /*! Layer 3 */
        /*! Differentiated services code point */
        uint8_t         l3_dscp;
        /*! Tells the Network layer at the destination host, to which Protocol
         * this packet belongs to. The following protocol are supported: ICMP,
         * IGMP, IPv4 (encapsulation), TCP, IPv6 (encapsulation), GRE, PTP */
        uint8_t         l3_protocol;
        uint32_t        l3_source_ip;           /*! Source IPv4 IP */
        uint32_t        l3_dest_ip;             /*! Destination IPv4 IP */
        /*! Layer 4 */
        uint16_t        l4_source_port;         /*! Source TCP/UDP Port */
        uint16_t        l4_dest_port;           /*! Destination TCP/UDP Port */
};

/**
 * @brief	ACL key
 *
 */
struct dpsw_acl_key {
        struct dpsw_acl_fields  match;	/*! Match fields */
        struct dpsw_acl_fields  mask;  	/*! Mask: b'1 - valid, b'0 don't care */
};

/**
 * @brief	ACL action
 *
 */
enum dpsw_acl_action {
	DPSW_ACL_ACTION_DROP, 			/* Drop frame */
	DPSW_ACL_ACTION_REDIRECT, 		/* Redirect to L2 Switch port */
	DPSW_ACL_ACTION_ACCEPT, 			/* Accept frame */
	DPSW_ACL_ACTION_REDIRECT_TO_CTRL_IF	/* Redirect to control port */	
};

struct dpsw_acl_result {
        enum dpsw_acl_action    action;	/*! Action should be taken when ACL
        				entry hit */
        uint16_t                if_id;  /*! Interface IDs to redirect frame.
        				Valid only if redirect selected for
        				action */
};

/**
 * @brief	ACL entry
 *
 */
struct dpsw_acl_entry_cfg {
	uint64_t     			key_iova;
        struct dpsw_acl_key     *key;            /*! key */
        struct dpsw_acl_result  result;         /*! Required action when entry
        					    hit occurs */
        int                     precedence;     /*! Precedence inside ACL */
        /*!
         * 	1. 0 is the highest priority
	 *	2. Priority valid range is from 0 to maximum number of
	 *	entries � 1
	 *	3. Adding an entry with the same priority multiple times
	 *	is invalid
         */
};
/**
 * @brief	Adds ACL to L2 switch.
 * 		Create Access Control List. Multiple ACLs can be created and
 * 		co-exist in L2 switch
 *
 * @param[in]	dpsw		DPSW descriptor object
 * @param[out] 	acl_id		ACL ID, for the future reference
 * @param[in]	cfg		ACL configuration
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpsw_acl_add(struct dpsw *dpsw, uint16_t *acl_id,
	const struct dpsw_acl_cfg  *cfg);

/**
 * @brief	Removes ACL from L2 switch.
 *
 * @param[in]	dpsw		DPSW descriptor object
 * @param[in] 	acl_id		ACL ID
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpsw_acl_remove(struct dpsw *dpsw, uint16_t acl_id);

/**
 * @brief	Adds an entry to ACL.
 *
 * @param[in]	dpsw		DPSW descriptor object
 * @param[in] 	acl_id		ACL ID
 * @param[in] 	cfg		entry configuration
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpsw_acl_add_entry(struct dpsw *dpsw, uint16_t acl_id,
         const struct dpsw_acl_entry_cfg *cfg);

/**
 * @brief	Removes an entry from ACL.
 *
 * @param[in]	dpsw		DPSW descriptor object
 * @param[in] 	acl_id		ACL ID
 * @param[in] 	cfg		entry configuration
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpsw_acl_remove_entry(struct dpsw *dpsw, uint16_t acl_id,
         const struct dpsw_acl_entry_cfg *cfg);

/**
 * @brief	List of interfaces to Associate with ACL
 *
 */
struct dpsw_acl_if_cfg {
	uint16_t	num_ifs;		/*! Number of interfaces */
	uint16_t	if_id[DPSW_MAX_IF];	/*! List of interfaces */
};
/**
 * @brief	Associate interface/interfaces with ACL.
 *
 * @param[in]	dpsw		DPSW descriptor object
 * @param[in] 	acl_id		ACL ID
 * @param[in] 	cfg		interfaces list
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpsw_acl_add_if(struct dpsw *dpsw, uint16_t acl_id,
         const struct dpsw_acl_if_cfg 	*cfg);

/**
 * @brief	De-associate interface/interfaces from ACL.
 *
 * @param[in]	dpsw		DPSW descriptor object
 * @param[in] 	acl_id		ACL ID
 * @param[in] 	cfg		interfaces list
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpsw_acl_remove_if(struct dpsw *dpsw, uint16_t acl_id,
         const struct dpsw_acl_if_cfg 	*cfg);

/**
 * @brief       ACL Attributes
 *
 */
struct dpsw_acl_attr {
        uint16_t max_entries; /*!< Max number of ACL entries */
        uint16_t num_entries; /*!< Number of used ACL entries */
        uint16_t num_ifs;     /*!< Number of ifaces associated with ACL */
};

/**
 * @brief	Function gets specific counter of particular interface
 *
 * @param[in]	dpsw		L2 switch handle
 *
 * @param[in]	acl_id		ACL Identifier
 *
 * @param[out]	attr		ACL attributes
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpsw_acl_get_attributes(struct dpsw *dpsw,
                            uint16_t acl_id,
                            struct dpsw_acl_attr *attr);
/**
 * @brief       Control Interface
 *
 */
struct dpsw_ctrl_if_attr {
	uint32_t	rx_fqid;		/* Receive FQID */
	uint32_t	rx_err_fqid;		/* Receive error FQID */
	uint32_t	tx_err_conf_fqid;	/* Transmit error and 
						   confirmation FQID */
};

/**
 * @brief	Function obtains control interface attributes
 *
 * @param[in]	dpsw		L2 switch context
 *
 * @param[out]	attr		control interface attributes
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpsw_ctrl_if_get_attributes(struct dpsw *dpsw, 
	struct dpsw_ctrl_if_attr *attr);

#define DPSW_MAX_DPBP	8

struct dpsw_ctrl_if_pools_cfg {
	uint8_t num_dpbp;
	struct {
		int dpbp_id;
		uint16_t buffer_size;
		int backup_pool;
	} pools[DPSW_MAX_DPBP];

};

/**
 * @brief	Function sets control interface buffer pools
 *
 * @param[in]	dpsw		L2 switch context
 *
 * @param[in]	pools		buffer pools configuration
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpsw_ctrl_if_set_pools(struct dpsw *dpsw, 
	const struct dpsw_ctrl_if_pools_cfg *pools);

/**
 * @brief	Function enables control interface 
 *
 * @param[in]	dpsw		L2 switch context
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpsw_ctrl_if_enable(struct dpsw *dpsw);

/**
 * @brief	Function disables control interface 
 *
 * @param[in]	dpsw		L2 switch context
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpsw_ctrl_if_disable(struct dpsw *dpsw);

#define DPSW_CTRL_IF_QUEUE_OPT_USER_CTX		0x00000001
#define DPSW_CTRL_IF_QUEUE_OPT_DEST		0x00000002

enum dpsw_ctrl_if_dest {
	DPSW_CTRL_IF_DEST_NONE = 0,
	DPSW_CTRL_IF_DEST_DPIO = 1,
};

struct dpsw_ctrl_if_dest_cfg {
	enum dpsw_ctrl_if_dest dest_type;
	int dest_id;
	uint8_t priority;
};

struct dpsw_ctrl_if_queue_cfg {
	uint32_t options;
	uint64_t user_ctx;
	struct dpsw_ctrl_if_dest_cfg dest_cfg;
};

enum dpsw_queue_type {
	DPSW_QUEUE_RX,
	DPSW_QUEUE_TX_ERR_CONF,
	DPSW_QUEUE_RX_ERR,
};

int dpsw_ctrl_if_set_queue(struct dpsw *dpsw,
	enum dpsw_queue_type qtype,
	const struct dpsw_ctrl_if_queue_cfg *queue_cfg);

int dpsw_ctrl_if_get_tx_counters(struct dpsw  *dpsw, uint16_t  if_id,
	struct dpsw_counters_cfg  *counters);

int dpsw_ctrl_if_get_rx_counters(struct dpsw  *dpsw,
	struct dpsw_counters_cfg  *counters);

struct dpsw_lag_cfg {
	uint8_t group_id;
	uint8_t num_ifs;
	uint8_t if_id[8];
};

int dpsw_if_lag_configure (struct dpsw *dpsw,
	const struct dpsw_lag_cfg *lag_cfg);

int dpsw_lag_set(struct dpsw *dpsw,
	const struct dpsw_lag_cfg *lag_cfg);

int dpsw_lag_get(struct dpsw *dpsw, uint8_t group_id,
	struct dpsw_lag_cfg *lag_cfg);

int dpsw_if_get_port_mac_addr(struct dpsw *dpsw, uint16_t if_id,
			      uint8_t addr[6]);


struct dpsw_taildrop_cfg {
	uint8_t		enable;
	enum dpsw_early_drop_unit units;
	uint32_t	threshold;
};

int dpsw_if_set_taildrop(struct dpsw *dpsw, uint16_t if_id, uint8_t tc,
		struct dpsw_taildrop_cfg *cfg);

int dpsw_if_get_taildrop(struct dpsw *dpsw, uint16_t if_id, uint8_t tc,
		struct dpsw_taildrop_cfg *cfg);

int dpsw_get_ap_ppid(struct dpsw *dpsw, int if_id, int *ppid);

int dpsw_clean_flow_control_config(struct dpsw *dpsw, int if_id);

enum dpsw_table_type {
	DPSW_FDB_TABLE = 1,
	DPSW_VLAN_ING_TABLE = 2,
	DPSW_VLAN_EGR_TABLE = 3,
	DPSW_ACL_TABLE	= 4,
};

int dpsw_table_dump(struct device *dev, uint16_t table_type, uint16_t table_index, uint64_t iova_addr, int iova_size, uint16_t *table_size);

#define DPSW_ERROR_DISC		0x80000000
#define DPSW_ERROR_EOFHE	0x00020000
#define DPSW_ERROR_FLE		0x00002000
#define DPSW_ERROR_FPE		0x00001000
#define DPSW_ERROR_PHE		0x00000020
#define DPSW_ERROR_L3CE		0x00000004
#define DPSW_ERROR_L4CE		0x00000001

enum dpsw_error_action {
	DPSW_ERROR_ACTION_DISCARD = 0,
	DPSW_ERROR_ACTION_CONTINUE = 1,
};

struct dpsw_error_cfg {
	uint32_t errors;
	enum dpsw_error_action error_action;
	int set_frame_annotation;
};

int dpsw_if_set_errors_behavior(struct dpsw *dpsw, int if_id, struct dpsw_error_cfg *cfg);

enum dpsw_flood_type {
	DPSW_BROADCAST = 0,
	DPSW_FLOODING,
};

struct dpsw_egress_flood_cfg {
	uint16_t fdb_id;
	uint16_t num_ifs;
	enum dpsw_flood_type flood_type;
	uint16_t if_id[DPSW_MAX_IF];
};

int dpsw_set_egress_flood(struct device *dev, struct dpsw_egress_flood_cfg *cfg);

int dpsw_if_set_learning_mode(struct dpsw *dpsw, uint16_t if_id,
			      enum dpsw_learning_mode mode);

#endif /* _FSL_DPSW_MC_H */

