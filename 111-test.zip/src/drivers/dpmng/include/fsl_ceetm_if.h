/*
 * Copyright 2013-2020 NXP
 */

#ifndef _FSL_CEETM_IF_H
#define _FSL_CEETM_IF_H

#include "fsl_types.h"
#include "fsl_dpmng_mc.h"

#define CEETM_IF_MAX_QPRI 	16
#define CEETM_IF_MAX_QDBIN	8
#define CEETM_IF_MAX_CCQIDX 	8
#define CEETM_IF_MAX_CCGIDX	8

/**
 * @brief	CEETM IF external data types
 *
 */

struct ceetm_if_qpri_cfg {
        int in_use;     /* 1 = used for ceetm configuration */
                        /* 0 - reserved for control port */
};

struct ceetm_if_cfg {
        int                     num_qpri; 	/* number of user priorities */
        int                     num_qdbin;    	/* distribution size */
        int 					lfqid;		/* Disconnect LFQID */
        struct ceetm_if_qpri_cfg    qpri[CEETM_IF_MAX_QPRI];
        int is_lag_enabled;
        struct ceetm_if_lag_cfg *lag_if_cfg;
};

/* create interface */
struct ceetm_if *ceetm_if_create( struct ceetm_if_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg);

/* destroy interface */
void ceetm_if_destroy(struct ceetm_if *ceetm_if);

/* connect accesspoint */
int ceetm_if_connect_accesspoint(struct ceetm_if *ceetm_if,
                        const struct dpmng_accesspoint  *ap,
                        const struct dpmng_amq  *amq);

/* disconnect access point */
int ceetm_if_disconnect_accesspoint(struct ceetm_if *ceetm_if,
                        const struct dpmng_accesspoint  *ap);

/* Features */
int ceetm_if_set_transmit_rate(struct ceetm_if *ceetm_if,
                                uint32_t committed_rate,
                                uint32_t max_rate);

enum ceetm_if_ccg_unit {
	CEETM_IF_CCG_UNIT_BYTES,
	CEETM_IF_CCG_UNIT_PACKETS,
	CEETM_IF_CCG_UNIT_BUFFERS
};

enum ceetm_if_ccg_mode {
        CEETM_IF_CCG_MODE_NONE,
        CEETM_IF_CCG_MODE_TAIL,
        CEETM_IF_CCG_MODE_WRED
};

struct ceetm_if_ccg_wred_cfg {
        uint64_t                min_threshold;            /* Minimum threshold */
        uint64_t                max_threshold;            /* Maximum threshold */
        /* Maximum probability 0-100% */
        uint8_t                 drop_probability;
};

struct ceetm_if_ccg_cfg {
        enum ceetm_if_ccg_mode   	mode; 		/* Drop mode */
	enum ceetm_if_ccg_unit		units;		/* Count mode */
        /* WRED parameters */
        struct ceetm_if_ccg_wred_cfg   	yellow; 	/* yellow */
        struct ceetm_if_ccg_wred_cfg    green;     	/* green */
        /* Tail drop parameters */
        uint32_t                	tail_drop_threshold; /* Tail drop th */
};

int ceetm_if_ccg_configure(struct ceetm_if *ceetm_if,
                        int cgidx,
                        const struct ceetm_if_ccg_cfg *ccg);

void ceetm_if_ccg_get_config(struct ceetm_if *ceetm_if,
        int cgidx,
        const struct ceetm_if_ccg_cfg *ccg);

enum ceetm_if_sched_mode {
        CEETM_IF_SCHED_STRICT_PRIORITY, /* Strict priority */
        CEETM_IF_SCHED_WEIGHTED,      	/* Enhance transmission selection */
 };

struct ceetm_if_ccq_cfg {
       enum ceetm_if_sched_mode mode;		/* Strict or ETS */
       uint16_t  		delta_bandwidth;/* weighted Bandwidth */
       uint8_t 			ccgidx;		/* congestion group index */
       uint8_t 			pps;		/* PFDR Pool Selection */
       int			ps;		/* PFDR stashing enable */
};

struct ceetm_if_ccqs_cfg {
        uint8_t ccqidx[CEETM_IF_MAX_QPRI];     	/* CEETM Class Queue mapping */

        /* Traffic classes configuration */
        struct ceetm_if_ccq_cfg  ccq[CEETM_IF_MAX_CCQIDX];
};

int ceetm_if_ccqs_configure(struct ceetm_if *ceetm_if,
        const struct ceetm_if_ccqs_cfg *ccqs);

/* Getting attributes */
struct ceetm_if_qpri_attr {
        int in_use;     /* 1 = used for ceetm configuration */
                        /* 0 - reserved for control port */
        int id;  			/* QPri Resource id */
        uint32_t lfqid[CEETM_IF_MAX_QDBIN];	/* lfq resources */
};

struct ceetm_if_attr {
        int     num_qpri;		/* number of queue priorities */
        int 	num_qdbin;          	/* distribution size */
        int     num_ccqs;		/* number of traffic classes */
        int     qdid;            	/* QDID */
        struct ceetm_if_qpri_attr   	qpri[CEETM_IF_MAX_QPRI];/* QPRI attr */
        struct ceetm_if_ccqs_cfg   	ccqs;	/* class queues config */
        struct ceetm_if *lag_master;	/* LAG master */
};

void ceetm_if_get_attributes(struct ceetm_if *ceetm_if,
	struct ceetm_if_attr *attr);

uint32_t ceetm_if_get_max_tbl(void);
void set_ceetm_lag_conf(struct ceetm_if *ceetm_if, struct ceetm_if *ceetm_if_master, int group_id, int num_ifs);
int ceetm_if_is_lag_master(struct ceetm_if *ceetm_if);

#endif /* _FSL_CEETM_IF_H */
