/**************************************************************************//**
 Copyright 2013 Freescale Semiconductor, Inc.

 @File          fsl_dpmng_mc.h

 @Description   This file contains LINK-MANAGER API.
 *//***************************************************************************/
#ifndef __FSL_CTRL_IF_H
#define __FSL_CTRL_IF_H

#include "fsl_types.h"
#include "fsl_enet.h"
#include "common/fsl_string.h"

#include "fsl_dbg.h"
//#include "fsl_eiop_port.h"		/* enum eiop_port_type */
//#include "drivers/fsl_qbman_portal_ex.h"
#include "fsl_dpmng_mc.h"
#include "fsl_eiop_ifp.h"



struct ctrl_if;

/************************************************************************
 * 					DPMNG_CNTRL_IF
 ***********************************************************************/
#define CTRL_IF_MAX_DPBP		8

#define CTRL_IF_ERROR_EOFHE	0x00020000
#define CTRL_IF_ERROR_FLE		0x00002000
#define CTRL_IF_ERROR_FPE		0x00001000
#define CTRL_IF_ERROR_PHE		0x00000020
#define CTRL_IF_ERROR_L3CE		0x00000004
#define CTRL_IF_ERROR_L4CE		0x00000001

enum ctrl_if_error_action {
	CTRL_IF_ERROR_ACTION_DISCARD = 0,
	CTRL_IF_ERROR_ACTION_CONTINUE = 1,
	CTRL_IF_ERROR_ACTION_SEND_TO_ERROR_QUEUE = 2
};

struct ctrl_if_error_cfg {
	uint32_t errors;
	enum ctrl_if_error_action error_action;
	int set_frame_annotation;
};



#define CTRL_IF_BUF_LAYOUT_OPT_TIMESTAMP		0x00000001
#define CTRL_IF_BUF_LAYOUT_OPT_PARSER_RESULT	0x00000002
#define CTRL_IF_BUF_LAYOUT_OPT_FRAME_STATUS	0x00000004
#define CTRL_IF_BUF_LAYOUT_OPT_PRIVATE_DATA_SIZE	0x00000008
#define CTRL_IF_BUF_LAYOUT_OPT_DATA_ALIGN		0x00000010
#define CTRL_IF_BUF_LAYOUT_OPT_DATA_HEAD_ROOM	0x00000020
#define CTRL_IF_BUF_LAYOUT_OPT_DATA_TAIL_ROOM	0x00000040

struct ctrl_if_buffer_layout {
	uint32_t options;
	int pass_timestamp;
	int pass_parser_result;
	int pass_frame_status;
	uint16_t private_data_size;
	uint16_t data_align;
	uint16_t data_head_room;
	uint16_t data_tail_room;
};

struct ctrl_if_attr {
//	uint64_t user_ctx;
	//struct dpni_dest_cfg dest_cfg;
	//struct dpni_flc_cfg flc_cfg;
//	int order_preservation_en;

	//uint32_t virt_fqid;
	int ifp_id;
	int virt_err_fqid;
	int virt_fqid;
	int virt_qdid;
	int internal_qdid;
	int plid;

};

struct ctrl_if_connect_if_id_cfg {
	struct dpmng_accesspoint *ap;
	int cq_id;
	int lfqmtidx_idx;
	int dctidx_idx;
	int next_ifp;
	int qprid;
	
};

struct ctrl_if_pools_cfg {
	uint8_t num_dpbp;
	struct {
		int dpbp_id;
		uint16_t buffer_size;
		int backup_pool;
	} pools[CTRL_IF_MAX_DPBP];
};


#define CTRL_IF_CFG_TX_CONF_ENABLE			0x80000000
#define CTRL_IF_CFG_TX_CONF_ONLY_ERROR		0x40000000
struct ctrl_if_cfg {
	uint16_t num_ifs;
	int 	src_qdid[64]; 	/*src QDID of interface - interface index*/
	int 	eiop_id;	/* EIOP ID */
	struct {	
		uint16_t mfl;	/* Maximum Frame Length */
	}adv;
};

enum ctrl_if_dest {
	CTRL_IF_DEST_NONE = 0, CTRL_IF_DEST_DPIO = 1
};
struct ctrl_if_dest_cfg {
	enum ctrl_if_dest dest_type;
	int dest_id;
	uint8_t priority;
};

#define CTRL_IF_QUEUE_OPT_USER_CTX	0x00000001
#define CTRL_IF_QUEUE_OPT_DEST		0x00000002

struct ctrl_if_queue_cfg {
	uint32_t options;
	uint64_t user_ctx;
	struct ctrl_if_dest_cfg dest_cfg;
};

struct ctrl_if *ctrl_if_allocate();

void ctrl_if_deallocate(struct ctrl_if *ctrl_if);

int ctrl_if_create	(struct ctrl_if *ctrl_if,
					const struct ctrl_if_cfg *cfg,
					const struct dpmng_dev_cfg *dev_cfg);

int ctrl_if_set_dev_ctx (	struct ctrl_if *ctrl_if,
							const struct dpmng_dev_ctx *dev_ctx);

int ctrl_if_enable_if_id	(struct ctrl_if *ctrl_if,
							int if_id);

int ctrl_if_destroy(struct ctrl_if *ctrl_if);

int ctrl_if_enable(struct ctrl_if *ctrl_if);

int ctrl_if_disable(struct ctrl_if *ctrl_if);

int ctrl_if_set_pools(struct ctrl_if *ctrl_if,
			const struct ctrl_if_pools_cfg *cfg);

int ctrl_if_connect_if_id(struct ctrl_if *ctrl_if, int if_id,
							const struct ctrl_if_connect_if_id_cfg *cfg);
int ctrl_if_disconnect_if_id(struct ctrl_if *ctrl_if,
							int if_id);

int ctrl_if_enable_if_id	(struct ctrl_if *ctrl_if,
							int if_id);

int ctrl_if_get_rx_flow_attr	(struct ctrl_if *ctrl_if,
							uint16_t flow_id,
							struct ctrl_if_attr *attr);

int ctrl_if_get_tx_if_id_attr	(struct ctrl_if *ctrl_if,
								uint16_t if_id,
								struct ctrl_if_attr *attr);

int ctrl_if_disable_if_id	(struct ctrl_if *ctrl_if,
							int if_id);

int ctrl_if_get_rx_counter(struct ctrl_if *ctrl_if,
	enum counter_type counter,
	uint64_t *value);

int ctrl_if_set_rx_counter(struct ctrl_if *ctrl_if,
	enum counter_type counter,
	uint64_t value);

int ctrl_if_get_tx_if_id_counter	(struct ctrl_if *ctrl_if,
		int if_id,
		enum counter_type counter,
		uint64_t *value);

int ctrl_if_set_tx_if_id_counter	(struct ctrl_if *ctrl_if,
		int if_id,
		enum counter_type counter,
		uint64_t value);


/*Advanced functionality*/

int ctrl_if_set_rx_buffer_layout	(struct ctrl_if *ctrl_if,
									const struct ctrl_if_buffer_layout 
															*layout);
int ctrl_if_set_tx_conf_buffer_layout	(struct ctrl_if *ctrl_if,
										const struct ctrl_if_buffer_layout 
															*layout);
int ctrl_if_set_tx_buffer_layout	(struct ctrl_if *ctrl_if,
									const struct ctrl_if_buffer_layout 
															*layout);

int ctrl_if_set_max_frame_length	(struct ctrl_if *ctrl_if, 
									uint16_t max_frame_length);

void ctrl_if_get_rx_attr	(struct ctrl_if *ctrl_if,
						struct ctrl_if_attr *attr);

int ctrl_if_set_tx_confirmation(struct ctrl_if *ctrl_if, int en);

int ctrl_if_set_errors_behavior(struct ctrl_if *ctrl_if, 
		struct ctrl_if_error_cfg *cfg);

int ctrl_if_set_rx_flow(struct ctrl_if *ctrl_if,
	uint16_t flow_id,
	const struct ctrl_if_queue_cfg *cfg);

int ctrl_if_set_rx_err_queue(struct ctrl_if *ctrl_if,
	const struct ctrl_if_queue_cfg *cfg);

int ctrl_if_set_tx_err_conf_queue(struct ctrl_if *ctrl_if,
	const struct ctrl_if_queue_cfg *cfg);

#endif /* __FSL_CTRL_IF_H */
