/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPRTC_MC_H
#define __FSL_DPRTC_MC_H

#include "fsl_dpmng_mc.h"
#include "fsl_eiop_rtc.h"

struct dprtc;

#define DPRTC_MAX_IRQ_NUM			1

#define DPRTC_IRQ_INDEX				0
#define DPRTC_EVENT_ALARM_1			0x80000000
#define DPRTC_EVENT_ALARM_2			0x40000000
#define DPRTC_EVENT_ALARM_3			0x20000000
#define DPRTC_EVENT_PERIODIC_PULSE_1		0x08000000
#define DPRTC_EVENT_PERIODIC_PULSE_2		0x04000000
/*#define DPRTC_EVENT_PERIODIC_PULSE_3		0x02000000
#define DPRTC_EVENT_PERIODIC_PULSE_4		0x01000000*/
#define DPRTC_EVENT_EXT_TRIGGER_1		0x00800000
#define DPRTC_EVENT_EXT_TRIGGER_2		0x00400000
#define DPRTC_EVENT_EXT_TRIGGER_3		0x00200000
#define DPRTC_EVENT_EXT_TRIGGER_4		0x00100000

struct dprtc_cfg {
	uint32_t options;
};

struct dprtc_attr {
	int id;
	uint32_t period;
	uint32_t addr;   
	uint8_t little_endian;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
};

int dprtc_create(struct dprtc *dprtc, const struct dprtc_cfg *cfg);

int dprtc_open(struct dprtc *dprtc, int dprtc_id);

int dprtc_close(struct dprtc *dprtc);

void dprtc_destroy(struct dprtc *dprtc);

int dprtc_enable(struct dprtc *dprtc);

int dprtc_disable(struct dprtc *dprtc);

int dprtc_is_enabled(struct dprtc *dprtc, int *en);

void dprtc_reset(struct dprtc *dprtc);

int dprtc_get_attributes(struct dprtc *dprtc, struct dprtc_attr *attr);

int dprtc_set_irq(struct dprtc *dprtc,
	uint8_t irq_index,
	const struct mc_irq_cfg *irq_cfg);

int dprtc_get_irq(struct dprtc *dprtc,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg);

int dprtc_set_irq_enable(struct dprtc *dprtc, uint8_t irq_index, uint8_t en);

int dprtc_get_irq_enable(struct dprtc *dprtc, uint8_t irq_index, uint8_t *en);

int dprtc_set_irq_mask(struct dprtc *dprtc, uint8_t irq_index, uint32_t mask, int version);

int dprtc_get_irq_mask(struct dprtc *dprtc, uint8_t irq_index, uint32_t *mask);

int dprtc_get_irq_status(struct dprtc *dprtc,
	uint8_t irq_index,
	uint32_t *status);

int dprtc_clear_irq_status(struct dprtc *dprtc,
	uint8_t irq_index,
	uint32_t status);

int dprtc_set_clock_offset(struct dprtc *dprtc,
	uint64_t offset);

int dprtc_get_clock_offset(struct dprtc *dprtc,
	uint64_t *offset);

int dprtc_set_freq_compensation(struct dprtc *dprtc,
	uint32_t freq_compensation);

int dprtc_get_freq_compensation(struct dprtc *dprtc,
	uint32_t *freq_compensation);

int dprtc_get_time(struct dprtc *dprtc,
	uint64_t *time);

int dprtc_set_time(struct dprtc *dprtc,
	uint64_t time);

struct dprtc_alarm_cfg {
	uint8_t alarm_id;
	uint64_t alarm_time;
};

int dprtc_set_alarm(struct dprtc *dprtc,
	struct dprtc_alarm_cfg *dprtc_alarm_cfg);

/*struct dprtc_periodic_cfg {
	uint8_t periodic_pulse_id;
	uint64_t period;
};

int dprtc_set_periodic_pulse(struct dprtc *dprtc,
	struct dprtc_periodic_cfg *dprtc_periodic_cfg);

int dprtc_clear_periodic_pulse(struct dprtc *dprtc,
	uint8_t id);
*/
struct dprtc_ext_trigger_cfg {
	uint8_t ext_trigger_id;
	uint8_t use_pulse_as_input;
};
struct dprtc_ext_trigger_status {
	uint64_t timestamp;
	uint8_t unread_valid_timestamp;
};


int dprtc_set_ext_trigger(struct dprtc *dprtc,
	struct dprtc_ext_trigger_cfg *dprtc_ext_trigger_cfg);

int dprtc_clear_ext_trigger(struct dprtc *dprtc,
	uint8_t id);

int dprtc_get_ext_trigger_timestamp(struct dprtc *dprtc,
	uint8_t id,
	struct dprtc_ext_trigger_status *status);

int dprtc_set_fiper_loopback(struct dprtc *dprtc,
	struct dprtc_ext_trigger_cfg *dprtc_ext_trigger_cfg);

/* MC internal functions */

struct dprtc *dprtc_allocate(void);
void dprtc_deallocate(struct dprtc *dprtc);
int dprtc_init(struct dprtc *dprtc,
	const struct dprtc_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg);
int dprtc_set_dev_ctx(struct dprtc *dprtc, const struct dpmng_dev_ctx *dev_ctx);
void dprtc_exceptions(struct dprtc *dprtc);


#endif /* __FSL_DPRTC_MC_H */
