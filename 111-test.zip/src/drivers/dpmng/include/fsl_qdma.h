/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_QDMA_H
#define __FSL_QDMA_H

#include "fsl_types.h"

struct qdma_desc {
	int disable;
	int id;
	phys_addr_t paddr;
	void *vaddr;
	int irq_err;
	int version;
};

/**************************************************************************//**
 @Description   enum for defining EIOP Exceptions
*//***************************************************************************/

enum qdma_exceptions {
    E_QDMA_SYSTEM_BUS_ERR,
    E_QDMA_FRAME_DESC_ERR,
    E_QDMA_FRAME_SIZE_ERR,
    E_QDMA_SRC_DESC_ERR,
    E_QDMA_DST_DESC_ERR,
};

/**************************************************************************//**
 @Function      qdma_init

 @Description   Initialize QDMA 

 @Param[in]     desc - QDMA descriptor

 @Return        0 on success, error code otherwise 
*//***************************************************************************/
int qdma_init(struct qdma_desc *desc);

/**************************************************************************//**
 @Function      qdma_set_exceptions

 @Description   Set or clear QDMA exception

 @Param[in]     desc - QDMA descriptor
                exception - Required exception  
                enable - 1 to set the exception, 0 to clear 

 @Return        0 on success, error code otherwise 
*//***************************************************************************/
int qdma_set_exceptions(struct qdma_desc *desc, enum qdma_exceptions exception, int enable);

#endif /* __FSL_QDMA_H */
