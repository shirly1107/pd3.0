/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_QBMAN_H
#define __FSL_QBMAN_H

#define QBMAN_MAX_DCP	12
#define QBMAN_MAX_CEETM_INS 4
#define QBMAN_MAX_CEETM_GRP_SIZE 4
#define QBMAN_MAX_SDEST_SRCID 16

#define QBMAN_MAX_LNI  12

#define QBMAN_PFDR_POOL_BASE    0
#define QBMAN_PFDR_POOL_PEB     1

#define QBMAN_FIRST_FQID 1
#define QBMAN_REL_FQ_ID 0 /* Dedicated FQID for recoverable error logging */

// reserve first DCP AIOP channel as default in order for MC
// to be backward compatible with previous AIOP SL versions
#define QBMAN_FIRST_AIOP_DCP_CHID 0
#define QBMAN_FIRST_USER_AIOP_DCP_CHID (QBMAN_FIRST_AIOP_DCP_CHID + 1)
// number of WQs or scheduling priorities within a QMan channel
#define QMAN_CHANNEL_WQ_PRIO_NUM 8

enum qbman_dcp {
	QBMAN_DCP_WRIOP = 0,
	QBMAN_DCP_AIOP,
	QBMAN_DCP_SEC,
	QBMAN_DCP_DCE,
	QBMAN_DCP_PME,
	QBMAN_DCP_QDMA,
};

struct qbman_desc {
	int disable;
	phys_addr_t paddr; /*  */
	void *vaddr; /*  */
	phys_addr_t portals_paddr; /*  */
	uint32_t clk; /* Clock in Hz*/
	int irq_recoverable;
	int irq_non_recoverable;
	uint32_t num_swp_wqs; /* Number of SWP WQs */
	uint32_t num_int_fqs; /* Number of internal FQs */
	uint32_t num_wq_per_wqpr; /* Number of WQ items per WQPR */
	uint32_t num_fq_cgs; /* Number of FQ CGs */
	uint32_t num_bpids; /* Number of BMan buffer pools */
	uint32_t num_qds; /* Number of QDs */
	uint32_t num_qprs; /* Number of QPRs */
	uint32_t num_odps_orps; /* Number of ODPs and ORPs */
	uint32_t num_orl_recs; /* Number of ORL records */
	uint32_t num_replication_records; /* Enqueue Replication list records */
	uint32_t max_in_flight_replications;
	/* Enqueue replication, max in flight replications */
	uint8_t  dqrr_size;
	uint32_t ceetm_strict_pri_q_base; /* id of first strict priority queue */
	uint32_t ceetm_num_strict_pri_q; /* num of weight schedueling
	 algorithm queues */
	uint32_t ceetm_weight_pri_q_base; /* id of first weight schedueling
	 algorithm queue */
	uint32_t ceetm_num_weight_pri_q; /* num of strict priority queues */
	uint32_t ceetm_weight_group_size; /* maximum size of a weighted group */
	uint32_t multiple_pfdr_support;  /* supports the multiple PFDR pools */
	uint32_t pfdr_peb_size;          /* the size for PFDR pool allocated in PEB (only QBMAN version >= 4.1)*/
	uint64_t ceetm_max_shaper_output_rate; /* maximum shaper rate required */
	uint8_t pfdr_pool_min_value; /* PFDR minimum pool */
	struct {
		int valid;
		/* is DCP valid */
		enum qbman_dcp dcp_type;
		/* DCP type; e.g AIOP */
		int ceetm_support;
		/* DCP using either CEETM or FQ/WQ. */
		uint32_t num_fq_wq_channels;
		/* Number of FQ/WQ channels. */
		struct {
			int valid; /* is instance valid */
			uint32_t num_lnis;
			/* Number of CEETM LNIs */
			uint32_t num_cq_channels;
			/* Number of CEETM channels. */
			uint8_t num_cqs_per_channel;
			/* Number of CQs per CEETM channel. */
			uint32_t num_lfqids;
			uint32_t num_ccg;
		/* Number of CEETM class congestion groups (CCG). */
		} ceetm_instance[QBMAN_MAX_CEETM_INS];
	} dcp[QBMAN_MAX_DCP];
	/* PFDR corruption might occur on rev1 due to ERR009381*/
	int err009381;
	uint8_t num_sdest_srcid;
	struct qbman_sdest_srcid {
		uint8_t sdest;
		uint8_t srcid;
	} sdest_srcid[QBMAN_MAX_SDEST_SRCID];
	struct qbman_sdest_core_index {
		uint8_t sdest;
	} sdest_core_index[SOC_NUM_OF_CORES];
};

struct qbman_swportal_desc {
	int qbman_id; /* The QBMan instance */
	int swportal_id; /* SWPs within a QBMan are indexed. -1 if opaque to the user */
	phys_addr_t paddr_cena; /* Cache-enabled portal physical address */
	void *vaddr_cena; /* Cache-enabled portal virtual address */
	uint64_t cena_size; /* Cache-enabled portal size */
	phys_addr_t paddr_cinh; /* Cache-inhibited portal physical address */
	void *vaddr_cinh; /* Cache-inhibited portal virtual address */
	uint64_t cinh_size; /* Cache-inhibited portal size */
	int irq; /* -1 if unused (or unassigned) */
};

/*
 * Returns 1 if CPC Stashing can be enabled for PFDRs, 0 otherwise.
 * Because of ERR009381 the feature cannot be enabled on Rev1 devices
 * and so the field err009381 is set to 1 for those devices.
 */
static inline int qbman_cacheable_pfdr()
{
	struct qbman_desc qbman_desc = {0};

	if (sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
					&qbman_desc, NULL))
		return 0;

	return !qbman_desc.err009381;
}

/* Oree mode */
enum orl_oree_mode {
	OREE_MODE_OFF = 0,
	OREE_MODE_ON = 1
};

#endif /*__FSL_QBMAN_H*/

