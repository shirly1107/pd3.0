/*
 * Copyright 2013-2020 NXP
 */

#ifndef _FSL_OPR_H
#define _FSL_OPR_H

#include "fsl_types.h"

#define OPR_OPT_CREATE 0x1
#define OPR_OPT_RETIRE 0x2
#define OPR_OPT_ASSIGN 0x4

#define OPR_RES_TYPE_STR "opr"
#define OPR_ERR_STR "OPR"

#define OPR_NOT_SET 0
#define OPR_SET 1
#define OPR_CREATED 2
#define OPR_ENABLED 3

struct opr_cfg {
	uint8_t oprrws;
	uint8_t oa;
	uint8_t olws;
	uint8_t oeane;
	uint8_t oloe;
};

struct opr_qry {
	char enable;
	char rip;
	uint16_t ndsn;
	uint16_t nesn;
	uint16_t ea_hseq;
	char hseq_nlis;
	uint16_t ea_tseq;
	char tseq_nlis;
	uint16_t ea_tptr;
	uint16_t ea_hptr;
	uint16_t opr_id;
	uint16_t opr_vid;
};

struct opr_info {
	int state;
	uint32_t id;
	uint32_t vid;
	uint32_t cfg;
};

int configure_opr(struct opr_cfg *cfg, struct opr_info *info);
int retire_opr(struct qbman_swp *s, struct opr_info *info);
int check_opr_cfg (struct opr_cfg *cfg);
int create_opr (struct qbman_swp *sw_portal, struct opr_info *info, uint32_t en);
int query_opr(struct qbman_swp *sw_portal, struct opr_info *info, struct opr_cfg *cfg, struct opr_qry *qry);
int enable_opr(struct qbman_swp *sw_portal, struct opr_info *info);
int auth_oprid(struct qbman_swp *sw_portal, int bdi, uint16_t icid, struct opr_info *info);
int deauth_oprid(struct qbman_swp *sw_portal, int bdi, uint16_t icid, struct opr_info *info);
int config_orp_fq(struct qbman_swp *sw_portal, int fqid, struct opr_info *info);

#endif /* _FSL_OPR_H */

