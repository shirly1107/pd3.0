/*
 * Copyright 2014-2015 Freescale Semiconductor, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *   * Neither the name of Freescale Semiconductor nor the
 *     names of its contributors may be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY Freescale Semiconductor ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Freescale Semiconductor BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __AIOP_COMMON_H
#define __AIOP_COMMON_H

#include "fsl_gen.h"

#define AIOP_EP_TABLE_NUM_OF_ENTRIES	1024
#define AIOP_INIT_DATA_FIXED_ADDR	(uint8_t *)0x01000000

#define AIOP_ATU_NUM_OF_WINDOWS         8

#define AIOP_MAX_COMMAND_LINE_ARGS      512

#define AIOP_SRV_EVM_AUTH_ID		0x1
#define AIOP_SRV_EVM_NAME		"EVMNG"

#define AIOP_MAX_NUM_CORES_IN_CLUSTER	4
#define AIOP_MAX_NUM_CLUSTERS		4

#define AIOP_EPID_SET_BY_DPNI		0x80000000

/**************************************************************************//**
 @Description   EPID table
*//***************************************************************************/
enum aiop_epid_table {
       AIOP_EPID_CMDIF_SERVER    = 0,     /**< EPID for command interface server*/
       AIOP_EPID_TIMER_EVENT_IDX = 1,     /**< EPID for T-MAN block */
       AIOP_EPID_CMDIF_CLIENT    = 2,     /**< EPID for command interface client */
       AIOP_EPID_DPNI_START      = 3,     /**< DPNI's first EPID */
       AIOP_EPID_SL_START        = 901,   /**< Start of AIOPSL managed pool */
       AIOP_EPID_TABLE_SIZE      = 1024   /**< MAX number of EPID's */
};

/**************************************************************************//**
 @Description   SPID table
*//***************************************************************************/
enum aiop_spid_table {
	AIOP_SPID_CMDIF           = 0,     /**< SPID for command interface */
	AIOP_SPID_DPNI_START      = 1      /**< DPNI's first SPID */
};

/* Internal data exchanged between AIOP and MC
 * FIELDS MUST BE ALIGNED AS PACKED */
struct aiop_app_init_info {

	uint64_t dp_ddr_size; /* initialized by AIOP APP at compile time, default provided */
	uint64_t peb_size; /* initialized by AIOP APP at compile time, default provided */
	uint64_t sys_ddr1_size; /* initialized by AIOP APP at compile time, default provided */

	uint32_t ctlu_sys_ddr_num_entries; /* initialized by AIOP APP at compile time, default provided */
	uint32_t ctlu_dp_ddr_num_entries; /* initialized by AIOP APP at compile time, default provided */
	uint32_t ctlu_peb_num_entries; /* initialized by AIOP APP at compile time, default provided */

	uint32_t mflu_sys_ddr_num_entries; /* initialized by AIOP APP at compile time, default provided */
	uint32_t mflu_dp_ddr_num_entries; /* initialized by AIOP APP at compile time, default provided */
	uint32_t mflu_peb_num_entries; /* initialized by AIOP APP at compile time, default provided */

	uint32_t sru_size;
	uint32_t tasks_per_core;

	uint32_t spid_count;
	uint32_t hcl;	/* FDMA hop count limit */

	uint32_t reserved[48]; /* reserved for future use. Keep 256B */
};

/* Internal data exchanged between AIOP and MC
 * FIELDS MUST BE ALIGNED AS PACKED */
struct aiop_sl_init_info
{
	uint32_t aiop_rev_major;  /* initialized by AIOP SL at compile time */
	uint32_t aiop_rev_minor; /* initialized by AIOP SL at compile time */
	uint32_t aiop_revision;  /* initialized by AIOP SL at compile time */

	uint32_t base_spid;

	uint64_t dp_ddr_paddr;
	uint64_t dp_ddr_vaddr;/*virtual base address, initialized by MC FW before AIOP elf is loaded */

	uint64_t peb_paddr;
	uint64_t peb_vaddr; /* virtual base address, initialized by MC FW before AIOP elf is loaded */

	uint64_t sys_ddr1_paddr;
	uint64_t sys_ddr1_vaddr;/*  virtual base address, initialized by MC FW before AIOP elf is loaded */

	uint64_t ccsr_paddr;
	uint64_t ccsr_vaddr;/*  virtual base address, initialized by MC FW before AIOP elf is loaded */

	uint64_t mc_portals_paddr;
	uint64_t mc_portals_vaddr;/*  virtual base address, initialized by MC FW before AIOP elf is loaded */

	uint32_t uart_port_id;      /* initialized by MC FW during init, before AIOP elf is loaded */
	uint32_t mc_portal_id;                  /* initialized by MC FW during init, before AIOP elf is loaded */
	uint32_t mc_dpci_id;                    /* initialized by MC FW during init, before AIOP elf is loaded */

	uint64_t log_buf_paddr; 	/* physical address of log buffer */
	uint32_t log_buf_size;
	uint32_t platform_clk; 		/* in Khtz */

	uint64_t options;
	uint32_t args_size;	/* AIOP command line string length */
	uint8_t args[AIOP_MAX_COMMAND_LINE_ARGS];	/* AIOP command line string */
	/* Parse profile ID */
	int32_t		ingress_pp_id;
	int32_t		egress_pp_id;
	/* Parse start HXS */
	uint16_t	ingress_start_hxs;
	uint16_t	egress_start_hxs;
	/* Reserved for future use. Keep 768B (3/4 K) */
	uint32_t reserved[26];
};


struct aiop_init_info
{
	struct aiop_sl_init_info  sl_info;
	struct aiop_app_init_info app_info;
};

/**************************************************************************//**
 @Description   AIOP tile and AIOP blocks registers
 *//***************************************************************************/
struct aiop_cmgw_regs {
	/* General Configuration Port Control and Status Registers */
	uint32_t tcr; /* Tile control register */
	uint32_t tsr; /* Tile status register */
	uint32_t ip_rev_1; /* IP block revision 1 register */
	uint32_t ip_rev_2; /* IP block revision 2 register */
	uint8_t reserved1[0x10];

	/* Tile Global Control and Status Registers */
	uint32_t wscr; /* Workspace control register */
	uint32_t rgcr; /* Region guarded control register */
	uint8_t reserved2[0x8];
	uint32_t tscru; /* 1588 time stamp capture register (upper portion) */
	uint32_t tscrl; /* 1588 time stamp capture register (lower portion) */
	uint32_t tsrr; /* 1588 time stamp resolution register */
	uint8_t reserved3[0x4];
	uint32_t amq_ste_cr; /* AMQ STE control register */
	uint8_t reserved4[0x3C];

	/* AIOP Core Control Registers */
	uint32_t rbase; /* Reset base address register */
	uint8_t reserved5[0x4];
	uint32_t sdabase; /* SDA base address register */
	uint32_t sda2base; /* SDA2 base address register */
	uint32_t abrr; /* AIOP boot release request register */
	uint32_t abrcr; /* AIOP boot release clear register */
	uint32_t abcr; /* AIOP boot completion register */
	uint32_t abccr; /* AIOP boot completion clear register */
	uint8_t reserved6[0x60];

	/* Error Management and Interrupt */
	uint32_t acintrqlr; /* AIOP core interrupt request LP register */
	uint32_t acintclrlr; /* AIOP core interrupt clear LP register  */
	uint32_t acintrqhr; /* AIOP core interrupt request HP register */
	uint32_t acintclrhr; /* AIOP core interrupt clear HP register */
	uint8_t reserved7[0xC];
	uint32_t rstcr; /* Reset Control Register */
	uint8_t reserved7a[0x20];

	/* Management General Purpose Registers */
	uint32_t mgpr[8]; /* Management general purpose registers 0-7 */
	uint8_t reserved8[0x20];

	/* AIOP Core General Purpose Registers */
	uint32_t acgpr[16]; /* AIOP core general purpose registers 0-15 */
	uint8_t reserved9[0x40];

	/* AIOP Block Registers */
	uint32_t stecr1; /* Statistics engine control register 1 */
	uint32_t reserved10;
	uint32_t ste_smcacr; 		/* 0x208 STE_SMCACR�Stats Engine System Memory Cache Attribute
					Control Register */
	uint32_t stesr; 		/* 0x20C STESR�Stats Engine Error Status Register */
	uint32_t ste_err_captr[4]; 	/* 0x210 STE_ERR_CAPT1-4R�Stats Engine Error Capture Register */
	uint8_t reserved11[0xE0];
	/* AIOP Discovery Registers */
	uint32_t tile_disc[4]; /* Tile discovery registers 1-4 */

	OS_MEM_RESERVED(0x310, 0x800);

	/* Shared Doorbell Unit Configuration
	 * Available only on LS2085�s Rev 2 and LS1080 */
	struct {
		struct {
			uint32_t dpcr[3];
			/**< General or Management Doorbell Priority x Configuration Register y */
			OS_MEM_RESERVED(0x80c, 0x810);
		}pr[2];
		/**< 0 or 1 priority */
		OS_MEM_RESERVED(0x820, 0x880);
	}init_g_m[2];
	/**< 0 - General or 1 - Management Doorbell */

	/* Shared Doorbell Clear Registers
	 * Available only on LS2085�s Rev 2 and LS1080 */
	struct {
		struct {
			uint32_t dpclrr;
			/**< General or Management Doorbell Priority x Clear Register */
			OS_MEM_RESERVED(0x904, 0x910);
		}pr[2];
		/**< 0 or 1 priority */
		OS_MEM_RESERVED(0x920, 0x980);
	}clear_g_m[2];
	/**< 0 - General or 1 - Management Doorbell */

	OS_MEM_RESERVED(0xa00, 0x1000);
};

struct aiop_fdma_regs {
	/* Global Common Configuration */
	uint32_t cfg; /* Configuration register */
	uint8_t reserved1[0xC];
	uint32_t hcl; /* Hop count limit register */
	uint32_t smcacr; /* System memory cache attribute control register */
	uint8_t reserved2[0xE8];

	/* System Memory Access Configuration */
	uint32_t sru_base_l; /* SRU Base register low */
	uint32_t sru_base_h; /* SRU Base register high */
	uint32_t sru_size; /* SRU Size register */
	uint32_t sru_hwm; /* SRU High Water Mark register */
	uint8_t reserved3[0x2E8];

	uint32_t ip_rev_1; /* IP Block Revision 1 register */
	uint32_t ip_rev_2; /* IP Block Revision 2 register */
	uint8_t reserved4[0xC00];
};

struct aiop_cdma_regs {
	/* Global Common Configuration */
	uint32_t cfg; /* Configuration register */
	uint8_t reserved1[0x10];
	uint32_t smcacr; /* System memory cache attribute control register */
	uint8_t reserved2[0x3E0];

	/* System Memory Access Configuration */
	uint32_t ip_rev_1; /* IP Block Revision 1 register */
	uint32_t ip_rev_2; /* IP Block Revision 2 register */
	uint8_t reserved3[0xC00];
};

struct aiop_osm_regs {
	uint32_t omr; /* OSM mode register */
	uint32_t osr; /* OSM status register */
	uint8_t reserved1[0x18];
	uint32_t ortar; /* OSM read task address register */
	uint8_t reserved2[0x4];
	uint32_t ortdr[8]; /* OSM read task data registers 0-7 */
	uint8_t reserved3[0x58];
	uint32_t oemvr; /* OSM event monitoring value register */
	uint32_t oemmr; /* OSM event monitoring mask register */
	uint8_t reserved4[0xB54];
	uint32_t ocr; /* OSM capability register */
	uint8_t reserved5[0x200];
	uint32_t oerr; /* OSM error report register */
	uint32_t oedr; /* OSM error detect register */
	uint32_t oeddr; /* OSM error detect disable register */
	uint8_t reserved6[0x14];
	uint32_t oecr[8]; /* OSM error capture registers 0-7 */
	uint8_t reserved7[0xC0];
	uint32_t oeuomr; /* OSM engineering use only mode register */
	uint8_t reserved8[0xFC];
};

struct aiop_ws_flow_ctrl_class {
	uint32_t fc_cgmc; /* Flow control congestion group matching class */
	uint32_t fc_bpmc; /* Flow control buffer pool matching class */
	uint32_t fc_fqid; /* Flow control FQID */
	uint8_t reserved[0x4];
};

struct aiop_ws_regs {
	/* Global Common Configuration */
	uint32_t cfg; /* Configuration register */
	uint8_t reserved0[0xC];
	uint32_t idle; /* Activity status register */
	uint32_t cstop; /* Core stop register */
	uint32_t cpend; /* Core pending status register */
	uint32_t cidle; /* Core idle status register */
	uint32_t ecclog; /* 2-bit ECC event log */
	uint8_t reserved2[0x4C];
	uint32_t fc_cgbcf; /* Flow control congestion group broadcast filter */
	uint32_t fc_bpbcf; /* Flow control buffer pool broadcast filter */
	uint8_t reserved3[0x58];
	uint32_t db_cfga; /* Debug configuration A */
	uint32_t db_cfgb; /* Debug configuration B */
	uint8_t reserved4[0x20];

	/* Entry Point ID Look Up Table Configuration */
	uint32_t epas; /* Entry point access select  */
	uint8_t reserved5[0x4];
	uint32_t ep_pc; /* Entry point program counter */
	uint32_t ep_pm; /* Entry point parameter */
	uint32_t ep_fdpa; /* Entry point frame descriptor presentation address */
	uint32_t ep_ptapa; /* Entry point pass through annotation presentation address */
	uint32_t ep_asapa; /* Entry point accelerator specific annotation presentation address */
	uint32_t ep_spa; /* Entry point segment presentation address */
	uint32_t ep_spo; /* Entry point segment presentation offset */
	uint32_t ep_osc; /* Entry point order scope construction */
	uint8_t reserved6[0xD8];

	/* Channel Configuration */
	uint32_t cas; /* Channel access select */
	uint8_t reserved7[0x4];
	uint32_t ch_cfga; /* Channel configuration A */
	uint32_t ch_cfgb; /* Channel configuration B */
	uint8_t reserved8[0xF4];
	uint32_t fc_cfg; /* Flow control configuration */
	struct aiop_ws_flow_ctrl_class class_regs[8];
	/* Class flow control registers */
	uint8_t reserved9[0x60];

	/* Statistics */
	uint32_t spare0;
	uint32_t spare1;
	uint32_t spare2;
	uint32_t spare3;
	uint8_t reserved10[0x8];

	/* Block ID */
	uint32_t ip_rev_1; /* IP Block Revision 1 */
	uint32_t ip_rev_2; /* IP Block Revision 2 */

	uint8_t reserved11[0xC00];
};

struct aiop_atu_win_regs {
	uint32_t acore_owbar; /* AIOP core outbound window base address register */
	uint32_t acore_owar; /* AIOP core outbound window attributes register */
	uint32_t acore_otear; /* AIOP core outbound translated extended address register */
	uint32_t acore_otar; /* AIOP core outbound translated address register */
};

struct aiop_atu_regs {
	/* ATU Control and Status Registers */
	uint32_t atucr; /* ATU Control Register */
	uint32_t atusr; /* ATU Status Register */
	uint32_t ip_rev_1; /* IP Block Revision 1 Register */
	uint32_t ip_rev_2; /* IP Block Revision 2 Register */
	uint8_t reserved1[0xC];
	uint32_t pmcr; /* Performance Monitor Register */
	uint8_t reserved2[0xE0];

	/* ATU Outbound Windows Registers */
	struct aiop_atu_win_regs win_regs[AIOP_ATU_NUM_OF_WINDOWS];
	uint8_t reserved3[0xC80];

	/* ATU Error Registers */
	uint32_t e_capt_address; /* Error Address Capture Register */
	uint32_t e_capt_attrib; /* Error Attributes Capture Register */
	uint8_t reserved4[0x1F8];
};

struct aiop_pm_regs {
	uint32_t pmpgdcr; /* Dynamic Power Gating Control Register */
	uint8_t reserved0[0xC];
	uint32_t tpmhr; /* Dynamic Power Gating Control Register */
	uint32_t tmphaltedr; /* Dynamic Power Gating Control Register */
	uint32_t cpmh; /* Core PM Halt */
	uint32_t cpmhd; /* Core PM Halted */
	uint32_t copms; /* Cluster PM Stop */
	uint32_t copmsd; /* Cluster PM Stopped */
	uint32_t clpmr; /* Cluster PM Retain */
	uint32_t clpmrd; /* Cluster PM Retained */
	uint8_t reserved1[0xFD0];
};

struct aiop_tmi_regs {
	uint32_t tmstatntc; /* TMan Stats Num of Timers Created */
	uint32_t tmstatntd; /* TMan Stats Num of Timers Deleted */
	uint32_t tmstatnat; /* TMan Stats Num of Active Timers */
	uint32_t tmstatnccp; /* TMan Stats Number of Callback Confirmation Pending */
	uint32_t tmstatntf; /* TMan Stats Number of Timers Fired */
	uint32_t tmstatnti; /* TMan Stats Number of Tasks Initiated */
	uint32_t tmstate; /* TMan State */
	uint8_t reserved[0x4];
};

struct aiop_tman_regs {
	uint32_t tmcfg; /* TMan configuration register */
	uint32_t tmamq; /* TMan AMQ */
	uint32_t tmbal; /* TMan external memory base address low */
	uint32_t tmbah; /* TMan external memory base address high */
	uint32_t tminit; /* TMan initialization register */
	uint32_t tmcbcc; /* TMan callback completion confirmation */
	uint32_t tmsmcacr; /* TMan system memory cache attributes control */ /* TODO: this register missing from rev2 spec */
	uint8_t reserved1[0x4];
	uint32_t tmtstmpl; /* TMan Timestamp Low */
	uint32_t tmtstmph; /* TMan Timestamp High */
	uint8_t reserved2[0x8];
	uint32_t tmeal;
	uint32_t tmeah;
	uint32_t tmev;
	uint8_t reserved3[0x4];
	uint32_t tmsc;	/* TMan stop control */
	uint32_t tmss; /* TMan stop status */
	uint32_t tmcacr; /* TMan cache attributes control */
	uint8_t reserved4[0x1FA4];
	uint32_t tmprbaddr; /* TMan Probe Address */
	uint32_t tmprbdata; /* TMan Probe Data */
	uint32_t tmdbg; /* TMan Debug */
	uint8_t reserved5[4];

	struct aiop_tmi_regs tmi_regs[252];
	uint8_t reserved6[0x80];
};

struct aiop_dte_tx_regs {
	/* Tx DMA and Stream Assembly Registers */
	uint32_t tx_com_sc; /* Transmit common status control register */
	uint32_t tx_user_en[2]; /* Transmit user enable 1/user enable 2 register */
	uint32_t tx_user_rst[2]; /* Transmit user reset 1/user reset 2 register */
	uint32_t tx_bus_err_stat1; /* Transmit bus error status 1 register */
	uint32_t tx_bus_err_stat2; /* Transmit bus error status 2 register */
	uint32_t tx_phy_undrn_stat1; /* Transmit phy underrun status 1 register */
	uint32_t tx_phy_undrn_stat2; /* Transmit phy underrun status 2 register */
	uint32_t tx_mpdu_stat1; /* Transmit MPDU status 1 register */
	uint32_t tx_mpdu_stat2; /* Transmit MPDU status 2 register */
	uint32_t tx_psdu_stat1; /* Transmit PSDU status 1 register */
	uint32_t tx_psdu_stat2; /* Transmit PSDU status 2 register */
	uint32_t tx_trust_cfg; /* Transmit trust configuration register */
	uint32_t tx_trans_attr_cr; /* Transmit transaction attributes control register */
	uint32_t tx_mpdu_link_stat1; /* Transmit MPDU link status 1 register */
	uint32_t tx_mpdu_link_stat2; /* Transmit MPDU link status 2 register */
	uint32_t tx_mpdu_outs_cmd_stat1; /* Transmit MPDU outstanding command status 1 register */
	uint32_t tx_mpdu_outs_cmd_stat2; /* Transmit MPDU outstanding command status 2 register */
	uint32_t tx_band0_ctrl; /* Transmit band 0 control register */
	uint32_t tx_band1_ctrl; /* Transmit band 1 control register */
	uint8_t reserved1[0x2C];

	/* User specific Registers */
	uint32_t tx_user0_cfg0; /* Transmit user configuration 0 register */
	uint32_t tx_user0_cfg1; /* Transmit user configuration 1 register */
	uint32_t tx_user0_mpdu_cmd1; /* Transmit user MPDU command 1 register */
	uint32_t tx_user0_mpdu_cmd2; /* Transmit user MPDU command 2 register */
	uint32_t tx_user0_mpdu_cmd3; /* Transmit user MPDU command 3 register */
	uint8_t reserved2[4];
	uint32_t tx_user0_mpdu_cmd4; /* Transmit user MPDU command 4 register */
	uint32_t tx_user0_mpdu_cmd5; /* Transmit user MPDU command 5 register */
	uint32_t tx_user0_stat; /* Transmit user status register */
	uint8_t reserved3[0xF5C];
};

struct aiop_dte_rx_regs {
	/* RX DMA and Stream Assembly Registers */
	uint32_t rx_com_sc; /* Receive common status control register */
	uint8_t reserved0[8];
	uint32_t rx_user_en[2]; /* Receive user enable 1/user enable 2 register */
	uint32_t rx_user_rst[2]; /* Receive user reset 1/user reset 2 register */
	uint32_t rx_bus_err_stat1; /* Receive bus error status 1 register */
	uint32_t rx_bus_err_stat2; /* Receive bus error status 2 register */
	uint32_t rx_phy_ovrn_stat1; /* Receive phy overrun status 1 register */
	uint32_t rx_phy_ovrn_stat2; /* Receive phy overrun status 2 register */
	uint32_t rx_mpdu_stat1; /* Receive MPDU status 1 register */
	uint32_t rx_mpdu_stat2; /* Receive MPDU status 2 register */
	uint32_t rx_psdu_stat1; /* Receive PSDU status 1 register */
	uint32_t rx_psdu_stat2; /* Receive PSDU status 2 register */
	uint32_t rx_buf_stat1; /* Receive buffer status 1 register */
	uint32_t rx_buf_stat2; /* Receive buffer status 2 register */
	uint32_t rx_ws_buf_stat1; /* Receive workspace buffer status 1 register */
	uint32_t rx_ws_buf_stat2; /* Receive workspace buffer status 2 register */
	uint32_t rx_drop_psdu_stat1; /* Receive DROP PSDU status 1 register */
	uint32_t rx_drop_psdu_stat2; /* Receive DROP PSDU status 2 register */
	uint32_t rx_fd_attr1_cr; /* Receive Frame Descriptor Attributes 1 control register */
	uint32_t rx_fd_attr2_cr; /* Receive Frame Descriptor Attributes 2 control register */
	uint32_t rx_annot_ins_cr; /* Receive annotation insertion control register */
	uint8_t reserved1[0xB8];
	uint32_t rx_trust_cfg; /* Receive trust configuration register */
	uint32_t rx_trans_attr_cr; /* Receive transaction attributes control register */
	uint32_t rx_buf_avl_stat1; /* Receive buffer available status 1 register */
	uint32_t rx_buf_avl_stat2; /* Receive buffer available status 2 register */
	uint32_t rx_ws_buf_avl_stat1; /* Receive WS buffer available status 1 register */
	uint32_t rx_ws_buf_avl_stat2; /* Receive WS buffer available status 2 register */

	/* Band Specific Registers */
	uint32_t rx_band0_com1_lo; /* Receive band0 common address 1 low register */
	uint32_t rx_band0_com1_hi; /* Receive band0 common address 1 high register */
	uint32_t rx_band0_com2_lo; /* Receive band0 common address 2 low register */
	uint32_t rx_band0_com2_hi; /* Receive band0 common address 2 high register */
	uint32_t rx_band0_ctr3_addr_lo; /* Receive band0 control address 3 low register */
	uint32_t rx_band0_ctr3_addr_hi; /* Receive band0 control address 3 high register */
	uint32_t rx_band0_ctr4_addr_lo; /* Receive band0 control address 4 low register */
	uint32_t rx_band0_ctr4_addr_hi; /* Receive band0 control address 4 high register */
	uint32_t rx_band0_ctr5_addr_lo; /* Receive band0 control address 5 low register */
	uint32_t rx_band0_ctr5_addr_hi; /* Receive band0 control address 5 high register */
	uint32_t rx_band0_ctr6_addr_lo; /* Receive band0 control address 6 low register */
	uint32_t rx_band0_ctr6_addr_hi; /* Receive band0 control address 6 high register */
	uint32_t rx_band0_data3_addr_lo; /* Receive band0 data address 3 low register */
	uint32_t rx_band0_data3_addr_hi; /* Receive band0 data address 3 high register */
	uint32_t rx_band0_data4_addr_lo; /* Receive band0 data address 4 low register */
	uint32_t rx_band0_data4_addr_hi; /* Receive band0 data address 4 high register */
	uint32_t rx_band0_data5_addr_lo; /* Receive band0 data address 5 low register */
	uint32_t rx_band0_data5_addr_hi; /* Receive band0 data address 5 high register */
	uint32_t rx_band0_data6_addr_lo; /* Receive band0 data address 6 low register */
	uint32_t rx_band0_data6_addr_hi; /* Receive band0 data address 6 high register */
	uint32_t rx_band0_mng3_addr_lo; /* Receive band0 management address 3 low register */
	uint32_t rx_band0_mng3_addr_hi; /* Receive band0 management address 3 high register */
	uint32_t rx_band0_mng4_addr_lo; /* Receive band0 management address 4 low register */
	uint32_t rx_band0_mng4_addr_hi; /* Receive band0 management address 4 high register */
	uint32_t rx_band0_mng5_addr_lo; /* Receive band0 management address 5 low register */
	uint32_t rx_band0_mng5_addr_hi; /* Receive band0 management address 5 high register */
	uint32_t rx_band0_mng6_addr_lo; /* Receive band0 management address 6 low register */
	uint32_t rx_band0_mng6_addr_hi; /* Receive band0 management address 6 high register */
	uint32_t rx_band0_cd_ws_base; /* Receive band0 completion descriptor WS base address register */
	uint32_t rx_band0_cd_ws_limit; /* Receive band0 completion descriptor WS limit address register */
	uint32_t rx_band0_cd_ws_tail; /* Receive band0 completion descriptor WS tail address register */
	uint32_t rx_band0_cd_ws_head; /* Receive band0 completion descriptor WS head address register */
	uint32_t rx_band0_cd_ws_dma_addr; /* Receive band0 completion descriptor WS DMA address register */
	uint32_t rx_band0_sc; /* Receive band0 status control register */
	uint8_t reserved2[0x88]; /* Reserved for band 1 */
	uint8_t reserved3[0x3C0];

	/* User specific Registers */
	uint32_t rx_user0_cfg0; /* Receive user configuration 0 register */
	uint32_t rx_user0_cfg1; /* Receive user configuration 1 register */
	uint32_t rx_user0_cfg2; /* Receive user configuration 2 register */
	uint8_t reserved4[4];
	uint32_t rx_user0_base_hi; /* Receive user base address high register */
	uint32_t rx_user0_base_lo; /* Receive user base address low register */
	uint32_t rx_user0_limit_hi; /* Receive user limit address high register */
	uint32_t rx_user0_limit_lo; /* Receive user limit address low register */
	uint32_t rx_user0_mh_ws_base; /* Receive user mac header WS base address register */
	uint32_t rx_user0_mh_ws_limit; /* Receive user mac header WS limit address register */
	uint32_t rx_user0_head_hi; /* Receive user head address high register */
	uint32_t rx_user0_head_lo; /* Receive user head address low register */
	uint32_t rx_user0_tail_hi; /* Receive user tail address high register */
	uint32_t rx_user0_tail_lo; /* Receive user tail address low register */
	uint32_t rx_user0_dma_addr_hi; /* Receive user DMA high address register */
	uint32_t rx_user0_dma_addr_lo; /* Receive user DMA low address register */
	uint32_t rx_user0_mh_ws_tail; /* Receive user mac header WS tail address register */
	uint32_t rx_user0_mh_ws_head; /* Receive user mac header WS head address register */
	uint32_t rx_user0_mh_ws_dma_addr; /* Receive user mac header WS dma address register */
	uint32_t rx_user0_stat; /* Receive user status register */
	uint8_t reserved5[0x177C]; /* Reservated space for User#1...#47 */
	uint8_t reserved6[0x234];
};

struct aiop_ete_edu_regs {
	OS_MEM_RESERVED(0x000, 0x040);

	uint32_t edu_mskaccr;	/* EDU Mask Access Register */

	OS_MEM_RESERVED(0x044, 0x048);

	uint32_t edu_staccr;	/* EDU Status Access Register */

	OS_MEM_RESERVED(0x04C, 0x050);

	uint32_t eduevtcr1; 	/* EDU Event Configuration Register 1 */
	uint32_t eduevtcr2;	/* EDU Event Configuration Register 2 */

	OS_MEM_RESERVED(0x058, 0x100);

	uint32_t edu_mn_r0;	/* EDU Mask Register 0 */
	uint32_t edu_mn_r1;	/* EDU Mask Register 1 */
	uint32_t edu_mn_r2;	/* EDU Mask Register 2 */
	uint32_t edu_mn_r3;	/* EDU Mask Register 3 */
	uint32_t edu_mn_r4;	/* EDU Mask Register 4 */
	uint32_t edu_mn_r5;	/* EDU Mask Register 5 */
	uint32_t edu_mn_r6;	/* EDU Mask Register 6 */
	uint32_t edu_mn_r7;	/* EDU Mask Register 7 */
	uint32_t edu_mn_r8;	/* EDU Mask Register 8 */
	uint32_t edu_mn_r9;	/* EDU Mask Register 9 */
	uint32_t edu_mn_r10;	/* EDU Mask Register 10 */
	uint32_t edu_mn_r11;	/* EDU Mask Register 11 */
	uint32_t edu_mn_r12;	/* EDU Mask Register 12 */
	uint32_t edu_mn_r13;	/* EDU Mask Register 13 */
	uint32_t edu_mn_r14;	/* EDU Mask Register 14 */
	uint32_t edu_mn_r15;	/* EDU Mask Register 15 */

	OS_MEM_RESERVED(0x140, 0x180);

	uint32_t edu_fevn_sr0;	/* EDU First Event Status Register 0 */
	uint32_t edu_fevn_sr1;	/* EDU First Event Status Register 1 */
	uint32_t edu_fevn_sr2;	/* EDU First Event Status Register 2 */
	uint32_t edu_fevn_sr3;	/* EDU First Event Status Register 3 */
	uint32_t edu_fevn_sr4;	/* EDU First Event Status Register 4 */
	uint32_t edu_fevn_sr5;	/* EDU First Event Status Register 5 */
	uint32_t edu_fevn_sr6;	/* EDU First Event Status Register 6 */
	uint32_t edu_fevn_sr7;	/* EDU First Event Status Register 7 */
	uint32_t edu_fevn_sr8;	/* EDU First Event Status Register 8 */
	uint32_t edu_fevn_sr9;	/* EDU First Event Status Register 9*/
	uint32_t edu_fevn_sr10;	/* EDU First Event Status Register 10 */
	uint32_t edu_fevn_sr11;	/* EDU First Event Status Register 11 */
	uint32_t edu_fevn_sr12;	/* EDU First Event Status Register 12 */
	uint32_t edu_fevn_sr13;	/* EDU First Event Status Register 13 */
	uint32_t edu_fevn_sr14;	/* EDU First Event Status Register 14 */
	uint32_t edu_fevn_sr15;	/* EDU First Event Status Register 15 */

	uint32_t edu_aevn_sr0;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr1;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr2;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr3;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr4;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr5;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr6;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr7;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr8;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr9;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr10;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr11;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr12;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr13;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr14;	/* EDU All Events Status Register 0 */
	uint32_t edu_aevn_sr15;	/* EDU All Events Status Register 0 */

	struct edu_tcprn {
		uint32_t edu_tcprn_r1;	/* EDU Task Cfg. Profile n Register 1 */
		uint32_t edu_tcprn_r2;	/* EDU Task Cfg. Profile n Register 2 */
		uint32_t edu_tcprn_r3;	/* EDU Task Cfg. Profile n Register 3 */
		uint32_t edu_tcprn_r4;	/* EDU Task Cfg. Profile n Register 4 */
		uint32_t edu_tcprn_r5;	/* EDU Task Cfg. Profile n Register 5 */
		uint32_t edu_tcprn_r6;	/* EDU Task Cfg. Profile n Register 6 */
		uint32_t edu_tcprn_r7;	/* EDU Task Cfg. Profile n Register 7 */

		OS_MEM_RESERVED(0x21C, 0x220);

	} edu_tcprn[16];

	OS_MEM_RESERVED(0x400, 0xC00);

	uint32_t tm_phy_tmr_ctrl;	/* PHY Timer Control Register */

	struct tm_phy_tmr_n {
		uint32_t tm_phy_tmr_cncrs;/* PHY Timer Comparator n Control and
					   * Status Register */
		uint32_t tm_phy_tmr_cnv;  /* PHY Timer Comparator 0 Value
					   * Register */
	} tm_phy_tmr_n[96];

	OS_MEM_RESERVED(0xF04, 0x1000);
};

struct aiop_ete_epu_regs {
	uint32_t epgcr;		/* Event Processor Global Control */

	OS_MEM_RESERVED(0x004, 0x010);

	uint32_t epesr;		/* Event Processor Event Status */

	OS_MEM_RESERVED(0x014, 0x020);

	uint32_t episr[4];	/* Event Processor Interrupt Status n
				   (EPISR0 - EPISR3) */
	uint32_t epctrisr0;	/* Event Processor Counter Interrupt Status n */

	OS_MEM_RESERVED(0x034, 0x040);

	uint32_t epctrcsr;	/* Event Processor Counter Capture Status */

	OS_MEM_RESERVED(0x044, 0x050);

	uint32_t epevctrn[10];	/* Event Processor EVT Pin Control n */

	OS_MEM_RESERVED(0x078, 0x090);

	uint32_t epxtrigcr;	/* Event Processor Crosstrigger Control */

	OS_MEM_RESERVED(0x094, 0x100);

	uint32_t epimcrn[32];

	OS_MEM_RESERVED(0x180, 0x200);

	uint32_t epsmcrn[16];	/* Event Processor SCU Mux Control n */

	OS_MEM_RESERVED(0x240, 0x300);

	uint32_t epecrn[16];	/* Event Processor Event Control n */

	OS_MEM_RESERVED(0x340, 0x400);

	uint32_t epacrn[16];	/* Event Processor Action Control n */

	OS_MEM_RESERVED(0x440, 0x480);

	uint32_t epgacrn[16];	/* Event Processor Group Action Control n */

	OS_MEM_RESERVED(0x4C0, 0x540);

	uint32_t epctrgcran[4]; /* Event Processor Counter Group
				   Configuration an */

	OS_MEM_RESERVED(0x550, 0x580);

	uint32_t epegcrn[3];	/* Event Processor Event Group
				   Configuration n */

	OS_MEM_RESERVED(0x58C, 0x600);

	uint32_t epfsmsr0;	/* Event Processor Finite State Machine
				   Status 0 */

	OS_MEM_RESERVED(0x604, 0x610);

	uint32_t epfsmcprn[4];	/* Event Processor Finite State Machine
				   Compare n */

	OS_MEM_RESERVED(0x620, 0x630);

	uint32_t epfsmcrn[8];	/* Event Processor Finite State Machine
				   Control n */

	OS_MEM_RESERVED(0x650, 0x800);

	uint32_t epccrn[32];	/* Event Processor Counter Control n */

	OS_MEM_RESERVED(0x880, 0x900);

	uint32_t epcmprn[32];	/* Event Processor Counter Compare n */

	OS_MEM_RESERVED(0x980, 0xA00);

	uint32_t epctrn[32];	/* Event Processor Counter n */

	OS_MEM_RESERVED(0xA80, 0xB00);

	uint32_t epcaprn[32];	/* Event Processor Counter Capture n */

	OS_MEM_RESERVED(0xB80, 0xFD0);

	uint32_t eprsrvn[8];	/* Event Processor Debug Reservation n */

	uint32_t ephsrn[4];	/* Event Processor Hardware Semaphore n */
};

struct aiop_ete_epu_global_timer_regs {
	uint32_t epgcr2;	/* Event Processor Global Control Register 2 */

	OS_MEM_RESERVED(0x004, 0x008);

	uint32_t epgctrisr;	/* Event Processor Global Counter Interrupt
				   Status */

	OS_MEM_RESERVED(0x00C, 0x080);

	uint32_t epgimcrn[8];	/* Event Processor Global Input Mux Control
				   Register n */

	OS_MEM_RESERVED(0x0A0, 0x0C0);

	uint32_t epgccrn[8];	/* Event Processor Global Counter Control
				   Register n */

	OS_MEM_RESERVED(0x0E0, 0x100);

	struct epgctr {
		uint32_t epgctrl;	/* Event Processor Global Counter
					   Register n Low */
		uint32_t epgctrh;	/* Event Processor Global Counter
					   Register n High */
	} epgctrn[8];		/* Event Processor Global Counter Register n */

	OS_MEM_RESERVED(0x140, 0x180);

	struct epgcapr {
		uint32_t epgcaprl;	/* Event Processor Global Counter
					   Capture Register Low */
		uint32_t epgcaprh;	/* Event Processor Global Counter
					   Capture Register High */
	} epgcaprn[8];		/* Event Processor Global Counter Capture
				   egister n*/

	OS_MEM_RESERVED(0x1C0, 0x200);

	struct {
		uint32_t epgcncmprm[4];	/* Event Processor Global Counter n
					   Compare Register m */

		OS_MEM_RESERVED(0x210, 0x220);

	} epgcncmprm[8];

	OS_MEM_RESERVED(0x300, 0xC00);

	uint32_t gdi_registers[0x100];
};

struct aiop_ete_regs {
	struct aiop_ete_edu_regs edu_regs;
	struct aiop_ete_epu_regs epu_regs;
	struct aiop_ete_epu_global_timer_regs epu_global_timer_regs;
};

struct aiop_tile_regs {
	struct aiop_cmgw_regs cmgw_regs; /* Configuration management gateway: tile configuration registers */
	uint8_t reserved1[0xB000];
	struct aiop_fdma_regs fdma_regs; /* Frame DMA Registers */
	struct aiop_cdma_regs cdma_regs; /* Context DMA Registers */
	uint8_t reserved2[0x6000];
	struct aiop_dte_tx_regs wtxa_regs; /* Wireless Transmit Accelerator Registers */
	uint8_t reserved3[0x1000];
	struct aiop_dte_rx_regs wrxa_regs; /* Wireless Receive Accelerator Registers */
	uint8_t reserved4[0x1000];
	struct aiop_ete_regs ete_regs; /* Event Timer Engine Registers */
	struct aiop_osm_regs osm_regs; /* Ordering Scope Manager Registers */
	struct aiop_ws_regs ws_regs; /* Work Scheduler Registers */
	struct aiop_atu_regs atu_regs; /* Address Translation Unit Registers */
	struct aiop_pm_regs pm_regs; /* Power Management Registers */
	struct aiop_tman_regs tman_regs; /* Timer Manager - Configuration Access Port */
	uint8_t reserved5[0x3C000];
};

struct aiop_dcsr_core {
	OS_MEM_RESERVED(0x0, 0x30C);
	volatile uint32_t ctstws; /**< CTS Task Watchdog Status Register */
	OS_MEM_RESERVED(0x310, 0x400);
};

struct aiop_dcsr_clustr {
	struct aiop_dcsr_core core[AIOP_MAX_NUM_CORES_IN_CLUSTER];
	OS_MEM_RESERVED(0x081000, 0x090000);
};

/**
 * AIOP peripherals DCSR memory map
 */
struct aiop_dcsr_regs {
	OS_MEM_RESERVED(0x0100000, 0x010042C);
	uint32_t wiopw_s_errcr;
	OS_MEM_RESERVED(0x0100430, 0x0180000);
	struct aiop_dcsr_clustr clustr[AIOP_MAX_NUM_CLUSTERS];
};

/**
 * AIOP Tile's Portal Map Space
 * Available only on LS2085�s Rev 2 and LS1080
 * Use SOC_PERIPH_OFF_PORTAL_MAP + AIOP_PERIPHERALS_OFF to access it
 * This space is allocated as follows:
	� AIOP Core accesses to 0x00F_0000 correspond to
	offset 0x0000_0000 in the Tile�s Portal map
	� AIOP Core accesses to 0x00F_0100 correspond to
	offset 0x0001_0000 in the Tile�s Portal map
	� ...
	� AIOP Core accesses to 0x00F_0800 correspond to
	offset 0x0008_0000 in the Tile�s Portal map
	� AIOP Core accesses to 0x00F_0900 correspond to
	offset 0x0009_0000 in the Tile�s Portal map
 */
struct aiop_portal_map_regs {
	struct {
		struct {
			uint32_t dprr;
			/**< General or Management Doorbell Priority x Request Register */
			OS_MEM_RESERVED(0x00004, 0x100);
		}pr[2];
		/**< 0 or 1 priority */
		OS_MEM_RESERVED(0x200, 0x800);
	}req_g_m[2];
	/**< 0 - General or 1 - Management Doorbell */
};

#endif /* __AIOP_COMMON_H */
