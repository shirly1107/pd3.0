/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_SEC_H_
#define __FSL_SECU_H_

#include "fsl_types.h"

/*!
 * @Group grp_sec	SEC API
 *
 * @brief	Contains initialization APIs and runtime APIs for SEC
 * @{
 */


/**************************************************************************//**
 @Description   SEC SoC dependent parameters
 *//***************************************************************************/
struct sec_desc {
	int disable;
	int coherency_mode; /**< How CAAM coherency is handled in SoC >*/
	phys_addr_t paddr; /**< SEC registers physical address >*/
	void *vaddr; /**< SEC registers virtual address >*/
};

/**
 * struct caam_attr - Structure representing attributes of the SEC hardware accelerator
 * @ip_id: ID for SEC.
 * @major_rev: Major revision number for SEC.
 * @minor_rev: Minor revision number for SEC.
 * @era: SEC Era.
 * @deco_num: The number of copies of the DECO that are implemented in this version of SEC.
 * @zuc_auth_acc_num: The number of copies of ZUCA that are implemented in this version of SEC.
 * @zuc_enc_acc_num: The number of copies of ZUCE that are implemented in this version of SEC.
 * @snow_f8_acc_num: The number of copies of the SNOW-f8 module that are implemented in this version of SEC.
 * @snow_f9_acc_num: The number of copies of the SNOW-f9 module that are implemented in this version of SEC.
 * @crc_acc_num: The number of copies of the CRC module that are implemented in this version of SEC.
 * @pk_acc_num: The number of copies of the Public Key module that are implemented in this version of SEC.
 * @kasumi_acc_num: The number of copies of the Kasumi module that are implemented in this version of SEC.
 * @rng_acc_num: The number of copies of the Random Number Generator that are implemented in this version of SEC.
 * @md_acc_num: The number of copies of the MDHA (Hashing module) that are implemented in this version of SEC.
 * @arc4_acc_num: The number of copies of the ARC4 module that are implemented in this version of SEC.
 * @des_acc_num: The number of copies of the DES module that are implemented in this version of SEC.
 * @aes_acc_num: The number of copies of the AES module that are implemented in this version of SEC.
 * @ccha_acc_num: The number of copies of the ChaCha20 module that are implemented in this version of SEC.
 * @ptha_acc_num: The number of copies of the Poly1305 module that are implemented in this version of SEC.
 **/
struct caam_attr {
	uint16_t	ip_id;
	uint8_t   	major_rev;
	uint8_t    	minor_rev;
	uint8_t		era;
	uint8_t		deco_num;
	uint8_t		zuc_auth_acc_num;
	uint8_t		zuc_enc_acc_num;
	uint8_t 	snow_f8_acc_num;
	uint8_t		snow_f9_acc_num;
	uint8_t		crc_acc_num;
	uint8_t		pk_acc_num;
	uint8_t		kasumi_acc_num;
	uint8_t		rng_acc_num;
	uint8_t		md_acc_num;
	uint8_t		arc4_acc_num;
	uint8_t		des_acc_num;
	uint8_t		aes_acc_num;
	uint8_t		ccha_acc_num;
	uint8_t		ptha_acc_num;
};

/**
 * struct caam_counters - Global counters of the SEC hardware accelerator
 * @dequeued_requests: Number of Requests Dequeued
 * @ob_enc_requests: Number of Outbound Encrypt Requests
 * @ib_dec_requests: Number of Inbound Decrypt Requests
 * @ob_enc_bytes: Number of Outbound Bytes Encrypted
 * @ob_prot_bytes: Number of Outbound Bytes Protected
 * @ib_dec_bytes: Number of Inbound Bytes Decrypted
 * @ib_valid_bytes: Number of Inbound Bytes Validated
 */
struct caam_counters {
	uint64_t 	dequeued_requests;
	uint64_t	ob_enc_requests;
	uint64_t	ib_dec_requests;
	uint64_t	ob_enc_bytes;
	uint64_t	ob_prot_bytes;
	uint64_t	ib_dec_bytes;
	uint64_t	ib_valid_bytes;
};

/**************************************************************************//**
 @Description   CAAM Coherency mode
*//***************************************************************************/
typedef enum coherency_mode {
	SEC_COHERENCY_MODE_NONE = 0, /**< Dummy value >*/
	SEC_COHERENCY_MODE_REV1, /**< CAAM transactions are not generated
		default coherent by Gen3 Chassis >*/
	SEC_COHERENCY_MODE_REV2 /**< CAAM transactions are generated
		coherent by Gen3 Chassis */
} e_coherency_mode;

int caam_get_attributes(struct sec_desc *desc, struct caam_attr *attr);
int caam_get_counters(struct sec_desc *desc, struct caam_counters *ctr);

/** @} */

#endif /* __FSL_SEC_H_ */
