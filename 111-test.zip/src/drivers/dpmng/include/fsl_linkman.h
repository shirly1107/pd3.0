/**************************************************************************//**
            Copyright 2013 Freescale Semiconductor, Inc.

 @File          fsl_linkman.h

 @Description   This file contains LINK-MANAGER API.
*//***************************************************************************/
#ifndef __FSL_LINKMAN_H
#define __FSL_LINKMAN_H


#include "fsl_types.h"
#include "fsl_enet.h"
#include "fsl_dpmng_mc.h"	/* struct dpmng_accesspoint */


#define DPMNG_MAX_CEETM_CH			16

/**************************************************************************//**
 @Group         ldpaa_g  LDPAA API

 @Description   TODO

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Group         linkman_g  LDPAA IO API

 @Description   TODO

 @{
*//***************************************************************************/

/**
 * @brief	linkman2.0
 */
enum linkman_state {
       LINKMAN_STATE_IDLE = 0,
       LINKMAN_STATE_CANDIDATE,
       LINKMAN_STATE_CONNECTED,
       LINKMAN_STATE_NEGOTIATION,
       LINKMAN_STATE_LINKUP,
       LINKMAN_STATE_INVALID
};

enum linkman_event {
	LINKMAN_EVENT_DISCONNECT = 0,
	LINKMAN_EVENT_CONNECT,
        LINKMAN_EVENT_ASSOCIATE,
        LINKMAN_EVENT_DEASSOCIATE,
        LINKMAN_EVENT_NEGOTIATION_OK,
        LINKMAN_EVENT_NEGOTIATION_FAIL,
        LINKMAN_EVENT_NEGOTIATION,
        LINKMAN_EVENT_LINKDOWN,
        LINKMAN_EVENT_LINKUP,
        LINKMAN_EVENT_INVALID
};

/*!
 * @name LINKMAN link options
 */
#define LINKMAN_LINK_OPT_AUTONEG		0x0000000000000001ULL
/* Enable auto-negotiation */
#define LINKMAN_LINK_OPT_HALF_DUPLEX		0x0000000000000002ULL
/* Enable half-duplex mode */
#define LINKMAN_LINK_OPT_PAUSE			0x0000000000000004ULL
/* Enable symmetric pause frames */
#define LINKMAN_LINK_OPT_ASYM_PAUSE		0x0000000000000008ULL
/* Enable asymmetric pause frames */
#define LINKMAN_LINK_OPT_PFC_PAUSE		0x0000000000000010ULL
/* Enable priority flow control pause frames */

/* Continue indication */
#define LINKMAN_ECONT		0xC0

/* Valid fields */
#define LINKMAN_FIELD_IFPID			0x00000001	/* Connect */
#define LINKMAN_FIELD_TID			0x00000020
#define LINKMAN_FIELD_KID			0x00000040
#define LINKMAN_FIELD_DPDMUX_METHOD		0x00000080
#define LINKMAN_FIELD_IFP_ENABLE		0x00000100
#define LINKMAN_FIELD_CONN_ID			0x00000200	/* Connect */
#define LINKMAN_FIELD_AP_AVAILABLE		0x00000400	/* Connect */
#define LINKMAN_FIELD_LINK_CFG			0x00000800	/* Link up, Disconnect - copy link configuration into internal linkman structures*/
#define LINKMAN_FIELD_LINK_STATE		0x00001000	/* Link up */
#define LINKMAN_FIELD_DPMAC_RX_DIS		0x00008000	/* link down */
#define LINKMAN_FIELD_ALLOCATE_CR		0x00010000	/* allocate committed rate */
#define LINKMAN_FIELD_PFC_CONFIG		0x00020000	/* disconnect
														dpni<->dp_master_object: check current flow cntrol configuration */
#define LINKMAN_FIELD_CLEAR_TX_FRAMES   0x00040000  /* disconnect - clear tx frames */
#define LINKMAN_FIELD_FREE_CONN_ID		0x00080000	/* Disconnect - signals if connection is freed */
#define LINKMAN_FIELD_CLEANUP_PFC		0x00100000	/* Disconnect - cleanup PFC before AP */
#define LINKMAN_FIELD_INIT				0x00200000	/* Connect - initialization phase when data must be passed down between two objects*/

/* linkman_control request */
#define LINKMAN_REQUEST_CANDIDATE     	0x00000001      /* Request for state */
#define LINKMAN_REQUEST_NEGOTIATION    	0x00000008      /* Request for state */
#define LINKMAN_REQUEST_COMPLETE_CB 	0x00000010      /* completion indication */

struct linkman_link_state {
        uint32_t rate;
        uint64_t options;
        uint64_t advertising;
};

struct linkman_endpoint {
	uint32_t 		valid_fields;

	/* End point information */
	enum fsl_module	type;		/* Device type SW/NIC/DMux */
	uint16_t		id;		/* Device ID */
	uint16_t		if_id;		/* interface ID */

	/* Connect */
	struct dpmng_accesspoint ap[DPMNG_MAX_CEETM_CH];		/* DPMNG access-point */
	int			ap_available;
	int			ifpid;
	int 			conn_id;	/* connection id */
	int			allocate_cr;
	int			num_channels;

	/*! Auxiliary information */
	uint16_t	tid;			/*! Table ID */
	uint16_t	kid;			/*! Key ID */
	int 		dpdmux_method;

	/* Link up */
        uint32_t 		rate;
        uint64_t 		options;
        uint64_t        advertising;
	int			link_state_available;

    int		fc_channel_idx; /* channel index to perform flow control in recycle port connections */
    int 	fc_available;
    int 	fc_disabled;

	int		ep_enabled; /* endpoint is enabled; reflect the state of the endpoint in case of
							dpni, dpdmux interface or dpsw interface*/
};

enum linkman_cmd {
	LINKMAN_CMD_ENABLE = 3,
	LINKMAN_CMD_DISABLE,
	LINKMAN_CMD_SET_LINK_CFG,
	LINKMAN_CMD_LINKUP_FROM_CONNECT,	/* Link up procedure is the result of the connect command */
	LINKMAN_CMD_LINKDOWN_FROM_DISCONNECT,   /* Link down procedure is the result of the disconnect command */
	LINKMAN_CMD_SILENTLY,	/* Used when MSI is not desired to be sent */
};

struct linkman_control {
        enum linkman_event             	event;          /* event */
        uint32_t                        committed_rate;	/* committed rate */
        uint32_t                        max_rate;	/* maximum rate */
        uint64_t						supported;
        enum linkman_cmd				cmd;
};

struct linkman_action {
        uint32_t                        request;        /* bitmap Request */
        struct linkman_link_state       state;          /* rate + options */
};

typedef int (linkman_cb_t)(void        *handle,        /* connector handle */
        const struct linkman_control   *control,       /* Control Information */
        struct linkman_endpoint        *self,          /* endpoint 1 info */
        const struct linkman_endpoint  *peer,          /* endpoint 2 info */
        struct linkman_action          *action         /* required action */
        );

/* Link manager 2.0 API*/
struct linkman;

struct linkman *linkman_create(int size);

void linkman_destroy(struct linkman *linkman);

int linkman_register_cb(struct linkman        *linkman,/* context */
                        enum fsl_module      type,  	/* connector type */
                        linkman_cb_t    	*event_cb,/* callback */
                        linkman_cb_t  	*event_complete_cb/* complete cb */
                        );

int linkman_unregister_cb(struct linkman        *linkman,/* context */
                        enum fsl_module  	type  	/* connector type */
                        );

int linkman_set_connection (
        struct linkman         *linkman,       		/* context */
        const struct linkman_control *control,          /* Control Information */
        const struct linkman_endpoint *endpoint1,      	/* endpoint 1 */
        const struct linkman_endpoint *endpoint2);     	/* endpoint 2 */

struct linkman_connection_attr {
	enum linkman_state	state;		/* link state */
	uint32_t 			rate;		/* rate */
	uint64_t 			options;	/* options */
	uint32_t			committed_rate;	/* committed rate */
	uint32_t			max_rate;	/* maximum rate */
	uint64_t			supported;
	uint64_t			advertising;
};

int linkman_get_connection(
	struct linkman 			*linkman,	/* context */
	const struct linkman_endpoint	*endpoint1,	/* endpoint 1 [in] */
        struct linkman_endpoint		*endpoint2,	/* endpoint 2 [out] */
        struct linkman_connection_attr	*attr  		/* attributes [out] */
);

#endif /* __FSL_LINKMAN_H */
