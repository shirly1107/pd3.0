/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_CTLU_H_
#define __FSL_CTLU_H_

#include "fsl_types.h"
#include "fsl_net.h"
#include "fsl_resman.h"

/*!
 * @Group grp_ctlu	CTLU API
 *
 * @brief	Contains initialization APIs and runtime APIs for CTLU
 * @{
 */

struct ctlu;

/* EIOP only options */
#define CTLU_DESC_OPT_REDUCED_TCAM 	0x00000001 /*! TCAM is to be half of reset value */
#define CTLU_DESC_OPT_USE_AS_EGRESS	0x00000002 /* may be used in Egress CTLU */
#define CTLU_DESC_OPT_NO_PEBM	        0x00000004 /* may be used in Egress CTLU */

/* AIOP only options */
#define CTLU_DESC_OPT_USE_AS_MFLU	0x00000001 /* may be used in AIOP CTLU */

/**************************************************************************//**
 @Description   An enum for defining CTLU type
 *//***************************************************************************/
enum ctlu_type {
	CTLU_EIOP_EGRESS, /*!< CTLU for EIOP Egress */
	CTLU_EIOP_INGRESS, /*!< CTLU for EIOP Ingress */
	CTLU_AIOP, /*!< CTLU for AIOP */
	CTLU_AIOP_MFLU
/*!< NAMING!!! */
};

struct ctlu_profiling_counters {
	uint32_t rule_lookups;
	uint32_t rule_hits;
	uint32_t entry_lookups;
	uint32_t entry_hits;
	uint32_t cache_accesses;
	uint32_t cache_hits;
	uint32_t cache_updates;
	uint32_t memory_accesses;
};

struct ctlu_profiling_options {
	uint8_t enable_profiling_counters;
	uint8_t enable_profiling_for_tid;
	uint16_t table_id; // valid iff enable_profiling_for_tid is 'true'
};
/**************************************************************************//**
 @Description   CTLU general parameters
 *//***************************************************************************/
/* TODO - consider having a per-CTLU resman device, no config, 
 * use sys_get_handle */
struct ctlu_cfg {
	void *resman_device; /*!< resman device for internally
	 managing CTLU resources */
/* TODO */
/*uint16_t	ifp_icid;*/
	struct ctlu_profiling_options;
};

/**************************************************************************//**
 @Description   CTLU SoC dependent parameters
 *//***************************************************************************/
struct ctlu_desc {
	int iop_id; /*! EIOP/AIOP id */
	enum ctlu_type type; /*! EIOP Egress/ingress, AIOP/MFLU id */

	phys_addr_t block_paddr; /*! CTLU registers physical address */
	void *block_vaddr; /*! CTLU registers virtual address */

	phys_addr_t dpparser_paddr; /*! Parser registers physical address */
	void *dpparser_vaddr; /*! Parser registers virtual address */
	int num_dpparser_profiles; /*! Number of Parser profiles */

	int num_dppolicy_entries; /*! Number of Policy entries */

	phys_addr_t dptbl_mng_paddr; /*! Tables registers physical address */
	void *dptbl_mng_vaddr; /*! Tables registers virtual address */
	int num_dptbl_tcam_entries; /*! Number of TCAM entries */
	uint16_t tcam_key_size; /*! size, in HW, of each TCAM entry */
	uint32_t dptbl_scanning_speed; /*!< This value is used as a timer for
	 aging. The CTLU clock is divided by this value. Each time the clock
	 expires the CTLU scans one entry in the CTLU memory. A value of zero
	 disables the CTLU scanning operation.*/

	phys_addr_t dpkg_paddr; /*! Keygen registers physical address */
	void *dpkg_vaddr; /*! Keygen registers virtual address */
	int num_dpkg_profiles; /*! Number of Keygen profiles */

	phys_addr_t dppolicer_paddr; /*! Policer registers physical address*/
	void *dppolicer_vaddr; /*! Policer registers virtual address */
	int num_dppolicer_profiles; /*! Number of Policer profiles */

	uint32_t options; /*! See CTLU_DESC_OPT_xxx */
	int errata; /*! See CTLU_DESC_ERR_xxx */
};

/**************************************************************************//**
 @Description   Enum for defining CTLU Management commands
 *//***************************************************************************/
/* ORDER MUST NOT BE CAHNGED!!!
 * ANY CHANGE TO THIS ENUM MUST BE REFLECTED IN ctlu_cmd_codes */
enum ctlu_cmd_id {
	MNG_CMD_DPTBL_CREATE, /*! Create table */
	MNG_CMD_DPTBL_PARAMS_QUERY, /*! Query table */
	MNG_CMD_DPTBL_DEL, /*! Delete table */
	MNG_CMD_DPTBL_NEXT_RULEID_QUERY,
	MNG_CMD_DPTBL_RULE_QUERY_WITH_RULEID,

	MNG_CMD_DPTBL_RULE_CREATE, /*! Create table rule*/
	MNG_CMD_DPTBL_RULE_CREATE_REPLACE,
	/*! Create or replace table rule */
	MNG_CMD_DPTBL_RULE_REPLACE, /*! Replace table rule */
	MNG_CMD_DPTBL_RULE_QUERY, /*! Query table rule */
	MNG_CMD_DPTBL_RULE_DEL, /*! Delete table rule */
	MNG_CMD_DPTBL_RULE_MOVE, /*! Move table rule */

	MNG_CMD_DPTBL_TCAM_RULE_REPLACE,
	/*! Replace TCAM table rule */
	MNG_CMD_DPTBL_TCAM_RULE_CREATE, /*! Replace TCAM table rule */
	MNG_CMD_DPTBL_TCAM_RULE_QUERY, /*! Query TCAM table rule */
	MNG_CMD_DPTBL_TCAM_RULE_DEL, /*! Delete TCAM table rule */
	MNG_CMD_DPTBL_TCAM_RULE_MOVE, /*! Move TCAM table rule */

	MNG_CMD_DPPARSER_PROFILE_CREATE_REPLACE,
	/*! Create or replace Parser profile*/
	MNG_CMD_DPPARSER_PROFILE_QUERY, /*! Query Parser profile */
	MNG_CMD_DPPARSER_PROFILE_DEL, /*! Delete Parser profile */

	MNG_CMD_DPPOLICY_RULE_CREATE_REPLACE,
	/*! Create or replace Policy rule */
	MNG_CMD_DPPOLICY_RULE_QUERY, /*! Query Policy rule */
	MNG_CMD_DPPOLICY_RULE_DEL, /*! Delete Policy rule */
	MNG_CMD_DPPOLICY_RULE_MOVE, /*! Move Policy entry rule */

	MNG_CMD_DPKG_RULE_CREATE_REPLACE,
	/*! Create Keygen profile */
	MNG_CMD_DPKG_RULE_QUERY, /*! Query Keygen profile */

	MNG_CMD_QOS_PROFILE_CREATE_UPDATE,
	/*! Create or update QOS entry*/

	MNG_CMD_QOS_PROFILE_QUERY,
	/*! Query QOS entry */
	MNG_CMD_DPPOLICER_PROFILE_CREATE_UPDATE,
	/*! Create  or update Policer profile*/
	MNG_CMD_DPPOLICER_PROFILE_QUERY,
	/*! Query Policer profile */

	MNG_CMD_NULL_ACTION,
	MNG_CMD_DUMMY_LAST
/* Do Not Remove */
};

/**************************************************************************//**
 @Description   Enum for defining CTLU Modules
 *//***************************************************************************/
enum ctlu_module {
	CTLU_CTRL,
	CTLU_DPPARSER,
	CTLU_DPPOLICY_MNG,
	CTLU_DPTABLE_MNG,
	CTLU_DPKG,
	CTLU_DPPOLICER
};
/**
 * @brief  	This function restores the CTLU module object
 *
 * @param[in]   	desc	- A structure of SoC dependent parameters.
 *                         Should be retrieved from the SoC DB.
 * @param[in]   	ctlu	- A structure of current status parameters
 * 
 * @returns      Error code, or 0 on success
 */
int restore_ctlu(const struct ctlu_desc *desc,
		const struct ctlu *ctlu);
/**
 * @brief  	This function initializes the CTLU module object
 *
 * @param[in]   	desc	- A structure of SoC dependent parameters.
 *                         Should be retrieved from the SoC DB.
 * @param[in]   	cfg	- A structure of configuration parameters
 *
 * @returns      A handle to the initialized CTLU module object
 */
struct ctlu * ctlu_init(const struct ctlu_desc *desc,
		const struct ctlu_cfg *cfg);

/**
 * @brief  	This function enables CTLU
 *
 * @param[in]   	ctlu	- A handle to the initialized CTLU module object
 *
 * @returns      None
 */
void ctlu_enable(struct ctlu *ctlu);

/**
 * @brief  	This function deletes the CTLU object
 *
 * @param[in]   	ctlu	- A handle to the initialized CTLU module object
 *
 * @returns      None
 */
void ctlu_done(struct ctlu *ctlu);

/**
 * @brief  	This function returns the CTLU management command code.
 *
 * @param[in]   	cmd	- CTLU Command id
 * @param[out]   code	- CTLU Command code
 *
 * @returns      management command code.
 */
int ctlu_get_cmd_code(struct ctlu *ctlu, enum ctlu_cmd_id cmd, uint32_t *code);

/**
 * @brief  	This function triggers the execution of a management command.
 *
 * @param[in]   	ctlu	- A handle to the initialized CTLU module object
 * @param[in]   	cmd_if	- May be NULL to use default interface, or may be one of
 * 			  eiop_ifp_cmd_if_cfg/TBD.
 * @param[in]   	cmd_cfg	- A pointer to a command configuration structure. may be
 * 			  one of eiop_mng_cmd_cfg/TBD
 * @param[in]   	ctlu_cmd_id - Command to be executed
 * @param[out]   status 	- as returned from command (should be specifically
 *                         parsed per resource)
 * @param[out]   mtypeout- as returned from command (should be specifically
 *                         parsed per resource)
 * @param[out]   out_msg - as returned from command (should be specifically
 *                         parsed per resource)
 * 
 *
 * @returns      Error code, or 0 on success
 */
int ctlu_execute_cmd(struct ctlu *ctlu, const void *cmd_if, void *cmd_cfg,
		enum ctlu_cmd_id cmd, uint16_t *status, uint32_t *mtypeout,
		void **out_msg);

/**
 * @brief  	This function allocates and configures the command configuration
 * 		object
 *
 * @param[in]   	ctlu	- A handle to the initialized CTLU module object
 * @param[out]  	cmd_cfg - CTLU management command object pointer
 * @param[out]   input_msg- the address of the input message. Should be written
 * 			  by caller.
 * @param[out]   mtypein_addr - the address of the input parameters. Should be
 * 			  written by caller.
 *
 * @returns      Error code, or 0 on success
 */
int ctlu_build_cmd_cfg(struct ctlu *ctlu, void **cmd_cfg, void **input_msg,
		uint32_t **mtypein_addr);

/**
 * @brief  	This function frees the command configuration object
 *
 * @param[in]   	ctlu	- A handle to the initialized CTLU module object
 * @param[in]   	cmd_desc- The command descriptor object pointer
 *
 * @returns      Error code, or 0 on success
 */
int ctlu_free_cmd_cfg(struct ctlu *ctlu, void *cmd_desc);


uint32_t ctlu_get_timestamp_period(struct ctlu *ctlu);


/**
 * @brief  	This function returns the Resource Manager object to be used by
 * 		the CTLU sub-modules.
 *
 * @param[in]   	ctlu	- A handle to the initialized CTLU module object
 *
 * @returns      The handle of the CTLU Resource Manager manager
 */
void * ctlu_get_resman(struct ctlu *ctlu);

/**
 * @brief  	This function returns the type of the CTLU object
 *
 * @param[in]   	ctlu	- A handle to the initialized CTLU module object
 *
 * @returns      The type of the CTLU object
 */
enum ctlu_type ctlu_get_type(struct ctlu *ctlu);

/**
 * @brief  	This function returns the memory base of a CTLU sub-module.
 *
 * @param[in]   	ctlu	- A handle to the initialized CTLU module object
 * @param[in]   	module	- The CTLU module
 * @param[out]   addr	- The eturned address
 *
 * @returns      Error code, or 0 on success
 */
int ctlu_get_mem_base(struct ctlu *ctlu, enum ctlu_module module, void **addr);

/**
 * @brief  	This function returns the SoC options for CTLU.
 *
 * @param[in]   	ctlu	- A handle to the initialized CTLU module object
 *
 * @returns      ORed options out of "CTLU_DESC_OPT_" list
 */
uint32_t ctlu_get_soc_options(struct ctlu *ctlu);

/**
 * @brief  	This function returns the SoC errata for CTLU.
 *
 * @param[in]   	ctlu	- A handle to the initialized CTLU module object
 *
 * @returns      ORed options out of "CTLU_DESC_ERR_" list
 */
uint32_t ctlu_get_soc_errata(struct ctlu *ctlu);
int ctlu_get_iop_id(struct ctlu *ctlu);
int ctlu_get_str(int iop_id, enum ctlu_type type, char *str);

void ctlu_dpkg_global_profile_create(struct ctlu *ctlu, uint8_t *ptr);
void ctlu_dptbl_global_rule_add(struct ctlu *ctlu, uint8_t *ptr, int size);
void ctlu_dptbl_global_mask_add(struct ctlu *ctlu, uint8_t *ptr, int size);

int ctlu_get_tcam_key_size(void);

#ifdef ERR009038
void	ctlu_wa_ERR009038(struct ctlu *ctlu);
#endif /* ERR009038 */

int ctlu_set_profiling(struct ctlu*, struct ctlu_profiling_options*);
int ctlu_get_profiling_counters(struct ctlu*, struct ctlu_profiling_counters*);

#endif /* __FSL_CTLU_H_ */
