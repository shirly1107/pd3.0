/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPSPARSER_MC_H
#define __FSL_DPSPARSER_MC_H

/******************************************************************************/
struct dpsparser_cfg {
	uint32_t options;
};

struct dpsparser_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
};

/******************************************************************************/
struct dpsparser;

/******************************************************************************/
int dpsparser_create(struct dpsparser *dpsparser,
		     const struct dpsparser_cfg *cfg);
int dpsparser_open(struct dpsparser *dpsparser, int dpsparser_id);
int dpsparser_close(struct dpsparser *dpsparser);
void dpsparser_destroy(struct dpsparser *dpsparser);
int dpsparser_enable(struct dpsparser *dpsparser);
int dpsparser_disable(struct dpsparser *dpsparser);
int dpsparser_is_enabled(struct dpsparser *dpsparser, int *en);
void dpsparser_reset(struct dpsparser *dpsparser);
int dpsparser_get_attributes(struct dpsparser *dpsparser,
			     struct dpsparser_attr *attr);
int dpsparser_set_irq(struct dpsparser *dpsparser, uint8_t irq_index,
		      const struct mc_irq_cfg *irq_cfg);
int dpsparser_get_irq(struct dpsparser *dpsparser, uint8_t irq_index,
		      struct mc_irq_cfg *irq_cfg);
int dpsparser_set_irq_enable(struct dpsparser *dpsparser, uint8_t irq_index,
			     uint8_t en);
int dpsparser_get_irq_enable(struct dpsparser *dpsparser, uint8_t irq_index,
			     uint8_t *en);
int dpsparser_set_irq_mask(struct dpsparser *dpsparser, uint8_t irq_index,
			   uint32_t mask);
int dpsparser_get_irq_mask(struct dpsparser *dpsparser, uint8_t irq_index,
			   uint32_t *mask);
int dpsparser_get_irq_status(struct dpsparser *dpsparser, uint8_t irq_index,
			     uint32_t *status);
int dpsparser_clear_irq_status(struct dpsparser *dpsparser, uint8_t irq_index,
			       uint32_t status);
/* API functions */

/* MC internal functions */
int dpsparser_restore(const struct dpsparser *dpsparser);
int dpsparser_initialize(struct dpsparser *dpsparser);
int dpsparser_set_dev_ctx(struct dpsparser *dpsparser,
			  const struct dpmng_dev_ctx *dev_ctx);
void dpsparser_exceptions(struct dpsparser *dpsparser);

#endif /* __FSL_DPSPARSER_MC_H */
