/* Copyright 2013 Freescale Semiconductor, Inc. */
/*!
 *  @file    fsl_log.h
 *  @brief   Log API
 *
 */
#ifndef __FSL_LOG_H
#define __FSL_LOG_H

#include "common/fsl_stdarg.h"

#ifndef LOG_MODULE
#define LOG_MODULE	LOG_MOD_DEFAULT
#endif

#define LOG_COLOR_RESET   			"\x1b[0m"
#define LOG_COLOR_RED     			"\x1b[31m"
#define LOG_COLOR_GREY     			"\x1b[37m"

#define LOG_PRINT_FORMAT_HEADER		"%c"		/* level */
#define LOG_PRINT_FORMAT_TIMSTAMP	":%x%08x"   /* timestamp */
#define LOG_PRINT_LOCATION			", %s:%d" 	/* func_name:line */

#define LOG_PRINT_MODULE			", %s" 		/* module_name */
#define LOG_PRINT_MODULE_OBJ		LOG_PRINT_MODULE ":%d" 		/* module_name:obj_id */

/* Next two macros should follow the format:
 * [level:core{:ts}, func_name:line{, module}{:obj_id}]
 * where the tokens between curly brackets are optional */
#define LOG_PRINT_FORMAT_GREY			LOG_COLOR_GREY "[" LOG_PRINT_FORMAT_HEADER "%s" LOG_PRINT_LOCATION "%s] " LOG_COLOR_RESET "%s "
#define LOG_PRINT_FORMAT_RED			LOG_COLOR_RED "[" LOG_PRINT_FORMAT_HEADER "%s" LOG_PRINT_LOCATION "%s] %s " LOG_COLOR_RESET
#define LOG_PRINT_FORMAT_SHORT			"[" LOG_PRINT_FORMAT_HEADER "%s]  "
#define LOG_PRINT_FORMAT_SIMPLE			"[" LOG_PRINT_FORMAT_HEADER "%s" LOG_PRINT_LOCATION "%s]  "
#define LOG_PRINT_FORMAT_GREY_SIMPLE	LOG_COLOR_GREY "[" LOG_PRINT_FORMAT_HEADER "%s] " LOG_COLOR_RESET "%s " 

#define LOG_MODULES_AMOUNT			NUM_LOG_MODULE_TYPE
#define LOG_MODULES_AMOUNT_PACKED	(LOG_MODULES_AMOUNT / 2)

/* Modules that can register to log */
enum log_module {
	LOG_MOD_DEFAULT = 0,
	LOG_MOD_DPNI = 1,
	LOG_MOD_DPIO = 2,
	LOG_MOD_DPBP = 3,
	LOG_MOD_DPSW = 4,
	LOG_MOD_DPRC = 5,
	LOG_MOD_DPCON = 6,
	LOG_MOD_DPDMUX = 7,
	LOG_MOD_DPLAG = 8,
	LOG_MOD_DPMAC = 9,
	LOG_MOD_DPMNG = 10,
	LOG_MOD_DPCI = 11,
	LOG_MOD_DPSECI = 12,
	LOG_MOD_RESMAN = 13,
	LOG_MOD_LINKMAN = 14,
	LOG_MOD_CTLU = 15,
	LOG_MOD_DPAIOP = 16,
	LOG_MOD_EIOP = 17,
	LOG_MOD_CMDIF = 18,
	LOG_MOD_QBMAN = 19,
	LOG_MOD_DPDMAI = 20,
	LOG_MOD_EDMA = 21,
	LOG_MOD_PLATFORM = 22,
	LOG_MOD_DCE = 23,
	LOG_MOD_DPMCP = 24,
	LOG_MOD_DPDCEI = 25,
	LOG_MOD_QDMA = 26,
	LOG_MOD_DPDBG = 27,
	LOG_MOD_DPRTC = 28,
	LOG_MOD_CAAM = 29,
	LOG_MOD_SERDES = 30,
	LOG_MOD_DUART = 31,
	LOG_MOD_DPSPARSER = 32,
	NUM_LOG_MODULE_TYPE
};

/* Log levels */
enum log_level {
	LOG_LEVEL_GLOBAL = 0,
	LOG_LEVEL_DEBUG = 1,
	LOG_LEVEL_INFO = 2,
	LOG_LEVEL_WARNING = 3,
	LOG_LEVEL_ERROR = 4,
	LOG_LEVEL_CRITICAL = 5,
#ifdef MC_CLI
    LOG_LEVEL_USER = 6,
#endif
	NUM_LOG_LEVEL_TYPE
};

#define LOG_LEVEL_NO_CHANGE (0xF)

/* Log mode */
enum log_mode {
	LOG_MODE_OFF = 0,
	LOG_MODE_ON = 1
};

/* Log timestamp mode */
enum log_timestamp_mode {
	LOG_TIMESTAMP_OFF = 0,
	LOG_TIMESTAMP_ON = 1
};

extern enum log_level log_levels[];
extern enum log_level log_global_level;

/*******************************************************************
 External Routines
 *******************************************************************/

int log_init(void);

void log_set_mode(enum log_mode mode);
enum log_mode log_get_mode();

int log_set_module_level(enum log_module module, enum log_level level);
int log_get_module_level(enum log_module module, enum log_level *level);

void log_set_global_level(enum log_level level);
enum log_level log_get_global_level();

int log_set_level_per_object(enum log_module module, int id, enum log_level level);
enum log_level log_get_level_per_object(enum log_module module, int id);

void log_set_timestamp_mode(enum log_timestamp_mode ts_mode);
enum log_timestamp_mode log_get_timestamp_mode();

void log_set_soc_info();

int log_record(enum log_level level, int user_log, enum log_module module, int obj_id, char *function_name, int line, va_list va);

int log_print(char *str, uint32_t count);

static int __will_log(enum log_level level, enum log_module module, int obj_id)
{
	enum log_level obj_level = log_get_level_per_object(module, obj_id);
	if (obj_level != LOG_LEVEL_GLOBAL) {
		if (obj_level <= level) {
			return 1;
		} else {
			return 0;
		}
	}
	/* otherwise use module / global level */
	if (
			((log_levels[module] != LOG_LEVEL_GLOBAL) && (log_levels[module] <= level)) ||
			((log_levels[module] == LOG_LEVEL_GLOBAL) && (log_global_level <= level))
		) {
		return 1;
	}
	
	return 0;
}

static void __log(enum log_level level, int user_log, enum log_module module, int obj_id, char *function_name, int line, ...)
{
	va_list va;

	va_start(va, line);
	log_record(level, user_log, module, obj_id, function_name, line, va);
	va_end(va);
}

#define NO_ID (-1)

#define LOG(_id, _level, _user_log, ...) \
		__log(_level, _user_log, LOG_MODULE, _id, (char*)__FUNCTION__, __LINE__, ##__VA_ARGS__)


/* extract a log level for a certain module from a packed module levels array 
 * @return LOG_LEVEL_NO_CHANGE in case of error
 */
static inline enum log_level mc_log_get_module_level(const uint8_t module_levels[LOG_MODULES_AMOUNT_PACKED], enum log_module module)
{
	int byte = (module >> 1);
	int offset = (module & 1) << 2;
	
	if (!module_levels) 
		return (enum log_level)LOG_LEVEL_NO_CHANGE;
	
	return (enum log_level)((module_levels[byte] >> offset) & 0xf);
}

/* set a log level for a certain module in a packed module levels array */
static inline int mc_log_set_module_level(uint8_t module_levels[LOG_MODULES_AMOUNT_PACKED], enum log_module module, enum log_level level)
{
	uint8_t byte = ((uint8_t)module >> 1);
	uint8_t offset = (((uint8_t)module & 1) << 2);
	uint8_t mask = ((uint8_t)0xF0 >> offset);
	uint8_t val;
	
	if (!module_levels) 
		return -1;
	
	val = (module_levels[byte] & mask) | ((uint8_t)level << offset);
	module_levels[byte] = val;
	
	return 0;
}

#endif /* __FSL_LOG_H */
