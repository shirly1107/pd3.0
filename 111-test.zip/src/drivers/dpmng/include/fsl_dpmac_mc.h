/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPMAC_MC_H
#define __FSL_DPMAC_MC_H

#include "fsl_types.h"
#include "fsl_enet.h"
#include "fsl_eiop_port.h"
#include "fsl_eiop_memac.h"
#include "fsl_dpmng_mc.h"
#include "fsl_linkman.h"
#include "fsl_event_pipe.h"
#include "fsl_serdes.h"
#include "eiop_port.h"

struct dpmac;

#define DPMAC_MAX_IRQ_NUM	1

/**
 * @brief	structure representing DPMAC link type
 */
enum dpmac_link_type {
	DPMAC_LINK_TYPE_NONE,
	DPMAC_LINK_TYPE_FIXED,
	DPMAC_LINK_TYPE_PHY,
	DPMAC_LINK_TYPE_BACKPLANE,
	DPMAC_LINK_TYPE_RECYCLE
};

enum dpmac_eth_if {
	DPMAC_ETH_IF_MII,	/**< MII interface */
	DPMAC_ETH_IF_RMII,	/**< RMII interface */
	DPMAC_ETH_IF_SMII,	/**< SMII interface */
	DPMAC_ETH_IF_GMII,	/**< GMII interface */
	DPMAC_ETH_IF_RGMII,	/**< RGMII interface */
	DPMAC_ETH_IF_SGMII,	/**< SGMII interface */
	DPMAC_ETH_IF_QSGMII,	/**< QSGMII interface */
	DPMAC_ETH_IF_XAUI,	/**< XAUI interface */
	DPMAC_ETH_IF_XFI,	/**< XFI interface */
	DPMAC_ETH_IF_CAUI,	/**< CAUI interface */
	DPMAC_ETH_IF_1000BASEX, /**< 1000Base_X interface */
	DPMAC_ETH_IF_USXGMII	/**< USXGMII interface */
};

struct dpmac_cfg {
	int mac_id;
};

/**
 * @brief	Inter-Frame Gap mode
 *
 * LAN/WAN uses different Inter-Frame Gap mode
 */
enum dpmac_ifg_mode {
	DPMAC_IFG_MODE_FIXED,
	/*!< IFG length represents number of octets in steps of 4 */
	DPMAC_IFG_MODE_STRECHED
	/*!< IFG length represents the stretch factor */
};


/**
 * @brief Structure representing Inter-Frame Gap mode configuration
 */
struct dpmac_ifg_cfg {
	enum dpmac_ifg_mode ipg_mode; /*!< WAN/LAN mode */
	uint8_t ipg_length; /*!< IPG Length, default value is 0xC */
};

#define DPMAC_SET_PARAMS_IFG 0x1

/* union of all dpmac attributes versions */
union dpmac_attr {
	struct attr_v3{
		int id;
		enum dpmac_link_type link_type;
		/* link type */
		enum dpmac_eth_if eth_if;
		/* Ethernet interface */
		uint32_t max_rate;
		/* Maximum supported rate - in Mbps */
		enum dpmac_fec_mode fec_mode;
		/* FEC mode */
		struct serdes_eq_settings serdes_cfg;
		/* SerDes equalization settings */
		struct dpmac_ifg_cfg ifg_cfg;
		/* ipg settings */
	} v3;
	struct attr_v2{
		int id;
		enum dpmac_link_type link_type;
		/* link type */
		enum dpmac_eth_if eth_if;
		/* Ethernet interface */
		uint32_t max_rate;
		/* Maximum supported rate - in Mbps */
		enum dpmac_fec_mode fec_mode;
		/* FEC mode */
		struct serdes_eq_settings serdes_cfg;
		/* SerDes equalization settings */
	} v2;
	struct attr_v1{
		int id;
		enum dpmac_link_type link_type;
		/* link type */
		enum dpmac_eth_if eth_if;
		/* Ethernet interface */
		uint32_t max_rate;
		/* Maximum supported rate - in Mbps */
	} v1;
	struct attr_v0{
		int id;
		enum dpmac_link_type link_type;
		/* link type */
		enum dpmac_eth_if eth_if;
		/* Ethernet interface */
		uint32_t max_rate;
		/* Maximum supported rate - in Mbps */
		int phy_id;
		struct {
			uint16_t major;
			uint16_t minor;
		} version;
	} v0;
};

int dpmac_create(struct dpmac *dpmac, const struct dpmac_cfg *cfg);

int dpmac_open(struct dpmac *dpmac, int dpmac_id);

int dpmac_close(struct dpmac *dpmac);

void dpmac_destroy(struct dpmac *dpmac);

int dpmac_is_enabled(struct dpmac *dpmac, int *en);

int dpmac_get_attributes(struct dpmac *dpmac, union dpmac_attr *attr);

int dpmac_get_serdes_eq_setup(struct dpmac *dpmac, union dpmac_attr *attr);

#define DPMAC_IRQ_INDEX				0
#define DPMAC_IRQ_EVENT_LINK_CFG_REQ		0x00000001
#define DPMAC_IRQ_EVENT_LINK_CHANGED		0x00000002
#define DPMAC_IRQ_EVENT_LINK_UP_REQ		0x00000004
#define DPMAC_IRQ_EVENT_LINK_DOWN_REQ		0x00000008
#define DPMAC_IRQ_EVENT_ENDPOINT_CHANGED	0x00000010

/*!< irq event - Indicates that the link state changed */
/* @} */

int dpmac_set_irq(struct dpmac *dpmac,
		  uint8_t irq_index,
		  const struct mc_irq_cfg *irq_cfg);

int dpmac_get_irq(struct dpmac *dpmac,
        	 uint8_t irq_index,
        	 struct mc_irq_cfg *irq_cfg);

int dpmac_set_irq_enable(struct dpmac *dpmac, uint8_t irq_index, uint8_t en);

int dpmac_get_irq_enable(struct dpmac *dpmac, uint8_t irq_index, uint8_t *en);

int dpmac_set_irq_mask(struct dpmac *dpmac, uint8_t irq_index, uint32_t mask);

int dpmac_get_irq_mask(struct dpmac *dpmac, uint8_t irq_index, uint32_t *mask);

int dpmac_get_irq_status(struct dpmac *dpmac,
			 uint8_t irq_index,
			 uint32_t *status);

int dpmac_clear_irq_status(struct dpmac *dpmac,
			   uint8_t irq_index,
			   uint32_t status);

int dpmac_get_port_mac_addr(struct dpmac *dpmac, uint8_t addr[6]);

struct dpmac_mdio_cfg {
	uint8_t		cl45;
	uint8_t		phy_addr;
	uint16_t	reg;
	uint16_t	data;
};

int dpmac_mdio_read(struct dpmac *dpmac, struct dpmac_mdio_cfg *cfg);

int dpmac_mdio_write(struct dpmac *dpmac, struct dpmac_mdio_cfg *cfg);

#define DPMAC_LINK_OPT_AUTONEG		0x0000000000000001ULL
#define DPMAC_LINK_OPT_HALF_DUPLEX	0x0000000000000002ULL
#define DPMAC_LINK_OPT_PAUSE		0x0000000000000004ULL
#define DPMAC_LINK_OPT_ASYM_PAUSE	0x0000000000000008ULL
#define DPMAC_LINK_OPT_PFC_PAUSE	0x0000000000000010ULL

#define DPMAC_ADVERTISED_10BASET_FULL		0x0000000000000001ULL
#define DPMAC_ADVERTISED_100BASET_FULL		0x0000000000000002ULL
#define DPMAC_ADVERTISED_1000BASET_FULL		0x0000000000000004ULL
#define DPMAC_ADVERTISED_AUTONEG			0x0000000000000008ULL
#define DPMAC_ADVERTISED_10000BASET_FULL	0x0000000000000010ULL
#define DPMAC_ADVERTISED_2500BASEX_FULL		0x0000000000000020ULL
#define DPMAC_ADVERTISED_5000BASET_FULL		0x0000000000000040ULL

#define DPMAC_ADVERTISED_MASK				0x3f

struct dpmac_link_cfg {
	uint64_t options;
	uint32_t rate;
	uint64_t advertising;
};

int dpmac_get_link_cfg(struct dpmac *dpmac, struct dpmac_link_cfg *cfg);

struct dpmac_link_state {
	uint32_t rate;
	uint64_t options;
	uint64_t supported;
	uint64_t advertising;
	int up;
	int state_valid;
};

int dpmac_set_link_state(struct dpmac *dpmac, struct dpmac_link_state *link_state);

void dpmac_dump(struct dpmac *dpmac);

/**
 * @brief	Configure PHY and test mdio read/write. Assumes SGMII riser card in slot 4.
 *
 * @param[in]	dpmac		Pointer to DPMAC object
 * @param[in]	phy_loop	0-no loop ; 1-loop
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_config_sgmii(struct dpmac *dpmac, int phy_loop);

/* MC internal functions */

/*!
 * @name Resource request options
 */
#define DPMAC_PTP_OPT_CHECKSUM_CORRECTION	0x00000001
/*!< UDP checksum needs correction */

/**
 * @brief	Structure representing DPMAC Precision Time Protocol
 * 		configuration
 */
struct dpmac_ptp_cfg {
	int enable;
	/*!< Enable PTP single-step */
	uint8_t offset;
	/*!< offset from the beginning of a frame */
	int options;
	/*!< UDP Checksum correction */
	uint32_t peer_delay;
	/*!< Peer delay */
};

#ifdef PFC_SUPPORT
/**
 * @brief	Inter-Frame Gap mode
 *		LAN/WAN uses different Inter-Frame Gap mode
 *
 */
enum dpmac_flow_ctrl_mode {
	DPMAC_FLOW_CTRL_802_3X,
	/*!< Legacy pause frames */
	DPMAC_FLOW_CTRL_802_1QBB
	/*!< Priority-based flow control (PFC) */
};


/**
 * @brief	Priority Flow Control Quanta parameters
 *
 */
struct dpmac_pfc_quanta {
	uint16_t pause_time;
	/*!<Pause quanta value used with transmitted pause frames.
	 * Each quanta represents a 512 bit-times.
	 * Note that '0' as an input here will be used as disabling the
	 * transmission of the pause-frames. */
	uint16_t thresh_time;
	/*!<Pause Threshold quanta value used by the MAC to retransmit pause
	 * frame. if the situation causing a  pause frame to be sent didn't
	 * finish when the timer reached the threshold quanta, the MAC will
	 * retransmit the pause frame. Each quanta represents a 512 bit-times.
	 */
};


/**
 * @brief Priority Flow Control request parameters
 *
 */
struct dpmac_pfc_request_cfg {
	enum dpmac_flow_ctrl_mode dpmac_flow_ctrl_mode; /**< Linked object type */
	union {
		struct {
			uint16_t pause_time;
			/*!<Pause quanta value used with transmitted pause
			 * frames. Each quanta represents a 512 bit-times.
			 * Note that '0' as an input here will be used as
			 * disabling the transmission of the pause-frames. */
		} standard_802_3x;
		struct {
			uint8_t				bit_map;
			struct dpmac_pfc_quanta 	dpmac_pfc_quanta[8];
		} standard_802_1QBB;
	} u;
};
#endif /* PFC SUPPORT */

/**
 * @brief	Structure representing DPMAC counters
 */
struct dpmac_counters {
	/* RMON */
	uint64_t pkts_64;
	/*!< r-10G tr-DT 64 byte frame counter */
	uint64_t pkts_65_to_127;
	/*!< r-10G 65 to 127 byte frame counter */
	uint64_t pkts_128_to_255;
	/*!< r-10G 128 to 255 byte frame counter */
	uint64_t pkts_256_to_511;
	/*!< r-10G 256 to 511 byte frame counter */
	uint64_t pkts_512_to_1023;
	/*!< r-10G 512 to 1023 byte frame counter */
	uint64_t pkts_1024_to_1518;
	/*!< r-10G 1024 to 1518 byte frame counter */
	uint64_t pkts_1519_to_1522;
	/*!< r-10G 1519 to 1522 byte good frame count */

	/* */
	uint64_t fragments;
	/*!< Total number of packets that were less than 64 octets long with
	 * a wrong CRC. */
	uint64_t jabbers;
	/*!< Total number of packets longer than valid maximum length octets */
	uint64_t drop_events;
	/*!< number of dropped packets due to internal errors of the MAC
	 * Client (during receive). */
	uint64_t crc_align_errors;
	/*!< Incremented when frames of correct length but with CRC error
	 * are received.*/
	uint64_t undersize_pkts;
	/**< Incremented for frames under 64 bytes with a valid FCS and
	 * otherwise well formed; This count does not include range
	 * length errors */
	uint64_t oversize_pkts;
	/*!< Incremented for frames which exceed 1518 (non VLAN) or 1522 (VLAN)
	 * and contains a valid FCS and otherwise well formed */

	/* Pause */
	uint64_t tx_pause;
	/*!< Pause MAC Control received */
	uint64_t rx_pause;
	/*!< Pause MAC Control sent */

	/* MIB II */
	uint64_t if_in_octets;
	/*!< Total number of byte received. */
	uint64_t if_in_pkts;
	/*!< Total number of packets received.*/
	uint64_t if_in_ucast_pkts;
	/*!< Total number of unicast frame received */
	uint64_t if_in_mcast_pkts;
	/*!< Total number of multicast frame received*/
	uint64_t if_in_bcast_pkts;
	/*!< Total number of broadcast frame received */
	uint64_t if_in_discards;
	/*!< Frames received, but discarded due to problems within
	 * the MAC RX. */
	uint64_t if_in_errors;
	/*!< Number of frames received with error:
	 * 		- FIFO Overflow Error
	 * 		- CRC Error
	 * 		- Frame Too Long Error
	 * 		- Alignment Error
	 * 		- The dedicated Error Code (0xfe, not a code error)
	 * 		  was received */
	uint64_t if_out_octets;
	/*!< Total number of byte sent. */
	uint64_t if_out_pkts;
	/*!< Total number of packets sent .*/
	uint64_t if_out_ucast_pkts;
	/*!< Total number of unicast frame sent; */
	uint64_t if_out_mcast_pkts;
	/*!< Total number of multicast frame sent */
	uint64_t if_out_bcast_pkts;
	/*!< Total number of multicast frame sent */
	uint64_t if_out_discards;
	/*!< Frames received, but discarded due to problems within the MAC TX
	 * N/A!.*/
	uint64_t if_out_errors;
	/*!< Number of frames transmitted with error:
	 * 		- FIFO Overflow Error
	 * 		- FIFO Underflow Error
	 * 		- Other */
};


enum dpmac_counter {
	DPMAC_CNT_ING_FRAME_64,
	DPMAC_CNT_ING_FRAME_127,
	DPMAC_CNT_ING_FRAME_255,
	DPMAC_CNT_ING_FRAME_511,
	DPMAC_CNT_ING_FRAME_1023,
	DPMAC_CNT_ING_FRAME_1518,
	DPMAC_CNT_ING_FRAME_1519_MAX,
	DPMAC_CNT_ING_FRAG,
	DPMAC_CNT_ING_JABBER,
	DPMAC_CNT_ING_FRAME_DISCARD,
	DPMAC_CNT_ING_ALIGN_ERR,
	DPMAC_CNT_EGR_UNDERSIZED,
	DPMAC_CNT_ING_OVERSIZED,
	DPMAC_CNT_ING_VALID_PAUSE_FRAME,
	DPMAC_CNT_EGR_VALID_PAUSE_FRAME,
	DPMAC_CNT_ING_BYTE,
	DPMAC_CNT_ING_MCAST_FRAME,
	DPMAC_CNT_ING_BCAST_FRAME,
	DPMAC_CNT_ING_ALL_FRAME,
	DPMAC_CNT_ING_UCAST_FRAME,
	DPMAC_CNT_ING_ERR_FRAME,
	DPMAC_CNT_EGR_BYTE,
	DPMAC_CNT_EGR_MCAST_FRAME,
	DPMAC_CNT_EGR_BCAST_FRAME,
	DPMAC_CNT_EGR_UCAST_FRAME,
	DPMAC_CNT_EGR_ERR_FRAME,
	DPMAC_CNT_ING_GOOD_FRAME,
	DPMAC_CNT_EGR_GOOD_FRAME
};

/**
 * @brief	Functions obtains specific counter of particular interface
 *
 * @param[in]	dpmac		dpmac handle
 *
 * @param[in]	if_id		Interface Identifier
 *
 * @param[in]	type		counter type
 *
 * @param[out]	counter	return value
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmac_if_get_counter(struct dpmac *dpmac,
			uint16_t if_id,
	enum dpmac_counter type,
	uint64_t *counter);

/**
 * @brief	Functions sets specific counter of particular interface
 *
 * @param[in]	dpmac		dpmac handle
 *
 * @param[in]	if_id		Interface Identifier
 *
 * @param[in]	type		counter type
 *
 * @param[in]	counter		new counter value
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmac_if_set_counter(struct dpmac *dpmac,
			uint16_t if_id,
	enum dpmac_counter type,
	uint64_t counter);

/**
 * @brief	Counters
 *
 */
struct dpmac_counters_cfg {
	uint64_t	ing_frame;	/*! Ingress frame count */
	uint64_t	ing_byte;	/*! Ingress byte count */
	uint64_t	ing_fltr_frame;	/*! Ingress filtered frame count */
	uint64_t	ing_frame_discard;/*! Ingress frame discard count */
	uint64_t	ing_mcast_frame;/*! Ingress multicast frame count */
	uint64_t	ing_mcast_byte;	/*! Ingress multicast byte count */
	uint64_t	ing_bcast_frame;/*! Ingress broadcast frame count */
	uint64_t	ing_bcast_bytes;/*! Ingress broad bytes count */
	uint64_t	egr_frame;	/*! Egress frame count */
	uint64_t	egr_byte;	/*! Egress byte count */
	uint64_t	egr_frame_discard;/*! Egress frame discard counter */
};

/**
 * @brief	Functions gets specific counter of particular interface
 *
 * @param[in]	dpmac		dpmac handle
 *
 * @param[in]	if_id		Interface Identifier
 *
 * @param[out]	counters	counter values
 *
 * @returns      Completion status. '0' on Success; Error code otherwise.
 */
int dpmac_if_get_counters(struct dpmac *dpmac, uint16_t  if_id,
	struct dpmac_counters_cfg  *counters);


/**
 * @brief   	DPMAC allocate
 *
 * @returns	pointer to DPMAC object
 */
struct dpmac *dpmac_allocate(void);


/**
 * @brief   	DPMAC enable
 *
 * @param[in]	dpmac	DPMAC object handle
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_enable(struct dpmac *dpmac);


/**
 * @brief   	DPMAC disable
 *
 * @param[in]	dpmac	DPMAC object handle
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_disable(struct dpmac *dpmac);


/**
 * @brief   	Get dpmac rate
 *
 * @param[in]	dpmac	DPMAC object handle
 * @param[out]	rate	rate value
 *
 * @returns	'0' on Success; Error code otherwise.
 */

int dpmac_get_rate(struct dpmac *dpmac, uint32_t *rate);


/**
 * @brief   	Set maximum frame length value
 *
 * @param[in]	dpmac	DPMAC object handle
 * @param[in]	length	maximum length value
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_set_max_frame_length(struct dpmac *dpmac, uint16_t length);


/**
 * @brief   	Get maximum frame length value
 *
 * @param[in]	dpmac	DPMAC object handle
 * @param[out]	length	maximum length value
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_get_max_frame_length(struct dpmac *dpmac, uint16_t *length);


/**
 * @brief   	Disable/Enable promiscuous mode
 *
 * @param[in]	dpmac	DPMAC object handle
 * @param[in]	enable	'1' for enabling, '0' for disabling
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_set_promiscuous(struct dpmac *dpmac, int enable);


/**
 * @brief   	Check if promiscuous mode is enabled
 *
 * @param[in]	dpmac	DPMAC object handle
 * @param[out]	status	'1' for enabled, '0' for disabled
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_get_promiscuous(struct dpmac *dpmac, int *status);


/**
 * @brief   	Disable/Enable 1588 single-step mode
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[in]	dpmac_ptp_cfg	PTP configuration parameters
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_set_ptp(struct dpmac *dpmac, struct dpmac_ptp_cfg *dpmac_ptp_cfg);


/**
 * @brief   	Get status of 1588 single-step mode
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[out]	dpmac_ptp_cfg	PTP configuration parameters
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_get_ptp(struct dpmac *dpmac, struct dpmac_ptp_cfg *dpmac_ptp_cfg);

#ifdef FUTURE_SUPPORT
/**
 * @brief   	Add MAC-Address to a specific MAC
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[in]	addr		address to add
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_add_mac_addr(struct dpmac *dpmac,
                       uint8_t *addr);


/**
 * @brief   	Remove MAC-Address from a specific MAC
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[in]	addr		address to remove
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_remove_mac_addr(struct dpmac *dpmac,
                          const uint8_t *addr);
#endif /* FUTURE_SUPPORT */

/**
 * @brief   	Enable/Disable ignore of RX Pause-Frames
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[in]   enable		'1' for enabling, using pause frames
 * 				'0' for disabling, ignoring pause frames
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_set_pfc_indication(struct dpmac *dpmac, int enable);

#ifdef PFC_SUPPORT
/**
 * @brief   	Enable/Disable ignore of RX Pause-Frames
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[out]  status		'1' for enabled, pause frames in use
 * 				'0' for disabled, pause frames are ignored
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_get_pfc_indication(struct dpmac *dpmac, int *status);


/**
 * @brief   	Set Priority flow control and TX pause frames
 *
 * @param[in]	dpmac	DPMAC object handle
 * @param[out]  cfg	Structure with PFC parameters:
 *	 	 	- For 802.3x: Pause time
 *	 	 	- For 802.1QBB: pause_time and threshold time for each
 *	 	 	  priority;
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_set_pfc_request(struct dpmac *dpmac,
                          struct dpmac_pfc_request_cfg *cfg);

/**
 * @brief   	Get Priority flow control and TX pause frames status
 *
 * @param[in]	dpmac	DPMAC object handle
 * @param[out]  cfg	Structure with PFC parameters to be filled:
 * 	 	 	- For 802.3x: Pause time
 *	 	 	- For 802.1QBB: pause_time and threshold time for each
 *	 	 	  priority;
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_get_pfc_request(struct dpmac *dpmac,
                          struct dpmac_pfc_request_cfg *cfg);
#endif /* PFC_SUPPORT */

/**
 * @brief   	Set Inter-Frame Gap value and mode
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[out]  dpmac_ifg_cfg	Inter-Frame Gap parameters:
 * 							WAM/LAN mode
 * 							Length
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_set_ifg_mode(struct dpmac *dpmac,
                       struct dpmac_ifg_cfg *cfg);

/**
 * @brief   	Get Inter-Frame Gap value and mode
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[out]  dpmac_ifg_cfg	Inter-Frame Gap parameters:
 * 							WAM/LAN mode
 * 							Length
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_get_ifg_mode(struct dpmac *dpmac,
                       struct dpmac_ifg_cfg *cfg);


/**
 * @brief   	Enable/Disable MAC loop back
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[in]  	enable		"1" for enabling, '0' for disabling
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_set_loopback (struct dpmac *dpmac, int enable);


/**
 * @brief   	Check rather MAC loopback is enabled
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[out]  enabled		"1" for enabled, '0' for disabled
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_get_loopback (struct dpmac *dpmac, int *status);


#ifdef WOL_SUPPORT
/**
 * @brief   	Magic Packet detection enable.
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[in]	enable		"1" for enabling, '0' for disabling
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_set_wol(struct dpmac *dpmac, int enable);


/**
 * @brief   	Check if Magic Packet detection is enabled.
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[in]	status		"1" for enabled, '0' for disabled
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_get_wol(struct dpmac *dpmac, int *status);
#endif /* WOL_SUPPORT */


/* TODO - Add support for physical port counters */
/**
 * @brief   	Get MAC counters
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[out]	dpmac_stats	Structure for saving all MAC counters
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_get_statistics(struct dpmac *dpmac,
                         struct dpmac_counters *dpmac_counters);

/* TODO - Add support for physical port counters */
/**
 * @brief   	Get MAC counter
 *
 * @param[in]	dpmac		DPMAC object handle
 * @param[out]	dpmac_counter	MAC requested counter
 *
 * @returns	counter value on Success; Error code otherwise.
 */
int dpmac_get_counter(struct dpmac *dpmac, enum dpmac_counter type, uint64_t *counter);

/**
 * @brief   	Reset MAC counters
 *
 * @param[in]	dpmac		DPMAC object handle
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_reset_counters(struct dpmac *dpmac);

/**
 * @brief	Reset the DPMAC, returns the object to initial state.
 *
 * @param[in]	dpmac - Pointer to dpmac object
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_reset(struct dpmac *dpmac);
/**
 * @brief	Restore the DPMAC, returns the object to runtime state after WRIOP reset.
 *
 * @param[in]	dpmac - Pointer to dpmac object
 * 				mac_id - MAC id.
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_hw_init(struct dpmac *dpmac, int mac_id);

/**
 * @brief	DPMAC interrupt handler
 *
 * @param[in]	mac_id - MAC id on which the interrupt occured.
 */
void dpmac_interrupt_handler(int mac_id);

/**
 * @brief	Allocates memory for DPMAC object
 *
 * @return 	dpmac - Allocated DPMAC object
 */
struct dpmac *dpmac_allocate(void);

/**
 * @brief	Free DPMAC object memory
 *
 * @param[in]	dpmac - DPMAC object to be freed
 */
void dpmac_deallocate(struct dpmac *dpmac);

/**
 * @brief	Preliminary initialization for dpmac
 *
 * @param[in]	dpmac - pointer to DPMAC object
 * @param[in]	mac_id - the MAC id to be initialized

 * @returns	'0' on Success; Error code otherwise.
 */
int dpmac_init(struct dpmac *dpmac, int mac_id);

int dpmac_event_cb(void *dpmac,
                   const struct linkman_control   *control,
                   struct linkman_endpoint        *self,
                   const struct linkman_endpoint  *peer,
                   struct linkman_action          *action);

int dpmac_event_complete_cb(void *dpmac,      
                            const struct linkman_control   *control,
                            struct linkman_endpoint        *self,
                            const struct linkman_endpoint  *peer,
                            struct linkman_action          *action);


/**
 * @brief	Check internal physical link
 *
 * @param[in]   handle - handler to DPMAC
 *
 * @returns	'0' for valid link, Error code otherwise.
 */
int dpmac_check_internal_physical_link(struct dpmac *dpmac);

int dpmac_set_dev_ctx(struct dpmac *dpmac,
		      const struct dpmng_dev_ctx *dev_ctx);

/* set BP or CG to TC association for flow control.  This is required both
 * for regular pause frames and for PFC. */
int dpmac_set_port_cgp(struct dpmac *dpmac, struct eiop_cgp *cgp, int cmd);

/* Set pause quanta and threshold to default values */
void dpmac_set_tx_pause_frames(struct dpmac *dpmac, int enable);
/* Enable receiving of Flow Control frames */
void dpmac_set_rx_ignore_pause_frame(struct dpmac *dpmac, int enable);
/* Return physical port id*/
int dpmac_get_ppid(struct dpmac *dpmac);

/* Return the type of SerDes associated with the MAC */
int dpmac_is_10g_mac(struct dpmac *dpmac);
int dpmac_is_25g_mac(struct dpmac *dpmac);
int dpmac_is_50g_mac(struct dpmac *dpmac);
int dpmac_is_100g_mac(struct dpmac *dpmac);
/* dpmac getters and setters */
struct dpmac *dpmac_get_handle(struct dpmac *dpmac);
int dpmac_get_id(struct dpmac *dpmac);
enum dpmac_link_type dpmac_get_link_type(struct dpmac *dpmac);
void dpmac_set_link_type(enum dpmac_link_type link_type, struct dpmac *dpmac);
void dpmac_set_linkup_from_phy(int linkup_from_phy, struct dpmac *dpmac);
int dpmac_get_eiop_id(struct dpmac *dpmac);
struct dpni *dpmac_get_dpni(struct dpmac *dpmac);
char *get_link_type_name(enum dpmac_link_type type);

int dpmac_check_empty(struct dpmac *dpmac, int tries, uint32_t tmp);

#endif /* __FSL_DPMAC_MC_H_ */
