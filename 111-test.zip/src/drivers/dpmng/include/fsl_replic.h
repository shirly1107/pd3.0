/*
 * Copyright 2013-2020 NXP
 */

#ifndef _FSL_REPLIC_H
#define _FSL_REPLIC_H

#include "fsl_types.h"

struct replic_cfg {
	int            		num_elements;
	struct device  		*dprc;      	/*! Resource manager */
};

struct replic_element_info {
    int         qdid;
    uint64_t    flc;
    uint16_t    icid;
    int         next_rrid;
    int         fqid;		/*! Return FQID */
};

struct replic *replic_create(struct replic_cfg *cfg);

void replic_destroy(struct replic *replic);

int replic_add_element(struct replic *replic,
        		int element_id,
                        struct replic_element_info *element_info);

int replic_remove_element(struct replic *replic,
			int element_id);

void replic_remove_all(struct replic *replic);

int replic_get_element_inuse_count(struct replic *replic);

int replic_get_element_rrid(struct replic *replic,
	int element_id, int *rrid);

int replic_query_element_rrid(int rrid, struct replic_element_info *rr);

int replic_config_element_rrid(int rrid, struct replic_element_info *rr);

int replic_get_element_head(struct replic *replic, int *head_id);

int replic_is_empty(struct replic *replic);

int replic_get_element(struct replic *replic, int rrid, int *element);

int replic_set_element_opaque(struct replic *replic, 
                              int element_id, 
                              uint64_t opaque);

int replic_get_element_opaque(struct replic *replic, 
                              int element_id, 
                              uint64_t *opaque);

#endif /* _FSL_REPLIC_H */

