/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_EIOP_PORT_H
#define __FSL_EIOP_PORT_H

#include "fsl_eiop.h"
#include "fsl_types.h"

/**************************************************************************//**
 @Description   enum for defining EIOP Exceptions
*//***************************************************************************/

enum eiop_port_counter_type {
       E_INGRESS_FLEC, /**< Frame Length Error Counter*/
       E_INGRESS_BDC, /**< Buffers Deallocate Counter*/
       E_INGRESS_FQDC, /**< Frames QMan Discard Counter*/
       E_INGRESS_ODC, /**< Out of Buffers Discard Counter*/
       E_INGRESS_PEC, /**< Prepare to Enqueue Counter*/
       E_INGRESS_BLKC, /**< Buffer Leak Counter*/
       E_INGRESS_RDC, /**< Recycle Discard Counter*/
       E_INGRESS_ETFC, /**< Enqueue Total Frame Counter*/

       E_EGRESS_FLEC, /**< Frame Length Error Counter*/
       E_EGRESS_FUFDC, /**< Frames Unsupported Format Discard Counter*/
       E_EGRESS_DSBEC, /**< Discard System Bus Error Counter*/
       E_EGRESS_BDC, /**< Buffers Deallocate Counter*/
       E_EGRESS_PEC, /**< Prepare to Enqueue Counter*/
       E_EGRESS_ETFC, /**< Enqueue Total Frame Counter*/
       E_EGRESS_DTFC, /*Dequeue Total Frame Counter */
       E_EGRESS_RRFC /* Recycle Read Failure Counter*/
};

enum eiop_port_ethernet_rate {
	EIOP_PORT_RATE_1_G = 0, 	/**< 1G */
	EIOP_PORT_RATE_2_5_G, 	/**< 2.5G */
	EIOP_PORT_RATE_5_G, 		/**< 5G */
	EIOP_PORT_RATE_10_G, 	/**< 10G */
	EIOP_PORT_RATE_20_G, 	/**< 20G */
	EIOP_PORT_RATE_25_G, 	/**< 25G */
	EIOP_PORT_RATE_40_G, 	/**< 40G */
	EIOP_PORT_RATE_50_G, 	/**< 50G */
	EIOP_PORT_RATE_100_G, 	/**< 100G */
};

enum eiop_clk {
	EIOP_CLK_500MHZ = 0, 	/**< 500MHz */
	EIOP_CLK_600MHZ, 		/**< 600MHz */
	EIOP_CLK_700MHZ, 		/**< 700MHz */
	EIOP_CLK_800MHZ, 		/**< 800MHz */
};

enum eiop_port_type {
	EIOP_ETHERNET_PORT = 0, 	/**< Ethernet port */
	EIOP_RECYCLE_PORT, 		/**< Recycle port */
	EIOP_MANAGEMENT_COMMAND_PORT	/** <Management command port*/
};

/**************************************************************************//**
 @Description   A structure defining EIOP Port SoC descriptor
*//***************************************************************************/
struct eiop_port_desc {
	int port_id;
	int eiop_id;
	enum eiop_port_type type;
	enum eiop_port_ethernet_rate rate; /* Relevant for recycle port only */
	phys_addr_t paddr;
	void *vaddr;
};

/* DO NOT CHANGE ORDER OF FIELDS!!! */
struct pport_connections_desc {
	int eiop_id;
	int dcp_id;
	int ceetm_id;
	int lni_id;
	int mac_id;
	int port_id;
};

/* DO NOT CHANGE ORDER OF FIELDS!!! */
struct vport_connections_desc {
	int eiop_id;
	int dcp_id;
	int ceetm_id;
	int lni_id;
	int port_id;
};


/**************************************************************************//**
 @Description   A structure which MUST be initialized by user and be passed
                for eiop_port_init function
*//***************************************************************************/

struct eiop_port_init_params{
	enum eiop_port_type type;		/*type of eiop port*/
	enum eiop_port_ethernet_rate rate;	/*rate of eiop port
						if type of the port
						Ethernet*/
	uint16_t default_ingress_ifpid;		/*initial IFPID for
						ingress direction*/
};
/**************************************************************************//**
 @Function      eiop_port_defconfig

 @Description   Initialize data structure parameter with default values
 		which can be modified by user after calling this function.

                No actual initialization or configuration of WRIOP
                hardware is done by this routine.

 @Param[in]     cfg_params   - Pointer to data structure of parameters

 @Retval        NONE
*//***************************************************************************/
//void eiop_port_defconfig(struct eiop_port_cfg_params *cfg_params);
/**************************************************************************//**
 @Function      eiop_port_init

 @Description   Configuring the EIOP PORT module hardware registers.

 @Param[in]     regs - 			Pointer to the area of specific
 					EIOP PORT register location
		cfg_params -  		Pointer to data structure of
					parameters which was passed to
					eiop_config and optionally was
                              		modified by user.

		init_params - 		Pointer to data structure of
					parameters which MUST be initialized
					by user.

 @Return        int
*//***************************************************************************/
int eiop_port_init(const struct eiop_port_desc *desc,
			struct eiop_port_init_params *init_params,
			int reset);

/**************************************************************************//**
 @Function      eiop_port_enable

 @Description   A runtime routine provided to enable of EIOP Port.

 @Param[in]     regs - 			Pointer to the area of specific
 					EIOP register location

 @Return        int
*//***************************************************************************/
int eiop_port_enable(const struct eiop_port_desc *desc);
/**************************************************************************//**
 @Function      eiop_port_set_mapping_pfc_class_to_qman_traffic_class

 @Description   A runtime routine provided for mapping flow control received
 		in PFC frame to the corresponding Traffic Class in QMAN
 		which should be paused.


 @Param[in]     regs - 			Pointer to the area of specific
 					EIOP register location

 		pfc_class -		flow control in PFC frame

		qman_traffic_class - 	traffic class in QMAN
 @Return        int
*//***************************************************************************/

int eiop_port_set_mapping_pfc_class_to_qman_traffic_class(const struct eiop_port_desc *desc,
							uint8_t pfc_class,
						uint8_t qman_traffic_class);

int eiop_port_set_map_pfc_cls_to_qman_traffic_cls(const struct eiop_port_desc *desc,
						  uint8_t pfc_class,
						uint8_t qman_traffic_class);

int eiop_port_set_default_ingress_ifpid(const struct eiop_port_desc *desc, int default_ingress_ifpid);
void eiop_port_rx_enable(const struct eiop_port_desc *desc);
void eiop_port_tx_enable(const struct eiop_port_desc *desc);
int eiop_port_rx_graceful_stop(const struct eiop_port_desc *desc);
int eiop_port_tx_graceful_stop(const struct eiop_port_desc *desc);
int eiop_port_tx_set_flush(const struct eiop_port_desc *desc);
void eiop_port_tx_get_dsp(const struct eiop_port_desc *desc, int *sp);
uint32_t eiop_get_counter(const struct eiop_port_desc *desc,
                                                enum eiop_port_counter_type type);
void eiop_port_dump_regs(const struct eiop_port_desc *desc);
#if 0
int eiop_ingress_flow_graceful_stop(const struct eiop_port_desc *port_desc,const struct eiop_memac_desc *memac_desc);
int eiop_egress_flow_graceful_stop(const struct eiop_port_desc *port_desc,const struct eiop_memac_desc *memac_desc);
#endif

/* sets an entry in the WRIOP congestion mapping table so that flow control can
 * be sent out during congestion.
 */
void eiop_port_set_cgp(const struct eiop_port_desc *desc,
		struct eiop_cgp *cgp, int cmd);

int eiop_port_get_ppid(struct eiop_port_desc *desc);

#ifdef ERR009038
uint32_t eiop_port_set_qmi_nia(const struct eiop_port_desc *desc, uint32_t val);
#endif /* ERR009038 */

#endif /* __FSL_EIOP_PORT_H */
