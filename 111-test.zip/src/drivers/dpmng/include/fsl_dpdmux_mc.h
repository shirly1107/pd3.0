/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPDMUX_H
#define __FSL_DPDMUX_H

#include "fsl_net.h"
#include "fsl_linkman.h"		/*! dpdmux_linkman_cb */
#include "fsl_dpmng_mc.h"		/*  */
#include "fsl_dpkg.h"

/*!< Forward declaration */
struct dpdmux;

#define DPDMUX_MAX_IRQ_NUM 		2
#define DPDMUX_IRQ_INDEX_IF		0x0000
#define DPDMUX_IRQ_INDEX		0x0001
#define DPDMUX_IRQ_EVENT_LINK_CHANGED	0x0001
#define DPDMUX_IRQ_EVENT_ENDPOINT_CHANGED	0x0002

#define DPDMUX_MAX_NUM_DMAT_ENTRIES	64
#define DPDMUX_MAX_DMAT_MC_GROUPS      32
#define DPDMUX_MAX_NUM_CONTROL_ENTRIES	64
#define DPDMUX_MAX_FRAME_LENGTH		1536
#define DPDMUX_MAX_VLAN_IDS             16

#define DPDMUX_MAX_TC		4	/* Maximum number of TC */
#define DPDMUX_MAX_PRI		8	/* Maximum number of priorities */

#define DPDMUX_MAX_IF		64

#define DPDMUX_DEFAULT_RATE 1000

#define DPDMUX_OPT_BRIDGE_EN	0x0000000000000002
#define DPDMUX_OPT_MULTICAST_DIS 0x0000000000000004
#define DPDMUX_OPT_CTRL		0x0000000000000010
/* Mask support for classification - use TCAM instead of exact match */
#define DPDMUX_OPT_CLS_MASK_SUPPORT		0x0000000000000020
/* Max frame length will be changed automatically by connected dpni's*/
#define DPDMUX_OPT_AUTO_MAX_FRAME_LEN	0x0000000000000040ULL

enum dpdmux_owner {
	DPDMUX_OWNER_MANAGEMENT = 0x1,
	DPDMUX_OWNER_NIC = 0x2,
	DPDMUX_OWNER_INTERNAL = 0x3,
	DPDMUX_OWNER_NONE = 0x4
};

enum dpdmux_manip {
	DPDMUX_MANIP_NONE = 0x0,
	DPDMUX_MANIP_ADD_REMOVE_S_VLAN = 0x1
};

enum dpdmux_method {
	DPDMUX_METHOD_NONE = 0x0,
	DPDMUX_METHOD_C_VLAN_MAC = 0x1,
	DPDMUX_METHOD_MAC = 0x2,
	DPDMUX_METHOD_C_VLAN = 0x3,
	DPDMUX_METHOD_S_VLAN = 0x4,
	DPDMUX_METHOD_CUSTOM = 0x5,
#ifdef IP_SUPPORT
	DPDMUX_METHOD_IPV4 = 0x5,
	DPDMUX_METHOD_IPV6 = 0x6
#endif /* IP_SUPPORT */
}	;

struct dpdmux_cfg {
	enum dpdmux_method method;
	enum dpdmux_manip manip;
	uint16_t num_ifs;
	uint16_t default_if;
	struct {
		uint64_t options;
		uint16_t max_dmat_entries;
		uint16_t max_mc_groups;
		uint16_t max_vlan_ids;
		uint16_t mem_size;
#if 0
	uint16_t dmux_control_num_entries;
	uint16_t max_frame_length;
#endif
	} adv;
};

struct dpdmux_l2_rule {
	uint8_t mac_addr[6];
	uint16_t vlan_id;
};

struct dpdmux_transmit_rate {
	uint32_t rate;
};

#define DPDMUX_LINK_OPT_AUTONEG		0x0000000000000001ULL
#define DPDMUX_LINK_OPT_HALF_DUPLEX	0x0000000000000002ULL
#define DPDMUX_LINK_OPT_PAUSE		0x0000000000000004ULL
#define DPDMUX_LINK_OPT_ASYM_PAUSE	0x0000000000000008ULL

struct dpdmux_link_cfg {
	uint32_t rate;
	uint64_t options;
	uint64_t advertising;
};

int dpdmux_if_set_link_cfg(struct dpdmux *dpdmux, uint16_t if_id,
	struct dpdmux_link_cfg *cfg);

struct dpdmux_link_state {
	uint32_t rate;
	uint64_t options;
    int		 up;
    int		 state_valid;
   	uint64_t supported;
   	uint64_t advertising;
};

int dpdmux_if_get_link_state(struct dpdmux *dpdmux, uint16_t if_id,
	struct dpdmux_link_state *state);

int dpdmux_open(struct dpdmux *dpdmux, int dpdmux_id);

int dpdmux_close(struct dpdmux *dpdmux);

int dpdmux_create(struct dpdmux *dpdmux, const struct dpdmux_cfg *cfg);

void dpdmux_destroy(struct dpdmux *dpdmux);

struct dpdmux_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
	uint64_t options;
	enum dpdmux_method method;
	enum dpdmux_manip manip;
	uint16_t num_ifs;
	uint16_t mem_size;
	uint16_t default_if;
	uint16_t max_dmat_entries;
	uint16_t max_mc_groups;
	uint16_t max_vlan_ids;
};

int dpdmux_get_attributes(struct dpdmux *dpdmux, struct dpdmux_attr *attr);

int dpdmux_enable(struct dpdmux *dpdmux);

int dpdmux_disable(struct dpdmux *dpdmux);

int dpdmux_reset(struct dpdmux *dpdmux);

#define DPDMUX_SKIP_DEFAULT_INTERFACE               0x01
#define DPDMUX_SKIP_UNICAST_RULES                   0x02
#define DPDMUX_SKIP_MULTICAST_RULES                 0x04

int dpdmux_set_resetable(struct dpdmux *dpdmux, uint8_t skip_reset_flags);

int dpdmux_get_resetable(struct dpdmux *dpdmux, uint8_t *skip_reset_flags);

struct dpdmux_rate_cfg {
	int delta_bandwidth[DPDMUX_MAX_IF];
};

int dpdmux_set_scheduling(struct dpdmux *dpdmux,
	const struct dpdmux_rate_cfg *cfg);

/**
 * Update the maximum frame length on all dmux interfaces.
 */
int dpdmux_set_max_frame_length(struct dpdmux *dpdmux,
	const uint16_t max_frame_length);

int dpdmux_get_max_frame_length(struct dpdmux *dpdmux, uint16_t if_id,
		uint16_t *max_frame_length);

int dpdmux_set_default_if(struct dpdmux *dpdmux, uint16_t if_id, int set);

int dpdmux_get_default_if(struct dpdmux *dpdmux, uint16_t *if_id);

enum dpdmux_counter_type {
	DPDMUX_CNT_ING_FRAME = 0x0,
	DPDMUX_CNT_ING_BYTE = 0x1,
	DPDMUX_CNT_ING_FLTR_FRAME = 0x2,
	DPDMUX_CNT_ING_FRAME_DISCARD = 0x3,
	DPDMUX_CNT_ING_MCAST_FRAME = 0x4,
	DPDMUX_CNT_ING_MCAST_BYTE = 0x5,
	DPDMUX_CNT_ING_BCAST_FRAME = 0x6,
	DPDMUX_CNT_ING_BCAST_BYTES = 0x7,
	DPDMUX_CNT_EGR_FRAME = 0x8,
	DPDMUX_CNT_EGR_BYTE = 0x9,
	DPDMUX_CNT_EGR_FRAME_DISCARD = 0xa,
	DPDMUX_CNT_ING_NO_BUFFER_DISCARD = 0xb,
	DPDMUX_MAX_CNT = 0xc
};

int dpdmux_ul_reset_counters(struct dpdmux *dpdmux);

int dpdmux_if_get_counter(struct dpdmux *dpdmux,
			  uint16_t if_id,
			  enum dpdmux_counter_type counter_type,
			  uint64_t *counter);

int dpdmux_if_enable(struct dpdmux *dpdmux, uint16_t if_id);
int dpdmux_if_disable(struct dpdmux *dpdmux, uint16_t if_id);

int dpdmux_if_get_transmit_rate(struct dpdmux *dpdmux,
	uint16_t if_id,
	struct dpdmux_transmit_rate *cfg);

struct dpdmux_tci_val {
	uint8_t pcp;
	uint8_t dei;
	uint16_t vlan_id;
};

int dpdmux_if_set_tci(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_tci_val *cfg);

enum dpdmux_accepted_frames_type {
	DPDMUX_ADMIT_ALL = 0,
	DPDMUX_ADMIT_ONLY_VLAN_TAGGED = 1,
	DPDMUX_ADMIT_ONLY_UNTAGGED = 2
};

enum dpdmux_unaccepted_frames_action {
	DPDMUX_ACTION_DROP = 0,
	DPDMUX_ACTION_REDIRECT_TO_CTRL = 1
};

struct dpdmux_accepted_frames {
	enum dpdmux_accepted_frames_type type;
	enum dpdmux_unaccepted_frames_action unaccept_act;
};

int dpdmux_if_set_accepted_frames(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_accepted_frames *cfg);

struct dpdmux_if_attr {
	struct dpdmux_tci_val tci;
	int rate;
	enum dpdmux_accepted_frames_type accept_frame_type;
	int is_default;
	int enabled;
};

int dpdmux_if_get_attributes(struct dpdmux *dpdmux,
	uint16_t if_id,
	struct dpdmux_if_attr *attr);

int dpdmux_if_set_transmit_rate(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_transmit_rate *cfg);

int dpdmux_if_add_l2_rule(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_l2_rule *l2_rule,
	enum dpdmux_owner owner);

int dpdmux_if_remove_l2_rule(struct dpdmux *dpdmux,
	uint16_t if_id,
	const struct dpdmux_l2_rule *l2_rule,
	enum dpdmux_owner owner);

int dpdmux_set_irq(struct dpdmux *dpdmux,
		   uint8_t irq_index,
		   const struct mc_irq_cfg *irq_cfg);

int dpdmux_get_irq(struct dpdmux *dpdmux,
        	 uint8_t irq_index,
        	 struct mc_irq_cfg *irq_cfg);

int dpdmux_set_irq_enable(struct dpdmux *dpdmux,
			  uint8_t irq_index,
			  uint8_t en);

int dpdmux_get_irq_enable(struct dpdmux *dpdmux,
			  uint8_t irq_index,
			  uint8_t *en);

int dpdmux_set_irq_mask(struct dpdmux *dpdmux,
			uint8_t irq_index,
			uint32_t mask);

int dpdmux_get_irq_mask(struct dpdmux *dpdmux,
			uint8_t irq_index,
			uint32_t *mask);

int dpdmux_get_irq_status(struct dpdmux *dpdmux,
			  uint8_t irq_index,
			  uint32_t *status);

int dpdmux_clear_irq_status(struct dpdmux *dpdmux,
			    uint8_t irq_index,
			    uint32_t status);

/* MC internal functions */

/**************************************************************************//**
 @Function	dpdmux_allocate

 @Description	Allocates DMux object

 @Return	allocated memory for the object.
 *//***************************************************************************/
struct dpdmux *dpdmux_allocate(void);

/**************************************************************************//**
 @Function	dpdmux_deallocate

 @Description	de-Allocates DMux object

 @Return	void.
 *//***************************************************************************/
void dpdmux_deallocate(struct dpdmux *dpdmux);

/**************************************************************************//**
 @Function      dpdmux_init

 @Description   init DMux

 @Param[in]     dpdmux - DMux handler
 @Param[in]     cfg - register configuration
 @Param[in]     info - object information

 @returns	'0' on Success; Error code otherwise.
 *//***************************************************************************/
int dpdmux_init(struct dpdmux *dpdmux,
		const struct dpdmux_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg);

/**************************************************************************//**
 @Function      dpdmux_if_set_unicast_promisc

 @Description   set promiscuous port in DMux

 * @Param[in]     dpdmux - DMux handler
 * @Param[in]   if_id - source interface Id
 * @Param[in]   vlan_id - vlan value
 * @Param[in]   en - enable or disable this interface from unicast promisc.

 @returns	'0' on Success; Error code otherwise.
 *//***************************************************************************/
int dpdmux_if_set_unicast_promisc(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t vlan_id,
	int en);

/**************************************************************************//**
 @Function      dpdmux_if_set_multicast_promisc

 @Description   set promiscuous port in DMux

 * @Param[in]     dpdmux - DMux handler
 * @Param[in]   if_id - source interface Id
 * @Param[in]   vlan_id - vlan value
 * @Param[in]   en - enable or disable this interface from multicast promisc.

 @returns	'0' on Success; Error code otherwise.
 *//***************************************************************************/
int dpdmux_if_set_multicast_promisc(struct dpdmux *dpdmux,
	uint16_t if_id,
	uint16_t vlan_id,
	int en);

int dpdmux_event_cb(void *dpdmux,        			/* L2 Switch handle */
        	const struct linkman_control   *control,/* Control Information*/
        	struct linkman_endpoint        *self,  	/* endpoint 1 info */
        	const struct linkman_endpoint  *peer, 	/* endpoint 2 info */
        	struct linkman_action          *action);/* required action */

int dpdmux_event_complete_cb(void *dpdmux,        		/* L2 Switch handle */
        	const struct linkman_control   *control,/* Control Information*/
        	struct linkman_endpoint        *self,  	/* endpoint 1 info */
        	const struct linkman_endpoint  *peer, 	/* endpoint 2 info */
        	struct linkman_action          *action);/* required action */

int dpdmux_set_dev_ctx(struct dpdmux *dpdmux, const struct dpmng_dev_ctx *dev_ctx);

/**
 * @brief	Traffic classes scheduling
 *
 */
enum dpdmux_schedule_mode {
        DPDMUX_SCHED_STRICT_PRIORITY,     /* Strict priority */
        DPDMUX_SCHED_WEIGHTED,            /* Enhance transmission selection */
 };

struct dpdmux_tx_sched_cfg {
       enum dpdmux_schedule_mode mode;	/* Strict or ETS */
       uint16_t  delta_bandwidth;   	/* weighted Bandwidth */
};

struct dpdmux_tx_selection_cfg {
	/* TC mapping */
        uint8_t tc_id[DPDMUX_MAX_PRI];     	

        /* Traffic classes configuration */
        struct dpdmux_tx_sched_cfg  tc_sched[DPDMUX_MAX_TC];
};

int dpdmux_if_set_tx_selection(struct dpdmux *dpdmux, uint16_t if_id,
	const struct dpdmux_tx_selection_cfg *ts);

/**
 * @brief	Early drop
 *
 */
enum dpdmux_early_drop_unit {
        DPDMUX_EARLY_DROP_UNIT_BYTES,
        DPDMUX_EARLY_DROP_UNIT_PACKETS,
        DPDMUX_EARLY_DROP_UNIT_BUFFERS,        
};

enum dpdmux_early_drop_mode {
        DPDMUX_EARLY_DROP_MODE_NONE,
        DPDMUX_EARLY_DROP_MODE_TAIL,
        DPDMUX_EARLY_DROP_MODE_WRED
};

struct dpdmux_wred_cfg {
        uint64_t                min_threshold;            /* Minimum threshold */
        uint64_t                max_threshold;            /* Maximum threshold */
        /* Maximum probability 0-100% */
        uint8_t                 drop_probability;
};

struct dpdmux_early_drop_cfg {
        enum dpdmux_early_drop_mode     drop_mode; 	/* Drop mode */
	enum dpdmux_early_drop_unit	units;	/* Count mode */
        /* WRED parameters */
        struct dpdmux_wred_cfg          yellow; 	/* yellow */
        struct dpdmux_wred_cfg       	green;     	/* green */
        /* Tail drop parameters */
        uint32_t                	tail_drop_threshold;   /* Tail drop threshold*/
};

int dpdmux_if_tc_set_early_drop(struct dpdmux *dpdmux,
                        uint16_t if_id,
                        uint8_t ccgidx,
                        const struct dpdmux_early_drop_cfg *drop_cfg);

#define DPDMUX_CUSTOM_KEY_SIZE 24

int dpdmux_set_custom_key(struct dpdmux *dpdmux,
		struct dpkg_profile_cfg *extract_cfg);

struct dpdmux_rule_cfg {
	uint8_t *key;
	uint8_t *mask;
	uint8_t size;
};


struct dpdmux_rule_cfg_tmp {
	uint64_t key_iova; /*!< IO virtual address to the key */
	uint64_t mask_iova;/*!< IO virtual address to the mask */
	uint8_t key_size; /*!< key/mask size */
	uint16_t entry_index; /*!< rule priority */
};

#define DPDMUX_FS_OPT_DISCARD		0x1

struct dpdmux_cls_action {
	uint16_t dest_if;
	uint16_t options;
};

int dpdmux_add_custom_cls_entry(struct dpdmux *dpdmux,
		struct dpdmux_rule_cfg *rule, uint16_t index,
		struct dpdmux_cls_action *action);

int dpdmux_remove_custom_cls_entry(struct dpdmux *dpdmux,
		struct dpdmux_rule_cfg *rule);

struct dpdmux_taildrop_cfg {
	uint8_t		enable;
	enum dpdmux_early_drop_unit units;
	uint32_t	threshold;
};

int dpdmux_if_set_taildrop(struct dpdmux *dpdmux, uint16_t if_id,
		struct dpdmux_taildrop_cfg *cfg);

int dpdmux_if_get_taildrop(struct dpdmux *dpdmux, uint16_t if_id,
		struct dpdmux_taildrop_cfg *cfg);


int dpdmux_get_ap_ppid(struct dpdmux *dpdmux, int if_id,
		int *ppid);

int dpdmux_clean_flow_control_config(struct dpdmux *dpdmux,
		int if_id);

enum dpdmux_table_type {
	DPDMUX_DMAT_TABLE = 1,
	DPDMUX_MISS_TABLE = 2,
	DPDMUX_PRUNE_TABLE = 3,
};

int dpdmux_dump_table(struct device *dev, uint16_t table_type, uint16_t table_index, uint64_t iova_addr, int iova_size, uint16_t *table_size);

enum dpdmux_error_action {
	DPDMUX_ERROR_ACTION_DISCARD = 0,
	DPDMUX_ERROR_ACTION_CONTINUE = 1,
};

struct dpdmux_error_cfg {
	uint32_t errors;
	enum dpdmux_error_action error_action;
};

int dpdmux_set_errors_behavior(struct dpdmux *dpdmux, uint16_t if_id, struct dpdmux_error_cfg *cfg);

int dpdmux_if_update_max_frame_len(struct dpdmux *dpdmux, uint16_t if_id, uint16_t max_frame_len);

int dpdmux_get_mac_rate(struct dpdmux *dpdmux, uint32_t *rate);
int dpdmux_get_id(struct dpdmux *dpdmux, uint16_t *id);
int dpdmux_get_num_ifs(struct dpdmux *dpdmux, uint16_t *num_ifs);

#endif /* _FSL_DPDMUX_MC_H */

