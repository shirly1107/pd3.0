/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_EIOP_IFP_H
#define __FSL_EIOP_IFP_H

#include "fsl_gen.h"
#include "fsl_net.h"


struct eiop_ifp_desc {
	int ifp_id;
	int eiop_id;
	phys_addr_t paddr;
	void *vaddr;
};

#define IFP_MAX_NUM_OF_EXT_POOLS 	8
#define IFP_MAX_FRAME_LENGTH		(10*KILOBYTE)

/**************************************************************************//**
 @Description   definition for IFP errors
 *//***************************************************************************/



#define EIOP_IFP_ERR_KS  		0x00040000
/*dpkg profile_id or extraction size error*/
#define EIOP_IFP_ERR_EOF 		0x00020000
/*dpkg extract out of frame error*/
#define EIOP_IFP_ERR_MNL 		0x00010000
/*dptbl maximum number of chaned lookups reached error */
#define EIOP_IFP_ERR_TID 		0x00008000
/* invalid tid error */
#define EIOP_IFP_ERR_PIE		0x00004000
/*policer initialization entry point error*/
#define EIOP_IFP_ERR_FL			0x00002000
/*frame length error*/
#define EIOP_IFP_ERR_FP			0x00001000
/*frame physical error*/
#define EIOP_IFP_ERR_PARSER_CL	0x00000080
/*parser cycle limit error*/
#define EIOP_IFP_ERR_PARSER_ISF	0x00000040
/*parser invalid softparse instruction*/
#define EIOP_IFP_ERR_PARSER_HDR	0x00000020
/*parser header error*/
#define EIOP_IFP_ERR_PARSER_BL	0x00000010
/*parser block limit error*/
#define EIOP_IFP_ERR_PARSER_L3C	0x00000004
/*parser L3 checksum error*/
#define EIOP_IFP_ERR_PARSER_L4C	0x00000001
/*parser L4 checksum error*/


/*NOTE: should be system define*/
#define NOT_VALID   0xffffffff

/**************************************************************************//**
 @Description   Enum for defining behaviour for errors
 *//***************************************************************************/

enum eiop_ifp_err_action {
	EIOP_IFP_ERR_DROP = 0, /**< drop frame */
	EIOP_IFP_ERR_ENQ = 1,
	EIOP_IFP_ERR_ENQ_TO_ERR_Q = 2,
/**< enqueue frame */
};

/**************************************************************************//**
 @Description   Enum for defining type of counter
 *//***************************************************************************/

enum counter_type {
	E_INGRESS_FC, /**< Rx frame count*/
	E_INGRESS_BC, /**< Rx byte counter */
	E_INGRESS_FFC, /**< Rx filtered frame counter */
	E_INGRESS_FDC, /**< Rx frame discard counter */
	E_INGRESS_MFC, /**< Rx multicast frame counter */
	E_INGRESS_MBC, /**< Rx multicast byte counter */
	E_INGRESS_BFC, /**< Rx broadcast frame counter */
	E_INGRESS_BBC, /**< Rx broadcast byte counter */
	E_EGRESS_FC, /**< Tx frame counter */
	E_EGRESS_BC, /**< Tx byte counter */
	E_EGRESS_FDC, /**< Tx frame discard counter */
	E_EGRESS_MFC, /**< Tx multicast frame counter */
	E_EGRESS_MBC, /**< Tx multicast byte counter */
	E_EGRESS_BFC, /**< Tx broadcast frame counter */
	E_EGRESS_BBC, /**< Tx broadcast byte counter */
	E_EGRESS_STDC, /**< Tx spanning tree discard counter */
	E_INGRESS_OODC, /**< Rx out of buffers discard counter */
	E_EGRESS_CFC, /**< Tx confirmation counter */

};

/**************************************************************************//**
 @Description   A structure for defining behavior of the system
 in the case of error frame
 *//***************************************************************************/
#define EIOP_IFP_ERR_CFG_OPT_SET_FD_STATUS 		0x80000000
#define EIOP_IFP_ERR_CFG_OPT_SET_FD_ERR			0x40000000

struct eiop_ifp_err_cfg {
	enum eiop_ifp_err_action 	action;/**< the behaviour for errored frames*/
	uint32_t options;
	/**< relevant if action is EIOP_IFP_ERR_ENQ or EIOP_IFP_ERR_ENQ_TO_ERR_Q*/
};

/**************************************************************************//**
 @Description   A structure for defining frame annotation area.
 *//***************************************************************************/
/*NOTES : instead of pass_eggr_ad and pass_ingr_ad
 I will interprate it in the driver - what should be taken from FAEAD/FAIAD
 and what register to update*/

struct buf_layout {
	int pass_fas; /**<Rx/TxConf - Output
	 WRIOP should update in frame annotation status
	 status and timestamp
	 Tx - Input
	 WRIOP should read status and in the case of
	 error in status to take the required action */
	int pass_ts; /**<Rx/TxConf - Output.*/
	int pass_ing_ad; /**<Rx - Output
	 AD is updated in in FA.
	 Tx - WRIOP is reading FAEAD located in FA
	 and behaves according to directives written
	 here*/
	int pass_egr_ad; /**<Rx - Output
	 AD is updated in in FA.
	 Tx - WRIOP is reading FAEAD located in FA
	 and behaves according to directives written
	 here*/

	int pass_pr; /**<Rx - Output
	 WRIOP should update PR in FA*/

	int pass_sw_opaque;	/*Rx - Output,
				Tx - in Recycle path it will be copied*/
	uint16_t priv_data_size; /**<Rx only:
	 Number of bytes to be left at the end
	 of the FA area added to previously
	 defined parameters.
	 Relevant for settings dataOffset*/
	// default 64
	uint16_t data_align; /**<Rx only:
	 value for selecting a data alignment
	 (must be a power of 2)
	 will be influence on FD.Offset*/
	uint16_t data_headroom; /*Rx - Output -
		 Relevant for settings dataOffset*/
	uint16_t data_tailroom;  /*Rx - Output -
		 adding space to the end of the data*/
	uint8_t no_sg;
};

/**************************************************************************//**
 @Description   A structure of information about each of the external
 buffer pools used by IFP.
 *//***************************************************************************/

//LDPA
#define EIOP_IFP_BUF_POOL_OPT_SCARCE_RESOURCE		0x80000000
#define EIOP_IFP_BUF_POOL_OPT_BMT					0x40000000

struct ldpa_buf_pool_cfg {
	int id; /**< External buffer pool id */
	int size; /**< External buffer pool buffer size */
	uint32_t	options;
	uint8_t		priority_mask;
};
/**************************************************************************//**
 @Description   A structure for informing the driver about the external
 buffer pools allocated in the BM and used by IFP
 *//***************************************************************************/
/**************************************************************************//**
 @Description   A structure for defining ifp parameters which updated by
 driver by default values and can be modified by user after
 calling eiop_ifp_defconfig before eiop_ifp_init
 Configured in the function of config :

 *//***************************************************************************/
enum eiop_ifp_rx_vlan_action
{
	EIOP_IFP_RX_VLAN_ACTION_NONE,
	EIOP_IFP_RX_VLAN_ACTION_INSERT,
	EIOP_IFP_RX_VLAN_ACTION_COND_INSERT,
};

struct eiop_ifp_rx_vlan_cfg {
	enum eiop_ifp_rx_vlan_action action;
	uint16_t cond_insert_ethype_not_found;
	uint32_t insert_vlan_hdr;
};

enum eiop_ifp_tx_vlan_action
{
	EIOP_IFP_TX_VLAN_ACTION_NONE,
	EIOP_IFP_TX_VLAN_ACTION_REMOVE,
	EIOP_IFP_TX_VLAN_ACTION_UPDATE_QOS,
	EIOP_IFP_TX_VLAN_ACTION_INSERT
	/**VLAN header is taken from appropriate register
	 * but VPRI/DEI are updated according to egress CTLU QoS mapping
	 */

};
struct eiop_ifp_tx_vlan_cfg {
	enum eiop_ifp_tx_vlan_action action;
	uint32_t insert_vlan_hdr;
	/** VLAN HDR doesn't consist PRI, DEI.
	 *VPRI/DEI are updated according to egress CTLU QoS mapping  */
};

#define EIOP_IFP_DEFCFG_OPT_SET_PRIVIL_LEVEL		0x80000000
#define EIOP_IFP_DEFCFG_OPT_SET_VIRT_ADDR			0x40000000
#define EIOP_IFP_DEFCFG_OPT_SET_BYPASS_DATA_ISOLATION	0x20000000
#define EIOP_IFP_DEFCFG_OPT_SET_WRITE_OPTIMIZE		0x10000000
#define EIOP_IFP_DEFCFG_OPT_SET_BUFFER_POOL_ON_QDBIN 0x08000000
#define EIOP_IFP_DEFCFG_OPT_SET_HEADER_STASHING		0x04000000
#define EIOP_IFP_DEFCFG_OPT_SET_PAYLOAD_STASHING	0x02000000


struct eiop_ifp_defcfg {
	uint16_t mng_cmd_ring_size; /**< The number of command descriptors in the ring
	 Default: 4 */

	uint16_t num_of_backup_pools_used;/**<Number of backup pools
	 use by specific IFP.
	 Can not be greater than
	 IFP_MAX_NUM_OF_EXT_POOLS */
	struct ldpa_buf_pool_cfg
	backup_pool_cfg[IFP_MAX_NUM_OF_EXT_POOLS];
	/**< Parameters for each pool */


	int no_rx_priv_data_size; /*!< set if rx_buf_layout.priv_data_size is
	 to be "0" (otherwize "0" indicates
	 driver's default) */
	struct buf_layout rx_buf_layout; /**<defining the frame
	 annotation area
	 and fields which should be
	 updated by WRIOP in Rx
	 process */
	struct buf_layout tx_buf_layout; /**<defining the frame
	 annotation area and fields
	 which should be ridden
	 by WRIOP*/
	struct buf_layout txconf_buf_layout; /**<defining the frame
	 annotation area and fields
	 which should be updated by
	 WRIOP in Tx confirmation */
	uint32_t	options;
	uint16_t 	icid;

};

/**************************************************************************//**
 @Description   A structure which MUST be initialized by user and be passed
 for ifp_init function
 *//***************************************************************************/
#define EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_PASSTHRU	0x10000000
#define EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_FOR_AIOP  	0x08000000
#define EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_REPLIC_ID 	0x04000000
#define EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_OPAQUE		0x02000000
#define EIOP_IFP_DEFAULT_CFG_OPT_SET_STASHING_CNTRL 	0x01000000
#define EIOP_IFP_DEFAULT_CFG_OPT_SET_IPRE 		0x00800000
struct eiop_ifp_default_cfg {
	uint32_t options;
	/**< Allowed combination :
	 * ((EIOP_IFP_INIT_PARAMS_DFLT_OPTIONS_SET_FLC_FOR_AIOP |
	 * EIOP_IFP_INIT_PARAMS_DFLT_OPTIONS_SET_FLC_OPAQUE)) ||
	 *  (EIOP_IFP_INIT_PARAMS_DFLT_OPTIONS_SET_FLC_OPAQUE) ||
	 *  (EIOP_IFP_INIT_PARAMS_OPTIONS_SET_FLC_REPLIC_ID)
	 * Forbidden combination :
	 * (EIOP_IFP_INIT_PARAMS_DFLT_OPTIONS_SET_FLC_FOR_AIOP |
	 * EIOP_IFP_INIT_PARAMS_OPTIONS_SET_FLC_REPLIC_ID) &&
	 * ( EIOP_IFP_INIT_PARAMS_OPTIONS_SET_FLC_REPLIC_ID |
	 * EIOP_IFP_INIT_PARAMS_DFLT_OPTIONS_SET_FLC_OPAQUE)
	 * (EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_PASSTHRU |
	 * EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_FOR_AIOP) &&
	 *  (EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_PASSTHRU |
	 *   EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_REPLIC_ID) &&
	 *  (EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_PASSTHRU |
	 *   EIOP_IFP_DEFAULT_CFG_OPT_SET_FLC_OPAQUE)
	 * May be changed by PCD.*/
	int qd_id;
	/**< QDID which no-error received frames will
	 be enqueued. May be changed by PCD.*/
	int replic_list_id;
	/**< Replic_ID which will be updated in FD[FLC] in the case options
	 * with EIOP_IFP_INIT_PARAMS_OPTIONS_SET_FLC_REPLIC_ID will be set.
	 * May be changed by PCD.*/
	uint64_t opaque;
	/**<if user choose in options :
	 * EIOP_IFP_INIT_PARAMS_DFLT_OPTIONS_SET_FLC_FOR_AIOP &
	 * RX_DFLT_AFTER_CLASSIF_OPT_SET_FLC_OPAQUE
	 * only 2 LSB bytes will be chosen,
	 * otherwise 8 bytes will be chosen
	 */

};

enum eiop_ifp_cfg_err_mode {
	EIOP_IFP_CFG_OPT_ERROR_DEFAULT = 0,
	EIOP_IFP_CFG_OPT_ERROR_SKIP_CFG = 1,
	EIOP_IFP_CFG_OPT_ERROR_LIMIT_DROP = 2,
};

struct eiop_ifp_cfg {
	int rx_err_fqid; /**< error FQID where error
	 received frames
	 will be enqueued */
	int tx_err_fqid; /**< error FQID where frames
	 which were identified
	 with errors during
	 transmition will be enqueued.*/

	int num_of_pools_used;/**<Number of pools use by
	 specific IFP.
	 Can not be greater than
	 IFP_MAX_NUM_OF_EXT_POOLS */
	struct ldpa_buf_pool_cfg pools_cfg[IFP_MAX_NUM_OF_EXT_POOLS];
	/**< Parameters for each pool */

	int enqueue_ifp; /**<This IFPID is used in
	 the ingress flow following
	 the egress flow of the
	 recycle path port.*/
	int max_frame_length; /**<maximum frame length WRIOP will
	 be able to receive.
	 If frame is greater than this
	 value, frame will be dropped
	 and relevant counter is
	 updated*/

	int use_mng_cmd;
	phys_addr_t mng_cmd_ring_paddr;
	/**< Management command descriptors ring base
	 address (physical address!);
	 A pointer to an allocated external memory area
	 of size mng_cmd_ring_size * 32 bytes;
	 It will be used for Management Commands
	 Descriptors. */
	void *mng_cmd_ring_vaddr;
	/**< Management command descriptors ring base
	 address (virtual address!);
	 A pointer to an allocated external memory area
	 of size mng_cmd_ring_size * 32 bytes;
	 It will be used for Management Commands
	 Descriptors. */
	uint16_t mng_cmd_icid;
	int mng_cmd_bmt;
	int mng_cmd_va;
	int mng_cmd_pl;

/**< Icid for accessing the ring_addr. */

	struct eiop_ifp_default_cfg default_cfg;
	struct eiop_ifp_defcfg defcfg; /*!< A structure of additional IFP
	parameters.
	Clear structure to use default
	values, set non-default values if required */

	enum eiop_ifp_cfg_err_mode errors_settings;
};

/**************************************************************************//**
 @Description   A structure which MUST be initialized by user and be passed
 for IFP SetPcd
 *//***************************************************************************/

#define  EIOP_IFP_ACTIVATE_MODULE_PARSER		0x80000000
#define	 EIOP_IFP_ACTIVATE_MODULE_POLICER		0x40000000
#define	 EIOP_IFP_ACTIVATE_MODULE_LOOKUP 		0x20000000
#define	 EIOP_IFP_ACTIVATE_MODULE_HASH_GENERATION 	0x10000000
#define	 EIOP_IFP_ACTIVATE_MODULE_QoS_MAPPING	0x08000000
#define	 EIOP_IFP_ACTIVATE_MODULE_POLICY 		0x04000000

#define EIOP_IFP_PARSER_RX_OPT_L3_CHECKSUM_VALIDATE	0x02000000
#define EIOP_IFP_PARSER_RX_OPT_L4_CHECKSUM_VALIDATE	0x01000000

struct eiop_ifp_parser_cfg {
	uint32_t	rx_options;
	/**<user can build here one/many options from the following
	 * possibilities :
	 * 		EIOP_IFP_PARSER_RX_OPTIONS_L3_CHECKSUM_VALIDATE
	 *		EIOP_IFP_PARSER_RX_OPTIONS_L4_CHECKSUM_VALIDATE
	 NOTE - relevant for eiop_ifp_rx_pcd_params
	 */
	int 		profile_id;
	/**< parser_profile_id for getting parameters for PARSER job */

	uint16_t 	start_hxs;
	/**< The starting HXS for the parser. Can be a net header or a SW parser index */
	uint8_t 	start_offset;
	/**< The offset of start_hdr from the beginning of the frame */
};

struct eiop_ifp_lookup_cfg {
	int 	dpkg_profile_id;
	int 	dptbl_id;
};


struct eiop_ifp_tx_pcd_cfg {
	uint32_t 		activate_modules;
	/**<user can build here one/many options from the following
	 * possibilities :  	EIOP_IFP_ACTIVATE_OPTIONS_PARSER
	 *			EIOP_IFP_ACTIVATE_OPTIONS_LOOKUP
	 * NOTE : 	EIOP_IFP_ACTIVATE_OPTIONS_LOOKUP
	 * 		requires activation of parser
 	 * 		(activate_options | EIOP_IFP_ACTIVATE_OPTIONS_PARSER).
	 */

	struct eiop_ifp_parser_cfg 	parser;
	/**<this data structure should be initialized in the case
	 * (activate_options & (EIOP_IFP_ACTIVATE_OPTIONS_PARSER))
	 * NOTE : in eiop_ifp_tx_pcd_params useful for
	 * L2SWITCH or/and checksum generation.
	 */

	struct eiop_ifp_lookup_cfg 	default_lookup;
	/**<this data structure should be initialized in the case
	 * (activate_options & EIOP_IFP_ACTIVATE_OPTIONS_LOOKUP)
	 */

};
enum eiop_ifp_qos_map_method {
	EIOP_IFP_QoS_BASED_ON_VLAN_PRI,
	EIOP_IFP_QoS_BASED_ON_IP_DSCP,
	EIOP_IFP_QoS_BASED_ON_FCV,
};

struct eiop_ifp_policer_cfg {
	int profile_id;
};

struct eiop_ifp_policy_cfg {
	int profile_id;
};

struct eiop_ifp_hash_generation_cfg {
	int profile_id;
};

struct eiop_ifp_rx_pcd_cfg {
	uint32_t 		activate_modules;
	/**<user can build here one/many options from the following
	 * possibilities :  	EIOP_IFP_ACTIVATE_MODULES_PARSER
 	 *	 	 	EIOP_IFP_ACTIVATE_MODULES_POLICER
 	 *	 	 	EIOP_IFP_ACTIVATE_MODULES_LOOKUP
 	 *	 	 	EIOP_IFP_ACTIVATE_MODULES_HASH_GENERATION
 	 *	 	 	EIOP_IFP_ACTIVATE_MODULES_QoS_MAP_METHOD
 	 *	 	 	EIOP_IFP_ACTIVATE_MODULES_POLICY
 	 * NOTE: 	EIOP_IFP_ACTIVATE_MODULES_LOOKUP,
 	 * 		EIOP_IFP_ACTIVATE_MODULES_QoS_MAP_METHOD,
 	 * 		EIOP_IFP_ACTIVATE_MODULES_POLICY
 	 * 		EIOP_IFP_ACTIVATE_MODULES_HASH_GENERATION
 	 * 		requires activation of parser
 	 * 	(activate_options | EIOP_IFP_ACTIVATE_MODULES_PARSER).
	 */

	struct eiop_ifp_parser_cfg 	parser;
	/**<this data structure should be initialized in the case
	 * (activate_options & EIOP_IFP_ACTIVATE_OPTIONS_PARSER)
	 */
	struct eiop_ifp_policer_cfg default_policer;
	/**<this data structure should be initialized in the case
	 * (activate_options & EIOP_IFP_ACTIVATE_OPTIONS_POLICER)
	 */
	struct eiop_ifp_policy_cfg policy;
	/**<this data structure should be initialized in the case
	 * (activate_options & EIOP_IFP_ACTIVATE_OPTIONS_POLICY)
	 */
	struct eiop_ifp_hash_generation_cfg default_hash_generation;
	/**<this field should be initialized in the case
	 * (activate_options & EIOP_IFP_ACTIVATE_OPTIONS_HASH_GENERATION)
	 */
	struct eiop_ifp_lookup_cfg	default_lookup;
	/**<this data structure should be initialized in the case
	 * (activate_options & EIOP_IFP_ACTIVATE_OPTIONS_LOOKUP)
	 */
	enum 	eiop_ifp_qos_map_method	default_qos_map_method;

};

int eiop_ifp_rx_pcd_set(const struct eiop_ifp_desc *desc, struct eiop_ifp_rx_pcd_cfg *cfg);
int eiop_ifp_tx_pcd_set(const struct eiop_ifp_desc *desc, struct eiop_ifp_tx_pcd_cfg *cfg);

/**************************************************************************//**
 @Function      eiop_ifp_init

 @Description   Configuring the WRIOP IFP configuring the hardware registers.

 @Param[in]     ifp_regs - 	Pointer to the area of specific
 IFP register location
 cfg_params -  Pointer to data structure of parameters which
 was passed to ifp_config and optionally was
 modified by user.

 init_params - Pointer to data structure of parameters which
 MUST be initialized by user.

 @Return        int
 *//***************************************************************************/
int eiop_ifp_init(const struct eiop_ifp_desc *eiop_ifp_desc,
                  const struct eiop_ifp_cfg *cfg);

int eiop_ifp_init_pools(const struct eiop_ifp_desc *eiop_ifp_desc,
	const struct eiop_ifp_cfg *cfg);

int eiop_ifp_init_egress(const struct eiop_ifp_desc *eiop_ifp_desc,
	const struct eiop_ifp_cfg *cfg);

/**************************************************************************//**
 @Function      ifp_enable

 @Description   A runtime routine provided to enable of ifp.

 @Param[in]     ifp_regs - 	Pointer to the area of specific
 IFP register location

 @Return        OK on success; Error code otherwise.

 @Cautions      Allowed only following ifp_init
 *//***************************************************************************/
int eiop_ifp_rx_enable(const struct eiop_ifp_desc *desc);
void eiop_ifp_tx_enable(const struct eiop_ifp_desc *desc);

/**************************************************************************//**
 @Function      ifp_disable

 @Description   Disable an IFP. The IFP will not start new tasks after all
 tasks associated with the port are terminated.

 @Param[in]     regs - 	Pointer to the area of specific IFP register
 location

 @Return        0 on success; Error code otherwise.

 @Cautions      Allowed only following ifp_init().

 *//***************************************************************************/
int eiop_ifp_disable(const struct eiop_ifp_desc *eiop_ifp_desc);

/**************************************************************************//**
 @Function      eiop_ifp_set_max_frame_length

 @Description   Function Set relevant maximum frame length
 of the frame WRIOP will receive.

 @Param[in]     ifp_regs - 	Pointer to the area of specific IFP register
 location
 max_frame_length - new value for maximum frame length

 @Return        0 on success; Error code otherwise.

 @Cautions      Allowed only following ifp_init().

 *//***************************************************************************/
int eiop_ifp_set_max_frame_length(const struct eiop_ifp_desc *eiop_ifp_desc, int max_frame_length);
/**************************************************************************//**
 @Function      eiop_ifp_get_max_frame_length

 @Description   Function GSet  maximum frame length
 of the frame WRIOP will receive.

 @Param[in]     ifp_regs - 	Pointer to the area of specific IFP register
 location
 max_frame_length - new value for maximum frame length

 @Return        0 on success; Error code otherwise.

 @Cautions      Allowed only following ifp_init().

 *//***************************************************************************/
uint16_t eiop_ifp_get_max_frame_length(const struct eiop_ifp_desc *desc);

/**************************************************************************//**
 @Function      eiop_ifp_set_macsec_enable

 @Description   Function allows MACSEC functionality  from EIOP point.

 @Param[in]     ifp_regs - 	Pointer to the area of specific IFP register
 location
 macsec_encrypts_channel - Security channel for encryption of
 the frame by MACSEC

 @Return        0 on success; Error code otherwise.

 @Cautions      Allowed only following ifp_init().IFP should be disabled prior
 to the call to this function.

 *//***************************************************************************/
int eiop_ifp_set_macsec_enable(const struct eiop_ifp_desc *eiop_ifp_desc, int macsec_encrypts_channel);

/**************************************************************************//**
 @Function      eiop_ifp_set_macsec_disable

 @Description   Function disables MACSEC functionality  from EIOP point.

 @Param[in]     ifp_regs - 	Pointer to the area of specific IFP register
 location
 @Return        0 on success; Error code otherwise.

 @Cautions      Allowed only following ifp_init().IFP should be disabled prior
 to the call to this function.

 *//***************************************************************************/
int eiop_ifp_set_macsec_disable(const struct eiop_ifp_desc *eiop_ifp_desc);

/**************************************************************************//**
 @Function      set_err_action

 @Description   Function sets for every error appropriate directives.

 @Param[in]    ifp_regs - 	Pointer to the area of specific IFP registers
 location.

 err_info - data structure with error and appropriate directives.

 @Return        0 on success; Error code otherwise.

 @Cautions      Allowed only following ifp_init().
 Can be called after ifp_enable.
 *//**************************************************************************/
void eiop_ifp_set_err_behavior	(const struct eiop_ifp_desc *eiop_ifp_desc,
								uint32_t error,
								struct eiop_ifp_err_cfg *err_info);

void eiop_ifp_set_err_behavior_limit_drop(const struct eiop_ifp_desc *eiop_ifp_desc);

/**************************************************************************//**
 @Function      eiop_ifp_get_counter

 @Description   Function returns relevant counter.

 @Param[in]    regs - 	Pointer to the area of specific IFP registers
 location.

 type - type of counter.
 cntr - relevant counter will be returned here.

 @Return        0 on success; Error code otherwise.

 @Cautions      Allowed only following ifp_init().
 Can be called after ifp_enable.
 *//**************************************************************************/
uint64_t eiop_ifp_get_counter(const struct eiop_ifp_desc *eiop_ifp_desc, enum counter_type type);

/**************************************************************************//**
 @Function      eiop_ifp_set_counter

 @Description   Function set value for relevant counter.

 @Param[in]    regs - 	Pointer to the area of specific IFP registers
 location.

 type - type of counter.
 value - value for relevant counter.

 @Return        0 on success; Error code otherwise.

 @Cautions      Allowed only following ifp_init().
 Can be called after ifp_enable.
 *//**************************************************************************/
void eiop_ifp_set_counter(const struct eiop_ifp_desc *eiop_ifp_desc,
                         enum counter_type type,
                         volatile uint64_t value);

#if 0
IFP_MAX_NUM_OF_CONG_GRPs = 8
struct pfc_cong_grp_params
{
	uint8_t num_of_cong_grps;
	uint8_t cong_grp_id[IFP_MAX_NUM_OF_CONG_GRP];

}
IFP_MAX_NUM_OF_EXT_POOLs = 4
struct pfc_buff_poo_depl_params
{
	uint8_t num_of_pools;
	uint8_t buff_poo_id[IFP_MAX_NUM_OF_EXT_POOLS];
}
IFP_MAX_NUM_OF_PPIDs = 4
struct pfc_ppid_params
{
	uint8_t num_of_ppids;
	uint8_t ppid[IFP_MAX_NUM_OF_PPIDs];
}
#endif

/**************************************************************************//**
 @Description   Management Commands List
 This enum is used to hold the available Management Commands.
 *//***************************************************************************/

#define MNG_CMD_DESC_SIZE	32
#define MNG_CMD_RING_SIZE	4
#define	MNG_CMD_IF_SYNC		0x8000
#define	MNG_CMD_IF_EGRESS	0x4000

#define MAX_MNG_CMD_MSG		256

/**************************************************************************//**
 @Description   Structure for defining IFP management command parameters
 *//***************************************************************************/
struct eiop_ifp_cmd_if_cfg {
	struct eiop_ifp_desc *ifp_desc;	/*! IFP SoC DB descriptor */
	void *cmd_if_ring;		/*! IFP management command ring
					address */
};

/**************************************************************************//**
 @Description   Management Commands Parameters
 This structure is used to pass Management Command parameters
 *//***************************************************************************/
struct eiop_mng_cmd_cfg {
	uint32_t mng_cmd; /**< Command type */
	void *msg_vaddr;
	phys_addr_t msg_paddr;
	uint32_t mtypein;
	uint16_t status;
	uint32_t mtypeout;

	uint16_t option_flags; /* one or more of : CMD_IF_EGRESS,
	 CMD_IF_SYNC,  CMD_IF_BDI */
	uint16_t icid; /* do we need this? */
};

/**************************************************************************//**
 @Function      ifp_mng_cmd_enqueue

 @Description   This function is the interface of the different modules
 into the Management Commands. It is used to invoke the
 commands in order

 @Retval        None.
 *//***************************************************************************/
int ifp_mng_cmd_enqueue(const struct eiop_ifp_desc *eiop_ifp_desc,
                        void *cmd_if_ring,
                        struct eiop_mng_cmd_cfg *eiop_mng_cmd_cfg,
                        uint16_t *index);
/**************************************************************************//**
 @Function      ifp_mng_cmd_try_dequeue

 @Description   This function is the interface of the different modules
 into the Management Commands. It is used to invoke the
 commands in order

 @Retval        0 when command completed, 1 otherwise.
 *//***************************************************************************/
int ifp_mng_cmd_try_dequeue(const struct eiop_ifp_desc *eiop_ifp_desc,
                            void *cmd_if_ring,
                            int index,
                            struct eiop_mng_cmd_cfg *eiop_mng_cmd_cfg);

int eiop_ifp_tx_graceful_stop(const struct eiop_ifp_desc *eiop_ifp_desc);
int eiop_ifp_rx_graceful_stop(const struct eiop_ifp_desc *eiop_ifp_desc);

int eiop_ifp_set_enqueue_ifp(const struct eiop_ifp_desc *eiop_ifp_desc, int ifp_id);

int eiop_ifp_rx_is_enable(const struct eiop_ifp_desc *desc);
int eiop_ifp_rx_disable(void *ifp_regs);
int eiop_ifp_tx_is_enable(const struct eiop_ifp_desc *desc);
int eiop_ifp_rx_vlan_cfg (const struct eiop_ifp_desc *desc,
						struct   eiop_ifp_rx_vlan_cfg	*rx_vlan_cfg);
void eiop_ifp_get_rx_vlan_cfg(const struct eiop_ifp_desc *desc,
	struct eiop_ifp_rx_vlan_cfg *rx_vlan_cfg);

int eiop_ifp_tx_vlan_cfg (const struct eiop_ifp_desc *desc,
						struct   eiop_ifp_tx_vlan_cfg	*tx_vlan_cfg);
void eiop_ifp_get_data_offset(const struct buf_layout *buf_layout, uint32_t *data_offset, int rx);
int eiop_ifp_check_buffer_layout(const struct eiop_ifp_defcfg *defcfg,
	const struct buf_layout *buf_layout, int rx);
void eiop_ifp_set_l4csv(const struct eiop_ifp_desc *desc, int en);
void eiop_ifp_set_l3csv(const struct eiop_ifp_desc *desc, int en);
void eiop_ifp_rx_pcd_set_opaque_h (const struct eiop_ifp_desc *desc,
									uint32_t opaque);

void eiop_ifp_get_hw_annotation_room(const struct eiop_ifp_desc *desc,
	uint16_t *size);
int eiop_ifp_set_in_egress_read_iad(const struct eiop_ifp_desc *desc);
int eiop_ifp_clear_in_egress_read_iad(const struct eiop_ifp_desc *desc);

void eiop_ifp_dump_regs(const struct eiop_ifp_desc *desc);
void eiop_ifp_rx_pcd_set_policer_profile_id (const struct eiop_ifp_desc *desc,
						int profile_id);
int eiop_ifp_rx_pcd_set_parser_profile_id(const struct eiop_ifp_desc *desc,
                                                int profile_id);

#endif /* __FSL_EIOP_IFP_H */
