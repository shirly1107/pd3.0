/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DCE_H
#define __FSL_DCE_H

struct dce_desc {
	int disable;
	phys_addr_t paddr; /*  */
	void *vaddr; /*  */
};

#endif /*__FSL_DCE_H*/

