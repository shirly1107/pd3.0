/*
 * Copyright 2013-2020 NXP
 */

/**
 @File          dppolicer.h

* @brief   Policer Application Programming Interface.
*/
#ifndef __FSL_DPPOLICER_H
#define __FSL_DPPOLICER_H

#include "fsl_types.h"
#include "fsl_net.h"
#include "fsl_ctlu.h"

struct dppolicer;

/*!
 * @Group grp_dppolicer	Policer API
 *
 * @brief	Contains initialization APIs and runtime APIs for the Policer
 *              module
 * @{
 */

/*!
 * @Group grp_dppolicer_init	Policer initialization API
 *
 * @brief	Contains initialization APIs for the Policer module
 * @{
 */


/**
 * @brief	Policer Configuration Parameters.
 *              This structure is used to hold the Policer parameters.
 */
struct dppolicer_cfg {
	struct ctlu *ctlu;
	int num_profiles;
};
/**
*
* @brief  	This function restores the Policer module hardware registers after WRIOP reset.
*
* @param[in]    dppolicer   A handle to the Policer object
*
* @returns      A handle to the Policer object
*
 *//**************************************************************************/
int dppolicer_restore(const struct dppolicer *dppolicer);

/**
*
* @brief  	This function initializes the Policer module hardware registers.
*
* @param[in]    cfg  - Policer parameters structure
*
* @returns      0 on Success; error code otherwise.
*
 *//**************************************************************************/
struct dppolicer *dppolicer_init(const struct dppolicer_cfg *cfg);

/**
*
* @brief  	This function deleted all initializations associated
* 		with the Policer object
*
* @param[in]    dppolicer   - A handle to the dppolicer object as returned by
* 				the dppolicer_init routine
*
* @returns        None
*
 *//**************************************************************************/
void dppolicer_done(struct dppolicer *dppolicer);

/*! @} */ /* end of grp_dppolicer_init group */

/*!
 * @Group grp_dppolicer_init	Policer Runtime UnitI
 *
 * @brief	Contains runtime API for the Policer module
 * @{
 */

/*!
 * @name Policer Profile configuration options
 */
#define DPPOLICER_MAX_NUM_PRIS	8	/*<! Maximum number of drop priorities*/
/* @} */

/**
*
* @brief   Get drop priority global counter
*
* @param[in]   	dppolicer	- Policer module handle
* @param[in]   	priority	- Drop priority.
* @param[out]   val		- Number of frames that exit the Policer with
* 				  the specified drop priority
*
* @returns        0 on Success; error code otherwise.
*/
int dppolicer_get_drop_pri_counter(struct dppolicer *dppolicer,
                                   uint8_t priority,
                                 uint32_t *val);

/**
*
* @brief   Set drop priority global counter
*
* @param[in]   	dppolicer	- Policer module handle
* @param[in]   	priority	- Drop priority.
* @param[in]    val		- value to be written to counter.
* 				  0 to reset counter.
*
* @returns        0 on Success; error code otherwise.
*/
int dppolicer_set_drop_pri_counter(struct dppolicer *dppolicer,
                                 uint8_t priority,
                                 uint32_t val);

/*!
 * @name Policer Profile configuration options
 */
#define DPPOLICER_OPT_COLOR_BLIND	0x80000000
/*!< Set to select color aware mode (otherwise - color blind) */
#define DPPOLICER_OPT_KEEP_DROP_PRI 	0x40000000
/*!< Set to keep the priority if color does not change (otherwise - always
 * change according to color drop priority) */
#define DPPOLICER_OPT_DISCARD_RED	0x20000000
/*!< Set to discard frame with RED color */
/* @} */

/**
 * @brief	Enumeration type for selecting the policer profile algorithm.
 *
 */
enum dppolicer_alg {
	DPPPLICER_PASS_THROUGH, /*!< Policer pass through */
	DPPPLICER_RFC_2698, /*!< Policer algorithm RFC 2698 */
	DPPPLICER_RFC_4115
/*!< Policer algorithm RFC 4115 */
};

/**
 * @brief	Enumeration type for selecting the policer profile algorithm.
 *
 */
enum dppolicer_rate_mode {
	DPPPLICER_BYTE_RATE_MODE, /*!< Byte rate mode */
	DPPPLICER_PACKET_RATE_MODE
/*!< Packet rate mode */
};

/**
 * @brief	Enumeration type for a policer profile color.
 *
 */
enum dppolicer_color {
	DPPPLICER_GREEN,                /*!< Green color code */
	DPPPLICER_YELLOW,               /*!< Yellow color code */
	DPPPLICER_RED                   /*!< Red color code */
};

/**
 * @brief	Enumeration type for the selecting roll-back frame
 *
 */
enum dppolicer_rollback_frame_select {
	DPPPLICER_ROLLBACK_L2_FRM_LEN,    /*!< Roll-back L2 frame length */
	DPPPLICER_ROLLBACK_FULL_FRM_LEN   /*!< Roll-back Full frame length */
} ;

/**
 * @brief	Enumeration type for the policer profile packet frame
 *              length selector
 *
 */
enum dppolicer_frame_len_select {
	DPPPLICER_L2_FRM_LEN,             /*!< L2 frame length */
	DPPPLICER_L3_FRM_LEN,             /*!< L3 frame length */
	DPPPLICER_L4_FRM_LEN,             /*!< L4 frame length */
	DPPPLICER_FULL_FRM_LEN            /*!< Full frame length */
} ;


/**
 * @brief	Enumeration type for the policer profile packet frame
 *              length selector
 *
 */
struct dppolicer_byte_rate_cfg {
	enum dppolicer_frame_len_select frame_len_select; /*!< Frame length selection */
	enum dppolicer_rollback_frame_select rollback_frame_select; /*!< Frame rollback selection */
};

/**
 * @brief	Enumeration type for the policer profile non-pass-through
 * 		parameters
 *
 */
struct dppolicer_non_passthrough {
	enum dppolicer_rate_mode rate_mode; /*!< Byte mode or Packet mode */
	uint32_t committed_info_rate; /*!< KBits/Second or Packets/Second */
	uint32_t committed_burst_size; /*!< Bytes/Packets */
	uint32_t peak_or_excessive_info_rate;
	/*!< KBits/Second or Packets/Second */
	uint32_t peak_or_excessive_burst_size; /*!< Bytes/Packets */
	struct dppolicer_byte_rate_cfg byte_rate_cfg;
	/*!< Valid for Byte Rate mode only */
};

/**
 * @brief	Policer Profile Configuration Parameters
 * 		This structure is used to hold the default Policer Profile
 * 		parameters.
 *
 */
struct dppolicer_profile_cfg {
	uint32_t options; /*!< One or more of DPPOLICER_OPT_xxx options */
	enum dppolicer_alg alg; /*!< Profile Algorithm PASS_THROUGH, RFC_2698,
	RFC_4115 */
	enum dppolicer_color default_color; /*!< For pass-through mode the
	policer re-colors with this color any incoming packets. For Color aware
	non-pass-through mode: policer re-colors with this color all packets
	that do not match the other colors drop priorities. */
	struct dppolicer_non_passthrough non_passthrough_cfg; /*!< A structure
	of parameters relevant for RFC2698 or RFC4115 algorithms */
	uint8_t green_drop_pri;  /*!< Green drop priority */
	uint8_t yellow_drop_pri;  /*!< Yellow drop priority */
	uint8_t red_drop_pri;  /*!< Red drop priority */
};

/**
* @brief  	This function initializes a new Policer Profile
*
* @param[in]   	dppolicer		- Policer module handle
* @param[in]   	profile_id	- Policer profile id
* @param[in]   	cfg		- Policer parameters structure
* @param[in]   	cmd_if_cfg	- Private command interface parameters.
* 				  NULL for using common interface. Otherwise a
* 				  pointer to a structure of command interface
* 				  parameters, IO dependent. (struct
* 				  eiop_ifp_cmd_if_cfg for EIOP).
*
* @returns      "0" on success, error code otherwise
*/
int dppolicer_init_profile(struct dppolicer *dppolicer,
                           int profile_id,
                           const void *cmd_if_cfg,
                           struct dppolicer_profile_cfg *cfg);

/**
*
* @brief   Deletes an existing Policer Profile
*
* @param[in]   	dppolicer	- Policer module handle
* @param[in]   	profile_id	- Policer profile id
* @param[in]   	cmd_if_cfg	- Private command interface parameters.
* 				  NULL for using common interface. Otherwise a
* 				  pointer to a structure of command interface
* 				  parameters, IO dependent. (struct
* 				  eiop_ifp_cmd_if_cfg for EIOP).
*
* @returns        0 on Success; error code otherwise.
*/
int dppolicer_delete_profile(struct dppolicer *dppolicer,
                             int profile_id,
                             const void *cmd_if_cfg);

/**
* @brief  	This function compares all existing Policer Profiles
*               with a set of new parameters until a match is found
*
* @param[in]   	dppolicer	- Policer module handle
* @param[in]   	cmd_if_cfg	- Private command interface parameters.
* 				  NULL for using common interface. Otherwise a
* 				  pointer to a structure of command interface
* 				  parameters, IO dependent. (struct
* 				  eiop_ifp_cmd_if_cfg for EIOP).
* @param[in]   	attr		- Policer parameters structure
* @param[in]   	start_from	- normally 0, other value to start from if this
* 				  is a consequent search.
* @param[in]   	match_id	- valid if return code is "0". The id that
*                             	  matches the attributes.
*
* @returns      "0" on success, error code otherwise.
*/
int dppolicer_find_profile(struct dppolicer *dppolicer,
        const void *cmd_if_cfg,
        void *attr,
        int start_from,
        int *match_id);

/**
 * @brief	Enumeration type for Policer counters
 *
 */
enum dppolicer_profile_counter {
	DPPOLICER_CNT_RED,
	DPPOLICER_CNT_YELLOW,
	DPPOLICER_CNT_GREEN,
	DPPOLICER_CNT_RE_RED,
	DPPOLICER_CNT_RE_YELLOW,
};

/**
*
* @brief   Reads one of the Policer profile counters
*
* @param[in]   	dppolicer		- Policer module handle
* @param[in]   	profile_id	- Policer profile id
* @param[in]   	counter		- Policer counter
* @param[out]  	val		- value read from counter.
*
*
* @returns        0 on Success; error code otherwise.
*/
int dppolicer_get_profile_counter(struct dppolicer *dppolicer,
                                   int profile_id,
                                   const void *cmd_if_cfg,
                                   enum dppolicer_profile_counter counter,
                                   uint32_t *val);

struct dppolicer_counters {
	uint32_t cnt_red;
	uint32_t cnt_yellow;
	uint32_t cnt_green;
	uint32_t cnt_re_red;
	uint32_t cnt_re_yellow;
};

/**
*
* @brief   Reads all of the Policer profile counters
*
* @param[in]   	dppolicer		- Policer module handle
* @param[in]   	profile_id	- Policer profile id
* @param[out]  	val			- value read from counter.
*
*
* @returns        0 on Success; error code otherwise.
*/
int dppolicer_get_profile_counters(struct dppolicer *dppolicer,
                                   int profile_id,
                                   const void *cmd_if_cfg,
                                   struct dppolicer_counters *counters);

/**
*
* @brief   Writes one of the Policer profile counters
*
* @param[in]   	dppolicer		- Policer module handle
* @param[in]   	profile_id	- Policer profile id
* @param[in]   	counter		- Policer counter
* @param[in]   	val		- value to write to counter, 0 to clear.
*
*/
int dppolicer_set_profile_counter(struct dppolicer *dppolicer,
                                   int profile_id,
                                   const void *cmd_if_cfg,
                                   enum dppolicer_profile_counter counter,
                                   uint32_t val);


/**
*
* @brief   Clear all Policer profile counters
*
* @param[in]   	dppolicer		- Policer module handle
* @param[in]   	profile_id	- Policer profile id
*
*/
int dppolicer_reset_profile_counters(struct dppolicer *dppolicer,
                                     int profile_id,
                                     const void *cmd_if_cfg);


/** @} *//* end of DPPOLICER_runtime_grp group */
/** @} *//* end of DPPOLICER_grp group */

#endif /* _FSL_DPPOLICER_H */
