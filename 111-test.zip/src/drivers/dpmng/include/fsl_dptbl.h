/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPTBL_H
#define __FSL_DPTBL_H

#include "fsl_types.h"
#include "fsl_ctlu.h"

#define 	TBLS_MAX_SETS 7

struct dump_table_entry;

enum dptbl_mem_type {
        DPTBL_INT_MEMORY,
        DPTBL_PEB,
        DPTBL_EXT_MEMORY_1,
        DPTBL_EXT_MEMORY_2
};

/**************************************************************************//**
 @Description    TABLE

 Enumeration type defining the flow by selecting the next
 action under certain conditions

 *//***************************************************************************/
/*WRIOP_ONLY*/
/***************************************************************************/
#define DPTBL_ACTION_SET_POLICER_ID     			0x80000000
#define DPTBL_ACTION_SET_QOS_MAP_METHOD  			0x40000000
#define DPTBL_ACTION_SET_QPRI          				0x20000000
#define DPTBL_ACTION_SET_IFP_ID         			0x10000000
#define DPTBL_ACTION_SET_HASH_KID      				0x00800000
#define DPTBL_ACTION_SET_DISCARD_FLAG   			0x00400000
#define DPTBL_ACTION_CLEAR_DISCARD_FLAG  			0x00200000
#define DPTBL_ACTION_SET_QDID          				0x00080000
#define DPTBL_ACTION_SET_QDBIN         				0x00040000

#define DPTBL_ACTION_SET_FLC_FOR_AIOP  				0x08000000
#define DPTBL_ACTION_SET_REPLIC_ID 				0x04000000
#define DPTBL_ACTION_SET_OPAQUE					0x02000000

#define DPTBL_ACTION_SET_STASHING_CNTRL				0x00008000
#define DPTBL_ACTION_SET_CONTEXT_IOMMU_BYPASS 			0x00002000
//***************************************************************************/
/*AIOP_ONLY*/
/***************************************************************************/
#define DPTBL_ACTION_UPDATE_REFERNCE_PTR
#define DPTBL_ACTION_SET_OPAQUE1

//***************************************************************************/
/*AIOP + WRIOP*/
/***************************************************************************/

#define DPTBL_ACTION_ACTIVATE_STATS				0x00000008
#define DPTBL_ACTION_ACTIVATE_TIMESTAMP				0x00000004
#define DPTBL_ACTION_ACTIVATE_AGING				0x00000002

enum dptbl_next_action {
        DPTBL_ACTION_LOOKUP, DPTBL_ACTION_DONE
};

enum dptbl_qos_map_method {
	DPTBL_ACTION_QoS_BASED_ON_VLAN_PRI,
	DPTBL_ACTION_QoS_BASED_ON_IP_DSCP,
	DPTBL_ACTION_NOT_QoS_BASED,
	
};
/**< NOTE :
 *   1. next_action = DPTBL_ACTION_DISCARD
 *   	a) the rest of the parameters are irrelevant.
 *
 *   2. next_action = DPTBL_ACTION_DONE
 *
 *	CAUTION : if on the frame way one of the actions was defined
 *	with options  DPPOLICY_ACTION_SET_FLC_REPLIC_ID or
 *	DPPOLICY_ACTION_SET_FLC_FOR_AIOP set, and after that another action was defined
 *	with options DPPOLICY_ACTION_SET_FLC_OPAQUE set -
 *	the defines : DPPOLICY_ACTION_SET_FLC_REPLIC_ID or DPPOLICY_ACTION_SET_FLC_FOR_AIOP are
 *	cancelled and this action will not be executed.
 *
 *    	CAUTION : if on the frame way one of the actions was defined
 *	with next_action = DPPOLICY_ACTION_DONE it can not be redefined
 *	on the rest of the same way as DPPOLICY_ACTION_LOOKUP.
 *
 *   3. next_action = DPTBL_ACTION_LOOKUP
 *   	a) action_specific = lookup should be initialized by user.
 *   	b) allowed DPPOLICY_ACTION_OVERRIDE_REPLIC_ID || DPPOLICY_ACTION_OVERRIDE_FLC
 *   	a) Allowed flc_type: DPPOLICY_FLC_FOR_AIOP
 *   	(relevant if DPPOLICY_ACTION_OVERRIDE_FLC set)
 *
 *   4. options :
 *   	Forbidden combination/settings :
 *   		a) (DPPOLICY_ACTION_SET_QDID && DPPOLICY_ACTION_SET_QDBIN)
 *   		b) (DPPOLICY_ACTION_SET_FLC_FOR_AIOP &&
 *   			DPPOLICY_ACTION_SET_FLC_REPLIC_ID)
 *   		c) (DPPOLICY_ACTION_SET_HASH_KID && DPPOLICY_ACTION_SET_QDBIN)
 */

struct dptbl_action {
        enum dptbl_next_action next_action;
        uint32_t options;
        struct {
                int dptbl_id;
                int dpkg_profile_id;
        } lookup_params;

        /*****************************************************
         * WRIOP ONLY
         ***************************************************** */

        int dppolicer_profile_id;
        /**< relevant if
         override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_DPPLCR_ID*/
        enum dptbl_qos_map_method qos_map_method;
        /**< relevant if
         * override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_QoS_MAP -
         2 bits*/
        int qpri;
        /**< relevant if
         * override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_QoS_MAP -
         4 bits*/
        int ifp_id;
        /**< relevant if
         * override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_IFPID -
         12 bits*/
        int hash_dpkg_profile_id;
        /**< relevant if
         * override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_HASH_KID -
         1 byte*/
        int qd_id;
        /**< relevant if
         * override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_QDID -
         2 bytes*/

        int qd_bin; //only for done without replic/qdid

        int replic_id;
        /**< relevant if
         * override_mask |= DPPOLICY_ACTION_OVERRIDE_REPLIC_ID -
         2 bytes*/

        uint64_t opaque;
        int in_use;
// for lookup or (done with replic/aiop), only 2 LSBytes will be set (not expected to reach GPP end-user)
// for (done without replic/aiop), 8 bytes will be set (possibly goes to GPP end user)

// replic_id overlaps the 8 bytes opaque in the FLC, therefore setting replic_id overrides any previous large opaque.

};

/**************************************************************************//**
 @Description   Enumeration type for selecting the lookup table type
 *//***************************************************************************/
enum dptbl_type {
        DPTBL_TYPE_EXACT_MATCH = 0, /**< Exact match table */
        DPTBL_TYPE_LPM, /**< Longest prefix match table */
        DPTBL_TYPE_TCAM_ACL, /**< TCAM ACL table */
        DPTBL_TYPE_ALG_ACL
/**< Algorithmic ACL table */
};

/**************************************************************************//**
 @Description   A structure for defining a key for a single rule
 in the lookup table
 *//***************************************************************************/
struct dptbl_rule {
        union {
                struct {
						uint32_t reserved0;
                        uint32_t size;	/**< key size */
                        uint8_t *key; /**< A pointer to the key */
                } exact; /**< To be used for exact match tables */
                struct {
                        int priority;
                        /**< logical, relative to Policy; 0 is lowest;
                         This priority can not change during the
                         lifetime of a Policy. It is user
                         responsibility to space the priorities
                         according to consequent rule additions. */
                        uint32_t size; /**< key size */
                        uint8_t *key; /**< A pointer to the key */
                        uint8_t *mask; /**< A pointer to the mask */
                } masked; /**< To be used for TBD tables */
                struct {
                        uint32_t keysize; /**< key size */
                        void *key; /**< A pointer to the key */
                        uint32_t prefix_size;/**< The size of the prefix */
                } prefix; /**< To be used for longest-prefix tables */
                struct {
                        int a; /*TBD */
                } range; /**< To be used for TBD tables */
        } rule_cfg;
};

/**************************************************************************//**
 @Description   A structure of parameters for creating a new lookup table
 *//***************************************************************************/
#define DPTBL_OPTIONS_OPTIMIZIED_DISCARD		0x80000000
#define DPTBL_OPTIONS_SET_BYPASS_DATA_ISOLATION	0x40000000

struct dptbl_cfg {
        enum dptbl_type type; /**< Match table type */
        enum dptbl_mem_type mem_type; /**< TBD */
        uint32_t options;
        uint32_t max_rules; /**< Maximum number of rules for
         the lifetime of this table. */
        uint32_t aging_threshold; /**< should be power of 2
         TBD */
        uint8_t max_key_size; /**< The size of the keys that will
         occupy this table */
        struct dptbl_action *action_on_miss;/**< The result is case a "miss"
         occures in this table. */
    	uint16_t 	icid;
        
};

struct dptbl_params {
        uintptr_t addr; /*! Virtual ddress of the table */
        uint32_t num_of_entries;/*! must be a power of 2. 1 is invalid option */
};

#define DPTBL_MEM_TYPES  3

struct dptbl_mem_cfg {
        enum dptbl_mem_type mem_type; /*! PEB/DPDDR/SYS_DDR */
        phys_addr_t tbl_paddr; /*! the address of a user
        allocated peb memory space of size
        peb_mem_size (user must first call
        dptbl_get_tbl_size_by_entries() to get the required
        allocation size). */
        uint32_t  num_entries; /* total number of entries
        in PEB tables */
};

/**************************************************************************//**
 @Description   A structure for defining Policy global parameters
 *//***************************************************************************/
struct dptbl_mng_cfg {
        struct ctlu *ctlu; /* TODO */
        /* only for AIOP */
        union {
                struct {
                	phys_addr_t int_list_paddr; /*! the address of a user
                        allocated external memory space. (user must first call
                        dptbl_get_int_list_size() to get the required
                        allocation size) */
                        struct dptbl_mem_cfg mem_cfg[DPTBL_MEM_TYPES];
                } aiop_tbl_mng_cfg; /*! to be used for aiop & acl_aiop */
                int l2sw_present; /*! to be used for EIOP */
        } u;
};

struct dptbl_attr {
	uint32_t max_rules;
	uint32_t current_rules;
	int delete_process_ongoing;
};
struct dptbl_mng;

/**************************************************************************//**
 @Function      dptbl_mng_restore

 @Description  	This function restores the Tables Manager module after WRIOP reset.

 @Param[in]    	cfg   		- Tables Manager parameters structure
 	 	 	 	dptbl_mng	- A handle to the Tables Manager object.

 @Retval        Error code.
 *//**************************************************************************/
int dptbl_mng_restore(struct dptbl_mng_cfg *cfg, struct dptbl_mng *dptbl_mng);

/**************************************************************************//**
 @Function      dptbl_mng_init

 @Description  	This function initializes the Tables Manager module.

 @Param[in]    	cfg   		- Tables Manager parameters structure

 @Retval        A handle to the Tables Manager object
 *//**************************************************************************/
struct dptbl_mng *dptbl_mng_init(struct dptbl_mng_cfg *cfg);

/**************************************************************************//**
 @Function     	dptbl_mng_delete

 @Description  	This function deleted all initializations associated
 with the Tables Manager object

 @Param[in]    	dptbl_mng   - A handle to the Tables Manager object as returned by the
 dptbl_mng_alloc routine

 @Retval        Error code.
 *//**************************************************************************/
void dptbl_mng_done(struct dptbl_mng *dptbl_mng);

struct dptbl;

int dptbl_restore( struct dptbl *dptbl,
						const struct dptbl_mng *dptbl_mng,
                         struct dptbl_cfg *init_params);

struct dptbl* dptbl_init(struct dptbl_mng *dptbl_mng, struct dptbl_cfg *cfg);

void dptbl_get_id(struct dptbl* dptbl, int *tid);

int dptbl_add_rule(struct dptbl* dptbl, struct dptbl_rule *rule,
                struct dptbl_action *action,
                int restore);

#if 0
int dptbl_init (struct dptbl_mng *dptbl_mng,
                struct dptbl_init_params *init_params,
                tbl_handle tbl);
#endif
int dptbl_modify_miss_action(struct dptbl* dptbl,
                struct dptbl_action *action_on_miss);
int dptbl_delete(struct dptbl* dptbl);
int dptbl_query(struct dptbl* dptbl,
		struct dump_table_entry *entries,
		int remaining_bytes,
		uint16_t *num_entries);
int dptbl_modify_rule(struct dptbl* dptbl, struct dptbl_rule *rule,
                struct dptbl_action *new_action);
int dptbl_remove_rule(struct dptbl* dptbl, struct dptbl_rule *rule);
uint32_t dptbl_get_int_list_size(struct ctlu *ctlu);
uint32_t dptbl_get_tbl_size_by_entries(uint32_t num_of_entries);
void dptbl_get_max_key_size(struct dptbl* dptbl, uint32_t *key_size);
int dptbl_get_action(struct dptbl* dptbl, struct dptbl_rule *rule,
                struct dptbl_action *action);
int dptbl_mng_add_debug_rule(struct dptbl_mng *dptbl_mng, uint8_t *key, uint8_t *mask, int size);
int dptbl_get_rule(struct dptbl* dptbl,
                   struct dptbl_rule *rule,
                   struct dptbl_action *action);
int dptbl_get_num_of_used_rules(struct dptbl* dptbl, int *num_of_used_rules);
int dptbl_get_num_of_max_rules(struct dptbl* dptbl, int *num_of_max_rules);
int dptbl_get_tbl_type(struct dptbl* dptbl, int *tbl_type);
int dptbl_get_tbl_id(struct dptbl* dptbl, int *tbl_id);
int dptbl_get_real_key_size(struct dptbl* dptbl, int *real_key_size);
int dptbl_get_attributes(struct dptbl* dptbl,
						struct dptbl_attr *attr);

int dptbl_get_next_ruleid(struct dptbl* dptbl, uint64_t *ruleid);
int dptbl_query_with_ruleid(struct dptbl* dptbl, uint64_t *ruleid, uint8_t *key, int key_size);

#if 0
// TODO - AIOP API

/***********************************************************
 * AIOP only
 /***********************************************************/

int32_t dptbl_table_lookup_by_keyid(uint16_t table_id, uint8_t keyid,
                struct ctlu_lookup_result *lookup_result);

int32_t ctlu_table_lookup_by_key(uint16_t table_id,
                union ctlu_key *key,
                uint8_t key_size,
                struct ctlu_lookup_result *lookup_result);

typedef tbl_handle uint64_t;
/*************************************************************
 * OUR proposal
 /*************************************************************
 */
int32_t dptbl_lookup_by_keyid(int dptbl_id, int dpkg_profile_id,
                struct dptbl_lookup_result *lookup_result);

int32_t dptbl_lookup_by_keyid(struct lookup_params *lookup_params,
                struct dptbl_lookup_result *lookup_result);

struct {
        int dptbl_id;
        int dpkg_profile_id;
}lookup_params;
#endif
#endif /*__FSL_DPTBL_H*/
