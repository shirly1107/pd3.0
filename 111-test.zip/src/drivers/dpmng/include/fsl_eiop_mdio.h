/*
 * Copyright 2020 NXP
 */

/**************************************************************************//**
 @File          FSL_EIOP_MDIO.h

 @Description   External definitions and API for External MDIO module.

 @Cautions      None.
 *//***************************************************************************/

#ifndef __FSL_EIOP_MDIO_H__
#define __FSL_EIOP_MDIO_H__


struct mdio_desc {
	int id;
	int eiop_id;
	uint32_t enet_if;
	phys_addr_t paddr;
	void *vaddr;
	phys_addr_t mii_paddr;
	void *mii_vaddr;
};

/**************************************************************************//**
 @Description   External MDIO configuration parameters structure.

 *//***************************************************************************/

/**************************************************************************//**
 @Function      eiop_emdio_init

 @Description   Configures the External MDIOs module according to hardware.

 The driver assigns default values to some MDIO parameters.

 @Param[in]     p_MdioParam    - MDIO configuration parameters.

 @Return        Handle to the new MDIO object; NULL pointer on failure.

 @Cautions      None
 *//***************************************************************************/
struct eiop_emdio *eiop_emdio_init(const struct mdio_desc *mdio_desc);

int eiop_emdio_restore(const struct eiop_emdio *eiop_emdio);

#endif /* __FSL_EIOP_MDIO_H__ */
