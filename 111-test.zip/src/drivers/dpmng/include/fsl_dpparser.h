/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 @File          dpparser.h

 @Description   Parser Application Programming Interface.
 *//***************************************************************************/
#ifndef __FSL_DPPARSER_H
#define __FSL_DPPARSER_H

#include "fsl_types.h"
#include "fsl_net.h"
#include "fsl_ctlu.h"

struct dpparser;
struct dpparser_profile_map;
/*!
 * @Group grp_dpparser	Parser API
 *
 * @brief	Contains initialization APIs and runtime APIs for the Parser
 *              module
 * @{
 */

/*!
 * @Group grp_dpparser_init	Parser initialization API
 *
 * @brief	Contains initialization APIs for the Parser module
 * @{
 */


/*!
 * @name Parser configuration options
 */
#define DPPARSER_MARK_ICMPV6_ATOMIC_FRAGS	0x01
/*!< Select to mark ICMPv6 atomic
 fragments as fragments */
#define DPPARSER_CLK_POWER_DOWN_ENABLE		0x02
#define DPPARSER_MARK_ICMPV6_ATOMIC_FRAGS	0x01
/*!< Select to allow various portions
 of the block to be powered down */
#define DPPARSER_PCLIM_MAX			0x1FFF
/*!< Maximum  Frame PArsing cycle limit*/
#define DPPARSER_LIB_SP				1
/*!< Soft sequence library size*/
#define DPPARSER_MAX_SP				((32 + 1) + DPPARSER_LIB_SP)
/*!< Maximum number of soft sequences managed in layout*/
/* @} */
/*!< Maximum allowed size of Soft Parser Profile name*/
#define MAX_SP_PROFILE_ID_SIZE	8

/**
 * @brief	Parser Configuration Parameters.
 *              This structure is used to hold the default Parser parameters.
 */
struct dpparser_cfg {
	struct ctlu	*ctlu;
	/*!< Maximum Frame Parsing cycle limit;
	When this value is exceeded, the Frame Parsing ceases parsing on
	the frame and report the error as an exception notification.
	A limit value of 0 disables this mechanism. */
	uint16_t	cycle_limit;
	/*!< OR'ed options:
		DPPARSER_MARK_ICMPV6_ATOMIC_FRAGS
		DPPARSER_CLK_POWER_DOWN_ENABLE */
	uint8_t		options;
	int		num_profiles;
};

enum hxs_code {
	HXS_ETH = 0x0000,
	HXS_LLC_SNAP = 0x0001,
	HXS_VLAN = 0x0002,
	HXS_PPPOE_PPP = 0x0003,
	HXS_MPLS = 0x0004,
	HXS_ARP = 0x0005,
	HXS_IP	 = 0x0006,
	HXS_IPV4 = 0x0007,
	HXS_IPV6 = 0x0008,
	HXS_GRE = 0x0009,
	HXS_MINENCAP = 0x000A,
	HXS_OTHER_L3_SHELL = 0x000B,
	HXS_TCP = 0x000C,
	HXS_UDP = 0x000D,
	HXS_IPSEC = 0x000E,
	HXS_SCTP = 0x000F,
	HXS_DCCP = 0x0010,
	HXS_OTHER_L4_SHELL = 0x0011,
	HXS_GTP = 0x0012,
	HXS_ESP = 0x0013,
	HXS_VXLAN = 0x0014,
	HXS_L5_SHELL = 0x001E,
	HXS_FINAL_SHELL = 0x001F,
	HXS_NULL = 0x7FF
};

struct hxs_ptr {
	enum hxs_code	code;
	uint16_t	*ptr;
};
/**
* @brief  	This function restores the Parser module after WRIOP reset
*
* @param[in]   	cfg	- Parser parameters structure
* 				dpparser - A handle to the dpparser object
*
* @returns      Completion status. '0' on Success; Error code otherwise.
*/
int dpparser_restore(const struct dpparser_cfg *cfg, struct dpparser *dpparser);

/**
* @brief  	This function initializes the Parser module
*
* @param[in]   	cfg	- Parser parameters structure
*
* @returns      A handle to the Parser object
*/
struct dpparser *dpparser_init(const struct dpparser_cfg *cfg);

/**
* @brief  	This function deleted all initializations associated
* 		with the Parser object
*
* @param[in]   dpparser - A handle to the dpparser object
*
* @returns      None
*/
void dpparser_done(struct dpparser *dpparser);

/*! @} */ /* end of DPPARSER_init_grp group */

/*!
 * @Group grp_dpparser_runtime	Parser Runtime API
 *
 * @brief	Contains runtime APIs for the Parser module
 * @{
 */

/*!
 * @name Parser Profile configuration options
 */
#define DPPARSER_PPP_DISABLE_MTU_CHECK     	       	0x00000001
/*!< When selected, MTU is not checked; Ethernet has a maximum payload size
 of 1500 bytes; PPPoE header is 6 bytes and the PPP Protocol ID is 2 bytes
 thus the PPP MTU can not exceed 14921; (RFC2516 section 7) */
#define DPPARSER_IPV6_ROUTE_HDR_ENABLE            	0x00000002
/*!< When not selected the routing header is ignored and the destination
 address from the Main header is used instead; The presence of the routing
 header is still reported in the Parse Array but is not handed off with
 the Parse Result. */
#define DPPARSER_L4_IGNORE_PAD_FOR_CHECKSUM  	   	0x00000004
/*!< Relevant for TCP/UDP; When selected, THE padded region at the end of a
 frame is removed from the checksum calculation; Required for layer 4
 checksum validation. */
#define DPPARSER_MPLS_LABEL_INTERPRETATION_DISABLE	0x00000008
/*!< When not selected, the last MPLS label is interpreted as defined below:
	MPLS Label 0 --> IPv4
	MPLS Label 1 --> Other L3 Shell
	MPLS Label 2 --> IPv6
	MPLS Label 3-15 --> Other L3 Shell
	MPLS Label > 15 --> Default next parse sequence;
 When selected, the Frame Parsing advances to MPLS default_next_parse which
 must be properly configured
 */
/* @} */

#define DPPARSER_MAX_PROT_DISABLE_FD_ERR 		8
/*!< The number of protocols that may be defined so their errors is not
 * reported in FD[PHE]. */

/* Default value for VXLAN port*/
#define DPPAPRSER_DEF_VXLAN				0x12B5

/**
 * @brief	Parser profile Configuration Parameters.
 *              This structure is used to hold the default Parser Profile
 *              parameters.
 */
struct dpparser_profile_opt_cfg {
	/*!< The valid size of the array below */
	int		num_of_disable_fd_err_report;
	/*!< A protocol parser error is normally reported in FD[PHE];
	 * up to DPPARSER_MAX_PROT_DISABLE_FD_ERR number of protocols may be
	 * defined, so their errors is not reported in FD[PHE];
	 * This may be used to monitor a specific protocol parser error while
	 * filtering the others. */
	enum hxs_code	disable_fd_err_report[DPPARSER_MAX_PROT_DISABLE_FD_ERR];
	 /*!< Configures a distinct EtherType value (or TPID value) to indicate
	  * a VLAN tag addition to the common TPID values 0x8100 and 0x88A8 */
	uint16_t	vlan_tpid[2];
	/*!< Configures a distinct UDP DA value to indicate a VXLAN tag in
	 * addition to the common DA value 0x12B5. */
	uint16_t	vxlan_da[2];
	/*!< OR'ed options:
		DPPARSER_PPP_DISABLE_MTU_CHECK
		IPV6_ROUTE_HDR_ENABLE
		L4_IGNORE_PAD_FOR_CHECKSUM
		MPLS_TABLE_INTERPRETATION_DISABLE
		EGRESS_FLOW */
	uint32_t	options;
	/*!< Relevant when DPPARSER_MPLS_LABEL_INTERPRETATION_DISABLE is
	 * cleared; Next header to be parsed after MPLS; Must be L3 and up; */
	enum hxs_code	mpls_next_hxs;
#ifdef CMD_IF_PTR
	 /*!< Private command interface pointer, used for issuing commands;
	  * if uninitialized, common CTLU interface will be used. */
	void		*cmd_if;
#endif
};

/**************************************************************************//**
@Description	Structure representing the information needed load a Soft
		Parser or to get information about a loaded Soft Parser.

*//***************************************************************************/
	/* SP loading address (starting PC) */
struct dpparser_sw_seq_info {
	uint16_t		pc;
	/* Number of bytes in the SP byte-code (must be a 4 multiple) */
	uint16_t		size;
	/* Pointer to the array containing the SP byte-code (must be aligned on
	 *  a 4 bytes boundary) */
	uint8_t			*byte_code;
};

/**************************************************************************//**
@Description	struct dpni_drv_sparser_param - Structure representing the
		information needed to activate(enable) a Soft Parser.

*//***************************************************************************/
struct dpparser_sw_seq_profile_info {
	/* Hard HXS on which a soft parser is activated.*/
	enum hxs_code hxs;
	/* Soft Sequence Start PC */
	uint16_t			start_pc;
	/* Pointer to the Parameters Array of the SP */
	uint8_t				*param_array;
	/* Parameters offset */
	uint8_t				param_offset;
	/* Parameters size */
	uint8_t				param_size;
};

/**
* @brief  	This function initializes a new Parser Profile
*
* @param[in]   	dpparser	- Parser module handle
* @param[in]   	profile_id	- Parser profile id
* @param[in]   	cmd_if_cfg	- Private command interface parameters.
* 				  NULL for using common interface. Otherwise a
* 				  pointer to a structure of command interface
* 				  parameters, IO dependent. (struct
* 				  eiop_ifp_cmd_if_cfg for EIOP).
* @param[in]   	cfg		- Parser parameters structure
*
* @returns      "0" on success, error code otherwise
*/
int dpparser_init_profile(struct dpparser *dpparser,
                          int profile_id,
                          const void *cmd_if_cfg,
                          const struct dpparser_profile_opt_cfg *cfg);

/**
* @brief	This function activates, on the given profile ID, the
*		soft parsers configured as system-level parsers (enabled by
*		default) in the current loaded soft parsers BLOB. If a BLOB
*		is not loaded this call has no effect.
*
* @param[in]	dpparser   - Parser module handle
*
* @param[in]	sp_profile - Soft Parser Profile name - It must be defined in the blob
* 				If empty string is used then the Default Profile is attached
*
* @param[in]	profile_id - Parser profile id
*
* @param[out]	start_pc - It there is a soft parser parsing a header placed
*			   before an Ethernet header, this variable gets the
*			   starting PC of that soft parser. Only one may exist.
*
* @param[in]	is_egress - 1 for an egress profile otherwise 0
*
* @param[in]	cmd_if_cfg - Private command interface parameters. NULL for
*			     using common interface. Otherwise a pointer to a
*			     structure of command interface parameters, IO
*			     dependent. (struct eiop_ifp_cmd_if_cfg for EIOP).
*
* @returns      "0" on success, error code otherwise
*/
int dpparser_attach_soft_parser(struct dpparser *dpparser, uint8_t sp_profile[], 
			int profile_id, uint16_t *start_pc, uint8_t is_egress, const void *cmd_if_cfg);

/**
* @brief  	This function compares all existing Parser Profiles
*               with a set of new parameters until a match is found
*
* @param[in]   	dpparser	- Parser module handle
* @param[in]   	cmd_if_cfg	- Private command interface parameters.
* 				  NULL for using common interface. Otherwise a
* 				  pointer to a structure of command interface
* 				  parameters, IO dependent. (struct
* 				  eiop_ifp_cmd_if_cfg for EIOP).
* @param[in]   	attr		- Parser parameters structure
* @param[in]   	start_from	- normally 0, other value to start from if this
* 				  is a consequent search.
* @param[in]   	match_id	- valid if return code is "0". The id that
*                             	  matches the attributes.
*
* @returns      "0" on success, error code otherwise.
*/
int dpparser_find_profile(struct dpparser *dpparser,
			  const void *cmd_if_cfg,
			  void *attr,
			  int start_from,
			  int *match_id);

/**
* @brief  	This function deletes an existing Parser Profile
*
* @param[in]   	dpparser	- Parser module handle
* @param[in]   	profile_id	- Parser profile id
* @param[in]   	cmd_if_cfg	- Private command interface parameters.
* 				  NULL for using common interface. Otherwise a
* 				  pointer to a structure of command interface
* 				  parameters, IO dependent. (struct
* 				  eiop_ifp_cmd_if_cfg for EIOP).
*
* @returns      "0" on success, error code otherwise
*/
int dpparser_delete_profile(struct dpparser *dpparser,
                            int profile_id,
                            const void *cmd_if_cfg);

/**
* @brief  	This function will add a TPID configuration if one of
* 		the TPID alternatives is not used.
*
* @param[in]   	dpparser	- Parser module handle
* @param[in]   	profile_id	- Parser profile id
* @param[in]   	cmd_if_cfg	- Private command interface parameters.
* 				  NULL for using common interface. Otherwise a
* 				  pointer to a structure of command interface
* 				  parameters, IO dependent. (struct
* 				  eiop_ifp_cmd_if_cfg for EIOP).
* @param[in]   	tpid		- New TPID
*
* @returns      "0" on success, error code if operation had failed or if both
*               TPID alternatives are used.
*/
int dpparser_add_tpid(struct dpparser *dpparser,
                      int profile_id,
                      const void *cmd_if_cfg,
                      uint16_t tpid);

/**
* @brief  	This function will remove a given �tpid� configuration
*               (to be used for �replacing a current known configuration)
*               or remove both alternatives if "tpid� = 0.
*
* @param[in]   	dpparser	- Parser module handle
* @param[in]   	profile_id	- Parser profile id
* @param[in]   	cmd_if_cfg	- Private command interface parameters.
* 				  NULL for using common interface. Otherwise a
* 				  pointer to a structure of command interface
* 				  parameters, IO dependent. (struct
* 				  eiop_ifp_cmd_if_cfg for EIOP).
* @param[in]   	tpid		- TPID for replacement, or "0" to clear both
* 				  TPID alternatives.
*
* @returns      "0" on success, error code otherwise
*/
int dpparser_remove_tpid(struct dpparser *dpparser,
                         int profile_id,
                         const void *cmd_if_cfg,
                         uint16_t tpid);

/**
* @brief  	This function will add a TPID configuration if one of
* 		the TPID alternatives is not used.
*
* @param[in]   	dpparser	- Parser module handle
* @param[in]   	profile_id	- Parser profile id
* @param[out]   	tpid1
* @param[out]		tpid2
*
* @returns      "0" on success, error code if operation had failed or if both
*               TPID alternatives are used.
*/
int dpparser_get_tpid(struct dpparser *dpparser,
                      int profile_id,
                      uint16_t *tpid1, uint16_t *tpid2);

int dpparser_check_hxs(uint16_t hxs);

void dpparser_get_resource_str(struct dpparser *dpparser, char *res_type);

int dpparser_get_hdr_code(enum net_prot prot, uint16_t *code);
int dpparser_get_hdr_prot(uint16_t code, enum net_prot *prot);

#ifndef OBSOLETED_SP_API
int dpparser_load_sw_seq(struct dpparser *dpparser,
			 struct dpparser_sw_seq_info *ss_info);

int dpparser_enable_sw_seq(struct dpparser *dpparser, int profile_id,
			   const void *cmd_if_cfg,
			   struct dpparser_sw_seq_profile_info *ss_pr_info);
#endif	/* OBSOLETED_SP_API */

/** @} *//* end of dpparser runtime group */
/** @} *//* end of dpparser group */

#endif /* _FSL_DPPARSER_H */
