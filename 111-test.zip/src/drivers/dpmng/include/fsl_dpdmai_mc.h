/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPDMAI_H
#define __FSL_DPDMAI_H

struct dpdmai;

#define DPDMAI_MAX_IRQ_NUM	0

#define DPDMAI_PRIO_NUM		2
#define DPDMAI_MAX_QUEUES	SOC_NUM_OF_CORES
#define DPDMAI_ALL_QUEUES	(uint8_t)(-1)

#define DPDMAI_OPT_CG_PER_PRIORITY		0x00000001

struct dpdmai_cfg {
	uint8_t num_queues;
	uint8_t priorities[DPDMAI_PRIO_NUM];
	struct {
		uint32_t options;
	} adv;
};

int dpdmai_create(struct dpdmai *dpdmai, const struct dpdmai_cfg *cfg);

void dpdmai_destroy(struct dpdmai *dpdmai);

int dpdmai_enable(struct dpdmai *dpdmai);

int dpdmai_disable(struct dpdmai *dpdmai);

int dpdmai_is_enabled(struct dpdmai *dpdmai, int *en);

int dpdmai_reset(struct dpdmai *dpdmai);

int dpdmai_get_irq(struct dpdmai *dpdmai,
		  uint8_t irq_index,
		  struct mc_irq_cfg *irq_cfg);

int dpdmai_set_irq(struct dpdmai *dpdmai,
		   uint8_t irq_index,
		   const struct mc_irq_cfg *irq_cfg);

int dpdmai_set_irq_enable(struct dpdmai *dpdmai,
			  uint8_t irq_index,
			  uint8_t en);

int dpdmai_get_irq_enable(struct dpdmai *dpdmai,
			  uint8_t irq_index,
			  uint8_t *en);

int dpdmai_set_irq_mask(struct dpdmai *dpdmai,
			uint8_t irq_index,
			uint32_t mask);

int dpdmai_get_irq_mask(struct dpdmai *dpdmai,
			uint8_t irq_index,
			uint32_t *mask);

int dpdmai_get_irq_status(struct dpdmai *dpdmai,
			  uint8_t irq_index,
			  uint32_t *status);

int dpdmai_clear_irq_status(struct dpdmai *dpdmai,
			    uint8_t irq_index,
			    uint32_t status);

struct dpdmai_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
	uint8_t num_of_priorities;
	uint8_t num_of_queues;
	uint32_t options;
};

int dpdmai_get_attributes(struct dpdmai *dpdmai, struct dpdmai_attr *attr);

enum dpdmai_dest {
	DPDMAI_DEST_NONE = 0,
	DPDMAI_DEST_DPIO = 1,
	DPDMAI_DEST_DPCON = 2
};

struct dpdmai_dest_cfg {
	enum dpdmai_dest dest_type;
	int dest_id;
	uint8_t priority;
};

#define DPDMAI_QUEUE_OPT_USER_CTX	0x00000001
#define DPDMAI_QUEUE_OPT_DEST		0x00000002

struct dpdmai_rx_queue_cfg {
	uint32_t options;
	uint64_t user_ctx;
	struct dpdmai_dest_cfg dest_cfg;
};

int dpdmai_set_rx_queue(struct dpdmai *dpdmai,
	uint8_t queue_id,
	uint8_t priority,
	const struct dpdmai_rx_queue_cfg *cfg);

struct dpdmai_rx_queue_attr {
	uint64_t user_ctx;
	struct dpdmai_dest_cfg dest_cfg;
	uint32_t fqid;
};

int dpdmai_get_rx_queue(struct dpdmai *dpdmai,
	uint8_t queue_id,
	uint8_t priority,
	struct dpdmai_rx_queue_attr *attr);

struct dpdmai_tx_queue_attr {
	uint32_t fqid;
};

int dpdmai_get_tx_queue(struct dpdmai *dpdmai,
	uint8_t queue_id,
	uint8_t priority,
	struct dpdmai_tx_queue_attr *attr);

enum dpdmai_congestion_unit {
	DPDMAI_CONGESTION_UNIT_BYTES = 0,
	DPDMAI_CONGESTION_UNIT_FRAMES
};

#define DPDMAI_CGN_MODE_WRITE_MEM_ON_ENTER	0x00000001
#define DPDMAI_CGN_MODE_WRITE_MEM_ON_EXIT	0x00000002
#define DPDMAI_CGN_MODE_COHERENT_WRITE		0x00000004

struct dpdmai_congestion_notification_cfg {
	enum dpdmai_congestion_unit units;
	uint16_t notification_mode;
	uint32_t threshold_entry;
	uint32_t threshold_exit;
	uint64_t message_ctx;
	uint64_t message_iova;
};

int dpdmai_set_rx_congestion_notification(struct dpdmai *dpdmai,
	uint8_t priority,
	struct dpdmai_congestion_notification_cfg *cfg);

int dpdmai_set_tx_congestion_notification(struct dpdmai *dpdmai,
	uint8_t priority,
	struct dpdmai_congestion_notification_cfg *cfg);

int dpdmai_get_rx_congestion_notification(struct dpdmai *dpdmai,
	uint8_t priority,
	struct dpdmai_congestion_notification_cfg *cfg);

int dpdmai_get_tx_congestion_notification(struct dpdmai *dpdmai,
	uint8_t priority,
	struct dpdmai_congestion_notification_cfg *cfg);

/* MC internal functions*/

/**
 * @brief	Will allocate resources and preliminary initialization
 *
 * @param[in]	dpdmai		Pointer to dpdmai object
 * @param[in]	cfg 		Configuration structure
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int dpdmai_init(struct dpdmai *dpdmai,
		const struct dpdmai_cfg *cfg,
		const struct dpmng_dev_cfg *dev_cfg);

struct dpdmai *dpdmai_allocate(void);
void dpdmai_deallocate(struct dpdmai *dpdmai);

int dpdmai_set_dev_ctx(struct dpdmai *dpdmai,
		       const struct dpmng_dev_ctx *dev_ctx);
int dpdmai_set_rx_pl(struct dpdmai *dpdmai, struct dpmng_dev_ctx *dev_ctx);
int dpdmai_set_tx_pl(struct dpdmai *dpdmai, struct dpmng_dev_ctx *dev_ctx);


#endif /* __FSL_DPDMAI_H */
