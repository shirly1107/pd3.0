/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPPMU_H
#define __FSL_DPPMU_H

struct dppmu_desc {
	int disable;

	phys_addr_t paddr;
	void *vaddr;
	/* The TPH10SETR, TPH10SR0,TPH15SETR and TPH15SR0 implementation depends
	 on the actual MC and AIOP core numbers present on the DPAA2 platform.*/
	uint32_t ph10_aiop_core_mask;
	uint32_t ph15_aiop_core_mask;
};

void dppmu_ph10_state_request(struct dppmu_desc *desc, uint32_t mask);

void dppmu_ph10_state_status(struct dppmu_desc *desc, uint32_t *status);

void dppmu_ph15_state_request(struct dppmu_desc *desc, uint32_t mask);

void dppmu_ph15_state_status(struct dppmu_desc *desc, uint32_t *status);

void dppmu_aiop_tile_reset_request(struct dppmu_desc *desc);

void dppmu_aiop_tile_reset_status(struct dppmu_desc *desc, uint32_t *status);

#endif /* __FSL_DPPMU_H */
