/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_EIOP_MEMAC_H
#define __FSL_EIOP_MEMAC_H

#include "fsl_types.h"
#include "fsl_enet.h"

#define MEMAC_NUM_OF_PADDRS 7 /* Num of additional exact match MAC adr regs */

/* Control and Configuration Register (COMMAND_CONFIG) */
#define CMD_CFG_MG				0x80000000 /* 00 Magic Packet detection */
#define CMD_CFG_RXSTP			0x20000000 /* 02 Rx stop */
#define CMD_CFG_FLT_HDL_DIS		0x08000000 /* 02 Disable RS fault handling */
#define CMD_CFG_REG_LOWP_RXETY	0x01000000 /* 07 Rx low power indication */
#define CMD_CFG_TX_LOWP_ENA		0x00800000 /* 08 Tx Low Power Idle Enable */
#define CMD_CFG_SFD_ANY			0x00200000 /* 10 Disable SFD check */
#define CMD_CFG_PFC_MODE		0x00080000 /* 12 Enable PFC */
#define CMD_CFG_NO_LEN_CHK		0x00020000 /* 14 Payload length check disable */
#define CMD_CFG_SEND_IDLE		0x00010000 /* 15 Force idle generation */
#define CMD_CFG_CNT_FRM_EN		0x00002000 /* 18 Control frame rx enable */
#define CMD_CFG_SW_RESET		0x00001000 /* 19 S/W Reset, self clearing bit */
#define CMD_CFG_TX_PAD_EN		0x00000800 /* 20 Enable Tx padding of frames */
#define CMD_CFG_LOOPBACK_EN		0x00000400 /* 21 XGMII/GMII loopback enable */
#define CMD_CFG_TX_ADDR_INS		0x00000200 /* 22 Tx source MAC addr insertion */
#define CMD_CFG_PAUSE_IGNORE	0x00000100 /* 23 Ignore Pause frame quanta */
#define CMD_CFG_PAUSE_FWD		0x00000080 /* 24 Terminate/frwd Pause frames */
#define CMD_CFG_CRC_FWD			0x00000040 /* 25 Terminate/frwd CRC of frames */
#define CMD_CFG_PAD_EN			0x00000020 /* 26 Frame padding removal */
#define CMD_CFG_PROMIS_EN		0x00000010 /* 27 Promiscuous operation enable */
#define CMD_CFG_WAN_MODE		0x00000008 /* 28 WAN mode enable */
#define CMD_CFG_RX_EN			0x00000002 /* 30 MAC receive path enable */
#define CMD_CFG_TX_EN			0x00000001 /* 31 MAC transmit path enable */

#define CMD_CFG_WAN_MODE_SHIFT		3
#define CMD_CFG_PROMIS_EN_MODE_SHIFT	4
#define CMD_CFG_PAUSE_IGNORE_SHIFT      8
#define CMD_CFG_LOOPBACK_EN_SHIFT	10
#define CMD_CFG_MG_SHIFT		31

/* IEEE1588 Single-Step Control Register (single_step) */
#define SINGLE_STEP_ENABLE				0x80000000
#define SINGLE_STEP_CHECKSUM_UPDATE			0x00000080
#define SINGLE_STEP_OFFSET_MASK				0x0000FF00
#define SINGLE_STEP_MASK				0x8000FF80
#define SINGLE_STEP_OFFSET_SHIFT			8

/* Transmit FIFO Sections Register (TX_FIFO_SECTIONS) */
/* TX_EMPTY */
#define TX_EMPTY_100000				0x003f0000
#define TX_EMPTY_40000				0x00160000
#define TX_EMPTY_25000				0x00360000
#define TX_EMPTY_10000				0x00360000
#define TX_EMPTY_2500				0x00100000
#define TX_EMPTY_1000				0x00070000
#define TX_EMPTY_10000_EIOP_1_0_0_500MHz	0x005a0000
#define TX_EMPTY_10000_EIOP_1_0_0_600MHz	0x003d0000
/* TX_AVAIL */
#define TX_AVAIL_100000				0x00000010
#define TX_AVAIL_40000				0x00000010
#define TX_AVAIL_25000				0x00000019
#define TX_AVAIL_10000				0x00000019
#define TX_AVAIL_2500				0x0000000F
#define TX_AVAIL_1000				0x00000006
#define TX_AVAIL_10000_EIOP_1_0_0_500MHz	0x00000048
#define TX_AVAIL_10000_EIOP_1_0_0_600MHz	0x0000002d

/* Receive FIFO Section Register (RX_FIFO_SECTIONS) */
#define RX_CEMAC_SECTION_EMPTY		0x00000000
#define RX_CEMAC_SECTION_AVAIL		0x00000010
#define RX_MEMAC_SECTION_EMPTY		0x00000000
#define RX_MEMAC_SECTION_AVAIL		0x00000020

/* Interface Mode Register (IF_MODE) */
#define IF_MODE_25G_RGMII_AUTO	0x80000000 /* bit 0 - Enable automatic speed selection*/
#define IF_MODE_25G_RGMII_1000	0x40000000 /* 10 - 1000Mbps RGMII */
#define IF_MODE_25G_RGMII_100	0x00000000 /* 0 - 100 Mbps RGMII*/
#define IF_MODE_25G_RGMII_10	0x20000000 /* 01 - 10Mbps RGMII */
#define IF_MODE_25G_RGMII_SP_MASK	0x60000000 /* Setsp mask bits */
#define IF_MODE_25G_XGMII	0x00000001 /* 30-31 XGMII (10G/25G) interface */
#define IF_MODE_25G_GMII	0x00000003 /* 30-31 GMII 25G mEmac (1G) interface */
#define IF_MODE_MASK		0x00000003 /* 30-31 Mask on i/f mode bits */
#define IF_MODE_XGMII		0x00000000 /* 30-31 XGMII (10G) interface */
#define IF_MODE_GMII		0x00000002 /* 30-31 GMII (1G) interface */
#define IF_MODE_RGMII		0x00000004
#define IF_MODE_RGMII_AUTO	0x00008000
#define IF_MODE_RGMII_1000  0x00004000 /* 10 - 1000Mbps RGMII */
#define IF_MODE_RGMII_100   0x00000000 /* 00 - 100Mbps RGMII */
#define IF_MODE_RGMII_10    0x00002000 /* 01 - 10Mbps RGMII */
#define IF_MODE_RGMII_SP_MASK 0x00006000 /* Setsp mask bits */
#define IF_MODE_RGMII_FD    0x00001000 /* Full duplex RGMII */
#define IF_MODE_HD          0x00000040 /* Half duplex operation */

/* Hash table Control Register (HASHTABLE_CTRL) */
#define HASH_CTRL_MCAST_SHIFT	26
#define HASH_CTRL_MCAST_EN	0x00000100 /* 23 Mcast frame rx for hash */
#define HASH_CTRL_ADDR_MASK	0x0000003f /* 26-31 Hash table address code */

#define GROUP_ADDRESS		0x0000010000000000ULL /* MAC mcast indication */
#define HASH_TABLE_SIZE		64 /* Hash tbl size */

/* Transmit Inter-Packet Gap Length Register (TX_IPG_LENGTH) */
#define MEMAC_TX_IPG_LENGTH_MASK	0x0000003f

/* Statistics Configuration Register (STATN_CONFIG) */
#define STATS_CFG_CLR		0x00000004 /* 29 Reset all counters */
#define STATS_CFG_CLR_ON_RD	0x00000002 /* 30 Clear on read */
#define STATS_CFG_SATURATE	0x00000001 /* 31 Saturate at the maximum val */

/* Interrupt Mask Register (IMASK) */
#define MEMAC_IMASK_MGI		0x40000000 /* 1 Magic pkt detect indication */
#define MEMAC_IMASK_TSECC_ER 	0x20000000 /* 2 Timestamp FIFO ECC error evnt */
#define MEMAC_IMASK_TECC_ER	0x02000000 /* 6 Transmit frame ECC error evnt */
#define MEMAC_IMASK_RECC_ER	0x01000000 /* 7 Receive frame ECC error evnt */

/* IEVENT register */
#define MEMAC_IEVENT_RX_EMPTY	0x00000040 /* 25 empty receive fifo condition */
#define MEMAC_IEVENT_TX_EMPTY	0x00000020 /* 26 empty transmit fifo condition */

#define MEMAC_ALL_ERRS_IMASK			\
		((uint32_t)(MEMAC_IMASK_TSECC_ER	| \
			MEMAC_IMASK_TECC_ER	| \
			MEMAC_IMASK_RECC_ER))

#define MEMAC_IEVNT_PCS			0x80000000/* PCS (XG). Link sync (G) */
#define MEMAC_IEVNT_AN			0x40000000 /* Auto-negotiation */
#define MEMAC_IEVNT_LT			0x20000000 /* Link Training/New page */
#define MEMAC_IEVNT_MGI			0x00004000 /* Magic pkt detection */
#define MEMAC_IEVNT_TS_ECC_ER   	0x00002000 /* Timestamp FIFO ECC error */
#define MEMAC_IEVNT_RX_FIFO_OVFL	0x00001000 /* Rx FIFO overflow */
#define MEMAC_IEVNT_TX_FIFO_UNFL	0x00000800 /* Tx FIFO underflow */
#define MEMAC_IEVNT_TX_FIFO_OVFL	0x00000400 /* Tx FIFO overflow */
#define MEMAC_IEVNT_TX_ECC_ER		0x00000200 /* Tx frame ECC error */
#define MEMAC_IEVNT_RX_ECC_ER		0x00000100 /* Rx frame ECC error */
#define MEMAC_IEVNT_LI_FAULT		0x00000080 /* Link Interruption flt */
#define MEMAC_IEVNT_RX_EMPTY		0x00000040 /* Rx FIFO empty */
#define MEMAC_IEVNT_TX_EMPTY		0x00000020 /* Tx FIFO empty */
#define MEMAC_IEVNT_RX_LOWP		0x00000010 /* Low Power Idle */
#define MEMAC_IEVNT_PHY_LOS		0x00000004 /* Phy loss of signal */
#define MEMAC_IEVNT_REM_FAULT		0x00000002 /* Remote fault (XGMII) */
#define MEMAC_IEVNT_LOC_FAULT		0x00000001 /* Local fault (XGMII) */

/* maxfrm register defines */
#define MEMAC_MFL_MASK			0x0000FFFF
#define MEMAC_TX_MTU_MASK		0xFFFF0000

/* EIOP MEMAC options */
#define MEMAC_DESC_OPT_FIFO_SECTIONS	0x00000001


/* Ethernet MAC registry's memory map regions */
enum emac_mem_map_areas {
	E_EMAC_GENERAL_CONTROL_STATUS_1_REGISTERS,
	E_EMAC_GENERAL_CONTROL_STATUS_2_REGISTERS,
	E_EMAC_EEE_CONTROL_STATUS_REGISTERS,
	E_EMAC_1588_CONTROL_STATUS_REGISTERS,
	E_EMAC_STATISTICS_CONFIGURATION_REGISTERS,
	E_EMAC_RX_TX_STATISTICS_COUNTER_REGISTERS,
	E_EMAC_LINE_INTERFACE_CONTROL_REGISTERS,
	E_EMAC_PFC_STATISTICS_COUNTERS_REGISTERS,
	E_EMAC_INTERRUPT_MASK_REGISTERS,
	E_EMAC_MEMORY_MAP_REGIONS
};

enum emac_type {
	E_EMAC_10_100_1G_10G_TYPE,
	E_EMAC_1G_10G_25G_TYPE,
	E_EMAC_40G_50G_100G_TYPE
};

struct eiop_memac_desc {
	int mac_id;
	int eiop_id;
	phys_addr_t paddr;
	void *vaddr;
	/* dynamic (non-spec) parameters) */
	int disable;
	uint32_t enet_if;
	uint8_t autoneg;
	uint8_t debug_link_check;
	int phy_id;
	uint32_t link_type;
	uint32_t rate;
	int serdes_id;
	int qsgmii_master;
	int qsgmii_phy_addr;
	uint32_t options;	/*! See MEMAC_DESC_OPT_xxx */
	enum emac_type type;	/* used to set as multi/any/high-rate mac*/
	const uint32_t *mem_map;
	uint8_t master_lane;
	uint8_t no_lanes;
	uint8_t disable_flt_hdl;	/* Disable RS fault handling */
	int converted;
	uint32_t enet_prev;
};

enum memac_counters {
	E_MEMAC_COUNTER_R64,
	E_MEMAC_COUNTER_R127,
	E_MEMAC_COUNTER_R255,
	E_MEMAC_COUNTER_R511,
	E_MEMAC_COUNTER_R1023,
	E_MEMAC_COUNTER_R1518,
	E_MEMAC_COUNTER_R1519X,
	E_MEMAC_COUNTER_RFRG,
	E_MEMAC_COUNTER_RJBR,
	E_MEMAC_COUNTER_RDRP,
	E_MEMAC_COUNTER_RALN,
	E_MEMAC_COUNTER_TUND,
	E_MEMAC_COUNTER_ROVR,
	E_MEMAC_COUNTER_RXPF,
	E_MEMAC_COUNTER_TXPF,
	E_MEMAC_COUNTER_ROCT,
	E_MEMAC_COUNTER_RMCA,
	E_MEMAC_COUNTER_RBCA,
	E_MEMAC_COUNTER_RPKT,
	E_MEMAC_COUNTER_RUCA,
	E_MEMAC_COUNTER_RERR,
	E_MEMAC_COUNTER_TOCT,
	E_MEMAC_COUNTER_TMCA,
	E_MEMAC_COUNTER_TBCA,
	E_MEMAC_COUNTER_TUCA,
	E_MEMAC_COUNTER_TERR,
	E_MEMAC_COUNTER_RFRM,
	E_MEMAC_COUNTER_TFRM
};

#define DEFAULT_PAUSE_QUANTA	0xf000
#define DEFAULT_PAUSE_THRESH	DEFAULT_PAUSE_QUANTA / 2
#define DEFAULT_FRAME_LENGTH	(10 * KILOBYTE)
#define DEFAULT_TX_IPG_LENGTH	12

/*
 * memory map
 */

struct mac_addr {
	uint32_t mac_addr_l; /* Lower 32 bits of 48-bit MAC address */
	uint32_t mac_addr_u; /* Upper 16 bits of 48-bit MAC address */
};

/* General Control and Status */
struct emac_csr_1_regs {
	uint32_t command_config; 	/* Ctrl and cfg */
	struct mac_addr mac_addr0;	/* MAC_ADDR_0...1 */
	uint32_t maxfrm; 			/* Max frame length */
	uint32_t res0018[1];
	uint32_t rx_fifo_sections; /* Receive FIFO configuration reg */
	uint32_t tx_fifo_sections; /* Transmit FIFO configuration reg */
};

struct emac_csr_2_regs {
	uint32_t ievent; 			/* Interrupt event */
	uint32_t tx_ipg_length; 	/* Transmitter inter-packet-gap */
	uint32_t res0048;
	uint32_t imask; 			/* Interrupt mask */
	uint32_t res0050;
	uint32_t pause_quanta[4]; 	/* Pause quanta */
	uint32_t pause_thresh[4]; 	/* Pause quanta threshold */
	uint32_t rx_pause_status; 	/* Receive pause status */
};

struct emac_csr_eee_regs {
	uint32_t lpwake_timer; 	/* Low Power Wakeup Timer */
	uint32_t sleep_timer; 	/* Transmit EEE Low Power Timer */
};

struct emac_csr_1588_regs {
	uint32_t single_step; 	/* IEEE-1588 Single-Step Control */
	uint32_t peer_delay; 	/* IEEE-1588 Single-Step Peer Delay */
};

/* multi/any rate embedded MAC statistics */
struct memac_rx_tx_stat_regs {
	/* Rx Statistics Counter */
	uint32_t reoct_l;
	uint32_t reoct_u;
	uint32_t roct_l;
	uint32_t roct_u;
	uint32_t raln_l;
	uint32_t raln_u;
	uint32_t rxpf_l;
	uint32_t rxpf_u;
	uint32_t rfrm_l;
	uint32_t rfrm_u;
	uint32_t rfcs_l;
	uint32_t rfcs_u;
	uint32_t rvlan_l;
	uint32_t rvlan_u;
	uint32_t rerr_l;
	uint32_t rerr_u;
	uint32_t ruca_l;
	uint32_t ruca_u;
	uint32_t rmca_l;
	uint32_t rmca_u;
	uint32_t rbca_l;
	uint32_t rbca_u;
	uint32_t rdrp_l;
	uint32_t rdrp_u;
	uint32_t rpkt_l;
	uint32_t rpkt_u;
	uint32_t rund_l;
	uint32_t rund_u;
	uint32_t r64_l;
	uint32_t r64_u;
	uint32_t r127_l;
	uint32_t r127_u;
	uint32_t r255_l;
	uint32_t r255_u;
	uint32_t r511_l;
	uint32_t r511_u;
	uint32_t r1023_l;
	uint32_t r1023_u;
	uint32_t r1518_l;
	uint32_t r1518_u;
	uint32_t r1519x_l;
	uint32_t r1519x_u;
	uint32_t rovr_l;
	uint32_t rovr_u;
	uint32_t rjbr_l;
	uint32_t rjbr_u;
	uint32_t rfrg_l;
	uint32_t rfrg_u;
	uint32_t rcnp_l;
	uint32_t rcnp_u;
	uint32_t rdrntp_l;
	uint32_t rdrntp_u;
	uint32_t res01d0[12];
	/* Tx Statistics Counter */
	uint32_t teoct_l;
	uint32_t teoct_u;
	uint32_t toct_l;
	uint32_t toct_u;
	uint32_t res0210[2];
	uint32_t txpf_l;
	uint32_t txpf_u;
	uint32_t tfrm_l;
	uint32_t tfrm_u;
	uint32_t tfcs_l;
	uint32_t tfcs_u;
	uint32_t tvlan_l;
	uint32_t tvlan_u;
	uint32_t terr_l;
	uint32_t terr_u;
	uint32_t tuca_l;
	uint32_t tuca_u;
	uint32_t tmca_l;
	uint32_t tmca_u;
	uint32_t tbca_l;
	uint32_t tbca_u;
	uint32_t res0258[2];
	uint32_t tpkt_l;
	uint32_t tpkt_u;
	uint32_t tund_l;
	uint32_t tund_u;
	uint32_t t64_l;
	uint32_t t64_u;
	uint32_t t127_l;
	uint32_t t127_u;
	uint32_t t255_l;
	uint32_t t255_u;
	uint32_t t511_l;
	uint32_t t511_u;
	uint32_t t1023_l;
	uint32_t t1023_u;
	uint32_t t1518_l;
	uint32_t t1518_u;
	uint32_t t1519x_l;
	uint32_t t1519x_u;
	uint32_t res02a8[6];
	uint32_t tcnp_l;
	uint32_t tcnp_u;
};

/* high speed embedded MAC statistics */
struct hemac_rx_tx_stat_regs {
	uint32_t tfrm_l;
	uint32_t tfrm_u;
	uint32_t rfrm_l;
	uint32_t rfrm_u;
	uint32_t rfcs_l;
	uint32_t rfcs_u;
	uint32_t raln_l;
	uint32_t raln_u;
	uint32_t txpf_l;
	uint32_t txpf_u;
	uint32_t rxpf_l;
	uint32_t rxpf_u;
	uint32_t res0b0_0bf[4];
	uint32_t tvlan_l;
	uint32_t tvlan_u;
	uint32_t rvlan_l;
	uint32_t rvlan_u;
	uint32_t toct_l;
	uint32_t toct_u;
	uint32_t roct_l;
	uint32_t roct_u;
	uint32_t ruca_l;
	uint32_t ruca_u;
	uint32_t rmca_l;
	uint32_t rmca_u;
	uint32_t rbca_l;
	uint32_t rbca_u;
	uint32_t terr_l;
	uint32_t terr_u;
	uint32_t res0100[2];
	uint32_t tuca_l;
	uint32_t tuca_u;
	uint32_t tmca_l;
	uint32_t tmca_u;
	uint32_t tbca_l;
	uint32_t tbca_u;
	uint32_t rdrp_l;
	uint32_t rdrp_u;
	uint32_t reoct_l;
	uint32_t reoct_u;
	uint32_t rpkt_l;
	uint32_t rpkt_u;
	uint32_t rund_l;
	uint32_t rund_u;
	uint32_t r64_l;
	uint32_t r64_u;
	uint32_t r127_l;
	uint32_t r127_u;
	uint32_t r255_l;
	uint32_t r255_u;
	uint32_t r511_l;
	uint32_t r511_u;
	uint32_t r1023_l;
	uint32_t r1023_u;
	uint32_t r1518_l;
	uint32_t r1518_u;
	uint32_t r1519x_l;
	uint32_t r1519x_u;
	uint32_t rovr_l;
	uint32_t rovr_u;
	uint32_t rjbr_l;
	uint32_t rjbr_u;
	uint32_t rfrg_l;
	uint32_t rfrg_u;
	uint32_t rerr_l;
	uint32_t rerr_u;
	uint32_t res0198[32]; /* PFC registers */
	uint32_t tcnp_l;
	uint32_t tcnp_u;
	uint32_t rcnp_l;
	uint32_t rcnp_u;
	uint32_t teoct_l;
	uint32_t teoct_u;
	uint32_t tpkt_l;
	uint32_t tpkt_u;
	uint32_t t64_l;
	uint32_t t64_u;
	uint32_t t127_l;
	uint32_t t127_u;
	uint32_t t255_l;
	uint32_t t255_u;
	uint32_t t511_l;
	uint32_t t511_u;
	uint32_t t1023_l;
	uint32_t t1023_u;
	uint32_t t1518_l;
	uint32_t t1518_u;
	uint32_t t1519x_l;
	uint32_t t1519x_u;
	uint32_t rdrntp_l;
	uint32_t rdrntp_u;

	/*
	uint32_t tfcs_l;
	uint32_t tfcs_u;
	uint32_t tund_l;
	uint32_t tund_u;
	*/
};

/* PFC Statistics Counter Registers */
struct emac_pfc_stat_regs {
	uint32_t reg[0];
};

struct emac_line_if_ctrl_regs {
	/* Line Interface Control */
	uint32_t if_mode; 		/* Interface Mode Control */
	uint32_t if_status; 	/* Interface Status */	
};

struct memac_cfg {
	int reset_on_init;
	int rx_error_discard;
	int pause_ignore;
	int pause_forward_enable;
	int no_length_check_enable;
	int cmd_frame_enable;
	int send_idle_enable;
	int wan_mode_enable;
	int promiscuous_mode_enable;
	int tx_addr_ins_enable;
	int loopback_enable;
	int lgth_check_nostdr;
	int time_stamp_enable;
	int pad_enable;
	int phy_tx_ena_on;
	int rx_sfd_any;
	int rx_pbl_fwd;
	int tx_pbl_fwd;
	int debug_mode;
	uint16_t max_frame_length;
	uint16_t pause_quanta;
	uint32_t tx_ipg_length;
	uint8_t disable_flt_hdl;
};

/**
 * eiop_memac_defconfig() - Get default MEMAC configuration
 * @cfg:    pointer to configuration structure.
 *
 * Call this function to obtain a default set of configuration values for
 * initializing MEMAC. The user can overwrite any of the values before calling
 * eiop_memac_init(), if specific configuration needs to be applied.
 */
void eiop_memac_defconfig(struct memac_cfg *cfg);

int eiop_memac_init(struct eiop_memac_desc *desc,
                    struct memac_cfg *cfg,
                    enum enet_interface enet_interface,
                    uint32_t rate,
                    uint32_t exceptions);

int eiop_memac_rx_graceful_stop(const struct eiop_memac_desc *desc);

int eiop_memac_tx_graceful_stop(struct eiop_memac_desc *desc);

void eiop_memac_enable(struct eiop_memac_desc *desc, int apply_rx, int apply_tx);

void eiop_memac_disable(const struct eiop_memac_desc *desc, int apply_rx, int apply_tx);

#ifdef FUTURE_SUPPORT
void eiop_memac_set_promiscuous(struct eiop_memac_desc *desc, int val);

int eiop_memac_get_promiscuous(struct eiop_memac_desc *desc);

void eiop_memac_add_addr_in_paddr(struct eiop_memac_desc *desc,
                                  uint8_t *adr,
                                  uint8_t paddr_num);

void eiop_memac_clear_addr_in_paddr(struct eiop_memac_desc *desc, uint8_t paddr_num);
#endif /* FUTURE_SUPPORT */

uint64_t eiop_emac_get_counter(struct eiop_memac_desc *desc,
                                enum memac_counters reg_name);
uint64_t eiop_memac_get_custom_counter(struct eiop_memac_desc *desc, uint32_t offset);

#ifdef PFC_SUPPORT
void eiop_memac_set_tx_pause_frames(struct eiop_memac_desc *desc,
                                    uint8_t priority,
                                    uint16_t pause_time,
                                    uint16_t thresh_time);

void eiop_memac_get_tx_pause_frames(struct eiop_memac_desc *desc,
                                    uint8_t *priority,
                                    uint16_t *pause_time,
                                    uint16_t *thresh_time);
#endif /* PFC_SUPPORT */

uint16_t eiop_memac_get_max_frame_len(struct eiop_memac_desc *desc);

void eiop_memac_set_max_frame_len(struct eiop_memac_desc *desc, uint16_t length);

void eiop_memac_set_exception(struct eiop_memac_desc *desc,
                              uint32_t val,
                              int enable);

void eiop_memac_reset_stat(struct eiop_memac_desc *desc);

void eiop_memac_reset(struct eiop_memac_desc *desc);

#ifdef FUTURE_WORK
void eiop_memac_reset_filter_table(struct eiop_memac_desc *desc);

void eiop_memac_set_hash_table_entry(struct eiop_memac_desc *desc, uint32_t crc);

void eiop_memac_set_hash_table(struct eiop_memac_desc *desc, uint32_t val);
#endif /* FUTURE_WORK */

void eiop_memac_set_tx_pause_frames(struct eiop_memac_desc *desc, int enable);

void eiop_memac_set_rx_ignore_pause_frames(struct eiop_memac_desc *desc,
                                           int enable);

void eiop_memac_set_pfc_mode(struct eiop_memac_desc *desc, int mode);
void eiop_memac_set_tx_pfc_frames(struct eiop_memac_desc *desc, uint8_t priority, uint16_t pause_time, uint16_t thresh_time);

#ifdef PFC_SUPPORT

int eiop_memac_get_rx_ignore_pause_frames(struct eiop_memac_desc *desc);
#endif /* PFC_SUPPORT */

void eiop_memac_set_ptp(struct eiop_memac_desc *desc,
                        int enable,
                        uint8_t offset,
                        int checksum_update,
                        uint32_t peer_delay);

void eiop_memac_get_ptp(struct eiop_memac_desc *desc,
                        int *enable,
                        uint8_t *offset,
                        int *checksum_update);

void eiop_memac_set_wan(struct eiop_memac_desc *desc, int enable);

int eiop_memac_get_wan(struct eiop_memac_desc *desc);

void eiop_memac_set_ipg_len(struct eiop_memac_desc *desc, int lengh);

uint8_t eiop_memac_get_ipg_len(struct eiop_memac_desc *desc);

void  eiop_memac_set_loopback(struct eiop_memac_desc *desc, int enable);

int eiop_memac_get_loopback(struct eiop_memac_desc *desc);

#ifdef WOL_SUPPORT
void eiop_memac_set_wol(struct eiop_memac_desc *desc, int enable);

int eiop_memac_get_wol(struct eiop_memac_desc *desc);
#endif /* WOL_SUPPORT */

uint32_t eiop_memac_get_event(struct eiop_memac_desc *desc, uint32_t ev_mask);

void eiop_memac_ack_event(struct eiop_memac_desc *desc, uint32_t ev_mask);

uint32_t eiop_memac_get_interrupt_mask(struct eiop_memac_desc *desc);

void eiop_memac_adjust_link(struct eiop_memac_desc *desc,
                            enum enet_interface iface_mode,
                            uint32_t rate,
                            int full_dx,
                            int fixed);

void eiop_memac_dump_regs(struct eiop_memac_desc *desc);

void dump_hardware_mac(struct eiop_memac_desc *desc);

/* MII Access section */
#define MDIO_CLAUSE22	0
#define MDIO_CLAUSE45	1

/* MII Management Registers */
#define MDIO_CFG_CLK_DIV_MASK       0x0000ff80
#define MDIO_CFG_CLK_DIV_SHIFT      7
#define MDIO_CFG_HOLD_MASK          0x0000001c
#define MDIO_CFG_ENC45              0x00000040
#define MDIO_CFG_READ_ERR           0x00000002
#define MDIO_CFG_BSY                0x00000001

#define MDIO_CTL_PHY_ADDR_SHIFT     5
#define MDIO_CTL_READ               0x00008000

#define MDIO_DATA_BSY               0x80000000

/* MEMAC Internal PHY Registers - SGMII */
#define PHY_SGMII_CR_PHY_RESET          0x8000
#define PHY_SGMII_CR_AN_EN           	0x1000
#define PHY_SGMII_CR_RESET_AN           0x0200
#define PHY_SGMII_CR_FD					0x0100
#define PHY_SGMII_CR_1G					0x0040
#define PHY_SGMII_CR_DEF_VAL			0x1140

#define PHY_SGMII_DEV_ABILITY_ACK			0x4000
#define PHY_SGMII_DEV_ABILITY_SGMII			0x0001
#define PHY_SGMII_DEV_ABILITY_FD			0x0020
#define PHY_SGMII_DEV_ABILITY_PS1_PAUSE		0x0080
#define PHY_SGMII_DEV_ABILITY_PS2_ASM_DIR	0x0100

#define PHY_SGMII_DEV_ABILITY_1000X     (PHY_SGMII_DEV_ABILITY_FD | PHY_SGMII_DEV_ABILITY_PS1_PAUSE | PHY_SGMII_DEV_ABILITY_PS2_ASM_DIR)

#define PHY_SGMII_IF_MODE_AN            0x0002 //USE_SGMII_AN
#define PHY_SGMII_IF_MODE_SGMII         0x0001 //SGMII_EN
#define PHY_SGMII_IF_MODE_SPEED_1G		0x0008 //SGMII_SPEED
#define PHY_SGMII_IF_MODE_DUPLEX_HALF	0x0010 //SGMII_DUPLEX
#define PHY_SGMII_IF_MODE_1000X         0x0000

/*----------------------------------------------------*/
/* MII Configuration Control Memory Map Registers     */
/*----------------------------------------------------*/
struct memac_mii_access_mem_map {
	uint32_t   mdio_cfg;       /* 0x030  */
	uint32_t   mdio_ctrl;      /* 0x034  */
	uint32_t   mdio_data;      /* 0x038  */
	uint32_t   mdio_addr;      /* 0x03c  */
};

int eiop_memac_mii_read_phy_reg(struct memac_mii_access_mem_map *mii_regs,
                                uint8_t phy_addr, uint32_t reg, uint16_t *data,
                                int clause);

int eiop_memac_mii_write_phy_reg(struct memac_mii_access_mem_map *mii_regs,
                                 uint8_t phy_addr, uint32_t reg, uint16_t data,
                                 int clause);

void eiop_memmac_set_pause_tresh( struct eiop_memac_desc *desc );

#endif /*__FSL_EIOP_MEMAC_H */

