/*
 * Copyright 2013-2020 NXP
 */

#ifndef FSL_DPPOLICY_H_
#define FSL_DPPOLICY_H_

#include "fsl_types.h"
#include "fsl_net.h"

#define DPPOLICY_MAX_NUM_OF_CLASSIFIERS				    8
#define DPPOLICY_RULE_MAX_NUM_OF_IDENTIFIERS			64
#define DPPOLICY_MAX_NUM_OF_IDs							0xfff

/**************************************************************************//**
 @Description    Policy Action Type

 Enumeration type defining the flow by selecting the next
 action under certain conditions

 *//***************************************************************************/

#define DPPOLICY_ACTION_SET_POLICER_ID     					0x80000000
#define DPPOLICY_ACTION_SET_QOS_MAP_METHOD  				0x40000000
#define DPPOLICY_ACTION_SET_QPRI          					0x20000000
#define DPPOLICY_ACTION_SET_IFP_ID         					0x10000000
#define DPPOLICY_ACTION_SET_HASH_KID      					0x00800000
#define DPPOLICY_ACTION_SET_DISCARD_FLAG   					0x00400000
#define DPPOLICY_ACTION_CLEAR_DISCARD_FLAG  				0x00200000
#define DPPOLICY_ACTION_SET_QDID          					0x00080000
#define DPPOLICY_ACTION_SET_QDBIN         					0x00040000

#define DPPOLICY_ACTION_SET_FLC_FOR_AIOP  					0x08000000
#define DPPOLICY_ACTION_SET_REPLIC_ID 						0x04000000
#define DPPOLICY_ACTION_SET_OPAQUE							0x02000000

#define DPPOLICY_ACTION_SET_STASHING_CNTRL						0x00008000
#define DPPOLICY_ACTION_SET_CONTEXT_IOMMU_BYPASS 			0x00002000


// if none of these are selected, FLCV bit is cleared, check that FLC is not overridden




enum dppolicy_next_action {
    DPPOLICY_ACTION_LOOKUP,
    DPPOLICY_ACTION_DONE
};

enum dppolicy_qos_map_method {
	DPPOLICY_ACTION_QoS_BASED_ON_VLAN_PRI,
	DPPOLICY_ACTION_QoS_BASED_ON_IP_DSCP,
};

/**< NOTE :
 *   1. next_action = DPPOLICY_ACTION_DISCARD
 *   	a) the rest of the parameters are irrelevant.
 *
 *   2. next_action = DPPOLICY_ACTION_DONE
*
*	CAUTION : if on the frame way one of the actions was defined
*	with options  DPPOLICY_ACTION_SET_FLC_REPLIC_ID or
*	DPPOLICY_ACTION_SET_FLC_FOR_AIOP set, and after that another action was defined
*	with options DPPOLICY_ACTION_SET_FLC_OPAQUE set -
*	the defines : DPPOLICY_ACTION_SET_FLC_REPLIC_ID or DPPOLICY_ACTION_SET_FLC_FOR_AIOP are
*	cancelled and this action will not be executed.
 *
 *    	CAUTION : if on the frame way one of the actions was defined
*	with next_action = DPPOLICY_ACTION_DONE it can not be redefined
*	on the rest of the same way as DPPOLICY_ACTION_LOOKUP.
*
 *   3. next_action = DPPOLICY_ACTION_LOOKUP
 *   	a) action_specific = lookup should be initialized by user.
 *   	b) allowed DPPOLICY_ACTION_OVERRIDE_REPLIC_ID || DPPOLICY_ACTION_OVERRIDE_FLC
 *   	a) Allowed flc_type: DPPOLICY_FLC_FOR_AIOP
 *   	(relevant if DPPOLICY_ACTION_OVERRIDE_FLC set)
 *
 *   4. options :
 *   	Forbidden combination/settings :
 *   		a) (DPPOLICY_ACTION_SET_QDID && DPPOLICY_ACTION_SET_QDBIN)
 *   		b) (DPPOLICY_ACTION_SET_FLC_FOR_AIOP &&
 *   			DPPOLICY_ACTION_SET_FLC_REPLIC_ID)
 *   		c) (DPPOLICY_ACTION_SET_HASH_KID && DPPOLICY_ACTION_SET_QDBIN)
 */
struct dppolicy_action {
      enum dppolicy_next_action   next_action;
      uint32_t                    options;
      int                    dppolicer_profile_id;
      /**< relevant if
	override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_DPPLCR_ID*/
      enum dppolicy_qos_map_method    qos_map_method;
      /**< relevant if
       * override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_QoS_MAP -
                                              2 bits*/
      int                     qpri;
      /**< relevant if
       * override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_QoS_MAP -
                                              4 bits*/
      int                    ifp_id;
      /**< relevant if
       * override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_IFPID -
                                              12 bits*/
     int                     hash_dpkg_profile_id;
     /**< relevant if
      * override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_HASH_KID -
                                              1 byte*/
     int                     qd_id;
     /**< relevant if
      * override_mask |= DPPOLICY_ACTION_MASK_OVERRIDE_QDID -
                                              2 bytes*/

     int   		qd_bin;	//only for done without replic/qdid



     int 			  replic_id;
     /**< relevant if
      * override_mask |= DPPOLICY_ACTION_OVERRIDE_REPLIC_ID -
                                              2 bytes*/

     uint64_t opaque;
     // for lookup or (done with replic/aiop), only 2 LSBytes will be set (not expected to reach GPP end-user)
     // for (done without replic/aiop), 8 bytes will be set (possibly goes to GPP end user)

     // replic_id overlaps the 8 bytes opaque in the FLC, therefore setting replic_id overrides any previous large opaque.

    struct {
	     int 	dptbl_id;
	     int 	dpkg_profile_id;
     } lookup_params;

};


/**************************************************************************//**
 @Description    Policy identifier

 Defines the possible types of Policy identifier

 *//***************************************************************************/
enum dppolicy_identifier_type {
	DPPOLICY_IDENTIFIER_PROT, /**< The identifier is a protocol */
	DPPOLICY_IDENTIFIER_PROT_OPT,
	/**< The identifier is a protocol option */
	DPPOLICY_IDENTIFIER_PROT_PRS_ERR,
	/**< The identifier is a specific protocol
	 parse error */
	DPPOLICY_IDENTIFIER_GEN_PRS_ERR,
/**< The identifier is a general
 parse error (any error) */
	DPPOLICY_IDENTIFIER_L2_UNRECOGNIZED_PROT,
	DPPOLICY_IDENTIFIER_L3_UNRECOGNIZED_PROT,
	DPPOLICY_IDENTIFIER_L4_UNRECOGNIZED_PROT

};

/**************************************************************************//**
 @Description    Policy rule identifier

 This structure hold the parameters needed to define a single
 classification rule.

 *//***************************************************************************/
struct identifier {
	int exclude;
	/**< 0 : rule will be active when frame contains the identifier,
	 1 : rule will be active when frame does not contain the identifier.*/
	enum dppolicy_identifier_type type;
	/**< Type of identifier,
	 also determines which of the following
	 parameters should be initialized:
	 DPPOLICY_IDENTIFIER_PROT: set "prot" and
	 "hdr_index" when applicable;
	 DPPOLICY_IDENTIFIER_PROT_OPT: set
	 "prot", "prot_opt" and "hdr_index" when
	 applicable;
	 DPPOLICY_IDENTIFIER_PROT_PRS_ERR: set
	 "prot" and "hdr_index" when applicable;
	 DPPOLICY_IDENTIFIER_GEN_PRS_ERR: No
	 parameters required. */
	enum net_prot prot;
	/**< One of the headers supported by CTLU;
	 Must be set for all "type"s but
	 DPPOLICY_IDENTIFIER_GEN_PRS_ERR*/
	uint32_t opt;
	/**< Option (one of NH_OPT_) must match prot;
	 Should only be set for
	 DPPOLICY_IDENTIFIER_PROT_OPT*/
	uint8_t hdr_index;
/**< Clear for cases not listed below;
 Used for protocols that may have more
 than a single header, 0 indicates
 outer header;
 Supported protocols (possible values):
 NET_PROT_VLAN (0, HDR_INDEX_LAST);
 NET_PROT_MPLS (0, HDR_INDEX_LAST);
 NET_PROT_IP(0, HDR_INDEX_LAST);
 NET_PROT_IPv4(0, HDR_INDEX_LAST);
 NET_PROT_IPv6(0, HDR_INDEX_LAST);
 */
};

/**************************************************************************//**
 @Description    Policy rule identifier

 This structure hold the parameters needed to define a single
 classification rule.

 *//***************************************************************************/
struct dppolicy_rule {
	int priority;
	/**< logical, relative to Policy; 0 is lowest;
	 This priority can not change during the
	 lifetime of a Policy. It is user
	 responsibility to space the priorities
	 according to consequent rule additions. */
	int num_of_identifiers;
	/**< Number of identifiers, defines the size
	 of the array below */
	struct identifier identifiers[DPPOLICY_RULE_MAX_NUM_OF_IDENTIFIERS];
};

/**************************************************************************//**
 @Description    Policy Init Parameters

 This structure hold the parameters needed to define a Policy

 *//***************************************************************************/
struct dppolicy_cfg {
	uint16_t max_num_of_rules; /**< The total number of
	 classification rules at any
	 given time during the lifetime
	 of the Policy. */
};

/**************************************************************************//**
 @Description   A structure for defining Policy global parameters
 *//***************************************************************************/
struct dppolicy_mng_cfg {
	struct ctlu *ctlu; /* TODO */
	int num_dppolicy_entries;
};

struct dppolicy_mng;

/**************************************************************************//**
 @Function      dppolicy_mng_init

 @Description  	This function initializes the Policy Manager module.

 @Param[in]    	cfg   		- Policy Manager parameters structure

 @Retval        A handle to the Policy Manager object
 *//**************************************************************************/
struct dppolicy_mng *dppolicy_mng_init(const struct dppolicy_mng_cfg *cfg);

/**************************************************************************//**
 @Function     	dppolicy_mng_done

 @Description  	This function deleted all initializations associated
               	with the Policy Manager object

 @Param[in]    	dppolicy_mng   - A handle to the Policy Manager object as returned by the
 	 	 	         dppolicy_mng_alloc routine

 @Retval        None
 *//**************************************************************************/
void dppolicy_mng_done(struct dppolicy_mng *dppolicy_mng);




struct dppolicy;
/**************************************************************************//**
 @Function      dppolicy_init

 @Description   Create a new empty Policy

 @Param[in]     dppolicy_id 	- id of the Policy
 @Param[in]     params 			- A structure of parameters for creating a new Policy

 @Return       TBD

 *//***************************************************************************/
struct dppolicy* dppolicy_init	(struct dppolicy_mng *dppolicy_mng,
                                 int dppolicy_id,
                                 const struct dppolicy_cfg *cfg);

/**************************************************************************//**
 @Function      dppolicy_done

 @Description   Deletes an existing Policy

 @Param[in]     dppolicy 		- A handle to the initialized Policy

 @Return        0 on Success; error code otherwise.

 *//***************************************************************************/
int dppolicy_done(struct dppolicy* dppolicy);

/**************************************************************************//**
 @Function      dppolicy_add_rule

 @Description

 @Param[in]     dppolicy 		- A handle to the initialized Policy
 @Param[in]     rule 	        - A structure of parameters for describing
 the required classifier
 @Param[in]     action 	    	- A structure of parameters for describing
 the action to be executed for this rule

 @Return        0 on Success; error code otherwise.

 *//***************************************************************************/
int dppolicy_add_rule(struct dppolicy* dppolicy,
                      const struct dppolicy_rule *rule,
                      const struct dppolicy_action *action,
                      int restore);

/**************************************************************************//**
 @Function      dppolicy_modify_rule

 @Description   Change the action of the specified rule

 @Param[in]     dppolicy 		- A handle to the initialized Policy
 @Param[in]     rule 	        - A structure of parameters for describing
 the required classifier
 @Param[in]     new_action 	    - A structure of parameters for describing
 the new action to replace the current one

 @Return        0 on Success; error code otherwise.

 *//***************************************************************************/
int dppolicy_modify_rule(struct dppolicy *dppolicy,
                         const struct dppolicy_rule *rule,
                         const struct dppolicy_action *new_action);

/**************************************************************************//**
 @Function      dppolicy_remove_rule

 @Description

 @Param[in]     dppolicy 		- A handle to the initialized Policy
 @Param[in]     rule 	        - A structure of parameters for describing
 the required classifier

 @Return        0 on Success; error code otherwise.

 *//***************************************************************************/
int dppolicy_remove_rule(struct dppolicy *dppolicy,
                         const struct dppolicy_rule *rule);

int dppolicy_move_rule(struct dppolicy *dppolicy,
                       const int old_priority, const int new_priority);

int dppolicy_rule_check_cfg(struct dppolicy* dppolicy,
							const struct dppolicy_rule 	*rule,
							const struct dppolicy_action *action);


#endif /* FSL_DPPOLICY_H_ */
