/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_EIOP_H
#define __FSL_EIOP_H

#include "fsl_types.h"

#define EIOP_DESC_OPT_NO_L2SW	0x80000000

// 	FCEAD[UPD] bit is managed by the driver and must not be modified inside MC
#define EIOP_DESC_UPDATE_FCEAD_UPD		0x00000001

// Create a 16bit word containing WRIOP version
#define WRIOP_VERSION(X, Y, Z)		( ((X)<<10) | ((Y)<<5) | ((Z)<<0) )

struct eiop_desc {
	int disable;
	int eiop_id;
	uint32_t options;
	phys_addr_t paddr;
	void *vaddr;
	int irq;
	int irq_rec_err;
	uint32_t flags;
	uint16_t wriop_version;
};


/**************************************************************************//**
 @Description   FCEAD
*//***************************************************************************/
struct eiop_fcead {
    volatile uint32_t	command1;
    volatile uint32_t	command2;
};

/**************************************************************************//**
 @Collection   FCEAD macros
*//***************************************************************************/
#define EIOP_FCEAD_IFPID_MASK	0x0fff0000
#define EIOP_FCEAD_FHO_MASK	0x00000080
#define EIOP_FCEAD_EBDD_MASK	0x00000020
#define EIOP_FCEAD_UPD_MASK	0x00000010
#define EIOP_FCEAD_FQIDT_MASK	0x00000008
#define EIOP_FCEAD_ESTD_MASK	0x00000004
#define EIOP_FCEAD_L3CSG_MASK	0x00000002
#define EIOP_FCEAD_L4CSG_MASK	0x00000001
#define EIOP_FCEAD_FQID_MASK	0x00ffffff

#define EIOP_FCEAD_IFPID_SHIFT	(31-15)
#define EIOP_FCEAD_FHO_SHIFT	(31-24)
#define EIOP_FCEAD_EBDD_SHIFT	(31-26)
#define EIOP_FCEAD_UPD_SHIFT	(31-27)
#define EIOP_FCEAD_FQIDT_SHIFT	(31-28)
#define EIOP_FCEAD_ESTD_SHIFT	(31-29)
#define EIOP_FCEAD_L3CSG_SHIFT	(31-30)
#define EIOP_FCEAD_L4CSG_SHIFT	(31-31)
#define EIOP_FCEAD_FQID_SHIFT	(31-31)

#define EIOP_FCEAD_GET_IFPID(fcead)	\
	((((struct eiop_fcead *)fcead)->command1 \
		& EIOP_FCEAD_IFPID_MASK) >> EIOP_FCEAD_IFPID_SHIFT)
#define EIOP_FCEAD_GET_FHO(fcead)	\
	((((struct eiop_fcead *)fcead)->command1 \
		& EIOP_FCEAD_FHO_MASK) >> EIOP_FCEAD_FHO_SHIFT)
#define EIOP_FCEAD_GET_EBDD(fcead)	\
	((((struct eiop_fcead *)fcead)->command1 \
		& EIOP_FCEAD_EBDD_MASK) >> EIOP_FCEAD_EBDD_SHIFT)
#define EIOP_FCEAD_GET_UPD(fcead)	\
	((((struct eiop_fcead *)fcead)->command1 \
		& EIOP_FCEAD_UPD_MASK) >> EIOP_FCEAD_UPD_SHIFT)
#define EIOP_FCEAD_GET_FQIDT(fcead)	\
	((((struct eiop_fcead *)fcead)->command1 \
		& EIOP_FCEAD_FQIDT_MASK) >> EIOP_FCEAD_FQIDT_SHIFT)
#define EIOP_FCEAD_GET_ESTD(fcead)	\
	((((struct eiop_fcead *)fcead)->command1 \
		& EIOP_FCEAD_ESTD_MASK) >> EIOP_FCEAD_ESTD_SHIFT)
#define EIOP_FCEAD_GET_L3CSG(fcead)	\
	((((struct eiop_fcead *)fcead)->command1 \
		& EIOP_FCEAD_L3CSG_MASK) >> EIOP_FCEAD_L3CSG_SHIFT)
#define EIOP_FCEAD_GET_L4CSG(fcead)	\
	((((struct eiop_fcead *)fcead)->command1 \
		& EIOP_FCEAD_L4CSG_MASK) >> EIOP_FCEAD_L4CSG_SHIFT)
#define EIOP_FCEAD_GET_FQID(fcead)	\
	((((struct eiop_fcead *)fcead)->command2 \
		& EIOP_FCEAD_FQID_MASK) >> EIOP_FCEAD_FQID_SHIFT)

#define EIOP_FCEAD_SET_IFPID(fcead, val)	\
	(((struct eiop_fcead *)fcead)->command1 = \
	(uint32_t)((((struct eiop_fcead *)fcead)->command1 &	\
	~EIOP_FCEAD_IFPID_MASK) |	\
	(((uint32_t)(val) << EIOP_FCEAD_IFPID_SHIFT) & EIOP_FCEAD_IFPID_MASK)))

#define EIOP_FCEAD_SET_FHO(fcead, val)	\
	(((struct eiop_fcead *)fcead)->command1 = \
	(uint32_t)((((struct eiop_fcead *)fcead)->command1 &	\
	~EIOP_FCEAD_FHO_MASK) |	\
	(((uint32_t)(val) << EIOP_FCEAD_FHO_SHIFT) & EIOP_FCEAD_FHO_MASK)))

#define EIOP_FCEAD_SET_EBDD(fcead, val)	\
	(((struct eiop_fcead *)fcead)->command1 = \
	(uint32_t)((((struct eiop_fcead *)fcead)->command1 &	\
	~EIOP_FCEAD_EBDD_MASK) |	\
	(((uint32_t)(val) << EIOP_FCEAD_EBDD_SHIFT) & EIOP_FCEAD_EBDD_MASK)))

#define EIOP_FCEAD_SET_UPD(fcead, val)	\
	(((struct eiop_fcead *)fcead)->command1 = \
	(uint32_t)((((struct eiop_fcead *)fcead)->command1 &	\
	~EIOP_FCEAD_UPD_MASK) |	\
	(((uint32_t)(val) << EIOP_FCEAD_UPD_SHIFT) & EIOP_FCEAD_UPD_MASK)))

#define EIOP_FCEAD_SET_FQIDT(fcead, val)	\
	(((struct eiop_fcead *)fcead)->command1 = \
	(uint32_t)((((struct eiop_fcead *)fcead)->command1 &	\
	~EIOP_FCEAD_FQIDT_MASK) |	\
	(((uint32_t)(val) << EIOP_FCEAD_FQIDT_SHIFT) & EIOP_FCEAD_FQIDT_MASK)))

#define EIOP_FCEAD_SET_ESTD(fcead, val)	\
	(((struct eiop_fcead *)fcead)->command1 = \
	(uint32_t)((((struct eiop_fcead *)fcead)->command1 &	\
	~EIOP_FCEAD_ESTD_MASK) |	\
	(((uint32_t)(val) << EIOP_FCEAD_ESTD_SHIFT) & EIOP_FCEAD_ESTD_MASK)))

#define EIOP_FCEAD_SET_L3CSG(fcead, val)	\
	(((struct eiop_fcead *)fcead)->command1 = \
	(uint32_t)((((struct eiop_fcead *)fcead)->command1 &	\
	~EIOP_FCEAD_L3CSG_MASK) |	\
	(((uint32_t)(val) << EIOP_FCEAD_L3CSG_SHIFT) & EIOP_FCEAD_L3CSG_MASK)))

#define EIOP_FCEAD_SET_L4CSG(fcead, val)	\
	(((struct eiop_fcead *)fcead)->command1 = \
	(uint32_t)((((struct eiop_fcead *)fcead)->command1 &	\
	~EIOP_FCEAD_L4CSG_MASK) |	\
	(((uint32_t)(val) << EIOP_FCEAD_L4CSG_SHIFT) & EIOP_FCEAD_L4CSG_MASK)))

#define EIOP_FCEAD_SET_FQID(fcead, val)	\
	(((struct eiop_fcead *)fcead)->command2 = \
	(uint32_t)((((struct eiop_fcead *)fcead)->command2 &	\
	~EIOP_FCEAD_FQID_MASK) |	\
	(((uint32_t)(val) << EIOP_FCEAD_FQID_SHIFT) & EIOP_FCEAD_FQID_MASK)))
/* @} */

/**************************************************************************//**
 @Description   FAEAD
*//***************************************************************************/
struct eiop_faead {
    volatile uint32_t	command1;
    volatile uint32_t	command2;
};

/**************************************************************************//**
 @Collection   FAEAD macros
*//***************************************************************************/
#define EIOP_FAEAD_A2V_MASK	0x20000000
#define EIOP_FAEAD_A4V_MASK	0x08000000

#define EIOP_FAEAD_EBDDV_MASK	0x00002000
#define EIOP_FAEAD_UPDV_MASK	0x00001000
#define EIOP_FAEAD_FQIDTV_MASK	0x00000800
#define EIOP_FAEAD_ESTDV_MASK	0x00000400
#define EIOP_FAEAD_L3CSGV_MASK	0x00000200
#define EIOP_FAEAD_L4CSGV_MASK	0x00000100

#define EIOP_FAEAD_EBDDV_SHIFT	(31-18)
#define EIOP_FAEAD_UPDV_SHIFT	(31-19)
#define EIOP_FAEAD_FQIDTV_SHIFT	(31-20)
#define EIOP_FAEAD_ESTDV_SHIFT	(31-21)
#define EIOP_FAEAD_L3CSGV_SHIFT	(31-22)
#define EIOP_FAEAD_L4CSGV_SHIFT	(31-23)

#define EIOP_FAEAD_GET_A2V(faead)	\
	((((struct eiop_faead *)faead)->command1 \
		& EIOP_FAEAD_A2V_MASK) >> EIOP_FAEAD_A2V_SHIFT)
#define EIOP_FAEAD_GET_A4V(faead)	\
	((((struct eiop_faead *)faead)->command1 \
		& EIOP_FAEAD_A4V_MASK) >> EIOP_FAEAD_A4V_SHIFT)
#define EIOP_FAEAD_GET_EBDDV(faead)	\
	((((struct eiop_faead *)faead)->command1 \
		& EIOP_FAEAD_EBDDV_MASK) >> EIOP_FAEAD_EBDDV_SHIFT)
#define EIOP_FAEAD_GET_UPDV(faead)	\
	((((struct eiop_faead *)faead)->command1 \
		& EIOP_FAEAD_UPDV_MASK) >> EIOP_FAEAD_UPDV_SHIFT)
#define EIOP_FAEAD_GET_FQIDTV(faead)	\
	((((struct eiop_faead *)faead)->command1 \
		& EIOP_FAEAD_FQIDTV_MASK) >> EIOP_FAEAD_FQIDTV_SHIFT)
#define EIOP_FAEAD_GET_ESTDV(faead)	\
	((((struct eiop_faead *)faead)->command1 \
		& EIOP_FAEAD_ESTDV_MASK) >> EIOP_FAEAD_ESTDV_SHIFT)
#define EIOP_FAEAD_GET_L3CSGV(faead)	\
	((((struct eiop_faead *)faead)->command1 \
		& EIOP_FAEAD_L3CSGV_MASK) >> EIOP_FAEAD_L3CSGV_SHIFT)
#define EIOP_FAEAD_GET_L4CSGV(faead)	\
	((((struct eiop_faead *)faead)->command1 \
		& EIOP_FAEAD_L4CSGV_MASK) >> EIOP_FAEAD_L4CSGV_SHIFT)
#define EIOP_FAEAD_GET_EBDD(faead) EIOP_FCEAD_GET_EBDD(faead)
#define EIOP_FAEAD_GET_UPD(faead) EIOP_FCEAD_GET_UPD(faead)
#define EIOP_FAEAD_GET_FQIDT(faead) EIOP_FCEAD_GET_FQIDT(faead)
#define EIOP_FAEAD_GET_ESTD(faead) EIOP_FCEAD_GET_ESTD(faead)
#define EIOP_FAEAD_GET_L3CSG(faead) EIOP_FCEAD_GET_L3CSG(faead)
#define EIOP_FAEAD_GET_L4CSG(faead) EIOP_FCEAD_GET_L4CSG(faead)
#define EIOP_FAEAD_GET_FQID(faead) EIOP_FCEAD_GET_FQID(faead)

#define EIOP_FAEAD_SET_A2V(faead, val)	\
	(((struct eiop_faead *)faead)->command1 = \
	(uint32_t)((((struct eiop_faead *)faead)->command1 &	\
	~EIOP_FAEAD_A2V_MASK) |	\
	(((uint32_t)(val) << EIOP_FAEAD_A2V_SHIFT) & EIOP_FAEAD_A2V_MASK)))

#define EIOP_FAEAD_SET_A4V(faead, val)	\
	(((struct eiop_faead *)faead)->command1 = \
	(uint32_t)((((struct eiop_faead *)faead)->command1 &	\
	~EIOP_FAEAD_A4V_MASK) |	\
	(((uint32_t)(val) << EIOP_FAEAD_A4V_SHIFT) & EIOP_FAEAD_A4V_MASK)))

#define EIOP_FAEAD_SET_EBDDV(faead, val)	\
	(((struct eiop_faead *)faead)->command1 = \
	(uint32_t)((((struct eiop_faead *)faead)->command1 &	\
	~EIOP_FAEAD_EBDDV_MASK) |	\
	(((uint32_t)(val) << EIOP_FAEAD_EBDDV_SHIFT) & EIOP_FAEAD_EBDDV_MASK)))

#define EIOP_FAEAD_SET_UPDV(faead, val)	\
	(((struct eiop_faead *)faead)->command1 = \
	(uint32_t)((((struct eiop_faead *)faead)->command1 &	\
	~EIOP_FAEAD_UPDV_MASK) |	\
	(((uint32_t)(val) << EIOP_FAEAD_UPDV_SHIFT) & EIOP_FAEAD_UPDV_MASK)))

#define EIOP_FAEAD_SET_FQIDTV(faead, val)	\
	(((struct eiop_faead *)faead)->command1 = \
	(uint32_t)((((struct eiop_faead *)faead)->command1 &	\
	~EIOP_FAEAD_FQIDTV_MASK) |	\
	(((uint32_t)(val) << EIOP_FAEAD_FQIDTV_SHIFT) & EIOP_FAEAD_FQIDTV_MASK)))

#define EIOP_FAEAD_SET_ESTDV(faead, val)	\
	(((struct eiop_faead *)faead)->command1 = \
	(uint32_t)((((struct eiop_faead *)faead)->command1 &	\
	~EIOP_FAEAD_ESTDV_MASK) |	\
	(((uint32_t)(val) << EIOP_FAEAD_ESTDV_SHIFT) & EIOP_FAEAD_ESTDV_MASK)))

#define EIOP_FAEAD_SET_L3CSGV(faead, val)	\
	(((struct eiop_faead *)faead)->command1 = \
	(uint32_t)((((struct eiop_faead *)faead)->command1 &	\
	~EIOP_FAEAD_L3CSGV_MASK) |	\
	(((uint32_t)(val) << EIOP_FAEAD_L3CSGV_SHIFT) & EIOP_FAEAD_L3CSGV_MASK)))

#define EIOP_FAEAD_SET_L4CSGV(faead, val)	\
	(((struct eiop_faead *)faead)->command1 = \
	(uint32_t)((((struct eiop_faead *)faead)->command1 &	\
	~EIOP_FAEAD_L4CSGV_MASK) |	\
	(((uint32_t)(val) << EIOP_FAEAD_L4CSGV_SHIFT) & EIOP_FAEAD_L4CSGV_MASK)))

#define EIOP_FAEAD_SET_EBDD(faead, val)	EIOP_FCEAD_SET_EBDD(faead, val)
#define EIOP_FAEAD_SET_UPD(faead, val) EIOP_FCEAD_SET_UPD(faead, val)
#define EIOP_FAEAD_SET_FQIDT(faead, val) EIOP_FCEAD_SET_FQIDT(faead, val)
#define EIOP_FAEAD_SET_ESTD(faead, val) EIOP_FCEAD_SET_ESTD(faead, val)
#define EIOP_FAEAD_SET_L3CSG(faead, val) EIOP_FCEAD_SET_L3CSG(faead, val)
#define EIOP_FAEAD_SET_L4CSG(faead, val) EIOP_FCEAD_SET_L4CSG(faead, val)
#define EIOP_FAEAD_SET_FQID(faead, val) EIOP_FCEAD_SET_FQID(faead, val)

/* @} */

/**************************************************************************//**
 @Description   enum for defining EIOP Exceptions
*//***************************************************************************/

enum eiop_exceptions {
	E_EIOP_SYSTEM_BUS_ERROR = 0,
	E_EIOP_STALL_EVENT = 1,
};


/**************************************************************************//**
 @Description   Debug
*//***************************************************************************/
struct eiop_debug_dynamic_match {
	int id;
	int mask;
};

#define EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_IFP_MATCH 		0x80000000
#define EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_QDID_MATCH 		0x40000000
#define EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_QPRI_MATCH 		0x20000000
#define EIOP_DEBUG_DYNAMIC_RULE_OPT_DST_QDBIN_MATCH 	0x10000000
#define EIOP_DEBUG_DYNAMIC_RULE_OPT_BPID_MATCH 			0x08000000
#define EIOP_DEBUG_DYNAMIC_RULE_OPT_CONF_FQID_MATCH 	0x04000000
#define EIOP_DEBUG_DYNAMIC_RULE_OPT_DEQ_FD_DD_MATCH 	0x02000000

struct eiop_debug_dynamic_rule {
	uint32_t options;
	struct eiop_debug_dynamic_match dst_ifp;
	struct eiop_debug_dynamic_match dst_qdid;
	struct eiop_debug_dynamic_match dst_bpid;
	struct eiop_debug_dynamic_match dst_qpri;
	struct eiop_debug_dynamic_match dst_qdbin;
	struct eiop_debug_dynamic_match conf_fqid;
	struct eiop_debug_dynamic_match deq_fd_dd;
	
};

#define EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_INGR	 				 0x80000000
#define EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_INGR_ORED_WITH_FD_DD	 0x40000000
#define EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_EGGR	 				 0x20000000
#define EIOP_DEBUG_DYNAMIC_ACTION_OPT_FRM_MARK_EGGR_ORED_WITH_FD_DD	 0x10000000


#define EIOP_DEBUG_DYNAMIC_ACTION_OPT_CTLU_DEBUG_TRACE_INGR	 		 0x08000000
#define EIOP_DEBUG_DYNAMIC_ACTION_OPT_DEBUG_TRACE_INGR	 			 0x04000000
#define EIOP_DEBUG_DYNAMIC_ACTION_OPT_DEBUG_TRACE_EGGR	 			 0x02000000
#define EIOP_DEBUG_DYNAMIC_ACTION_DEBUG_TRACE		 				 0x01000000

struct eiop_debug_dynamic_action {
	uint32_t options;
	uint8_t ctlu_ingr_mark;
	uint8_t ingr_mark;
	uint8_t ctlu_eggr_mark;
	uint8_t eggr_mark;
};


struct eiop_debug_dynamic_cfg {
	struct eiop_debug_dynamic_rule rule;
	struct eiop_debug_dynamic_action action;
};

#define EIOP_DEBUG_OPTIONS_SET_DYNAMIC_DEBUG 0x80000000
struct eiop_debug_cfg {
	uint32_t options;
	struct eiop_debug_dynamic_cfg debug_dynamic_cfg;
};
/**************************************************************************//**
 @Description   A structure for defining eiop parameters which updated by
                driver by default values and can be modified by user after
                calling eiop_defconfig before eiop_init

*//***************************************************************************/
struct eiop_cfg {
/*NOTE - take care what entity is doing allocation*/
	uint64_t temp_pfc_buffer;
	uint16_t temp_pfc_icid;
};

/**************************************************************************//**
 @Function      eiop_temp_pfc_buffer_restore

 @Description   Restores PFC buffers after WRIOP reset.

 @Param[in]     eiop_desc - Pointer to the descriptor
				cfg -  Pointer to data structure of
					parameters which was passed to
					eiop_config and optionally was
                              		modified by user.

 @Return        Error code.
*//***************************************************************************/
int eiop_temp_pfc_buffer_restore( struct eiop_desc *eiop_desc, struct eiop_cfg *cfg);

/**************************************************************************//**
 @Function      eiop_init

 @Description   Configuring the EIOP module hardware registers.

 @Param[in]     regs - 			Pointer to the area of specific
 					EIOP register location
		cfg -  		Pointer to data structure of
					parameters which was passed to
					eiop_config and optionally was
                              		modified by user.

 @Return        int
*//***************************************************************************/
int eiop_init( struct eiop_desc *eiop_desc, struct eiop_cfg *cfg);

/**************************************************************************//**
 @Function      eiop_get_revision

 @Description   return values for registers IOP_IP_REV_1 and IOP_IP_REV_2

 @Return        int
*//***************************************************************************/
int eiop_get_revision(int eiop_id, uint32_t *rev1, uint32_t *rev2);

#ifdef TKT508412
/**************************************************************************//**
 @Function      eiop_get_revision

 @Description   check if this platform need fix for TKT508412

 @Return        int
*//***************************************************************************/
int eiop_wriop_apply_TKT508412_fix(void);
#endif
/**************************************************************************//**
 @Function      eiop_set_exceptions

 @Description   Define EIOP exceptions.

 @Param[in]     regs - 			Pointer to the area of specific
 					EIOP register location
		exception -  		Specific exception

		enable - 		Enable (TRUE) or disable (FALSE)

 @Return        int
*//***************************************************************************/
int eiop_set_exceptions(struct eiop_desc *eiop_desc, enum eiop_exceptions exception, int enable);

void eiop_force_exceptions(struct eiop_desc *eiop_desc, enum eiop_exceptions exception);

int eiop_get_temp_pfc_buffer_size(void);


int eiop_set_debug (struct eiop_desc *eiop_desc, struct eiop_debug_cfg *debug_cfg);

int eiop_reset(void);

#define EIOP_CGP_CONGESTION_GROUP  0
#define EIOP_CGP_BUFFER_DEPLETION  1

struct eiop_cgp {
	char type; /* << one of the EIOP_PORT_CGP_ values */
	uint16_t id; /* << CG ID or BP ID */
	uint8_t bits; /* << priority bits.. */
};

void eiop_set_port_cgp(int eiop_id, int port_id, struct eiop_cgp *cgp, int cmd);

#endif /* __FSL_EIOP_H */
