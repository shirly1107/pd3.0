/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DCFG_H
#define __FSL_DCFG_H

#include "fsl_types.h"
#include "fsl_gen.h"

/* Maximum number of Ethernet Controllers - driving RGMII interfaces */
#define MAX_EC_CFG	2

/* Maximum number of Serdes protocols */
#define MAX_SD_CFG	3

struct dcfg_desc {
		uint8_t sys_clk_rcwsr_id;
		uint32_t sys_clk_rcwsr_mask;

		uint8_t sys_pll_rat_rcwsr_id;
		uint32_t sys_pll_rat_rcwsr_mask;

		uint32_t svr_sec_disable_mask;
		uint32_t svr_aiop_disable_mask;

		void *vaddr;

		/* Clock divider */
		uint8_t sys_clk_div;

		struct {
			int valid;
			uint8_t port_id;
			uint8_t rcwsr_id;
			uint32_t rcwsr_mask;
		} ec[MAX_EC_CFG];

		struct {
			int valid;
			uint8_t rcwsr_id;
			uint32_t rcwsr_mask;
		} sd[MAX_SD_CFG];
};

struct dcfg_device_info {
		uint32_t system_version;
		/*uint8_t manufactor_id;
		uint8_t family;
		uint8_t device_id;
		uint8_t personality;*/
		uint8_t major;
		uint8_t minor;
};

/*
 * SYSCLK in KHZ
 * SYSCLK feeds the Platform Clock
 */
uint32_t dcfg_get_sys_clk(void);

/*
 * Platform Clock in KHZ
 * Platform Clock feeds the System Clock
 */
uint32_t dcfg_get_platform_clk(void);

void dcfg_get_revision(uint8_t *major,
			uint8_t *minor,
	uint32_t *system_version);

void dcfg_get_proc_version(
	uint32_t *proc_version);

uint32_t dcfg_get_serdes_protocol(uint8_t rcwsr_id, uint32_t rcwsr_mask);

int dcfg_has_rgmii(struct dcfg_desc *dcfg_desc, int ec_index);
int dcfg_get_ec_pmux(struct dcfg_desc *dcfg_desc, int ec_index);

enum dcfg_disabled_devices {
	DCFG_DEVDIS_NONE = 0,
	DCFG_DEVDIS_DCE,
	DCFG_DEVDIS_SEC,
	DCFG_DEVDIS_PEBM,
	DCFG_DEVDIS_DPDDR,
	DCFG_DEVDIS_DDR,
	DCFG_DEVDIS_EIOP,
	DCFG_DEVDIS_AIOP,
	DCFG_DEVDIS_DUART,
	DCFG_DEVDIS_MAC,
	DCFG_DEVDIS_QBMAN,
	DCFG_DEVDIS_EDMA,
	DCFG_DEVDIS_QDMA,
	DCFG_DEVDIS_DBG
};

/* Returns 1 if module is disabled or unavailable.
 * Returns 0 if module is enabled. 
 * status is relevant only if module is available (0 returned) and indicates which 
 * instanciations of this module are disabled. */

int dcfg_is_unavailable(enum dcfg_disabled_devices dev, uint32_t *status);

#endif /* __FSL_DCFG_H */

