/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPKG_MC_H_
#define __FSL_DPKG_MC_H_

#include "fsl_types.h"
#include "fsl_net.h"

/*!
 * @Group grp_dpkg	DP Key Generator API
 *
 * @brief	Contains initialization APIs and runtime APIs for the
 * 		Key Generator
 * @{
 */

/*!
 * @name Key Generator properties
 */

/* TODO - remove, define and take from soc_db */
#define DPKG_MAX_NUM_OF_EXTRACTS_PER_KEY			64
/*!< Number of extraction per Key */
/* TODO - remove, take from soc_db */
#define DPKG_NUM_OF_MASKS					4
/*!< Number of profiles per CTLU Keygen */
/* TODO - remove, define and take from soc_db */
#define DPKG_MAX_NUM_OF_EXTRACTS				22
/*!< Number of extraction per Key */

#define DPKG_EXT_MAX_NUM_OF_EXTRACTS			20
/*!< Number of extraction per Key for DPNI*/
/* @} */

/**
 * @brief	A structure for defining Key generator general parameters
 */
struct dpkg_cfg {
	/* TODO */
	struct ctlu *ctlu; /*!< A handle to the CTLU module */
	int num_profiles; /*!< The number of available profiles */
};

struct dpkg;

/**
 * @brief  		This function restors DPKG after WRIOP reset
 *
 * @param[in]   dpkg- A handle to the Key generator object as
 *			  	  returned by the dpkg_init routine
 * @returns     Error code.
 */
int dpkg_restore(struct dpkg *dpkg);

/**
 * @brief  	This function initializes the Key generator module
 *
 * @param[in]   cfg	- Key generator parameters structure
 *
 * @returns     A handle to the Key generator object
 */
struct dpkg *dpkg_init(struct dpkg_cfg *cfg);

/**
 * @brief  	This function deleted all initializations associated
 *              with the Key generator object
 *
 * @param[in]   dpkg	- A handle to the Key generator object as returned by
 *			  the dpkg_init routine
 *
 * @returns     None
 */
void dpkg_done(struct dpkg *dpkg);

/**
 * @brief  	This function reads the counter of a profile
 *
 * @param[in]   dpkg		- A handle to the Key generator object as
 *			  	  returned by the dpkg_init routine
 * @param[in]   profile_id	- The profile to read the counter of
 *
 * @returns     Error code.
 */
int dpkg_get_counter(struct dpkg *dpkg, int profile_id);
void dpkg_set_counter(struct dpkg *dpkg, int profile_id, uint32_t val);
int dpkg_get_error(struct dpkg *dpkg, int profile_id);

/**
 * @brief	Enumeration type for selecting extraction by header types
 */
enum dpkg_extract_from_hdr_type {
	DPKG_FROM_HDR = 0, /*!< Extract bytes from header */
	DPKG_FROM_FIELD = 1, /*!< Extract bytes from header field */
	DPKG_FULL_FIELD = 2
/*!< Extract a full field */
};

/**
 * @brief	Enumeration type for selecting extraction source
 *              (when it is not DPKG_EXTRACT_FROM_CONTEXT )
 */
enum dpkg_extract_from_context_type {
	DPKG_FROM_PARSE_RESULT_SPECIFIC_PROTOCOL = 0, /*!< Extract from the Key generator result */
	DPKG_FROM_FCV = 1, /*!< TODO: Extract from the Key generator result */
	DPKG_FROM_IFP = 2,
	DPKG_FROM_FCV_L2SWITCH_FDB_SPECIFIC = 3,
	DPKG_FROM_FCV_FD_FLC_FOR_REPLIC_SRC_QDID = 4
/*!< TODO: Extract from enqueue FQID */
/* add logic context's */
};

/**
 * @brief	Enumeration type for selecting extraction type
 */
enum dpkg_extract_type {
	DPKG_EXTRACT_FROM_HDR = 0, /*!< Extract according to header */
	DPKG_EXTRACT_FROM_DATA = 1, /*!< Extract from data that is not the header */
	DPKG_EXTRACT_FROM_CONTEXT = 3, /*!< Extract from data that is not the header
	 */
	DPKG_EXTRACT_CONSTANT = 2
/*!< Extract private info as specified by user */
};

/**
 * @brief	A structure for defining a single extraction mask
 */
struct dpkg_mask {
	uint8_t mask; /*!< a byte mask for the extracted content */
	uint8_t offset; /*!< offset within the extracted content */
};

/**
 * @brief	A structure for defining a single extraction
 */
struct dpkg_extract {
	enum dpkg_extract_type type;
	/*!< Type may be one of the members of
	 enum: dpkg_extract_type;
	 type determines how the union
	 below will be interpreted:
	 DPKG_EXTRACT_FROM_HDR: select "from_hdr";
	 DPKG_EXTRACT_FROM_DATA: select
	 "from_data";
	 DPKG_EXTRACT_FROM_CONTEXT: select
	 "from_context";
	 DPKG_EXTRACT_CONSTANT: select constant. */
	union {
		struct {
			enum net_prot prot;
			/*!< One of the headers supported by CTLU */

			enum dpkg_extract_from_hdr_type type;
			/*!< Defines the type of header extraction:
			 DPKG_FROM_HDR: use size & offset
			 below;
			 DPKG_FROM_FIELD: use field, size
			 & offset below;
			 DPKG_FULL_FIELD: use field below
			 */

			uint32_t field;
			/*!< One of the supported fields (NH_FLD_) */
			uint8_t size; /*!< Size in byte */
			uint8_t offset; /*!< Byte offset */

			uint8_t hdr_index;
			/*!< Clear for cases not listed below;
			 Used for protocols that may have more
			 than a single header, 0 indicates
			 outer header;
			 Supported protocols (possible values):
			 NET_PROT_VLAN (0, HDR_INDEX_LAST);
			 NET_PROT_MPLS (0, 1, HDR_INDEX_LAST);
			 NET_PROT_IP(0, HDR_INDEX_LAST);
			 NET_PROT_IPv4(0, HDR_INDEX_LAST);
			 NET_PROT_IPv6(0, HDR_INDEX_LAST);
			 */
#ifdef ERR008531
		/* Note: Due to errata NH_FLD_IPV6_NEXT_HDR on IPv6 tunneled
		 * (inner) will extract the first PTYPE field rather than the
		 * L4 header.
		 */
#endif /* ERR008531 */

		} from_hdr; /*!< used when type = DPKG_EXTRACT_FROM_HDR */
		struct {
			uint8_t size; /*!< Size in byte */
			uint8_t offset; /*!< Byte offset */
		} from_data; /*!< used when type = DPKG_EXTRACT_FROM_DATA */
		struct {
			enum dpkg_extract_from_context_type src;
			/*!< Non-header extraction source */
			uint8_t size; /*!< Size in byte */
			uint8_t offset; /*!< Byte offset */
		} from_context;
		/*!< used when type = DPKG_EXTRACT_FROM_CONTEXT */
		struct {
			uint8_t constant; /*!< a constant value */
			uint8_t num_of_repeats;
		/*!< The number of times
		 the constant is to be
		 entered to the key */
		} constant; /*!< used when type = DPKG_EXTRACT_CONSTANT */
	} extract; /*!< Selects extraction method */
	uint8_t num_of_byte_masks;
	/*!< Defines the valid number of entries in the
	 array below; This is also number of bytes
	 to be used as masks */
	struct dpkg_mask masks[DPKG_NUM_OF_MASKS]; /*!< Mask parameters */
};

/**
 * @brief	A structure for defining a full Key Generation profile (rule)
 */
struct dpkg_profile_cfg {
	uint8_t num_extracts; /*!< defines the valid number of
	 entries in the array below */
	struct dpkg_extract extracts[DPKG_MAX_NUM_OF_EXTRACTS];
/*!< An array of extractions definition. */
};

struct dpkg_profile;
/**************************************************************************//**
 @Function      dpkg_profile_create

 @Description   Initialize a new Key Generation profile

 @Param[in]     profile_id 		- id of the profile
 @Param[in]     profile_params 	- A structure of parameters for creating a new Key Generation profile
 @Param[out]    keysize 		- The size (in bytes) of the key created

 @Return        A handle to the initialized Key extraction profile

 *//***************************************************************************/
int 	dpkg_profile_create(const struct dpkg * dpkg,
							int profile_id,
							const struct dpkg_profile_cfg *cfg);

/**************************************************************************//**
 @Function      dpkg_profile_delete

 @Description   Deletes an existing Key Extraction Profile

 @Param[in]     dpkg_profile	- A handle to the initialized Key Profile

 @Return        0 on Success; error code otherwise.

 *//***************************************************************************/
int 	dpkg_profile_delete(const struct dpkg * dpkg,
							int profile_id);

/**************************************************************************//**
 @Function      dpkg_profile_modify

 @Description   Modify an existing Key Extraction Profile

 @Param[in]     TBD

 @Return        0 on Success; error code otherwise.

 *//***************************************************************************/
int 	dpkg_profile_modify	(const struct dpkg * dpkg,
							int profile_id,
							const struct dpkg_profile_cfg *cfg);

int dpkg_profile_check_cfg(const struct dpkg * dpkg,
							const struct dpkg_profile_cfg *cfg);

int dpkg_debug_profile_create(const struct dpkg * dpkg,
								const struct dpkg_profile_cfg *cfg);

void dpkg_get_resource_str(const struct dpkg *dpkg, char *res_type);

int dpkg_read_extract_cfg_extention(struct dpkg_profile_cfg *extract_cfg,
	uint64_t *ext_params);

/** @} *//* end of grp_dpkg group */

#endif /* __FSL_DPKG_MC_H_ */
