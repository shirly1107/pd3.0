/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPBP_MC_H
#define __FSL_DPBP_MC_H

#include "fsl_dpmng_mc.h"
#include "fsl_dpmac_mc.h"

struct dpbp;

#define DPBP_MAX_IRQ_NUM			0

#define DPBP_BPID_NOT_VALID			(-1)

struct dpbp_cfg {
	uint32_t options;
};

struct dpbp_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
	uint16_t bpid;
};

int dpbp_create(struct dpbp *dpbp, const struct dpbp_cfg *cfg);

int dpbp_open(struct dpbp *dpbp, int dpbp_id);

int dpbp_close(struct dpbp *dpbp);

void dpbp_destroy(struct dpbp *dpbp);

void dpbp_enable(struct dpbp *dpbp);

int dpbp_disable(struct dpbp *dpbp);

int dpbp_is_enabled(struct dpbp *dpbp, int *en);

void dpbp_reset(struct dpbp *dpbp);

int dpbp_get_attributes(struct dpbp *dpbp, struct dpbp_attr *attr);
int dpbp_get_num_free_bufs(struct dpbp *dpbp, uint32_t *num_free_bufs);

#define DPBP_NOTIF_OPT_COHERENT_WRITE	0x00000001
/* Target of BP depletion SCNs is WRIOP DCP (#0) */
#define DPBP_NOTIF_OPT_WRIOP		0x00010000
/* Target of BP depletion SCNs is AIOP DCP (#1) */
#define DPBP_NOTIF_OPT_AIOP		0x00020000

struct dpbp_notification_cfg {
	uint32_t depletion_entry;
	uint32_t depletion_exit;
	uint32_t surplus_entry;
	uint32_t surplus_exit;
	uint64_t message_iova;
	uint64_t message_ctx;
	uint32_t options;
};

int dpbp_set_notifications(struct dpbp *dpbp,
	struct dpbp_notification_cfg *cfg);

int dpbp_get_notifications(struct dpbp *dpbp,
	struct dpbp_notification_cfg *cfg);

int dpbp_set_irq(struct dpbp *dpbp,
	uint8_t irq_index,
	const struct mc_irq_cfg *irq_cfg);

int dpbp_get_irq(struct dpbp *dpbp,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg);

int dpbp_set_irq_enable(struct dpbp *dpbp, uint8_t irq_index, uint8_t en);

int dpbp_get_irq_enable(struct dpbp *dpbp, uint8_t irq_index, uint8_t *en);

int dpbp_set_irq_mask(struct dpbp *dpbp, uint8_t irq_index, uint32_t mask);

int dpbp_get_irq_mask(struct dpbp *dpbp, uint8_t irq_index, uint32_t *mask);

int dpbp_get_irq_status(struct dpbp *dpbp, uint8_t irq_index, uint32_t *status);

int dpbp_clear_irq_status(struct dpbp *dpbp,
	uint8_t irq_index,
	uint32_t status);

/* MC internal functions */

struct dpbp *dpbp_allocate(void);
void dpbp_deallocate(struct dpbp *dpbp);
int dpbp_init(struct dpbp *dpbp,
	const struct dpbp_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg);
int dpbp_set_dev_ctx(struct dpbp *dpbp, const struct dpmng_dev_ctx *dev_ctx);
void dpbp_register_dpni(struct dpbp *dpbp, int register_dpni);

struct dpbp_hw_notification_cfg {
	uint32_t depletion_entry;
	uint32_t depletion_exit;
};

/* Assumes that this is relevant only for WRIOP (DCP#0) */
int dpbp_set_hw_notifications(struct dpbp *dpbp,
	struct dpbp_hw_notification_cfg *cfg);

int dpbp_get_hw_notifications(struct dpbp *dpbp,
	struct dpbp_hw_notification_cfg *cfg);

/*! Allocate memory, release buffers to BMan*/
int dpbp_allocate_buffers(struct dpbp *dpbp,
	enum memory_partition_id partition_id,
	size_t memory_size,
	uint32_t buffer_size);

/*! Acquire buffers from BMan, free PEB memory */
int dpbp_deallocate_buffers(struct dpbp *dpbp, size_t memory_size);

/*! Configure buffer depletion priority */
int dpbp_config_pfc_priority(struct dpmac *dpmac, struct dpbp *dpbp, uint8_t priority_mask, int cmd);
int cong_config_pfc_priority(struct dpmac *dpmac, uint16_t cgid, uint8_t priority_mask, int cmd);
/*! Return buffer pool id*/
int dpbp_get_bpid(struct dpbp *dpbp);

#endif /* __FSL_DPBP_MC_H */
