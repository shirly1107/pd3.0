/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_RESMAN_H
#define __FSL_RESMAN_H

#include "fsl_types.h"
#include "fsl_dbg.h"
#include "fsl_dpmng_mc.h"
#include "fsl_dprc_mc.h"
#include "fsl_event_pipe.h"

struct resman;
struct resman_device;
struct device;

/* Indication of invalid ids */
#define RESMAN_NO_DEVICE_ID    (uint16_t)(~0)
//#define RESMAN_NO_PORTAL_ID    -1
#define RESMAN_NO_CONTAINER_ID -1

#define DP_DEV_OWNERS_MASK              	0x1F

#define RESMAN_MAX_POOL_ATTR_NUM		4
#define RESMAN_MAX_REGION_NUM			4

#define NO_PORTAL_ID			(int)(~(0))

#define LAYOUT 				1

#define STR_MAX_SIZE 16

struct resman_res_req {
	char type[STR_MAX_SIZE];
	/*!< Resource/device type represemted by string
	 * Note: it is not possible to assign/unassign DP_DEV_DPRC devices */
	uint32_t num;
	/*!< Number of resources */
	uint32_t options;
	/*!< Request options: combination of DPRC_RES_REQ_OPT_ options */
	int id_base_align;
/*!<
 * In case of explicit assignment, this field represents the
 * required base ID for resource allocation;
 * In case of non-explicit
 * assignment, this field indicates the required alignment for the
 * resource ID(s) - use 0 or 1 if there is no alignment requirement.
 */
//uint16_t pool_attr[4];
/*!<
 * Defines the pool attributes for the specific resource type
 *
 */
};

enum resman_region_type {
	DPRC_REGION_TYPE_QMAN_CE,
	/*!< QMan Cache enabled region */
	DPRC_REGION_TYPE_QMAN_CI,
	/*!< QMan Cache inhibited region */
	DPRC_REGION_TYPE_MCP,
	DPRC_REGION_TYPE_QMAN_MB
	/*!< QMan Memory backed region */
};

/** Describes what actions the resman_create_dev and resman_open_dev
 * should do: create or open a device or both. */
enum resman_open_create_dev_type {
	DPRC_OPEN_DEV_ONLY = 0,
	DPRC_OPEN_CREATE_DEV = 1,
	DPRC_CREATE_DEV_ONLY = 2
};

/**************************************************************************//**
 @Description
 *//***************************************************************************/
struct dp_dev_type_param {
	int (*f_destroy)(struct device *device);
	int (*f_reset)(struct device *device);
#ifdef TKT011436 
	int (*f_graceful_stop)(struct device *device);
	int (*f_empty_check)(struct device *device);
	int (*f_restore_after_eiop_reset)(struct device *device);
	int (*f_resume)(struct device *device);
#endif /* TKT011436 */
	int (*f_assign)(struct device *device,
			const struct dpmng_dev_ctx *dev_ctx);
	int (*f_set_irq)(struct device *device, struct mc_irq_cfg *irq_cfg, int irq_index);
	int (*f_get_irq)(struct device *device, struct mc_irq_cfg *irq_cfg, int irq_index);

	uint16_t vendor;
	char device_type[STR_MAX_SIZE];
	uint16_t ver_major;
	uint16_t ver_minor;
	uint8_t irq_count;
	uint8_t region_count;
	uint16_t flags;
	enum resman_region_type region_types[RESMAN_MAX_REGION_NUM];
};

/**************************************************************************//**
 @Description     Unassigned Portal Policy
 *//***************************************************************************/
enum resman_unassigned_portal_policy {
	DPRC_UNASSIGNED_PORTAL_POLICY_BLOCK, /*  */
	DPRC_UNASSIGNED_PORTAL_POLICY_ALLOW
/*  */
};

/**************************************************************************//**
 @Description   Primitive Resource Advance Parameters
 *//***************************************************************************/
struct dp_pres_type_adv_param {
	int sharing_policy;
};

/**
 * @brief	Container attributes, returned by dprc_get_attributes()
 */
struct resman_container_attributes {
	int container_id;
	/*!< Container's ID */
	uint32_t icid;
	/*!< Container's ICID */
	int portal_id;
	/*!< Container's portal ID */
	int pl;
	/*!< Container's pl */
	int bmt;
	/*!< Container's bmt */
	int va;
	/*!< Container's va */
	int bdi;
	/*!< Container's bdi */
	uint64_t options;
	/*!< Container's options as set at container's creation */
	struct {
		uint16_t major; /*!< DPRC major version*/
		uint16_t minor; /*!< DPRC minor version*/
	} version;
	/*!< DPRC version */
};
/**
 * @brief	Creation Of resource manager module.
 *
 *
 * @returns	resource manager handle.
 *
 * @Cautions     This function should be called only ones during lifetime of
 * resource manager object.
 */
struct resman *resman_init(void);

/**
 * @brief	Free resource Manager Module.
 *
 *
 * @param[in]	resman	- Handle of Resource Manager
 *
 * @returns	'0' on Success; Error code otherwise.
 *
 * @Cautions      Last function call during lifetime of resource manager object.
 * The handle to the object is no longer valid after this call.
 */
int resman_free(struct resman *resman);

/**
 * @brief	Creates device pool
 *
 * This Function used to create a new device pool for a specific type at Resman.
 * Device pool name and count are given as input
 *
 *
 * @param[in]	resman - Handle of Resource Manager
 * @param[in]   type - Device type. Represent the pool name
 * @param[in]	num - Number of devices in the pool
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_create_obj_pool(struct resman *resman, char *type, int base, int num);

/**
 * @brief	Creates resource pool
 *
 * This Function used to create a new resource pool or to add resources to an
 * exist pool for Resman. Resource pool details such as: name, count and
 * resources ids in the pool are given as input
 *
 * @param[in]	resman - Handle of Resource Manager
 * @param[in]   req - Request details to create the pool (pool name and
 * resources ids)
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_create_res_pool(struct resman *resman, struct resman_res_req *req);

/**
 * @brief	Create ICID pool.
 *
 * This Function used to create or add icids to the Resman icid pool.
 * Resource pool details such as: name, count and resources ids in the pool are
 * given as input.
 *
 * @param[in]	resman - Handle of Resource Manager
 * @param[in]   bace_id	 - The first icid to add to icid pool
 * @param[in]	num - The amount of icids to add the icid pool.
 * @param[in]   lauout - Indication whether the command received from layout.
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_create_icid_pool(struct resman *resman,
	int base_icid,
	int num,
	int layout);

/**
 * @brief Destroy ICID pool	.
 *
 * This Function used to destroy icid pool. Can be done only if the icids are
 * not used by any container
 *
 * @param[in]	resman - Handle of Resource Manager
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_destroy_icid_pool(struct resman *resman);

/**
 * @brief	Create new container.
 *
 * This function is used to create a container.
 *
 * The new container created is the child of the container which received as
 * dprc parameter.The required container configuration, and id are given
 * as input.  In case the container id and portal id are not given, Resman will
 * allocate those values and return them to the user.
 *
 * @param[in]	  dprc -	DPRC descriptor object
 * @param[in]     cfg - The new container configuration parameters
 * @param[in/out] child_container_id - new container id
 * @param[out]	  child_portal_paddr - child container�s portal physical address
 * @param[in]	  layout - Indication whether command received from layout
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_create_container(struct dprc *dprc,
	struct dprc_cfg *cfg,
	int *child_container_id,
	uint64_t *child_portal_paddr,
	int layout);
/**
 * @brief	Destroy Container
 *
 * This function is used to destroy container.
 *
 * Before destroying the container all container�s descendant should be
 * destroyed
 *
 * @param[in]	dprc			DPRC descriptor object
 * @param[in]   child_container_id	ID of the container to destroy
 *
 * @returns	'0' on Success; Error code otherwise.
 *
 * @caution 	Container may destroy its children only. Container can�t destroy
 * itself or its descendant which are not its direct children.
 */

int resman_destroy_container(struct dprc *dprc, int child_container_id);

/**
 * @brief	.
 *
 *  This function is used to reset container. Before resetting the container all
 *  container�s descendant should be reset as well.
 *
 *
 * @param[in]	dprc			DPRC descriptor object
 * @param[in]   child_container_id	ID of the container to reset

 *
 * @returns	'0' on Success; Error code otherwise.
 *
 * @caution 	Container may reset its children only. Container can�t reset
 * itself or its descendant which are not its direct children.
 */
int resman_reset_container(struct dprc *dprc, int child_container_id, int portal_id, uint32_t options);

/**
 * @brief	Gets device version.
 *F
 * This routine is used to get device�s device driver version registered by the
 * device driver
 *
 * @param[in]	resman		Resman handle
 * @param[in]   dev_handle	Device handle to get its version
 * @param[in]	ver_minor	minor version id
 * @param[in]	ver_major	major version id
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_ver(struct resman *resman,
	void *dev_handle,
	uint16_t *ver_minor,
	uint16_t *ver_major);

/**
 * @brief	Gets Container's handle
 *
 *
 * @param[in]	resman		Resman handle
 * @param[in]   container_id	container id
 *
 * @returns	'0' on Success; Error code otherwise.
 */
void *resman_get_container(struct resman *resman, int container_id);

/**
 * @brief	Gets Container's id
 *
 * This routine is used to get the container id that owns the portal id received
 * as input. This routine can be called after container was created and before
 * it was opened
 *
 * @param[in]	 portal_id	Portal id related at the container
 * @param[out]   container_id	Container id
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_container_id(int portal_id, int *container_id);

/**
 * @brief	Sets resource quota
 *
 * This function Sets allocation policy for a specific resource/object type in a
 * child container. Allocation policy determines whether or not a container may
 * allocate resources from its parent. Each container has a 'global' allocation
 * policy that is set when the container is created. This function sets
 * allocation policy for a specific resource type.
 *
 * The default policy for all resource types matches the container's 'global'
 * allocation policy.
 *
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   child_container_id	ID of the container to change its
 * resource policy
 * @param[in]	type		Resource/object type
 * @param[in]	quota		The maximum number of resources of the selected
 * type that the child container is allowed to allocate from its parent;
 * when quota is set to -1, the policy is the same as container's general policy
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_set_quota(struct dprc *dprc,
	int child_container_id,
	char *type,
	uint16_t quota);

/**
 * @brief	Gets resource quota
 *
 * Gets the allocation policy of a specific resource/object type in a child
 * container
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   child_container_id	ID of the container to change its
 * resource policy
 * @param[in]	type		Resource/object type
 * @param[out]	quota		The maximum number of resources of the selected
 * type that the child container is allowed to allocate from its parent;
 * when quota is set to -1, the policy is the same as container's general policy
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_quota(struct dprc *dprc,
	int child_container_id,
	char *type,
	uint16_t *quota);

/**
 * @brief	Set locked a child container from parent container
 *
 * Locked means that the child container and all his children will not be able to:
 * -create another object
 * -destroy an existing object
 * -assign/unassign objects
 * -lock/unlock a child container
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   child_container_id	ID of the container to change its
 * resource policy
 * @param[in]	locked		1 = locked
 * 							0 = unlocked
 * @param[in]	portal_id	The portal id associated with the container that
 * opens the device
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_set_locked(struct dprc *dprc,
		int child_container_id,
		uint8_t locked,
		int portal_id);

/**
 * @brief	Bind resource to device
 *
 * This function is used to bind physical resources to devices so it will be the
 * exclusive owners of those resources (unless they are shared).
 * Binding resources to devices is done at device initialization by device�s
 * device driver. The resources to bind are taken from the free resource pools
 * according to resource/container policy.  Request for binding may be explicit
 * or not according to user demand. The bound resources ids returned to the user
 * so it can remap the resources ids along with the container icid and get
 * virtual ids for these resources.
 *
 * @param[in]	dev_handle	Device's handle
 * @param[in]   res_req 	Requested resources to bind
 * @param[out]  res_ids		Bound resources ID�s
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_bind(struct device *dev_handle,
	struct resman_res_req *res_req,
	int *res_ids);

/**
 * @brief	Unbind resource from device
 *
 * Unbind resources from device and return them to the container they were taken
 * from. This unbind routine at contrary from bind is done one by one for each
 * explicit primitive resource.
 *
 * @param[in]	dev_handle	Device's handle
 * @param[in]   type 		Resource type to unbind
 * @param[out]  id		Resource ID to unbind
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_unbind(void *handle, char *type, int id);

/**
 * @brief	Unbind resource from device
 *
 * Unbind all resources from device and return them to the container they were
 * taken from.
 *
 * @param[in]	dev_handle	Device's handle
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_unbind_all(void *dev_handle);

/**
 * @brief	Create MC internal device
 *
 * This Function used to create a mc device which is not exposed to GPPs and
 * contained at the global container at the mc devices pool.
 *
 * Mc device is needed in order to enable resource allocation for mc usage.
 *
 * @param[in]	resman	Resman's handle
 *
 * @returns	Handle of the created MC device
 */
void *resman_create_mc_device(struct resman *resman);

/**
 * @brief	Destroy MC device
 *
 *
 * @param[in]	resman		Resman Handle
 * @param[in]   dev_handle	MC device's handle
 *
 * @returns	'0' on Success; Error code otherwise.
 *
 * @caution	MC device can�t be destroyed as long it has bound resources.
 */
int resman_destroy_mc_device(struct resman *resman, void *dev_handle);

/**
 * @brief	Assign resources or device
 *
 * This Function is used to assign devices or resources to child container or
 * for self assignment.
 *
 * According to the DPRC allocation policy, the assigned resources may be taken
 * (allocated) from the container's ancestors, if not enough resources are
 * available in the container itself.
 *
 * The type of assignment depends on the assignment request, as follows:
 * - If DPRC_RES_REQ_OPT_EXPLICIT flag is set, the assigned resources hould have
 * explicit base ID that also specified at the request
 * - If DPRC_RES_REQ_OPT_ALIGNED flag is set, the assigned resources should be
 * aligned to the value given at the request.
 * - For devices only, if the DPRC_RES_REQ_OPT_PLUGGED is set, the object must
 * be set to the plugged state. A container may use this function with its own
 * ID for self assignment in order to change an object state to plugged or
 * unplugged
 *
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   container_id 	ID of the container to assign resources
 * @param[in]	res_req		The type and amount of resources to assign
 * @param[in]	layout		Indication if the assign request received from
 * layout
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_assign(struct dprc *dprc,
	int container_id,
	struct resman_res_req *res_req,
	int layout);
/**
 * @brief	Un-assign resources or devices from child to parent container.
 *
 *
 *
 * @param[in]	dprc		     DPRC descriptor object
 * @param[in]   child_container_id   ID of the container to un-assign resources
 * @param[in]	res_req		   The type and amount of resources to un-assign
 *
 * @returns	'0' on Success; Error code otherwise.
 *
 * @caution 	Un-assignment of objects can succeed only if the object is not
 * in the plugged or opened state.
 */
int resman_unassign(struct dprc *dprc,
	int child_container_id,
	struct resman_res_req *res_req);

/**
 * @brief	Register device operation
 *
 * This function should be called once for each device type supported by Resman,
 * by the device driver of this type. This function, register some general data
 * related to the device such as device driver version, callbacks routine to
 * handle specific, irqs count, device�s region count etc...
 *
 * @param[in]	resman		Resman's Handle
 * @param[in]   type   		Device's type
 * @param[in]	dev_type_param	Device�s parameters to register
 *
 * @returns	'0' on Success; Error code otherwise.
 *
 * @caution 	In order to create a device, this routine should be called for
 * the device type prior to device creation.
 */
int resman_register_device_operation(struct resman *resman,
	char *type,
	struct dp_dev_type_param *dev_type_param);

/**
 * @brief	Unregister device type from Resman.
 *
 * @param[in]	resman		Resman's Handle
 * @param[in]   type   		Device's type
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_unregister_device_operation(struct resman *resman, char *type);

/**
 * @brief	Gets device's context
 *
 * This function is used to get information about the device. This information
 * depends on the container the device contained at
 *
 * @param[in]	dev_handle	Device's handle
 * @param[out]  dev_ctx		Device's context (from container)
 *
 * @returns	'0' on Success; Error code otherwise.
 */
void resman_get_dev_ctx(void *dev_handle, struct dpmng_dev_ctx *dev_ctx, int dev_amq);

/**
 * @brief	Update PL bit in device's context
 *
 * This function is used to get information about the device. This information
 * depends on the container the device contained at
 *
 * @param[in]	dev_handle	Device's handle
 * @param[out]  dev_ctx		Device's context (from container)
 *
 * @returns	'0' on Success; Error code otherwise.
 */
void resman_update_dev_ctx_pl(void *dev_handle, struct dpmng_dev_ctx *dev_ctx, int dev_amq);

/**
 * @brief	Gets device's resources count
 *
 * This function is used to get the amount of all physical resources from a
 * specific type bound to the device.
 * The requested type received as input parameter
 *
 * @param[in]	device		Device's pointer
 * @param[in]   type		Resource type o get its count
 * @param[out]  count		Resource count
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_dev_res_count(struct resman_device *device,
	char *type,
	int *count);

/**
 * @brief	Gets device's resources ids
 *
 * This function is used to get the all physical resources ids from a specific
 * type bound to the device. The requested type received as input parameter.
 * The resources ids are filled at the array given from the user. The user
 * should use the resman_get_dev_res_count() to set the size of the array.
 *
 * @param[in]	device	    Device's pointer
 * @param[in]   type	    Resource type
 * @param[in]   num_of_ids  The size of the array to fill with the resources ids
 * @param[out]  res_ids	    The array to fill with the ids to return the user
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_dev_res_ids(struct resman_device *device,
	char *type,
	int num_of_ids,
	int *res_ids);

/**
 * @brief	Sets unassign portal policy
 *
 * This function set the policy to handle the creation of devices when the
 * create command received on an unassigned portal (portal that not contained at
 * any container). If this policy is set to DPRC_UNASSIGNED_PORTAL_POLICY_ALLOW,
 * then the device will be contained at a special container that dedicated for
 * devices which were created on unassigned portal. Otherwise, if the policy is
 * set to DPRC_UNASSIGNED_PORTAL_POLICY_BLOCK, the creation of the device will
 * reject.
 *
 * @param[in]	dprc	    container's pointer
 * @param[in]   policy	    Requested policy
 *
 * @returns	'0' on Success; Error code otherwise.
 *
 * @Caution 	This operation allowed to root container only
 */
int resman_set_unassign_portal_policy(struct dprc *dprc,
	enum resman_unassigned_portal_policy policy);

/**
 * @brief	Open object
 *
 * This function is used to open or create and open objects.
 * This can be decided according to input parameters:
 * 	-In case the given device id is -1, then a new device will be created
 * 	and opened. Its id will be set by Resman.
 * 	-In case the device id is given and the request received from GPP
 * 	(layout = 0, portal_id not -1) then it will open the device if exist.
 * 	-In case the device id is given and the request received from MC but not
 * 	from layout (layout = 0, portal_id is -1) then it will create and open
 * 	the device with the requested id.
 * 	-In case the device id is given, the request received from layout and
 * 	the portal id is not -1, a device will be created and opened at the
 * 	container that owns the portal id.
 * 	-In case the device id is given, the request received from layout and
 * 	the portal id is -1, this means that device already created by layout
 * 	and needs to be open.
 *
 * Container can only be opened by this routine if exists, and not created
 *
 * Open by Resman means to set device state as open, allocate an owner id for
 * the container that open the device. And update the owners of the device.
 *
 * @param[in]	resman		Resman's Handle
 * @param[in]   type	    	object type
 * @param[in]   id  		object id
 * @param[in]   portal_id	The portal id associated with the container that
 * opens the device
 * @param[in]	create	Controls whether the resman_create_dev and remsan_open_dev
 * 						should create or open a device or both.
 * 						0 = open; create & open = 1; create = 2
 * @param[in]   label  	object label
 *
 * @returns	'0' on Success; Error code otherwise.
 * @see resman_open_create_dev_type
 */
void *resman_open_dev(struct resman *resman,
	char *type,
	uint16_t id,
	int portal_id,
	int create,
	char *label);

/* Creates a device and returns both device handler and device id.
 * It calls resman_open_dev with 'create' parameter 'true'
 * and in case of success it sets the new allocated (or provided) device id.
 *
 * @param[in]	resman		Resman's Handle
 * @param[in]   type	    	object type
 * @param[in]   portal_id	The portal id associated with the container that
 * opens the device
 * @param[in] label			object label
 * @param[in|out]   id  		object id which can be allocated by resman or
 * provided by caller - e.g. DPAIOP, DPMAC or DPMCP
 *
 * @returns	'0' on Success; Error code otherwise.
 */
void *resman_create_dev(struct resman *resman,
	char *type,
	int portal_id,
	char *label,
	uint16_t* id);

int resman_object_created(void *dev_handle);

/**
 * @brief	Closes object by the container that owns the portal_id
 *
 * Close by Resman means to remove the container from object�s owners
 *
 * @param[in]	resman		Resman's Handle
 * @param[in]   device	    	device handle to close
 * @param[in]	type		object type
 * @param[in]   portal_id	The portal id associated with the container that
 * close the device
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_close_dev(struct resman *resman,
	void *device,
	char *type,
	int portal_id,
	int destroy);

/**
 * @brief	Gets container's objects count
 *
 * This function is used to get the number of object inside specific container.
 * This function is also number the object in the container so object descriptor
 * can be retrieved afterwards by resman_get_obj_desc_by_index()
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[ouj_count]   obj_count	The number of object in the container
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_obj_count(struct dprc *dprc, int *obj_count);

/**
 * @brief	Gets object descriptor.
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   obj_index	The index of the object in the container.
 * The index was given to the object at resman_get_obj_count()
 * @param[out]	obj_desc	The descriptor to fill and return to the user
 *
 * @returns	'0' on Success; Error code otherwise.
 *
 * @caution     resman_get_obj_count() should be called prior to
 * resman_get_obj_desc_by_index() to number the objects inside the container
 */
int resman_get_obj_desc_by_index(struct dprc *dprc,
	int obj_index,
	struct dprc_obj_desc *obj_desc);

#define RESMAN_ERRATA_FORCE_WORKAROUND	0x00000001
#define RESMAN_ERRATA_CHECK_WORKAROUND	0x00000002

/**
 * @brief	Main function for Errata A-011436 workaround.
 *
 * @param[in]	dpmac_id	MAC id.
 * @param[in]   options		Options for workaround.
 *
 * @returns	'0' on Success; Error code otherwise.
 *
 */
int resman_errata_workaround(int dpmac_id, uint32_t options);

/**
 * @brief	Gets object descriptor.
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   obj_type	The type of the object to get its descriptor.
 * @param[in]	obj_id		The id of the object to get its descriptor
 * @param[out]	obj_desc	The descriptor to fill and return to the user
 *
 * @returns	'0' on Success; Error code otherwise.
 *
 */
int resman_get_obj_desc(struct dprc *dprc,
        char *obj_type,
        int obj_id,
        struct dprc_obj_desc *dev_desc);

/**
 * @brief	Gets container's attributes
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[out]  attributes	container�s attributes
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_attributes(struct dprc *dprc,
	struct resman_container_attributes *attributes);

/**
 * @brief	Gets object�s regions
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   type		Object type
 * @param[in]	obj_id		Object ID
 * @param[in]   region_index	Region index
 * @param[in]	region_desc	Region descriptor
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_obj_region(struct dprc *dprc,
	char *obj_type,
	int obj_id,
	uint8_t region_index,
	struct dprc_region_desc *region_desc,
	int modify_region_size);

struct mc_irq_cfg;

int resman_get_obj_irq(struct dprc *dprc,
                       char *obj_type,
                       int obj_id,
                       uint8_t irq_index,
		   	struct mc_irq_cfg *irq_cfg);

int resman_set_obj_irq(struct dprc *dprc,
		       char *obj_type,
		       int obj_id,
		       uint8_t irq_index,
		       int portal_id,
		       struct mc_irq_cfg *irq_cfg);
/**
 * @brief	Sets container�s irq information to trigger interrupt.
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   irq_index	Interrupt index to configure.
 * DPRC supports only irq_index 0 - this interrupt will be signaled on every
 * change to resource/object assignment in this DPRC.
 * @param[in]	irq_addr	IRQ address that must be written to signal a
 * message-based interrupt
 * @param[in]   irq_val		Value to write into irq_addr address
 * @param[in]   irq_virt_id	A user defined number associated with this IRQ
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_set_irq(struct dprc *dprc,
		   uint8_t irq_index,
		   int portal_id,
		   struct mc_irq_cfg *irq_cfg);

/**
 * @brief	Gets IRQ information from the container
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   irq_index	The index of the irq to get.
 * @param[out]  type		Interrupt type: 0 represents message interrupt
 * @param[in]	irq_addr	Physical address that must be written in order
 * to signal the message-based interrupt
 * @param[in]   irq_val		Value to write in order to signal the
 * message-based interrupt
 * @param[in]   irq_virt_id	A user defined number associated with this IRQ
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_irq(struct dprc *dprc,
		   uint8_t irq_index,
		   struct mc_irq_cfg *irq_cfg);

/**
 * @brief	This function is used to enable/disable interrupts generation.
 *
 * Each interrupt can have up to 32 causes.
 * The enable/disable control's the overall interrupt state. if the interrupt is
 * disabled no causes will cause an interrupt.
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   irq_index	The interrupt index to configure
 * @param[in]	enable_state 	Interrupt state
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_set_irq_enable(struct dprc *dprc, uint8_t irq_index, uint8_t en, int portal_id);

/**
 * @brief	Get overall interrupts state (enabled/disabled)..
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   irq_index	Interrupt index
 * @param[out]	enable_state 	Interrupt state
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_irq_enable(struct dprc *dprc, uint8_t irq_index, uint8_t *en);

/**
 * @brief	Sets interrupt mask.
 *
 * Every interrupt can have up to 32 causes and the interrupt model supports
 * mask/unmask each cause independently
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   irq_index	The interrupt index to configure
 * @param[out]	mask		Event mask to trigger interrupt.
 *				each bit:
 *					0 = ignore event
 *					1 = consider event for asserting irq
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_set_irq_mask(struct dprc *dprc, uint8_t irq_index, uint32_t mask);

/**
 * @brief	Gets interrupt mask.
 *
 * Every interrupt can have up to 32 causes and the interrupt model supports
 * mask/unmask each cause independently
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   irq_index	Interrupt index
 * @param[in]	mask		Event mask to trigger interrupt.
 *				each bit:
 *					0 = ignore event
 *					1 = consider event for asserting irq
 *
 * @returns	'0' on Success; Error code otherwise.
 */

int resman_get_irq_mask(struct dprc *dprc, uint8_t irq_index, uint32_t *mask);
/**
 * @brief	Gets the current status of any pending interrupts.
 *
 *
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   irq_index	Interrupt index
 * @param[out]	mask		Event mask to trigger interrupt.
 *				each bit:
 *					0 = No pending interrupt
 *					1 = Interrupt pending
 *
 * @returns	'0' on Success; Error code otherwise.
 */

int resman_get_irq_status(struct dprc *dprc,
			  uint8_t irq_index,
			  uint32_t *status);

/**
 * @brief	Clears pending interrupt status.
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   irq_index	Interrupt index
 * @param[out]	status		Bits to clear (One bit per cause).
 *				each bit:
 *					0 = Don�t change
 *					1 = Clear status bit
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_clear_irq_status(struct dprc *dprc,
			    uint8_t irq_index,
			    uint32_t status);

/**
 * @brief	Gets container's pool count
 *
 * This routine is also number to pools inside the container so user can use
 * pool index (0 - pool_count) to get pools types(string).
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[out]  pool_count	The number of pool in the container
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_pool_count(struct dprc *dprc, int *pool_count);

/**
 * @brief	Gets pool's type.
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   pool_index	pool index
 * @param[out]	type		A string that represent pool type
 *
 * @returns	'0' on Success; Error code otherwise.
 *
 * @cautiion 	resman_get_pool_count() should be called prior to
 * resman_get_pool() in order to  set index for each pool.
 */
int resman_get_pool(struct dprc *dprc, int pool_index, char type[STR_MAX_SIZE]);

/**
 * @brief	Gets the number of resources of a specific pool type inside the
 * container.
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   type		Pool type
 * @param[out]	res_count	The number of resources from the requested type
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_res_count(struct dprc *dprc, char *type, int *res_count);

/**
 * @brief	Gets the physical ids of the resources from a specific pool type
 * inside the container.
 *
 * The ids returned to the user as ranges. Each range has minimum and maximum id
 * and a state that indicate if there are more ranges or this is the last one.
 * The user should continue and call this routine with the previous range
 * descriptor in order to get the next range until the returned range marked as
 * last. At the first time this routines is called the range descriptor has to
 * be zeroed which indicate to Resman to return the first ids range.
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   type		Pool type
 * @param[in]	range_desc	Range descriptor
 *
 * @returns	'0' on Success; Error code otherwise.
 */
int resman_get_res_ids(struct dprc *dprc,
	char *type,
	struct dprc_res_ids_range_desc *range_desc);
/**
 * @brief	Finds specific device at conainer's descendant.
 *
 * @param[in]	dprc		DPRC descriptor object
 * @param[in]   type		Device type
 * @param[in]	id		Device id
 *
 * @returns	'0' on Success; Error code otherwise.
 */
struct resman_device *resman_find_device_at_descendant(
		struct resman *resman, struct dprc *dprc,
		char *type,
		int id,
		struct dprc **contain_dprc);

/**
 * @brief Checks if the given portal id is the assigned portal id of the DPRC containing
 * the device or in the device's DPRC ancestors hierarchy.
 * If the assigned portal id and and the given portal id are different then search
 * the "free mcp resources" or/and "in use portals" lists.
 *
 * @param[in]	device		resman_device or dprc object depending on 'is_dprc_dev' parameter
 * @param[in]	is_dprc_dev	'0' if 'device' points to a resman_device object (non-container device)
 *							> 0 if 'device' points to a dprc object (container device)
 * @param[in]	portal_id	The portal id to be searched
 * @param[in]	dprc_id		The id of the dprc containing the portal id
 * @param[in]	search_ancestors Specifies the next 'n' ancestors to extend the search;
 * 								 a value of '0' means only direct parent is searched.
 *
 * @returns	'1' if resource is found and '0' otherwise.
 */
int resman_is_portal_in_dev_rc_hierarchy(
		struct resman *resman,
		void* device,
		unsigned int is_dprc_dev,
		int portal_id,
		int* dprc_id,
		int search_ancestors
		);

int resman_is_link_permitted (struct resman *resman,
		              char *ep1_type,
		              int ep1_id,
		              char *ep2_type,
		              int ep2_id,
		              struct dprc **contain_dprc);

int resman_get_bound_res_counters(struct resman *resman);

/**
 * Check if the dprc currently owning the device is also the creator.
 * If there is no owner (as it should happen before calling dpXX_destroy commands
 * - as of MC v10.0.0) the caller can provide the dprc obtained from the command token.
 */
int resman_is_destroy_allowed(void *device, char *type, struct dprc *contain_dprc);

int resman_set_obj_label(struct dprc *dprc, char *obj_type, int obj_id, char *label);

int resman_clear_root_container(struct resman *resman);

#if 0
int resman_is_parent_portal(struct resman *resman,
	int portal_id,
	int container_id);
#endif
int resman_is_irq_cfg_allowed(struct device *dev);

static inline int allocate_resource(struct device *device,
	char *type,
	uint32_t num,
	int b_a,
	uint32_t opt,
	int *addr,
	char *str)
{
	struct resman_res_req req;
	int err = 0;

	ASSERT_COND(device);

	memset(&req, 0, sizeof(struct resman_res_req));
	strncpy(req.type, type, sizeof(req.type)-1);
	req.num = num;
	req.id_base_align = b_a;
	req.options = opt;
	err = resman_bind(device, &req, addr);
	if (err != 0)
		pr_err("resman_bind() failed for %s\n", str);
	return err;
}

static inline int deallocate_resource(struct device	*device,
	char *type,
	int id,
	char *str)
{
	int err = 0;

	ASSERT_COND(device);

	err = resman_unbind(device, type, id);
	if (err != 0)
		pr_err("resman_bind() failed for %s\n", str);

	return err;
}

void resman_get_peb_info();
int resman_get_mem_avail_list(uint16_t page, uint8_t flags, uint8_t partition_id, struct dprc_mem *mem);

#endif /* __FSL_RESMAN_H */
