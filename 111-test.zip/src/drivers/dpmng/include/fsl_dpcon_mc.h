/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPCON_MC_H
#define __FSL_DPCON_MC_H

#include "fsl_dpmng_mc.h"

struct dpcon;

#define DPCON_INVALID_DPIO_ID		(int)(-1)

#define DPCON_MAX_IRQ_NUM			0

struct dpcon_cfg {
	uint8_t num_priorities;
};

enum dpcon_channel_type_cfg {
	DPCON_CHANNEL_NONE = 0,
	DPCON_SWP_CHANNEL_8WQ,
	DPCON_SWP_CHANNEL_2WQ,
	DPCON_DCP_CHANNEL
};

struct dpcon_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
	uint16_t qbman_ch_id;
	uint8_t num_priorities;
};

struct dpcon_notification_cfg {
	int dpio_id;
	uint8_t priority;
	uint64_t user_ctx;
};

int dpcon_create(struct dpcon *dpcon, const struct dpcon_cfg *cfg);

int dpcon_open(struct dpcon *dpcon, int dpcon_id);

int dpcon_close(struct dpcon *dpcon);

void dpcon_destroy(struct dpcon *dpcon);

void dpcon_enable(struct dpcon *dpcon);

int dpcon_disable(struct dpcon *dpcon);

int dpcon_is_enabled(struct dpcon *dpcon, int *en);

void dpcon_reset(struct dpcon *dpcon, int clear_channel);

int dpcon_get_attributes(struct dpcon *dpcon, struct dpcon_attr *attr);

int dpcon_set_notification(struct dpcon *dpcon,
	struct dpcon_notification_cfg *cfg);

int dpcon_set_irq(struct dpcon *dpcon,
		  uint8_t irq_index,
		  const struct mc_irq_cfg *irq_cfg);

int dpcon_get_irq(struct dpcon *dpcon,
		  uint8_t irq_index,
		  struct mc_irq_cfg *irq_cfg);

int dpcon_set_irq_enable(struct dpcon *dpcon, uint8_t irq_index, uint8_t en);

int dpcon_get_irq_enable(struct dpcon *dpcon, uint8_t irq_index, uint8_t *en);

int dpcon_set_irq_mask(struct dpcon *dpcon, uint8_t irq_index, uint32_t mask);

int dpcon_get_irq_mask(struct dpcon *dpcon, uint8_t irq_index, uint32_t *mask);

int dpcon_get_irq_status(struct dpcon *dpcon,
			 uint8_t irq_index,
			 uint32_t *status);

int dpcon_clear_irq_status(struct dpcon *dpcon,
			   uint8_t irq_index,
			   uint32_t status);

/* MC internal functions */

struct dpcon *dpcon_allocate(void);
void dpcon_deallocate(struct dpcon *dpcon);
int dpcon_init(struct dpcon *dpcon,
	       const struct dpcon_cfg *cfg,
	       const struct dpmng_dev_cfg *dev_cfg);
int dpcon_assign_init(struct dpcon *dpcon,
		const struct dpmng_dev_ctx *dev_ctx);
int dpcon_is_aiop_dcp_channel_type(struct dpcon *dpcon);
int dpcon_set_dev_ctx(struct dpcon *dpcon,
		      const struct dpmng_dev_ctx *dev_ctx);
int dpcon_get_destwq(struct dpcon *dpcon, uint8_t priority, uint16_t *destwq);
int dpcon_is_priority_in_range(struct dpcon *dpcon, uint8_t priority);
int dpcon_is_cdan_enabled(struct dpcon *dpcon);
uint16_t dpcon_get_channel_id(struct dpcon *dpcon);
void dpcon_set_static_dequeue(struct dpcon *dpcon, int enable);

#endif /* __FSL_DPCON_MC_H */
