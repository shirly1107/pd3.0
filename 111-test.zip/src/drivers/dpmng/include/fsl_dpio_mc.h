/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_DPIO_MC_H
#define __FSL_DPIO_MC_H

#include "fsl_dpmng_mc.h"

struct dpio;

#define DPIO_MAX_IRQ_NUM		1

enum dpio_channel_mode {
	DPIO_NO_CHANNEL = 0, DPIO_LOCAL_CHANNEL = 1
};

struct dpio_cfg {
	enum dpio_channel_mode channel_mode;
	uint8_t num_priorities;
};

struct dpio_attr {
	int id;
	struct {
		uint16_t major;
		uint16_t minor;
	} version;
	uint64_t qbman_portal_ce_offset;
	uint64_t qbman_portal_ci_offset;
	uint16_t qbman_portal_id;
	enum dpio_channel_mode channel_mode;
	uint8_t num_priorities;
	uint32_t clk;
	uint32_t qbman_version;
};

int dpio_create(struct dpio *dpio, const struct dpio_cfg *cfg);

int dpio_open(struct dpio *dpio, int dpio_id);

int dpio_close(struct dpio *dpio);

int dpio_destroy(struct dpio *dpio);

void dpio_enable(struct dpio *dpio);

int dpio_disable(struct dpio *dpio);

int dpio_is_enabled(struct dpio *dpio, int *en);

int dpio_reset(struct dpio *dpio, int clear_channel);

int dpio_get_attributes(struct dpio *dpio, struct dpio_attr *attr);

int dpio_set_stashing_destination(struct dpio *dpio, uint8_t sdest);

int dpio_set_stashing_destination_target(struct dpio *dpio, uint8_t core_id);

int dpio_get_stashing_destination(struct dpio *dpio, uint8_t *sdest);

int dpio_set_stashing_destination_source(struct dpio *dpio, uint8_t ss);

int dpio_get_stashing_destination_source(struct dpio *dpio, uint8_t *ss);

int dpio_add_static_dequeue_channel(struct dpio *dpio,
	int dpcon_id,
	uint8_t *channel_index);

int dpio_remove_static_dequeue_channel(struct dpio *dpio, int dpcon_id);

#define DPIO_IRQ_SWP_INDEX				0

int dpio_set_irq(struct dpio *dpio,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg);

int dpio_get_irq(struct dpio *dpio,
	uint8_t irq_index,
	struct mc_irq_cfg *irq_cfg);

int dpio_set_irq_enable(struct dpio *dpio, uint8_t irq_index, uint8_t en);

int dpio_get_irq_enable(struct dpio *dpio, uint8_t irq_index, uint8_t *en);

int dpio_set_irq_mask(struct dpio *dpio, uint8_t irq_index, uint32_t mask);

int dpio_get_irq_mask(struct dpio *dpio, uint8_t irq_index, uint32_t *mask);

int dpio_get_irq_status(struct dpio *dpio, uint8_t irq_index, uint32_t *status);

int dpio_clear_irq_status(struct dpio *dpio,
	uint8_t irq_index,
	uint32_t status);

/* MC internal functions */

struct dpio *dpio_allocate(void);
void dpio_deallocate(struct dpio *dpio);
int dpio_init(struct dpio *dpio,
	const struct dpio_cfg *cfg,
	const struct dpmng_dev_cfg *dev_cfg);
int dpio_set_dev_ctx(struct dpio *dpio, const struct dpmng_dev_ctx *dev_ctx);
int dpio_get_destwq(struct dpio *dpio, uint8_t priority, uint16_t *destwq);
int dpio_is_priority_in_range(struct dpio *dpio, uint8_t priority);

#endif /* __FSL_DPIO_MC_H */
