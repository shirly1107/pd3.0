/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_SYS_DPC_H
#define __FSL_SYS_DPC_H

#include "fsl_types.h"
#include "fsl_dpmac_mc.h"
#include "fsl_log.h"
#include "fsl_serdes.h"

struct node;

extern struct dpc dpc;

struct dpc_mod_params {
    char            *compatibles;
        /**< The type of the owner module */

    int             (*f_prob_module)(void *dtc_addr, int node_off);
        /**< modules initialization routine */
    int             (*f_remove_module)(void *dtc_addr, int node_off);
        /**< modules free routine */
};

#define DPC_ICID_POOL_MASK_NUM 0x1
#define DPC_ICID_POOL_MASK_BASE_ICID 0x2

struct dpc_icid_pool {
	uint32_t dpc_mask;
	uint32_t num;
	int base_icid;
};

#define DPC_QBMAN_MASK_TOTAL_BUFFERS	0x00000001
#define DPC_QBMAN_MASK_WQ_CH			0x00000004
#define DPC_QBMAN_MASK_PFDR_PEB_SIZE	0x00000008
#define DPC_QBMAN_MASK_OREE_MODE		0x00000010

struct dpc_qbman {
	uint32_t dpc_mask;
	uint32_t total_bman_buffers;
	uint16_t wq_ch_conversion;
	uint32_t pfdr_peb_size;
	enum orl_oree_mode oree_mode;
};

#define DPC_PME_MASK_PDSR 0x1
#define DPC_PME_MASK_SRE  0x2

struct dpc_pme {
	uint32_t dpc_mask;
	uint64_t pdsr_size_kb; /* 9.5MB - 134MB */
	uint64_t sre_size_kb;  /* 0 - 4GB */
};

#define DPC_MEMORY_MASK_DPDDR 0x1
#define DPC_MEMORY_MASK_MC_START_DDR 0x2
#define DPC_MEMORY_MASK_MC_END_DDR 0x4

struct dpc_memory {
	uint32_t dpc_mask;
	uint64_t dpddr_size; /* u-boot set: DP-DDR size;'0' = no DP-DDR */
	uint64_t mc_sys_ddr_end_add; /* u-boot set: upper limit of MC sys-DDR */
	uint64_t mc_sys_ddr_start_add; /* u-boot set: low address of MC sys-DDR */
};

#define DPC_MAC_MASK_LINK_TYPE	0x1
#define DPC_MAC_MASK_PHY_ID 	0x1
#define DPC_MAC_MASK_ENET_IF	0x2
#define DPC_MAC_MASK_AUTONEG	0x4
#define DPC_MAC_MASK_FEC_MODE	0x8
#define DPC_MAC_MASK_SERDES_CFG	0x10
#define DPC_MAC_MASK_RATE		0x20
#define DPC_MAC_MASK_DEBUG_LINK_CHECK 0x40
#define DPC_MAC_MASK_CEETM_ID	0x80

struct dpc_mac {
	uint32_t dpc_mask;
	int mac_id;
	enum dpmac_link_type link_type;
	int phy_id;
	uint8_t port_mac_addr[6];
	enum enet_interface enet_if;
	uint8_t autoneg;
	uint8_t debug_link_check;
	enum dpmac_fec_mode fec_mode;
	struct serdes_eq_settings serdes_cfg;
	uint32_t rate;
	uint16_t ceetm_id;
};

#define DPC_LOG_MASK_MODE  		0x1
#define DPC_LOG_MASK_LEVEL 		0x2
#define DPC_LOG_MASK_MEM_SIZE 	0x4
#define DPC_LOG_MASK_TIMESTAMP 	0x8
#define DPC_LOG_MASK_MODULE_LEVELS 0x10

struct dpc_log {
	uint32_t dpc_mask;
	enum log_mode mode;
	enum log_level level;
	enum log_timestamp_mode ts_mode;
	enum log_level module_levels[LOG_MODULES_AMOUNT];
	uint64_t mem_size_kb;
};

enum console_mode {
	CONSOLE_MODE_ON,
	CONSOLE_MODE_OFF
};

#define DPC_CONSOLE_MASK_MODE  		0x1
#define DPC_CONSOLE_MASK_UART_ID	0x2

struct dpc_console {
	uint32_t dpc_mask;
	enum console_mode mode;
	int uart_id;
};

#define DPC_MAX_ICID_POOLS 	16
#define DPC_MAX_MACS 		18

struct dpc_aiop {
	struct dpc_log log;
	struct dpc_console console;
};

#define DPC_ERRATA_STATE_MASK  		0x1

enum errata_state {
	WA_DISABLED = 0,
	WA_ENABLED = 1
};

struct dpc_errata {
	uint32_t dpc_mask;
	enum errata_state state;
};

struct dpc {
	struct dpc_icid_pool icid_pools[DPC_MAX_ICID_POOLS];
	struct dpc_qbman qbman;
	struct dpc_pme pme;
	struct dpc_memory memory;
	struct dpc_log log;
	struct dpc_console console;
	struct dpc_mac macs[DPC_MAX_MACS];
	struct dpc_aiop aiop;
	struct dpc_errata errata;
};

int dpc_process(void);
void dpc_get_mac_info(int mac_id, int *disable, uint32_t *link_type,
		int *phy_id, uint32_t *enet_if, uint8_t *autoneg, uint8_t *debug_link_check, uint32_t *rate);

/** Gets the size of DP-DDR
 * @param dpddr_size: the size of DP-DDR
 * @return >0 if the DP-DDR value was set in DPC
 */
int dpc_get_dpddr_size(uint64_t* dpddr_size);

/** Gets the upper and lower limits of the system DDR allocated
 * by u-boot to MC FW.
 * @param start_address: MC start system ddr address
 * @param end_address: first unavailable MC system ddr address
 * @return >0 if the DP-DDR value was set in DPC
 */
int dpc_get_mc_sys_ddr_limits(uint64_t* start_address, uint64_t* end_address);

int dpc_get_A011436_state(uint32_t dpc_mask);

#endif /* __FSL_SYS_DPC_H */
