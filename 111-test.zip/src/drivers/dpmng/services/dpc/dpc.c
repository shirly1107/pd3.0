/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "fsl_system.h"
#include "fsl_resman.h"
#include "fsl_soc.h"
#include "fsl_serdes.h"
#include "drivers/fsl_mc.h"
#include "dpc.h"
#include "dtc/dtc.h"
#include "common/fsl_string.h"
#include "log.h"
#include "kernel/layout.h"

#define DPC_PROPERTY_TEST_AND_GET(addr, offset, property, value) \
	do { \
		uint64_t val; \
		if (getprop_val((addr), (offset), (property), 0, 0, &val) == 0) \
			(value) = (int)val; \
	} while(0)

struct dpc dpc = { 0 };

int incorrect_log_level;

static unsigned int *dpc_read(void)
{
	return UINT_TO_PTR(0x00f00000);
}

#ifdef TKT011436
static int get_errata_state(void *lo, int node_off, enum errata_state *state)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		enum errata_state state;
	} map[] = {
			{ "ENABLED", WA_ENABLED },
			{ "DISABLED", WA_DISABLED }
	};

	str = (char *)fdt_getprop(lo, node_off, "A-011436", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (!strcmp(str, map[i].str)) {
			*state = map[i].state;
			return 0;
		}
	}
	return -EINVAL;
}

static int errata_process(void *dpc_addr, int node_off)
{
	dpc.errata.dpc_mask = 0;
	dpc.errata.state = WA_DISABLED;

	if(!strcmp(fdt_get_name(dpc_addr, node_off, NULL), "errata"))
		if (get_errata_state(dpc_addr, node_off, &dpc.errata.state) == 0)
			dpc.errata.dpc_mask |= DPC_ERRATA_STATE_MASK;

	return 0;
}

int dpc_get_A011436_state(uint32_t dpc_mask)
{
	return (((dpc.errata.dpc_mask & dpc_mask) && (dpc.errata.state == WA_ENABLED)) ? 1 : 0);
}
#endif /* TKT011436 */

static int icid_pool_process(void *dpc_addr, int node_off)
{
	int subnode_off;
	uint64_t val;
	int err, id;

	subnode_off = fdt_first_subnode(dpc_addr, node_off);

	while (subnode_off != -FDT_ERR_NOTFOUND) //containers, objects ,connections
	{
		err = get_node_id(dpc_addr, subnode_off, &id);
		if (err)
			return err;

		if (id < 0 || id >= ARRAY_SIZE(dpc.icid_pools)) {
	//		pr_err("icid_pool id must be value between 0 and %d\n", ARRAY_SIZE(dpc.icid_pools));
			return -EINVAL;
		}
		dpc.icid_pools[id].dpc_mask = 0;

		/* reading parameters */
		if (getprop_val(dpc_addr, subnode_off, "num", 0, 0, &val) == 0) {
			dpc.icid_pools[id].num = (uint32_t)val;
			dpc.icid_pools[id].dpc_mask |= DPC_ICID_POOL_MASK_NUM;
		}
		if (getprop_val(dpc_addr, subnode_off, "base_icid", 0, 0, &val) == 0) {
			dpc.icid_pools[id].base_icid = (int)val;
			dpc.icid_pools[id].dpc_mask |= DPC_ICID_POOL_MASK_BASE_ICID;
		}
		subnode_off = fdt_next_subnode(dpc_addr, subnode_off);
	}

	return 0;
}

static int get_oree_mode(void *lo, int node_off, enum orl_oree_mode *mode)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		enum orl_oree_mode mode;
	} map[] = {
			{ "OREE_MODE_OFF", OREE_MODE_OFF },
			{ "OREE_MODE_ON", OREE_MODE_ON }
	};

	str = (char *)fdt_getprop(lo, node_off, "oree_mode", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (!strcmp(str, map[i].str)) {
			*mode = map[i].mode;
			return 0;
		}
	}
	return -EINVAL;
}

static int qbman_process(void *dpc_addr, int node_off)
{
	uint64_t val;

	dpc.qbman.dpc_mask = 0;

	/* reading parameters */
	if (getprop_val(dpc_addr, node_off, "total_bman_buffers", 0, 0, &val) == 0) {
		dpc.qbman.total_bman_buffers = (uint32_t)val;
		dpc.qbman.dpc_mask |= DPC_QBMAN_MASK_TOTAL_BUFFERS;
		if( dpmng_mctiny() ) {
			pr_warn("MC running with reduced memory size; dpc parameter total_bman_buffers is ignored\n");
		}
	}

	if (getprop_val(dpc_addr, node_off, "wq_ch_conversion", 0, 0, &val) == 0) {
		dpc.qbman.wq_ch_conversion = (uint16_t)val;
		dpc.qbman.dpc_mask |= DPC_QBMAN_MASK_WQ_CH;
	}

	if (getprop_val(dpc_addr, node_off, "pfdr_peb_size_kb", 0, 0, &val) == 0) {
		dpc.qbman.pfdr_peb_size = (uint32_t)val;
		dpc.qbman.dpc_mask |= DPC_QBMAN_MASK_PFDR_PEB_SIZE;
	}
	
	if (get_oree_mode(dpc_addr, node_off, &dpc.qbman.oree_mode) == 0) {
		dpc.qbman.dpc_mask |= DPC_QBMAN_MASK_OREE_MODE;
	}
	return 0;
}

static int get_log_mode(void *lo, int node_off, enum log_mode *mode)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		enum log_mode mode;
	} map[] = {
			{ "LOG_MODE_OFF", LOG_MODE_OFF },
			{ "LOG_MODE_ON", LOG_MODE_ON }
	};

	str = (char *)fdt_getprop(lo, node_off, "mode", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (!strcmp(str, map[i].str)) {
			*mode = map[i].mode;
			return 0;
		}
	}
	return -EINVAL;
}

static int get_log_timestamp_mode(void *lo, int node_off, enum log_timestamp_mode *mode)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		enum log_timestamp_mode mode;
	} map[] = {
			{ "LOG_TIMESTAMP_OFF", LOG_TIMESTAMP_OFF },
			{ "LOG_TIMESTAMP_ON", LOG_TIMESTAMP_ON }
	};

	str = (char *)fdt_getprop(lo, node_off, "timestamp", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (!strcmp(str, map[i].str)) {
			*mode = map[i].mode;
			return 0;
		}
	}
	return -EINVAL;
}

struct {
	char *str;
	enum log_level level;
} level_map[] = {
		{ "LOG_LEVEL_GLOBAL", LOG_LEVEL_GLOBAL },
		{ "LOG_LEVEL_DEBUG", LOG_LEVEL_DEBUG },
		{ "LOG_LEVEL_INFO", LOG_LEVEL_INFO },
		{ "LOG_LEVEL_WARNING", LOG_LEVEL_WARNING },
		{ "LOG_LEVEL_ERROR", LOG_LEVEL_ERROR },
		{ "LOG_LEVEL_CRITICAL", LOG_LEVEL_CRITICAL }
};

static int get_log_level(void *lo, int node_off, enum log_level *level)
{
	char *str;
	int i = 0;

	str = (char *)fdt_getprop(lo, node_off, "level", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(level_map); i++) {
		if (!strcmp(str, level_map[i].str)) {
			*level = level_map[i].level;
			return 0;
		}
	}

	incorrect_log_level = 1;
	return -EINVAL;
}

#define PROP_NAME_LEN 64

static int get_log_module_levels(void *lo, int node_off, enum log_level module_levels[LOG_MODULES_AMOUNT])
{
	int ret = 0;
	int i = 0;
	int prop_off;
	enum log_level level;
	enum log_module module;
	uint64_t val = 0;
	const char *propname;
	int len;
	struct {
		char *module_name;
		enum log_module module;
	} module_map[] = {
			{ "level-DEFAULT", LOG_MOD_DEFAULT },
			{ "level-DPNI"	 , LOG_MOD_DPNI },
			{ "level-DPIO"	 , LOG_MOD_DPIO },
			{ "level-DPBP"	 , LOG_MOD_DPBP },
			{ "level-DPSW"	 , LOG_MOD_DPSW },
			{ "level-DPRC"	 , LOG_MOD_DPRC },
			{ "level-DPCON"	 , LOG_MOD_DPCON },
			{ "level-DPDMUX"	 , LOG_MOD_DPDMUX },
			{ "level-DPLAG"	 , LOG_MOD_DPLAG },
			{ "level-DPMAC"	 , LOG_MOD_DPMAC },
			{ "level-DPMNG"	 , LOG_MOD_DPMNG },
			{ "level-DPCI"	 , LOG_MOD_DPCI },
			{ "level-DPSECI"	 , LOG_MOD_DPSECI },
			{ "level-RESMAN"	 , LOG_MOD_RESMAN },
			{ "level-LINKMAN"	 , LOG_MOD_LINKMAN },
			{ "level-CTLU"	 , LOG_MOD_CTLU },
			{ "level-DPAIOP"	 , LOG_MOD_DPAIOP },
			{ "level-EIOP"	 , LOG_MOD_EIOP },
			{ "level-CMDIF"	 , LOG_MOD_CMDIF },
			{ "level-QBMAN"	 , LOG_MOD_QBMAN },
			{ "level-DPDMAI"	 , LOG_MOD_DPDMAI },
			{ "level-EDMA"	 , LOG_MOD_EDMA },
			{ "level-PLATFORM"	 , LOG_MOD_PLATFORM },
			{ "level-DCE"	 , LOG_MOD_DCE },
			{ "level-DPMCP"	 , LOG_MOD_DPMCP },
			{ "level-DPDCEI"	 , LOG_MOD_DPDCEI },
			{ "level-QDMA"	 , LOG_MOD_QDMA },
			{ "level-DPDBG"	 , LOG_MOD_DPDBG },
			{ "level-DPRTC"	 , LOG_MOD_DPRTC },
			{ "level-CAAM",		LOG_MOD_CAAM },
			{ "level-DPSPARSER",	LOG_MOD_DPSPARSER }
	};

	if (!module_levels) {
		return -EINVAL;
	}
	
	for (i = 0; i < LOG_MODULES_AMOUNT; i++) {
		module_levels[i] = LOG_LEVEL_GLOBAL;
	}
	
	prop_off = fdt_first_property_offset(lo, node_off);

	while (prop_off != -FDT_ERR_NOTFOUND)
	{
		char *prop = (char*)fdt_getprop_by_offset(lo, prop_off, &propname, &len);
		if (prop && (strstr(propname, "level-") == propname)) {
			
			for (i = 0; i < ARRAY_SIZE(module_map); i++) {
				if (!strcmp(propname, module_map[i].module_name)) {
					int j;
					module = module_map[i].module;
					
					for (j = 0; j < ARRAY_SIZE(level_map); j++) {
						if (!strcmp(prop, level_map[j].str)) {
							level = level_map[j].level;
							
							module_levels[module] = level;
							ret++;
							break;
						}
					}
					
					break;
				}
			}
		}

		prop_off = fdt_next_property_offset(lo, prop_off);
	}

	return ret;
}

static int log_process(void *dpc_addr, int node_off)
{
	uint64_t val;

	if(!strcmp(fdt_get_name(dpc_addr, fdt_parent_offset(dpc_addr, node_off), NULL), "aiop"))
	{
		/* reading parameters */
		if (get_log_mode(dpc_addr, node_off, &dpc.aiop.log.mode) == 0) {
			dpc.aiop.log.dpc_mask |= DPC_LOG_MASK_MODE;
		}
	} else {
		/* reading parameters */
		if (get_log_mode(dpc_addr, node_off, &dpc.log.mode) == 0) {
			dpc.log.dpc_mask |= DPC_LOG_MASK_MODE;
		}
		if (get_log_level(dpc_addr, node_off, &dpc.log.level) == 0) {
			dpc.log.dpc_mask |= DPC_LOG_MASK_LEVEL;
		}
		if (get_log_timestamp_mode(dpc_addr, node_off, &dpc.log.ts_mode) == 0) {
			dpc.log.dpc_mask |= DPC_LOG_MASK_TIMESTAMP;
		}
		if (get_log_module_levels(dpc_addr, node_off, dpc.log.module_levels) > 0) {
			dpc.log.dpc_mask |= DPC_LOG_MASK_MODULE_LEVELS;
		}
		
		if (getprop_val(dpc_addr, node_off, "mem_size_kb", 0, 0, &val) == 0) {
			dpc.log.mem_size_kb = (uint64_t)val;
			dpc.log.dpc_mask |= DPC_LOG_MASK_MEM_SIZE;
		}
	}
	return 0;
}

static int get_link_type(void *lo, int node_off, enum dpmac_link_type *link_type)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		enum dpmac_link_type link_type;
	} map[] = {
			{ "MAC_LINK_TYPE_NONE", DPMAC_LINK_TYPE_NONE },
			{ "MAC_LINK_TYPE_FIXED", DPMAC_LINK_TYPE_FIXED },
			{ "MAC_LINK_TYPE_PHY", DPMAC_LINK_TYPE_PHY },
			{ "MAC_LINK_TYPE_BACKPLANE", DPMAC_LINK_TYPE_BACKPLANE },
			{ "MAC_LINK_TYPE_RECYCLE", DPMAC_LINK_TYPE_RECYCLE }
	};

	str = (char *)fdt_getprop(lo, node_off, "link_type", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (!strcmp(str, map[i].str)) {
			*link_type = map[i].link_type;
			return 0;
		}
	}
	return -EINVAL;
}

static int get_fec_mode(void *lo, int node_off, enum dpmac_fec_mode *fec_mode)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		enum dpmac_fec_mode fec_mode;
	} map[] = {
			{ "none", DPMAC_FEC_NONE },
			{ "rs", DPMAC_FEC_RS },
			{ "fc", DPMAC_FEC_FC },
	};

	str = (char *)fdt_getprop(lo, node_off, "fec_mode", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (!strcmp(str, map[i].str)) {
			*fec_mode = map[i].fec_mode;
			return 0;
		}
	}
	return -EINVAL;
}

static int get_serdes_cfg(void *lo, int node_off, struct serdes_eq_settings *serdes_cfg)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		enum serdes_eq_cfg_mode cfg;
	} map[] = {
			{ "default", SERDES_CFG_DEFAULT },
			{ "sfi",     SERDES_CFG_SFI },
			{ "custom",  SERDES_CFG_CUSTOM },
	};

	str = (char *)fdt_getprop(lo, node_off, "serdes_cfg", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (!strcmp(str, map[i].str)) {
			serdes_cfg->cfg = map[i].cfg;
			break;
		}
	}

	/* initialize the serdes_cfg structure to _KEEP_EXISTING (-1) */
	serdes_cfg->eq_type = SERDES_CFG_KEEP_EXISTING;
	serdes_cfg->eq_amp_red = SERDES_CFG_KEEP_EXISTING;
	serdes_cfg->eq_preq = SERDES_CFG_KEEP_EXISTING;
	serdes_cfg->eq_post1q = SERDES_CFG_KEEP_EXISTING;
	serdes_cfg->sgn_post1q = SERDES_CFG_KEEP_EXISTING;
	serdes_cfg->sgn_preq = SERDES_CFG_KEEP_EXISTING;

	/* the structure was added to avoid using too many bits in the dpc mask.
	 * only 1 bit was added to select the operating mode (custom/sfi/etc)
	 */
	switch (serdes_cfg->cfg) {
	case SERDES_CFG_CUSTOM:
		DPC_PROPERTY_TEST_AND_GET(lo, node_off, "serdes_eq", serdes_cfg->eq_type);
		DPC_PROPERTY_TEST_AND_GET(lo, node_off, "serdes_amp", serdes_cfg->eq_amp_red);
		DPC_PROPERTY_TEST_AND_GET(lo, node_off, "serdes_preq", serdes_cfg->eq_preq);
		DPC_PROPERTY_TEST_AND_GET(lo, node_off, "serdes_post1q", serdes_cfg->eq_post1q);
		DPC_PROPERTY_TEST_AND_GET(lo, node_off, "serdes_sgn_preq", serdes_cfg->sgn_preq);
		DPC_PROPERTY_TEST_AND_GET(lo, node_off, "serdes_sgn_post1q", serdes_cfg->sgn_post1q);
		break;
	case SERDES_CFG_SFI:
		/* SFI settings will be applied in dpmac_hw_init, for the eventuality when
		 * standard will cover other types of interfaces, not to mention the eventuality when
		 * identical interfaces (e.g. XFI) required different settings due to different
		 * implementations in SoC
		 */
	case SERDES_CFG_DEFAULT:
		break;
	default:
		return -ENOSYS;
	}

	return 0;
}

static int get_autoneg(void *lo, int node_off, uint8_t *autoneg)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		uint8_t autoneg;
	} map[] = {
			{ "off", 0 },
			{ "on", 1 }
	};

	str = (char *)fdt_getprop(lo, node_off, "pcs_autoneg", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++)
		if (!strcmp(str, map[i].str)) {
			*autoneg = map[i].autoneg;
			return 0;
		}
	return -EINVAL;
}

static int get_link_check(void *lo, int node_off, uint8_t *debug_link_check)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		uint8_t debug_link_check;
	} map[] = {
			{ "off", 0 },
			{ "on", 1 }
	};

	str = (char *)fdt_getprop(lo, node_off, "debug_link_check", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++)
		if (!strcmp(str, map[i].str)) {
			*debug_link_check = map[i].debug_link_check;
			return 0;
		}
	return -EINVAL;
}

static int get_enet_if(void *lo, int node_off, enum enet_interface *enet_if)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		enum enet_interface enet_if;
	} map[] = {
			{ "MAC_ENET_IF_1000BASEX", FSL_ENET_IF_SGMII_BASEX }, /* backwards compatibility */
			{ "1000BASEX", FSL_ENET_IF_SGMII_BASEX },
			{ "USXGMII", FSL_ENET_IF_USXGMII },
			{ "XFI", FSL_ENET_IF_XFI },
			{ "CAUI", FSL_ENET_IF_CAUI },
			{ "SGMII", FSL_ENET_IF_SGMII },

	};

	str = (char *)fdt_getprop(lo, node_off, "enet_if", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++)
		if (!strcmp(str, map[i].str)) {
			*enet_if = map[i].enet_if;
			return 0;
		}
	return -EINVAL;
}

static int get_rate_cfg(void *lo, int node_off, uint32_t *rate)
{
	char *str;
	int i = 0;
	static struct {
		char *str;
		uint32_t rate;
	} map[] = {
			{ "1G",	  1000 },  /**< 1G */
			{ "2.5G", 2500 },  /**< 2.5G */
			{ "5G",   5000 },  /**< 5G */
			{ "10G",  10000},  /**< 10G */
			{ "20G",  20000},  /**< 20G */
			{ "25G",  25000},  /**< 25G */
			{ "40G",  40000},  /**< 40G */
			{ "50G",  50000},  /**< 50G */
			{ "100G", 100000}  /**< 100G */
	};

	str = (char *)fdt_getprop(lo, node_off, "max_rate", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++)
		if (!strcmp(str, map[i].str)) {
			*rate = map[i].rate;
			return 0;
		}
	return -EINVAL;
}

static int mac_process(void *dpc_addr, int node_off)
{
	int subnode_off;
	uint64_t val;
	int id, err, i, len;
	void *mac_addr;

	subnode_off = fdt_first_subnode(dpc_addr, node_off);

	while (subnode_off != -FDT_ERR_NOTFOUND) 
	{
		err = get_node_id(dpc_addr, subnode_off, &id);
		/* MAC IDs are 1-16, we need to shift it to 0-15 */
		id--;
		if (err) {
			//pr_err("mac id is not available from DPC\n");
			break;
		}
		if (id < 0 || id >= ARRAY_SIZE(dpc.macs)) {
			//pr_err("mac id should be 0-%d\n", ARRAY_SIZE(dpc.macs) - 1);
			return -EINVAL;
		}

		if (get_autoneg(dpc_addr, subnode_off, &dpc.macs[id].autoneg) == 0)
			dpc.macs[id].dpc_mask |= DPC_MAC_MASK_AUTONEG;

		if (get_link_check(dpc_addr, subnode_off, &dpc.macs[id].debug_link_check) == 0)
			dpc.macs[id].dpc_mask |= DPC_MAC_MASK_DEBUG_LINK_CHECK;

		if (get_enet_if(dpc_addr, subnode_off, &dpc.macs[id].enet_if) == 0)
			dpc.macs[id].dpc_mask |= DPC_MAC_MASK_ENET_IF;

		if (get_link_type(dpc_addr, subnode_off, &dpc.macs[id].link_type) == 0) {
			dpc.macs[id].dpc_mask |= DPC_MAC_MASK_LINK_TYPE;
		}
		if (getprop_val(dpc_addr, subnode_off, "phy_id", 0, 0, &val) == 0) {
			dpc.macs[id].phy_id = (int)val;
			dpc.macs[id].dpc_mask |= DPC_MAC_MASK_PHY_ID;
		}
		if (get_fec_mode(dpc_addr, subnode_off, &dpc.macs[id].fec_mode) == 0) {
			dpc.macs[id].dpc_mask |= DPC_MAC_MASK_FEC_MODE;
		}

		if (get_serdes_cfg(dpc_addr, subnode_off, &dpc.macs[id].serdes_cfg) == 0) {
			dpc.macs[id].dpc_mask |= DPC_MAC_MASK_SERDES_CFG;
		}

		if (get_rate_cfg(dpc_addr, subnode_off, &dpc.macs[id].rate) == 0) {
			dpc.macs[id].dpc_mask |= DPC_MAC_MASK_RATE;
		}

		if (getprop_val(dpc_addr, subnode_off, "ceetm_instance", 0, 0, &val) == 0) {
			dpc.macs[id].ceetm_id = (uint16_t)val;
			dpc.macs[id].dpc_mask |= DPC_MAC_MASK_CEETM_ID;
		}

		mac_addr = fdt_getprop(dpc_addr, subnode_off, "port_mac_address", &len);
		/* Property present */
		if (mac_addr) {
			switch(len) {
			case 6:
				for (i = 0; i < 6; i++)
					dpc.macs[id].port_mac_addr[i] = *((uint8_t*)mac_addr + i);
				break;
			case 24:
				for (i = 0; i < 6; i++)
					dpc.macs[id].port_mac_addr[i] = (uint8_t)*((uint32_t*)mac_addr + i);
				break;
			default:
				pr_warn("Ignored port_mac_address property in DPC, expected size 6 or 24, found %d\n",len);
				break;
			}
		}
		subnode_off = fdt_next_subnode(dpc_addr, subnode_off);
	}

	return 0;
}

static int get_console_mode(void *lo, int node_off, enum console_mode *mode)
{
	char *str;
	int i = 0;
	struct {
		char *str;
		enum console_mode mode;
	} map[] = {
			{ "CONSOLE_MODE_ON", CONSOLE_MODE_ON },
			{ "CONSOLE_MODE_OFF", CONSOLE_MODE_OFF }
	};

	str = (char *)fdt_getprop(lo, node_off, "mode", NULL);
	if (!str)
		return -EINVAL;

	for (i = 0; i < ARRAY_SIZE(map); i++) {
		if (!strcmp(str, map[i].str)) {
			*mode = map[i].mode;
			return 0;
		}
	}
	return -EINVAL;
}

static int console_process(void *dpc_addr, int node_off)
{
	uint64_t val;

	if(!strcmp(fdt_get_name(dpc_addr, fdt_parent_offset(dpc_addr, node_off), NULL), "aiop"))
	{
		/* reading parameters */
		if (get_console_mode(dpc_addr, node_off, &dpc.aiop.console.mode) == 0) {
			dpc.aiop.console.dpc_mask |= DPC_CONSOLE_MASK_MODE;
		}
		if (getprop_val(dpc_addr, node_off, "uart_id", 0, 0, &val) == 0) {
			dpc.aiop.console.uart_id = (int)val;
			dpc.aiop.console.dpc_mask |= DPC_CONSOLE_MASK_UART_ID;
		}
	} else {
		/* reading parameters */
		if (get_console_mode(dpc_addr, node_off, &dpc.console.mode) == 0) {
			dpc.console.dpc_mask |= DPC_CONSOLE_MASK_MODE;
		}
		if (getprop_val(dpc_addr, node_off, "uart_id", 0, 0, &val) == 0) {
			dpc.console.uart_id = (int)val;
			dpc.console.dpc_mask |= DPC_CONSOLE_MASK_UART_ID;
		}
	}
	return 0;
}

#if 0
static int pme_process(void *dpc_addr, int node_off)
{
	struct dpc *dpc;
	uint64_t val;

	dpc.pme.dpc_mask = 0;

	/* reading parameters */
	if (getprop_val(dpc_addr, node_off, "pdsr_size_kb", "DPC_PME_PDSR", DPC_PME_PDSR, &val) == 0) {
		dpc.pme.pdsr_size_kb = (uint32_t)val;
		dpc.pme.dpc_mask |= DPC_PME_MASK_PDSR;
	}
	if (getprop_val(dpc_addr, node_off, "sre_size_kb", "DPC_PME_SRE", DPC_PME_SRE, &val) == 0) {
		dpc.pme.sre_size_kb = (uint32_t)val;
		dpc.pme.dpc_mask |= DPC_PME_MASK_SRE;
	}
	return 0;
}
#endif
static int memory_process(void *dpc_addr, int node_off)
{
	uint64_t val = 0ULL;

	dpc.memory.dpc_mask = 0;

	/* reading parameters */
	if (getprop_val(dpc_addr, node_off, "dpddr_size", 0, 0, &val) == 0) {
		dpc.memory.dpddr_size = val;
		dpc.memory.dpc_mask |= DPC_MEMORY_MASK_DPDDR; // marks property
	}
	val = 0ULL;
	if (getprop_val(dpc_addr, node_off, "mc_sys_ddr_end_address", 0, 0, &val) == 0) {
		dpc.memory.mc_sys_ddr_end_add = val;
		dpc.memory.dpc_mask |= DPC_MEMORY_MASK_MC_END_DDR; // marks property
	}
	val = 0ULL;
	if (getprop_val(dpc_addr, node_off, "mc_sys_ddr_start_address", 0, 0, &val) == 0) {
		dpc.memory.mc_sys_ddr_start_add = val;
		dpc.memory.dpc_mask |= DPC_MEMORY_MASK_MC_START_DDR; // marks property
	}
	return 0;
}

#ifndef TKT011436
#define NUM_OF_DPC_MODULES 6
#else
#define NUM_OF_DPC_MODULES 7
#endif

int dpc_process(void)
{
	int i, err;
	struct dtc dtc[NUM_OF_DPC_MODULES] = { 0 };
	struct sys_dtc_mod_params modules[NUM_OF_DPC_MODULES] = { 0 };
	struct {
		char *node_name[1];
		int (*func_cb)(void *dpc_addr, int node_off);
		int (*remove_cb)(void *dpc_addr, int node_off);
	} map[] = {
				{ "icid_pools", icid_pool_process, NULL },
				{ "qbman", qbman_process, NULL },
#if 0
				{ "pme", pme_process, NULL },
#endif
				{ "memory", memory_process, NULL },
				{ "log", log_process, NULL },
				{ "console", console_process, NULL },
#ifdef TKT011436
				{ "errata", errata_process, NULL },
#endif /* TKT011436 */
				{ "ports", mac_process, NULL }
	};

	/* loop for static definition of dtc */
	for (i = 0; i < NUM_OF_DPC_MODULES; i++) {
		if (i <(NUM_OF_DPC_MODULES - 1))
			dtc[i].next = &(dtc[i+1]);
		dtc[i].module = &modules[i];
	}

	for (i = 0; i < ARRAY_SIZE(map); i++){
		dtc[i].module->num_compats = 1;
		dtc[i].module->compatibles = map[i].node_name;
		dtc[i].module->f_prob_module = map[i].func_cb;
		dtc[i].module->f_remove_module = map[i].remove_cb;
	}

	err = dtc_process(dpc_read(), dtc, NULL);
	if (err) {
		return err;
		//	pr_err("DPC failed\n");
	}
	/* resseting DTC driver */
	return 0;
}

void dpc_get_mac_info(int mac_id, int *disable, uint32_t *link_type,
		int *phy_id, uint32_t *enet_if, uint8_t *autoneg, uint8_t *debug_link_check, uint32_t *rate)
{

	if (link_type)
		if (dpc.macs[mac_id - 1].dpc_mask & DPC_MAC_MASK_LINK_TYPE)
		{
			*link_type = dpc.macs[mac_id - 1].link_type;
			if (*link_type == DPMAC_LINK_TYPE_NONE || *link_type == DPMAC_LINK_TYPE_RECYCLE)
			{
				*disable = 1;
				return;
			}
			else
				if (*link_type == DPMAC_LINK_TYPE_PHY)
				{
					if (!(dpc.macs[mac_id - 1].dpc_mask &
						DPC_MAC_MASK_PHY_ID))
						dpc.macs[mac_id - 1].phy_id = 0;
					*phy_id = dpc.macs[mac_id - 1].phy_id;
				}
		}
		else
			*link_type = dpc.macs[mac_id - 1].link_type = DPMAC_LINK_TYPE_FIXED;

	if (enet_if)
		if (dpc.macs[mac_id - 1].dpc_mask & DPC_MAC_MASK_ENET_IF)
			*enet_if = dpc.macs[mac_id - 1].enet_if;

	if (autoneg) {
		if (dpc.macs[mac_id - 1].dpc_mask & DPC_MAC_MASK_AUTONEG)
			*autoneg = dpc.macs[mac_id - 1].autoneg;
		else
			/* Set ANEG to ON by default if 'pcs_autoneg' option is missing */
			*autoneg = 1;
	}

	/* This option is used for debug purpose in DPC. If set to false then no link check is done on the PCS.
	 * Link will be reported as always up. This is useful when debugging traffic path from MAC to SERDES.
	 * If for some reason, there is no link at phy level, serdes level, then the only way to test that there is no
	 * issue at PCS level or MAC level is by putting PCS in loopback mode (or MAC in loopback mode) and send traffic.
	 * However the "no link" event propagates to the DPNI. It means that in linux/ u-boot, no traffic can be sent or received
	 * because the rx/ tx queues are stopped. To prevent that, use this option, to always report link up.
	 */
	if (debug_link_check) {
		if (dpc.macs[mac_id - 1].dpc_mask & DPC_MAC_MASK_DEBUG_LINK_CHECK)
			*debug_link_check = dpc.macs[mac_id - 1].debug_link_check;
		else
			/* Set link_check to ON by default if 'debug_link_check' option is missing */
			*debug_link_check = 1;
	}

	if (rate) {
		if (dpc.macs[mac_id - 1].dpc_mask & DPC_MAC_MASK_RATE)
		{
			if (*rate != dpc.macs[mac_id - 1].rate)
				pr_info("Mac %d new max rate %d\n",mac_id,dpc.macs[mac_id - 1].rate);
			*rate = dpc.macs[mac_id - 1].rate;
		}
	}
}

int dpc_get_dpddr_size(uint64_t* dpddr_size)
{
	if (dpc.memory.dpc_mask & DPC_MEMORY_MASK_DPDDR) {
		*dpddr_size = dpc.memory.dpddr_size;
		return 1;
	}
	return 0;
}

int dpc_get_mc_sys_ddr_limits(uint64_t* start_address, uint64_t* end_address)
{
	/* both properties must be set to be taken into account */
	if (dpc.memory.dpc_mask &
			(DPC_MEMORY_MASK_MC_START_DDR | DPC_MEMORY_MASK_MC_END_DDR)) {
		*start_address = dpc.memory.mc_sys_ddr_start_add;
		*end_address = dpc.memory.mc_sys_ddr_end_add;
		return 1;
	}
	return 0;
}
