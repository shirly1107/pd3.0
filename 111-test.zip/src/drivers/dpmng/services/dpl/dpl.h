/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPL_H
#define _DPL_H
#include "dtc/libfdt/libfdt.h"
#include "fsl_dbg.h"
#include "dtc/dtc.h"


#define DPDBG_RESERVED_PORTAL	255

#define DPL_CONTAINERS_NODE "containers"
#define DPL_OBJECTS_NODE "objects"

//unsigned int *lo_read(void);
int dpl_process(void);

int dpl_is_obj_defined(const char*, int);

#endif /* _DPL_H */
