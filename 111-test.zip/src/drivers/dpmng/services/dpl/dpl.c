/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_dbg.h"
#include "kernel/layout.h"
#include "fsl_system.h"
#include "fsl_resman.h"
#include "fsl_soc.h"
#include "drivers/fsl_mc.h"
#include "dtc/dtc.h"
#include "common/fsl_string.h"
#include "fsl_malloc.h"
#include "dpl.h"

#define COMPATIBLE	"compatible"
#define BIND	 1
#define UNBIND	 0
#define STR_MAX_SIZE 16

/* Contains all ids of defined objects */
struct object_ids {
	char type[MAX_OBJ_TYPE_NAME];
	struct object_id_list_item {
		int id;
		struct object_id_list_item* next_id;
	} *ids;
	struct object_ids* next_item;
} *dpl_objdef_ids = NULL, *dpl_objdecl_ids = NULL;

/* Add object id to type set and check if the id was already added.*/
static int add_obj_id_for_type(struct object_ids** obj_ids_list,
								const char* obj_type, int obj_id) {
	struct object_ids* iter = NULL;
	struct object_ids* last_iter = NULL;
	struct object_ids* temp_item = NULL;
	if (!obj_ids_list)
		return -EINVAL;
	if (!obj_type || strlen(obj_type) == 0)
		return -EINVAL;
	iter = *obj_ids_list;
	last_iter = *obj_ids_list;
	while (iter && strcmp(obj_type, iter->type)) {
		last_iter = iter;
		iter = iter->next_item;
	}
	if (iter == NULL) {
		iter = (struct object_ids*)fsl_malloc(sizeof(struct object_ids));
		memset(iter->type, 0, 64);
		strcpy(iter->type, obj_type);
		iter->next_item = NULL;
		iter->ids = (struct object_id_list_item*)
								fsl_malloc(sizeof(struct object_id_list_item));
		iter->ids->id = obj_id;
		iter->ids->next_id = NULL;
		/* preserve the order from dpl */
		if (last_iter)
			last_iter->next_item = iter;
		else
			*obj_ids_list = iter;
	} else {
		struct object_id_list_item* id_iter = iter->ids;
		struct object_id_list_item* last_id_iter = iter->ids;
		while (id_iter && id_iter->id != obj_id) {
			last_id_iter = id_iter;
			id_iter = id_iter->next_id;
		}
		if (id_iter)
			return -EEXIST;
		id_iter = (struct object_id_list_item*)
								fsl_malloc(sizeof(struct object_id_list_item));
		id_iter->id = obj_id;
		id_iter->next_id = NULL;
		last_id_iter->next_id = id_iter; // preserve the dpl order
	}
	return 0;
}

int dpl_is_obj_defined(const char* obj_type, int obj_id) {
	struct object_ids* iter = dpl_objdef_ids;
	int found = 0;
	if (!obj_type || strlen(obj_type) == 0)
		return 0;
	while (iter && strcmp(obj_type, iter->type)) {
		iter = iter->next_item;
	}
	if (iter) {
		struct object_id_list_item* id_iter = iter->ids;
		while (id_iter && id_iter->id != obj_id) {
			id_iter = id_iter->next_id;
		}
		if (id_iter)
			found = 1;
	}
	return found;
}

static void clear_dpl_obj_ids_lists(struct object_ids** obj_ids_list) {
	struct object_ids* iter = NULL;
	struct object_ids* temp_item = NULL;
	if (!obj_ids_list || *obj_ids_list == NULL)
		return;
	iter = *obj_ids_list;
	while (iter) {
		struct object_id_list_item* id_iter = iter->ids;
		struct object_id_list_item* temp_id_item = NULL;
		iter->ids = NULL;
		while (id_iter) {
			temp_id_item = id_iter;
			id_iter = id_iter->next_id;
			temp_id_item->next_id = NULL;
			fsl_free(temp_id_item);
		}
		temp_item = iter;
		iter = iter->next_item;
		temp_item->next_item = NULL;
		fsl_free(temp_item);
	}
	*obj_ids_list = NULL;
}

static unsigned int *lo_read(void)
{
	void *lo = UINT_TO_PTR(0x00F20000);

	if (fdt_magic(lo) == 0xD00DFEED)
		return lo;
	/* support DPL address from GSR register */
#define MC_GSR_READ_LO_MASK     0x3FFFFFFF
	uint32_t tmp;
	struct mc_desc mc_desc;
	uint32_t *mc_gsr_reg;
	int err;

	pr_info("DPL wasn't found at DPL address: 0x%x, searching address in GSR register...\n", PTR_TO_UINT(lo));

	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, 0);
	ASSERT_COND(!err);

	mc_gsr_reg = (uint32_t *)PTR_MOVE(mc_desc.vaddr, 0x8);

	tmp = ioread32(mc_gsr_reg);
	tmp &= MC_GSR_READ_LO_MASK;
	tmp <<= 2;
	return UINT_TO_PTR(tmp);
}

static uint32_t get_res_options(void *lo, int node_off)
{
	char *opt_str;
	int total_len;
	int len;
	int i = 0;
	uint64_t options = 0;
	struct {
		char *opt_str;
		uint32_t options;
	} map[] = {

	{ "DPRC_RES_REQ_OPT_EXPLICIT", DPRC_RES_REQ_OPT_EXPLICIT },
			{ "DPRC_RES_REQ_OPT_ALIGNED",
					DPRC_RES_REQ_OPT_ALIGNED }};

	//check if user entered number instead of define
	getprop_val(lo, node_off, "options", 0, 0, &options);
	if (options > 3){ //options entered as define
		options = 0;
		opt_str = (char *)fdt_getprop(lo, node_off, "options", &total_len);
		if (opt_str && (int)(*opt_str) != 0) {
			while (total_len > 0) {
				while (i < ARRAY_SIZE(map)
					&& strcmp(opt_str, map[i].opt_str))
					i++;
				if (i < ARRAY_SIZE(map)
					&& !strcmp(opt_str, map[i].opt_str))
					options |= map[i].options;
				len = (int)strlen(opt_str) + 1;
				total_len -= len;
				opt_str = PTR_MOVE(opt_str, len );
				i = 0;
			}
		}
	}
	return (uint32_t)options;
}

static int lo_bind_resources(void *lo,
	int node_off,
	struct device *mc_dev,
	int container_id)
{
	int subnode_off;
	struct resman_res_req res_req;
	char *str;
	int err = 0;
	int resman_err;
	uint64_t val;
	uint32_t num_explicit;
	int i;

	memset(&res_req, 0, sizeof(struct resman_res_req));

	subnode_off = fdt_first_subnode(lo, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND) {
		res_req.options = (uint32_t)get_res_options(lo, subnode_off);
		if (res_req.options && DPRC_RES_REQ_OPT_EXPLICIT)
		{
			str = (char *)fdt_getprop(lo, subnode_off, "type", NULL);
			if (str) {
				strncpy(res_req.type, str, sizeof(res_req.type) - 1);
			} else {
				pr_err("dprc@%d - Resource type is not defined\n", container_id);
				return -EINVAL;
			}
			if(getprop_val(lo, subnode_off, "num", 0, 0, &val)){
				pr_err("dprc@%d - 'num' is a required field for %s resource request\n", container_id, str);
				return -EINVAL;
			}
			res_req.num = (uint32_t)val;
			if(getprop_val(lo, subnode_off, "id_base_align", 0, 0, &val)){
				pr_err("dprc@%d- 'id_base_align' is a required field for %s resource\n", container_id, str);
				return -EINVAL;
			}
			res_req.id_base_align = (int)val;
			
			/* reserve portal DPDBG_RESERVED_PORTAL for DPDBG */
			if (res_req.id_base_align <= DPDBG_RESERVED_PORTAL &&
				DPDBG_RESERVED_PORTAL < (res_req.id_base_align + res_req.num)) {
				if (!strcmp(res_req.type, "mcp")) {
					pr_err("portal %d is reserved\n", DPDBG_RESERVED_PORTAL);
					return -EINVAL;
				}
			}
			// explicit resources must be bind one at the time
			if (res_req.num > 1)
			{
				num_explicit = res_req.num;
				res_req.num = 1;
				for (i = 0; i < num_explicit; i++)
				{
					resman_err = resman_bind(mc_dev, &res_req, NULL);
					if (resman_err) {
						pr_err("dprc@%d - %s resource is not available\n", container_id, str);
						return resman_err;
					}
					res_req.id_base_align++;
				}
			}
		}
		subnode_off = fdt_next_subnode(lo, subnode_off);
	}

	return err;
}

static int get_object_preferences(void *lo, int node_off, char *type, int container_id, int *obj_id)
{
	char tokens[STR_MAX_SIZE] = { 0 };
	char obj_name[STR_MAX_SIZE] = { 0 };
	char *tmp_str;

	tmp_str = (char *)fdt_getprop(lo, node_off, "obj_name", NULL);
	ASSERT_COND(tmp_str);

	strncpy(obj_name, tmp_str, sizeof(obj_name) - 1);
	obj_name[strlen(tmp_str)] = '\0';

	tmp_str = strtok(obj_name, "@");
	if (!tmp_str){
		pr_err("dprc@%d - object name %s in is not defined as <name>@<id>!\n", container_id, obj_name);
		return -EINVAL;
	}
	
	*obj_id = atoi(PTR_MOVE(tmp_str,strlen(tmp_str)+1));

	strncpy(tokens, tmp_str, sizeof(tokens) - 1);
	tokens[strlen(tmp_str)] = '\0';

	strncpy(type, tokens, STR_MAX_SIZE - 1);
	type[strlen(tokens)] = '\0';
	return 0;
}

static int lo_bind_dpmcp(struct device *mc_dev, struct resman_res_req *res_req)
{			
	int err;
	
	if (res_req->id_base_align == DPDBG_RESERVED_PORTAL) {
		pr_err("Portal %d is reserved\n", DPDBG_RESERVED_PORTAL);
		return -EINVAL;
	}
	strcpy(res_req->type, "mcp");
	res_req->options = DPRC_RES_REQ_OPT_EXPLICIT;
	res_req->num = 1;

	err = resman_bind(mc_dev, res_req, NULL);
	if (err) {
		pr_err("portal id %d is not available for dpmcp object\n", res_req->id_base_align);
		return err;
	}
	return 0;
}

static int lo_bind_objects(void *lo,
	int node_off,
	struct device *mc_dev,
	int container_id)
{
	int subnode_off;
	char subnode_name[16] = { 0 };
	struct resman_res_req res_req;
	char tmp_str[16] = { 0 };
	char *obj_type;
	int err = 0;
	int i, len;
	uint32_t val;

	memset(&res_req, 0, sizeof(struct resman_res_req));

	subnode_off = fdt_first_subnode(lo, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND) {
		get_node_name(lo, subnode_off, subnode_name);
		if ( strcmp(subnode_name, "obj")==0 ) {
			obj_type = (char *)tmp_str;
			err = get_object_preferences(lo, subnode_off, obj_type, container_id, &res_req.id_base_align);
			if (err)
				return err;
			err = add_obj_id_for_type(&dpl_objdecl_ids, obj_type,
										res_req.id_base_align);
			if (err) {
				if (err == -EEXIST) {
					pr_err(
					"Object %s@%d from dprc@%d already declared in '%s'\n",
					obj_type, res_req.id_base_align, container_id,
					dtc_get_last_visited_node());
				}
				return err;
			}
			if (strcmp(obj_type, "dpmcp") == 0){
				err = lo_bind_dpmcp(mc_dev, &res_req);
				if(err)
					return err;
			}
		}
		else if (!strcmp(subnode_name, "obj_set")) {
			obj_type = (char *)fdt_getprop(lo, subnode_off, "type", NULL);
			fdt_getprop(lo, subnode_off, "ids", &len);
			for (i = 0; (4 * i) < len; i++) {
				getprop_array(lo, subnode_off, "ids", i, &val);
				res_req.id_base_align = (int)val;
				err = add_obj_id_for_type(&dpl_objdecl_ids, obj_type,
											res_req.id_base_align);
				if (err) {
					if (err == -EEXIST) {
						pr_err(
						"Object %s@%d from dprc@%d already declared in '%s'\n",
						obj_type, res_req.id_base_align, container_id,
						dtc_get_last_visited_node());
					}
					return err;
				}
				if (strcmp(obj_type, "dpmcp") == 0){
					err = lo_bind_dpmcp(mc_dev, &res_req);
					if(err)
						return err;
				}
			}
		}
		subnode_off = fdt_next_subnode(lo, subnode_off);
	}

	return err;
}

static int lo_bind(void *lo, int node_off)
{
	struct device *mc_dev;
	int cont_node_off, subnode_off, id;
	const char *subnode_name;
	uint64_t portal_id;
	struct resman_res_req res_req;
	int err;

	mc_dev = sys_get_unique_handle(FSL_MOD_MC);
	CHECK_COND_RETVAL(mc_dev, -ENODEV, "Fail to get MC device");
	cont_node_off = fdt_first_subnode(lo, node_off);
	while (cont_node_off != -FDT_ERR_NOTFOUND) { //goes over all containers
		subnode_off = fdt_first_subnode(lo, cont_node_off);
		getprop_val(lo, cont_node_off, "portal_id", "DPRC_GET_PORTAL_ID_FROM_POOL", DPRC_GET_PORTAL_ID_FROM_POOL, &portal_id);
		if (portal_id && ((int)portal_id != DPRC_GET_PORTAL_ID_FROM_POOL)){
			strcpy(res_req.type, "mcp");
			res_req.id_base_align = (int)portal_id;
			res_req.num = 1;
			res_req.options = DPRC_RES_REQ_OPT_EXPLICIT;
			err = resman_bind(mc_dev, &res_req, NULL);
			if (err) {
				err = get_node_id(lo, cont_node_off, &id);
				CHECK_COND_RETVAL(err = 0, err, "get_node_id() call failed\n");
				pr_err("portal id %d is not available for dprc@%d\n", portal_id, id);
				return err;
			}
		}
		while (subnode_off != -FDT_ERR_NOTFOUND) { //goes over all resources in container
			subnode_name = fdt_get_name(lo, subnode_off, NULL);
			err = get_node_id(lo, cont_node_off, &id);
			if (err)
				return err;
			
			if (subnode_name && !strcmp(subnode_name, "resources")) {
				err = lo_bind_resources(lo, subnode_off, mc_dev, id);
				if (err)
					return err;
			}
			if (subnode_name && !strcmp(subnode_name, "objects")) {
				err = lo_bind_objects(lo, subnode_off, mc_dev, id);
				if (err)
					return err;
			}
			subnode_off = fdt_next_subnode(lo, subnode_off);
		}
		cont_node_off = fdt_next_subnode(lo, cont_node_off);
	}
	return 0;
}

static int lo_count_objects(void *dtc_addr, int node_off) {
	int subnode_off;
	char subnode_name[MAX_OBJ_TYPE_NAME];
	int err = 0;
	int obj_id = 0;
	struct device *mc_dev;

	mc_dev = sys_get_unique_handle(FSL_MOD_MC);
	CHECK_COND_RETVAL(mc_dev, -ENODEV, "Fail to get MC device");
	/* start processing subnodes */
	subnode_off = fdt_first_subnode(dtc_addr, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND) {
		err = get_node_name(dtc_addr, subnode_off, subnode_name);
		obj_id = -1;
		if (!err) {
			err = get_node_id(dtc_addr, subnode_off, &obj_id);
		}
		if (!err) {
			err = add_obj_id_for_type(&dpl_objdef_ids, subnode_name, obj_id);
			/* skip parsing if found dpl configuration issues;
			 eg. duplicate object ids */
			if (err) {
				if (err == -EEXIST)
					pr_err("Object %s@%d already defined in '%s'\n",
							subnode_name, obj_id, dtc_get_last_visited_node());
				return err;
			}
		}
		subnode_off = fdt_next_subnode(dtc_addr, subnode_off);
	}
	return err;
}

/* For preprocessing the dpl before creating containers and objects */
static const struct dtc_node_parser dpl_nodes_preprocess[] = {
	{DPL_CONTAINERS_NODE, lo_bind, 1}, // bind resources like 'mcp' to resman
	{DPL_OBJECTS_NODE, lo_count_objects, 1} // count obj to create
};
static const struct dtc_parse_params preprocess_dpl_params = {
		.node_order = dpl_nodes_preprocess,
		.node_order_size = ARRAY_SIZE(dpl_nodes_preprocess),
		.parse_all_nodes = 0 // parse only the specified nodes
};
/* For processing the dpl in order to create containers and objects */
static const struct dtc_node_parser default_dpl_nodes[] = {
		{DPL_CONTAINERS_NODE, 0, 0}, 	// default probe function
		{DPL_OBJECTS_NODE, 0, 0} 		// default probe function
};
static const struct dtc_parse_params default_dpl_params = {
		.node_order = default_dpl_nodes,
		.node_order_size = ARRAY_SIZE(default_dpl_nodes),
		.parse_all_nodes = 1 // parse all nodes after
};

int dpl_process(void)
{
	void *lo;
	struct resman *resman;
	struct device *mc_dev;
	int err = 0;

	/* goes over layout for binding explicit resources */
	lo = lo_read();
	if (!lo) {
		pr_info("DPL not found; Continuing without DPL\n");
		return 0;
	}
	/* create a temporary 'mc' device which will exist only while
	parsing the dpl in order to avoid "accidentally" calling some
	probe callbacks; the existence of the 'mc' device means that
	the dpl parse action is in progress */
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	CHECK_COND_RETVAL(resman, -ENODEV,
	"Internal error: fail to get resource manager handle. Skip process DPL.");
	mc_dev = (struct device *) resman_create_mc_device(resman);
	CHECK_COND_RETVAL(mc_dev, -ENODEV,
				"Internal error: fail to create MC device. Skip process DPL.");
	sys_add_handle(mc_dev, FSL_MOD_MC, 1, 0);
	resman_clear_root_container(resman);
	do {
		struct dtc* dtc = sys_get_dtc();
		/* preprocess the dpl: to bind resources from 'containers' node and
		 to count the objects to be created from 'objects' node in order to
		 avoid probe or create unnecessary resman devices after parsing the
		 'containers' node.
		TODO: merge objects and containers nodes */
		err = dtc_process(lo, dtc, &preprocess_dpl_params);
		if (err) {
			pr_err(
			"Error while pre-processing '%s'. Ignore DPL configuration.\n",
			dtc_get_last_visited_node());
			break;
		}
		/* actual dpl process */
		err = dtc_process(lo, dtc, &default_dpl_params);
		if (err) {
			pr_err(
			"Error while parsing '%s'. Skip processing the rest of DPL.\n",
			dtc_get_last_visited_node());
		}
	} while (0);
	/* cleanup memory allocated by object id lists */
	clear_dpl_obj_ids_lists(&dpl_objdef_ids);
	clear_dpl_obj_ids_lists(&dpl_objdecl_ids);
	/* destroy the temporary 'mc' device marking the end of dpl parsing */
	pr_info("Release resources not linked to any device...\n");
	resman_unbind_all(mc_dev);
	resman_destroy_mc_device(resman, mc_dev);
	sys_remove_handle(FSL_MOD_MC, 1, 0);
	/* parse errors that the user should be aware must reach here */
	if (err) {
		pr_info("DPL processing completed with errors\n");
		return err;
	}

	pr_info("DPL processing completed successfully\n");
	return 0;
}
