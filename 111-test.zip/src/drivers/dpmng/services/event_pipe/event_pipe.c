/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_event_pipe.h"
#include "fsl_io.h"
#include "fsl_dbg.h"
#include "drivers/fsl_mc.h"
#include "inc/fsl_sys.h"
#include "platform.h"


void event_pipe_init(void)
{

}
