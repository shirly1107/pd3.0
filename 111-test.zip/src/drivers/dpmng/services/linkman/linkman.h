/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          linkman.h

 @Description   LINKMAN internal structures and definitions.
*//***************************************************************************/
#ifndef __LINKMAN_H
#define __LINKMAN_H

#include "kernel/fsl_spinlock.h"
#include "fsl_list.h"
#include "fsl_linkman.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_LINKMAN

#define KEY_SIZE	8

/**
 * @brief	LINKMAN 2.0
 */
struct linkman_link {
	enum linkman_state		state;		/* link state */
        uint32_t 			rate;		/* rate */
        uint32_t			rate_set;	/* rate manually set in connect command */
        uint64_t 			options;	/* options */
        uint32_t			committed_rate; /* Committed rate */
        uint32_t                        max_rate;	/* maximum rate */
        uint64_t            supported;
        uint64_t            advertising;
};

struct linkman {
	linkman_cb_t 	*event_cb[FSL_MOD_DUMMY_LAST];
	linkman_cb_t 	*event_complete_cb[FSL_MOD_DUMMY_LAST];
	struct hmap	*hmap_link;	/* links databse */
	int 		size;		/* number of links */
};

struct connection_point {
	struct linkman_endpoint endpoint;
	void 			*handle;
	linkman_cb_t 		*event_cb;
	linkman_cb_t		*event_complete_cb;
	struct linkman_action	action;
};

struct connection_control_block {
	struct linkman_control  control;
	uint8_t 		key[KEY_SIZE];
	enum linkman_state	state;
	struct connection_point cp1;
	struct connection_point cp2;
};

#endif /* __LINKMAN_H */
