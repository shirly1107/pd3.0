/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          linkman.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_list.h"
#include "linkman.h"
#include "fsl_hmap.h"
#include "fsl_dpdmux_mc.h"
#include "fsl_dpni_mc.h"

/**
 * @brief	linkman2.0
 */
static int connection_control_block_init(struct linkman  *linkman,
        	const struct linkman_control *control,
        	const struct linkman_endpoint *endpoint1,
        	const struct linkman_endpoint *endpoint2,
        	struct connection_control_block	*ccb);

static int connection_params_integrity(struct linkman  *linkman,
		struct connection_control_block	*ccb);

static int connection_state_machine(struct linkman  *linkman,
		struct connection_control_block	*ccb);

static int connection_state_machine_rollback(struct linkman  *linkman,
		struct connection_control_block	*ccb);

static int connection_state_machine_completed(struct linkman  *linkman,
		struct connection_control_block	*ccb);

static int get_connection_key(
        struct linkman                 *linkman,
        const struct linkman_endpoint  *ep,
        hmap_key                        key);

static void make_ep_key(const struct linkman_endpoint *ep, hmap_key key);

static int get_ep_from_key(struct linkman_endpoint *ep, hmap_key key);

static void make_connection_key(
        const struct linkman_endpoint  *ep1,
        const struct linkman_endpoint  *ep2,
        hmap_key                        key);

static int get_connection_epid( int	*epid,
			const struct linkman_endpoint *ep,
			hmap_key key);

static int get_connection_endpoint(int	epid,
			struct linkman_endpoint *ep,
			hmap_key key);

static int is_endpoints_equal(
        const struct linkman_endpoint *ep1,
        const struct linkman_endpoint *ep2);

static int get_next_state(struct linkman  *linkman,
			struct connection_control_block	*ccb, 
			enum linkman_state *state);

enum linkman_state  next_state_tbl[LINKMAN_EVENT_INVALID][LINKMAN_STATE_INVALID] =
{				/* STATE_IDLE */		/* STATE_CANDIDATE */		/* STATE_CONNECTED*/		/* STATE_NEGOTIATION*/		/* STATE_LINKUP*/
/* EVENT_DISCONNECT */   	{LINKMAN_STATE_IDLE,      	LINKMAN_STATE_IDLE,     	LINKMAN_STATE_IDLE,         	LINKMAN_STATE_INVALID,		LINKMAN_STATE_INVALID},
/* EVENT_CONNECT */		{LINKMAN_STATE_CONNECTED,      	LINKMAN_STATE_CANDIDATE,    	LINKMAN_STATE_CONNECTED,       	LINKMAN_STATE_INVALID,		LINKMAN_STATE_INVALID},
/* EVENT_ASSOCIATE */		{LINKMAN_STATE_INVALID,      	LINKMAN_STATE_CONNECTED,     	LINKMAN_STATE_CONNECTED,        LINKMAN_STATE_INVALID,		LINKMAN_STATE_INVALID},
/* EVENT_DEASSOCIATE */		{LINKMAN_STATE_INVALID,      	LINKMAN_STATE_CANDIDATE,     	LINKMAN_STATE_INVALID,         	LINKMAN_STATE_INVALID,		LINKMAN_STATE_INVALID},
/* EVENT_NEGOTIATION_OK */	{LINKMAN_STATE_INVALID,      	LINKMAN_STATE_INVALID,     	LINKMAN_STATE_INVALID,         	LINKMAN_STATE_LINKUP,		LINKMAN_STATE_LINKUP},
/* EVENT_NEGOTIATION_FAIL */	{LINKMAN_STATE_INVALID,      	LINKMAN_STATE_INVALID,     	LINKMAN_STATE_CONNECTED,       	LINKMAN_STATE_CONNECTED,	LINKMAN_STATE_INVALID},
/* EVENT_NEGOTIATION */		{LINKMAN_STATE_INVALID,      	LINKMAN_STATE_INVALID,     	LINKMAN_STATE_INVALID,         	LINKMAN_STATE_NEGOTIATION,	LINKMAN_STATE_NEGOTIATION},
/* EVENT_LINKDOWN */		{LINKMAN_STATE_INVALID,      	LINKMAN_STATE_INVALID,     	LINKMAN_STATE_CONNECTED,       	LINKMAN_STATE_INVALID,		LINKMAN_STATE_CONNECTED},
/* EVENT_LINKUP */		{LINKMAN_STATE_INVALID,      	LINKMAN_STATE_INVALID,     	LINKMAN_STATE_LINKUP,         	LINKMAN_STATE_NEGOTIATION,	LINKMAN_STATE_LINKUP}
};

enum linkman_event rollback_event_tbl[] =
{
/* EVENT_DISCONNECT */		LINKMAN_EVENT_CONNECT,
/* EVENT_CONNECT */		LINKMAN_EVENT_DISCONNECT,
/* EVENT_ASSOCIATE */		LINKMAN_EVENT_DEASSOCIATE,
/* EVENT_DEASSOCIATE */		LINKMAN_EVENT_ASSOCIATE,
/* EVENT_NEGOTIATION_OK */	LINKMAN_EVENT_NEGOTIATION,
/* EVENT_NEGOTIATION_FAIL */	LINKMAN_EVENT_LINKUP,
/* EVENT_NEGOTIATION */		LINKMAN_EVENT_NEGOTIATION_OK,
/* EVENT_LINKDOWN */		LINKMAN_EVENT_LINKUP,
/* EVENT_LINKUP */		LINKMAN_EVENT_LINKDOWN
};


struct linkman *linkman_create(int size)
{
	struct linkman *linkman;
	int i;
	struct linkman_link *link;
	int err;

	/*! Allocate link manager context */
	linkman = (struct linkman *)fsl_malloc(sizeof(struct linkman));
	if (linkman == NULL)
		return NULL;

	memset(linkman, 0, sizeof(struct linkman));

	/* Create connections database */
	linkman->hmap_link = hmap_create(size, KEY_SIZE);
	if (linkman->hmap_link == NULL) {
		linkman_destroy(linkman);
		return NULL;
	}

	/*! Save size */
	linkman->size = size;

	/*! Set connections database */
	for (i = 0; i < size; i++) {
		/* allocate link database */
		link = fsl_malloc(sizeof(struct linkman_link));
		if (link == NULL) {
			linkman_destroy(linkman);
			return NULL;
		}

		/* reset database */
		memset(link, 0, sizeof(struct linkman_link));

		/* setting link database */
		err = hmap_set_data(linkman->hmap_link, i, link);
		if( err ) {
			fsl_free(link);
			linkman_destroy(linkman);
			return NULL;
		}
	}

	return linkman;
}

void linkman_destroy(struct linkman *linkman)
{
	int i;
	struct linkman_link *link;
	int err;

	/* release links database */
	for (i = 0; i < linkman->size && linkman->hmap_link; i++) {
		err = hmap_get_data(linkman->hmap_link, i, (hmap_data *)&link);
		CHECK_COND_RET( err == 0 );
		if (link != NULL)
			fsl_free(link);
	}

	/*! Destory link manager database */
	if (linkman->hmap_link != NULL)
		hmap_destroy(linkman->hmap_link);

	/*! free link manager memmory */
	fsl_free(linkman);
}

int linkman_register_cb(struct linkman        	*linkman,
                        enum fsl_module      type,
                        linkman_cb_t    	*event_cb,
                        linkman_cb_t  		*event_complete_cb)
{
	if ((event_cb == NULL) || (event_complete_cb == NULL))
		return EINVAL;

	linkman->event_cb[type] = event_cb;
	linkman->event_complete_cb[type] = event_complete_cb;

	return 0;
}

int linkman_unregister_cb(struct linkman        *linkman,
                        enum fsl_module  	type)
{
	linkman->event_cb[type] = NULL;
	linkman->event_complete_cb[type] = NULL;

	return 0;
}

int linkman_set_connection (
        struct linkman         *linkman,
        const struct linkman_control *control,
        const struct linkman_endpoint *endpoint1,
        const struct linkman_endpoint *endpoint2)
{
	int err = 0;
	struct connection_control_block	ccb;

	/* Init Connection Control Block */
	err = connection_control_block_init(
		linkman, 		/* Context */
	        control,       		/* Control information */
	        endpoint1,    		/* endpoint 1 */
	        endpoint2,		/* endpoint 2 */
	        &ccb);			/* Connection Control Block */
	/* After AIOP reset the connection may already exist so we must check parameters integrity*/
	if ( err != 0 && (err != -EEXIST) )
		return err;

	/* Verify Parameters integrity */
	err = connection_params_integrity(linkman, &ccb);
	if (err != 0)
		return (err == -EEXIST) ? 0 : err;

	/* Execute state machine */
	err = connection_state_machine(linkman, &ccb);
	if (err != 0) {
		/* roll back */
		connection_state_machine_rollback(linkman, &ccb);
		return err;
	}

	/* State machine completed */
	err = connection_state_machine_completed(linkman, &ccb);

	return err;
}

static int connection_control_block_init(struct linkman  *linkman,
        	const struct linkman_control *control,
        	const struct linkman_endpoint *ep1,
        	const struct linkman_endpoint *ep2,
        	struct connection_control_block	*ccb)
{
	int err1, err2, err = 0;

	struct linkman_connection_attr	attr;

	memset(ccb, 0x0, sizeof(struct connection_control_block));


	if (control->event == LINKMAN_EVENT_CONNECT) {
		/* look for end-points in database */
		err1 = get_connection_key(linkman, ep1, ccb->key);
		err2 = get_connection_key(linkman, ep2, ccb->key);

		/* make sure end-points are not there */
		if ((err1 != 0) && (err2 != 0)) {

			/* create connection key */
                        make_connection_key(ep1, ep2, ccb->key);

                        /* set initial state */
			ccb->state = LINKMAN_STATE_IDLE;

			/* save committed & max rate */
			ccb->control.max_rate = control->max_rate;
			ccb->control.committed_rate = control->committed_rate;
			ccb->control.supported = control->supported;

			/* End points */
			memcpy(&(ccb->cp1.endpoint), ep1,
				sizeof(struct linkman_endpoint));
			memcpy(&(ccb->cp2.endpoint), ep2,
				sizeof(struct linkman_endpoint));
		}
		else
			return -EEXIST;
	}
	else {
		/* get connection */
		err = linkman_get_connection(linkman, ep1,
		                             &(ccb->cp2.endpoint), &attr);
		if (err != 0)
			return err;

		/* copy first endpoint */
		memcpy(&(ccb->cp1.endpoint), ep1,
			sizeof(struct linkman_endpoint));

		/* Get connection key */
		err = get_connection_key(linkman, ep1, ccb->key);
		if (err != 0)
			return err;

		/* Get current state */
		ccb->state = attr.state;

		/* get committed & maximum rate */
		ccb->control.max_rate = attr.max_rate;
		ccb->control.committed_rate = attr.committed_rate;
		ccb->control.supported = attr.supported;
	}


	/* Control information */
	ccb->control.event = control->event;
	ccb->control.cmd = control->cmd;
	if (control->supported)
	{
	     ccb->control.supported = control->supported;
	}

	/* handles */
	ccb->cp1.handle = sys_get_handle(ccb->cp1.endpoint.type, 1,
	                                 ccb->cp1.endpoint.id);
	ccb->cp2.handle = sys_get_handle(ccb->cp2.endpoint.type, 1,
	                                 ccb->cp2.endpoint.id);
	if ((ccb->cp1.handle == NULL) || (ccb->cp2.handle == NULL))
		return -ENODEV;			/* No such device */

	/* callback */
	ccb->cp1.event_cb = linkman->event_cb[ccb->cp1.endpoint.type];
	ccb->cp2.event_cb = linkman->event_cb[ccb->cp2.endpoint.type];

	/* complete callback*/
	ccb->cp1.event_complete_cb = linkman->event_complete_cb[ccb->cp1.endpoint.type];
	ccb->cp2.event_complete_cb = linkman->event_complete_cb[ccb->cp2.endpoint.type];

	/* verify callbacks */
	if ((ccb->cp1.event_cb == NULL) ||
		(ccb->cp2.event_cb == NULL) ||
		(ccb->cp1.event_complete_cb == NULL) ||
		(ccb->cp2.event_complete_cb == NULL))
		return -ENAVAIL;

	return err;
}

static int connection_params_integrity(struct linkman  *linkman,
		struct connection_control_block	*ccb)
{
	int err = 0;
	enum linkman_state	next_state;

	err = get_next_state(linkman, ccb, &next_state);
	if (err != 0)
		return err;
	
	if (next_state == LINKMAN_STATE_INVALID)
		err = -EINVAL;
	else if (next_state == ccb->state)
		err = -EEXIST;

	return err;
}

static int connection_state_machine(struct linkman  *linkman,
		struct connection_control_block	*ccb)
{
	int err1 = LINKMAN_ECONT, err2 = LINKMAN_ECONT;

	do{
		if (err2 == LINKMAN_ECONT) {
			err2 = ccb->cp2.event_cb(
				ccb->cp2.handle, 	/* handle */
				&(ccb->control),	/* control */
				&(ccb->cp2.endpoint),	/* self */
				&(ccb->cp1.endpoint),	/* peer */
				&(ccb->cp2.action));	/* required action */
		}

		if ((err1 == LINKMAN_ECONT) && ((err2 == 0) || (err2 == LINKMAN_ECONT))) {
			err1 = ccb->cp1.event_cb(
				ccb->cp1.handle, 	/* handle */
				&(ccb->control),	/* control */
				&(ccb->cp1.endpoint),	/* self */
				&(ccb->cp2.endpoint),	/* peer */
				&(ccb->cp1.action));	/* required action */
		}
	}while(((err1 == LINKMAN_ECONT) && (err2 == 0)) ||
		((err1 == 0) && (err2 == LINKMAN_ECONT)) ||
		((err1 == LINKMAN_ECONT) && (err2 == LINKMAN_ECONT)));

	return ((err1 != 0) && (err1 != LINKMAN_ECONT)) ? err1 : err2;
}

static void update_link_rate(struct linkman *linkman,
							 struct linkman_link *link,
							 struct connection_control_block *ccb)
{
	int err = 0;
	struct dpdmux *dpdmux = NULL;
	struct dpni *dpni;
	struct linkman_endpoint dpdmux_endpoint = { 0 };
	struct linkman_endpoint endpoint = { 0 };
	struct linkman_connection_attr attr;
	struct linkman_control control;
	uint16_t i, id, num_ifs = 0;
	uint8_t key[KEY_SIZE] = { 0 };
	struct linkman_link *new_link = NULL;

	memset(&attr, 0, sizeof(struct linkman_connection_attr));
	memset(&control, 0, sizeof(struct linkman_control));

	/* 1st scenario: dpdmux dpmac. Connect a dpni */
	if (ccb->cp1.endpoint.type == FSL_MOD_DPNI &&
			ccb->cp2.endpoint.type == FSL_MOD_DPDMUX)
		dpdmux = (struct dpdmux *) ccb->cp2.handle;
	if (ccb->cp1.endpoint.type == FSL_MOD_DPDMUX &&
			ccb->cp2.endpoint.type == FSL_MOD_DPNI)
		dpdmux = (struct dpdmux *) ccb->cp1.handle;
	if (dpdmux && !ccb->control.committed_rate) {
		link->rate_set = 0;
		dpdmux_get_mac_rate(dpdmux, &link->rate);
	} else if (ccb->control.committed_rate)
		link->rate_set = 1;
	dpdmux = NULL;

	/* 2nd scenario: connect or disconnect a dpmac.
	 * Update the link configuration for all dpnis.
	 */
	if (ccb->cp1.endpoint.type == FSL_MOD_DPDMUX &&
			ccb->cp2.endpoint.type == FSL_MOD_DPMAC)
		dpdmux = (struct dpdmux *) ccb->cp1.handle;
	if (ccb->cp1.endpoint.type == FSL_MOD_DPMAC &&
			ccb->cp2.endpoint.type == FSL_MOD_DPDMUX)
		dpdmux = (struct dpdmux *) ccb->cp2.handle;
	if (dpdmux) {
		dpdmux_get_num_ifs(dpdmux, &num_ifs);
		dpdmux_endpoint.type = FSL_MOD_DPDMUX;
		dpdmux_get_id(dpdmux, &dpdmux_endpoint.id);

		for (i = 1; i < num_ifs; i++) {
			memset(&endpoint, 0, sizeof(struct linkman_endpoint));

			dpdmux_endpoint.if_id = i;
			err = linkman_get_connection(linkman, &dpdmux_endpoint,
										 &endpoint, &attr);
			if (err)
				continue;

			/* check that a dpni is connected */
			if (endpoint.type != FSL_MOD_DPNI)
				continue;

			/* redefine the link rate */
			make_connection_key(&dpdmux_endpoint, &endpoint, key);
			err = hmap_lookup(linkman->hmap_link, key,
							  (hmap_data *)&(new_link));
			if (err != 0) {
				make_connection_key(&endpoint, &dpdmux_endpoint, key);
				err = hmap_lookup(linkman->hmap_link, key,
								  (hmap_data *)&(new_link));
				if (err != 0) {
					pr_err("ID[%d] Lookup error when searching\
							link cfg on if %d\n", dpdmux_endpoint.id, i);
					continue;
				}
			}

			/* if rate_set is 1, rate must not be updated */
			if (new_link->rate_set)
				continue;

			/* update the link rate */
			dpdmux_get_mac_rate(dpdmux, &new_link->rate);

			/* send interrupt to mc for updating the rate */
			dpni = (struct dpni *) sys_get_handle(endpoint.type, 1,
												  endpoint.id);
			if (dpni) {
				control.event = LINKMAN_EVENT_LINKDOWN;
				err = dpni_linkman_event_complete_cb(dpni, &control, NULL,
													 NULL, NULL);
				if (err)
					pr_err("ID[%d] Dpni interrupt error when updating link cfg\
							on if %d\n", dpdmux_endpoint.id, i);
			}
		}
	}
}

static int connection_state_machine_completed(struct linkman  *linkman,
		struct connection_control_block	*ccb)
{
	int err = 0;
	struct linkman_link	*link;

	if (ccb->control.event == LINKMAN_EVENT_CONNECT) {
                /* add connection */
                err = hmap_add_key(linkman->hmap_link, ccb->key);
                if (err != 0)
                        return err;
	}

	/* Obtain link information */
	err = hmap_lookup(linkman->hmap_link, ccb->key, (hmap_data *)&(link));
	if (err != 0)
		return err;

	/* Update connection state */
	err = get_next_state(linkman, ccb, &(link->state));
	if (err != 0)
		return err;

	/* committed & Maximum rate */
	link->max_rate = ccb->control.max_rate;
	link->committed_rate = ccb->control.committed_rate;
	link->supported = ccb->control.supported;

	switch (link->state) {
		case LINKMAN_STATE_IDLE:
			err = hmap_remove_key(linkman->hmap_link, ccb->key);
			if (err != 0)
				return err;
			memset(link, 0x0, sizeof(struct linkman_link));
			break;
		case LINKMAN_STATE_LINKUP:
			/*
			 * Consider generating an error when end point rates
			 * are not identical
			 * */
			link->rate = ccb->cp1.action.state.rate;
			link->options = ccb->cp1.action.state.options;
			link->advertising = ccb->cp1.action.state.advertising;
			break;
		default:
			break;
	}

	/* update the link rate when connecting a dpmac/dpni to dpdmux */
	update_link_rate(linkman, link, ccb);

	/* Completion Notification */
	if (ccb->cp1.action.request & LINKMAN_REQUEST_COMPLETE_CB) {
		ccb->cp1.event_complete_cb(
			ccb->cp1.handle, 	/* handle */
			&(ccb->control),	/* control */
			&(ccb->cp1.endpoint),	/* self */
			&(ccb->cp2.endpoint),	/* peer */
			&(ccb->cp1.action));	/* required action */
	}
	if (ccb->cp2.action.request & LINKMAN_REQUEST_COMPLETE_CB) {
		ccb->cp2.event_complete_cb(
			ccb->cp2.handle, 	/* handle */
			&(ccb->control),	/* control */
			&(ccb->cp2.endpoint),	/* self */
			&(ccb->cp1.endpoint),	/* peer */
			&(ccb->cp2.action));	/* required action */
	}

        return err;
}

static int get_next_state(struct linkman  *linkman,
			struct connection_control_block	*ccb, 
			enum linkman_state *state)
{
	uint32_t    request;        	/* bitmap Request */

	/* just in case */
	if ((ccb->control.event == LINKMAN_EVENT_INVALID) || 
		(ccb->state == LINKMAN_STATE_INVALID))
		return -EACCES;
	
	/* get default state */
	*state = next_state_tbl[ccb->control.event][ccb->state];

	/* Get request */
	request = ccb->cp1.action.request | ccb->cp2.action.request;

	switch(ccb->state) {
		case LINKMAN_STATE_IDLE:
			if (request & LINKMAN_REQUEST_CANDIDATE)
				*state = LINKMAN_STATE_CANDIDATE;
			break;
		case LINKMAN_STATE_CANDIDATE:
			break;
		case LINKMAN_STATE_CONNECTED:
			if (request & LINKMAN_REQUEST_NEGOTIATION)
				*state = LINKMAN_STATE_NEGOTIATION;
			break;
		case LINKMAN_STATE_NEGOTIATION:
			break;
		case LINKMAN_STATE_LINKUP:
			break;
		default:
			break;
	}

	return 0;
}

int linkman_get_connection(
	struct linkman 			*linkman,
	const struct linkman_endpoint	*ep1,
        struct linkman_endpoint		*ep2,
        struct linkman_connection_attr	*attr)
{
	int err = 0, epid;
	uint8_t	key[KEY_SIZE];
	struct linkman_link	*link;

	/* Get connection key */
	err = get_connection_key(linkman, ep1, key);
	if (err != 0) {
		attr->state = LINKMAN_STATE_IDLE;
		return 0;
	}

	/* get End-point #1 id*/
	err = get_connection_epid(&epid, ep1, key);
	if (err != 0)
		return -EINVAL;

	/* obtain the other end-point */
	err = get_connection_endpoint(!epid, ep2, key);
	if (err != 0)
		return err;

	/* get link database */
	err = hmap_lookup(linkman->hmap_link, key, (hmap_data *)&link);
	if (err != 0)
		return err;

	attr->committed_rate = link->committed_rate;
	attr->max_rate = link->max_rate;
	attr->options = link->options;
	attr->rate = link->rate;
	attr->state = link->state;
	attr->supported = link->supported;
	attr->advertising = link->advertising;

	return err;
}

static void make_ep_key(const struct linkman_endpoint *ep, hmap_key key)
{
/*
 * 0 -7  type
 * 8 -19 id
 * 20-31 interface id
 * */
	uint32_t	u_key;

	/* Make uint32 key */
	u_key = u32_enc(0, 8, ep->type);
	u_key |= u32_enc(8, 12, ep->id);
	u_key |= u32_enc(20, 12, ep->if_id);

	/* make string key */
	key[0] = UINT8_LO(UINT16_LO(u_key));
	key[1] = UINT8_HI(UINT16_LO(u_key));
	key[2] = UINT8_LO(UINT16_HI(u_key));
	key[3] = UINT8_HI(UINT16_HI(u_key));
}

static int get_ep_from_key(struct linkman_endpoint *ep, hmap_key key)
{
	uint32_t	u_key;


	/* Make uint32 key from string */
	u_key = MAKE_UINT32(MAKE_UINT16(key[3], key[2]),
	                    MAKE_UINT16(key[1], key[0]));

	/*! make endpoint */
	ep->type = (enum fsl_module)u32_dec(u_key, 0, 8);
	ep->id = (uint16_t)u32_dec(u_key, 8, 12);
	ep->if_id = (uint16_t)u32_dec(u_key, 20, 12);

	return 0;
}

static void make_connection_key(
        const struct linkman_endpoint  *ep1,
        const struct linkman_endpoint  *ep2,
        hmap_key                        key)
{
	make_ep_key(ep1, &(key[0]));
	make_ep_key(ep2, &(key[KEY_SIZE/2]));
}

static int get_connection_key(
        struct linkman                 *linkman,
        const struct linkman_endpoint  *ep,
        hmap_key                        key)
{
        int err;
        struct hmap_mask mask;
	struct linkman_link	*link;

        /*! make a key for ep1 */
        make_ep_key(ep, key);

        /*! search in left half of the key */
        mask.size = KEY_SIZE/2;
        mask.start = 0;
        err = hmap_ternary_lookup(linkman->hmap_link,
                        key, &mask, (hmap_data *)&link);

        if (err != 0) {
                /*! search in right half of the key */
                mask.size = KEY_SIZE/2;
                mask.start = KEY_SIZE/2;
                err = hmap_ternary_lookup(linkman->hmap_link,
                                key, &mask, (hmap_data *)&link);
                if (err != 0)
                        return err;
        }
        return err;
}

static int get_connection_epid(int	*epid,
			const struct linkman_endpoint *ep,
			hmap_key key)
{
	int err;
	struct linkman_endpoint	endpoint;

	/* extract first end-point */
	err = get_ep_from_key(&endpoint, key);
	if (err != 0)
		return err;

	/* Verify first endpoint */
	if( is_endpoints_equal(&endpoint, ep) == 1) {
		*epid = 0;
		return 0;
	}

	/* Get second endpoint */
	err = get_ep_from_key(&endpoint, &(key[KEY_SIZE/2]));
	if (err != 0)
		return err;

	/* Verify first endpoint */
	if( is_endpoints_equal(&endpoint, ep) == 1) {
		*epid = 1;
		return 0;
	}
	return -ENODEV;
}

static int get_connection_endpoint(int	epid,
			struct linkman_endpoint *ep,
			hmap_key key)
{
	int offset = (epid == 0) ? 0 : KEY_SIZE/2;

	return get_ep_from_key(ep, &(key[offset]));
}

static int is_endpoints_equal(
        const struct linkman_endpoint *ep1,
        const struct linkman_endpoint *ep2)
{
	 return ((ep1->type == ep2->type) &&
		 (ep1->id == ep2->id) && (ep1->if_id == ep2->if_id));
}

static int connection_state_machine_rollback(struct linkman  *linkman,
		struct connection_control_block	*ccb)
{
	int err = 0;

	/* Get rollback event */
	ccb->control.event = rollback_event_tbl[ccb->control.event];

	/* Execute state machine */
	err = connection_state_machine(linkman, ccb);

	return err;
}
