/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_soc.h"
#include "fsl_platform.h"
#include "dtc/dtc.h"
#include "fsl_dbg.h"
#include "kernel/layout.h"

#include "fsl_linkman.h"

#include "fsl_resman.h"

#define MAX_STR_LENGTH 64

int linkman_drv_init(void);

static int get_device_type(char *dev_name, char *type_name, enum fsl_module *type)
{
	char *token;
	char original[MAX_STR_LENGTH];
	strncpy(original, dev_name, sizeof(original)-1);
	original[strlen(dev_name)] = 0;
	token = strtok(original, "@");
	if (token) {
		if (type_name)
			strcpy(type_name, token);

		if (!strcmp(token, "dpni")) {
			*type = FSL_MOD_DPNI;
			return 0;
		}
		if (!strcmp(token, "dpdmux")){
			*type = FSL_MOD_DPDMUX;
			return 0;
		}
		if (!strcmp(token, "dpmac")){
			*type = FSL_MOD_DPMAC;
			return 0;
		}
		if (!strcmp(token, "dpsw")) {
			*type = FSL_MOD_DPSW;
			return 0;
		}
		if (!strcmp(token, "dplag")) {
			*type = FSL_MOD_DPLAG;
			return 0;
		}
		if (!strcmp(token, "dpci")) {
			*type = FSL_MOD_DPCI;
			return 0;
		}
	}
	pr_err("Invalid device type to link: '%s'\n", token);
	return -EINVAL;
}

static int get_device_id(char *dev_str, uint16_t *id)
{
	char *tokens;
	char original[MAX_STR_LENGTH];
	strncpy(original, dev_str, sizeof(original) - 1);
	original[strlen(dev_str)] = 0;
	tokens = strtok(original, "@");
	if (!tokens) {
		return -EINVAL;
	}
	tokens = PTR_MOVE(tokens, strlen(tokens)+1);
	tokens = strtok(tokens, "/");
	if (!tokens) {
		return -EINVAL;
	}
	*id = (uint16_t)atoi(tokens);
	return 0;
}

static int get_if_id(char *dev_str, uint16_t *id)
{
	char *tokens;
	char original[MAX_STR_LENGTH];
	strncpy(original, dev_str, sizeof(original) - 1);
	original[strlen(dev_str)] = 0;
	tokens = strtok(original, "/");
	if (!tokens) {
		return -EINVAL;
	}
	tokens = PTR_MOVE(tokens, strlen(tokens)+1);
	tokens = strtok(tokens, "@");
	if (!tokens) {
		return -EINVAL;
	}
	*id = (uint16_t)atoi(PTR_MOVE(tokens,strlen(tokens)+1));
	return 0;
}



static int get_dev_cfg(char *prop, char *type_name, struct linkman_endpoint *ep)
{
	int err = 0;

	/*! Obtain device type */
	err = get_device_type(prop, type_name, &(ep->type));
	if (err != 0)
		return err;

	/*! Obtain device id */
	err = get_device_id(prop, &(ep->id));
	if (err != 0) {
		pr_err("Did not get device ID for %s", prop);
		return err;
	}
	/*! Obtain device interface id */
	if (ep->type == FSL_MOD_DPSW ||
		ep->type == FSL_MOD_DPDMUX ||
		ep->type == FSL_MOD_DPLAG){
		err = get_if_id(prop, &(ep->if_id));
		if (err)
			pr_err("Did not get interface ID\n");
	}
	return err;
}

static char *linkman_type_to_dp_res_type(enum fsl_module type)
{
	switch (type) {
		case FSL_MOD_DPMAC:
			return "dpmac";
		case FSL_MOD_DPSW:
			return "dpsw";
		case FSL_MOD_DPDMUX:
			return "dpdmux";
		case FSL_MOD_DPNI:
			return "dpni";
		default:
			return "no_dev";
	}
}

static int linkman_probe_cb(void *lo, int node_off)
{
	int err = 0;
	char *prop;
	char ep1_type[16], ep2_type[16];
	struct linkman_endpoint ep1, ep2;
	struct linkman *linkman;
	struct linkman_control 	control;
	struct resman *resman;
	int id;
	uint64_t val;

	/*! Obtain link manager */
	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	if (linkman == NULL) {
		pr_err ("Can't find linkman\n");
		return -ENODEV;
	}

	/*! Parse layout */
#if 0
	subnode_off = fdt_first_subnode(lo, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND)
	{
#endif
		memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
		memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
		memset(&control, 0x0, sizeof(struct linkman_control));

		/* first device to link */
		prop = (char *)fdt_getprop(lo, node_off, "endpoint1", NULL);
		if (!prop){
			pr_err("no device to link.\n");
			return -EINVAL;
		}

		/*! Get first endpoint */
		err = get_dev_cfg(prop, ep1_type, &ep1);
		if (err != 0)
			return err;

		/* Parse to second endpoint */
		prop = (char *)fdt_getprop(lo, node_off, "endpoint2", NULL);
		if (prop == NULL) {
			pr_err("no device to link.\n");
			return -EINVAL;
		}

		/* Get second endpoint */
		err = get_dev_cfg(prop, ep2_type, &ep2);
		if (err != 0)
			return err;

		/* get endpoints containers and check common parent */
		resman = sys_get_unique_handle(FSL_MOD_RESMAN);
		ASSERT_COND(resman);

		if (resman_is_link_permitted(
						resman, ep1_type, ep1.id, ep2_type, ep2.id, NULL)) {
			pr_err("No common ancestor - Failed to connect %s@%d and %s@%d \n",
				   ep1_type, ep1.id, ep2_type, ep2.id);
			return -EPERM;
		}

		/*! Generate connect event */
		/* Get rates */
		getprop_val(lo, node_off, "committed_rate", 0, 0, &val);
		control.committed_rate = (uint32_t)val;
		getprop_val(lo, node_off, "max_rate", 0, 0, &val);
		control.max_rate = (uint32_t)val;

		control.event = LINKMAN_EVENT_CONNECT;
		err = linkman_set_connection (
			linkman,			/* context */
			&control,			/* control information */
			&ep1,				/* endpoint 1 */
			&ep2);				/* endpoint 2 */
		if (err != 0){
			err = get_node_id(lo,node_off, &id);
			CHECK_COND_RETVAL(err = 0, err, "get_node_id() call failed\n");
			pr_err("Failed to set connection from DPL connection %d", id);
			return err;
		}
		/*! Generate linkup event */
		ep1.valid_fields = 0;
		ep2.valid_fields = 0;
		control.event = LINKMAN_EVENT_LINKUP;
		linkman_set_connection (
			linkman,			/* context */
			&control,			/* event */
			&ep1,				/* endpoint 1 */
			&ep2);				/* endpoint 2 */
		/*! No need to check an error */
#if 0
		subnode_off = fdt_next_subnode(lo, subnode_off);
	}
#endif
	return err;
}

static int linkman_remove_cb(void *lo, int node_off)
{
	int err = 0;
	int prop_off;
	char *prop;
	struct linkman_endpoint ep1, ep2;
	struct linkman *linkman;
	struct linkman_control 	control;

	memset(&ep1, 0x0, sizeof(struct linkman_endpoint));
	memset(&ep2, 0x0, sizeof(struct linkman_endpoint));
	memset(&control, 0x0, sizeof(struct linkman_control));

	/*! Obtain link manager */
	linkman = sys_get_unique_handle(FSL_MOD_LINKMAN);
	if (linkman == NULL) {
		pr_err ("Can't find linkman\n");
		return -ENODEV;
	}

	/*! Parse layout */
#if 0
	subnode_off = fdt_first_subnode(lo, node_off);
	while (subnode_off != -FDT_ERR_NOTFOUND)
	{
#endif
		/*! first endpoint */
		prop_off = fdt_first_property_offset(lo, node_off);
		prop = (char *)fdt_getprop_by_offset(lo, prop_off, NULL, NULL);
		if (prop == NULL) {
			pr_err("no device to unlink.\n");
			return -EINVAL;
		}

		/*! Get first endpoint configuration */
		err = get_dev_cfg(prop, NULL, &ep1);
		if (err != 0)
			return err;

		/* second endpoint */
		prop_off = fdt_next_property_offset(lo, node_off);
		prop = (char *)fdt_getprop_by_offset(lo, prop_off, NULL, NULL);
		if (prop == NULL) {
			pr_err("no device to unlink.\n");
			return -EINVAL;
		}
		err = get_dev_cfg(prop, NULL, &ep2);
		if (err != 0)
			return err;

		/*! Generate linkdown event */
		control.event = LINKMAN_EVENT_LINKDOWN;
		linkman_set_connection(
			linkman,			/* context */
			&control,			/* event */
			&ep1,				/* endpoint 1 */
			&ep2);				/* endpoint 2 */
		/*! No need to check an error */

		/*! Generate disconnect event */
		ep1.valid_fields = 0;
		ep2.valid_fields = 0;
		control.event = LINKMAN_EVENT_DISCONNECT;
		err = linkman_set_connection(
			linkman,			/* context */
			&control,			/* event */
			&ep1,				/* endpoint 1 */
			&ep2);				/* endpoint 2 */
		if (err != 0){
			pr_err("Failed to set disconnection from DPL\n");
			return err;
//		}
//		subnode_off = fdt_next_subnode(lo, subnode_off);
	}
	return err;
}

static char *linkman_match[] = { "fsl,linkman", "connection" };

int linkman_drv_init(void)
{
	struct linkman 	*linkman;

	pr_info("Executing linkman_drv_init...\n");

	/*! register to layout */
	t_sys_dtc_mod_params dtc_params;
	dtc_params.num_compats = ARRAY_SIZE(linkman_match);
	dtc_params.compatibles = linkman_match;
	dtc_params.f_prob_module = linkman_probe_cb;
	dtc_params.f_remove_module = linkman_remove_cb;
	sys_dtc_register_module(&dtc_params);

	/* linkman 2.0 */
	linkman = linkman_create(40);
	if (!linkman) {
		pr_err("No memory for linkman\n");
		return -EIO;
	}

	/*! Register linkman handler */
	sys_add_handle(linkman, FSL_MOD_LINKMAN, 1, 0);

	return 0;
}
