/*
 * Copyright 2013-2020 NXP
 */

/*
 * dbg.h
 *
 */

#ifndef DBG_H_
#define DBG_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#ifndef UNUSED
#define UNUSED(_x)	((void)(_x))
#endif

#ifndef KILOBYTE
#define KILOBYTE	1024UL
#define MEGABYTE	(KILOBYTE * KILOBYTE)
#define GIGABYTE	((KILOBYTE * MEGABYTE))
#endif

#if !(defined(ARRAY_SIZE))
#define ARRAY_SIZE(arr)		(sizeof(arr) / sizeof((arr)[0]))
#endif /* !defined(ARRAY_SIZE) */

#define STR(s) #s

#define DUMP_MAX_STR        64

#ifndef MIN
#define MIN(a,b)    ((a) < (b) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a,b)    ((a) > (b) ? (a) : (b))
#endif

static char	dump_idx_str[DUMP_MAX_STR] = "";
static char	dump_sub_str[DUMP_MAX_STR] = "";
static int	dump_arr_idx = 0, dump_arr_size = 0, dump_var_size = 0;
static char dump_buf[4 * KILOBYTE] = "";
static int 	dump_buf_idx = 0, dump_tmp_var = 0;

static char dump_indent[] = "\0                                       ";
static int dump_indent_pos = 0;

static int search_last_char(char* buf, int start, const char enemy) 
{
	if (!buf || (start <= 0)) 
		return -1;
	
	for (; start >= 0; start--) {
		if (buf[start] == enemy) 
			return start;
	}
	
	return -1;
}

#define DUMP_INTENT_DELTA 4

#define DUMP_INDENT_MORE \
	( dump_tmp_var = dump_indent_pos + DUMP_INTENT_DELTA, \
	  ( dump_tmp_var < sizeof(dump_indent) ? \
			(dump_indent[dump_indent_pos] = ' ', \
			dump_indent_pos = dump_tmp_var, \
			dump_indent[dump_indent_pos] = '\0') : \
			0 ) \
	)

#define DUMP_INDENT_LESS \
	( dump_indent_pos >= DUMP_INTENT_DELTA ? \
			(dump_indent[dump_indent_pos] = ' ', \
			dump_indent_pos -= DUMP_INTENT_DELTA, \
			dump_indent[dump_indent_pos] = '\0') : \
			0 )

#define dump_print(...) \
	dump_buf_idx += sprintf(&(dump_buf[dump_buf_idx]), __VA_ARGS__)

#define dump_format(dest, ...) \
	( sprintf(dest, __VA_ARGS__) )

#define dump_format_attr_only(dest, phrase) \
	(	dump_tmp_var = 1 + search_last_char(phrase, sizeof(phrase) - 1, '>'), \
		strcpy(dest, &phrase[dump_tmp_var]) \
	)

/**************************************************************************//**
 @Description   DUMP_TITLE
 	 	 	 	Prints a title for a subsequent dumped structure or data.

                The inputs for this macro are the format and arguments, similar to printf.
                When there are no arguments besides the format, a 0 must be used as the second argument.
*//***************************************************************************/
#define DUMP_TITLE(format, ...)           \
    dump_print("%s" format "\n", dump_indent, __VA_ARGS__);

/**************************************************************************//**
  @Description  DUMP_MEMORY
  	  	  	    Dumps a memory region in 4-bytes aligned format.

                The inputs for this macro are the base addresses and size
                (in bytes) of the memory region.
*//***************************************************************************/
#define DUMP_MEMORY(addr, size)  \
    mem_disp((uint8_t *)(addr), (int)(size))

#define DUMP_IDX dump_arr_idx
	
#define DUMP_TMP_STR dump_sub_str

#define DUMP_ALL INT_MAX

/**************************************************************************//**
 @Description   DUMP_SUBSTRUCT_ARRAY[_RAW]
 	 	 	 	Declares a dump loop, for dumping a structure field which is an array 
 	 	 	 	of complex types such as other structures.

                The inputs for this macro are:
                @param st - pointer to the structure
                @param phrase - the array field of the structure, which will be looped
                @param total - max number of times to loop. To loop the entire array, 
                	use DUMP_ALL macro.
				@param name - is a name to be displayed instead of the actual array field name.
					For DUMP_SUBSTRUCT_ARRAY_RAW this argument is missing because
					the actual field name is used automatically. 
				
				Note, that the body of the loop must be written inside brackets.
				Inside the body you may use DUMP_VAR or DUMP_PTR to actually 
				dump the fields for every member of the array.
				To access the loop index, use DUMP_IDX macro (which is global)

				Example:
				struct tc_config {
					uint32_t max_dist;
					uint8_t max_entries;
				};
				struct cfg {
					...
					struct tc_config tc_cfg[MAX_TCS];
					... 
				} cfg;
				
				DUMP_SUBSTRUCT_ARRAY(cfg, tc_cfg, DUMP_ALL, "configuration") {
					DUMP_VAR(cfg->tc_cfg[DUMP_IDX], max_dist, "max distance");
					DUMP_VAR(cfg->tc_cfg[DUMP_IDX], max_fs_entries, "max entries");
				}
				
				This will display:
				configuration[0]
        			max distance = 0x7
        			max entries = 0x0
    			configuration[1]
        			max dist = 0x0
        			max entries = 0x0
        		...
				
*//***************************************************************************/
#define DUMP_SUBSTRUCT_ARRAY(st, phrase, total, name) \
	dump_arr_size = MIN(total, ARRAY_SIZE((st)->phrase)); \
    for (DUMP_IDX=0, dump_idx_str[0] = '\0'; \
         (DUMP_IDX < dump_arr_size) && \
			(dump_print("%s%s[%d]\n", dump_indent, name, DUMP_IDX), DUMP_INDENT_MORE, 1); \
         DUMP_IDX++, dump_idx_str[0] = '\0', DUMP_INDENT_LESS)

#define DUMP_SUBSTRUCT_ARRAY_RAW(st, phrase, total) DUMP_SUBSTRUCT_ARRAY(st, phrase, total, #phrase)

#define DUMP_SUBSTRUCT_ARRAY_LOG(...) DUMP_SUBSTRUCT_ARRAY(__VA_ARGS__)
#define DUMP_SUBSTRUCT_ARRAY_NO_LOG(...)

#define DUMP_SUBSTRUCT_ARRAY_RAW_LOG(...) DUMP_SUBSTRUCT_ARRAY_RAW(__VA_ARGS__)
#define DUMP_SUBSTRUCT_ARRAY_RAW_NO_LOG(...)

/* EWL implementation of *printf functions does not handle %llx for 64 bit variables
 * so we need to split them in two 32 bit parts and display them separately.
 * TODO: investigate compiler optimizations, to see if the branches for the sizes that don't apply are removed from the elf.
 * 		If not, find ways to optimize this by hand (e.g. create separate macro clones to handle 64bit data
 * 		and implment custom static assert for compile time type checking)
 * 	Same for the other macros below handling 64 bit data.  
 */ 
#define _DUMP_VALUES(val) \
		if (dump_var_size < 8) \
		{ \
            dump_print("%s%s = 0x%x\n", \
            		dump_indent, DUMP_TMP_STR, (uint32_t)(val)); \
		} else { \
			dump_print("%s%s = 0x%x%08x\n", \
					dump_indent, DUMP_TMP_STR, (uint32_t)((uint64_t)val >> 32), (uint32_t)(val)); \
		}

/**************************************************************************//**
 @Description   DUMP_VAR[_RAW]
 	 	 	 	Dumps a structure's member variable.

                The inputs for this macro are:
                @param st - the structure
                @param phrase - the field of the structure
				@param name - is a name to be displayed instead of the actual field name.
					For DUMP_SUBSTRUCT_ARRAY_RAW this argument is missing because
					the field name is used automatically. 

				This macro will print st.phrase under the form ({} means value of):
				name = {st.phrase}
                If the member variable is part of a sub-structure hierarchy,
                the full hierarchy (including array indexing) must be specified.
                
                Examples:   DUMP_VAR(st, member, name) prints name = {st.member}
                            DUMP_VAR(p_Struct->sub, member, name) prints name = {p_Struct->sub.member}
                            DUMP_VAR(p_Struct->sub[i], member, name) prints name = {p_Struct->sub[i].member}
                            
                Note: the variant DUMP_PTR[_RAW] will treat st as pointer to structure and display st->phrase
                
*//***************************************************************************/
#define DUMP_VAR(st, phrase, name) \
    do { \
        dump_var_size = sizeof((st).phrase); \
        sprintf(DUMP_TMP_STR, "%s", name); \
        _DUMP_VALUES((st).phrase) \
    } while (0)

#define DUMP_VAR_LOG(...) DUMP_VAR(__VA_ARGS__)
#define DUMP_VAR_NO_LOG(...)

#define DUMP_PTR(st, phrase, name) \
    do { \
        dump_var_size = sizeof((st)->phrase); \
        sprintf(DUMP_TMP_STR, "%s", name); \
        _DUMP_VALUES((st)->phrase) \
    } while (0)

#define DUMP_VAR_RAW(st, phrase) DUMP_VAR(st, phrase, #phrase)

#define DUMP_VAR_RAW_LOG(...) DUMP_VAR_RAW(__VA_ARGS__)
#define DUMP_VAR_RAW_NO_LOG(...)

#define DUMP_PTR_RAW(st, phrase) DUMP_PTR(st, phrase, #phrase)

/**************************************************************************//**
 @Description   DUMP_ARRAY[_SEP][_NO_ST][_RAW]
 	 	 	 	Dumps a structure field which is an array of plain types. 
 	 	 	 	Normally, each item in the array is display on a separate line (except for *_SEP* variants)

                The inputs for this macro are:
                @param st - pointer to the structure. If *_NO_ST* variant is used, st is missing
                	and phrase is referring a variable or the full hierarchy of a sub-structure field. 
                @param phrase - the array field of the structure, which will be looped
                @param total - max number of times to loop. To loop the entire array, 
                	use DUMP_ALL macro.
				@param name - is a name to be displayed instead of the actual array field name.
					For if *_RAW variant is used, this argument is missing because
					the actual field name is used automatically.
				@param sep - separator. If the *_SEP* variant is used, all items of the array are displayed
					on the same line, separated by sep.

*//***************************************************************************/
#define DUMP_ARRAY(st, phrase, total, name) \
    do { \
        sprintf(DUMP_TMP_STR, "%s%s", dump_indent, name); \
        dump_arr_size = MIN(total, ARRAY_SIZE((st)->phrase)); \
        dump_var_size = sizeof((st)->phrase[0]); \
		for (DUMP_IDX=0; DUMP_IDX < dump_arr_size; DUMP_IDX++) { \
			if (dump_var_size < 8) { \
				dump_print("%s[%d] = 0x%x\n", \
						DUMP_TMP_STR, DUMP_IDX, (st)->phrase[DUMP_IDX]); \
			} else { \
				uint64_t dump_uin64_tmp = (st)->phrase[DUMP_IDX]; \
				dump_print("%s[%d] = 0x%x%08x\n", \
							DUMP_TMP_STR, DUMP_IDX, (uint32_t)(dump_uin64_tmp >> 32), (uint32_t)dump_uin64_tmp); \
			} \
		} \
    } while (0)

#define DUMP_ARRAY_RAW(st, phrase, total) \
		DUMP_ARRAY(st, phrase, total, #phrase)

#define DUMP_ARRAY_RAW_LOG(...) DUMP_ARRAY_RAW(__VA_ARGS__)
#define DUMP_ARRAY_RAW_NO_LOG(...)

#define _DUMP_ARRAY_SEP_GENERIC(phrase, total, name, sep) \
	dump_print("%s%s = ", dump_indent, name); \
	dump_arr_size = MIN(total, ARRAY_SIZE(phrase)); \
	dump_var_size = sizeof(phrase[0]); \
	for (DUMP_IDX=0; DUMP_IDX < dump_arr_size; DUMP_IDX++) { \
		if (dump_var_size < 8) { \
			dump_print("%s0x%x", \
					(DUMP_IDX ? sep : ""), \
					phrase[DUMP_IDX]); \
		} else { \
			uint64_t dump_uin64_tmp = phrase[DUMP_IDX]; \
			dump_print("%s0x%x%08x", \
					(DUMP_IDX ? sep : ""), \
					(uint32_t)(dump_uin64_tmp >> 32), (uint32_t)dump_uin64_tmp); \
		} \
	}

#define DUMP_ARRAY_SEP_NO_ST_STR(phrase, total, name, sep) \
    do { \
    	_DUMP_ARRAY_SEP_GENERIC(phrase, total, name, sep); \
		if (dump_var_size == 1) { \
			dump_print("\t(\"%s\")", (char*)phrase); \
		} \
        dump_print("\n"); \
    } while (0)

#define DUMP_ARRAY_SEP_NO_ST(phrase, total, name, sep) \
    do { \
    	_DUMP_ARRAY_SEP_GENERIC(phrase, total, name, sep); \
        dump_print("\n"); \
    } while (0)


#define DUMP_ARRAY_SEP(st, phrase, total, name, sep) \
		DUMP_ARRAY_SEP_NO_ST((st)->phrase, total, name, sep)

#define DUMP_ARRAY_SEP_STR(st, phrase, total, name, sep) \
		DUMP_ARRAY_SEP_NO_ST_STR((st)->phrase, total, name, sep)

#define DUMP_ARRAY_SEP_STR_LOG(...) DUMP_ARRAY_SEP_STR(__VA_ARGS__)
#define DUMP_ARRAY_SEP_STR_NO_LOG(...)

#define DUMP_ARRAY_SEP_LOG(...) DUMP_ARRAY_SEP(__VA_ARGS__)
#define DUMP_ARRAY_SEP_NO_LOG(...)

#define DUMP_ARRAY_SEP_RAW(st, phrase, total, sep) \
		dump_format_attr_only(DUMP_TMP_STR, #phrase); \
		DUMP_ARRAY_SEP_NO_ST((st)->phrase, total, DUMP_TMP_STR, sep);

#define DUMP_ARRAY_SEP_RAW_STR(st, phrase, total, sep) \
		dump_format_attr_only(DUMP_TMP_STR, #phrase); \
		DUMP_ARRAY_SEP_NO_ST_STR((st)->phrase, total, DUMP_TMP_STR, sep);

#define DUMP_ARRAY_SEP_RAW_LOG(...) DUMP_ARRAY_SEP_RAW(__VA_ARGS__)
#define DUMP_ARRAY_SEP_RAW_NO_LOG(...)

#define DUMP_ARRAY_SEP_RAW_STR_LOG(...) DUMP_ARRAY_SEP_RAW(__VA_ARGS__)
#define DUMP_ARRAY_SEP_RAW_STR_NO_LOG(...)

#define DUMP_ARRAY_SEP_NO_ST_RAW(phrase, total, sep) \
		DUMP_ARRAY_SEP_NO_ST(phrase, total, #phrase, sep)

#define DUMP_ARRAY_SEP_NO_ST_RAW_STR(phrase, total, sep) \
		DUMP_ARRAY_SEP_NO_ST_STR(phrase, total, #phrase, sep)

/**************************************************************************//**
 @Description   DUMP_VARIABLE[_RAW]
 	 	 	 	DUMP_POINTER[_RAW]
 	 	 	 	Dumps a complex structure, by calling the function dump_{type}(var), where type is a struct type.
 	 	 	 	This function should expect a pointer to {type}.

                The inputs for this macro are:
                @param type - the structure type (without keyword 'struct').
                @param var - the name of the struct instance.
                	DUMP_VARIABLE* will dump &var (address of var), while 
                	DUMP_POINTER will dump var (which must be a pointer by itself).
				@param name - is a name to be displayed instead of the actual struct instance name.
					For if *_RAW variant is used, this argument is missing because
					the actual instance name is used automatically.

*//***************************************************************************/
#define DUMP_VARIABLE_RAW(type, var) \
	DUMP_TITLE(STR(var), 0); \
	DUMP_INDENT_MORE; \
	dump_ ## type ## ( ## &(var) ## ); \
	DUMP_INDENT_LESS;

#define DUMP_POINTER_RAW(type, var) \
	DUMP_TITLE(STR(var), 0); \
	DUMP_INDENT_MORE; \
	dump_ ## type ## ( ## var ## ); \
	DUMP_INDENT_LESS;

#define DUMP_VARIABLE(type, var, name) \
	DUMP_TITLE(name, 0); \
	DUMP_INDENT_MORE; \
	dump_ ## type ## ( ## &(var) ## ); \
	DUMP_INDENT_LESS;

#define DUMP_POINTER(type, var, name) \
	DUMP_TITLE(name, 0); \
	DUMP_INDENT_MORE; \
	dump_ ## type ## ( ## var ## ); \
	DUMP_INDENT_LESS;

#define DUMP_TO_LOG(obj_id) \
	do { \
		obj_debug(obj_id, dump_buf); \
		dump_buf[0] = '\0'; \
		dump_buf_idx = 0; \
	} while (0)

#endif /* DBG_H_ */
