/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          log.c

 @Description   library implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "log.h"
#include "fsl_console.h"

/*******************************************************************
 	 	 	 	 	 Global Variables
 *******************************************************************/
struct log_db log_db = { 0 };	/* Singleton */

enum log_level log_levels[LOG_MODULES_AMOUNT] =
{
	[LOG_MOD_DEFAULT]	= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPNI]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPIO]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPBP]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPSW]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPRC]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPCON]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPDMUX]	= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPLAG]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPMAC]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPMNG]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPCI]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPSECI]	= LOG_LEVEL_GLOBAL,
	[LOG_MOD_RESMAN]	= LOG_LEVEL_GLOBAL,
	[LOG_MOD_LINKMAN]	= LOG_LEVEL_GLOBAL,
	[LOG_MOD_CTLU]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPAIOP]	= LOG_LEVEL_GLOBAL,
	[LOG_MOD_EIOP]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_CMDIF]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_QBMAN]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPDMAI]	= LOG_LEVEL_GLOBAL,
	[LOG_MOD_EDMA]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_PLATFORM]	= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DCE]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPMCP]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPDCEI]	= LOG_LEVEL_GLOBAL,
	[LOG_MOD_QDMA]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPDBG]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPRTC]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_CAAM]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_SERDES]	= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DUART]		= LOG_LEVEL_GLOBAL,
	[LOG_MOD_DPSPARSER]	= LOG_LEVEL_GLOBAL
};

char log_module_names[LOG_MODULES_AMOUNT][10] =
{
		[LOG_MOD_DEFAULT] 	= "DEFAULT",
		[LOG_MOD_DPNI]		= "DPNI",
		[LOG_MOD_DPIO]		= "DPIO",
		[LOG_MOD_DPBP]		= "DPBP",
		[LOG_MOD_DPSW]		= "DPSW",
		[LOG_MOD_DPRC]		= "DPRC",
		[LOG_MOD_DPCON]		= "DPCON",
		[LOG_MOD_DPDMUX]	= "DPDMUX",
		[LOG_MOD_DPLAG]		= "DPLAG",
		[LOG_MOD_DPMAC]		= "DPMAC",
		[LOG_MOD_DPMNG]		= "DPMNG",
		[LOG_MOD_DPCI]		= "DPCI",
		[LOG_MOD_DPSECI]	= "DPSECI",
		[LOG_MOD_RESMAN]	= "RESMAN",
		[LOG_MOD_LINKMAN]	= "LINKMAN",
		[LOG_MOD_CTLU]		= "CTLU",
		[LOG_MOD_DPAIOP]	= "DPAIOP",
		[LOG_MOD_EIOP]		= "EIOP",
		[LOG_MOD_CMDIF]		= "CMDIF",
		[LOG_MOD_QBMAN]		= "QBMAN",
		[LOG_MOD_DPDMAI]	= "DPDMAI",
		[LOG_MOD_EDMA]		= "EDMA",
		[LOG_MOD_PLATFORM]	= "PLATFORM",
		[LOG_MOD_DCE]		= "DCE",
		[LOG_MOD_DPMCP]		= "DPMCP",
		[LOG_MOD_DPDCEI]	= "DPDCEI",
		[LOG_MOD_QDMA]		= "QDMA",
		[LOG_MOD_DPDBG]		= "DPDBG",
		[LOG_MOD_DPRTC]		= "DPRTC",
		[LOG_MOD_CAAM]		= "CAAM",
		[LOG_MOD_SERDES]	= "SERDES",
		[LOG_MOD_DUART]		= "DUART",
		[LOG_MOD_DPSPARSER]	= "DPSPARSER"
};

enum log_level log_global_level;

#define LOG_MAX_NUM_OBJ_PER_MODULE			100

struct obj_level_node {
	int id;
	enum log_level level;
};

struct object_log_array {
	uint32_t count;
	struct obj_level_node obj_levels[LOG_MAX_NUM_OBJ_PER_MODULE];
};

struct cached_obj_pos {
	enum log_module module;
	int id;
	int pos;
};

struct cached_obj_pos cache = {LOG_MOD_DEFAULT, NO_ID, -EINVAL};

struct object_log_array log_levels_per_object[LOG_MODULES_AMOUNT] =
{
	[LOG_MOD_DEFAULT] = {0},
	[LOG_MOD_DPNI]	= {0},
	[LOG_MOD_DPIO]	= {0},
	[LOG_MOD_DPBP]	= {0},
	[LOG_MOD_DPSW]	= {0},
	[LOG_MOD_DPRC]	= {0},
	[LOG_MOD_DPCON]	= {0},
	[LOG_MOD_DPDMUX]= {0},
	[LOG_MOD_DPLAG]	= {0},
	[LOG_MOD_DPMAC]	= {0},
	[LOG_MOD_DPMNG]	= {0},
	[LOG_MOD_DPCI]	= {0},
	[LOG_MOD_DPSECI]= {0},
	[LOG_MOD_RESMAN]= {0},
	[LOG_MOD_LINKMAN]= {0},
	[LOG_MOD_CTLU]	= {0},
	[LOG_MOD_DPAIOP] = {0},
	[LOG_MOD_EIOP]	= {0},
	[LOG_MOD_CMDIF]	= {0},
	[LOG_MOD_QBMAN]	= {0},
	[LOG_MOD_DPDMAI]= {0},
	[LOG_MOD_EDMA]= {0},
	[LOG_MOD_PLATFORM]= {0},
	[LOG_MOD_DCE]= {0},
	[LOG_MOD_DPMCP]= {0},
	[LOG_MOD_DPDCEI]= {0},
	[LOG_MOD_QDMA]= {0},
	[LOG_MOD_DPDBG]= {0}
};

/*******************************************************************
 	 	 	 	 	 Static Functions
 *******************************************************************/
static void log_string_to_ddr(enum log_buf_type	buf_type,
			    char* str,
			    uint32_t data_len);

/**
 * Return the position of the object settings in the corresponding object_log_array
 * for the module and object id, or negative value if not found.
 */
static int find_position_in_object_log_array(enum log_module module, int id)
{
	/* validate args */
	if ((module <= LOG_MOD_DEFAULT) || (module >= NUM_LOG_MODULE_TYPE)) {
	   return -EINVAL;
	}
	
	//Check cached
	if (module == cache.module && id == cache.id) {
		return cache.pos;
	}
	
	struct object_log_array* object_array = &log_levels_per_object[module];
	if (!object_array->count) {
		return -EAGAIN;
	} else {
		struct obj_level_node* log_levels = object_array->obj_levels;
		
		/* binary search in the array */
		uint32_t first, last, middle;
		 
		first = 0;
		last = object_array->count - 1;
		middle = (first + last) / 2;
		
		while (first <= last) {
			if (log_levels[middle].id < id)
				first = middle + 1;
			else if (log_levels[middle].id == id) {
				return (int)middle;
			} else
				last = middle - 1;

			middle = (first + last) / 2;
		}
		
		/* first > last -> not found.
		 * Return the position where it should have been if found and cache it */
		cache.module = module;
		cache.id = id;
		cache.pos = (int)first;
		
		return (int)first;
	}
}

static int num_cores()
{
	struct mc_desc mc_desc;
	int err;

	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, 0);
	ASSERT_COND(!err);
	return mc_desc.num_cores;
}

static uint32_t get_free_space(enum log_buf_type buf_type)
{
	return (uint32_t)(log_db.ext_buf_info[buf_type].start_addr +
			  log_db.ext_buf_info[buf_type].buf_size -
			  log_db.ext_buf_info[buf_type].current_addr);
}

static void prepare_log_header(void)
{
	uint8_t magic_word[4] = { (uint8_t)'M', (uint8_t)'C', (uint8_t)LOG_VERSION_MAJOR, (uint8_t)LOG_VERSION_MINOR };
	
	log_db.header = (struct log_header *)LOG_DDR_ADDR;
	memset(log_db.header, 0, sizeof(struct log_header));

	/* offset 0x00 holds 32-bit little-endian magic word 'MC<log-version>'*/
	log_db.header->magic_word = CPU_TO_LE32(*(uint32_t *)magic_word);
	/* offset 0x08 holds the 32-bit little-endian offset of the start of the buffer */
	/* TODO: buf_start is temporary initialized to core0 log section - need to be moved to user log section in the future */
	log_db.header->buf_start = CPU_TO_LE32(LOG_CORE_BUF_START);
	/* offset 0x0c holds the 32-bit little-endian length of the buffer - not including these initial words*/
	/* TODO buf_length is temporary set so core_buf_length - should be replaced by user_buf_length in the future*/
	log_db.header->buf_length = CPU_TO_LE32(LOG_CORE_BUF_SIZE);
	/* offset 0x10 holds the 31-bit little-endian offset of the byte after the last byte that was written */
	/* MSB of last_byte represents buffer wraparound */
	log_db.header->last_byte = CPU_TO_LE32(0);		
}

static void log_create_ext_buffer(void)
{
	enum log_buf_type buf_idx;
	uint8_t *addr;
	
	/* Prepare log header initial values */
	prepare_log_header();
	
	/* zero buffer */
//	memset(PTR_MOVE((int*)log_db.header, sizeof(struct log_header)), 0, mem_size);
	
	/* user log info initialization */
	log_db.ext_buf_info[LOG_BUF_TYPE_USER].start_addr =
		log_db.ext_buf_info[LOG_BUF_TYPE_USER].current_addr =
			(uint8_t *)(LOG_DDR_ADDR + sizeof(struct log_header));
	log_db.ext_buf_info[LOG_BUF_TYPE_USER].buf_size = (uint32_t)LOG_USER_BUF_SIZE - sizeof(struct log_header);
	
	/* MC log core buffers info initialization*/
	addr = (uint8_t *)LOG_CORE_BUF_START;
	for (buf_idx = LOG_BUF_TYPE_CORE0; buf_idx < LOG_BUF_TYPE_DUMMY; buf_idx++) {
		log_db.ext_buf_info[buf_idx].start_addr = addr;
		log_db.ext_buf_info[buf_idx].current_addr = addr;
		log_db.ext_buf_info[buf_idx].buf_size = LOG_CORE_BUF_SIZE;
		addr += LOG_CORE_BUF_SIZE;
	}
}

static void log_event_to_str(enum log_level level, char* module_str, struct log_event *event)
{
	char ts_buf[MODULE_STR];
	static const char level_to_string[] = {' ', 'D', 'I', 'W', 'E', 'C', 'A'};
	
	/* timestamp */
	ts_buf[0] = 0;
	if (log_db.ts_mode == LOG_TIMESTAMP_ON) {
		snprintf(ts_buf, MODULE_STR, LOG_PRINT_FORMAT_TIMSTAMP, UINT32_HI(event->timestamp), UINT32_LO(event->timestamp));
	}
		
	if (level <= LOG_LEVEL_WARNING) {
		snprintf(event->event_to_str, EVENT_TO_STR,
				LOG_PRINT_FORMAT_SHORT,
				level_to_string[level],
				module_str
				);	
	} else {
		snprintf(event->event_to_str, EVENT_TO_STR,
				LOG_PRINT_FORMAT_SIMPLE,
				level_to_string[level],
				ts_buf,
				event->function_name,
				event->line_number,
				module_str
				);	
	}
}

static void console_print(char *format, ...)
{
    va_list args;
    char tmp_buf[STR_BUF];

    memset(&args, 0, sizeof(args));
    va_start(args, format);

    vsnprintf (tmp_buf, STR_BUF, format, args);
    va_end(args);

    sys_print(tmp_buf, SYS_PRINT_TO_CONSOLE_DEVICE);
}

static void log_push_to_ddr(enum log_buf_type	buf_type,
			    char 		*str,
			    char 		*function_name,
			    int 		line,
			    enum log_level 	level,
			    char* 		module_str,
			    uint64_t 	ts)
{
	struct log_event event = { 0 };

	event.function_name = function_name;
	event.line_number = (uint16_t)line;
	event.timestamp = ts;

	/* create a string represents an event inside mc buffer */
	log_event_to_str(level, module_str, &event);

	log_string_to_ddr(buf_type, event.event_to_str, strlen(event.event_to_str));
	log_string_to_ddr(buf_type, str, strlen(str));
}

static void log_string_to_ddr(enum log_buf_type	buf_type,
			    char* str,
			    uint32_t data_len)
{
	int wraparound = 0;
	uint32_t tmp, free_space, last_byte;

	free_space = get_free_space(buf_type);

	if(data_len > log_db.ext_buf_info[buf_type].buf_size) { /*in case the length is too big */
		return;
	}

	/* Update the header */
	last_byte = (uint32_t)(log_db.ext_buf_info[buf_type].current_addr +
				data_len -
				log_db.ext_buf_info[buf_type].start_addr);
	if (free_space < data_len) {
		last_byte -= log_db.ext_buf_info[buf_type].buf_size;
		wraparound = 1;
	}

	tmp = LE32_TO_CPU(log_db.header->last_byte) & LOG_LAST_BYTE_WRAPAROUND;
	tmp |= last_byte;
	if (wraparound)
		tmp |= LOG_LAST_BYTE_WRAPAROUND;
	log_db.header->last_byte = CPU_TO_LE32(tmp);

	/* copy event string, as much as possible, at current buffer pointer */
	strncpy((char *)log_db.ext_buf_info[buf_type].current_addr,
	        str,
	        MIN(free_space, data_len));
	log_db.ext_buf_info[buf_type].current_addr += MIN(free_space, data_len);

	if (free_space < data_len) {
		strncpy((char *)log_db.ext_buf_info[buf_type].start_addr,
		        (char *)PTR_MOVE(str, free_space),
		        data_len - free_space);
		log_db.ext_buf_info[buf_type].current_addr =
			log_db.ext_buf_info[buf_type].start_addr +
			(data_len - free_space);
	}

#ifdef EMULATOR
	// write the variable "curr" to scratch_pad_2 (offset 0x21019008) so the emulator testbench
	// knows the total length of the logbuf.
	iowrite32((unsigned long) log_db.ext_buf_info[buf_type].current_addr, (uint32_t *)0x21019008);
#endif
}

/*******************************************************************
 	 	 	 	 	 Non Static Functions
 *******************************************************************/

int log_set_level_per_object(enum log_module module, int id, enum log_level level)
{
	/* validate args */
	if ((module <= LOG_MOD_DEFAULT) || (module >= NUM_LOG_MODULE_TYPE)) {
	   return -EINVAL;
	}
	
	if ((level >= LOG_LEVEL_GLOBAL) && (level < NUM_LOG_LEVEL_TYPE)) {
		/* find the object in the map */
		int pos = find_position_in_object_log_array(module, id);

		if (pos >= 0) {
			if (log_levels_per_object[module].obj_levels[pos].id == id) {
				/* it exists at pos; update it */

				if (level == LOG_LEVEL_GLOBAL) {
					uint32_t i;
					
					/* remove from map */
					/* shift all items from pos + 1 to the left */
					for (i = (uint32_t)pos + 1; i < log_levels_per_object[module].count; i++) {
						log_levels_per_object[module].obj_levels[i - 1] = log_levels_per_object[module].obj_levels[i];
					}
					log_levels_per_object[module].count--;
					log_levels_per_object[module].obj_levels[i - 1].id = 0;
					log_levels_per_object[module].obj_levels[i - 1].level = LOG_LEVEL_GLOBAL;
				} else {
					/* update existing level for the object */
					log_levels_per_object[module].obj_levels[pos].level = level;
					return 0;
				}
			} else {
				/* does not exist */
				uint32_t i;
				
				if (log_levels_per_object[module].count == LOG_MAX_NUM_OBJ_PER_MODULE) {
					/* no room left */
					return -ENOMEM;
				}
				
				/* shift all items from pos to the right and insert it in the map */
				for (i = log_levels_per_object[module].count; i > (uint32_t)pos; i--) {
					log_levels_per_object[module].obj_levels[i] = log_levels_per_object[module].obj_levels[i - 1];
				}
				
				/* insert value at position */
				log_levels_per_object[module].obj_levels[pos].id = id;
				log_levels_per_object[module].obj_levels[pos].level = level;
				log_levels_per_object[module].count++;
			}
		}
	} else {
	   return -EINVAL;
	}

	return 0;
}

enum log_level log_get_level_per_object(enum log_module module, int id)
{
	/* validate args */
	if (id == NO_ID) {
		return LOG_LEVEL_GLOBAL;
	}
	if ((module <= LOG_MOD_DEFAULT) || (module >= NUM_LOG_MODULE_TYPE)) {
	   return LOG_LEVEL_GLOBAL;
	}
	
	int pos = find_position_in_object_log_array(module, id);

	if (pos >= 0) {
		if (log_levels_per_object[module].obj_levels[pos].id == id) {
			/* it exists at pos */
			return log_levels_per_object[module].obj_levels[pos].level;
		}
	}

	return LOG_LEVEL_GLOBAL;
}

int log_record(enum log_level level, int user_log, enum log_module module, int obj_id, char *function_name, int line, va_list va)
{
	char str_buf[STR_BUF];
	char ts_buf[MODULE_STR];
	char module_buf[MODULE_STR];
	uint32_t core_id = core_get_id();
	uint32_t int_flags;
	uint64_t timestamp = 0;
	enum log_buf_type buf_type;
	
	static const char level_to_string[] = {' ', 'D', 'I', 'W', 'E', 'C', 'A'};

	/* LOG OFF */
	if (log_db.console_mode == CONSOLE_MODE_OFF &&
		log_db.mode == LOG_MODE_OFF)
			return 0;

	/* LOG ON */
	str_buf[0] = 0;
	
	/* timestamp */
	ts_buf[0] = 0;
	/* module:object info */
	module_buf[0] = 0;

	vsnprintf(str_buf, STR_BUF, va_arg(va, char*)/* string format */, va/* arguments for string */);
	
	/* TODO: ensure str_buf ends with '\n' */
	
	if (log_db.eiop_rtc != NULL) {
		eiop_rtc_get_current_timestamp(log_db.eiop_rtc, &timestamp);
		if (log_db.ts_mode == LOG_TIMESTAMP_ON) {
			snprintf(ts_buf, MODULE_STR, LOG_PRINT_FORMAT_TIMSTAMP, UINT32_HI(timestamp), UINT32_LO(timestamp));
		}
	} else {
		if (sys.console) /* temp, sys_get_handle crashed otherwise */
			log_db.eiop_rtc = sys_get_handle(FSL_MOD_EIOP_RTC, 1, 0);
		/* skip the timestamp in this case, for code efficiency */
	}
	
	if (module > LOG_MOD_DEFAULT) {
		if (obj_id == NO_ID) {
			snprintf(module_buf, MODULE_STR, LOG_PRINT_MODULE, log_module_names[module]);
		} else {
			snprintf(module_buf, MODULE_STR, LOG_PRINT_MODULE_OBJ, log_module_names[module], obj_id);
		}
	}
	
	/* console output */
	if (log_db.console_mode == CONSOLE_MODE_ON) {
		/* colored prints */
		if (level <= LOG_LEVEL_WARNING) {
			console_print(	LOG_PRINT_FORMAT_GREY_SIMPLE,
							level_to_string[level],
							module_buf,
							(char*)str_buf);
		} else {
			console_print(
							LOG_PRINT_FORMAT_RED,
							level_to_string[level],
							ts_buf,
							function_name,
							line,
							module_buf,
							(char*)str_buf);
		}
		
	}

	/* log to memory */
	if (log_db.mode == LOG_MODE_ON) {
		int_flags = core_local_irq_save(); /* disable interrupts */

		if (user_log)
			buf_type = LOG_BUF_TYPE_USER;
		else 
			buf_type = (enum log_buf_type)(LOG_BUF_TYPE_CORE0 + core_id);
		
		log_push_to_ddr(buf_type, str_buf, function_name, line, level, module_buf, timestamp);

		core_local_irq_restore(int_flags); /* enable interrupts */
	}

	return 0;
}

int log_print(char *str, uint32_t count)
{
	/* log to memory */
	if (log_db.mode == LOG_MODE_ON) {
		uint32_t core_id = core_get_id();
		uint32_t int_flags;
		enum log_buf_type buf_type;

		int_flags = core_local_irq_save(); /* disable interrupts */

		buf_type = (enum log_buf_type)(LOG_BUF_TYPE_CORE0 + core_id);

		log_string_to_ddr(buf_type, str, count);

		core_local_irq_restore(int_flags); /* enable interrupts */
	}

	return 0;
}

static int dpc_log(enum log_mode *mode,
				   enum log_level *level,
				   enum console_mode *console_mode, 
				   enum log_timestamp_mode *ts_mode)
{
	*mode = (dpc.log.dpc_mask & DPC_LOG_MASK_MODE) ?
		dpc.log.mode : LOG_MODE_ON;
	*level = (dpc.log.dpc_mask & DPC_LOG_MASK_LEVEL) ? dpc.log.level :
			LOG_LEVEL_INFO;
	*console_mode = (dpc.console.dpc_mask & DPC_CONSOLE_MASK_MODE) ?
			dpc.console.mode : CONSOLE_MODE_OFF;
	*ts_mode = (dpc.log.dpc_mask & DPC_LOG_MASK_TIMESTAMP) ?
				dpc.log.ts_mode : LOG_TIMESTAMP_OFF;
	
	if (dpc.log.dpc_mask & DPC_LOG_MASK_MODULE_LEVELS) {
		int i;
		for (i = LOG_MOD_DEFAULT + 1; i < LOG_MODULES_AMOUNT; i++) {
			if (dpc.log.module_levels[i] != LOG_LEVEL_GLOBAL) {
				log_levels[i] = dpc.log.module_levels[i];
			}
		}
	}

	return 0;
}

int log_init()
{
	enum log_mode mode;
	enum log_level level;
	enum console_mode console_mode;
	enum log_timestamp_mode ts_mode;
	int err;

	/* Reading DPC initialization file */
	err = dpc_log(&mode, &level, &console_mode, &ts_mode);
	if (err)
		return err;

	/* Working mode */
	log_db.mode = mode;
	log_db.ts_mode = ts_mode;

	log_db.console_mode = console_mode;
	log_global_level = level;

	/* create external buffer */
	log_create_ext_buffer();

	if (incorrect_log_level)
		pr_warn("DPC log level set to incorrect value. "
				"LOG_LEVEL_INFO chosen as default value\n");
	return 0;
}

void log_set_mode(enum log_mode mode)
{
	log_db.mode = mode;
}

enum log_mode log_get_mode()
{
	return log_db.mode;
}

void log_set_timestamp_mode(enum log_timestamp_mode ts_mode)
{
	log_db.ts_mode = ts_mode;
}

enum log_timestamp_mode log_get_timestamp_mode()
{
	return log_db.ts_mode;
}

int log_set_module_level(enum log_module module, enum log_level level)
{
	if ((module < 0) || (module >= LOG_MODULES_AMOUNT)) {
		return -EINVAL;
	}
	
	log_levels[module] = level;
	return 0;
}

int log_get_module_level(enum log_module module, enum log_level *level)
{
	if ((module < 0) || (module >= LOG_MODULES_AMOUNT) || !level) {
		return -EINVAL;
	}
	
	*level = log_levels[module];
	return 0;
}

void log_set_global_level(enum log_level level)
{
	log_global_level = level;
}

enum log_level log_get_global_level()
{
	return log_global_level;
}
