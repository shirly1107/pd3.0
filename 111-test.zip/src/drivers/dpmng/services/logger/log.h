/*
 * Copyright 2017, 2019 NXP
 */

/******************************************************************************
 @File          log.h

 @Description   LOG internal structures and definitions.
 *//***************************************************************************/

#ifndef __LOG_H
#define __LOG_H

#include "common/fsl_string.h"	/* for memset function */
#include "common/fsl_stdarg.h"	/* for variadic functions */
#include "fsl_eiop_rtc.h"		/* for eiop_rtc_get_current_timestamp() */
#include "fsl_sys.h"
#include "fsl_core.h" 	/* for core_get_id(void), core_local_irq_save(), core_local_irq_restore(uint32_t flags) */
#include "fsl_dpmng_mc.h"	/* for mc_get_version(struct mc_version *user_struct) */
#include "drivers/fsl_mc.h"	/* for struct mc_desc mc_desc */
#include "fsl_platform.h"	/* for sys_get_desc() */
#include "stdio.h"
#include "math.h"
#include "fsl_system.h"
#include "fsl_log.h"
#include "dpc.h"

#define LOG_VERSION_MAJOR		1
#define LOG_VERSION_MINOR		0

#define LOG_LAST_BYTE_MASK		0x7fffffff
#define LOG_LAST_BYTE_WRAPAROUND 0x1 << 31

#define LOG_MAX_CORE_NUMBER		8
#define LOG_MC_CORE_SIZE		4*KILOBYTE
#define LOG_CB_CORE_SIZE		4*KILOBYTE

#define MEM_PARTITION_ID_CB		MEM_PART_DMEM
#define STR_BUF				1024
#define EVENT_TO_STR			100
#define MODULE_STR			30

#define LOG_USER_BUF_SIZE		1*MEGABYTE
#define LOG_USER_RESERVED_SIZE		1*MEGABYTE /* Reserved 1MB */
#define LOG_GLOBAL_MC_DATA_SIZE		2*MEGABYTE /* Unused for now */

#define	LOG_CORE_BUF_START \
	(LOG_DDR_ADDR + LOG_USER_BUF_SIZE + LOG_USER_RESERVED_SIZE + \
	 LOG_GLOBAL_MC_DATA_SIZE)

#define	LOG_CORE_BUF_SIZE		3*MEGABYTE

extern struct log_db log_db;

/* All the information event contains */
struct log_event {
	uint64_t timestamp;
	char *function_name;
	uint16_t line_number;
	uint16_t request_id;	/* GPP request */
	uint16_t str_len;	/* length of string that follows event */
	char event_to_str[EVENT_TO_STR];
};

#define LOG_NUM_OF_BUFFERS 4

enum log_buf_type {
	LOG_BUF_TYPE_USER = 0,
	LOG_BUF_TYPE_GLOBAL,
	LOG_BUF_TYPE_CORE0,
	LOG_BUF_TYPE_CORE1,
	LOG_BUF_TYPE_DUMMY
};

/* Addresses for each buffer and size of every buffer */
struct buf_data {
	uint8_t *start_addr;
	uint8_t *current_addr;
	uint32_t buf_size;
};

#define LOG_HEADER_FLAG_BUFFER_WRAPAROUND 0x00000001

struct log_header {
	uint32_t magic_word;
	char reserved1[4];
	uint32_t buf_start;
	uint32_t buf_length;
	uint32_t last_byte;
	char reserved2[44];
};

struct log_db {
	struct log_header *header;
	struct buf_data ext_buf_info[LOG_NUM_OF_BUFFERS];
	enum log_mode mode; /* '0'=OFF, '1'=ON */
	enum console_mode console_mode; /* '0'=ON, '1'=OFF */
	enum log_timestamp_mode ts_mode; /* '1'=ON, '0'=OFF */
	struct eiop_rtc *eiop_rtc;
};

extern int incorrect_log_level;

#endif /* __LOG_H */
