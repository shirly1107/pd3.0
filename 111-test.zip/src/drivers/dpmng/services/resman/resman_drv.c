/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//*
 @File          dprc_drv.c

 @Description   driver implementation

 more_detailed_description

 @Cautions      None.
 *//***************************************************************************/

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_cmdif.h"
#include "kernel/layout.h"
#include "fsl_soc.h"
#include "fsl_sys.h"

#include "fsl_resman.h"
#include "fsl_soc.h"
#include "drivers/fsl_mc.h"
#include "fsl_platform.h"
#include "resman.h"

int resman_drv_init(void);

int resman_drv_init(void)
{
	struct resman *resman;
	struct resman_res_req req;
	int err, mcp_cnt = 0;
	struct mc_portal_desc mcp_desc;

	pr_info("Executing resman_drv_init...\n");

	/* get number of IFP's to create a resman pool */
	memset(&mcp_desc, 0, sizeof(mcp_desc));
	while (sys_get_desc(SOC_MODULE_MC_PORTAL, SOC_DB_NO_MATCH_FIELDS,
				&mcp_desc, &mcp_cnt) == 0) ;

	resman = resman_init();
	if (!resman)
		return -ENODEV;
	sys_add_handle(resman, FSL_MOD_RESMAN, 1, 0);

	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 1;
	req.num = (uint32_t)mcp_cnt - 1;
	strcpy(req.type, "mcp");
	req.options |= DPRC_RES_REQ_OPT_EXPLICIT;

	if ((err = resman_create_res_pool(resman, &req)) != 0) {
		pr_err("Cannot create mcp pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpni", 0, 64)) != 0) {
		pr_err("Cannot create dpni pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpio", 0, MAX_NUM_OF_DPIOS)) != 0) {
		pr_err("Cannot create dpio pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpbp", 0, 64)) != 0) {
		pr_err("Cannot create dpbp pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpsw", 0, 16)) != 0) {
		pr_err("Cannot create dpsw pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpmac", 1, 18)) != 0) {
		pr_err("Cannot create dpmac pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpci", 0, 256)) != 0) {
		pr_err("Cannot create dpci pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpcon", 0, 256)) != 0) {
		pr_err("Cannot create dpcon pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpseci", 0, 100)) != 0) {
		pr_err("Cannot create dpseci pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpdmux", 0, 16)) != 0) {
		pr_err("Cannot create dpdmux pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpaiop", 0, 16)) != 0) {
		pr_err("Cannot create dpaiop pool\n");
		return err;
	}

	if ((err = resman_create_obj_pool(resman, "dpmcp", 0, 256)) != 0) {
		pr_err("Cannot create dpmcp pool\n");
		return err;
	}

	if ((err = resman_create_obj_pool(resman, "dpdmai", 0, 256)) != 0) {
		pr_err("Cannot create dpdmai pool\n");
		return err;
	}

	if ((err = resman_create_obj_pool(resman, "dpdcei", 0, 256)) != 0) {
		pr_err("Cannot create dpdcei pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dpdbg", 0, 1)) != 0) {
		pr_err("Cannot create dpdbg pool\n");
		return err;
	}
	if ((err = resman_create_obj_pool(resman, "dprtc", 0, 16)) != 0) {
		pr_err("Cannot create dprtc pool\n");
		return err;
	}
	err = resman_create_obj_pool(resman, "dpsparser", 0, 1);
	if (err) {
		pr_err("Cannot create dpsparser pool\n");
		return err;
	}

	return 0;
}
