/*
 * Copyright 2013-2020 NXP
 */

#ifndef _RESMAN_H
#define _RESMAN_H

#include "common/fsl_string.h"
#include "fsl_event_pipe.h"
#include "fsl_resman.h"
#include "device.h"
#include "fsl_slab.h"
#include "fsl_core_booke_regs.h"
#include "fsl_soc.h"
#include "fsl_spinlock.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_RESMAN

#define INVALID_DEVICE_ID                        ~(0)
#define INVALID_OWNER_ID                         ~(0)

#define ADD_ALLOCATED_RES                                        1
#define SUBTRACT_ALLOCATED_RES                    0

#define DPRC_IRQ_INDEX                            0
#define MAX_NUM_OF_CONTAINERS                     256
#define MAX_NUM_OF_OPEN_HANDLES 		  		  1024
#define MAX_NUM_OF_RESOURCE_TYPES                 35
#define MAX_NUM_OF_DEVICES                 	      512
#define MAX_NUM_OF_RESOURCES                 	  3840
#define MAX_NUM_OF_DPIOS                          65

/* Fixed Container IDs */
#define GLOBAL_CONTAINER_ID                       0
#define ROOT_CONTAINER_ID                         1
#define UNASSINGED_PORTAL_CONTAINER_ID     	 -2
/* The highest ICID supported by HW is 0xFFFF */
#define MAX_ICID    0xFFFF

#define DP_DEV_MAX_OWNERS                         32

#define HASH_SIZE                                 24

#define DPRC_REGION_COUNT 1
#define DPRC_IRQ_COUNT 1

#define DPRC_NO_PORTAL_ID			(int)(~(0))

#define RESMAN_INIT_DONE 			0x00000001
#define HAS_ICID_0				0x00000002

#define DPRC_STACK_PROCESS_CHILD		0x00000001
#define DPRC_STACK_PROCESS_SIBLING		0x00000002
#define MAX_NUM_OF_CONTAINERS_IN_STACK		64

#define OWNER_ID(device)	(((int)(device)) & DP_DEV_OWNERS_MASK)
#define GET_DEVICE(device)			((struct resman_device *)((int)(device) & ~DP_DEV_OWNERS_MASK))
#define GET_DEV_HANDLE(dev, i)	((void *)((int)dev | i))

#define RESMAN_DPRC_RESET_RETRIES 3

#define DPRC_OPTION_RESET_NON_RECURSIVE		0x00000001

#define DPRC_MEM_MAX_PAGE_DATA					 5

#define PEB_MAX_BLOCKS_ENTRIES					32

/* Known device types */
static char* device_types[] = { "dpni", "dpbp", "dpsw", "dpdmux", "dpmac", "dpdcei",
			 "dplag", "dpci", "dpseci", "dpaiop", "dpdmai",
			 "dpmcp", "dpdbg", "dprtc", "dpio", "dpcon",
			 "dpsparser" };

/* Number of device types */
#define DP_NUM_OF_DEVICE_TYPES (sizeof(device_types) / sizeof(char *))

/* Key Type to search for a specific container in the container hierarchy  */
enum key_type {
        RESMAN_KEY_TYPE_CONTAINER_ID,
        /* Container id */
        RESMAN_KEY_TYPE_PORTAL_ID,
        /* portal id inside the container */
        RESMAN_KEY_TYPE_CONTAINER_PORTAL_ID
        /* Dedicated container's portal id */
};

/*States of the device container*/
enum dprc_state {
	/*default state*/
	RESMAN_DPRC_STATE_UNLOCKED = 0,
	/*set through API*/
	RESMAN_DPRC_STATE_LOCKED
};

/* Number of cache lines required for data size (in bytes) */
#define CHACHE_LINES(size) (((size) + L1_CACHE_LINE_SIZE - 1) / L1_CACHE_LINE_SIZE)
/* Calculate the number of reserved bytes to fill the cache line */
#define CACHE_LINE_PAD(size) ((CHACHE_LINES(size) * L1_CACHE_LINE_SIZE) - (size))

/**
 * @brief        ID Range object
 *
 * resman_res_range is used in the free resources array of the
 * in order to save space. When creating a resource we change the range
 * min_id or max_id or split resman_res_range the range to reflect the fact
 * that an id is no longer a part of this range
 */
struct resman_res_range {
        int min_id;
        int max_id;
        int valid;
};

/**
 * @brief        device owner object
 *
 * Used in a list of device owners, specifies the owner dprc and the portal
 * that it used to open the device
 */
struct dev_owner {
        int portal_id;
        struct dprc *dprc;
};

/**
 * @brief        Allocation Policy
 *
 * Each type of resource/device has its own allocation policy which contains
 * the maximum quota allowed to be allocated to the containers for a specific
 * resource. The default value is the container�s allocation policy
 */
struct resman_alloc_policy {
        int quota; /**< Maximum amount of resources  or devices
         allowed taking from parent or -1 = by container */
        int allocated;
        /* Number of resources/devices allocated/assigned to the container*/
};

struct resman_stack_item_container {
        struct resman_list_item_container *container_item;
        int options;
};
/*****************************************************************************
 Resman List Items
 *****************************************************************************/
/**********************************1 line � 16 bytes *************************/
struct resman_list_item_container {
        struct dprc *container;
        /* pointer to the Container */
        struct resman_list_item_container *next;
        /* Next container item */
        int index;
        /* index is relevant only for dprc's children list //TODO -documentation
         *  and used by resman_get_device_count and resman_get_device_desc */
        int portal_id;
        /* Portal id is relevant only for object's open_containers list */
};

/**********************************1 line � 12 bytes *************************/
struct resman_list_item_device {
        struct resman_device *device;
        /* Pointer to the device */
        int index;
        /* set by resman_get_device_count.
         * Used to get the devices by resman_get_device_desc*/
        struct resman_list_item_device *next;
        /* Next device item */
};

/**********************************1 line � 20 bytes *************************/
struct resman_list_item_range {
        struct resman_res_range range;
        /* ids range */
        void *private;
        /**/
        struct resman_list_item_range *next;
        /* Next range item */
};

/*****************************************************************************
 Resman List Items
 *****************************************************************************/
/**********************************1 line � 24 bytes *************************/
struct resman_list_pres {
        //char type[16];
        char *pool_type;
	/* Primitive resource type */
        struct resman_res_range range;
        /* Primitive ID's range */
        struct dprc *orig_container;
        /* The container the free resource was taken from*/
        struct resman_list_pres *next;
};

/**********************************1 line � 32 bytes *************************/
struct resman_list_pool {
        char pool_type[16];
        /* Pool name */
        struct resman_list_item_range *range_item;
        /* List of pool resource ids ranges */
        struct resman_list_pool *next_pool;
        /* Next pool */
        int index;
        /* pool index - used to return the pool after resman_get_pool_count */
        int bound_counter;
        /* Number of bound resources. Relevant only in resman module */
};

/**********************************1 line � 28 bytes *************************/
struct resman_list_res_policy {
        char pool_type[16];
        /* Pool name */
        struct resman_alloc_policy res_alloc_policy;
        /* allocation policy data */
        struct resman_list_res_policy *next_policy;
        /* Next policy */
};

/**********************************1 line � 16 bytes *************************/
struct resman_list_open {
        void *open_dev;
        /* The opened device */
        int dev_type;
        int owner_id;
        struct resman_list_open *next;
        /* Next opened device */
};

/**********************************1 line � 32 bytes *************************/
struct resman_list_in_use_portal {
        int portal_id;
        /* Portal id */
        int users;
        /* Numsber of users */
        struct resman_list_open *open_list;
        /* List of devices that open on this portal */
        struct resman_list_in_use_portal *next;
        /* Next used portal */
        int dpmcp_object;
};

/*****************************************************************************
 Modules
 *****************************************************************************/
/**********************************1 line � 28 bytes *************************/
struct resman_icid {
        int icid_number;
        /* isolation context id */
        int owners;
        /* number of icid's owners */
        struct resman_list_item_container *containers_list;
        /* list of owner containers */
        void * lock_container_list;
        /* lock for icid's owner containers list */
        struct resman_icid *next;
        /* Next icid item */
};

/**********************************16 line � *********************************/
struct dprc
{
	/**********************************1 line � 32 bytes *****************/
        /* container's static information */
        /***********************/
        struct resman *resman;
        /* resman pointer */
        struct dprc *parent;
        /* Containr's parent */
        struct resman_icid *icid;
        /* Containr's icid */
        struct resman_list_item_container *container_item;
        /* a pointer to the object that holds this dprc */
        uint64_t options;
        /*!< Container's options as set at container's creation */
        int container_id;
        /* Containr's id */
        int portal_id;
        /* Containr's portal id */
        uint8_t locked;
        /* A variable which indicates if the container is locked */
        
	/**********************************1 line � 32 bytes *****************/
        char label[16];
        /* Containr's label */
        struct resman_list_item_container *open_containers;
        /* list of dprc's that opened this container */
        struct resman_list_item_container *children;
        /* dprc's children list */
        struct resman_list_in_use_portal *in_use_portals;
        /* a list of portals that belong to this container and in use by it */
        uint8_t reserved1[4];

	/**********************************3 lines � 96 bytes ****************/
        struct resman_list_res_policy *res_alloc_policy[HASH_SIZE];
        /* resources allocation policy */

        /**********************************3 lines � 96 bytes ****************/
        void * lock_res_alloc_policy[HASH_SIZE];
        /* lock for resources allocation policy */

	/**********************************4 lines � 128 bytes ***************/
        struct resman_alloc_policy dev_alloc_policy[DP_NUM_OF_DEVICE_TYPES];	//16 * 8 = 128 bytes
        /* devices allocation policy */

//        uint8_t reserved2[CACHE_LINE_PAD(sizeof(struct resman_alloc_policy) * DP_NUM_OF_DEVICE_TYPES)];
	/**********************************3 lines � 96 bytes ***************/
        struct resman_list_pool *free_res_pools[HASH_SIZE];
        /* free resources pools belongs to this container */

        /**********************************3 lines � 96 bytes ***************/
        void * lock_free_res_pools[HASH_SIZE];
        /* lock for free resources pools */

      	/**********************************2 lines � 64 bytes ****************/
        struct mc_irq irqs[DPRC_NUM_OF_IRQS]; //64
         /* irqs data */
//        uint8_t reserved3[CACHE_LINE_PAD(sizeof(struct mc_irq))];
	/**********************************2 lines � 64 bytes ****************/
        struct resman_list_item_device* devices[DP_NUM_OF_DEVICE_TYPES]; //16 devices 16*4 = 64
        /* dprc's device list */
 //       uint8_t reserved4[CACHE_LINE_PAD(sizeof(struct resman_list_item_device *) * DP_NUM_OF_DEVICE_TYPES)];
        /**********************************2 lines � 64 bytes ****************/
        void * lock_open_containers_list;
        void * lock_children_list;
        void * lock_in_use_portal_list;
};

struct resman_device {
	/**********************************2 lines � 64 bytes ****************/
        struct device dev; //52 bytes
        /* must be first */
        uint8_t owners_num;
        /* Number of device's owners */
        uint8_t reserved[CACHE_LINE_PAD(sizeof(struct device) + 1)];
	/**********************************4 lines  **************************/
        struct dev_owner owners[DP_DEV_MAX_OWNERS];
        /* Device's owners */
	/**********************************1 lines  **************************/
        void *    lock_dev_owners;
        /* lock for owners device owners */
        struct resman_list_pres *bound_res;
        /* Bound resource list */
        struct dprc* creator;
        /* Device's creator container */
        struct dprc* holder;
        /* The container that contains the device */
};

struct resman {
        struct dprc *global_container;
        /* Pointer to global container */

        uint32_t options;
        /* Resman options (init done. icid 0)*/

        struct dp_dev_type_param *dev_type_params[DP_NUM_OF_DEVICE_TYPES];
        /* Advanced parameter for each device type registered by the device driver*/

        /* Internal Free Resources pools*/
        /********************************/
        struct resman_list_item_range *container_ids;
        /* Free container ids range list */
        struct resman_list_item_range *free_icid_range_list;
        /* Free ICIDs range list */
        struct resman_list_item_range *dev_pool[DP_NUM_OF_DEVICE_TYPES];
        /* Indicates for each device type the maximum quota that can be created for this type*/

        /* All Resman's Resources and devices */
        /**************************************/
        struct resman_list_pool *pres_pools[HASH_SIZE];
        /* Hash Table that contains all the resources pool created */
        struct resman_icid *icid_list;
        /* In use ICIDs list */
        struct resman_list_item_device* devices[DP_NUM_OF_DEVICE_TYPES];
        /* List of all the devices created in the system and contains at the containers */

        /* Pool slabs */
	struct slab *container_item_slab;
	struct slab *range_item_slab;
	struct slab *pool_slab;
	struct slab *res_policy_slab;
	struct slab *open_dev_slab;
	struct slab *icid_slab;
	struct slab *in_use_portal_slab;
	struct slab *device_slab;
	struct slab *device_item_slab;
	struct slab *dprc_slab;
	struct slab *pres_slab;

	struct resman_stack_item_container container_stack[INTG_MAX_NUM_OF_CORES][MAX_NUM_OF_CONTAINERS_IN_STACK];

	/* spin locks */
	void *    lock_container_ids_list;
	void *    lock_free_icid_list;
	void *    lock_icid_list;
	void *    lock_dev_pool[DP_NUM_OF_DEVICE_TYPES];
	void *    lock_pres_pool[HASH_SIZE];
	void *    lock_devices_list[DP_NUM_OF_DEVICE_TYPES];
	/* lock for dprc's structures */
        void *    lock_dprc_devices[DP_NUM_OF_DEVICE_TYPES];


	/* Unassigned portal Policy */
        /****************************/
        int unassigned_portal_container_id;
        /* The container ID of the unassigned portal container */
        enum resman_unassigned_portal_policy unassigned_portal_policy;
        /* policy for blocking\enabling unassigned portals */
        int num_of_resources;
};

struct peb_avail_ranges {
	uint32_t offset[PEB_MAX_BLOCKS_ENTRIES];
	uint32_t size[PEB_MAX_BLOCKS_ENTRIES];
	int used;
	uint64_t base_paddr;
};

#endif /* _RESMAN_H */
