/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dprc_drv.h

 @Description   DPRC driver.
*//***************************************************************************/
#ifndef __RESMAN_DRV_H
#define __RESMAN_DRV_H

#endif /* __RESMAN_DRV_H */
