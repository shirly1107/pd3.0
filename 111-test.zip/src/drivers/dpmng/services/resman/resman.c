/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_errors.h"
#include "kernel/device.h"
#include "fsl_malloc.h"
#include "fsl_cmdif.h"
#include "fsl_platform.h"
#include "drivers/fsl_mc.h"
#include "fsl_io.h"
#include "fsl_gen.h"
#include "fsl_qbman.h"
#include "dpl.h"
#include "resman.h"
#include "fsl_dprc_cmd.h"
#include "fsl_core.h"
#include "kernel/fsl_spinlock.h"
#include "drivers/fsl_qbman_ctrl.h"
#include "dpc.h"
#include "fsl_timer.h"
#include "fsl_dpni_mc.h"
#include "fsl_dpdbg_mc.h"

extern int eiop_drv_hardware_restore(void);
static struct peb_avail_ranges ranges;

static int hash(char *type)
{
	int key;
	key = MIN((int)(type[0] - 'a'), HASH_SIZE - 1);
	return key;
}

static int get_dev_index(char *type)
{
	int i;

	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		if (strcmp(device_types[i], type) == 0)
			return i;
	}
	ASSERT_COND(0);
	return -EEXIST;
}

static int is_dev(char *type)
{
	int i;

	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		if (strcmp(device_types[i], type) == 0)
			return 1;
	}
	return 0;
}

static int invoke_inter(struct dprc *dprc, uint32_t event)
{
	if (!(dprc->resman->options & RESMAN_INIT_DONE))
		return 0;

	if (dprc->container_id != GLOBAL_CONTAINER_ID)
		event_send(&dprc->irqs[DPRC_IRQ_INDEX], event);

	return 0;
}

static struct resman_list_pool *find_res_pool(struct dprc *dprc, char *type)
{
	struct resman_list_pool *cur_pool;
	int index;

	index = hash(type);
	spin_lock(dprc->lock_free_res_pools[index]);
	cur_pool = dprc->free_res_pools[index];

	while (cur_pool) {
		if (strcmp(cur_pool->pool_type, type) == 0) {
			spin_unlock(dprc->lock_free_res_pools[index]);
			return cur_pool;
		} else
			cur_pool = cur_pool->next_pool;
	}
	spin_unlock(dprc->lock_free_res_pools[index]);
	return NULL;
}

static int find_res_policy(struct dprc *dprc,
                           char *type,
                           struct resman_alloc_policy **alloc_policy)
{
	struct resman_list_res_policy *res_policy;
	int index;

	index = hash(type);
	spin_lock(dprc->lock_res_alloc_policy[index]);
	res_policy = dprc->res_alloc_policy[index];

	while (res_policy) {
		if (strcmp(res_policy->pool_type, type) == 0) {
			*alloc_policy = &(res_policy->res_alloc_policy);
			spin_unlock(dprc->lock_res_alloc_policy[index]);
			return 0;
		} else
			res_policy = res_policy->next_policy;
	}
	spin_unlock(dprc->lock_res_alloc_policy[index]);
	*alloc_policy = NULL;
	return -EEXIST;
}

static struct resman_device *get_dev_from_resman_dev_pool(struct resman *resman,
                                                          int dev_type_index,
                                                          uint32_t id)
{
	struct resman_list_item_device *cur_device_item;

	if (id == RESMAN_NO_DEVICE_ID)
		return NULL;

	/* Search for the device in resman device pool */
	spin_lock(resman->lock_devices_list[dev_type_index]);

	cur_device_item = resman->devices[dev_type_index];
	while (cur_device_item) {
		if (cur_device_item->device->dev.id == id) {
			spin_unlock(resman->lock_devices_list[dev_type_index]);
			return cur_device_item->device;
		}
		cur_device_item = cur_device_item->next;
	}

	spin_unlock(resman->lock_devices_list[dev_type_index]);

	return NULL;
}

static struct resman_alloc_policy *alloc_new_policy(struct dprc *dprc,
                                                    char *type)
{
	struct resman_list_res_policy *new_res_policy, **res_policy_list;
	uint64_t tmp_addr;
	int index, err;

	index = hash(type);

	spin_lock(dprc->lock_res_alloc_policy[index]);
	res_policy_list = &(dprc->res_alloc_policy[index]);
	err = slab_acquire(dprc->resman->res_policy_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	new_res_policy = (struct resman_list_res_policy *)UINT_TO_PTR(tmp_addr);
	memset(new_res_policy, 0, sizeof(struct resman_list_res_policy));

	new_res_policy->res_alloc_policy.allocated = 0;
	new_res_policy->res_alloc_policy.quota = -1;
	strncpy(new_res_policy->pool_type, type,
	        STR_MAX_SIZE - 1);
	new_res_policy->next_policy = *res_policy_list;
	*res_policy_list = new_res_policy;
	spin_unlock(dprc->lock_res_alloc_policy[index]);

	return &(new_res_policy->res_alloc_policy);
}

static int update_alloc_res(struct dprc *src_dprc,
                            struct dprc *dst_dprc,
                            char *type,
                            int quota,
                            int operation)
{
	/* Update the allocated resource quota of the container and its
	 * ancestors*/
	struct resman_alloc_policy *res_policy = NULL;

	ASSERT_COND(src_dprc);
	ASSERT_COND(dst_dprc);

	find_res_policy(dst_dprc, type, &res_policy);
	if (res_policy == NULL)
		res_policy = alloc_new_policy(dst_dprc, type);

	while (dst_dprc != src_dprc) {
		if (operation == ADD_ALLOCATED_RES) {
			if (res_policy)
				res_policy->allocated += quota;
		}
		else {
			if (res_policy)
				res_policy->allocated -= quota;
		}
		dst_dprc = dst_dprc->parent;
		find_res_policy(dst_dprc, type, &res_policy);
		if (res_policy == NULL)
			res_policy = alloc_new_policy(dst_dprc, type);


	}
	return 0;
}

static int update_alloc_dev(struct dprc *src_dprc,
                            struct dprc *dst_dprc,
                            int dev_type_index,
                            int operation)
{
	while (dst_dprc != src_dprc) {
		if (operation == ADD_ALLOCATED_RES)
			dst_dprc->dev_alloc_policy[dev_type_index].allocated += 1;
		else
			dst_dprc->dev_alloc_policy[dev_type_index].allocated -= 1;
		dst_dprc = dst_dprc->parent;
	}
	return 0;
}


static int is_obj_creation_allowed(struct dprc *src_dprc,
                            struct dprc *dst_dprc,
                            char *type)
{
	int dev_type_index = get_dev_index(type);
	CHECK_COND_RETVAL(dev_type_index >= 0, -EEXIST);

	while (dst_dprc != src_dprc) {
		if (dst_dprc->dev_alloc_policy[dev_type_index].quota != -1)
			if ((dst_dprc->dev_alloc_policy[dev_type_index].allocated + 1) >
				(dst_dprc->dev_alloc_policy[dev_type_index].quota))
				return 0;

		dst_dprc = dst_dprc->parent;
	}
	return 1;
}

static int free_range_list(struct resman *resman, struct resman_list_item_range *list)
{
	struct resman_list_item_range *cur_find_item, *tmp_find_item;

	cur_find_item = list;
	while (cur_find_item) {
		tmp_find_item = cur_find_item;
		cur_find_item = cur_find_item->next;
		slab_release(resman->range_item_slab, (uint64_t)tmp_find_item);
	}

	return 0;
}

static int add_res_range_to_list(struct resman *resman,
	int min_id,
	int max_id,
	void *private,
	struct resman_list_item_range **list)
{
	struct resman_list_item_range *cur_range_item, **p_cur_range_item, *tmp_range_item;
	struct resman_list_item_range *new_range;
	int num = 0, err;
	uint64_t tmp_addr;

	num = (max_id - min_id + 1);

	/* Add as first node in list */
	if (*list == NULL) {
		err = slab_acquire(resman->range_item_slab, &tmp_addr);
		ASSERT_COND(err == 0);
		new_range = (struct resman_list_item_range *)UINT_TO_PTR(tmp_addr);

		new_range->range.min_id = min_id;
		new_range->range.max_id = max_id;
		new_range->range.valid = 1;
		new_range->private = private;
		/* insert new range after prev range*/
		new_range->next = (*list);
		*list = new_range;
		return num;
	}

	p_cur_range_item = list;
	cur_range_item = (*list); /* first node*/

	while(cur_range_item)
	{
		if (min_id < cur_range_item->range.min_id) {
			if (max_id >= cur_range_item->range.min_id)
				return -EEXIST;
			if (max_id == cur_range_item->range.min_id - 1) {
				cur_range_item->range.min_id = min_id;
				return num;
			}
			else{
				err = slab_acquire(resman->range_item_slab, &tmp_addr);
				ASSERT_COND(err == 0);
				new_range = (struct resman_list_item_range *)UINT_TO_PTR(tmp_addr);

				new_range->range.min_id = min_id;
				new_range->range.max_id = max_id;
				new_range->range.valid = 1;
				new_range->private = private;
				/* insert new range after prev range*/
				new_range->next = cur_range_item;
				*p_cur_range_item = new_range;
				return num;
			}
		}
		else { /* (min_id < cur_range_item->range.min_id) */
			if (min_id <= cur_range_item->range.max_id)
				return -EEXIST;
			else {
				if (min_id == cur_range_item->range.max_id + 1) {
					if (cur_range_item->next) {
						if ( max_id >= cur_range_item->next->range.min_id)
							return -EEXIST;
						if (max_id == (cur_range_item->next->range.min_id - 1)) {
							cur_range_item->range.max_id = cur_range_item->next->range.max_id;
							tmp_range_item = cur_range_item->next;
							cur_range_item->next = tmp_range_item->next;
							slab_release(resman->range_item_slab, (uint64_t)tmp_range_item);
							return num;
						}
					}
					cur_range_item->range.max_id = max_id;
					return num;
				}
			}
			p_cur_range_item = &(cur_range_item->next);
			cur_range_item = cur_range_item->next;
		}
	}
	/* Last node in the list */
	if (cur_range_item == NULL) {
		err = slab_acquire(resman->range_item_slab, &tmp_addr);
		ASSERT_COND(err == 0);
		new_range = (struct resman_list_item_range *)UINT_TO_PTR(tmp_addr);

		new_range->range.min_id = min_id;
		new_range->range.max_id = max_id;
		new_range->range.valid = 1;
		new_range->private = private;
		/* insert new range after prev range*/
		new_range->next = NULL;
		*p_cur_range_item = new_range;
		return num;
	}

	return 0;
}

static int create_new_dprc_res_pool(struct resman *resman,
	struct dprc *dprc,
	char *type)
{
	struct resman_list_pool *new_res_pool;
	struct resman_list_res_policy *new_res_policy;
	struct resman_list_pool **res_pool_list;
	struct resman_list_res_policy **res_policy_list;
	struct resman_alloc_policy *res_policy = NULL;
	int index, err;
	uint64_t tmp_addr;

	index = hash(type);

	err = slab_acquire(resman->pool_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	new_res_pool = (struct resman_list_pool *)UINT_TO_PTR(tmp_addr);
	memset(new_res_pool, 0, sizeof(struct resman_list_pool));

	new_res_pool->index = -1;
	strncpy(new_res_pool->pool_type, type,
	        STR_MAX_SIZE - 1);

	if (dprc == NULL) {
		/* No need to lock here. if dprc == NULL called from core 0 only*/
		res_pool_list = &(resman->pres_pools[index]);
	}
	else {
		find_res_policy(dprc, type, &res_policy);
		if (res_policy == NULL) {
			spin_lock(dprc->lock_res_alloc_policy[index]);
			res_policy_list = &(dprc->res_alloc_policy[index]);
			err = slab_acquire(resman->res_policy_slab, &tmp_addr);
			ASSERT_COND(err == 0);
			new_res_policy = (struct resman_list_res_policy *)UINT_TO_PTR(tmp_addr);
			memset(new_res_policy, 0, sizeof(struct resman_list_res_policy));

			new_res_policy->res_alloc_policy.allocated = 0;
			new_res_policy->res_alloc_policy.quota = -1;
			strncpy(new_res_policy->pool_type, type,
			        STR_MAX_SIZE - 1);
			new_res_policy->next_policy = *res_policy_list;
			*res_policy_list = new_res_policy;
			spin_unlock(dprc->lock_res_alloc_policy[index]);
		}
		spin_lock(dprc->lock_free_res_pools[index]);
		res_pool_list = &(dprc->free_res_pools[index]);
	}

	err = slab_acquire(resman->pool_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	new_res_pool = (struct resman_list_pool *)UINT_TO_PTR(tmp_addr);
	memset(new_res_pool, 0, sizeof(struct resman_list_pool));

	new_res_pool->index = -1;
	strncpy(new_res_pool->pool_type, type,
	        STR_MAX_SIZE - 1);

	new_res_pool->next_pool = *res_pool_list;
	*res_pool_list = new_res_pool;

	if (dprc)
		spin_unlock(dprc->lock_free_res_pools[index]);

	return 0;
}

static int destroy_dpmcp(struct dprc *dprc, int portal_id)
{
	struct resman_list_in_use_portal *cur_portal, **p_cur_portal, *tmp_used_portal;
	struct resman_list_item_range **list;
	struct resman_list_pool *dprc_res_pool;

	spin_lock(dprc->lock_in_use_portal_list);
	p_cur_portal = &(dprc->in_use_portals);
	cur_portal = dprc->in_use_portals;
	while (cur_portal) {
		if (cur_portal->portal_id == portal_id) {
			cur_portal->dpmcp_object = 0;
			if (portal_id == dprc->portal_id)
				cur_portal->users--; /* when the mcp is the dprc portal id it get users++ at initialization*/
			if (cur_portal->users == 0) {
				tmp_used_portal = cur_portal;
				*p_cur_portal = tmp_used_portal->next;
				slab_release(dprc->resman->in_use_portal_slab, (uint64_t)tmp_used_portal);
				if (portal_id != dprc->portal_id) {
					dprc_res_pool = find_res_pool(dprc, "mcp");
					ASSERT_COND(dprc_res_pool);
					list = &(dprc_res_pool->range_item);
					add_res_range_to_list(dprc->resman, portal_id,
					                      portal_id,
					                      NULL, list);
				}
			}
			spin_unlock(dprc->lock_in_use_portal_list);
			return 0;
		}
		p_cur_portal = &((*p_cur_portal)->next);
		cur_portal = cur_portal->next;
	}
	spin_unlock(dprc->lock_in_use_portal_list);
	ASSERT_COND(0);
	return -EEXIST;
}

static int get_container_id(struct resman *resman, int *container_id)
{
	struct resman_list_item_range *cur_range_item, *tmp_range_item = NULL;

	spin_lock(resman->lock_container_ids_list);
	/* Check if the pool of container's id is empty */
	cur_range_item = resman->container_ids;
	if (cur_range_item == NULL) {

		spin_unlock(resman->lock_container_ids_list);
		pr_err("Container IDs pool is empty\n");
		return -EEXIST;
	}

	/* Get the first free ID */
	*container_id = (int)cur_range_item->range.min_id;

	/* Delete empty range if this was the last free container id*/
	if (cur_range_item->range.min_id == cur_range_item->range.max_id) {
		tmp_range_item = cur_range_item;
		resman->container_ids = cur_range_item->next;
		spin_unlock(resman->lock_container_ids_list);
		slab_release(resman->range_item_slab, (uint64_t)tmp_range_item);
		return 0;
	}

	/* Remove the returned container id from the list */
	cur_range_item->range.min_id++;

	spin_unlock(resman->lock_container_ids_list);

	return 0;
}

static int free_container_id(struct resman *resman, int container_id)
{
	struct resman_list_item_range **list;

	/* Return an id to the list of free container ids */
	spin_lock(resman->lock_container_ids_list);

	list = &(resman->container_ids);
	add_res_range_to_list(resman, container_id, container_id, NULL, list);

	spin_unlock(resman->lock_container_ids_list);

	return 0;
}

static int get_aligned_pres(struct dprc *dprc,
	int min_range,
	int max_range,
	int num,
	int alignment,
	int *min_id,
	int *max_id,
	int *ret_cnt,
	struct resman_list_item_range **find_list)
{
	int vaild_range, mult, mod, aligned_min;

	if (alignment == 0)
		alignment = 1;

	/* Get the first aligned number between min_range and max_range */
	mod = min_range % alignment;
	mult = (((mod) == 0) ? 0 : 1);
	aligned_min = (min_range + ((mult * alignment) - mod));

	/* Calculate the valid range */
	vaild_range = (int)(max_range - aligned_min + 1);

	/* Check if the required number of resources contained in the
	 * valid range */
	if (num <= vaild_range) {
		*min_id = aligned_min;
		*max_id = aligned_min + num - 1;

		*ret_cnt += add_res_range_to_list(dprc->resman, *min_id, *max_id, dprc,
							find_list);

		return 0;
	}
	return -ENAVAIL;
}

static int add_pres_to_list(struct dprc *dprc,
	int min_range,
	int max_range,
	int num,
	int *cnt,
	struct resman_list_item_range **find_list)
{
	int min_id, max_id, ret_val;

	min_id = min_range;

	if (max_range < (num + min_range))
		max_id = max_range;
	else
		max_id = min_id + num - 1;

	ret_val = (int)add_res_range_to_list(dprc->resman, min_id, max_id, dprc, find_list);
	if (ret_val < 0) {
		return ret_val;
	}

	*cnt = ret_val;

	return 0;
}

static int is_search_at_parent_allowed(
		struct dprc *dprc,
		struct resman_res_req *res_req,
		int num)
{
	struct resman_alloc_policy *res_policy = NULL;
	int tmp_quota, tmp_allocated;

	find_res_policy(dprc, res_req->type, &res_policy);
	if (res_policy != NULL) {
		tmp_allocated = res_policy->allocated;
		tmp_quota = res_policy->quota;
	}

	if ((((res_policy == NULL) || (tmp_quota == -1)) &&
		((dprc->options & DPRC_CFG_OPT_ALLOC_ALLOWED) == 0)) ||
		((res_policy != NULL) && (tmp_quota != -1) && (tmp_allocated + num > tmp_quota)))
		return 0;

	return 1;
}

static int find_pres(struct dprc *dprc,
	struct resman_res_req *res_req, int ancestor_search, struct resman_list_item_range **find_list)
{
	int alignment;
	int cnt = 0;
	int cur_max_id, cur_min_id, min_id, max_id, num;
	struct resman_list_item_range *cur_range_item;
	struct resman_list_pool *res_pool;
	struct dprc *orig_dprc = dprc;

	/* Get the required alignment and number if resources */
	num = (int)res_req->num;
	alignment = (res_req->options & DPRC_RES_REQ_OPT_ALIGNED) ? 1 : 0;

	/* Create the the list for found pres */
	while (dprc) {
		res_pool = find_res_pool(dprc, res_req->type);
		if (res_pool != NULL) {
			cur_range_item = res_pool->range_item;
			while (cur_range_item) {
				cur_max_id = (int)cur_range_item->range.max_id;
				cur_min_id = (int)cur_range_item->range.min_id;
				if (alignment) {
					if (get_aligned_pres(dprc, cur_min_id,
					                     cur_max_id, num,
					                     res_req->id_base_align,
					                     &min_id, &max_id,
					                     &cnt,
						find_list) == 0) {
						return 0;
					} else
						cur_range_item = cur_range_item->next;
				} else {
					add_pres_to_list(dprc, cur_min_id,
					                 cur_max_id, num, &cnt,
					                 find_list);
					num -= cnt;
					if (num == 0)
						return 0;
					else
						cur_range_item =
							cur_range_item->next;
				}
			}
		}
		if (!ancestor_search)
			break;

		/* Check if search at the parent is allowed according to policy */
		if (!(is_search_at_parent_allowed(dprc, res_req, num)))
			break;

		dprc = dprc->parent;
	}

	/* Resources weren't found - free res_range_list */
	free_range_list(orig_dprc->resman, *find_list);
	*find_list = NULL;

	return -EEXIST;
}

static int get_pres_from_cur_range(struct dprc *dprc,
	int min_id,
	int max_id,
	struct resman_list_item_range *cur_range_item,
	struct resman_list_item_range **find_list,
	int *cnt)
{
	if (min_id <= cur_range_item->range.max_id) {
		if (cur_range_item->range.max_id < max_id)
			max_id = cur_range_item->range.max_id;
		if (cur_range_item->range.min_id > min_id)
			min_id = cur_range_item->range.min_id;

		*cnt = *cnt
			+ (int)add_res_range_to_list(dprc->resman, min_id, max_id, dprc,
							find_list);
	}

	return 0;

}

static int find_explicit_pres(struct dprc *dprc,
	struct resman_res_req *res_req, int ancestor_search, struct resman_list_item_range **find_list)
{
	int min_id, max_id, base;
	int cnt = 0;
	int num;
	struct resman_list_item_range *cur_range_item;
	struct resman_list_pool *res_pool;
	struct resman *resman = dprc->resman;

	num = (int)res_req->num;
	base = res_req->id_base_align;

	while (dprc) {
		res_pool = find_res_pool(dprc, res_req->type);
		if (res_pool != NULL) {
			cur_range_item = res_pool->range_item;
			while (cur_range_item) {
				min_id = base;
				max_id = base + (int)num - 1;

				if (max_id < cur_range_item->range.min_id)
					break;
				get_pres_from_cur_range(dprc, min_id, max_id,
							cur_range_item,
							find_list, &cnt);
				num -= cnt;
				if (num == 0)
					return 0;
				else
					cur_range_item = cur_range_item->next;
			}
		}

		if (!ancestor_search)
			break;


		if (!(is_search_at_parent_allowed(dprc, res_req, num)))
			break;

		dprc = dprc->parent;
	}

	/* Resources weren't found - free res_range_list */
	free_range_list(resman, *find_list);
	*find_list = NULL;

	return -EEXIST;
}

static int get_portal_id(uint64_t offset)
{
	struct soc_mc_portal_desc soc_mc_portal_desc;
	int err;

	memset(&soc_mc_portal_desc, 0, sizeof(soc_mc_portal_desc));
	/*mc_portal_desc.portal_id = 0; //already 0 */
	err = sys_get_desc(SOC_MODULE_SOC_MC_PORTAL,
				SOC_DB_SOC_MC_PORTAL_DESC_ID,
				&soc_mc_portal_desc, NULL);
	ASSERT_COND(err == 0);
	soc_mc_portal_desc.vaddr = 0;
	soc_mc_portal_desc.paddr += offset;
	err = sys_get_desc(SOC_MODULE_SOC_MC_PORTAL,
				SOC_DB_SOC_MC_PORTAL_DESC_PADDR,
				&soc_mc_portal_desc, NULL);
	if (err)
		return err;

	return soc_mc_portal_desc.portal_id;
}

static uint64_t get_portal_offset(int portal_id)
{
	struct soc_mc_portal_desc mc_portal_desc;
	struct soc_mc_portal_desc base_mc_portal_desc;

	int err;

	memset(&mc_portal_desc, 0, sizeof(struct soc_mc_portal_desc));
	mc_portal_desc.portal_id = portal_id;
	err = sys_get_desc(SOC_MODULE_SOC_MC_PORTAL,
				SOC_DB_SOC_MC_PORTAL_DESC_ID,
				&mc_portal_desc, NULL);
	ASSERT_COND(err == 0);
	memset(&base_mc_portal_desc, 0, sizeof(struct soc_mc_portal_desc));
	base_mc_portal_desc.portal_id = 0;
	err = sys_get_desc(SOC_MODULE_SOC_MC_PORTAL,
				SOC_DB_SOC_MC_PORTAL_DESC_ID,
				&base_mc_portal_desc, NULL);
	if (err)
		return err;

	return mc_portal_desc.paddr - base_mc_portal_desc.paddr;
}

static uint64_t get_portal_base(int portal_id)
{
	struct soc_mc_portal_desc mc_portal_desc;
	struct soc_mc_portal_desc base_mc_portal_desc;

	int err;

	memset(&mc_portal_desc, 0, sizeof(struct soc_mc_portal_desc));
	mc_portal_desc.portal_id = portal_id;
	err = sys_get_desc(SOC_MODULE_SOC_MC_PORTAL,
				SOC_DB_SOC_MC_PORTAL_DESC_ID,
				&mc_portal_desc, NULL);
	ASSERT_COND(err == 0);
	memset(&base_mc_portal_desc, 0, sizeof(struct soc_mc_portal_desc));
	base_mc_portal_desc.portal_id = 0;
	err = sys_get_desc(SOC_MODULE_SOC_MC_PORTAL,
				SOC_DB_SOC_MC_PORTAL_DESC_ID,
				&base_mc_portal_desc, NULL);
	if (err)
		return err;

	return base_mc_portal_desc.paddr;
}

static int match_container_id(struct dprc *dprc, int container_id)
{
	if (dprc->container_id == container_id)
		return 1;
	return 0;
}

static int match_free_portal_id(struct dprc *dprc, int portal_id)
{
	struct resman_res_req req;
	struct resman_list_item_range *list = NULL;
	struct resman_list_pool *res_pool;

	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = portal_id;
	req.num = 1;
	req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	strcpy(req.type, "mcp");

	res_pool = find_res_pool(dprc, "mcp");
	if (res_pool == NULL)
		return 0;

	find_explicit_pres(dprc, &req, 0, &list);
	if (list != NULL) {
		free_range_list(dprc->resman, list);
		return 1;
	}

	return 0;
}

static int match_container_portal_id(struct dprc *dprc, int portal_id)
{
	if (dprc->portal_id == portal_id)
		return 1;
	return 0;
}

static int remove_res_range_from_list(struct resman *resman,
	int min_id,
	int max_id,
	struct resman_list_item_range **list)
{
	struct resman_list_item_range *cur_range_item, **p_cur_range_item, *tmp_range_item;
	struct resman_list_item_range *new_range_item;
	uint64_t tmp_addr;
	int err;

	cur_range_item = *list;
	p_cur_range_item = list;

	if (cur_range_item == NULL)
		return -ENAVAIL;

	while (cur_range_item) {
		if ((min_id == cur_range_item->range.min_id)
			&& (max_id == cur_range_item->range.max_id)) {
			tmp_range_item = cur_range_item;
			cur_range_item = cur_range_item->next;
			(*p_cur_range_item) = cur_range_item;
			slab_release(resman->range_item_slab, (uint64_t)tmp_range_item);
			return 0;
		}
		if (min_id == cur_range_item->range.min_id) {
			cur_range_item->range.min_id = max_id + 1;
			return 0;
		}
		if (max_id == cur_range_item->range.max_id) {
			cur_range_item->range.max_id = min_id - 1;
			return 0;
		}
		if ((min_id > cur_range_item->range.min_id)
			&& (max_id < cur_range_item->range.max_id)) {

			err = slab_acquire(resman->range_item_slab, &tmp_addr);
			ASSERT_COND(err == 0);
			new_range_item = (struct resman_list_item_range *)UINT_TO_PTR(tmp_addr);

			memset(new_range_item, 0,
				sizeof(struct resman_list_item_range));
			new_range_item->range.max_id =
				cur_range_item->range.max_id;
			new_range_item->range.min_id = max_id + 1;
			new_range_item->range.valid = 1;

			cur_range_item->range.max_id = min_id - 1;
			new_range_item->next = cur_range_item->next;
			cur_range_item->next = new_range_item;
			return 0;
		} else {
			p_cur_range_item = &((*p_cur_range_item)->next);
			cur_range_item = cur_range_item->next;
		}
	}

	return -ENAVAIL;
}

#if 0 //this function causes double locking from get_explicit_free_dev_id and get_free_dev_id - flattened it inside those functions
static int remove_free_dev_id(struct resman *resman,
                              int dev_type_index,
                              uint16_t id)
{
	struct resman_list_item_range **cur_dev_range_list;

	spin_lock(resman->lock_dev_pool[dev_type_index]);

	cur_dev_range_list = &(resman->dev_pool[dev_type_index]);
	remove_res_range_from_list(resman, id, id, cur_dev_range_list);

	spin_unlock(resman->lock_dev_pool[dev_type_index]);

	return 0;
}
#endif

static int get_free_dev_id(struct resman *resman,
                           int dev_type_index,
                           uint16_t* id)
{
	uint16_t new_id;
    struct resman_list_item_range **cur_dev_range_list;

	/* Check if there is a pool for this device type */
	spin_lock(resman->lock_dev_pool[dev_type_index]);

	if (resman->dev_pool[dev_type_index] == NULL){
		pr_err("No free ids\n");
		return -ENAVAIL;
	}
	new_id = (uint16_t)resman->dev_pool[dev_type_index]->range.min_id;

	//	remove_free_dev_id(resman, dev_type_index, new_id);
    cur_dev_range_list = &(resman->dev_pool[dev_type_index]);
    remove_res_range_from_list(resman, new_id, new_id, cur_dev_range_list);

	spin_unlock(resman->lock_dev_pool[dev_type_index]);

	/* Return the id */
	*id = new_id;
	return 0;
}

static int get_explicit_free_dev_id(struct resman *resman,
                                int dev_type_index,
                                uint16_t id)
{
	struct resman_list_item_range *cur_range;
    struct resman_list_item_range **cur_dev_range_list;

	spin_lock(resman->lock_dev_pool[dev_type_index]);
	cur_range = resman->dev_pool[dev_type_index];
	while (cur_range) {
		if ((id >= cur_range->range.min_id) &&
			(id <= cur_range->range.max_id)) {
			//remove_free_dev_id(resman, dev_type_index, id);
		     cur_dev_range_list = &(resman->dev_pool[dev_type_index]);
		     remove_res_range_from_list(resman, id, id, cur_dev_range_list);

			spin_unlock(resman->lock_dev_pool[dev_type_index]);
			return 1;
		}
		cur_range = cur_range->next;
	}
	spin_unlock(resman->lock_dev_pool[dev_type_index]);

	return 0;
}

static int match_in_use_portal_id(struct dprc *dprc,
                                  int portal_id,
                                  int *users)
{
	struct resman_list_in_use_portal *portal_item;

	spin_lock(dprc->lock_in_use_portal_list);
	portal_item = dprc->in_use_portals;
	while (portal_item) {
		if (portal_item->portal_id == portal_id) {
			if (users)
				*users = portal_item->users;
			spin_unlock(dprc->lock_in_use_portal_list);
			return 1;
		}
		portal_item = portal_item->next;
	}
	spin_unlock(dprc->lock_in_use_portal_list);
	return 0;
}

static int is_match_container(struct resman_list_item_container *container_item,
                              enum key_type type,
                              int key)
{
	if (!container_item)
		return 0;

	if (type == RESMAN_KEY_TYPE_CONTAINER_ID)
		if (match_container_id(container_item->container, key))
			return 1;
	if (type == RESMAN_KEY_TYPE_PORTAL_ID) {
		if (container_item->container->portal_id == key)
			return 1;
		if (match_free_portal_id( container_item->container, key))
			return 1;
		if (match_in_use_portal_id(container_item->container, key,
		                           NULL))
			return 1;
	}
	if (type == RESMAN_KEY_TYPE_CONTAINER_PORTAL_ID)
		if (match_container_portal_id(
			container_item->container, key))
			return 1;

	return 0;
}

static struct dprc *get_container_by_key(struct resman *resman,
	enum key_type type,
	int key)
{
	struct dprc *container;
	struct resman_list_item_container *container_item;
	int process;

	if (type == RESMAN_KEY_TYPE_CONTAINER_ID)
		if (resman->global_container->container_id == key)
			return resman->global_container;

	container = resman->global_container;

	container_item = container->children;
	process = 1;
	while (container_item != NULL) {
		container = container_item->container;
		spin_lock(container->lock_children_list);
		if (process) {
			if (is_match_container(container_item, type, key)) {
				spin_unlock(container->lock_children_list);
				return container_item->container;
			}
		}
		if (container_item->container->children != NULL
			&& process) {
			container_item =
				container_item->container->children;
			process = 1;
		} else if (container_item->next != NULL) {
			container_item = container_item->next;
			process = 1;
		} else {
			container_item =
				container_item->container->parent->container_item;
			process = 0;
		}
		spin_unlock(container->lock_children_list);
	}
	return NULL;
}

static int add_container_to_icid(struct dprc *dprc, struct resman_icid *icid)
{
	struct resman_list_item_container *container_item;
	uint64_t tmp_addr;
	int err;

	err = slab_acquire(dprc->resman->container_item_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	container_item = (struct resman_list_item_container *)UINT_TO_PTR(tmp_addr);

	container_item->container = dprc;
	spin_lock(icid->lock_container_list);
	container_item->next = icid->containers_list;
	container_item->index = -1;
	icid->containers_list = container_item;
	icid->owners++;
	spin_unlock(icid->lock_container_list);
	return 0;
}

static int free_icid(struct resman *resman, int icid)
{
	struct resman_icid **p_icid_item, *tmp_icid_item;
	struct resman_list_item_range **cur_res_range_list;

	spin_lock(resman->lock_icid_list);

	p_icid_item = &(resman->icid_list);

	while (*p_icid_item) {
		if ((*p_icid_item)->icid_number == icid) {
			if ((*p_icid_item)->owners != 0) {
				spin_unlock(resman->lock_icid_list);
				pr_err("owners exist for this icid\n");
				return -EPERM;
			}
			tmp_icid_item = (*p_icid_item);
			(*p_icid_item) = (*p_icid_item)->next;
			slab_release(resman->icid_slab, (uint64_t)tmp_icid_item);
			spin_lock(resman->lock_free_icid_list);
			cur_res_range_list = &(resman->free_icid_range_list);
			if (!((icid == 0) && ((resman->options & HAS_ICID_0) == 0)))
				add_res_range_to_list(resman, icid, icid, NULL, cur_res_range_list);

			spin_unlock(resman->lock_free_icid_list);
			spin_unlock(resman->lock_icid_list);

			return 0;
		}
		p_icid_item = &((*p_icid_item)->next);
	}
	spin_unlock(resman->lock_icid_list);
	pr_err("ICID dosen't exist\n");
	return -ENAVAIL;
}

static int remove_container_from_icid(struct dprc *dprc,
	struct resman_icid *icid)
{
	struct resman_list_item_container **p_container_item, *tmp_container_item;
	int err = 0;

	spin_lock(icid->lock_container_list);
	p_container_item = &(icid->containers_list);
	while (*p_container_item) {
		if ((*p_container_item)->container == dprc) {
			icid->owners--;
			tmp_container_item = *p_container_item;
			*p_container_item = tmp_container_item->next;
			slab_release(dprc->resman->container_item_slab, (uint64_t)tmp_container_item);
			if (icid->owners == 0)
				err = free_icid(dprc->resman,
							icid->icid_number);
			spin_unlock(icid->lock_container_list);
			return err;
		}
		p_container_item = &((*p_container_item)->next);
	}
	spin_unlock(icid->lock_container_list);
	pr_err("container wasn't found for this icid\n");
	return -ENAVAIL;
}

static int get_free_icid(struct resman *resman, int *icid)
{
	struct resman_list_item_range *cur_range_item, *tmp_range_item = NULL;

	spin_lock(resman->lock_free_icid_list);

	cur_range_item = resman->free_icid_range_list;
	if (cur_range_item == NULL) {
		spin_unlock(resman->lock_free_icid_list);
		pr_err("ICID pool is empty\n");
		return -EEXIST;
	}

	/* Get the first free ID */
	*icid = (int)cur_range_item->range.min_id;

	/* delete empty range */
	if (cur_range_item->range.min_id == cur_range_item->range.max_id) {
		tmp_range_item = cur_range_item;
		resman->free_icid_range_list = cur_range_item->next;
		slab_release(resman->range_item_slab, (uint64_t)tmp_range_item);
	}
	else {
		cur_range_item->range.min_id++;
	}
	spin_unlock(resman->lock_free_icid_list);
	return 0;
}

static struct resman_icid* create_new_icid(struct resman *resman, int icid)
{
	struct resman_icid *new_icid;
	//struct resman_list_item_range	*new_range;
	struct resman_icid **p_cur_icid_item;
	uint64_t tmp_addr;
	int err;

	err = slab_acquire(resman->icid_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	new_icid = (struct resman_icid *)UINT_TO_PTR(tmp_addr);
	memset(new_icid, 0, sizeof(struct resman_icid));

	new_icid->icid_number = icid;
	new_icid->owners = 0;

	new_icid->lock_container_list = spin_lock_create();
	if (!new_icid->lock_container_list) {
		pr_err("icid %d: no memory for spinlock\n", icid);
		return NULL;
	}

	/* Add Icid to icid list */
	p_cur_icid_item = &(resman->icid_list);
	while (*p_cur_icid_item)
		if ((*p_cur_icid_item)->icid_number > icid)
			break;
		else
			p_cur_icid_item = &((*p_cur_icid_item)->next);

	new_icid->next = (*p_cur_icid_item);
	(*p_cur_icid_item) = new_icid;

	return new_icid;
}

static int unassign_pres(struct dprc *dprc,
	struct dprc *child_container,
	struct resman_res_req *res_req)
{
	struct resman_list_item_range *find_list = NULL, *cur_range_item;
	struct resman_list_item_range **cur_res_range_list;
	int min_id, max_id;
	struct resman_list_pool *child_res_pool, *dprc_res_pool;


	find_pres(child_container, res_req, 0, &find_list);
	if (find_list == NULL) {
		pr_err("resources weren't found\n");
		return -ENAVAIL;
	}

	cur_range_item = find_list;
	while (cur_range_item) {
		min_id = cur_range_item->range.min_id;
		max_id = cur_range_item->range.max_id;

		/*Remove found resources from child container */
		child_res_pool = find_res_pool(child_container, res_req->type);
		ASSERT_COND(child_res_pool);
		cur_res_range_list = &(child_res_pool->range_item);
		remove_res_range_from_list(dprc->resman, min_id, max_id, cur_res_range_list);

		/*Add found resources to dprc */
		dprc_res_pool = find_res_pool(dprc, res_req->type);
		if (dprc_res_pool == NULL) {
			create_new_dprc_res_pool(dprc->resman, dprc,
							res_req->type);
			dprc_res_pool = find_res_pool(dprc, res_req->type);
			ASSERT_COND(dprc_res_pool);
		}
		cur_res_range_list = &(dprc_res_pool->range_item);
		add_res_range_to_list(dprc->resman, min_id, max_id, NULL,
					cur_res_range_list);

		cur_range_item = cur_range_item->next;
	}

	free_range_list(dprc->resman, find_list);

	return 0;
}

static int unassign_explicit_pres(struct dprc *dprc,
	struct dprc *child_container,
	struct resman_res_req *res_req)
{
	struct resman_list_item_range *find_list = NULL, *cur_range_item;
	struct resman_list_item_range **cur_res_range_list;
	int min_id, max_id;
	struct resman_list_pool *dprc_res_pool, *child_res_pool;


	find_explicit_pres(child_container, res_req, 0, &find_list);
	if (find_list == NULL) {
		pr_err("resources weren't found\n");
		return -ENAVAIL;
	}
	cur_range_item = find_list;

	min_id = cur_range_item->range.min_id;
	max_id = cur_range_item->range.max_id;

	/* Remove resources from child container */
	child_res_pool = find_res_pool(child_container, res_req->type);
	ASSERT_COND(child_res_pool);
	cur_res_range_list = &(child_res_pool->range_item);
	remove_res_range_from_list(dprc->resman, min_id, max_id, cur_res_range_list);

	/* Add resources to dprc */
	dprc_res_pool = find_res_pool(dprc, res_req->type);
	if (dprc_res_pool == NULL) {
		create_new_dprc_res_pool(dprc->resman, dprc, res_req->type);
		dprc_res_pool = find_res_pool(dprc, res_req->type);
		ASSERT_COND(dprc_res_pool);
	}
	cur_res_range_list = &(dprc_res_pool->range_item);
	add_res_range_to_list(dprc->resman, min_id, max_id, NULL, cur_res_range_list);

	free_range_list(dprc->resman, find_list);

	return 0;
}

/* add device to resman and dprc lists. all locks on devices list should be placed in the caller routine*/
static struct resman_list_item_device *add_dev_to_list(struct resman_device *device,
	struct resman_list_item_device **p_new_dev_item)
{
	struct resman_list_item_device *new_device_item;
	int err;
	uint64_t tmp_addr;

	device = GET_DEVICE(device);

	err = slab_acquire(device->creator->resman->device_item_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	new_device_item = (struct resman_list_item_device *)UINT_TO_PTR(tmp_addr);
	memset(new_device_item, 0, sizeof(struct resman_list_item_device));

	new_device_item->next = (*p_new_dev_item);
	(*p_new_dev_item) = new_device_item;
	new_device_item->device = device;
	new_device_item->index = -1;

	return new_device_item;
}

/* no lock_dprc_devices should be placed here!! */
static struct resman_device *free_dev(struct dprc *dprc,
	struct resman_device *device)
{
	struct resman_list_item_device **cur_device_item;
	struct resman_list_item_device *tmp_new_device_item;
	int dev_type_index, id;
	struct resman_device *dev;
	struct resman_list_item_range **cur_dev_range_list;

	dev = GET_DEVICE(device);
	dev_type_index = get_dev_index(dev->dev.type);
	CHECK_COND_RETVAL(dev_type_index >= 0, NULL);

	/* Return device id to the pool */
	id = dev->dev.id;

	cur_device_item = &(dprc->devices[dev_type_index]);
	while (*cur_device_item) {
		if ((*cur_device_item)->device == dev) {
			tmp_new_device_item = *cur_device_item;
			*cur_device_item = tmp_new_device_item->next;
			slab_release(dprc->resman->device_item_slab, (uint64_t)tmp_new_device_item);
			break;
		}
		cur_device_item = &((*cur_device_item)->next);
	}

	spin_lock(dprc->resman->lock_devices_list[dev_type_index]);
	cur_device_item = &(dprc->resman->devices[dev_type_index]);
	while (*cur_device_item) {
		if ((*cur_device_item)->device == dev) {
			tmp_new_device_item = *cur_device_item;
			*cur_device_item = tmp_new_device_item->next;
			slab_release(dprc->resman->device_slab, (uint64_t)device);
			slab_release(dprc->resman->device_item_slab, (uint64_t)tmp_new_device_item);

			break;
		}
		cur_device_item = &((*cur_device_item)->next);
	}
	spin_unlock(dprc->resman->lock_devices_list[dev_type_index]);

	spin_lock(dprc->resman->lock_dev_pool[dev_type_index]);
	cur_dev_range_list = &(dprc->resman->dev_pool[dev_type_index]);
	add_res_range_to_list(dprc->resman, id, id, NULL, cur_dev_range_list);

	spin_unlock(dprc->resman->lock_dev_pool[dev_type_index]);

	return 0;
}

static struct resman_device *create_dev(struct dprc *dprc,
	char *type,
	int dev_type_index,
	uint16_t id,
	char *label)
{
	struct resman_list_item_device **cur_device_item;
	struct resman_device *device = NULL;
	uint64_t tmp_addr;

	spin_lock(dprc->resman->lock_devices_list[dev_type_index]);

	cur_device_item =
		&(((struct resman *)dprc->resman)->devices[dev_type_index]);

	/* Find the location to add the new device */
	while (*cur_device_item) {
		if ((*cur_device_item)->device->dev.id == id) {
			spin_unlock(dprc->resman->lock_devices_list[dev_type_index]);
			pr_err("Device already exist\n");
			return NULL;
		}
		if ((*cur_device_item)->device->dev.id > id)
			break;
		else
			cur_device_item = &((*cur_device_item)->next);
	}
	if( slab_acquire(dprc->resman->device_slab, &tmp_addr) ) {
		spin_unlock(dprc->resman->lock_devices_list[dev_type_index]);
		pr_err("Could not allocate new slab from device_slab\n");
		return NULL;
	}
	device = (struct resman_device *)UINT_TO_PTR(tmp_addr);
	memset(device, 0, sizeof(struct resman_device));

	device->dev.id = id;
	device->creator = dprc;
	device->holder = dprc;
	strncpy(device->dev.type, type,
	        STR_MAX_SIZE - 1);
	if (label)
		strncpy(device->dev.label, label, STR_MAX_SIZE - 1);
	/* Add device to list */
	add_dev_to_list(device, cur_device_item);

	spin_unlock(dprc->resman->lock_devices_list[dev_type_index]);

	device->lock_dev_owners = spin_lock_create();
	if (!device->lock_dev_owners) {
		pr_err("%s[%d]: no memory for spinlock\n", type, id);
		spin_lock(dprc->resman->lock_dprc_devices[dev_type_index]);
		free_dev(dprc, device);
		spin_unlock(dprc->resman->lock_dprc_devices[dev_type_index]);
		return NULL;
	}

	/* Add the device to container's devices list */

	spin_lock(dprc->resman->lock_dprc_devices[dev_type_index]);
	add_dev_to_list(device, &(dprc->devices[dev_type_index]));
	spin_unlock(dprc->resman->lock_dprc_devices[dev_type_index]);

	update_alloc_dev(dprc->resman->global_container, dprc,
			dev_type_index, ADD_ALLOCATED_RES);
	return device;
}

static struct resman_device *move_dev(struct dprc *src_dprc,
	struct dprc *dest_dprc,
	struct resman_list_item_device **cur_dev_item,
	int dev_type_index)
{
	struct resman_list_item_device *dev_item_to_move;
	struct resman *resman = src_dprc->resman;
	struct resman_list_in_use_portal **used_portal, *tmp_used_portal;
	struct dpmng_dev_ctx dev_ctx;
	int iommu_bypass, aiop;

	/* move the device to the requested container */
	dev_item_to_move = (*cur_dev_item);
	*cur_dev_item = dev_item_to_move->next;
	dev_item_to_move->next = dest_dprc->devices[dev_type_index];
	dest_dprc->devices[dev_type_index] = dev_item_to_move;
	dev_item_to_move->device->holder = dest_dprc;

	if (resman->dev_type_params[dev_type_index]->f_assign) {
		aiop = ((dest_dprc->options & DPRC_CFG_OPT_AIOP) == DPRC_CFG_OPT_AIOP);
		dev_ctx.type = aiop ? DPMNG_CTX_TYPE_AIOP : DPMNG_CTX_TYPE_GPP;
		dev_ctx.amq.icid = (uint16_t)dest_dprc->icid->icid_number;
		iommu_bypass = ((dest_dprc->options & DPRC_CFG_OPT_IOMMU_BYPASS) == DPRC_CFG_OPT_IOMMU_BYPASS);
		dev_ctx.amq.pl = iommu_bypass;
		dev_ctx.amq.bmt = iommu_bypass;
		dev_ctx.amq.bdi = iommu_bypass;
		dev_ctx.amq.va = 0;
		resman->dev_type_params[dev_type_index]->f_assign(
			&(dest_dprc->devices[dev_type_index]->device->dev),
			&dev_ctx);
	}

	/* The assumption here is that if this routine called, the number of user of this dcpmcp object is 0*/
	if (dev_type_index == get_dev_index("dpmcp")){
		spin_lock(src_dprc->lock_in_use_portal_list);
		spin_lock(dest_dprc->lock_in_use_portal_list);
		used_portal = &(src_dprc->in_use_portals);
		while (*used_portal) {
			if ((*used_portal)->portal_id == dev_item_to_move->device->dev.id) {
				tmp_used_portal = (*used_portal);
				(*used_portal) = tmp_used_portal->next;
				tmp_used_portal->next = dest_dprc->in_use_portals;
				dest_dprc->in_use_portals = tmp_used_portal;
				break;
			}
			used_portal = &((*used_portal)->next);
		}
	}
	spin_unlock(src_dprc->lock_in_use_portal_list);
	spin_unlock(dest_dprc->lock_in_use_portal_list);
	return dev_item_to_move->device;
}

static int unassign_device(struct dprc *dprc,
	struct dprc *child_container,
	int dev_type_index)
{
	struct resman_list_item_device **cur_dev_item;
	int users = 0, is_mcp, process;
	struct dprc *container = child_container;
	struct dprc *tmp_container = container;
	struct dprc *container_to_lock;
	is_mcp = (dev_type_index == get_dev_index("dpmcp"));

	process = 1;
	spin_lock(tmp_container->resman->lock_dprc_devices[dev_type_index]);
	while (container != NULL) {
		container_to_lock = container;
		spin_lock(container_to_lock->lock_children_list);
		if (process) {
			cur_dev_item = &(container->devices[dev_type_index]);
			while (*cur_dev_item) {
				if (is_mcp) {
					match_in_use_portal_id(container,
					                       (*cur_dev_item)->device->dev.id,
					                        &users);
					if (users) {
						cur_dev_item = &((*cur_dev_item)->next);
						continue;
					}
				}
				if (!((*cur_dev_item)->device->dev.state
					& (DPRC_OBJ_STATE_OPEN | DPRC_OBJ_STATE_PLUGGED
						| DPRC_OBJ_STATE_ENABLE))) {
					move_dev(container, dprc, cur_dev_item,
							dev_type_index);
					spin_unlock(container_to_lock->lock_children_list);
					spin_unlock(container->resman->lock_dprc_devices[dev_type_index]);
					return 0;
				} else {
					pr_err("unauthorized operation - device "
					"is open, plugged or enable\n");
					return -EPERM;
				}
			}
		}
		/* No need to lock - child containers can't be removed because no destroy container is active during other routines.
		 * New containers added to be first in the list and will not be searched */
		if (container->children != NULL && process) {
		     container = container->children->container;
		     process = 1;
		} else if (container->container_item->next != NULL) {
		     container = container->container_item->next->container;
		     process = 1;
		} else {
		     container = container->parent;
		     process = 0;
		}
		spin_unlock(container_to_lock->lock_children_list);

	}

	spin_unlock(tmp_container->resman->lock_dprc_devices[dev_type_index]);
	return -ENODEV;

}

/* no locks, all locks should be placed in the caller routine */
static struct resman_device *assign_device_to_child(struct dprc *dprc,
	struct dprc *child_container,
	char *type,
	int plugged)
{
	int index, users = 0, is_mcp;
	struct resman_list_item_device **cur_dev_item;
	struct resman_device *assigned_device;

	index = get_dev_index(type);
	CHECK_COND_RETVAL(index >= 0, NULL);
	is_mcp = (strcmp(type, "dpmcp") == 0);

#if 0
	/* Check if self assignment */
	if (dprc == child_container)
	{
		pr_err("self assignment is forbidden\n");
		return NULL;
		/* Device not found */
		if (dprc->parent->container_id == GLOBAL_CONTAINER_ID){
			/* self assignment for root container */
			dprc = dprc->parent; /* Global container */
			/* Continue with assignment from global to root container */
		}
		else {
			pr_err("self assignment of non-explicit object allowed for root container only\n");
			return NULL;
		}

	}
#endif
	/* search for the requested device */
	cur_dev_item = &(dprc->devices[index]);
	while (*cur_dev_item) {

		if (is_mcp) {
			match_in_use_portal_id(dprc,
			                       (*cur_dev_item)->device->dev.id, &users);
			if (users) {
				cur_dev_item = &((*cur_dev_item)->next);
				continue;
			}
		}
		if (!((*cur_dev_item)->device->dev.state
			& (DPRC_OBJ_STATE_OPEN | DPRC_OBJ_STATE_PLUGGED
				| DPRC_OBJ_STATE_ENABLE))) {
			/* move the device to the requested container*/
			assigned_device =  move_dev(dprc, child_container,
			                            cur_dev_item, index);
			return assigned_device;

		} else
			cur_dev_item = &((*cur_dev_item)->next);
	}
	return NULL;
}

static int unassign_explicit_device(struct dprc *dprc,
	struct dprc *child_container,
	int id,
	char *dev_type)
{
	struct resman_list_item_device **cur_dev_item;
	int users = 0, is_mcp;
	struct resman_device *device;
	struct dprc *contain_dprc = NULL;
	int dev_type_index;

	dev_type_index = get_dev_index(dev_type);
	CHECK_COND_RETVAL(dev_type_index >= 0, -EEXIST);

	spin_lock(dprc->resman->lock_dprc_devices[dev_type_index]);
	/* Check if device is already exist in parent container */
	cur_dev_item = &(dprc->devices[dev_type_index]);
	while (*cur_dev_item) {
		if ((*cur_dev_item)->device->dev.id == id) {
			spin_unlock(dprc->resman->lock_dprc_devices[dev_type_index]);
			return -EEXIST;
		}
		cur_dev_item = &((*cur_dev_item)->next);
	}

	is_mcp = (get_dev_index("dpmcp") == dev_type_index);

	device = resman_find_device_at_descendant(dprc->resman, child_container,
	                                          dev_type, id, &contain_dprc);
	if (device == NULL){
		spin_unlock(dprc->resman->lock_dprc_devices[dev_type_index]);
		pr_err("object to unassign wasn't found\n");
		return -ENODEV;
	}

	cur_dev_item = &(contain_dprc->devices[dev_type_index]);
	while (*cur_dev_item) {
		if ((*cur_dev_item)->device->dev.id == id) {
			if (is_mcp) {
				match_in_use_portal_id(child_container, id,  &users);
				if (users) {
					spin_unlock(dprc->resman->lock_dprc_devices[dev_type_index]);
					pr_err("unauthorized operation - mcp is in use\n");
					return -EPERM;
				}
			}
			if (((*cur_dev_item)->device->dev.state
				& (DPRC_OBJ_STATE_OPEN | DPRC_OBJ_STATE_PLUGGED
					| DPRC_OBJ_STATE_ENABLE))) {
				spin_unlock(dprc->resman->lock_dprc_devices[dev_type_index]);
				pr_err("unauthorized operation - device "
				"is open, plugged or enable\n");
				return -EPERM;
			}
			move_dev(contain_dprc, dprc, cur_dev_item,
					dev_type_index);

			spin_unlock(dprc->resman->lock_dprc_devices[dev_type_index]);
			return 0;
		}
		cur_dev_item = &((*cur_dev_item)->next);
	}

	spin_unlock(dprc->resman->lock_dprc_devices[dev_type_index]);
	return -ENODEV;

}

static int set_dev_plug_state(struct resman_device *device, int plugged)
{
	device = GET_DEVICE(device);

	device->dev.state &= (~DPRC_OBJ_STATE_PLUGGED);
	device->dev.state |= (plugged * DPRC_OBJ_STATE_PLUGGED);
	return 0;
}

/* no lock_dprc_devices for this routine. place lock_dprc_devices lock at the caller routine*/
static struct resman_device *assign_explicit_device_to_child(struct dprc *dprc,
	struct dprc *child_container,
	char *type,
	uint16_t id,
	int plugged)
{
	int dev_type_index;
	struct resman_list_item_device **cur_dev_item;
	int users = 0, is_mcp;
	struct resman_device *assigned_device;

	dev_type_index = get_dev_index(type);
	CHECK_COND_RETVAL(dev_type_index >= 0, NULL);
	is_mcp = (strcmp(type, "dpmcp") == 0);

	/* Device not found in child container *
	/* Check if self assignment */
	if (dprc == child_container)
	{
		pr_err("self assignment is forbidden\n");
		return NULL;
#if 0
		if (dprc->parent->container_id == GLOBAL_CONTAINER_ID){
			/* self assignment for root container */
			dprc = dprc->resman->global_container; /* Global container */
			/* Continue with assignment from global to root container */
		}
#endif
	}

	/* search for the requested device */
	cur_dev_item = &(dprc->devices[dev_type_index]);
	while (*cur_dev_item) {
		if ((*cur_dev_item)->device->dev.id == id) {
			/* device was found */

			 /*if the dpmcp is in use by this container, it can't be assigned */
			if (is_mcp) {
				match_in_use_portal_id(dprc, id, &users);
				if (users) {
					pr_err("unauthorized operation - mcp is in use\n");
					return NULL;
				}
			}
			/* Check if device can be copied or moved to
			 * other container according to its state */
			if (((*cur_dev_item)->device->dev.state
				& (DPRC_OBJ_STATE_OPEN
					| DPRC_OBJ_STATE_PLUGGED
					| DPRC_OBJ_STATE_ENABLE))) {
				pr_err("unauthorized operation - device "
				"is open, plugged or enable\n");
				return NULL;
			}
			/* move the device to the requested container*/
			assigned_device =  move_dev(dprc, child_container,
					cur_dev_item, dev_type_index);
			return assigned_device;

		} else
			cur_dev_item = &((*cur_dev_item)->next);
	}
	pr_err("Device is not available\n");
	return NULL;
}

static int get_explicit_container_id(struct resman *resman, int container_id)
{
	struct resman_list_item_range **list;
	int err;

	spin_lock(resman->lock_container_ids_list);

	list = &(resman->container_ids);
	err = remove_res_range_from_list(resman, container_id, container_id, list);

	spin_unlock(resman->lock_container_ids_list);
	return err;
}
static int remove_found_res_from_list(struct resman *resman, struct resman_list_item_range *res_list,
	struct resman_res_req *res_req)
{
	struct resman_list_item_range *cur_range_item;
	struct resman_list_item_range **cur_res_range_list;
	struct dprc *cont;
	struct resman_list_pool *res_pool;
	int min_id, max_id;

	/* remove bound resources from free list*/
	cur_range_item = res_list;
	while (cur_range_item) {
		min_id = cur_range_item->range.min_id;
		max_id = cur_range_item->range.max_id;

		/* Remove resources from their container*/
		cont = ((struct dprc *)(cur_range_item->private));
		res_pool = find_res_pool(cont, res_req->type);
		ASSERT_COND(res_pool);
		cur_res_range_list = &(res_pool->range_item);
		remove_res_range_from_list(resman, min_id, max_id, cur_res_range_list);

		if ((cur_range_item->next == NULL) ||
			(cur_range_item->private != cur_range_item->next->private))
			invoke_inter(cont, DPRC_IRQ_EVENT_RES_REMOVED);

		cur_range_item = cur_range_item->next;
	}

	return 0;
}

static int find_res_at_containers(
		struct resman_res_req *res_req,
		struct dprc *dprc_to_search_from,
		int layout,
		int ancestor_search, struct resman_list_item_range **find_list)
{
	;
	if (res_req->options & DPRC_RES_REQ_OPT_EXPLICIT) {
		return find_explicit_pres(dprc_to_search_from,
				res_req, ancestor_search, find_list);
	} else
		return find_pres(dprc_to_search_from, res_req,
				      ancestor_search, find_list);
}

static int assign_pres(struct dprc *dprc,
	struct dprc *child_container,
	struct resman_res_req *res_req,
	int layout,
	int ancestor_search)
{
	struct resman_list_item_range *find_list = NULL, *cur_find_item;
	struct dprc *dprc_to_search_from;
	struct resman_list_item_range **child_range_list;
	struct resman_list_pool *child_res_pool, *res_pool;
	int min_id, max_id;
	struct resman_list_item_range **src_res_range_list;
	struct dprc *src_cont;

	dprc_to_search_from = dprc;

	if (layout)
		dprc_to_search_from = dprc->resman->global_container;
	else if (dprc->parent->container_id == GLOBAL_CONTAINER_ID)
		ancestor_search = 1;
	else if (dprc == child_container){
			pr_err("self assignment is forbidden for this container\n");
			return -EPERM;
	}

	find_res_at_containers(res_req, dprc_to_search_from, layout,
	                                   ancestor_search, &find_list);
	if (find_list == NULL)
		return -EEXIST;

	/* Get child resource pool to add resources */
	child_res_pool = find_res_pool(child_container, res_req->type);
	if (child_res_pool == NULL) {
		create_new_dprc_res_pool(dprc->resman, child_container,
						res_req->type);
		child_res_pool = find_res_pool(child_container, res_req->type);
		ASSERT_COND(child_res_pool);
	}
	child_range_list = &(child_res_pool->range_item);

	/* Add resources to the required container resource list */
	cur_find_item = find_list;
	while (cur_find_item) {
		min_id = cur_find_item->range.min_id;
		max_id = cur_find_item->range.max_id;

		/* Remove resources from their source container*/
		src_cont = ((struct dprc *)(cur_find_item->private));
		res_pool = find_res_pool(src_cont, res_req->type);
		ASSERT_COND(res_pool);
		src_res_range_list = &(res_pool->range_item);
		remove_res_range_from_list(dprc->resman, min_id, max_id, src_res_range_list);

		/* add resources to child resource pool */
		add_res_range_to_list(dprc->resman, min_id, max_id, NULL, child_range_list);

		/* update resource allocation amount */
		if (((struct dprc *)cur_find_item->private) != dprc)
			update_alloc_res(src_cont,
							 dprc, res_req->type,
							 max_id - min_id + 1,
							 ADD_ALLOCATED_RES);

		/* invoke interrupt at the container the resources took from */
		invoke_inter(src_cont, DPRC_IRQ_EVENT_RES_REMOVED);

		cur_find_item = cur_find_item->next;
	}
	invoke_inter(child_container, DPRC_IRQ_EVENT_RES_ADDED);

	free_range_list(dprc->resman, find_list);
	return 0;
}

static int assign_explicit_device(struct dprc *dprc,
	struct dprc *child_container,
	char *type,
	uint16_t id,
	int plugged)
{
	struct resman_list_item_device *device_item;
	struct resman *resman;
	struct resman_list_item_device **child_cur_device_item;
	struct resman_device *device;
	int dev_type_index, found_dev = 0;

	dev_type_index = get_dev_index(type);
	CHECK_COND_RETVAL(dev_type_index >= 0, -EEXIST);
	resman = dprc->resman;
	/* Check if the device already exist in child list */
	spin_lock(resman->lock_dprc_devices[dev_type_index]);
	child_cur_device_item = &(child_container->devices[dev_type_index]);
	while (*child_cur_device_item) {
		if ((*child_cur_device_item)->device->dev.id == id) {
			if (dprc == child_container) {
				/* self assignment to change device state */
				set_dev_plug_state(
					(*child_cur_device_item)->device,
					plugged);
				//invoke_inter(child_container);
				found_dev = 1;
				device_item = (*child_cur_device_item);
				break;
				//return 0;
			} else {
				spin_unlock(resman->lock_dprc_devices[dev_type_index]);
				pr_err("Device already exist\n");
				return -EEXIST;
			}
		}
		child_cur_device_item = &((*child_cur_device_item)->next);
	}

	/* set requested device at child container */
	if (!found_dev) {
		device = assign_explicit_device_to_child(dprc, child_container,
		                                         type, id, plugged);
		if (device == NULL) {
			return -EINVAL;
		}
		/* Search for the devices to assign in the requester container list */
		device_item = child_container->devices[dev_type_index];
	}

	if (plugged == 1)
		device_item->device->dev.state |= DPRC_OBJ_STATE_PLUGGED;

	spin_unlock(resman->lock_dprc_devices[dev_type_index]);

	return 0;
}

static int assign_device(struct dprc *dprc,
	struct dprc *child_container,
	char *type,
	int plugged)
{
	struct resman_list_item_device *cur_device_item;
	struct dprc *dprc_to_search_from = dprc;
	struct resman_device *device;
	int dev_type_index;

	dev_type_index = get_dev_index(type);
	CHECK_COND_RETVAL(dev_type_index >= 0, -EEXIST);

	if (dprc == child_container){
		pr_err("self assignment is forbidden\n");
		return -EPERM;
#if 0
		if (!(dprc->parent->container_id == GLOBAL_CONTAINER_ID)){
			pr_err("self assignment of non-explicit devices allowed only for root container\n");
			return -EPERM;
		}
		dprc_to_search_from = dprc->parent; /*Global container*/
#endif
	}
	spin_lock(dprc->resman->lock_dprc_devices[dev_type_index]);
	device = assign_device_to_child(dprc_to_search_from,
	                                child_container, type, plugged);
	if (device == NULL) {
		spin_unlock(dprc->resman->lock_dprc_devices[dev_type_index]);
		pr_err("Device is not available\n");
		return -ENODEV;
	}
	/* Search for the assigned device in the child container list */
	cur_device_item = child_container->devices[dev_type_index];

	if (plugged == 1)
		cur_device_item->device->dev.state |= DPRC_OBJ_STATE_PLUGGED;

	spin_unlock(dprc->resman->lock_dprc_devices[dev_type_index]);

	return 0;
}

static void set_dev_desc(struct dprc *dprc,
	struct resman_list_item_device *cur_device_item,
	struct dprc_obj_desc *dev_desc,
	int type_index)
{
	struct dp_dev_type_param *dev_param;

	/* according to device type */
	dev_param = dprc->resman->dev_type_params[type_index];
	dev_desc->vendor = dev_param->vendor;
	strncpy(dev_desc->type, dev_param->device_type, STR_MAX_SIZE-1);
	dev_desc->id = cur_device_item->device->dev.id;
	dev_desc->ver_major = dev_param->ver_major;
	dev_desc->ver_minor = dev_param->ver_minor;
	dev_desc->state = cur_device_item->device->dev.state;
	dev_desc->irq_count = dev_param->irq_count;
	dev_desc->region_count = dev_param->region_count;
	dev_desc->flags = dev_param->flags;
	strncpy(dev_desc->label, cur_device_item->device->dev.label, STR_MAX_SIZE-1);

	return;
}

static void set_dprc_desc(struct dprc *dprc,
	struct resman_list_item_container *cur_container_item,
	struct dprc_obj_desc *dprc_desc)
{
	int id;

	/* according to device type */
	dprc_desc->vendor = 0x1957;
	dprc_desc->ver_major = DPRC_VER_MAJOR;
	dprc_desc->ver_minor = DPRC_VER_MINOR;
	strcpy(dprc_desc->type, "dprc");
	id = cur_container_item->container->container_id;
	dprc_desc->id = id;
	dprc_desc->region_count = DPRC_REGION_COUNT;
	dprc_desc->irq_count = DPRC_IRQ_COUNT;
	dprc_desc->flags = 0;
	strncpy(dprc_desc->label, cur_container_item->container->label, STR_MAX_SIZE-1);
	return;
}

static int free_dev_portal(struct dprc *dprc, void *dev_handle, int portal_id)
{
	struct resman_list_item_range **list;
	struct resman_list_in_use_portal **used_portal, *tmp_used_portal;
	struct resman_list_open **dev_item, *tmp_dev_item;

	list = &((find_res_pool(dprc, "mcp"))->range_item);

	spin_lock(dprc->lock_in_use_portal_list);
	used_portal = &(dprc->in_use_portals);
	while ((*used_portal)) {
		if ((*used_portal)->portal_id == portal_id) {
			dev_item = &((*used_portal)->open_list);
			while (*dev_item) {
				if ((*dev_item)->open_dev == dev_handle) {
					(*used_portal)->users--;
					tmp_dev_item = (*dev_item);
					(*dev_item) = tmp_dev_item->next;
					slab_release(dprc->resman->open_dev_slab, (uint64_t)tmp_dev_item);
					if (((*used_portal)->users == 0) &&
						((*used_portal)->dpmcp_object == 0)){
						tmp_used_portal = (*used_portal);
						(*used_portal) = tmp_used_portal->next;
						slab_release(dprc->resman->in_use_portal_slab, (uint64_t)tmp_used_portal);
						if (portal_id != dprc->portal_id)
							add_res_range_to_list(dprc->resman, portal_id, portal_id, NULL,
									list);
					}
					spin_unlock(dprc->lock_in_use_portal_list);
					return 0;
				}
				dev_item = &((*dev_item)->next);
			}

		}
		used_portal = &((*used_portal)->next);
	}
	spin_unlock(dprc->lock_in_use_portal_list);
	return -EEXIST;
}

static int allocate_portal(struct dprc *dprc, int *portal_id,
                           int dpmcp_obj,
                           struct resman_list_in_use_portal **in_use_portal,
                           int ancestor_search)
{
	struct resman_res_req req;
	struct resman_list_item_range *list = NULL, **remove_list;
	struct resman_list_pool *res_pool;
	struct resman_list_in_use_portal *used_portal;

	memset(&req, 0, sizeof(struct resman_res_req));
	req.num = 1;
	req.options = ((*portal_id == (uint16_t)NO_PORTAL_ID) ? 0 : DPRC_RES_REQ_OPT_EXPLICIT);
	req.id_base_align = *portal_id;
	strcpy(req.type, "mcp");

	if (*portal_id == (uint16_t)NO_PORTAL_ID)
		find_pres(dprc, &req, ancestor_search, &list);
	else
		find_explicit_pres(dprc, &req, ancestor_search, &list);

	if (list != NULL) {
		/* Remove_portal id from the list it found at and assign
		 * this portal to the to device */
		res_pool = find_res_pool(
			((struct dprc *)(list->private)), req.type);
		ASSERT_COND(res_pool);
		remove_list = &(res_pool->range_item);
		*portal_id = list->range.min_id;
		remove_res_range_from_list(dprc->resman, *portal_id, *portal_id, remove_list);
		if (in_use_portal)
			*in_use_portal = NULL;
		// the list is not needed any more
		free_range_list(dprc->resman, list);
		return 0;
	}

	spin_lock(dprc->lock_in_use_portal_list);
	used_portal = dprc->in_use_portals;
	while (used_portal) {
		if (used_portal->portal_id == *portal_id) {
			if ((dpmcp_obj) && (used_portal->dpmcp_object)){
				pr_err("dcmcp object with the requested portal id already exists\n");
				spin_unlock(dprc->lock_in_use_portal_list);
				return -EEXIST;
			}
			if (in_use_portal)
				*in_use_portal = used_portal;
			spin_unlock(dprc->lock_in_use_portal_list);
			return 0;
		}
		used_portal = used_portal->next;
	}
	if (in_use_portal)
		*in_use_portal = NULL;
	spin_unlock(dprc->lock_in_use_portal_list);
	return -EAGAIN;
}

static int add_dev_to_in_use_portal(struct dprc *dprc,
	void *dev_handle,
	int portal_id,
	int dev_type,
	int owner_id)
{
	struct resman_list_in_use_portal *used_portal;
	struct resman_list_open *open_item;
	uint64_t tmp_addr;
	int err;

	spin_lock(dprc->lock_in_use_portal_list);
	used_portal = dprc->in_use_portals;
	while (used_portal) {
		if (used_portal->portal_id == portal_id) {
			used_portal->users++;

			err = slab_acquire(dprc->resman->open_dev_slab, &tmp_addr);
			ASSERT_COND(err == 0);
			open_item = (struct resman_list_open *)UINT_TO_PTR(tmp_addr);

			open_item->open_dev = dev_handle;
			open_item->owner_id = owner_id;
			open_item->dev_type = dev_type;
			open_item->next = used_portal->open_list;
			used_portal->open_list = open_item;
			spin_unlock(dprc->lock_in_use_portal_list);
			return 0;
		}
		used_portal = used_portal->next;
	}

	err = slab_acquire(dprc->resman->in_use_portal_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	used_portal = (struct resman_list_in_use_portal *)UINT_TO_PTR(tmp_addr);
	memset(used_portal, 0, sizeof(struct resman_list_in_use_portal));

	used_portal->next = dprc->in_use_portals;
	dprc->in_use_portals = used_portal;
	used_portal->portal_id = portal_id;
	used_portal->users = 1;

	err = slab_acquire(dprc->resman->open_dev_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	open_item = (struct resman_list_open *)UINT_TO_PTR(tmp_addr);

	open_item->open_dev = dev_handle;
	open_item->dev_type = dev_type;
	open_item->owner_id = owner_id;
	used_portal->open_list = open_item;
	open_item->next = NULL;

	spin_unlock(dprc->lock_in_use_portal_list);
	return 0;
}
static int get_owner_id(struct resman_device *device)
{
	int owner_id;

	device = GET_DEVICE(device);
	for (owner_id = 0; owner_id < DP_DEV_MAX_OWNERS; owner_id++) {
		if (device->owners[owner_id].dprc == NULL)
			return owner_id;
	}

	return -EINVAL;
}

static struct dprc *get_dprc(struct resman *resman,
	char *type,
	uint16_t id,
	int portal_id)
{
	int key;
	struct dprc *dprc;
	struct resman_device *device = NULL;
	int dev_type_index;

	/* Search for the device in the container */
	if (portal_id == NO_PORTAL_ID) {
		dev_type_index = get_dev_index(type);
		CHECK_COND_RETVAL( dev_type_index >= 0, NULL, "Invalid device type: %s\n", type );
		device = get_dev_from_resman_dev_pool(resman,
							dev_type_index,
							id);
		if (device == NULL)
			dprc = resman->global_container;
		else
			dprc = device->holder;
	} else {
		dprc = get_container_by_key(resman,
		                            RESMAN_KEY_TYPE_PORTAL_ID,
		                            portal_id);
		if (dprc == NULL) {
			if (resman->unassigned_portal_policy
				== DPRC_UNASSIGNED_PORTAL_POLICY_BLOCK)
				return NULL;
			key = resman->unassigned_portal_container_id;
			dprc = get_container_by_key(
				resman, RESMAN_KEY_TYPE_CONTAINER_ID, key);
			if (dprc == NULL) {
				pr_err("Container wasn't found\n");
				return NULL;
			}
		}
	}
	return dprc;
}

static struct resman_device *create_dpmcp_object(struct resman *resman,
	struct dprc *dprc,
	uint16_t id,
	char *label)
{
	struct resman_device *device;
	struct resman_list_in_use_portal **used_portal_p, *used_portal = NULL;
	int dev_type_index;
	int portal_id;
	int err;
	uint64_t tmp_addr;

	used_portal_p = &used_portal;
	dev_type_index = get_dev_index("dpmcp");
	CHECK_COND_RETVAL(dev_type_index >= 0, NULL);

	//LOCK
	portal_id = (int)id;
	err = allocate_portal(dprc, &portal_id, 1, used_portal_p, 1);
	if (err == -EEXIST)
		return NULL;

	if (portal_id == NO_PORTAL_ID)
	{
		pr_err("portal id is not available\n");
		return NULL;
	}

	if (err == -EAGAIN) /* portal wasn't found at in use and free list */
		if (dprc->portal_id != id){
			pr_err("portal id is not available\n");
			return NULL;
	}

	if (used_portal == NULL) {

		err = slab_acquire(dprc->resman->in_use_portal_slab, &tmp_addr);
		ASSERT_COND(err == 0);
		used_portal = (struct resman_list_in_use_portal *)UINT_TO_PTR(tmp_addr);
		memset(used_portal, 0, sizeof(struct resman_list_in_use_portal));

		spin_lock(dprc->lock_in_use_portal_list);
		used_portal->next = dprc->in_use_portals;
		dprc->in_use_portals = used_portal;
		used_portal->portal_id = portal_id;
		spin_unlock(dprc->lock_in_use_portal_list);
	}

	used_portal->dpmcp_object = 1;
	if (dprc->portal_id == portal_id)
		used_portal->users++;

	device = create_dev(dprc, "dpmcp", dev_type_index, (uint16_t)portal_id, label);
	if (device == NULL) {
		pr_err("Device is not available\n");
		return NULL;
	}
	//UNLOCK
	return device;
}

static struct resman_device *create_device(struct resman *resman,
	struct dprc *dprc,
	char *type,
	uint16_t id,
	int portal_id,
	char *label)
{
	struct resman_device *device;
	int dev_type_index;

	dev_type_index = get_dev_index(type);
	CHECK_COND_RETVAL(dev_type_index >= 0, NULL);

	if (id == RESMAN_NO_DEVICE_ID) {
		if (get_free_dev_id(resman, dev_type_index, &id) != 0) {
			pr_err("failed to get free device id\n");
			return NULL;
		}
		device = create_dev(dprc, type, dev_type_index, id, label);
		if (device == NULL) {
			pr_err("failed to create device\n");
			return NULL;
		}
	} else {
		/* Create device from layout */
		if (get_explicit_free_dev_id(resman, dev_type_index, id) != 1) {
				pr_err("failed to get free device id\n");
				return NULL;
		}

		device = create_dev(dprc, type, dev_type_index, id, label);
		if (device == NULL) {
			pr_err("Device is not available\n");
			return NULL;
		}
	}

	return device;
}

static void *open_device(struct resman *resman,
	struct dprc *dprc,
	char *type,
	uint16_t id,
	int portal_id)
{
	struct resman_list_item_device *device_item;
	struct resman_device *device = NULL;
	struct dprc *contain_dprc = NULL;
	int dev_type_index;

	/* Search the device inside the dprc */
	dev_type_index = get_dev_index(type);
	CHECK_COND_RETVAL(dev_type_index >= 0, NULL);

	spin_lock(resman->lock_dprc_devices[dev_type_index]);
	device_item = dprc->devices[dev_type_index];
	while (device_item) {
		if (device_item->device->dev.id == id) {
			device = device_item->device;
			break;
		}
		device_item = device_item->next;
	}

	/* Search the device in the child containers of the dprc */
	if (device == NULL) {
		device = resman_find_device_at_descendant(resman, dprc, type, id, &contain_dprc);
	}
	spin_unlock(resman->lock_dprc_devices[dev_type_index]);

	if (device == NULL) {
		pr_err("no device\n");
		return NULL;
	}

	return device;
}

static void *open_create_device(struct resman *resman,
	char *type,
	uint16_t id,
	int portal_id,
	int create,
	char *label)
{
	struct dprc *dprc;
	struct resman_device *device = NULL;
	int owner_id = 0;

	dprc = get_dprc(resman, type, id, portal_id);
	if (dprc == NULL)
		return NULL;

	if(strcmp(type, "dpdbg") == 0) {
		if (dprc->parent->parent != NULL) {
			pr_err("object creation forbidden - DPDBG must be created in a root container\n");
			return NULL;
		}
	}
	
	if (create != DPRC_OPEN_DEV_ONLY) {
		if (!is_obj_creation_allowed(resman->global_container, dprc, type))
		{
			pr_err("object creation forbidden - exceed the maximum object quota\n");
			return NULL;
		}
		/* Deny the creation of the object that is not defined in DPL
		 * if it is not permitted through DPRC options*/
		if(!(dpl_is_obj_defined(type, id)))
			if ((dprc->options & DPRC_CFG_OPT_OBJ_CREATE_ALLOWED) == 0) {
				pr_err("create device policy is forbidden\n");
				return NULL;
			}
		if (strcmp(type, "dpmcp") == 0)
			device = create_dpmcp_object(resman, dprc, id, label);
		else
			device = create_device(resman,
			                       dprc, type, id, portal_id, label);
	}
	else
		device = open_device(resman, dprc, type, id, portal_id);


	if (device == NULL) {
		return NULL;
	}

	/* validate and allocate portal ID*/
	/* if we just create the device don't try to set the owner
	 and increase the reference count */
	if (portal_id != NO_PORTAL_ID &&
			(create != DPRC_CREATE_DEV_ONLY)) {

		/* Allocate portal to open the device */
		if (dprc->portal_id != portal_id)
			if (allocate_portal(dprc, &portal_id, 0, NULL, 9) != 0) 
				return NULL;
		/* Create new device */
		spin_lock(device->lock_dev_owners);
		owner_id = get_owner_id(device);
		if (owner_id < 0) {
			spin_unlock(device->lock_dev_owners);
			pr_err("max number of owners\n");
			return NULL;
		}
		device->owners[owner_id].dprc = dprc;
		device->owners[owner_id].portal_id = portal_id;
		/* Increase the number of device's owners*/
		device->owners_num++;
		/* Mark device as open */
		device->dev.state |= DPRC_OBJ_STATE_OPEN;
		spin_unlock(device->lock_dev_owners);

		/* Update container's in use portal list*/
		add_dev_to_in_use_portal(dprc, device, portal_id, 1, owner_id);
		return (void*)((int)device | owner_id);
	}

	return (void*)((int)device);
}

static int close_device(struct resman *resman, void *device, int portal_id)
{
	struct resman_device *dev = NULL;
	struct dprc *owner_dprc = NULL;
	int owner_id;

	ASSERT_COND(device);

	owner_id = OWNER_ID(device);
	dev = GET_DEVICE(device);

	owner_dprc = dev->owners[owner_id].dprc;
	if (owner_dprc == NULL) {
		pr_err("Not open\n");
		return -EPERM;
	}

	spin_lock(dev->lock_dev_owners);
	dev->owners_num--;
	if (dev->owners_num == 0)
		dev->dev.state &= (~DPRC_OBJ_STATE_OPEN);

	dev->owners[owner_id].dprc = NULL;
	dev->owners[owner_id].portal_id = 0;
	spin_unlock(dev->lock_dev_owners);

	/* Return portal to free portals pool*/
	free_dev_portal(owner_dprc, dev, portal_id);

	return 0;
}

static int destroy_device(struct resman *resman, void *device)
{
	struct resman_device *dev;
	struct dprc *contain_dprc = NULL;
	int i, owner_id, index;

	owner_id = OWNER_ID(device);
	dev = GET_DEVICE(device);

	/* Return the portal id of all the device's owners and inform the
	 * software context of the owners containers*/
	for (i = 0; i < DP_DEV_MAX_OWNERS; i++) {
		if (dev->owners[i].dprc) {

			if (i != owner_id)
				cmdif_close_dev(GET_DEV_HANDLE(dev, i),
						dev->owners[i].portal_id);
			close_device(resman,
			             (struct resman_device *)(GET_DEV_HANDLE(dev, i)),
			             dev->owners[i].portal_id);
		}
	}
	/* Free the device from Resman's device list */
	/* Release the device from the device list in its contain container */

	index = get_dev_index(dev->dev.type);
	CHECK_COND_RETVAL(index >= 0, -EEXIST);
	spin_lock(resman->lock_dprc_devices[index]);
	resman_find_device_at_descendant(resman, NULL, dev->dev.type,
	                                 dev->dev.id, &contain_dprc);
	ASSERT_COND(contain_dprc);
	free_dev(contain_dprc, dev);
	if (strcmp(dev->dev.type, "dpmcp") == 0) {
		destroy_dpmcp(contain_dprc, dev->dev.id);
	}

	spin_unlock(resman->lock_dprc_devices[index]);
	update_alloc_dev(contain_dprc->resman->global_container, contain_dprc,
			index, SUBTRACT_ALLOCATED_RES);
	/* invoke interrupt at the device's containing container */
	invoke_inter(contain_dprc, DPRC_IRQ_EVENT_OBJ_DESTROYED);

	return 0;
}

static int destroy_device_without_portal(struct resman *resman, void *device)
{
	struct resman_device *dev;
	struct dprc *contain_dprc = NULL;
	int index;

	dev = GET_DEVICE(device);

	/* Free the device from Resman's device list */
	/* Release the device from the device list in its contained container */
	index = get_dev_index(dev->dev.type);
	CHECK_COND_RETVAL(index >= 0, -EEXIST);
	spin_lock(resman->lock_dprc_devices[index]);
	resman_find_device_at_descendant(resman, NULL,
		dev->dev.type, dev->dev.id, &contain_dprc);
	ASSERT_COND(contain_dprc);
	free_dev(contain_dprc, dev);
	if (strcmp(dev->dev.type, "dpmcp") == 0) {
			destroy_dpmcp(contain_dprc, dev->dev.id);
	}
	spin_unlock(resman->lock_dprc_devices[index]);
	return 0;
}

static int is_ancestor(struct dprc *requester_dprc, struct dprc *child_dprc)
{
	struct dprc *tmp_dprc;

	tmp_dprc = child_dprc;
	while (tmp_dprc->parent) {
		if (tmp_dprc == requester_dprc) {
			return 1;
		} else
			tmp_dprc = tmp_dprc->parent;
	}

	return 0;
}

/* This routine is called from destroy container, therefore no locks needed.
 * The parent that called destroy and its descendant can't handle other commands during destroy */
static int unassign_all_res_pool_to_parent(struct dprc *container)
{
	struct resman_list_pool *res_pool, *tmp_res_pool;
	struct resman_list_item_range *cur_range_item;
	struct resman_res_req res_req;

	int i, err;

	for (i = 0; i < HASH_SIZE; i++) {
		res_pool = container->free_res_pools[i];
		while (res_pool) {
			cur_range_item = res_pool->range_item;
			while (cur_range_item) {
				memset(&res_req, 0,
					sizeof(struct resman_res_req));
				res_req.num =
					(uint32_t)(cur_range_item->range.max_id
							- cur_range_item->range.min_id
							+ 1);
				res_req.options = DPRC_RES_REQ_OPT_EXPLICIT;
				strncpy(res_req.type, res_pool->pool_type, STR_MAX_SIZE-1);
				res_req.id_base_align =
					cur_range_item->range.min_id;
				err = resman_unassign(container->parent,
						container->container_id,
						&res_req);
				CHECK_COND_RETVAL(err==0, err);

				cur_range_item = res_pool->range_item;
			}
			tmp_res_pool = res_pool;
			container->free_res_pools[i] =
				tmp_res_pool->next_pool;
			res_pool = container->free_res_pools[i];
			slab_release(container->resman->pool_slab, (uint64_t)tmp_res_pool);
		}
	}
	return 0;
}

/* all lock_dprc_devices locks should be placed in the called routine  */
static int destroy_device_from_destroy_container(struct resman *resman,
                                                 int type_index,
                                                 struct dprc *container,
                                                 struct resman_device* device)
{
	struct dprc *open_container;
	int i;

	if (resman->dev_type_params[type_index]->f_destroy) {
		resman->dev_type_params[type_index]->f_destroy((void *)device);
		ASSERT_COND(device->bound_res == NULL);
	} else
		resman_unbind_all(device);

	for (i = 0; i < DP_DEV_MAX_OWNERS; i++) {
		if (device->owners[i].dprc) {
			open_container = device->owners[i].dprc;
			{
				/* Indicate that device is destroyed to owner
				 * ancestor*/
				invoke_inter(open_container,
				             DPRC_IRQ_EVENT_OBJ_DESTROYED);
				/* Close device for owner id i*/
				cmdif_close_dev(GET_DEV_HANDLE(device, i),
						device->owners[i].portal_id);
				close_device(resman,GET_DEV_HANDLE(device, i),
						device->owners[i].portal_id);
			}
		}
	}

	free_dev(container, device);

	if (strcmp(device->dev.type, "dpmcp") == 0) {
		destroy_dpmcp(container, device->dev.id);
	}

	return 0;
}

static int destroy_container(struct resman *resman, struct dprc *container)
{
	struct resman_list_item_device *cur_device_item;
	struct resman_res_req res_req;
	int i, j, portal_id, err;
	struct resman_list_item_range **list;

	pr_debug("container id - %d\n", container->container_id);

	/* Get all container's devices and handle them before destroy */
	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		spin_lock(resman->lock_dprc_devices[i]);
		cur_device_item = container->devices[i];
		while (cur_device_item) {
			if (cur_device_item->device->creator == container) {
				/* Destroy the device */
				destroy_device_from_destroy_container(resman, i, container, cur_device_item->device);

				cur_device_item = cur_device_item->next;

			} else {
				for (j = 0; j < DP_DEV_MAX_OWNERS; j++)
					if (cur_device_item->device->owners[j].dprc == container) {
						portal_id = cur_device_item->device->owners[j].portal_id;
						cmdif_close_dev(GET_DEV_HANDLE(cur_device_item->device, j), portal_id);
						close_device(resman, GET_DEV_HANDLE(cur_device_item->device, j), portal_id);
					}
				if (cur_device_item->device->dev.state
					& DPRC_OBJ_STATE_ENABLE)
					if (resman->dev_type_params[i]->f_reset)
						resman->dev_type_params[i]->f_reset(
							(void *)cur_device_item->device);
				memset(&res_req, 0,
					sizeof(struct resman_res_req));
				res_req.num = 1;
				res_req.options = DPRC_RES_REQ_OPT_EXPLICIT;
				strncpy(res_req.type,
					cur_device_item->device->dev.type,
					STR_MAX_SIZE-1);
				res_req.id_base_align =
					cur_device_item->device->dev.id;

				cur_device_item = cur_device_item->next;

				spin_unlock(resman->lock_dprc_devices[i]);
				err = resman_unassign(container->parent,
						container->container_id,
						&res_req);
				CHECK_COND_RETVAL(err==0, err, "Failed to unassign device which wasn't create by this container");
			}
		}
	}
	/* Free Container id */
	free_container_id(resman, container->container_id);
	/* Remove containers from icids owners */
	remove_container_from_icid(container, container->icid);
	/* Return container's portal id to list */
	list = &(find_res_pool(container, "mcp")->range_item);
	ASSERT_COND(list);
	res_req.num = 1;
	res_req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	strcpy(res_req.type, "mcp");
	res_req.id_base_align = container->portal_id;
	add_res_range_to_list(resman, container->portal_id, container->portal_id,
		NULL, list);

	/* Unassigns free resource pools to parent container */
	err = unassign_all_res_pool_to_parent(container);
	CHECK_COND_RETVAL(err==0, err, "Failed to unassign device which wasn't create by this container");

	return 0;
}

static void *open_dprc(struct resman *resman, uint16_t id, int portal_id)
{
	struct dprc *dprc;
	struct dprc *requester_dprc;
	struct resman_list_item_container *container_item;
	int container_portal_id = 1;
	uint64_t tmp_addr;
	int err;

	requester_dprc = get_container_by_key(
		resman, RESMAN_KEY_TYPE_CONTAINER_PORTAL_ID, portal_id);
	if (requester_dprc == NULL) {
		requester_dprc = get_container_by_key(
			resman, RESMAN_KEY_TYPE_PORTAL_ID, portal_id);
		if (requester_dprc == NULL) {
			pr_err("container is unavailable\n");
			return NULL;
		}
		container_portal_id = 0;
	}

	if (id == GLOBAL_CONTAINER_ID) {
		/* Only root container allowed to open global container */
		if (requester_dprc->parent->container_id != GLOBAL_CONTAINER_ID) {
			pr_err("operation is not allowed\n");
			return NULL;
		}
		dprc = resman->global_container;
	} else {

		dprc = get_container_by_key(resman,
						RESMAN_KEY_TYPE_CONTAINER_ID,
						id);
		if (dprc == NULL) {
			pr_err("container is unavailable\n");
			return NULL;
		}

		/* Check if requestor dprc can open dprc -
		 * requestor dprc is dprc or its ancestor */
		if (is_ancestor(requester_dprc, dprc) == 0)
			return NULL;
	}
	if (container_portal_id == 0) {
		if (allocate_portal(requester_dprc, &portal_id, 0, NULL, 0) != 0) {
			return NULL;
		}
	}
	err = slab_acquire(dprc->resman->container_item_slab, &tmp_addr);
	CHECK_COND_RETVAL(err == 0,	NULL,
			"Open container failed: resman out of memory");
	container_item = (struct resman_list_item_container *)UINT_TO_PTR(tmp_addr);
	/* Don't need to check if the container was already opened on
	the same portal id in order to allow two users that share the same MCP
	to access its objects */
	add_dev_to_in_use_portal(requester_dprc, dprc, portal_id, 0, 0);

	container_item->container = requester_dprc;
	container_item->portal_id = portal_id;
	container_item->index = -1;
	spin_lock(dprc->lock_open_containers_list);
	container_item->next = dprc->open_containers;
	dprc->open_containers = container_item;
	spin_unlock(dprc->lock_open_containers_list);

	return (void *)dprc;
}

static int close_dprc(struct resman *resman, struct dprc *dprc, int portal_id)
{
	struct resman_list_item_container *tmp_container_item;
	struct resman_list_item_container **p_cur_container_item;
	struct dprc *requester_dprc;

	requester_dprc = get_container_by_key(
		resman, RESMAN_KEY_TYPE_CONTAINER_PORTAL_ID, portal_id);
	if (requester_dprc == NULL) {
		requester_dprc = get_container_by_key(
			resman, RESMAN_KEY_TYPE_PORTAL_ID, portal_id);
		if (requester_dprc == NULL) {
			pr_err("container is unavailable\n");
			return -ENAVAIL;
		}
	}
	/* Check if it is open and remove from open list */
	spin_lock(dprc->lock_open_containers_list);
	p_cur_container_item = &(dprc->open_containers);
	while (*p_cur_container_item) {
		if (((*p_cur_container_item)->container == requester_dprc)
			&& ((*p_cur_container_item)->portal_id == portal_id))
			break;
		p_cur_container_item = &((*p_cur_container_item)->next);
	}
	if (*p_cur_container_item == NULL) {
		spin_unlock(dprc->lock_open_containers_list);
		pr_err("not open\n");
		return -EPERM;
	}
	/* free container item in the list */
	tmp_container_item = *p_cur_container_item;
	*p_cur_container_item = (*p_cur_container_item)->next;
	spin_unlock(dprc->lock_open_containers_list);

	free_dev_portal(requester_dprc, dprc, portal_id);

	slab_release(resman->container_item_slab, (uint64_t)tmp_container_item);

	return 0;
}

static int close_destroyed_container(struct dprc *container)
{
	struct resman_list_item_container *open_container;

	/* Inform all the GPPs that opened this container */
	spin_lock(container->lock_open_containers_list);
	open_container = container->open_containers;
	while (open_container) {
		/* Indicate container is destroyed to ancestor GPP */
		invoke_inter(open_container->container,
				DPRC_IRQ_EVENT_CONTAINER_DESTROYED);

		cmdif_close_dev((void *)((int)container),
				open_container->portal_id);
		/* Close dprc for all the GPPs that this dprc is currently open for them */
		close_dprc(container->resman, container,
				open_container->portal_id);

		open_container = open_container->next;
	}
	spin_unlock(container->lock_open_containers_list);
	return 0;
}

static int free_container(struct dprc *container)
{
	int i;

	for (i = 0; i < HASH_SIZE; i++)
		spin_lock_free(container->lock_res_alloc_policy[i]);

	spin_lock_free(container->lock_open_containers_list);
	slab_release(container->resman->dprc_slab, (uint64_t)container);

	return 0;
}

static int destroy_container_dynasty(struct resman *resman,
	struct dprc *container)
{
	struct dprc *parent = container->parent;
	struct resman_list_item_container **p_container_item, *tmp_container_item;
	int err;

	/* no need to lock destroy can't be active with other commands */
	while ((container != NULL) && (container != parent)) {
		if (container->children != NULL) {
			container = container->children->container;
		} else {
			close_destroyed_container(container);
			err = destroy_container(resman, container);
			CHECK_COND_RETVAL(err==0, err);

			/* Remove container from parent's list */
			p_container_item = &(container->parent->children);
			while(*p_container_item) {
				if ((*p_container_item)->container == container){
					container = container->parent;
					tmp_container_item = *p_container_item;
					*p_container_item = tmp_container_item->next;

					free_container(tmp_container_item->container);
					slab_release(resman->container_item_slab, (uint64_t)tmp_container_item);
					break;
				}
				p_container_item = &((*p_container_item)->next);
			}
		}
	}
	return 0;
}

static int set_icid(struct resman *resman, struct dprc *container, int icid)
{
	struct resman_icid *cur_icid_item;
	struct resman_icid *new_icid;
	struct resman_list_item_range **cur_res_range_list;

	spin_lock(resman->lock_icid_list);

	if (icid != DPRC_GET_ICID_FROM_POOL) {
		/* Check if icid already exists */
		cur_icid_item = resman->icid_list;
		while (cur_icid_item) {
			if (cur_icid_item->icid_number == icid) {
				container->icid = cur_icid_item;
				spin_unlock(resman->lock_icid_list);
				return add_container_to_icid(container,
							     cur_icid_item);
			}
			cur_icid_item = cur_icid_item->next;
		}

		/* Search the icid at the free icid list if exist remove from free icid list */
		spin_lock(resman->lock_free_icid_list);
		cur_res_range_list = &(resman->free_icid_range_list);
		remove_res_range_from_list(resman, icid, icid, cur_res_range_list);
		spin_unlock(resman->lock_free_icid_list);
	}
	else {
		if (get_free_icid(resman, &icid) != 0) {
			spin_unlock(resman->lock_icid_list);
			return -EEXIST;
		}
	}

	/* Create new icid with the requested id */
	new_icid = create_new_icid(resman, icid);
	spin_unlock(resman->lock_icid_list);
	if (new_icid == NULL) {
		return -ENOMEM;
	}

	container->icid = new_icid;
	return add_container_to_icid(container, new_icid);
}

static int set_root_new_icid(struct resman *resman,
                             struct dprc *dprc,
                             int new_icid)
{
	int err;

	if ((dprc->icid->icid_number) != new_icid) {
		err = remove_container_from_icid(dprc, dprc->icid);
		if (err != 0)
				return err;
		err = set_icid(resman, dprc, new_icid);
		if (err != 0)
				return err;
	}

	return 0;
}

static int check_set_root_new_attr(struct dprc *dprc,
                                   struct dprc_cfg *container_attr)
{
	int err;
	dprc->options &= (~DPRC_CFG_OPT_ALLOC_ALLOWED);
	dprc->options |= (container_attr->options & DPRC_CFG_OPT_ALLOC_ALLOWED) ?
			DPRC_CFG_OPT_ALLOC_ALLOWED : 0;

	dprc->options &= (~DPRC_CFG_OPT_SPAWN_ALLOWED);
	dprc->options |= (container_attr->options & DPRC_CFG_OPT_SPAWN_ALLOWED) ?
			DPRC_CFG_OPT_SPAWN_ALLOWED : 0;

	dprc->options &= (~DPRC_CFG_OPT_IRQ_CFG_ALLOWED);
	dprc->options |= (container_attr->options & DPRC_CFG_OPT_IRQ_CFG_ALLOWED) ?
			DPRC_CFG_OPT_IRQ_CFG_ALLOWED : 0;

	if (container_attr->options & DPRC_CFG_OPT_AIOP) {
		pr_err("Root container can't be set as aiop container\n");
		return -ENOTSUP;
	}

	dprc->options &= (~DPRC_CFG_OPT_IOMMU_BYPASS);
	dprc->options |= (container_attr->options & DPRC_CFG_OPT_IOMMU_BYPASS) ?
			DPRC_CFG_OPT_IOMMU_BYPASS : 0;

	err = set_root_new_icid(dprc->resman, dprc, (int)container_attr->icid);
	if (err){
			pr_err("Can't set the requested icid to root container\n");
			return err;
	}

	return 0;

}

static int update_root_container(struct resman *resman,
	int portal_id,
	struct dprc_cfg *container_attr,
	uint64_t *portal_offset)
{
	struct dprc *dprc;
	struct resman_res_req req;
	struct resman_list_item_range *tmp;
	int err;
	struct resman_list_pool *portal_pool;

	dprc = get_container_by_key(resman, RESMAN_KEY_TYPE_CONTAINER_ID,
					ROOT_CONTAINER_ID);
	ASSERT_COND(dprc);

	/* Set new container's attributes */
	err = check_set_root_new_attr(dprc, container_attr);
	if (err)
		return err;

	if ((portal_id != dprc->portal_id)
		&& (portal_id != DPRC_GET_PORTAL_ID_FROM_POOL)) {
		/* Set the new portal for the first container */
		memset(&req, 0, sizeof(struct resman_res_req));
		req.num = 1;
		strcpy(req.type, "mcp");
		req.id_base_align = portal_id;
		req.options = DPRC_RES_REQ_OPT_EXPLICIT;

		if (assign_pres(dprc, dprc, &req, 1, 1) != 0) {
			pr_err("portal is not available\n");
			return ENAVAIL;
		}

		portal_pool = find_res_pool(dprc, "mcp");
		ASSERT_COND(portal_pool);
		dprc->portal_id =
			(uint16_t)portal_pool->range_item->range.min_id;

		/* Remove portal ID from container's free portals pool*/
		tmp = portal_pool->range_item;
		portal_pool->range_item = NULL;
		slab_release(resman->range_item_slab, (uint64_t)tmp);

	}
	if (portal_offset != NULL)
		*portal_offset = (get_portal_offset(dprc->portal_id));

	return 0;
}

static int allocate_free_container_id(struct resman *resman,
	int *container_id)
{
	int err;

	/* Find container ID for the new container */
	if (*container_id == RESMAN_NO_CONTAINER_ID) {
		err = get_container_id(resman, container_id);
		return err;
	}

	if (*container_id >= 0) {
		if (get_explicit_container_id(resman, *container_id) != 0) {
			pr_err("Container ID not available\n");
			return -ENAVAIL;
		}
		return 0;
	} else if (*container_id == UNASSINGED_PORTAL_CONTAINER_ID)
		return 0;
	else {
		pr_err("Invalid Container ID\n");
		return -EINVAL;
	}
}

static int set_portal_for_container(struct dprc *container,
	struct dprc *parent,
	int portal_id,
	uint64_t *portal_offset,
	int layout,
	struct resman_list_item_container *tmp_container_item,
	int ancestor_search)
{
	struct resman_res_req req;
	struct resman_list_item_range *tmp;
	struct resman_list_pool *res_pool;

	if (portal_offset != NULL) {
		memset(&req, 0, sizeof(struct resman_res_req));
		req.num = 1;
		strcpy(req.type, "mcp");

		if (portal_id != DPRC_GET_PORTAL_ID_FROM_POOL) {
			req.id_base_align = portal_id;
			req.options = DPRC_RES_REQ_OPT_EXPLICIT;
		} else {
			req.id_base_align = 0;
			req.options = 0;
		}

		if (assign_pres(parent, container, &req, layout,
		                ancestor_search) != 0) {
			/* Free Container id */
			free_container_id(container->resman, container->container_id);
			/* Remove containers from icids owners */
			remove_container_from_icid(container, container->icid);
			/* Return container's portal id to list */
			spin_lock(parent->lock_children_list);
			tmp_container_item = parent->children;
			parent->children = tmp_container_item->next;

			spin_unlock(parent->lock_children_list);
			free_container(container);

			slab_release(container->resman->container_item_slab, (uint64_t)tmp_container_item);
			pr_err("portal id not available\n");
			return -ENAVAIL;
		}

		res_pool  = find_res_pool(container, "mcp");
		ASSERT_COND(res_pool);
		ASSERT_COND(res_pool->range_item);
		container->portal_id = res_pool->range_item->range.min_id;

		if (portal_offset != NULL)
			*portal_offset =
				(get_portal_offset(container->portal_id));

		tmp = res_pool->range_item;
		res_pool->range_item = NULL;
		slab_release(container->resman->range_item_slab, (uint64_t)tmp);
	}

	return 0;
}

static struct dprc *allocate_container(struct resman *resman,
	struct dprc *parent,
	struct dprc_cfg *container_attr,
	int container_id,
	int portal_id)
{
	struct dprc *container = NULL;
	int i, err;
	uint64_t tmp_addr;

	/* Create new container and initialize it */
	err = slab_acquire(resman->dprc_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	container = (struct dprc *)UINT_TO_PTR(tmp_addr);
	memset(container, 0, sizeof(struct dprc));

	container->resman = resman;
	container->container_id = container_id;
	container->portal_id = DPRC_GET_PORTAL_ID_FROM_POOL;
	container->parent = parent;
	/*set all container by default unlocked*/
	container->locked = RESMAN_DPRC_STATE_UNLOCKED;
	container->options |=
		(container_attr->options & DPRC_CFG_OPT_OBJ_CREATE_ALLOWED);
	container->options |=
		(container_attr->options
			& DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED);
	container->options |=
		(container_attr->options & DPRC_CFG_OPT_AIOP);
	container->options |=
		(container_attr->options & DPRC_CFG_OPT_ALLOC_ALLOWED);
	container->options |=
		(container_attr->options & DPRC_CFG_OPT_SPAWN_ALLOWED);
	container->options |=
		(container_attr->options & DPRC_CFG_OPT_IRQ_CFG_ALLOWED);
	container->options |=
			(container_attr->options & DPRC_CFG_OPT_PL_ALLOWED);
	/* set iommu_bypass flag for AIOP container */
	if (container->options & DPRC_CFG_OPT_AIOP)
		container->options |= DPRC_CFG_OPT_IOMMU_BYPASS;

	strncpy(container->label, container_attr->label, sizeof(container_attr->label)-1);

	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		container->dev_alloc_policy[i].allocated = 0;
		container->dev_alloc_policy[i].quota = -1;
	}

	for (i = 0; i < HASH_SIZE; i++) {
		container->lock_res_alloc_policy[i] = spin_lock_create();
		if (!container->lock_res_alloc_policy[i]) {
			pr_err("container creation failed: no memory for spinlock\n");
			slab_release(resman->dprc_slab, (uint64_t)container);
			return NULL;
		}
	}

	container->lock_open_containers_list = spin_lock_create();
	if (!container->lock_open_containers_list) {
		pr_err("container creation failed: no memory for spinlock\n");
		slab_release(resman->dprc_slab, (uint64_t)container);
		return NULL;
	}

	container->lock_children_list = spin_lock_create();
	if (!container->lock_children_list) {
		pr_err("container creation failed: no memory for spinlock\n");
		slab_release(resman->dprc_slab, (uint64_t)container);
		return NULL;
	}

	container->lock_in_use_portal_list = spin_lock_create();
	if (!container->lock_in_use_portal_list) {
		pr_err("container creation failed: no memory for spinlock\n");
		slab_release(resman->dprc_slab, (uint64_t)container);
		return NULL;
	}

	for (i = 0; i < HASH_SIZE; i++) {
		container->lock_free_res_pools[i] = spin_lock_create();
		if (!container->lock_free_res_pools[i]) {
			pr_err("container creation failed: no memory for spinlock\n");
			slab_release(resman->dprc_slab, (uint64_t)container);
			return NULL;
		}
	}
	return container;
}

static int is_plcy_exceed_parent_plcy(
		struct dprc *parent, struct dprc_cfg *container_attr)
{
	if ((container_attr->options & DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED)
			&& ((parent->options & DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED) == 0)) {
		pr_err("parent container is not privileged to create "
		"container with topology change policy allowed\n");
		return 1;
	}

	if ((container_attr->options & DPRC_CFG_OPT_OBJ_CREATE_ALLOWED)
			&& ((parent->options & DPRC_CFG_OPT_OBJ_CREATE_ALLOWED) == 0)) {
		pr_err("parent container is not privileged to create "
		"container with object creation policy allowed\n");
		return 1;
	}
	if ((container_attr->options & DPRC_CFG_OPT_IRQ_CFG_ALLOWED)
			&& ((parent->options & DPRC_CFG_OPT_IRQ_CFG_ALLOWED) == 0)) {
			pr_err("parent container is not privileged to create "
			"container with irq cfg policy allowed\n");
			return 1;
	}

	if ((container_attr->options & DPRC_CFG_OPT_ALLOC_ALLOWED)
			&& ((parent->options & DPRC_CFG_OPT_ALLOC_ALLOWED) == 0)) {
		pr_err("parent container is not privileged to create "
		"container with allocation policy allowed\n");
		return 1;
	}

	return 0;
}

static int create_container(struct resman *resman,
	struct dprc *parent,
	struct dprc_cfg *container_attr,
	int *container_id,
	uint64_t *child_portal_offset,
	int layout,
	int ancestor_search)
{
	struct dprc *container = NULL;
	struct resman_list_item_container *tmp_container_item, *new_container_item;
	uint64_t tmp_addr;
	int err;

	if((!layout) && (parent)){
	/* Check if spawn allowed for parent container*/
			if((parent->options & DPRC_CFG_OPT_SPAWN_ALLOWED) == 0) {
					pr_err("dprc@%d is not allowed to spawn child containers"
							" due to spawn policy\n", parent->container_id);
						return 1;
		}
	}
	else {
		/* Check if root container needs to be updated */
		if  ((*container_id == ROOT_CONTAINER_ID)
		&& (parent == resman->global_container)) {
			return update_root_container(resman, container_attr->portal_id,
						container_attr, child_portal_offset);
		}

	}
	/*for new create command, all containers will be allowed to create objects
	 * Setting locked, will take this feature
	 */
	if(layout)
		container_attr->options |= DPRC_CFG_OPT_OBJ_CREATE_ALLOWED;

	err = allocate_free_container_id(resman, container_id);
	if (err)
		return err;

	/* Create new container and initialize it */
	container = allocate_container(resman, parent, container_attr,
					*container_id, container_attr->portal_id);
	if (container == NULL)
		return -ENOMEM;

	/* Add the new container to its parent children list */
	if (parent) {

		if(is_plcy_exceed_parent_plcy(parent, container_attr)){
			free_container_id(resman, container->container_id);

			free_container(container);

			return -EPERM;
		}

		err = slab_acquire(resman->container_item_slab, &tmp_addr);
		ASSERT_COND(err == 0);
		new_container_item = (struct resman_list_item_container *)UINT_TO_PTR(tmp_addr);
		container->container_item = new_container_item;
		spin_lock(parent->lock_children_list);
		new_container_item->next = parent->children;
		new_container_item->index = -1;
		new_container_item->container = container;
		parent->children = new_container_item;
		spin_unlock(parent->lock_children_list);
		if ((*container_id == GLOBAL_CONTAINER_ID)
			|| (*container_id == UNASSINGED_PORTAL_CONTAINER_ID))
			container->icid = NULL;
		else {
			if (set_icid(resman, container, (int)container_attr->icid) != 0) {
				/* Free Container id */
				free_container_id(container->resman, container->container_id);
				/* Return container's portal id to list */
				spin_lock(parent->lock_children_list);
				tmp_container_item = parent->children;
				parent->children = tmp_container_item->next;

				spin_unlock(parent->lock_children_list);
				free_container(container);

				slab_release(container->resman->container_item_slab, (uint64_t)tmp_container_item);
				pr_err("ICID not available\n");
				return -ENAVAIL;
			}
		}

		return set_portal_for_container(container, parent, container_attr->portal_id,
		                                child_portal_offset, layout,
		                                new_container_item,
		                                ancestor_search);


	} else
		resman->global_container = container;

	return 0;
}

static int bind_res_to_dev(struct resman *resman,
	struct resman_device *dev,
	struct resman_list_item_range *res_list,
	struct resman_res_req *res_req,
	char *pool_type)
{
	struct resman_list_pres **bound_res_list, *new_pres_item;
	struct resman_list_item_range *cur_range_item;
	int min_id, max_id, err;
	uint64_t tmp_addr;

	/* move resources to device */
	bound_res_list = &(dev->bound_res);
	cur_range_item = res_list;
	while (cur_range_item) {
		min_id = cur_range_item->range.min_id;
		max_id = cur_range_item->range.max_id;

		err = slab_acquire(resman->pres_slab, &tmp_addr);
		ASSERT_COND(err == 0);
		new_pres_item = (struct resman_list_pres *)UINT_TO_PTR(tmp_addr);
		memset(new_pres_item, 0, sizeof(struct resman_list_pres));

		new_pres_item->range.min_id = min_id;
		new_pres_item->range.max_id = max_id;
		new_pres_item->range.valid = 1;
		//strcpy(new_pres_item->type, res_req->type);
		new_pres_item->pool_type = pool_type;
		new_pres_item->orig_container =
			((struct dprc *)(cur_range_item->private));

		new_pres_item->next = (*bound_res_list);
		(*bound_res_list) = new_pres_item;

		cur_range_item = cur_range_item->next;
	}
	return 0;
}

static int set_res_quota(struct dprc *dprc,
	struct dprc *child_container,
	char *type,
	int quota)
{
	struct resman_alloc_policy *res_policy = NULL, *child_res_policy = NULL;
	struct resman_list_res_policy **res_policy_list;
	struct resman_list_res_policy *new_res_policy;
	int index, err;
	uint64_t tmp_addr;

	/* Check the validity of quota according to parent's policy */
	find_res_policy(dprc, type, &res_policy);
	if ((res_policy == NULL) || (res_policy->quota == -1)) {
		if ((dprc->options & DPRC_CFG_OPT_ALLOC_ALLOWED) == 0)
			if ((quota != -1) && (quota != 0)) {
				pr_err("child container resource quota can't "
				"exceed parent quota\n");
				return -EINVAL;
			}
	} else {
		if (res_policy->quota < quota) {
			pr_err("child container resource quota can't "
			"exceed parent quota\n");
			return -EINVAL;
		}
	}

	find_res_policy(child_container, type, &child_res_policy);
	if (child_res_policy == NULL) {
		index = hash(type);
		spin_lock(child_container->lock_res_alloc_policy[index]);
		res_policy_list = &(child_container->res_alloc_policy[index]);

		err = slab_acquire(dprc->resman->res_policy_slab, &tmp_addr);
		ASSERT_COND(err == 0);
		new_res_policy = (struct resman_list_res_policy *)UINT_TO_PTR(tmp_addr);
		memset(new_res_policy, 0, sizeof(struct resman_list_res_policy));

		new_res_policy->res_alloc_policy.allocated = 0;
		strncpy(new_res_policy->pool_type, type,
		        STR_MAX_SIZE - 1);
		new_res_policy->next_policy = *res_policy_list;
		*res_policy_list = new_res_policy;
		spin_unlock(child_container->lock_res_alloc_policy[index]);
		child_res_policy = &(new_res_policy->res_alloc_policy);
	}

	child_res_policy->quota = quota;

	return 0;
}

static int set_dev_quota(struct dprc *dprc,
	struct dprc *child_container,
	char *type,
	int quota)
{
	int dev_type_index;

	dev_type_index = get_dev_index(type);
	CHECK_COND_RETVAL(dev_type_index >= 0, -EEXIST);

	if ((child_container->options & DPRC_CFG_OPT_OBJ_CREATE_ALLOWED) == 0)
	{
		pr_err("operation is forbidden due child container object creation policy \n");
		return -EPERM;
	}

	if ((dprc->dev_alloc_policy[dev_type_index].quota != -1) && (dprc->dev_alloc_policy[dev_type_index].quota < quota)) {
			pr_err("child container resource quota can't exceed parent quota\n");
			return -EINVAL;
	}

	if (child_container->dev_alloc_policy[dev_type_index].allocated > quota) {
			pr_err("child container object quota can't be larger than the number of already created objects\n");
			return -EINVAL;
	}

	child_container->dev_alloc_policy[dev_type_index].quota = quota;

	return 0;
}

static int reset_container(struct dprc *reset_dprc,
		struct dprc *dprc,
		int portal_id,
		int recursive)
{
	struct resman_device *device;
	struct resman_list_item_device *cur_device_item;
	struct resman_list_in_use_portal *in_use_portal;
	struct resman_list_open *open_obj;
	void *dev_handle;
	int i,j;
	int ret;
	int reset_tries = 0;

	spin_lock(dprc->lock_in_use_portal_list);
	in_use_portal = dprc->in_use_portals;
	/* iterate all open objects from all portals and close them*/
	while (in_use_portal) {
		/* In this stage the open object are only containers,
		 * the devices are already closed */
		open_obj = in_use_portal->open_list;
		while (open_obj) {
			if (open_obj->dev_type == 1) {
				dev_handle = (void*)((int)open_obj->open_dev
							| open_obj->owner_id);
				cmdif_close_dev(dev_handle,
						in_use_portal->portal_id);
				close_device(dprc->resman, dev_handle,
						in_use_portal->portal_id);
			} else {
				if (!((open_obj->open_dev == dprc) && (in_use_portal->portal_id == portal_id)) &&
						recursive){
					close_dprc(dprc->resman,
							(struct dprc*)open_obj->open_dev,
							in_use_portal->portal_id);
					cmdif_close_dev(open_obj->open_dev,
							in_use_portal->portal_id);
				}
			}
			open_obj = open_obj->next;
		}
		in_use_portal = in_use_portal->next;
	}
	spin_unlock(dprc->lock_in_use_portal_list);

	/* Reset all devices inside the container */
	do {
		pr_info("Reset[%d] devices from dprc:%d\n",
				reset_tries, dprc->container_id);
		ret = 0;
		for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
			spin_lock(dprc->resman->lock_dprc_devices[i]);
			cur_device_item = dprc->devices[i];
			while (cur_device_item) {
				device = cur_device_item->device;
				if (dprc->resman->dev_type_params[i]->f_reset)
					ret |= dprc->resman->dev_type_params[i]->f_reset(
							(void *)(device));

				cur_device_item = cur_device_item->next;
			}
			spin_unlock(dprc->resman->lock_dprc_devices[i]);
		}
		pr_info("Finish reset[%d] devices from dprc:%d\n",
				reset_tries, dprc->container_id);
	} while (ret != 0 && (reset_tries++ < RESMAN_DPRC_RESET_RETRIES));

	if (ret) {
		pr_err("Failed to reset devices from dprc:%d\n", dprc->container_id);
		return ret;
	}

	/* Close all opened devices inside the container*/
	
	pr_info("Close opened devices from dprc:%d\n", dprc->container_id);
	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		spin_lock(dprc->resman->lock_dprc_devices[i]);
		cur_device_item = dprc->devices[i];
		while (cur_device_item) {
			for (j = 0; j < DP_DEV_MAX_OWNERS; j++) {
				ret = 0;
				if (cur_device_item->device->owners[j].dprc){
					ret = cmdif_close_dev(GET_DEV_HANDLE(cur_device_item->device, j),
							cur_device_item->device->owners[i].portal_id);
					ret |= close_device(dprc->resman, GET_DEV_HANDLE(cur_device_item->device, j),
							cur_device_item->device->owners[i].portal_id);
					if (!ret)
						pr_info("The %s[%d] device has been closed from dprc:%d\n",
								cur_device_item->device->dev.type,
								cur_device_item->device->dev.id,
								dprc->container_id);
					else
						pr_err("Failed to close the %s[%d] device from dprc:%d\n",
								cur_device_item->device->dev.type,
								cur_device_item->device->dev.id,
								dprc->container_id);
				}
			}
			cur_device_item = cur_device_item->next;
		}
		spin_unlock(dprc->resman->lock_dprc_devices[i]);
		if (ret) {
			pr_err("Failed to close opened devices from dprc:%d\n",
					dprc->container_id);
			return ret;
		}
	}
	pr_info("Finish to close opened devices from dprc:%d\n",
			 dprc->container_id);

	return 0;
}

static int update_bound_res_counter(struct resman *resman,
	char *pool_name,
	int num,
	int add)
{
	int index;
	struct resman_list_pool *cur_pool;

	index = hash(pool_name);

	spin_lock(resman->lock_pres_pool[index]);
	cur_pool = resman->pres_pools[index];

	while (cur_pool) {
		if (strcmp(cur_pool->pool_type, pool_name) == 0) {
			if (add)
				cur_pool->bound_counter += num;

			else
				cur_pool->bound_counter -= num;

			spin_unlock(resman->lock_pres_pool[index]);
			return 0;
		}
		cur_pool = cur_pool->next_pool;
	}

	spin_unlock(resman->lock_pres_pool[index]);
	return -EEXIST;
}

static int get_dev_region(struct resman *resman,
	struct resman_device *device,
	struct dprc_region_desc *region_desc,
	int index,
	int modify_region_size)
{
	int dev_type_index, res_id, err;
	struct resman_list_pres *pres_item;
	enum resman_region_type region_type;
	struct qbman_swportal_desc swp_desc;
	struct qbman_desc qbman_desc;

	dev_type_index = get_dev_index(device->dev.type);
	CHECK_COND_RETVAL(dev_type_index >= 0, -EEXIST);

	region_type =
		resman->dev_type_params[dev_type_index]->region_types[index];

	switch (region_type) {
	case DPRC_REGION_TYPE_QMAN_CE:
		pres_item = device->bound_res;
		while (pres_item) {
			if (strcmp(pres_item->pool_type, "swp") == 0) {
				res_id = pres_item->range.min_id;

				memset(&swp_desc, 0, sizeof(swp_desc));
				swp_desc.swportal_id = res_id;
				err = sys_get_desc(
					SOC_MODULE_QBMAN_PORTAL,
					SOC_DB_QBMAN_PORTAL_DESC_ID, &swp_desc,
					NULL);
				ASSERT_COND(err == 0);

				memset(&qbman_desc, 0, sizeof(struct qbman_desc));
				err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
							&qbman_desc, NULL);
				ASSERT_COND(err == 0);

				region_desc->base_offset = (uint32_t)(swp_desc.paddr_cena -
					qbman_desc.portals_paddr);
				/* each sw portal occupy 64KB in hardware, for backward compatibility
				 * the registers are located up to 0x1000 offset */
				if (modify_region_size == 1)
					region_desc->size = DPRC_64KB_SW_PORTAL_REGION_SIZE;
				else
					region_desc->size = DPRC_4KB_SW_PORTAL_REGION_SIZE;
				region_desc->type = DPRC_REGION_TYPE_QBMAN_PORTAL;
				region_desc->flags = DPRC_REGION_FLAG_CACHEABLE;
				region_desc->base_address = qbman_desc.portals_paddr;
				return 0;
			}
			pres_item = pres_item->next;
		}
		pr_err("swp resource is not bound to this object\n");
		return EEXIST;
	case DPRC_REGION_TYPE_QMAN_CI:
		pres_item = device->bound_res;
		while (pres_item) {
			if (strcmp(pres_item->pool_type, "swp") == 0) {
				res_id = pres_item->range.min_id;

				memset(&swp_desc, 0, sizeof(swp_desc));
				swp_desc.swportal_id = res_id;
				err = sys_get_desc(
					SOC_MODULE_QBMAN_PORTAL,
					SOC_DB_QBMAN_PORTAL_DESC_ID, &swp_desc,
					NULL);
				ASSERT_COND(err == 0);

				memset(&qbman_desc, 0, sizeof(struct qbman_desc));
				err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
							&qbman_desc, NULL);
				ASSERT_COND(err == 0);

				region_desc->base_offset = (uint32_t)swp_desc.paddr_cinh -
					(uint32_t)qbman_desc.portals_paddr;
				/* each sw portal occupy 64KB in hardware, for backward compatibility
				 * the registers are located up to 0x1000 offset */
				if (modify_region_size == 1)
					region_desc->size = DPRC_64KB_SW_PORTAL_REGION_SIZE;
				else
					region_desc->size = DPRC_4KB_SW_PORTAL_REGION_SIZE;
				region_desc->type = DPRC_REGION_TYPE_QBMAN_PORTAL;
				region_desc->flags = 0;
				region_desc->base_address = qbman_desc.portals_paddr;
				return 0;
			}
			pres_item = pres_item->next;
		}
		pr_err("swp resource is not bound to this object\n");
		return EEXIST;
	case DPRC_REGION_TYPE_MCP:
		region_desc->base_offset = (uint32_t)get_portal_offset(device->dev.id);
		if (modify_region_size == 1)
			region_desc->size = DPRC_64KB_MC_PORTAL_REGION_SIZE;
		else
			region_desc->size = DPRC_64B_MC_PORTAL_REGION_SIZE;
		region_desc->type = DPRC_REGION_TYPE_MC_PORTAL;
		region_desc->flags = 0;
		region_desc->base_address = get_portal_base(device->dev.id);
		break;
	case DPRC_REGION_TYPE_QMAN_MB:
		pres_item = device->bound_res;
		while (pres_item) {
			if (strcmp(pres_item->pool_type, "swp") == 0) {
				res_id = pres_item->range.min_id;
				region_desc->base_offset = (uint32_t) res_id * 0x10000;
				region_desc->size = 0x10000;
				region_desc->type = DPRC_REGION_TYPE_QBMAN_PORTAL;
				region_desc->flags = DPRC_REGION_FLAG_CACHEABLE | DPRC_REGION_FLAG_SHAREABLE;
				region_desc->base_address = qbman_block_get_cp_mem_paddr();
				return 0;
			}
			pres_item = pres_item->next;
		}
		pr_err("swp resource is not bound to this object\n");
		return EEXIST;

	default:
		pr_err("Wrong index - No region type\n");
		return -EINVAL;
	}
	return 0;
}

/*************************API Routine - DPRC***********************************/
#include "fsl_sys.h"
int resman_create_container(struct dprc *dprc,
	struct dprc_cfg *cfg,
	int *child_container_id,
	uint64_t *child_portal_offset,
	int layout)
{
	struct resman *resman;
	int err, ancestor_search;

	if (dprc && (dprc->container_id == GLOBAL_CONTAINER_ID)) {
		pr_err("Operation not allowed\n");
		return -EPERM;
	}

	if (cfg->icid > MAX_ICID) {
		pr_err("failed to create container, icid must be smaller than %#x\n", MAX_ICID);
		return -EINVAL;
	}

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	ASSERT_COND(resman);

	if (dprc == NULL)
		dprc = resman->global_container;
	ancestor_search = (layout ? 1 : ((dprc->options & DPRC_CFG_OPT_ALLOC_ALLOWED) ? 1 : 0));
	err = create_container(resman, dprc, cfg, child_container_id,
				child_portal_offset, layout,
				ancestor_search);
	if (err)
		return err;

	if (cfg->portal_id == DPRC_GET_PORTAL_ID_FROM_POOL)
		cfg->portal_id = get_portal_id(*child_portal_offset);

	if (dprc && (dprc->resman->options & RESMAN_INIT_DONE))
		invoke_inter(dprc, DPRC_IRQ_EVENT_OBJ_ADDED);

	return 0;

}

int resman_destroy_container(struct dprc *dprc, int child_container_id)
{
	struct dprc *child_container;
	int err;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed\n");
		return -EPERM;
	}

	child_container = get_container_by_key(dprc->resman,
						RESMAN_KEY_TYPE_CONTAINER_ID,
						child_container_id);
	if (!child_container)
		return -EIO;

	/* Only parent can destroy its child - container 0 can't be destroyed */
	if (child_container->parent != dprc)
		return -EPERM;

	err = destroy_container_dynasty(dprc->resman, child_container);
	CHECK_COND_RETVAL(err==0, err);

	invoke_inter(dprc, DPRC_IRQ_EVENT_CONTAINER_DESTROYED);
	return 0;
}

int resman_set_quota(struct dprc *dprc,
	int child_container_id,
	char *type,
	uint16_t quota)
{
	struct dprc *child_container;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed\n");
		return -EPERM;
	}

	child_container = get_container_by_key(dprc->resman,
						RESMAN_KEY_TYPE_CONTAINER_ID,
						child_container_id);

	if (child_container == NULL)
		return -EINVAL;

	if (child_container->parent != dprc) {
		pr_err("Container policies can be set by parent only\n");
		return -EPERM;
	}

	if (is_dev(type))
		return set_dev_quota(dprc, child_container, type, quota);
	return set_res_quota(dprc, child_container, type, quota);
}

int resman_get_quota(struct dprc *dprc,
	int child_container_id,
	char *type,
	uint16_t *quota)
{
	struct dprc *child_container;
	struct resman_alloc_policy *res_policy = NULL;
	int dev_type_index;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed\n");
		return -EPERM;
	}

	child_container = get_container_by_key(dprc->resman,
						RESMAN_KEY_TYPE_CONTAINER_ID,
						child_container_id);

	if (child_container == NULL)
		return -EPERM;

	if ((child_container->parent != dprc)
		&& (dprc->container_id != child_container_id)) {
		pr_err("Container policies can be set by parent only\n");
		return -EPERM;
	}

	if (is_dev(type)) {
		dev_type_index = get_dev_index(type);
		CHECK_COND_RETVAL( dev_type_index >= 0, -EINVAL, "Device index not found: %s\n", type);
		*quota = (uint16_t)child_container->dev_alloc_policy[dev_type_index].quota;
		return 0;
	}
	find_res_policy(child_container, type, &res_policy);
	if ((res_policy == NULL) || (res_policy->quota == -1)) {
		if (child_container->options & DPRC_CFG_OPT_ALLOC_ALLOWED)
			*quota = (uint16_t)-1;
		else if ((child_container->options & DPRC_CFG_OPT_ALLOC_ALLOWED) == 0)
			*quota = 0;
		else
			return -EPERM;
	} else
		*quota = (uint16_t)res_policy->quota;

	return 0;
}

int resman_set_locked(struct dprc *dprc, int child_container_id, uint8_t locked, int portal_id)
{
	struct dprc *child_container;
	struct dprc *container;
	uint8_t hierarchy_down = 1;
	uint8_t hierarchy_continue = 1;

	if ((dprc->container_id == GLOBAL_CONTAINER_ID) || (child_container_id == GLOBAL_CONTAINER_ID)) {
		pr_err("Operation not allowed, global and root container cannot be locked\n");
		return -EPERM;
	}

	if (dprc->container_id == child_container_id){
		pr_err("Operation locked/unlocked cannot be made itself\n");
		return -EPERM;
	}

	if (dprc->portal_id != portal_id){
		pr_err("Operation locked/unlocked can be made only through parent's portal\n");
		return -EPERM;
	}

	child_container = get_container_by_key(dprc->resman,
							RESMAN_KEY_TYPE_CONTAINER_ID,
							child_container_id);

	if (child_container == NULL){
		pr_err("Container_id = %d is not available \n", child_container_id);
		return -EPERM;
	}
	if ((child_container->parent != dprc)
		&& (dprc->container_id != child_container_id)) {
		pr_err("Operation locked/unlocked can be made only by parent\n");
		return -EPERM;
	}

	container = child_container;

	if(container->locked != locked)
		container->locked = locked;

	if(container->children != NULL){
		while(container != NULL && hierarchy_continue )
		{
			if (container->children != NULL && hierarchy_down){
				container = container->children->container;
				hierarchy_down = 1;
			} else if((container->container_item) && (container->container_item->next != NULL)){
				container = container->container_item->next->container;
				hierarchy_down = 1;
			} else {
				container = container->parent;
				hierarchy_down = 0;
			}
			if(container == child_container)
				hierarchy_continue = 0;

			if(container->locked != locked)
				container->locked = locked;
		}
	}
	return 0;
}

int resman_reset_container(struct dprc *dprc, int child_container_id, int portal_id, uint32_t options)
{
	int process_child, process_sibling, process_recursive, index = 0;
	struct dprc *child_container, *container_to_lock;;
	struct resman_list_item_container *container_item;
	struct resman_stack_item_container *container_stack_item,
		*tmp_container_stack_item;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed\n");
		return -EPERM;
	}

	/* Get the child container to reset */
	child_container = get_container_by_key(dprc->resman,
						RESMAN_KEY_TYPE_CONTAINER_ID,
						child_container_id);
	if (child_container == NULL){
		pr_err("child container is not exist\n");
		return -EIO;
	}
	/* Check if dprc is the child container or its parent*/
	if ((child_container->parent != dprc) && (child_container != dprc)) {
		pr_err("container can be reset by itself or by its parent\n");
		return -EPERM;
	}

	container_item = child_container->container_item;

	process_child = process_sibling = process_recursive =
			(options & DPRC_OPTION_RESET_NON_RECURSIVE) ? 0 : 1;

	while (container_item != NULL) {
		container_to_lock = container_item->container;
		spin_lock(container_to_lock->lock_children_list);
		if ((container_item->container->children)
			&& (process_child == 1)) {

			if (index == MAX_NUM_OF_CONTAINERS_IN_STACK) {
				pr_err("exceed the maximum container stack size for reset command\n");
				ASSERT_COND(0);
			}
			container_stack_item = &(dprc->resman->container_stack[core_get_id()][index++]);
			container_stack_item->container_item = container_item;
			container_stack_item->options &= (~DPRC_STACK_PROCESS_CHILD);
			container_stack_item->options |= DPRC_STACK_PROCESS_SIBLING;
			container_item =
				container_item->container->children;
			process_child = 1;
			process_sibling = 1;
		} else if ((child_container_id
				!= container_item->container->container_id)
				&& (container_item->next != NULL)
				&& (process_sibling == 1)) {

			if (index == MAX_NUM_OF_CONTAINERS_IN_STACK) {
				pr_err("exceed the maximum container stack size for reset command\n");
				ASSERT_COND(0);
			}
			container_stack_item = &(dprc->resman->container_stack[core_get_id()][index++]);
			container_stack_item->container_item = container_item;
			container_stack_item->options = 0;
			container_item = container_item->next;
			process_child = 1;
			process_sibling = 1;
		} else {
			reset_container(child_container,
					container_item->container, portal_id, process_recursive);
			if (index == 0) {
				spin_unlock(container_to_lock->lock_children_list);
				return 0;
			}
			tmp_container_stack_item = &(dprc->resman->container_stack[core_get_id()][--index]);

			process_child =
				(tmp_container_stack_item->options & DPRC_STACK_PROCESS_CHILD) ? 1 : 0;
			process_sibling =
				(tmp_container_stack_item->options & DPRC_STACK_PROCESS_SIBLING) ? 1 : 0;
			container_item =
				tmp_container_stack_item->container_item;
			tmp_container_stack_item->container_item = NULL;
			tmp_container_stack_item->options = 0;
		}
		spin_unlock(container_to_lock->lock_children_list);
	}
	return 0;
}

int resman_assign(struct dprc *dprc,
	int container_id,
	struct resman_res_req *res_req,
	int layout)
{
	int plugged;
	int err;
	struct dprc *child_container;
	struct resman_list_pool *res_pool;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed\n");
		return -EPERM;
	}
	/* Get the container to assign resources */
	child_container = get_container_by_key(dprc->resman,
						RESMAN_KEY_TYPE_CONTAINER_ID,
						container_id);
	if (child_container == NULL) {
		pr_err("container ID dosen't exist\n");
		return -EEXIST;
	}

	/* Check if dprc is the parent of child container */
	if ((child_container->parent != dprc) && (child_container != dprc))
		return -EPERM;

	if (is_dev(res_req->type)) {
		if (res_req->num > 1) {
			pr_err("Number of objects to assign should be 1\n");
			return -EIO;
		}
		plugged =
			(res_req->options & DPRC_RES_REQ_OPT_PLUGGED) ? 1 : 0;

		if (res_req->options & DPRC_RES_REQ_OPT_EXPLICIT) {
			err = assign_explicit_device(
				dprc, child_container, res_req->type,
				(uint16_t)res_req->id_base_align, plugged);
		}
		else {
			err =  assign_device(dprc, child_container,
			                     res_req->type, plugged);
		}

		if(!err){
				invoke_inter(child_container,
				             DPRC_IRQ_EVENT_OBJ_ADDED);
				invoke_inter(dprc, DPRC_IRQ_EVENT_OBJ_REMOVED);
		}
		return err;
	} else {
		/* Check if the requested resource pool exists */
		res_pool = find_res_pool(dprc->resman->global_container,
						res_req->type);
		if (res_pool == NULL) {
			pr_err("Requested resources pool is not exist\n");
			return -EEXIST;
		}
		err = assign_pres(dprc, child_container, res_req, layout, 0);
		return err;
	}
}

int resman_unassign(struct dprc *dprc,
	int child_container_id,
	struct resman_res_req *res_req)
{
	struct resman_list_pool *res_pool;
	struct dprc *child_container;
	int err, dev_type_index;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed\n");
		return -EPERM;
	}

	child_container = get_container_by_key(dprc->resman,
						RESMAN_KEY_TYPE_CONTAINER_ID,
						child_container_id);
	if (child_container == NULL)
		return -EINVAL;

	/* Check if dprc is the parent of child container */
	if (child_container->parent != dprc)
		return -EPERM;

	if (is_dev(res_req->type)) {
		if (res_req->num > 1) {
			pr_err("The maximum number to un-assign is one device\n");
			return -EPERM;
		}
		dev_type_index = get_dev_index(res_req->type);
		CHECK_COND_RETVAL(dev_type_index >= 0, -EEXIST);
		if (res_req->options & DPRC_RES_REQ_OPT_EXPLICIT)
			err =  unassign_explicit_device(dprc, child_container,
					res_req->id_base_align, res_req->type);
		else
			err =  unassign_device(dprc, child_container,
			                       dev_type_index);

		if (!err) {
			invoke_inter(child_container,
			             DPRC_IRQ_EVENT_OBJ_REMOVED);
			invoke_inter(dprc, DPRC_IRQ_EVENT_OBJ_ADDED);
		}
		return err;

	} else {
		res_pool = find_res_pool(dprc->resman->global_container,
						res_req->type);
		if (res_pool == NULL) {
			pr_err("Requested resources pool is not exist\n");
			return -EEXIST;
		}
		if (res_req->options & DPRC_RES_REQ_OPT_EXPLICIT)
			err =  unassign_explicit_pres(dprc, child_container,
							res_req);
		else
			err = unassign_pres(dprc, child_container, res_req);

		if (!err) {
			invoke_inter(child_container, DPRC_IRQ_EVENT_RES_REMOVED);
			invoke_inter(dprc, DPRC_IRQ_EVENT_RES_ADDED);
		}
		return err;
	}
}

int resman_get_obj_count(struct dprc *dprc, int *dev_count)
{
	struct resman_list_item_device *cur_device_item;
	struct resman_list_item_container *cur_container_item;

	int i, cnt = 0;

	ASSERT_COND(dprc);

	/* count the number of devices from each device type */
	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		spin_lock(dprc->resman->lock_dprc_devices[i]);
		cur_device_item = dprc->devices[i];
		while (cur_device_item) {
			if (cur_device_item->device->dev.id >= 0) {
				cur_device_item->index = cnt;
				cnt++;
			}
			cur_device_item = cur_device_item->next;
		}
		spin_unlock(dprc->resman->lock_dprc_devices[i]);
	}
	/* count the number of children containers */
	spin_lock(dprc->lock_children_list);
	cur_container_item = dprc->children;
	while (cur_container_item) {
		if (cur_container_item->container->container_id >= 0) {
			cur_container_item->index = cnt;
			cnt++;
		}
		cur_container_item = cur_container_item->next;
	}
	spin_unlock(dprc->lock_children_list);
	*dev_count = cnt;
	return 0;
}

int resman_get_obj_desc(struct dprc *dprc,
        char *obj_type,
        int obj_id,
        struct dprc_obj_desc *obj_desc)
{
	int type_index;
	struct resman_list_item_container *cur_container_item;
	struct resman_list_item_device *cur_device_item;

	ASSERT_COND(obj_desc);

	if (is_dev(obj_type)){
		type_index = get_dev_index(obj_type);
		CHECK_COND_RETVAL(type_index >= 0, -EEXIST);
		spin_lock(dprc->resman->lock_dprc_devices[type_index]);
		cur_device_item = dprc->devices[type_index];
		while (cur_device_item) {
			if (cur_device_item->device->dev.id == obj_id) {
				set_dev_desc(dprc, cur_device_item, obj_desc, type_index);
				spin_unlock(dprc->resman->lock_dprc_devices[type_index]);
				return 0;
			}
			cur_device_item = cur_device_item->next;
		}
		spin_unlock(dprc->resman->lock_dprc_devices[type_index]);
	}
	else if (strcmp(obj_type, "dprc") == 0) {
		spin_lock(dprc->lock_children_list);
		cur_container_item = dprc->children;
		while (cur_container_item) {
			if (cur_container_item->container->container_id == obj_id) {
				set_dprc_desc(dprc, cur_container_item, obj_desc);
				spin_unlock(dprc->lock_children_list);
				return 0;
			}
			cur_container_item = cur_container_item->next;
		}
		spin_unlock(dprc->lock_children_list);
	}
	return -EEXIST;
}

#ifdef TKT011436 
static struct dprc *next_container(struct dprc *container)
{
	static int hierarchy_down = 1;
	struct dprc *dprc = NULL;
	struct dprc *dprc_tmp;

	if (container->children != NULL && hierarchy_down) {
		dprc = container->children->container;
		hierarchy_down = 1;
	} else if((container->container_item) && (container->container_item->next != NULL)) {
		dprc = container->container_item->next->container;
		hierarchy_down = 1;
	} else if((container->container_id != GLOBAL_CONTAINER_ID) && (container->parent->container_id != GLOBAL_CONTAINER_ID)) {
		dprc_tmp = container->parent;
		hierarchy_down = 0;
		dprc = next_container(dprc_tmp); /* recursive function */
	} else {
		dprc = NULL;
		hierarchy_down = 1;
	}

	/* Skip UNASSINGED_PORTAL_CONTAINER_ID */
	if(dprc && (dprc->container_id == UNASSINGED_PORTAL_CONTAINER_ID))
		dprc = next_container(dprc);

	return dprc;
}

static int resman_drain_all_type_objects(struct resman *resman, char *obj_type, uint32_t depleton_wait_us)
{
	int index;
	struct resman_list_item_device *cur_device_item;
	int iter = 0, ret = 0, tries = 5, timeout = 0, err = 0;
	struct dprc *dprc;
	struct dprc *root_container, *global_container;
	
	/* Get GLOBAL Container */
	global_container = resman->global_container;
	CHECK_COND_RETVAL(global_container, -EINVAL, "NULL Global Container\n");

	/* Get root container as a first child of Global Container */
	root_container = next_container(global_container);
	CHECK_COND_RETVAL(root_container, -EINVAL, "NULL Root Container\n");

	dprc = root_container;
	do {
		pr_info("Start the consumption of pending frames for all ports associated with a %s from DPRC[%d]\n",
				obj_type, dprc->container_id);
		/* f_graceful_stop callback will start the consumption of pending frames */
		for (index = 0; index < DP_NUM_OF_DEVICE_TYPES; index++) {
			spin_lock(dprc->resman->lock_dprc_devices[index]);
			cur_device_item = dprc->devices[index];
			while (cur_device_item) {
				if (!strcmp(cur_device_item->device->dev.type, obj_type)) {
					if (dprc->resman->dev_type_params[index]->f_graceful_stop)
						ret |= dprc->resman->dev_type_params[index]->f_graceful_stop((void *)(cur_device_item->device));
					spin_unlock(dprc->resman->lock_dprc_devices[index]);
				}
				cur_device_item = cur_device_item->next;
			}
			spin_unlock(dprc->resman->lock_dprc_devices[index]);
		}
		CHECK_COND_RETVAL(!ret, ret, "DPNI graceful stop failed");
		
		dprc = next_container(dprc);
	}while(dprc);

	do{
		/* start container iteration from root */
		dprc = root_container;
		/* wait for pending frames to be consumed by WRIOP */
		timer_udelay(depleton_wait_us);
		do {
			pr_info("Empty check stage for every %s from DPRC[%d]\n", 
					obj_type, dprc->container_id);
			/* Check all DPNIs to be depleted */
			for (index = 0; index < DP_NUM_OF_DEVICE_TYPES; index++) {
				spin_lock(dprc->resman->lock_dprc_devices[index]);
				cur_device_item = dprc->devices[index];
				while (cur_device_item) {
					if (!strcmp(cur_device_item->device->dev.type, obj_type)) {
						if (dprc->resman->dev_type_params[index]->f_empty_check)
							ret = dprc->resman->dev_type_params[index]->f_empty_check((void *)(cur_device_item->device));
						if(ret == -ETIMEDOUT)
							timeout = 1;
						if(ret)
							err = ret;
							//goto get_error;
						spin_unlock(dprc->resman->lock_dprc_devices[index]);
					}
					cur_device_item = cur_device_item->next;
				}
				spin_unlock(dprc->resman->lock_dprc_devices[index]);
			}
			/* get next container */
			dprc = next_container(dprc);
		}while(dprc);
		/* err -> possible we have to wait more
		 * tries -> avoid infinite loop
		 */
	}while(err && --tries);

	if (timeout)
		return -ETIMEDOUT;

	return err;
}

static int resman_restore_all_type_objects(struct resman *resman,
	char *obj_type)
{
	int index;
	struct resman_list_item_device *cur_device_item;
	int ret = 0, err = 0;
	struct dprc *dprc, *global_container;
	
	/* Get GLOBAL Container */
	global_container = resman->global_container;
	CHECK_COND_RETVAL(global_container, -EINVAL, "NULL Global Container\n");

	/* Get root container as a first child of Global Container */
	dprc = next_container(global_container);
	CHECK_COND_RETVAL(dprc, -EINVAL, "NULL Root Container\n");
	do{
		pr_info("Start the restore stage for every %s object from DPRC[%d]\n", obj_type, dprc->container_id);
		for (index = 0; index < DP_NUM_OF_DEVICE_TYPES; index++) {
			spin_lock(dprc->resman->lock_dprc_devices[index]);
			cur_device_item = dprc->devices[index];
			while (cur_device_item) {
				if (!strcmp(cur_device_item->device->dev.type, obj_type)) {
					if (dprc->resman->dev_type_params[index]->f_restore_after_eiop_reset)
						ret = dprc->resman->dev_type_params[index]->f_restore_after_eiop_reset((void *)(cur_device_item->device));
					if (ret)
						err = ret;
					spin_unlock(dprc->resman->lock_dprc_devices[index]);
				}
				cur_device_item = cur_device_item->next;
			}
			spin_unlock(dprc->resman->lock_dprc_devices[index]);
		}
		/* get next container */
		dprc = next_container(dprc);
	}while(dprc);

	return err;
}

static int resman_resume_from_errata_check(struct dprc *dprc,
	char *obj_type)
{
	int index;
	struct resman_list_item_device *cur_device_item;
	int ret = 0;

	pr_debug("Start the resume stage for every %s\n", obj_type);
	for (index = 0; index < DP_NUM_OF_DEVICE_TYPES; index++) {
		spin_lock(dprc->resman->lock_dprc_devices[index]);
		cur_device_item = dprc->devices[index];
		while (cur_device_item) {
			if (!strcmp(cur_device_item->device->dev.type, obj_type)) {
				if (dprc->resman->dev_type_params[index]->f_resume)
					ret = dprc->resman->dev_type_params[index]->f_resume((void *)(cur_device_item->device));
				spin_unlock(dprc->resman->lock_dprc_devices[index]);
			}
			cur_device_item = cur_device_item->next;
		}
		spin_unlock(dprc->resman->lock_dprc_devices[index]);
	}
	
	if(ret)
		return ret;
	return 0;
}

int resman_errata_workaround(int dpmac_id, uint32_t options)
{
	int err = 0, i, ret = 0, errata_occured = 0;
	struct dpmac *dpmac;
	struct resman *resman;
	
	if(options & RESMAN_ERRATA_CHECK_WORKAROUND) {
		pr_info("mEMAC[%d] Errata A-011436 occurrence check\n", dpmac_id);

		dpmac = (struct dpmac *)sys_get_handle(FSL_MOD_DPMAC, 1, dpmac_id);
		CHECK_COND_RETVAL(dpmac != NULL, -EINVAL, "DPMAC[%d] handle doesn't exist\n", dpmac_id);

		err = qbman_connection_phys_set_state(dpmac_get_id(dpmac), dpmac_get_eiop_id(dpmac), 0);
		CHECK_COND_RETVAL(!err, err, "Fail to disable subportal <-> LNI connection\n");
		
		if (dpmac_get_dpni(dpmac)){
			ret = dpni_errata_check(dpmac_get_dpni(dpmac), 
					1); /* time in us to drain */ 
			
			/* If ret == -ETIMEDOUT means that errata occurred or DPNI fails to be recovered 
			 * If ret == 0 means that dpni was checked and resumed 
			 * if(ret)  means that dpni's graceful stop failed or there are still frames on IFP ingress
			 */
			if (ret == -ETIMEDOUT)
				errata_occured = 1;
		}
		
		if(!errata_occured) {
			err = qbman_connection_phys_set_state(dpmac_get_id(dpmac), dpmac_get_eiop_id(dpmac), 1);
			CHECK_COND_RETVAL(!err, err, "Fail to disable subportal <-> LNI connection\n");
			pr_info("mEMAC[%d] Errata A-011436 verified - NOT occurred\n", dpmac_get_id(dpmac));
			return 0;
		}
	}

	pr_info("Start Workaround for mEMAC Errata A-011436\n");
	resman = sys_get_unique_handle(FSL_MOD_RESMAN);

	/* Disable TX for eache subportal asociated with physical/virtual port */
	/* remove CEETM channel from LNI */
	err = qbman_connections_all_phys_recycle_set_state( 0 );
	CHECK_COND_RETVAL(!err, err, "Fail to remove all CEETM channel from LNI\n");

/*	 Iterate every DPNI from all containers and make graceful stop 
	 Firstly start to drain all ports associated with DPNI 
	 Wait 1 us 
	 Check if all ports where drained */
	ret = resman_drain_all_type_objects(resman, "dpni", 1);

	if((ret == -ETIMEDOUT) && (options & RESMAN_ERRATA_CHECK_WORKAROUND))
		pr_warn("mErrata A-011436 also occured on DPAMC different of %d\n", dpmac_get_id(dpmac));			

	/* WRIOP reset */
	for(i = 0; i < 2; i++){
		err = eiop_reset();
		CHECK_COND_RETVAL(!err, err, "WRIOP reset failed\n");
	}
	
	pr_info("WRIOP + MAC reset finished\n");
	
	/* WRIOP hardware restore */
	err = eiop_drv_hardware_restore();
	CHECK_COND_RETVAL(!err, err, "WRIOP HW restore failed\n");
	
	/* Iterate every DPMAC and reconfigure as it was before reset */
	err = resman_restore_all_type_objects(resman, "dpmac");
	CHECK_COND_RETVAL(!err, err, "Restore object after WRIOP reset Failed\n");
	
	/* Iterate every DPNI and reconfigure as it was before reset */
	err = resman_restore_all_type_objects(resman, "dpni");
	CHECK_COND_RETVAL(!err, err, "Restore object after WRIOP reset Failed\n");

	/*Enable TX subportal to permit enque in QMAN */
	err = qbman_connections_all_phys_recycle_set_state( 1 );
	CHECK_COND_RETVAL(!err, err, "qbman_connections_all_phys_recycle_set_state\n");

	pr_info("Finish Workaround for mEMAC Errata A-011436\n");

	return ret;
}
#endif /* TKT011436 */

int resman_get_obj_desc_by_index(struct dprc *dprc,
	int obj_index,
	struct dprc_obj_desc *obj_desc)
{
	int index;
	struct resman_list_item_container *cur_container_item;
	struct resman_list_item_device *cur_device_item;

	ASSERT_COND(obj_desc);

	for (index = 0; index < DP_NUM_OF_DEVICE_TYPES; index++) {
		spin_lock(dprc->resman->lock_dprc_devices[index]);
		cur_device_item = dprc->devices[index];
		while (cur_device_item) {
			if (cur_device_item->index == obj_index) {
				set_dev_desc(dprc, cur_device_item, obj_desc,
						index);
				spin_unlock(dprc->resman->lock_dprc_devices[index]);
				return 0;
			}
			cur_device_item = cur_device_item->next;
		}
		spin_unlock(dprc->resman->lock_dprc_devices[index]);
	}

	/* count the number of children containers */
	spin_lock(dprc->lock_children_list);
	cur_container_item = dprc->children;
	while (cur_container_item) {
		if (cur_container_item->index == obj_index) {
			set_dprc_desc(dprc, cur_container_item, obj_desc);
			spin_unlock(dprc->lock_children_list);
			return 0;
		}
		cur_container_item = cur_container_item->next;
	}
	spin_unlock(dprc->lock_children_list);
	pr_err("Object index %d is not available\n", obj_index);
	return -ENAVAIL;
}

int resman_get_res_count(struct dprc *dprc, char *type, int *res_count)
{
	struct resman_list_item_range *cur_range_item;
	int cnt = 0, i;
	struct resman_list_pool *res_pool;
	struct resman_list_in_use_portal *portal_item;

	res_pool = find_res_pool(dprc->resman->global_container, type);
	if (res_pool == NULL) {
		pr_err("Resource type is not defined\n");
		return -EINVAL;
	}

	if (strcmp(type, "mcp") == 0) {
		spin_lock(dprc->lock_in_use_portal_list);
		portal_item = dprc->in_use_portals;
		while (portal_item) {
			if ((portal_item->portal_id != dprc->portal_id) && (!(portal_item->dpmcp_object)))
				cnt++;
			portal_item = portal_item->next;
		}
		spin_unlock(dprc->lock_in_use_portal_list);
	}

	res_pool = find_res_pool(dprc, type);
	if (res_pool == 0) {
		*res_count = 0;
		return 0;
	}
	cur_range_item = res_pool->range_item;
	while (cur_range_item) {
		for (i = cur_range_item->range.min_id;
			i <= cur_range_item->range.max_id; i++)
			cnt++;
		cur_range_item = cur_range_item->next;
	}
	*res_count = cnt;
	return 0;
}

static int is_last_mcp_id(struct dprc *dprc,
                          struct resman_list_in_use_portal *portal_item,
                          struct resman_list_pool *res_pool)
{
	while (portal_item){
		if ((portal_item->portal_id != dprc->portal_id) && (!(portal_item->next->dpmcp_object)))
				return 0;
		portal_item = portal_item->next;
	}
	if (res_pool->range_item)
		return 0;
	return 1;
}

static int get_free_res_range(
		struct resman_list_pool *res_pool,
		struct dprc_res_ids_range_desc *range_desc)
{
	struct resman_list_item_range *cur_range_item, *prv_range_item = NULL;
	int found_range = 0;

	cur_range_item = res_pool->range_item;
	prv_range_item = NULL;
	while (cur_range_item) {
		if (found_range) {
			range_desc->iter_status = DPRC_ITER_STATUS_MORE;
			return 0;
		}

		if (range_desc->iter_status == DPRC_ITER_STATUS_FIRST) {
			range_desc->base_id =
				cur_range_item->range.min_id;
			range_desc->last_id =
				cur_range_item->range.max_id;
			found_range = 1;
		} else if (range_desc->iter_status == DPRC_ITER_STATUS_LAST)
			return -EIO;
		else if (range_desc->iter_status == DPRC_ITER_STATUS_MORE) {
			if (prv_range_item == NULL) {
				prv_range_item = cur_range_item;
				cur_range_item = cur_range_item->next;
			}
			if ((range_desc->last_id
				>= prv_range_item->range.max_id)
				&& (range_desc->last_id
					< cur_range_item->range.min_id)) {
				range_desc->base_id =
					cur_range_item->range.min_id;
				range_desc->last_id =
					cur_range_item->range.max_id;
				found_range = 1;
			}
		} else
			return -EIO;

		prv_range_item = cur_range_item;
		cur_range_item = cur_range_item->next;
	}
	range_desc->iter_status = DPRC_ITER_STATUS_LAST;
	return 0;
}


int resman_get_res_ids(struct dprc *dprc,
	char *type,
	struct dprc_res_ids_range_desc *range_desc)
{
	struct resman_list_pool *res_pool;
	struct resman_res_req req;
	struct resman_list_in_use_portal *portal_item;
	int found = 0;

	res_pool = find_res_pool(dprc->resman->global_container, type);
	if (res_pool == NULL) {
		pr_err("Wrong resource type\n");
		return -EINVAL;
	}

	memset(&req, 0, sizeof(struct resman_res_req));
	strncpy(req.type, type, STR_MAX_SIZE - 1);
	res_pool = find_res_pool(dprc, req.type);
	if (res_pool == 0) {
		pr_err("resource pool dosn't exist\n");
		return -EEXIST;
	}

	if (strcmp(type, "mcp") == 0) {
		/*Get mcp resources frm in use portal list */
		if (range_desc->iter_status == DPRC_ITER_STATUS_FIRST){
			found = 1;
			range_desc->base_id = -1;
			range_desc->last_id = -1;
		}

		spin_lock(dprc->lock_in_use_portal_list);
		portal_item = dprc->in_use_portals;
		while(portal_item)
		{
			if ((!found) && (portal_item->portal_id == range_desc->base_id) && (portal_item->portal_id == range_desc->last_id))
				found = 1;
			else if ((found) && (portal_item->portal_id != dprc->portal_id) && (!(portal_item->dpmcp_object))) {
				range_desc->base_id = portal_item->portal_id;
				range_desc->last_id = portal_item->portal_id;
				if (is_last_mcp_id(dprc, portal_item, res_pool))
					range_desc->iter_status = DPRC_ITER_STATUS_LAST;
				else
					range_desc->iter_status = DPRC_ITER_STATUS_MORE;
				spin_unlock(dprc->lock_in_use_portal_list);
				return 0;
			}
			portal_item = portal_item->next;
		}
		spin_unlock(dprc->lock_in_use_portal_list);
	}

	if (found)
		range_desc->iter_status = DPRC_ITER_STATUS_FIRST;

	return get_free_res_range(res_pool, range_desc);
}

int resman_get_attributes(struct dprc *dprc,
	struct resman_container_attributes *attributes)
{
	int iommu_bypass;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed\n");
		return -EPERM;
	}

	attributes->container_id = dprc->container_id;
	attributes->icid = (uint32_t)dprc->icid->icid_number;
	attributes->portal_id = dprc->portal_id;
	attributes->options = dprc->options;
	/* clear DPRC_CFG_OPT_IOMMU_BYPASS flag before sending back to user */
	attributes->options &= ~DPRC_CFG_OPT_IOMMU_BYPASS;
	iommu_bypass = ((dprc->options & DPRC_CFG_OPT_IOMMU_BYPASS) == DPRC_CFG_OPT_IOMMU_BYPASS);
	attributes->bmt = iommu_bypass;
	attributes->pl = iommu_bypass;
	attributes->bdi = iommu_bypass;
	attributes->va = 0;
	attributes->version.major = DPRC_VER_MAJOR;
	attributes->version.minor = DPRC_VER_MINOR;

	return 0;
}

int resman_get_obj_region(struct dprc *dprc,
	char *obj_type,
	int obj_id,
	uint8_t region_index,
	struct dprc_region_desc *region_desc,
	int modify_region_size)
{
	int type_index, portal_id, err;
	struct resman_list_item_container *container_item;
	struct resman_list_item_device *cur_device_item;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed\n");
		return -EPERM;
	}

	if (is_dev(obj_type)){
		type_index = get_dev_index(obj_type);
		CHECK_COND_RETVAL(type_index >= 0, -EEXIST);
		spin_lock(dprc->resman->lock_dprc_devices[type_index]);
		cur_device_item = dprc->devices[type_index];
		while (cur_device_item) {
			if (cur_device_item->device->dev.id == obj_id) {
				err =  get_dev_region(
					dprc->resman, cur_device_item->device,
					region_desc, region_index,
					modify_region_size);
				spin_unlock(dprc->resman->lock_dprc_devices[type_index]);
				return err;
			}
			cur_device_item = cur_device_item->next;
		}
		spin_unlock(dprc->resman->lock_dprc_devices[type_index]);

	} else if (strcmp(obj_type, "dprc") == 0) {
		spin_lock(dprc->lock_children_list);
		container_item = dprc->children;
		while (container_item) {
			if (container_item->container->container_id == obj_id){
				if (region_index == 0) {
					portal_id =
						container_item->container->portal_id;
					spin_unlock(dprc->lock_children_list);
					region_desc->base_offset =
						(uint32_t)get_portal_offset(portal_id);
					if (modify_region_size == 1)
						region_desc->size = DPRC_64KB_MC_PORTAL_REGION_SIZE;
					else
						region_desc->size = DPRC_64B_MC_PORTAL_REGION_SIZE;
					region_desc->type = DPRC_REGION_TYPE_MC_PORTAL;
					region_desc->flags = 0;
					return 0;
				} else {
					spin_unlock(dprc->lock_children_list);
					pr_err("region_index must be 0 for dprc\n");
					return -EINVAL;
				}
			}
			container_item = container_item->next;
		}
		spin_unlock(dprc->lock_children_list);
	}

	return -EIO;
}

int resman_is_irq_cfg_allowed(struct device *device)
{
	struct resman_device *dev;
	int owner_id = OWNER_ID(device);

	dev = GET_DEVICE(device);

	if (dev->owners[owner_id].dprc->options & DPRC_CFG_OPT_IRQ_CFG_ALLOWED)
		return 1;
	else
		return 0;
}

int resman_set_irq(struct dprc *dprc,
		   uint8_t irq_index,
		   int portal_id,
		   struct mc_irq_cfg *irq_cfg)
{
	struct dprc *req_dprc;
	int iommu_bypass;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed on global container\n");
		return -EPERM;
	}

	req_dprc = get_container_by_key(dprc->resman, RESMAN_KEY_TYPE_PORTAL_ID, portal_id);
	ASSERT_COND(req_dprc);
	if ((req_dprc->options & DPRC_CFG_OPT_IRQ_CFG_ALLOWED) == 0) {
		pr_err("Operation not allowed for dprc%d\n", req_dprc->container_id);
		return -EPERM;
	}

	if (irq_index >= DPRC_NUM_OF_IRQS) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPRC_NUM_OF_IRQS);
		return -EINVAL;
	}

	irq_cfg->dev_ctx.amq.icid = (uint16_t)dprc->icid->icid_number;
	iommu_bypass = ((req_dprc->options & DPRC_CFG_OPT_IOMMU_BYPASS) == DPRC_CFG_OPT_IOMMU_BYPASS);
	irq_cfg->dev_ctx.amq.bmt = iommu_bypass;
	irq_cfg->dev_ctx.amq.pl = iommu_bypass;
	irq_cfg->dev_ctx.amq.bdi = iommu_bypass;
	irq_cfg->dev_ctx.amq.va = 0;
	irq_cfg->dev_ctx.type = (req_dprc->options & DPRC_CFG_OPT_AIOP) ? DPMNG_CTX_TYPE_AIOP : DPMNG_CTX_TYPE_GPP;

	mc_set_irq(&dprc->irqs[irq_index], irq_cfg);
	return 0;
}

int resman_set_obj_irq(struct dprc *dprc,
		       char *obj_type,
		       int obj_id,
		       uint8_t irq_index,
		       int portal_id,
		       struct mc_irq_cfg *irq_cfg)
{
	int iommu_bypass, type_index, err;
	struct resman_list_item_device *cur_device_item;
	struct resman_list_item_container *container_item;
	struct dprc *req_dprc;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed on global container\n");
		return -EPERM;
	}

	req_dprc = get_container_by_key(dprc->resman, RESMAN_KEY_TYPE_PORTAL_ID, portal_id);
	ASSERT_COND(req_dprc);
	if ((req_dprc->options & DPRC_CFG_OPT_IRQ_CFG_ALLOWED)== 0) {
		pr_err("Operation not allowed for dprc%d\n", req_dprc->container_id);
		return -EPERM;
	}

	if (is_dev(obj_type)){
		type_index = get_dev_index(obj_type);
		CHECK_COND_RETVAL(type_index >= 0, -EEXIST);
		spin_lock(dprc->resman->lock_dprc_devices[type_index]);
		cur_device_item = dprc->devices[type_index];
		while (cur_device_item) {
			if (cur_device_item->device->dev.id == obj_id) {
				irq_cfg->dev_ctx.amq.icid = (uint16_t)dprc->icid->icid_number;
				iommu_bypass = ((req_dprc->options & DPRC_CFG_OPT_IOMMU_BYPASS) == DPRC_CFG_OPT_IOMMU_BYPASS);
				irq_cfg->dev_ctx.amq.pl = iommu_bypass;
				irq_cfg->dev_ctx.amq.bmt = iommu_bypass;
				irq_cfg->dev_ctx.amq.bdi = iommu_bypass;
				irq_cfg->dev_ctx.amq.va = 0;
				irq_cfg->dev_ctx.type = (req_dprc->options & DPRC_CFG_OPT_AIOP) ? DPMNG_CTX_TYPE_AIOP : DPMNG_CTX_TYPE_GPP;
				err = dprc->resman->dev_type_params[type_index]->f_set_irq((void *)cur_device_item->device, irq_cfg, irq_index);
				spin_unlock(dprc->resman->lock_dprc_devices[type_index]);
				return err;
			}
			cur_device_item = cur_device_item->next;
		}
		spin_unlock(dprc->resman->lock_dprc_devices[type_index]);
	}
	else if (strcmp(obj_type, "dprc") == 0) {
		spin_lock(dprc->lock_children_list);
		container_item = dprc->children;
		while (container_item) {
			if (container_item->container->container_id == obj_id) {
				err = resman_set_irq(container_item->container, irq_index, portal_id, irq_cfg);
				spin_unlock(dprc->lock_children_list);
				return err;
			}
			container_item = container_item->next;
		}
		spin_unlock(dprc->lock_children_list);
	}

	return -EEXIST;
}

int resman_get_obj_irq(struct dprc *dprc,
		       char *obj_type,
		       int obj_id,
		       uint8_t irq_index,
		       struct mc_irq_cfg *irq_cfg)
{
	int type_index, err;
	struct resman_list_item_device *cur_device_item;
	struct resman_list_item_container *container_item;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed on global container\n");
		return -EPERM;
	}

	if (is_dev(obj_type)){
		type_index = get_dev_index(obj_type);
		CHECK_COND_RETVAL(type_index >= 0, -EEXIST);
		spin_lock(dprc->resman->lock_dprc_devices[type_index]);
		cur_device_item = dprc->devices[type_index];
		while (cur_device_item) {
			if (cur_device_item->device->dev.id == obj_id) {
				err = dprc->resman->dev_type_params[type_index]->f_get_irq((void *)cur_device_item->device, irq_cfg, irq_index);
				spin_unlock(dprc->resman->lock_dprc_devices[type_index]);
				return err;
			}
			cur_device_item = cur_device_item->next;
		}
		spin_unlock(dprc->resman->lock_dprc_devices[type_index]);
	}
	else if (strcmp(obj_type, "dprc") == 0) {
		spin_lock(dprc->lock_children_list);
		container_item = dprc->children;
		while (container_item) {
			if (container_item->container->container_id == obj_id) {
				err = resman_get_irq(container_item->container, irq_index, irq_cfg);
				spin_unlock(dprc->lock_children_list);
				return err;
			}
			container_item = container_item->next;
		}
		spin_unlock(dprc->lock_children_list);
	}

	return -EEXIST;
}

int resman_get_irq(struct dprc *dprc,
		   uint8_t irq_index,
		   struct mc_irq_cfg *irq_cfg)
{
	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed on global container\n");
		return -EPERM;
	}
	if (irq_index >= DPRC_NUM_OF_IRQS) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPRC_NUM_OF_IRQS);
		return -EINVAL;
	}

	return mc_get_irq(&dprc->irqs[irq_index], irq_cfg);
}

int resman_set_irq_enable(struct dprc *dprc, uint8_t irq_index, uint8_t en, int portal_id)
{
	struct dprc *req_dprc;

	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed on global container\n");
		return -EPERM;
	}

	req_dprc = get_container_by_key(dprc->resman, RESMAN_KEY_TYPE_PORTAL_ID, portal_id);
	ASSERT_COND(req_dprc);
	if ((req_dprc->options & DPRC_CFG_OPT_IRQ_CFG_ALLOWED) == 0) {
		pr_err("Operation not allowed for dprc%d\n", req_dprc->container_id);
		return -EPERM;
	}

	if (irq_index >= DPRC_NUM_OF_IRQS) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPRC_NUM_OF_IRQS);
		return -EINVAL;
	}

	return mc_set_irq_enable(&dprc->irqs[irq_index], en);
}

int resman_get_irq_enable(struct dprc *dprc, uint8_t irq_index,	uint8_t *en)
{
	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed on global container\n");
		return -EPERM;
	}
	if (irq_index >= DPRC_NUM_OF_IRQS) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPRC_NUM_OF_IRQS);
		return -EINVAL;
	}

	return mc_get_irq_enable(&dprc->irqs[irq_index], en);
}

int resman_set_irq_mask(struct dprc *dprc, uint8_t irq_index, uint32_t mask)
{
	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed on global container\n");
		return -EPERM;
	}
	if (irq_index >= DPRC_NUM_OF_IRQS) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPRC_NUM_OF_IRQS);
		return -EINVAL;
	}

	return mc_set_irq_mask(&dprc->irqs[irq_index], mask);
}

int resman_get_irq_mask(struct dprc *dprc, uint8_t irq_index, uint32_t *mask)
{
	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed on global container\n");
		return -EPERM;
	}
	if (irq_index >= DPRC_NUM_OF_IRQS) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPRC_NUM_OF_IRQS);
		return -EINVAL;
	}

	return mc_get_irq_mask(&dprc->irqs[irq_index], mask);
}

int resman_get_irq_status(struct dprc *dprc,
			  uint8_t irq_index,
			  uint32_t *status)
{
	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed on global container\n");
		return -EPERM;
	}
	if (irq_index >= DPRC_NUM_OF_IRQS) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPRC_NUM_OF_IRQS);
		return -EINVAL;
	}

	return mc_get_irq_status(&dprc->irqs[irq_index], status);
}

int resman_clear_irq_status(struct dprc *dprc,
			    uint8_t irq_index,
			    uint32_t status)
{
	if (dprc->container_id == GLOBAL_CONTAINER_ID) {
		pr_err("Operation not allowed on global container\n");
		return -EPERM;
	}
	if (irq_index >= DPRC_NUM_OF_IRQS) {
		pr_err("IRQ index %d exceeds supported IRQs (%d)\n",
		       irq_index, DPRC_NUM_OF_IRQS);
		return -EINVAL;
	}

	return mc_clear_irq_status(&dprc->irqs[irq_index], status);
}

int resman_get_container_id(int portal_id, int *container_id)
{
	struct resman *resman;
	struct dprc *dprc;

	resman = sys_get_unique_handle(FSL_MOD_RESMAN);
	ASSERT_COND(resman);

	dprc = get_container_by_key(resman,
					RESMAN_KEY_TYPE_CONTAINER_PORTAL_ID,
					(int)portal_id);
	if (dprc == NULL) {
		dprc = get_container_by_key(resman, RESMAN_KEY_TYPE_PORTAL_ID,
						(int)portal_id);
		if (dprc == NULL) {
			pr_err("Container is not available\n");
			return -ENAVAIL;
		}
	}

	*container_id = dprc->container_id;
	return 0;

}

/*************************API Routine - ResMan*********************************/
static int create_slabs(struct resman *resman)
{
	int err, mcp_cnt = 0;
	struct mc_portal_desc mcp_desc;

	/* get number of IFP's to create a resman pool */
	memset(&mcp_desc, 0, sizeof(mcp_desc));
	while (sys_get_desc(SOC_MODULE_MC_PORTAL, SOC_DB_NO_MATCH_FIELDS,
					&mcp_desc, &mcp_cnt) == 0) ;

	err = slab_create("Container list item",
	                  &resman->container_item_slab,
	                  (uint16_t)((2 * MAX_NUM_OF_CONTAINERS) + MAX_NUM_OF_OPEN_HANDLES),
	                  (uint16_t)sizeof(struct resman_list_item_container), 0, 0, L1_CACHE_LINE_SIZE,
	                  MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for container list items failed\n");
		return err;
	}

	err = slab_create("range list items",
	                  &resman->range_item_slab,
	                  (4 * KILOBYTE) + (2 * MAX_NUM_OF_CONTAINERS), /*16K resources in the system. assuming that the average range contains more then 4 resources (16K / 4 = 4K)*/
	                  (uint16_t)sizeof(struct resman_list_item_range), 0, 0, L1_CACHE_LINE_SIZE,
	                  MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for range list item failed\n");
		return err;
	}

	err = slab_create("resource pool",
	                  &resman->pool_slab,
	                  (MAX_NUM_OF_CONTAINERS * MAX_NUM_OF_RESOURCE_TYPES) + MAX_NUM_OF_RESOURCE_TYPES,
	                  (uint16_t)sizeof(struct resman_list_pool), 0, 0, L1_CACHE_LINE_SIZE,
	                  MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for resource pool failed\n");
		return err;
	}

	err = slab_create("device item",
	                  &resman->device_item_slab,
	                  (MAX_NUM_OF_DEVICES * 2),
	                  (uint16_t)sizeof(struct resman_list_item_device), 0, 0, L1_CACHE_LINE_SIZE,
	                  MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for device item failed\n");
		return err;
	}



	err = slab_create("resource policy",
	                  &resman->res_policy_slab,
	                  (MAX_NUM_OF_CONTAINERS * MAX_NUM_OF_RESOURCE_TYPES),
	                  (uint16_t)sizeof(struct resman_list_res_policy), 0, 0, L1_CACHE_LINE_SIZE,
	                  MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for resource policy failed\n");
		return err;
	}

	err = slab_create("open device",
		       	  &resman->open_dev_slab,
		          MAX_NUM_OF_OPEN_HANDLES,
		          (uint16_t)sizeof(struct resman_list_open), 0, 0, L1_CACHE_LINE_SIZE,
		          MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for open device failed\n");
		return err;
	}

	err = slab_create("icid",
		       	  &resman->icid_slab,
		       	  MAX_NUM_OF_CONTAINERS,
		       	  (uint16_t)sizeof(struct resman_icid), 0, 0, L1_CACHE_LINE_SIZE,
		          MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for icid failed\n");
		return err;
	}

	err = slab_create("in use_portal",
			  &resman->in_use_portal_slab,
			  (uint32_t)mcp_cnt,
			  (uint16_t)sizeof(struct resman_list_in_use_portal), 0, 0, L1_CACHE_LINE_SIZE,
			  MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for in use_portal failed\n");
		return err;
	}

	err = slab_create("device",
	                  &resman->device_slab,
	                  MAX_NUM_OF_DEVICES,
	                  (uint16_t)sizeof(struct resman_device), 0, 0, L1_CACHE_LINE_SIZE,
			  MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for devices failed\n");
		return err;
	}

	err = slab_create("dprc",
			  &resman->dprc_slab,
			  MAX_NUM_OF_CONTAINERS + 1,
			  (uint16_t)sizeof(struct dprc), 0, 0, L1_CACHE_LINE_SIZE,
			  MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for dprcs failed\n");
		return err;
	}

	err = slab_create("pres",
			  &resman->pres_slab,
			  MAX_NUM_OF_RESOURCES,
			  (uint16_t)sizeof(struct resman_list_pres), 0, 0, L1_CACHE_LINE_SIZE,
			  MEM_PART_SYSTEM_DDR1_CACHEABLE, 0);
	if (err) {
		pr_err("slab creation for pres failed\n");
		return err;
	}

	return 0;
}

static int create_resman_spin_lock(struct resman *resman)
{
	int i;

	resman->lock_container_ids_list = spin_lock_create();
	if (!resman->lock_container_ids_list) {
		pr_err("Resman: no memory for spinlock\n");
		return -EIO;
	}

	resman->lock_free_icid_list = spin_lock_create();
	if (!resman->lock_free_icid_list) {
		pr_err("Resman: no memory for spinlock\n");
		return -EIO;
	}

	resman->lock_icid_list = spin_lock_create();
	if (!resman->lock_icid_list) {
		pr_err("Resman: no memory for spinlock\n");
		return -EIO;
	}

	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		resman->lock_dev_pool[i] = spin_lock_create();
		if (!resman->lock_dev_pool[i]) {
			pr_err("Resman: no memory for spinlock\n");
			return -EIO;
		}
	}

	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		resman->lock_devices_list[i] = spin_lock_create();
		if (!resman->lock_devices_list[i]) {
			pr_err("Resman: no memory for spinlock\n");
			return -EIO;
		}
	}

	for (i = 0; i < HASH_SIZE; i++) {
		resman->lock_pres_pool[i] = spin_lock_create();
		if (!resman->lock_pres_pool[i]) {
			pr_err("Resman: no memory for spinlock\n");
			return -EIO;
		}
	}

	for (i = 0; i < DP_NUM_OF_DEVICE_TYPES; i++) {
		resman->lock_dprc_devices[i] = spin_lock_create();
		if (!resman->lock_dprc_devices[i]) {
			pr_err("resman: no memory for spinlock\n");
			return -EIO;
		}
	}

	return 0;
}

static int dpc_init_icid_pool(struct resman *resman)
{
	int pool_created = 0;
	int i, err;

	for (i = 0; i < DPC_MAX_ICID_POOLS; i++) {
		if (dpc.icid_pools[i].dpc_mask) {
			/* set defaults for missing properties in DPC */
			if (!(dpc.icid_pools[i].dpc_mask & DPC_ICID_POOL_MASK_NUM)) {
				pr_err ("DPC icid_pool does not contain 'num' property\n");
				return -EINVAL;
			}
			if (!(dpc.icid_pools[i].dpc_mask & DPC_ICID_POOL_MASK_BASE_ICID)) {
				pr_err ("DPC icid_pool does not contain 'base_icid' property\n");
				return -EINVAL;
			}
			err = resman_create_icid_pool(resman,
			                              dpc.icid_pools[i].base_icid,
			                              (int)dpc.icid_pools[i].num,
			                              1);
			CHECK_COND_RETVAL(err == 0, err,
					  "failed to create icid pool (base = %d, num = %d)\n",
					  dpc.icid_pools[i].base_icid,
					  (int)dpc.icid_pools[i].num);
			pool_created = 1;
		}
	}

	/* When no ICID pool was specified in the DPC file, then just create a
	 * default one with only one ICID - 0x0 - as it was before.
	 */
	if (!pool_created) {
		err = resman_create_icid_pool(resman, 0, 1, 0);
		CHECK_COND_RETVAL(err == 0, err,
				  "failed to create icid pool (base = 0, num = 1)\n");
	}

	return 0;
}

struct resman *resman_init(void)
{
	struct resman *resman;
	struct dprc_cfg dprc_cfg;
	struct resman_res_req req;
	int global_container_id;
	int unassigned_portal_container_id;
	int root_container_id, err;
	uint64_t child_portal_offset;

	resman = (struct resman*)fsl_malloc(sizeof(struct resman));
	if (resman == NULL) {
		pr_err("fsl_malloc() failed\n");
		return NULL;
	}
	memset(resman, 0, sizeof(struct resman));
	memset(&dprc_cfg, 0, sizeof(struct dprc_cfg));
	err = create_slabs(resman);
	if (err) {
		fsl_free(resman);
		return NULL;
	}

	err = create_resman_spin_lock(resman);
	if (err){
		pr_err("creation of spin-locks for resman failed\n");
		fsl_free(resman);
		return NULL;
	}

	dprc_cfg.options = DPRC_CFG_OPT_SPAWN_ALLOWED
				| DPRC_CFG_OPT_ALLOC_ALLOWED
				| DPRC_CFG_OPT_OBJ_CREATE_ALLOWED
				| DPRC_CFG_OPT_IOMMU_BYPASS
				| DPRC_CFG_OPT_TOPOLOGY_CHANGES_ALLOWED
				| DPRC_CFG_OPT_IRQ_CFG_ALLOWED;

	dprc_cfg.portal_id = DPRC_GET_PORTAL_ID_FROM_POOL;

	if (resman_create_obj_pool(resman, "dprc", 0, MAX_NUM_OF_CONTAINERS)){
			fsl_free(resman);
			return NULL;
	}

	global_container_id = GLOBAL_CONTAINER_ID;
	if (create_container(resman, NULL, &dprc_cfg, &global_container_id,
	                     NULL, 0, 1)
		!= 0) {
		slab_release(resman->range_item_slab, (uint64_t)resman->container_ids);
		fsl_free(resman);
		return NULL;
	}
	resman->global_container = get_container_by_key(
		resman, RESMAN_KEY_TYPE_CONTAINER_ID, global_container_id);

	dpc_init_icid_pool(resman);
	dprc_cfg.icid = DPRC_GET_ICID_FROM_POOL;
	root_container_id = ROOT_CONTAINER_ID;
	memset(&req, 0, sizeof(struct resman_res_req));
	req.id_base_align = 0;
	req.num = 1;
	strcpy(req.type, "mcp");
	req.options = DPRC_RES_REQ_OPT_EXPLICIT;
	if (resman_create_res_pool(resman, &req) != 0) {
		pr_err("create pool for type DP_RES_TYPE_MCPID failed.\n");
		return NULL;
	}
	if (create_container(resman, resman->global_container, &dprc_cfg, &root_container_id,
				&child_portal_offset, 0, 1)
		!= 0) {
		slab_release(resman->range_item_slab, (uint64_t)resman->container_ids);
		fsl_free(resman);
		pr_err("create default root container failed.\n");
		return NULL;
	}

	dprc_cfg.portal_id = DPRC_NO_PORTAL_ID;
	unassigned_portal_container_id = UNASSINGED_PORTAL_CONTAINER_ID;
	if (create_container(resman, resman->global_container, &dprc_cfg,
				&unassigned_portal_container_id,
				NULL, 0, 1)
		!= 0) {
		slab_release(resman->range_item_slab, (uint64_t)resman->container_ids);
		fsl_free(resman);
		pr_err("create unassigned portals container failed.\n");
		return NULL;
	}
	resman->unassigned_portal_policy = DPRC_UNASSIGNED_PORTAL_POLICY_BLOCK;
	resman->unassigned_portal_container_id =
		unassigned_portal_container_id;

	/*Init client/primitives/ICID lists*/
	resman->options |= RESMAN_INIT_DONE;
	return resman;
}

/* No need to lock - This routine is called only during MC initialization on core 0*/
int resman_create_obj_pool(struct resman *resman, char *type, int base, int num)
{
	struct resman_list_item_range *cur_range_item;
	int min_id, max_id, index, dprc = 0;

	ASSERT_COND(resman);

	if (num <= 0) {
		pr_err("number of requested objects can't be 0 or less\n");
		return -EINVAL;
	}

	if (strcmp(type, "dprc") == 0)
		dprc = 1;
	else {
		index = get_dev_index(type);
		CHECK_COND_RETVAL(index >= 0, -EEXIST);
	}

	min_id = base;
	max_id = base + num - 1;

	/* Check if object already exist in the system*/
	if (dprc)
		cur_range_item = resman->container_ids;
	else
		cur_range_item = resman->dev_pool[index];

	while (cur_range_item) {
		if (((min_id >= cur_range_item->range.min_id)
			&& (min_id <= cur_range_item->range.max_id))
			|| ((max_id >= cur_range_item->range.min_id)
				&& (max_id <= cur_range_item->range.max_id))) {
			pr_err("Invalid operation - resource already exist.\n");
			return -EEXIST;
		}
		cur_range_item = cur_range_item->next;
	}


	add_res_range_to_list(resman, min_id,
				  max_id,
				  NULL,
				  dprc ? &resman->container_ids : &resman->dev_pool[index]);

	return 0;
}

static int is_res_exist_in_resman(struct resman_list_pool *cur_res_pool,
		int min_id, int max_id)
{
	struct resman_list_item_range *cur_range_item;

	if (!cur_res_pool)
		return 0;

	cur_range_item = cur_res_pool->range_item;
	while (cur_range_item) {
			if (((min_id >= cur_range_item->range.min_id)
				&& (min_id <= cur_range_item->range.max_id))
				|| ((max_id >= cur_range_item->range.min_id)
					&& (max_id <= cur_range_item->range.max_id))) {
				return 1;
			}
			cur_range_item = cur_range_item->next;
		}
	return 0;
}

/* No need to lock, called during MC initialization - core 0 only */
int resman_create_res_pool(struct resman *resman, struct resman_res_req *req)
{
	struct resman_list_item_range **free_range_list;
	struct dprc *dprc;
	int min_id, max_id, index;
	struct resman_list_pool *cur_res_pool, *global_res_pool;

	ASSERT_COND(resman);
	ASSERT_COND(req);

	if (req->num <= 0) {
		pr_err("number of requested resources should be > 0\n");
		return -EINVAL;
	}

	if (resman->num_of_resources >= MAX_NUM_OF_RESOURCE_TYPES) {
		pr_err("number of resource pools exceed the maximum pool number\n");
		ASSERT_COND(0);
	}

	dprc = ((struct resman *)resman)->global_container;

	index = hash(req->type);

	cur_res_pool = resman->pres_pools[index];
	while (cur_res_pool) {
		if (strcmp(cur_res_pool->pool_type, req->type) == 0) {
			break;
		}
		cur_res_pool = cur_res_pool->next_pool;
	}
	if (cur_res_pool == NULL) {
		/* Create new pool */
		resman->num_of_resources++;
		create_new_dprc_res_pool(dprc->resman, NULL, req->type);
		create_new_dprc_res_pool(dprc->resman, dprc, req->type);
		cur_res_pool = resman->pres_pools[index];
	}

	min_id = req->id_base_align;
	max_id = (req->id_base_align + (int)req->num - 1);

	/* Check if resource already exist in the system*/
	if (is_res_exist_in_resman(cur_res_pool, min_id, max_id))
	{
		pr_warn("Invalid operation - resource already exist.\n");
		return -EEXIST;
	}

	/* Add resource to the relevant lists*/
	global_res_pool = find_res_pool(dprc, req->type);
	ASSERT_COND(global_res_pool);
	free_range_list = &(global_res_pool->range_item);
	add_res_range_to_list(resman, min_id, max_id, NULL, free_range_list);

	/*free_range_list = &(resman->pres[(int)(req->type)]);*/
	free_range_list = &(cur_res_pool->range_item);
	add_res_range_to_list(resman, min_id, max_id, NULL, free_range_list);

	return 0;
}

/* No need to lock - called from core 0 only */
int resman_create_icid_pool(struct resman *resman,
	int base_icid,
	int num,
	int layout)
{
	struct resman_list_item_range **icid_range_list, *cur_range_item;
	int min_id = base_icid;
	int max_id = base_icid + num - 1, cnt;

	if (layout && (base_icid == 0)) {
		resman->options |= HAS_ICID_0;
		base_icid = 1;
		num--;
		if (num == 0)
			return 0;
	}
	icid_range_list = &(resman->free_icid_range_list);
	cur_range_item = *icid_range_list;
	while (cur_range_item != NULL) {
		if (((cur_range_item->range.min_id <= min_id)
			&& (cur_range_item->range.max_id >= min_id))
			|| ((cur_range_item->range.min_id <= max_id)
				&& (cur_range_item->range.max_id >= max_id))) {
			pr_err("icid exist in the pool\n");
			return -EEXIST;
		} else
			cur_range_item = cur_range_item->next;
	}
	cnt = add_res_range_to_list(resman, base_icid, (base_icid + num - 1), NULL,
					icid_range_list);

	if (cnt != num)
		return cnt;

	return 0;
}

int resman_destroy_icid_pool(struct resman *resman)
{
	struct resman_list_item_range *icid_range_list;

	/* Check if there are any icid in use (except for icid 0) */
	spin_lock(resman->lock_icid_list);

	if (resman->icid_list != NULL) {
		ASSERT_COND(resman->icid_list->icid_number == 0);
		ASSERT_COND(resman->icid_list->next == NULL);
	}

	spin_unlock(resman->lock_icid_list);


	/* Get the free-icid list to free */
	spin_lock(resman->lock_free_icid_list);

	icid_range_list = resman->free_icid_range_list;

	/* Free the free-icid list */
	free_range_list(resman, icid_range_list);

	spin_unlock(resman->lock_free_icid_list);

	return 0;
}

void *resman_open_dev(struct resman *resman,
	char *type,
	uint16_t id,
	int portal_id,
	int create,
	char *label)
{
	int dev_type_index;

	ASSERT_COND(resman);

	if (strcmp(type, "dprc") == 0)
		return open_dprc(resman, id, portal_id);

	if (is_dev(type)) {
		dev_type_index = get_dev_index(type);
		CHECK_COND_RETVAL( dev_type_index >= 0, NULL, "Device index not found: %s\n", type);
		if (resman->dev_type_params[dev_type_index] == NULL) {
			pr_err("unregister device type\n");
			return NULL;
		}
		return open_create_device(resman, type, id, portal_id, create, label);
	} else {
		pr_err("Invalid type\n");
		return NULL;
	}
}

void *resman_create_dev(struct resman *resman,
	char *type,
	int portal_id,
	char *label,
	uint16_t* dev_id)
{
	void* device = NULL;
	ASSERT_COND(dev_id);
	ASSERT_COND(resman);
	device = resman_open_dev(resman, type, *dev_id, portal_id, DPRC_CREATE_DEV_ONLY, label);
	if (device) {
		if (strcmp(type, "dprc") == 0) {
			*dev_id = (uint16_t)((struct dprc*) device)->container_id;
		} else {
			*dev_id = (uint16_t)((struct resman_device*) device)->dev.id;
		}
	}
	return device;
}

int resman_object_created(void *dev_handle)
{
	struct resman_device *device;

	device = GET_DEVICE(dev_handle);

	ASSERT_COND(OWNER_ID(dev_handle) == 0);
	invoke_inter(device->creator, DPRC_IRQ_EVENT_OBJ_CREATED);

	return 0;
}


int resman_close_dev(struct resman *resman,
	void *obj,
	char *type,
	int portal_id,
	int destroy)
{
	ASSERT_COND(resman);

	if (portal_id == NO_PORTAL_ID){
		if (destroy)
			return destroy_device_without_portal(resman, obj);
		else
			return 0;
	}

	if ((destroy == 1) && (strcmp(type, "dprc") == 0))
		return 0;

	if (strcmp(type, "dprc") == 0)
		return close_dprc(resman, (struct dprc *)obj, portal_id);

	if (is_dev(type)) {
		if (destroy)
			return destroy_device(resman, obj);
		else
			return close_device(resman, obj, portal_id);
	} else {
		pr_err("Invalid type\n");
		return -EINVAL;
	}
}

int resman_bind(struct device *dev_handle,
	struct resman_res_req *res_req,
	int *res_ids)
{
	struct resman_device *dev = NULL;
	struct resman_list_item_range *res_list = NULL, *cur_range_item;
	uint32_t cnt = 0, explicit = 0;
	int min_id, max_id, i;
	struct resman_list_pool *res_pool;
	struct dprc *dprc;

	if (res_req->options & DPRC_RES_REQ_OPT_EXPLICIT) {
		if (res_req->num > 1) {
			pr_err("Bind operation for more than one resource,"
			" is not supported for explicit resources\n");
			return -ENOTSUP;
		}
		explicit = 1;
	}
	dev = GET_DEVICE(dev_handle);

	dprc = dev->creator;

	res_pool = find_res_pool(dprc->resman->global_container,
					res_req->type);
	if (res_pool == NULL) {
		pr_err("No resource pool defined for this resource type\n");
		return -EINVAL;
	}

	if (explicit == 1)
		find_explicit_pres(dprc, res_req, 1, &res_list);
	else
		find_pres(dprc, res_req, 1, &res_list);
	if (res_list == NULL) {
		pr_err("resources not found\n");
		return -ENAVAIL;
	}

	/* Fill returned resources id's */
	cur_range_item = res_list;
	while (cur_range_item) {
		min_id = cur_range_item->range.min_id;
		max_id = cur_range_item->range.max_id;

		/* Update res_ids with virt/phys id's */
		if (res_ids){
			for (i = min_id; i <= max_id; i++) {
				res_ids[cnt++] = i;
			}
		}
		/* update resource allocation amount */
		if (((struct dprc *)cur_range_item->private) != dprc)
				update_alloc_res(((struct dprc *)(cur_range_item->private)),
							 dprc, res_req->type,
							 max_id - min_id + 1,
							 ADD_ALLOCATED_RES);

		cur_range_item = cur_range_item->next;
	}

	/* move resources to device */
	bind_res_to_dev(dprc->resman, dev, res_list, res_req, res_pool->pool_type);

	/* Update bound resources counter at resman */
	update_bound_res_counter(dprc->resman, res_req->type, (int)res_req->num,
					ADD_ALLOCATED_RES);

	/* remove bound resources from free list*/
	remove_found_res_from_list(dprc->resman, res_list, res_req);

	free_range_list(dprc->resman, res_list);

	if (((log_levels[LOG_MODULE] != LOG_LEVEL_GLOBAL)
			&& (log_levels[LOG_MODULE] <= LOG_LEVEL_DEBUG))
			|| ((log_levels[LOG_MODULE] == LOG_LEVEL_GLOBAL)
					&& (log_global_level <= LOG_LEVEL_DEBUG))) {
		if (res_req->num <= 1)
			pr_debug("Bind device %s[%d] with resource %s[%xh]\n",
				dev_handle->type, dev_handle->id, res_req->type, res_ids!=NULL?*res_ids:-1);
		else {
			pr_debug("Bind device %s[%d] with %d %s resources (%xh..%xh)\n",
				dev_handle->type, dev_handle->id, res_req->num, res_req->type,
				res_ids!=NULL?*res_ids:-1, res_ids!=NULL?res_ids[res_req->num - 1]:-1);
		}
	}
	return 0;
}


static int remove_res_from_cur_pres(int id, struct resman_list_pres **p_pres_item)
{
	struct resman_list_pres *cur_pres;
	struct resman_list_pres *new_pres, *tmp_pres;
	uint64_t tmp_addr;
	int err;

	cur_pres = (*p_pres_item);
	if ((id == cur_pres->range.min_id) && (id == cur_pres->range.max_id)) {
		tmp_pres = cur_pres;
		(*p_pres_item) = cur_pres->next;

		slab_release(tmp_pres->orig_container->resman->pres_slab, (uint64_t)tmp_pres);
	} else if (id == cur_pres->range.min_id)
		cur_pres->range.min_id++;
	else if (id == cur_pres->range.max_id)
		cur_pres->range.max_id--;
	else/* id in the middle of max and min */
	{
		err = slab_acquire(cur_pres->orig_container->resman->pres_slab, &tmp_addr);
		ASSERT_COND(err == 0);
		new_pres = (struct resman_list_pres *)UINT_TO_PTR(tmp_addr);
		memset(new_pres, 0, sizeof(struct resman_list_pres));
		new_pres->pool_type = cur_pres->pool_type;
		new_pres->orig_container = cur_pres->orig_container;
		new_pres->range.min_id = id + 1;
		new_pres->range.max_id = cur_pres->range.max_id;
		cur_pres->range.max_id = id - 1;
		new_pres->next = cur_pres->next;
		cur_pres->next = new_pres;
	}
	return 0 ;
}

int resman_unbind(void *dev_handle, char *type, int id)
{
	struct resman_device *dev = NULL;
	struct resman_list_pres *pres_item, **p_pres_item;
	struct resman_list_item_range **list;
	struct resman_list_pool *res_pool;
	struct resman *resman;
	int err;

	dev = GET_DEVICE(dev_handle);

	resman = dev->creator->resman;

	res_pool = find_res_pool(resman->global_container, type);
	ASSERT_COND(res_pool);

	p_pres_item = &(dev->bound_res);
	pres_item = *p_pres_item;

	while (pres_item) {
		//cur_pres = pres_item->next;
		if ((strcmp(pres_item->pool_type, type) == 0)
			&& (pres_item->range.min_id <= id)
			&& (pres_item->range.max_id >= id)) {

			err = remove_res_from_cur_pres(id, p_pres_item);
			if (err)
				return err;

			res_pool = find_res_pool(pres_item->orig_container, type);
			ASSERT_COND(res_pool);
			list = &(res_pool->range_item);
			add_res_range_to_list(resman, id, id, NULL, list);

			if ((pres_item->next == NULL) || (pres_item->orig_container != pres_item->next->orig_container))
				invoke_inter(pres_item->orig_container, DPRC_IRQ_EVENT_RES_ADDED);

			/* Update bound resources counter at resman */

			/* update resource allocation amount */
			if (((struct dprc *)pres_item->orig_container) != dev->creator)
					update_alloc_res(((struct dprc *)(pres_item->orig_container)),
								dev->creator, type, 1, SUBTRACT_ALLOCATED_RES);

			update_bound_res_counter(
				resman, type, 1, SUBTRACT_ALLOCATED_RES);
			return 0;

		}
		p_pres_item = &((*p_pres_item)->next);
		pres_item = pres_item->next;
	}

	return 0;
}

int resman_unbind_all(void *dev_handle)
{
	struct resman_list_pres **bound_res;
	struct resman_device *dev = NULL;
	struct resman_list_pres *cur_pres;
	struct resman_list_item_range **list;
	struct resman_list_pool *res_pool;
	int min_id, max_id;
	int count = 0;
	ASSERT_COND(OWNER_ID(dev_handle) == 0);
	dev = GET_DEVICE(dev_handle);

	bound_res = &(dev->bound_res);

	while (*bound_res) {
		cur_pres = (*bound_res);

		min_id = cur_pres->range.min_id;
		max_id = cur_pres->range.max_id;
		(*bound_res) = cur_pres->next;

		res_pool = find_res_pool(cur_pres->orig_container,
						cur_pres->pool_type);
		ASSERT_COND(res_pool);
		list = &(res_pool->range_item);
		if (add_res_range_to_list(cur_pres->orig_container->resman, min_id, max_id, NULL, list) < 0) {
			pr_err("failed to unbind all resources\n");
			return -EEXIST;
		}

		if ((cur_pres->next == NULL) ||
			(cur_pres->orig_container != cur_pres->next->orig_container))

			invoke_inter(cur_pres->orig_container, DPRC_IRQ_EVENT_RES_ADDED);
		count = max_id - min_id + 1;
		if (((struct dprc *)cur_pres->orig_container) != dev->creator)
			update_alloc_res(((struct dprc *)(cur_pres->orig_container)),
						 	 dev->creator, cur_pres->pool_type,
							 count,
						 	 SUBTRACT_ALLOCATED_RES);

		update_bound_res_counter(dev->creator->resman, cur_pres->pool_type,
						count,
						SUBTRACT_ALLOCATED_RES);
		pr_info("Unbind %d resource(s) from '%s' pool\n",
				count, cur_pres->pool_type);
		slab_release(dev->creator->resman->pres_slab, (uint64_t)cur_pres);

	}

	return 0;
}

int resman_register_device_operation(struct resman *resman,
	char *res_type,
	struct dp_dev_type_param *dev_type_param)
{
	struct dp_dev_type_param *new_dev_type_param;
	int index, i;

	if (!(is_dev(res_type))){
		pr_err("wrong device object type\n");
		return -EINVAL;
	}

	index = get_dev_index(res_type);
	CHECK_COND_RETVAL(index >= 0, -EEXIST);

	if (dev_type_param->region_count >= RESMAN_MAX_REGION_NUM) {
		pr_err("Region Count exceed the maximum number\n");
		return -EINVAL;
	}

	if (resman->dev_type_params[index] != NULL) {
		pr_err("device type is already registered\n");
		return -EPERM;
	}
	new_dev_type_param = (struct dp_dev_type_param *)fsl_malloc(
		sizeof(struct dp_dev_type_param));
	if (new_dev_type_param == NULL) {
		pr_err("fsl_malloc() failed\n");
		return -ENOMEM;
	}
	resman->dev_type_params[index] = new_dev_type_param;

	new_dev_type_param->f_reset = dev_type_param->f_reset;
	new_dev_type_param->f_destroy = dev_type_param->f_destroy;
	new_dev_type_param->f_assign = dev_type_param->f_assign;
	new_dev_type_param->f_set_irq = dev_type_param->f_set_irq;
	new_dev_type_param->f_get_irq = dev_type_param->f_get_irq;
#ifdef TKT011436 
	new_dev_type_param->f_graceful_stop = dev_type_param->f_graceful_stop;
	new_dev_type_param->f_empty_check = dev_type_param->f_empty_check;
	new_dev_type_param->f_restore_after_eiop_reset = dev_type_param->f_restore_after_eiop_reset;
	new_dev_type_param->f_resume = dev_type_param->f_resume;
#endif /* TKT011436 */

	new_dev_type_param->vendor = dev_type_param->vendor;
	strncpy(new_dev_type_param->device_type, dev_type_param->device_type, STR_MAX_SIZE-1);
	new_dev_type_param->ver_major = dev_type_param->ver_major;
	new_dev_type_param->ver_minor = dev_type_param->ver_minor;
	new_dev_type_param->irq_count = dev_type_param->irq_count;
	new_dev_type_param->region_count = dev_type_param->region_count;
	for (i = 0; i < dev_type_param->region_count; i++)
		new_dev_type_param->region_types[i] =
			dev_type_param->region_types[i];
	return 0;
}

int resman_get_ver(struct resman *resman,
	void *dev_handle,
	uint16_t *ver_minor,
	uint16_t *ver_major)
{
	int index;

	struct resman_device *device;

	device = GET_DEVICE(dev_handle);

	index = get_dev_index(device->dev.type);
	CHECK_COND_RETVAL(index >= 0, -EEXIST);

	if (resman->dev_type_params[index] == NULL) {
		pr_err("device type is not registered\n");
		return -EINVAL;
	}

	*ver_major = resman->dev_type_params[index]->ver_major;
	*ver_minor = resman->dev_type_params[index]->ver_minor;

	return 0;
}

int resman_unregister_device_operation(struct resman *resman, char *res_type)
{
	int index;

	if (!(is_dev(res_type))){
			pr_err("wrong device type\n");
				return -EINVAL;
	}

	index = get_dev_index(res_type);
	CHECK_COND_RETVAL(index >= 0, -EEXIST);

	if (resman->dev_type_params[index] == NULL) {
		pr_err("device type is not registered\n");
		return -EINVAL;
	}

	fsl_free(resman->dev_type_params[index]);
	resman->dev_type_params[index] = NULL;

	return 0;
}

void resman_get_dev_ctx(void *dev_handle, struct dpmng_dev_ctx *dev_ctx, int dev_amq)
{
	struct resman_device *device;
	struct dprc *dprc;
	int iommu_bypass;

	device = GET_DEVICE(dev_handle);

//	if (dev_amq)
		dprc = device->holder;
//	else
//		dprc = device->owners[OWNER_ID(dev_handle)].dprc;

	dev_ctx->amq.icid = (uint16_t)dprc->icid->icid_number;
	iommu_bypass = ((dprc->options & DPRC_CFG_OPT_IOMMU_BYPASS) == DPRC_CFG_OPT_IOMMU_BYPASS);
	dev_ctx->amq.pl = iommu_bypass;
	dev_ctx->amq.bmt =iommu_bypass;
	dev_ctx->amq.bdi = iommu_bypass;
	dev_ctx->amq.va = 0;
	dev_ctx->type =
		(dprc->options & DPRC_CFG_OPT_AIOP) ? DPMNG_CTX_TYPE_AIOP : DPMNG_CTX_TYPE_GPP;
}

void resman_update_dev_ctx_pl(void *dev_handle, struct dpmng_dev_ctx *dev_ctx, int dev_amq)
{
	struct resman_device *device;
	struct dprc *dprc;
	int iommu_bypass;
	int pl;

	device = GET_DEVICE(dev_handle);

//	if (dev_amq)
		dprc = device->holder;
//	else
//		dprc = device->owners[OWNER_ID(dev_handle)].dprc;
	iommu_bypass = ((dprc->options & DPRC_CFG_OPT_IOMMU_BYPASS) == DPRC_CFG_OPT_IOMMU_BYPASS);
	pl = ((dprc->options & DPRC_CFG_OPT_PL_ALLOWED) == DPRC_CFG_OPT_PL_ALLOWED);
	dev_ctx->amq.pl = iommu_bypass ? iommu_bypass : pl;
}

#if 0
int resman_get_dev_res_count(struct resman_device *device,
	char *res_type,
	int *count)
{
	int cnt = 0, i;
	struct resman_list_pres *cur_pres_item;
	struct resman_list_pool *res_pool;

	ASSERT_COND(device);

	device =
		(struct resman_device *)((int)device & (~(DP_DEV_OWNERS_MASK)));

	res_pool = find_res_pool(device->creator->resman->global_container,
					res_type);
	if (res_pool == NULL) {
		pr_err("Wrong resource type\n");
		*count = 0;
		return -EINVAL;
	}

	cur_pres_item = device->bound_res;
	while (cur_pres_item) {
		if (cur_pres_item->type == res_type) {
			for (i = cur_pres_item->range.min_id;
				i <= cur_pres_item->range.max_id; i++)
				cnt++;
		}
		cur_pres_item = cur_pres_item->next;
	}
	*count = cnt;
	return 0;
}

int resman_get_dev_res_ids(struct resman_device *device,
	char *res_type,
	int num_of_ids,
	int *res_ids)
{
	int cnt = 0, i;
	struct resman_list_pres *cur_pres_item;
	struct resman_list_pool *res_pool;

	ASSERT_COND(device);

	device =
		(struct resman_device *)((int)device & (~(DP_DEV_OWNERS_MASK)));

	res_pool = find_res_pool(device->creator->resman->global_container,
					res_type);
	if (res_pool == NULL) {
		pr_err("Wrong resource type\n");
		return -EINVAL;
	}

	cur_pres_item = device->bound_res;
	while (cur_pres_item) {
		if (strcmp(cur_pres_item->type, res_type) == 0) {
			for (i = cur_pres_item->range.min_id;
				i <= cur_pres_item->range.max_id; i++) {
				if (cnt == num_of_ids) {
					pr_err("num of descs too small\n");
					return -EIO;
				}
				res_ids[cnt++] = i;
			}
		}
		cur_pres_item = cur_pres_item->next;
	}
	return 0;
}
#endif
int resman_set_unassign_portal_policy(struct dprc *dprc,
	enum resman_unassigned_portal_policy policy)
{
	dprc->resman->unassigned_portal_policy = policy;

	return 0;
}

void *resman_create_mc_device(struct resman *resman)
{
	struct resman_device *device;
	struct resman_list_item_device *new_device_item;
	uint64_t tmp_addr;
	int err;

	ASSERT_COND(resman);
	/* Create new device */
	err = slab_acquire(resman->device_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	device = (struct resman_device *)UINT_TO_PTR(tmp_addr);
	memset(device, 0, sizeof(struct resman_device));

	device->dev.id = INVALID_DEVICE_ID;
	device->creator = resman->global_container;
	strcpy(device->dev.type, "mc");


	/* Add device to list */
	err = slab_acquire(resman->device_item_slab, &tmp_addr);
	ASSERT_COND(err == 0);
	new_device_item = (struct resman_list_item_device *)UINT_TO_PTR(tmp_addr);
	memset(new_device_item, 0, sizeof(struct resman_list_item_device));

	new_device_item->device = device;
	new_device_item->index = -1;
	spin_lock(resman->lock_dprc_devices[0]);
	new_device_item->next = resman->global_container->devices[0];
	resman->global_container->devices[0] = new_device_item;
	spin_unlock(resman->lock_dprc_devices[0]);
	return device;
}

int resman_destroy_mc_device(struct resman *resman, void *dev_handle)
{
	struct resman_device *device;
	struct resman_list_item_device **cur_device_item, *tmp_device_item;

	device = (struct resman_device *)dev_handle;
	if (device->bound_res != NULL) {
		pr_err("Can't destroy device - device has bound resources\n");
		return -EPERM;
	}
	spin_lock(resman->lock_dprc_devices[0]);
	cur_device_item = &(resman->global_container->devices[0]);
	while (*cur_device_item) {
		if ((*cur_device_item)->device == dev_handle) {
			tmp_device_item = (*cur_device_item);
			(*cur_device_item) = tmp_device_item->next;

			spin_unlock(resman->lock_dprc_devices[0]);
			slab_release(resman->device_slab, (uint64_t)(tmp_device_item->device));
			slab_release(resman->device_item_slab, (uint64_t)tmp_device_item);
			return 0;
		}
		cur_device_item = &((*cur_device_item)->next);
	}
	spin_unlock(resman->lock_dprc_devices[0]);

	return 0;
}

void *resman_get_container(struct resman *resman, int container_id)
{

	ASSERT_COND(resman);
	return get_container_by_key(resman, RESMAN_KEY_TYPE_CONTAINER_ID,
					container_id);
}

int resman_get_pool_count(struct dprc *dprc, int *pool_count)
{
	int i, count = 0;
	struct resman_list_pool *res_pool;
	struct resman_list_in_use_portal *portal_item;

	/* Handle the case that there is only "in use" mcp pool and no free mcp pool and count it */
	res_pool = find_res_pool(dprc, "mcp");
	if ((!res_pool) || (!(res_pool->range_item))){
		spin_lock(dprc->lock_in_use_portal_list);
		portal_item = dprc->in_use_portals;
		while (portal_item) {
			if ((portal_item->portal_id != dprc->portal_id) && (!(portal_item->dpmcp_object))){
					count++;
					break;
			}
			portal_item = portal_item->next;
		}
		spin_unlock(dprc->lock_in_use_portal_list);
	}
	for (i = 0; i < HASH_SIZE; i++) {
		spin_lock(dprc->lock_free_res_pools[i]);
		res_pool = dprc->free_res_pools[i];
		while (res_pool) {
			if (res_pool->range_item) {
				res_pool->index = count;
				count++;
			} else
				res_pool->index = -1;

			res_pool = res_pool->next_pool;
		}
		spin_unlock(dprc->lock_free_res_pools[i]);
	}
	*pool_count = count;
	return 0;
}

int resman_get_pool(struct dprc *dprc, int pool_index, char type[STR_MAX_SIZE])
{
	int i;
	struct resman_list_pool *res_pool;
	struct resman_list_in_use_portal *portal_item;

	/* Handle the case that there is only "in use" mcp pool and no free mcp pool and count it */
	res_pool = find_res_pool(dprc, "mcp");
	if ((!res_pool) || (!(res_pool->range_item))) {
		spin_lock(dprc->lock_in_use_portal_list);
		portal_item = dprc->in_use_portals;
		while (portal_item) {
			if ((portal_item->portal_id != dprc->portal_id) && (!(portal_item->dpmcp_object))){
				if (pool_index == 0){
					strcpy(type, "mcp");
					spin_unlock(dprc->lock_in_use_portal_list);
					return 0;
				}
			}
			portal_item = portal_item->next;
		}
		spin_unlock(dprc->lock_in_use_portal_list);
	}
	for (i = 0; i < HASH_SIZE; i++) {
		spin_lock(dprc->lock_free_res_pools[i]);
		res_pool = dprc->free_res_pools[i];
		while (res_pool) {
			if ((res_pool->range_item)
				&& (res_pool->index == pool_index)) {
				spin_unlock(dprc->lock_free_res_pools[i]);
				strncpy(type, res_pool->pool_type, STR_MAX_SIZE-1);
				return 0;
			}
			res_pool = res_pool->next_pool;
		}
		spin_unlock(dprc->lock_free_res_pools[i]);
	}
	return -ENAVAIL;

}
int resman_is_link_permitted (struct resman *resman,
		              char *ep1_type,
		              int ep1_id,
		              char *ep2_type,
		              int ep2_id,
		              struct dprc **contain_dprc)
{
	struct dprc *ep1_dprc = NULL;
	struct dprc *tmp_dprc = NULL;

	if (resman_find_device_at_descendant(resman, NULL, ep1_type,
	                                     ep1_id, &ep1_dprc) == NULL){
		pr_err("Object wasn't found\n");
		return -EPERM;
	}

	if (ep1_dprc->parent != resman->global_container) {
		tmp_dprc = ep1_dprc->parent;

		while (tmp_dprc->parent != resman->global_container){
			tmp_dprc = tmp_dprc->parent;
		}
	}

	if (resman_find_device_at_descendant(
                        resman, tmp_dprc, ep2_type, ep2_id, NULL) == NULL)
		return -EPERM;
    return 0;
}
/* searches for the portal id within the device's dprc hierarchy */
int resman_is_portal_in_dev_rc_hierarchy(
		struct resman *resman,
		void* device,
		unsigned int is_dprc_dev,
		int portal_id,
		int* dprc_id,
		int search_ancestors)
{
	int found = 0;
	int search_next_nth_parents = 0;
	struct dprc* current_dprc = (struct dprc*) 0;
	struct resman_list_item_container *container_item = (struct resman_list_item_container*) 0;
	struct resman_device* res_device = (struct resman_device*) 0;
	struct resman_list_in_use_portal* in_use_portal_list_item = (struct resman_list_in_use_portal*) 0;

	*dprc_id = RESMAN_NO_CONTAINER_ID;
	// fail fast
	if (!device || !resman ||
			portal_id >= 256)
		return 0;

	if (is_dprc_dev)
	{
		current_dprc = (struct dprc*) device;
		search_next_nth_parents = 1;// need to search the dprc'parent also
	}
	else
	{
		res_device = GET_DEVICE(device);
		// get container holding of the object
		current_dprc = res_device->holder;
	}
	if (search_ancestors > 0)
		search_next_nth_parents = MAX(search_next_nth_parents, search_ancestors);
	// search the DPRC ancestor hierarchy for the portal id
	while (current_dprc != 0 &&
			current_dprc->container_item &&
			search_next_nth_parents >= 0)
	{
		// check if the portal_id is:
		// 1. the current container portal id
		// 2. in the free mcp resource list
		// 3. in the in use portal list
		found = is_match_container(current_dprc->container_item,
				RESMAN_KEY_TYPE_PORTAL_ID,
				portal_id);
		if (found)
		{
			*dprc_id = current_dprc->container_id;
			break;
		}
		current_dprc = current_dprc->parent; // search next parent
		search_next_nth_parents--;
	}

	return found;
}

/* no lock for this routine. place locks at the caller routine */
struct resman_device *resman_find_device_at_descendant(
              struct resman *resman,
              struct dprc *dprc,
              char *type,
              int id,
              struct dprc **contain_dprc)
{
       struct dprc *container, *container_to_lock;
       struct resman_list_item_device *cur_device_item;
       int process;
       int first;
       int dev_type_index;

       dev_type_index = get_dev_index(type);
       CHECK_COND_RETVAL(dev_type_index >= 0, NULL);

       if (dprc == NULL) {
              container = resman->global_container;
              ASSERT_COND(container);
       } else {
              container = dprc;
       }

       first = 1;
       process = 1;
       while (container != NULL) {
	       container_to_lock = container;
	       spin_lock(container_to_lock->lock_children_list);
              if (process) {
                     cur_device_item =
                           container->devices[dev_type_index];
                     while (cur_device_item) {
                           if (cur_device_item->device->dev.id == id) {
                        	   if (contain_dprc != NULL)
                        		   *contain_dprc = container;
                        	   spin_unlock(container_to_lock->lock_children_list);
                        	   return cur_device_item->device;
                           }
                           cur_device_item = cur_device_item->next;
                     }
              }

              if (container->children != NULL && process) {
                     container = container->children->container;
                     process = 1;
              } else if ((!first) && (container->container_item) && (container->container_item->next != NULL)) {
                     container = container->container_item->next->container;
                     process = 1;
              } else {
                     container = container->parent;
                     process = 0;
              }
              first = 0;
              spin_unlock(container_to_lock->lock_children_list);
       }
       return NULL;
}

int resman_get_bound_res_counters(struct resman *resman)
{
	int i, j = 1;
	struct resman_list_pool *res_pool;

	/* Go over all the pools that exist at resman and print the bound_counter
	 * for each pool, which indicates the number of resources that bound
	 * to the devices at the system */
	for (i = 0; i < HASH_SIZE; i++) {
		spin_lock(resman->lock_pres_pool[i]);
		res_pool = resman->pres_pools[i];
		while (res_pool) {
			pr_info(
				"#%d. pool type - %s, bound resources - %d \n",
				j++, res_pool->pool_type,
				res_pool->bound_counter);

			res_pool = res_pool->next_pool;
		}
		spin_unlock(resman->lock_pres_pool[i]);
	}

	return 0;
}

int resman_is_destroy_allowed(void *dev_handle, char *type, struct dprc *contain_dprc)
{
	struct resman_device *device;

	device = GET_DEVICE(dev_handle);
	/*check if the container is locked*/
	if (!device->holder->locked)
	{
		/* Check if the request to destroy the device received from the device creator */
		if (device->owners[OWNER_ID(dev_handle)].dprc == device->creator)
			return 1;
		else {
			if (device->owners_num == 0 && contain_dprc != NULL &&
					device->creator == contain_dprc) {
				return 1;
			} else {
				pr_err("The destroy can be made only by creator container\n");
				return 0;
			}
		}
	} else {
		pr_err("Destroy command not allowed from a locked container\n");
		return 0;
	}
}

int resman_set_obj_label(struct dprc *dprc, char *obj_type, int obj_id, char *label)
{
	int type_index;
	struct resman_list_item_container *cur_container_item;
	struct resman_list_item_device *cur_device_item;

	if (is_dev(obj_type)){
		type_index = get_dev_index(obj_type);
		CHECK_COND_RETVAL(type_index >= 0, -EEXIST);
		spin_lock(dprc->resman->lock_dprc_devices[type_index]);
		cur_device_item = dprc->devices[type_index];
		while (cur_device_item) {
			if (cur_device_item->device->dev.id == obj_id) {
				strncpy(cur_device_item->device->dev.label, label, STR_MAX_SIZE - 1);
				spin_unlock(dprc->resman->lock_dprc_devices[type_index]);
				return 0;
			}
			cur_device_item = cur_device_item->next;
		}
		spin_unlock(dprc->resman->lock_dprc_devices[type_index]);
	}
	else if (strcmp(obj_type, "dprc") == 0) {
		spin_lock(dprc->lock_children_list);
		cur_container_item = dprc->children;
		while (cur_container_item) {
			if (cur_container_item->container->container_id == obj_id) {
				strncpy(cur_container_item->container->label, label, STR_MAX_SIZE - 1);
				spin_unlock(dprc->lock_children_list);
				return 0;
			}
			cur_container_item = cur_container_item->next;
		}
		spin_unlock(dprc->lock_children_list);
	}

	return -EEXIST;
}

int resman_clear_root_container(struct resman *resman)
{
	int i;
	struct dprc *root_container;
	struct resman_list_pool *res_pool;
	struct resman_res_req res_req = { 0 };

	/* Get the root container to reset */
	root_container = get_container_by_key(resman,
						RESMAN_KEY_TYPE_CONTAINER_ID,
						ROOT_CONTAINER_ID);
	if (root_container == NULL){
		pr_err("Root container does not exist\n");
		return -EIO;
	}

	for (i = 0; i < HASH_SIZE; i++) {
		spin_lock(root_container->lock_free_res_pools[i]);
		res_pool = root_container->free_res_pools[i];
		while (res_pool) {
			if (res_pool->range_item) {
				strncpy(res_req.type, res_pool->pool_type, STR_MAX_SIZE-1);
				res_req.num = (uint32_t)(res_pool->range_item->range.max_id - res_pool->range_item->range.min_id + 1);
				res_req.id_base_align = res_pool->range_item->range.min_id;
				res_req.options = DPRC_RES_REQ_OPT_EXPLICIT;
				unassign_explicit_pres(resman->global_container, root_container, &res_req);
			}
			res_pool = res_pool->next_pool;
		}
		spin_unlock(root_container->lock_free_res_pools[i]);
	}
	return 0;
}

void resman_get_peb_info()
{
	get_peb_free_blocks(ranges.offset, ranges.size, &ranges.used, &ranges.base_paddr);
}

int resman_get_mem_avail_list(uint16_t page, uint8_t flags, uint8_t partition_id, struct dprc_mem *mem)
{
	uint8_t num_entries;
	uint16_t total_page_cnt;
	void *mem_cpy = mem;
	int i;
	int current_idx = DPRC_MEM_MAX_PAGE_DATA * page;

	if (flags) {
		memset(&ranges, 0, sizeof(struct peb_avail_ranges));
		resman_get_peb_info();
	}

	total_page_cnt = ranges.used % DPRC_MEM_MAX_PAGE_DATA ?
				ranges.used / DPRC_MEM_MAX_PAGE_DATA + 1:
				ranges.used / DPRC_MEM_MAX_PAGE_DATA;

	if (page > total_page_cnt - 1) {
		return -EINVAL;
	} else if (page == total_page_cnt - 1) {
		num_entries = ranges.used - page * DPRC_MEM_MAX_PAGE_DATA;
	} else {
		num_entries = DPRC_MEM_MAX_PAGE_DATA;
	}

	*((uint8_t *) mem_cpy) = num_entries;
	mem_cpy += 2;
	*((uint16_t *) mem_cpy) = total_page_cnt;
	mem_cpy += 2;
	for (i = 0; i < num_entries; i++) {
		*((uint32_t *) mem_cpy) = ranges.offset[current_idx + i];
		mem_cpy += 4;
		*((uint32_t *) mem_cpy) = ranges.size[current_idx + i];
		mem_cpy += 4;
	}

	return 0;
}
