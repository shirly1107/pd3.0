/*
 * Copyright 2013-2021 NXP
 */

#include "common/fsl_string.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "fsl_malloc.h"
#include "fsl_platform.h"
#include "fsl_list.h"
#include "drivers/fsl_qbman_ctrl.h"
#include "drivers/fsl_qbman_portal.h"
#include "fsl_resman.h"
#include "fsl_soc.h"
#include "drivers/fsl_mc.h"
#include "dpmng.h"
#include "drivers/fsl_edma.h"
#include "fsl_qbman.h"
#include "fsl_eiop_memac.h"
#include "fsl_eiop.h"
#include "fsl_eiop_port.h"
#include "fsl_dppolicer.h"
#ifdef TKT220573
#include "fsl_eiop_ifp.h"
#endif
#include "fsl_hmap.h"
#include "coherent_access.h"
#include "fsl_dpaiop_mc.h"
#include "fsl_timer.h"
#include "qbman_portal.h"

#define DPMNG_SOC_WINDOW_SIZE	0x80000000
#define DPMNG_SDS_WINDOW_MASK 	0xFFFFFFFFF0000000LL

static int get_num_iop();
static int get_iop(int mac_id);
static int get_num_dcp(int iop_id);
static int get_num_phys(int iop_id, int dcp_id);
static int get_num_virt(int iop_id, int dcp_id);
static int get_num_recycle(int iop_id, int dcp_id);
static void make_key(int iop_id,
	int dcp_id,
	int ceetm_id,
	int id,
	hmap_key key);

static int get_aggr_num_cqch();
static int get_num_cqch(int iop_id, int dcp_id);

static int get_aggr_num_lni();
static int get_num_lni(int iop_id, int dcp_id);
static int get_num_ceetm_instances(int iop_id, int dcp_id);

static int connections_init_mallocate(struct dpmng *dpmng);
static int connections_init_mallocate_dcps(struct dpmng *dpmng, int iop_id);

/*! Physical connections */
static int connections_init_phys(struct dpmng *dpmng);
static int connections_init_phys_if(struct dpmng *dpmng,
	int id,
	struct pport_connections_desc *desc);
static int connections_init_phys_if_qbman(struct dpmng *dpmng,
	int id,
	struct pport_connections_desc *desc,
	int txstate,
	int wriop_reset);
static int connections_init_endpoint(struct dpmng *dpmng,
	struct dpmng_accesspoint *ap);

static int connections_init_bandwidth(struct dpmng *dpmng);
static int connections_init_bandwidth_cqch(struct dpmng *dpmng);
static int connections_init_bandwidth_lni(struct dpmng *dpmng);
static int connections_init_bandwidth_recycle(struct dpmng *dpmng);
static int phys_add_bandwidth(struct dpmng *dpmng,
	int iop_id,
	int dcp_id,
	int ceetm_id,
	int lniid,
	uint32_t bandwidth);

static long phys_get_bandwidth(struct dpmng *dpmng,
		int iop_id,
		int dcp_id,
		int ceetm_id,
		int lniid);

static int phys_remove_bandwidth(struct dpmng *dpmng,
	int iop_id,
	int dcp_id,
	int ceetm_id,
	int lniid);

/*! Virtual connections */
static int connections_init_virt(struct dpmng *dpmng);
static int connections_init_virt_if(struct dpmng *dpmng,
	int iop_id,
	int dcp_id,
	int id);
/*! recycle */
static int connections_init_recycle(struct dpmng *dpmng,
	int wriop_reset);
static int connections_init_recycle_port(struct dpmng *dpmng,
	int id,
	struct vport_connections_desc *desc,
	int wriop_reset);
static int connections_init_recycle_port_qbman(struct dpmng *dpmng,
	int id,
	struct vport_connections_desc *desc,
	int txstate,
	int wriop_reset);
static int connections_init_recycle_port_eiop(struct dpmng *dpmng,
	int id,
	struct vport_connections_desc *desc);

/*! dpmng_allocate_virt_connection */
static int allocate_virt_connection_iopid(struct dpmng *dpmng,
	int *iop_id,
	int *dcp_id);

static int allocate_virt_connection_id(struct dpmng *dpmng,
	int iop_id,
	int dcp_id,
	int *id);

static int get_phys_connection(struct dpmng *dpmng,
	int iop_id,
	int mac_id,
	int *dcp_id,
	int *id);

static int get_recycle(struct dpmng *dpmng,
	struct dpmng_accesspoint *ap,
	uint32_t req_bw,
	int *id);

static int connection_make_id(enum dpmng_connection_type type,
	int iop_id,
	int dcp_id,
	int id);
static int connection_get_iopid(int conn_id);
static int connection_get_dcpid(int conn_id);
static int connection_get_id(int conn_id);
static enum dpmng_connection_type connection_get_type(int conn_id);

#pragma push
#pragma section RW ".fw_version"

__declspec(section ".fw_version") struct mc_version mc_version = { 10, 30, 0 };

#pragma pop

void mc_get_version(struct mc_version *version)
{
	version->major = mc_version.major;
	version->minor = mc_version.minor;
	version->revision = mc_version.revision;
}

void mc_get_platform(struct mc_soc_version *platform)
{
	uint8_t major, minor;
	dcfg_get_revision(&major, &minor, &platform->svr);
	dcfg_get_proc_version(&platform->pvr);
}

/**
 * @brief	static functions declaration
 */

/* dpmng_init */
static int init_swp(struct dpmng *dpmng, struct dpmng_cfg *cfg);

static int init_swp(struct dpmng *dpmng, struct dpmng_cfg *cfg)
{
	dpmng->swportal_id = fsl_malloc(cfg->num_cores * sizeof(int));
	if (dpmng->swportal_id == NULL)
		return -ENODEV;

	dpmng->sw_portal_lock = fsl_malloc(cfg->num_cores * sizeof(int));
	if (dpmng->sw_portal_lock == NULL)
		return -ENODEV;

	return 0;
}

static int init_dpbp_peb_pools(struct dpmng *dpmng)
{
	int i, j, err;

	dpmng->dpbp_paddrs_by_pool_size[0].size = DPSW_DPBP_SIZE;
	dpmng->dpbp_paddrs_by_pool_size[0].alignment = 256;
	dpmng->dpbp_paddrs_by_pool_size[0].num_of_pools = NUM_OF_DPSW_POOLS;

	dpmng->dpbp_paddrs_by_pool_size[1].size = DPDMUX_DPBP_SIZE;
	dpmng->dpbp_paddrs_by_pool_size[1].alignment = 256;
	dpmng->dpbp_paddrs_by_pool_size[1].num_of_pools = NUM_OF_DPDMUX_POOLS;

	dpmng->dpbp_paddrs_by_pool_size[2].size = SNIC_DPBP_SIZE;
	dpmng->dpbp_paddrs_by_pool_size[2].alignment = 256;
	dpmng->dpbp_paddrs_by_pool_size[2].num_of_pools = NUM_OF_SNIC_POOLS;

	for (i = 0; i < 3; i++) {
		for (j = 0;
			j < dpmng->dpbp_paddrs_by_pool_size[i].num_of_pools;
			j++) {
			err =
				fsl_get_mem(
					dpmng->dpbp_paddrs_by_pool_size[i].size, /* 2 Mega Byte*/
					MEM_PART_PEB,
					dpmng->dpbp_paddrs_by_pool_size[i].alignment,
					&dpmng->dpbp_paddrs_by_pool_size[i].dpbp_paddr[j].paddr);
			if (err)
				return -ENOMEM;
		}

	}
	return 0;
}

struct dpmng * dpmng_allocate(void)
{
	struct dpmng *dpmng;

	dpmng = (struct dpmng *)fsl_malloc(sizeof(struct dpmng));
	if (dpmng)
		memset(dpmng, 0, sizeof(struct dpmng));
	return dpmng;
}

void dpmng_register(struct dpmng *dpmng, const struct dpmng_register *info)
{
	memcpy(&(dpmng->registration), /* Destination */
		info, /* Source */
		sizeof(struct dpmng_register)); /* Size */
}

int dpmng_init(struct dpmng *dpmng, struct dpmng_cfg *cfg)
{
	int err;
	struct mc_desc mc_desc;

	dpmng->aiop_container_id = -1;

	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, SOC_DB_NO_MATCH_FIELDS, &mc_desc,
				NULL);
	ASSERT_COND(!err);

	dpmng->mc_vaddr = mc_desc.vaddr;
	dpmng->soc_ccsr = mc_desc.soc_ccsr;
	
	dpmng->scratch_memory.data = fsl_malloc(SIZE_SCRATCH_MAP);
	
	if (dpmng->scratch_memory.data == NULL)
		return -ENOMEM;

	/*err = init_dpbp_peb_pools(dpmng);
	 if (err != 0)
	 return err;*/

	/* Software Portal management */
	err = init_swp(dpmng, cfg);
	if (err != 0)
		return err;

	return 0;
}

int dpmng_free(struct dpmng *dpmng)
{
	if (dpmng->swportal_id)
		fsl_free(dpmng->swportal_id);

	if (dpmng->sw_portal_lock)
		fsl_free(dpmng->sw_portal_lock);

	fsl_free(dpmng);

	return 0;
}

int dpmng_init_management_port(struct dpmng *dpmng)
{
	/*
	 *
	 */
	int iter, err = 0;
	struct eiop_port_desc port_desc;

	iter = 0;

	memset(&port_desc, 0, sizeof(struct eiop_port_desc));

	while (sys_get_desc(SOC_MODULE_EIOP_PORT, 0, &(port_desc), &iter) == 0) {
		if (port_desc.type == EIOP_MANAGEMENT_COMMAND_PORT) {
			pr_debug("Init management port ID = %d\n", port_desc.port_id);
			eiop_port_rx_enable(&port_desc);
			eiop_port_tx_enable(&port_desc);
		}
		memset(&port_desc, 0, sizeof(struct eiop_port_desc));
	}
	return err;
}

int dpmng_init_swportal(struct dpmng *dpmng,
	struct dpmng_portal_cfg *portal_cfg)
{
	struct qbman_swp_desc swp_desc;
	void *qman_hndl;
	int err;

	err = allocate_resource(dpmng->registration.resman_dev, "swp", 1, 1, 0,
				&(portal_cfg->swportal_id), "SWP-id");
	if (err)
		return err;

	memset(&swp_desc, 0x00, sizeof(struct qbman_swp_desc));
	/* initialize portal parameters */
	qman_hndl = sys_get_unique_handle(FSL_MOD_QBMAN);
	if (qman_hndl == NULL)
		return -ENODEV;

	swp_desc.block = qbman_block_get_desc(qman_hndl);

	swp_desc.cena_bar = NULL;
	/*sys_get_memory_mapped_module_base(
	 FSL_MOD_QBMAN_PORTAL,
	 (uint32_t)(params->swportal_id),
	 E_MAPPED_MEM_TYPE_CE_PORTAL);*/

	swp_desc.cinh_bar = NULL;
	/*sys_get_memory_mapped_module_base(
	 FSL_MOD_QBMAN_PORTAL,
	 (uint32_t)(params->swportal_id),
	 E_MAPPED_MEM_TYPE_CI_PORTAL);*/

	swp_desc.irq = -1;

	swp_desc.idx = portal_cfg->swportal_id;

	qbman_block_set_swp_icid(qman_hndl, swp_desc.idx, DPMNG_AMQ_ICID);
	qbman_block_set_swp_iobypass(qman_hndl, swp_desc.idx, DPMNG_AMQ_BMT);
	qbman_block_set_swp_va(qman_hndl, swp_desc.idx, DPMNG_AMQ_VA);
	qbman_block_set_swp_isolated(qman_hndl, swp_desc.idx, !DPMNG_AMQ_BDI);
	qbman_block_set_swp_enabled(qman_hndl, swp_desc.idx, 1);

	portal_cfg->swp = (void*)qbman_swp_init(&swp_desc);
	if (portal_cfg->swp == NULL) {
		err = deallocate_resource(dpmng->registration.resman_dev,
						"swp", portal_cfg->swportal_id,
						"SWP-id");
		if (err)
			return -err;
		return -EAGAIN;

	}

	dpmng->swportal_id[portal_cfg->index] = portal_cfg->swportal_id;

	return 0;
}

int dpmng_free_swportal(struct dpmng *dpmng,
	struct dpmng_portal_cfg *portal_cfg)
{
	int err;

	portal_cfg->swportal_id = dpmng->swportal_id[portal_cfg->index];
	portal_cfg->swp = sys_get_handle(FSL_MOD_QBMAN_PORTAL, 1,
						portal_cfg->swportal_id);
	if (portal_cfg->swp == NULL)
		return -ENODEV;

	qbman_swp_finish(portal_cfg->swp);

	/* SW-Portal deallocation */
	err = deallocate_resource(dpmng->registration.resman_dev, "swp",
					portal_cfg->swportal_id, "SWP-id");
	if (err)
		return -err;
	return 0;
}

int dpmng_get_swportal(struct dpmng *dpmng, void **portal)
{
	int swportal_id;
	uint32_t core_id;

	ASSERT_COND(dpmng);
	core_id = core_get_id();
	/*	if (dpmng->sw_portal_lock[core_id] == LOCKED)
	 return LOCKED;
	 */
	/* lock here the software portal */
	/* dpmng->sw_portal_lock[core_id] = LOCKED; */
	swportal_id = dpmng->swportal_id[core_id];

	*portal = sys_get_handle(FSL_MOD_QBMAN_PORTAL, 1, swportal_id);
	ASSERT_COND(*portal);

	return 0;
}

int dpmng_put_swportal(struct dpmng *dpmng, void *portal)
{
//	struct qbman_block *qman_hndl = sys_get_unique_handle(FSL_MOD_QBMAN);
	//uint32_t core_id = 0;

	//core_id = core_get_id();
	/* check that the portal belongs to the one that called this routine */
	//if (dpmng->swportal_id[core_id] != portal)
	//return error  - can't unlock this portal because it's not
	//belong to you
	/*	if (dpmng->sw_portal_lock[core_id] != LOCKED)
	 return 0;
	 */
	/* unlock here the software portal */
	/* dpmng->sw_portal_lock[core_id] = UNLOCKED; */
	return 0;
}

void *dpmng_get_scratch(struct dpmng *dpmng)
{
	if (dpmng->scratch_memory.inuse)
		return NULL;
	
	dpmng->scratch_memory.inuse = 1;
	return dpmng->scratch_memory.data;
}

void dpmng_put_scratch(struct dpmng *dpmng)
{
	dpmng->scratch_memory.inuse = 0;
}

int dpmng_get_scratch_size(struct dpmng *dpmng)
{
	if (dpmng->scratch_memory.inuse)
		return SIZE_SCRATCH_MAP;
	else
		return 0;
}

int dpmng_init_cgid(struct dpmng *dpmng)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr cgr_desc;
	int err;

	err = allocate_resource(dpmng->registration.resman_dev, "cg", 1, 1, 0,
				&dpmng->cgid, "CG-id");
	if (err)
		return err;

	qbman_cgr_attr_clear(&cgr_desc);
	qbman_cgr_attr_set_mode(&cgr_desc, 0, 0);
	qbman_cgr_attr_set_td_ctrl(&cgr_desc, 1);
	qbman_cgr_attr_set_td_thres(&cgr_desc, 0);

	dpmng_get_swportal(dpmng, (void**)&sw_portal);
	err = qbman_cgr_configure(sw_portal, (uint32_t)dpmng->cgid, &cgr_desc);
	dpmng_put_swportal(dpmng, (void*)sw_portal);
	if (err) {
		deallocate_resource(dpmng->registration.resman_dev, "cg",
					dpmng->cgid, "CG-id");
		return err;

	}

	return 0;
}

int dpmng_get_cgid(struct dpmng *dpmng)
{
	ASSERT_COND(dpmng);

	return dpmng->cgid;
}

#ifdef TKT011436
int dpmng_restore_plcrid(struct dpmng *dpmng)
{
	struct dppolicer_profile_cfg policer = { 0 };
	struct dppolicer *ing_dppolicer;
	int eiop_id = 0, err;

	ing_dppolicer = sys_get_handle(FSL_MOD_POLICER, 2, eiop_id,
					CTLU_EIOP_INGRESS);
	CHECK_COND_RETVAL(ing_dppolicer, -EINVAL, "Cannot get ingress dppolicer handle\n");

	policer.alg = DPPPLICER_PASS_THROUGH;
	policer.default_color = DPPPLICER_GREEN;
	err = dppolicer_init_profile(ing_dppolicer, dpmng->plcrid, NULL,
					&policer);
	CHECK_COND_RETVAL(err == 0, err, "dppolicer_init_profile Failed\n");

	return err;
}
#endif /* TKT011436 */

int dpmng_init_plcrid(struct dpmng *dpmng)
{
	struct dppolicer_profile_cfg policer = { 0 };
	struct dppolicer *ing_dppolicer;
	char type[16];
	int eiop_id = 0, err;

	ing_dppolicer = sys_get_handle(FSL_MOD_POLICER, 2, eiop_id,
					CTLU_EIOP_INGRESS);
	ASSERT_COND(ing_dppolicer);

	snprintf(type, sizeof(type), "plcr.wr%d.ctlui", eiop_id);
	err = allocate_resource(dpmng->registration.resman_dev, type, 1, 1, 0,
				&dpmng->plcrid, "plcr-id");
	if (err)
		return err;

	policer.alg = DPPPLICER_PASS_THROUGH;
	policer.default_color = DPPPLICER_GREEN;
	err = dppolicer_init_profile(ing_dppolicer, dpmng->plcrid, NULL,
					&policer);
	if (err) {
		deallocate_resource(dpmng->registration.resman_dev, type,
					dpmng->plcrid, "plcr-id");
		return err;
	}

	return 0;
}

int dpmng_get_plcrid(struct dpmng *dpmng)
{
	ASSERT_COND(dpmng);

	return dpmng->plcrid;
}

int dpmng_get_aiop_container_id(struct dpmng *dpmng)
{
	ASSERT_COND(dpmng);

	return dpmng->aiop_container_id;
}

void dpmng_set_mc_status(uint32_t status)
{
	struct mc_desc mc_desc;
	uint32_t *mc_gsr_reg;
	int err;

	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, 0);
	ASSERT_COND(!err);

	mc_gsr_reg = (uint32_t *)PTR_MOVE(mc_desc.vaddr, 0x8);

	/* Add status */
	iowrite32(status, mc_gsr_reg);
}

uint32_t dpmng_get_mc_status(void)
{
	struct mc_desc mc_desc;
	uint32_t *mc_gsr_reg;
	int err;

	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, 0);
	ASSERT_COND_LIGHT(!err);

	mc_gsr_reg = (uint32_t *)PTR_MOVE(mc_desc.vaddr, 0x8);

	return (ioread32(mc_gsr_reg) & GSR_STATUS_MASK);
}

phys_addr_t dpmng_get_mc_mem_base(void)
{
	struct mc_desc mc_desc = { 0 };
	phys_addr_t mc_mem_paddr;
	uint32_t mcfbalr, mcfbahr;
	int err;

	err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, 0);
	ASSERT_COND(!err);

	mcfbalr = ioread32((uint32_t *)PTR_MOVE(mc_desc.vaddr, 0x20));
	mcfbahr = ioread32((uint32_t *)PTR_MOVE(mc_desc.vaddr, 0x24));
	/* Mask out reserved bits */
	mcfbalr &= MCFBALR_MASK;
	mcfbahr &= MCFBAHR_MASK;

	mc_mem_paddr = (phys_addr_t)(
		(uint64_t)mcfbalr | ((uint64_t)mcfbahr << 32));

	return mc_mem_paddr;
}

int dpmng_port_add_channel_to_recycle(struct dpmng *dpmng,
	const struct dpmng_channel_cfg *channel)
{
	return 0;
}

int dpmng_port_set_channel_to_phys(struct dpmng *dpmng,
	const struct dpmng_port_cfg *port,
	const struct dpmng_channel_cfg *channel)
{

	return 0;
}

#define MCFAPR_ICID_MASK 		0x00007FFF
#define MCFAPR_VA_MASK 			0x00010000
#define MCFAPR_BMT_MASK 		0x00020000
#define MCFAPR_PL_MASK 			0x00040000

void dpmng_get_amq(struct dpmng_amq *amq)
{
	struct mc_desc mc_desc;
	uint64_t tmp;
	uint32_t *mcfapr_reg;
	int err;

	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, 0);
	ASSERT_COND(!err);

	mcfapr_reg = (uint32_t *)PTR_MOVE(mc_desc.vaddr, 0x28);

	tmp = ioread32(mcfapr_reg);

	amq->bdi = DPMNG_AMQ_BDI; /* Bypass LDPAA Isolation */
	amq->bmt = (int)((tmp & MCFAPR_BMT_MASK) >> 17);
	amq->icid = (uint16_t)(tmp & MCFAPR_ICID_MASK);
	amq->pl = (int)((tmp & MCFAPR_PL_MASK) >> 18);
	amq->va = (int)((tmp & MCFAPR_VA_MASK) >> 16);
	pr_debug(
		"AMQ parameters read from MCFAPR:\nbmt  %d\n icid 0x%x\n pl %d\n va %d\n", amq->bmt, amq->icid, amq->pl, amq->va);

}

void *dpmng_mc_set_soc_window(phys_addr_t paddr, struct dpmng_amq *dpmng_amq)
{
	struct mc_bt_desc mc_bt_desc;
	struct mc_desc mc_desc;
	phys_addr_t aligned_paddr;
	int err;
	uint32_t c1sawapr_val = 0;

	memset(&mc_bt_desc, 0, sizeof(mc_bt_desc));
	mc_bt_desc.core_id = 1;
	err = sys_get_desc(SOC_MODULE_MC_BT, SOC_DB_MC_BT_DESC_CORE_ID,
				&mc_bt_desc, NULL);
	ASSERT_COND(!err);

	/* align physical address to 2G possible window size */
	aligned_paddr = (paddr & 0xFFFFFFFF80000000LL);

	/* Initialize SoC internal access window to point
	 * to peripheral space of appropriate AIOP tile */
	iowrite32((uint32_t)(aligned_paddr), mc_bt_desc.vaddr);
	iowrite32((uint32_t)(aligned_paddr >> 32),
			PTR_MOVE(mc_bt_desc.vaddr, 0x4));

	/* Prepare the value to write into C1SAWAPR Register*/
	c1sawapr_val = dpmng_amq->icid;
	if (dpmng_amq->bmt)
		c1sawapr_val |= DPMNG_AMQ_BMT_MASK;
	if (dpmng_amq->pl)
		c1sawapr_val |= DPMNG_AMQ_PL_MASK;
	if (dpmng_amq->va)
		c1sawapr_val |= DPMNG_AMQ_VA_MASK;

	iowrite32(c1sawapr_val, PTR_MOVE(mc_bt_desc.vaddr, 0x8));

	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, SOC_DB_NO_MATCH_FIELDS, &mc_desc,
				NULL);
	ASSERT_COND(!err);
	return (void *)((uintptr_t)mc_desc.soc_int_addr_map
			+ (uintptr_t)(paddr - aligned_paddr));
}

void *dpmng_mc_set_ccsr_window(phys_addr_t paddr, struct dpmng_amq *dpmng_amq)
{
	phys_addr_t aligned_paddr;
	uint32_t sicapr_val = 0;
	struct dpmng *dpmng;

	/* align physical address to SoC device space possible window size */
	aligned_paddr = (paddr & DPMNG_SDS_WINDOW_MASK);

	dpmng = sys_get_handle(FSL_MOD_DPMNG, 1, 0);
	ASSERT_COND(dpmng);

	dpmng->saved_reg0 = ioread32(PTR_MOVE(dpmng->mc_vaddr, 0x10));
	dpmng->saved_reg1 = ioread32(PTR_MOVE(dpmng->mc_vaddr, 0x14));
	dpmng->saved_reg2 = ioread32(PTR_MOVE(dpmng->mc_vaddr, 0x18));

	/* Initialize SoC internal access window to point
	 * to peripheral space of appropriate AIOP tile */
	iowrite32((uint32_t)(aligned_paddr), PTR_MOVE(dpmng->mc_vaddr, 0x10));
	iowrite32((uint32_t)(aligned_paddr >> 32),
			PTR_MOVE(dpmng->mc_vaddr, 0x14));

	/* Prepare the value to write into C1SAWAPR Register*/
	sicapr_val = dpmng_amq->icid;
	if (dpmng_amq->bmt)
		sicapr_val |= DPMNG_AMQ_BMT_MASK;
	if (dpmng_amq->pl)
		sicapr_val |= DPMNG_AMQ_PL_MASK;
	if (dpmng_amq->va)
		sicapr_val |= DPMNG_AMQ_VA_MASK;

	iowrite32(sicapr_val, PTR_MOVE(dpmng->mc_vaddr, 0x18));

	return (void *)((uintptr_t)dpmng->soc_ccsr
			+ (uintptr_t)(paddr - aligned_paddr));
}

void dpmng_mc_revert_ccsr_window(void)
{
	struct dpmng *dpmng;

	dpmng = sys_get_handle(FSL_MOD_DPMNG, 1, 0);
	ASSERT_COND(dpmng);

	iowrite32(dpmng->saved_reg0, PTR_MOVE(dpmng->mc_vaddr, 0x10));
	iowrite32(dpmng->saved_reg1, PTR_MOVE(dpmng->mc_vaddr, 0x14));
	iowrite32(dpmng->saved_reg2, PTR_MOVE(dpmng->mc_vaddr, 0x18));
}

void dpmng_mc_lock_soc_window(struct dpmng *dpmng)
{

}

void dpmng_mc_unlock_soc_window(struct dpmng *dpmng)
{

}

void dpmng_mc_lock_ccsr_window(struct dpmng *dpmng)
{

}

void dpmng_mc_unlock_ccsr_window(struct dpmng *dpmng)
{

}

/* DMA address fix-up, AIOP apps use effective addresses when talking to MC */
static inline int get_addr_by_context(struct device *dev,
	dma_addr_t addrin,
	dma_addr_t *addrout)
{
	struct dpmng_dev_ctx dev_ctx;
	struct dpaiop *dpaiop;
	int err = 0;

	resman_get_dev_ctx(dev, &dev_ctx, 0);

	if (dev_ctx.type == DPMNG_CTX_TYPE_AIOP) {
		dpaiop = sys_get_handle(FSL_MOD_DPAIOP, 1, 0);
		ASSERT_COND(dpaiop);
		err = dpaiop_virt2phys(dpaiop, (uintptr_t)addrin, addrout);
	}
	else
		*addrout = addrin;

	return err;
}
/* translates a DMA address to an effective address MC can access, in the
 * context of a given device
 */
static int dpmng_address_translate(struct device *dev, dma_addr_t inaddr,
		void **addr, size_t *size)
{
	struct dpmng_dev_ctx dev_ctx;
	int err;

	err = get_addr_by_context(dev, inaddr, &inaddr);
	if (err)
		return err;

	resman_get_dev_ctx(dev, &dev_ctx, 0);
	*addr = dpmng_mc_set_soc_window(inaddr, &dev_ctx.amq);

	/* SoC window is aligned to 2G and its size is 2G so we cannot map
	 * a buffer over the 2G boundary
	 */
	*size = MIN(*size, DPMNG_SOC_WINDOW_SIZE -
			((DPMNG_SOC_WINDOW_SIZE-1) & (uint32_t)inaddr));
	return 0;
}

/* It checks if a dma/physical address (source) points to the same location as
a local address (destination) plus the MC Fw base address. */
int dpmng_is_same_local_mc_address(struct device *dev, phys_addr_t src_addr, intptr_t dst_local_addr)
{
	int same_address = 0;
	dma_addr_t translated_dma_add = 0;
	if (get_addr_by_context(dev, (dma_addr_t)src_addr, &translated_dma_add) == 0)
	{
		phys_addr_t mc_base = dpmng_get_mc_mem_base();
		if (mc_base + dst_local_addr == translated_dma_add)
		{
			same_address = 1;
		}
	}
	return same_address;
}

/* copy data to/from DMA memory in the context of a device. */
int dpmng_dev_memcpy(struct device *dev, void *local_addr, dma_addr_t dev_addr,
		size_t size, int from_device)
{
	void *src = NULL, *dst = NULL;
	int err = 0;
	size_t local_size;
	uint32_t irq_flags;

#ifdef DPMNG_DEV_COPY_USES_EDMA
	return dpmng_dma(dev,
			(from_device)?(uint64_t)dev_addr:(uint64_t)local_addr,
			(from_device)?(uint64_t)local_addr:(uint64_t)dev_addr,
			(uint32_t)size,
			(from_device)?DPMNG_DMA_IN:DPMNG_DMA_OUT);
#else

	/* we can only map up to a boundary of 2G, so potentially this copy should
	 * fetch more than one segment.
	 */
	do {
		local_size = size;

		irq_flags = core_local_irq_save();
		if (from_device) {
			/* read in */
			err = dpmng_address_translate(dev, dev_addr, &src, &local_size);
			dst = local_addr;

			/* invalidate caches to avoid copying stale data, MC caches but does not
			 * provide coherency for SoC window
			 */
			l1dcache_invalidate();
		} else {
			/* write out */
			src = local_addr;
			err = dpmng_address_translate(dev, dev_addr, &dst, &local_size);
		}

		if (!err)
			memcpy(dst, src, local_size);

		core_local_irq_restore(irq_flags);

		local_addr = (void*)((intptr_t)local_addr + local_size);
		dev_addr += local_size;
		size -= local_size;
	} while (size && !err);

	return err;
#endif
}

int dpmng_dma(struct device *dev,
	uint64_t src_addr,
	uint64_t dest_addr,
	uint32_t size,
	enum dpmng_dma_direction dma_dir)
{
	struct edma_queue *dma_queue;
	struct dpmng_dev_ctx dev_ctx;
	uint64_t dest;
	uint64_t src;
	int err;

	ASSERT_COND(src_addr);
	ASSERT_COND(dest_addr);

	/* check if source is AIOP and get the physical address */
	if (dma_dir == DPMNG_DMA_IN) {
		err = get_addr_by_context(dev, src_addr, &src);
		dest = dest_addr;
	} else {
		err = get_addr_by_context(dev, dest_addr, &dest);
		src = src_addr;
	}
	if (err)
		return err;

	/* Retrieve queue_0 that belongs to block 0 from the system*/
	dma_queue = sys_get_handle(FSL_MOD_EDMA_BLOCK_QUEUE, 3, 0,
					core_get_id()/*block_id*/,
					0/*queue_id*/);
	ASSERT_COND(dma_queue != NULL);

	/* Get container's AMQ from resman */
	resman_get_dev_ctx(dev, &dev_ctx, 0);

	return dpmng_dma_by_amq(&(dev_ctx.amq), src , dest, size, dma_dir);
}

int dpmng_dma_by_amq(struct dpmng_amq *src_amq,
		uint64_t src_addr,
		uint64_t dest_addr,
		uint32_t size,
		enum dpmng_dma_direction dma_dir)
{
	struct edma_queue *dma_queue;
	struct edma_transfer params;
	struct dpmng_amq mc_amq;
	enum transac_status status;
	int rc = 0;

	ASSERT_COND(src_addr);
	ASSERT_COND(dest_addr);

	/* Retrieve queue_0 that belongs to block 0 from the system*/
	dma_queue = sys_get_handle(FSL_MOD_EDMA_BLOCK_QUEUE, 3, 0,
					core_get_id()/*block_id*/,
					0/*queue_id*/);
	ASSERT_COND(dma_queue != NULL);

	/* Get MC's AMQ */
	dpmng_get_amq(&mc_amq);

	/* Set transaction parameters */
	memset(&params, 0, sizeof(params));
	params.src = (dma_addr_t)src_addr;
	params.dst = (dma_addr_t)dest_addr;
	params.byte_count = size;
	if (dma_dir == DPMNG_DMA_IN) {
		params.src_icid = src_amq->icid;
		params.dst_icid = mc_amq.icid;

		/* Destination address is an internal address */
		params.flags |= EDMA_DEST_ADDR_IA;
		if (mc_amq.pl) {
			params.flags |= EDMA_DEST_ADDR_PL;
			if (mc_amq.bmt)
				params.flags |= EDMA_DEST_ADDR_BMT;
		}

		/* Source address is an external address */
		if (src_amq->pl) {
			params.flags |= EDMA_SRC_ADDR_PL;
			if (src_amq->bmt)
				params.flags |= EDMA_SRC_ADDR_BMT;
		}
	} else { //mc is the source
		params.src_icid = mc_amq.icid;
		params.dst_icid = src_amq->icid;

		/* Source address is an internal address */
		params.flags |= EDMA_SRC_ADDR_IA;
		if (mc_amq.pl) {
			params.flags |= EDMA_SRC_ADDR_PL;
			if (mc_amq.bmt)
				params.flags |= EDMA_SRC_ADDR_BMT;
		}

		/* Destination address is an external address */
		if (src_amq->pl) {
			params.flags |= EDMA_DEST_ADDR_PL;
			if (src_amq->bmt)
				params.flags |= EDMA_DEST_ADDR_BMT;
		}
	}
	/* Enqueue to eDMA */
	rc = edma_queue_transfer(dma_queue, &params, &status);
	if (0 != rc || EDMA_NORMAL != status) {
		pr_err("DMA transfer failed\n");
		return -EIO;
	}

	if (dma_dir == DPMNG_DMA_IN)
		fetch(UINT_TO_PTR(dest_addr), size);

	pr_debug("DMA success\n");
	return 0;
}
uint32_t dpmng_last_rerr_isr = 0;

#define MAX_DEQUEUE_FRAMES 16
/* should be inside the 'dpmng_clear_fqid' but there is a compiler issue */
static struct qbman_result dq_storage[MAX_DEQUEUE_FRAMES] __attribute__ ((aligned(64)));

#define QBMAN_DQ_INIT_TOKEN 0x55
#define QBMAN_DQ_CMD_TOKEN 0xab

#define QBMAN_ISR_RERR_DQ_MASK 0x07030f2d
#define CHANNEL_DQ_TRIES 100

void dpmng_clear_channel(uint32_t channel_id)
{
	phys_addr_t dq_storage_phys;
	struct qbman_swp *sw_portal;
	struct qbman_pull_desc pulldesc;
	struct qbman_result *dq;
	struct dpmng *dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	int ret;
	uint32_t dq_frames = 0;
	uint32_t dq_fq_frames;
	uint32_t fqid;
	uint32_t flags;
	int response_verb;
	struct qbman_desc qman_desc = {0};
	struct qbman_attr fq_state = {0};
	int retire_pending;
	int dq_tries = CHANNEL_DQ_TRIES;
	pr_info("dpmng_clear_channel: start clearing CH[%d]\n",
			channel_id);
	ret = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS, &qman_desc, 0);
	CHECK_COND_RET(ret == 0,
				"dpmng_clear_channel: fail to get QMan properties\n");
	dpmng_get_swportal(dpmng, (void**)&sw_portal);
	do {
		qbman_result_set_oldtoken(dq_storage, MAX_DEQUEUE_FRAMES,
						(uint8_t)QBMAN_DQ_INIT_TOKEN);
		dq_storage_phys = fsl_virt_to_phys(dq_storage);
		qbman_pull_desc_clear(&pulldesc);
		qbman_pull_desc_set_storage(&pulldesc, dq_storage,
						dq_storage_phys, 0);
		qbman_pull_desc_set_numframes(&pulldesc, MAX_DEQUEUE_FRAMES);
		qbman_pull_desc_set_token(&pulldesc, (uint8_t)QBMAN_DQ_CMD_TOKEN);
		qbman_pull_desc_set_channel(&pulldesc, channel_id,
				qbman_pull_type_active);
		dpmng_set_last_rerr_isr(0);
		sw_portal->vdq.busy = 0;
		ret = qbman_swp_pull(sw_portal, &pulldesc);
		if (ret) {
			pr_err("CH[%d]: fail to execute VDQ command, SWP[%d] busy\n",
				channel_id, sw_portal->sys.idx);
			break;
		}
		if (dpmng_rerr_isr_has_errors(QBMAN_ISR_RERR_DQ_MASK)) {
			pr_err("CH[%d]: fail to execute VDQ command, RERR_ISR:0x%x\n",
					channel_id, dpmng_last_rerr_isr);
			sw_portal->vdq.busy = 0;
			break;
		}
		dq = &dq_storage[0];
		dq_fq_frames = 0;
		while (1) {
			dq_tries = CHANNEL_DQ_TRIES;
			do {
				fetch(dq, sizeof(struct qbman_result));
				ret = qbman_result_has_newtoken(sw_portal, dq,
						(uint8_t)QBMAN_DQ_CMD_TOKEN);
			} while (!ret && (dq_tries-- > 0));
			if ((dq_tries <= 0) || qbman_result_DQ_is_pull_complete(dq))
				break;
			if(dq == &dq_storage[MAX_DEQUEUE_FRAMES-1])
				break;
			dq++;
			dq_fq_frames++;
		}
		fqid = qbman_result_DQ_fqid(dq);
		flags = qbman_result_DQ_flags(dq);
		response_verb = qbman_result_is_DQ(dq);
		/* If STAT bit 7 (FQ Empty) is 0 and STAT bit 4 (number of frames)
		is also 0, this indicates a null dequeue response, and in this case the
		FQID field is not valid. Such a response can be generated as the result
		of an error, or because a FQ which reached the head of a WQ was not
		eligible for dequeue (for example, Retirement Pending or FQ XOFF was
		asserted on this FQ). In the case of a null dequeue response due to an
		error, the specific error that occurred will be indicated in RERR_ISR */
		if ((flags & QBMAN_DQ_STAT_FQEMPTY) == 0 &&
			(flags & QBMAN_DQ_STAT_VALIDFRAME) == 0 &&
			dq_fq_frames == 0 &&
			response_verb) {
			/* check if retire pending on a valid FQID */
			if (qman_desc.num_int_fqs <= fqid || fqid < QBMAN_FIRST_FQID) {
				pr_info("dpmng_clear_channel: stopping VDQ on CH[%d] after "
				"reaching non-allocated FQ[%d]\n", channel_id, fqid);
				break;
			}
			pr_info("dpmng_clear_channel: no frames from CH[%d]/FQ[%d] after "
					"VDQ command\n", channel_id, fqid);
			memset(&fq_state, 0, sizeof fq_state);
			ret = qbman_fq_query_state(sw_portal, fqid, &fq_state);
			if (ret) {
				pr_err("dpmng_clear_channel: Fail to retrieve FQ[%d] state\n",
						fqid);
				break;
			}
			/* If the FQ is in the Truly Scheduled or Active states and the
			Retire FQ command was issued, the FQ state doesn't change
			immediately. Must check if the FQ is in intermediary state of
			retirement pending; if yes then continue dequeuing from the channel
			until the FQ becomes retired and is removed from the WQ	channel.*/
			if (!qbman_fq_state_retirement_pending(&fq_state)) {
				pr_info("dpmng_clear_channel: CH[%d]/FQ[%d] state:%d\n",
				channel_id, fqid, qbman_fq_state_schedstate(&fq_state));
				dpmng_clear_fqid(fqid, dq_storage, &retire_pending);
				continue; // try WQ reschedule
			}
		}
		dq_frames += dq_fq_frames;
		pr_info("dpmng_clear_channel: frames dequeued from CH[%d]/FQ[%d]: %d\n",
				channel_id, fqid, dq_fq_frames);
	} while ((dq_tries > 0) &&
			!(flags == (QBMAN_DQ_STAT_FQEMPTY | QBMAN_DQ_STAT_VOLATILE)));
	pr_info("dpmng_clear_channel: total frames dequeued from CH[%d]: %d\n",
			channel_id, dq_frames);
	dpmng_put_swportal(dpmng, (void*)sw_portal);
}

#define FQ_DQ_TRIES 100

void dpmng_clear_fqid(uint32_t fqid,
	struct qbman_result *retire_storage,
	int *retire_pending)
{
	phys_addr_t dq_storage_phys;
	struct qbman_swp *sw_portal;
	struct qbman_pull_desc pulldesc;
	struct qbman_attr state;
	struct qbman_result *dq;
	struct dpmng *dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	uint32_t loop = 0;
	uint32_t fqstate;
	int ret;
	int dq_tries = FQ_DQ_TRIES;


	dpmng_get_swportal(dpmng, (void**)&sw_portal);
	ret = qbman_fq_query_state(sw_portal, fqid, &state);
	dpmng_put_swportal(dpmng, (void*)sw_portal);
	CHECK_COND_RET(ret == 0, "Fail to get state for FQ[%d]\n", fqid);
	fqstate = qbman_fq_state_schedstate(&state);
	pr_info("dpmng_clear_fqid: FQ[%d] state:%d\n", fqid, fqstate);
	if (fqstate == qbman_fq_schedstate_oos)
		return;
	/* The Retire FQ command will fail on a retired queue */
	if (!(fqstate == qbman_fq_schedstate_retired)) {
		/* make sure this FQ is really in retirement pending */
		*retire_pending = qbman_fq_state_retirement_pending(&state);
		if (!*retire_pending) {
			pr_info("dpmng_clear_fqid: start retire FQ[%d]\n", fqid);
			dpmng_get_swportal(dpmng, (void**)&sw_portal);
			dq_storage_phys = fsl_virt_to_phys(retire_storage);
			ret = qbman_fq_retire_start(sw_portal, fqid, retire_storage,
					NULL, dq_storage_phys);
			dpmng_put_swportal(dpmng, (void*)sw_portal);
			CHECK_COND_RET(ret == 0, "Fail to retire FQ[%d]\n", fqid);
		} else {
			pr_info("dpmng_clear_fqid: FQ[%d] already in retirement pending\n",
					fqid);
		}
		ret = 0;
		while (!*retire_pending && !ret && (++loop < 100)) {
			fetch(retire_storage, sizeof(struct qbman_result));
			ret = qbman_fq_retire_is_finished(retire_storage);
			if( !ret ) {
				/*'Truly scheduled' state means the FQ is within a WQ and it
				contains frames. In order to retire it the FQ needs to be
				selected as next target FQ for dequeue in that WQ and then
				fetch all frames from it. Unfortunately, dequeuing from a WQ
				is unpredictable and may pull frames from an active FQ. Also,
				QMan does not provide a mechanism for triggering a FQ
				reschedule on a WQ other than the dequeue command.
				In this case the SW context that owns the FQ needs to
				manually drain it before reset or disable the DP object that
				uses this queue. There is also a ticket (TKT303334) to
				address this HW limitation.
				Since the FQ is in 'Truly scheduled' state there is no point
				in waiting to become retired in order to drain it.*/
				if (fqstate == qbman_fq_schedstate_truly_scheduled) {
					break;
				}
				timer_udelay(1000);
			}
		}
		if (!ret) {
			*retire_pending = 1;
			CHECK_COND_RET(0, "FQ[%d] retirement is pending\n", fqid);
		}
	}
	*retire_pending = 0;
	dpmng_get_swportal(dpmng, (void**)&sw_portal);
	uint32_t dequeued_frames = 0;
	/* Drain the FQ */
	do {
		qbman_result_set_oldtoken(dq_storage, MAX_DEQUEUE_FRAMES,
						(uint8_t)0x55);
		dq_storage_phys = fsl_virt_to_phys(dq_storage);
		qbman_pull_desc_clear(&pulldesc);
		qbman_pull_desc_set_storage(&pulldesc, dq_storage,
						dq_storage_phys, 0);
		qbman_pull_desc_set_numframes(&pulldesc, MAX_DEQUEUE_FRAMES);
		qbman_pull_desc_set_token(&pulldesc, 0xab);
		qbman_pull_desc_set_fq(&pulldesc, fqid);
		dpmng_set_last_rerr_isr(0); // needed to catch recoverable errors
		sw_portal->vdq.busy = 0;
		ret = qbman_swp_pull(sw_portal, &pulldesc);
		if (ret) {
			pr_err("FQ[%d] fail to execute VDQ command: SWP[%d] busy\n",
					fqid, sw_portal->sys.idx);
			break;
		}
		if (dpmng_rerr_isr_has_errors(QBMAN_ISR_RERR_DQ_MASK)) {
			pr_err("FQ[%d] fail to execute VDQ command: RERR_ISR:0x%x\n",
					fqid, dpmng_last_rerr_isr);
			break;
		}
		dq = &dq_storage[0];
		while (1) {
			dq_tries = FQ_DQ_TRIES;
			do {
				fetch(dq, sizeof(struct qbman_result));
				ret = qbman_result_has_newtoken(sw_portal, dq,
								0xab);
			} while (!ret && (dq_tries-- > 0));

			if ((dq_tries <= 0) || qbman_result_DQ_is_pull_complete(dq))
				break;

			if(dq == &dq_storage[MAX_DEQUEUE_FRAMES-1])
				break;

			dq++;
			dequeued_frames++;
		}
	} while ((dq_tries > 0) &&
			!(qbman_result_DQ_flags(dq) & QBMAN_DQ_STAT_FQEMPTY));
	pr_info("dpmng_clear_fqid: frames after VDQ from FQ[%d]: %d\n",
			fqid, dequeued_frames);
	if (dq_tries <= 0)
		pr_warn("Did not receive DQ complete for FQ[%d]\n", fqid);
	ret = qbman_fq_oos(sw_portal, fqid);
	dpmng_put_swportal(dpmng, (void*)sw_portal);
	CHECK_COND_RET(ret == 0, "Fail to move FQ[%d] to out-of-service\n", fqid);
	pr_info("dpmng_clear_fqid: FQ[%d] moved to out-of-service\n", fqid);
}

uint16_t dpmng_get_dcp_wqid(struct dpmng *dpmng, enum qbman_dcp dcp_type, uint8_t index)
{
	UNUSED(index);
	ASSERT_COND(dpmng);

	return dpmng->dcp_wqid[dcp_type];
}

int dpmng_init_dcp_wqid(struct dpmng *dpmng)
{
	struct qbman_desc qbman_desc;
	int err, i, iter = 0;

	memset(&qbman_desc, 0, sizeof(struct qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, &iter);
	if (err)
		return -1;

	for (i = 0; i < QBMAN_MAX_DCP; i++) {
		if (!qbman_desc.dcp[i].valid || qbman_desc.dcp[i].ceetm_support)
			continue;
		if (qbman_desc.dcp[i].num_fq_wq_channels > 16) {
			/* according to the qbman BG DCP0 cannot be assigned to 64 channels. */
			ASSERT_COND(i!=0);
			dpmng->dcp_wqid[qbman_desc.dcp[i].dcp_type] =
				(uint16_t)(0x800 + (0x40*(i-1)));
		} else {
			dpmng->dcp_wqid[qbman_desc.dcp[i].dcp_type] =
				(uint16_t)(0xe00 + (0x10*i));
		}
	}

	return 0;
}

int dpmng_init_rerr_fqid(struct dpmng *dpmng)
{
	struct qbman_swp *sw_portal;
	struct qbman_attr fqdesc;
	int err;

	/* initialize rerr-fqid */
	dpmng_get_swportal(dpmng, (void**)&sw_portal);
	qbman_fq_attr_clear(&fqdesc);
	/* Set tail-drop of 1000 to avoid overflow of PFDRs */
	qbman_fq_attr_set_fqctrl(&fqdesc, QBMAN_FQCTRL_TAILDROP);
	qbman_fq_attr_set_tdthresh(&fqdesc, 1000);
	/* fqid '0' not in used */
	err = qbman_fq_configure(sw_portal, QBMAN_REL_FQ_ID, &fqdesc);
	ASSERT_COND(!err);
	dpmng_put_swportal(dpmng, (void*)sw_portal);

	dpmng_set_last_rerr_isr(0);
	return 0;
}

/* Last RERR Interrupt Status set by QBman recoverable error ISR;
 However, in order to catch recoverable errors after a dequeue must clear
 the last status before each DQ command.
*/
void dpmng_set_last_rerr_isr(uint32_t rerr_status) {
	dpmng_last_rerr_isr = rerr_status;
}

uint32_t dpmng_rerr_isr_has_errors(uint32_t error_mask) {
	if (error_mask != 0) {
		return error_mask & dpmng_last_rerr_isr;
	}
	return dpmng_last_rerr_isr;
}

#define REL_FQ_DQ_TRIES FQ_DQ_TRIES

int dpmng_dump_rerr_fqid(struct dpmng *dpmng)
{
	phys_addr_t dq_storage_phys;
	struct qbman_swp *sw_portal;
	struct qbman_pull_desc pulldesc;
	struct qbman_result *dq;
	struct qbman_attr fq_attr;
	int ret, first = 1;
	uint32_t num;
	int dq_tries = REL_FQ_DQ_TRIES;

	dpmng_get_swportal(dpmng, (void**)&sw_portal);
	ret = qbman_fq_query_state(sw_portal, QBMAN_REL_FQ_ID, &fq_attr);
	if (ret) {
		pr_err("Fail to get REL_FQ (FQ[%d]) state\n", QBMAN_REL_FQ_ID);
		dpmng_put_swportal(dpmng, (void*)sw_portal);
		return -EINVAL;
	}
	num = qbman_fq_state_frame_count(&fq_attr);

	pr_err("REL_FQ (FQ[%d]) has %d messages, dumping up to %d:\n",
			QBMAN_REL_FQ_ID, num, MAX_DEQUEUE_FRAMES);
	/* Drain the REL_FQ */
	do {
		qbman_result_set_oldtoken(dq_storage, MAX_DEQUEUE_FRAMES,
						(uint8_t)0x55);
		dq_storage_phys = fsl_virt_to_phys(dq_storage);
		qbman_pull_desc_clear(&pulldesc);
		qbman_pull_desc_set_storage(&pulldesc, dq_storage,
						dq_storage_phys, 0);
		qbman_pull_desc_set_numframes(&pulldesc, MAX_DEQUEUE_FRAMES);
		qbman_pull_desc_set_token(&pulldesc, 0xab);
		qbman_pull_desc_set_fq(&pulldesc, QBMAN_REL_FQ_ID);
		sw_portal->vdq.busy = 0;
		ret = qbman_swp_pull(sw_portal, &pulldesc);
		if (ret) {
			pr_err(
			"Fail to execute VDQ command on REL_FQ(FQ[%d]): SWP[%d] busy\n",
			QBMAN_REL_FQ_ID, sw_portal->sys.idx);
			break;
		}
		dq = &dq_storage[0];
		while (1) {
			dq_tries = REL_FQ_DQ_TRIES;
			do {
				fetch(dq, sizeof(struct qbman_result));
				if (first) {
					pr_err("\tMessage:\n");
					mem_disp(
						(uint8_t*)dq,
						sizeof(struct qbman_result));
				}
				ret = qbman_result_has_newtoken(sw_portal, dq,
								0xab);
			} while (!ret && (dq_tries-- > 0));
			if ((dq_tries <= 0) || qbman_result_DQ_is_pull_complete(dq))
				break;
			if(dq == &dq_storage[MAX_DEQUEUE_FRAMES-1])
				break;
			dq++;
		}
		first = 0;
	} while ((dq_tries > 0) &&
			 !(qbman_result_DQ_flags(dq) & QBMAN_DQ_STAT_FQEMPTY));
	dpmng_put_swportal(dpmng, (void*)sw_portal);
	return 0;
}

void dpmng_set_rate_limit(struct dpmng *dpmng, uint64_t rate)
{
	dpmng->shaper_rate_limit = rate;
}

int dpmng_is_rate_allowed(struct dpmng *dpmng, uint64_t rate)
{
	if (rate <= dpmng->shaper_rate_limit)
		return 1;
	else
		return 0;
}

uint64_t dpaa_sys_ddr_base;
uint64_t dpaa_sys_ddr_size;
uint64_t dpaa_lcfg_base;
uint64_t dpaa_lcfg_size;
/* second ddr partition created when MC mem size >= 1GB or/and
 the dpc 'mc_sys_ddr_start_address' property exists. */
uint64_t mc_sysddr2_ph_base = 0ULL;
uint64_t mc_sys_ddr2_size = 0ULL;
uintptr_t mc_sys_ddr2_virt_add_base = 0UL;

#define MCFBALR_ADDR_MASK 0xE0000000
#define MCFBALR_NUM_BLOCKS_MASK 0x000000FF
#define DPAA_MC_SMALL_IMAGE		0x100

static int dpaa_tiny_image = 0;

int dpmng_mctiny( void )
{
	return dpaa_tiny_image;
}

void dpmng_set_dpaa_sys_ddr_region(void)
{
	int num_blocks = 0;
	uint64_t mc_base;
	uint32_t mcfbalr, mcfbahr;
	struct mc_desc mc_desc;
	int err;

	memset(&mc_desc, 0, sizeof(mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, 0);
	ASSERT_COND(!err);

	mcfbalr = ioread32((uint32_t *)PTR_MOVE(mc_desc.vaddr, 0x20));
	mcfbahr = ioread32((uint32_t *)PTR_MOVE(mc_desc.vaddr, 0x24));

	mc_base = ((uint64_t)mcfbahr << 32) | (mcfbalr & MCFBALR_ADDR_MASK);
	num_blocks = (int)((mcfbalr & MCFBALR_NUM_BLOCKS_MASK) + 1);

	if (num_blocks == DPAA_MC_SMALL_IMAGE ) {
		// MC uses a total of 128Mb
		dpaa_sys_ddr_base = mc_base + (96 * MEGABYTE);
		dpaa_sys_ddr_size = (128-96) * (uint64_t)MEGABYTE;
		dpaa_tiny_image = 1;
	} else if (num_blocks == 1) {
		dpaa_sys_ddr_base = mc_base + (128 * MEGABYTE);
		dpaa_sys_ddr_size = 128 * (uint64_t)MEGABYTE;
	} else if (num_blocks == 2) {
		dpaa_sys_ddr_base = mc_base + (256 * (uint64_t)MEGABYTE);
		dpaa_sys_ddr_size = 256 * (uint64_t)MEGABYTE;
	} else if (num_blocks % 2) { //uneven
		dpaa_sys_ddr_base = mc_base
					- (num_blocks - 1)
						* 256 * (uint64_t)MEGABYTE;dpaa_sys_ddr_size = (num_blocks - 1) * 256 * (uint64_t)MEGABYTE;
	}
	else { //even
		dpaa_sys_ddr_base = mc_base - (num_blocks - 2) * DPMNG_DDR_BLOCK_SIZE;
		dpaa_sys_ddr_size = (num_blocks - 2) * DPMNG_DDR_BLOCK_SIZE;
		/* create the 2nd ddr partition when MC receives >= 1GB of sys-DDR,
		located at 256MB from MC base address and has at least 256MB; the final
		value depends on the dpc 'mc_sys_ddr_start_address' property */
		if (num_blocks >= 4) {
			mc_sys_ddr2_size = DPMNG_DDR_BLOCK_SIZE;
			mc_sys_ddr2_virt_add_base = DPMNG_DDR_BLOCK_SIZE;
			mc_sysddr2_ph_base = mc_base + DPMNG_DDR_BLOCK_SIZE;
		}
	}
	if (num_blocks == DPAA_MC_SMALL_IMAGE ) {
		dpaa_lcfg_base =
					(mc_base > dpaa_sys_ddr_base) ? dpaa_sys_ddr_base : mc_base;
		dpaa_lcfg_size = 128 * (uint64_t)MEGABYTE;
	}
	else {
		dpaa_lcfg_base =
			(mc_base > dpaa_sys_ddr_base) ? dpaa_sys_ddr_base : mc_base;
		dpaa_lcfg_size = num_blocks * 256 * (uint64_t)MEGABYTE;

		if( num_blocks > 1 )
		{
			// extend the size for the non-cacheable memory
			g_system_ddr1_non_cacheable_size = g_system_ddr1_non_cacheable_size + g_system_ddr1_cacheable_size;
			// move cacheable memory into a bigger area
			g_system_ddr1_cacheable_offset = 128*MEGABYTE;
			g_system_ddr1_cacheable_size   = 128*MEGABYTE;
		}
	}

}

void dpmng_dump(struct dpmng *dpmng)
{
}

#ifndef DPMNG3_0
static int connections_init_mallocate(struct dpmng *dpmng)
{
	/*!
	 * 	Allocate memory
	 * 		- EIOP
	 * 		- DCP
	 * 		- Physical connections
	 * 		- Virtual connections
	 * 		- Recycle path ports
	 */
	int err = 0, i;

	/*! Allocate EIOP */
	dpmng->num_iops = get_num_iop();
	dpmng->iop = fsl_malloc(sizeof(struct dpmng_iop) * dpmng->num_iops);

	ASSERT_COND(dpmng->iop);

	for (i = 0; i < dpmng->num_iops; i++) {
		err = connections_init_mallocate_dcps(dpmng, i);
		if (err != 0)
			break;
	}
	return err;
}

static int connections_init_mallocate_dcps(struct dpmng *dpmng, int iop_id)
{
	int i;

	/*! Allocate DCP */
	dpmng->iop[iop_id].num_dcps = get_num_dcp(iop_id);
	dpmng->iop[iop_id].dcp = fsl_malloc(
		sizeof(struct dpmng_dcp) * dpmng->iop[iop_id].num_dcps);

	ASSERT_COND(dpmng->iop[iop_id].dcp);

	for (i = 0; i < dpmng->iop[iop_id].num_dcps; i++) {
		/*! Allocate Physical connections */
		dpmng->iop[iop_id].dcp[i].num_phys = get_num_phys(iop_id, i);
		dpmng->iop[iop_id].dcp[i].phys_conn = fsl_malloc(
			sizeof(struct dpmng_phys_connection)
			* dpmng->iop[iop_id].dcp[i].num_phys);
		ASSERT_COND(dpmng->iop[iop_id].dcp[i].phys_conn);

		/*! Allocate virtual connections */
		dpmng->iop[iop_id].dcp[i].num_virt = get_num_virt(iop_id, i);
		dpmng->iop[iop_id].dcp[i].virt_conn = fsl_malloc(
			sizeof(struct dpmng_virt_connection)
			* dpmng->iop[iop_id].dcp[i].num_virt);
		ASSERT_COND(dpmng->iop[iop_id].dcp[i].virt_conn);

		/*! Allocate recycle */
		dpmng->iop[iop_id].dcp[i].num_recycle = get_num_recycle(iop_id,
									i);
		dpmng->iop[iop_id].dcp[i].recycle = fsl_malloc(
			sizeof(struct dpmng_recycle)
			* dpmng->iop[iop_id].dcp[i].num_recycle);
		ASSERT_COND(dpmng->iop[iop_id].dcp[i].recycle);

	}

	return 0;
}

static int connections_init_phys(struct dpmng *dpmng)
{
	/*
	 * go over SOC_MODULE_DPMNG_PHY_CONNECTIONS descriptor
	 * call interface init
	 */
	int err = 0, i, j, iter, id;
	//struct dpmng_phys_connection_desc desc;
	struct pport_connections_desc desc;

	for (i = 0; i < dpmng->num_iops; i++) {
		for (j = 0; j < dpmng->iop[i].num_dcps; j++) {

			memset(&desc, 0x0,
				sizeof(struct pport_connections_desc));

			desc.eiop_id = i; /*! wriop id*/
			desc.dcp_id = j; /*! dcp id */
			iter = 0; /*! iterator */
			id = 0;
			while (sys_get_desc(
				SOC_MODULE_EIOP_PPORT_CON,
				SOC_DB_PORT_CON_DESC_DCP_ID
				| SOC_DB_PORT_CON_DESC_EIOP_ID,
				&desc, &iter)
				== 0) {
				
				pr_info("Mac[%d] ceetm %d lni %d\n",desc.mac_id ,desc.ceetm_id ,desc.lni_id);
				
				/*! Init physical interface */
				err = connections_init_phys_if(dpmng, id++,
								&desc);
				if (err != 0)
					return err;
				memset(&desc, 0,
					sizeof(struct pport_connections_desc));
			}
		}
	}
	return err;
}

static int connections_init_phys_if(struct dpmng *dpmng,
	int id,
	struct pport_connections_desc *desc)
{
	/*
	 * 	- Save information from descriptor
	 * 	- Allocate CQCH
	 * 	- Allocate lni
	 * 	- init ppid
	 * 	- bind lni to sp - qbman_subportal_configure
	 */
	int err = 0;
	struct dpmng_phys_connection *phys_conn;

	/*! Obtain connection */
	phys_conn =
		&(dpmng->iop[desc->eiop_id].dcp[desc->dcp_id].phys_conn[id]);

	/*! Save information from descriptor */
	phys_conn->ppid = desc->port_id; /*! Physical port */
	phys_conn->mac_id = desc->mac_id; /*! mac id */
	phys_conn->lniid = desc->lni_id; /*! lni id */
	phys_conn->ap.ceetm_id = desc->ceetm_id;/*! CEETM ID */
	phys_conn->ap.iop_id = desc->eiop_id;
	phys_conn->ap.dcp_id = desc->dcp_id;

	/*! Init QMan related */
	err = connections_init_phys_if_qbman(dpmng, id, desc, 1, 0);
	if (err != 0)
		return err;

	/*! Init EIOP port */
	//err = connections_init_phys_if_eiop(dpmng, id, desc);
	return err;
}

static int connections_init_phys_if_qbman(struct dpmng *dpmng,
	int id,
	struct pport_connections_desc *conn_desc,
	int txstate,
	int wriop_reset)
{
	int err;
	char type[16];
	struct dpmng_phys_connection *phys_conn;
	struct eiop_port_desc port_desc;
	int spid;
	void *swp;
	uint32_t ceetmid;

	/*! Obtain connection */
	phys_conn =
		&(dpmng->iop[conn_desc->eiop_id].dcp[conn_desc->dcp_id].phys_conn[id]);

	if(!wriop_reset){
		err = connections_init_endpoint(dpmng, &(phys_conn->ap));
		CHECK_COND_RETVAL(err == 0, err, "connections_init_endpoint FAILED\n");
	
		/*! Allocate LNI */
		snprintf(type, sizeof(type), "lni.ctm%d.ins%d", conn_desc->dcp_id,
				conn_desc->ceetm_id);
		err = allocate_resource(dpmng->registration.resman_dev, /* Resource Manager handle */
					type, /* Resource type */
					1, /* Number of resources*/
					phys_conn->lniid, /* Base align */
					DPRC_RES_REQ_OPT_EXPLICIT, /* Options */
					&(phys_conn->lniid), /* Address */
					"LNIID"); /* Error string */
		CHECK_COND_RETVAL(err == 0, err, "allocate_resource FAILED\n");
	}
	/*! Get physical port descriptor */
	memset(&port_desc, 0x0, sizeof(struct eiop_port_desc));
	port_desc.eiop_id = conn_desc->eiop_id;
	port_desc.port_id = conn_desc->port_id;
	err = sys_get_desc(SOC_MODULE_EIOP_PORT,
				SOC_DB_PORT_DESC_EIOP_ID | SOC_DB_PORT_DESC_ID,
				&port_desc, NULL);
	ASSERT_COND(err == 0);

	/*! Obtain Sub-portal */
	eiop_port_tx_get_dsp(&port_desc, &spid);

	/*! Compose ceetm id */
	ceetmid = qbman_ceetmid_compose((uint8_t)conn_desc->dcp_id,
					(uint8_t)conn_desc->ceetm_id);

	/*! Get software portal */
	err = dpmng_get_swportal(dpmng, &(swp));
	CHECK_COND_RETVAL(err == 0, err, "dpmng_get_swportal FAILED\n");

	/*! Sub-Portal Map to LNI */
	err = qbman_subportal_configure(swp, /* CEETM SW Portal */
					ceetmid, /* CEETM ID */
					(uint8_t)spid, /* Sub-Portal ID */
					(uint8_t)(conn_desc->lni_id), /* LNI ID */
					txstate); /* TX STATE */
	CHECK_COND_RETVAL(err == 0, err, "qbman_subportal_configure FAILED\n");

	if(!wriop_reset){
		err = qbman_lni_shaper_disable(swp, ceetmid,
						(uint32_t)conn_desc->lni_id, 24);
		CHECK_COND_RETVAL(err == 0, err, "qbman_lni_shaper_disable FAILED\n");
	}
	/*! Put software portal */
	err = dpmng_put_swportal(dpmng, swp);
	CHECK_COND_RETVAL(err == 0, err, "dpmng_put_swportal FAILED\n");

	return err;
}

static int connections_init_endpoint(struct dpmng *dpmng,
	struct dpmng_accesspoint *ap)
{
	/*
	 * 	Allocate from resource manager
	 * 		- cqchid
	 * 		- dctidx[8]
	 * 		- lfqmtidx[64]
	 * 		- IFP
	 */
	int err = 0;
	char type[16];

	/*! Allocate dctidx[8] */
	snprintf(type, sizeof(type), "dct.ctm%d.ins%d", ap->dcp_id,
			ap->ceetm_id);
	err = allocate_resource(dpmng->registration.resman_dev, /*Resource manager handle */
				type, /* Resource type */
				DPMNG_MAX_DCTIDX_ALLOC, /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				&(ap->dctidx[0]), /* Address */
				"DCTIDX"); /* Error string */
	if (err != 0)
		return err;

	/*! Allocate IFP here */
	return err;
}

static int connections_init_virt(struct dpmng *dpmng)
{
	/*
	 * go over SOC_MODULE_DPMNG_PHY_CONNECTIONS descriptor
	 * call virtual interface init
	 */
	int err = 0, i, j, k;

	for (i = 0; i < dpmng->num_iops; i++) {
		for (j = 0; j < dpmng->iop[i].num_dcps; j++) {
			for (k = 0; k < dpmng->iop[i].dcp[j].num_virt; k++) {
				/*! Init Virtual connection */
				err = connections_init_virt_if(dpmng, /*! Context */
								i, /*! eiop id*/
								j, /*! dcp id */
								k /*! connection id */
								);
				if (err != 0)
					return err;
			}
		}
	}
	return err;
}

static int connections_init_virt_if(struct dpmng *dpmng,
	int iop_id,
	int dcp_id,
	int id)
{
	int err = 0;
	struct dpmng_virt_connection *virt_conn;
	int num_ceetm_inst;

	/*! Obtain connection */
	virt_conn = &(dpmng->iop[iop_id].dcp[dcp_id].virt_conn[id]);

	num_ceetm_inst = get_num_ceetm_instances(iop_id, dcp_id);

	/*! Save required information */
	virt_conn->inuse = 0;
	virt_conn->ap[0].ceetm_id = 0;
	virt_conn->ap[0].iop_id = iop_id;
	virt_conn->ap[0].dcp_id = dcp_id;

	virt_conn->ap[1].ceetm_id = 1 % num_ceetm_inst;
	virt_conn->ap[1].iop_id = iop_id;
	virt_conn->ap[1].dcp_id = dcp_id;

	/*! Allocate resource for end-point #0 */
	err = connections_init_endpoint(dpmng, &(virt_conn->ap[0]));
	if (err != 0)
		return err;

	/*! Allocate resource for end-point #1 */
	err = connections_init_endpoint(dpmng, &(virt_conn->ap[1]));
	if (err != 0)
		return err;

	return err;
}

static int connections_init_recycle(struct dpmng *dpmng, int wriop_reset)
{
	/*
	 * go over SOC_MODULE_DPMNG_PHY_CONNECTIONS descriptor
	 * call virtual interface init
	 */
	int err = 0, i, j, iter, id;
	struct vport_connections_desc desc;

	for (i = 0; i < dpmng->num_iops; i++) {
		for (j = 0; j < dpmng->iop[i].num_dcps; j++) {

			memset(&desc, 0x0,
				sizeof(struct vport_connections_desc));

			desc.eiop_id = i; /*! wriop id*/
			desc.dcp_id = j; /*! dcp id */
			iter = 0; /*! iterator */
			id = 0;
			while (sys_get_desc(
				SOC_MODULE_EIOP_VPORT_CON,
				SOC_DB_PORT_CON_DESC_EIOP_ID
				| SOC_DB_PORT_CON_DESC_DCP_ID,
				&desc, &iter)
				== 0) {
				/*! Init physical interface */
				err = connections_init_recycle_port(dpmng,
									id++,
									&desc,
									wriop_reset);
				if (err != 0)
					return err;
				memset(&desc, 0,
					sizeof(struct vport_connections_desc));
			}
		}
	}
	return err;
}

static int connections_init_recycle_port(struct dpmng *dpmng,
	int id,
	struct vport_connections_desc *recycle_desc,
	int wriop_reset)
{
	int err = 0;
	struct dpmng_recycle *recycle;

	/*! Obtain recycle entry */
	recycle =
		&(dpmng->iop[recycle_desc->eiop_id].\
dcp[recycle_desc->dcp_id].recycle[id]);

	/*! Save required info */
	recycle->ceetm_id = recycle_desc->ceetm_id;
	recycle->lniid = recycle_desc->lni_id;
	recycle->ppid = recycle_desc->port_id;
	
	/* After WRIOP reset the QBMAN staff have not made*/
	if(!wriop_reset){
		/*! Init QMan staff */
		err = connections_init_recycle_port_qbman(dpmng, id, recycle_desc, 1, wriop_reset);
		if (err != 0)
			return err;
	}
	/*! Init recycle path port */
	err = connections_init_recycle_port_eiop(dpmng, id, recycle_desc);

	return err;
}

static int connections_init_recycle_port_qbman(struct dpmng *dpmng,
	int id,
	struct vport_connections_desc *recycle_desc,
	int txstate,
	int wriop_reset)
{
	/*
	 * 	-Allocate LNI
	 * 	-Obtain port descriptor
	 * 	-Obtain Sub-portal
	 * 	-Sub-Portal Map to LNI
	 */
	int err, spid;
	struct dpmng_recycle *recycle;
	char type[16];
	struct eiop_port_desc port_desc;
	void *swp;
	uint32_t ceetmid;

	/*! Obtain recycle entry */
	recycle =
		&(dpmng->iop[recycle_desc->eiop_id].dcp[recycle_desc->dcp_id].recycle[id]);

	/* Allocate LNI */
	if(!wriop_reset) {
		snprintf(type, sizeof(type), "lni.ctm%d.ins%d", recycle_desc->dcp_id,
				recycle_desc->ceetm_id);
		err = allocate_resource(dpmng->registration.resman_dev, /* Resource Manager handle */
					type, /* Resource type */
					1, /* Number of resources*/
					recycle->lniid, /* Base align */
					DPRC_RES_REQ_OPT_EXPLICIT, /* Options */
					&(recycle->lniid), /* Address */
					"LNIID"); /* Error string */
		CHECK_COND_RETVAL(err == 0, err, "allocate_resource FAILED\n");
	}
	/*! Get physical port descriptor */
	memset(&port_desc, 0x0, sizeof(struct eiop_port_desc));
	port_desc.eiop_id = recycle_desc->eiop_id;
	port_desc.port_id = recycle_desc->port_id;
	err = sys_get_desc(SOC_MODULE_EIOP_PORT,
				SOC_DB_PORT_DESC_EIOP_ID | SOC_DB_PORT_DESC_ID,
				&port_desc, NULL);
	ASSERT_COND(err == 0);

	/*! Obtain Sub-portal */
	eiop_port_tx_get_dsp(&port_desc, &spid);

	/*! Compose ceetm id */
	ceetmid = qbman_ceetmid_compose((uint8_t)recycle_desc->dcp_id,
					(uint8_t)recycle_desc->ceetm_id);

	/*! Get software portal */
	err = dpmng_get_swportal(dpmng, &(swp));
	CHECK_COND_RETVAL(err == 0, err, "dpmng_get_swportal FAILED\n");

	/*! Sub-Portal Map to LNI */
	err = qbman_subportal_configure(swp, /* CEETM SW Portal */
					ceetmid, /* CEETM ID */
					(uint8_t)spid, /* Sub-Portal ID */
					(uint8_t)(recycle->lniid), /* LNI ID */
					txstate); /* TX Enable */
	CHECK_COND_RETVAL(err == 0, err, "qbman_subportal_configure FAILED\n");

	if(!wriop_reset) {
		err = qbman_lni_shaper_disable(swp, ceetmid, (uint32_t)recycle->lniid,
						24);
		CHECK_COND_RETVAL(err == 0, err, "qbman_subportal_configure FAILED\n");
	}
	/*! Put software portal */
	err = dpmng_put_swportal(dpmng, swp);
	CHECK_COND_RETVAL(err == 0, err, "dpmng_put_swportal FAILED\n");

	return err;
}

static int connections_init_recycle_port_eiop(struct dpmng *dpmng,
	int id,
	struct vport_connections_desc *recycle_desc)
{
	/*
	 * 	-Obtain port descriptor
	 * 	-Initialize Recycle path port
	 */
	int err = 0;
	struct eiop_port_init_params eiop_params;
	struct eiop_port_desc port_desc;

	/*! Obtain port descriptor */
	memset(&port_desc, 0x0, sizeof(struct eiop_port_desc));
	port_desc.eiop_id = recycle_desc->eiop_id;
	port_desc.port_id = recycle_desc->port_id;
	err = sys_get_desc(SOC_MODULE_EIOP_PORT,
				SOC_DB_PORT_DESC_EIOP_ID | SOC_DB_PORT_DESC_ID,
				&port_desc, NULL);
	ASSERT_COND(err == 0);

	/*! Initialize Recycle Path Port */
	eiop_params.rate = port_desc.rate;
	eiop_params.default_ingress_ifpid = DPMNG_IFP;
	eiop_params.type = EIOP_RECYCLE_PORT;

	/* Init port */
	err = eiop_port_init(&port_desc, &eiop_params, 0);
	if (err != 0)
		return err;

	/* Enable port */
	eiop_port_rx_enable(&port_desc);
	eiop_port_tx_enable(&port_desc);

	return err;
}

static int get_num_iop()
{
	int cnt = 0;
	int iter = 0;
	struct eiop_desc desc;

	while (sys_get_desc(SOC_MODULE_EIOP, 0, &desc, &iter) == 0)
		cnt++;

	return cnt;
}

static int get_iop(int mac_id)
{
	UNUSED(mac_id);
	return 0;
}

static int get_num_dcp(int iop_id)
{
	int err = 0, cnt = 0, i;
	struct qbman_desc desc;

	memset(&desc, 0x0, sizeof(struct qbman_desc));

	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				0, /* match options*/
				&desc, /* descriptor */
				NULL); /* iterator */
	ASSERT_COND(err == 0);

	for (i = 0; i < QBMAN_MAX_DCP; i++) {
		if ((desc.dcp[i].valid == 1)
			&& (desc.dcp[i].ceetm_support == 1))
			cnt++;
	}
	return cnt;
}

static int get_num_phys(int iop_id, int dcp_id)
{
	int cnt, iter;
	struct pport_connections_desc desc;

	memset(&desc, 0x0, sizeof(struct pport_connections_desc));
	desc.eiop_id = iop_id;
	desc.dcp_id = dcp_id;
	iter = 0, cnt = 0;
	while (sys_get_desc(
		SOC_MODULE_EIOP_PPORT_CON,
		SOC_DB_PORT_CON_DESC_EIOP_ID | SOC_DB_PORT_CON_DESC_DCP_ID,
		&desc, &iter)
		== 0) {
		cnt++;
	}
	return cnt;
}

static int get_num_virt(int iop_id, int dcp_id)
{
	int num_virt;
	int num_cq_channels = 0;
	int i;
	int cnt, iter, num_ceetm_inst;
	struct pport_connections_desc con_desc;
	struct qbman_desc desc;
	int max_cnt;
	int err;

	num_cq_channels = get_num_cqch(iop_id, dcp_id);

	/* Reserve eight channels to Smart NIC TODO from descriptor */
	num_cq_channels -= NUM_RESERVED_CEETM_CHANNELS;

	err = sys_get_desc(SOC_MODULE_QBMAN, iop_id, &desc, NULL);
	ASSERT_COND(err == 0);

	max_cnt = 0;
	num_ceetm_inst = 0;
	for( i = 0 ; i < QBMAN_MAX_CEETM_INS ; i++ ) {
		if ( !desc.dcp[dcp_id].ceetm_instance[i].valid )
			continue;
		cnt = 0;
		iter = 0;
		memset(&con_desc, 0x0, sizeof(struct pport_connections_desc));
		con_desc.eiop_id = iop_id;
		con_desc.dcp_id = dcp_id;
		con_desc.ceetm_id = i;
		while (sys_get_desc(
				SOC_MODULE_EIOP_PPORT_CON,
				SOC_DB_PORT_CON_DESC_EIOP_ID | SOC_DB_PORT_CON_DESC_DCP_ID | SOC_DB_PORT_CON_DESC_CEETM_ID,
				&con_desc, &iter) == 0) cnt++;
		if( cnt > max_cnt )
			max_cnt = cnt;
		num_ceetm_inst++;
	}

	num_virt = (num_cq_channels - max_cnt * num_ceetm_inst ) / 2;

	return num_virt;
}

static int get_num_cqch(int iop_id, int dcp_id)
{
	int err = 0, i;
	struct qbman_desc desc;
	int num_cq_channels = 0;

	memset(&desc, 0x0, sizeof(struct qbman_desc));

	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				iop_id, /*! iop_id *//* match options*/
				&desc, /* descriptor */
				NULL); /* iterator */
	ASSERT_COND(err == 0);

	for (i = 0; i < QBMAN_MAX_CEETM_INS; i++) {
		if (desc.dcp[dcp_id].valid
			&& desc.dcp[dcp_id].ceetm_instance[i].valid)
			num_cq_channels +=
				desc.dcp[dcp_id].ceetm_instance[i].num_cq_channels;
	}

	return num_cq_channels;
}

static int get_aggr_num_cqch()
{
	int num_iops, num_dcps, i, j;
	int num_cq_channels = 0;

	num_iops = get_num_iop();

	for (i = 0; i < num_iops; i++) {
		num_dcps = get_num_dcp(i);
		for (j = 0; j < num_dcps; j++) {
			num_cq_channels += get_num_cqch(i, j);
		}
	}
	return num_cq_channels;
}

static int get_num_ceetm_instances(int iop_id, int dcp_id)
{
	int err = 0, i;
	struct qbman_desc desc;
	int num_ceetm_instances = 0;

	memset(&desc, 0x0, sizeof(struct qbman_desc));

	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				iop_id, /*! iop_id *//* match options*/
				&desc, /* descriptor */
				NULL); /* iterator */
	ASSERT_COND(err == 0);

	for (i = 0; i < QBMAN_MAX_CEETM_INS; i++) {
		if (desc.dcp[dcp_id].valid
			&& desc.dcp[dcp_id].ceetm_instance[i].valid)
			num_ceetm_instances++;
	}
	return num_ceetm_instances;
}

static int get_num_lni(int iop_id, int dcp_id)
{
	int err = 0, i;
	struct qbman_desc desc;
	int num_lnis = 0;

	memset(&desc, 0x0, sizeof(struct qbman_desc));

	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				iop_id, /*! iop_id *//* match options*/
				&desc, /* descriptor */
				NULL); /* iterator */
	ASSERT_COND(err == 0);

	for (i = 0; i < QBMAN_MAX_CEETM_INS; i++) {
		if (desc.dcp[dcp_id].valid
			&& desc.dcp[dcp_id].ceetm_instance[i].valid)
			num_lnis +=
				desc.dcp[dcp_id].ceetm_instance[i].num_lnis;
	}
	return num_lnis;
}

static int get_aggr_num_lni()
{
	int num_iops, num_dcps, i, j;
	int num_lnis = 0;

	num_iops = get_num_iop();

	for (i = 0; i < num_iops; i++) {
		num_dcps = get_num_dcp(i);
		for (j = 0; j < num_dcps; j++) {
			num_lnis += get_num_lni(i, j);
		}
	}
	return num_lnis;
}

static int get_num_recycle(int iop_id, int dcp_id)
{
	int cnt, iter;
	struct vport_connections_desc desc;

	memset(&desc, 0x0, sizeof(struct vport_connections_desc));
	desc.eiop_id = iop_id;
	desc.dcp_id = dcp_id;
	iter = 0, cnt = 0;
	while (sys_get_desc(
		SOC_MODULE_EIOP_VPORT_CON,
		SOC_DB_PORT_CON_DESC_EIOP_ID | SOC_DB_PORT_CON_DESC_DCP_ID,
		&desc, &iter)
		== 0) {
		cnt++;
	}
	return cnt;
}

static int allocate_virt_connection_iopid(struct dpmng *dpmng,
	int *iop_id,
	int *dcp_id)
{
	int err = -ENAVAIL, i, j, virt_cnt = BIG_NUMBER;

	for (i = 0; i < dpmng->num_iops; i++) {
		for (j = 0; j < dpmng->iop[i].num_dcps; j++) {
			if (dpmng->iop[i].dcp[j].virt_cnt < virt_cnt) {
				virt_cnt = dpmng->iop[i].dcp[j].virt_cnt++;
				*iop_id = i;
				*dcp_id = j;
				err = 0;
			}
		}
	}
	return err;
}

static int allocate_virt_connection_id(struct dpmng *dpmng,
	int iop_id,
	int dcp_id,
	int *id)
{
	int i, num_virt;
	struct dpmng_virt_connection *virt_conn;

	virt_conn = &(dpmng->iop[iop_id].dcp[dcp_id].virt_conn[0]);
	num_virt = dpmng->iop[iop_id].dcp[dcp_id].num_virt;

	/*! look for unused virtual connection */
	for (i = 0; i < num_virt; i++) {
		if (virt_conn[i].inuse == 0) {
			/*! Mark connection as used */
			virt_conn[i].inuse = 1;

			/*! save id */
			*id = i;

			/*! Indicate virtual connection found */
			return 0;
		}

	}
	return -ENAVAIL;
}

static int get_phys_connection(struct dpmng *dpmng,
	int iop_id,
	int mac_id,
	int *dcp_id,
	int *id)
{
	int i, j;
	struct dpmng_dcp *dcp;

	for (i = 0; i < dpmng->iop[iop_id].num_dcps; i++) {
		dcp = &(dpmng->iop[iop_id].dcp[i]);
		for (j = 0; j < dcp->num_phys; j++) {
			if (dcp->phys_conn[j].mac_id == mac_id) {
				*dcp_id = i;
				*id = j;
				return 0;
			}
		}
	}
	return -ENAVAIL;
}

static int get_recycle(struct dpmng *dpmng,
	struct dpmng_accesspoint *ap,
	uint32_t req_bw,
	int *id)
{
	int err = -ENAVAIL, i;
	struct dpmng_recycle *recycle;
	int num_recycle;
	long curr_bw, min_residual_value = -1;

	/*! Get pointer to recycle */
	recycle = &(dpmng->iop[ap->iop_id].dcp[ap->dcp_id].recycle[0]);
	num_recycle = dpmng->iop[ap->iop_id].dcp[ap->dcp_id].num_recycle;

	pr_debug("dpmng: get_recycle: req_bw = %d\n", req_bw);

	/*! Lookup for recycle having the same ceetm id */
	for (i = 0; i < num_recycle; i++) {
		if (recycle[i].ceetm_id == ap->ceetm_id) {
			curr_bw = phys_get_bandwidth(dpmng, ap->iop_id, ap->dcp_id,
									recycle[i].ceetm_id, recycle[i].lniid);
			/* if we just want one recycle port (no bw),
			 * provide the one with the biggest remaining bw
			 */
			if ((!req_bw) && (min_residual_value < curr_bw)) {
				/* min_residual_value used here as max_remaining_bw */
				min_residual_value = curr_bw, *id = i, err = 0;
			} else {
				/*  otherwise, best first fit algorithm */
				if ((curr_bw >= req_bw) &&
						(min_residual_value > (curr_bw - req_bw)))
					min_residual_value = curr_bw - (long)req_bw, *id = i, err = 0;
			}
		}
	}

	if( *id >= 0 )
		pr_debug("dpmng: get_recycle: err = %d, min_residual_value = %d, ceetm = %d, recycle.lniid = %d\n",
				err, min_residual_value, recycle[*id].ceetm_id, recycle[*id].lniid);

	return err;
}

/**
 * @brief	DPMNG2.0.1
 */

static int connection_make_id(enum dpmng_connection_type type,
	int iop_id,
	int dcp_id,
	int id)
{
	/*
	 * 	0  - 15 	connection id
	 * 	16 - 19 	dcp id
	 * 	20 - 23 	wriop id
	 * 	24      	connection type
	 */
	return ((type << 24) | /* 24 - connection type */
	((iop_id & 0xF) << 20)
		| /* 20 - 23 wriop id */
		((dcp_id & 0xF) << 16)
		| /* 16 - 19 dcp id */
		(id & 0xFFFF)); /* 0  - 15 connection id */
}

static enum dpmng_connection_type connection_get_type(int conn_id)
{
	return (enum dpmng_connection_type)(conn_id >> 24);
}

static int connection_get_iopid(int conn_id)
{
	return ((conn_id >> 20) & 0x0F);
}

static int connection_get_dcpid(int conn_id)
{
	return ((conn_id >> 16) & 0xFF);
}

static int connection_get_id(int conn_id)
{
	return (conn_id & 0xFFFF);
}

/**
 * @brief	DPMNG2.0.1
 */
int dpmng_connections_init(struct dpmng *dpmng)
{
	int err = 0, i, j, iter;
	struct vport_connections_desc vport_desc;
	struct eiop_port_init_params eiop_params;
	struct eiop_port_desc port_desc;

	/* Allocate required memory */
	err = connections_init_mallocate(dpmng);
	if (err != 0)
		return err;

	/* Init physical connections */
	err = connections_init_phys(dpmng);
	if (err != 0)
		return err;

	/* Iterate according to num WRIOPs and num Direct Portal Connections*/
	for (i = 0; i < dpmng->num_iops; i++) {
		for (j = 0; j < dpmng->iop[i].num_dcps; j++) {

			memset(&port_desc, 0x0,
					sizeof(struct eiop_port_desc));

			port_desc.eiop_id = i; /*! wriop id*/
			port_desc.type = EIOP_ETHERNET_PORT; /*! Port Type*/
			iter = 0; /*! iterator */

			/* Reset all physical port resources iterating by PORT DB*/
			while (sys_get_desc(SOC_MODULE_EIOP_PORT,
						SOC_DB_PORT_DESC_TYPE | SOC_DB_PORT_DESC_EIOP_ID,
						&port_desc,
						&iter)==0)
			{
				pr_debug("Resetting WRIOP resources for physical port_id: %d\n",
									port_desc.port_id);

				/*! Initialize Recycle Path Port */
				eiop_params.rate = port_desc.rate;
				eiop_params.default_ingress_ifpid = DPMNG_IFP;
				eiop_params.type = port_desc.type;

				/* Init port */
				err = eiop_port_init(&port_desc, &eiop_params, 1);

				if (err != 0)
					return err;

				memset(&port_desc, 0x0,
						sizeof(struct eiop_port_desc));
				port_desc.eiop_id = i; /*! wriop id*/
				port_desc.type = EIOP_ETHERNET_PORT; /*! Port Type*/

			}

			memset(&vport_desc, 0x0,
				sizeof(struct vport_connections_desc));

			vport_desc.eiop_id = i; /*! wriop id*/
			vport_desc.dcp_id = j; /*! dcp id */
			iter = 0; /*! iterator */

			/* Reset all recycle port resources iterating by Connection Virtual Ports DB */
			while (sys_get_desc(
				SOC_MODULE_EIOP_VPORT_CON,
				SOC_DB_PORT_CON_DESC_EIOP_ID
				| SOC_DB_PORT_CON_DESC_DCP_ID,
				&vport_desc, &iter)
				== 0) {

				pr_debug("Resetting WRIOP resources for virtual port_id: %d\n",
						vport_desc.port_id);
				/*! Obtain port descriptor */
				memset(&port_desc, 0x0, sizeof(struct eiop_port_desc));
				port_desc.eiop_id = vport_desc.eiop_id;
				port_desc.port_id = vport_desc.port_id;
				err = sys_get_desc(SOC_MODULE_EIOP_PORT,
							SOC_DB_PORT_DESC_EIOP_ID | SOC_DB_PORT_DESC_ID,
							&port_desc, NULL);
				ASSERT_COND(err == 0);

				/*! Initialize Recycle Path Port */
				eiop_params.rate = port_desc.rate;
				eiop_params.default_ingress_ifpid = DPMNG_IFP;
				eiop_params.type = EIOP_RECYCLE_PORT;

				/* Init port */
				err = eiop_port_init(&port_desc, &eiop_params, 1);

				if (err != 0)
					return err;

				memset(&vport_desc, 0,
					sizeof(struct vport_connections_desc));
				vport_desc.eiop_id = i; /*! wriop id*/
				vport_desc.dcp_id = j; /*! dcp id */
			}
		}
	}

	/* Init virtual connections */
	err = connections_init_virt(dpmng);
	if (err != 0)
		return err;

	/* Init recycle path ports */
	err = connections_init_recycle(dpmng, 0);
	if (err != 0)
		return err;

	/* Init database for bandwidth allocation */
	err = connections_init_bandwidth(dpmng);

	return err;
}

int dpmng_connection_virt_allocate(struct dpmng *dpmng, int *conn_id)
{
	/*
	 * 	-Obtain iop_id and dcp_id
	 * 	-Find free connection
	 * 	-Mark connection as inuse
	 * 	-make connection id from iop_id, dcp_id and connection offset
	 */
	int err = 0, iop_id, dcp_id, id;

	/*! Obtain iop_id and dcp_id */
	err = allocate_virt_connection_iopid(dpmng, &iop_id, &dcp_id);
	if (err != 0)
		return err;

	/*! Get connection id */
	err = allocate_virt_connection_id(dpmng, iop_id, dcp_id, &id);
	if (err != 0)
		return err;

	/*! Make connection id */
	*conn_id = connection_make_id(DPMNG_CONNECTION_TYPE_VIRT, iop_id,
					dcp_id, id);

	return err;
}

int dpmng_connection_virt_lniid(struct dpmng *dpmng,
	struct dpmng_accesspoint *ap)
{
	int err = 0, recycle_id = 0;

	err = get_recycle(dpmng, ap, 0, &recycle_id);
	if (err != 0)
		return err;

	/* Obtain LNI */
	ap->lniid =
		dpmng->iop[ap->iop_id].dcp[ap->dcp_id].\
recycle[recycle_id].lniid;

	return err;
}

int dpmng_connection_phys_allocate(struct dpmng *dpmng,
	int mac_id,
	int *conn_id)
{
	int err, iop_id, dcp_id, id;

	iop_id = get_iop(mac_id);

	err = get_phys_connection(dpmng, iop_id, mac_id, &dcp_id, &id);
	if (err != 0)
		return err;

	/*! Make connection id */
	*conn_id = connection_make_id(DPMNG_CONNECTION_TYPE_PHYS, iop_id,
					dcp_id, id);

	return err;
}

int dpmng_connection_free(struct dpmng *dpmng, int conn_id)
{
	/*
	 * 	-Obtain iop_id, dcp_id and id
	 * 	-Mark as unused
	 */
	int err = 0, iop_id, dcp_id, id;
	static enum dpmng_connection_type type;

	type = connection_get_type(conn_id);
	iop_id = connection_get_iopid(conn_id);
	dcp_id = connection_get_dcpid(conn_id);
	id = connection_get_id(conn_id);

	switch (type) {
	case DPMNG_CONNECTION_TYPE_VIRT:
		dpmng->iop[iop_id].dcp[dcp_id].virt_conn[id].inuse = 0;
		dpmng->iop[iop_id].dcp[dcp_id].virt_cnt--;
		break;
	case DPMNG_CONNECTION_TYPE_PHYS:
		break;
	default:
		err = -ENOTSUP;
		break;
	}
	return err;
}

int dpmng_connection_get_accesspoint(struct dpmng *dpmng,
	int conn_id,
	int ap_id, uint32_t bandwidth,
	struct dpmng_accesspoint *ap)
{
	int err = 0, iop_id, dcp_id, id, recycle_id = 0, lniid;
	static enum dpmng_connection_type type;
	struct dpmng_accesspoint *db_ap;
	int ppid = -1;

	type = connection_get_type(conn_id);
	iop_id = connection_get_iopid(conn_id);
	dcp_id = connection_get_dcpid(conn_id);
	id = connection_get_id(conn_id);

	/* Obtain accessspoint */
	switch (type) {
	case DPMNG_CONNECTION_TYPE_VIRT:
		db_ap =
			&(dpmng->iop[iop_id].\
					dcp[dcp_id].\
					virt_conn[id].ap[!!ap_id]);

		err = get_recycle(dpmng, db_ap, bandwidth, &recycle_id);
		if (err != 0)
			return err;

		/* Obtain LNI */
		lniid = dpmng->iop[iop_id].dcp[dcp_id].recycle[recycle_id].lniid;
		ppid = dpmng->iop[iop_id].dcp[dcp_id].recycle[recycle_id].ppid;

		break;
	case DPMNG_CONNECTION_TYPE_PHYS:
		db_ap =
			&(dpmng->iop[iop_id].\
dcp[dcp_id].\
phys_conn[id].ap);

		/* Obtain LNI */
		lniid = dpmng->iop[iop_id].dcp[dcp_id].\
phys_conn[id].lniid;
		break;
	default:
		err = -ENOTSUP;
		break;
	}
	/*! Copy accesspoint */
	memcpy(ap, db_ap, sizeof(struct dpmng_accesspoint));
	ap->lniid = lniid;
	ap->ppid = ppid;
	return err;
}

int dpmng_connection_alloc_ceetm_channel(struct dpmng *dpmng,
	int *channel_id_array, int dcp_id, int ceetm_id,
	int num_res)
{
	int err = 0;
	char type[16];

	snprintf(type, sizeof(type), "cqch.ctm%d.ins%d", dcp_id, ceetm_id);
	err = allocate_resource(dpmng->registration.resman_dev, /*Resource manager handle */
			type, /* Resource type */
			(uint32_t)num_res, /* Number of resources*/
			1, /* Base align */
			0, /* Options */
			channel_id_array, /* Address */
			"CQCHID"); /* Error string */

	return err;
}

int dpmng_connection_free_ceetm_channel(struct dpmng *dpmng,
	int *channel_id_array, int dcp_id, int ceetm_id,
	int num_res)
{
	int err = 0, err1 = 0;
	int i;
	char type[16];

	snprintf(type, sizeof(type), "cqch.ctm%d.ins%d", dcp_id, ceetm_id);
	for( i = 0 ; i < num_res ; i++ ) {
		err = deallocate_resource(dpmng->registration.resman_dev, /*Resource manager handle */
				type, /* Resource type */
				channel_id_array[i], /* Address */
				"CQCHID"); /* Error string */
		if( err ) {
			pr_err("Failed to free CQCHID resource with id %d\n", channel_id_array[i]);
			err1 = err;
		}
	}

	return err1 ? err1 : err;
}

#ifdef TKT220573
static int add_accesspoint_to_recycle(struct dpmng *dpmng,
	struct dpmng_accesspoint *ap)
{

	int err = 0, recycle_id = -1, lniid;
	struct qbman_swp *swp;
	uint32_t ceetmid;

	dpmng_get_swportal(dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	err = get_recycle(dpmng, ap, 0, &recycle_id);
	if (err != 0)
		return err;

	/* Obtain LNI */
	lniid = dpmng->iop[ap->iop_id].dcp[ap->dcp_id].recycle[recycle_id].lniid;


	/*! Compose CEETM */
	ceetmid = qbman_ceetmid_compose((uint8_t)ap->dcp_id,
					(uint8_t)ap->ceetm_id);


	err = qbman_cchannel_configure(swp, /* SW Portal */
					ceetmid, /* Composed CEETM ID */
					(uint8_t)ap->cqchid, /* Channel ID */
					(uint8_t)lniid, /* LNI ID */
					0); /* shaped/un-shaped */
	return err;
}

static int connections_init_endpoint_ex(struct dpmng *dpmng,
	struct dpmng_accesspoint *ap)
{
	int err = 0;
	struct eiop_ifp_desc eiop_ifp_desc;

	err = allocate_resource(dpmng->registration.resman_dev, "ifp.wr0", /* Resource type */
				1, /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				&(ap->ifpid), /* Address to store */
				"IFPID"); /* Error string */
	if (err != 0)
		return err;

	/* Disable IFP */
	/*! Get IFP descriptor */
	eiop_ifp_desc.ifp_id = ap->ifpid;
	eiop_ifp_desc.eiop_id = ap->iop_id; /* WRIOP ID */
	err = sys_get_desc(SOC_MODULE_EIOP_IFP, /* module */
				SOC_DB_IFP_DESC_ID | SOC_DB_IFP_DESC_EIOP_ID,
				&eiop_ifp_desc, /* descriptor */
				NULL); /* iterator */
	if (err != 0)
		return err;

	/* TX IFP valid disable */
	err = eiop_ifp_tx_graceful_stop(&eiop_ifp_desc);
	if (err != 0)
		return err;

	/* RX IFP valid disable */
	err = eiop_ifp_rx_graceful_stop(&eiop_ifp_desc);

	return err;
}

static uint16_t ceetm_get_cqid(int cqchid, int cq)
{
	int err;
	struct qbman_desc desc;
	uint32_t cqid;
	uint32_t num_cqs;

	memset(&desc, 0x0, sizeof(struct qbman_desc));

	err = sys_get_desc(SOC_MODULE_QBMAN, /* module */
				0, /* match options*/
				&desc, /* descriptor */
				NULL); /* iterator */
	ASSERT_COND(err == 0);

	num_cqs = desc.ceetm_num_strict_pri_q + desc.ceetm_num_weight_pri_q;
	cq = cq + (int)desc.ceetm_weight_pri_q_base;

	cqid = (cqchid * (num_cqs)) | cq;

	return (uint16_t)cqid;
}

/**
 * @brief	configure_rtn_fqid() and dpmng_get_rtn_fqid()
 * 		are workaround for TKT220573 - QMan does not release buffers
 * 		for the frame at the end of replication.
 * 		Whenever TKT220573 resolved configure_rtn_fqid() and
 * 		dpmng_get_rtn_fqid() should be used for conventional
 * 		return FQID
 */
static int configure_rtn_fqid(struct dpmng *dpmng, struct dpmng_accesspoint *ap)
{
	/*
	 *	-Configure DCT qbman_dct_configure()
	 * 	-Configure CEETM CQ
	 * 	-Configure LFQID
	 */

	int err = 0;
	uint32_t ceetm_id, lfqid;
	uint16_t cqid;
	struct qbman_swp *swp;
	struct eiop_fcead fcead;
	struct dpmng_amq amq;
	int ps = qbman_cacheable_pfdr();

	/* Configure DCT */
	ceetm_id = qbman_ceetmid_compose((uint8_t)ap->dcp_id, /*! DCP Id */
						(uint8_t)ap->ceetm_id); /*! CEETM Id */

	dpmng_get_swportal(dpmng, (void **)&(swp));
	ASSERT_COND(swp);

	/* Obtain AMQ */
	memset(&amq, 0x0, sizeof(struct dpmng_amq));
	dpmng_get_amq(&amq);

	memset(&fcead, 0x0, sizeof(struct eiop_fcead));

	/* set IFP */
	EIOP_FCEAD_SET_IFPID(&fcead, ap->ifpid);

	/* fetch header only */
	EIOP_FCEAD_SET_FHO(&fcead, 1);

	/* Configure DCT context */
	err = qbman_dct_configure(
		swp,
		ceetm_id, /* CEETM ID */
					(uint16_t)(ap->dctidx[0]), /* dct index */
					amq.bdi, /* BDI */
					amq.va, /* Virtual Address */
					amq.icid, /* icid */
					amq.pl, /* Privilege level */
					((uint64_t)fcead.command1 << 32) | /* Context "hi" */
					(uint64_t)fcead.command2 /* Context "lo" */
					);
	if (err != 0)
		return err;

	/* Make LFQID */
	lfqid = qbman_lfqid_compose((uint8_t)ap->dcp_id, /* DCP */
					(uint8_t)ap->ceetm_id, /* Inst ID */
					(uint16_t)(ap->lfqmtidx[0]));

	cqid = ceetm_get_cqid(ap->cqchid, 0);

	/* CEETM CQ configuration */
	err = qbman_cq_configure(swp, /* SW portal */
					ceetm_id, /* CEETMID */
					cqid, /* CQID */
					0, /* CGID */
					ps, /* Stashing EN*/
					0); /* PPS */
	if (err != 0)
		return err;

	/* Configure LFQID */
	err = qbman_lfq_configure(swp, /* SW Portal */
					lfqid, /* LFQID */
					cqid, /* CQ ID */
					(uint16_t)(ap->dctidx[0]), /* DCTIDX */
					0 /* Error FQID */
					);

	return err;
}

int dpmng_init_rtn_fqid(struct dpmng *dpmng)
{
	/*
	 * 	-Allocate access point connections_init_endpoint()
	 * 	-Allocate IFP and disable
	 * 	-Configure QMan
	 */
	int err = 0;
	int num_lfq;

	/* Allocate access point */
	dpmng->rtn_fqid_ap.dcp_id = 0;
	dpmng->rtn_fqid_ap.iop_id = 0;
	dpmng->rtn_fqid_ap.ceetm_id = 0;
	err = connections_init_endpoint(dpmng, &(dpmng->rtn_fqid_ap));
	CHECK_COND_RETVAL( err == 0, err, "Endpoint init failed\n");

	err = dpmng_connection_alloc_ceetm_channel(dpmng,
			&dpmng->rtn_fqid_ap.cqchid, dpmng->rtn_fqid_ap.dcp_id, dpmng->rtn_fqid_ap.ceetm_id,
			1);
	CHECK_COND_RETVAL( err==0, err, "Fail to allocate %d channels\n", 1);

	num_lfq = SOC_NUM_OF_CORES;
	err = dpmng_connection_alloc_lfqmtidx(dpmng,
			dpmng->rtn_fqid_ap.lfqmtidx, dpmng->rtn_fqid_ap.dcp_id, dpmng->rtn_fqid_ap.ceetm_id,
			num_lfq);
	CHECK_COND_RETVAL( err == 0, err, "Failed to allocate %d LFQ resources\n", num_lfq);
	dpmng->rtn_fqid_ap.lfq_cnt = num_lfq;

	/* Allocate IFP */
	err = connections_init_endpoint_ex(dpmng, &(dpmng->rtn_fqid_ap));
	if (err != 0)
		return err;

	/* Configure QMan stuff of return FQID */
	err = configure_rtn_fqid(dpmng, &(dpmng->rtn_fqid_ap));
	if (err != 0)
		return err;

	/* Associate with recycle */
	err = add_accesspoint_to_recycle(dpmng, &(dpmng->rtn_fqid_ap));

	return err;
}
#endif

int dpmng_get_rtn_fqid(struct dpmng *dpmng)
{
	/*
	 * In Rev2, RD = 1 and DCPID = 0 in order for WRIOP to release buffers after replication
	 * is done.
	 *
	 * QMan 4.1 Block Guide:
	 * RTN_FQID_DCPID - Return FQID or DCPID
	 *
	 * If RD = 0, then this field contains a FQID. Most commonly, this value will be a CEETM
	 * 		LFQID used to send the original FDs to the WRIOP to be discarded, with appropriate
	 *		settings in the CTX field of the dequeue context table.
	 * If RD = 1, then bits 3-0 of this field contain the DCPID (DCP portal number) of a DCP
	 *		portal that is connected to a WRIOP, and a dedicated interface will be used to send the
	 *		original FD directly to the WRIOP. Note this option is supported only in qman_4.1 and later
	 *		versions, in qman_4.0 the only option for returning the original FD is using a FQID.
	 */
#ifdef TKT220573
	uint32_t lfqid;

	lfqid = qbman_lfqid_compose(
		(uint8_t)dpmng->rtn_fqid_ap.dcp_id, /* DCP */
		(uint8_t)dpmng->rtn_fqid_ap.ceetm_id, /* Inst ID */
		(uint16_t)(dpmng->rtn_fqid_ap.lfqmtidx[0]));

	return (int)lfqid;
#else
	return 0;
#endif
}

static int connections_init_bandwidth(struct dpmng *dpmng)
{
	int err = 0;

	err = connections_init_bandwidth_cqch(dpmng);
	if (err != 0)
		return err;

	err = connections_init_bandwidth_lni(dpmng);
	if (err != 0)
		return err;

	err = connections_init_bandwidth_recycle(dpmng);

	return err;
}

static int connections_init_bandwidth_cqch(struct dpmng *dpmng)
{
	int err = 0, num_cqch, i;
	struct dpmng_cqch *cqch;

	/* Obtain number of channels */
	num_cqch = get_aggr_num_cqch();

	/* Allocate hmap */
	dpmng->hmap_cqch = hmap_create(num_cqch, 4);
	if (dpmng->hmap_cqch == NULL)
		return -ENOMEM;

	for (i = 0; i < num_cqch; i++) {
		/* allocate  database */
		cqch = fsl_malloc(sizeof(struct dpmng_cqch));
		if (cqch == NULL)
			return -ENOMEM;

		/* reset database */
		memset(cqch, 0x0, sizeof(struct dpmng_cqch));

		/* set data into hmap */
		err = hmap_set_data(dpmng->hmap_cqch, i, cqch);
		if (err != 0)
			return err;
	}
	return err;
}

static int connections_init_bandwidth_lni(struct dpmng *dpmng)
{
	int err = 0, num_lni, i;
	struct dpmng_lni *lni;

	/* Obtain number of channels */
	num_lni = get_aggr_num_lni();

	/* Allocate hmap */
	dpmng->hmap_lni = hmap_create(num_lni, 4);
	if (dpmng->hmap_lni == NULL)
		return -ENOMEM;

	for (i = 0; i < num_lni; i++) {
		/* allocate  database */
		lni = fsl_malloc(sizeof(struct dpmng_lni));
		if (lni == NULL)
			return -ENOMEM;

		/* reset database */
		memset(lni, 0x0, sizeof(struct dpmng_lni));

		/* set data into hmap */
		err = hmap_set_data(dpmng->hmap_lni, i, lni);
		if (err != 0)
			return err;
	}
	return err;
}

static int connections_init_bandwidth_recycle(struct dpmng *dpmng)
{
	int err = 0, num_iops, num_dcps, num_recycle, i, j, k, lniid, ceetm_id;

	num_iops = dpmng->num_iops;

	for (i = 0; i < num_iops; i++) {
		num_dcps = dpmng->iop[i].num_dcps;
		for (j = 0; j < num_dcps; j++) {
			num_recycle = dpmng->iop[i].dcp[j].num_recycle;
			for (k = 0; k < num_recycle; k++) {
				lniid = dpmng->iop[i].dcp[j].recycle[k].lniid;
				ceetm_id =
					dpmng->iop[i].dcp[j].recycle[k].ceetm_id;
				err = phys_add_bandwidth(
					dpmng, i, /* IOP */
					j, /* DCP */
					ceetm_id, /* CEETM */
					lniid, /* LNI */
					DPMNG_RECYCLE_BANDWIDTH);/* BW */
				if (err != 0)
					break;
			}
		}
	}
	return err;
}

static int phys_add_bandwidth(struct dpmng *dpmng,
	int iop_id,
	int dcp_id,
	int ceetm_id,
	int lniid,
	uint32_t bandwidth)
{
	/*
	 * 	make a key
	 * 	add an entry
	 * */
	int err = 0;
	uint8_t key[4];
	struct dpmng_lni *lni;

	/* make a key */
	make_key(iop_id, dcp_id, ceetm_id, lniid, key);

	/* Add and entry */
	err = hmap_add_key(dpmng->hmap_lni, key);
	if (err != 0)
		return err;

	/* Obtain database */
	err = hmap_lookup(dpmng->hmap_lni, key, (hmap_data *)&lni);
	if (err != 0)
		return -EEXIST;

	/* Reset database */
	memset(lni, 0x0, sizeof(struct dpmng_lni));
	lni->avail_bandwidth = bandwidth;

	return err;
}

static long phys_get_bandwidth(struct dpmng *dpmng,
		int iop_id,
		int dcp_id,
		int ceetm_id,
		int lniid)
{
	int err;
	uint8_t key[4];
	struct dpmng_lni *lni;

	/* make a key */
	make_key(iop_id, dcp_id, ceetm_id, lniid, key);

	/* Obtain database */
	err = hmap_lookup(dpmng->hmap_lni, key, (hmap_data *)&lni);
	if (err != 0)
		return -EEXIST;

	return (long int)lni->avail_bandwidth;
}

static int phys_remove_bandwidth(struct dpmng *dpmng,
	int iop_id,
	int dcp_id,
	int ceetm_id,
	int lniid)
{
	int err = 0;
	uint8_t key[4];

	/* make a key */
	make_key(iop_id, dcp_id, ceetm_id, lniid, key);

	/* Add and entry */
	err = hmap_remove_key(dpmng->hmap_lni, key);
	if (err != 0)
		return err;

	return err;
}

static void make_key(int iop_id,
	int dcp_id,
	int ceetm_id,
	int id,
	hmap_key key)
{
	uint32_t u_key;

	/* Make uint32 key */
	u_key = u32_enc(0, 4, (uint32_t)iop_id);
	u_key |= u32_enc(4, 4, (uint32_t)dcp_id);
	u_key |= u32_enc(8, 8, (uint32_t)ceetm_id);
	u_key |= u32_enc(16, 16, (uint32_t)id);

	/* make string key */
	key[0] = UINT8_LO(UINT16_LO(u_key));
	key[1] = UINT8_HI(UINT16_LO(u_key));
	key[2] = UINT8_LO(UINT16_HI(u_key));
	key[3] = UINT8_HI(UINT16_HI(u_key));
}

#ifdef TKT011436
int dpmng_connections_restore(struct dpmng *dpmng)
{
	int err = 0, i, j, iter;
	struct vport_connections_desc vport_desc;
	struct eiop_port_init_params eiop_params;
	struct eiop_port_desc port_desc;

	/* Init physical connections */
/*	err = connections_init_phys(dpmng);
	if (err != 0)
		return err;
*/
	/* Iterate according to num WRIOPs and num Direct Portal Connections*/
	for (i = 0; i < dpmng->num_iops; i++) {
		for (j = 0; j < dpmng->iop[i].num_dcps; j++) {

			memset(&port_desc, 0x0,
					sizeof(struct eiop_port_desc));

			port_desc.eiop_id = i; /*! wriop id*/
			port_desc.type = EIOP_ETHERNET_PORT; /*! Port Type*/
			iter = 0; /*! iterator */

			/* Reset all physical port resources iterating by PORT DB*/
			while (sys_get_desc(SOC_MODULE_EIOP_PORT,
						SOC_DB_PORT_DESC_TYPE | SOC_DB_PORT_DESC_EIOP_ID,
						&port_desc,
						&iter)==0)
			{
				pr_debug("Resetting WRIOP resources for physical port_id: %d\n",
									port_desc.port_id);

				/*! Initialize Recycle Path Port */
				eiop_params.rate = port_desc.rate;
				eiop_params.default_ingress_ifpid = DPMNG_IFP;
				eiop_params.type = port_desc.type;

				/* Init port */
				err = eiop_port_init(&port_desc, &eiop_params, 1);
				CHECK_COND_RETVAL(!err, err, "eiop_port_init Failed\n");

				memset(&port_desc, 0x0,
						sizeof(struct eiop_port_desc));
				port_desc.eiop_id = i; /*! wriop id*/
				port_desc.type = EIOP_ETHERNET_PORT; /*! Port Type*/

			}

			memset(&vport_desc, 0x0,
				sizeof(struct vport_connections_desc));

			vport_desc.eiop_id = i; /*! wriop id*/
			vport_desc.dcp_id = j; /*! dcp id */
			iter = 0; /*! iterator */

			/* Reset all recycle port resources iterating by Connection Virtual Ports DB */
			while (sys_get_desc(
				SOC_MODULE_EIOP_VPORT_CON,
				SOC_DB_PORT_CON_DESC_EIOP_ID
				| SOC_DB_PORT_CON_DESC_DCP_ID,
				&vport_desc, &iter)
				== 0) {

				pr_debug("Resetting WRIOP resources for virtual port_id: %d\n",
						vport_desc.port_id);
				/*! Obtain port descriptor */
				memset(&port_desc, 0x0, sizeof(struct eiop_port_desc));
				port_desc.eiop_id = vport_desc.eiop_id;
				port_desc.port_id = vport_desc.port_id;
				err = sys_get_desc(SOC_MODULE_EIOP_PORT,
							SOC_DB_PORT_DESC_EIOP_ID | SOC_DB_PORT_DESC_ID,
							&port_desc, NULL);
				ASSERT_COND(err == 0);

				/*! Initialize Recycle Path Port */
				eiop_params.rate = port_desc.rate;
				eiop_params.default_ingress_ifpid = DPMNG_IFP;
				eiop_params.type = EIOP_RECYCLE_PORT;

				/* Init port */
				err = eiop_port_init(&port_desc, &eiop_params, 1);
				CHECK_COND_RETVAL(!err, err, "eiop_port_init Failed\n");

				memset(&vport_desc, 0,
					sizeof(struct vport_connections_desc));
				vport_desc.eiop_id = i; /*! wriop id*/
				vport_desc.dcp_id = j; /*! dcp id */
			}
		}
	}

	/* Init virtual connections */
/*	err = connections_init_virt(dpmng);
	if (err != 0)
		return err;
*/
	/* Init recycle path ports */
	err = connections_init_recycle(dpmng, 1);
	if (err != 0)
		return err;

	/* Init database for bandwidth allocation */
/*	err = connections_init_bandwidth(dpmng);
*/
	return err;
}

int qbman_connection_phys_set_state(int mac_id, int eiop_id, int txstate)
{
	struct dpmng *dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	int err = 0, id = 0;
	struct pport_connections_desc desc_p;
	
	pr_info("%s TX for subportal associated with physical port = %d\n", txstate? "Enable" : "Disable", mac_id);

	memset(&desc_p, 0x0,
		sizeof(struct pport_connections_desc));

	/* Physical port */
	desc_p.eiop_id = eiop_id; /*! wriop id*/
	desc_p.mac_id = mac_id; /*! mac id */
	if (sys_get_desc(
		SOC_MODULE_EIOP_PPORT_CON,
		SOC_DB_PORT_CON_DESC_MAC_ID
		| SOC_DB_PORT_CON_DESC_EIOP_ID,
		&desc_p, NULL)
		== 0) {
		pr_info("Set state=%d for Physical PORT = %d\n", txstate, desc_p.port_id);
		/*! Init physical interface */
		err = connections_init_phys_if_qbman(dpmng,
						id++,
						&desc_p,
						txstate,
						1); /*WRIOP RESET*/
		CHECK_COND_RETVAL(err == 0, err, "connection_phys_if_set_state FAILED\n");
		memset(&desc_p, 0,
		sizeof(struct pport_connections_desc));
	}

	return err;
}

int qbman_connections_all_phys_recycle_set_state(int txstate)
{
	/*
	 * go over SOC_MODULE_DPMNG_PHY/VIRT_CONNECTIONS descriptor
	 * call interface init
	 */
	struct dpmng *dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	int err = 0, i = 0, j = 0, iter, id;
	struct pport_connections_desc desc_p;
	struct vport_connections_desc desc_v;
	
	pr_info("%s TX for each subportal associated with physical/virtual port\n", txstate? "Enable" : "Disable");
	/* Iterate all DCPs from all WRIOPs */
	for (i = 0; i < dpmng->num_iops; i++) {
		for (j = 0; j < dpmng->iop[i].num_dcps; j++) {

			memset(&desc_p, 0x0,
				sizeof(struct pport_connections_desc));

			/* Physical port */
			desc_p.eiop_id = i; /*! wriop id*/
			desc_p.dcp_id = j; /*! dcp id */
			iter = 0; /*! iterator */
			id = 0;
			while (sys_get_desc(
				SOC_MODULE_EIOP_PPORT_CON,
				SOC_DB_PORT_CON_DESC_DCP_ID
				| SOC_DB_PORT_CON_DESC_EIOP_ID,
				&desc_p, &iter)
				== 0) {
				pr_info("Set state=%d for Physical PORT = %d\n", txstate, desc_p.port_id);
				/*! Init physical interface */
				err = connections_init_phys_if_qbman(dpmng,
								id++,
								&desc_p,
								txstate,
								1); /*WRIOP RESET*/
				CHECK_COND_RETVAL(err == 0, err, "connection_phys_if_set_state FAILED\n");
				memset(&desc_p, 0,
				sizeof(struct pport_connections_desc));
			}
			
			memset(&desc_v, 0x0,
				sizeof(struct vport_connections_desc));

			/* Virtual port */
			desc_v.eiop_id = i; /*! wriop id*/
			desc_v.dcp_id = j; /*! dcp id */
			iter = 0; /*! iterator */
			id = 0;
			while (sys_get_desc(
				SOC_MODULE_EIOP_VPORT_CON,
				SOC_DB_PORT_CON_DESC_EIOP_ID
				| SOC_DB_PORT_CON_DESC_DCP_ID,
				&desc_v, &iter)
				== 0) {
				pr_info("Set state=%d for Virtual PORT = %d\n", txstate, desc_v.port_id);
				/*! Init physical interface */
				err = connections_init_recycle_port_qbman(dpmng,
									id++,
									&desc_v,
									txstate,
									1); /* wriop_reset */
				CHECK_COND_RETVAL(err == 0, err, "connection_recycle_port_set_state FAILED\n");
				memset(&desc_v, 0,
					sizeof(struct vport_connections_desc));
			}
		}
	}
	return err;
}
#endif /* TKT011436 */

int dpmng_connection_allocate_bandwidth(struct dpmng *dpmng,
	const struct dpmng_accesspoint *ap,
	uint32_t bandwidth)
{
	/*
	 * 	Make a lni key
	 * 	Find LNI database
	 * 	is bandwidth available
	 * 	Allocate bandwidth
	 * 	Make channel key
	 * 	add an entry into channel database
	 * */
	int err = 0;
	uint8_t key_lni[4];
	uint8_t key_cqch[4];
	struct dpmng_lni *lni;
	struct dpmng_cqch *cqch;

	/* make lni key */
	make_key(ap->iop_id, ap->dcp_id, ap->ceetm_id, ap->lniid, key_lni);

	/* Obtain lni database */
	err = hmap_lookup(dpmng->hmap_lni, key_lni, (hmap_data *)&lni);
	if (err != 0)
		return -ENODEV;

	/* is bandwidth available? */
	if (bandwidth > lni->avail_bandwidth)
		return -ENAVAIL;

	/* Make channel key */
	make_key(ap->iop_id, ap->dcp_id, ap->ceetm_id, ap->cqchid, key_cqch);

	/* Add and entry */
	err = hmap_add_key(dpmng->hmap_cqch, key_cqch);
	if (err != 0)
		return err;

	/* Obtain channel database */
	err = hmap_lookup(dpmng->hmap_cqch, key_cqch, (hmap_data *)&cqch);
	if (err != 0)
		return -ENODEV;

	/* Save allocated bandwidth */
	cqch->bandwidth = bandwidth;

	/* Allocate bandwidth */
	lni->avail_bandwidth -= bandwidth;

	return err;
}

int dpmng_connection_free_bandwidth(struct dpmng *dpmng,
	const struct dpmng_accesspoint *ap)
{
	/*
	 *	Find channel database
	 *	Remove an entry
	 *	update bandwidth in lni database
	 */

	int err = 0;
	uint8_t key_cqch[4];
	uint8_t key_lni[4];
	struct dpmng_lni *lni;
	struct dpmng_cqch *cqch;

	/* Make channel key */
	make_key(ap->iop_id, ap->dcp_id, ap->ceetm_id, ap->cqchid, key_cqch);

	/* Obtain channel database */
	err = hmap_lookup(dpmng->hmap_cqch, key_cqch, (hmap_data *)&cqch);
	if (err != 0)
		return -ENODEV;

	/* Remove an entry */
	err = hmap_remove_key(dpmng->hmap_cqch, key_cqch);
	if (err != 0)
		return err;

	/* make lni key */
	make_key(ap->iop_id, ap->dcp_id, ap->ceetm_id, ap->lniid, key_lni);

	/* Obtain lni database */
	err = hmap_lookup(dpmng->hmap_lni, key_lni, (hmap_data *)&lni);
	if (err != 0)
		return -ENODEV;

	/* update bandwidth in lni database */
	lni->avail_bandwidth += cqch->bandwidth;

	return err;
}

int dpmng_phys_allocate_bandwidth(struct dpmng *dpmng,
	const struct dpmng_accesspoint *ap,
	uint32_t bandwidth)
{
	int err = 0;

	err = phys_add_bandwidth(dpmng, ap->iop_id, ap->dcp_id, ap->ceetm_id,
					ap->lniid, bandwidth);

	return err;
}

int dpmng_phys_free_bandwidth(struct dpmng *dpmng,
	const struct dpmng_accesspoint *ap)
{
	int err = 0;

	err = phys_remove_bandwidth(dpmng, ap->iop_id, ap->dcp_id,
					ap->ceetm_id, ap->lniid);

	return err;
}

int dpmng_soc_has_tcam(int eiop_id)
{
	struct ctlu_desc ctlu_desc = { 0 };
	int err;

	ctlu_desc.iop_id = eiop_id;
	ctlu_desc.type = CTLU_EIOP_INGRESS;
	err = sys_get_desc(
		SOC_MODULE_CTLU,
		(SOC_DB_CTLU_DESC_TYPE | SOC_DB_CTLU_DESC_IOP_ID),
		&ctlu_desc, NULL);
	if (err)
		return 0;

	return !!ctlu_desc.num_dptbl_tcam_entries;
}

int dpmng_soc_has_orp() {
	struct qbman_desc qbman_desc;
	int err = 0, iter = 0;

	memset(&qbman_desc, 0, sizeof(struct qbman_desc));
	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
					&qbman_desc, &iter);

	CHECK_COND_RETVAL(err == 0, err);

	return (qbman_desc.num_odps_orps > 0);
}

int dpmng_connection_alloc_lfqmtidx(struct dpmng *dpmng, int *lfqmtidx, int dcp_id, int ceetm_id, int num_res)
{
	char type[16];
	int err = 0;

	snprintf(type, sizeof(type), "lfqmt.ctm%d.ins%d", dcp_id, ceetm_id);
	err = allocate_resource(dpmng->registration.resman_dev, /*Resource manager handle */
				type, /* Resource type */
				num_res, /* Number of resources*/
				1, /* Base align */
				0, /* Options */
				lfqmtidx, /* Address */
				"LFQMTIDX"); /* Error string */

	return err;
}

int dpmng_connection_free_lfqmtidx(struct dpmng *dpmng, int *lfqmtidx, int dcp_id, int ceetm_id, int num_res)
{
	char type[16];
	int result = 0;
	int err;
	int i;

	snprintf(type, sizeof(type), "lfqmt.ctm%d.ins%d", dcp_id, ceetm_id);
	for( i=0 ; i<num_res ; i++ ) {
		err = deallocate_resource(dpmng->registration.resman_dev, type, lfqmtidx[i], "LFQMTIDX");
		if( err ) {
			pr_err("Could not free LFQMTIDX[%d]\n", lfqmtidx[i]);
			result = err;
		}
	}

	return result;
}

#else
/**
 * @brief	DPMNG3.0
 */
static int accesspoints_init_mac(struct dpmng *dpmng);
static int accesspoints_init_pp(struct dpmng *dpmng);
static int accesspoints_init_ap(struct dpmng *dpmng);

static int accesspoints_init_hmap_mac(struct dpmng *dpmng);
static int accesspoints_init_hmap_pp(struct dpmng *dpmng);
static int accesspoints_init_hmap_ap(struct dpmng *dpmng);

static int accesspoints_populate_hmap_mac(struct dpmng *dpmng);
static int accesspoints_populate_hmap_pp(struct dpmng *dpmng);
static int accesspoints_populate_hmap_ap(struct dpmng *dpmng);

static int populate_hmap_mac(
	struct dpmng *dpmng,
	struct pport_connections_desc *desc);

static int populate_hmap_pp(
	struct dpmng *dpmng,
	struct vport_connections_desc *desc,
	enum eiop_port_type type);

static int populate_hmap_ap(
	struct dpmng *dpmng,
	int	iop_id,
	int	dcp_id,
	int	ceetm_id);

static int get_num_macs();
static int get_num_pps();
static int get_num_aps();

static int get_num_iops();
static int get_num_dcps(int iop_id);
static int get_num_instances(int iop_id, int dcp_id);

static void encode_mac_key(int mac_id, hmap_key key);
static void encode_pp_key(
	int iop_id,
	int dcp_id,
	int ceetm_id,
	int lni_id,
	hmap_key key);
static void encode_ap_key(
	int iop_id,
	int dcp_id,
	int ceetm_id,
	int cqchid,
	hmap_key key);
static void decode_pp_key(int *iop_id, int *dcp_id,
	int *ceetm_id, int *lni_id, hmap_key key);

static int init_pp(struct dpmng *dpmng,
	struct vport_connections_desc *desc,
	enum eiop_port_type type,
	struct dpmng_pp	*pp);
static int init_mac(struct dpmng *dpmng,
	struct pport_connections_desc *desc,
	struct dpmng_mac *mac);
static int init_ap(struct dpmng *dpmng,
	int	iop_id,
	int	dcp_id,
	int	ceetm_id,
	struct dpmng_ap *ap);
static int init_pp_lni(struct dpmng *dpmng,
	struct vport_connections_desc *desc,
	enum eiop_port_type type,
	struct dpmng_pp	*pp);
static int init_pp_iop(struct dpmng *dpmng,
	struct vport_connections_desc *desc,
	enum eiop_port_type type,
	struct dpmng_pp	*pp);
static int is_accesspoint_allocate_condition_met(
	const struct dpmng_allocate_cond *cond,
	hmap_key key);
static int accesspoint_allocate(
	struct dpmng *dpmng,
	int iop_id,
	int dcp_id,
	int ceetm_id,
	struct dpmng_accesspoint *ap);

static int accesspoint_set_lni(	struct dpmng *dpmng,
	struct dpmng_accesspoint *ap,
	int lni_id);

static int compose_phys_connection_id(int mac_id);
static int compose_virt_connection_id(struct dpmng_accesspoint *ap1,
	struct dpmng_accesspoint *ap2);

static void decompose_phys_connection_id(int conn_id, int *mac_id);
static void decompose_virt_connection_id(int conn_id,
	struct dpmng_accesspoint *ap1,
	struct dpmng_accesspoint *ap2);
static int decompose_connection_type(int conn_id);
static int get_accesspoint_phys(struct dpmng *dpmng, int conn_id,
	struct dpmng_accesspoint *ap);
static int get_accesspoint_virt(struct dpmng *dpmng, int conn_id,
	int ap_id, struct dpmng_accesspoint *ap);
static int get_accesspoint(struct dpmng *dpmng, int iop_id, int dcp_id,
	int ceetm_id, int cqchid, struct dpmng_accesspoint *ap);
static int connection_virt_allocate_instance_x_1(
	struct dpmng *dpmng, int *conn_id);
static int connection_virt_allocate_instance_x_2(
	struct dpmng *dpmng, int *conn_id);
static int connection_phys_free(struct dpmng *dpmng, int conn_id);
static int connection_virt_free(struct dpmng *dpmng, int conn_id);

int dpmng_accesspoints_init(struct dpmng *dpmng)
{
	int err = 0;

	/* accesspoints */
	err = accesspoints_init_ap(dpmng);
	if (err != 0)
		return err;

	/* recycle path ports */
	err = accesspoints_init_pp(dpmng);
	if (err != 0)
		return err;

	/* macs */
	err = accesspoints_init_mac(dpmng);
	if (err != 0)
		return err;


	return err;
}

static int accesspoints_init_mac(struct dpmng *dpmng)
{
	int err = 0;

	err = accesspoints_init_hmap_mac(dpmng);
	if (err != 0)
		return err;

	err = accesspoints_populate_hmap_mac(dpmng);
	if (err != 0)
		return err;

	return err;
}

static int accesspoints_init_pp(struct dpmng *dpmng)
{
	int err = 0;

	/* Init physical ports hmap */
	err = accesspoints_init_hmap_pp(dpmng);
	if (err != 0)
		return err;

	/* populate physical ports hmap */
	err = accesspoints_populate_hmap_pp(dpmng);
	if (err != 0)
		return err;

	return err;
}

static int accesspoints_init_ap(struct dpmng *dpmng)
{
	int err = 0;

	/* Init accesspoints hmap */
	err = accesspoints_init_hmap_ap(dpmng);
	if (err != 0)
		return err;

	/* Populate accesspoints hmap */
	err = accesspoints_populate_hmap_ap(dpmng);
	if (err != 0)
		return err;

	return err;
}

static int accesspoints_init_hmap_mac(struct dpmng *dpmng)
{
	/*
	 * 	- get number of macs
	 * 	- create hmap
	 * 	- set data
	 * */
	int err = 0, num_macs, i;
	struct dpmng_mac	*mac;

	/* get number of macs */
	num_macs = get_num_macs();

	/* create hmap */
	dpmng->hmap_mac = hmap_create(num_macs, MAC_KEY_SIZE);
	if (dpmng->hmap_mac == NULL)
		return -ENOMEM;

	/* set data */
	for (i = 0; i < num_macs; i++) {
		/* allocate  database */
		mac = fsl_malloc(sizeof(struct dpmng_mac));
		if (mac == NULL)
			return -ENOMEM;

		/* reset database */
		memset(mac, 0x0, sizeof(struct dpmng_mac));

		/* set data into hmap */
		err = hmap_set_data(dpmng->hmap_mac, i, mac);
		if (err != 0)
			return err;
	}
	return err;
}

static int accesspoints_init_hmap_pp(struct dpmng *dpmng)
{
	int err = 0, num_pps, i;
	struct dpmng_pp *pp;

	/* get number of macs */
	num_pps = get_num_pps();

	/* create hmap */
	dpmng->hmap_pp = hmap_create(num_pps, PP_KEY_SIZE);
	if (dpmng->hmap_pp == NULL)
		return -ENOMEM;

	/* set data */
	for (i = 0; i < num_pps; i++) {
		/* allocate  database */
		pp = fsl_malloc(sizeof(struct dpmng_pp));
		if (pp == NULL)
			return -ENOMEM;

		/* reset database */
		memset(pp, 0x0, sizeof(struct dpmng_pp));

		/* set data into hmap */
		err = hmap_set_data(dpmng->hmap_pp, i, pp);
		if (err != 0)
			return err;
	}
	return err;
}

static int accesspoints_init_hmap_ap(struct dpmng *dpmng)
{
	int err = 0, num_aps, i;
	struct dpmng_ap *ap;

	/* get number of macs */
	num_aps = get_num_aps();

	/* create hmap */
	dpmng->hmap_ap = hmap_create(num_aps, AP_KEY_SIZE);
	if (dpmng->hmap_ap == NULL)
		return -ENOMEM;

	/* set data */
	for (i = 0; i < num_aps; i++) {
		/* allocate  database */
		ap = fsl_malloc(sizeof(struct dpmng_ap));
		if (ap == NULL)
			return -ENOMEM;

		/* reset database */
		memset(ap, 0x0, sizeof(struct dpmng_ap));

		/* set data into hmap */
		err = hmap_set_data(dpmng->hmap_ap, i, ap);
		if (err != 0)
			return err;
	}
	return err;
}

static int accesspoints_populate_hmap_mac(struct dpmng *dpmng)
{
	/*
	 * 	- go over pport_connections_desc
	 * 	- add key to hmap_mac
	 * 	- update mac database
	 * 	- add key to hmap_pp
	 * 	- update pp database
	 * */
	int err = 0, iter;
	struct pport_connections_desc pport_desc;
	struct vport_connections_desc vport_desc;

	while (sys_get_desc(
		SOC_MODULE_EIOP_PPORT_CON,
		SOC_DB_NO_MATCH_FIELDS,
		&pport_desc, &iter)
		== 0) {

		/* add an entry into hmap_mac */
		err = populate_hmap_mac(dpmng, &pport_desc);
		if (err != 0)
			return err;

		/* add an entry into hmap_pp */
		vport_desc.eiop_id = pport_desc.eiop_id;
		vport_desc.dcp_id = pport_desc.dcp_id;
		vport_desc.ceetm_id = pport_desc.dcp_id;
		vport_desc.lni_id = pport_desc.dcp_id;
		vport_desc.port_id = pport_desc.dcp_id;
		err = populate_hmap_pp(dpmng, &vport_desc, EIOP_ETHERNET_PORT);
		if (err != 0)
			return err;

	}
	return err;
}

static int accesspoints_populate_hmap_pp(struct dpmng *dpmng)
{
	int err = 0, iter;
	struct vport_connections_desc vport_desc;

	while (sys_get_desc(
		SOC_MODULE_EIOP_VPORT_CON,
		SOC_DB_NO_MATCH_FIELDS,
		&vport_desc, &iter)
		== 0) {

		/* add an entry into hmap_mac */
		err = populate_hmap_pp(dpmng, &vport_desc, EIOP_RECYCLE_PORT);
		if (err != 0)
			return err;
	}
	return err;
}

static int accesspoints_populate_hmap_ap(struct dpmng *dpmng)
{
	int err = 0, num_iops, num_dcps, num_instances, i, j, k;

	/* get number of iops */
	num_iops = get_num_iops();

	for (i = 0; i < num_iops; i++) {
		/* get number of dcps */
		num_dcps = get_num_dcps(i);
		for (j = 0; j < num_dcps; j++) {
			/* get number of instances */
			num_instances = get_num_instances(i, j);
			for (k = 0; k < num_instances; k++) {
				/* add accesspoint into hmap_ap */
				err = populate_hmap_ap(dpmng, i, j, k);
				if (err != 0)
					return err;
			}
		}
	}
	return err;
}

static int populate_hmap_mac(
	struct dpmng *dpmng,
	struct pport_connections_desc *desc)
{
	/*
	 * 	- make mac key
	 * 	- add an entry into hmap_mac
	 * 	- obtain entry database (hmap_lookup)
	 * 	- allocate accesspoint
	 * 	- init database
	 * */
	int err = 0;
	uint8_t		key[MAC_KEY_SIZE];
	struct dpmng_mac	*mac;

	/* make mac key */
	encode_mac_key(desc->mac_id, key);

	err = hmap_add_key(dpmng->hmap_mac, key);
	if (err != 0)
		return err;

	/* obtain entry database */
	err = hmap_lookup(dpmng->hmap_mac, key, (hmap_data *)&mac);
	if (err != 0)
		return err;

	err = init_mac(dpmng, desc, mac);

	return err;
}

static int populate_hmap_pp(
	struct dpmng *dpmng,
	struct vport_connections_desc *desc,
	enum eiop_port_type port_type)
{
	/*
	 * 	- allocate lni
	 * 	- make pp key
	 * 	- add an entry into hmap_pp
	 * 	- obtain entry database (hmap_lookup)
	 * 	- init database
	 * */
	int err = 0;
	uint8_t		key[PP_KEY_SIZE];
	struct dpmng_pp	*pp;
	int		lni_id;
	char 		type[16];

	/* allocate lni */
	/*! Allocate LNI */
	snprintf(type, sizeof(type), "lni.ctm%d.ins%d",
		desc->dcp_id, desc->ceetm_id);
	err = allocate_resource(
		dpmng->registration.resman_dev, /* Resource Manager handle */
		type, 				/* Resource type */
		1, 				/* Number of resources*/
		desc->lni_id, 			/* Base align */
		DPRC_RES_REQ_OPT_EXPLICIT, 	/* Options */
		&(lni_id), 			/* Address */
		"LNIID"); 			/* Error string */
	if (err != 0)
		return err;

	/* make pp key */
	encode_pp_key(desc->eiop_id, desc->dcp_id,
		desc->ceetm_id, lni_id, key);

	/* add an entry into hmap_pp */
	err = hmap_add_key(dpmng->hmap_pp, key);
	if (err != 0)
		return err;

	/* obtain entry database */
	err = hmap_lookup(dpmng->hmap_pp, key, (hmap_data *)&pp);
	if (err != 0)
		return err;

	/* init database */
	err = init_pp(dpmng, desc, port_type, pp);
	if (err != 0)
		return err;

	/* obtain buffer pools here */

	return err;
}

static int populate_hmap_ap(
	struct dpmng *dpmng,
	int	iop_id,
	int	dcp_id,
	int	ceetm_id)
{
	/*
	 * 	- allocate cqchid
	 * 	- make ap key
	 * 	- add an entry into hmap_ap
	 * 	- obtain entry database (hmap_lookup)
	 * 	- Init database
	 * */

	int err = 0, cqchid;
	char type[16];
	uint8_t	key[AP_KEY_SIZE];
	struct  dpmng_ap *ap;

	/* allocate cqchid */
	snprintf(type, sizeof(type), "cqch.ctm%d.ins%d", dcp_id, ceetm_id);
	err = allocate_resource(
		dpmng->registration.resman_dev, /*Resource manager handle */
		type, 				/* Resource type */
		1, 				/* Number of resources*/
		1, 				/* Base align */
		0, 				/* Options */
		&(cqchid), 			/* Address */
		"CQCHID"); 			/* Error string */
	if (err != 0)
		return err;

	/* make ap key */
	encode_ap_key(iop_id, dcp_id, ceetm_id, cqchid, key);

	/* add an entry into hmap_ap */
	err = hmap_add_key(dpmng->hmap_ap, key);
	if (err != 0)
		return err;

	/* obtain entry database */
	err = hmap_lookup(dpmng->hmap_ap, key, (hmap_data *)&ap);
	if (err != 0)
		return err;

	err = init_ap(dpmng, iop_id, dcp_id, ceetm_id, ap);

	return err;
}

static int init_mac(struct dpmng *dpmng,
	struct pport_connections_desc *desc,
	struct dpmng_mac *mac)
{
	int err = 0;
	struct dpmng_accesspoint	ap;

	/* allocate accesspoint */
	err = accesspoint_allocate(
		dpmng,
		desc->eiop_id,
		desc->dcp_id,
		desc->ceetm_id,
		&ap);
	if (err != 0)
		return err;

	/* init database */
	mac->iop_id = desc->eiop_id;
	mac->dcp_id = desc->dcp_id;
	mac->ceetm_id = desc->ceetm_id;
	mac->cqchid = ap.cqchid;

	/* update lni id in accesspoint database */
	err = accesspoint_set_lni(dpmng, &ap, desc->lni_id);

	return err;
}

static int init_ap(struct dpmng *dpmng,
	int	iop_id,
	int	dcp_id,
	int	ceetm_id,
	struct dpmng_ap *ap)
{
/*
 * 	- allocate resource dctidx
 * 	- allocate resource lfqmtidx
 * 	- bandwidth = 0
 * 	- inuse = 0;
 */
	int err = 0;
	char type[16];

	/* Allocate dctidx[8] */
	snprintf(type, sizeof(type), "dct.ctm%d.ins%d", dcp_id, ceetm_id);
	err = allocate_resource(
		dpmng->registration.resman_dev, /*Resource manager handle */
		type, 				/* Resource type */
		8, 				/* Number of resources*/
		1, 				/* Base align */
		0, 				/* Options */
		&(ap->dctidx[0]), 		/* Address */
		"DCTIDX"); 			/* Error string */
	if (err != 0)
		return err;

	/*! lfqmtidx[64] */
	snprintf(type, sizeof(type), "lfqmt.ctm%d.ins%d", dcp_id, ceetm_id);
	err = allocate_resource(
		dpmng->registration.resman_dev, /*Resource manager handle */
		type, 				/* Resource type */
		64, 				/* Number of resources*/
		1, 				/* Base align */
		0, 				/* Options */
		&(ap->lfqmtidx[0]), 		/* Address */
		"LFQMTIDX"); 			/* Error string */
	if (err != 0)
		return err;

	/* init database */
	ap->bandwidth = 0;
	ap->inuse = 0;

	return err;
}

static int init_pp(struct dpmng *dpmng,
	struct vport_connections_desc *desc,
	enum eiop_port_type type,
	struct dpmng_pp	*pp)
{
	int err = 0;

	/* init lni of physical port */
	err = init_pp_lni(dpmng, desc, type, pp);
	if (err != 0)
		return err;

	/* Init eiop physical port */
	err = init_pp_iop(dpmng, desc, type, pp);

	return err;
}

static int init_pp_lni(struct dpmng *dpmng,
	struct vport_connections_desc *desc,
	enum eiop_port_type port_type,
	struct dpmng_pp	*pp)
{
	/*
	 * 	- Get physical port descriptor
	 * 	- Obtain Sub-portal
	 * 	- Compose ceetm id
	 * 	- Sub-Portal Map to LNI
	 * 	- disable lni shaper
	 */
	int err = 0, spid;
        struct eiop_port_desc eiop_desc;
        uint32_t ceetmid;
        void *swp;

        /* Get physical port descriptor */
        memset(&eiop_desc, 0x0, sizeof(struct eiop_port_desc));
        eiop_desc.eiop_id = desc->eiop_id;
        eiop_desc.port_id = desc->port_id;
        err = sys_get_desc(SOC_MODULE_EIOP_PORT,
                                SOC_DB_PORT_DESC_EIOP_ID | SOC_DB_PORT_DESC_ID,
                                &eiop_desc, NULL);
        if (err != 0)
        	return err;

        /* Obtain Sub-portal */
        eiop_port_tx_get_dsp(&eiop_desc, &spid);

        /* Compose ceetm id */
        ceetmid = qbman_ceetmid_compose((uint8_t)desc->dcp_id,
                                        (uint8_t)desc->ceetm_id);

        /* Get software portal */
        err = dpmng_get_swportal(dpmng, &(swp));
        if (err != 0)
                return err;

        /* Sub-Portal Map to LNI */
        err = qbman_subportal_configure(
        	swp, 			/* CEETM SW Portal */
                ceetmid, 		/* CEETM ID */
                (uint8_t)spid, 		/* Sub-Portal ID */
                (uint8_t)(desc->lni_id),/* LNI ID */
                1); 			/* TX Enable */
        if (err != 0)
                return err;

        /*Disable LNI shaper - by setting an infinite token credit rate,
         * thus there is no shaping limitation at LNI level */
        err = qbman_lni_shaper_disable(
        	swp, 			/* software portal */
        	ceetmid,		/* composed */
                (uint32_t)desc->lni_id,	/* lni */
                24);			/* Overhead accounting length */
        if (err != 0)
                return err;

        return err;
}

static int init_pp_iop(struct dpmng *dpmng,
	struct vport_connections_desc *desc,
	enum eiop_port_type type,
	struct dpmng_pp	*pp)
{
        /*
         * 	-if recycle
         *      	-Obtain port descriptor
         *      	-Initialize physical port
         *      	-enable port
         *      ppid
         *      bandwidth
         *      type
         */

	int err = 0;
        struct eiop_port_desc 		eiop_desc;
        struct eiop_port_init_params 	eiop_params;


	if (type == EIOP_RECYCLE_PORT) {
	        /* Get physical port descriptor */
	        memset(&eiop_desc, 0x0, sizeof(struct eiop_port_desc));
	        eiop_desc.eiop_id = desc->eiop_id;
	        eiop_desc.port_id = desc->port_id;
	        err = sys_get_desc(
	        	SOC_MODULE_EIOP_PORT,
	                SOC_DB_PORT_DESC_EIOP_ID | SOC_DB_PORT_DESC_ID,
	                &eiop_desc, NULL);
	        if (err != 0)
	        	return err;

	        /* Initialize Physical Port */
	        eiop_params.rate = EIOP_PORT_RATE_20_G;
	        eiop_params.default_ingress_ifpid = DPMNG_IFP;
	        eiop_params.type = EIOP_RECYCLE_PORT;

	        err = eiop_port_init(&eiop_desc, &eiop_params, 1);
	        if (err != 0)
	                return err;

	        /* Enable port */
	        eiop_port_rx_enable(&eiop_desc);
	        eiop_port_tx_enable(&eiop_desc);

	        /* update bandwidth */
	        pp->bandwidth = DPMNG_RECYCLE_BANDWIDTH;
	}

	/* save information */
	pp->ppid = desc->port_id;
	pp->type = type;

	return err;
}

int dpmng_accesspoint_allocate(
        struct dpmng                    *dpmng,
        const struct dpmng_allocate_cond *cond,
        struct dpmng_accesspoint        *ap)
{
	int err = -ENODEV, iter_status, iter;
	uint8_t	key[PP_KEY_SIZE], winner_key[PP_KEY_SIZE];
	struct dpmng_pp	*pp;
	int iop_id, dcp_id, ceetm_id, lni_id;
	int bandwidth = -1;

	iter_status = hmap_get_start_iterator(dpmng->hmap_pp, &iter);

	while (iter_status == 0) {
		/* Retrieve vlan at iterator and updates iterator */
		iter_status = hmap_iterate(dpmng->hmap_pp, &iter, key,
						(hmap_data *)&pp);

		/* Consider only recycle path ports */
		if (pp->type != EIOP_RECYCLE_PORT)
			continue;

		/* Is accesspoint allocate condition met? */
		if (is_accesspoint_allocate_condition_met(cond, key) == 0)
			continue;

		if (((int)(pp->bandwidth)) > bandwidth) {
			memcpy(winner_key, key, PP_KEY_SIZE);
			bandwidth = (int)pp->bandwidth;
			err = 0;
		}
	}

	if (err == 0) {
		/* obtain physical port parameters */
		decode_pp_key(&iop_id, &dcp_id, &ceetm_id,
		                &lni_id, winner_key);

		/* allocate accesspoint from database */
		err = accesspoint_allocate(dpmng, iop_id, dcp_id, ceetm_id, ap);
		if (err != 0)
			return err;

		/* update lni id in accesspoint database */
		err = accesspoint_set_lni(dpmng, ap, lni_id);
		if (err != 0)
			return err;

		/* update lni */
		ap->lniid = lni_id;
	}

	return err;
}

static void encode_pp_key(
	int iop_id,
	int dcp_id,
	int ceetm_id,
	int lni_id,
	hmap_key key)
{
	/*
	 * 0  	1  	iop
	 * 2    3 	dcp
	 * 4	5	ceetm
	 * 6	13	lni
	 * 14	15	reserved
	 *
	 */

	uint32_t	u_key = 0;

	/* encode uint32 */
	u_key = u32_enc(0, 2, (uint32_t)iop_id);
	u_key |= u32_enc(2, 2, (uint32_t)dcp_id);
	u_key |= u32_enc(4, 2, (uint32_t)ceetm_id);
	u_key |= u32_enc(6, 8, (uint32_t)lni_id);

	/* make string key */
	key[0] = UINT8_LO(UINT16_LO(u_key));
	key[1] = UINT8_HI(UINT16_LO(u_key));
}

static void decode_pp_key(int *iop_id, int *dcp_id,
	int *ceetm_id, int *lni_id, hmap_key key)
{
	uint32_t	u_key;

	/* Make uint16 key from string */
	u_key = MAKE_UINT32(0, MAKE_UINT16(key[1], key[0]));

	/* decode values */
	*iop_id = 	(int)u32_dec(u_key, 0, 2);
	*dcp_id = 	(int)u32_dec(u_key, 2, 2);
	*ceetm_id = 	(int)u32_dec(u_key, 4, 2);
	*lni_id = 	(int)u32_dec(u_key, 6, 8);
}

static void encode_mac_key(int mac_id, hmap_key key)
{
/*
 * 	0	15	mac id
 *
 * */
	uint32_t	u_key = 0;

	/* encode uint32 */
	u_key = u32_enc(0, 16, (uint32_t)mac_id);

	/* make string key */
	key[0] = UINT8_LO(UINT16_LO(u_key));
	key[1] = UINT8_HI(UINT16_LO(u_key));
}
static void decode_mac_key(int *mac_id, hmap_key key)
{
	uint32_t	u_key;

	/* Make uint16 key from string */
	u_key = MAKE_UINT32(0, MAKE_UINT16(key[1], key[0]));

	/* decode value */
	*mac_id = 	(int)u32_dec(u_key, 0, 16);
}


static void encode_ap_key(
	int iop_id,
	int dcp_id,
	int ceetm_id,
	int cqchid,
	hmap_key key)
{
	/*
	 * 0  	1  	iop
	 * 2    3 	dcp
	 * 4	5	ceetm
	 * 6	13	cqchid
	 * 14	15	reserved
	 *
	 */

	uint32_t	u_key = 0;

	/* encode uint32 */
	u_key = u32_enc(0, 2, (uint32_t)iop_id);
	u_key |= u32_enc(2, 2, (uint32_t)dcp_id);
	u_key |= u32_enc(4, 2, (uint32_t)ceetm_id);
	u_key |= u32_enc(6, 8, (uint32_t)cqchid);

	/* make string key */
	key[0] = UINT8_LO(UINT16_LO(u_key));
	key[1] = UINT8_HI(UINT16_LO(u_key));
}

static void decode_ap_key(
	int *iop_id,
	int *dcp_id,
	int *ceetm_id,
	int *cqchid,
	hmap_key key)
{
	uint32_t	u_key;

	/* Make uint16 key from string */
	u_key = MAKE_UINT32(0, MAKE_UINT16(key[1], key[0]));

	/* decode values */
	*iop_id = 	(int)u32_dec(u_key, 0, 2);
	*dcp_id = 	(int)u32_dec(u_key, 2, 2);
	*ceetm_id = 	(int)u32_dec(u_key, 4, 2);
	*cqchid = 	(int)u32_dec(u_key, 6, 8);
}

static int is_accesspoint_allocate_condition_met(
	const struct dpmng_allocate_cond *cond,
	hmap_key key)
{
	int iop_id, dcp_id, ceetm_id, lni_id;

	decode_pp_key(&iop_id, &dcp_id, &ceetm_id, &lni_id, key);

	/**************************Equal**********************/
	/* iop EQ */
	if ((cond->cond_fields & DPMNG_COND_EQ_IOP_ID) != 0) {
		if (iop_id != cond->iop_id)
			return 0;
	}

	/* dcp EQ */
	if ((cond->cond_fields & DPMNG_COND_EQ_DCP_ID) != 0) {
		if (dcp_id != cond->dcp_id)
			return 0;
	}

	/* ceetm EQ */
	if ((cond->cond_fields & DPMNG_COND_EQ_CEETM_ID) != 0) {
		if (ceetm_id != cond->ceetm_id)
			return 0;
	}

	/* lni EQ */
	if ((cond->cond_fields & DPMNG_COND_EQ_LNI_ID) != 0) {
		if (lni_id != cond->lni_id)
			return 0;
	}

	/**************************Not Equal**********************/
	/* iop NEQ */
	if ((cond->cond_fields & DPMNG_COND_NEQ_IOP_ID) != 0) {
		if (iop_id == cond->iop_id)
			return 0;
	}

	/* dcp NEQ */
	if ((cond->cond_fields & DPMNG_COND_NEQ_DCP_ID) != 0) {
		if (dcp_id == cond->dcp_id)
			return 0;
	}

	/* ceetm NEQ */
	if ((cond->cond_fields & DPMNG_COND_NEQ_CEETM_ID) != 0) {
		if (ceetm_id == cond->ceetm_id)
			return 0;
	}

	/* ceetm NEQ */
	if ((cond->cond_fields & DPMNG_COND_NEQ_LNI_ID) != 0) {
		if (lni_id == cond->lni_id)
			return 0;
	}
	return 1;
}

static int accesspoint_allocate(
	struct dpmng *dpmng,
	int iop_id,
	int dcp_id,
	int ceetm_id,
	struct dpmng_accesspoint *ap)
{
	/*
	 * 	- go over database of accesspoints
	 * 	- is accesspoint free?
	 * 	- decode key
	 * 	- compare with required context (iop, dcp and ceetm)
	 * */
	int err = -ENODEV, iter_status, iter;
	struct dpmng_ap	*database;
	uint8_t key[AP_KEY_SIZE];
	int _iop_id, _dcp_id, _ceetm_id, _cqchid;

	iter_status = hmap_get_start_iterator(dpmng->hmap_ap, &iter);

	while (iter_status == 0) {
		/* Retrieve database at iterator and updates iterator */
		iter_status = hmap_iterate(dpmng->hmap_ap, &iter, key,
						(hmap_data *)&database);

		/* is accesspoint free? */
		if (database->inuse == 1)
			continue;

		/* decode key */
		decode_ap_key(&_iop_id, &_dcp_id, &_ceetm_id, &_cqchid, key);

		/* compare with required context */
		if ((_iop_id == iop_id) &&
			(_dcp_id == dcp_id) &&
			(_ceetm_id == ceetm_id)) {
			err = 0;
			break;
		}
	}

	if (err == 0) {
		/* mark accesspoint in use */
		database->inuse = 1;

		err = get_accesspoint(dpmng, iop_id, dcp_id,
		                      ceetm_id, _cqchid, ap);
		if (err != 0)
			return err;
	}
	return err;
}

static int get_num_macs()
{
	int num_macs = 0, iter = 0;
	struct pport_connections_desc desc;

	memset(&desc, 0x0, sizeof(struct pport_connections_desc));

	while (sys_get_desc(
		SOC_MODULE_EIOP_PPORT_CON,
		SOC_DB_NO_MATCH_FIELDS,
		&desc,
		&iter) == 0) {
		num_macs++;
	}

	return num_macs;
}

static int get_num_pps()
{
	int num_pps = 0, num_macs = 0, iter = 0;
	struct vport_connections_desc desc;

	/* obtain macs number */
	num_macs = get_num_macs();

	while (sys_get_desc(
		SOC_MODULE_EIOP_VPORT_CON,
		SOC_DB_NO_MATCH_FIELDS,
		&desc, &iter) == 0) {
		num_pps++;
	}

	return num_pps + num_macs;
}

static int get_num_aps()
{
	int err = 0, num_aps = 0, i, j;
	struct qbman_desc desc;

	memset(&desc, 0x0, sizeof(struct qbman_desc));

	err = sys_get_desc(
		SOC_MODULE_QBMAN, 	/* module */
	        SOC_DB_NO_MATCH_FIELDS, /* match options*/
		&desc, 			/* descriptor */
		NULL); 			/* iterator */
	if (err != 0)
		return err;

	for (i = 0; i < QBMAN_MAX_DCP; i++) {
		if (desc.dcp[i].valid == 1) {
			for (j = 0; j < QBMAN_MAX_CEETM_INS; j++) {
				if (desc.dcp[i].ceetm_instance[j].valid == 1) {
					num_aps += desc.dcp[i].ceetm_instance[j].num_cq_channels;
				}
			}
		}
	}

	return num_aps;
}

static int get_num_iops()
{
	int num_iops = 0, iter = 0;
	struct eiop_desc desc;

	while (sys_get_desc(
		SOC_MODULE_EIOP,
		SOC_DB_NO_MATCH_FIELDS,
		&desc,
		&iter) == 0)
		num_iops++;

	return num_iops;
}
static int get_num_dcps(int iop_id)
{
	int err = 0, num_dcps = 0, i;
	struct qbman_desc desc;

	memset(&desc, 0x0, sizeof(struct qbman_desc));

	err = sys_get_desc(
		SOC_MODULE_QBMAN, 	/* module */
		SOC_DB_NO_MATCH_FIELDS, /* match options*/
		&desc, 			/* descriptor */
		NULL); 			/* iterator */
	if (err != 0)
		return err;

	for (i = 0; i < QBMAN_MAX_DCP; i++) {
		if ((desc.dcp[i].valid == 1)
			&& (desc.dcp[i].ceetm_support == 1))
			num_dcps++;
	}

	return num_dcps;
}

static int get_num_instances(int iop_id, int dcp_id)
{
	int err = 0, num_instances = 0, i;
	struct qbman_desc desc;

	memset(&desc, 0x0, sizeof(struct qbman_desc));

	err = sys_get_desc(
		SOC_MODULE_QBMAN, 	/* module */
	        SOC_DB_NO_MATCH_FIELDS, /* match options*/
		&desc, 			/* descriptor */
		NULL); 			/* iterator */
	if (err != 0)
		return err;

	for (i = 0; i < QBMAN_MAX_CEETM_INS; i++) {
		if (desc.dcp[dcp_id].valid
			&& desc.dcp[dcp_id].ceetm_instance[i].valid)
			num_instances++;
	}

	return num_instances;
}

int dpmng_init_rtn_fqid(struct dpmng *dpmng)
{
	/* 	Allocate access point
	 * 	Allocate IFP
	 * 	Create ceetm interface
	 * 	associate accesspoint with ceetm interface
	 * 	Associate with recycle
	 */

	int err = 0;
	return err;
}

int dpmng_get_rtn_fqid(struct dpmng *dpmng)
{
	/*
	 * 	get attributes of ceetm interface
	 * 	return lfqid
	 * */
	int err = 0;
	return err;
}

int dpmng_connection_phys_allocate(struct dpmng *dpmng,
	int mac_id,
	int *conn_id)
{
	/*
	 * 	- encode a mac key
	 * 	- if entry free, mark as used
	 * 	- compose connection id
	 * */
	int err = 0;
	uint8_t 		key[MAC_KEY_SIZE];
	struct dpmng_mac	*mac;

	/* encode a mac key */
	encode_mac_key(mac_id, key);

	err = hmap_lookup(dpmng->hmap_mac, key, (hmap_data *)&mac);
	if (err != 0)
		return err;

	if (mac->inuse == 1)
		return -EEXIST;

	/* compose connection id */
	*conn_id = compose_phys_connection_id(mac_id);

	/* allocate mac */
	mac->inuse = 1;

	return err;
}

int dpmng_connection_get_accesspoint(struct dpmng *dpmng,
	int conn_id,
	int ap_id,
	struct dpmng_accesspoint *ap)
{
	/*
	 * 	- extract connection type from connection id
	 * 	- 	#physical connection
	 * 		#Virtual connection
	 *
	 * */
	int err = 0, conn_type;

	/* extract connection type from connection id */
	conn_type = decompose_connection_type(conn_id);

	switch (conn_type) {
		case PHYS_CONN_TYPE:
			err = get_accesspoint_phys(dpmng, conn_id, ap);
			break;
		case VIRT_CONN_TYPE:
			err = get_accesspoint_virt(dpmng, conn_id, ap_id, ap);
			break;
		default:
			err = -EINVAL;
			break;
	}

	return err;
}

/* This API should be deleted */
int dpmng_connection_virt_lniid(struct dpmng *dpmng,
	struct dpmng_accesspoint *ap)
{
	int err = 0;
	return err;
}

int dpmng_connection_free(struct dpmng *dpmng, int conn_id)
{
	/*
	 * 	- extract connection type from connection id
	 * 	- 	#physical connection
	 * 			- decode mac from connection id
	 * 			- encode a mac key
	 * 			- lookup for mac entry
	 * 			- mark free
	 * 		#Virtual connection
	 * 			- decode corresponding accesspoint information
	 * 			- encode accesspoint key
	 * 			- lookup for accesspoint entries
	 * 			- mark as free
	 *
	 * */
	int err = -EINVAL, conn_type;

	/* extract connection type from connection id */
	conn_type = decompose_connection_type(conn_id);

	switch (conn_type) {
		case PHYS_CONN_TYPE:
			err = connection_phys_free(dpmng, conn_id);
			break;
		case VIRT_CONN_TYPE:
			err = connection_virt_free(dpmng, conn_id);
			break;
		default:
			break;
	}

	return err;
}

int dpmng_connection_virt_allocate(struct dpmng *dpmng, int *conn_id)
{
	/*
	 * 	- Get number of CEETM instances
	 * 	- if number of ceetm instances is
	 * 		#1 allocate accesspoints belong to belong to different
	 * 			LNIs by using dpmng_accesspoint_allocate()
	 * 		#2 allocate accesspoints belong to belong to different
	 * 			CEETMs by using dpmng_accesspoint_allocate()
	 * 	- Compose connection ID
	 */
	int err = -ENOTSUP, num_instances;

	/* Get number of CEETM instances */
	num_instances = get_num_instances(0, 0);

	switch (num_instances) {
		case 1:
			err = connection_virt_allocate_instance_x_1(
				dpmng, conn_id);
			break;
		case 2:
			err = connection_virt_allocate_instance_x_2(
				dpmng, conn_id);
			break;
		default:
			break;
	}
	return err;
}

int dpmng_accesspoint_free(
        struct dpmng                    *dpmng, /* DPMNG context */
        struct dpmng_accesspoint        *ap     /* accesspoint */
        )
{
	int err = 0;

	return err;
}

int dpmng_connection_allocate_bandwidth(struct dpmng *dpmng,
	const struct dpmng_accesspoint *ap,
	uint32_t bandwidth)
{
/*
 * 	- Compose key for physical port mapping
 * 	- add allocated bandwidth to physical port database
 * 	- compose key for accesspoint mapping
 * 	- save allocated bandwidth in accesspoint database
 *
 * */
	int err = 0;
	return err;
}

int dpmng_connection_free_bandwidth(struct dpmng *dpmng,
	const struct dpmng_accesspoint *ap)
{
	int err = 0;

	/*
	 * 	- compose key for accesspoint mapping
	 * 	- obtain bandwidth allocated by accesspoint
	 * 	- compose key for physical port mapping
	 * 	- remove allocated bandwidth from physical port database
	 * */
	return err;
}

static int compose_phys_connection_id(int mac_id)
{
/*
 * 	30-31	connection type
 * 	16-29	reserved
 * 	0-15	mac id
 * */
	int reserved = 0;

	return (((PHYS_CONN_TYPE & 0x3) << 30) |
		((reserved & 0x3FFF) << 16) |
		((mac_id & 0xFFFF) << 0));
}

static int compose_virt_connection_id(struct dpmng_accesspoint *ap1,
	struct dpmng_accesspoint *ap2)
{
/*
 * 	bits	description	size
 **************************************
 * 	30-31 	connection type	2
 * 	22-29	cqch2		8
 * 	20-21	ceetm2		2
 * 	18-19	dcp2		2
 * 	16-17	iop2		2
 * 	14-15	reserved	2
 * 	6-13	cqch1		8
 * 	4-5	ceetm1		2
 * 	2-3	dcp1		2
 * 	0-1	iop1		2
 * */
	int reserved = 0;

	return (((VIRT_CONN_TYPE & 0x3) << 30) |
		((ap2->cqchid & 0xFF) << 22) |
		((ap2->ceetm_id & 0x3) << 20) |
		((ap2->dcp_id & 0x3) << 18) |
		((ap2->iop_id & 0x3) << 16) |
		((reserved & 0x3) << 14) |
		((ap1->cqchid & 0xFF) << 6) |
		((ap1->ceetm_id & 0x3) << 4) |
		((ap1->dcp_id & 0x3) << 2) |
		((ap1->iop_id & 0x3) << 0));
}

static void decompose_phys_connection_id(int conn_id, int *mac_id)
{
	/*
	 * 	30-31	connection type
	 * 	16-29	reserved
	 * 	0-15	mac id
	 * */
	*mac_id = (conn_id >> 0) & 0xFFFF;
}

static void decompose_virt_connection_id(int conn_id,
	struct dpmng_accesspoint *ap1,
	struct dpmng_accesspoint *ap2)
{
	/*
	 * 	bits	description	size
	 **************************************
	 * 	30-31 	connection type	2
	 * 	22-29	cqch2		8
	 * 	20-21	ceetm2		2
	 * 	18-19	dcp2		2
	 * 	16-17	iop2		2
	 * 	14-15	reserved	2
	 * 	6-13	cqch1		8
	 * 	4-5	ceetm1		2
	 * 	2-3	dcp1		2
	 * 	0-1	iop1		2
	 * */

	ap2->cqchid = (conn_id >> 22) & 0xFF;
	ap2->ceetm_id = (conn_id >> 20) & 0x3;
	ap2->dcp_id = (conn_id >> 18) & 0x3;
	ap2->iop_id = (conn_id >> 16) & 0x3;

	ap1->cqchid = (conn_id >> 6) & 0xFF;
	ap1->ceetm_id = (conn_id >> 4) & 0x3;
	ap1->dcp_id = (conn_id >> 4) & 0x3;
	ap1->iop_id = (conn_id >> 0) & 0x3;
}

static int decompose_connection_type(int conn_id)
{
	return (conn_id >> 30) & 0x3;
}

static int get_accesspoint_phys(struct dpmng *dpmng, int conn_id,
	struct dpmng_accesspoint *ap)
{
	/*
	 * 	- decode mac from connection id
	 * 	- encode a mac key
	 * 	- lookup for mac entry
	 * 	- encode accesspoint key
	 * 	- lookup for accesspoint entry
	 */
	int err = 0, mac_id;
	uint8_t	mac_key[MAC_KEY_SIZE];
	struct dpmng_mac	*mac_database;

	/* decode mac from connection id */
	decompose_phys_connection_id(conn_id, &mac_id);

	/* encode a mac key */
	encode_mac_key(mac_id, mac_key);

	/* lookup for mac entry */
	err = hmap_lookup(dpmng->hmap_mac, mac_key, (hmap_data *)&mac_database);
	if (err != 0)
		return err;

	if (mac_database->inuse == 0)
		return -EACCES;

	/* read accesspoint from database */
	err = get_accesspoint(dpmng, mac_database->iop_id,
	                      mac_database->dcp_id, mac_database->ceetm_id,
	                      mac_database->cqchid, ap);

	return err;
}
static int get_accesspoint_virt(struct dpmng *dpmng, int conn_id,
	int id, struct dpmng_accesspoint *ap)
{
	/*
	 * 	- decode corresponding accesspoint information
	 * 	- encode accesspoint key
	 * 	- lookup for accesspoint entry
	 *
	 * */
	int err;
	struct dpmng_accesspoint apx[2];

	/* obtain accesspoint from virtual connection */
	decompose_virt_connection_id(conn_id, &apx[0], &ap[1]);

	/* read accesspoint from database */
	err = get_accesspoint(dpmng, apx[id].iop_id,
	                      apx[id].dcp_id, apx[id].ceetm_id,
	                      apx[id].cqchid, ap);

	return err;
}

static int accesspoint_set_lni(	struct dpmng *dpmng,
	struct dpmng_accesspoint *ap,
	int lni_id)
{
	int err = 0;
	struct dpmng_ap		*ap_database;
	uint8_t			ap_key[AP_KEY_SIZE];

	/* encode accesspoint key */
	encode_ap_key(ap->iop_id, ap->dcp_id,
		ap->ceetm_id, ap->cqchid, ap_key);

        /* lookup for accesspoint entry */
        err = hmap_lookup(dpmng->hmap_ap, ap_key, (hmap_data *)&ap_database);
        if (err != 0)
                return err;

        /* update lni id in accesspoint database */
        ap_database->lni_id = lni_id;

        return err;
}

static int get_accesspoint(struct dpmng *dpmng, int iop_id, int dcp_id,
	int ceetm_id, int cqchid, struct dpmng_accesspoint *ap)
{

	int err = 0;
	struct dpmng_ap		*ap_database;
	uint8_t			ap_key[AP_KEY_SIZE];

	/* encode accesspoint key */
	encode_ap_key(iop_id, dcp_id, ceetm_id, cqchid, ap_key);

        /* lookup for accesspoint entry */
        err = hmap_lookup(dpmng->hmap_ap, ap_key, (hmap_data *)&ap_database);
        if (err != 0)
                return err;

	/* update accesspoint information */
	ap->iop_id = iop_id;
	ap->dcp_id = dcp_id;
        ap->ceetm_id = ceetm_id;
	ap->cqchid = cqchid;

	/* from database */
	ap->lniid = ap_database->lni_id;
	ap->ifpid = ap_database->ifpid;
	memcpy(&(ap->dctidx[0]), &(ap_database->dctidx[0]), (sizeof(int) * 8));
	memcpy(&(ap->lfqmtidx[0]), &(ap_database->lfqmtidx[0]), (sizeof(int) * 64));

	return err;
}

static int connection_virt_allocate_instance_x_1(
	struct dpmng *dpmng, int *conn_id)
{
	int err = 0;
	struct dpmng_accesspoint       	ap1, ap2;
	struct dpmng_allocate_cond 	cond;

	memset(&cond, 0x0, sizeof(struct dpmng_allocate_cond));

	/* allocate first accesspoint */
	err = dpmng_accesspoint_allocate(dpmng, &cond, &ap1);
	if (err != 0)
		return err;

	/* allocate second accesspoint */
	err = dpmng_accesspoint_allocate(dpmng, &cond, &ap2);
	if (err != 0)
		return err;

	/* Compose connection id */
	*conn_id = compose_virt_connection_id(&ap1, &ap2);

	return err;
}

static int connection_virt_allocate_instance_x_2(
	struct dpmng *dpmng, int *conn_id)
{
	int err = 0;
	struct dpmng_accesspoint       	ap1, ap2;
	struct dpmng_allocate_cond 	cond;

	memset(&cond, 0x0, sizeof(struct dpmng_allocate_cond));

	/* allocate first accesspoint */
	cond.ceetm_id = 0;
	cond.cond_fields = DPMNG_COND_EQ_CEETM_ID;
	err = dpmng_accesspoint_allocate(dpmng, &cond, &ap1);
	if (err != 0)
		return err;

	/* allocate second accesspoint */
	cond.ceetm_id = 1;
	err = dpmng_accesspoint_allocate(dpmng, &cond, &ap2);
	if (err != 0)
		return err;

	/* Compose connection id */
	*conn_id = compose_virt_connection_id(&ap1, &ap2);

	return err;
}

static int connection_phys_free(struct dpmng *dpmng, int conn_id)
{
	/*	- decode mac from connection id
	 * 	- encode a mac key
	 * 	- lookup for mac entry
	 * 	- mark free
	 */
	int err = 0, mac_id;
	uint8_t	mac_key[MAC_KEY_SIZE];
	struct dpmng_mac	*mac_database;

	/* decode mac from connection id */
	decompose_phys_connection_id(conn_id, &mac_id);

	/* encode a mac key */
	encode_mac_key(mac_id, mac_key);

	/* lookup for mac entry */
        err = hmap_lookup(dpmng->hmap_mac, mac_key, (hmap_data *)&mac_database);
        if (err != 0)
                return err;

        if (mac_database->inuse == 0)
        	return -EACCES;

        /* mark free */
        mac_database->inuse = 0;

        return err;
}

static int connection_virt_free(struct dpmng *dpmng, int conn_id)
{
	 /*
	  * 	- decode corresponding accesspoint information
	 * 	- encode accesspoint key
	 * 	- lookup for accesspoint entries
	 * 	- mark as free
	 */
	int err = 0;
	struct dpmng_accesspoint ap1, ap2;

	/* decompose virtual connection */
	decompose_virt_connection_id(conn_id, &ap1, &ap2);

	/* free first accesspoint */
	err = dpmng_accesspoint_free(dpmng, &ap1);
	if (err != 0)
		return err;

	/* free second accesspoint */
	err = dpmng_accesspoint_free(dpmng, &ap2);
	if (err != 0)
		return err;

	return err;
}

#endif /* #define DPMNG3_0 */
