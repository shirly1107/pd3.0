/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_gen.h"
#include "common/fsl_string.h"
#include "fsl_soc.h"
#include "fsl_platform.h"
#include "kernel/device.h"
#include "fsl_dbg.h"
#include "dplib/fsl_dpmng_cmd.h"
#include "fsl_cmdif_mc.h"
#include "fsl_cmdif.h"
#include "drivers/fsl_aiop.h"
#include "fsl_dpmng_mc.h"
#include "drivers/fsl_mc.h"
#include "fsl_resman.h"
#include "fsl_event_pipe.h"
#include "fsl_eiop.h"
#include "fsl_eiop_port.h"
#include "fsl_qbman.h"
#include "dpmng_cmd.h"

#define CMD_READ(_param, _offset, _width, _type, _arg) \
	_arg = (_type)u64_dec(swap_uint64(cmd_data->params[_param]), _offset, _width);

#define RSP_PREP(_param, _offset, _width, _type, _arg) \
	cmd_data->params[_param] |= swap_uint64(u64_enc(_offset, _width, _arg));

int dpmng_drv_init(void);
int dpmng_drv_post_controllers_init(void);

/**
 * @brief	static functions declaration
 */
/* dpmng_drv_init */
static int drv_init_swp(struct dpmng *dpmng, int num_of_cores);

static int get_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct mc_version tmp = { 0 };
	struct mc_version *mc_ver_info = &tmp;
	UNUSED(dev);
	mc_get_version(mc_ver_info);
	/* recieve out parameters */

	DPMNG_RSP_GET_VERSION(cmd_data, mc_ver_info);

	return 0;
}

static int get_soc_version(struct device *dev, struct mc_cmd_data *cmd_data)
{
	struct mc_soc_version tmp = { 0 };
	struct mc_soc_version *mc_soc_info = &tmp;
	UNUSED(dev);

	mc_get_platform(mc_soc_info);

	DPMNG_RSP_GET_SOC_VERSION(cmd_data, mc_soc_info);

	return 0;
}

static int reset_mc_portal(struct device *dev, struct mc_cmd_data *cmd_data)
{
	return 0;
}

static int dpmng_open_cb_dummy(void *dev, int portal_id)
{
	UNUSED(dev);
	UNUSED(portal_id);
	return 0;
}

static int dpmng_close_cb_dummy(void *dev, int portal_id, uint32_t token)
{
	UNUSED(dev);
	UNUSED(portal_id);
	UNUSED(token);
	return 0;
}

static int dpmng_ctrl_cb(void *dev, uint8_t cmd_ver, uint16_t cmd, int portal_id, uint8_t *data)
{
	struct mc_cmd_data *cmd_data = (struct mc_cmd_data *)data;
	int i;
	struct {
		int code;
		int (*function)(struct device *dev,
			struct mc_cmd_data *cmd_data);
		char *cmd_str;
                uint8_t ver;
	} map_commands[] = {
	                    { DPMNG_CMD_CODE_GET_VERSION, get_version, "dpmng_get_version", DPMNG_CMD_VER_BASE }, 
	                    { DPMNG_CMD_CODE_SOC_VERSION, get_soc_version, "dpmng_get_platform", DPMNG_CMD_VER_BASE }
	};

	UNUSED(portal_id);

	for (i = 0; i < ARRAY_SIZE(map_commands); i++)
		if ((cmd == map_commands[i].code) &&
                    ((cmd_ver == MC_CMD_HDR_NO_VER) || (cmd_ver == map_commands[i].ver))) {
			pr_info("Handling command: %s on DPMNG\n", map_commands[i].cmd_str);
			return map_commands[i].function((struct device *)dev,
							cmd_data);
		}
	return -ENOTSUP;
}

static int drv_init_swp(struct dpmng *dpmng, int num_of_cores)
{
	int i;
	struct dpmng_portal_cfg portal_cfg;

	/* initialize portal per mc core */
	for (i = 0; i < num_of_cores; i++) {
		memset(&portal_cfg, 0, sizeof(struct dpmng_portal_cfg));
		portal_cfg.index = i;

		dpmng_init_swportal(dpmng, &portal_cfg);
		if (portal_cfg.swp == NULL)
			return -ENODEV;
		sys_add_handle(portal_cfg.swp, FSL_MOD_QBMAN_PORTAL, 1,
		               portal_cfg.swportal_id);
	}

	return 0;
}

int dpmng_drv_init(void)
{
	struct dpmng *dpmng;
	struct dpmng_cfg cfg;
	struct resman *resman;
	struct device *device = NULL;
	int err = 0;
	struct mc_desc mc_desc;
	struct dpmng_register register_cfg;
	struct eiop_desc eiop_desc;
	struct qbman_desc qbman_desc;
	struct cmdif_module_ops cmdif_ops = { 0 };
	struct dpmng_amq mc_amq;

	pr_info("Executing dpmng_drv_init...\n");

	memset(&cfg, 0, sizeof(struct dpmng_cfg));
	memset(&mc_desc, 0, sizeof(struct mc_desc));
	memset(&eiop_desc, 0, sizeof(struct eiop_desc));
	memset(&qbman_desc, 0, sizeof(struct qbman_desc));

	err = sys_get_desc(SOC_MODULE_QBMAN, SOC_DB_NO_MATCH_FIELDS,
				&qbman_desc, NULL);
	ASSERT_COND(!err);

	if (qbman_desc.disable)
	{
		pr_err("QBMan disabled, MC boot failed.");
		return -EINVAL;
	}

	/* initialize resources for dpmng */
	resman = (struct resman *)sys_get_unique_handle(FSL_MOD_RESMAN);
	if (resman == NULL)
		return -ENODEV;

	device = resman_create_mc_device(resman);
	ASSERT_COND(device);

	dpmng = device_get_priv(device);
	if (!dpmng) {
		dpmng = dpmng_allocate();
		if (!dpmng) {
			pr_err("No memory for dpmng\n");
			return -ENOMEM;
		}

		register_cfg.resman_dev = device;

		dpmng_register(dpmng, &register_cfg);

		/* get mc descriptor */
		err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, NULL);
		if (err != 0)
			return err;

		/*! number of cores */
		cfg.num_cores = mc_desc.num_cores;

		/*! Init DPMNG */
		err = dpmng_init(dpmng, &cfg);
		if (err)
			return err;

		sys_add_handle(dpmng, FSL_MOD_DPMNG, 1, 0);

		dpmng_get_amq(&mc_amq);
		dpmng_mc_set_ccsr_window(0x0, &mc_amq);
	}

	err = dpmng_init_management_port(dpmng);
	if (err)
		return err;

	/*register to cmdif */
	cmdif_ops.open_cb = dpmng_open_cb_dummy;
	cmdif_ops.close_cb = dpmng_close_cb_dummy;
	cmdif_ops.ctrl_cb = dpmng_ctrl_cb;
	cmdif_ops.cmd_priority_cb = NULL;
	cmdif_register_module((enum cmdif_module)0x31, &cmdif_ops);
	cmdif_register_module((enum cmdif_module)0x32, &cmdif_ops);
	cmdif_register_module((enum cmdif_module)0x33, &cmdif_ops);
	cmdif_register_module((enum cmdif_module)0x34, &cmdif_ops);
	cmdif_register_module((enum cmdif_module)0x35, &cmdif_ops);

	return err;
}

#ifdef TKT011436 
int dpmng_post_controllers_restore(void)
{
	struct dpmng *dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	int err = 0;

	CHECK_COND_RETVAL(dpmng, -EINVAL, "Cannot get dpmng handle\n" );

	err = dpmng_connections_restore(dpmng);
	CHECK_COND_RETVAL(!err, err, "dpmng_connections_restore Failed\n" );

	err = dpmng_restore_plcrid(dpmng);
	CHECK_COND_RETVAL(!err, err, "dpmng_restore_plcrid Failed\n" );

	return err;
}
#endif /* TKT011436 */

int dpmng_drv_post_controllers_init(void)
{
	struct dpmng *dpmng = sys_get_unique_handle(FSL_MOD_DPMNG);
	struct mc_desc mc_desc;
	int err = 0;

	ASSERT_COND(dpmng);
	pr_info("Executing dpmng_drv_post_controllers_init...\n");
	/* get mc descriptor */
	memset(&mc_desc, 0, sizeof(struct mc_desc));
	err = sys_get_desc(SOC_MODULE_MC, 0, &mc_desc, NULL);
	if (err != 0)
		return err;

	/*! Init QMan software portals */
	err = drv_init_swp(dpmng, mc_desc.num_cores);
	if (err)
		return err;

	/*! DPMN2.0 init */
#ifdef DPMNG3_0
	err = dpmng_accesspoints_init(dpmng);
#else
	err = dpmng_connections_init(dpmng);
#endif
	if (err)
		return err;

	err = dpmng_init_dcp_wqid(dpmng);
	if (err)
		return err;

	err = dpmng_init_rerr_fqid(dpmng);
	if (err)
		return err;

	err = dpmng_init_cgid(dpmng);
	if (err)
		return err;

	err = dpmng_init_plcrid(dpmng);
#ifdef TKT220573
	if (err)
		return err;

	err = dpmng_init_rtn_fqid(dpmng);
#endif

	return err;
}
