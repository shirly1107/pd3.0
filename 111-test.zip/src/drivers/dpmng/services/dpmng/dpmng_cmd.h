/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DPMNG_CMD_H
#define _DPMNG_CMD_H

/* default version for all dpmng commands */
#define DPMNG_CMD_VER_BASE                       CMDHDR_CMD_VERSION(MC_CMD_HDR_BASE_VER)

/* add your new command version number here
 * Ex:
 * #define DPMNG_CMD_CREATE_VER_1                MC_CMD_HDR_VERSION(DPMNG_CMD_VER_BASE + 1) or
 * #define DPMNG_CMD_CREATE_VER                  MC_CMD_HDR_VERSION(3)
 */

/* Command Codes */
#define DPMNG_CMD_CODE_GET_VERSION                 0x831
#define DPMNG_CMD_CODE_SOC_VERSION                 0x832

#endif /* _DPMNG_CMD_H */
