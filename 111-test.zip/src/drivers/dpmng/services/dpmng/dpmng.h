/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          dpmng.h

 @Description   dpmng internal structures and definitions.
 *//***************************************************************************/
#ifndef __DPMNG_H
#define __DPMNG_H

#include "kernel/device.h"
#include "fsl_types.h"
#include "fsl_dpmng_mc.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_DPMNG

#define GSR_STATUS_MASK 	0xCFFFFFFF
#define BIG_NUMBER		0x7FFFFFFF

#define NUM_SMART_NIC_CEETM_CHANNELS	2
#ifdef TKT220573
#define NUM_RTN_FQID_CEETM_CHANNELS	1
#else
#define NUM_RTN_FQID_CEETM_CHANNELS     0
#endif
#define NUM_RESERVED_CEETM_CHANNELS	(NUM_SMART_NIC_CEETM_CHANNELS +\
					NUM_RTN_FQID_CEETM_CHANNELS)

/* AMQ - DON'T CHANGE */
#define DPMNG_AMQ_BDI           1 /* Bypass LDPAA Isolation */
#define DPMNG_AMQ_ICID          0 /* Isolation Context ID */
#define DPMNG_AMQ_VA            0 /* Virtual Address */
#define DPMNG_AMQ_BMT           1 /* Bypass Memory Translation */
#define DPMNG_AMQ_PL            1 /* Privilege level */

#define DPMNG_AMQ_VA_MASK       0x00010000 /* Virtual Address mask */
#define DPMNG_AMQ_BMT_MASK      0x00020000 /* Bypass Memory Translation mask */
#define DPMNG_AMQ_PL_MASK       0x00040000 /* Privilege level mask */

#define DPMNG_RECYCLE_BANDWIDTH	20000

#define NUM_OF_DPSW_POOLS	1
#define NUM_OF_DPDMUX_POOLS	3
#define NUM_OF_SNIC_POOLS	10

#define DPSW_DPBP_SIZE		2*MEGABYTE;
#define DPDMUX_DPBP_SIZE	256*KILOBYTE;
#define SNIC_DPBP_SIZE		25*KILOBYTE;

#define MCFBALR_MASK		0xE0000000
#define MCFBAHR_MASK		0x0000FFFF

#define DPMNG_DDR_BLOCK_SIZE (256 * (uint64_t)MEGABYTE)
struct dpbp_paddr {
	int used;
	phys_addr_t paddr;
};

struct dpbp_paddrs_by_pool_size {
	uint32_t size;
	uint32_t alignment;
	int num_of_pools;
	struct dpbp_paddr dpbp_paddr[10];
};

/**
 * @brief	DPMNG2.0
 */
#define DPMNG_IFP	0

enum dpmng_connection_type {
	DPMNG_CONNECTION_TYPE_VIRT = 0,
	DPMNG_CONNECTION_TYPE_PHYS
};

struct dpmng_virt_connection {
        struct dpmng_accesspoint 	ap[2];  /* Accesspoints */
        int             	 	inuse;  /* in use */
};

struct dpmng_phys_connection {
        struct dpmng_accesspoint 	ap;	/* Accesspoint */
        int             		lniid;
        int             		ppid;
        int             		mac_id;
};

struct dpmng_recycle {
        int ceetm_id;
        int lniid;
        int ppid;
};

struct dpmng_dcp {
	/*! Number of connections */
        int                         num_phys;
        int                         num_virt;
        /*! Number of recycles */
        int                         num_recycle;
        /*! database */
        struct  dpmng_phys_connection    *phys_conn;    /* Physical x 16 */
        struct  dpmng_virt_connection    *virt_conn;    /* Virtual x 32 */
        struct  dpmng_recycle            *recycle;      /* Recycle x 2 */
        /*! Statistics/load*/
        int     virt_cnt;                               /* Number of virt */
};

struct dpmng_iop {
	/* Connections */
	int                	num_dcps;
        struct dpmng_dcp        *dcp;     	/* dcp database */
};

/* Key - IOP, DCP, CH [4][4][8] */
struct dpmng_cqch {
        int             lniid;                  /* Logical Network Interface ID */
        uint32_t        bandwidth;              /* Allocated bandwidth */
};

/* Key - IOP, DCP, LNI [4][4][8] */
struct dpmng_lni {
        uint32_t        avail_bandwidth;          /* Available bandwidth */
};

#define SIZE_SCRATCH_MAP 1024

struct scratch_map{
	uint8_t		*data;
	int			inuse;
};

struct dpmng {
	struct dpmng_register registration; /* Resource Manager information */

	/* Software Portal management */
	int *swportal_id; /* array of software portal ids*/
	/* TODO  -check if the lock is int */
	int *sw_portal_lock; /* array of locks per software portal */

	/* global use */
	int cgid; /* CGID with tail-drop '0' */
	int plcrid; /* Policer-ID with pass-through & green color */
#ifdef TKT220573
	struct dpmng_accesspoint rtn_fqid_ap;	/* Return FQID, used by en-queue
						replicator for returning the
						original source FD */
#endif
	uint64_t shaper_rate_limit;
	uint16_t dcp_wqid[QBMAN_MAX_DCP];

	int lock;

	int aiop_container_id;

	void *mc_vaddr;
	void *soc_ccsr;

	uint32_t saved_reg0;
	uint32_t saved_reg1;
	uint32_t saved_reg2;

	struct dpbp_paddrs_by_pool_size dpbp_paddrs_by_pool_size[3];
	
	struct scratch_map scratch_memory;

	/* DPMNG2.0 */
	struct dpmng_iop  	*iop;
	int 			num_iops; 	/* Number of WRIOPs */

    /* Bandwidth allocation */
    struct hmap             *hmap_cqch;  	/* Channels database */
    struct hmap             *hmap_lni;      /* LNIs database */

	/* DPMNG3.0 */ 
    struct hmap             *hmap_mac;      /* mac lookup */
    struct hmap             *hmap_pp;      	/* physical port lookup */
    struct hmap             *hmap_ap;      	/* accesspoint lookup */
};

/**
 * @brief	DPMNG3.0
 */
#define MAC_KEY_SIZE		2	/* mac hmap lookup table */
#define AP_KEY_SIZE		2	/* accesspoint hmap lookup table */
#define PP_KEY_SIZE		2	/* physical port hmap lookup table */
#define VIRT_CONN_KEY_SIZE	4	/* virtual connection */
#define PHYS_CONN_KEY_SIZE	4	/* physical connection */
#define PHYS_CONN_TYPE		0
#define VIRT_CONN_TYPE		1

/**
 * @brief	accesspoint database
 * 		key - iop, dcp, ceetm, cqch
 */
struct  dpmng_ap {
        int             ifpid;      	/* IFPID */
	int 		dctidx[8]; 	/* DCTable index */
	int 		lfqmtidx[64]; 	/* Logical frame queue index */        
        uint32_t	bandwidth;	/* save allocated bandwidth */
	int		lni_id;		/* valid only when in use */
        int		inuse;
};

/**
 * @brief	physical port database
 * 		key - iop, dcp, ceetm, lni
 */
struct dpmng_pp {
	enum eiop_port_type 	type;	/*EIOP_ETHERNET_PORT/EIOP_RECYCLE_PORT*/
        int             	ppid;	/* physical port id */
        uint32_t		bandwidth;
        /* buffer pools here */
};

/**
 * @brief	physical port database
 * 		key - mac id
 */
struct dpmng_mac {
	int			iop_id;
	int 			dcp_id;
	int			ceetm_id;
	int			cqchid;
	int			inuse;
};


#endif /* __DPMNG_H */
