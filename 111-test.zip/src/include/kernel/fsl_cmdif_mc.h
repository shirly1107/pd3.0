/*
 * Copyright 2013-2016, Freescale Semiconductor, Inc.
 * Copyright 2017-2020 NXP
 */

#ifndef __FSL_MC_CMDIF_H
#define __FSL_MC_CMDIF_H

#define MC_CMD_HDR_NO_VER               0x0
#define MC_CMD_HDR_BASE_VER             0x1

/* offsets and sizes used in old command header format */
#define CMDHDR_AUTH_ID_O_V0            38 /* Authentication ID field offset */
#define CMDHDR_AUTH_ID_S_V0            10 /* Authentication ID field size */

#define CMDHDR_CMD_ID_O                 48 /* Command ID (code + version) field offset */
#define CMDHDR_CMD_ID_S                 16 /* Command ID (code + version) field size */
#define CMDHDR_CMD_CODE_O               52 /* Command code field offset */
#define CMDHDR_CMD_CODE_S               12 /* Command code field size */
#define CMDHDR_CMD_VER_O                48 /* Command ver field offset */
#define CMDHDR_CMD_VER_S                4  /* Command ver field size */
#define CMDHDR_AUTH_ID_O                32 /* Authentication ID field offset */
#define CMDHDR_AUTH_ID_S                16 /* Authentication ID field size */
#define CMDHDR_INTR_DIS_O               24 /* Interrupt disable filed offset*/
#define CMDHDR_INTR_DIS_S               1  /* Interrupt disable filed size*/
#define CMDHDR_STATUS_O                 16 /* Status field offset */
#define CMDHDR_STATUS_S                 8  /* Status field size*/
#define CMDHDR_PRI_O                    15 /* Priority field offset */
#define CMDHDR_PRI_S                    1  /* Priority field size */
#define CMDHDR_SRCID_O                  0  /* Src id field offset */
#define CMDHDR_SRCID_S                  8  /* Src id field size */


#define CMDHDR_CMD_CODE(code)           (code & 0xfff)
#define CMDHDR_CMD_VERSION(ver)         (ver & 0xf)

/* command header masks and shifts */
#define CMDHDR_SRCID_MASK               0x00000000000000FF
#define CMDHDR_PRIORITY_MASK            0x0000000000008000
#define CMDHDR_STATUS_MASK              0x0000000000FF0000
#define CMDHDR_INTR_DIS_MASK            0x0000000001000000
#define CMDHDR_AUTH_ID_MASK_V0          0x0000FFC000000000
#define CMDHDR_AUTH_ID_MASK             0x0000FFFF00000000
#define CMDHDR_CMD_CODE_MASK            0xFFF0000000000000
#define CMDHDR_CMD_CODE_VERSION_MASK    0x000F000000000000


#define CMDHDR_PRIORITY_SHIFT           CMDHDR_PRI_O
#define CMDHDR_STATUS_SHIFT             CMDHDR_STATUS_O
#define CMDHDR_INTR_DIS_SHIFT           CMDHDR_INTR_DIS_O
#define CMDHDR_AUTH_ID_SHIFT            CMDHDR_AUTH_ID_O
#define CMDHDR_AUTH_ID_SHIFT_V0         CMDHDR_AUTH_ID_O_V0
#define CMDHDR_CMD_CODE_SHIFT           CMDHDR_CMD_CODE_O
#define CMDHDR_CMD_VERSION_SHIFT        CMDHDR_CMD_VER_O

#define CMDPARAM1_ID_MASK               0x000000000000FFFF
#define CMDPARAM1_ICID_MASK             0x00000000FFFF0000

#define CMDPARAM1_ICID_SHIFT            16

/* HPSPR/LPSPR 'Valid' bit */
#define CMD_PORTAL_PENDING_BIT          0x80000000
#define CMD_PORTAL_INDEX_MASK           0x000000FF

#define MC_CMD_NUM_OF_PARAMS	7

struct mc_cmd_data {
	uint64_t params[MC_CMD_NUM_OF_PARAMS];
};

struct mc_portal {
	uint64_t header;
	struct mc_cmd_data data;
};

#define MC_PREP_OP(_ext, _param, _offset, _width, _type, _arg) \
	   (_ext[_param] |= swap_uint64(u64_enc((_offset), (_width), _arg)))

#define MC_EXT_OP(_ext, _param, _offset, _width, _type, _arg) \
       (_arg = (_type)u64_dec(swap_uint64(_ext[_param]), (_offset), (_width)))

#define MC_RSP_OP(_cmd, _param, _offset, _width, _type, _arg) \
       ((_cmd)->params[_param] |= swap_uint64(u64_enc((_offset), (_width), _arg)))

#define MC_CMD_OP(_cmd, _param, _offset, _width, _type, _arg) \
       (_arg = (_type)u64_dec(swap_uint64(_cmd->params[_param]), (_offset), (_width)))

enum mc_cmd_status {
	MC_CMD_STATUS_OK = 0x0, /*!< Completed successfully */
	MC_CMD_STATUS_READY = 0x1, /*!< Ready to be processed */
	MC_CMD_STATUS_AUTH_ERR = 0x3, /*!< Authentication error */
	MC_CMD_STATUS_NO_PRIVILEGE = 0x4, /*!< No privilege */
	MC_CMD_STATUS_DMA_ERR = 0x5, /*!< DMA or I/O error */
	MC_CMD_STATUS_CONFIG_ERR = 0x6, /*!< Configuration error */
	MC_CMD_STATUS_TIMEOUT = 0x7, /*!< Operation timed out */
	MC_CMD_STATUS_NO_RESOURCE = 0x8, /*!< No resources */
	MC_CMD_STATUS_NO_MEMORY = 0x9, /*!< No memory available */
	MC_CMD_STATUS_BUSY = 0xA, /*!< Device is busy */
	MC_CMD_STATUS_UNSUPPORTED_OP = 0xB, /*!< Unsupported operation */
	MC_CMD_STATUS_INVALID_STATE = 0xC /*!< Invalid state */
};



#define MC_CMD_HDR_READ_STATUS(_hdr) \
        ((enum mc_cmd_status)u64_dec((_hdr), \
            CMDHDR_STATUS_O, CMDHDR_STATUS_S))

#define MC_CMD_HDR_READ_AUTHID(_hdr) \
        ((uint16_t)u64_dec((_hdr), CMDHDR_AUTH_ID_O, CMDHDR_AUTH_ID_S))

#define MC_CMD_PRI_LOW		0 /*!< Low Priority command indication */
#define MC_CMD_PRI_HIGH		1 /*!< High Priority command indication */

#define CMDIF_MOD_MC_RESERVED 0x30

static inline void mc_cmd_write(struct mc_portal *portal,
				uint16_t cmd_id,
	uint16_t auth_id,
	uint8_t size,
	int pri,
	struct mc_cmd_data *cmd_data)
{
	uint64_t hdr;
	int i;

	hdr = u64_enc(CMDHDR_CMD_ID_O, CMDHDR_CMD_ID_S, cmd_id);
	hdr |= u64_enc(CMDHDR_AUTH_ID_O, CMDHDR_AUTH_ID_S, auth_id);
	hdr |= u64_enc(CMDHDR_PRI_O, CMDHDR_PRI_S, pri);
	hdr |= u64_enc(CMDHDR_STATUS_O, CMDHDR_STATUS_S,
			MC_CMD_STATUS_READY);

	if (cmd_data)
		/* copy command parameters into the portal */
		for (i = 0; i < MC_CMD_NUM_OF_PARAMS; i++)
			iowrite64(cmd_data->params[i],
				  &(portal->data.params[i]));
	else
		/* zero all parameters */
		for (i = 0; i < MC_CMD_NUM_OF_PARAMS; i++)
			iowrite64(0, &(portal->data.params[i]));

	/* submit the command by writing the header */
	iowrite64(hdr, &portal->header);
}

static inline enum mc_cmd_status mc_cmd_read_status(struct mc_portal *portal)
{
	uint64_t hdr = ioread64(&(portal->header));

	return MC_CMD_HDR_READ_STATUS(hdr);
}

static inline uint16_t mc_cmd_read_auth_id(struct mc_portal *portal)
{
	uint64_t hdr = ioread64(&(portal->header));

	return MC_CMD_HDR_READ_AUTHID(hdr);
}

static inline void mc_cmd_read_response(struct mc_portal *portal,
					struct mc_cmd_data *resp)
{
	int i;

	if (resp)
		for (i = 0; i < MC_CMD_NUM_OF_PARAMS; i++)
			resp->params[i] = ioread64(&(portal->data.params[i]));
}

#endif /* __FSL_MC_CMDIF_H */
