/*
 * Copyright 2013-2020 NXP
 */

/**
 @File          timer_ext.h

 @Description   structures and definitions for initialize and operate the
                Timer module.
                This module
*//***************************************************************************/

#ifndef __SYS_TIMER_H
#define __SYS_TIMER_H

#include "fsl_types.h"

/**************************************************************************//**
 @Group         Timer - Timers module

 @Description   Timer module functions,definitions and enums.

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Description   Timers operation mode
*//***************************************************************************/
typedef enum e_timer_mode {
    E_TIMER_MODE_PERIODIC,    /**< Periodic - counter restarts counting from 0
                                   after reaching the reference value. */
    E_TIMER_MODE_SINGLE       /**< Single (one-shot) - counter stops counting
                                   after reaching the reference value. */
} e_timer_mode;

/**************************************************************************//**
 @Function      timer_init_module

 @Description   Initialize the timer module.

*//***************************************************************************/
int timer_init_module();

/**************************************************************************//**
 @Function      timer_free_module

 @Description   Exit the timer module.

*//***************************************************************************/
void timer_free_module(void);

/**************************************************************************//**
 @Function      timer_create

 @Description   Creating a timer structure.

 @Return        A handle to the created timer for succsses, NULL - otherwise.
*//***************************************************************************/
void* timer_create(void);

/**************************************************************************//**
 @Function      timer_init

 @Description   Initialize timer structure.

                The routine initializing the given timer structure with the
                given parameters.

 @Param[in]     tmr        -  Pointer to timer structure to be initialize.
 @Param[in]     expires    -  The interval time of the expiration
                              for this timer (in milli-seconds).
 @Param[in]     expired_cb -  User call-back routine that will be called
                              when this timer will be expired.
 @Param[in]     data       -  The argument for the call-back routine.
 @Param[in]     mode       -  Timer mode of operation - Single-shot/Periodic.
 @Param[in]     sys_timer  -  flag that indicate a system timer or
                              user timer.
                              System timers execute user call-backs in ISR context
                              and interrupts are disabled during call-back.
                              User timers execute user call-backs in tasklets.
 @Cautions      Only system timers are currently supported.

 @Return        0 - for succsses, E_FAIL\E_BADPARM - otherwise.
*//***************************************************************************/
int timer_init(void* tmr,
               uint32_t expires,
               void (*expired_cb)(void*),
               void* data,
               e_timer_mode mode,
               int sys_timer);

/**************************************************************************//**
 @Function      timer_free

 @Description   Free timer structure.

 @Param[in]     tmr        -  Pointer to timer structure to be initialize.

 @Return        0 - for succsses, E_FAIL\E_BADPARM - otherwise.
*//***************************************************************************/
int timer_free(void* tmr);

/**************************************************************************//**
 @Function      timer_get_expiration_time

 @Description   Get the expiration time of the timer.

                The routine returns the expiration time of the given timer.
                expiration time is the system time when this timer will expire.
                System time is the number of miliseconds since the system started.

 @Param[in]     tmr        -  Pointer to timer structure.

 @Return        uint64_t: current time - tmr->expires.
*//***************************************************************************/
uint64_t timer_get_expiration_time(void* tmr);

/**************************************************************************//**
 @Function      timer_start

 @Description   Activate a timer.

                The routine adds the given timer to the timers queue.

 @Param[in]     tmr        -  Pointer to timer structure to be added.
*//***************************************************************************/
void timer_start(void* tmr);

/**************************************************************************//**
 @Function      timer_stop

 @Description   De-activate a timer.

                The routine removes the given timer to the timers queue.

 @Param[in]     tmr        -  Pointer to timer structure to be deleted.
*//***************************************************************************/
void timer_stop(void* tmr);

/**************************************************************************//**
 @Function      timer_mod

 @Description   Update timer expiration.

                timer_mod is a more efficient way to update the expire
                field of an active timer (if the timer is inactive it will be
                activated) timer_mod(a,b) is equivalent to
                timer_del(a); a->expires = b; timer_add(a).
                If the timer is known to be not pending (ie, in the handler),
                timer_mod is less efficient than
                a->expires = b; timer_add(a).

 @Param[in]     tmr        -  Pointer to timer structure to be modified.
 @Param[in]     expires    -  The interval time of the expiration
                              for this timer (In milli-seconds).

 @Return        0 - for successes, E_FAIL\E_BADPARM - otherwise.
*//***************************************************************************/
int timer_mod(void* tmr, uint32_t expires);

/**************************************************************************//**
 @Function      timer_is_pending

 @Description   Check if a timer is pending.

                The routine checks whether the given timer is queued to the
                timers list or not.

 @Param[in]     tmr        -  Pointer to timer structure.

 @Return        1 - If this timer is pending, 0 - otherwise.
*//***************************************************************************/
int timer_is_pending(const void* tmr);

/**************************************************************************//**
 @Function      timer_current_time

 @Description   Get the current time in the system.

                The routine read the global time value.

 @Return        Current time (In milli-seconds).
*//***************************************************************************/
uint64_t timer_current_time(void);

/**************************************************************************//**
 @Function      timer_sleep

 @Description   This routine is used for relatively long delays with interrupts enabled.

 @Param[in]     msecs   - The time to wait (in milli-seconds).

 @Return        Always zero.

 @Cautions      This routine is enabling interrupts.
*//***************************************************************************/
uint32_t timer_sleep(uint32_t msecs);

/**************************************************************************//**
 @Function      timer_udelay

 @Description   This routine is used for relatively short delays with busy waiting.

 @Param[in]     usecs   - The time to wait (in micro-seconds).

 @Cautions      This routine performs busy waiting!
*//***************************************************************************/
void timer_udelay(uint32_t usecs);

/** @} */ /* end of group */

#endif /* __SYS_TIMER_H */
