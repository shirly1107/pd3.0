/*
 * Copyright 2013 Freescale Semiconductor, Inc.
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 @File          spinlock.h

 @Description   Prototypes, externals and typedefs for system-supplied
                (external) routines
*//***************************************************************************/

#ifndef __FSL_SYS_DTC_H
#define __FSL_SYS_DTC_H

#include "fsl_types.h"


/**************************************************************************//**
 @Group         fsl_os_g  FSL OS Interface (System call hooks)

 @Description   Prototypes, externals and typedefs for system-supplied
                (external) routines

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Group         fsl_os_dtc_g  FSL OS DTC API

 @{
*//***************************************************************************/

#define SYS_DTC_MAX_COMPATIBLE_NAME  20
#define SYS_DTC_MAX_COMPATIBLES      4


struct node;


/**************************************************************************//**
 @Description   DTC Modules Registration Parameters.

                This structure provides registration parameters for a set of
                sub-modules. Each module should register its own sub-modules
                in the system using the sys_dtc_register_module() routine.
*//***************************************************************************/
typedef struct sys_dtc_mod_params {
    int             num_compats;
    char            **compatibles;
        /**< The type of the owner module */

    int             (*f_prob_module)(void *dtc_addr, int node_off);
        /**< modules initialization routine */
    int             (*f_remove_module)(void *dtc_addr, int node_off);
        /**< modules free routine */
} t_sys_dtc_mod_params;

/**************************************************************************//**
 @Function      sys_dtc_register_module

 @Param[in]     dtc_mod_params

 @Return        0 on success; error code otherwise..
*//***************************************************************************/
int sys_dtc_register_module (struct sys_dtc_mod_params *dtc_mod_params);

/**************************************************************************//**
 @Function      sys_dtc_unregister_module

 @Param[in]     module_match

 @Return        0 on success; error code otherwise..
*//***************************************************************************/
int sys_dtc_unregister_module(char *module_match);

/** @} */ /* end of fsl_os_dtc_g group */
/** @} */ /* end of fsl_os_g group */


#endif /* __FSL_SYS_DTC_H */
