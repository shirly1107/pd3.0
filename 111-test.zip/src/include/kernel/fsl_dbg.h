/*
 * Copyright 2013 Freescale Semiconductor, Inc.
 * Copyright 2014-2020 NXP
 */

/**************************************************************************//**
 @File          fsl_dbg.h

 @Description   Debug mode definitions.
*//***************************************************************************/

#ifndef __FSL_DBG_H
#define __FSL_DBG_H

#include "fsl_core.h"
#include "fsl_stdlib.h"
#include "fsl_stdio.h"
#include "fsl_smp.h"
#include "fsl_log.h"
#include "fsl_errors.h"
#include "fsl_mem_mng.h"
#include "fsl_io.h"

// uncomment this to see some extra function enter/exit messages in logs
//#define EXTRA_VERBOSE

// uncomment this to see some extra function enter/exit messages in logs
//#define LOG_LO_CREATE
 
#ifdef __KLOCWORK__
#define DEBUG_ERRORS 0
#define LOG_OFF
#endif

#ifndef DEBUG_GLOBAL_LEVEL
#define DEBUG_GLOBAL_LEVEL  REPORT_LEVEL_WARNING
#endif /* DEBUG_GLOBAL_LEVEL */

#ifndef ERROR_GLOBAL_LEVEL
#define ERROR_GLOBAL_LEVEL  DEBUG_GLOBAL_LEVEL
#endif /* ERROR_GLOBAL_LEVEL */


#ifndef DEBUG_DYNAMIC_LEVEL
#define DEBUG_USING_STATIC_LEVEL

#ifdef DEBUG_STATIC_LEVEL
#define DEBUG_DYNAMIC_LEVEL DEBUG_STATIC_LEVEL
#else
#define DEBUG_DYNAMIC_LEVEL DEBUG_GLOBAL_LEVEL
#endif /* DEBUG_STATIC_LEVEL */

#else /* DEBUG_DYNAMIC_LEVEL */
#ifdef DEBUG_STATIC_LEVEL
#error "please use either DEBUG_STATIC_LEVEL or DEBUG_DYNAMIC_LEVEL (not both)"
#else
#define DEBUG_DYNAMIC_LEVEL DEBUG_GLOBAL_LEVEL
#endif /* DEBUG_STATIC_LEVEL */
#endif /* !DEBUG_DYNAMIC_LEVEL */


#ifndef ERROR_DYNAMIC_LEVEL

#ifdef ERROR_STATIC_LEVEL
#define ERROR_DYNAMIC_LEVEL ERROR_STATIC_LEVEL
#else
#define ERROR_DYNAMIC_LEVEL ERROR_GLOBAL_LEVEL
#endif /* ERROR_STATIC_LEVEL */

#else /* ERROR_DYNAMIC_LEVEL */
#ifdef ERROR_STATIC_LEVEL
#error "please use either ERROR_STATIC_LEVEL or ERROR_DYNAMIC_LEVEL (not both)"
#else
#define ERROR_DYNAMIC_LEVEL ERROR_GLOBAL_LEVEL
#endif /* ERROR_STATIC_LEVEL */
#endif /* !ERROR_DYNAMIC_LEVEL */

/**************************************************************************//**
 @Group         gen_g  General Drivers Utilities

 @Description   External routines.

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Description   Declaration of Halting the core in debug mode.

                se_dnh - Debug Notify Halt
                Acts as 'se_illegal' if EDBCR0[DNH_EN] is not set.
*//***************************************************************************/
#if (!defined(DEBUG_ERRORS) || (DEBUG_ERRORS == 0))
	#define DEBUG_HALT
#else
	#ifdef __KLOCWORK__
	#define DEBUG_HALT do { } while (1)
	#else
	#define DEBUG_HALT asm { se_dnh }
	#endif /* __KLOCWORK__ */
#endif /* DEBUG_ERRORS */

#if (!defined(DEBUG_ERRORS) || (DEBUG_ERRORS == 0))
/* No debug/error/event messages at all */
#define DBG(_level, ...)

#else /* DEBUG_ERRORS > 0 */

#if ((defined(DEBUG_USING_STATIC_LEVEL)) && (DEBUG_DYNAMIC_LEVEL < REPORT_LEVEL_WARNING))
/* No need for DBG macro - debug level is higher anyway */
#define DBG(_level, ...)
#else
extern const char *dbg_level_strings[];
#define DBG(_level, ...) \
do { \
    if (_level <= DEBUG_DYNAMIC_LEVEL) { \
        fsl_print("> %s " PRINT_FORMAT ": ", \
                     dbg_level_strings[_level - 1], \
                     PRINT_FMT_PARAMS); \
        fsl_print(__VA_ARGS__); \
        /*fsl_print("\n");*/ \
    } \
} while (0)
#endif /* (defined(DEBUG_USING_STATIC_LEVEL) && (DEBUG_DYNAMIC_LEVEL < WARNING)) */
#endif /* (!defined(DEBUG_ERRORS) || (DEBUG_ERRORS == 0)) */

/**************************************************************************//**
 @Collection    Debug Levels for Errors and Events

                The level description refers to errors only.
                For events, classification is done by the user.
 @{
*//***************************************************************************/
#define REPORT_LEVEL_CRITICAL   1       /**< Crasher: Incorrect flow, NULL pointers/handles. */
#define REPORT_LEVEL_MAJOR      2       /**< Cannot proceed: Invalid operation, parameters or
                                             configuration. */
#define REPORT_LEVEL_MINOR      3       /**< Recoverable problem: a repeating call with the same
                                             parameters may be successful. */
#define REPORT_LEVEL_WARNING    4       /**< Something is not exactly right, yet it is not an error. */
#define REPORT_LEVEL_INFO       5       /**< Messages which may be of interest to user/programmer. */
#define REPORT_LEVEL_TRACE      6       /**< Program flow messages. */

#define EVENT_DISABLED          0xff    /**< Disabled event (not reported at all) */

/* @} */
#define PRINT_FORMAT        "[CPU %d, %s:%d %s]"
#define PRINT_FMT_PARAMS    core_get_id(), __FILE__, __LINE__, __FUNCTION__

#define will_log(id, log_level) 	__will_log(log_level, LOG_MODULE, id)

#define pr_crit(...)\
	do{\
		if (will_log(NO_ID, LOG_LEVEL_CRITICAL)) {\
			LOG(NO_ID, LOG_LEVEL_CRITICAL, 0, ##__VA_ARGS__);\
		}\
	} while (0)

#define pr_err(...)\
	do{\
		if (will_log(NO_ID, LOG_LEVEL_ERROR)) {\
			LOG(NO_ID, LOG_LEVEL_ERROR, 0, ##__VA_ARGS__);\
		}\
	} while (0)

#define pr_warn(...)\
	do{\
		if (will_log(NO_ID, LOG_LEVEL_WARNING)) {\
			LOG(NO_ID, LOG_LEVEL_WARNING, 0, ##__VA_ARGS__);\
		}\
	} while (0)

#define pr_info(...)\
	do{\
		if (will_log(NO_ID, LOG_LEVEL_INFO)) {\
			LOG(NO_ID, LOG_LEVEL_INFO, 0, ##__VA_ARGS__);\
		}\
	} while (0)

#define pr_debug(...)\
	do{\
		if (will_log(NO_ID, LOG_LEVEL_DEBUG)) {\
			LOG(NO_ID, LOG_LEVEL_DEBUG, 0, ##__VA_ARGS__);\
		}\
	} while (0)

#ifdef MC_CLI
#ifdef EMULATOR
#define pr_user(...) LOG(NO_ID, LOG_LEVEL_USER, 0, ##__VA_ARGS__)
#else
#define pr_user(...) fsl_print(__VA_ARGS__)
#endif
#endif

#define obj_crit(id, ...)\
	do{\
		if (will_log(id, LOG_LEVEL_CRITICAL)) {\
			LOG(id, LOG_LEVEL_CRITICAL, 0, ##__VA_ARGS__);\
		}\
	} while (0)

#define obj_err(id, ...)\
	do{\
		if (will_log(id, LOG_LEVEL_ERROR)) {\
			LOG(id, LOG_LEVEL_ERROR, 0, ##__VA_ARGS__);\
		}\
	} while (0)

#define obj_warn(id, ...)\
	do{\
		if (will_log(id, LOG_LEVEL_WARNING)) {\
			LOG(id, LOG_LEVEL_WARNING, 0, ##__VA_ARGS__);\
		}\
	} while (0)

#define obj_info(id, ...)\
	do{\
		if (will_log(id, LOG_LEVEL_INFO)) {\
			LOG(id, LOG_LEVEL_INFO, 0, ##__VA_ARGS__);\
		}\
	} while (0)

#define obj_debug(id, ...)\
	do{\
		if (will_log(id, LOG_LEVEL_DEBUG)) {\
			LOG(id, LOG_LEVEL_DEBUG, 0, ##__VA_ARGS__);\
		}\
	} while (0)

// CHECK_... macros serve to simplify the error handling, because have they the same behaviour
// in both debug and release configurations.
//
// The condition being checked, in positive form.
// CHECK_COND_... print a message if the condition is false. 
// These macros can be used with empty message (e.g. CHECK_COND_RETVAL(err == 0, err); ).
#define CHECK_COND_RET(_cond, ...)\
		do{\
			if (!(_cond)) {\
				if (sizeof(#__VA_ARGS__) != sizeof("")) {\
					LOG(NO_ID, LOG_LEVEL_ERROR, 0, ##__VA_ARGS__);\
				}\
				return;\
			}\
		} while (0)
#define CHECK_COND_RETVAL(_cond, _retval, ...)\
		do{\
			if (!(_cond)) {\
				if (sizeof(#__VA_ARGS__) != sizeof("")) {\
					LOG(NO_ID, LOG_LEVEL_ERROR, 0, ##__VA_ARGS__);\
				}\
				return _retval;\
			}\
		} while (0)
#define CHECK_COND_GOTO(_cond, _label, ...)\
		do{\
			if (!(_cond)) {\
				if (sizeof(#__VA_ARGS__) != sizeof("")) {\
					LOG(NO_ID, LOG_LEVEL_ERROR, 0, ##__VA_ARGS__);\
				}\
				goto _label;\
			}\
		} while (0)

// Prints variable args to an input buffer while avoiding buffer overrun.
#define SNPRINTF_OR_EXIT(buff, buff_size, count, __exit_label, str_format, ...)\
do {\
	if (sizeof(str_format) != sizeof("")) {\
		if ((buff_size) - 1 > (count)) {\
			count += snprintf((char *)&(buff)[(count)],\
			((buff_size) - (count) - 1),\
			(str_format),\
			##__VA_ARGS__);\
		} else {\
			LOG(NO_ID, LOG_LEVEL_DEBUG, 0,\
		    "Not enough print buffer size: %d bytes", (buff_size));\
		    goto __exit_label;\
		}\
	}\
} while (0)

/**************************************************************************//**
 @Function      ASSERT_COND

 @Description   Assertion macro.

 @Param[in]     _cond - The condition being checked, in positive form;
                        Failure of the condition triggers the assert.
*//***************************************************************************/
#ifdef DISABLE_ASSERTIONS
#define ASSERT_COND(_cond)
#else

#define ASSERT_PRINT_FORMAT        "[CPU %d, %s:%d %s]"

static void _assert_handler(uint32_t	core_id,
			    const char	*file,
			    int		line,
			    const char	*func)
{
	pr_crit("*** ASSERT_COND failed" ASSERT_PRINT_FORMAT "\n",
            core_id, file, line, func);
	abort();
}
#define ASSERT_COND(_cond) ((_cond) ? ((void) 0) : _assert_handler(PRINT_FMT_PARAMS))
#endif /* DISABLE_ASSERTIONS */

/**************************************************************************//**
 @Function      ASSERT_COND_LIGHT

 @Description   Assertion macro, without printing an error message.

 @Param[in]     _cond - The condition being checked, in positive form;
                        Failure of the condition triggers the assert.
*//***************************************************************************/
#ifdef DISABLE_ASSERTIONS
#define ASSERT_COND_LIGHT(_cond)
#else
#define ASSERT_COND_LIGHT(_cond) \
    do { \
        if (!(_cond)) { \
            abort(); \
        } \
    } while (0)
#endif /* DISABLE_ASSERTIONS */

/**************************************************************************//**
 @Function      dbg_get_core_id

 @Description   Returns the core ID in the system.

 @Return        Core ID.
*//***************************************************************************/
#define dbg_get_core_id()    core_get_id()

/**************************************************************************//**
 @Function      dbg_get_num_of_cores

 @Description   Returns the number of active cores in the system.

 @Return        number of active cores.
*//***************************************************************************/
#define dbg_get_num_of_cores()    sys_get_num_of_cores()

/**************************************************************************//**
 @Function      dbg_get_max_num_of_cores

 @Description   Returns the number of existing cores in the system.

 @Return        number of existing cores.
*//***************************************************************************/
#define dbg_get_max_num_of_cores()    sys_get_max_num_of_cores()

#endif /* __FSL_DBG_H */
