/*
 * Copyright 2013-2020 NXP
 */

#ifndef _DEVICE_H
#define _DEVICE_H

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_resman.h"

struct device {
	void *private;
	char type[16];
	/* object type */
	char label[16];
	/* object label */
	int id;
	/* Device ID */
	uint32_t state;
	/* Device state
	 - enabled
	 - Open flag
	 - Dynamically created flag
	 - Shared device flag
	 - Plugged */
	int *lock;
	int irq;
	/* Device's IRQ */
};

static inline void device_set_priv(struct device *device, void *private)
{
	device = (struct device *)((int)device & ~DP_DEV_OWNERS_MASK);
	device->private = private;
}

static inline void* device_get_priv(struct device *device)
{
	device = (struct device *)((int)device & ~DP_DEV_OWNERS_MASK);
	return device->private;
}

static inline void* device_free_priv(struct device *device)
{
	device->private = NULL;
	return 0;
}

static inline uint16_t device_get_id(struct device *device)
{
	device = (struct device *)((int)device & ~DP_DEV_OWNERS_MASK);
	return (uint16_t)device->id;
}

static inline void device_set_enable(struct device *device, int enable)
{
	device = (struct device *)((int)device & ~DP_DEV_OWNERS_MASK);
	if (enable)
		device->state |= DPRC_OBJ_STATE_ENABLE;
	else
		device->state &= (~DPRC_OBJ_STATE_ENABLE);
	return;
}

static inline int device_get_enable(struct device *device, int *enable)
{
	device = (struct device *)((int)device & ~DP_DEV_OWNERS_MASK);
	
	if (device->state & DPRC_OBJ_STATE_ENABLE) 
		*enable = 1;
	else
		*enable = 0;
	
	return 0;
}

#endif /* _DEVICE_H */
