/*
 * Copyright 2013 Freescale Semiconductor, Inc.
 * Copyright 2014-2020 NXP
 */

/**************************************************************************//**
 @File          fsl_tasklet.h

 @Description   Prototypes, externals and typedefs for system-supplied
                (external) routines
*//***************************************************************************/

#ifndef __FSL_TASKLET_H
#define __FSL_TASKLET_H

#include "fsl_types.h"

enum tasklet_priority_t {
	tsk_priority_immediate = 0,
	tsk_priority_delayed
};

/**************************************************************************//**
 @Function      tasklet_module_init

 @Description   Initialization for the tasklet module

 @Param[in]     max_num_of_tasklets - maximum number of tasklets allowed in
 	 	 	 	                      the system.
				mem_part_id - partition ID for the linked lists
				
 @Return        status code
 *//***************************************************************************/
int tasklet_module_init(uint32_t max_num_of_tasklets, uint8_t mem_part_id);

/**************************************************************************//**
 @Function      fsl_schedule_tasklet

 @Description   Schedule a tasklet

 @Param[in]     func     - User callback for the tasklet
 	 	 	 	data     - Data passed to the user callback (func)
 	 	 	 	priority - Immediate or delayed

 @Return        status code
 *//***************************************************************************/
int fsl_schedule_tasklet(void (*func)(uint64_t data), uint64_t data, 
										enum tasklet_priority_t priority);

/**************************************************************************//**
 @Function      flush_scheduled_tasklets

 @Description   Remove and free all pending tasklets. 
 *//***************************************************************************/
void fsl_flush_scheduled_tasklets();

#endif /* __FSL_TASKLET_H */
