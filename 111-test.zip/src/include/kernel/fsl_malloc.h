/*
 * Copyright 2013 Freescale Semiconductor, Inc.
 * Copyright 2014-2020 NXP
 */

/**************************************************************************//**
 @File          fsl_malloc.h

 @Description   Prototypes, externals and typedefs for system-supplied
                (external) routines
*//***************************************************************************/

#ifndef __FSL_MALLOC_H
#define __FSL_MALLOC_H

#include "fsl_types.h"


/**************************************************************************//**
 @Group         fsl_lib_g   Utility Library
 @Description   Prototypes, externals and typedefs for system-supplied
                (external) routines

 @{
*//***************************************************************************/


/**************************************************************************//**
 @Description   Memory Partition Identifiers

                Note that not all memory partitions are supported by all
                platforms. Every platform may select which memory partitions
                to support.
*//***************************************************************************/
typedef enum memory_partition_id {
    MEM_PART_SYSTEM_DDR1_CACHEABLE = 1,    /**< Primary DDR cacheable memory partition */
    MEM_PART_SYSTEM_DDR1_NON_CACHEABLE,    /**< Primary DDR non-cacheable memory partition */
    MEM_PART_SYSTEM_DDR1,
    MEM_PART_DMEM,                      /** < Depending on core number redirected to either
                                             MEM_PART_DMEM1 or MEM_PART_DMEM2 */
    MEM_PART_DMEM1,                     /**< DMEM1 memory partition */
    MEM_PART_DMEM2,                     /**< DMEM2 memory partition */
    MEM_PART_PEB,                      /**< Packet-Express-Buffer memory partition */
    MEM_PART_DP_DDR,                   /**< DP-DDR memory partition */
    MEM_PART_LOGGER,
    MEM_PART_SYSTEM_DDR2, /**< Optional second system DDR partition */
    MEM_PART_LAST                      /**< Invalid memory partition */
} e_memory_partition_id;

#define VALID_FSL_GET_MEM_PARTITION(p) ((p) == MEM_PART_SYSTEM_DDR1 || \
										(p) == MEM_PART_SYSTEM_DDR2 || \
										(p) == MEM_PART_PEB || \
										(p) == MEM_PART_DP_DDR )
/* Holds a list of memory partitions; see fsl_get_mem_mp() */
struct memory_partition_list {
	e_memory_partition_id mem_part_ids[MEM_PART_LAST];
};

typedef enum memory_region { //TODO - what is this? why needed?
	MEM_RGN_MC_DDR = 0,
}e_memory_region;

/**************************************************************************//**
 @Function      fsl_malloc

 @Description   Allocates contiguous block of memory from default heap.
                mc_link.lcf linker file contains information where default
                heap is mapped to.

 @Param[in]     size    Number of bytes to allocate.

 @Return        The address of the newly allocated block on success, NULL on failure.
*//***************************************************************************/
void * fsl_malloc(size_t size);

/**************************************************************************//**
 @Function     fsl_xmalloc

 @Description   Allocates contiguous block of memory in a specified
                alignment and from the specified  memory partition.

 @Param[in]     size                Number of bytes to allocate.
 @Param[in]     mem_partition_id    Memory partition ID; The value zero must
                                    be mapped to the default heap partition.
                Valid values: MEM_PART_SYSTEM_DDR1_CACHEABLE,MEM_PART_DP_DDR_NON_CACHEABLE,
                              MEM_PART_DMEM,MEM_PART_DMEM1,MEM_PART_DMEM2.
                              If MEM_PART_DMEM argument is used, the allocation
                              will be performed either from MEM_PART_DMEM1 or
                              MEM_PART_DMEM2 depending on core number that
                              calls this function.
 @Param[in]     alignment           Required memory alignment (in bytes).
                                    Should be a power of 2 ( 4, 8, 16 etc.)
 @Return        The address of the newly allocated block on success, NULL on failure.
*//***************************************************************************/
void *fsl_xmalloc(size_t size, int mem_partition_id, uint32_t alignment);

/**************************************************************************//**
 @Function      fsl_xfree

 @Description   Frees the memory block pointed to by "p".
                Only for memory allocated by fsl_xmalloc().

 @Param[in]     mem     A pointer to the memory block.
*//***************************************************************************/
void fsl_xfree(void *mem);

/**************************************************************************//**
 @Function      fsl_free

 @Description   frees the memory block pointed to by "p".

 @Param[in]     mem     A pointer to the memory block.
*//***************************************************************************/
void fsl_free(void *mem);

/**************************************************************************//**
@Function      fsl_get_mem

@Description   Allocates contiguous block of memory with the specified
                alignment and from the specified  memory partition.
@Param[in]     mem_partition_id    Memory partition ID;
               Valid values:MEM_PART_SYSTEM_DDR1, MEM_PART_PEB,MEM_PART_DP_DDR
@Param[in]     alignment           Required memory alignment (in bytes).
                                   Should be a power of 2 ( 4, 8, 16 etc.)
@Param[out]    paddr               A valid allocated physical address if success,
                                   NULL if failure.
@Return        0                   on success,
               -ENOMEM (not enough memory to allocate)or
               -EINVAL ( invalid memory partition ) on failure.
*//***************************************************************************/
int fsl_get_mem(uint64_t size, int mem_partition_id, uint64_t alignment,
                   uint64_t* paddr);

/**************************************************************************//**
@Function	fsl_get_mem_mp

@Description	Tries to allocate a contiguous block of memory with the
				specified alignment. The memory partition is the first one
				from the provided list that is available on the current SoC
				and supports the required block size.
@Param[in]	mem_partitions	Preferred memory partition list.
			Valid values are: MEM_PART_SYSTEM_DDR1, MEM_PART_SYSTEM_DDR2,
			MEM_PART_PEB, MEM_PART_DP_DDR. Any values besides these indicates
			an end of list and the search for a suitable partition stops.
@Param[in]	alignment	Required memory alignment (in bytes).
						Should be a power of 2 ( 4, 8, 16 etc.)
@Param[out]	paddr	A valid allocated physical address if success,
					NULL if failure.
@Return	0	on success,
		-ENOMEM (not enough memory to allocate) or
		-EINVAL ( invalid memory partition ) on failure.
*//***************************************************************************/

int fsl_get_mem_mp(uint64_t size,
				const struct memory_partition_list* mem_partitions,
				uint64_t alignment,
				uint64_t* paddr);
/**************************************************************************//**
@Function      fsl_put_mem

@Description   Frees the memory block pointed to by "paddr".
               paddr should be allocated by fsl_get_mem()

@Param[in]    paddr  An address to be freed.

*//***************************************************************************/
void  fsl_put_mem(uint64_t paddr);

/**************************************************************************//**
@Function      fsl_mem_exists

@Description   Returns data if the provided  memory partition exists

@Param[in]    mem_partition_id   A memory partition id
@Return        1                 if exists,
               0                 if does not exist
*//***************************************************************************/
int fsl_mem_exists(int mem_partition_id);

/** @} */ /* end of fsl_lib_g  group */

#ifdef MEM_MNG_REC_ALLOC_INFO
	/* switch to debug version */
void *fsl_malloc_dbg(size_t size, const char* info, const char* filename, int line);
void *fsl_xmalloc_dbg(size_t size, int mem_partition_id, uint32_t alignment,
		const char* info, const char* filename, int line);

#undef fsl_malloc
#define fsl_malloc(size)	fsl_malloc_dbg(size, __FUNCTION__, __FILE__, __LINE__)

#undef fsl_xmalloc
#define fsl_xmalloc(size, mem_partition_id, alignment)	\
		fsl_xmalloc_dbg(size, mem_partition_id, alignment, __FUNCTION__, __FILE__, __LINE__)

#endif //MEM_MNG_REC_ALLOC_INFO

#endif /* __FSL_MALLOC_H */
