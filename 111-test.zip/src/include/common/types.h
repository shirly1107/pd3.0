/*
 * Copyright 2013 Freescale Semiconductor, Inc.
 * Copyright 2014-2020 NXP
 */

/**************************************************************************//**
 @File          types.h

 @Description
 *//***************************************************************************/
#ifndef __FSL_TYPES_H
#define __FSL_TYPES_H


#if defined(__GNUC__) && defined(__cplusplus)
#include "kernel/types_gpp.h"

#elif defined(__GNUC__)
#include "kernel/types_gcc.h"

#elif defined(__MWERKS__)
#include "kernel/types_mw.h"

#else
#error "missing types definition"
#endif


/**************************************************************************//**
 @Description   General Handle
 *//***************************************************************************/
typedef void * fsl_handle_t;


#endif /* __FSL_TYPES_H */
