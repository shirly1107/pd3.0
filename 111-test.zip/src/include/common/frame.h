/*
 * Copyright 2013-2020 NXP
 */

/**
 @File          mb_frame_ext.h

 @Description   External definitions and prototypes for multi-buffer
                frame object.

*//***************************************************************************/

#ifndef __MB_FRAME_EXT_H
#define __MB_FRAME_EXT_H

#include "buf_ext.h"


/**************************************************************************//**
 @Group         fsl_lib_g   Utility Library Application Programming Interface

 @Description   External routines.

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Group         frame_id Frame

 @Description   Frame module functions,definitions and enums.

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Description   Multi-Buffer Frame structure
*//***************************************************************************/
typedef struct t_frame
{
/* MUST BE FIRST */
    struct t_frame      *p_next;    /**< Pointer to next frame */

    void *            first_buf;   /**< Handle of the first buffer */
    void *            last_buf;    /**< Handle of the last buffer */
    uint16_t            length;     /**< Number of data bytes in frame */
    volatile uint16_t   owners;     /**< Number of owners */
    void                *info1;     /**< User info pointer */
    void                *info2;     /**< User info pointer */
    uintptr_t           info3;      /**< 32-bit user info */
    uintptr_t           info4;      /**< 32-bit user info */
    uintptr_t           info5;      /**< 32-bit user info */
    uint32_t            status;     /**< 32-bit status field; represents device-specific
                                         Tx/Rx status; A value of 0 always indicates success. */

} t_frame;


/**************************************************************************//**
 @Function      F_Sizeof

 @Description   Returns the size of a multi-buffer frame structure.

 @Return        Size of multi-buffer frame structure.
*//***************************************************************************/
#define     f_sizeof()  sizeof(t_frame)


/**************************************************************************//**
 @Function      F_InitPool

 @Description   Initializes the global multi-buffer frames pool.

 @Param[in]     numOfFrames - Number of frames in the global pool.

 @Return        None.
*//***************************************************************************/
int f_init_pool(uint32_t num_of_frames);

/**************************************************************************//**
 @Function      F_FreePool

 @Description   Frees the global multi-buffer frames pool.

 @Return        None.
*//***************************************************************************/
void    f_free_pool(void);


/**************************************************************************//**
 @Function      F_New

 @Description   Allocates a new frame structure.

                The user initializes the frame with a handle to an already
                initialized buffer. If this handle is NULL, the user should
                insert the buffer later, using one of the following functions:
                F_AppendBuffer(), F_PrependBuffer(), F_InsertBuffer().

 @Param[in]     h_Buffer - The first buffer in the frame (can be NULL).

 @Return        A handle to the frame structure on success; NULL otherwise.
*//***************************************************************************/
void *    f_new(void * h_buffer);

/**************************************************************************//**
 @Function      F_Delete

 @Description   Deletes (release memory of) a frame structure.

                All buffer structures associated with the frame are also
                released. The data blocks of the buffers are released only if
                releaseData is '1'.

 @Param[in]     h_Frame     - Frame structure handle.
 @Param[in]     releaseData - Boolean: release data blocks of all buffers.
*//***************************************************************************/
void        f_delete(void * h_frame, int release_data);

/**************************************************************************//**
 @Function      F_GetBuffer

 @Description   Gets the buffer at the given location from a frame.

 @Param[in]     h_Frame     - Frame structure handle.
 @Param[in]     bufIndex    - Index of desired buffer (first is 0).
 @Param[out]    p_IsLast    - Return by reference: '1' if buffer is last
                              in frame; 0 otherwise.

 @Return        The handle of the desired buffer; NULL if no such buffer.
*//***************************************************************************/
void *    f_get_buffer(void * h_frame, uint16_t buf_index, int *p_is_last);

/**************************************************************************//**
 @Function      F_GetNextBuffer

 @Description   Gets the next buffer after the current buffer.

 @Param[in]     h_Frame     - Frame structure handle.
 @Param[in]     h_Buffer    - Current buffer.
 @Param[out]    p_IsLast    - Return by reference: '1' if buffer is last
                              in frame; 0 otherwise.

 @Return        The handle of the desired buffer; NULL if no such buffer.
*//***************************************************************************/
void *    f_get_next_buffer(void * h_frame, void * h_buffer, int *p_is_last);

/**************************************************************************//**
 @Function      F_AppendBuffer

 @Description   Appends the given buffer to the end of a frame.

 @Param[in]     h_Frame     - Frame structure handle.
 @Param[in]     h_Buffer    - Handle of the buffer to add.
*//***************************************************************************/
void        f_append_buffer(void * h_frame, void * h_buffer);

/**************************************************************************//**
 @Function      F_PrependBuffer

 @Description   Prepends the given buffer to the start of a frame.

 @Param[in]     h_Frame     - Frame structure handle.
 @Param[in]     h_Buffer    - Handle of the buffer to add.
*//***************************************************************************/
void        f_prepend_buffer(void * h_frame, void * h_buffer);

/**************************************************************************//**
 @Function      F_InsertBuffer

 @Description   Inserts the given buffer to a frame, at the requested location.

 @Param[in]     h_Frame     - Frame structure handle.
 @Param[in]     h_Buffer    - Handle of the buffer to insert.
 @Param[in]     bufIndex    - Index (location) for inserting the buffer.
                                   (first is 0). This will be the buffer's index
                                   after the insertion.

 @Return        The actual insertion index, or the highest allowed insertion
                if the requested index is not valid.
*//***************************************************************************/
uint16_t    f_insert_buffer(void * h_frame, void * h_buffer, uint16_t buf_index);

/**************************************************************************//**
 @Function      F_RemoveFirstBuffer

 @Description   Removes the first buffer from the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The handle of the removed buffer; NULL if no such buffer.
*//***************************************************************************/
void *    f_remove_first_buffer(void * h_frame);

/**************************************************************************//**
 @Function      F_RemoveLastBuffer

 @Description   Removes the last buffer from the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The handle of the removed buffer; NULL if no such buffer.
*//***************************************************************************/
void *    f_remove_last_buffer(void * h_frame);

/**************************************************************************//**
 @Function      F_RemoveBuffer

 @Description   Removes a specific buffer from the frame.

 @Param[in]     h_Frame     - Frame structure handle.
 @Param[in]     bufIndex    - Index of the buffer to remove.

 @Return        The handle of the removed buffer; NULL if no such buffer.
*//***************************************************************************/
void *    f_remove_buffer(void * h_frame, uint16_t buf_index);

/**************************************************************************//**
 @Function      F_AppendData

 @Description   Adds (copies) data to the end of the frame.

                This function adds data according to the tail room of the
                frame's last buffer. If there is no sufficient tail room for the
                requested length, the adds buffers repeatedly to the frame, until
                all data is added. The added buffers are created with similar
                attributes to the frame's last buffer, except the headLimit which
                is set to zero.

 @Param[in]     h_Frame     - Frame structure handle.
 @Param[in]     p_Data      - Pointer to the data to be added.
 @Param[in]     length      - The number of bytes to add.

 @Return        The actual number of added bytes.
*//***************************************************************************/
uint16_t    f_append_data(void * h_frame, uint8_t *p_data, uint16_t length);

/**************************************************************************//**
 @Function      F_PrependData

 @Description   Adds (copies) data to the start of the frame.

                This function does not add any buffers to the frame. It only
                adds data according to the head room of the frame's first
                buffer. If there is no sufficient head room for the requested
                length, data will be partially added (last bytes of data shall
                be added).

 @Param[in]     h_Frame - Frame structure handle.
 @Param[in]     p_Data  - Pointer to the data to be added.
 @Param[in]     length  - The number of bytes to add.

 @Return        The actual number of added bytes.
*//***************************************************************************/
uint16_t    f_prepend_data(void * h_frame, uint8_t *p_data, uint16_t length);

/**************************************************************************//**
 @Function      F_CutFromHead

 @Description   Discards data from the start of the frame.

                The p_RemovedBuffer pointer can be used to control the removal of
                buffers from the frame:
                - If p_RemovedBuffer is NULL, no buffers are removed from the
                  frame, and data is removed only from the frame's first buffer.
                - If p_RemovedBuffer is not NULL, it will point to the handle of
                  the removed buffer with the highest index. The user can access
                  all removed buffers by repeatedly calling B_GetPrev() on that
                  buffer and on. If no buffers were removed, p_RemovedBuffer will
                  point to a NULL handle.

                This function does not clear the contents of the removed bytes.

 @Param[in]     h_Frame         - Frame structure handle.
 @Param[in]     length          - The number of bytes to remove.
 @Param[out]    p_RemovedBuffer - If not NULL, shall point to the handle
                                  of the highest-index removed buffer.

 @Return        The actual number of removed bytes.
*//***************************************************************************/
uint16_t    f_cut_from_head(void * h_frame, uint16_t length, void * *p_removed_buffer);

/**************************************************************************//**
 @Function      F_CutFromTail

 @Description   Discards data from the end of the frame.

                The p_RemovedBuffer pointer can be used to control the removal of
                buffers from the frame:
                - If p_RemovedBuffer is NULL, no buffers are removed from the
                  frame, and data is removed only from the frame's last buffer.
                - If p_RemovedBuffer is not NULL, it will point to the handle of
                  the removed buffer with the lowest index. The user can access
                  all removed buffers by repeatedly calling B_GetNext() on that
                  buffer and on. If no buffers were removed, p_RemovedBuffer will
                  point to a NULL handle.

                This function does not clear the contents of the removed bytes.

 @Param[in]     h_Frame         - Frame structure handle.
 @Param[in]     length          - The number of bytes to remove.
 @Param[out]    p_RemovedBuffer - If not NULL, shall point to the handle
                                  of the lowest-index removed buffer.

 @Return        The actual number of removed bytes.
*//***************************************************************************/
uint16_t    f_cut_from_tail(void * h_frame, uint16_t length, void * *p_removed_buffer);

/**************************************************************************//**
 @Function      F_PullHead

 @Description   Increments the position of the first data byte in the frame.

                This function can be used to remove a header from the data.
                The function does not clear the contents of the removed bytes,
                it only moves the position of the first data byte.

 @Param[in]     h_Frame         - Frame structure handle.
 @Param[in]     length          - Number of bytes to remove from the head.

 @Cautions      This function must be called only if length does not exceed
                the buffer's data length. For safer (and slower) operation,
                and for partial removal, use F_CutFromHead().
*//***************************************************************************/
void        f_pull_head(void * h_frame, uint16_t length);

/**************************************************************************//**
 @Function      F_PushHead

 @Description   Decrements the position of the first data byte in the frame.

                This function can be used to include a part which already
                exists in front of the data as part of the data (header).
                The function adds the header only if there is enough room for
                it at the head of the buffer (no partial addition).

 @Param[in]     h_Frame         - Frame structure handle.
 @Param[in]     length          - Number of bytes to add to the head.

 @Cautions      This function must be called only if length does not exceed
                the buffer's head room. For safer (and slower) operation,
                and for partial removal, use F_PrependData().
*//***************************************************************************/
void        f_push_head(void * h_frame, uint16_t length);

/**************************************************************************//**
 @Function      F_PullTail

 @Description   Decrements the position of the last data byte in the frame.

                This function can be used to remove a trailer from the data.
                The function does not clear the contents of the removed bytes,
                it only moves the position of the last data byte.

 @Param[in]     h_Frame         - Frame structure handle.
 @Param[in]     length          - Number of bytes to remove from the tail.

 @Cautions      This function must be called only if length does not exceed
                the buffer's data length. For safer (and slower) operation,
                and for partial removal, use F_CutFromTail().
*//***************************************************************************/
void        f_pull_tail(void * h_frame, uint16_t length);

/**************************************************************************//**
 @Function      F_PushTail

 @Description   Increments the position of the last data byte in the frame.

                This function can be used to include a part which already
                exists right after the data as part of the data (trailer).
                The function adds the trailer only if there is enough room for
                it at the tail of the buffer (no partial addition).

 @Param[in]     h_Frame         - Frame structure handle.
 @Param[in]     length          - Number of bytes to add to the tail.

 @Cautions      This function must be called only if length does not exceed
                the buffer's tail room. For safer (and slower) operation,
                and for partial removal, use F_AppendData().
*//***************************************************************************/
void        f_push_tail(void * h_frame, uint16_t length);

/**************************************************************************//**
 @Function      F_Read

 @Description   Reads (copies) a number of data bytes from a given offset in
                the frame into the given destination.

 @Param[in]     h_Frame - Frame structure handle.
 @Param[out]    p_Dest  - Pointer to a data block to fill with data.
 @Param[in]     offset  - Reading offset from the start of the data.
 @Param[in]     length  - Number of bytes to read (copy).

 @Return        The actual number of copied bytes.
*//***************************************************************************/
uint16_t    f_read(void * h_frame, uint8_t *p_dest, uint16_t offset, uint16_t length);

/**************************************************************************//**
 @Function      F_ReadByte

 @Description   Reads (copies) a single byte from a given offset in the frame
                into the given destination.

 @Param[in]     h_Frame - Frame structure handle.
 @Param[out]    p_Dest  - Pointer to a data block to fill with data.
 @Param[in]     offset  - Reading offset from the start of the data.

 @Return        The actual number of copied bytes (0 or 1).
*//***************************************************************************/
uint16_t    f_read_byte(void * h_frame, uint8_t *p_dest, uint16_t offset);

/**************************************************************************//**
 @Function      F_Replace

 @Description   Replaces a number of data bytes from a given offset in a frame.

 @Param[in]     h_Frame     - Frame structure handle.
 @Param[in]     p_Source    - Pointer to the new data.
 @Param[in]     offset      - Offset from the start of the data.
 @Param[in]     length      - Number of bytes to replace.

 @Return        The actual number of replaced bytes.
*//***************************************************************************/
uint16_t    f_replace(void * h_frame, uint8_t *p_source, uint16_t offset, uint16_t length);

/**************************************************************************//**
 @Function      F_Copy

 @Description   Creates a new frame structure with a copy of the data, but
                with (possibly) different buffer attributes than those of the
                original frame.

                This function can be used to copy a frame that belongs to one
                data pool to another data pool. To copy the frame using the
                same data pool and buffer attributes, one can use F_Clone().

 @Param[in]     h_Frame         - Frame structure handle.
 @Param[in]     p_MemAccess     - Pointer to memory manager access structure.
                                  This pointer must remain valid until the
                                  frame object it released.
 @Param[in]     bufferTailLimit - Tail limit for each buffer (see B_New()).
 @Param[in]     bufferHeadLimit - Head limit for each buffer (see B_New()).

 @Return        A handle to the new frame structure on success; NULL otherwise.
*//***************************************************************************/
void * f_copy(void *        h_frame,
                t_buf_mem_access  *p_mem_access,
                uint16_t        buffer_tail_limit,
                uint16_t        buffer_head_limit);

/**************************************************************************//**
 @Function      F_Clone

 @Description   Creates a new frame structure with a copy of the data, and with
                buffer attributes similar to the original frame.

                The data blocks of the new frame are retrieved using the given
                callback function. The callback parameter shall be the release
                callback parameter in the original frame.

                This function can be used to duplicate a frame using the same
                buffers pool. To copy the frame to a different buffers pool,
                one can use F_Copy().

                The frame can be cloned in one of the following methods:
                - If cloneBuffers is 0, the buffers of the original frame
                  are linked using B_Link(), and not cloned.
                - If cloneBuffers is '1', the buffers of the original frame
                  are cloned using B_Clone() (new buffers are created).

 @Param[in]     h_Frame         - Frame structure handle.
 @Param[in]     cloneBuffers    - '1' to clone the original buffer as well;
                                  '0' to link to original buffers without
                                  cloning them.

 @Return        A handle to the new frame structure on success; NULL otherwise.
*//***************************************************************************/
void * f_clone(void * h_frame, int clone_buffers);

/**************************************************************************//**
 @Function      F_NumOfBuffers

 @Description   Returns the number of buffers in the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The number of buffers in the frame.
*//***************************************************************************/
uint16_t    f_num_of_buffers(void * h_frame);

/**************************************************************************//**
 @Function      F_Print

 @Description   Prints the data in the frame.

 @Param[in]     h_Frame - Frame structure handle.
*//***************************************************************************/
void        f_print(void * h_frame);


#if (DEBUG_ERRORS > 0)

/**************************************************************************//**
 @Function      F_GetFirstBuffer

 @Description   Gets the first buffer of the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The handle of the first buffer if exists; NULL otherwise.
*//***************************************************************************/
void *    f_get_first_buffer(void * h_frame);

/**************************************************************************//**
 @Function      F_GetLastBuffer

 @Description   Gets the first buffer of the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The handle of the last buffer if exists; NULL otherwise.
*//***************************************************************************/
void *    f_get_last_buffer(void * h_frame);

/**************************************************************************//**
 @Function      F_Link

 @Description   Adds an owner to an existing frame (not interrupt safe).

 @Param[in]     h_Frame - Frame structure handle.
*//***************************************************************************/
void        f_link(void * h_frame);

/**************************************************************************//**
 @Function      F_GetLength

 @Description   Gets the total length of data in a frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The total data length.
*//***************************************************************************/
uint16_t    f_get_length(void * h_frame);

/**************************************************************************//**
 @Function      F_SetInfo1

 @Description   Sets the info1 field in the frame.

 @Param[in]     h_Frame - Frame structure handle.
 @Param[in]     info1   - Value of info1.
*//***************************************************************************/
void        f_set_info1(void * h_frame, void *info1);

/**************************************************************************//**
 @Function      F_SetInfo2

 @Description   Sets the info2 field in the frame.

 @Param[in]     h_Frame - Frame structure handle.
 @Param[in]     info2   - Value of info2.
*//***************************************************************************/
void        f_set_info2(void * h_frame, void *info2);

/**************************************************************************//**
 @Function      F_SetInfo3

 @Description   Sets the info3 field in the frame.

 @Param[in]     h_Frame - Frame structure handle.
 @Param[in]     info3   - Value of info3.
*//***************************************************************************/
void        f_set_info3(void * h_frame, uintptr_t info3);

/**************************************************************************//**
 @Function      F_SetInfo4

 @Description   Sets the info4 field in the frame.

 @Param[in]     h_Frame - Frame structure handle.
 @Param[in]     info4   - Value of info4.
*//***************************************************************************/
void        f_set_info4(void * h_frame, uintptr_t info4);

/**************************************************************************//**
 @Function      F_SetInfo5

 @Description   Sets the info5 field in the frame.

 @Param[in]     h_Frame - Frame structure handle.
 @Param[in]     info5   - Value of info5.
*//***************************************************************************/
void        f_set_info5(void * h_frame, uintptr_t info5);

/**************************************************************************//**
 @Function      F_SetStatus

 @Description   Sets the status field in the frame.

 @Param[in]     h_Frame - Frame structure handle.
 @Param[in]     status  - Status value.
*//***************************************************************************/
void        f_set_status(void * h_frame, uint32_t status);

/**************************************************************************//**
 @Function      F_GetInfo1

 @Description   Gets the info1 field from the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The value of info1 field.
*//***************************************************************************/
void *      f_get_info1(void * h_frame);

/**************************************************************************//**
 @Function      F_GetInfo2

 @Description   Gets the info2 field from the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The value of info2 field.
*//***************************************************************************/
void *      f_get_info2(void * h_frame);

/**************************************************************************//**
 @Function      F_GetInfo3

 @Description   Gets the info3 field from the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The value of info3 field.
*//***************************************************************************/
uintptr_t    f_get_info3(void * h_frame);

/**************************************************************************//**
 @Function      F_GetInfo4

 @Description   Gets the info4 field from the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The value of info4 field.
*//***************************************************************************/
uintptr_t    f_get_info4(void * h_frame);

/**************************************************************************//**
 @Function      F_GetInfo5

 @Description   Gets the info5 field from the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The value of info5 field.
*//***************************************************************************/
uintptr_t    f_get_info5(void * h_frame);

/**************************************************************************//**
 @Function      F_GetStatus

 @Description   Gets the status field from the frame.

 @Param[in]     h_Frame - Frame structure handle.

 @Return        The value of the frame's status field.
 *//***************************************************************************/
uint32_t    f_get_status(void * h_frame);

#else /* not DEBUG_ERRORS */


#define f_link(p_F)             ((t_frame *)(p_F))->owners++
#define f_get_length(p_F)        ((t_frame *)(p_F))->length
#define f_set_info1(p_F,p)       ((t_frame *)(p_F))->info1 = (void *)(p)
#define f_set_info2(p_F,p)       ((t_frame *)(p_F))->info2 = (void *)(p)
#define f_set_info3(p_F,l)       ((t_frame *)(p_F))->info3 = (uintptr_t)(l)
#define f_set_info4(p_F,l)       ((t_frame *)(p_F))->info4 = (uintptr_t)(l)
#define f_set_info5(p_F,l)       ((t_frame *)(p_F))->info5 = (uintptr_t)(l)
#define f_set_status(p_F,l)      ((t_frame *)(p_F))->status = (uint32_t)(l)
#define f_get_info1(p_F)         ((t_frame *)(p_F))->info1
#define f_get_info2(p_F)         ((t_frame *)(p_F))->info2
#define f_get_info3(p_F)         ((t_frame *)(p_F))->info3
#define f_get_info4(p_F)         ((t_frame *)(p_F))->info4
#define f_get_info5(p_F)         ((t_frame *)(p_F))->info5
#define f_get_status(p_F)        ((t_frame *)(p_F))->status
#define f_get_first_buffer(p_F)   ((t_frame *)(p_F))->first_buf
#define f_get_last_buffer(p_F)    ((t_frame *)(p_F))->last_buf

#endif /* not DEBUG_ERRORS */


/** @} */ /* end of frame_id group */
/** @} */ /* end of fsl_lib_g group */


#endif /* __MB_FRAME_EXT_H */

