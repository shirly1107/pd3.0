/*
 * Copyright 2013 Freescale Semiconductor, Inc.
 * Copyright 2014-2020 NXP
 */

/**************************************************************************//**
 @File          fsl_types.h

 @Description
 *//***************************************************************************/
#ifndef __FSL_TYPES_H
#define __FSL_TYPES_H

#ifndef __cplusplus
#define NULL ((void *)0)
#else
#define NULL 0L
#endif  /* __cplusplus */

#define MAKE_UMASK32(_width)	(uint32_t)(((uint64_t)1 << (_width)) - 1)
#define MAKE_UMASK64(_width) \
	((uint64_t)((_width) < 64 ? ((uint64_t)1 << (_width)) - 1 : -1))

#include "stdint.h"
#include "stddef.h"

#define _prepacked
#define _packed

/* temporary, due to include issues */
typedef uint32_t uintptr_t;
typedef int32_t intptr_t;

typedef uint64_t dma_addr_t;
typedef uint64_t phys_addr_t;

/*Empty macros to keep common files identical with  AIOP */
#define __START_COLD_CODE 
#define __END_COLD_CODE 

#endif /* __FSL_TYPES_H */
