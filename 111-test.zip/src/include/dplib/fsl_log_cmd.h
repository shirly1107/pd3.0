/* Copyright 2013-2016 Freescale Semiconductor Inc.
 * Copyright 2017-2020 NXP
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * * Neither the name of the above-listed copyright holders nor the
 * names of any contributors may be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 *
 * ALTERNATIVELY, this software may be distributed under the terms of the
 * GNU General Public License ("GPL") as published by the Free Software
 * Foundation, either version 2 of that License or (at your option) any
 * later version.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef __FSL_LOG_CMD_H
#define __FSL_LOG_CMD_H

#include "fsl_cmdif_mc.h"

/* Command IDs */
#define DPMNG_CMDID_SET_LOG 			0x832
#define DPMNG_CMDID_GET_LOG 			0x833

#define CMD_LOG_MASK_MODE  		0x1
#define CMD_LOG_MASK_LEVEL 		0x2
#define CMD_LOG_MASK_MEM_SIZE 	0x4
#define CMD_LOG_MASK_TIMESTAMP 	0x8
#define CMD_LOG_MASK_MODULE_LEVELS 0x10

struct mc_log_data {
	uint32_t mask;
	uint8_t mode; /* log off or on */
	uint8_t global_level; /* global log level */
	uint8_t timestamp_mode; /* timestamp off or on */
	uint64_t mem_size_kb;
	uint8_t  module_levels[LOG_MODULES_AMOUNT_PACKED]; /* 4 bits encoding for the level */
};

#define DPMNG_CMD_LOG_SET_GLOBAL_SETTINGS(cmd, mc_log_info) \
do { \
	MC_CMD_OP(cmd, 0, 0,  32, uint32_t, mc_log_info->mask); \
	MC_CMD_OP(cmd, 0, 32,  8, uint8_t, mc_log_info->mode); \
	MC_CMD_OP(cmd, 0, 40,  8, uint8_t, mc_log_info->global_level); \
	MC_CMD_OP(cmd, 0, 48,  8, uint8_t, mc_log_info->timestamp_mode); \
	MC_CMD_OP(cmd, 1, 0,  64, uint64_t, mc_log_info->mem_size_kb); \
} while (0)

#define DPMNG_CMD_LOG_SET_MODULE_SETTINGS(cmd, mc_log_info) \
do { \
	int DPMNG_CMD_LOG_SET_SETTINGS_i = 0; \
	int DPMNG_CMD_LOG_SET_SETTINGS_param = 0; \
	int DPMNG_CMD_LOG_SET_SETTINGS_bits = LOG_MODULES_AMOUNT * 4; \
	for (; DPMNG_CMD_LOG_SET_SETTINGS_i < DPMNG_CMD_LOG_SET_SETTINGS_bits; DPMNG_CMD_LOG_SET_SETTINGS_i += 8) { \
		DPMNG_CMD_LOG_SET_SETTINGS_param = 2 + (DPMNG_CMD_LOG_SET_SETTINGS_i >> 6); \
		MC_CMD_OP_NO_LOG(cmd, DPMNG_CMD_LOG_SET_SETTINGS_param, DPMNG_CMD_LOG_SET_SETTINGS_i & 0x3F,  8, uint8_t, mc_log_info->module_levels[DPMNG_CMD_LOG_SET_SETTINGS_i >> 3]); \
	} \
	DUMP_ARRAY_SEP_RAW(mc_log_info, module_levels, DUMP_ALL, " "); \
} while (0)

#define DPMNG_CMD_LOG_GET_SETTINGS(cmd, mc_log_info) \
do { \
	MC_CMD_OP(cmd, 0, 0,  32, uint32_t, mc_log_info->mask); \
} while (0)

#define DPMNG_RSP_LOG_GET_SETTINGS(cmd, mc_ver_info) \
do { \
	int DPMNG_RSP_LOG_GET_SETTINGS_i = 0; \
	int DPMNG_RSP_LOG_GET_SETTINGS_param = 0; \
	int DPMNG_RSP_LOG_GET_SETTINGS_bits = LOG_MODULES_AMOUNT * 4; \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, mc_log_info->mask); \
	MC_RSP_OP(cmd, 0, 32,  8, uint8_t, mc_log_info->mode); \
	MC_RSP_OP(cmd, 0, 40,  8, uint8_t, mc_log_info->global_level); \
	MC_RSP_OP(cmd, 0, 48,  8, uint8_t, mc_log_info->timestamp_mode); \
	MC_RSP_OP(cmd, 1, 0,  64, uint64_t, mc_log_info->mem_size_kb); \
	for (; DPMNG_RSP_LOG_GET_SETTINGS_i < DPMNG_RSP_LOG_GET_SETTINGS_bits; DPMNG_RSP_LOG_GET_SETTINGS_i += 8) { \
		DPMNG_RSP_LOG_GET_SETTINGS_param = 2 + (DPMNG_RSP_LOG_GET_SETTINGS_i >> 6); \
		MC_RSP_OP_NO_LOG(cmd, DPMNG_RSP_LOG_GET_SETTINGS_param, DPMNG_RSP_LOG_GET_SETTINGS_i & 0x3F,  8, uint8_t, mc_log_info->module_levels[DPMNG_RSP_LOG_GET_SETTINGS_i >> 3]); \
	} \
	DUMP_ARRAY_SEP_RAW(mc_log_info, module_levels, DUMP_ALL, " "); \
} while (0)

#endif /* __FSL_LOG_CMD_H */
