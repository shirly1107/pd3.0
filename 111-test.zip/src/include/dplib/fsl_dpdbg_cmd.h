/* Copyright 2013-2016 Freescale Semiconductor Inc.
 * Copyright 2017-2020 NXP
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 * * Neither the name of the above-listed copyright holders nor the
 * names of any contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 *
 * ALTERNATIVELY, this software may be distributed under the terms of the
 * GNU General Public License ("GPL") as published by the Free Software
 * Foundation, either version 2 of that License or (at your option) any
 * later version.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef _FSL_DPDBG_CMD_H
#define _FSL_DPDBG_CMD_H

/* DPDBG Version */
#define DPDBG_VER_MAJOR				1
#define DPDBG_VER_MINOR				0

/* Command IDs */
#define DPDBG_CMDID_CREATE						 	0x90f1
#define DPDBG_CMDID_DESTROY						 	0x98f1

#define DPDBG_CMDID_CLOSE                           0x8001
#define DPDBG_CMDID_OPEN                            0x80f1

#define DPDBG_CMDID_GET_API_VERSION                 0xa0f1
#define DPDBG_CMDID_GET_ATTR                        0x0041
#define DPDBG_CMDID_DUMP                            0x1301
#define DPDBG_CMDID_SET								0x1401

/*                cmd, param, offset, width, type, arg_name */
#define DPDBG_CMD_CREATE(cmd, cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  32, int,	    cfg->dpdbg_id);\
	MC_CMD_OP(cmd, 0, 32, 32, int,	    cfg->dpdbg_container_id);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDBG_CMD_OPEN(cmd, dpdbg_id) \
	MC_CMD_OP(cmd, 0, 0,  32, int,	    dpdbg_id)

/*                cmd, param, offset, width, type, arg_name */
#define DPDBG_RSP_GET_ATTRIBUTES(cmd, attr) \
do { \
        MC_RSP_OP(cmd, 0, 32, 32, int,      (attr)->id);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDBG_CMD_DUMP(cmd, obj_id, obj_type) \
do { \
        MC_CMD_OP(cmd, 0, 0,  32, int,      obj_id);\
        MC_CMD_OP(cmd, 0, 32, 8,  char, obj_type[0]);\
        MC_CMD_OP(cmd, 0, 40, 8,  char, obj_type[1]);\
        MC_CMD_OP(cmd, 0, 48, 8,  char, obj_type[2]);\
        MC_CMD_OP(cmd, 0, 56, 8,  char, obj_type[3]);\
        MC_CMD_OP(cmd, 1, 0,  8,  char, obj_type[4]);\
        MC_CMD_OP(cmd, 1, 8,  8,  char, obj_type[5]);\
        MC_CMD_OP(cmd, 1, 16, 8,  char, obj_type[6]);\
        MC_CMD_OP(cmd, 1, 24, 8,  char, obj_type[7]);\
        MC_CMD_OP(cmd, 1, 32, 8,  char, obj_type[8]);\
        MC_CMD_OP(cmd, 1, 40, 8,  char, obj_type[9]);\
        MC_CMD_OP(cmd, 1, 48, 8,  char, obj_type[10]);\
        MC_CMD_OP(cmd, 1, 56, 8,  char, obj_type[11]);\
        MC_CMD_OP(cmd, 2, 0,  8,  char, obj_type[12]);\
        MC_CMD_OP(cmd, 2, 8,  8,  char, obj_type[13]);\
        MC_CMD_OP(cmd, 2, 16, 8,  char, obj_type[14]);\
        MC_CMD_OP(cmd, 2, 24, 8,  char, obj_type[15]);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDBG_CMD_SET(cmd, state, module) \
do { \
		MC_CMD_OP(cmd, 0, 0,  32, int, state);\
        MC_CMD_OP(cmd, 0, 32, 8,  char, module[0]);\
        MC_CMD_OP(cmd, 0, 40, 8,  char, module[1]);\
        MC_CMD_OP(cmd, 0, 48, 8,  char, module[2]);\
        MC_CMD_OP(cmd, 0, 56, 8,  char, module[3]);\
        MC_CMD_OP(cmd, 1, 0,  8,  char, module[4]);\
        MC_CMD_OP(cmd, 1, 8,  8,  char, module[5]);\
        MC_CMD_OP(cmd, 1, 16, 8,  char, module[6]);\
        MC_CMD_OP(cmd, 1, 24, 8,  char, module[7]);\
        MC_CMD_OP(cmd, 1, 32, 8,  char, module[8]);\
        MC_CMD_OP(cmd, 1, 40, 8,  char, module[9]);\
        MC_CMD_OP(cmd, 1, 48, 8,  char, module[10]);\
        MC_CMD_OP(cmd, 1, 56, 8,  char, module[11]);\
        MC_CMD_OP(cmd, 2, 0,  8,  char, module[12]);\
        MC_CMD_OP(cmd, 2, 8,  8,  char, module[13]);\
        MC_CMD_OP(cmd, 2, 16, 8,  char, module[14]);\
        MC_CMD_OP(cmd, 2, 24, 8,  char, module[15]);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPDBG_RSP_GET_API_VERSION(cmd, major, minor) \
do { \
        MC_RSP_OP(cmd, 0, 0,  16, uint16_t, major);\
        MC_RSP_OP(cmd, 0, 16, 16, uint16_t, minor);\
} while (0)

#endif /* _FSL_DPDBG_CMD_H */
