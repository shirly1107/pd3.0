/* Copyright 2013-2016 Freescale Semiconductor Inc.
 * Copyright 2017-2020 NXP
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * * Neither the name of the above-listed copyright holders nor the
 * names of any contributors may be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 *
 * ALTERNATIVELY, this software may be distributed under the terms of the
 * GNU General Public License ("GPL") as published by the Free Software
 * Foundation, either version 2 of that License or (at your option) any
 * later version.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef _FSL_DPSPARSER_CMD_H
#define _FSL_DPSPARSER_CMD_H

/* DPSPARSER last supported API version */
#define DPSPARSER_VER_MAJOR				1
#define DPSPARSER_VER_MINOR				1

/* Command IDs */
#define DPSPARSER_CMDID_CLOSE				0x8001
#define DPSPARSER_CMDID_OPEN				0x8111
#define DPSPARSER_CMDID_CREATE				0x9111
#define DPSPARSER_CMDID_DESTROY				0x9911
#define DPSPARSER_CMDID_GET_API_VERSION		0xa111

#define DPSPARSER_CMDID_ENABLE				0x0021
#define DPSPARSER_CMDID_DISABLE				0x0031
#define DPSPARSER_CMDID_GET_ATTR			0x0041
#define DPSPARSER_CMDID_RESET				0x0051
#define DPSPARSER_CMDID_IS_ENABLED			0x0061

#define DPSPARSER_CMDID_SET_IRQ					0x1101
#define DPSPARSER_CMDID_GET_IRQ					0x1111
#define DPSPARSER_CMDID_SET_IRQ_ENABLE			0x1121
#define DPSPARSER_CMDID_GET_IRQ_ENABLE			0x1131
#define DPSPARSER_CMDID_SET_IRQ_MASK			0x1141
#define DPSPARSER_CMDID_GET_IRQ_MASK			0x1151
#define DPSPARSER_CMDID_GET_IRQ_STATUS			0x1161
#define DPSPARSER_CMDID_CLEAR_IRQ_STATUS		0x1171

#define DPSPARSER_CMDID_APPLY_SPB				0x1181

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_OPEN(cmd) \
	MC_CMD_OP(cmd, 0, 0,  32, int,	    0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_BLOB_SET_ADDR(cmd, addr) \
	MC_CMD_OP(cmd, 0, 0,  64, uint64_t,	    addr)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_BLOB_REPORT_ERROR(cmd, err) \
	MC_RSP_OP(cmd, 0, 0, 16, uint16_t, err)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_RSP_IS_ENABLED(cmd, en) \
	MC_RSP_OP(cmd, 0, 0,  1,  int,	    en)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_SET_IRQ(cmd, irq_index, irq_cfg) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,  irq_index);\
	MC_CMD_OP(cmd, 0, 32, 32, uint32_t, irq_cfg->val);\
	MC_CMD_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr); \
	MC_CMD_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_GET_IRQ(cmd, irq_index) \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_SET_IRQ_ENABLE(cmd, irq_index, en) \
do { \
	MC_CMD_OP(cmd, 0, 0,  8,  uint8_t,  en); \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_GET_IRQ_ENABLE(cmd, irq_index) \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_RSP_GET_IRQ_ENABLE(cmd, en) \
	MC_RSP_OP(cmd, 0, 0,  8,  uint8_t,  en)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_SET_IRQ_MASK(cmd, irq_index, mask) \
do { \
	MC_CMD_OP(cmd, 0, 0,  32, uint32_t, mask);\
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_GET_IRQ_MASK(cmd, irq_index) \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_RSP_GET_IRQ_MASK(cmd, mask) \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, mask)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_GET_IRQ_STATUS(cmd, irq_index, status) \
do { \
	MC_CMD_OP(cmd, 0, 0,  32, uint32_t, status);\
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index);\
} while (0)
/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_RSP_GET_IRQ_STATUS(cmd, status) \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, status)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_CLEAR_IRQ_STATUS(cmd, irq_index, status) \
do { \
	MC_CMD_OP(cmd, 0, 0,  32, uint32_t, status); \
	MC_CMD_OP(cmd, 0, 32, 8,  uint8_t,  irq_index);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_RSP_GET_ATTRIBUTES(cmd, attr) \
	MC_RSP_OP(cmd, 0, 32, 32, int, (attr)->id)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_RSP_GET_API_VERSION(cmd, major, minor) \
do { \
	MC_RSP_OP(cmd, 0, 0,  16, uint16_t, major);\
	MC_RSP_OP(cmd, 0, 16, 16, uint16_t, minor);\
} while (0)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_CMD_SET_FREQ_COMPENSATION(cmd, freq_compensation) \
	MC_CMD_OP(cmd, 0, 0,  32, uint32_t, freq_compensation)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_RSP_GET_FREQ_COMPENSATION(cmd, freq_compensation) \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, freq_compensation)

/*                cmd, param, offset, width, type, arg_name */
#define DPSPARSER_RSP_GET_IRQ(cmd, type, irq_cfg) \
do { \
	MC_RSP_OP(cmd, 0, 0,  32, uint32_t, irq_cfg->val); \
	MC_RSP_OP(cmd, 1, 0,  64, uint64_t, irq_cfg->addr); \
	MC_RSP_OP(cmd, 2, 0,  32, int,	    irq_cfg->irq_num); \
	MC_RSP_OP(cmd, 2, 32, 32, int,	    type); \
} while (0)

/* MC Returned Error codes: */
typedef enum mc_error_spb_id {
	MC_ERROR_SPB_ID_OK = 0,
	MC_ERROR_SPB_ID_MAGIC,
	MC_ERROR_SPB_ID_BLOB_VER,
	MC_ERROR_SPB_ID_BLOB_IP_REV,
	MC_ERROR_SPB_ID_BLOB_LENGTH,
	MC_ERROR_SPB_ID_BLOB_INVALID_LENGTH,
	MC_ERROR_SPB_ID_NAME_NEGATIVE_LENGTH,
	MC_ERROR_SPB_ID_NAME_LENGTH_NOT_MULT_4,
	MC_ERROR_SPB_ID_NO_TARGET_HW,
	MC_ERROR_SPB_ID_BLOB_SP_SIZE_NEGATIVE,
	MC_ERROR_SPB_ID_BLOB_SIZE_ZERO,
	MC_ERROR_SPB_ID_BLOB_NEGATIVE_PROT_NO,
	MC_ERROR_SPB_ID_BLOB_ZERO_PROT_NO,
	MC_ERROR_SPB_ID_BLOB_NULL_PROT_NAME,
	MC_ERROR_SPB_ID_BLOB_SP_SEQ_START_NOT_IN_RANGE,
	MC_ERROR_SPB_ID_BLOB_INVALID_BASE_PROT,
	MC_ERROR_SPB_ID_BLOB_INVALID_PARAM_SECT,
	MC_ERROR_SPB_ID_BLOB_INVALID_PARAMETER,
	MC_ERROR_SPB_ID_BLOB_INVALID_PARAM_CONFIG,
	MC_ERROR_SPB_ID_BLOB_VALUE_NOT_ALIGNED,
	MC_ERROR_SPB_ID_BLOB_INVALID_SECT_TAG,
	MC_ERROR_SPB_ID_BLOB_ZERO_SECT_SIZE,
	MC_ERROR_SPB_ID_BLOB_SECT_SIZE_MULT_4,
	MC_ERROR_SPB_ID_BLOB_SECT_SIZE_BIG,
	MC_ERROR_SPB_ID_BLOB_NO_BYTECODE_SECT_BEFORE,
	MC_ERROR_SPB_ID_BLOB_NO_SP_PROTO_SECT_BEFORE,
	MC_ERROR_SPB_ID_BLOB_NO_BYTECODE_SECT_DEFINED,
	MC_ERROR_SPB_ID_BLOB_NO_SP_PROTO_SECT_DEFINED,
	MC_ERROR_SPB_ID_BLOB_SP_BLOB_PARSING_ERROR,
	MC_ERROR_SPB_ID_BLOB_ALREADY_APPLIED,
	MC_ERROR_SPB_ID_BLOB_NO_ADDRESS_SET,
	MC_ERROR_SPB_ID_BLOB_PARAM_OFFSET_MULT_4,
	MC_ERROR_SPB_ID_BLOB_PARAM_OFFSET_LESS_0x40,
	MC_ERROR_SPB_ID_BLOB_BYTECODE_SIZE_MULT_4,
	MC_ERROR_SPB_ID_BLOB_BYTECODE_SIZE_ZERO,
	MC_ERROR_SPB_ID_BLOB_BYTECODE_OVERWRITE_0xFFE,
	MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_TARGET_PARSER,
	MC_ERROR_SPB_ID_BLOB_BYTECODE_OVERLAPPED,
	MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_PARSER_SUPPORT,
	MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_EXCEEDED_WRIOP_ingress,
	MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_EXCEEDED_WRIOP_egress,
	MC_ERROR_SPB_ID_BLOB_BYTECODE_NO_EXCEEDED_AIOP,
	MC_ERROR_SPB_ID_BLOB_PROTOCOL_DUPLICATED,
	MC_ERROR_SPB_ID_BLOB_PROTOCOL_NO_EXCEEDED,
	MC_ERROR_SPB_ID_BLOB_PROTOCOL_LIMIT_EXCEEDED,
	MC_ERROR_SPB_ID_BLOB_PROTOCOL_LINKED_TWICE,
	MC_ERROR_SPB_ID_BLOB_SP_LINKED_TWICE,
	MC_ERROR_SPB_ID_BLOB_PARAM_OFFSET_EXCEEDED,
	MC_ERROR_SPB_ID_BLOB_PARAM_SIZE_EXCEEDED,
	MC_ERROR_SPB_ID_BLOB_PARAM_OFFSET_SIZE_EXCEEDED,
	MC_ERROR_SPB_ID_BLOB_PARAM_NO_EXCEEDED,
	MC_ERROR_SPB_ID_BLOB_PARAM_NAME_DUPLICATED,
	MC_ERROR_SPB_ID_BLOB_PARAM_OVERLAPPED,
	MC_ERROR_SPB_ID_BLOB_NO_DPSP_HANDLE,
	MC_ERROR_SPB_ID_BLOB_PROFILE_DUPLICATED,
	MC_ERROR_SPB_ID_BLOB_INVALID_PROT_NO,
	MC_ERROR_SPB_ID_BLOB_PROFILES_NO_EXCEEDED,
	MC_ERROR_SPB_ID_BLOB_UNSUPPORTED_VERSION,

}mc_error_spb_id;

/* MC Unknown error: */
#define MC_ERROR_MSG_SPB_UNKNOWN 	"Unknown MC error\n"

/* MC Error messages (in order for each error code defined above): */
#define MC_ERROR_MSG_APPLY_SPB \
{ \
	"OK\n", \
	"BLOB : Magic number does not match\n", \
	"BLOB : Version does not match MC API version\n", \
	"BLOB : IP revision does not match HW revision\n", \
	"BLOB : Blob length is not a multiple of 4\n", \
	"BLOB : Invalid length detected\n", \
	"BLOB : Name length < 0 in 'blob-name'\n", \
	"BLOB : Name length not a 4 multiple in 'blob-name'\n", \
	"BLOB : No target HW parser selected\n", \
	"BLOB : SP size is negative\n", \
	"BLOB : Size is zero\n", \
	"BLOB : Number of protocols is negative\n", \
	"BLOB : Zero protocols\n", \
	"BLOB : Protocol name is null\n", \
	"BLOB : SP 'seq-start' is not in [0x40, 0xffc0) range\n", \
	"BLOB : Invalid base protocol\n", \
	"BLOB : Invalid parameters section\n", \
	"BLOB : Invalid parameter\n", \
	"BLOB : Invalid parameter configuration\n", \
	"BLOB : Not aligned value\n", \
	"BLOB : Invalid section TAG detected\n", \
	"BLOB : Section size is zero\n", \
	"BLOB : Section size not a 4 multiple\n", \
	"BLOB : Section size is too big\n", \
	"BLOB : No 'bytecode' section before\n", \
	"BLOB : No 'sp-protocols' section before\n", \
	"BLOB : No 'bytecode' section defined\n", \
	"BLOB : No 'sp-protocols' section defined\n", \
	"BLOB : Soft Parser BLOB parsing : Error detected\n", \
	"apply spb : Soft Parser BLOB is already applied\n", \
	"apply spb : BLOB address is not set\n", \
	"BLOB : SP parameter offset is not a 4 multiple\n", \
	"BLOB : SP parameter offset can't be less than 0x40\n", \
	"BLOB : Bytecode size is not a 4 multiple\n", \
	"BLOB : Bytecode size cannot be zero\n", \
	"BLOB : Bytecode can't overwrite the 0xFFE address\n", \
	"BLOB : No hardware parser selected as target\n", \
	"BLOB : Bytecode overlap detected\n", \
	"BLOB : No parser support\n", \
	"BLOB : Too many bytecode sections on WRIOP ingress\n", \
	"BLOB : Too many bytecode sections on WRIOP egress\n", \
	"BLOB : Too many bytecode sections on AIOP\n", \
	"BLOB : Duplicated protocol is already registered\n", \
	"BLOB : Maximum number of allowed protocols was exceeded\n", \
	"BLOB : Protocols limit exceeded\n", \
	"BLOB : Protocol is linked twice\n", \
	"BLOB : Soft parser is linked twice\n", \
	"BLOB : Parameter offset exceeds the maximum parameters limit\n", \
	"BLOB : Parameter size can't be 0 or greater than 64\n", \
	"BLOB : Parameter offset plus size exceeds the maximum parameters limit\n", \
	"BLOB : Parameters number exceeds the maximum limit\n", \
	"BLOB : Duplicated parameter name\n", \
	"BLOB : Parameters overlapped detected\n", \
	"apply spb : No dpsparser handle.\n", \
	"BLOB : Duplicated profile is already registered\n", \
	"BLOB : Number of protocols is invalid\n", \
	"BLOB : Maximum number of allowed profiles was exceeded\n", \
	"BLOB : Unsupported backward compatible version\n", \
	\
	MC_ERROR_MSG_SPB_UNKNOWN, \
	NULL, \
}

#endif /* _FSL_DPSPARSER_CMD_H */
