/*
 * Copyright 2013-2020 NXP
 */

#ifndef _FSL_DCE_CTRL_H
#define _FSL_DCE_CTRL_H

#include "drivers/fsl_dce_base.h"

/* Driver object for managing a DCE instance on the SoC */
struct dce_block;

/* Creates a functional object representing the given DCE block descriptor.
 * This includes mapping the block's register space (if it isn't statically
 * mapped) and allocating the dce_block data structure (if it isn't statically
 * declared). This can not be done more than once for a given descriptor. */
struct dce_block *dce_block_init(const struct dce_block_desc *);
/* This undoes the effect of dce_block_init() */
void dce_block_finish(struct dce_block *);

/* Returns the descriptor for this block. */
const struct dce_block_desc *dce_block_get_desc(struct dce_block *);

/* Global attributes of the block. These will have sane defaults. */

/* The read safe disable should always be enabled, default setting is enabled.
 * This is a read optimization that pads system bus transactions with extra read
 * data in order to create optimally aligned transactions. */
void dce_block_get_read_safe_disable(struct dce_block *, int *is_disable);
void dce_block_set_read_safe_disable(struct dce_block *, int disable);

/* Dynamic power management disable. This setting conserves power when the DCE
 * block is enabled, but not porcessing work. It should be left at reset value,
 * false, to conserve power usage */
void dce_block_get_dynamic_power_management_disable(struct dce_block *b,
							int *is_disable);
void dce_block_set_dynamic_power_management_disable(struct dce_block *b,
							int disable);

/* enable level */
enum dce_enable_level {
	DCE_ENABLE_LEVEL_DISABLE,
	DCE_ENABLE_LEVEL_PAUSE,
	DCE_ENABLE_LEVEL_RESERVED,
	DCE_ENABLE_LEVEL_ENABLE
};

/* This field enables/disables operations of the DCE. If changed during
 * operation, the DCE will gracefully start or stop dequeuing and processing of
 * Frames. The stop state (dce_block_get_stop_state) is used to determine when a
 * graceful DCE_ENABLE_LEVEL_PAUSE has completed. The idle state
 * (dce_block_get_idle_state) will eventually become set when this field is set
 * to DCE_ENABLE_LEVEL_DISABLE, indicating that the block is disabled and has
 * quiesced. */
void dce_block_get_enable_level(struct dce_block *,
				enum dce_enable_level *level);
void dce_block_set_enable_level(struct dce_block *,
				enum dce_enable_level level);

/* Impose a length limit on the output data Frames when the buffers being used
 * to store the Frame data are taken from BMan. If the output data for a Frame
 * required more buffers than specified by this limit, the output data Frame
 * will be treated as a case of insufficiency. */
void dce_block_get_output_length_limit(struct dce_block *, uint16_t *limit);
void dce_block_set_output_length_limit(struct dce_block *, uint16_t limit);

/* Impose a protection limit on the depth of input scatter/gather structure that
 * the DCE can traverse. DCE increments an internal counter every time it
 * follows a scatter/gather table entry that has FMT=b10 and F=0 (TODO: need toi
 * reword). If the internal counter reaches the value programmed by this api
 * without encountering an end of Frame entry (F=1), the DCE will behave as if
 * it encountered an F=1 entry. This api exists in order to prevent the DCE from
 * becoming unresponsive if it is given a circular input scatter/gather
 * structure to process. Maximum value is 0x3ff */
void dce_block_get_hop_count_limit(struct dce_block *, uint16_t *limit);
void dce_block_set_hop_count_limit(struct dce_block *, uint16_t limit);

/* Idle,Stop status state */
void dce_block_get_stop_state(struct dce_block *, int *is_stopped);
void dce_block_get_idle_state(struct dce_block *, int *is_idle);

/* system memory cache attribute control
 * chwc: compression history write cache aware.
 * scwc: stream context record write cache aware
 * fdwc: frame data (and table) write cache aware
 * dhwc: decompression history write cache aware
 * chrc: compression history read aware
 * scrc: stream comtext record read cache aware
 * fdrc: frame data (and table) read cache aware
 * The default values should be COHERENT_SNOOP
*/
enum dce_write_cache_type {
	DCE_WRITE_CACHE_TYPE_COHERENT,
	DCE_WRITE_CACHE_TYPE_COHERENT_SNOOP,
	DCE_WRITE_CACHE_TYPE_COHERENT_STASHING
};

enum dce_read_cache_type {
	DCE_READ_CACHE_TYPE_COHERENT,
	DCE_READ_CACHE_TYPE_COHERENT_SNOOP,
};

void dce_block_get_chwc(struct dce_block *, enum dce_write_cache_type *cache);
void dce_block_set_chwc(struct dce_block *, enum dce_write_cache_type cache);
void dce_block_get_scwc(struct dce_block *, enum dce_write_cache_type *cache);
void dce_block_set_scwc(struct dce_block *, enum dce_write_cache_type cache);
void dce_block_get_fdwc(struct dce_block *, enum dce_write_cache_type *cache);
void dce_block_set_fdwc(struct dce_block *, enum dce_write_cache_type cache);
void dce_block_get_dhwc(struct dce_block *, enum dce_write_cache_type *cache);
void dce_block_set_dhwc(struct dce_block *, enum dce_write_cache_type cache);
void dce_block_get_chrc(struct dce_block *, enum dce_read_cache_type *cache);
void dce_block_set_chrc(struct dce_block *, enum dce_read_cache_type cache);
void dce_block_get_scrc(struct dce_block *, enum dce_read_cache_type *cache);
void dce_block_set_scrc(struct dce_block *, enum dce_read_cache_type cache);
void dce_block_get_fdrc(struct dce_block *, enum dce_read_cache_type *cache);
void dce_block_set_fdrc(struct dce_block *, enum dce_read_cache_type cache);
void dce_block_get_dhrc(struct dce_block *, enum dce_read_cache_type *cache);
void dce_block_set_dhrc(struct dce_block *, enum dce_read_cache_type cache);

/* system memory priority control
 * read and write transactions. Default level is NORMAL */
enum dce_sys_mem_priority_level {
	DCE_SYS_MEM_PRIORITY_LEVEL_NORMAL,
	DCE_SYS_MEM_PRIORITY_LEVEL_ELEVATED,
};

void dce_block_get_sysmemwpri(struct dce_block *,
				enum dce_sys_mem_priority_level *level);
void dce_block_set_sysmemwpri(struct dce_block *,
				enum dce_sys_mem_priority_level level);
void dce_block_get_sysmemrpri(struct dce_block *,
				enum dce_sys_mem_priority_level *level);
void dce_block_set_sysmemrpri(struct dce_block *,
				enum dce_sys_mem_priority_level level);

/* Provides the ability to invalidate any copies of system memory data help
 * internally by DCE. It is not safe to call this api unless the DCE is in the
 * stopped state by setting the enable level to DCE_ENABLE_LEVEL_PAUSE first. */
void dce_block_invalidate_internal_context(struct dce_block *);

/* statistics */
/* The DCE hardware has two 32bit registers that represents the below 64bit
 * statistics. Both registers (high/low) will silently roll over unless reset by
 * software.
 * Design note: should there be a task on the MC that run periodically to read
 * the latest values and keeps a running counter? The following apis would be
 * accessing these cached version of stats. If this is the case should add apis
 * to reset/set the counters */

/* statistics compressor */
void dce_block_get_compressor_input_byte_count(struct dce_block *,
						uint64_t *count);
void dce_block_set_compressor_input_byte_count(struct dce_block *,
						uint64_t count);
void dce_block_get_compressor_output_byte_count(struct dce_block *,
						uint64_t *count);
void dce_block_set_compressor_output_byte_count(struct dce_block *,
						uint64_t count);

/* statistics decompressor */
void dce_block_get_decompressor_input_byte_count(struct dce_block *,
						uint64_t *count);
void dce_block_set_decompressor_input_byte_count(struct dce_block *,
						uint64_t count);
void dce_block_get_decompressor_output_byte_count(struct dce_block *,
						uint64_t *count);
void dce_block_set_decompressor_output_byte_count(struct dce_block *,
						uint64_t count);

/* error interrupt */
void dce_block_set_init_err(struct dce_block *);

/* source id */
void dce_block_get_sourceid(struct dce_block *, uint32_t *sourceid);
void dce_block_get_dce_version(struct dce_block *);
uint64_t dce_block_get_version(void);

#define ERR010843_DCE_REV 0x0AF0020000000100LLU

#endif /* !_FSL_DCE_CTRL_H */
