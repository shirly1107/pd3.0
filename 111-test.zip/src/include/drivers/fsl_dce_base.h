/*
 * Copyright 2013-2020 NXP
 */

#ifndef _FSL_DCE_BASE_H
#define _FSL_DCE_BASE_H

/* Descriptor for a DCE instance on the SoC. On partitions/targets that do not
 * control this DCDE instance, these values may simply be place-holders. The
 * idea is simply that we be able to distinguish between them, eg. so that
 * descriptors can identify which DCE instance they belong to. */
struct dce_block_desc {
	void *ccsr_reg_bar; /* CCSR register map */
	int irq_err;  /* Error interrupt line */
};

#endif /* !_FSL_DCE_BASE_H */
