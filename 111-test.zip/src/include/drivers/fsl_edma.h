/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_EDMA_H
#define __FSL_EDMA_H

#include "fsl_dpmng_mc.h"

/**************************************************************************//**
 @Description SoC specific configuration for eDMA
*//***************************************************************************/
struct edma_desc 
{
    uint32_t edma_id; /**< eDMA id */
    uint32_t num_blocks; /**< eDMA blocks number, for ls2100 it is 2 */
    uint32_t irq_transaction_err; /**< irq number for eDMA Read/Write 
             transaction Errors */
    uint32_t irq_queue_err; /**< irq number for eDMA queue related Errors */
    phys_addr_t paddr;/**< Virtual address of eDMA privileged registers in MC
                      memory map */
    void *vaddr;/**< Physical address of eDMA privileged registers in MC memory
                 map */
};
/**************************************************************************//**
 @Description Placeholder for edma handle 
*//***************************************************************************/
struct edma; 

/**************************************************************************//**
 @Function edma_init
 @Description EDMA initialization function, called from platform.
 @Param[in] desc SoC specific configurations
 @Return    eDMA handle on Success, platform will store it in the system.
  		'NULL' on Failure, no handle is stored.
*//***************************************************************************/
struct edma* edma_init (const struct edma_desc *desc);

/**************************************************************************//**
 @Function      edma_free.
 @Description   Deallocates resources allocated in edma_init.
 @Param[in]  edma_handle  eDMA handle
 @Return    Status of deallocation. Negative value means an error.
*//***************************************************************************/
int edma_free(struct edma* edma_handle);


/**************************************************************************//**
 @Description SoC specific configuration for an eDMA block
*//***************************************************************************/
struct edma_block_desc 
{
    uint32_t edma_block_id; /**< eDMA block id */
    uint32_t irq; /**< irq number for normally terminated block transactions */
    uint32_t num_queues; /**< queues number per block, for ls2100 it is 8*/
    phys_addr_t paddr;/**< Physical address of command queue0 registers in MC 
                      memory map */
    void *vaddr;/**< Virtual address of command queue0 registers in MC memory 
                 map */
};

/**************************************************************************//**
 @Description eDMA block configuration parameters.
*//***************************************************************************/
struct edma_block_cfg
{
    struct edma *edma; /**< edma handle */
    uint32_t num_entries_in_status_queue;/**< Number of entries in status queue
                                         of this block. Min. value=64, 
                                         Max.value=16384, must be a power of 2*/
    uint32_t coalesc_intr_status_threshold;/**< Coalescing interrupt status 
                                           threshold for this block. 
                                           0 means no interrupts*/
    uint32_t water_mark_threshold; /**< Water mark for Status queue
                                    Congestion Management */
    int      mem_partition_id; /**<Memory partition where block related data 
                                   structures are allocated */
    struct dpmng_amq block_amq; /** Access Management Qualifiers to access eDMA 
                                    descriptors */ 
};

/**************************************************************************//**
 @Description Placeholder for edma_block handle 
*//***************************************************************************/
struct edma_block; 



/**************************************************************************//**
 @Function edma_block_init
 @Description EDMA block initialization function, called from platform.
 @Param[in] cfg  User specific configurations for this block
 @Param[in] descr eDMA SoC specific configurations
 @Param[in] block_id  Index of the eDMA block to be initialized.
 @Return    eDMA block handle on Success, platform will store it in the system.
  		'NULL' on Failure, no handle is stored.
*//***************************************************************************/
struct edma_block* edma_block_init (const struct edma_block_desc *desc,
			                const struct edma_block_cfg *cfg); 


/**************************************************************************//**
@Function      edma_block_free
@Description   Deallocates resources allocated in edma_block_init
@Param[in]	  block_handle -  Handle to a  eDMA  block
@Return        Status of deallocation, a negative value means an error. 

*//***************************************************************************/
int edma_block_free(struct edma_block* block_handle);





/**************************************************************************//**
 @Description eDMA queue initialization parameters.
*//***************************************************************************/
struct edma_queue_cfg
{
    uint8_t priority_queue; /**< Queue priority, can get values 0-7, lower 
                            number means higher priority */
    uint32_t size_queue; /**< Number of entries in this queue.
                          Min. value = 64, Max.value = 16384, must be 
                          a power of 2 */
    int   mem_partition_id; /**< Memory partition where queue related data 
                            structures are allocated */
};

/**************************************************************************//**
 @Description Placeholder for edma_queue handle 
*//***************************************************************************/
struct edma_queue;


/**************************************************************************//**
@ Function edma_queue_init
@Description Initializes an eDMA queue.
@Param[in]    block_handle - Handle to a eDMA  block, should be retrieved 
              from the system.
@Param[in]    block_id Block id that this queue belongs to.
@Param[in]    queue_id � Index of queue, valid values 0-7.                           
@Param[in]    edma_queue_cfg � parameters for queue initialization 
              (priority, etc).
@Returns      A handle to queue in case of success, NULL in case of failure.
              The handle should be stored in system.
*//***************************************************************************/
struct edma_queue* edma_queue_init(struct edma_block* block_handle,
                                   uint32_t block_id,
                                   uint32_t queue_id,
                                   struct edma_queue_cfg *cfg);

/**************************************************************************//**
@Function      edma_queue_free
@Description   Deallocates resources allocated in edma_queue_init
@Param[in]	  queue_handle -  Handle to a eDMA queue	
@Return Status of deallocation. 
*//***************************************************************************/
int edma_queue_free(struct edma_queue* queue_handle);




/**************************************************************************//**
 @Description Possible values for transfer_flag parameter of edma_transfer_cfg 
              structure
*//***************************************************************************/
#define EDMA_SNOOP_ENABLE_TRANSFER 0x1	/**< Enable snooping on local core */

/**< If EDMA_ASYNC bit set, this transaction is asynchronous and non-blocking 
     (returns immediately). A callback function will be called 
     upon transaction completion.       
     If not set, it is synchronous and blocking (upon returning from function
     , the transaction is completed) */
#define EDMA_ASYNC (0x1 << 1)

#define EDMA_SRC_ADDR_PL (0x1 << 2)  	/**<Privilege Level for source address*/
#define EDMA_SRC_ADDR_BMT (0x1 << 3)  	/**<Bypass Memory Translation for src.
                                         address */
#define EDMA_SRC_ADDR_VA (0x1 << 4)  	/**< Whether the source address provided
                                       edma_transfer_cfg is a virtual address */
#define EDMA_SRC_ADDR_IA (0x1 << 5)  	/**< Internal source address, by default
                                        it is external */
#define EDMA_DEST_ADDR_PL (0x1 << 6)  	/**<Privilege Level for dest. address*/
#define EDMA_DEST_ADDR_BMT (0x1 << 7)  	/**<Bypass Memory Translation for  dest.
                                         address */
#define EDMA_DEST_ADDR_VA (0x1 << 8)  	/**< Whether the dest. address provided
                                       edma_transfer_cfg is a virtual address */
#define EDMA_DEST_ADDR_IA (0x1 << 9)  	/**< Internal dest. address, by default
                                        it is external */

enum transac_status
{
    EDMA_NORMAL                = 0x0,  
    EDMA_DEST_DESCRIPTOR_ERROR = 0x1,
    EDMA_SRC_DESCRIPTOR_ERROR  = 0x2,
    EDMA_CD_ERROR   	       = 0x4,
    EDMA_WRITE_TRANS_ERROR     = 0x10,  
    EDMA_READ_TRANS_ERROR      = 0x20,       
    EDMA_DESCRIPTORS_ACCESS_ERROR = 0x40,
};





/**************************************************************************//**
 @Description Type for a parameter of edma_queue_transfer function
*//***************************************************************************/
struct edma_transfer
{
    dma_addr_t src; /**< Physical source address of the transfer */
    dma_addr_t dst; /**< Physical destination address of the transfer */
    uint16_t	src_icid;  /**<This transfer Isolation Context ID */
    uint16_t	dst_icid;  /**<This transfer Isolation Context ID */
    uint32_t byte_count; 	    /**< Number of bytes to transfer */
   /**<Complete callback invoked by driver on end of transfer event. 
    If EDMA_ASYNC is not set and complete_cb is not null � error,
    If EDMA_ASYNC is not set and complete_cb is null � synchronous, blocking
    If EDMA_ASYNC is set and complete_cb is not null, the callback 
      will be called  upon transaction completion.
    If EDMA_ASYNC is set and complete_cb is null � �fire and forget� mode>*/   
    void (*complete_cb )(void *arg, enum transac_status status); 
    void *arg; /**< Transfer context, will be provided as an argument in the 
                   callback */
    uint32_t flags; /**< Additional parameters for transaction , i.e. 
                     snoop_enable etc.,see the above #define */     
};


/**************************************************************************//**
@Function    edma_queue_transfer
@Description Add eDMA transaction to queue.
@Param[in]	  queue � Queue handle to a add transaction to. It is retrieved from
               system.	
@Param[in]     cfg - Defines  eDMA transfer parameters.
@Param[out]    status - In case of synchronous transaction, contains transaction
               status.
               In case of asynchronous transaction, this parameter is ignored 
               and a callback function parameter will include the transaction 
               status. 
@Return        Status of the transfer 0  means success, 
               A non-zero ORed combination of enum transac_status means error.
*//***************************************************************************/
int edma_queue_transfer(struct edma_queue *queue,
                        struct edma_transfer *params,
			    enum transac_status *status);
#endif //__FSL_EDMA_H


