/*
 * Copyright 2013-2020 NXP
 */

#ifndef _FSL_QBMAN_CTRL_H
#define _FSL_QBMAN_CTRL_H

#include "drivers/fsl_qbman_base.h"
#include "fsl_qbman.h"

/* Driver object for managing a QBMan instance on the SoC */
struct qbman_block;

/* Creates a functional object representing the given QBMan block descriptor.
 * This includes mapping the block's register space (if it isn't statically
 * mapped) and allocating the qbman_block data structure (if it isn't statically
 * declared). This can not be done more than once for a given descriptor. */
struct qbman_block *qbman_block_init(const struct qbman_block_desc *, enum orl_oree_mode oree_mode);
/* This undoes the effect of qbman_block_init() */
void qbman_block_finish(struct qbman_block *);

/* Returns the descriptor for this block. */
const struct qbman_block_desc *qbman_block_get_desc(struct qbman_block *);

/* Some attributes of the block must be set before the device can be considered
 * to be "available", and can no longer be modified at that point. (Eg. private
 * memory windows and access attributes, the number of 2-WQ channels versus
 * 8-WQ channels, etc.) Use of portals via the CCSR access registers is not
 * possible until this point has been reached. */
void qbman_block_init_complete(struct qbman_block *);

/* Global attributes of the block. These will have sane defaults. */
void qbman_block_get_wred_prescalar(struct qbman_block *, uint16_t *pres);
void qbman_block_set_wred_prescalar(struct qbman_block *, uint16_t pres);

void qbman_block_get_orl_external_memory(struct qbman_block *b, int *oree);
void qbman_block_set_orl_external_memory(struct qbman_block *b, int oree);

void qbman_block_get_ics_precedence_mode(struct qbman_block *, int *ics_pm);
void qbman_block_set_ics_precedence_mode(struct qbman_block *, int ics_pm);
void qbman_block_get_order_restoration_depletion(struct qbman_block *b,
						 int *ordbe, uint16_t *ordt);
void qbman_block_set_order_restoration_depletion(struct qbman_block *b,
						 int ordbe, uint16_t ordt);
void qbman_block_get_bus_source_id(struct qbman_block *, uint8_t *srcid); /* read-only */
void qbman_block_get_num8ch(struct qbman_block *, uint16_t *num8ch);
void qbman_block_set_num8ch(struct qbman_block *, uint16_t num8ch);
void qbman_block_get_initiator_sched_weight(struct qbman_block *,
				uint8_t *bman, uint8_t *qman, uint8_t *srq);
void qbman_block_set_initiator_sched_weight(struct qbman_block *,
				uint8_t bman, uint8_t qman, uint8_t srq);
void qbman_block_get_initiator_stash_credit(struct qbman_block *, uint8_t *srcciv);
void qbman_block_set_initiator_stash_credit(struct qbman_block *, uint8_t srcciv);

/* Global attribute that won't have a usable default. */
int qbman_block_set_msi_address(struct qbman_block *, int idx,
				 uint32_t msi_bare, uint32_t msi_bar);

/* Per-DCP attributes of the block. These will have sane defaults. */
void qbman_block_get_shaper_prescalar(struct qbman_block *,
				      unsigned int idx, unsigned int iid,
				      uint16_t *pres);
void qbman_block_set_shaper_prescalar(struct qbman_block *,
				      unsigned int idx, unsigned int iid,
				      uint16_t pres);

/* Per-SWP attributes of the block. These will have sane/disabled defaults. */
void qbman_block_get_swp_icid(struct qbman_block *, int idx, uint16_t *icid);
void qbman_block_set_swp_icid(struct qbman_block *, int idx, uint16_t icid);
void qbman_block_get_swp_iobypass(struct qbman_block *, int idx, int *iobypass);
void qbman_block_set_swp_iobypass(struct qbman_block *, int idx, int iobypass);
void qbman_block_get_swp_sdest(struct qbman_block *, int idx, uint8_t *sdest);
void qbman_block_set_swp_sdest(struct qbman_block *, int idx, uint8_t sdest);
void qbman_block_get_swp_ss(struct qbman_block *b, int idx, uint8_t *ss);
void qbman_block_set_swp_ss(struct qbman_block *b, int idx, uint8_t ss);
void qbman_block_get_swp_va(struct qbman_block *, int idx, int *va);
void qbman_block_set_swp_va(struct qbman_block *, int idx, int va);
void qbman_block_get_swp_isolated(struct qbman_block *, int idx, int *isolated);
void qbman_block_set_swp_isolated(struct qbman_block *, int idx, int isolated);
void qbman_block_get_swp_enabled(struct qbman_block *, int idx, int *enabled);
int qbman_block_set_swp_enabled(struct qbman_block *, int idx, int enabled);
void qbman_block_get_swp_msi_data(struct qbman_block *, int idx, uint16_t *data);
void qbman_block_set_swp_msi_data(struct qbman_block *, int idx, uint16_t data);
/* Get/set the 16 "push index" dequeue channel mappings for each SWP. */
void qbman_block_get_swp_channel(struct qbman_block *, int idx,
				 uint8_t sdqmr_idx, int *enabled,
				 uint16_t *channel_id);
void qbman_block_set_swp_channel(struct qbman_block *, int idx,
				 uint8_t sdqmr_idx, int enabled,
				 uint16_t channel_id);
void qbman_block_get_swp_srcid_map(struct qbman_block *b, int idx,
				   uint8_t *srcid, uint8_t *sdest);
void qbman_block_set_swp_srcid_map(struct qbman_block *b, int idx,
				   uint8_t srcid, uint8_t sdest);

#ifdef MC_CLI
int qbman_block_swp_cinh_write(struct qbman_block *, int idx, uint32_t offset,
				    uint32_t val);
uint32_t qbman_block_swp_cinh_read(struct qbman_block *, int idx, uint32_t offset);
int qbman_block_swp_cena_write(struct qbman_block *, int idx, uint32_t offset,
				    uint32_t *val);
int qbman_block_swp_cena_read(struct qbman_block *, int idx, uint32_t offset,
				    uint32_t *val);
#endif

/* Map one of the 4 non-MSI IRQs to a portal. */
void qbman_block_get_non_msi_portal(struct qbman_block *, unsigned int irq_index,
				    unsigned int *swp_idx, int *enabled);
void qbman_block_set_non_msi_portal(struct qbman_block *, unsigned int irq_index,
				    unsigned int swp_idx, int enabled);

/* Reset a SWP, blocks until hardware completes */
int qbman_block_reset_swp(struct qbman_block *, int idx);

/* Set private (main) memory windows and access attributes */
void qbman_block_set_mem_attributes(struct qbman_block *, uint16_t icid, int iobypass, int va,
				    int iobypass1, int iobypass2, int iobypass3);
void qbman_block_set_mem_fbpr(struct qbman_block *, uint32_t fbpr_bare, uint32_t fbpr_bar, size_t fbpr_size);
int qbman_block_set_mem_pfdr(struct qbman_block *, uint32_t pfdr_bare,
			      uint32_t pfdr_bar, size_t pfdr_size, int sm,
			      uint32_t num_orl_recs, uint8_t pps, uint8_t pfdr_pool_min_value);
void qbman_block_set_mem_wqpr(struct qbman_block *, uint32_t wqpr_bare, uint32_t wqpr_bar, size_t wqpr_size);
void qbman_block_set_swp_bar(struct qbman_block *, uint32_t swp_bare, uint32_t swp_bar);
void qbman_block_set_swp_bar_cp_mem(struct qbman_block *b,
				    uint32_t swp_bare_cp_mem,
				    uint32_t swp_bar_cp_mem);
void qbman_block_set_pfdr_threshold(struct qbman_block *, uint32_t th, uint8_t k, uint8_t pps);
/* Disable all recoverable interrupts and clear them in status register.*/
void qbman_block_set_init_rerr(struct qbman_block *b);
void qbman_block_set_init_rerr_fqid(struct qbman_block *b, uint32_t fqid);
void qbman_block_set_init_nrerr(struct qbman_block *b);

void qbman_block_set_rerr_status(struct qbman_block *b, uint32_t status);
uint32_t qbman_block_get_rerr_status(struct qbman_block *b);
void qbman_block_set_rerr_enable(struct qbman_block *b, uint32_t enable);
uint32_t qbman_block_get_rerr_enable(struct qbman_block *b);
void qbman_block_set_nrerr_status(struct qbman_block *b, uint32_t status);
uint32_t qbman_block_get_nrerr_status(struct qbman_block *b);
void qbman_block_set_nrerr_enable(struct qbman_block *b, uint32_t enable);
uint32_t qbman_block_get_nrerr_enable(struct qbman_block *b);


/* Configure/Query the WQ channel data availability notification */
void qbman_block_set_wq_ch_cdan(struct qbman_block *b,
				uint16_t chid,
                                unsigned int bdi,
                                uint16_t wqid,
                                uint16_t vchid);
void qbman_block_get_wq_ch_cdan(struct qbman_block *b,
                                uint16_t chid,
                                unsigned int *bdi,
                                uint16_t *wqid,
                                uint16_t *vchid);
/* Enable the generation of CDAN from this channel */
void qbman_block_enable_wq_ch_cdan(struct qbman_block *b,
                                   uint16_t chid, int enable);


#define QMAN_REV_4000   0x04000000
#define QMAN_REV_4100   0x04010000
#define QMAN_REV_4101   0x04010001
#define QMAN_REV_5000   0x05000000

void qbman_block_get_qman_version(struct qbman_block *b);
uint16_t qbman_block_get_max_pres(struct qbman_block *b);
uint32_t qbman_block_get_version(void);
uint64_t qbman_block_get_cp_mem_paddr(void);

/* Set/get the QMan DD configuration register.
 * @b: qbman block
 * @l_mode: lossy mode, 0 = lossless mode, 1 = lossy mode.
 * @full: 0 = FIFO is not full, 1 = FIFO is full.
 * @m_mode: Marking mode, 0 = overwrite mode, 1 = bitwise OR mode
 * @m_dd_code: Marking dd code.
 * @m_cfg: Marking config.
 */
void qbman_block_set_qman_dd_cfg(struct qbman_block *b,
				 int m_mode, uint8_t m_dd_code,
				 uint16_t m_cfg);
void qbman_block_get_qman_dd_cfg(struct qbman_block *b,
				 int *l_mode, int *full,
				 int *m_mode, uint8_t *m_dd_code,
				 uint16_t *m_cfg);

/* Set/get QMan SWP_DD_CFG */
/* Set/get enqueue marking.
 * @idx: Software portal index
 * @em: 1 = enable enqueue marking, 0 = disable enqueue marking.
 * @emdd: enqueue marking dd code.
 * @emm: enqueue masking mode, available for qman_4.1 and above.
 */
void qbman_block_set_swp_dd_em(struct qbman_block *b,
			       int idx, int em, uint8_t emdd, int emm);
void qbman_block_get_swp_dd_em(struct qbman_block *b,
			       int idx, int *em, uint8_t *emdd, int *emm);
/* Set/get Trace point configuration.
 * @idx: SWP index.
 * @tp_idx: trace point index, 0 = tp0, 1 = tp1
 * @tp_cmpv: The dd code point in the FD monitored by this trace point, was
 * referred as dd_code on qman_4.0.
 * @tp_mask: trace point mask, only available on qman_4.1 and above.
 * @tp_config_flag: The flag used for configuring this trace point.
 * @tp_type: 0 = TP is triggered by enqueue of a marked frame.
 *         1 = TP is triggered by deffered enqueue of a marked frame completes.
 */
void qbman_block_set_swp_dd_tp(struct qbman_block *b, int idx,
			       int tp_idx, uint8_t tp_cmpv, uint8_t tp_mask,
			       uint32_t tp_config_flag, int tp_type);
void qbman_block_get_swp_dd_tp(struct qbman_block *b, int idx,
			       int tp_idx, uint8_t *tp_cmpv, uint8_t *tp_mask,
			       uint8_t *tp_cfg, int *tp_type);

int qbman_block_is_swp_internal_ihr_asserted(struct qbman_block *b, int idx);
int qbman_block_swp_ihr_is_asserted(struct qbman_block *b, int idx);
void qbman_block_swp_ihr_clear(struct qbman_block *b, int idx);
void qbman_block_swp_ihrf_set(struct qbman_block *b, int idx);
int qbman_block_swp_is_in_halted_state(struct qbman_block *b, int idx);

/* Set/get QMan DCP_DD_CFG
 * @idx: the DCP portal index
 * @tp_idx: trace point index, 0 = tp0, 1 = tp1
 * @tp_cmpv: The dd code point in the FD monitored by this trace point, was
 * referred as dd_code on qman_4.0.
 * @tp_mask: trace point mast value
 * @tp_config_flag: The flag used for configuring this trace point.
 */
void qbman_block_set_dcp_dd_tp(struct qbman_block *b,
			       uint16_t idx, int tp_idx, uint8_t tp_cmpv,
			       uint8_t tp_mask, uint32_t tp_config_flag);
void qbman_block_get_dcp_dd_tp(struct qbman_block *b,
			       uint16_t idx, int tp_idx, uint8_t *tp_cmpv,
			       uint8_t *tp_mask, uint8_t *tp_cfg);

int qbman_block_dcp_ihr_is_asserted(struct qbman_block *b, int idx);
void qbman_block_dcp_ihr_clear(struct qbman_block *b, int idx);
void qbman_block_dcp_ihrf_set(struct qbman_block *b, int idx);
int qbman_block_dcp_is_in_halted_state(struct qbman_block *b, int idx);

/* Set/get QMan WQ_CH_DD_CFG
 * @chid: WQ channel index, should be 0, 4, 8 etc. for channels with 8 WQs.
 * @tp_idx: trace point index, 0 = tp0, 1 = tp1
 * @tp_cmpv: The dd code point in the FD monitored by this trace point, was
 * referred as dd_code on qman_4.0.
 * @tp_mask: trace point mast value
 * @tp_config_flag: The flag used for configuring this trace point.
 */
void qbman_block_set_wq_ch_dd_tp(struct qbman_block *b,
				 uint16_t chid, int tp_idx, uint8_t tp_cmpv,
				 uint8_t tp_mask, uint32_t tp_config_flag);
void qbman_block_get_wq_ch_dd_tp(struct qbman_block *b,
				 uint16_t chid, int tp_idx, uint8_t *tp_cmpv,
				 uint8_t *tp_mask, uint8_t *tp_cfg);

/* Set/get QMAN_CEETM_DD_CFG
 * @idx: the DCP portal ID.
 * @iid: the CEETM instance ID
 * @dcp_idx:the DCT index
 * @tp_idx: The Trace point index, 0 or 1.
 * @tp_cpmv: Trace point compare value, indicate the dd code point in the FD of
 * dequeued frames.
 * @tp_mask: trace point mast value
 * @tp_config_flag: The flag used for configuring this trace point.
 */
int qbman_block_set_ceetm_dd_cfg(struct qbman_block *b,
				 unsigned int idx, unsigned int iid,
				 uint16_t dct_idx, int tp_idx,
				 uint8_t tp_cmpv, uint8_t tp_mask,
				 uint32_t tp_config_flag);
int qbman_block_get_ceetm_dd_cfg(struct qbman_block *b,
				 unsigned int idx, unsigned int iid,
				 uint16_t dct_idx,
				 int tp_idx, uint8_t *tp_cmpv,
				 uint8_t *tp_mask, uint8_t *tp_cfg);
void qbman_block_set_disable_interrupts(struct qbman_block *b,
				 int disable_interrupts);
int qbman_block_get_disable_interrupts(struct qbman_block *b);

#endif /* !_FSL_QBMAN_CTRL_H */
