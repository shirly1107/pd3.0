/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_AIOP_H
#define __FSL_AIOP_H

#include "fsl_types.h"
#include "fsl_dpmng_mc.h"

struct aiop_tile_desc {
	int disable;
	int tile_id;
	phys_addr_t paddr;
	void *vaddr_dcsr;
	void *vaddr;
	phys_addr_t psram_paddr;
	uint32_t num_ep;
	uint32_t num_sp;
	uint8_t num_clusters;

	phys_addr_t iram_paddr;
	void *iram_vaddr;
	uint32_t iram_offset;
	uint32_t iram_size;

	phys_addr_t sram_paddr;
	void *sram_vaddr;
	uint32_t sram_size;

	void *peb_vaddr;
	void *dp_ddr_vaddr;

	uint64_t dp_ddr_atu_size;
	uint64_t peb_atu_size;

	int irq_rec_err;
	int irq_cat_err;

	int pta_support;
	int ste_support;

	int wscr_disable;
};

#define AIOP_FDMA_SRU_ALIGN         64
#define AIOP_FDMA_HCL_MASK          0x3ff
#define AIOP_TMAN_CTRL_ALIGN        64
#define AIOP_STE_ALIGN              8
#define AIOP_LU_TABLES_ALIGN		64

struct aiop_tile_desc;
struct aiop_tile;
/**************************************************************************//**
 @Description   AIOP work scheduler enablement mode
 *//***************************************************************************/
enum aiop_ws_en_mode {
	AIOP_WS_DISABLE = 0, /* Disable work scheduler from receiving tasks */
	AIOP_WS_ENABLE_QMAN = 1, /* Enable work scheduler to receive tasks from QMan only */
	AIOP_WS_ENABLE_TMAN = 2, /* Enable work scheduler to receive tasks from TMan only */
	AIOP_WS_ENABLE_ALL = 3
/* Enable work scheduler to receive tasks from both QMan and TMan */
};

/**************************************************************************//**
 @Description   AIOP cache attributes
 *//***************************************************************************/
enum aiop_cache_attr {
	AIOP_CACHE_ATTR_NO_CACHE = 0x0, /* Non-coherent, neither Snoop nor Allocate are set during transactions */
	AIOP_CACHE_ATTR_CACHE = 0x1, /* Coherent, 'snoop' is set during transactions, but 'allocate' is not */
	AIOP_CACHE_ATTR_CACHE_AND_STASH = 0x2
/* Coherent with stashing, 'snoop' and 'allocate' set for all transactions */
};

/**************************************************************************//**
 @Description   AIOP error handling levels
 *//***************************************************************************/
enum aiop_err_level {
	AIOP_ERROR_REPORT = 0, /* Error detected and reported */
	AIOP_ERR_DETECT, /* Error detected only */
	AIOP_ERR_DISABLE,
/* Error is not detected and not reported */
};

/**************************************************************************//**
 @Description   AIOP channel fairness mode
 *//***************************************************************************/
enum aiop_ch_fair_mode {
	AIOP_FAIR_MODE_CORE_WORK = 0, /* The channel bandwidth monitor tracks the amount of core work
	 (measured in task lifetime units) that each channel is
	 receiving relative to other channels; Channel selection among
	 eligible channels is then skewed in favor of channels who are
	 receiving fewer core work units; */
	AIOP_FAIR_MODE_BANDWIDTH
/* The channel bandwidth monitor tracks the amount of processed
 data (measured in bytes) that each channel is receiving relative
 to other channels; Channel selection among eligible channels is
 then skewed in favor of channels who are receiving fewer data bytes; */
};

/**************************************************************************//**
 @Description   AIOP access management qualifier (AMQs)

 The AMQ values are attached by AIOP to all its accesses to
 external resources that are dedicated to the AIOP;
 The AMQs permit SoC components to perform necessary access
 control and/or address translations;
 *//***************************************************************************/
struct aiop_amq {
	int bmt; /* Bypass memory translation; This is a request to bypass
	 the memory translation performed by the I/O MMU */
	int pl; /* Privilege level; BMT will be qualified by PL - if PL
	 is not set then BMT will be ignored */
	int va; /* Virtual address; VA is set if the associated address is
	 virtual, cleared if it is physical. For the purposes of
	 determining physical versus virtual addresses BMT
	 overrides VA. If BMT is set than the address is treated
	 as a physical address */
	uint16_t icid; /* Isolation context id */
};

/**************************************************************************//**
 @Description   AIOP
 *//***************************************************************************/
enum aiop_ws_frames_src {
	AIOP_WS_FRAMES_SRC_QMAN, /* Only QMan frames will generate trace events when tracing by frame source is enabled */
	AIOP_WS_FRAMES_SRC_TMAN,
/* Only TMan frames will generate trace events when tracing by frame source is enabled */
};

/**************************************************************************//**
 @Description   AIOP
 *//***************************************************************************/
struct aiop_ws_event_trace {
	int iose; /* Enables trace event generation for received frames matching the provided initial order scope value */
	uint32_t ios; /* Initial order scope value that will generate trace events when these are enabled */

	int se; /* Enables trace event generation for received frames matching the provided frames source */
	enum aiop_ws_frames_src src; /* Frames source that will generate trace events when these are enabled */

	int ee; /* Enables trace event generation for received frames matching the provided EPID value */
	uint16_t epid; /* EPID value that will generate trace events when these are enabled */

	uint16_t dde; /* Dynamic Debug Enable; Each bit of the DDE field enables a trace event when a frame
	 with the corresponding DD value is received; If DDE[5] is set, a trace event is
	 generated for every frame that arrives with FD[DD]=5; */
};

/**************************************************************************//**
 @Description   AIOP Work scheduler default configuration
 *//***************************************************************************/
struct aiop_ws_cfg {
	enum aiop_ch_fair_mode ch_fairness_mode; /* Channel Fairness Mode; Work Scheduler�s channel bandwidth monitor
	 can be used in one of two exclusive fairness modes: core work
	 fairness mode or bandwidth fairness mode; */
	uint16_t high_prio_threshold; /* High priority task reservation threshold; This is the number of tasks
	 that are reserved for use by high priority QMan channels;
	 Once the count of available tasks reaches this value, only high priority
	 QMan channels will be considered for scheduling; */
#ifdef UNDER_CONSTRUCTION
struct aiop_ws_event_trace event_trace; /* Specifies trace collection match sets for debug triggers; */
#endif /* UNDER_CONSTRUCTION */
};

/**************************************************************************//**
 @Description   AIOP FDMA parameters
 *//***************************************************************************/
struct aiop_fdma_cfg {
	uint32_t sru_size; /* Size of the SRUs memory region */
	uint32_t hcl; /* Hop Count Limit value */
	struct aiop_amq amq; /* Memory attributes used for FDMA access to SRU memory */
	uint32_t sru_write_attr; /* Cache aware attributes during SRUs write transactions */
	uint32_t sru_read_attr; /* Cache aware attributes during SRUs read transactions */
	uint32_t data_write_attr; /* Cache aware attributes during frame data (and table) write transactions */
	uint32_t data_read_attr; /* Cache aware attributes during frame data (and table) read transactions */
};

/**************************************************************************//**
 @Description   AIOP CDMA parameters
 *//***************************************************************************/
struct aiop_cdma_cfg {
	struct aiop_amq amq; /* Memory attributes used on access to context memory */
	int bdi; /* Bypass DPAA resource isolation
	 0 - Isolation is enabled for BMan acquire and release;
	 The pool ID specified is virtual within the specified ICID;
	 1 - Isolation is not enabled for BMan acquire and release;
	 The pool ID specified is a real (not virtual) pool ID */
	uint32_t context_write_attr; /* Cache aware attributes during context memory write transactions */
	uint32_t context_read_attr; /* Cache aware attributes during context memory read transactions */
};

/**************************************************************************//**
 @Description   AIOP Ordering scope errors management
 *//***************************************************************************/
struct aiop_osm_err_mng {
	enum aiop_err_level mult_err; /* Multiple errors of the same type */
	enum aiop_err_level relinquish_concurrent; /* An attempt was made to relinquish a task in concurrent mode; */
	enum aiop_err_level exit_no_scope; /* An explicit call to exit or exit-all when no scope is present; */
	enum aiop_err_level enter_scope_exhausted; /* An attempt to enter a new scope when the maximum depth of nesting reached */
	enum aiop_err_level no_scope_transition; /* An explicit call to transition from the current scope when no scope is present */
	enum aiop_err_level duplicate_scope; /* An attempt to reuse a scope identifier, which is already in use by the task,
	 when transitioning or entering scope */
};

/**************************************************************************//**
 @Description   AIOP
 *//***************************************************************************/
struct aiop_osm_cfg {
	struct aiop_osm_err_mng err_mng;
};

/**************************************************************************//**
 @Description   AIOP
 *//***************************************************************************/
struct aiop_tmi_cfg {
	uint8_t mem_partition_id; /* Memory partition ID for allocation of TMI TCRs  */
	struct aiop_amq amq; /* Memory attributes used for this TMI */
	uint32_t max_num_of_timers; /* Maximal number of timers in this TMI */
};

/**************************************************************************//**
 @Description   AIOP
 *//***************************************************************************/
struct aiop_tman_cfg {
	uint32_t freq; /* Prescale value : integer part of the input clock
	frequency expressed in MHz */
	uint32_t freq_frac; /* Prescale fraction value : fractional part of
	the input clock frequency expressed in MHz */
	struct aiop_amq amq; /* Memory attributes used for TMan transactions */
	int bdi; /* Bypass DPAA resource isolation;
	 Should be asserted to invalidate TMI create BDI value;
	 0: isolation enabled, 1: isolation disabled */
};

/**************************************************************************//**
 @Description   AIOP ATU window parameters
 *//***************************************************************************/
struct aiop_atu_win_cfg {
	uint8_t num; /* ATU window number; Higher numbered windows take precedence over lower numbered windows */
	uint64_t size; /* ATU window size; Supported values are all power-of-2s from 64KB to 2GB */
	uint64_t base_addr; /* Window base address; Must be aligned to window size */
	uint64_t trans_addr; /* 64-bit SoC address leaving the AIOP tile on match to the window; Must be aligned to window size */
	int instr_access; /* TRUE if received transaction must be an instruction access to detect a �hit� */
	int data_access; /* TRUE if received transaction must be a data access to detect a �hit� */
	struct aiop_amq amq; /* Memory attributes for AIOP cores transactions that match this window */
};

/**************************************************************************//**
 @Description   AIOP Statistics engine parameters
 *//***************************************************************************/
struct aiop_ste_cfg {
	struct aiop_amq amq; /* Memory attributes used for STE transactions */
	uint32_t data_write_attr; /* Cache attributes during data write transactions */
	uint32_t data_read_attr; /* Cache attributes during data read transactions */
};

/**************************************************************************//**
 @Description   AIOP tile default configuration
 *//***************************************************************************/
struct aiop_tile_defcfg {
	struct aiop_osm_cfg osm_cfg; /* Ordering scope manager default configuration */
	struct aiop_ws_cfg ws_cfg; /* Work scheduler default configuration */
};


/**************************************************************************//**
 @Description   AIOP work scheduler channel scheduling-related initialization
 parameters
 *//***************************************************************************/
struct aiop_ws_ch_sched_cfg {
	uint8_t priority; /* Channel scheduling priority of 0-8, where 0 is highest possible priority */
	uint8_t cmask; /* Cluster mask; A 1 in a CMASK bit position will prevent the associated cluster
	 from processing this channel�s frames; Bit 0 (LSB) corresponds to core cluster 0, etc; */
	uint8_t weight; /* Scheduling weight  of a channel for weighted bandwidth fair share scheduling */
#ifdef UNDER_CONSTRUCTION
uint8_t task_count_limit; /* Task Count Limit (number of tasks that may be active from this channel at any given time);
 The supported values are multiples of 4, from 1 upto 128 tasks; Setting this field to 0
 means no limit on active tasks; */
uint8_t dq_limit; /* Channel DQ Limit, specified a limit on how many outstanding dequeue commands the Work
 Scheduler may have outstanding for this channel;
 The supported values are 1, 4, 8 or no limit */
#endif /* UNDER_CONSTRUCTION */
};

#ifdef UNDER_CONSTRUCTION
/**************************************************************************//**
 @Description   AIOP work scheduler channel flow control parameters
 *//***************************************************************************/
struct aiop_ws_ch_flow_cfg {
	uint16_t icid; /* ICID of the channel; Used for mapping of received Congestion State Change Notification,
	 Buffer Pool State Change Notification and TMan expiry indications */
	int bdi; /* Bypass Datapath Isolation; When isolation is enabled for this QMan channel the table
	 is searched when a matching ICID with BDI=0 CSCN/BPSCN arrives; FQIDs that are flow
	 controlled are considered a virtual resources;
	 When isolation is not enabled for this QMan channel, the table is searched when a
	 matching ICID with BDI=1 CSCN/BPSCN arrives; FQIDs that are flow controlled are
	 considered a non-virtual resources; */
	int hw_mapping_en; /* When set, Work Scheduler will perform a flow control XON/XOFF action upon receipt
	 and successful match of either a congestion or depletion indication message; */
	int create_task; /* Work Scheduler will create a software task via the provided EPID when any of the
	 classes configured for this channel match a received congestion or depletion indication */
	int msg_select; /* When set, FQID XON/XOFF messages issued; Otherwise Traffic Class XON/XOFF messages issued; */

	uint16_t epid; /* When create_task is set, this EPID value will be used to create a software task upon
	 successful match of a congestion or depletion indication */
	uint16_t cg_id; /* Congestion Group ID; Arriving CSCNs whose CGID value, bit-wise ANDed with the value in
	 provided mask, matches the value programmed in this field will result in an XON/XOFF
	 command being sent to QMan for either traffic class 0-7 or the programmed FQID value */
	uint16_t cg_mask; /* This mask is bit-wise ANDed with received CGIDs prior to comparison with the provided
	 CGID; Setting any bits in the CGID field that have a corresponding 0 in this field
	 will disable congestion group flow control mapping for this traffic class */
	uint16_t bp_id; /* Arriving BPSCNs whose BPID value, bit-wise ANDed with the value in provided mask,
	 matches the value programmed in this field will result in an XON/XOFF command being
	 sent to QMan for either traffic class 0 or the FQID value programmed */
	uint16_t bp_mask; /* This mask is bit-wise ANDed with received BPIDs prior to comparison with the
	 provided BPID; Setting any bits in the BPID field that have a corresponding 0 in this
	 field will disable buffer pool flow control mapping for this traffic class; */
};
#endif /* UNDER_CONSTRUCTION */

/**************************************************************************//**
 @Description   Storage Profile Frame Formats
 *//***************************************************************************/
enum sp_frame_format {
	SP_FF_SINGLE_BUF_OR_SG = 0, /* Single buffer or an SG buffer with as many data
	 buffer(s) as needed to hold the frame data */
	SP_FF_SINGLE_BUF_CHAIN, /* Single buffer chain with 1 or more elements
	 holding data within the data region of an SG */
	SP_FF_SINGLE_BUF_ONLY, /* Force single buffer use (generate error if
	 (anticipated) output data does not fit in single
	 buffer) */
	SP_FF_SG_ONLY
/* Force use of SG list format; This may produce
 a 1 entry SG table plus a single buffer */
};


/**************************************************************************//**
 @Description   AIOP storage profile parameters
 *//***************************************************************************/
struct aiop_sp_cfg {
	int bdi; /* Bypass datapath isolation */
	int pl; /* Privilege level */
	uint16_t icid; /* Storage profile ICID */

	uint16_t data_length;
	/* An estimate for an absolute output data length (data_lenght_ctrl=1)
	 or a length correction / adjustment of the output frame length based
	 on input frame length information (data_lenght_ctrl=0) */
	int buff_src;
	/* 0 for allocate output buffers, 1 for reusing input buffers as
	 output buffers */
	enum sp_frame_format frame_format;
	/* Frame format, applies if 'buff_src'=0 */
	int virt_addr;
	/* Virtual address attribute */
	int data_lenght_ctrl;
	/* 0 if 'data_length' is used to calculate the anticipated output
	 frame buffer requirements using an input frame length as a basis
	 and modifying the base with a positive or negative correction
	 defined by 'data_length'.
	 1 if 'data_length' is an absolute output buffer length. */
	uint16_t pass_thru_ann_room;
	/* Size in bytes of anticipated pass through annotation in the front
	 of the frame. Set to 0 if no annotation room is required. */
	int sg_head_room;
	/* Indication to optionally generate additional 64 bytes for
	 anticipated SG table growth in the front of the frame */
	uint16_t accel_specific_ann_room;
	/* Size in bytes of generated HW annotation space in the output frame
	 (preserve in the reuse mode). Must be a multiple of 64 bytes. */
	uint16_t data_head_room;
	/* Encoded in bytes.
	 If 'buff_src'=0, used to generate data headroom.
	 If 'buff_src'=1, this field is treated as a signed value of a
	 data headroom correction and defines by how many bytes an
	 existing offset should be adjusted to make room for additional
	 output data or any need to move the output �forward� in relation
	 to the input data so that output generation does not destroy
	 input data before it is consumed */
	uint8_t	num_pools;
	struct bp_cfg {
		int bmt; /* Bypass memory translation */
		uint16_t bpid; /* Buffer pool ID */
		uint16_t bp_size; /* Buffer pool size */
		int scarce_resource; /* Scarce resource attribute */
		int backup_pool; /* WRIOP and AIOP-specific attribute to indicate
		 regular versus preferred buffer pools */
	} bp_cfg[2];
};

/**************************************************************************//**
 @Description   AIOP EP (Entry point) table entry parameters
 *//***************************************************************************/
struct aiop_ep_entry_cfg {
	uint32_t pc; /* Initial program counter value */
	uint32_t parameter; /* Opaque parameter value */
};


/* high level aiop tile routines */
int aiop_tile_early_init(struct aiop_tile_desc *aiop_tile_desc);
void aiop_tile_restore_sp_table(struct aiop_tile *aiop_tile);
void aiop_tile_restore_ep_table(struct aiop_tile *aiop_tile);
int aiop_tile_set_storage_profile(struct aiop_tile *aiop_tile,
                             uint32_t entry_id,
                             struct aiop_sp_cfg *cfg);
int aiop_tile_ws_set_ep_entry(struct aiop_tile *aiop_tile,
                         uint32_t epid,
                         struct aiop_ep_entry_cfg *cfg);
void aiop_tile_set_isr_params(struct aiop_tile *aiop_tile, 
	int (*isr_cb)(void *arg, uint8_t irq_id, uint32_t event), 
	void *arg, 
	uint8_t irq_id);


/* low level aiop routines */

void aiop_tile_init(struct aiop_tile_desc *aiop_tile_desc, uint8_t tasks_per_core);

void aiop_tile_ws_init(struct aiop_tile_desc *aiop_tile_desc, const struct aiop_ws_cfg *cfg);

void aiop_tile_fdma_init(struct aiop_tile_desc *aiop_tile_desc, phys_addr_t sru_base,
                    const struct aiop_fdma_cfg *cfg);

void aiop_tile_cdma_init(struct aiop_tile_desc *aiop_tile_desc,
                    const struct aiop_cdma_cfg *cfg);

void aiop_tile_osm_init(struct aiop_tile_desc *aiop_tile_desc,
                   const struct aiop_osm_cfg *cfg);

int aiop_tile_tman_init(struct aiop_tile_desc *aiop_tile_desc,
			phys_addr_t tman_ctrl_mem,
                    const struct aiop_tman_cfg *cfg);

void aiop_tile_tman_get_timestamp(struct aiop_tile_desc *aiop_tile_desc,
                                 uint64_t *timestamp);

void aiop_tile_tman_stop(struct aiop_tile_desc *aiop_tile_desc);

void aiop_tile_tman_is_busy(struct aiop_tile_desc *aiop_tile_desc, uint32_t *is_busy);

void aiop_tile_ste_init(struct aiop_tile_desc *aiop_tile_desc,
                   const struct aiop_ste_cfg *cfg);

void aiop_tile_ste_reset(struct aiop_tile_desc *aiop_tile_desc,
                const struct aiop_ste_cfg *cfg);

uint32_t aiop_tile_get_rbase(struct aiop_tile_desc *aiop_tile_desc);

void aiop_tile_set_rbase(struct aiop_tile_desc *aiop_tile_desc, uint32_t rbase);

void aiop_tile_reset(struct aiop_tile_desc *aiop_tile_desc);

void aiop_tile_halt(struct aiop_tile_desc *aiop_tile_desc);

void aiop_tile_release_cores_boot(struct aiop_tile_desc *aiop_tile_desc, uint64_t cores_mask);

uint32_t aiop_tile_get_cores_boot_status(struct aiop_tile_desc *aiop_tile_desc);

uint32_t aiop_tile_get_core_gpr(struct aiop_tile_desc *aiop_tile_desc, int i);

void aiop_tile_set_mng_gpr(struct aiop_tile_desc *aiop_tile_desc, uint8_t reg_num, uint32_t value);

uint32_t aiop_tile_get_mng_gpr(struct aiop_tile_desc *aiop_tile_desc, uint8_t reg_num);

//void aiop_clear_cores_boot_complete(struct aiop_tile_desc *aiop_tile_desc, uint32_t cores_mask);


void aiop_tile_write_rbase(struct aiop_tile_desc *aiop_tile_desc, uint32_t core_out_of_reset_addr);

/**************************************************************************//**
 @Function      aiop_ws_set_ch_sched_cfg

 @Description   This routine sets scheduling-related parameters of an AIOP work
 scheduler channel

 @Param[in]     aiop_regs - AIOP tile registers base address
 @Param[in]     ch_id - Id of the channel to be modified
 @Param[in]     sched_cfg - Scheduling-related parameters of the channel

 @Return    '0' on Success; error code otherwise

 @Cautions  None
 *//***************************************************************************/
int aiop_tile_ws_set_ch_sched_cfg(struct aiop_tile_desc *aiop_tile_desc,
                             uint8_t ch_id,
                             struct aiop_ws_ch_sched_cfg *sched_cfg);
#ifdef UNDER_CONSTRUCTION
int aiop_tile_ws_set_ch_flow_ctrl_cfg(struct aiop_tile_desc *aiop_tile_desc,
	uint8_t ch_id,
	struct aiop_ws_ch_flow_cfg *flow_cfg);
#endif /* UNDER_CONSTRUCTION */

/**************************************************************************//**
 @Function

 @Description

 @Param[out]

 @Return    '0' on Success; error code otherwise

 @Cautions  None
 *//***************************************************************************/
int aiop_tile_ws_enable(struct aiop_tile_desc *aiop_tile_desc, enum aiop_ws_en_mode en_mode);

/**************************************************************************//**
 @Function

 @Description

 @Param[out]

 @Return    '0' on Success; error code otherwise

 @Cautions  None
 *//***************************************************************************/
int aiop_tile_atu_win_enable(struct aiop_tile_desc *aiop_tile_desc,
                        const struct aiop_atu_win_cfg *win_cfg);

/**************************************************************************//**
 @Function

 @Description

 @Param[out]

 @Return    '0' on Success; error code otherwise

 @Cautions  None
 *//***************************************************************************/
int aiop_tile_atu_win_disable(struct aiop_tile_desc *aiop_tile_desc, uint8_t win_num);

int aiop_tile_atu_win_in_use(struct aiop_tile_desc *aiop_tile_desc, uint8_t win_num);

void aiop_tile_disable(struct aiop_tile_desc *aiop_tile_desc);

void aiop_tile_enable(struct aiop_tile_desc *aiop_tile_desc);

void aiop_tile_disable_dbg_intr_requests(struct aiop_tile_desc *aiop_tile_desc);

int aiop_tile_get_atu(struct aiop_tile_desc *aiop_tile_desc, int i, void **vbase, phys_addr_t *pbase, uint64_t *size);

void aiop_ws_get_pending_tasks(struct aiop_tile_desc *aiop_tile_desc, uint32_t *pending);

void aiop_ws_get_cores_idle(struct aiop_tile_desc *aiop_tile_desc, uint32_t *idle_bits);

void aiop_err_isr(uint32_t arg);
void aiop_cat_err_isr(uint32_t arg);


#if 0
/**
 * @brief	AIOP run configuration
 */
struct dpmng_aiop_run_cfg {
	uint32_t cores_mask; /*!< Mask of AIOP cores to run (core 0 in msb)*/
	uint64_t options; /*!< Execution options (currently none defined) */
};


/*int aiop_tile_load_img(struct aiop_tile_desc *aiop_tile_desc,
	int container_id, uint8_t *img_addr);
int aiop_tile_reset(struct aiop_tile_desc *aiop_tile_desc, int container_id);
int aiop_tile_run(struct aiop_tile_desc *aiop_tile_desc, int container_id, uint32_t cores_mask);
*/
#endif
#endif /* __FSL_AIOP_H */

