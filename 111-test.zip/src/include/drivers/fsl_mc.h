/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_MC_H
#define __FSL_MC_H

struct mc_desc {
	void *vaddr;
	phys_addr_t ccsr_paddr;
	uint32_t ccsr_size;
	void *soc_ccsr;
	void *soc_dcsr;
	void *soc_int_addr_map;
	int num_cores;
};

struct mc_bt_desc {
	int core_id;
	phys_addr_t paddr;
	void *vaddr;

};

struct mc_portal_desc {
    int portal_id;
    phys_addr_t paddr;
    void *vaddr;
};

struct soc_mc_portal_desc {
    int portal_id;
    phys_addr_t paddr;
    void *vaddr;
};

struct cpm_desc {
	int core_id;
	phys_addr_t paddr;
	void *vaddr;
	uint32_t irq_hp;
	uint32_t irq_lp;
};

struct pic_desc {
    phys_addr_t paddr;
    void *vaddr;
};

struct mem_desc {
	int disable;
	phys_addr_t regs_paddr;
	void *regs_vaddr;
	phys_addr_t paddr;
	uint64_t size;
	int irq_rec_err;
};

struct memc_desc {
	int disable;
	phys_addr_t paddr;
	void *vaddr;
	int irq;
	int irq_rec_err;
};

struct serdes_desc {
        int id;
        uint32_t mac_mask;
        uint8_t rcwsr_id;
        uint32_t rcwsr_mask;
        uint8_t num_lanes;
        uint8_t master_lane_select[8];
        void *vaddr;
};

struct dmem_desc {
	int core_id;
	phys_addr_t global_paddr;
	phys_addr_t local_paddr;
	int block_size;
};

#endif /*__FSL_MC_H */

