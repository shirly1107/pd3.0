/*
 * Copyright 2013 Freescale Semiconductor, Inc.
 * Copyright 2014-2020 NXP
 */

/**************************************************************************//**
 @File          fsl_mcpic.h

 @Description   MC PIC external structures and definitions.
*//***************************************************************************/

#ifndef __FSL_MCPIC_H
#define __FSL_MCPIC_H

#include "fsl_types.h"


/**************************************************************************//**
 @Group         mcpic_g MCPIC Application Programming Interface

 @Description   MCPIC functions, definitions and enums.

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Group         mcpic_init_g MCPIC Initialization Unit

 @Description   MCPIC initialization functions.

 @{
*//***************************************************************************/

/**************************************************************************//**
 @Function      mcpic_init

 @Description   Fully initializes MCPIC and enables it.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int mcpic_init(void *regs);

/**************************************************************************//**
 @Function      mcpic_free

 @Description   Frees all resources used by MCPIC.

 @Param[in]     mcpic - MCPIC descriptor returned by duart_config().

 @Return        None.

 @Cautions      Does not disable MCPIC.
*//***************************************************************************/
void mcpic_free(void *regs);

/** @} */ /* end of mcpic_init_g group */
/** @} */ /* end of mcpic_g Programming Interface group */


#endif /* __FSL_MCPIC_H */
