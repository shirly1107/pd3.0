/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_SERDES_H
#define __FSL_SERDES_H

#include "fsl_enet.h"
#include "drivers/fsl_mc.h"

#define NUM_OF_SERDES_LANES 8

struct dcfg_desc;

struct serdes_mac_info {
	int valid;
	int mac_id;
	int eiop_id;
	enum enet_interface enet_if;
	uint32_t converted;
	enum enet_interface enet_prev;
	uint32_t rate;
	uint8_t lanes;
	uint8_t autoneg;
	uint8_t debug_link_check;
};

/* 10GBase-KR related structures */
struct serdes_kr_cfg {
	uint32_t ratio_preq;
	uint32_t ratio_pst1q;
	uint32_t adpt_eq;
	int lane;
};

enum serdes_10gbase_kr_bins {
	SERDES_10GBASE_KR_BIN_M1,
	SERDES_10GBASE_KR_BIN_LONG
};

/* serdes sfi/custom settings feature internals */
enum serdes_eq_cfg_mode {
	SERDES_CFG_DEFAULT = 0,
	SERDES_CFG_SFI,
	SERDES_CFG_CUSTOM,
};

struct serdes_eq_settings {
	enum serdes_eq_cfg_mode cfg;
	int eq_type;
	int sgn_preq;
	int eq_preq;
	int sgn_post1q;
	int eq_post1q;
	int eq_amp_red;
};

enum serdes_fault_type {
	SERDES_REMOTE_FAULT = 0,
	SERDES_LOCAL_FAULT,
};

enum dpmac_fec_mode {
	DPMAC_FEC_NONE,
	DPMAC_FEC_RS,
	DPMAC_FEC_FC,
};

enum serdes_enet_if_convert {
	SERDES_IF_CONVERT_NONE = 0,
	SERDES_IF_CONVERT_SUCCESS = 1,
	SERDES_IF_CONVERT_FAILURE = 2,
	SERDES_IF_CONVERT_NOT_SUPPORTED = 3,
};

#define SERDES_CFG_KEEP_EXISTING (-1)

/* helper macro to update group of bits in a SerDes register
 * requires MASK and OFFSET defines in a specific format:
 *		SERDES_10G_TECR0_EQ_POST1Q_MASK
 *		SERDES_28G_TECR0_EQ_POST1Q_OFFSET
 *		    |               |
 *		 register       bit group
 *		  prefix          name
 * Inputs:
 * 		serdes_reg: serdes type followed by register name (e.g. SERDES_10G_TECR0)
 * 		src:        value to be copied over destination
 * 		dest:       value to be updated with src content
 * 		name:		field name
 * Example:
 * 		SERDES_SET_CFG(serdes_type,      to_be_set_val, accumulator, register_name)
 *		SERDES_SET_CFG(SERDES_10G_TECR0, 0x3F,          tecr0_val,   EQ_POST1Q)
 */
#define SERDES_SET_CFG(serdes_reg, src, dest, name) \
	do { \
			if (src != SERDES_CFG_KEEP_EXISTING) { \
				dest &= ~serdes_reg##_##name##_MASK; \
				dest |= (src << serdes_reg##_##name##_OFFSET) & \
								serdes_reg##_##name##_MASK; \
			} \
	} while(0)

#define SERDES_GET_CFG(serdes_reg, src, dest, name) \
	do { \
			dest = 0; \
			dest |= ((src & serdes_reg##_##name##_MASK) >> \
					serdes_reg##_##name##_OFFSET);\
	} while(0)

void serdes_get_mac_info(struct serdes_desc *desc,
                         struct serdes_mac_info *mac_info,
                         int *lane,
                         uint8_t sd_proto);

int serdes_convert_enet_if(struct serdes_desc *desc,
						   struct serdes_mac_info *mac_info,
						   uint8_t sd_proto,
						   uint32_t pssr0_enet_if);

void serdes_set_loopback(struct serdes_desc *desc);

int serdes_get_mac_string(struct dcfg_desc *dcfg_desc,
		struct serdes_desc *desc,
		int *lane,
		char *buf,
		uint8_t sd_proto);

int serdes_mac_to_lane(struct serdes_desc *desc, int mac_id, uint8_t sd_proto, uint8_t *lane);

void serdes_disable_lane(enum enet_interface enet_if,
			 struct serdes_desc *desc,
			 int mac_id,
			 uint8_t master_lane);

void serdes_enable_lane(struct serdes_desc *desc,
			int mac_id,
			uint8_t master_lane,
			uint8_t no_lanes,
			enum enet_interface enet_if);

void serdes_reset_lane(struct serdes_desc *desc, int lane);

void serdes_enable_1000base_kx_an(struct serdes_desc *desc, int lane, int dpmac_id);

void serdes_init_1000base_kx(struct serdes_desc *desc, int lane, int dpmac_id);

void serdes_set_tx_equalization_values(struct serdes_desc *desc,
                                       struct serdes_kr_cfg kr_cfg);

int serdes_check_bin_status(struct serdes_desc *desc,
                            enum serdes_10gbase_kr_bins bin_sel, int lane);

void convert_xfi2usxgmiia(struct serdes_desc *desc, int dpmac_id);

void serdes_wa_gain_tecr();

void serdes_set_fault(struct serdes_desc *desc, int dpmac_id, enum serdes_fault_type, uint8_t en);
void serdes_setup_fec_dispatch(struct serdes_desc *desc, int dpmac_id, enum dpmac_fec_mode fec_mode);

#ifdef TKT320141
void serdes_wa_cdr_lock();
int serdes_reset_receiver_lane(struct serdes_desc *,
								int,
								uint8_t,
								uint8_t,
								enum enet_interface);
void serdes_reset_protocol(struct serdes_desc *, int, uint8_t, uint8_t, enum enet_interface);
int get_cdr_lock(struct serdes_desc *, uint8_t);
#endif
void serdes_enable_rs_fec();
int is_serdes_sfi_capable(struct serdes_eq_settings *sfi_settings);
int get_serdes_eq_setup(struct serdes_desc *desc, int dpmac_id, struct serdes_eq_settings *attr);
int serdes_eq_setup(struct serdes_desc *, int, struct serdes_eq_settings *);
unsigned char *serdes_get_enet_if_str(uint32_t enet_if);
uint32_t serdes_enet_to_pssr0(enum enet_interface);
#ifdef ERR050369
void serdes_apply_caui_err050369(struct serdes_desc *desc, int dpmac_id);
#endif
#endif /* __FSL_SERDES_H */
