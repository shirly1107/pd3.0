/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_core_booke_regs.h"
#include "fsl_core_booke.h"
#include "mpu.h"
#include "fsl_mpu.h"
#include "fsl_dbg.h"
#include "fsl_soc_arch.h"

/* MAS0 defines */
#define MPU_MAS0_VALID      0x80000000
#define MPU_MAS0_SEL        0x20000000 /* Select MPU */
#define MPU_MAS0_INST       0x01000000
#define MPU_MAS0_SHD        0x00800000 /* Shared Entry Select */
#define MPU_MAS0_ESEL_MASK  0x000f0000 /* Entry select for MPU */
#define MPU_MAS0_I          0x00000008 /* 1 - This region is considered cache-inhibited */
#define MPU_MAS0_IOVR       0x00000080 /* Cache-Inhibit attribute Override */
#define MPU_MAS0_G          0x00000002 /* Guarded region attribute (not present in dedicated INST entries) */
#define MPU_MAS0_GOVR       0x00000040 /* G attribute Override */
#define MPU_MAS0_UW         0x00000800 /* User Mode Write Permission */
#define MPU_MAS0_SW         0x00000400 /* Supervisor Mode Write / Read Permission */
#define MPU_MAS0_UX_UR      0x00000200 /* User Mode Execute / Read Per mission */
#define MPU_MAS0_SX_SR      0x00000100 /* Supervisor Mode Execute / Read Per mission */

#define MPU_MAS0_READ_ONLY_BITS ((MPU_MAS0_UW) | (MPU_MAS0_SW))


/* MAS1 defines */
#define MPU_MAS1_TID        0x00ff0000 /* should be 0 */
#define MPU_MAS1_TIDMSK     0x000000ff /* should be 0 */

#define MPU_MPU0CSR0_MPUEN  0x00000001 /* MPU Enable bit */
#define MPU_MPU0CSR0_DWDEN  0x00000040 /* Data Write Debug Enable */
#define MPU_MPU0CSR0_DRDEN  0x00000080 /* Data Read Debug Enable */

#define MPU_MPU0CSR0_BYPSW  0x00004000 /* Bypass MPU protections for Supervisor Write accesses */
#define MPU_MPU0CSR0_BYPUW  0x00000800 /* Bypass MPU protections for User Write accesses */
#define MPU_MPU0CSR0_BYPASS_ALL 0x0000fc00

#define NUM_OF_DATA_REGIONS    (12)
#define NUM_OF_INST_REGIONS    (6)
#define NUM_OF_SHARED_REGIONS  (6)

#define MPU_DATA_TABLE       0x00010000
#define MPU_INST_TABLE       0x00020000
#define MPU_SHARED_TABLE     0x00040000
#define MPU_HANDLE_ID_MASK   0x0000ffff
#define MPU_HANDLE_TYPE_MASK 0xffff0000
#define MPU_CREATE_HANDLE(__table_, __id_) (((__table_) & (MPU_HANDLE_TYPE_MASK)) | ((__id_) & (MPU_HANDLE_ID_MASK)))

#define MPURE asm {mpure}      /* asm { opword 0x7E000764 } */
#define MPUWE asm {mpuwe}      /* asm { opword 0x7E0007A4 } */
#define MPUSYNC asm {mpusync}  /* asm { opword 0x7E00046C } */

enum entry_type_t{
	mpu_data_entry          = 0,
	mpu_instruction_entry   = 1,
	mpu_shared_entry        = 2,
	mpu_invalid_entry       = 3 /* invalid entry */
};

struct region_attr_t{
	uint32_t upper_bound;    /* Upper address bound (compared against effective address) */
	uint32_t lower_bound;    /* Lower address bound (compared against effective address) */
	int instruction;         /* Instruction or Data Access entry (1=INST) */
	int cacheable;           /* Catchable region attribute */
	int override_cacheable;  /* Catchable region attribute override, 1 -> override */
	int guarded;             /* Guarded region attribute */
	int read_only;			 /* Read-only control for entry updates (write permissions) */
};

struct mpu_entry_t{
	int entry_id;
	int valid;              /* Valid bit for entry */
	enum entry_type_t type; /* entry type (data / instruction / shared) */
	struct region_attr_t *attr;
};

static void* log_buffer_handle[INTG_MAX_NUM_OF_CORES];

/*****************************************************************************/
static uint32_t mpu_get_spr_MPU0CSR0(void)
{
	register uint32_t val;
	asm {
		mfspr val, MPU0CSR0
	}
	return val;
}

/*****************************************************************************/
static void mpu_set_spr_MPU0CSR0(register uint32_t mpu0csr0)
{
	asm {
		mtspr MPU0CSR0, mpu0csr0 /* MPU0CSR0 = 1014 */
	}
}

/*****************************************************************************/
static uint32_t mpu_get_spr_MPU0CFG(void)
{
	register uint32_t val;
	asm {
		mfspr val, MPU0CFG
	}
	return val;
}

/*****************************************************************************/
void mpu_enable(const struct mpu_flags * const flags)
{
	uint32_t mpu0csr0 = MPU_MPU0CSR0_BYPASS_ALL | MPU_MPU0CSR0_MPUEN;

	ASSERT_COND(flags != NULL);

	if(flags->memory_protection) {
		mpu0csr0 &= ~((MPU_MPU0CSR0_BYPUW) | (MPU_MPU0CSR0_BYPSW));
	}

	mpu_set_spr_MPU0CSR0(mpu0csr0);
	MPUSYNC;
}


/*****************************************************************************/
static inline int get_regions_num(enum entry_type_t type)
{
	ASSERT_COND(type != mpu_invalid_entry);

	switch(type)
	{
	case mpu_data_entry:
		return NUM_OF_DATA_REGIONS;
	case mpu_instruction_entry:
		return NUM_OF_INST_REGIONS;
	case mpu_shared_entry:
		return NUM_OF_SHARED_REGIONS;
	default:
		return 0;
	}
}

static void mpu_mas0_update_type(uint32_t *mas0, const struct mpu_entry_t *entry)
{
	if(entry->type == mpu_data_entry) {
		*mas0 &= ~MPU_MAS0_INST;
	} else if(entry->type == mpu_instruction_entry) {
		*mas0 |= MPU_MAS0_INST;
	} else { /* shared */
		*mas0 |= MPU_MAS0_SHD;
		*mas0 |= entry->attr->instruction ? MPU_MAS0_INST : 0;
	}
}

/*****************************************************************************/
static void mpu_write_entry(const struct mpu_entry_t *entry)
{
	uint32_t mas0;

	ASSERT_COND(entry != NULL);
	ASSERT_COND_LIGHT(entry->attr->lower_bound <= entry->attr->upper_bound);

	mas0 = MPU_MAS0_SEL;
	mas0 |= (entry->entry_id << 16) & MPU_MAS0_ESEL_MASK;
	mas0 |= entry->attr->cacheable ? 0 : MPU_MAS0_I;
	mas0 |= entry->attr->override_cacheable ? MPU_MAS0_IOVR : 0;
	mas0 |= entry->attr->guarded ? MPU_MAS0_G : 0;
	mas0 |= entry->attr->read_only ? 0 : MPU_MAS0_UW | MPU_MAS0_SW;
	mas0 |= entry->valid ? MPU_MAS0_VALID : 0;
	mpu_mas0_update_type(&mas0, entry);

	booke_set_spr_MAS0(mas0);
	booke_set_spr_MAS1(0);
	booke_set_spr_MAS2(entry->attr->upper_bound);
	booke_set_spr_MAS3(entry->attr->lower_bound);

	core_instruction_sync();
	MPUWE
	core_instruction_sync();
}

/*****************************************************************************/
static void mpu_read_entry(struct mpu_entry_t *entry)
{
	uint32_t mas0;

	mas0 = MPU_MAS0_SEL;
	mas0 |= (entry->entry_id << 16) & MPU_MAS0_ESEL_MASK;
	if(entry->type == mpu_data_entry) {
		mas0 &= ~MPU_MAS0_INST;
	} else if(entry->type == mpu_instruction_entry) {
		mas0 |= MPU_MAS0_INST;
	} else { /* shared */
		mas0 |= MPU_MAS0_SHD;
	}

	booke_set_spr_MAS0(mas0);

	core_instruction_sync();
	MPURE
	core_instruction_sync();

	mas0 = booke_get_spr_MAS0();

	entry->valid = (mas0 & MPU_MAS0_VALID) ? 1 : 0;

	if(entry->attr != NULL) {
		entry->attr->upper_bound = booke_get_spr_MAS2();
		entry->attr->lower_bound = booke_get_spr_MAS3();
		entry->attr->cacheable = (mas0 & MPU_MAS0_I) ? 0 : 1;
		entry->attr->guarded = (mas0 & MPU_MAS0_G) ? 1 : 0;
		entry->attr->read_only = (mas0 & (MPU_MAS0_READ_ONLY_BITS)) ? 0 : 1;
		entry->attr->instruction = (mas0 & MPU_MAS0_INST) ? 1 : 0;
	}
}

/*****************************************************************************/
static int mpu_add_region(enum entry_type_t entry_type, struct region_attr_t *new_attr)
{
	int i;
	struct mpu_entry_t entry = {0};

	ASSERT_COND(entry_type != mpu_invalid_entry);

	entry.type = entry_type;

	ASSERT_COND_LIGHT(new_attr->lower_bound < new_attr->upper_bound);

	for (i=0; i < get_regions_num(entry_type); i++)
	{
		entry.entry_id = i;
		mpu_read_entry(&entry);
		if (!entry.valid)
		{
			entry.valid = 1;
			entry.attr = new_attr;
			entry.type = entry_type;
			mpu_write_entry(&entry);
			return entry.entry_id;
		}
	}

	return -EIO;
}

/*****************************************************************************/
void *mpu_add_non_cacheable_region(uint32_t start_addr, uint32_t size)
{
	struct region_attr_t attr = {0};
	int ret_val;

	ASSERT_COND_LIGHT(size > 0);

	attr.cacheable = 0;
	attr.override_cacheable = 1;
	attr.guarded = 0;
	attr.read_only = 0;
	attr.instruction = 0;
	attr.lower_bound = start_addr;
	attr.upper_bound = start_addr + size;

	ASSERT_COND_LIGHT(attr.lower_bound < attr.upper_bound);

	ret_val = mpu_add_region(mpu_data_entry, &attr);
	if(ret_val < 0) return NULL;

	return (void*)MPU_CREATE_HANDLE(MPU_DATA_TABLE, ret_val);
}

/*****************************************************************************/
static void mpu_clear_table(enum entry_type_t table_type)
{
	int i;
	struct region_attr_t attr;
	struct mpu_entry_t entry;

	ASSERT_COND(table_type != mpu_invalid_entry);

	attr.cacheable = 1;
	attr.guarded = 0;
	attr.read_only = 0;
	attr.lower_bound = 0;
	attr.upper_bound = 0;
	if(table_type == mpu_instruction_entry) {
		attr.instruction = 1;
	} else {
		attr.instruction = 0;
	}

	entry.attr = &attr;
	entry.valid = 0;
	entry.type = table_type;


	/* clear entries */
	for (i=0; i < get_regions_num(entry.type); i++)
	{
		entry.entry_id = i;
		mpu_write_entry(&entry);
	}
}

/*****************************************************************************/
static void mpu_clear_tables(void)
{
	/* clear data entries */
	mpu_clear_table(mpu_data_entry);

	/* clear instruction entries */
	mpu_clear_table(mpu_instruction_entry);

	/* clear shared entries */
	mpu_clear_table(mpu_shared_entry);
}

/*****************************************************************************/
static void mpu_print_table(enum entry_type_t entry_type)
{
	int i;
	struct region_attr_t attr;
	struct mpu_entry_t entry;
	char        buf[1024];
	int         count = 0;

	ASSERT_COND(entry_type != mpu_invalid_entry);
	memset(buf, 0, sizeof(buf));

	entry.attr = &attr;

	count += sprintf((char *)&buf[count], "\nentry\tvalid\tstart   \tend     \tcached\tro\n");
	count += sprintf((char *)&buf[count], "#####\t#####\t#####   \t###     \t######\t##\n");

	for (i=0; i < get_regions_num(entry_type); i++)
	{
		int tmp_count = 0;
		entry.entry_id = i;
		entry.type = entry_type;
		mpu_read_entry(&entry);

		tmp_count = sprintf((char *)&buf[count], "%d\t%d\t0x%08lx\t0x%08lx\t%d\t%d\n", entry.entry_id,
					entry.valid, entry.attr->lower_bound, entry.attr->upper_bound,
					entry.attr->cacheable, entry.attr->read_only);
		if ((count + tmp_count) > 1023)
		{
			pr_debug(buf);
			count = 0;
			i--;
		}
		else
			count += tmp_count;
	}
	pr_debug(buf);

}

/*****************************************************************************/
void mpu_print_tables(void)
{
	pr_debug("\nMPU Table (data):\n");
	mpu_print_table(mpu_data_entry);

	pr_debug("\nMPU Table (instructions):\n");
	mpu_print_table(mpu_instruction_entry);

	pr_debug("\nMPU Table (shared):\n");
	mpu_print_table(mpu_shared_entry);
}

/*****************************************************************************/
void *mpu_add_protectable_region(const uint32_t start_addr, const uint32_t size, const int is_protected)
{
	int ret_val;
	struct region_attr_t attr = {0};

	ASSERT_COND_LIGHT(size > 0);

	attr.cacheable = 1;
	attr.guarded = 0;
	attr.read_only = is_protected ? 1 : 0;
	attr.instruction = 0;
	attr.lower_bound = start_addr;
	attr.upper_bound = start_addr + size;

	ASSERT_COND_LIGHT(attr.lower_bound < attr.upper_bound);

	ret_val = mpu_add_region(mpu_data_entry, &attr);
	if(ret_val < 0) return NULL;

	return (void*)MPU_CREATE_HANDLE(MPU_DATA_TABLE, ret_val);
}

/*****************************************************************************/
static enum entry_type_t entry_type_from_handle(const void* const handle)
{
	uint32_t handle_type = ((uint32_t)handle) & MPU_HANDLE_TYPE_MASK;

	if(handle_type == MPU_DATA_TABLE)
		return mpu_data_entry;
	else if(handle_type == MPU_INST_TABLE)
		return mpu_instruction_entry;
	else if(handle_type == MPU_SHARED_TABLE)
		return mpu_shared_entry;
	else
		return mpu_invalid_entry;
}

/*****************************************************************************/
void mpu_modify_region_protection(const void* const handle, const int is_protected)
{
	struct region_attr_t attr;
	struct mpu_entry_t entry;

	ASSERT_COND(handle != NULL);

	entry.attr = &attr;
	entry.entry_id = (int)(((uint32_t)handle) & MPU_HANDLE_ID_MASK);
	entry.type = entry_type_from_handle(handle);

	ASSERT_COND(entry.type != mpu_invalid_entry);

	mpu_read_entry(&entry);

	entry.attr->read_only = is_protected ? 1 : 0;
	mpu_write_entry(&entry);
}

/*****************************************************************************/
void mpu_init(void)
{
	mpu_clear_tables();
}

/*****************************************************************************/
void mpu_register_log_buffer_handle(void* handle)
{
	uint32_t core_id = core_get_id();

	ASSERT_COND(handle != NULL);
	ASSERT_COND(log_buffer_handle[core_id] == NULL);

	log_buffer_handle[core_id] = handle;
}

/*****************************************************************************/
void mpu_protect_log_buffer()
{
	uint32_t core_id = core_get_id();

	/* Don't lock if logger partition was not registered */
	if(log_buffer_handle[core_id] == NULL)
		return;

	mpu_modify_region_protection(log_buffer_handle[core_id], 1);
}

/*****************************************************************************/
void mpu_unprotect_log_buffer()
{
	uint32_t core_id = core_get_id();

	/* Don't lock if logger partition was not registered */
	if(log_buffer_handle[core_id] == NULL)
		return;

	mpu_modify_region_protection(log_buffer_handle[core_id], 0);
}



