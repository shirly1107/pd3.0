/*
 * Copyright 2013-2015 Freescale Semiconductor, Inc.
 * Copyright 2016-2020 NXP
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *   * Neither the name of Freescale Semiconductor nor the
 *     names of its contributors may be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY Freescale Semiconductor ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Freescale Semiconductor BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**************************************************************************//**
 @File          fsl_core_arch.h

 @Description   BOOKE external definitions prototypes
                This file is not included by the BOOKE
                source file as it is an assembly file. It is used
                only for prototypes exposure, for inclusion
                by user and other modules.
                Specific for E200 z4201Mn3 core
*//***************************************************************************/

#ifndef __FSL_CORE_ARCH_H
#define __FSL_CORE_ARCH_H

#include "fsl_types.h"
                
#define core_dcache_enable      booke_dcache_enable
#define core_dcache_disable     booke_dcache_disable
#define core_icache_flush       booke_icache_flush

/**************************************************************************//**
 @Function      booke_dcache_enable

 @Description   Enables the data cache for memory pages that are
                not cache inhibited.

 @Return        None.
*//***************************************************************************/
void booke_dcache_enable(void);

/**************************************************************************//**
 @Function      booke_is_dcache_enabled

 @Description   Checks if data cache is enabled

 @Return        '1'(Enabled)/'0'(Disabled)
*//***************************************************************************/
int booke_is_dcache_enabled(void);

/**************************************************************************//**
 @Function      booke_dcache_disable

 @Description   Disables the data cache.

 @Return        None.
*//***************************************************************************/
void booke_dcache_disable(void);

/**************************************************************************//**
 @Function      booke_dcache_set_stash_id

 @Description   Set Stash Id for data cache

 @Param[in]     stashId     the stash id to be set.

 @Return        None.
*//***************************************************************************/
void booke_dcache_set_stash_id(uint8_t stash_id);

/**************************************************************************//**
 @Function      booke_dcache_get_stash_id

 @Description   Get Stash Id for data cache

 @Param[in]     none.

 @Return        Stash ID.
*//***************************************************************************/
uint8_t booke_dcache_get_stash_id(void);

int booke_set_intr(int ppc_intr_src,
                   void (*isr)(void *arg),
                   void *arg);

int booke_clear_intr(int ppc_intr_src);

/* Layer 1 Cache Manipulations
 *==============================
 * Should not be called directly by the user.
 */
void        l1dcache_block_invalidate (uint32_t addr);
void        l1icache_block_invalidate (uint32_t addr);
void        l1dcache_block_flush (uint32_t addr);

/*
 *
 * Book E Special-Purpose Registers (by SPR Abbreviation)
 */
 void booke_set_spr_PVR(uint32_t newvalue);    /* [287]        Processor version register */

/*
*
* Implementation-Specific SPRs (by SPR Abbreviation)
*
*/
void booke_set_spr_SVR(uint32_t newvalue);    /* [1023]       System version register */


#endif /* __FSL_CORE_ARCH_H */
