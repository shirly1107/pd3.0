/*
 * Copyright 2013-2015 Freescale Semiconductor, Inc.
 * Copyright 2016-2020 NXP
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *   * Neither the name of Freescale Semiconductor nor the
 *     names of its contributors may be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY Freescale Semiconductor ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Freescale Semiconductor BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**************************************************************************//**
 @File          fsl_core_regs_arch.h

 @Description   BOOKE external definitions prototypes
                This file is not included by the BOOKE
                source file as it is an assembly file. It is used
                only for prototypes exposure, for inclusion
                by user and other modules.
*//***************************************************************************/

#ifndef __FSL_CORE_REGS_ARCH_H
#define __FSL_CORE_REGS_ARCH_H

/*******************************************************
* interrupt vector
*
* The handler is fixed to this address.
********************************************************/
#define CRITICAL_INTR               	0x0100
#define MACHINE_CHECK_INTR          	0x0200
#define DATA_STORAGE_INTR           	0x0300
#define INSTRUCTION_STORAGE_INTR    	0x0400
#define EXTERNAL_INTR               	0x0500
#define ALIGNMENT_INTR              	0x0600
#define PROGRAM_INTR                	0x0700
#define SYSTEM_CALL_INTR            	0x0800
#define DEBUG_INTR                  	0x0900
#define EFPU_DATA_INTR              	0x0a00
#define EFPU_ROUND_INTR               	0x0b00
#define EFPU_NA_INTR                	0x0c00
#define PERF_MONITOR_INTR           	0x0d00
/* Next should be +1 from last Interrupt, for table build */
#define LAST_INTR			            0x0e00

/*
 *
 * Implementation-Specific SPRs (by SPR Abbreviation)
 *
 */
#define DSRR0       574     /* Debug save/restore register 0 */
#define DSRR1       575     /* Debug save/restore register 1 */

#define MPU0CSR0    1014    /* MPU0 Control and Status Register 0 */
#define MPU0CFG     692     /* MPU Configuration Register */


#endif /* __FSL_CORE_REGS_ARCH_H */
