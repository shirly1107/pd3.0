/*
 * Copyright 2013-2020 NXP
 */

/***************************************************************************//*
 @File          booke_core_arch.c

 @Description   Upper Level IO interfaces to the ASM functions
                Specific for E200 z4201Mn3 core

 @Cautions
*//***************************************************************************/
#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_core_booke_regs.h"
#include "fsl_core_booke.h"
#include "booke.h"
#include "fsl_dbg.h"

/*----------------------------------*/
/*  Is Data Cache Enabled           */
/*----------------------------------*/
int  booke_is_dcache_enabled(void)
{
    return !!l1dcache_is_enabled();
}

/*----------------------------------*/
/*  Data Cache Enable               */
/*----------------------------------*/
void booke_dcache_enable(void)
{
    l1dcache_invalidate();
    l1dcache_enable();
}

/*----------------------------------*/
/*  Data Cache Disable              */
/*----------------------------------*/
void booke_dcache_disable(void)
{
   uint32_t       int_flags;

   int_flags = core_local_irq_save();
   l1dcache_flush();
   l1dcache_disable();
   core_local_irq_restore(int_flags);
}

/*----------------------------------*/
/*  Data Cache Flush                */
/*----------------------------------*/
void booke_dcache_flush(void)
{
    l1dcache_flush();
}

/*----------------------------------*/
/*  Data Cache Set Stash Id         */
/*----------------------------------*/
void booke_dcache_set_stash_id(uint8_t stash_id)
{
    uint32_t    reg = (booke_get_spr_L1CSR2() & not_L1CSR2_STASHID);

    reg |= stash_id;

    booke_set_spr_L1CSR2(reg);
}

/*----------------------------------*/
/*  Data Cache Set Stash Id         */
/*----------------------------------*/
uint8_t booke_dcache_get_stash_id(void)
{
    uint32_t   reg = booke_get_spr_L1CSR2 ();

    reg &= L1CSR2_STASHID;

    return (uint8_t)reg;
}

/*****************************************************************************/
uint32_t booke_get_id(void)
{
    uint32_t cpu_id = 0;

    cpu_id = get_cpu_id();

    if (cpu_id >= INTG_MAX_NUM_OF_CORES) {
        pr_err("Core ID 0x%x is out of range, max = %d \n",
               cpu_id,
               INTG_MAX_NUM_OF_CORES);
    }

    return cpu_id;
}
