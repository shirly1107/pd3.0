/*
 * Copyright 2013-2020 NXP
 */

#ifndef __MPU_H
#define __MPU_H

#include "fsl_types.h"

struct mpu_flags {
	int memory_protection;
};

void mpu_init(void);
void *mpu_add_non_cacheable_region(uint32_t start_addr, uint32_t size);
void mpu_enable(const struct mpu_flags * const flags);
void mpu_print_tables(void);

void mpu_modify_region_protection(const void* const handle, const int is_protected);
void *mpu_add_protectable_region(const uint32_t start_addr, const uint32_t size, const int is_protected);

void mpu_register_log_buffer_handle(void* handle);

#endif /* __MPU_H */
