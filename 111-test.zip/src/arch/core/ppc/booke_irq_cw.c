/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_core_booke_regs.h"
#include "tasklet.h"

extern void booke_generic_isr(unsigned long exceptNumber);
extern void pic_isr(unsigned long exceptNumber);
extern void booke_critical_isr(unsigned long exceptNumber);

extern void tasklets_isr_epilog(uint32_t orig_msr);
#if __COVERITY__
void booke_init_interrupt_vector(void);
void __sys_start(register int argc, register char **argv, register char **envp);
#else
asm void booke_init_interrupt_vector(void);
asm void __sys_start(register int argc, register char **argv, register char **envp);
#endif

#pragma push
#pragma section code_type ".interrupt_vector"
#pragma force_active on
#pragma function_align 256

/*
 * Note:
 * System reset exception vector
 * Value on p_rstbase[0:29] concatenated with 2'b00
 * Address must be 0x00000000
 */
#if __COVERITY__
static void system_reset_vector(void) {}
#else
asm static void system_reset_vector(void) {
    nofralloc

    lis r4,__sys_start@h
    ori r4,r4,__sys_start@l
    mtlr r4
    blrl
}
#endif

#if __COVERITY__
static void branch_table(void) {}
#else
asm static void branch_table(void) {
  nofralloc

  /* Critical Input Interrupt (Offset 0x00) */
    b  critical_irq
    
    /* Machine check Interrupt (Offset 0x10) */
    .align 0x10
    b  mechinecheck_irq
    
    /* Data Storage Interrupt (Offset 0x20) */
    .align 0x10
    b  data_stor_irq
    
    /* Instruction Storage Interrupt (Offset 0x30) */
    .align 0x10
    b  inst_stor_irq
    
    /* External Input Interrupt (Offset 0x40) */
    .align 0x10
    b  ext_irq
    
    /* Alignment Interrupt (Offset 0x50) */
    .align 0x10
    b  alignment_irq
    
    /* Program Interrupt (Offset 0x60) */
    .align 0x10
    b  program_irq
    
    /* Performance Monitor Interrupt (Offset 0x70) */
    .align 0x10
    b  perf_mon_irq
    
    /* System call Interrupt (Offset 0x80) */
    .align 0x10
    b  sys_call_irq
    
    /* Debug Interrupt (Offset 0x90) */
    .align 0x10
    b  dbg_irq
    
    /* EFPU Data Exception Interrupt (offset 0xA0) */
    .align 0x10
    b  floating_point_data_irq
    
    /* EFPU Round Exception Interrupt (offset 0xB0) */
    .align 0x10
    b  floating_point_round_irq
    
    /* EFPU Unavailable Interrupt (offset 0xC0) */
    .align 0x10
    b  floating_point_na_irq
    
    /* Critical interrupt */
    .align 0x100
critical_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfspr    r0,CSRR0 /* Critical save/restore register 0 */
    stw      r0,28(rsp)
    mfspr    r0,CSRR1 /* Critical save/restore register 1 */
    stw      r0,32(rsp)

    li  r3,CRITICAL_INTR
    lis r4,booke_critical_isr@h
    ori r4,r4,booke_critical_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtspr    CSRR1,r0
    lwz      r0,28(rsp)
    mtspr    CSRR0,r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfci

    /* Machine Check interrupt */
    .align 0x100
mechinecheck_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfspr    r0,MCSRR0 /* Machine check save/restore register 0 */
    stw      r0,28(rsp)
    mfspr    r0,MCSRR1 /* Machine check save/restore register 1 */
    stw      r0,32(rsp)

    li  r3,MACHINE_CHECK_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtspr    MCSRR1,r0
    lwz      r0,28(rsp)
    mtspr    MCSRR0,r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfmci

    /* 0x0300 Data Storage */
    .align 0x100
data_stor_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfsrr0   r0
    stw      r0,28(rsp)
    mfsrr1   r0
    stw      r0,32(rsp)

    li  r3,DATA_STORAGE_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtsrr1   r0
    lwz      r0,28(rsp)
    mtsrr0   r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfi

    /* Instruction Storage */
    .align 0x100
inst_stor_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfsrr0   r0
    stw      r0,28(rsp)
    mfsrr1   r0
    stw      r0,32(rsp)

    li  r3,INSTRUCTION_STORAGE_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtsrr1   r0
    lwz      r0,28(rsp)
    mtsrr0   r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfi

    /* External Interrupt */
    .align 0x100
ext_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfsrr0   r0
    stw      r0,28(rsp)
    mfsrr1   r0
    stw      r0,32(rsp)

    li  r3,EXTERNAL_INTR
    lis r4,pic_isr@h
    ori r4,r4,pic_isr@l
    mtlr    r4
    blrl

    lwz     r3,32(rsp) /* SRR1 - Original MSR */
    addis   r10, 0, tasklets_isr_epilog@h
    ori     r10, r10, tasklets_isr_epilog@l
    mtlr    r10
    blrl

    lwz      r0,32(rsp)
    mtsrr1   r0
    lwz      r0,28(rsp)
    mtsrr0   r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfi

    /* Alignment interrupt */
    .align 0x100
alignment_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfsrr0   r0
    stw      r0,28(rsp)
    mfsrr1   r0
    stw      r0,32(rsp)

    li  r3,ALIGNMENT_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtsrr1   r0
    lwz      r0,28(rsp)
    mtsrr0   r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfi

    /* Program interrupt */
    .align 0x100
program_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfsrr0   r0
    stw      r0,28(rsp)
    mfsrr1   r0
    stw      r0,32(rsp)

    li  r3,PROGRAM_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtsrr1   r0
    lwz      r0,28(rsp)
    mtsrr0   r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfi

    /* Performance Monitor interrupt */
    .align 0x100
perf_mon_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfsrr0   r0
    stw      r0,28(rsp)
    mfsrr1   r0
    stw      r0,32(rsp)

    li  r3,PERF_MONITOR_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtsrr1   r0
    lwz      r0,28(rsp)
    mtsrr0   r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfi

    
    /* System Call interrupt */
    .align 0x100
sys_call_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfsrr0   r0
    stw      r0,28(rsp)
    mfsrr1   r0
    stw      r0,32(rsp)

    li  r3,SYSTEM_CALL_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtsrr1   r0
    lwz      r0,28(rsp)
    mtsrr0   r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfi

    /* Debug interrupt */
    .align 0x100
dbg_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)   
    mfspr    r0,DSRR0
    stw      r0,28(rsp)
    mfspr    r0,DSRR1
    stw      r0,32(rsp)

    li  r3,DEBUG_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtspr    DSRR1,r0
    lwz      r0,28(rsp)
    mtspr    DSRR0,r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfdi
   
/* Floating-point data exception */
    .align 0x100
floating_point_data_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfsrr0   r0
    stw      r0,28(rsp)
    mfsrr1   r0
    stw      r0,32(rsp)

    li  r3,EFPU_DATA_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtsrr1   r0
    lwz      r0,28(rsp)
    mtsrr0   r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfi

    /* Floating-point round exception */
    .align 0x100
floating_point_round_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfsrr0   r0
    stw      r0,28(rsp)
    mfsrr1   r0
    stw      r0,32(rsp)

    li  r3,EFPU_ROUND_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtsrr1   r0
    lwz      r0,28(rsp)
    mtsrr0   r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfi
    
    /* Floating-point unavailable */
    .align 0x100
floating_point_na_irq:
    stwu     rsp,-80(rsp)
    stw      r0,8(rsp)
    mfctr    r0
    stw      r0,12(rsp)
    mfxer    r0
    stw      r0,16(rsp)
    mfcr     r0
    stw      r0,20(rsp)
    mflr     r0
    stw      r0,24(rsp)
    stw      r3,40(rsp)
    stw      r4,44(rsp)
    stw      r5,48(rsp)
    stw      r6,52(rsp)
    stw      r7,56(rsp)
    stw      r8,60(rsp)
    stw      r9,64(rsp)
    stw      r10,68(rsp)
    stw      r11,72(rsp)
    stw      r12,76(rsp)
    mfsrr0   r0
    stw      r0,28(rsp)
    mfsrr1   r0
    stw      r0,32(rsp)

    li  r3,EFPU_NA_INTR
    lis r4,booke_generic_isr@h
    ori r4,r4,booke_generic_isr@l
    mtlr    r4
    blrl

    lwz      r0,32(rsp)
    mtsrr1   r0
    lwz      r0,28(rsp)
    mtsrr0   r0
    lwz      r3,40(rsp)
    lwz      r4,44(rsp)
    lwz      r5,48(rsp)
    lwz      r6,52(rsp)
    lwz      r7,56(rsp)
    lwz      r8,60(rsp)
    lwz      r9,64(rsp)
    lwz      r10,68(rsp)
    lwz      r11,72(rsp)
    lwz      r12,76(rsp)
    lwz      r0,24(rsp)
    mtlr     r0
    lwz      r0,20(rsp)
    mtcrf    0xff,r0
    lwz      r0,16(rsp)
    mtxer    r0
    lwz      r0,12(rsp)
    mtctr    r0
    lwz      r0,8(rsp)
    addi     rsp,rsp,80
    rfi
}
#endif

#if __COVERITY__
void booke_init_interrupt_vector(void) {}
#else
asm void booke_init_interrupt_vector(void)
{
	lis     r3,branch_table@h
	ori     r3,r3,branch_table@l
    mtspr   IVPR,r3
}
#endif

#pragma pop
