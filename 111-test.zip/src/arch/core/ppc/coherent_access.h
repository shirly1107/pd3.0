/*
 * Copyright 2013-2015 Freescale Semiconductor, Inc.
 * Copyright 2016-2020 NXP
 */

/**************************************************************************//**
 @File          coherent_access.h

 @Description   Prototypes for dcache flush and fetch routines to use for
                coherent access.
*//***************************************************************************/
#ifndef __COHERENT_ACCESS_H
#define __COHERENT_ACCESS_H

#include "fsl_types.h"
#include "fsl_spinlock.h"

/**************************************************************************//**
@Function      fetch

@Description   Fetch the l1 dcache before read / write operations.

@Param[in]     ptr - pointer to memory virtual address.
@Param[in]     size - size in bytes for memory to be fetched

@Cautions      This is suitable for accessing SYS-DDR from the MC core.
               To access DP-DDR or PEB from the MC core,
               then the caller needs to set up the window first.
*//***************************************************************************/
void fetch(void *ptr, uint32_t size);

/**************************************************************************//**
@Function      flush

@Description   flush the l1 dcache after read / write operations.

@Param[in]     ptr - pointer to memory virtual address.
@Param[in]     size - size in bytes for memory to be fetched

@Cautions      This is suitable for accessing SYS-DDR from the MC core.
               To access DP-DDR or PEB from the MC core,
               then the caller needs to set up the window first.
*//***************************************************************************/
void flush(void *ptr, uint32_t size);

#endif /* __COHERENT_ACCESS_H */
