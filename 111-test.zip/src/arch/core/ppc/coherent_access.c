/*
 * Copyright 2013-2020 NXP
 */

/*
 @File          coherent_access.c

 @Description   Upper Level interfaces to the ASM functions

 @Cautions
*//***************************************************************************/
#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_core_booke_regs.h"
#include "fsl_core_booke.h"
#include "coherent_access.h"
#include "fsl_io.h"
#include "fsl_dbg.h"

void fetch(void *ptr, uint32_t size)
{
	uint32_t cache_size = 0;
	uint32_t addr = (uint32_t)ptr;

	ASSERT_COND(size != 0);
	while(cache_size <= size)
	{
		l1dcache_block_invalidate(addr);
		addr += L1_CACHE_LINE_SIZE;
		cache_size += L1_CACHE_LINE_SIZE;
	}

}

void flush(void *ptr, uint32_t size)
{
	uint32_t cache_size = 0;
	uint32_t addr = (uint32_t)ptr;
	volatile uint64_t chase_read;
	int i;

	ASSERT_COND(size != 0);
	while(cache_size <= size)
	{
		/*The cache is right through so the call to flush is
		 * just for future support */
		l1dcache_block_flush(addr);
		l1dcache_block_invalidate(addr);
		/*read in chunks of 8 bytes*/
		for(i = 0; i < L1_CACHE_LINE_SIZE && cache_size <= size;
			i += sizeof(uint64_t),
			addr += sizeof(uint64_t),
			cache_size += sizeof(uint64_t))
		{
			chase_read = (*(uint64_t *)addr);
			core_memory_barrier();
			core_instruction_sync();
			UNUSED(chase_read);
		}
	}
	core_instruction_sync();
}
