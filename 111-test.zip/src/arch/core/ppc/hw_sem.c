/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_io.h"
#include "hw_sem.h"
#include "fsl_smp.h"
#include "fsl_dbg.h"

/**************************************************************************//**
@Description   Hardware Semaphore Registers.
*//***************************************************************************/
struct hs_map_t
{
    uint32_t       hsmpr;          /**< Hardware Semaphore Register, 8 LST bits */
    uint8_t        reserved[0x4];
};

struct hs_map_t*   soc_hw_sem_module;

/**************************************************************************/
static inline void sem_write(int sem_num, uint8_t val)
{
    // accesses MUST be of 32 bit even though the semaphore is 8 bit; 
    // this is a hardware requirement
	iowrite32(val, &soc_hw_sem_module[sem_num].hsmpr);
}

/**************************************************************************/
static inline uint8_t sem_read(int sem_num)
{
	/* cache block invalidate */
	l1dcache_block_invalidate( (uint32_t) &soc_hw_sem_module[sem_num].hsmpr);

    // accesses MUST be of 32 bit even though the semaphore is 8 bit; 
    // this is a hardware requirement
    return (uint8_t) ioread32(&soc_hw_sem_module[sem_num].hsmpr);
}

/**************************************************************************/
void hw_sem_init(void * regs_base)
{
    int i;
    ASSERT_COND(sys_is_master_core());
    
    soc_hw_sem_module = (struct hs_map_t*) regs_base;
    
    /* Release(zero) all HW semaphores */
    for (i=0; i<NUMBER_OF_HW_SEMAPHORES; i++) {
    	hw_sem_release(i);
    	ASSERT_COND(hw_sem_is_free(i));
    }
}

/**************************************************************************/
void hw_sem_take(int sem_num, uint8_t val)
{
    ASSERT_COND(sem_num < NUMBER_OF_HW_SEMAPHORES);
    ASSERT_COND(val != 0);
    
    do
    {
        sem_write(sem_num, val);
    } while (sem_read(sem_num) != val);
}

#if 0
/**************************************************************************/
void hwSemaphoreIrqTake(int sem_num, uint8_t val)
{
    ASSERT_COND(sem_num < NUMBER_OF_HW_SEMAPHORES);
    ASSERT_COND(val != 0);
    
    osHwiSwiftDisable();
    
    do
    {
        sem_write(sem_num, val);
    } while (sem_read(sem_num) != val);
}
#endif

/**************************************************************************/
void hw_sem_release(int sem_num)
{
    ASSERT_COND(sem_num < NUMBER_OF_HW_SEMAPHORES);
    
    sem_write(sem_num, 0);
}

#if 0
/**************************************************************************/
void   hwSemaphoreIrqRelease(int sem_num)
{
    ASSERT_COND(sem_num < NUMBER_OF_HW_SEMAPHORES);
    
    sem_write(sem_num, 0);
    
    osHwiSwiftEnable();
}
#endif

/**************************************************************************/
int hw_sem_try_take(int sem_num, uint8_t val)
{
    ASSERT_COND(sem_num < NUMBER_OF_HW_SEMAPHORES);
    
    sem_write(sem_num, val);
    
    if (sem_read(sem_num) == val)
        return 0;
    
    return -EAGAIN;
}

/**************************************************************************/
uint8_t hw_sem_get_val(int sem_num)
{
    ASSERT_COND(sem_num < NUMBER_OF_HW_SEMAPHORES);
    
    return sem_read(sem_num);
}
