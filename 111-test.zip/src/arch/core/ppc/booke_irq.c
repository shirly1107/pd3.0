/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_stdio.h"
#include "fsl_core_booke_regs.h"
#include "fsl_core_booke.h"
#include "booke.h"
#include "fsl_dbg.h"

#define INTR_INDEX(_entry)	((int)((_entry) & 0x0000ff00) >> 8)

/******************************************************
 *   Structure:      ppc_intr_info
 *
 *   Description:    Holds interrupt callback function
 *******************************************************/
typedef struct {
	void            (* f_isr)(void *);
	/**< interrupt handler */
	void *    src_handle;
	/**< Parameter to pass to interrupt handler */
	int             active;
	/* True if f_Isr active */
} ppc_intr_info;

static ppc_intr_info core_intr_table[INTR_INDEX(LAST_INTR)] = {{ 0 }};

void booke_init_interrupt_vector(void);


/*---------------------------------------------------------*/
/*  Install A PPC Interrupt vector routine                 */
/*---------------------------------------------------------*/
int booke_set_intr(int ppc_intr_src,
		   void (* isr)(void * handle),
		   void * handle)
{
	int index = INTR_INDEX(ppc_intr_src);

	if (index >= INTR_INDEX(LAST_INTR)) {
		pr_err("Undefined interrupt: %d\n", index);
		
		return -EINVAL;
	}

	core_intr_table[index].f_isr =  isr;
	core_intr_table[index].src_handle = handle;
	core_intr_table[index].active = 1;

	return 0;
}

/*---------------------------------------------------------*/
/*  Clear A PPC Interrupt vector routine                   */
/*---------------------------------------------------------*/
int booke_clear_intr(int ppc_intr_src)
{
	int index = INTR_INDEX(ppc_intr_src);

	if (index >= INTR_INDEX(LAST_INTR)) {
		pr_err("Undefined interrupt: %d\n", index);
		return -EINVAL;
	}

	core_intr_table[index].active = 0;

	return 0;
}

/*****************************************************************/
/* routine:       booke_generic_irq_init                         */
/*                                                               */
/* description:                                                  */
/*        Initiate the Ivpr register to point to right address.  */
/* arguments:                                                    */
/*    None.                                                      */
/*                                                               */
/*****************************************************************/
void booke_generic_irq_init(void)
{
	booke_init_interrupt_vector();
}

/*****************************************************************/
/* routine:       booke_critical_isr                             */
/*                                                               */
/* description:                                                  */
/*    Internal routine, called by the critical interrupt handler */
/*    to indicate the occurrence of a critical INT.              */
/*                                                               */
/* arguments:                                                    */
/*    intr_entry (In) - The interrupt handler original offset.   */
/*                                                               */
/*****************************************************************/
void booke_critical_isr(uint32_t intr_entry)
{
	int index = INTR_INDEX(CRITICAL_INTR);

	if (core_intr_table[index].active)
		core_intr_table[index].f_isr(core_intr_table[index].src_handle);
	else
		pr_err("int: CRITICAL\n");
}

/*****************************************************************/
/* routine:       booke_generic_isr                              */
/*                                                               */
/* description:                                                  */
/*    Internal routine, called by the main interrupt handler     */
/*    to indicate the occurrence of an INT.                      */
/*                                                               */
/* arguments:                                                    */
/*    intr_entry (In) - The interrupt handler original address.  */
/*                                                               */
/*****************************************************************/
void booke_generic_isr(uint32_t intr_entry)
{
	static int print_limit = 3;
	int index = INTR_INDEX(intr_entry);

	char *intr_names[] = {
	                      "",
	                      "CRITICAL",
	                      "MACHINE_CHECK",
	                      "DATA_STORAGE",
	                      "INST_STORAGE",
	                      "EXTERNAL",
	                      "ALIGNMENT",
	                      "PROGRAM",
	                      "SYSTEM CALL",
	                      "DEBUG",
	                      "FP DATA",
	                      "FP ROUND",
	                      "FP NA",
	                      "PERF MON"
	};

	if (index >= INTR_INDEX(LAST_INTR)) {
		pr_err("Undefined interrupt: %d\n", index);
	} 
	else {
		if (core_intr_table[index].active)
			core_intr_table[index].f_isr(core_intr_table[index].src_handle);
		else if (print_limit > 0) {
			print_limit--;
			pr_err("interrupt: %s\n", intr_names[index]);
		}	
	}
	
}
