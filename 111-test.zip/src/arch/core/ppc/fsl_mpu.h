/*
 * Copyright 2013-2020 NXP
 */

#ifndef __FSL_MPU_H
#define __FSL_MPU_H

/**************************************************************************//**
 @Function      mpu_protect_log_buffer

 @Description   Protect the log buffer memory from core access
*//***************************************************************************/
void mpu_protect_log_buffer();

/**************************************************************************//**
 @Function      mpu_unprotect_log_buffer

 @Description   Unprotect the log buffer memory from core access
*//***************************************************************************/
void mpu_unprotect_log_buffer();

#endif /* __FSL_MPU_H */
