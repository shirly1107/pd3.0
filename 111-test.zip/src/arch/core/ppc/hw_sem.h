/*
 * Copyright 2013-2020 NXP
 */

#ifndef __HW_SEM_H
#define __HW_SEM_H

#include "fsl_types.h"

#define NUMBER_OF_HW_SEMAPHORES 8

#define HW_SEM_VAL ((uint8_t)(core_get_id() + 1))

#define HW_SEM_SPINLOCK 0

/**************************************************************************//**
 @Function      hw_sem_init

 @Description   Initializes the hardware semaphore module.
                
 @Param[in]     regs_base - HW Semaphore registers base address.
 
*//***************************************************************************/
void hw_sem_init(void * regs_base);

/**************************************************************************//**
 @Function      hw_sem_take

 @Description   Performs a busy wait trying to acquire a hardware semaphore.

 @Param[in]     sem_num - Number of the semaphore to take.
 @Param[in]     val     - Value to write to the semaphore (0x01 - 0xFF)
                
*//***************************************************************************/
void hw_sem_take(int sem_num, uint8_t val);

#if 0
/**************************************************************************//**
 @Function      hwSemaphoreIrqTake

 @Description   Disables interrupts and then performs a busy wait trying to acquire 
                a hardware semaphore.
                
 @Param[in]     sem_num - Number of the semaphore to take.
 @Param[in]     val     - Value to write to the semaphore (0x01 - 0xFF)
                
*//***************************************************************************/
void   hwSemaphoreIrqTake(int sem_num, uint8_t val);
#endif

/**************************************************************************//**
 @Function      hw_sem_release

 @Description   Releases a hardware semaphore.

 @Param[in]     sem_num - Number of the semaphore to release.
 
 @Cautions      This function doesn't validate the the software entity
                 releasing the semaphore is the same as that acquired it 
                
*//***************************************************************************/
void hw_sem_release(int sem_num);

#if 0
/**************************************************************************//**
 @Function      hwSemaphoreIrqRelease

 @Description   Releases a hardware semaphore and then enables interrupts

 @Param[in]     sem_num - Number of the semaphore to release.
 
 @Cautions      This function doesn't validate the the software entity
                 releasing the semaphore is the same as that acquired it 
                
*//***************************************************************************/
void   hwSemaphoreIrqRelease(int sem_num);
#endif

/**************************************************************************//**
 @Function      hw_sem_try_take

 @Description   Try taking a hardware semaphore.

 @Param[in]     sem_num - Number of the semaphore to take.
 @Param[in]     val     - Value to write to the semaphore (0x01 - 0xFF)

 @Retval        0 on success, error code otherwise.
 
*//***************************************************************************/
int hw_sem_try_take(int sem_num, uint8_t val);


/**************************************************************************//**
 @Function      hw_sem_get_val

 @Description   Read the value currently written in a hardware semaphore.

 @Param[in]     sem_num - Number of the semaphore to read.

 @Return        Value currently written
 
*//***************************************************************************/
uint8_t hw_sem_get_val(int sem_num);


/**************************************************************************//**
 @Function      hw_sem_is_taken

 @Description   Checks if hardware semaphore is taken.

 @Param[in]     sem_num - Number of the semaphore to check.

 @Retval        TRUE  - Semaphore is taken
 @Retval        FALSE - Semaphore is not taken
 
*//***************************************************************************/
#define hw_sem_is_taken(sem_num) (hw_sem_get_val(sem_num) != 0)


/**************************************************************************//**
 @Function      hw_sem_is_free

 @Description   Checks if hardware semaphore is free.

 @Param[in]     sem_num - Number of the semaphore to check.

 @Retval        FALSE - Semaphore is not taken
 @Retval        TRUE  - Semaphore is taken
 
*//***************************************************************************/
#define hw_sem_is_free(sem_num) (hw_sem_get_val(sem_num) == 0)


#endif /* __HW_SEM_H */
