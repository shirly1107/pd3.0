/*
 * Copyright 2013 Freescale Semiconductor, Inc.
 * Copyright 2014-2020 NXP
 */

/**************************************************************************//**
 @File          fsl_core_ppc.h

 @Description   Core API for PowerPC cores

                These routines must be implemented by each specific PowerPC
                core driver.
*//***************************************************************************/
#ifndef __FSL_CORE_PPC_H
#define __FSL_CORE_PPC_H

#include "fsl_soc.h"


#define CORE_IS_BIG_ENDIAN

#include "fsl_core_booke.h"
#define CORE_CACHELINE_SIZE     32

#endif /* __FSL_CORE_PPC_H */
