/*
 * Copyright 2013-2020 NXP
 */

/**
 @File          fsl_soc_spec.h

 @Description   LS2100A external definitions and structures.
*//***************************************************************************/
#ifndef __FSL_SOC_SPEC_H
#define __FSL_SOC_SPEC_H

#include "fsl_types.h"

/*
 * This defines The maximum number of cores across all devices/archs/Revs
 * Not the actual number of cores available on the chip
 */
#define INTG_MAX_NUM_OF_CORES   2

#define INTERNAL_PERIPH_OFF_PORTALS_MC_AREA  0x0000000
#define INTERNAL_PERIPH_MC_PORTAL_ALIGNMENT  0x40       /* Alignment of a MC portal in internal MC DMEM */
#define PERIPH_MC_PORTAL_SIZE                0x40       /* Size of a MC portal*/
#define LDPAA_CCSR_OFF                       0x20000000

/* The number of GPP cores of the SOC */
#define SOC_NUM_OF_CORES		8

/* Allocation of LFQs */
#define DPMNG_DEFAULT_LFQMTIDX_ALLOC	64
#define DPMNG_MAX_LFQMTIDX_ALLOC	128
#define DPMNG_MAX_DCTIDX_ALLOC		SOC_NUM_OF_CORES

#define ERR008757
#define ERR008531
#define ERR008610
#define ERR008247
#define ERR008754
#define ERR008425
#define ERR008524
#define ERR008637
#define ERR008679
#define ERR009038
#define ERR008246
#define ERR008523
#define ERR008742
#define ERR009534
#define ERR008838
#define ERR009354
#define TKT255570 /* NO ERR id yet */
#define TKT256609 /* NO ERR id yet */
#define TKT220573

#define ENGR357301 /* AIOP RESET Not supported*/

/*simulator bugs */
#define ENGR00352475 /* Reading SGMII/XFI internal link in the MAC always shows link down */

#define TKT011436 /* LS specific define for mEMAC errata workaround */
#endif /* __FSL_SOC_SPEC_H */
