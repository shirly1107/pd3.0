/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "fsl_gen.h"
#include "fsl_dbg.h"
#include "common/fsl_string.h"
#include "fsl_io.h"
#include "fsl_platform.h"
#include "fsl_sys.h"
#include "drivers/fsl_mc.h"
#include "fsl_dpmng_mc.h"
#include "fsl_mem_mng.h"
#include "dpc.h"
#include "init_arch.h"
#include "fsl_qbman.h"
#include "fsl_qdma.h"
#include "fsl_dce.h"
#include "fsl_sec.h"

extern void build_apps_array(struct sys_module_desc *apps);

// default values set here; modified in dpmngr.c
uint32_t g_system_ddr1_non_cacheable_offset     = 0x03000000;
uint32_t g_system_ddr1_non_cacheable_size       = 16*MEGABYTE;

// default values set here; modified in dpmngr.c
uint32_t g_system_ddr1_cacheable_offset         = 0x04000000;
uint32_t g_system_ddr1_cacheable_size           = 32*MEGABYTE;

/**/
const uint32_t  g_boot_mem_mng_offset = 0x2800000;
const uint32_t  g_boot_mem_mng_size = 8*MEGABYTE;
/* This is part of g_boot_mem_mng_size for buffer pool ( e.g. for slob free/busy blocks */
const uint32_t  g_buffer_pool_size = 4*MEGABYTE;


struct init_module_desc {
	struct sys_module_desc f; /* modules functions */
	uint32_t status;
	int (*is_enabled)(void);
};

#define MAX_NUM_OF_APPS		10

int fill_system_parameters(t_sys_param *sys_param);
int global_init(void);
void run_apps(void);

int fill_system_parameters(t_sys_param *sys_param)
{
#ifdef SYS_SMP_SUPPORT
	sys_param->active_cores_mask = (1 << sys_get_max_num_of_cores()) - 1; /* Cores bit mask */
#else
	sys_param->active_cores_mask = 0x1;
#endif SYS_SMP_SUPPORT

	sys_param->master_cores_mask = 0x1;
	sys_param->use_cli = 0;

	/* make sure master core is running */
	ASSERT_COND_LIGHT(sys_param->active_cores_mask & sys_param->master_cores_mask);

	sys_param->platform_param->l1_cache_mode = E_CACHE_MODE_DATA_AND_INST;

	if (dpc.console.dpc_mask & DPC_CONSOLE_MASK_MODE) {
		if (dpc.console.mode == CONSOLE_MODE_ON)
			sys_param->platform_param->console_type = PLTFRM_CONSOLE_DUART;
		else
			sys_param->platform_param->console_type = PLTFRM_CONSOLE_NONE;
	} else {
		sys_param->platform_param->console_type = PLTFRM_CONSOLE_NONE;
	}

	sys_param->platform_param->console_id = (uint8_t)
			((dpc.console.dpc_mask & DPC_CONSOLE_MASK_UART_ID) ? (dpc.console.uart_id - 1) : (3 - 1));
	/* UART 0 means no prints to console */
	if (dpc.console.uart_id == 0) {
		sys_param->platform_param->console_type = PLTFRM_CONSOLE_NONE;
	}

	struct platform_memory_info mem_info[] = MEMORY_PARTITIONS;
	memcpy(sys_param->platform_param->mem_info, mem_info,
	       sizeof(struct platform_memory_info) * ARRAY_SIZE(mem_info));
	sys_param->platform_param->num_of_mem_parts = ARRAY_SIZE(mem_info);

	return 0;
}

static int is_global_module_enabled(enum soc_module mod, enum dcfg_disabled_devices dev)
{
	/* if module doesn't exist */
	if (sys_get_desc(mod, 0, NULL, NULL) == 0)
	{
		/* if module has no devdisr bit, or devdisr bit is clear */
		if (!dev || !(dcfg_is_unavailable(dev, NULL))) 
			return 1;
	}
	
	return 0;
}

static int is_qbman_enabled()
{
	return is_global_module_enabled(SOC_MODULE_QBMAN, DCFG_DEVDIS_QBMAN);
}

/* Disabled on emulator because some emulation models do not include QDMA block */
#ifdef EMULATOR
static int is_qdma_enabled()
{
	return 0;
}
#else
static int is_qdma_enabled()
{
	return is_global_module_enabled(SOC_MODULE_QDMA, DCFG_DEVDIS_QDMA);
}
#endif /* EMULATOR */

static int is_dce_enabled()
{
	return is_global_module_enabled(SOC_MODULE_DCE, DCFG_DEVDIS_DCE);
}

static int is_caam_enabled()
{
	return is_global_module_enabled(SOC_MODULE_SEC, DCFG_DEVDIS_SEC);
}

static int is_aiop_enabled()
{
	return is_global_module_enabled(SOC_MODULE_AIOP, DCFG_DEVDIS_AIOP);
}

static int is_eiop_enabled()
{
	return is_global_module_enabled(SOC_MODULE_EIOP, DCFG_DEVDIS_EIOP);
}

static int is_pebm_enabled()
{
	return is_global_module_enabled(SOC_MODULE_PEBM, DCFG_DEVDIS_PEBM);
}

static int is_rtc_enabled()
{
	return is_global_module_enabled(SOC_MODULE_EIOP_RTC, DCFG_DEVDIS_NONE);
}


static int global_module_enabled_stub()
{
	return 1;
}

int global_init(void)
{
	int i, err;
	struct init_module_desc modules[] = GLOBAL_MODULES;

	for (i = 0; i < ARRAY_SIZE(modules); i++) {
		if((modules[i].is_enabled) && (modules[i].is_enabled())) {
			if (modules[i].f.init) {
				if ((err = modules[i].f.init()) != 0) {
					pr_err("global_init failed");
					dpmng_set_mc_status(modules[i].status);
					return err;
				}
			}
		}
	}

	return 0;
}

void run_apps(void)
{
	struct sys_module_desc apps[MAX_NUM_OF_APPS];
	int i;

	memset(apps, 0, sizeof(apps));
	build_apps_array(apps);

	for (i = 0; i < MAX_NUM_OF_APPS; i++)
		if (apps[i].init)
			apps[i].init();
}


