/*
 * Copyright 2013-2020 NXP
 */

#ifndef __SOC_DB_H
#define __SOC_DB_H

#include "fsl_types.h"
#include "fsl_soc.h"
#include "fsl_ctlu.h"
#include "fsl_eiop.h"
#include "fsl_eiop_ifp.h"
#include "fsl_eiop_rtc.h"
#include "fsl_eiop_port.h"
#include "fsl_eiop_memac.h"
#include "fsl_eiop_mdio.h"
#include "fsl_qbman.h"
#include "fsl_sec.h"
#include "drivers/fsl_qbman_base.h"
#include "drivers/fsl_mc.h"
#include "drivers/fsl_edma.h"
#include "drivers/fsl_aiop.h"
#include "fsl_dpmac_mc.h"
#include "fsl_duart.h"
#include "fsl_dce.h"
#include "fsl_pebm.h"
#include "fsl_lcfg.h"
#include "fsl_qdma.h"
#include "fsl_dcfg.h"
#include "fsl_dppmu.h"

struct soc_db_module_info {
    enum soc_module module;
    void *db_head;
    uint16_t db_item_count;
    uint16_t db_item_size;
    int (*match_desc)(const void *ref_desc,
                      void *user_desc,
                      int match_options,
                      uint32_t id_increment,
                      uint64_t addr_increment);
};

struct soc_db_range {
    uint32_t num;
    uint32_t id_inc;
    uint64_t addr_inc;
};

#define MAX_EIOP_CFG        1
#define MAX_AIOP_CFG        1
#define MAX_EIOP_IFP_CFG        12
#define MAX_EIOP_PORT_CFG        64
#define MAX_PPORT_CFG    32
#define MAX_VPORT_CFG    MAX_PPORT_CFG + 4
#define MAX_EIOP_RTC_CFG	1
#define MAX_EIOP_EXT_MDIO_CFG	2
#define MAX_CTLU_CFG        8
#define MAX_UART_CFG        4
#define MAX_CPM_CFG       2
#define MAX_PIC_CFG            1
#define MAX_QBMAN_CFG            1
#define MAX_QBMAN_SWPORTAL_CFG   1
#define MAX_SOC_MC_PORTAL_CFG    16
#define MAX_MC_PORTAL_CFG    16
#define MAX_DPMAC_CFG        16
#define MAX_MDIO_CFG	2
#define MAX_SERDES_CFG    2
#define MAX_EDMA_CFG        1
#define MAX_EDMA_BLOCKS_CFG    2
#define MAX_MC_CORES_CFG        4
#define MAX_LCFG_CFG        4
#define MAX_SEC_CFG	1
#define MAX_DCE_CFG	1
#define MAX_DDR_CFG	1
#define MAX_DPDDR_CFG	1
#define MAX_PEB_CFG	1
#define MAX_QDMA_CFG	1
#define MAX_DPPMU_CFG	1
#define MAX_VARIANCE_CFG 40

#define DEVICE_PACKAGE_LX2_SYSTEM_VER	0x87360000
#define DEVICE_PACKAGE_SMALL_LX2162		1
#define DEVICE_PACKAGE_BIG_LX2160		2

#define MAC_NUM_MEMORY_REGIONS		9
#define NUM_MAC_TYPES				3

struct soc_db {
	struct {
		uint32_t system_version_arch;
		uint32_t system_version_mask;
		uint32_t personality_mask;
		uint8_t  options;
		struct {
			uint32_t personality;
			uint8_t major;
			uint8_t minor;
			char name[10];
			struct soc_db *soc_db;
		} variances[MAX_VARIANCE_CFG];
	} var_select;

	uint32_t emac_regs_mem_map[NUM_MAC_TYPES][MAC_NUM_MEMORY_REGIONS];
	int use_recycle_port_timestamp;

	struct {
		struct soc_db_range range;
		struct mc_desc desc;
	} mc_db[1];

	struct {
		struct soc_db_range range;
		struct dcfg_desc desc;
	} dcfg_db[1];

	struct {
		struct soc_db_range range;
		struct mem_desc desc;
	} pebm_db[MAX_PEB_CFG];

	struct {
		struct soc_db_range range;
		struct mem_desc desc;
	} dpddr_db[MAX_DPDDR_CFG];

	struct {
		struct soc_db_range range;
		struct mem_desc desc;
	} mc_ddr_db[MAX_DDR_CFG];

	struct {
		struct soc_db_range range;
		struct dmem_desc desc;
	} dmem_db[MAX_MC_CORES_CFG];

	struct {
		struct soc_db_range range;
		struct mc_bt_desc desc;
	} mc_bt_db[MAX_MC_CORES_CFG];

	struct {
		struct soc_db_range range;
		struct mc_portal_desc desc;
	} mc_portal_db[MAX_MC_PORTAL_CFG];

	struct {
		struct soc_db_range range;
		struct soc_mc_portal_desc desc;
	} soc_mc_portal_db[MAX_SOC_MC_PORTAL_CFG];

	struct {
		struct soc_db_range range;
		struct cpm_desc desc;
	} cpm_db[MAX_CPM_CFG];

	struct {
		struct soc_db_range range;
		struct qdma_desc desc;
	} qdma_db[MAX_QDMA_CFG];

	struct {
		struct soc_db_range range;
		struct eiop_desc desc;
	} eiop_block_db[MAX_EIOP_CFG];

	struct {
		struct soc_db_range range;
		struct eiop_ifp_desc desc;
	} eiop_ifp_db[MAX_EIOP_IFP_CFG];

	struct {
		struct soc_db_range range;
		struct eiop_port_desc desc;
	} eiop_port_db[MAX_EIOP_PORT_CFG];

	struct {
		struct soc_db_range range;
		struct eiop_memac_desc desc;
	} eiop_memac_db[MAX_EIOP_PORT_CFG];

	struct {
		struct soc_db_range range;
		struct eiop_rtc_desc desc;
	} eiop_rtc_db[MAX_EIOP_RTC_CFG];

	struct {
		struct soc_db_range range;
		struct ctlu_desc desc;
	} ctlu_db[MAX_CTLU_CFG];

	struct {
		struct soc_db_range range;
		struct aiop_tile_desc desc;
	} aiop_tile_db[MAX_AIOP_CFG];

	struct {
		struct soc_db_range range;
		struct uart_desc desc;
	} uart_db[MAX_UART_CFG];

	struct {
		struct soc_db_range range;
		struct pic_desc desc;
	} pic_db[MAX_PIC_CFG];

	struct {
		struct soc_db_range range;
		struct qbman_desc desc;
	} qbman_db[MAX_QBMAN_CFG];

	struct {
		struct soc_db_range range;
		struct qbman_swportal_desc desc;
	} qbman_swportal_db[MAX_QBMAN_SWPORTAL_CFG];

	struct {
		struct soc_db_range range;
		struct edma_desc desc;
	} edma_db[MAX_EDMA_CFG];

	struct {
		struct soc_db_range range;
		struct edma_block_desc desc;
	} edma_block_db[MAX_EDMA_BLOCKS_CFG];
	struct {
		struct soc_db_range range;
		struct lcfg_desc desc;
	} lcfg_db[MAX_LCFG_CFG];

	struct {
		struct soc_db_range range;
		struct sec_desc desc;
	} sec_db[MAX_SEC_CFG];

	struct {
		struct soc_db_range range;
		struct pport_connections_desc desc;
	} pport_connections_db[MAX_PPORT_CFG];

	struct {
		struct soc_db_range range;
		struct vport_connections_desc desc;
	} vport_connections_db[MAX_VPORT_CFG];

	struct {
		struct soc_db_range range;
		struct dce_desc desc;
	} dce_db[MAX_DCE_CFG];
	struct {
		struct soc_db_range range;
		struct mdio_desc desc;
	} mdio_db[MAX_MDIO_CFG];
	struct {
		struct soc_db_range range;
		struct serdes_desc desc;
	} serdes_db[MAX_SERDES_CFG];
	struct {
		struct soc_db_range range;
		struct dppmu_desc desc;
	} dppmu_db[MAX_DPPMU_CFG];
};

#endif /* __SOC_DB_H */
