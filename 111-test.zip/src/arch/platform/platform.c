/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "fsl_dbg.h"
#include "fsl_io.h"
#include "fsl_duart.h"
#include "drivers/fsl_mcpic.h"
#include "drivers/fsl_mc.h"
#include "drivers/fsl_edma.h"
#include "fsl_console.h"
#include "fsl_platform.h"
#include "fsl_timer.h"
#include "fsl_smp.h"
#include "mpu.h"
#include "fsl_mem_mng.h"
#include "fsl_intr_mng.h"
#include "fsl_sys.h"
#include "fsl_soc.h"
#include "edma.h"
#include "edma_init.h"
#include "fsl_dpmng_mc.h"
#include "dpmng.h"
#include "fsl_dcfg.h"
#include "drivers/fsl_serdes.h"
#include "fsl_eiop_memac.h"
#include "dpc.h"
#include "mpic_timers.h"
#include "fsl_tasklet.h"

#undef LOG_MODULE
#define LOG_MODULE LOG_MOD_PLATFORM

#define __ERR_MODULE__  MODULE_SOC_PLATFORM

#define MEM_ALIGN_4K_MASK (~(uint64_t)(4 * KILOBYTE - 1))
#define MEM_SYS_DDR2_CREATE_LIMIT (4 * KILOBYTE)
/* Memory map for phys2vist/virt2phys conversion
 * Currently it contains only MC ddr memory
 */
#define VIRT_2_PHYS_MAP\
{/* Memory region   Virt. Address    Phys. Address Size */\
	{MEM_RGN_MC_DDR,0x000000000,    0xFFFFFFFF,   0xFFFFFFFF}\
}

extern phys_addr_t dpmng_get_mc_mem_base(void);

/* Global platform variable that holds platform definitions. Will reside in sram */
static struct t_platform  s_pltfrm = {0};

/* Module names for debug messages */
const char *module_strings[] = {
                                "???"                      /* MODULE_UNKNOWN */
                                ,"MEM"                      /* MODULE_MEM */
                                ,"SLOB"                       /* MODULE_MM */
                                ,"CORE"                     /* MODULE_CORE */
                                ,"SoC"                      /* MODULE_LS2100A */
                                ,"SoC-platform"             /* MODULE_LS2100A_PLATFORM */
                                ,"PM"                       /* MODULE_PM */
                                ,"MMU"                      /* MODULE_MMU */
                                ,"PIC"                      /* MODULE_PIC */
                                ,"DUART"                    /* MODULE_DUART */
                                ,"SERDES"                   /* MODULE_SERDES */
                                ,"QM"                       /* MODULE_QM */
                                ,"BM"                       /* MODULE_BM */
                                ,"SEC"                      /* MODULE_SEC */
                                ,"LAW"                      /* MODULE_LAW */
                                ,"LBC"                      /* MODULE_LBC */
                                ,"MII"                      /* MODULE_MII */
                                ,"DMA"                      /* MODULE_DMA */
                                ,"SRIO"                     /* MODULE_SRIO */
                                ,"RMan"                     /* MODULE_RMAN */
				,"DCE"			    /* MODULE_DCE */
};
static int build_mem_partitions_table(t_platform  *pltfrm,
		                          struct platform_memory_info* mem_partitions);
static int build_virt2phys_mapping(t_platform  *pltfrm);

/*****************************************************************************/
static void print_platform_info(t_platform *pltfrm)
{
	char buf[1024];
	int count = 0;
	uint32_t sys_clock;
	int iter = 0, i = 0;
	struct serdes_desc serdes_desc = { 0 };
	struct dcfg_desc dcfg_desc = { 0 };
	uint8_t sd_proto = 0;	/* Serdes protocol - read from RCW */

	ASSERT_COND(pltfrm);

	/*------------------------------------------*/
	/* Device enable/disable and status display */
	/* Power Save mode                          */
	/*------------------------------------------*/
	count += sprintf((char *)&buf[count], "Freescale LS2");

	count += sprintf(
		(char *)&buf[count], "\n\nclocks: [IN:%lu.%lu] ",
		(uint32_t)(pltfrm->platform_clk / 1000),
		(uint32_t)((pltfrm->platform_clk % 1000) / 100));

	sys_clock = platform_get_clk(pltfrm);
	count += sprintf((char *)&buf[count], "[SYS BUS:%ld.%ld]",
			 (sys_clock / 1000000),
			 ((sys_clock % 1000000) / 100000));

	/*--------------------------------------*/
	/*      CACHE Status display            */
	/*--------------------------------------*/
	count += sprintf((char *)&buf[count], "\n\nPlatform status: ");
	count += sprintf((char *)&buf[count], "\nDCACHE ICACHE\n");

	if (pltfrm->param.l1_cache_mode & E_CACHE_MODE_DATA_ONLY)
		count += sprintf((char *)&buf[count], "ON     ");
	else
		count += sprintf((char *)&buf[count], "OFF    ");

	if (pltfrm->param.l1_cache_mode & E_CACHE_MODE_INST_ONLY)
		count += sprintf((char *)&buf[count], "ON     ");
	else
		count += sprintf((char *)&buf[count], "OFF    ");

	count += sprintf((char *)&buf[count], "\n");

	/*--------------------------------------*/
	/*      SoC Info display            */
	/*--------------------------------------*/
	count += sprintf((char *)&buf[count], "\n");
	count += sprintf((char *)&buf[count], "SoC id:\t%s\n", s_pltfrm.soc_info.name);
	count += sprintf((char *)&buf[count], "SVR:\t0x%08lx\n",
		s_pltfrm.soc_info.rev.system_version);
	count += sprintf((char *)&buf[count], "Major:\t%d\n",
		s_pltfrm.soc_info.rev.major);
	count += sprintf((char *)&buf[count], "Minor:\t%d\n",
		s_pltfrm.soc_info.rev.minor);
	count += sprintf((char *)&buf[count], "\n");

	/* List the RGMII ports if any */
	sys_get_desc(SOC_MODULE_DCFG,
			SOC_DB_NO_MATCH_FIELDS,
			&dcfg_desc,
			NULL);

	for (i = 0; i < MAX_EC_CFG; i++)
		if (dcfg_desc.ec[i].valid && dcfg_has_rgmii(&dcfg_desc, i))
			count += sprintf((char *)&buf[count], "RGMII[%d]\n",
							dcfg_desc.ec[i].port_id);

	while (soc_db_get_desc(SOC_MODULE_SERDES, SOC_DB_NO_MATCH_FIELDS,
				&serdes_desc, &iter)
		== 0) {
		if (dcfg_desc.sd[serdes_desc.id].valid)
		{
			sd_proto = (uint8_t)dcfg_get_serdes_protocol(dcfg_desc.sd[serdes_desc.id].rcwsr_id,
												dcfg_desc.sd[serdes_desc.id].rcwsr_mask);

			count += sprintf((char *)&buf[count], "Serdes %d: %#x\n",
					serdes_desc.id + 1, sd_proto);
		}

		for (i = 0; i < serdes_desc.num_lanes; i++)
		{
			int tmp_count = 0;

			tmp_count += serdes_get_mac_string(&dcfg_desc, &serdes_desc, &i,
					(char *)&buf[count], sd_proto);
			if ((count + tmp_count) > 1023)
			{
				pr_info(buf);
				count = 0;
				i--;
			}
			else
				count += tmp_count;
		}
	}

	pr_info(buf);
}

#if 0
/*****************************************************************************/
static int cli_cmd_mem_info_cb(void * h_platform, int argc, char *argv[])
{
	t_platform *pltfrm = (t_platform *)h_platform;
	int        index = 0;

	UNUSED(argc);UNUSED(argv);
	ASSERT_COND(pltfrm);

	while (index < ARRAY_SIZE(pltfrm->registered_partitions)) {
		if (pltfrm->registered_partitions[index])
			sys_print_mem_partition_debug_info(pltfrm->registered_partitions[index], 0);
		index++;
	}

	return 0;
}

/*****************************************************************************/
static void register_cli_commands(t_platform *pltfrm)
{
	ASSERT_COND(pltfrm);

	fsl_os_cli_register_command("meminfo",
	                            "display memory partition information.",
	                            "meminfo",
	                            pltfrm,
	                            cli_cmd_mem_info_cb);
}

/*****************************************************************************/
static void unregister_cli_commands(t_platform *pltfrm)
{
	UNUSED(pltfrm);

	fsl_os_cli_unregister_command("meminfo");
}
#endif

/*****************************************************************************/
static void init_l1_cache(t_platform *pltfrm)
{
	ASSERT_COND(pltfrm);

	/* L1 Cache Init */
	if (pltfrm->param.l1_cache_mode & E_CACHE_MODE_INST_ONLY) {
		core_icache_enable();
		core_icache_flush();
	}

	if (pltfrm->param.l1_cache_mode & E_CACHE_MODE_DATA_ONLY)
		core_dcache_enable();
}

/*****************************************************************************/
static int disable_l1_cache(t_platform *pltfrm)
{
	if (pltfrm->param.l1_cache_mode & E_CACHE_MODE_INST_ONLY)
		booke_icache_disable();

	if (pltfrm->param.l1_cache_mode & E_CACHE_MODE_DATA_ONLY) {
		/*  booke_dcache_flush(); */
		booke_dcache_disable();
	}

	return 0;
}

/*****************************************************************************/
static int console_print_cb(void * h_console_dev,
				uint8_t *p_data, uint32_t size)
{
	int err;

	err = duart_tx(h_console_dev, p_data, size);
	if (err != 0)
		return 0;

	return (int)size;
}

/*****************************************************************************/
static int console_print_cb_uart_disabled(void * h_console_dev, uint8_t *p_data, uint32_t size)
{
	UNUSED(h_console_dev);
	UNUSED(p_data);
	UNUSED(size);
	return 0;
}

/*****************************************************************************/
static int console_get_line_cb(void * h_console_dev,
				uint8_t *p_data, uint32_t size)
{
	uint32_t count;

	count = duart_rx(h_console_dev, p_data, size);

	return (int)count;
}

/*****************************************************************************/
static void pltfrm_enable_local_irq_cb(void * h_platform)
{
	UNUSED(h_platform);

	msr_enable_ee();
	msr_enable_me();
	msr_enable_ce();
}

/*****************************************************************************/
static void pltfrm_disable_local_irq_cb(void * h_platform)
{
	UNUSED(h_platform);

	msr_disable_ee();
	msr_disable_me();
	msr_disable_ce();
}

/*****************************************************************************/
/*------------------------------------------------------*/
/* Initialize MPU                                       */
/*------------------------------------------------------*/
static int pltfrm_init_mpu_cb(void * h_platform)
{
	struct mpu_flags mflags = {0};
	t_platform  *pltfrm = (t_platform *)h_platform;
	t_platform_memory_info  *p_mem_info;
	uintptr_t               virt_base_addr;
	uint32_t                size;
	int                     i;

	uint32_t lb_addr = 0, lb_size = 0;

	mpu_init();

	for (i = 0; i < pltfrm->num_of_mem_parts; i++)
	{
		p_mem_info = &pltfrm->param.mem_info[i];

		if(p_mem_info->size != 0)
		{
			void* mpu_handle;

			if(p_mem_info->mem_attribute & MEMORY_ATTR_NON_CACHEABLE)
			{// add non-cacheable area to mpu
				virt_base_addr = p_mem_info->virt_base_addr;
				size = (uint32_t)p_mem_info->size;
				/* must be less then 32 bit to fit in the mpu table */
				ASSERT_COND_LIGHT((p_mem_info->virt_base_addr + size) <= 0xffffffff);

				mpu_handle = mpu_add_non_cacheable_region(virt_base_addr, size);
				if(mpu_handle == NULL) {
					ASSERT_COND(mpu_handle != NULL);
					return -EBUSY;
				}

				if(p_mem_info->mem_partition_id == MEM_PART_LOGGER)
				{
					lb_addr = virt_base_addr;
					lb_size = size;
					mpu_register_log_buffer_handle(mpu_handle);
				}
			}

			if((p_mem_info->mem_partition_id == MEM_PART_LOGGER) && (lb_addr == 0))
			{
				lb_addr = p_mem_info->virt_base_addr;
				lb_size = (uint32_t)p_mem_info->size;
				mpu_handle = mpu_add_protectable_region(lb_addr, lb_size, 0);
				mpu_register_log_buffer_handle(mpu_handle);
			}
		}
	}

	/* Allow access to all memory except NULL */
	if(lb_size == 0) {
		mpu_add_protectable_region(0x00000004, 0xfffffffb, 0);
	}
	else {
		uint32_t limit_addr = lb_addr + lb_size;
		mpu_add_protectable_region(0x00000004, lb_addr - 4, 0);
		mpu_add_protectable_region(limit_addr, 0xffffffff - limit_addr, 0);
	}

	mflags.memory_protection = 1;
	mpu_enable(&mflags);

	return 0;
}

/*****************************************************************************/
static int pltfrm_init_core_cb(void * h_platform)
{
	t_platform  *pltfrm = (t_platform *)h_platform;

	ASSERT_COND(pltfrm);

#ifndef DEBUG
	/* Enable the BTB - branches predictor */
	booke_set_spr_BUCSR(booke_get_spr_BUCSR() | 0x00000201);
#endif /* DEBUG */

#if 0
	/*------------------------------------------------------*/
	/* Initialize MMU                                       */
	/*------------------------------------------------------*/
	if (pltfrm->param.user_init_hooks.f_init_mmu)
		err = pltfrm->param.user_init_hooks.f_init_mmu(pltfrm);
	else
		err = platform_init_mmu(pltfrm);

	if (err != 0)
		RETURN_ERROR(MAJOR, err, NO_MSG);
#endif /* 0 */

	/*------------------------------------------------------*/
	/* Initialize L1 Cache                                  */
	/*------------------------------------------------------*/
	init_l1_cache(pltfrm);

	return 0;
}

/*****************************************************************************/
static int pltfrm_free_core_cb(void * h_platform)
{
	t_platform  *pltfrm = (t_platform *)h_platform;

	ASSERT_COND(pltfrm);

	/* Disable L1 cache */
	disable_l1_cache(pltfrm);

	return 0;
}

/*****************************************************************************/
int pltfrm_init_console_cb(void * h_platform)
{
	t_platform  *pltfrm = (t_platform *)h_platform;
	int     err;

	ASSERT_COND(pltfrm);

	if(sys_is_master_core())
	{
		/* Master partition - register DUART console */
		err = platform_enable_console(pltfrm);
		if (err != 0)
		{
			err = sys_register_console((void *)-1, console_print_cb_uart_disabled, NULL);
			/*Uart failed. the print will go only to buffer*/
			pr_warn("UART print failed, all debug data will be printed to buffer.\n");
			return err;
		} else {
			pr_warn("The UART Console is enabled and the commands take longer time. "
					"Set CONSOLE_MODE_OFF in DPC file to disable it!\n");
		}

		err = sys_register_console(pltfrm->uart, console_print_cb,
						console_get_line_cb);
		if (err != 0) {
			pr_err("console registration failed\n");
			return err;
		}
	}

	sys_flush_pre_console_buf(pltfrm->uart);

	return 0;
}

/*****************************************************************************/
int pltfrm_free_console_cb(void * h_platform)
{
	t_platform  *pltfrm = (t_platform *)h_platform;

	ASSERT_COND(pltfrm);

	platform_disable_console(pltfrm);

	sys_unregister_console();

	return 0;
}

/*****************************************************************************/
static int pltfrm_init_edma_ctrl_cb(void * h_platform)
{
	// assume that every core has its own edma block
	uint32_t block_id = core_get_id();
	struct edma *edma_handle = NULL;
	struct edma_block_cfg block_cfg;
	struct edma_queue_cfg high_priority_queue_cfg, low_priority_queue_cfg;
	struct dpmng_amq mc_amq = {0};
	// eDMA's amq attributes are the same as for MC
	dpmng_get_amq(&mc_amq);

	ASSERT_COND(h_platform);
	if(sys_is_master_core())
	{
		edma_handle = add_edma();
		if( NULL == edma_handle)
			return 0;
	}
	sys_barrier();
	edma_handle = (struct edma *)sys_get_unique_handle(FSL_MOD_EDMA);

	if(NULL == edma_handle)
	{
		pr_warn("Couldn't retrieve edma  handle from system \n");
		/* return -E_NO_DEVICE; */
		return 0; /* not a failure */
	}
	block_cfg.edma = edma_handle;
	block_cfg.mem_partition_id = MEM_PART_SYSTEM_DDR1_NON_CACHEABLE;
	block_cfg.num_entries_in_status_queue = NUM_ENTRIES_IN_SQ;
	block_cfg.coalesc_intr_status_threshold =  0; /* No coalescing interrupt */
	block_cfg.water_mark_threshold = SQ_WATER_MARK;
	block_cfg.block_amq.icid = mc_amq.icid;
	block_cfg.block_amq.bmt = mc_amq.bmt;
	block_cfg.block_amq.bdi= mc_amq.bdi;
	block_cfg.block_amq.pl= mc_amq.pl;
	block_cfg.block_amq.va= mc_amq.va;
	// Each core creates its own edma_block.
	if(NULL == add_edma_block(block_id,&block_cfg))
		/* return -E_NO_DEVICE; */
			return 0; /* not a failure */
	// initialize 2 queues per block, one high priority, one - low.
	high_priority_queue_cfg.mem_partition_id = MEM_PART_SYSTEM_DDR1_NON_CACHEABLE;
	high_priority_queue_cfg.priority_queue = 0;
	high_priority_queue_cfg.size_queue = NUM_ENTRIES_IN_CQ;
	low_priority_queue_cfg.mem_partition_id = MEM_PART_SYSTEM_DDR1_NON_CACHEABLE;
	low_priority_queue_cfg.priority_queue = 7;
	low_priority_queue_cfg.size_queue = NUM_ENTRIES_IN_CQ;
	if(0 != add_edma_queue(block_id,0/*queue_id*/,&high_priority_queue_cfg))
	{
		pr_warn("Couldn't create edma queue num %d for edma block %d\n",
					0,block_id);
		/* return -ENAVAIL;	*/
		return 0; /* not a failure */
	}
	if(0 != add_edma_queue(block_id,1/*queue_id*/,&high_priority_queue_cfg))
	{
		pr_warn("Couldn't create edma queue num %d for edma block %d\n",
					1,block_id);
		/* return -ENAVAIL;	*/
		return 0; /* not a failure */
	}
	return 0;
}


/*****************************************************************************/
static int pltfrm_free_edma_ctrl_cb(void * h_platform)
{
	uint32_t block_id = core_get_id();
	int is_master = sys_is_master_core();

	int rc = 0;
	// Each core removes the queues and the block that belongs to it.
	remove_edma_queues(block_id);
	remove_edma_blocks(block_id);
	if(is_master)
		rc = remove_edma();
	return rc;
}

/*****************************************************************************/
static int pltfrm_init_intr_ctrl_cb(void * h_platform)
{
	t_platform  *pltfrm = (t_platform *)h_platform;
	int   err, iter = 0;
	struct pic_desc pic_desc;

	ASSERT_COND(pltfrm);

	//    if (pltfrm->param.user_init_hooks.f_init_intr_ctrl)
	//        return pltfrm->param.user_init_hooks.f_init_intr_ctrl(pltfrm);


	memset(&pic_desc, 0, sizeof(pic_desc));
	sys_get_desc(SOC_MODULE_PIC, SOC_DB_NO_MATCH_FIELDS, &pic_desc, &iter);

	pltfrm->pic = pic_desc.vaddr;

	err = mcpic_init(pltfrm->pic);
	if (err != 0) {
		pr_err("MPIC initiation failed\n");
		return err;
	}

	err = sys_register_intr_controller(pltfrm->pic,
	                                   NULL/*mcpic_set_intr*/,
	                                   NULL/*mcpic_free_intr*/,
	                                   NULL/*mcpic_enable_intr*/,
	                                   NULL/*mcpic_disable_intr*/,
	                                   &(pltfrm->pic_intr_id_base));
	if (err != 0) {
		pr_err("interrupt controller registration failed\n");
		return err;
	}

	return 0;
}

/*****************************************************************************/
static int pltfrm_free_intr_ctrl_cb(void * h_platform)
{
	t_platform  *pltfrm = (t_platform *)h_platform;

	ASSERT_COND(pltfrm);

	/* Free PIC interrupt controller */
	if (pltfrm->pic) {
		mcpic_free(pltfrm->pic);
		pltfrm->pic = NULL;
	}

	return 0;
}

/*****************************************************************************/
static int pltfrm_init_timer_cb(void * h_platform)
{
	t_platform  *pltfrm = (t_platform *)h_platform;
	int     err;

	ASSERT_COND(pltfrm);

	if(sys_is_master_core())
	{
		struct mpic_gt_init_params mpic_timer_params;

		mpic_timer_params.clk_src = mpic;
		mpic_timer_params.clk_ratio = div_8;
		pltfrm->timer = mpic_gt_init(&mpic_timer_params);

	}
	sys_barrier();

	if(pltfrm->timer == NULL)
		return -ENODEV;

	err = timer_init_module();
	if (err != 0)
		return err;

	return 0;
}

/*****************************************************************************/
static int pltfrm_free_timer_cb(void * h_platform)
{
	UNUSED(h_platform);

	timer_free_module();

	return 0;
}

/*****************************************************************************/
static int pltfrm_init_mem_partitions_cb(void * h_platform)
{
	t_platform              *pltfrm = (t_platform *)h_platform;
	t_platform_memory_info  *p_mem_info;
	int                     err;
	uintptr_t               virt_base_addr;
	uint64_t                size;
	int                     i, index = 0,rc = 0;


	ASSERT_COND(pltfrm);

	pltfrm->mc_mem_phys_base = dpmng_get_mc_mem_base();

	if((rc = build_mem_partitions_table(pltfrm, pltfrm->param.mem_info)) != 0)
		    return rc;
	build_virt2phys_mapping(pltfrm);

	for (i = 0; i < pltfrm->num_of_mem_parts; i++)
	{
		p_mem_info = &pltfrm->param.mem_info[i];
		virt_base_addr = p_mem_info->virt_base_addr;
		size = p_mem_info->size;
		if(size != 0 && p_mem_info->mem_attribute & MEMORY_ATTR_MALLOCABLE)
		{
		    err = sys_register_mem_partition(p_mem_info->mem_partition_id,
			                             virt_base_addr,
			                             size,
			                             p_mem_info->mem_attribute,
			                             p_mem_info->name);

		    if (err != 0)
		    {
		        return err;
		    }
	            pltfrm->registered_partitions[index++] = p_mem_info->mem_partition_id;
		}// end of MEMORY_ATTR_MALLOCABLE
		if(size != 0 && p_mem_info->mem_attribute & MEMORY_ATTR_PHYS_ALLOCATION)
		{
		    err = sys_register_phys_addr_alloc_partition(
							       p_mem_info->mem_partition_id,
							       p_mem_info->phys_base_addr,
							       p_mem_info->size,
							       p_mem_info->mem_attribute,
							       p_mem_info->name
								);
		    if (err != 0)
		         return err;
            pltfrm->registered_partitions[index++] = p_mem_info->mem_partition_id;
		}// end of MEMORY_ATTR_PHYS_ALLOCATION
	}
	sys_mem_partitions_init_complete();
	return 0;
}


/*****************************************************************************/
static int build_mem_partitions_table(t_platform  *pltfrm,
		                          struct platform_memory_info* mem_partitions)
{
	struct mem_desc peb_desc = {0};
	struct dmem_desc dmem1_desc = {0},dmem2_desc = {0};
	struct mem_desc dpddr_desc = {0};
	uint32_t no_dpddr = 0;
	uint32_t no_dmem2 = 0,no_dmem1 = 0;
	uint32_t no_peb = 0;
	t_platform_memory_info  *p_mem_info;
	dma_addr_t   mc_mem_phys_base = dpmng_get_mc_mem_base();
	uint64_t mc_dpc_sys_ddr_ladd = 0ULL;
	uint64_t mc_dpc_sys_ddr_hadd = 0ULL;
	/* Check if peb  memory exists for this chip */
	no_peb = (sys_get_desc(SOC_MODULE_PEBM, 0, &peb_desc, NULL) != 0);
	dmem1_desc.core_id = 1;
	/* Check if  dmem1 memory exists for this chip */
	no_dmem1 = sys_get_desc(SOC_MODULE_DMEM, SOC_DB_DMEM_DESC_CORE_ID, &dmem1_desc, NULL) != 0;
	dmem2_desc.core_id = 2;
	/* Check if dmem2 memory exists for this chip */
	no_dmem2 = sys_get_desc(SOC_MODULE_DMEM, SOC_DB_DMEM_DESC_CORE_ID, &dmem2_desc, NULL) != 0;
	/* Check if dp_ddr memory exists for this chip */
	no_dpddr = (sys_get_desc(SOC_MODULE_DPDDR, 0, &dpddr_desc, NULL) != 0);
	/* Check if u-boot or the user allocated custom DDR memory bounds for MC,
	 other than the number of 256MB memory chunks configured via MCFBALR
	 register; the bellow code can change the current MEM_PART_SYSTEM_DDR1
	 size and base address and add a new MEM_PART_SYSTEM_DDR2 for malloc or
	 physical memory allocation. */
	if (dpc_get_mc_sys_ddr_limits(&mc_dpc_sys_ddr_ladd,
			&mc_dpc_sys_ddr_hadd) != 0) {
		mc_dpc_sys_ddr_ladd &= MEM_ALIGN_4K_MASK; // must align to 4K
		// DDR1 part is below MC FW base
		if (dpaa_sys_ddr_base < mc_mem_phys_base) {
			// increase DDR1 size if the lower allocated bound is
			// below the current base
			if (dpaa_sys_ddr_base > mc_dpc_sys_ddr_ladd) {
				dpaa_sys_ddr_size += dpaa_sys_ddr_base - mc_dpc_sys_ddr_ladd;
				dpaa_sys_ddr_base  = mc_dpc_sys_ddr_ladd;
			}
			// create second DDR2 partition if partition is bigger than 4Kb
			if ((mc_dpc_sys_ddr_hadd
				- (mc_mem_phys_base + DPMNG_DDR_BLOCK_SIZE)) >
								MEM_SYS_DDR2_CREATE_LIMIT) {
				mc_sysddr2_ph_base = mc_mem_phys_base + DPMNG_DDR_BLOCK_SIZE;
				mc_sys_ddr2_size =
									mc_dpc_sys_ddr_hadd - mc_sysddr2_ph_base;
				// the MC private space ends at MC base + 256 MB
				mc_sys_ddr2_virt_add_base = (uintptr_t) DPMNG_DDR_BLOCK_SIZE;
			}
		} else { // DDR1 part is above MC FW base
			// create second DDR2 partition if partition is bigger than 4Kb
			if (mc_dpc_sys_ddr_ladd == mc_mem_phys_base &&
				(mc_dpc_sys_ddr_hadd
						- (dpaa_sys_ddr_base + dpaa_sys_ddr_size)) >
												MEM_SYS_DDR2_CREATE_LIMIT) {
				mc_sysddr2_ph_base = dpaa_sys_ddr_base + dpaa_sys_ddr_size;
				mc_sys_ddr2_size = dpaa_sys_ddr_base - dpaa_sys_ddr_size;
				mc_sys_ddr2_virt_add_base =
				(uintptr_t) (mc_sysddr2_ph_base - mc_mem_phys_base);
			}
		}
	}
	pr_debug("MC memory Partitions:\n");
	if( dpmng_mctiny() ) {
		pr_warn("MC uses small memory footprint\n");
	}
	for (int i =0; i < pltfrm->num_of_mem_parts; i++)
	{
		p_mem_info = &mem_partitions[i];
		ASSERT_COND(p_mem_info);
		switch(p_mem_info->mem_partition_id)
		{
		    case MEM_PART_SYSTEM_DDR1_CACHEABLE:
			 p_mem_info->phys_base_addr = mc_mem_phys_base +
				    p_mem_info->virt_base_addr;
			 pr_debug("MC DDR cacheable:virt_add= 0x%x,phys_add=0x%x%08x,size=0x%x\n",
				   p_mem_info->virt_base_addr,
			           (uint32_t)(p_mem_info->phys_base_addr>>32),
				   (uint32_t)(p_mem_info->phys_base_addr),
				   (uint32_t)(p_mem_info->size));
			break;
		    case MEM_PART_SYSTEM_DDR1_NON_CACHEABLE:
			p_mem_info->phys_base_addr = mc_mem_phys_base +
				    p_mem_info->virt_base_addr;
			pr_debug("MC DDR non-cacheable:virt_add= 0x%x,phys_add=0x%x%08x,size=0x%x\n",
	                         p_mem_info->virt_base_addr,
			         (uint32_t)(p_mem_info->phys_base_addr>>32),
                                 (uint32_t)(p_mem_info->phys_base_addr),
		                 (uint32_t)(p_mem_info->size));
			break;
		    case MEM_PART_SYSTEM_DDR1:{
			p_mem_info->phys_base_addr = dpaa_sys_ddr_base;
			p_mem_info->size = dpaa_sys_ddr_size;
			pr_debug(
			"System DDR :virt_add= 0x%x,phys_add=0x%x%08x,size=0x%x%08x\n",
				 p_mem_info->virt_base_addr,
			         (uint32_t)(p_mem_info->phys_base_addr>>32),
			         (uint32_t)(p_mem_info->phys_base_addr),
			         (uint32_t)(p_mem_info->size >> 32),
			         (uint32_t)(p_mem_info->size));
			break;
		    }
		    case MEM_PART_DMEM1:
			if(no_dmem1)
			{
		            p_mem_info->size = 0;
                            pr_debug("No DMEM1 memory \n");
			}
			else
			{
			    p_mem_info->size = dmem1_desc.block_size;
			    p_mem_info->phys_base_addr = dmem1_desc.global_paddr;
			    p_mem_info->virt_base_addr = (uintptr_t)p_mem_info->phys_base_addr;
			    pr_debug("DMEM1 :virt_add= 0x%x,phys_add=0x%x%08x,size=0x%x\n",
				p_mem_info->virt_base_addr,
				(uint32_t)(p_mem_info->phys_base_addr>>32),
				(uint32_t)(p_mem_info->phys_base_addr),
			        (uint32_t)(p_mem_info->size));
			}
		        break;
		    case MEM_PART_DMEM2:
                        if(no_dmem2)
                        {
                            p_mem_info->size = 0;
                            pr_debug("No DMEM2 memory \n");
                        }
                        else
                        {
                            p_mem_info->size = dmem2_desc.block_size;
                            p_mem_info->phys_base_addr = dmem2_desc.global_paddr;
                            p_mem_info->virt_base_addr = (uintptr_t)p_mem_info->phys_base_addr;
                            pr_debug("DMEM2 :virt_add= 0x%x,phys_add=0x%x%08x,size=0x%x\n",
                                    p_mem_info->virt_base_addr,
                                    (uint32_t)(p_mem_info->phys_base_addr>>32),
                                    (uint32_t)(p_mem_info->phys_base_addr),
                                    (uint32_t)(p_mem_info->size));
                        }
                        break;
		    case MEM_PART_PEB:
			if(no_peb)
			{
                            p_mem_info->size = 0;
                            pr_debug("No PEB memory \n");
			}
			else
			{
			    p_mem_info->size = peb_desc.size;
			    p_mem_info->phys_base_addr = peb_desc.paddr;
			    pr_debug("PEB :virt_add= 0x%x,phys_add=0x%x%08x,size=0x%x\n",
			        p_mem_info->virt_base_addr,
				(uint32_t)(p_mem_info->phys_base_addr>>32),
				(uint32_t)(p_mem_info->phys_base_addr),
				(uint32_t)(p_mem_info->size));
			}
			break;
		    case MEM_PART_DP_DDR:
		    {
			if(no_dpddr)
			{
				p_mem_info->size = 0;
				pr_debug("No DP-DDR memory \n");
			}
			else
			{
			    p_mem_info->size = dpddr_desc.size;
			    p_mem_info->phys_base_addr = dpddr_desc.paddr;
			    pr_debug("DP-DDR :virt_add= 0x%x,phys_add=0x%x%08x,size=0x%x%08x\n",
				p_mem_info->virt_base_addr,
			    (uint32_t)(p_mem_info->phys_base_addr>>32),
				(uint32_t)(p_mem_info->phys_base_addr),
			    (uint32_t)(p_mem_info->size>>32),
			    (uint32_t)(p_mem_info->size));
			}
			break;
		    }// case
		    case MEM_PART_SYSTEM_DDR2: {
				if (mc_sys_ddr2_size > 0) {
					p_mem_info->phys_base_addr = mc_sysddr2_ph_base;
					p_mem_info->size = mc_sys_ddr2_size;
					p_mem_info->virt_base_addr = mc_sys_ddr2_virt_add_base;
					pr_debug("System DDR partition 2: virt_add= 0x%x,phys_add=0x%x%08x,size=0x%x\n",
						 p_mem_info->virt_base_addr,
							 (uint32_t)(p_mem_info->phys_base_addr>>32),
							 (uint32_t)(p_mem_info->phys_base_addr),
							 (uint32_t)(p_mem_info->size));
				}
			break;
		    } //case
		} // switch
	}
	return 0;
}
/*****************************************************************************/
static int build_virt2phys_mapping(t_platform  *pltfrm)
{
	struct mem_desc mc_ddr_desc = {0};
	dma_addr_t   mc_mem_phys_base = dpmng_get_mc_mem_base();
	t_platform_region_info  region_info[] = VIRT_2_PHYS_MAP;
	int regions_size = ARRAY_SIZE(region_info);
	int rc = 0,err = 0;
	if (0 != (rc = sys_get_desc(SOC_MODULE_MC_DDR, 0, &mc_ddr_desc, NULL)))
		return rc;
	for(int i = 0; i < regions_size; i++)
	{
		switch(region_info[i].mem_region_id){
		    case MEM_RGN_MC_DDR:
                        region_info[i].size = mc_ddr_desc.size;
                        region_info[i].phys_base_addr = mc_mem_phys_base;
                        region_info[i].virt_base_addr = (uint32_t)mc_ddr_desc.paddr;
                    break;
		}
	}
	for(int i = 0; i < regions_size; i++)
	{
		err = sys_register_virt_mem_mapping(region_info[i].virt_base_addr,
				                      region_info[i].phys_base_addr,
				                      region_info[i].size);
		if (err != 0)
		{
			 pr_err("MAJOR coundn't register virt map virt_base_addr = 0x%x, "
					 "phys_base_addr = 0x%x\n",region_info[i].virt_base_addr,
					 region_info[i].phys_base_addr);
			 return err;
		}
	}
	return 0;
}
/*****************************************************************************/
static int pltfrm_free_mem_partitions_cb(void * h_platform)
{
	t_platform *pltfrm = (t_platform *)h_platform;
	int index = -1;
	t_platform_memory_info  *p_mem_info = NULL;

	ASSERT_COND(pltfrm);

	index = (int)pltfrm->num_of_mem_parts;

	while ((--index) >= 0) {
		sys_unregister_virt_mem_mapping(pltfrm->param.mem_info[index].virt_base_addr);

		if (pltfrm->registered_partitions[index])
		{
			sys_unregister_mem_partition(pltfrm->registered_partitions[index]);
			
			/* mark as unregistered*/
			pltfrm->registered_partitions[index] = 0;
		}
	}

	return 0;
}

/*****************************************************************************/
static int pltfrm_init_private_cb(void * h_platform)
{
	int err;
	t_platform *pltfrm = (t_platform *)h_platform;
	ASSERT_COND(pltfrm);

	if (sys_is_master_core()) {
		/* Register Platform CLI commands */
#if 0
		if (fsl_os_cli_is_available())
			register_cli_commands(pltfrm);
#endif
	}

	err = tasklet_module_init(100, MEM_PART_SYSTEM_DDR1_CACHEABLE);
	if(err) {
		return err;
	}

	if (sys_is_master_core()) {
		/* Print platform information */
		print_platform_info(pltfrm);
	}
	sys_barrier();
	return 0;
}

/*****************************************************************************/
static int pltfrm_free_private_cb(void * h_platform)
{
	t_platform  *pltfrm = (t_platform *)h_platform;

	ASSERT_COND(pltfrm);

	if (sys_is_master_core()) {
		/* Unregister Platform CLI commands */
#if 0
		if (fsl_os_cli_is_available())
			unregister_cli_commands(pltfrm);
#endif
	}

	return 0;
}


static uint64_t serdes_set_info(void)
{
	int iter = 0, i, j;
	struct serdes_desc serdes_desc = { 0 };
	struct dcfg_desc dcfg_desc = { 0 };
	struct serdes_mac_info mac_info = { 0 };
	uint64_t valid_macs = 0;
	uint8_t master_lane = 0, no_lanes, sd_proto = 0;	/* Serdes protocol - read from RCW */
	enum enet_interface pssr0_enet_if;

	sys_get_desc(SOC_MODULE_DCFG,
			SOC_DB_NO_MATCH_FIELDS,
			&dcfg_desc,
			NULL);

	while (soc_db_get_desc(SOC_MODULE_SERDES,
	                       SOC_DB_NO_MATCH_FIELDS,
	                       &serdes_desc, &iter) == 0) {
		/* workaround for quitting SerDes configuration in simulator */
#if 0
		if (dcfg_get_serdes_protocol(serdes_desc.rcwsr_id, serdes_desc.rcwsr_mask) == 0)
		{
			pr_info("No SerDes protocol\n", serdes_desc.id);
			continue;
		}
#endif
		if (dcfg_desc.sd[serdes_desc.id].valid)
			sd_proto = (uint8_t)dcfg_get_serdes_protocol(dcfg_desc.sd[serdes_desc.id].rcwsr_id,
											dcfg_desc.sd[serdes_desc.id].rcwsr_mask);

		for (i = 0; i < serdes_desc.num_lanes; i++) {
			/* Read SerDes information */
			memset(&mac_info, 0, sizeof (struct serdes_mac_info));
			master_lane = serdes_desc.master_lane_select[i];
			no_lanes = (uint8_t)i;
			serdes_get_mac_info(&serdes_desc, &mac_info, &i, sd_proto);
			no_lanes = (uint8_t)i - no_lanes + 1;
			pssr0_enet_if = mac_info.enet_if;

			/* Fill SoC */
			if (mac_info.valid) {
				/* read DPC in case the user wants to change the interface from SerDes*/
				dpc_get_mac_info(mac_info.mac_id, 0, 0, 0,
						(uint32_t *)&mac_info.enet_if, &mac_info.autoneg,  &mac_info.debug_link_check, &mac_info.rate);

				/* if DPC enet_if property is present and pssr0 representation of initial and desired
				 * protocols is different, check if conversion is possible */
				if (serdes_enet_to_pssr0(pssr0_enet_if) != serdes_enet_to_pssr0(mac_info.enet_if)) {
					if (!serdes_convert_enet_if(&serdes_desc, &mac_info, sd_proto, pssr0_enet_if)) {
						/* in case of failure, to be displayed later in dpmac_hw_init */
						mac_info.enet_prev = mac_info.enet_if;
						mac_info.enet_if = pssr0_enet_if;
					}
				}

				soc_db_mac_set_type(mac_info.eiop_id,
				                    mac_info.mac_id,
				                    mac_info.enet_if,
				                    mac_info.autoneg,
				                    mac_info.debug_link_check,
				                    mac_info.rate,
				                    serdes_desc.id,
				                    master_lane,
				                    no_lanes,
				                    mac_info.converted,
				                    mac_info.enet_prev);

				valid_macs |= (1 << (mac_info.mac_id - 1));
				/* QSGMII has 4 MACs on a single lane, when we read
				 * information from SerDes, we read only information
				 * about the first QSGMII port, we need to update the
				 * other QSMGII ports in SoC data base.
				 */
				if (mac_info.enet_if == FSL_ENET_IF_QSGMII) {
					for (j = 1; j < 4; j++) {
						soc_db_mac_set_type(
							mac_info.eiop_id,
							mac_info.mac_id + j,
							mac_info.enet_if,
							mac_info.autoneg,
							mac_info.debug_link_check,
							mac_info.rate,
							serdes_desc.id,
							master_lane,
							no_lanes,
							mac_info.converted,
		                    mac_info.enet_prev);

						valid_macs |= (1 << (mac_info.mac_id - 1 + j));
					}
				}
			}
		}
		memset(&serdes_desc, 0, sizeof(serdes_desc));
	}

	return valid_macs;

}

static void init_soc_dynamic_info()
{
	uint32_t mask = 0;
	struct eiop_memac_desc memac_desc = {0}, tmp_desc = {0};
	struct eiop_memac_desc *desc;
	struct eiop_desc eiop_desc = {0};
	struct dcfg_desc dcfg_desc = {0};
	int iter = 0, i;
	uint64_t enabled_macs = 0, valid_macs = 0, all_soc_db_macs = 0;
	uint64_t dp_ddr_size = 0;
	int err;

	if (dcfg_is_unavailable(DCFG_DEVDIS_DCE, &mask))
		soc_db_dce_disable();

	if (dcfg_is_unavailable(DCFG_DEVDIS_SEC, &mask))
		soc_db_sec_disable();

	if (dcfg_is_unavailable(DCFG_DEVDIS_DPDDR, &mask))
		soc_db_dpddr_disable();
	else if (dpc_get_dpddr_size(&dp_ddr_size) != 0) {
		if (dp_ddr_size == 0)
			soc_db_dpddr_disable();
		else
			soc_db_dpddr_set_size(dp_ddr_size);
	}

	if (dcfg_is_unavailable(DCFG_DEVDIS_PEBM, &mask))
		soc_db_pebm_disable();

	if (dcfg_is_unavailable(DCFG_DEVDIS_AIOP, &mask))
		soc_db_aiops_disable(mask);

	if (dcfg_is_unavailable(DCFG_DEVDIS_EIOP, &mask))
		soc_db_eiops_disable(mask);

	if (dcfg_is_unavailable(DCFG_DEVDIS_DUART, &mask))
		soc_db_duarts_disable(mask);

	if (dcfg_is_unavailable(DCFG_DEVDIS_MAC, &mask))
		soc_db_macs_disable(0, mask);

	while (soc_db_get_desc(SOC_MODULE_EIOP_MEMAC,
		                       SOC_DB_NO_MATCH_FIELDS,
		                       &memac_desc, &iter) == 0) {
		dpc_get_mac_info(memac_desc.mac_id, &memac_desc.disable,
					&memac_desc.link_type,
					&memac_desc.phy_id, 0, 0, &memac_desc.debug_link_check, &memac_desc.rate);

		/* Mark enabled MACs */
		if (!memac_desc.disable)
			enabled_macs |= 1 << memac_desc.mac_id;
		
		all_soc_db_macs |= 1 << memac_desc.mac_id;
		/* Update link type */
		tmp_desc.mac_id = memac_desc.mac_id;
		tmp_desc.eiop_id = memac_desc.eiop_id;
		err = soc_db_get_desc(
			SOC_MODULE_EIOP_MEMAC,
			SOC_DB_MAC_DESC_ID | SOC_DB_MAC_DESC_EIOP_ID | SOC_DB_SET_VAL,
			&tmp_desc, (int *)&desc);
		if( !err ) {
			desc->link_type = memac_desc.link_type;
			desc->debug_link_check = memac_desc.debug_link_check;
		}
		memset(&memac_desc, 0, sizeof (memac_desc));
	}
		
	enabled_macs = enabled_macs >> 1;
	all_soc_db_macs = all_soc_db_macs >> 1;

	/*
	 * LS1088:
	 * EC1 pin controls DPMAC@4 -> RGMII port 1
	 * EC2 pin controls DPMAC@5 -> RGMII port 2
	 *
	 * LS1575:
	 * EC1 pin controls DPMAC@4 -> RGMII port 1
	 *
	 * LX2160
	 * EC1 pin controls DPMAC@17 -> RGMII port 1
	 * EC2 pin controls DPMAC@18 -> RGMII port 2
	 *
	 * TO DO
	 * LX2162
	 * A single RGMII port is available. Which one of them?
	 *
	 * According to RM a value of 0 of the EC1 or EC2 fields means
	 * that RGMII1 and/or RGMII2 ports are enabled.
	 *
	 *E.g. LS1088
	 * EC1 Pin Configuration:
	 * 			Configures the functionality of the EC1 pins
	 * 			0b000 - WRIOP MAC4 RGMII
	 * 			0b001 - GPIO2,GPIO4
	 *
	 * EC2 Pin Configuration:
	 * 			Configures the functionality of the EC2 pins
	 * 			0b000 - WRIOP MAC5 RGMII
	 * 			0b001 - GPIO4
	 * 			0b010 - 1588
	 */
	sys_get_desc(SOC_MODULE_DCFG,
			SOC_DB_NO_MATCH_FIELDS,
			&dcfg_desc,
			NULL);

	/* print information about EC2_PMUX 1588 configuration
	 * On LS2088, there is no EC, and 1588 is always wired
	 */
	if ((dcfg_desc.ec[1].valid && (dcfg_get_ec_pmux(&dcfg_desc, 1) != 2)))
		pr_info("IEEE 1588 is NOT wired to output\n");
	else
		pr_info("IEEE 1588 is wired to output\n");

	for (i = 0; i < MAX_EC_CFG; i++) {
		if (dcfg_desc.ec[i].valid && dcfg_has_rgmii(&dcfg_desc, i)) {
			memac_desc.mac_id = dcfg_desc.ec[i].port_id;

			soc_db_get_desc(SOC_MODULE_EIOP_MEMAC,
					SOC_DB_MAC_DESC_ID | SOC_DB_SET_VAL,
					&memac_desc,
					(int *)&desc);

			desc->enet_if = FSL_ENET_IF_RGMII;
			/* Max speed of RGMII port is 1G */
			desc->rate = 1000;

			/* init registry memory map */
			/* desc->type comes from SoC DB */
			desc->mem_map = soc_db_select_mac_memmap(desc->type);

			/* Add RGMII port to "valid" MACs */
			valid_macs |= 1<<(memac_desc.mac_id - 1);
		}
	}

	/* set SerDes info in MAC descriptors, "valid" means MAC was found in SerDes
	 * For protocols which enables both SerDes protocol and RGMII through ECx_PMUX
	 * valid_macs won't be set here because RGMII has precedence
	 */
	valid_macs |= serdes_set_info();

#ifdef ENGR00352474
	if (IS_SIM)
		valid_macs = 0xffff;
#endif /* ENGR00352474 */
	/* Disable MACs not found in SerDes or marked as PHY_NONE in DPC file.
	 * If DPL will try to connect this MAC to DPNI object the processing will fail;
	 * If the restool attempts to create a DPMAC object using this ID the command will fail; */
	soc_db_macs_disable(0, (uint32_t)(~(valid_macs & enabled_macs) & all_soc_db_macs));

	if (!IS_SIM) {
		/* Salvage selected physical port as recycle ports.
		 * This will be done by copying them in soc_db as RP
		 */
		soc_db_salvage_pp_as_rp(0);

		/* Remove unused ports from SoC DB */
		soc_db_remove_unused_ports(eiop_desc.eiop_id);

		soc_db_ceetm_rate_balance(eiop_desc.eiop_id);
	}
}

/*****************************************************************************/
int platform_early_init(void)
{
	memset(&s_pltfrm, 0, sizeof(t_platform));

	/*------------------------------------------------------*/
	/* Initialize PPC interrupts vector                     */
	/*------------------------------------------------------*/
	booke_generic_irq_init();

	if (core_get_id() == 0) {
		/* soc_db init */
		dcfg_get_revision(&s_pltfrm.soc_info.rev.major,
					&s_pltfrm.soc_info.rev.minor,
					&s_pltfrm.soc_info.rev.system_version);

		return soc_db_select(&s_pltfrm.soc_info.rev, s_pltfrm.soc_info.name);
	}

	return 0;
}

int platform_init(struct platform_param    *pltfrm_param,
                  t_platform_ops           *pltfrm_ops)
{
	int             i;

	if((!pltfrm_param) || (!pltfrm_ops)) {
		pr_crit("Null pointer");
		return -ENODEV;
	}

	/* Store configuration parameters */
	memcpy(&(s_pltfrm.param), pltfrm_param, sizeof(struct platform_param));

	/* get SoC dynamic info and set soc_db dynamic parameters. */
	init_soc_dynamic_info();

	/* read info from DCFG */
	s_pltfrm.platform_clk = dcfg_get_platform_clk();

	if (IS_SIM) {
		if (s_pltfrm.platform_clk == 0) {
			s_pltfrm.platform_clk = 800000;
			pr_err("rcwsr return 0, platform clock frequency was set to %d KHz\n", s_pltfrm.platform_clk);
		}
	}

	s_pltfrm.num_of_mem_parts = s_pltfrm.param.num_of_mem_parts;

	/* Store LDPAA CCSR base (for convenience) */
	s_pltfrm.ccsr_base = LDPAA_CCSR_OFF;

	/* Initialize platform operations structure */
	pltfrm_ops->h_platform              = &s_pltfrm;
	pltfrm_ops->f_enable_local_irq      = pltfrm_enable_local_irq_cb;
	pltfrm_ops->f_disable_local_irq     = pltfrm_disable_local_irq_cb;

	memset(pltfrm_ops->modules, 0, sizeof(struct pltform_module_desc) * PLTFORM_NUM_OF_INIT_MODULES);

	/*
	 * Note: order of execution is according to the array placement
	 */
	i = 0;
	pltfrm_ops->modules[i++] = (struct pltform_module_desc){.init = pltfrm_init_core_cb,           .free = pltfrm_free_core_cb,           .is_single_core = PLATFORM_MULTI_CORE};
	pltfrm_ops->modules[i++] = (struct pltform_module_desc){.init = pltfrm_init_intr_ctrl_cb,      .free = pltfrm_free_intr_ctrl_cb,      .is_single_core = PLATFORM_SINGLE_CORE};
	pltfrm_ops->modules[i++] = (struct pltform_module_desc){.init = pltfrm_init_timer_cb,          .free = pltfrm_free_timer_cb,          .is_single_core = PLATFORM_MULTI_CORE};
	pltfrm_ops->modules[i++] = (struct pltform_module_desc){.init = pltfrm_init_mem_partitions_cb, .free = pltfrm_free_mem_partitions_cb, .is_single_core = PLATFORM_SINGLE_CORE};
	pltfrm_ops->modules[i++] = (struct pltform_module_desc){.init = pltfrm_init_console_cb,        .free = pltfrm_free_console_cb,        .is_single_core = PLATFORM_MULTI_CORE};
	/* mpu initialization must be after memory partitions table is ready. the table is built in f_init_mem_partitions */
	pltfrm_ops->modules[i++] = (struct pltform_module_desc){.init = pltfrm_init_mpu_cb,            .free = NULL,                          .is_single_core = PLATFORM_MULTI_CORE};
	pltfrm_ops->modules[i++] = (struct pltform_module_desc){.init = pltfrm_init_edma_ctrl_cb,      .free = pltfrm_free_edma_ctrl_cb,      .is_single_core = PLATFORM_MULTI_CORE};
	pltfrm_ops->modules[i++] = (struct pltform_module_desc){.init = pltfrm_init_private_cb,        .free = pltfrm_free_private_cb,        .is_single_core = PLATFORM_MULTI_CORE};
	ASSERT_COND(i <= PLTFORM_NUM_OF_INIT_MODULES);

	return 0;
}

/*****************************************************************************/
int platform_free(void * h_platform)
{
	/* h_platform is not allocated by malloc, no need to free */
	return 0;
}


/*****************************************************************************/
uint32_t platform_get_clk(void * h_platform)
{
	t_platform  *pltfrm = (t_platform *)h_platform;
	if(!pltfrm) {
		pr_info("no device\n");
		return 0;
	}
	/*
	 * MC gets clock of (platform clk / 1) see LS2085ARM_RM.pdf
	 */
	return (pltfrm->platform_clk);
}

/*****************************************************************************/
int platform_enable_console(void * h_platform)
{
	t_platform          *pltfrm = (t_platform *)h_platform;
	t_duart_uart_param  duart_uart_param;
	void *        uart;
	int           err = 0;
	struct uart_desc uart_desc;

	if(!pltfrm) {
		pr_crit("Null pointer");
		return -ENODEV;
	}

	if (pltfrm->param.console_type == PLTFRM_CONSOLE_NONE) /*if console none print to buffer*/
		return -ENAVAIL;

	if(pltfrm->param.console_type != PLTFRM_CONSOLE_DUART) {
		pr_crit("Console not supported");
		return -ENOTSUP;
	}

	/* Fill DUART configuration parameters */
	memset(&uart_desc, 0, sizeof(uart_desc));
	uart_desc.uart_id = pltfrm->param.console_id;
	sys_get_desc(SOC_MODULE_UART, SOC_DB_UART_DESC_ID, &uart_desc, NULL);

	duart_uart_param.base_address = (uintptr_t)uart_desc.vaddr;

	duart_uart_param.irq                = NO_IRQ;
	/* Each UART is clocked by the platform clock/2 */
	duart_uart_param.system_clock_mhz   =
			((platform_get_clk(pltfrm) / 1000) / 2 / uart_desc.clk_div);

	duart_uart_param.baud_rate          = 115200;
	duart_uart_param.parity             = E_DUART_PARITY_NONE;
	duart_uart_param.data_bits          = E_DUART_DATA_BITS_8;
	duart_uart_param.stop_bits          = E_DUART_STOP_BITS_1;
	duart_uart_param.flow_control       = E_DUART_NO_FLOW_CONTROL;
	duart_uart_param.h_app              = NULL;
	duart_uart_param.f_low_space_alert  = NULL;
	duart_uart_param.f_exceptions       = NULL;
	duart_uart_param.f_tx_conf          = NULL;

	/* Configure and initialize DUART driver */
	uart = duart_config(&duart_uart_param);
	if (!uart) {
		pr_err("resource is unavailable: DUART\n");
		return -EAGAIN;
	}

	/* Configure polling mode */
	err = duart_config_poll_mode(uart, 1);
	if (err != 0) {
		pr_err("duart config poll failed\n");
		return err;
	}

	/* Convert end-of-line indicators */
	err = duart_config_poll_lf2crlf(uart, 1);
	if (err != 0) {
		pr_err("duart config poll failed\n");
		return err;
	}

	/* Prevent blocking */
	err = duart_config_rx_timeout(uart, 0);
	if (err != 0) {
		pr_err("duart config rx timeout failed\n");
		return err;
	}

	err = duart_init(uart);
	if (err != 0) {
		pr_err("duart init failed\n");
		return err;
	}

	/* Lock DUART handle in system */
	err = sys_add_handle(uart, FSL_MOD_UART, 1, pltfrm->param.console_id);
	if (err != 0) {
		pr_err("add handle failed\n");
		return err;
	}

	pltfrm->uart = uart;
	pltfrm->duart_id = pltfrm->param.console_id;

	/*Try to print one character - if failed, disable uart*/
	if(duart_tx(uart, (uint8_t *) "#", 1)) /*Error while trying to print character*/
	{
		return -ENAVAIL;
	}
	return 0;
}

/*****************************************************************************/
int platform_disable_console(void * h_platform)
{
	t_platform  *pltfrm = (t_platform *)h_platform;

	if(!pltfrm) {
		pr_crit("Null pointer");
		return -ENODEV;
	}

	/* Unregister platform console */
	/* errCode = SYS_UnregisterConsole();
if (errCode != 0)
	RETURN_ERROR(MAJOR, errCode, NO_MSG);*/

	if (pltfrm->uart)
	{
		/* Unlock DUART handle in system */
		sys_remove_handle(FSL_MOD_UART, 1, pltfrm->duart_id);

		/* Free DUART driver */
		duart_free(pltfrm->uart);
		pltfrm->uart = NULL;
	}

	return 0;
}
