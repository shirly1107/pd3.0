/*
 * Copyright 2013-2020 NXP
 */

/**************************************************************************//**
 @File          fsl_soc.h

 @Description   Definitions for the part (integration) module.
 *//***************************************************************************/

#ifndef __FSL_SOC_H
#define __FSL_SOC_H

#include "fsl_types.h"
#include "fsl_gen.h"
#include "fsl_soc_arch.h"

/* Adding an enum below requires updating "mod_info" array in soc_db.h */
enum soc_module {
	SOC_MODULE_MC,
	SOC_MODULE_PEBM,
	SOC_MODULE_DPDDR,
	SOC_MODULE_MC_DDR,
	SOC_MODULE_DMEM,
	SOC_MODULE_MC_BT,
	SOC_MODULE_MC_PORTAL,
	SOC_MODULE_SOC_MC_PORTAL,

	SOC_MODULE_EIOP,
	SOC_MODULE_EIOP_IFP,
	SOC_MODULE_EIOP_PORT,
	SOC_MODULE_EIOP_MEMAC,
	SOC_MODULE_EIOP_RTC,
	SOC_MODULE_EIOP_PPORT_CON,
	SOC_MODULE_EIOP_VPORT_CON,

	SOC_MODULE_CTLU,

	SOC_MODULE_AIOP,

	SOC_MODULE_UART,

	SOC_MODULE_CPM,

	SOC_MODULE_LCFG,

	SOC_MODULE_PIC,

	SOC_MODULE_EDMA,
	SOC_MODULE_EDMA_BLOCK,

	SOC_MODULE_QBMAN,
	SOC_MODULE_QBMAN_PORTAL,

	SOC_MODULE_SEC,

	SOC_MODULE_QDMA,

	SOC_MODULE_DCE,

	SOC_MODULE_SERDES,

	SOC_MODULE_MDIO,

	SOC_MODULE_DCFG,

	SOC_MODULE_DPPMU
};

/**************************************************************************//**
 @Description   Module types.
 	 	 The number of hierarchies and order of the id's is defined
 	 	 for each module below
 *//***************************************************************************/
enum fsl_module {
	FSL_MOD_SOC = 0,

	FSL_MOD_CMDIF_SRV,
	FSL_MOD_CMDIF_CL_REGS,
	FSL_MOD_RESMAN, /* 0 */
	FSL_MOD_DPRC,   /* 1 (dprc id) */
	FSL_MOD_DPNI,   /* 1 (dpni id) */
	FSL_MOD_DPIO,  /* 1 (dpio id) */
	FSL_MOD_DPCON,
	FSL_MOD_DPBP,  /* 1 (dpbp id) */
	FSL_MOD_DPSW,  /* 1 (dpsw id) */
	FSL_MOD_DPDMUX,  /* 1 (dpmux id) */
	FSL_MOD_DPLAG,
	FSL_MOD_LINKMAN,  	/* 2.0 */
	FSL_MOD_DPMAC,/* 1 (dpmac id) */
	FSL_MOD_DPMNG,
	FSL_MOD_DPCI,
	FSL_MOD_DPDCEI,
	FSL_MOD_DPSECI,
	FSL_MOD_DPDMAI,
	FSL_MOD_DPAIOP,
	FSL_MOD_DPMCP,
	FSL_MOD_DPDBG,
	FSL_MOD_DPRTC,
	FSL_MOD_UART,/* 1 (uart id) */
	FSL_MOD_PIC, /**< PIC */
	FSL_MOD_EDMA, /**< EDMA: 3, (edma id, edma block id, queue id) */
	FSL_MOD_EDMA_BLOCK, /**< EDMA BLOCK*/
	FSL_MOD_EDMA_BLOCK_QUEUE, /**< EDMA QUEUE*/

	FSL_MOD_QBMAN, /**< QBMan module */
	FSL_MOD_QBMAN_PORTAL,

	FSL_MOD_EIOP, /**< Ethernet manager module: 1 (eiop id) */
	FSL_MOD_EIOP_IFP, /**< Ethernet manager IFP module */
	FSL_MOD_EIOP_RTC, /**< EIOP 1588 */
	FSL_MOD_EIOP_EXT_MDIO, /**< External MDO module */

	FSL_MOD_AIOP_TILE, /**< 1 (AIOP id) */
	FSL_MOD_CTLU, /**<  CTLU module: 2 (iop id, ctlu type) */
	FSL_MOD_PARSER, /**<  Parser 2 (iop id, ctlu type) */
	FSL_MOD_POLICIES_MNG, /**< Policies manager 2 (iop id, ctlu type)*/
	FSL_MOD_KG, /**<  Key generator 2 (iop id, ctlu type)*/
	FSL_MOD_TABLES_MNG, /**<  Tables manager 2 (iop id, ctlu type)*/
	FSL_MOD_POLICER, /**<  Policer 2 (iop id, ctlu type)*/
	FSL_MOD_QoS_MNG, /**<  QoS 2  (iop id, ctlu type)*/
	FSL_MOD_SEC_GEN, /**< SEC General registers      */
	FSL_MOD_SEC_QI, /**< SEC QI registers           */
	FSL_MOD_SEC_JQ, /**< SEC JQ registers         */
	FSL_MOD_SEC_RTIC, /**< SEC RTIC registers         */
	FSL_MOD_SEC_DECO_CCB, /**< SEC DECO/CCB registers */

	FSL_MOD_MC, /* 0 */
	FSL_MOD_MC_PORTAL, /* 1 (portal id) */
	FSL_MOD_CPM,

	FSL_MOD_DTC, /**< layout: 0 */
	FSL_MOD_DPC, /**< Pre - initialization configurations */
	/*FSL_MOD_CTLU_DRV, /**< 0 */

	FSL_MOD_SOC_MC_PORTAL, /**< MC portals in SoC address map ( for AIOP or GPP)*/

	FSL_MOD_DCE,

	FSL_MOD_PARSER_CTRL,	/** HW Parsers */
	FSL_MOD_DPSPARSER,	/** Soft Parser */

	FSL_MOD_DUMMY_LAST
};

/*****************************************************************************
 INTEGRATION-SPECIFIC MODULE CODES
******************************************************************************/
#define MODULE_UNKNOWN          0x00000000
#define MODULE_SLAB             0x00010000
#define MODULE_SLOB             0x00020000
#define MODULE_SOC_PLATFORM     0x00030000
#define MODULE_DUART            0x00050000

#define INTERNAL_PERIPH_OFF_PORTALS_MC(_prtl) \
    (INTERNAL_PERIPH_OFF_PORTALS_MC_AREA + INTERNAL_PERIPH_MC_PORTAL_ALIGNMENT * (_prtl))

/*!
 * @name Match option possibilities for each SOC_DB module
 */
/* DO NOT USE !!! */
#define SOC_DB_RESERVED 			0x00000001



#define SOC_DB_NO_MATCH_FIELDS 			0x00000000

/* AIOP */
#define SOC_DB_AIOP_TILE_DESC_ID 		0x80000000

/* EIOP */
#define SOC_DB_EIOP_DESC_ID 			0x80000000

/* IFP */
#define SOC_DB_IFP_DESC_ID 			0x80000000
#define SOC_DB_IFP_DESC_EIOP_ID 		0x40000000

/* MAC */
#define SOC_DB_MAC_DESC_ID 			0x80000000
#define SOC_DB_MAC_DESC_EIOP_ID 		0x40000000

/* SERDES */
#define SOC_DB_SERDES_DESC_ID 			0x80000000

/* MDIO */
#define SOC_DB_MDIO_DESC_ID 			0x80000000
#define SOC_DB_MDIO_DESC_EIOP_ID 		0x40000000
#define SOC_DB_MDIO_DESC_ENET_IF 		0x20000000

/* EIOP PORT */
#define SOC_DB_PORT_DESC_ID 			0x80000000
#define SOC_DB_PORT_DESC_TYPE 			0x40000000
#define SOC_DB_PORT_DESC_EIOP_ID		0x20000000

/* EIOP PPORT CONNECTION */
#define SOC_DB_PORT_CON_DESC_ID 		0x80000000
#define SOC_DB_PORT_CON_DESC_EIOP_ID	        0x40000000
#define SOC_DB_PORT_CON_DESC_DCP_ID		0x20000000
#define SOC_DB_PORT_CON_DESC_MAC_ID		0x10000000
#define SOC_DB_PORT_CON_DESC_CEETM_ID	0x08000000

/* CTLU */
#define SOC_DB_CTLU_DESC_TYPE 			0x80000000
#define SOC_DB_CTLU_DESC_IOP_ID 		0x40000000

/* EIOP RTC */
#define SOC_DB_RTC_DESC_EIOP_ID 		0x80000000

/* MC BT */
#define SOC_DB_MC_BT_DESC_CORE_ID		0x80000000

/* CPM */
#define SOC_DB_CPM_DESC_CORE_ID			0x80000000

/* DMEM */
#define SOC_DB_DMEM_DESC_CORE_ID		0x80000000

/* QBMAN PORTAL */
#define SOC_DB_QBMAN_PORTAL_DESC_ID		0x80000000
#define SOC_DB_QBMAN_PORTAL_DESC_QBMAN_ID	0x40000000

/* UART */
#define SOC_DB_UART_DESC_ID			0x80000000

/* MC PORTAL */
#define SOC_DB_MC_PORTAL_DESC_ID		0x80000000

/* MC PORTAL */
#define SOC_DB_SOC_MC_PORTAL_DESC_ID		0x80000000
#define SOC_DB_SOC_MC_PORTAL_DESC_PADDR		0x40000000


/* EDMA */
#define SOC_DB_EDMA_DESC_ID			0x80000000

/* EDMA BLOCK */
#define SOC_DB_EDMA_BLOCK_DESC_ID		0x80000000
//#define SOC_DB_EDMA_BLOCK_DESC_EDMA_ID	0x40000000
/* @} */

#define SOC_DB_SET_VAL		0x00000001

/**
* @brief  	This function gets a requested descriptor with all its fields.
* 		If called repeatedly with increasing "iter" value, will return
* 		all the descriptors of this module (with the restriction of
* 		"match_options" - if used).
*
* @param[in]   		module - The module for which the descriptor is required.
* @param[in]   		match_options - An ORed list of module's identifiers.
* 			    		One of the module specific list of
* 			    		"SOC_DB_<module>_DESC_<identifier>".
* 			    		Use SOC_DB_NO_MATCH_FIELDS to rely on
* 			    		"iter" only.
* @param[in/out]	user_desc - A pointer to a module's descriptor. This
* 			    		descriptor may be fully cleared or
* 			    		contain some identifying fields to be
* 			    		matched by the routine.
* @param[in/out]	iter 	  - The sequential id of the descriptor. Used
* 					to repeatedly call the routine to obtain
* 					all descriptors for a specific module.
*
* @returns      A handle to the initialized CTLU module object
*/
int soc_db_get_desc(enum soc_module module,
                    int match_options,
                    void *user_desc,
                    int *iter);

uint32_t soc_db_get_sys_clk(void);
uint32_t soc_db_get_platform_clk(void);
int  soc_db_init(void);
void soc_db_mac_set_type(int eiop_id,
                         int mac_id,
                         uint32_t enet_if,
                         uint8_t autoneg,
                         uint8_t debug_link_check,
                         uint32_t rate,
                         int serdes_id,
                         uint8_t master_lane,
                         uint8_t no_lanes,
                         uint32_t converted,
                         uint32_t enet_prev);
void soc_db_dce_disable();
void soc_db_sec_disable();
void soc_db_macs_disable(int eiop_id, uint32_t mac_mask);
void soc_db_salvage_pp_as_rp(int eiop_id);
void soc_db_remove_unused_ports(int eiop_id);
int soc_db_ceetm_rate_balance(int eiop_id);
void soc_db_aiops_disable(uint32_t aiop_mask);
void soc_db_eiops_disable(uint32_t eiop_mask);

void soc_db_duarts_disable(uint32_t uarts_mask);
void soc_db_pebm_disable();
void soc_db_dpddr_disable();
void soc_db_dpddr_set_size(uint64_t dpddr_size);
void soc_db_update(int i);

struct soc_rev {
	uint32_t system_version;
	uint8_t major;
	uint8_t minor;
} ;

int soc_db_select(struct soc_rev *soc_rev, char *name);
int soc_db_is_lx2162_package();
int soc_db_is_lx2_rev2();
int soc_db_get_recycle_port_bandwidth();

uint32_t *soc_db_select_mac_memmap(int type);

int soc_db_use_recycle_port_timestamp();

#endif /* __FSL_SOC_H */

