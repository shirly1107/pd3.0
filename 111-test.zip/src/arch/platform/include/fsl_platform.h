/*
 * Copyright 2013-2020 NXP
 */

/******************************************************************************
 @File          fsl_platform.h

 @Description   Prototypes, externals and typedefs for platform routines
****************************************************************************/
#ifndef __FSL_PLATFORM_H
#define __FSL_PLATFORM_H

#include "fsl_types.h"
#include "fsl_errors.h"
#include "fsl_soc.h"
#include "fsl_dcfg.h"

#define PLATFORM_SINGLE_CORE 1
#define PLATFORM_MULTI_CORE 0

#define PLTFORM_NUM_OF_INIT_MODULES 8

/**************************************************************************//**
 @Group         platform_grp PLATFORM Application Programming Interface

 @Description   Generic Platform API, that must be implemented by each
                specific platform.

 @{
*//***************************************************************************/

#define PLATFORM_IO_MODE_ANY            (~0)    /**< Unspecified I/O mode */

#define MAX_CHIP_NAME_LEN               10   /**< Maximum chip name length (including null character) */

/**************************************************************************//**
 @Description   Cache Operation Mode
*//***************************************************************************/
typedef enum cache_mode {
    E_CACHE_MODE_DISABLED       = 0x00000000,   /**< Cache is disabled */
    E_CACHE_MODE_DATA_ONLY      = 0x00000001,   /**< Cache is enabled for data only */
    E_CACHE_MODE_INST_ONLY      = 0x00000002,   /**< Cache is enabled for instructions only */
    E_CACHE_MODE_DATA_AND_INST  = 0x00000003    /**< Cache is enabled for data and instructions */
} e_cache_mode;

/**************************************************************************//**
 @Description   Chip Type and Revision Information Structure
*//***************************************************************************/
typedef struct t_chip_rev_info {
    char        chip_name[MAX_CHIP_NAME_LEN];
                /**< Chip name (e.g. "MPC8360E", "MPC8360") */
    uint16_t    rev_major;
                /**< Major chip revision */
    uint16_t    rev_minor;
                /**< Minor chip revision */
} t_chip_rev_info;

/**************************************************************************//**
 @Description   Platform initialization module description
*//***************************************************************************/
struct pltform_module_desc {
	int (*init) (void * h_platform);
	int (*free) (void * h_platform);
	int is_single_core;
};

/**************************************************************************//**
 @Description   Descriptor memory-partition
*//***************************************************************************/
typedef struct platform_memory_info {
    int             mem_partition_id;
    dma_addr_t      phys_base_addr;
    uintptr_t       virt_base_addr;
    uint64_t        size;
    uint32_t        mem_attribute; /* malloc-able, cacheable */
    char            name[32];
} t_platform_memory_info;

typedef struct platform_region_info {
    int             mem_region_id;
    dma_addr_t      phys_base_addr;
    uintptr_t       virt_base_addr;
    uint64_t        size;
}t_platform_region_info;

typedef struct t_platform_ops {
    void * h_platform;

    /* Enable/disable functions */
    void    (*f_enable_local_irq)      (void * h_platform);
    void    (*f_disable_local_irq)     (void * h_platform);
    
    struct pltform_module_desc modules[PLTFORM_NUM_OF_INIT_MODULES];
} t_platform_ops;


#define PLATFORM_MAX_MEM_INFO_ENTRIES   11


/**************************************************************************//**
 @Description   Platform Console Types
 *//***************************************************************************/
typedef enum platform_console_type {
	PLTFRM_CONSOLE_NONE,        /**< Do not use platform console */
	PLTFRM_CONSOLE_DUART,       /**< Use DUART-x as console port */
} e_platform_console_type;


/**************************************************************************//**
 @Description   Platform configuration parameters structure
 *//***************************************************************************/
struct platform_param {
	struct platform_memory_info	mem_info[PLATFORM_MAX_MEM_INFO_ENTRIES];
	uint32_t                        num_of_mem_parts;
	enum cache_mode			l1_cache_mode;
	enum platform_console_type	console_type;
	uint8_t				console_id;
};

struct disabled_devices {
	int dce;
	int sec;
	int pebm;
	int ddr1;
	uint32_t macs; /* lsb = */
	uint32_t uarts;
	uint32_t aiops;
	uint32_t eiops;
};

struct soc_dynamic_info {
	struct soc_rev rev;
	struct disabled_devices disabled_devices;
	char name[10];
} ;

typedef struct t_platform {
	struct soc_dynamic_info soc_info;
	/* Copy of platform parameters */
	struct platform_param   param;

	/* Platform-owned module handles */
	void *            pic; // consider removing and using sys_get_handle

	/* Console-related variables */
	void *            timer; // consider removing and using sys_get_handle

	uint32_t                num_of_mem_parts;
	int                     registered_partitions[PLATFORM_MAX_MEM_INFO_ENTRIES];

	/* Interrupt management variables */
	int                     pic_intr_id_base;

	/* Platform clock in KHz */
	uint32_t 		platform_clk;

	/* Console-related variables */
	void *            uart; // consider removing and using sys_get_handle
	uint32_t                duart_id;

	uintptr_t               ccsr_base;
	dma_addr_t              mc_mem_phys_base; //read from dpmng (uboot initialized)
} t_platform;

/**************************************************************************//**
 @Function      platform_early_init

 @Description   Initializes the platform object according to the user's
                parameters and the board design and constraints.

 @Param[in]     p_platform_params - Pointer to platform early configuration parameters.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int platform_early_init(void);

/**************************************************************************//**
 @Function      platform_init

 @Description   Creates the platform object and fills the platform operations
                structure, for later use by the system.

 @Param[in]     p_platform_param - Pointer to platform configuration parameters.
 @Param[out]    p_platform_ops   - Pointer to platform operations structure,
                                  that should be filled by this routine.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int platform_init(struct platform_param    *p_platform_param,
                        t_platform_ops             *p_platform_ops);

/**************************************************************************//**
 @Function      platform_free

 @Description   Releases the platform object and all its allocated resources.

 @Param[in]     h_platform - Platform object handle.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int platform_free(void * h_platform);

/**************************************************************************//**
 @Function      platform_get_chip_rev_info

 @Description   Retrieves the revision information of the device.

 @Param[in]     h_platform      - Platform object handle.
 @Param[out]    p_chip_rev_info   - Returns the revision information structure.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int platform_get_chip_rev_info(void * h_platform, t_chip_rev_info *p_chip_rev_info);

/**************************************************************************//**
 @Function      platform_get_clk

 @Description   Gets the platform clock of the device.

 @Param[in]     h_platform - Platform object handle.

 @Return        The clock in KHz.
*//***************************************************************************/
uint32_t platform_get_clk(void * h_platform);

/**************************************************************************//**
 @Function      platform_init_mac_for_mii_access

 @Description   Initialize MAC for MII access only.

 @Param[in]     h_platform  - Platform object handle.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int platform_init_mac_for_mii_access(void * h_platform);

/**************************************************************************//**
 @Function      platform_free_mac_for_mii_access

 @Description   Free a MAC device that was previously initialized for
                MII access only.

 @Param[in]     h_platform  - Platform object handle.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int platform_free_mac_for_mii_access(void * h_platform);

/**************************************************************************//**
 @Function      platform_enable_console

 @Description   Enables the platform's console.

 @Param[in]     h_platform - Platform object handle.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int platform_enable_console(void * h_platform);

/**************************************************************************//**
 @Function      platform_disable_console

 @Description   Disables the platform's console.

 @Param[in]     h_platform - Platform object handle.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int platform_disable_console(void * h_platform);

/**************************************************************************//**
 @Function      platform_set_serdes_loopback

 @Description   Sets SERDES loopback for the specified module.

 @Param[in]     h_platform - Platform object handle.
 @Param[in]     module     - Controller object type (usually a sub-module type)
 @Param[in]     id         - Controller object identifier

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int platform_set_serdes_loopback (void *    h_platform,
                                    enum fsl_module module,
                                    uint32_t id);

/**************************************************************************//**
 @Function      platform_clear_serdes_loopback

 @Description   Clears SERDES loopback for the specified module.

 @Param[in]     h_platform - Platform object handle.
 @Param[in]     module     - Controller object type (usually a sub-module type)
 @Param[in]     id         - Controller object identifier

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int platform_clear_serdes_loopback(void *    h_platform,
                                     enum fsl_module module,
                                     uint32_t    id);

/**************************************************************************//**
 @Function      platform_init_console_cb

 @Description   Register the platform's UART console.

 @Param[in]     h_platform - Platform object handle.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int pltfrm_init_console_cb(void * h_platform);

/**************************************************************************//**
 @Function      platform_free_console_cb

 @Description   Unregister the platform's UART console.

 @Param[in]     h_platform - Platform object handle.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
int pltfrm_free_console_cb(void * h_platform);


/** @} */ /* end of platform_grp */

/**************************************************************************//**
 @Group         sys_platform_grp    System Platform Interface

 @Description   Bare-board system interface for platform-related operations.

 @{
*//***************************************************************************/
#include "fsl_sys.h"


static inline int sys_get_desc(enum soc_module module,
                                   int match_options,
                                   void *user_desc,
                                   int *iter)
{
    return soc_db_get_desc(module, match_options, user_desc, iter);
}


/**************************************************************************//**
 @Function      sys_get_platform_clk

 @Description   Gets the platform clock

 @Return        The platform clock frequency (KHz)
*//***************************************************************************/
static inline uint32_t sys_get_platform_clk()
{
    return platform_get_clk(sys_get_unique_handle(FSL_MOD_SOC));
}

/**************************************************************************//**
 @Function      sys_get_sys_clk

 @Description   Gets the system bus frequency of the device

                It is the MC clock which has been feed by the platform clock

 @Return        The system bus frequency (KHz)
*//***************************************************************************/
static inline uint32_t sys_get_sys_clk()
{
	/*
	 * MC gets clock of (platform clk / 1) that's
	 * why it is platform_get_clk(), see LS2085ARM_RM.pdf
	 */
    return platform_get_clk(sys_get_unique_handle(FSL_MOD_SOC));
}


#if 0
/**************************************************************************//**
 @Function      sys_get_chip_rev_info

 @Description   Retrieves the revision information of the device.

 @Param[out]    p_chip_rev_info - Returns the revision information structure.

 @Return        0 on success; Error code otherwise.
*//***************************************************************************/
static inline fsl_err_t sys_get_chip_rev_info(t_chip_rev_info *p_chip_rev_info)
{
    return platform_get_chip_rev_info(sys_get_unique_handle(FSL_MOD_SOC),
                                   p_chip_rev_info);
}
#endif /* 0 */

/** @} */ /* end of sys_platform_grp */


#endif /* __FSL_PLATFORM_H */
