/*
 * Copyright 2013-2020 NXP
 */

/**
 @File          fsl_soc_spec.h

 @Description   LS2100A external definitions and structures.
*//***************************************************************************/
#ifndef __FSL_SOC_SPEC_H
#define __FSL_SOC_SPEC_H

#include "fsl_types.h"

#define INTG_MAX_NUM_OF_CORES   1

#define INTERNAL_PERIPH_OFF_PORTALS_MC_AREA  0x0000000
#define INTERNAL_PERIPH_MC_PORTAL_ALIGNMENT  0x40       /* Alignment of a MC portal in internal MC DMEM */
#define PERIPH_MC_PORTAL_SIZE                0x40       /* Size of a MC portal*/
#define LDPAA_CCSR_OFF                  0x20000000

/* The number of GPP cores of the SOC */
#define SOC_NUM_OF_CORES		8

/* Allocation of LFQs */
#define DPMNG_DEFAULT_LFQMTIDX_ALLOC	64
#define DPMNG_MAX_LFQMTIDX_ALLOC	128
#define DPMNG_MAX_DCTIDX_ALLOC		SOC_NUM_OF_CORES

#define ENGR357301 /* AIOP RESET Not supported*/
#define TKT241224 /* Rev2 specific a*cache registers for STE/CMGW */
#define TKT320141 /* CDR_LCK bit fails to be set to 1 */

/* remove when taken care of !!! */
#define TMP_UA_SERDES_SIM /* NO ERR id */
#define TMP_1088_QBMAN_DQRR_RING_SIZE

/*simulator bugs */
#define ENGR00352475 /* Reading SGMII/XFI internal link in the MAC always shows link down */

/* support old system DDR virtual address used in AIOP SL */
#define LS1088A_OBSOLETE_SYS_DDR_VADDR 0x20000000

#define TKT011436 /* LS specific define for mEMAC errata workaround */

#endif /* __FSL_SOC_SPEC_H */
