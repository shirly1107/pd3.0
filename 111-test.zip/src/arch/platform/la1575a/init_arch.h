/*
 * Copyright 2013-2020 NXP
 */

#ifndef __INIT_ARCH_H
#define __INIT_ARCH_H

extern int dtc_drv_init(void);
extern int resman_drv_init(void);
extern int linkman_drv_init(void);
extern int cmdif_srv_init(void);
extern int qbman_drv_init(void);
extern int eiop_drv_init(void);
extern int dpmac_drv_init(void);
extern int dprc_drv_init(void);
extern int dpdbg_drv_init(void);
extern int dpmng_drv_init(void);
extern int dpmng_drv_post_controllers_init(void);
extern int dpio_drv_init(void);
extern int dpbp_drv_init(void);
extern int dpni_drv_init(void);
extern int dpsw_drv_init(void);
extern int dpcon_drv_init(void);
extern int dpci_drv_init(void);
extern int dpseci_drv_init(void);
extern int dpdcei_drv_init(void);
extern int dpdmai_drv_init(void);
extern int qdma_drv_init(void);
extern int dpdmux_drv_init(void);
extern int dpaiop_drv_init(void);
extern int dpmcp_drv_init(void);
extern int caam_drv_init(void);
extern int cmdif_client_init();
extern int pebm_drv_init(void);
extern int lcfg_drv_init(void);
extern int dprtc_drv_init(void);

extern int global_module_enabled_stub(void);
extern int is_pebm_enabled(void);
extern int is_aiop_enabled(void);
extern int is_eiop_enabled(void);
extern int is_caam_enabled(void);
extern int is_qdma_enabled(void);
extern int is_qbman_enabled(void);

int parser_ctrl_init(void);
int dpsparser_drv_init(void);

#define GLOBAL_MODULES                      \
{                                           \
	{{dtc_drv_init}, MC_DTC_INIT_ERR, global_module_enabled_stub}, 		\
	{{resman_drv_init}, MC_RESMAN_INIT_ERR, global_module_enabled_stub},     \
	{{linkman_drv_init}, MC_LINKMAN_INIT_ERR, global_module_enabled_stub},  \
	{{cmdif_srv_init}, MC_CMDIF_INIT_ERR, global_module_enabled_stub},       	\
	{{lcfg_drv_init}, MC_LCFG_INIT_ERR, global_module_enabled_stub}, \
	{{dpmng_drv_init}, MC_DPMNG_INIT_ERR, global_module_enabled_stub},\
	{{pebm_drv_init}, MC_PEBM_INIT_ERR, is_pebm_enabled},   /* must be before QBMAN */\
	{{qbman_drv_init}, MC_QBMAN_INIT_ERR, is_qbman_enabled},/* must be after LCFG and DPMNG */\
	{{parser_ctrl_init}, 0, global_module_enabled_stub},		\
	{{eiop_drv_init}, MC_EIOP_INIT_ERR, is_eiop_enabled},         \
	{{caam_drv_init}, MC_CAAM_INIT_ERR, is_caam_enabled},         \
	{{qdma_drv_init}, MC_QDMA_INIT_ERR, is_qdma_enabled},   \
	{{dpmng_drv_post_controllers_init}, MC_DPMNG_INIT_ERR, global_module_enabled_stub},/* must after QBMAN&EIOP */\
	{{dpdbg_drv_init}, MC_DPDBG_INIT_ERR, global_module_enabled_stub},     \
	{{dpaiop_drv_init}, MC_DPAIOP_INIT_ERR, is_aiop_enabled},   \
	{{dprc_drv_init}, MC_DPRC_INIT_ERR, global_module_enabled_stub},         \
	{{dpmac_drv_init}, MC_DPMAC_INIT_ERR, global_module_enabled_stub},/* must be after DPMNG */\
	{{dpio_drv_init}, MC_DPIO_INIT_ERR, global_module_enabled_stub},         \
	{{dpbp_drv_init}, MC_DPBP_INIT_ERR, global_module_enabled_stub},         \
	{{dpsparser_drv_init}, MC_DPRTC_INIT_ERR, global_module_enabled_stub}, \
	{{dpni_drv_init}, MC_DPNI_INIT_ERR, global_module_enabled_stub},         \
	{{dpsw_drv_init}, MC_DPSW_INIT_ERR, global_module_enabled_stub},         \
	{{dpdmux_drv_init}, MC_DPDMUX_INIT_ERR, global_module_enabled_stub},   \
	{{dpcon_drv_init}, MC_DPCON_INIT_ERR, global_module_enabled_stub},      \
	{{dpci_drv_init}, MC_DPCI_INIT_ERR, global_module_enabled_stub},         \
	{{dpseci_drv_init}, MC_DPSECI_INIT_ERR, is_caam_enabled},   \
	{{dpdcei_drv_init}, MC_DPDCEI_INIT_ERR, global_module_enabled_stub},   \
	{{dpdmai_drv_init}, MC_DPDMAI_INIT_ERR, global_module_enabled_stub},   \
	{{dprtc_drv_init}, MC_DPRTC_INIT_ERR, global_module_enabled_stub},   \
	{{dpmcp_drv_init}, MC_DPMCP_INIT_ERR, global_module_enabled_stub},   \
	{{cmdif_client_init}, MC_CMDIF_INIT_ERR, global_module_enabled_stub},/* must be after DPCI */\
}

#endif /* __INIT_ARCH_H */
