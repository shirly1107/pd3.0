/*
 * Copyright 2013-2020 NXP
 */

#include "soc_db.h"
#include "drivers/fsl_mc.h"
#include "ls2085_mc_mpic.h"

/*
 * This structure represents the SOC database, describing selected hardware
 * attributes of different blocks or components.
 * Each module is represented by an array of database items - each item contains
 * two structures:
 * The first ("range") defines the number of module instances that
 * share common configuration. Commonness may not necessarily include the
 * instance id or its base address - for these it is possible to set increment
 * values (applied according to the index of each instance in the range).
 * The second ("desc") defines specific attributes of the module instances.
 */

//struct soc_db soc_db_rev1 = { 0 };

struct soc_db soc_db = {0,
               	 .var_select = {
               			 .system_version_arch = 0x87090000,
               			 .system_version_mask = 0xFFFF0000,
               			 .personality_mask = 0x00003F00,
               			 .variances = {
								/*personality; major; minor; name; soc_db */
								{0x00000000, 1, 0, "LS2088AE", 0},
								{0x00000000, 1, 1, "LS2088AE", 0},
								{0x00002000, 1, 0, "LS2048AE", 0},
								{0x00002000, 1, 1, "LS2048AE", 0},
								{0x00000200, 1, 0, "LS2068AE", 0},
								{0x00000200, 1, 1, "LS2068AE", 0},
								{0x00002200, 1, 0, "LS2028AE", 0},
								{0x00002200, 1, 1, "LS2028AE", 0},
								/* no SEC */
								{0x00000100, 1, 0, "LS2088A", 0},
								{0x00000100, 1, 1, "LS2088A", 0},
								{0x00002100, 1, 0, "LS2048A", 0},
								{0x00002100, 1, 1, "LS2048A", 0},
								{0x00000300, 1, 0, "LS2068A", 0},
								{0x00000300, 1, 1, "LS2068A", 0},
								{0x00002300, 1, 0, "LS2028A", 0},
								{0x00002300, 1, 1, "LS2028A", 0},
								/* no AIOP SVR[12] */
								{0x00001000, 1, 0, "LS2084AE", 0},
								{0x00001000, 1, 1, "LS2084AE", 0},
								{0x00003000, 1, 0, "LS2044AE", 0},
								{0x00003000, 1, 1, "LS2044AE", 0},
								{0x00001200, 1, 0, "LS2064AE", 0},
								{0x00001200, 1, 1, "LS2064AE", 0},
								{0x00003200, 1, 0, "LS2024AE", 0},
								{0x00003200, 1, 1, "LS2024AE", 0},
								{0x00001800, 1, 1, "LS2081AE", 0},
								/* no AIOP, No SEC */
								{0x00001100, 1, 0, "LS2084A", 0},
								{0x00001100, 1, 1, "LS2084A", 0},
								{0x00003100, 1, 0, "LS2044A", 0},
								{0x00003100, 1, 1, "LS2044A", 0},
								{0x00001300, 1, 0, "LS2064A", 0},
								{0x00001300, 1, 1, "LS2064A", 0},
								{0x00003300, 1, 0, "LS2024A", 0},
								{0x00003300, 1, 1, "LS2024A", 0},
								{0x00001900, 1, 1, "LS2081A", 0},
				}
	},

	.emac_regs_mem_map = {
			{0x008, 0x040, 0x0c8, 0x0c0, 0x0e0, 0x100, 0x300, 0x380, 0x04c},
			{0x008, 0x040, 0x0c8, 0x0c0, 0x0e0, 0x100, 0x080, 0x380, 0x088},
			{0x008, 0x040, 0x000, 0x2c0, 0x000, 0x080, 0x000, 0x198, 0x2C8}
	},

     .mc_db = {
	 {
	     .range = {.num = 1},
	     .desc = {.num_cores = 2,
	              .ccsr_paddr = 0x00000000,
		      .ccsr_size = 64*MEGABYTE,
		      .soc_ccsr = (void*)0x30000000,
		      .soc_dcsr = (void*)0x40000000,
		      .soc_int_addr_map = (void*)0x80000000,
		      .vaddr = (void *)0x28340000}
	 }
     },

     .dcfg_db = {
	 {
	     .range = {.num = 1},
	     .desc = {.vaddr = (void*)0x31E00000LL,
	    		 .sys_clk_div = 2,
	    		 .sys_clk_rcwsr_id = 9,
	    		 .sys_clk_rcwsr_mask = 0x00003FF0,
	    		 .sys_pll_rat_rcwsr_id = 0,
	    		 .sys_pll_rat_rcwsr_mask = 0x0000007C,
	    		 .svr_sec_disable_mask = 0x00000100,
	    		 .svr_aiop_disable_mask = 0x00001000}
	 }
     },
     .pebm_db = {
                 {
                  .range = {.num = 1},
                  .desc = {.paddr = 0x4c00000000LL,
                           .size = 4*MEGABYTE,
                           .regs_paddr = 0x28200000,
                           .irq_rec_err = MC_MPIC_INTR_PEBM_REC_ERR,
                 		/* non-spec, clear */
                 		.disable = 0}
                 }
     	     },

     .dpddr_db = {
                  {
                   .range = {.num = 1},
                   .desc = {.paddr = 0x6000000000LL,
                            .size = 4*(uint64_t)GIGABYTE,
                  		/* non-spec, clear */
                  		.disable = 0}
                  }
     	     },

     .mc_ddr_db = {
                   {
                    .range = {.num = 1},
                    .desc = {.paddr = 0x0,
                             .size = 512*MEGABYTE}
                   }
	 	 },

     .dmem_db = {
                 {
                  .range = {.num = 2, .id_inc = 1, .addr_inc = 0x100000},
                  .desc = {.core_id = 1,
                           .global_paddr = 0x20804000,
                            .local_paddr = 0x20004000,
                           .block_size = 80*KILOBYTE}
                 }
     	     },

    .mc_bt_db = {
              {
                  .range = {.num = 2,  .id_inc = 1, .addr_inc = 0x1000},
                  .desc = {.core_id = 1,
                           .paddr = 0x21010000}
              }
     },

    .mc_portal_db = {
        {
            .range = {.num = 256, .id_inc = 1, .addr_inc = 0x40},
            .desc = {.portal_id = 0, .paddr = 0x20000000 }
        }
    },

    .soc_mc_portal_db = {
        {
            .range = {.num = 256, .id_inc = 1, .addr_inc = 0x10000},
            .desc = {.portal_id = 0, .paddr = 0x00080C000000}
        }
    },

    .cpm_db = {
               {
                   .range = {.num = 1},
                   .desc = {
                            .core_id = 0,
                            .paddr = 0x21000000,
                   	     .irq_hp = MC_MPIC_INTR_CPM_1_HP,
                   	     .irq_lp = MC_MPIC_INTR_CPM_1_LP}
               },
               {
                   .range = {.num = 1},
                   .desc = {.core_id = 1,
                            .paddr = 0x21001000,
                   	     .irq_hp = MC_MPIC_INTR_CPM_2_HP,
                   	     .irq_lp = MC_MPIC_INTR_CPM_2_LP}
               },
    },

    .lcfg_db = {
        {
            .range = {.num = 1},
            .desc = {.paddr = 0x28240000}
        },
    },

    .qdma_db = {
        {
             .range = {.num = 1},
	     .desc = {.id = 0,
		 .paddr = 0x28380000,
         .irq_err = MC_MPIC_INTR_QDMA_REC_ERR,
         .version = 1},
        }
     },

    .eiop_block_db = {
        {
            .range = {.num = 1},
            .desc = {.eiop_id = 0,
                .paddr = 0x28b90000,
                .irq = MC_MPIC_INTR_WRIOP_1_RT,
                .irq_rec_err = MC_MPIC_INTR_WRIOP_1_REC_ERR,
                .wriop_version = WRIOP_VERSION(1, 1, 1),
            }
          }
    },

    .eiop_ifp_db = {
        {
            .range = {.num = 256, .id_inc = 1, .addr_inc = 0x400},
            .desc = {.ifp_id = 0,
                .eiop_id = 0,
                .paddr = 0x28800000}
        }
   },

    .eiop_port_db = {
        {
            .range = {.num = 16, .id_inc = 1, .addr_inc = 0x4000},
            .desc = {.port_id = 1,
                .eiop_id = 0,
                .type = EIOP_ETHERNET_PORT,
                .paddr = 0x28c04000}
        },
        {
            .range = {.num = 2, .id_inc = 1, .addr_inc = 0x4000},
            .desc = {.port_id = 17,
                .eiop_id = 0,
                .type = EIOP_RECYCLE_PORT,
                .rate = EIOP_PORT_RATE_20_G,                
                .paddr = 0x28C44000}
        },
        {
            .range = {.num = 1},
            .desc = {.port_id = 0,
                .eiop_id = 0,
                .type = EIOP_MANAGEMENT_COMMAND_PORT,
                .paddr = 0x28c00000}
        }
    },
	.eiop_memac_db = {
	{
		.range = {.num = 1},
		.desc = {.mac_id = 1,
		.eiop_id = 0,
		.paddr = 0x28c07000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 4,
		.qsgmii_phy_addr = 3}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 2,
		.eiop_id = 0,
		.paddr = 0x28c0b000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 4,
		.qsgmii_phy_addr = 2}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 3,
		.eiop_id = 0,
		.paddr = 0x28c0f000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 4,
		.qsgmii_phy_addr = 1}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 4,
		.eiop_id = 0,
		.paddr = 0x28c13000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 4,
		.qsgmii_phy_addr = 0}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 5,
		.eiop_id = 0,
		.paddr = 0x28c17000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 8,
		.qsgmii_phy_addr = 3}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 6,
		.eiop_id = 0,
		.paddr = 0x28c1b000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 8,
		.qsgmii_phy_addr = 2}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 7,
		.eiop_id = 0,
		.paddr = 0x28c1f000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 8,
		.qsgmii_phy_addr = 1}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 8,
		.eiop_id = 0,
		.paddr = 0x28c23000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 8,
		.qsgmii_phy_addr = 0}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 9,
		.eiop_id = 0,
		.paddr = 0x28c27000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 9,
		.qsgmii_phy_addr = 0}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 10,
		.eiop_id = 0,
		.paddr = 0x28c2b000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 9,
		.qsgmii_phy_addr = 1}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 11,
		.eiop_id = 0,
		.paddr = 0x28c2f000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 9,
		.qsgmii_phy_addr = 2}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 12,
		.eiop_id = 0,
		.paddr = 0x28c33000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 9,
		.qsgmii_phy_addr = 3}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 13,
		.eiop_id = 0,
		.paddr = 0x28c37000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 13,
		.qsgmii_phy_addr = 0}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 14,
		.eiop_id = 0,
		.paddr = 0x28c3b000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 13,
		.qsgmii_phy_addr = 1}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 15,
		.eiop_id = 0,
		.paddr = 0x28c3f000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 13,
		.qsgmii_phy_addr = 2}
	},
	{
		.range = {.num = 1},
		.desc = {.mac_id = 16,
		.eiop_id = 0,
		.paddr = 0x28c43000,
		/* non-spec, clear */
		.disable = 0,
		.enet_if = 0,
		.rate = 0,
		.phy_id = 0,
		.link_type = 0,
		.qsgmii_master = 13,
		.qsgmii_phy_addr = 3}
	}
     },

    .eiop_rtc_db = {
        {
            .range = {.num = 1},
            .desc = {.eiop_id = 0,
                .paddr = 0x28b95000,
            	.num_alarms = 2,
                .num_periodics = 3,
                .num_ext_triggers = 2,
		        .little_endian = 1,
            }
        }
   },

   .ctlu_db = {
        {
            .range = {.num = 1},
            .desc = {.iop_id = 0,
                .type = CTLU_EIOP_INGRESS,
                .block_paddr = 0x28b80000,
                .dpparser_paddr = 0x28b80000,
                .dptbl_mng_paddr = 0x28b81400,
                .dpkg_paddr = 0x28b82000,
                .dppolicer_paddr = 0x28b81C00,
                .num_dpparser_profiles = 64,
                .num_dppolicy_entries = 256,
                .num_dpkg_profiles = 256,
                .num_dppolicer_profiles = 256,
                .num_dptbl_tcam_entries = 1024,
                .tcam_key_size = 27,
                .dptbl_scanning_speed = 0x800,
                .options = CTLU_DESC_OPT_REDUCED_TCAM}
        },
        {
            .range = {.num = 1,},
            .desc = {.iop_id = 0,
                .type = CTLU_EIOP_EGRESS,
                .block_paddr = 0x28b84000,
                .dpparser_paddr = 0x28b84000,
                .dptbl_mng_paddr = 0x28b85400,
                .dpkg_paddr = 0x28b86000,
                .dppolicer_paddr = 0x28b85C00,
                .num_dpparser_profiles = 64,
                .num_dppolicy_entries = 0,
                .num_dpkg_profiles = 256,
                .num_dppolicer_profiles = 0,
                .dptbl_scanning_speed = 0x800,
                .options = 0}
        },
        {
            .range = {.num = 1,},
            .desc = {.iop_id = 0,
                .type = CTLU_AIOP,
                .block_paddr = 0x28938000,
                .dpparser_paddr = 0x28938000,
                .dptbl_mng_paddr = 0x28939400,
                .dpkg_paddr = 0x2893a000,
                .dppolicer_paddr = 0x28939c00,
                .num_dpparser_profiles = 64,
                .num_dppolicy_entries = 0,
                .num_dpkg_profiles = 256,
                .num_dppolicer_profiles = 0,
                .options = 0,
#ifdef ERR008757
                .dptbl_scanning_speed = 0}
#else
            .dptbl_scanning_speed = 0x800}
#endif
        },
        {
            .range = {.num = 1,},
            .desc = {.iop_id = 0,
                .type = CTLU_AIOP_MFLU,
                .block_paddr = 0x28930000,
                .dpparser_paddr = 0x28930000,
                .dptbl_mng_paddr = 0x28931400,
                .dpkg_paddr = 0x28932000,
                .dppolicer_paddr = 0x28931c00,
                .num_dpparser_profiles = 64,
                .num_dppolicy_entries = 0,
                .num_dpkg_profiles = 32,
                .num_dppolicer_profiles = 0,
                .options = 0,
#ifdef ERR008757
                .dptbl_scanning_speed = 0}
#else
            .dptbl_scanning_speed = 0x800}
#endif
        }
    },
    .aiop_tile_db = {
        {
            .range = {.num = 1},
            .desc = {.tile_id = 0,
                     .paddr = 0x28900000,
                     .vaddr_dcsr = (void *)0x40800000,
		     .num_clusters = 4,
                     .num_ep = 1024,
                     .num_sp = 256,
                     .psram_paddr = 0x4B02000000LL,

		     .iram_paddr = 0x4B00fe0000LL,
		     .iram_vaddr = (void *)0x00fe0000,
		     .iram_size = 128*KILOBYTE,
		     .iram_offset = 0x100000,

		     .sram_paddr = 0x4B01000000LL,
		     .sram_vaddr = (void *)0x01000000,
		     .sram_size = 256*KILOBYTE,

		     .dp_ddr_vaddr = (void *)0x40000000,
		     .dp_ddr_atu_size = 1 * GIGABYTE,
		     .peb_vaddr = (void *)0x1C000000,
		     .peb_atu_size = 4 * MEGABYTE,

            	    .irq_cat_err = MC_MPIC_INTR_AIOP_1_CAT_ERR,
                    .irq_rec_err = MC_MPIC_INTR_AIOP_1_REC_ERR,

                    .pta_support = 0,
		    .ste_support = 1,

          	    /* non-spec, clear */
          	    .disable = 0}
        }
    },

    .pic_db = {
        {
            .range = {.num = 1},
            .desc = {.paddr = 0x21040000}
        }
    },

    .uart_db = {
        {
            .range = {.num = 1},
            .desc = {.uart_id = 0,
                .paddr = 0x321c0500,
      		/* non-spec, clear */
      		.disable = 0,
      		.clk_div = 1}
        },
        {
            .range = {.num = 1},
            .desc = {.uart_id = 1,
                .paddr = 0x321c0600,
      		/* non-spec, clear */
      		.disable = 0,
      		.clk_div = 1}
        },
        {
            .range = {.num = 1},
            .desc = {.uart_id = 2,
                .paddr = 0x321d0500,
      		/* non-spec, clear */
      		.disable = 0,
      		.clk_div = 1}
        },
        {
            .range = {.num = 1},
            .desc = {.uart_id = 3,
                .paddr = 0x321d0600,
      		/* non-spec, clear */
      		.disable = 0,
      		.clk_div = 1}
        }
    },

    .qbman_db = {
        {
            .range = {.num = 1},
            .desc = {.paddr = 0x28180000,
                 .portals_paddr = 0x818000000LL,
                 .irq_recoverable = MC_MPIC_INTR_QBMAN_REC_ERR,
                 .irq_non_recoverable = MC_MPIC_INTR_QBMAN_CAT_ERR,
                 .num_swp_wqs = 512,
                 .num_int_fqs = 2048,
                 .num_fq_cgs = 256,
                 .num_bpids = 64,
                 .num_wq_per_wqpr = 5,
                 .num_qds = 256,
                 .num_qprs = 2048,
                 .num_odps_orps = 128,
                 .num_orl_recs = 2048,
                 .num_replication_records = 2048,
                 .max_in_flight_replications = 256,
            	 .ceetm_strict_pri_q_base = 0,
            	 .ceetm_num_strict_pri_q = 8,
            	 .ceetm_weight_pri_q_base = 8,
            	 .ceetm_num_weight_pri_q = 8,
                 .multiple_pfdr_support = 1,
                 .pfdr_peb_size = 512*KILOBYTE,
				 .pfdr_pool_min_value = 8,
		 .ceetm_max_shaper_output_rate = 20000000000LL,
            	 .dcp[0] =
                     {.valid = 1,
                      .dcp_type = QBMAN_DCP_WRIOP,
                      .ceetm_support = 1,
                      .ceetm_instance[0] =
                          {.valid = 1,
                           .num_lnis = 12,
                           .num_lfqids = 2048,
                           .num_cq_channels = 32,
                           .num_cqs_per_channel = 16,
                           .num_ccg = 512
                          },
                      .ceetm_instance[1] =
                          {.valid = 1,
                           .num_lnis = 12,
                           .num_lfqids = 2048,
                           .num_cq_channels = 32,
                           .num_cqs_per_channel = 16,
                           .num_ccg = 512
                          },
                     },
    		 .dcp[1] =
    		  {.valid = 1,
                   .dcp_type = QBMAN_DCP_AIOP,
    		   .num_fq_wq_channels = 64,
    		   },
    		 .dcp[2] =
    		  {.valid = 1,
    		   .dcp_type = QBMAN_DCP_SEC,
    		   .num_fq_wq_channels = 1,
    		   },
      		 .dcp[3] =
      		  {.valid = 1,
      		   .dcp_type = QBMAN_DCP_DCE,
      		   .num_fq_wq_channels = 2,
      		   },
      		 .dcp[4] =
      		  {.valid = 1,
      		   .dcp_type = QBMAN_DCP_PME,
      		   .num_fq_wq_channels = 1,
      		   },
    		 .dcp[5] =
    		  {.valid = 1,
    		   .dcp_type = QBMAN_DCP_QDMA,
    		   .num_fq_wq_channels = 1,
    		   },
                 .num_sdest_srcid = 0,
                 .sdest_core_index[0] =
                   {
                        .sdest = 0,
                   },
                 .sdest_core_index[1] =
                   {
                        .sdest = 0,
                   },
                 .sdest_core_index[2] =
                   {
                        .sdest = 1,
                   },
                 .sdest_core_index[3] =
                   {
                        .sdest = 1,
                   },
                 .sdest_core_index[4] =
                   {
                        .sdest = 2,
                   },
                 .sdest_core_index[5] =
                   {
                        .sdest = 2,
                   },
                 .sdest_core_index[6] =
                   {
                        .sdest = 3,
                   },
                 .sdest_core_index[7] =
                   {
                        .sdest = 3,
                   },
            }
        }
    },

    .qbman_swportal_db = {
        {
            .range = {.num = 35, .id_inc = 1, .addr_inc = 0x10000},
            .desc = {
                     .qbman_id = 0,
                     .swportal_id = 0,
                     .paddr_cena = 0x818000000LL,
                     .paddr_cinh = 0x81C000000LL,
                     .irq = MC_MPIC_INTR_GPPL_SW_NMI,
            }
        }
    },

    .edma_db = {
        {
            .range = {.num = 1, .id_inc = 1, .addr_inc = 0x4000},
            .desc = {.edma_id = 0,
                     .num_blocks = 2,
                     .irq_transaction_err = MC_MPIC_INTR_EDMA_ERR,
                     .irq_queue_err = MC_MPIC_INTR_EDMA_QML_ERR,
                     .paddr = 0x21028000,
                }
        }
    },
    .edma_block_db = {
        {
            .range = {.num = 1, .id_inc = 1, .addr_inc = 0x1000},
            .desc = {.edma_block_id = 0,
                     .num_queues = 8,
                 .irq = MC_MPIC_INTR_EDMA_QML_OUT_1,
                 .paddr = 0x2102A000,
                }
        },
        {
            .range = {.num = 1, .id_inc = 1, .addr_inc = 0x1000},
            .desc = {.edma_block_id = 1,
                     .num_queues = 8,
                 .irq = MC_MPIC_INTR_EDMA_QML_OUT_2,
                 .paddr = 0x2102B000,
                }
        }
    },
     .sec_db = {
                 {
                     .range = {.num = 1},
                     .desc = {.paddr = 0x28000000,
              		/* non-spec, clear */
              		.disable = 0}
                 }
             },

     .pport_connections_db = {
		/*! /* range *//*iop_id	dcp_id 	ceetm	lniid	mac_id	ppid */
		{ {1, 0, 0},	{0,	0,	0,	0,	1,	1}},
		{ {1, 0, 0},	{0,	0,	0,	1,	2,	2}},
		{ {1, 0, 0},	{0,	0,	0,	4,	3,	3}},
		{ {1, 0, 0},	{0,	0,	0,	5,	4,	4}},
		{ {1, 0, 0},	{0,	0,	1,	0,	5,	5}},
		{ {1, 0, 0},	{0,	0,	1,	1,	6,	6}},
		{ {1, 0, 0},	{0,	0,	1,	4,	7,	7}},
		{ {1, 0, 0},	{0,	0,	1,	5,	8,	8}},
		{ {1, 0, 0},	{0,	0,	0,	2,	9,	9}},
		{ {1, 0, 0},	{0,	0,	0,	3,	10,	10}},
		{ {1, 0, 0},	{0,	0,	0,	6,	11,	11}},
		{ {1, 0, 0},	{0,	0,	0,	7,	12,	12}},
		{ {1, 0, 0},	{0,	0,	1,	2,	13,	13}},
		{ {1, 0, 0},	{0,	0,	1,	3,	14,	14}},
		{ {1, 0, 0},	{0,	0,	1,	6,	15,	15}},
		{ {1, 0, 0},	{0,	0,	1,	7,	16,	16}}
     },

	.vport_connections_db = {
	       	/*! /* range *//*iop_id	dcp_id 	ceetm	lniid	ppid */
		{ {1, 0, 0}, 	{0,	0,	0,	8,	17}},
		{ {1, 0, 0}, 	{0,	0,	1,	8,	18}}
     },

     .dce_db = {
		 {
		     .range = {.num = 1},
		     .desc = {.paddr = 0x28120000,
				/* non-spec, clear */
				.disable = 0}
		 }
	       },
       .serdes_db = {
  		   {
  		       .range = {.num = 1},
  		       .desc = {
  		                .id = 0,
  		                .vaddr = (void *)0x31EA0000LL,
  		                .num_lanes = 8,
  		                .rcwsr_mask = 0x00FF0000,
		                .rcwsr_id = 28,
		                .mac_mask = 0x000F0000,
						.master_lane_select = {0, 1, 2, 3, 4, 5, 6, 7}
  		       }
  		   },
		   {
		       .range = {.num = 1},
		       .desc = {
		                .id = 1,
		                .vaddr = (void *)0x31EB0000LL,
		                .num_lanes = 8,
		                .rcwsr_mask = 0xFF000000,
		                .rcwsr_id = 28,
		                .mac_mask = 0x000F0000,
						.master_lane_select = {0, 1, 2, 3, 4, 5, 6, 7}
		       }
		   }
		 },
      .mdio_db = {
		   {
		       .range = {.num = 1},
		       .desc = {
				.id = 0,
				.eiop_id = 0,
				.paddr = 0x28b96000,
				.mii_paddr = 0x28b96030,
				.enet_if = (FSL_ENET_IF_QSGMII|
							FSL_ENET_IF_SGMII|
							FSL_ENET_IF_RGMII)
		       }
		   },
		   {
		       .range = {.num = 1},
		       .desc = {
				.id = 1,
				.eiop_id = 0,
				.paddr = 0x28b97000,
				.mii_paddr = 0x28b97030,
				.enet_if = (FSL_ENET_IF_XGMII | FSL_ENET_IF_XFI)
		       }
		   }
		 },
		.dppmu_db = {
			{
					.range = {.num = 1},
					.desc = {
							/*CCSR offset from system memory map +
							DP-PM block offset */
							.paddr = (0x1000000LL + 0x8290000LL),
							/* Directly accessible from MC's LDPAA CCSR Space
							(0x2800_0000). Note: the dppmu_match_desc must not
							translate the virtual address from physical.*/
							.vaddr = (void *)0x28290000UL,
							/* The TPH10SETR, TPH10SR0, TPH15SETR and TPH15SR0
							implementations depend on the actual number of MC
							and AIOP cores present in the DPAA2 platform;
							eg. LS2088A DPAA2 has 16 AIOP and 2 MC cores. */
							.ph10_aiop_core_mask = 0x3FFFC,
							.ph15_aiop_core_mask = 0x3FFFC,
							.disable = 0
					}
			}
    }
};
