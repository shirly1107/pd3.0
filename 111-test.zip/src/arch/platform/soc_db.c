/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_errors.h"
#include "fsl_gen.h"

#include "soc_db.h"
#include "fsl_platform.h"
#include "dpc.h"

extern struct soc_db soc_db;

#define ONLY_CHECK_IF_EXISTS(user_desc, match_options)\
{\
	if (user_desc == NULL) /* caller is just checking module's existence */\
	{\
		if (match_options) /* must have a desc for comparing */\
			return -EINVAL;\
		else\
		{\
			return 0;\
		}\
	}\
}

static int dcfg_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct dcfg_desc *ref = (const struct dcfg_desc *)ref_desc;
	struct dcfg_desc *desc = (struct dcfg_desc *)user_desc;

	if((match_options) && (match_options != SOC_DB_SET_VAL))
	{
		pr_err("not supported");
		return -ENOTSUP;
	}
	
	ONLY_CHECK_IF_EXISTS(user_desc, match_options);
	
	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;

	return 0;
}

static int eiop_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct eiop_desc *ref = (const struct eiop_desc *)ref_desc;
	struct eiop_desc *desc = (struct eiop_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_EIOP_DESC_ID)
		no_match |= (desc->eiop_id != (ref->eiop_id + id_increment));
	if (no_match)
		return -ENAVAIL;

	/*if(ref->disable)
		return -ENAVAIL;*/

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->eiop_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int aiop_tile_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct aiop_tile_desc *ref = (const struct aiop_tile_desc *)ref_desc;
	struct aiop_tile_desc *desc = (struct aiop_tile_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_AIOP_TILE_DESC_ID)
		no_match |= (desc->tile_id != (ref->tile_id + id_increment));
	if (no_match)
		return -ENAVAIL;

	if(ref->disable)
		return -ENAVAIL;

	*desc = *ref;
	desc->tile_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int ctlu_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct ctlu_desc *ref = (const struct ctlu_desc *)ref_desc;
	struct ctlu_desc *desc = (struct ctlu_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_CTLU_DESC_IOP_ID)
		no_match |= (desc->iop_id != (ref->iop_id + id_increment));
	if (match_options & SOC_DB_CTLU_DESC_TYPE)
		no_match |= (desc->type != (ref->type));

	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->block_vaddr = fsl_phys_to_virt(desc->block_paddr);
	desc->dpparser_vaddr = fsl_phys_to_virt(desc->dpparser_paddr);
	desc->dptbl_mng_vaddr = fsl_phys_to_virt(desc->dptbl_mng_paddr);
	desc->dpkg_vaddr = fsl_phys_to_virt(desc->dpkg_paddr);
	desc->dppolicer_vaddr = fsl_phys_to_virt(desc->dppolicer_paddr);

	return 0;
}

static int eiop_ifp_match_desc(const void *ref_desc,
                               void *user_desc,
                               int match_options,
                               uint32_t id_increment,
                               uint64_t addr_increment)
{
	const struct eiop_ifp_desc *ref = (const struct eiop_ifp_desc *)ref_desc;
	struct eiop_ifp_desc *desc = (struct eiop_ifp_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_IFP_DESC_ID)
		no_match |= (desc->ifp_id != (ref->ifp_id + id_increment));
	if (match_options & SOC_DB_IFP_DESC_EIOP_ID)
		no_match |= (desc->eiop_id != ref->eiop_id);
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->ifp_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int eiop_rtc_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct eiop_rtc_desc *ref = (const struct eiop_rtc_desc *)ref_desc;
	struct eiop_rtc_desc *desc = (struct eiop_rtc_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_RTC_DESC_EIOP_ID)
		no_match |= (desc->eiop_id != ref->eiop_id);
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}


static int memac_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct eiop_memac_desc *ref = (const struct eiop_memac_desc *)ref_desc;
	struct eiop_memac_desc *desc = (struct eiop_memac_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_MAC_DESC_ID)
		no_match |= (desc->mac_id != (ref->mac_id + id_increment));
	if (match_options & SOC_DB_MAC_DESC_EIOP_ID)
		no_match |= (desc->eiop_id != ref->eiop_id);
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->mac_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int eiop_port_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct eiop_port_desc *ref = (const struct eiop_port_desc *)ref_desc;
	struct eiop_port_desc *desc = (struct eiop_port_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_PORT_DESC_ID)
		no_match |= (desc->port_id != (ref->port_id + id_increment));
	if (match_options & SOC_DB_PORT_DESC_EIOP_ID)
		no_match |= (desc->eiop_id != ref->eiop_id);
	if (match_options & SOC_DB_PORT_DESC_TYPE)
		no_match |= (desc->type != ref->type);
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->port_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int eiop_pport_conn_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct pport_connections_desc *ref = (const struct pport_connections_desc *)ref_desc;
	struct pport_connections_desc *desc = (struct pport_connections_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_PORT_CON_DESC_ID)
		no_match |= (desc->port_id != (ref->port_id + id_increment));
	if (match_options & SOC_DB_PORT_CON_DESC_EIOP_ID)
		no_match |= (desc->eiop_id != ref->eiop_id);
	if (match_options & SOC_DB_PORT_CON_DESC_DCP_ID)
		no_match |= (desc->dcp_id != ref->dcp_id);
	if (match_options & SOC_DB_PORT_CON_DESC_MAC_ID)
		no_match |= (desc->mac_id != ref->mac_id);
	if (match_options & SOC_DB_PORT_CON_DESC_CEETM_ID )
		no_match |= (desc->ceetm_id != ref->ceetm_id);
	if (no_match)
		return -1;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;

	return 0;
}

static int eiop_vport_conn_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct vport_connections_desc *ref = (const struct vport_connections_desc *)ref_desc;
	struct vport_connections_desc *desc = (struct vport_connections_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_PORT_CON_DESC_ID)
		no_match |= (desc->port_id != (ref->port_id + id_increment));
	if (match_options & SOC_DB_PORT_CON_DESC_EIOP_ID)
		no_match |= (desc->eiop_id != ref->eiop_id);
	if (match_options & SOC_DB_PORT_CON_DESC_DCP_ID)
		no_match |= (desc->dcp_id != ref->dcp_id);
	if (match_options & SOC_DB_PORT_CON_DESC_CEETM_ID )
		no_match |= (desc->ceetm_id != ref->ceetm_id);
	if (no_match)
		return -1;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;

	return 0;
}

static int mdio_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct mdio_desc *ref = (const struct mdio_desc *)ref_desc;
	struct mdio_desc *desc = (struct mdio_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_MDIO_DESC_ID)
		no_match |= (desc->id != (ref->id + id_increment));
	if (match_options & SOC_DB_MDIO_DESC_EIOP_ID)
		no_match |= (desc->eiop_id != ref->eiop_id);
	if (match_options & SOC_DB_MDIO_DESC_ENET_IF)
		no_match |= (!(desc->enet_if & ref->enet_if));
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);
	desc->mii_vaddr = fsl_phys_to_virt(desc->mii_paddr);

	return 0;
}

static int serdes_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct serdes_desc *ref = (const struct serdes_desc *)ref_desc;
	struct serdes_desc *desc = (struct serdes_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_SERDES_DESC_ID)
		no_match |= (desc->id != (ref->id + id_increment));
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->id += id_increment;

	return 0;
}

static int mc_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct mc_desc *ref = (const struct mc_desc *)ref_desc;
	struct mc_desc *desc = (struct mc_desc *)user_desc;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if(match_options)
	{
		pr_err("not supported");
		return -ENOTSUP;
	}

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;

	return 0;
}

static int memc_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct mem_desc *ref = (const struct mem_desc *)ref_desc;
	struct mem_desc *desc = (struct mem_desc *)user_desc;

	if((match_options) && (match_options != SOC_DB_SET_VAL))
	{
		pr_err("not supported");
		return -ENOTSUP;
	}

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if(ref->disable)
		return -ENAVAIL;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->regs_vaddr = fsl_phys_to_virt(desc->regs_paddr); //vaddr/paddr

	return 0;
}

static int dmem_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct dmem_desc *ref = (const struct dmem_desc *)ref_desc;
	struct dmem_desc *desc = (struct dmem_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_DMEM_DESC_CORE_ID)
		no_match |= (desc->core_id != (ref->core_id + id_increment));
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->core_id += id_increment;
	desc->global_paddr += addr_increment;

	return 0;
}

static int mc_bt_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct mc_bt_desc *ref = (const struct mc_bt_desc *)ref_desc;
	struct mc_bt_desc *desc = (struct mc_bt_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_MC_BT_DESC_CORE_ID)
		no_match |= (desc->core_id != (ref->core_id + id_increment));
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->core_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int cpm_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct cpm_desc *ref = (const struct cpm_desc *)ref_desc;
	struct cpm_desc *desc = (struct cpm_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_CPM_DESC_CORE_ID)
		no_match |= (desc->core_id != (ref->core_id + id_increment));
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->core_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}
#if 0
static int pebm_memc_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct pebm_memc_desc *ref = (const struct pebm_memc_desc *)ref_desc;
	struct pebm_memc_desc *desc = (struct pebm_memc_desc *)user_desc;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if((match_options) && (match_options != SOC_DB_SET_VAL))
	{
		pr_err("not supported");
		return -ENOTSUP;
	}

	if(ref->disable)
		return -ENAVAIL;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}
#endif
static int lcfg_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct lcfg_desc *ref = (const struct lcfg_desc *)ref_desc;
	struct lcfg_desc *desc = (struct lcfg_desc *)user_desc;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if(match_options)
	{
		pr_err("not supported");
		return -ENOTSUP;
	}

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int pic_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct pic_desc *ref = (const struct pic_desc *)ref_desc;
	struct pic_desc *desc = (struct pic_desc *)user_desc;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if(match_options)
	{
		pr_err("not supported");
		return -ENOTSUP;
	}

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int qbman_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct qbman_desc *ref = (const struct qbman_desc *)ref_desc;
	struct qbman_desc *desc = (struct qbman_desc  *)user_desc;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if((match_options) && (match_options != SOC_DB_SET_VAL))
	{
		pr_err("not supported");
		return -ENOTSUP;
	}

	/*if(ref->disable)
		return -ENAVAIL;*/

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);
	desc->clk = sys_get_platform_clk() * 1000;

	return 0;
}

static int qbman_swportal_match_desc(const void *ref_desc,
                               void *user_desc,
                               int match_options,
                               uint32_t id_increment,
                               uint64_t addr_increment)
{
	const struct qbman_swportal_desc *ref = (const struct qbman_swportal_desc *)ref_desc;
	struct qbman_swportal_desc *desc = (struct qbman_swportal_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_QBMAN_PORTAL_DESC_ID)
		no_match |= (desc->swportal_id != (ref->swportal_id + id_increment));
	if (match_options & SOC_DB_QBMAN_PORTAL_DESC_QBMAN_ID)
		no_match |= (desc->qbman_id != ref->qbman_id);
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->swportal_id += id_increment;
	desc->paddr_cena += addr_increment;
	desc->vaddr_cena = fsl_phys_to_virt(desc->paddr_cena);
	desc->cena_size = addr_increment;
	desc->paddr_cinh += addr_increment;
	desc->vaddr_cinh = fsl_phys_to_virt(desc->paddr_cinh);
	desc->cinh_size = addr_increment;

	return 0;
}

static int mc_portal_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct mc_portal_desc *ref = (const struct mc_portal_desc *)ref_desc;
	struct mc_portal_desc *desc = (struct mc_portal_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_MC_PORTAL_DESC_ID)
		no_match |= (desc->portal_id != (ref->portal_id + id_increment));
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->portal_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int soc_mc_portal_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct soc_mc_portal_desc *ref = (const struct soc_mc_portal_desc *)ref_desc;
	struct soc_mc_portal_desc *desc = (struct soc_mc_portal_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_SOC_MC_PORTAL_DESC_ID)
		no_match |= (desc->portal_id != (ref->portal_id + id_increment));
	if (match_options & SOC_DB_SOC_MC_PORTAL_DESC_PADDR)
		no_match |= (desc->paddr != (ref->paddr + addr_increment));
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->portal_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int uart_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct uart_desc *ref = (const struct uart_desc *)ref_desc;
	struct uart_desc *desc = (struct uart_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_UART_DESC_ID)
		no_match |= (desc->uart_id != (ref->uart_id + id_increment));
	if (no_match)
		return -ENAVAIL;;

	/*if(ref->disable)
		return -ENAVAIL;*/

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->uart_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int edma_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct edma_desc *ref = (const struct edma_desc *)ref_desc;
	struct edma_desc *desc = (struct edma_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_EDMA_DESC_ID)
		no_match |= (desc->edma_id != (ref->edma_id + id_increment));
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->edma_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;

}

static int edma_block_match_desc(const void *ref_desc,
                           void *user_desc,
                           int match_options,
                           uint32_t id_increment,
                           uint64_t addr_increment)
{
	const struct edma_block_desc *ref = (const struct edma_block_desc *)ref_desc;
	struct edma_block_desc *desc = (struct edma_block_desc *)user_desc;
	int no_match = 0;

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if (match_options & SOC_DB_EDMA_BLOCK_DESC_ID)
		no_match |= (desc->edma_block_id != (ref->edma_block_id + id_increment));
	if (no_match)
		return -ENAVAIL;;

	/* matched; copy the descriptor and increment relevant fields */
	*desc = *ref;
	desc->edma_block_id += id_increment;
	desc->paddr += addr_increment;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int sec_match_desc(const void *ref_desc,
			  void *user_desc,
			  int match_options,
			  uint32_t id_increment,
			  uint64_t addr_increment)
{
	const struct sec_desc *ref = ref_desc;
	struct sec_desc *desc = user_desc;

	if((match_options) && (match_options != SOC_DB_SET_VAL))
	{
		pr_err("not supported");
		return -ENOTSUP;
	}

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	if(ref->disable)
		return -ENAVAIL;

	*desc = *ref;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static int qdma_match_desc(const void *ref_desc,
			  void *user_desc,
			  int match_options,
			  uint32_t id_increment,
			  uint64_t addr_increment)
{
	const struct qdma_desc *ref = ref_desc;
	struct qdma_desc *desc = user_desc;

	if((match_options) && (match_options != SOC_DB_SET_VAL))
	{
		pr_err("not supported");
		return -ENOTSUP;
	}

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	/*if(ref->disable)
		return -ENAVAIL;*/

	*desc = *ref;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}


static int dppmu_match_desc(const void *ref_desc,
			  void *user_desc,
			  int match_options,
			  uint32_t id_increment,
			  uint64_t addr_increment)
{
	const struct dppmu_desc *ref = ref_desc;
	struct dppmu_desc *desc = user_desc;

	if((match_options) && (match_options != SOC_DB_SET_VAL))
	{
		pr_err("not supported");
		return -ENOTSUP;
	}

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);
	/* Don't need to translate the physical address of the device to virtual address since
	 the DPPMU CCSR offset is fixed and can be accessed directly by MC. Both virtual and physical addresses
	 are configured for each derivative/processor in soc_db_arch.h */
	*desc = *ref;

	return 0;
}

static int dce_match_desc(const void *ref_desc,
			  void *user_desc,
			  int match_options,
			  uint32_t id_increment,
			  uint64_t addr_increment)
{
	const struct dce_desc *ref = ref_desc;
	struct dce_desc *desc = user_desc;

	if((match_options) && (match_options != SOC_DB_SET_VAL))
	{
		pr_err("not supported");
		return -ENOTSUP;
	}

	ONLY_CHECK_IF_EXISTS(user_desc, match_options);

	/*if(ref->disable)
		return -ENAVAIL;*/

	*desc = *ref;
	desc->vaddr = fsl_phys_to_virt(desc->paddr);

	return 0;
}

static const struct soc_db_module_info mod_info[] =
{
 {SOC_MODULE_MC, (void*)soc_db.mc_db, ARRAY_SIZE(soc_db.mc_db), ARRAY_EL_SIZE(soc_db.mc_db), mc_match_desc},
 {SOC_MODULE_PEBM, (void*)soc_db.pebm_db, ARRAY_SIZE(soc_db.pebm_db), ARRAY_EL_SIZE(soc_db.pebm_db), memc_match_desc},
 {SOC_MODULE_DPDDR, (void*)soc_db.dpddr_db, ARRAY_SIZE(soc_db.dpddr_db), ARRAY_EL_SIZE(soc_db.dpddr_db), memc_match_desc},
 {SOC_MODULE_MC_DDR, (void*)soc_db.mc_ddr_db, ARRAY_SIZE(soc_db.mc_ddr_db), ARRAY_EL_SIZE(soc_db.mc_ddr_db), memc_match_desc},
 {SOC_MODULE_DMEM, (void*)soc_db.dmem_db, ARRAY_SIZE(soc_db.dmem_db), ARRAY_EL_SIZE(soc_db.dmem_db), dmem_match_desc},
 {SOC_MODULE_MC_BT, (void*)soc_db.mc_bt_db, ARRAY_SIZE(soc_db.mc_bt_db), ARRAY_EL_SIZE(soc_db.mc_bt_db), mc_bt_match_desc},
 {SOC_MODULE_MC_PORTAL, (void*)soc_db.mc_portal_db, ARRAY_SIZE(soc_db.mc_portal_db), ARRAY_EL_SIZE(soc_db.mc_portal_db), mc_portal_match_desc},
 {SOC_MODULE_SOC_MC_PORTAL, (void*)soc_db.soc_mc_portal_db, ARRAY_SIZE(soc_db.soc_mc_portal_db), ARRAY_EL_SIZE(soc_db.soc_mc_portal_db), soc_mc_portal_match_desc},
 {SOC_MODULE_EIOP, (void *)soc_db.eiop_block_db, ARRAY_SIZE(soc_db.eiop_block_db), ARRAY_EL_SIZE(soc_db.eiop_block_db), eiop_match_desc},
 {SOC_MODULE_EIOP_IFP, (void*)soc_db.eiop_ifp_db, ARRAY_SIZE(soc_db.eiop_ifp_db), ARRAY_EL_SIZE(soc_db.eiop_ifp_db), eiop_ifp_match_desc},
 {SOC_MODULE_EIOP_PORT, (void*)soc_db.eiop_port_db, ARRAY_SIZE(soc_db.eiop_port_db), ARRAY_EL_SIZE(soc_db.eiop_port_db), eiop_port_match_desc },
 {SOC_MODULE_EIOP_MEMAC, (void*)soc_db.eiop_memac_db, ARRAY_SIZE(soc_db.eiop_memac_db), ARRAY_EL_SIZE(soc_db.eiop_memac_db), memac_match_desc },
 {SOC_MODULE_EIOP_RTC, (void*)soc_db.eiop_rtc_db, ARRAY_SIZE(soc_db.eiop_rtc_db), ARRAY_EL_SIZE(soc_db.eiop_rtc_db), eiop_rtc_match_desc },
 {SOC_MODULE_EIOP_PPORT_CON, (void*)soc_db.pport_connections_db, ARRAY_SIZE(soc_db.pport_connections_db), ARRAY_EL_SIZE(soc_db.pport_connections_db), eiop_pport_conn_match_desc },
 {SOC_MODULE_EIOP_VPORT_CON, (void*)soc_db.vport_connections_db, ARRAY_SIZE(soc_db.vport_connections_db), ARRAY_EL_SIZE(soc_db.vport_connections_db), eiop_vport_conn_match_desc },
 {SOC_MODULE_CTLU, (void*)soc_db.ctlu_db, ARRAY_SIZE(soc_db.ctlu_db), ARRAY_EL_SIZE( soc_db.ctlu_db), ctlu_match_desc},
 {SOC_MODULE_AIOP, (void*)soc_db.aiop_tile_db,	ARRAY_SIZE(soc_db.aiop_tile_db), ARRAY_EL_SIZE(soc_db.aiop_tile_db), aiop_tile_match_desc},
 {SOC_MODULE_UART, (void*)soc_db.uart_db, ARRAY_SIZE(soc_db.uart_db), ARRAY_EL_SIZE(soc_db.uart_db), uart_match_desc},
 {SOC_MODULE_CPM, (void*)soc_db.cpm_db,	ARRAY_SIZE(soc_db.cpm_db), ARRAY_EL_SIZE(soc_db.cpm_db), cpm_match_desc},
 {SOC_MODULE_LCFG, (void*)soc_db.lcfg_db,ARRAY_SIZE(soc_db.lcfg_db), ARRAY_EL_SIZE(soc_db.lcfg_db),lcfg_match_desc},
 {SOC_MODULE_PIC, (void*)soc_db.pic_db,	ARRAY_SIZE(soc_db.pic_db), ARRAY_EL_SIZE(soc_db.pic_db), pic_match_desc},
 {SOC_MODULE_EDMA, (void*)soc_db.edma_db,ARRAY_SIZE(soc_db.edma_db), ARRAY_EL_SIZE(soc_db.edma_db), edma_match_desc},
 {SOC_MODULE_EDMA_BLOCK, (void*)soc_db.edma_block_db,ARRAY_SIZE(soc_db.edma_block_db), ARRAY_EL_SIZE(soc_db.edma_block_db), edma_block_match_desc},
 {SOC_MODULE_QBMAN, (void*)soc_db.qbman_db,ARRAY_SIZE(soc_db.qbman_db), ARRAY_EL_SIZE(soc_db.qbman_db), qbman_match_desc},
 {SOC_MODULE_QBMAN_PORTAL, (void*)soc_db.qbman_swportal_db,ARRAY_SIZE(soc_db.qbman_swportal_db), ARRAY_EL_SIZE(soc_db.qbman_swportal_db), qbman_swportal_match_desc},
 {SOC_MODULE_SEC, (void*)soc_db.sec_db, ARRAY_SIZE(soc_db.sec_db), ARRAY_EL_SIZE(soc_db.sec_db), sec_match_desc},
 {SOC_MODULE_QDMA, (void*)soc_db.qdma_db, ARRAY_SIZE(soc_db.qdma_db), ARRAY_EL_SIZE(soc_db.qdma_db), qdma_match_desc},
 {SOC_MODULE_DCE, (void*)soc_db.dce_db, ARRAY_SIZE(soc_db.dce_db), ARRAY_EL_SIZE(soc_db.dce_db), dce_match_desc},
 {SOC_MODULE_SERDES, (void*)soc_db.serdes_db, ARRAY_SIZE(soc_db.serdes_db), ARRAY_EL_SIZE(soc_db.serdes_db), serdes_match_desc},
 {SOC_MODULE_MDIO, (void*)soc_db.mdio_db, ARRAY_SIZE(soc_db.mdio_db), ARRAY_EL_SIZE(soc_db.mdio_db), mdio_match_desc},
 {SOC_MODULE_DCFG, (void*)soc_db.dcfg_db, ARRAY_SIZE(soc_db.dcfg_db), ARRAY_EL_SIZE(soc_db.dcfg_db), dcfg_match_desc},
 {SOC_MODULE_DPPMU, (void*)soc_db.dppmu_db, ARRAY_SIZE(soc_db.dppmu_db), ARRAY_EL_SIZE(soc_db.dppmu_db), dppmu_match_desc},
};

int soc_db_get_desc(enum soc_module module,
                    int match_options,
                    void *user_desc,
                    int *iter)
{
	int ret, desc_idx, relative_idx, sum = 0, count = 0;
	const struct soc_db_range *range;

	ASSERT_COND(mod_info[module].module == module);
	ASSERT_COND(mod_info[module].match_desc);

	range = (const struct soc_db_range *)mod_info[module].db_head;
	if (match_options & SOC_DB_SET_VAL)
	{
		if (iter == NULL)
			return -EINVAL;
		desc_idx = 0;
	}
	else
		desc_idx = (iter ? *iter : 0); /* caller may request first match only */

	/* make sure not to iterate past the end of the database */
	while ((count < mod_info[module].db_item_count) && (range->num != 0)) {
		/* find/verify the database item for current iteration */
		while (desc_idx < (sum + range->num)) {
			/* iterate over items in this group */
			relative_idx = (desc_idx - sum);
			ret = mod_info[module].match_desc(
			        PTR_MOVE(range, sizeof(struct soc_db_range)),
			        user_desc, match_options,
			        range->id_inc * relative_idx,
			        range->addr_inc * relative_idx);

			desc_idx++; /* try the next index */

			if (ret == 0) {
				if(match_options & SOC_DB_SET_VAL)
				{
					*iter = (int)PTR_MOVE(range, sizeof(struct soc_db_range));
					return 0;
				}
				/* match found - update iterator
				 * for future searches and return */
				if (iter)
					*iter = desc_idx;
				return 0;
			}
		}

		/* try the next database item */
		count++;
		sum += range->num;
		range = PTR_MOVE(range, mod_info[module].db_item_size);
	}
	return -ENAVAIL;
}

/*
int soc_db_get_range(enum soc_module module,
                    int match_options,
                    void *user_desc,
                    uint32_t *num,
                    int *iter)
{
	int ret, desc_idx, relative_idx, sum = 0, count = 0;
	const struct soc_db_range *range;

	if(match_options && (match_options != SOC_DB_DESC_CONTAINER_ID))
	{
		pr_err("Not supported match_options");
		return -ENOTSUP;
	}

	range = (const struct soc_db_range *)mod_info[module].db_head;
	range = PTR_MOVE(range, (mod_info[module].db_item_size * (*iter)));

	if(soc_db_get_desc(module, match_options, user_desc, iter) == 0)
	{
		if (range->id_inc == 1)
			*num = range->num;
		else
			*num = 1;
		return 0;
	}

	return -ENAVAIL;
}
*/

void soc_db_mac_set_type(int eiop_id,
                         int mac_id,
                         uint32_t enet_if,
                         uint8_t autoneg,
                         uint8_t debug_link_check,
                         uint32_t rate,
                         int serdes_id,
                         uint8_t master_lane,
                         uint8_t no_lanes,
                         uint32_t converted,
                         uint32_t enet_prev)
{
	struct eiop_memac_desc desc = {0};
	struct eiop_memac_desc *memac_desc;

	desc.mac_id = mac_id;
	desc.eiop_id = eiop_id;
	soc_db_get_desc(SOC_MODULE_EIOP_MEMAC,
		SOC_DB_MAC_DESC_ID | SOC_DB_MAC_DESC_EIOP_ID | SOC_DB_SET_VAL,
		&desc,
		(int *)&memac_desc);
	if (memac_desc->disable)
		return;

	memac_desc->enet_if = enet_if;
	memac_desc->autoneg = autoneg;
	memac_desc->debug_link_check = debug_link_check;
	memac_desc->rate = rate;
	memac_desc->serdes_id = serdes_id;
	memac_desc->enet_prev = enet_prev;
	memac_desc->converted = (int)converted;
	
	/* just to be on the safe side */
	if ( (memac_desc->type != E_EMAC_1G_10G_25G_TYPE) &&
			(memac_desc->type != E_EMAC_40G_50G_100G_TYPE)) {
		memac_desc->type = E_EMAC_10_100_1G_10G_TYPE;
	}

	/* init registry memory map */
	memac_desc->mem_map = soc_db_select_mac_memmap(memac_desc->type);
	memac_desc->master_lane = master_lane;
	memac_desc->no_lanes = no_lanes;
}

void soc_db_dce_disable()
{
	struct dce_desc desc = {0};
	struct dce_desc *dce_desc;


	soc_db_get_desc(SOC_MODULE_DCE, SOC_DB_SET_VAL,
		&desc,
		(int *)&dce_desc);

	dce_desc->disable = 1;
}


void soc_db_sec_disable()
{
	struct sec_desc desc = {0};
	struct sec_desc *sec_desc;


	soc_db_get_desc(SOC_MODULE_SEC, SOC_DB_SET_VAL,
		&desc,
		(int *)&sec_desc);

	sec_desc->disable = 1;
}

void soc_db_macs_disable(int eiop_id, uint32_t mac_mask)
{
	struct eiop_memac_desc desc = { 0 };
	struct eiop_memac_desc *memac_desc;
	int mac_id = 1;
	uint32_t tmp_mac_mask = mac_mask;
	int err;

	while (tmp_mac_mask) {
		if (tmp_mac_mask & 1) {

			desc.mac_id = mac_id;
			desc.eiop_id = eiop_id;
			err = soc_db_get_desc(
				SOC_MODULE_EIOP_MEMAC,
				SOC_DB_MAC_DESC_ID | SOC_DB_MAC_DESC_EIOP_ID
				| SOC_DB_SET_VAL,
				&desc, (int *)&memac_desc);
			if( !err )
				memac_desc->disable = 1;
		}
		mac_id++;
		tmp_mac_mask >>= 1;
	}
}

void soc_db_aiops_disable(uint32_t aiop_mask)
{
	struct aiop_tile_desc desc = { 0 };
	struct aiop_tile_desc *aiop_desc;
	int aiop_tile_id = 0;
	uint32_t tmp_aiop_mask = aiop_mask;

	while (tmp_aiop_mask) {
		if (tmp_aiop_mask & 1) {
			desc.tile_id = aiop_tile_id;
			soc_db_get_desc(
				SOC_MODULE_AIOP,
				SOC_DB_AIOP_TILE_DESC_ID | SOC_DB_SET_VAL,
				&desc, (int *)&aiop_desc);

			aiop_desc->disable = 1;
		}
		aiop_tile_id++;
		tmp_aiop_mask >>= 1;
	}
}

void soc_db_eiops_disable(uint32_t eiop_mask)
{
	struct eiop_desc desc = {0};
	struct eiop_desc *eiop_desc;
	int eiop_id = 0;
	uint32_t tmp_eiop_mask = eiop_mask;

	while (tmp_eiop_mask) {
		if(tmp_eiop_mask & 1)
		{
			desc.eiop_id = eiop_id;
			soc_db_get_desc(SOC_MODULE_EIOP,
				SOC_DB_EIOP_DESC_ID | SOC_DB_SET_VAL,
				&desc,
				(int *)&eiop_desc);

			eiop_desc->disable = 1;
		}
		eiop_id ++;
		tmp_eiop_mask >>= 1;

	}
}

void soc_db_duarts_disable(uint32_t uarts_mask)
{
	struct uart_desc desc = {0};
	struct uart_desc *uart_desc;
	int uart_id = 0;
	uint32_t tmp_uarts_mask = uarts_mask;

	while (tmp_uarts_mask) {
		if(tmp_uarts_mask & 1)
		{
			desc.uart_id = uart_id;
			soc_db_get_desc(SOC_MODULE_UART,
				SOC_DB_UART_DESC_ID | SOC_DB_SET_VAL,
				&desc,
				(int *)&uart_desc);

			uart_desc->disable = 1;
		}
		uart_id ++;
		tmp_uarts_mask >>= 1;
	}
}

void soc_db_dpddr_disable()
{
	struct mem_desc desc = {0};
	struct mem_desc *dpddr_desc;


	soc_db_get_desc(SOC_MODULE_DPDDR,
		SOC_DB_SET_VAL,
		&desc,
		(int *)&dpddr_desc);

	dpddr_desc->disable = 1;
}

void soc_db_dpddr_set_size(uint64_t dpddr_size)
{
	struct mem_desc desc = {0};
	struct mem_desc *dpddr_desc;

	soc_db_get_desc(SOC_MODULE_DPDDR,
		SOC_DB_SET_VAL,
		&desc,
		(int *)&dpddr_desc);

	dpddr_desc->size = dpddr_size;
}

void soc_db_pebm_disable()
{
	struct memc_desc desc = {0};
	struct memc_desc *pebm_desc;


	soc_db_get_desc(SOC_MODULE_PEBM,
		SOC_DB_SET_VAL,
		&desc,
		(int *)&pebm_desc);

	pebm_desc->disable = 1;
}

static void soc_db_qbman_disable()
{
	struct qbman_desc desc = {0};
	struct qbman_desc *qbman_desc;


	soc_db_get_desc(SOC_MODULE_QBMAN, SOC_DB_SET_VAL,
		&desc,
		(int *)&qbman_desc);

	qbman_desc->disable = 1;
}

void soc_db_update(int i)
{
	soc_db = *soc_db.var_select.variances[i].soc_db;
}

int soc_db_select(struct soc_rev *soc_rev, char *name)
{
	int i;

	if ((soc_rev->system_version & soc_db.var_select.system_version_mask) != soc_db.var_select.system_version_arch)
	{
		pr_err("This MC image is not compatible with SoC\n");
		return -EINVAL;
	}

	for (i = 0; i < ARRAY_SIZE(soc_db.var_select.variances); i++ )
	{
		if ((soc_rev->major == soc_db.var_select.variances[i].major) &&
				(soc_rev->minor == soc_db.var_select.variances[i].minor) &&
				((soc_rev->system_version & soc_db.var_select.personality_mask) == soc_db.var_select.variances[i].personality))
		{

			strcpy(name, &soc_db.var_select.variances[i].name[0]);
			if (soc_db.var_select.variances[i].soc_db != 0) /* not the default revision */
				soc_db_update(i);
			break;
		}

	}
	if (i == ARRAY_SIZE(soc_db.var_select.variances))
	{
		pr_err("This MC image is not compatible with SoC\n");
		return -EINVAL;
	}

	return 0;
}

/*
 * remove entry from soc_db
 */
static void remove_from_soc_db(enum soc_module module, int entry_no)
{
	const struct soc_db_range *range_dest;
	const struct soc_db_range *range_src;
	int i;

	ASSERT_COND(mod_info[module].module == module);
	ASSERT_COND(mod_info[module].match_desc);

	range_dest = PTR_MOVE(mod_info[module].db_head,
			entry_no * mod_info[module].db_item_size);
	range_src = PTR_MOVE(range_dest, mod_info[module].db_item_size);

	/* copy everything else one spot up */
	for (i = entry_no; i < mod_info[module].db_item_count - 1; i++) {
		/* end of the line, no need to go further */
		if (range_dest->num == 0)
			break;

		memcpy(range_dest, range_src, mod_info[module].db_item_size);

		range_dest = PTR_MOVE(range_dest, mod_info[module].db_item_size);
		range_src = PTR_MOVE(range_src, mod_info[module].db_item_size);
	}

	/* if the last one or up to the very end */
	if (i == (mod_info[module].db_item_count - 1)) {
		memset(range_dest, 0x0, mod_info[module].db_item_size);
		return;
	}
}

/*
 * add entry at the end in soc_db
 */
static int insert_to_soc_db(enum soc_module module, void *data)
{
	const struct soc_db_range *range;
	struct soc_db_range range_temp = {0};
	int i;

	ASSERT_COND(mod_info[module].module == module);
	ASSERT_COND(mod_info[module].match_desc);

	range = (const struct soc_db_range *)mod_info[module].db_head;

	/* find first open space */
	for(i = 0; i < mod_info[module].db_item_count; i++) {
		if(range->num != 0) {
			range = PTR_MOVE(range, mod_info[module].db_item_size);
			continue;
		}
		range_temp = (struct soc_db_range) {.num = 1, .id_inc = 1, .addr_inc = 0};
		memcpy(range, &range_temp, sizeof(struct soc_db_range));
		memcpy(PTR_MOVE(range, sizeof(struct soc_db_range)), data,
				mod_info[module].db_item_size - sizeof(struct soc_db_range));

		return 0;
	}

	return -ENAVAIL;
}

/* just add the new recycle ports by copying the required info from physical ports
 * delete the info from physical ports db since it's not used anymore
 * */
static int copy_from_eiop_pp_to_eiop_rp(struct eiop_port_desc port_desc)
{
	int count = 0, sum = 0, desc_idx = 0, relative_idx, ret, count2, temp;
	struct soc_db_range *range, *free_range;
	struct eiop_port_desc *top_half;

	range = (struct soc_db_range *)mod_info[SOC_MODULE_EIOP_PORT].db_head;

	/* remove as ethernet port */
	while ((count < mod_info[SOC_MODULE_EIOP_PORT].db_item_count) && (range->num != 0)) {
		/* find/verify the database item for current iteration */
		while (desc_idx < (sum + range->num)) {
			/* iterate over items in this group */
			relative_idx = (desc_idx - sum);
			ret = mod_info[SOC_MODULE_EIOP_PORT].match_desc(
			        PTR_MOVE(range, sizeof(struct soc_db_range)),
			        &port_desc, SOC_DB_PORT_DESC_ID |
					SOC_DB_PORT_DESC_TYPE | SOC_DB_PORT_DESC_EIOP_ID,
			        range->id_inc * relative_idx,
			        range->addr_inc * relative_idx);

			desc_idx++; /* try the next index */

			/*  not found */
			if(ret)
				continue;

			/* bottom half is just relative_idx */
			temp = (int)range->num, range->num = (uint32_t)relative_idx;

			/* find first empty slot... */
			free_range = (struct soc_db_range *)mod_info[SOC_MODULE_EIOP_PORT].db_head;
			count2 = 0;
			while ((count2 < mod_info[SOC_MODULE_EIOP_PORT].db_item_count) && (free_range->num != 0))
				count2 += 1,
				free_range = PTR_MOVE(free_range, mod_info[SOC_MODULE_EIOP_PORT].db_item_size);
			/* if overflow, exit function */
			if (count2 == mod_info[SOC_MODULE_EIOP_PORT].db_item_count)
				return -EDOM;

			/*... and put the top half */
			free_range->num = temp - range->num - 1, free_range->id_inc = range->id_inc,
					free_range->addr_inc = range->addr_inc;
			top_half = PTR_MOVE(free_range, sizeof(struct soc_db_range));
			memcpy(top_half, &port_desc, sizeof(struct eiop_port_desc));
			top_half->paddr += free_range->addr_inc;
			top_half->vaddr = fsl_phys_to_virt(top_half->paddr);
			top_half->port_id += free_range->id_inc;
		}
		/* try the next database item */
		count++;
		sum += range->num;
		range = PTR_MOVE(range, mod_info[SOC_MODULE_EIOP_PORT].db_item_size);
	}

	/* add as recycle port */
	port_desc.type = EIOP_RECYCLE_PORT;
	port_desc.rate = EIOP_PORT_RATE_20_G;

	return insert_to_soc_db(SOC_MODULE_EIOP_PORT, &port_desc);
}

static inline int move_from_pport_to_vport(struct pport_connections_desc connection_desc, int loc)
{
	struct vport_connections_desc desc = {0};
	int err;

	desc.ceetm_id = connection_desc.ceetm_id;
	desc.dcp_id = connection_desc.dcp_id;
	desc.eiop_id = connection_desc.eiop_id;
	desc.lni_id = connection_desc.lni_id;
	desc.port_id = connection_desc.port_id;

	/* if correctly inserted in vport_con, remove from pport_con */
	if((err = insert_to_soc_db(SOC_MODULE_EIOP_VPORT_CON, &desc)))
		return err;
	remove_from_soc_db(SOC_MODULE_EIOP_PPORT_CON, loc);

	return 0;
}

void soc_db_salvage_pp_as_rp(int eiop_id)
{
	struct eiop_memac_desc memac_desc = {0};
	struct eiop_port_desc port_desc;
	struct pport_connections_desc connection_desc;
	int iter = 0, iter2;

	pr_debug("soc_db: Salvaging PP as RP...\n");

	/* for all macs in this eiop */
	while (soc_db_get_desc(SOC_MODULE_EIOP_MEMAC, SOC_DB_NO_MATCH_FIELDS,
			&memac_desc, &iter) == 0) {
		if ((memac_desc.eiop_id == eiop_id) && (memac_desc.link_type == DPMAC_LINK_TYPE_RECYCLE) ) {
			/* Move the information from pport_connections_db to vport_connections_db.
			 * Update eiop_port_db with the new recycle ports.
			 */
			pr_debug("soc_db: Salvaging: mac_id = %d\n", memac_desc.mac_id);

			/* find the port description with that mac id */
			memset(&port_desc, 0x0, sizeof(struct eiop_port_desc));
			port_desc.port_id = memac_desc.mac_id;
			port_desc.type = EIOP_ETHERNET_PORT;
			port_desc.eiop_id = eiop_id;
			soc_db_get_desc(SOC_MODULE_EIOP_PORT, SOC_DB_PORT_DESC_ID |
					SOC_DB_PORT_DESC_TYPE | SOC_DB_PORT_DESC_EIOP_ID,
					&(port_desc), NULL);
			/* add a new entry in eiop_port_db, break if too many */
			if(copy_from_eiop_pp_to_eiop_rp(port_desc))
				break;

			/* find the connection based on that mac id */
			memset(&connection_desc, 0x0, sizeof(struct pport_connections_desc));
			connection_desc.eiop_id = eiop_id;
			connection_desc.mac_id = memac_desc.mac_id;
			iter2 = 0;
			soc_db_get_desc(SOC_MODULE_EIOP_PPORT_CON, SOC_DB_PORT_CON_DESC_MAC_ID |
	                   SOC_DB_PORT_CON_DESC_EIOP_ID, &connection_desc, &iter2);
			/* move it in vport_connections_db */
			move_from_pport_to_vport(connection_desc, iter2 - 1);
		}
		memset(&memac_desc, 0, sizeof(memac_desc));
	}
}

void soc_db_remove_unused_ports(int eiop_id)
{
	struct eiop_memac_desc memac_desc;
	struct pport_connections_desc connection_desc;
	int iter = 0, iter2;

	pr_debug("soc_db: Removing unused ports from database...\n");

	/* for all macs in this eiop */
	while (soc_db_get_desc(SOC_MODULE_EIOP_MEMAC, SOC_DB_NO_MATCH_FIELDS,
			&memac_desc, &iter) == 0) {
		if ((memac_desc.eiop_id == eiop_id) && memac_desc.disable) {
			pr_debug("soc_db: Removing port@%d\n", memac_desc.mac_id);

			/* find the connection based on mac id */
			memset(&connection_desc, 0x0, sizeof(struct pport_connections_desc));
			connection_desc.eiop_id = eiop_id;
			connection_desc.mac_id = memac_desc.mac_id;
			iter2 = 0;
			soc_db_get_desc(SOC_MODULE_EIOP_PPORT_CON, SOC_DB_PORT_CON_DESC_MAC_ID |
					   SOC_DB_PORT_CON_DESC_EIOP_ID, &connection_desc, &iter2);

			remove_from_soc_db(SOC_MODULE_EIOP_PPORT_CON, iter2 - 1);
		}
	}
}

struct mac_info{
	int mac_id;
	uint32_t rate;
	int ceetm;
	int lniid;
};

static int cmpfunc (const void * a, const void * b) {
   return (int)( ((struct mac_info*)b)->rate - ((struct mac_info*)a)->rate );
}

#define LNI_GROUP_SIZE 4
#define LNI_GROUP_MASK 0x0f
#define LNI_IN_GROUP(lni) (0x1 << (lni)%LNI_GROUP_SIZE)
#define LNI_GROUP(lni) ((lni)/LNI_GROUP_SIZE)

/*
 * When mapping sub-portals to LNIs, consideration must also be given to the
 * bandwidth requirements of those sub-portals. For the purpose of dequeue
 * processing each CEETM instance treats its LNIs as 3 groups, for example a
 * CEETM instance with 12 LNIs groups them as LNI 0-3, LNI 4-7, and LNI 8-11.
 * To optimize resource usage, sub-portals should be mapped to LNIs in such a
 * way as to spread the traffic load as evenly as possible among the three LNI
 * groups, for example a CEETM instance that is used by sub-portals connected
 * to four 10GbE and four 1GbE physical ports could map two 10GbE to one LNI
 * group, and one 10GbE plus two 1GbE ports to the remaining two LNI groups. In
 * a DCP portal which supports more than one CEETM instance, the same
 * consideration extends to the CEETM instances within a portal, that is,
 * enable sub-portals on CEETM instances to spread the load evenly among
 * instances, and then evenly between the 3 LNI groups within each instance.
 *
 * [2.21.12 CEETM Sub-Portal Mapping and Physical Interface Switchover]
 */
static int find_next_free_lni_in_ceetm_balanced(
		int lni_group_total_rate[QBMAN_MAX_CEETM_INS][QBMAN_MAX_LNI/LNI_GROUP_SIZE],
		int assign_lni_group[QBMAN_MAX_CEETM_INS][QBMAN_MAX_LNI/LNI_GROUP_SIZE],
		int *nr_lni,  int ceetm, int *next_lni)
{
	int err = 0, j, min_lni_group_rate;

	/* Find the LNI group which has the least bandwidth already accumulated */
	min_lni_group_rate =  lni_group_total_rate[ceetm][0];
	*next_lni = 0;
	for (j = 1; j < QBMAN_MAX_LNI/LNI_GROUP_SIZE; j++)
	{
		if ((min_lni_group_rate > lni_group_total_rate[ceetm][j]) &&
				assign_lni_group[ceetm][j] != LNI_GROUP_MASK)
		{
			min_lni_group_rate = lni_group_total_rate[ceetm][j];
			*next_lni = j * LNI_GROUP_SIZE;
		}
	}

	/* Find the first free LNI from the group */
	while((assign_lni_group[ceetm][LNI_GROUP(*next_lni)] & (LNI_IN_GROUP(*next_lni))) != 0)
		(*next_lni)++;

	if (*next_lni > nr_lni[ceetm]){
		err = -ENAVAIL;
	}

	return err;
}

static int find_next_ceetm_lni_balanced(int ceetm_to_set, int lni_to_set, int nr_ceetm, int *ceetm_total_rate,
		int lni_group_total_rate[QBMAN_MAX_CEETM_INS][QBMAN_MAX_LNI/LNI_GROUP_SIZE],
		int assign_lni_group[QBMAN_MAX_CEETM_INS][QBMAN_MAX_LNI/LNI_GROUP_SIZE],
		int *nr_lni,  int *next_ceetm, int *next_lni)
{
	/* Find the next CEETM instance to alocate a port to */
	*next_ceetm = ceetm_to_set + 1;
	if (*next_ceetm >= nr_ceetm)
		*next_ceetm = 0;
	if (ceetm_total_rate[ceetm_to_set] < ceetm_total_rate[*next_ceetm])
		*next_ceetm = ceetm_to_set;

	return find_next_free_lni_in_ceetm_balanced(lni_group_total_rate,
						    assign_lni_group,
						    nr_lni, *next_ceetm, next_lni);
}

static int find_next_free_lni( int nr_ceetm, int assign_lni_group[QBMAN_MAX_CEETM_INS][QBMAN_MAX_LNI/LNI_GROUP_SIZE],
		int *nr_lni,  int *next_ceetm, int *next_lni)
{
	int err = 0;
	
	/* ceetm management*/
	*next_ceetm = 0;	
	*next_lni = 0;
	
	while((assign_lni_group[*next_ceetm][LNI_GROUP(*next_lni)] & (LNI_IN_GROUP(*next_lni))) != 0)
	{
		(*next_lni)++;
		if (*next_lni > nr_lni[*next_ceetm]){
			(*next_ceetm)++;
			if (*next_ceetm > nr_ceetm)
				err =  -ENAVAIL;
			break;
		}
	}
	return err;
}

static int soc_db_translate_port_rate(enum eiop_port_ethernet_rate port_rate)
{
	int rate = 0;
	
	switch (port_rate)
	{
		case EIOP_PORT_RATE_1_G:
			rate  = 1000;
			break;
		case EIOP_PORT_RATE_2_5_G:
			rate  = 2500;
			break;
		case EIOP_PORT_RATE_5_G:
			rate  = 5000;			
			break;
		case EIOP_PORT_RATE_10_G:
			rate  = 10000;
			break;
		case EIOP_PORT_RATE_20_G:
			rate  = 20000;
			break;
		case EIOP_PORT_RATE_25_G:
			rate  = 25000;
			break;
		case EIOP_PORT_RATE_40_G:
			rate  = 40000;
			break;
		case EIOP_PORT_RATE_50_G:
			rate  = 50000;
			break;
		case EIOP_PORT_RATE_100_G:
			rate  = 100000;
			break;
	}
	
	return rate;
}

static int get_recycle_port_rate(int port_id, int eiop_id)
{
	struct eiop_port_desc port_desc;

	/* find the port description with that MAC id */
	memset(&port_desc, 0x0, sizeof(struct eiop_port_desc));
	port_desc.port_id = port_id;
	port_desc.type = EIOP_RECYCLE_PORT;
	port_desc.eiop_id = eiop_id;
	soc_db_get_desc(SOC_MODULE_EIOP_PORT,
			SOC_DB_PORT_DESC_ID | SOC_DB_PORT_DESC_TYPE | SOC_DB_PORT_DESC_EIOP_ID,
			&(port_desc), NULL);

	return soc_db_translate_port_rate(port_desc.rate);
}

/* Update the structures that hold the current allocation of ports across CEETM
 * instances and LNI groups.
 *  - the total rate per CEETM instances - ceetm_total_rate
 *  - the rate per LNI group from a CEETM - lni_group_total_rate
 * Also mark the CEETM,LNI pair as being used (not available for further
 * allocation) in assign_lni_group
 */
static inline void setup_allocated_ceetm(int *ceetm_total_rate,
		int lni_group_total_rate[QBMAN_MAX_CEETM_INS][QBMAN_MAX_LNI/LNI_GROUP_SIZE],
		int assign_lni_group[QBMAN_MAX_CEETM_INS][QBMAN_MAX_LNI/LNI_GROUP_SIZE],
		int ceetm, int lni, int rate)
{
		ceetm_total_rate[ceetm] += rate;
		lni_group_total_rate[ceetm][LNI_GROUP(lni)] += rate;
		assign_lni_group[ceetm][LNI_GROUP(lni)] |= LNI_IN_GROUP(lni);
}

int soc_db_ceetm_rate_balance(int eiop_id)
{
	struct eiop_memac_desc memac_desc;
	struct pport_connections_desc connection_desc;
	struct pport_connections_desc *desc;
	struct vport_connections_desc vport_desc;
	struct eiop_port_desc port_desc;
	int iter = 0, rate = 0, i, err, err1;
	struct mac_info port_info[MAX_PPORT_CFG];
	int nr_ceetm =0, nr_lni[QBMAN_MAX_CEETM_INS];
	int ceetm_to_set=0, next_ceetm = 0, lni_to_set= 0;
	int assign_lni_group[QBMAN_MAX_CEETM_INS][QBMAN_MAX_LNI/LNI_GROUP_SIZE];
	int ceetm_total_rate[QBMAN_MAX_CEETM_INS],next_lni;
	int lni_group_total_rate[QBMAN_MAX_CEETM_INS][QBMAN_MAX_LNI/LNI_GROUP_SIZE];
	struct qbman_desc qbman_desc;
	int mac_id, ceetm, lni;

	pr_debug("soc_db: Balance port on ceetm...\n");
	
	memset(assign_lni_group, 0 , sizeof(assign_lni_group));
	memset(nr_lni, 0 , sizeof(nr_lni));
	memset(ceetm_total_rate, 0 , sizeof(ceetm_total_rate));
	memset(lni_group_total_rate, 0 , sizeof(lni_group_total_rate));
	
	/* Get number of ceetm instance and lni*/
	
	err = sys_get_desc(SOC_MODULE_QBMAN, eiop_id, &qbman_desc, NULL); /* iterator */
	
	if (err)
	{
		pr_err("Failed to get qbman description.\n");
		return err;
	}
	
	for (iter = 0; iter < QBMAN_MAX_DCP; iter++)
	{
		if (qbman_desc.dcp[iter].valid
			&& qbman_desc.dcp[iter].ceetm_support)
		{
			nr_ceetm =0;
			for (i = 0; i < QBMAN_MAX_CEETM_INS; i++)
			{
				if (qbman_desc.dcp[iter].valid
					&& qbman_desc.dcp[iter].ceetm_instance[i].valid)
				{
					//Last lni used for recycle port
					nr_lni[i] = (int)qbman_desc.dcp[iter].ceetm_instance[i].num_lnis-1;
					nr_ceetm++;
				}
			}
		}
	}
	

	iter = 0;
	/*Find recycle ports*/
	while (sys_get_desc(SOC_MODULE_EIOP_VPORT_CON, SOC_DB_NO_MATCH_FIELDS,
			    &vport_desc, &iter) == 0) {
		ceetm = vport_desc.ceetm_id;
		lni = vport_desc.lni_id;

		/* Update the rate distribution structures */
		rate = get_recycle_port_rate(vport_desc.port_id, eiop_id);
		setup_allocated_ceetm(ceetm_total_rate, lni_group_total_rate,
				      assign_lni_group, ceetm, lni, rate);
	}


	/*Find out valid ports and rate*/
	iter = 0;

	while (soc_db_get_desc(SOC_MODULE_EIOP_PPORT_CON, SOC_DB_NO_MATCH_FIELDS,
			&connection_desc, &iter) == 0) {

			memac_desc.mac_id = connection_desc.mac_id;
			soc_db_get_desc(SOC_MODULE_EIOP_MEMAC, SOC_DB_MAC_DESC_ID, &memac_desc, NULL);

			port_info[iter-1].mac_id = connection_desc.mac_id;
			port_info[iter-1].rate = memac_desc.rate;
	}

	qsort(port_info, (uint32_t)iter, sizeof(struct mac_info), cmpfunc);

	/* Setup physical ports on the DPC requested CEETM instance before
	 * attempting to balance any other ports
	 */
	for (i = 0; i < iter; i++) {
		mac_id = port_info[i].mac_id;
		if (!(dpc.macs[mac_id - 1].dpc_mask & DPC_MAC_MASK_CEETM_ID))
			continue;

		/* Find a free LNI */
		ceetm = dpc.macs[mac_id - 1].ceetm_id;
		err = find_next_free_lni_in_ceetm_balanced(lni_group_total_rate,
							   assign_lni_group,
							   nr_lni, ceetm,
							   &lni);
		if (err) {
			pr_err("error finding a free LNI in CEETM instance #%d requested for PP %d\n",
			       ceetm, mac_id);
			return err;
		}

		/* Update the port info structure */
		port_info[i].ceetm = (int)ceetm;
		port_info[i].lniid = lni;

		/* Update the rate distribution structures */
		setup_allocated_ceetm(ceetm_total_rate, lni_group_total_rate,
				      assign_lni_group, ceetm, lni,
				      port_info[i].rate);
		pr_debug("MAC.%d(PP) requested ceetm_id = %d and got lni = %d (rate = %d)\n",
			 mac_id, port_info[i].ceetm, port_info[i].lniid, port_info[i].rate);
	}

	/* After all ports specified in the DPC have been assigned a CEETM/LNI
	 * pair run the algorithm again to find the next IDs to be used for the
	 * remaining ports
	 */
	ceetm_to_set = 0;
	lni_to_set = 0;
	err = find_next_ceetm_lni_balanced(ceetm_to_set, lni_to_set, nr_ceetm,
					   ceetm_total_rate,
					   lni_group_total_rate,
					   assign_lni_group,
					   nr_lni, &next_ceetm,
					   &next_lni);
	for (i = 0; i<iter; i++)
	{
		/* Do not go through the ports that have already been assigned
		 * a CEETM instance and LNI (requested from DPC ceetm_instance)
		 */
		mac_id = port_info[i].mac_id;
		if (dpc.macs[mac_id - 1].dpc_mask & DPC_MAC_MASK_CEETM_ID) {
			continue;
		}

		ceetm_to_set = next_ceetm;
		lni_to_set = next_lni;

		port_info[i].ceetm = ceetm_to_set;
		port_info[i].lniid = lni_to_set;
		setup_allocated_ceetm(ceetm_total_rate, lni_group_total_rate,
				      assign_lni_group, port_info[i].ceetm,
				      port_info[i].lniid, port_info[i].rate);

		err = find_next_ceetm_lni_balanced(ceetm_to_set, lni_to_set, nr_ceetm, ceetm_total_rate,
				lni_group_total_rate, 
				assign_lni_group,
				nr_lni, 
				&next_ceetm, 
				&next_lni);
		
		if (err)
		{
			err1 = find_next_free_lni(nr_ceetm, assign_lni_group, nr_lni, &next_ceetm, &next_lni);
			if (err1)
			{
				pr_err("Failed to dynamic balance ports. Fall back to static alloc.\n");
				return err1;
			}
		}
		pr_debug("MAC.%d(PP) was balanced to ceetm_id = %d and lni = %d (rate = %d)\n",
			 port_info[i].mac_id, port_info[i].ceetm,
			 port_info[i].lniid, port_info[i].rate);
	}
	
	memset(&connection_desc, 0, sizeof(connection_desc));
	for (i = 0; i<iter; i++){
		
		connection_desc.mac_id = port_info[i].mac_id;
		err = soc_db_get_desc(SOC_MODULE_EIOP_PPORT_CON, SOC_DB_PORT_CON_DESC_MAC_ID|SOC_DB_SET_VAL,
					&connection_desc, (int *)&desc);
		
		ASSERT_COND(err == 0);
		
		if (err)
		{
			pr_err("Failed to find entry for mac %d\n",connection_desc.mac_id);
			continue;
		}
		
		if (desc)
		{
			desc->ceetm_id = port_info[i].ceetm;
			desc->lni_id = port_info[i].lniid;
		}
	}

	pr_debug("Total rate ceetm 0 %d, ceetm 1 %d\n",ceetm_total_rate[0],ceetm_total_rate[1]);
	pr_debug("Total rate ceetm 0 lnig0 %d lnig1 %d lnig2 %d\n",lni_group_total_rate[0][0],
			lni_group_total_rate[0][1],lni_group_total_rate[0][2]);
	pr_debug("Total rate ceetm 1 lnig0 %d lnig1 %d lnig2 %d\n",lni_group_total_rate[1][0],
			lni_group_total_rate[1][1],lni_group_total_rate[1][2]);
	
	return 0;
}

int soc_db_is_lx2162_package()
{
	if (soc_db.var_select.options == DEVICE_PACKAGE_SMALL_LX2162)
		return 1;
	return 0;
}

int soc_db_is_lx2_rev2()
{
	struct t_platform soc_platform;
	struct soc_rev *soc_rev = &soc_platform.soc_info.rev;

	memset(&soc_platform, 0, sizeof(t_platform));

	dcfg_get_revision(&soc_platform.soc_info.rev.major,
					  &soc_platform.soc_info.rev.minor,
					  &soc_platform.soc_info.rev.system_version);

	/* if we are not running on a LX2xxx platform, exit */
	if (soc_rev->system_version & soc_db.var_select.system_version_mask != DEVICE_PACKAGE_LX2_SYSTEM_VER)
		return 0;

	return (soc_rev->major == 2);
}

uint32_t *soc_db_select_mac_memmap(int type)
{
	return &soc_db.emac_regs_mem_map[type][0];
}

int soc_db_get_recycle_port_bandwidth()
{
	struct vport_connections_desc vport_desc;
	struct eiop_port_desc port_desc;
	int iter = 0;

	/*Find first recycle port */
	sys_get_desc(SOC_MODULE_EIOP_VPORT_CON, SOC_DB_NO_MATCH_FIELDS,
					&vport_desc, NULL);

	memset(&port_desc, 0x0, sizeof(struct eiop_port_desc));
	port_desc.port_id = vport_desc.port_id;
	port_desc.type = EIOP_RECYCLE_PORT;
	port_desc.eiop_id = 0;
	soc_db_get_desc(SOC_MODULE_EIOP_PORT, SOC_DB_PORT_DESC_ID |
				SOC_DB_PORT_DESC_TYPE | SOC_DB_PORT_DESC_EIOP_ID,
				&(port_desc), NULL);

	return soc_db_translate_port_rate(port_desc.rate);
}

int soc_db_use_recycle_port_timestamp()
{
	return soc_db.use_recycle_port_timestamp;
}
