/*
 * Copyright 2013-2020 NXP
 */

#include "fsl_types.h"
#include "common/fsl_string.h"
#include "common/fsl_stdio.h"
#include "fsl_io.h"
#include "fsl_platform.h"
#include "fsl_malloc.h"
#include "fsl_sys.h"
#include "drivers/fsl_mc.h"

void build_apps_array(struct sys_module_desc *apps);
int mc_app_init(void);

#ifdef MC_CLI
int cli_app_init(void);

#define APPS                            \
{                                       \
    {cli_app_init},        \
    {mc_app_init},         \
    {NULL} /* never remove! */    \
}
#else

#define APPS                            \
{                                       \
    {mc_app_init},         \
    {NULL} /* never remove! */    \
}
#endif


void build_apps_array(struct sys_module_desc *apps)
{
	struct sys_module_desc apps_tmp[] = APPS;
	memcpy(apps, apps_tmp, sizeof(apps_tmp));
}

#ifdef MC_CLI
#include "fsl_console.h"
#ifdef EMULATOR
#include "fsl_timer.h"
#endif
#include "cli.h"

int mc_app_init(void)
{
	fsl_print("Running MC_CLI app, waiting for events ...\n");

#if 0
	event_transfer(git_msg_block, 0xdeadbeaf);
#endif

#ifdef EMULATOR
#else
    while(sys_get_char());
#endif

	while (1) {
#ifdef EMULATOR
        cli_simple_run_command("qfq 0x3 0x4 0x5 0x6 0x9 0xa 0xb 0xc", 0);
        cli_simple_run_command("qcq 0 0x1 0x11", 0);
        cli_simple_run_command("qopr 1 2", 0);
        cli_simple_run_command("md 0x28180d14", 0);
        timer_udelay(10000);
#else        
        cli_simple_iteration();
#endif
    }

	/* TODO - complete!*/
	return 0;
}
#else
int mc_app_init(void)
{
	fsl_print("Running MC app, waiting for events ...\n");

#if 0
	event_transfer(git_msg_block, 0xdeadbeaf);
#endif

	while (1) {}

	/* TODO - complete!*/
	return 0;
}
#endif
